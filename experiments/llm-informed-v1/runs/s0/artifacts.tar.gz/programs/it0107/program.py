# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets, dynamic mean-based targets,
and a size-match bonus derived from the empirical item-size distribution.

Capacity is 100.  Items arrive online.  We rank each bin by how close the
residual after placement is to an attractive target residual (harmonic
fractions of capacity, plus multiples/complements of the running mean size).
On top of that, we add a bonus when the post-placement residual is exactly
zero or matches an item size observed so far, so a later item can close the
bin cleanly.  This reduces tiny unfillable residues without abandoning the
target geometry that already performs well.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

# Empirical item-size frequency, indexed by size (1..100).  Used to decide
# whether a post-placement residual is likely closable by a single later item.
_SIZE_FREQ = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    # Dynamic target residuals: harmonic fractions of capacity, mixed with
    # multiples/complements of the running mean item size.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Fullness-weighted exact-fit bonus: consolidate near-full bins.
    fullness = bins / _CAP
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    # Size-match bonus: reward residuals (rounded) that equal 0 or a size seen
    # before, so the bin can be closed by a single later item of that size.
    if _TOTAL > 0.0:
        r_int = np.rint(residual_after).astype(np.int64)
        r_int = np.clip(r_int, 0, 100)
        freq = _SIZE_FREQ[r_int]
        prob = freq / _TOTAL
        score = score + 1.5 * prob

    _SIZE_FREQ[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END

