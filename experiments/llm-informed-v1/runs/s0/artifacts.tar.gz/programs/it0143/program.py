# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by best fit.

Capacity is 100. Items arrive online. We rank the bins the item fits in by how
close the post-placement residual is to a small set of empirically attractive
residuals, then break near-ties toward tighter fits.

Attractive residuals are derived from the observed item-size histogram: the most
frequent sizes seen so far, plus their complements (100 - s). A leftover equal to
a frequent upcoming size can be closed exactly by one item; a leftover equal to a
complement leads to a tight fit on the next matching item. The target list is
refreshed incrementally from a candidate pool instead of a full argsort pass,
keeping the per-call cost small and stable over the whole instance.

Best-fit pressure grows as the instance fills up: early on, keep many bins open;
later, prefer tight fits to avoid wasting capacity. A mild penalty discourages
nonzero residuals smaller than any item seen so far (unfillable space), and a
small bonus rewards residuals that can still be closed by a pair of plausible
sizes.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_MIN_SIZE = 101.0

# Cached attractive-residual targets.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
# Cached pair-sum set (0/1 indexed by residual 0..100).
_PAIR_OK = np.zeros(101, dtype=np.float64)
_REFRESH = 8
_N_ITEMS = 0.0


def _rebuild_targets():
    global _TARGETS, _PAIR_OK
    counts = _SIZE_COUNT[1:101]
    top_idx = np.argpartition(counts, -12)[-12:] + 1
    top_idx = top_idx[counts[top_idx - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top_idx:
        s = float(s)
        targets.add(s)
        targets.add(_CAP - s)
    _TARGETS = np.array(sorted(targets), dtype=np.float64)

    plausible = np.nonzero(counts > 0)[0] + 1
    pair = np.zeros(101, dtype=np.float64)
    if plausible.size:
        support = np.zeros(101, dtype=np.float64)
        support[plausible] = 1.0
        conv = np.convolve(support, support)
        n = min(101, conv.size)
        pair[:n] = (conv[:n] > 0).astype(np.float64)
    _PAIR_OK = pair


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Smooth distance to the nearest attractive residual: exp(-d) falloff.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)
    target_score = np.exp(-0.5 * best)

    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    fit_weight = 0.04 + 0.10 * frac

    score = target_score - fit_weight * residual_after

    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)
    score += 0.015 * _PAIR_OK[ri]

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
