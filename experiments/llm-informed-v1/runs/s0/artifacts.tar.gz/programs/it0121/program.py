# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by best fit.

Capacity is 100. Items arrive online. The residual a bin is left with is what a
future item must match, so the most useful residuals are the item sizes that
actually show up. We track a histogram of observed sizes, derive the most
frequent sizes as targets, and score each bin primarily by how close its
post-placement residual is to one of those attractive residuals. An extra bonus
rewards exact matches, weighted by how common that target is, and a modest
best-fit pressure breaks near-ties toward a tighter fit.

Guard: a nonzero residual smaller than the smallest item seen so far can never be
filled by any future item, so it is wasted space; such bins get a mild tie-break
penalty that does not override the main target logic.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached target arrays, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_TARGET_W = np.array([1.0, 1.0], dtype=np.float64)
_REFRESH = 32


def _rebuild_targets():
    global _TARGETS, _TARGET_W
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:10] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]

    wmap = {}
    for s in top:
        s = float(s)
        c = counts[int(s) - 1]
        wmap[s] = max(wmap.get(s, 0.0), c)              # leftover == common size
        wmap[_CAP - s] = max(wmap.get(_CAP - s, 0.0), c)  # complement also useful

    wmap[0.0] = max(wmap.get(0.0, 0.0), 1.0)
    wmap[_CAP] = max(wmap.get(_CAP, 0.0), 1.0)

    vals = np.array(sorted(wmap.keys()), dtype=np.float64)
    _TARGETS = vals
    _TARGET_W = np.array([wmap[v] for v in vals], dtype=np.float64)
    # Normalize weights so the exact-match bonus stays tie-break scale.
    mx = _TARGET_W.max()
    if mx > 0:
        _TARGET_W = _TARGET_W / mx


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Exact-match bonus weighted by the target's observed frequency.
    exact = np.where(d <= 1e-9, _TARGET_W[None, :], 0.0)
    exact_bonus = exact.max(axis=1)

    # Primary: prefer a residual matching a commonly arriving size.
    # Secondary: exact residual matches weighted by frequency.
    # Tie-break: modest best-fit pressure (prefer smaller residual).
    score = -best + 0.3 * exact_bonus - 0.05 * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END

