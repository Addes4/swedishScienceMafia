# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by
size-aware best fit.

Capacity is 100. Items arrive online. We learn which residual values are actually
useful: the most frequent item sizes seen so far are the residuals a future item
is most likely to (nearly) fill. We score each bin by how likely its
post-placement residual can be closed by future items, using a smooth
interpolated histogram, then break near-ties toward tighter fits, with the
strength of that pressure scaled by how large the arriving item is.

Guard 1: a residual that is nonzero but smaller than the smallest item size seen
so far can never be filled by any future item (wasted space) -> mild penalty.

Guard 2: closability. For each candidate post-placement residual r we add a
probability-weighted bonus: the smoothed empirical probability that a future item
is near r (single-item close) plus a discounted probability that r is hittable by
two items (pair-sum table). This is smooth, so near-perfect residuals still get
partial credit.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached arrays, refreshed as the histogram grows.
_PAIR_SCORE = np.zeros(101, dtype=np.float64)
_EXACT_SCORE = np.zeros(101, dtype=np.float64)
_NEAR_SCORE = np.zeros(101, dtype=np.float64)
_CLOSE_SCORE = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)

# Small bandwidth kernel over residuals for "near a frequent size" credit.
_KERNEL_R = 3
_KR = np.arange(-_KERNEL_R, _KERNEL_R + 1, dtype=np.float64)
_KERNEL = np.exp(-0.5 * (_KR / 1.5) ** 2)

# Fine grid for the interpolated closability score.
_GRID = np.arange(0.0, _CAP + 1.0, 1.0)


def _rebuild_targets():
    global _PAIR_SCORE, _EXACT_SCORE, _NEAR_SCORE, _CLOSE_SCORE
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:12] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]

    # Probability-weighted two-item sum table over residuals 0..100.
    support = np.zeros(101, dtype=np.float64)
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    if plausible.size:
        w = _SIZE_COUNT[plausible]
        support[plausible] = w / w.sum()
    conv = np.convolve(support, support)
    n = min(101, conv.size)
    pair = np.zeros(101, dtype=np.float64)
    pair[:n] = conv[:n]
    m = pair.max()
    if m > 0:
        pair = pair / m
    _PAIR_SCORE = pair

    # Smooth exact-fill score: empirical probability a future item equals r.
    exact = support.copy()
    mx = exact.max()
    if mx > 0:
        exact = exact / mx
    _EXACT_SCORE = exact

    # Smooth "near a frequent size" score: convolve the support with a small
    # Gaussian kernel so residuals within a few units of a frequent size still
    # get partial credit (items are roughly continuous, not discrete).
    near = np.convolve(support, _KERNEL, mode="same")
    near = near[:101]
    if near.size < 101:
        pad = np.zeros(101, dtype=np.float64)
        pad[: near.size] = near
        near = pad
    mn = near.max()
    if mn > 0:
        near = near / mn
    _NEAR_SCORE = near

    # Continuous closability score for any residual r in [0, 100]:
    # probability a future item lands close to r (Gaussian-smoothed support
    # evaluated by interpolation), blended with the two-item pair-sum table.
    grid = _GRID
    # Gaussian-smoothed single-item density evaluated at every integer residual.
    g = np.zeros(101, dtype=np.float64)
    g[:101] = near[:101]
    # Combine single-item closability with pair-sum closability.
    close = 0.7 * g + 0.3 * pair
    cmin, cmax = close.min(), close.max()
    if cmax > cmin:
        close = (close - cmin) / (cmax - cmin)
    _CLOSE_SCORE = close


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Continuous, empirically-weighted closability of the resulting residual.
    r = np.clip(residual_after, 0.0, _CAP)
    lo = np.floor(r).astype(np.int64)
    hi = np.minimum(lo + 1, 100)
    frac = r - lo
    close = _CLOSE_SCORE[lo] * (1.0 - frac) + _CLOSE_SCORE[hi] * frac

    # Size-aware best-fit pressure: larger arriving items prefer snug bins.
    fr = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    base_w = 0.02 + 0.06 * fr
    size_lean = (item - 50.0) / 50.0
    fit_weight = base_w * (1.0 + 0.6 * size_lean)

    score = 1.0 * close - fit_weight * residual_after

    # Guard 1: penalize tiny nonzero residuals no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Guard 2: exact-fill and pair bonuses (already embedded in close, kept small).
    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)
    score += 0.1 * _EXACT_SCORE[ri]

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
