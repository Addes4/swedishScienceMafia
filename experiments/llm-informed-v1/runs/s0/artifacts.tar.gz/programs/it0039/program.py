# EVOLVE-BLOCK-START
"""Harmonic-style bin choice blended with best-fit consolidation.

For online bin packing with item sizes bounded by 1 (capacity 100), the
"Harmonic" family classifies items into size classes and packs each class into
reserved bins. A robust, smooth variant: score a bin by how close the residual
after placement is to a "good" residual (a packable remainder), while also
rewarding tighter fits so partially-full bins get consolidated. We combine a
target-proximity term with a best-fit term, plus an online-learned bonus for
residuals that match commonly seen item sizes.

The frequency bonus is normalized by the running maximum count rather than the
total, so its strength does not decay as the instance grows.
"""
import numpy as np

_CAP = 100.0

# Harmonic breakpoints scaled to capacity: remainders we like to leave open so
# later items of the "matching" size class can close them well.
_TARGETS = np.array(
    [
        _CAP / 2.0,          # 50
        _CAP / 3.0,          # ~33
        (2.0 * _CAP) / 3.0,  # ~67
        _CAP / 4.0,          # 25
        (3.0 * _CAP) / 4.0,  # 75
        _CAP / 5.0,          # 20
        0.0,                 # perfectly full
    ],
    dtype=np.float64,
)

# Online histogram of item sizes (1..100), used to reward residuals that a
# typical future item could close exactly.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual_after = bins - item  # new remaining capacity after placing here
    # Distance to the nearest attractive target residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)
    # Primary: closeness to an attractive target residual (harmonic structure).
    # Secondary: tighter fits (smaller residual_after) consolidate bins.
    score = -best - 0.18 * residual_after

    # Online-learned bonus: reward residuals matching a commonly observed size,
    # since a later item of that size can close the bin exactly. Normalize by
    # the running maximum count so the signal stays strong over the whole run.
    _SIZE_COUNT[item] += 1.0
    max_count = _SIZE_COUNT.max()
    if max_count > 0.0:
        resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
        freq = _SIZE_COUNT[resid_int] / max_count
        score = score + 8.0 * freq

    return score
# EVOLVE-BLOCK-END

