# EVOLVE-BLOCK-START
"""Best-fit with an online-learned "closable residual" bonus.

Capacity is 100, items arrive online. The primary signal is best-fit (prefer the
bin where the residual after placement is smallest, i.e. tighten partially-full
bins). On top of that we reward leaving a residual exactly equal to a size class
we have observed often: if a later item of that size arrives, the bin closes
exactly. The per-size weight is normalized to stay O(1) over time so the signal
does not decay as the instance grows.
"""
import numpy as np

_CAP = 100.0

# Empirical counts of item sizes seen so far (index = integer size 1..100).
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL
    residual_after = bins - item

    # Primary: best-fit. Prefer small residuals (tighter packing).
    score = -residual_after

    if _TOTAL > 0.0:
        mx = _SIZE_COUNT.max()
        if mx > 0.0:
            resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
            counts = _SIZE_COUNT[resid_int]
            # Normalized closable-residual bonus, stays O(1) over time.
            score = score + 8.0 * (counts / mx)
            # Strong bonus for exactly closing a bin (residual 0).
            score = score + 2.0 * (resid_int == 0)

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END
