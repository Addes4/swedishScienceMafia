# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets and fullness-weighted fit bonus.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic fractions of
capacity), rewarding tighter fits to consolidate partially-filled bins. The
histogram bonus is replaced by a fullness-weighted exact-fit bonus: a bin that
is already nearly full and can be closed cleanly is preferred over one that
would leave a small but hard-to-fill residual.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0

# Adaptive "closing residual" table: for each residual value r, an exponential
# moving estimate of how often a bin left at residual r was subsequently closed
# exactly by an incoming item. Initialized to zero (no prior knowledge).
_CLOSE = np.zeros(101, dtype=np.float64)
_PREV_RES = -1  # residual of the bin chosen on the previous call, or -1


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _PREV_RES
    residual_after = bins - item

    # Learn: if an item exactly closed the bin we picked last time, reward that
    # residual value so we seek similar closable states going forward.
    if _PREV_RES >= 0:
        if item == _PREV_RES:
            _CLOSE[_PREV_RES] += 1.0
        _CLOSE *= 0.999  # decay keeps the table adaptive and bounded

    # Dynamic target residuals: harmonic fractions of capacity, mixed with
    # multiples/complements of the running mean item size.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Fullness-weighted exact-fit bonus: strongly reward placing the item into a
    # bin that becomes tightly packed (small residual) when the bin was already
    # mostly full, i.e. consolidating near-full bins.
    fullness = (bins / _CAP)
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    # Adaptive closing-residual bonus: prefer residuals that have historically
    # been closed exactly by a following item.
    ra = np.clip(residual_after, 0, 100).astype(np.int64)
    score = score + 0.5 * _CLOSE[ra]

    # Record the residual of the bin this item will land in (highest score,
    # first on ties) so the next call can update the closing table.
    choice = int(np.argmax(score))
    _PREV_RES = int(residual_after[choice])

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END
