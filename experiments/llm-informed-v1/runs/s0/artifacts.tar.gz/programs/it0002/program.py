# EVOLVE-BLOCK-START
"""Best fit with a reserve for large items and fragmentation control for small items."""
import numpy as np

_remaining = {}  # bin_index -> remaining capacity (tracked across calls)
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _seen
    n = len(bins)

    # Build index list of all bins and their capacities as we know them.
    # `bins` here only contains bins the item fits in, but the array is aligned to
    # the full bin order via the fact that unused bins (cap 100) are always present.
    # We reconstruct absolute indices: the array given is a filtered view whose order
    # matches bin order. We simply treat positions in this array as the candidate bins.
    idx = np.nonzero(bins < 100)[0]  # partially used (may be empty for first items)

    # Score: prefer best fit among already-open bins; for large items, avoid opening new bins.
    # Pure best fit score.
    base = -(bins - item).astype(np.float64)

    if idx.size > 0 and item <= 33:
        # Small item: strongly prefer partially filled bins (any non-full bin),
        # best fit within them; penalize empty bins.
        best_partial = bins[idx].min()
        j = idx[np.argmin(bins[idx])]
        score = base.copy()
        penalty = 1000.0
        # empty bins (cap 100) get pushed far down
        empty = bins == 100
        score[empty] -= penalty
        # within partial bins, standard best fit already handled by base
        return score
    else:
        return base
# EVOLVE-BLOCK-END
