# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets, fullness-weighted fit bonus,
and a recency/aging bias that keeps packing concentrated in few open bins.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic fractions of
capacity), rewarding tighter fits to consolidate partially-filled bins. The
histogram bonus is replaced by a fullness-weighted exact-fit bonus: a bin that
is already nearly full and can be closed cleanly is preferred over one that
would leave a small but hard-to-fill residual. A small recency bonus steers
items into bins that were just used, reducing the number of bins that are
simultaneously "open" with tiny residuals.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0

# Per-bin last-used step (index within the instance) for recency bias.
_LAST_USED = np.zeros(0, dtype=np.float64)
_STEP = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _LAST_USED, _STEP
    residual_after = bins - item

    # Dynamic target residuals: harmonic fractions of capacity, mixed with
    # multiples/complements of the running mean item size.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Fullness-weighted exact-fit bonus: strongly reward placing the item into a
    # bin that becomes tightly packed (small residual) when the bin was already
    # mostly full, i.e. consolidating near-full bins.
    fullness = (bins / _CAP)
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    # Recency bonus: prefer bins used recently so packing concentrates.
    if _LAST_USED.shape[0] != bins.shape[0]:
        _LAST_USED = np.zeros(bins.shape[0], dtype=np.float64)
    age = _STEP - _LAST_USED
    score = score + 0.05 / (1.0 + age)

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item

    # Record the chosen bin (highest score, first on ties).
    chosen = int(np.argmax(score))
    _STEP += 1.0
    _LAST_USED[chosen] = _STEP

    return score
# EVOLVE-BLOCK-END
