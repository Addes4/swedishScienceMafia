# EVOLVE-BLOCK-START
"""Best-fit-first bin choice with a light harmonic target and a stable
"closable residual" bonus.

Capacity is 100. Items have a Weibull-shaped size distribution with mean ~40,
so items frequently pair to near-100. The rule:
  * Primary signal: tightest fit (smallest residual after placement), which
    consolidates partially-filled bins and reduces fragmentation.
  * Light harmonic-target term: mild pull toward classic residuals that leave
    a nice remainder structure.
  * Closable-residual bonus: reward a post-placement residual that exactly
    matches a commonly observed item size, so a later item can close the bin.
    Weighted by a stable normalized frequency so the signal does not vanish.
"""
import numpy as np

_CAP = 100.0

_TARGETS = np.array(
    [
        _CAP / 2.0,          # 50
        _CAP / 3.0,          # ~33
        (2.0 * _CAP) / 3.0,  # ~67
        _CAP / 4.0,          # 25
        (3.0 * _CAP) / 4.0,  # 75
        _CAP / 5.0,          # 20
        0.0,                 # perfectly full
    ],
    dtype=np.float64,
)

# Smoothed histogram of observed item sizes (Laplace-ish smoothing via reuse).
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
# Running max of the smoothed probability, used to stabilize the bonus scale.
_MAX_P = 1.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _MAX_P
    residual_after = bins - item

    # Primary: tightest fit. Strong weight so consolidation dominates.
    score = -3.0 * residual_after

    # Light harmonic-target pull.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    score = score - 0.35 * d.min(axis=1)

    if _TOTAL > 0.0:
        resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
        # Normalized frequency (probability), stable over time.
        p = _SIZE_COUNT / _TOTAL
        counts = p[resid_int]
        # Scale by running max observed probability so bonus stays O(1).
        score = score + 4.0 * (counts / _MAX_P)

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    p_item = _SIZE_COUNT[item] / _TOTAL
    if p_item > _MAX_P:
        _MAX_P = p_item
    return score
# EVOLVE-BLOCK-END
