# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets and a best-fit refinement.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic fractions of
capacity), then break ties toward the closest fit: among bins whose residual is
near a productive harmonic target, the one with the smallest residual is
preferred. A fullness-weighted exact-fit bonus consolidates nearly-full bins.
"""
import numpy as np

_CAP = 100.0

_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    targets = _FRACS * _CAP

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)

    # Base: closeness to a harmonic target residual.
    score = -best

    # Best-fit refinement: among comparable target matchings, prefer the
    # smallest post-placement residual (tighter packing).
    score = score - 0.06 * residual_after

    # Fullness-weighted exact-fit bonus: strongly reward placing the item into a
    # bin that becomes tightly packed when the bin was already mostly full.
    fullness = bins / _CAP
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END

