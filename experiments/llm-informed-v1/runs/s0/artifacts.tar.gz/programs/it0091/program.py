# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets and fullness-weighted fit bonus.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic fractions of
capacity), rewarding tighter fits to consolidate partially-filled bins. A
fullness-weighted exact-fit bonus prefers sealing nearly-full bins cleanly.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)
_TARGETS = _FRACS * _CAP


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual_after = bins - item

    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Fullness-weighted exact-fit bonus: strongly reward placing the item into a
    # bin that becomes tightly packed (small residual) when the bin was already
    # mostly full, i.e. consolidating near-full bins.
    fullness = bins / _CAP
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.5 * exact

    return score
# EVOLVE-BLOCK-END
