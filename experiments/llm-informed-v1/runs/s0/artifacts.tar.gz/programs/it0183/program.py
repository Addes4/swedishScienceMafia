# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by
size-aware best fit.

Capacity is 100. Items arrive online. We learn which residual values are actually
useful: the most frequent item sizes seen so far are the residuals a future item
is most likely to exactly fill. We score each bin by how close its post-placement
residual is to a small set of such empirically attractive values, then break
near-ties toward tighter fits, with the strength of that pressure scaled by how
large the arriving item is.

Guard 1: a residual that is nonzero but smaller than the *typical smallest*
item size seen so far (estimated from the empirical distribution) can rarely be
filled by any future item (wasted space) -> graded penalty.

Guard 2: closability. For each candidate post-placement residual r we add a
probability-weighted bonus: the empirical probability that a future item exactly
equals r (single-item close) plus a discounted probability that r is hittable by
two items (pair-sum table). This is smooth, so near-perfect residuals still get
partial credit.

Guard 3: exact-close preference. Residuals of exactly 0 are ideal, so they get a
small extra bump beyond the exact-fill score, encouraging clean closures.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0
# Estimate of the item size below which items are "rare enough not to count":
# used to gauge which nonzero residuals are practically unfillable.
_SMALL_Q = 1.0

# Cached arrays, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_PAIR_SCORE = np.zeros(101, dtype=np.float64)
_EXACT_SCORE = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)


def _rebuild_targets():
    global _TARGETS, _PAIR_SCORE, _EXACT_SCORE, _SMALL_Q
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:12] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)          # a leftover equal to this size closes cleanly
        targets.add(_CAP - s)   # complement also leaves a fillable residual
    _TARGETS = np.array(sorted(targets), dtype=np.float64)

    # Probability-weighted two-item sum table over residuals 0..100.
    support = np.zeros(101, dtype=np.float64)
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    if plausible.size:
        w = _SIZE_COUNT[plausible]
        support[plausible] = w / w.sum()
    conv = np.convolve(support, support)
    n = min(101, conv.size)
    pair = np.zeros(101, dtype=np.float64)
    pair[:n] = conv[:n]
    m = pair.max()
    if m > 0:
        pair = pair / m
    _PAIR_SCORE = pair

    # Smooth exact-fill score: empirical probability a future item equals r.
    exact = support.copy()
    mx = exact.max()
    if mx > 0:
        exact = exact / mx
    _EXACT_SCORE = exact

    # Estimate a "practically minimal fillable" item size: the size at which
    # cumulative probability reaches ~8%.  Residuals below this are rarely
    # closed by a single future item and tend to be wasted.
    cum = np.cumsum(support)
    idx = np.nonzero(cum >= 0.08)[0]
    if idx.size:
        _SMALL_Q = float(idx[0] + 1)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Size-aware best-fit pressure: larger arriving items prefer snug bins.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    base_w = 0.02 + 0.06 * frac
    size_lean = (item - 50.0) / 50.0
    fit_weight = base_w * (1.0 + 0.6 * size_lean)

    score = -best - fit_weight * residual_after

    # Guard 1: graded penalty for tiny nonzero residuals no seen item could fill.
    thresh = min(_MIN_SIZE, _SMALL_Q)
    if thresh <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < thresh)
        score -= 0.02 * waste

    # Guard 2: smooth closability bonus (single- and two-item).
    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)
    score += 0.02 * _PAIR_SCORE[ri]
    score += 0.5 * _EXACT_SCORE[ri]

    # Guard 3: small extra bump for perfectly closed bins.
    score += 0.03 * (ri == 0)

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
