# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets and a seal bonus.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic fractions of
capacity), mixed with the running mean item size. A saturating seal bonus
strongly rewards leaving a residual so small that it is below the smallest
item size observed so far, since such a residual is effectively unfillable
future waste and is best concentrated in already-nearly-full bins.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE
    residual_after = bins - item

    # Dynamic target residuals: harmonic fractions of capacity, mixed with
    # multiples/complements of the running mean item size.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Seal bonus: if the post-placement residual is smaller than the smallest
    # item size seen so far, it can never be filled and is wasted space. Since
    # small residuals are unavoidable somewhere, prefer concentrating them in
    # bins that are already nearly full (and thus nearly closed). Saturate so
    # that any sub-min residual gets roughly the same strong preference, and
    # weight by fullness to keep the bin selection stable.
    min_size = _MIN_SIZE if _MIN_SIZE <= _CAP else 1.0
    fullness = bins / _CAP
    if min_size <= 1.0:
        seal = np.exp(-residual_after)
    else:
        seal = np.exp(-residual_after / min_size)
    score = score + 2.0 * seal * fullness

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END

