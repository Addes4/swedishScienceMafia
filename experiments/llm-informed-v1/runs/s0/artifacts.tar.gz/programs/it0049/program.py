# EVOLVE-BLOCK-START
"""Adaptive target-residual bin choice.

Capacity is 100. Items arrive online with a Weibull-shaped size distribution
(mean ~40). Instead of fixed capacity fractions, we derive attractive target
residuals from the empirical mean item size m: leaving a residual near m lets a
single typical item close the bin; leaving residual near 2m allows a two-item
close. We blend closeness to those targets with a mild best-fit consolidation
term and a stable histogram bonus.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SUM
    residual_after = bins - item

    # Empirical mean item size (fallback to 40).
    if _TOTAL > 0.0:
        m = _SUM / _TOTAL
    else:
        m = 40.0
    if m < 1.0:
        m = 40.0

    targets = np.array([m, 2.0 * m, 0.0, m / 2.0], dtype=np.float64)

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.20 * residual_after

    if _TOTAL > 0.0:
        resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
        counts = _SIZE_COUNT[resid_int]
        mx = _SIZE_COUNT.max()
        if mx > 0.0:
            score = score + 6.0 * (counts / mx)

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SUM += item
    return score
# EVOLVE-BLOCK-END
