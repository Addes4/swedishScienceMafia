# EVOLVE-BLOCK-START
"""Harmonic-style bin choice: size-class buckets with targeted residuals.

For online bin packing with item sizes bounded by 1 (equivalent to capacity 100),
the "Harmonic" family of algorithms classifies items into size classes and packs
each class into bins reserved for that class. A simpler, robust variant is to
score a bin by how close the residual after placement is to a "good" residual:
we want to leave a remainder that is itself packable. Here we use the observation
that, for an item of size s, a bin with residual r (>= s) becomes r - s after
placement. We prefer the placement whose new residual is closest to one of a set
of attractive "target" residuals (which correspond to breakpoints of harmonic
progression 1/2, 1/3, ... of capacity). This keeps bins at stable fill levels.
"""
import numpy as np

_CAP = 100.0

# Harmonic breakpoints scaled to capacity: targets are remainders we like to
# leave open so later items (of the "matching" size class) can close them well.
_TARGETS = np.array(
    [
        _CAP / 2.0,      # 50   -> wait for ~50
        _CAP / 3.0,      # ~33
        (2.0 * _CAP) / 3.0,  # ~67
        _CAP / 4.0,      # 25
        (3.0 * _CAP) / 4.0,  # 75
        _CAP / 5.0,      # 20
        0.0,             # perfectly full
    ],
    dtype=np.float64,
)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual_after = bins - item  # new remaining capacity after placing here
    # Distance to the nearest attractive target residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)
    # Higher score = closer to an attractive target; also break ties by
    # preferring the tighter (smaller) residual so we consolidate well.
    return -best - 1e-6 * residual_after
# EVOLVE-BLOCK-END
