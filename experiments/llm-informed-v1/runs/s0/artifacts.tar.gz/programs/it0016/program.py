# EVOLVE-BLOCK-START
"""Adaptive harmonic / best-fit bin choice.

Items have mean ~40 and capacity 100, so most bins close with 2-3 items. Rather
than a fixed harmonic target set, we learn the item-size distribution online and
score each candidate bin by how well its post-placement residual can be closed
by a typical future item. We combine:
  - best-fit (smaller residual after placement is better),
  - a proximity reward toward residuals that are common item-size complements
    (i.e. residual near a value frequently seen / near 0),
  - a small penalty for consuming a fresh empty bin.
"""
import numpy as np

_CAP = 100.0


class _State:
    def __init__(self):
        self.sizes = []
        # rolling stats
        self.n = 0
        self.mean = 40.0
        self.q = np.array([0.0, 40.0, 80.0, 100.0], dtype=np.float64)

    def update(self, item):
        self.sizes.append(item)
        self.n += 1
        if self.n <= 64 or self.n % 32 == 0:
            arr = np.asarray(self.sizes, dtype=np.float64)
            self.mean = float(arr.mean())
            self.q = np.quantile(arr, [0.25, 0.5, 0.75, 0.95])


_state = _State()


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    _state.update(item)

    residual_after = bins - item  # remaining capacity if placed here

    # Typical future item size estimates.
    mu = _state.mean
    q50 = _state.q[1]
    q75 = _state.q[2]
    q95 = _state.q[3]

    # "Good" residual targets: what we'd like to leave open so a few typical
    # items finish the bin. Include 0 (closed), one typical item, and combos.
    targets = np.array(
        [0.0,
         q50,
         2.0 * q50,
         q75,
         mu,
         q95,
         _CAP - q50,
         _CAP - mu],
        dtype=np.float64,
    )
    targets = np.clip(targets, 0.0, _CAP)

    # Distance from residual_after to the nearest attractive target.
    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)

    # Primary: closeness to an attractive residual (harmonic-like structure).
    # Secondary: tighter fits consolidate bins (best fit).
    # Tertiary: tiny penalty for opening a fresh empty bin (residual_after==CAP-item).
    score = -best - 0.15 * residual_after
    # Penalize leaving a totally untouched bin (residual_after close to CAP-item
    # means we opened/consumed a fresh bin) slightly to encourage consolidation.
    fresh = np.clip(residual_after - (_CAP - item - 1.0), 0.0, 1.0)
    score -= 0.5 * fresh
    return score
# EVOLVE-BLOCK-END
