# EVOLVE-BLOCK-START
"""Adaptive combo bin choice driven by an empirical residual-value model.

Capacity is 100. Items arrive online from a fixed Weibull-shaped distribution.
A bin is only useful if its leftover capacity can eventually be filled by some
future item (or sequence of items). So the core idea is: build a set of
"attractive residual values" from the observed history -- the sizes themselves,
their complements, and frequent two-item sums -- and rank each candidate bin by
how close its post-placement residual is to one of those values, while applying
a mild best-fit pressure that grows as the instance fills up.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached attractive residual values and pair-fill table.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_PAIR_OK = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)


def _rebuild_targets():
    global _TARGETS, _PAIR_OK
    counts = _SIZE_COUNT[1:101]

    # Rank sizes by count; keep every size with a meaningful share of mass so
    # the target set is dense rather than just the top handful.
    total = counts.sum()
    if total <= 0.0:
        _TARGETS = np.array([0.0, _CAP], dtype=np.float64)
        _PAIR_OK = np.zeros(101, dtype=np.float64)
        return

    order = np.argsort(counts, kind="stable")
    top = order[::-1] + 1  # all sizes, most frequent first
    top = top[counts[top - 1] > 0]

    targets = set([0.0, _CAP])
    # Keep sizes capturing the bulk of the observed mass.
    accum = 0.0
    n_keep = 0
    for s in top:
        accum += counts[s - 1]
        n_keep += 1
        if accum >= 0.90 * total or n_keep >= 24:
            break
    for s in top[:n_keep]:
        s = float(s)
        targets.add(s)         # a leftover equal to this size closes cleanly
        targets.add(_CAP - s)  # complement also leaves a fillable residual
    _TARGETS = np.array(sorted(targets), dtype=np.float64)

    # Pair-fill table: residuals expressible as a sum of two plausible sizes.
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    pair = np.zeros(101, dtype=np.float64)
    if plausible.size:
        support = np.zeros(101, dtype=np.float64)
        support[plausible] = 1.0
        conv = np.convolve(support, support)
        n = min(101, conv.size)
        pair[:n] = (conv[:n] > 0).astype(np.float64)
    _PAIR_OK = pair


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Best-fit pressure grows as the instance fills up: early on, pack freely to
    # keep many bins open; later, prefer tight fits to avoid wasting capacity.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    fit_weight = 0.02 + 0.06 * frac

    # Primary: prefer a residual that matches a commonly arriving size.
    score = -best - fit_weight * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Guard 2: small bonus if the residual can still be closed by two items.
    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)
    score += 0.015 * _PAIR_OK[ri]

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
