# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a "multiple of typical item" bonus.

Items are Weibull-shaped with mean ~40. Pure best-fit consolidates bins well,
but it tends to leave awkward mid-size residuals. We add a bonus when the
post-placement residual is close to a small multiple of the running mean item
size (so a few typical items can fill the rest tightly), while keeping a strong
best-fit primary term.
"""
import numpy as np

_CAP = 100.0

_state = {"n": 0, "sum": 0.0, "count": None}


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    st = _state
    if st["count"] is None:
        # Number of items equals total bins on the very first call.
        st["count"] = len(bins)
    st["n"] += 1
    st["sum"] += item
    mean = st["sum"] / st["n"]

    residual_after = bins - item  # new remaining capacity after placing here

    # Best-fit primary term: prefer smaller post-placement residual.
    fit = -residual_after

    # Bonus: residual close to a small multiple of the typical item size.
    if mean > 1.0:
        mult = residual_after / mean
        nearest = np.round(mult)
        # Penalize fractional part only when near (within ~0.5 of a multiple).
        frac = np.abs(mult - nearest)
        bonus = np.maximum(0.0, 0.5 - frac)  # in [0, 0.5]
    else:
        bonus = np.zeros_like(residual_after)

    return fit + 3.0 * bonus
# EVOLVE-BLOCK-END
