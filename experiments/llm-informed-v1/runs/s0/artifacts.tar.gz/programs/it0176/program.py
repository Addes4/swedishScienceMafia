# EVOLVE-BLOCK-START
"""Soft-target combo bin choice.

Capacity is 100. Items arrive online. We keep an empirical histogram of item
sizes seen so far and score each candidate bin by:

  1. A soft "target density": how probable it is that the post-placement
     residual r is exactly an item size, or the complement 100-r of one, using
     the empirical distribution (smoothed). This replaces the hard nearest-
     target distance with a smooth, weighted score.

  2. A small size-aware best-fit pressure that prefers snug residuals,
     strengthened for larger arriving items.

  3. A waste guard: nonzero residuals below the smallest seen item cannot ever
     be filled.

  4. A pair-sum closability bonus: r is hittable by two future items.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

_TARGET_DENSITY = np.zeros(101, dtype=np.float64)  # per residual 0..100
_PAIR_SCORE = np.zeros(101, dtype=np.float64)
_EXACT_SCORE = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0


def _rebuild_targets():
    global _TARGET_DENSITY, _PAIR_SCORE, _EXACT_SCORE
    support = np.zeros(101, dtype=np.float64)
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    if plausible.size:
        w = _SIZE_COUNT[plausible]
        support[plausible] = w / w.sum()

    # Smooth the support a bit so rare-but-possible sizes still get credit.
    kernel = np.array([0.05, 0.15, 0.6, 0.15, 0.05], dtype=np.float64)
    smooth = np.convolve(support, kernel, mode="same")
    smooth[0] = 0.0
    smooth[101:] = 0.0
    m = smooth.max()
    if m > 0:
        smooth = smooth / m

    # Target density for residual r: probability mass at r plus at complement.
    td = smooth.copy()
    for r in range(101):
        comp = 100 - r
        if 1 <= comp <= 100:
            td[r] += 0.6 * smooth[comp]
    mx = td.max()
    if mx > 0:
        td = td / mx
    _TARGET_DENSITY = td

    # Pair-sum table over residuals.
    conv = np.convolve(support, support)
    n = min(101, conv.size)
    pair = np.zeros(101, dtype=np.float64)
    pair[:n] = conv[:n]
    m = pair.max()
    if m > 0:
        pair = pair / m
    _PAIR_SCORE = pair

    _EXACT_SCORE = smooth.copy()


def priority(item, bins):
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item
    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)

    # Soft target density term.
    score = 1.5 * _TARGET_DENSITY[ri]

    # Size-aware best-fit pressure.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    base_w = 0.02 + 0.06 * frac
    size_lean = (item - 50.0) / 50.0
    fit_weight = base_w * (1.0 + 0.6 * size_lean)
    score -= fit_weight * residual_after

    # Waste guard.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Closability bonuses.
    score += 0.02 * _PAIR_SCORE[ri]
    score += 0.5 * _EXACT_SCORE[ri]

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
