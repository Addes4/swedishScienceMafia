# EVOLVE-BLOCK-START
"""Expected-exact-fill bin choice.

Capacity is 100. Items arrive online and must be placed immediately. The key
observation: a bin whose post-placement residual exactly equals a frequently
arriving item size will very likely be closed later by a single item, so such
residuals are precious. We therefore score each bin by the empirical probability
(Lapace-smoothed) that the next single item exactly fills the residual, which is
just the observed frequency of that residual value as an item size.

We combine this with a mild best-fit pressure (scaled by fill level) and a small
penalty for nonzero residuals smaller than the smallest item seen so far, since
those can never be filled by any future item.
"""
import numpy as np

_CAP = 100.0

# Empirical item-size distribution, updated incrementally.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_MIN_SIZE = 101.0

# Cached fill-probability table, refreshed as the histogram grows.
_FILL_PROB = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)


def _rebuild_table():
    global _FILL_PROB
    total = _SIZE_COUNT.sum()
    # Laplace-smoothed probability that an item equals each possible size.
    probs = (_SIZE_COUNT + 1.0) / (total + 101.0)
    probs[0] = 0.0  # item of size 0 never occurs; residual 0 means full bin
    _FILL_PROB = probs


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_table()

    residual_after = bins - item
    r = residual_after.astype(np.int64)
    r = np.clip(r, 0, 100)

    # Primary: probability this residual is exactly filled by a single future item.
    fill = _FILL_PROB[r]

    # Best-fit pressure grows as the instance fills up.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    fit_weight = 0.02 + 0.06 * frac

    score = fill - fit_weight * residual_after

    # Guard: penalize tiny nonzero residuals no seen item could ever fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
