# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by best fit.

Capacity is 100. Items arrive online. Rather than ranking bins by distance to a
fixed set of harmonic fractions, we learn which residual values are actually
useful: the most frequent item sizes seen so far are the residuals a future item
is most likely to exactly fill. We score each bin by how close its
post-placement residual is to a small set of such empirically attractive values,
then break near-ties toward tighter fits (smaller residual), with the strength of
that best-fit pressure scaled by how full the instance already is.

Extra guard 1: a residual that is nonzero but smaller than the smallest item size
seen so far can never be filled by any future item, so it is wasted space. Such
bins get a mild penalty, applied at tie-break scale so the main target logic
still dominates.

Extra guard 2: a residual that is reachable as a two-item sum is more valuable
than one that is not, because even if no single future item exactly closes the
bin, two items can. We grade this by a probability-weighted two-item sum table
(the convolution of the empirical size distribution with itself), so residuals
reachable through many likely decompositions get a larger bonus.

Extra guard 3: we track which residuals actually get filled by a single arriving
item (a fill-success memory). Residuals that have historically been closed by one
item are the most valuable ones to leave behind, so bins producing them get an
additional bonus. This memory is learned online and purely from the past.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached target array, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
# Cached pair-sum table (probability-weighted two-item sums, indexed 0..100).
_PAIR_SCORE = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)

# Fill-success memory: how often a residual value r (0..100) was later closed
# exactly by a single arriving item.  We also record the residuals we created on
# the previous placement so we can credit them when they are closed.
_OPEN_RESIDUAL = np.zeros(101, dtype=np.float64)   # live residuals by value
_FILL_HITS = np.zeros(101, dtype=np.float64)       # times residual r closed
_FILL_VIEWS = np.zeros(101, dtype=np.float64)      # times residual r exposed
_LAST_RESIDUAL = -1                                # residual left by last item


def _rebuild_targets():
    global _TARGETS, _PAIR_SCORE
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:12] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)          # a leftover equal to this size closes cleanly
        targets.add(_CAP - s)   # complement also leaves a fillable residual
    _TARGETS = np.array(sorted(targets), dtype=np.float64)

    # Probability-weighted two-item sum table over residuals 0..100.
    support = np.zeros(101, dtype=np.float64)
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    if plausible.size:
        w = _SIZE_COUNT[plausible]
        support[plausible] = w / w.sum()
    conv = np.convolve(support, support)
    n = min(101, conv.size)
    pair = np.zeros(101, dtype=np.float64)
    pair[:n] = conv[:n]
    # Normalize to a stable [0,1]-ish scale for use as a tie-break bonus.
    m = pair.max()
    if m > 0:
        pair = pair / m
    _PAIR_SCORE = pair


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS, _LAST_RESIDUAL

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    # Credit the residual created by the previous placement if this item closes it.
    if _LAST_RESIDUAL >= 0:
        _FILL_VIEWS[_LAST_RESIDUAL] += 1.0
        if _LAST_RESIDUAL == item:
            _FILL_HITS[_LAST_RESIDUAL] += 1.0
        _OPEN_RESIDUAL[_LAST_RESIDUAL] -= 1.0

    residual_after = bins - item

    # Distance to the nearest attractive residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Best-fit pressure grows as the instance fills up: early on, pack freely to
    # keep many bins open; later, prefer tight fits to avoid wasting capacity.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    fit_weight = 0.02 + 0.06 * frac

    # Primary: prefer a residual that matches a commonly arriving size.
    score = -best - fit_weight * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Guard 2: graded bonus if the residual can still be closed by two items.
    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)
    score += 0.02 * _PAIR_SCORE[ri]

    # Guard 3: bonus for residuals that history shows get closed by one item.
    rate = np.zeros(101, dtype=np.float64)
    seen = _FILL_VIEWS > 0.0
    rate[seen] = _FILL_HITS[seen] / _FILL_VIEWS[seen]
    score += 0.02 * rate[ri]

    # Record the residual we are about to create for future credit.
    chosen = int(np.argmax(score))
    _LAST_RESIDUAL = int(residual_after[chosen])
    if _LAST_RESIDUAL >= 0:
        _OPEN_RESIDUAL[_LAST_RESIDUAL] += 1.0

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
