# EVOLVE-BLOCK-START
"""Smooth empirical target-density bin choice with adaptive best-fit pressure.

Capacity is 100. Items arrive online. Instead of matching each post-placement
residual to a hard, arbitrarily truncated set of "good" residuals, we score it by
a smooth kernel density over the empirically attractive residual values: the
frequent item sizes seen so far and their complements (since a residual equal to
either lets a common item close the bin cleanly). Bins whose residual lies close
to many such values get a high score, so the target logic degrades gracefully
rather than flipping when the top-12 set changes.

A best-fit tie-break, scaled by how full the instance already is, prefers tighter
fits as the run progresses. Bins left with a tiny nonzero residual that no item
seen so far could ever fill are mildly penalized, since that space is wasted.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the smooth residual value function.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached kernel-density weights over residuals 0..100.
_WEIGHT = np.zeros(101, dtype=np.float64)
_REFRESH = 8
_N_ITEMS = 0.0  # number of items in the instance (known on first call)
_KERNEL_SIGMA = 2.0


def _rebuild_weights():
    """Build a smooth value function over residual capacity 0..100.

    Frequent item sizes and their complements are attractive closing residuals.
    We accumulate Gaussian kernels centered on each such value, weighted by the
    observed frequency, so nearby residuals also receive partial credit.
    """
    global _WEIGHT
    counts = _SIZE_COUNT[1:101]
    total = counts.sum()
    w = np.zeros(101, dtype=np.float64)
    if total <= 0.0:
        _WEIGHT = w
        return

    r = np.arange(101, dtype=np.float64)
    two_sig2 = 2.0 * _KERNEL_SIGMA * _KERNEL_SIGMA
    for s in range(1, 101):
        c = counts[s - 1]
        if c <= 0.0:
            continue
        w += (c / total) * np.exp(-((r - float(s)) ** 2) / two_sig2)
        comp = _CAP - float(s)
        w += (c / total) * np.exp(-((r - comp) ** 2) / two_sig2)
    # Emphasize the fully-packed residual and the empty-bin residual slightly.
    w[0] += 0.05
    w[100] += 0.05
    maxw = w.max()
    if maxw > 0.0:
        w /= maxw
    _WEIGHT = w


def _weight_of(residual):
    """Lookup smooth residual value with linear interpolation."""
    r = np.clip(residual, 0.0, _CAP)
    lo = np.floor(r).astype(np.int64)
    hi = np.minimum(lo + 1, 100)
    frac = r - lo
    return _WEIGHT[lo] * (1.0 - frac) + _WEIGHT[hi] * frac


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_weights()

    residual_after = bins - item

    # Smooth value of each residual: how likely a future item closes it.
    value = _weight_of(residual_after)

    # Best-fit pressure grows as the instance fills up.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    fit_weight = 0.02 + 0.06 * frac

    score = value - fit_weight * residual_after

    # Penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
