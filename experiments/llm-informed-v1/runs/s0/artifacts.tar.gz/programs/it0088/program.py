# EVOLVE-BLOCK-START
"""Target-residual bin choice with learned targets.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual. Targets combine static
harmonic fractions of capacity with a running, empirically-learned set of
residual values: whenever a bin is later filled exactly (residual becomes 0
after an item), the residual it had just before that closing item is recorded.
These "productive residuals" are blended into the target set with a small
weight, so the rule tends to recreate fragments that experience shows get
cleaned up by a single future item.
"""
import numpy as np

_CAP = 100.0

_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

# Learned residuals that were recently closed (integer residual values).
_PRODUCTIVE = np.zeros(101, dtype=np.float64)

_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    # Blend in learned productive residuals with a modest weight by adding
    # copies proportional to how often each residual was successfully closed.
    prod_idx = np.nonzero(_PRODUCTIVE)[0]
    if prod_idx.size:
        reps = np.minimum((_PRODUCTIVE[prod_idx] // 2).astype(int) + 1, 3)
        learned = np.repeat(prod_idx.astype(np.float64), reps)
        targets = np.unique(np.concatenate([targets, learned]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    fullness = bins / _CAP
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    # Record productive residuals: if this item exactly closes a bin, the
    # residual that bin had before this placement was item (a productive one).
    just_closed = residual_after == 0.0
    if np.any(just_closed):
        r = int(item)
        if 0 <= r <= 100:
            _PRODUCTIVE[r] += 1.0

    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END

