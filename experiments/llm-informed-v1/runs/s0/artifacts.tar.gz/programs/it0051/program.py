# EVOLVE-BLOCK-START
"""Best-fit with a bounded exact-closure bonus.

Capacity is 100. Items arrive online. We primarily consolidate by preferring the
tightest fit (smallest residual after placement), which is a robust online rule
for Weibull-shaped sizes with mean ~40. On top of that we add a bounded bonus for
leaving a residual equal to a common item size, so a later item can close the bin
exactly. The bonus is a fixed, size-based weight (not a noisy moving histogram),
keeping the signal stable across the whole instance.
"""
import numpy as np

_CAP = 100.0

# A fixed, smooth proxy for the item-size frequency (Weibull-shaped, mean ~40).
# Peak near the mean, tapering toward small and large sizes. Used only to decide
# which residual sizes are worth leaving, with bounded weight.
_SIZES = np.arange(101, dtype=np.float64)
_MU = 40.0
_SIGMA = 22.0
_WEIGHT = np.exp(-0.5 * ((_SIZES - _MU) / _SIGMA) ** 2)
# Small residuals are usually easy to close with a tiny item; give them a floor.
_WEIGHT[:6] += 0.5
_WEIGHT = _WEIGHT / _WEIGHT.max()


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual_after = bins - item

    # Primary signal: prefer the tightest fit (smallest residual after placement).
    score = -residual_after

    # Secondary: bounded reward for leaving a residual that is a common size,
    # so it can later be closed exactly.
    resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
    score = score + 3.0 * _WEIGHT[resid_int]

    return score
# EVOLVE-BLOCK-END
