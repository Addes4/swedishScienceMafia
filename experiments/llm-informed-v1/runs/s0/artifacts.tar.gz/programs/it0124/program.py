# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by best fit.

Capacity is 100. Items arrive online. We learn which residual values are actually
useful: the most frequent item sizes seen so far are the residuals a future item
is most likely to exactly fill. We score each bin by how close its
post-placement residual is to a small set of such empirically attractive values,
then break near-ties toward tighter fits (smaller residual).

Adaptive best-fit pressure: early in the instance we pack freely so we do not
seal bins prematurely; as the instance progresses we increase the pressure
toward tighter fits, since late arrivals benefit from consolidated bins.

Guard: a residual that is nonzero but smaller than the smallest item size
seen so far can never be filled by any future item, so it is wasted space.
Such bins get a mild penalty applied at tie-break scale.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0
_N_ITEMS = 0.0

# Cached target array and its frequency weights, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_WEIGHTS = np.array([1.0, 1.0], dtype=np.float64)
_REFRESH = 32


def _rebuild_targets():
    global _TARGETS, _WEIGHTS
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:10] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]
    targets = {0.0: 0.5, _CAP: 0.5}
    total_counts = counts.sum()
    for s in top:
        s = float(s)
        s = int(s)
        w = counts[s - 1] / max(total_counts, 1.0)
        targets[s] = max(targets.get(s, 0.0), w)          # leftover fills exactly
        targets[_CAP - s] = max(targets.get(_CAP - s, 0.0), w)  # complement
    keys = sorted(targets.keys())
    _TARGETS = np.array(keys, dtype=np.float64)
    _WEIGHTS = np.array([targets[k] for k in keys], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0 and len(bins) > 0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual, weighted by attractiveness.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    # Weighted distance: divide by weight so higher-weight targets attract more.
    wd = d / (_WEIGHTS[None, :] + 0.05)
    best = wd.min(axis=1)

    # Adaptive best-fit pressure: grows as the instance progresses.
    progress = _TOTAL / max(_N_ITEMS, 1.0)
    fit_pressure = 0.03 + 0.06 * progress

    score = -best - fit_pressure * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END

