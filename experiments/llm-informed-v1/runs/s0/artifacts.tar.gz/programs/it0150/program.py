# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by best fit.

Capacity is 100. Items arrive online. We score each bin by how close its
post-placement residual is to a set of empirically attractive values (frequent
sizes and their complements), then break near-ties toward tighter fits, with the
strength of that best-fit pressure scaled by how full the instance already is.

Guard 1: a residual that is nonzero but smaller than the smallest item size seen
so far can never be filled by any future item, so it is wasted space. Mild penalty.

Guard 2: a residual that is a plausible two-item sum (pair-fill) is slightly more
valuable; small bonus.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached target arrays.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_TWEIGHT = np.array([1.0, 1.0], dtype=np.float64)
# Cached pair-sum set (bools indexed by residual 0..100).
_PAIR_OK = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)


def _rebuild_targets():
    global _TARGETS, _TWEIGHT, _PAIR_OK
    counts = _SIZE_COUNT[1:101].copy()
    total = counts.sum()
    if total <= 0.0:
        _TARGETS = np.array([0.0, _CAP], dtype=np.float64)
        _TWEIGHT = np.array([1.0, 1.0], dtype=np.float64)
        _PAIR_OK = np.zeros(101, dtype=np.float64)
        return

    # Smoothed distribution: blend observed counts with a small uniform floor so
    # unseen-but-plausible sizes still contribute a little.
    p = counts / total
    p = 0.85 * p + 0.15 / 100.0

    # Target residual weight for a value r: probability some future item leaves r
    # (i.e. r is a frequent size) plus probability r equals CAP - s for frequent s
    # (so that leaving r lets a frequent item close the bin next).
    tw = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        ps = p[s - 1]
        if ps <= 0.0:
            continue
        tw[s] += ps            # leftover == frequent size
        tw[int(round(_CAP - s))] += ps  # leftover == complement of frequent size

    # Always keep the extremes attractive.
    tw[0] += 1.0
    tw[100] += 1.0

    # Restrict to the best-scoring target values to keep the distance computation
    # cheap and focused: keep the top 24 by weight.
    idx = np.argsort(tw, kind="stable")[::-1][:24]
    idx = idx[tw[idx] > 0.0]
    _TARGETS = idx.astype(np.float64)
    w = tw[idx]
    _TWEIGHT = w / (w.max() + 1e-12)

    # Pair-fill table via convolution of the size support with itself.
    support = (counts > 0).astype(np.float64)
    support[0] = 1.0  # allow "empty + item"
    conv = np.convolve(support, support)
    n = min(101, conv.size)
    pair = np.zeros(101, dtype=np.float64)
    pair[:n] = (conv[:n] > 0).astype(np.float64)
    _PAIR_OK = pair


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Weighted distance to attractive residuals: a residual close to a high-weight
    # target is good; closeness to multiple targets accumulates reward.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    # Smooth falloff kernel: reward decays with distance (scale ~4).
    k = _TWEIGHT[None, :] * np.exp(-(d * d) / (2.0 * 4.0 * 4.0))
    match = k.max(axis=1) + 0.25 * k.sum(axis=1)

    # Best-fit pressure grows as the instance fills up.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    fit_weight = 0.02 + 0.06 * frac

    score = match - fit_weight * residual_after

    # Guard: penalize tiny nonzero residuals no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Guard 2: small bonus if the residual can still be closed by two items.
    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)
    score += 0.015 * _PAIR_OK[ri]

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
