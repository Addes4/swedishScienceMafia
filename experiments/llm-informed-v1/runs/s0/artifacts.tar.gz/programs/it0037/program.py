# EVOLVE-BLOCK-START
"""Harmonic-style bin choice with a smoothed online size-class model.

Items are integer sizes in [1, 100]. Online bin packing improves when a bin's
post-placement residual matches a size that is likely to arrive later, so the
bin can be closed exactly. We approximate the item-size distribution with a
light running histogram (smoothed, so early estimates are not noisy), and we
blend three signals:

  1. Proximity of the residual-after-placement to attractive "harmonic"
     target residuals (so bins keep a useful remainder).
  2. A best-fit term so tighter fits consolidate partially filled bins.
  3. A distribution-aware bonus when the residual exactly matches a commonly
     observed item size (a later such item can close the bin).
"""
import numpy as np

_CAP = 100.0

_TARGETS = np.array(
    [
        _CAP / 2.0,          # 50
        _CAP / 3.0,          # ~33
        (2.0 * _CAP) / 3.0,  # ~67
        _CAP / 4.0,          # 25
        (3.0 * _CAP) / 4.0,  # 75
        _CAP / 5.0,          # 20
        0.0,                 # perfectly full
    ],
    dtype=np.float64,
)

# Smoothed online histogram of item sizes (1..100).
_SIZE_COUNT = np.ones(101, dtype=np.float64)  # +1 smoothing
_TOTAL = float(101.0)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL
    residual_after = bins - item  # remaining capacity after placing here

    # 1) Distance to nearest attractive target residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # 2) Consolidated score: target proximity + best-fit consolidation.
    score = -best - 0.20 * residual_after

    # 3) Distribution-aware bonus: residual matching a common item size.
    freq = _SIZE_COUNT / _TOTAL
    resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
    score = score + 12.0 * freq[resid_int]

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END
