# EVOLVE-BLOCK-START
"""Best-fit-plus-learned-closure bin choice.

Baseline: classic Best Fit — among bins the item fits in, choose the one that
leaves the smallest non-negative residual (tighest fit). This is the strongest
simple online rule for this kind of distribution and directly limits the number
of open bins.

Refinement: add a small data-driven bonus for post-placement residuals that
equal a frequently-seen item size (a single future item would then close the
bin exactly), which nudges the packer toward leaving "cleanly fillable" gaps
without disturbing best-fit on the vast majority of decisions.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "clean residual" bonus.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_N_ITEMS = 0.0  # number of items in the instance (known on first call)

# Cached exact-fill indicator (residual equals a frequent item size).
_EXACT_FILL = np.zeros(101, dtype=np.float64)
_REFRESH = 32


def _rebuild_targets():
    global _EXACT_FILL
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:10] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]
    ef = np.zeros(101, dtype=np.float64)
    for s in top:
        ef[int(s)] = 1.0
    _EXACT_FILL = ef


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Best-fit core: smaller non-negative residual is better.
    score = -residual_after

    # Learned clean-close bonus: prefer residuals matching a frequent item size.
    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)
    score += 0.5 * _EXACT_FILL[ri]

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END
