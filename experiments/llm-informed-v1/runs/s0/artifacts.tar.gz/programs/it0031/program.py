# EVOLVE-BLOCK-START
"""Best-fit bin choice with a harmonic "closeable residual" bonus.

Items arrive online into capacity-100 bins. Best-fit (smallest residual after
placement) is a strong online rule; we augment it with a bonus when the
post-placement residual is close to a common item size (so a later item of
that size can close the bin), giving a harmonic-like closing effect while
still consolidating partially-filled bins.
"""
import numpy as np

_CAP = 100.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual_after = bins - item  # new remaining capacity after placing here
    # Primary: tighter fits consolidate bins (best-fit).
    best_fit = -residual_after.astype(np.float64)
    # Secondary: reward residuals near a "closeable" size so a later typical
    # item can finish the bin. We like residuals small but also matching common
    # sizes; a mild peak near ~40 (typical large item) and small residuals.
    r = residual_after.astype(np.float64)
    closeable = np.exp(-((r - 40.0) ** 2) / (2.0 * 12.0 ** 2))
    return best_fit + 0.6 * closeable
# EVOLVE-BLOCK-END


