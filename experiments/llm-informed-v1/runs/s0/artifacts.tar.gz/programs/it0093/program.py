# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets, fullness-weighted exact-fit
bonus, and an empirical "closable residual" bonus.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic fractions of
capacity), rewarding tighter fits to consolidate partially-filled bins. In
addition, we track the empirical histogram of item sizes seen so far and boost
bins whose post-placement residual is a size that has frequently appeared
(so a later single item is likely to seal the bin), while mildly penalizing
residuals in sparse regions of the size histogram.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0

# Precomputed size index grid for vectorized empirical density lookup.
_SIZES = np.arange(0, 101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    # Running mean item size (bounded) for dynamic targets.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Fullness-weighted exact-fit bonus.
    fullness = (bins / _CAP)
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    # Empirical "closable residual" bonus: how likely is a future single item
    # to close this bin?  Use the histogram of sizes seen so far, smoothed.
    if _TOTAL > 20.0:
        # Smoothed empirical density over integer sizes 1..100.
        hist = _SIZE_COUNT[1:101]
        # 3-wide smoothing to avoid over-reacting to single observations.
        ker = np.array([1.0, 2.0, 3.0, 2.0, 1.0], dtype=np.float64)
        sm = np.convolve(hist, ker, mode="same")
        sm = sm / (sm.sum() + 1e-9)
        # Rank-transform the density so only relative "commonness" matters.
        order = np.argsort(sm)
        ranks = np.empty_like(order, dtype=np.float64)
        ranks[order] = np.linspace(0.0, 1.0, sm.size)
        dens = np.concatenate([[0.0], ranks])  # index by size 0..100

        # For each bin, look at residual-after; the integer size nearest below
        # the residual is the "opening" we would leave for a closing item.
        res_int = np.clip(np.floor(residual_after + 0.5), 0.0, 100.0)
        closable = dens[res_int.astype(np.int64)]
        score = score + 1.2 * closable

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END
