# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by best fit.

Capacity is 100. Items arrive online. We score each bin by how close its
post-placement residual is to a small set of empirically attractive values,
then break near-ties toward tighter fits, with the strength of that best-fit
pressure scaled by how full the instance already is.

Extra guard 1: a residual that is nonzero but smaller than the smallest item size
seen so far can never be filled by any future item, so it is wasted space.

Extra guard 2: a residual reachable as a one- or two-item sum from the empirical
size distribution is more valuable than one that is not, since even if no single
future item closes the bin, two items can. Residuals that cannot be formed by any
one or two plausible items get an explicit unusable-space penalty.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached target array, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
# Cached pair-sum table (probability-weighted two-item sums, indexed 0..100).
_PAIR_SCORE = np.zeros(101, dtype=np.float64)
# Reachability mask: residual formable by one or two plausible items.
_REACH = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)


def _rebuild_targets():
    global _TARGETS, _PAIR_SCORE, _REACH
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:12] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)          # a leftover equal to this size closes cleanly
        targets.add(_CAP - s)   # complement also leaves a fillable residual
    _TARGETS = np.array(sorted(targets), dtype=np.float64)

    # Probability-weighted two-item sum table over residuals 0..100.
    support = np.zeros(101, dtype=np.float64)
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    if plausible.size:
        w = _SIZE_COUNT[plausible]
        support[plausible] = w / w.sum()
    conv = np.convolve(support, support)
    n = min(101, conv.size)
    pair = np.zeros(101, dtype=np.float64)
    pair[:n] = conv[:n]
    m = pair.max()
    if m > 0:
        pair = pair / m
    _PAIR_SCORE = pair

    # Reachability: residual can be a single item or a two-item sum.
    reach = np.zeros(101, dtype=np.float64)
    reach[plausible] = 1.0
    if plausible.size:
        sums = np.zeros(101, dtype=bool)
        for a in plausible:
            # vectorized: mark a + b for all plausible b <= 100
            b = plausible[plausible <= 100 - a]
            sums[a + b] = True
        reach[sums] = 1.0
    reach[0] = 1.0
    _REACH = reach


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Best-fit pressure grows as the instance fills up: early on, pack freely to
    # keep many bins open; later, prefer tight fits to avoid wasting capacity.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    fit_weight = 0.02 + 0.06 * frac

    # Primary: prefer a residual that matches a commonly arriving size.
    score = -best - fit_weight * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)

    # Guard 2: graded bonus if the residual can still be closed by two items.
    score += 0.02 * _PAIR_SCORE[ri]

    # Guard 3: explicit penalty for residuals that are unreachable as a one- or
    # two-item sum; such space is effectively locked away.
    unreachable = (residual_after > 0.0) & (_REACH[ri] < 0.5)
    score -= 0.015 * unreachable

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
