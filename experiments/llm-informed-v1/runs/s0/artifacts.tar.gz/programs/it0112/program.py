# EVOLVE-BLOCK-START
"""Fillability-driven bin choice.

The previous version ranked bins by proximity of the post-placement residual to
a set of harmonic/dynamic "target" residuals.  That geometry ignores whether a
residual can actually be absorbed by future items.  This version instead scores
each candidate bin by an estimate of how likely its post-placement residual is
to be "consumable" by the remaining items:

  * residual == 0  -> a perfectly closed bin, strongly rewarded,
  * residual equal to a size (or a sum of the two most common sizes) that we
    have actually observed -> likely fillable, rewarded,
  * otherwise the residual is penalised, with a mild preference for small
    residuals (best-fit) as a tie-break.

The empirical size distribution is tracked online across the instance.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0

# cached derived quantities, refreshed periodically
_SIZES = np.arange(0, 101, dtype=np.float64)
_GOOD = np.zeros(101, dtype=np.float64)   # 1 if residual likely fillable
_REFRESH = 0


def _refresh():
    """Rebuild the 'good residual' table from the seen size histogram."""
    global _GOOD
    good = np.zeros(101, dtype=np.float64)
    if _TOTAL <= 0.0:
        _GOOD = good
        return
    hist = _SIZE_COUNT.copy()
    freq = hist / _TOTAL
    # sizes that actually occur, weighted by their relative frequency
    good += freq
    # sums of the two most common sizes
    top = np.argsort(freq)[-4:]
    top = top[top > 0]
    for a in top:
        for b in top:
            s = a + b
            if 1 <= s <= 100:
                good[s] += 0.5 * freq[a] * freq[b]
    # small sums of two equal moderately common sizes already covered above
    _GOOD = good


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _REFRESH
    residual_after = bins - item

    if _REFRESH >= 25:
        _refresh()
        _REFRESH = 0
    elif _TOTAL > 0.0 and _GOOD.sum() == 0.0:
        _refresh()

    r = residual_after.astype(np.int64)
    r = np.clip(r, 0, 100)

    fill = _GOOD[r]                       # likely-fillable mass of the residual
    closed = (residual_after == 0).astype(np.float64)

    # base score: reward fillable residuals, strongly reward exact closure,
    # mild best-fit tie-break so small residuals are preferred among equals.
    score = 6.0 * fill + 3.0 * closed - 0.02 * residual_after

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    _REFRESH += 1
    return score
# EVOLVE-BLOCK-END

