# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by best fit.

Capacity is 100. Items arrive online. We learn which residual values are actually
useful: the most frequent item sizes seen so far are the residuals a future item
is most likely to exactly fill. We score each bin by how close its post-placement
residual is to a small set of such empirically attractive values, then break
near-ties toward tighter fits (smaller residual). We additionally reward leaving
a residual that exactly equals a frequently observed item size, scaled by that
size's frequency, so bins pair up common items.

Extra guard: a residual that is nonzero but smaller than the smallest item size
seen so far can never be filled by any future item, so it is wasted space. Such
bins get a mild penalty, applied at tie-break scale so the main target logic
still dominates.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached target array, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_FREQ = np.zeros(101, dtype=np.float64)   # normalized frequency per size
_REFRESH = 32


def _rebuild_targets():
    global _TARGETS, _FREQ
    counts = _SIZE_COUNT[1:101]
    total = counts.sum()
    if total > 0:
        _FREQ = _SIZE_COUNT / total
    # Most frequent sizes (ties broken toward larger sizes via ordering).
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:10] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)          # a leftover equal to this size closes cleanly
        targets.add(_CAP - s)   # complement also leaves a fillable residual
    _TARGETS = np.array(sorted(targets), dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Primary: prefer a residual that matches a commonly arriving size.
    # Tie-break: modest best-fit pressure (prefer smaller residual).
    score = -best - 0.05 * residual_after

    # Pairing bonus: strongly reward leaving a residual exactly equal to a
    # frequently observed item size (or sealing the bin to 0).
    ri = np.clip(residual_after.astype(np.int64), 0, 100)
    exact = (_SIZE_COUNT[ri] > 0) & (np.abs(residual_after - ri) < 1e-9)
    score += 0.30 * _FREQ[ri] * exact
    zero = np.abs(residual_after) < 1e-9
    score += 0.30 * zero * (_FREQ[1:101].max() if _TOTAL > 0 else 0.0)

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
