# EVOLVE-BLOCK-START
"""Harmonic-style bin choice blended with best-fit consolidation.

For online bin packing with item sizes bounded by 1 (capacity 100), the
"Harmonic" family classifies items into size classes and packs each class into
reserved bins. A robust, smooth variant: score a bin by how close the residual
after placement is to a "good" residual (a packable remainder), while also
rewarding tighter fits so partially-full bins get consolidated. We combine a
target-proximity term with a best-fit term, and discourage opening fresh bins.
"""
import numpy as np

_CAP = 100.0

# Harmonic breakpoints scaled to capacity: remainders we like to leave open so
# later items of the "matching" size class can close them well. With mean item
# size ~40, residuals near 20, 25, 33, 40 and 50 correspond to common
# complementary sizes.
_TARGETS = np.array(
    [
        _CAP / 2.0,          # 50
        _CAP / 3.0,          # ~33
        (2.0 * _CAP) / 3.0,  # ~67
        _CAP / 4.0,          # 25
        (3.0 * _CAP) / 4.0,  # 75
        _CAP / 5.0,          # 20
        0.0,                 # perfectly full
    ],
    dtype=np.float64,
)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual_after = bins - item  # new remaining capacity after placing here

    # Distance to the nearest attractive target residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Freshly untouched bin (residual 100 before placement) is penalized so the
    # packing consolidates open bins before opening a new one.
    fresh = (bins == _CAP).astype(np.float64)

    # Primary: closeness to an attractive target residual (harmonic structure).
    # Secondary: tighter fits (smaller residual_after) consolidate bins.
    return -best - 0.15 * residual_after - 0.5 * fresh
# EVOLVE-BLOCK-END

