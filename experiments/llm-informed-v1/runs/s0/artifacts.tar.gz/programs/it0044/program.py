# EVOLVE-BLOCK-START
"""Best-fit primary signal with a stable "closable residual" bonus.

Capacity is 100, items arrive online. We rank bins primarily by tightest fit
(smallest residual after placement) to consolidate partially-filled bins, and
add a stable bonus proportional to the empirical probability that a future item
will exactly equal the residual (closing the bin). Probabilities are Laplace-
smoothed so the signal neither vanishes nor lets a single rare size dominate.
"""
import numpy as np

_CAP = 100.0
_SIZE_COUNT = np.zeros(101, dtype=np.float64)   # observed counts per size
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL
    residual_after = bins - item

    # Primary: tightest fit (smallest residual). Light penalty on big residuals.
    score = -residual_after - 0.05 * residual_after

    if _TOTAL > 0.0:
        resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
        # Laplace-smoothed probability that a future item equals this residual.
        prob = (_SIZE_COUNT[resid_int] + 1.0) / (_TOTAL + 101.0)
        score = score + 40.0 * prob

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END
