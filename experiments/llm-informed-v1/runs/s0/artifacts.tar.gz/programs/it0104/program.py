# EVOLVE-BLOCK-START
"""Adaptive residual-value bin choice.

Capacity is 100. Items arrive online. Rather than using a fixed set of
harmonic target residuals, we learn online which post-placement residuals
tend to be "productive" (i.e. later exactly completed by future items).
We maintain an exponential moving estimate, indexed by residual value, of
the recent exact-completion success for that residual, and blend it with
the classical geometric target-distance term. This lets the rule discover
the empirically useful residual values for this instance's distribution.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity as a geometric prior.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0

# Online estimate of "productive residual": residual value r that was created
# and then later exactly consumed by an item.  Indexed 0..100.
_PROD = np.zeros(101, dtype=np.float64)
_PROD_HITS = np.zeros(101, dtype=np.float64)
_PROD_TRIES = np.zeros(101, dtype=np.float64)

# Track open-bin residuals we ourselves created, to credit completions.
_OPEN = {}  # residual value -> count of open bins with that residual


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM

    # Credit exact completions: an arriving item exactly matching an open
    # residual marks that residual value as productive.
    if item in _OPEN and _OPEN[item] > 0:
        _PROD_HITS[item] += 1.0

    residual_after = bins - item

    # Dynamic targets from running mean item size.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Fullness-weighted exact-fit bonus.
    fullness = bins / _CAP
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    # Empirical productivity of the resulting residual: reward leaving a
    # residual that has historically been exactly completed by later items.
    ra = residual_after.astype(np.int64)
    valid = (ra >= 0) & (ra <= 100)
    prod = np.where(valid, _PROD[np.clip(ra, 0, 100)], 0.0)
    score = score + 3.0 * prod

    # Update performance bookkeeping.
    item_int = int(item)
    _SIZE_COUNT[item_int] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item_int

    # Update open-residual counts for bins we are about to keep open.
    # Remove the chosen bin's prior residual bookkeeping lazily: we only
    # track coarse open residual counts via current bins' residuals.
    # Rebuild open counts from the bins array after this call is not possible
    # (we only see fitting bins), so we maintain incrementally: when a bin is
    # chosen its old residual is consumed.
    # We approximate by tracking residuals of bins we have seen fitting.
    # Decrement the chosen residual region heuristically.
    len_bins = bins.shape[0]
    # Best choice by current score (matches harness tie rule).
    best_idx = int(np.argmax(score))
    # The prior residual of the chosen bin was bins[best_idx]; it is consumed.
    # We do not have global bin identity, so we only credit completions via
    # the item-match rule above using residuals we recorded when created.
    # Record residuals created for the non-chosen visible bins as open.
    # (Coarse but useful: record the resulting residuals.)
    for j in range(len_bins):
        r = int(bins[j] - item_int)
        if r >= 0:
            _PROD_TRIES[r] += 1.0

    # Update productivity estimate via EMA of hit rate.
    mask = _PROD_TRIES > 0
    rate = np.zeros(101, dtype=np.float64)
    rate[mask] = _PROD_HITS[mask] / _PROD_TRIES[mask]
    _PROD[:] = 0.9 * _PROD + 0.1 * rate

    return score
# EVOLVE-BLOCK-END

