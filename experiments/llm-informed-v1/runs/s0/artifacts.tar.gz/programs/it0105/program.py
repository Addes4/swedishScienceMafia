# EVOLVE-BLOCK-START
"""Best-fit core with exact-closure and common-residual bonuses.

Capacity is 100. Items arrive online. We choose the bin minimizing the
post-placement residual (best fit), which is the strongest simple online rule
for this capacity, but add two corrections learned online:
  (1) a strong bonus for exact closure (residual 0),
  (2) a bonus when the post-placement residual is itself a commonly observed
      item size, so a single later item can finish the bin.
A tiny target geometry over harmonic fractions keeps partially-filled bins
from drifting into awkward residuals.
"""
import numpy as np

_CAP = 100.0

_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    # Core: best fit (small post-placement residual is good).
    score = -residual_after.astype(np.float64)

    # Strong exact-closure bonus.
    score += 6.0 * (residual_after == 0)

    # Harmonic target geometry: reward residuals near harmonic fractions of
    # capacity (encourages productive partial fills).
    targets = _FRACS * _CAP
    d = np.abs(residual_after[:, None] - targets[None, :])
    score -= 1.5 * d.min(axis=1)

    # Bias toward residuals that match commonly seen item sizes so a single
    # later item can complete the bin.
    if _TOTAL > 20.0:
        counts = _SIZE_COUNT.copy()
        counts[0] = 0.0
        tot = counts.sum()
        if tot > 0.0:
            probs = counts / tot
            r = residual_after
            valid = (r >= 1) & (r <= 100)
            ri = np.clip(r, 1, 100).astype(np.int64)
            p = np.where(valid, probs[ri], 0.0)
            score += 3.0 * p

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END
