# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets, fullness-weighted fit bonus,
and a soft "future single-item closure" term.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic fractions of
capacity), rewarding tighter fits to consolidate partially-filled bins. On top
of that we reward residuals that look like a plausible next item size, since
such a bin can be closed cleanly by one later item, estimated from the running
empirical distribution of item sizes.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    # Dynamic target residuals: harmonic fractions of capacity, mixed with
    # multiples/complements of the running mean item size.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Fullness-weighted exact-fit bonus: strongly reward placing the item into a
    # bin that becomes tightly packed (small residual) when the bin was already
    # mostly full, i.e. consolidating near-full bins.
    fullness = (bins / _CAP)
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    # Soft "future single-item closure" term: the residual after this placement
    # is itself the size of a future item, so a later arrival could finish this
    # bin. Estimate the probability from the running (smoothed) size histogram.
    if _TOTAL > 30.0:
        counts = _SIZE_COUNT
        total = _TOTAL
        # Laplace-smoothed probability mass over residual values 0..100.
        resid_idx = np.clip(np.rint(residual_after), 0, 100).astype(np.int64)
        p = (counts[resid_idx] + 1.0) / (total + 101.0)
        score = score + 3.0 * p
    else:
        # Before enough history, just lightly favor small residuals that are
        # likely fillable (small integers).
        small = (residual_after <= 10.0).astype(np.float64)
        score = score + 0.05 * small

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END

