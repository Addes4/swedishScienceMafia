# EVOLVE-BLOCK-START
"""Target-residual bin choice with empirically-scaled harmonic targets.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual, and reward tighter fits
to consolidate partially-filled bins. The target residuals are the harmonic
fractions of capacity, scaled by a smoothed estimate of the mean item size so
that the attractive residual levels track the actual scale of the distribution.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

# Precomputed multiplier grid for the dynamic targets.
_MULT = np.arange(0.5, 3.5 + 1e-9, 0.25)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_MEAN = 40.0  # smoothed running mean of item sizes


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _MEAN
    residual_after = bins - item

    # Dynamic target residuals: harmonic fractions of capacity, mixed with
    # multiples and complements of the smoothed mean item size.
    mean = min(max(_MEAN, 20.0), 60.0)
    mult = _MULT * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.20 * residual_after

    if _TOTAL > 0.0:
        resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
        counts = _SIZE_COUNT[resid_int]
        mx = _SIZE_COUNT.max()
        if mx > 0.0:
            score = score + 6.0 * (counts / mx)

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _MEAN += (item - _MEAN) / _TOTAL
    return score
# EVOLVE-BLOCK-END
