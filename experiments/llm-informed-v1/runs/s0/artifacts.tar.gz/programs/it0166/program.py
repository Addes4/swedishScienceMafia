# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by
size-aware best fit.

Capacity is 100. Items arrive online. We learn which residual values are actually
useful: the most frequent item sizes seen so far are the residuals a future item
is most likely to exactly fill, plus their complements. We score each bin by how
close its post-placement residual is to a small set of such empirically
attractive values, then break near-ties toward tighter fits, with the strength
made asymmetric: large arriving items want snug bins, small items prefer roomier
bins that can still host a future large item.

Guards: a nonzero residual smaller than the smallest seen item can never be
filled, so it takes a mild penalty; residuals closable by two likely items get a
small graded bonus.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_MIN_SIZE = 101.0

# Cached target array and cached bonus lookup, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_PAIR_SCORE = np.zeros(101, dtype=np.float64)
_RESID_BONUS = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)


def _rebuild_targets():
    global _TARGETS, _PAIR_SCORE, _RESID_BONUS
    counts = _SIZE_COUNT[1:101]
    total = counts.sum()
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:12] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]

    targets = set([0.0, _CAP])
    bonus = np.zeros(101, dtype=np.float64)
    if total > 0:
        for s in top:
            s = float(s)
            targets.add(s)
            targets.add(_CAP - s)
            # Normalized preference; exact targets share the bonus mass.
            bonus[int(s)] = counts[int(s) - 1] / total
            c = int(_CAP - s)
            if 0 <= c <= 100:
                bonus[c] = max(bonus[c], counts[int(s) - 1] / total)
    _TARGETS = np.array(sorted(targets), dtype=np.float64)
    m = bonus.max()
    if m > 0:
        bonus = bonus / m
    _RESID_BONUS = bonus

    # Probability-weighted two-item sum table over residuals 0..100.
    support = np.zeros(101, dtype=np.float64)
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    if plausible.size:
        w = _SIZE_COUNT[plausible]
        support[plausible] = w / w.sum()
    conv = np.convolve(support, support)
    n = min(101, conv.size)
    pair = np.zeros(101, dtype=np.float64)
    pair[:n] = conv[:n]
    mm = pair.max()
    if mm > 0:
        pair = pair / mm
    _PAIR_SCORE = pair


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Size-aware best-fit pressure: large items prefer snug bins (small positive
    # residual), small items prefer roomier bins so large future items still fit.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    base_w = 0.02 + 0.06 * frac
    size_lean = (item - 50.0) / 50.0
    fit_weight = base_w * (1.0 + 0.6 * size_lean)

    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)

    score = -best - fit_weight * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Guard 2: graded bonus if the residual can still be closed by two items.
    score += 0.02 * _PAIR_SCORE[ri]

    # Direct preference for residuals matching a frequent item size/complement.
    score += 0.03 * _RESID_BONUS[ri]

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
