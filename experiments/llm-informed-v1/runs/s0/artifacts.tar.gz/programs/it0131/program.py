# EVOLVE-BLOCK-START
"""Adaptive bin choice via incrementally-learned residual desirability.

Capacity is 100. Items arrive online. We maintain a table `_DESIRE[r]` giving how
attractive it is to leave a bin with residual capacity r for future items. It is
updated online: every time we see an item of size s, residuals 0 and s (a future
item could exactly close the bin) get boosted, and residual 100 - s also gets a
boost (so that placing an item of size s next to a residual that complements it
to a full bin is favored).

For each candidate bin we compute the residual after placing the item, look up
its desirability, and add a small best-fit pressure (prefer tighter fits) plus a
guard penalty for tiny nonzero residuals that no seen item could ever fill.

The desirability table is a plain numpy array updated in O(1) per call, so the
scoring always reflects all observed items with no reconstruction lag.
"""
import numpy as np

_CAP = 100

# Desirability of leaving each possible residual value (0..100).
_DESIRE = np.zeros(_CAP + 1, dtype=np.float64)
_TOTAL = 0.0
_SIZE_COUNT = np.zeros(_CAP + 1, dtype=np.float64)
_MIN_SIZE = _CAP + 1


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _MIN_SIZE

    residual_after = bins - item

    # Look up desirability of each candidate residual. Clip to valid range so
    # residuals outside [0,100] (shouldn't happen for fitting bins) are safe.
    r = np.clip(residual_after, 0, _CAP).astype(np.int64)
    desire = _DESIRE[r]

    # Primary: prefer residuals that we've learned are fillable.
    # Tie-break: modest best-fit pressure (prefer smaller residual).
    score = desire - 0.05 * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # ---- learn from this item ----
    s = int(item)
    _SIZE_COUNT[s] += 1.0
    # Boost the residual 0 and residual == s (exact close).
    _DESIRE[0] += 1.0
    _DESIRE[s] += 1.0
    # Boost the complementary residual too, capped.
    comp = _CAP - s
    if comp >= 0:
        _DESIRE[comp] += 0.5

    _TOTAL += 1.0
    if s < _MIN_SIZE:
        _MIN_SIZE = float(s)

    return score
# EVOLVE-BLOCK-END

