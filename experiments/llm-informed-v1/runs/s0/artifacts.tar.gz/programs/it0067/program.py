# EVOLVE-BLOCK-START
"""Best-fit with a fill-value bonus for residuals that remain useful.

The key idea is that we want to pack tightly (small post-placement residual),
but a very small residual that cannot fit any future item wastes capacity.
We maintain an exact size-frequency histogram and score bins by:
  - preferring the tightest fit (smallest residual after placement),
  - with a large bonus when the residual equals 0 (perfect close),
  - with a bonus when the residual equals a frequently seen future item size,
  - with a small penalty for residuals that are too small to be useful.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item
    resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)

    # Base: prefer tightest fit (smallest residual after placement).
    score = -residual_after

    # Strong reward for closing a bin exactly.
    score = score + 8.0 * (residual_after == 0.0)

    # Reward leaving a residual that matches a size we have seen often
    # (a high chance a future item exactly fills it).
    if _TOTAL > 0.0:
        counts = _SIZE_COUNT[resid_int]
        mx = _SIZE_COUNT.max()
        if mx > 0.0:
            score = score + 10.0 * (counts / mx)

    # Penalize residuals too small to fit typical future items, but not 0.
    # The empirical mean gives a rough scale; small nonzero residuals are bad.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    small = (residual_after > 0.0) & (residual_after < 0.5 * mean)
    score = score - 0.5 * small

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END
