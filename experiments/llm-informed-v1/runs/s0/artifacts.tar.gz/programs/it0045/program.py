# EVOLVE-BLOCK-START
"""Best-fit with a concave "closable residual" bonus.

Capacity is 100. Items arrive online from a Weibull-shaped distribution with mean
~40. The dominant good heuristic for such online packing is tightest-fit
(smallest residual), which consolidates partially filled bins. We make the
primary signal a best-fit, but add a bonus that rewards residuals which a later
item can plausibly close exactly, using a smoothed empirical size histogram that
stays stable over time (probability, not a max-normalized peak).
"""
import numpy as np

_CAP = 100.0

# Empirically smoothed per-size weights updated online.
_SIZE_COUNT = np.ones(101, dtype=np.float64)  # Laplace smoothing
_TOTAL = 0.0
_LAST_ITEM = 0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _LAST_ITEM
    residual_after = bins - item

    # Primary: tightest fit (smaller residual -> higher score), slightly concave
    # so that perfectly-full bins are not over-obsessed relative to near-full.
    score = -np.sqrt(residual_after + 1.0)

    # Bonus: reward residuals equal to a size class that appears often, so a
    # later item can close the bin exactly. Signal is a probability, stable.
    resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
    prob = _SIZE_COUNT[resid_int] / (_TOTAL + 101.0)
    score = score + 3.0 * prob

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _LAST_ITEM = item
    return score
# EVOLVE-BLOCK-END
