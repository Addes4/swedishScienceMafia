# EVOLVE-BLOCK-START
"""Target-residual bin choice with empirically learned targets.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual. Instead of a fixed
harmonic target set, we learn targets online from the running histogram of
observed item sizes: the most frequent sizes, their arithmetic combinations,
and their complements to capacity. This adapts the geometry to the actual
distribution, which is what determines which residuals are completable.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0

# Cached target array, rebuilt occasionally.
_TARGETS = None
_SINCE_REBUILD = 0
_REBUILD_EVERY = 50

# Fallback static fractions used early on.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)


def _build_targets():
    """Build a target residual set from the empirical size histogram."""
    counts = _SIZE_COUNT
    total = counts.sum()
    if total < 50.0:
        base = _FRACS * _CAP
        extra = np.array([], dtype=np.float64)
    else:
        # Take the most frequent observed sizes.
        order = np.argsort(counts)[::-1]
        top = order[:12]
        top = top[counts[top] > 0]
        sizes = top.astype(np.float64)
        base = _FRACS * _CAP
        # Complements of common sizes: residual that a single common item finishes.
        comp = _CAP - sizes
        # Pair sums that leave a common size: 100 - s1 - s2 small set
        extra = np.concatenate([sizes, comp])
    return np.unique(np.clip(np.concatenate([base, extra]), 0.0, _CAP))


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _TARGETS, _SINCE_REBUILD

    _SINCE_REBUILD += 1
    if _TARGETS is None or _SINCE_REBUILD >= _REBUILD_EVERY:
        _TARGETS = _build_targets()
        _SINCE_REBUILD = 0

    residual_after = bins - item

    # Dynamic targets: harmonic fractions plus multiples of the running mean.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_TARGETS, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Fullness-weighted exact-fit bonus: reward placing the item into a bin
    # that becomes tightly packed when the bin was already mostly full.
    fullness = (bins / _CAP)
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END

