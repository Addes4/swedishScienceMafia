# EVOLVE-BLOCK-START
"""Online bin packing via target-residual (best-fit around an estimated ideal residual)."""
import numpy as np

_state = {
    "n_total": None,
    "seen": 0,
    "sum": 0,
    "open_used": [],  # remaining capacities of bins we've already put items into
}


def priority(item, bins):
    n = len(bins)
    st = _state
    if st["n_total"] != n:
        # fresh instance (len(bins) == number of items on first call)
        st["n_total"] = n
        st["seen"] = 0
        st["sum"] = 0
        st["open_used"] = []
    st["seen"] += 1
    st["sum"] += item

    mean_item = st["sum"] / st["seen"]

    # Estimate the optimal residual to leave after this placement.
    # Ideal average load per bin for such distributions is ~0.8-0.85 of capacity.
    # Target residual ~ (1 - utilization) * 100. Using a modest target helps
    # balance loads, which empirically reduces total bins.
    # Keep the target small relative to item sizes so best-fit behavior dominates
    # for tight placements.
    target_residual = 100.0 - 0.83 * 100.0  # ~17

    residual_after = bins - item
    # Penalize deviation from target residual; ties resolved by bin order.
    return -((residual_after - target_residual) ** 2)
# EVOLVE-BLOCK-END
