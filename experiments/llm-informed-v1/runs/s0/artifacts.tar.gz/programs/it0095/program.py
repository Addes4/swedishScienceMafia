# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets plus size-complement targets.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic fractions of
capacity, plus the running mean item size). We add an extra bonus when the
post-placement residual is likely to be exactly fillable by a future item,
estimated from the running histogram of observed item sizes (heavy sizes).
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    # Dynamic target residuals: harmonic fractions of capacity, mixed with
    # multiples/complements of the running mean item size.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Fullness-weighted exact-fit bonus: strongly reward placing the item into a
    # bin that becomes tightly packed (small residual) when the bin was already
    # mostly full, i.e. consolidating near-full bins.
    fullness = (bins / _CAP)
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    # Exact-fill likelihood bonus: reward residuals that are close to a common
    # observed item size, since such a bin is likely to be closed cleanly by a
    # single future item. Weighted by how common that size is so far.
    if _TOTAL >= 30.0:
        counts = _SIZE_COUNT[1:101]
        peak = counts.max()
        if peak > 0.0:
            common = np.nonzero(counts >= 0.5 * peak)[0].astype(np.float64) + 1.0
            dc = np.abs(residual_after[:, None] - common[None, :])
            near = np.exp(-0.25 * dc).max(axis=1)
            score = score + 0.6 * near * fullness

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END
