# EVOLVE-BLOCK-START
"""Best-fit bin choice with a common-size exact-closure bonus.

Capacity is 100. Items arrive online. The primary signal is classic best-fit:
prefer the bin that leaves the smallest non-negative residual after placing the
item, which consolidates partially filled bins and tends to use few bins. A
secondary bonus favors leaving a residual equal to a frequently seen item size,
so the bin is easy to close exactly later.

State kept: a histogram of item sizes seen so far, used as a smooth proxy for
how likely a given residual is to be matched by a future item.
"""
import numpy as np

_CAP = 100.0

# Histogram of item sizes seen so far (index 0..100), smoothed implicitly by
# using raw counts normalized by the maximum.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL
    residual_after = bins - item

    # Primary: best-fit. Smaller residual is better (more consolidated).
    score = -residual_after

    # Secondary: reward residuals that match a common historical item size,
    # making the bin closable by a single typical future item.
    if _TOTAL > 0.0:
        mx = _SIZE_COUNT.max()
        if mx > 0.0:
            resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
            counts = _SIZE_COUNT[resid_int]
            score = score + 8.0 * (counts / mx)

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END
