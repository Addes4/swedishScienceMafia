# EVOLVE-BLOCK-START
"""Adaptive fillability bin choice: prefer residuals in dense regions of the
empirical item-size distribution, with size-aware best-fit pressure and sliver
guards.

Capacity is 100. Items arrive online. For each candidate post-placement residual
r we estimate the probability that some future item (or pair of items) can fill
it, using the observed size histogram directly rather than a hand-built target
set. This is a smooth "expected closability" that rewards residuals sitting in
dense parts of the size distribution and gives partial credit nearby.

Guard 1: residuals that are nonzero but smaller than the smallest item size seen
so far can never be filled by any future item -> penalty.

Guard 2: a mild penalty for residuals far below the empirical mean item size,
which tend to become slivers that waste space.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the fillability estimate.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_SIZE_SQ = 0.0
_MIN_SIZE = 101.0

# Cached fillability arrays, refreshed as the histogram grows.
_FILL = np.zeros(101, dtype=np.float64)   # P(fill by one item near r)
_PAIR = np.zeros(101, dtype=np.float64)   # P(fill by two items summing to <= r)
_REFRESH = 16
_N_ITEMS = 0.0

# Gaussian kernel over the size axis for smoothing the empirical density.
_KERNEL_R = 4
_KR = np.arange(-_KERNEL_R, _KERNEL_R + 1, dtype=np.float64)
_KERNEL = np.exp(-0.5 * (_KR / 2.0) ** 2)
_KERNEL = _KERNEL / _KERNEL.sum()


def _rebuild():
    global _FILL, _PAIR

    counts = _SIZE_COUNT[1:101]
    plausible = np.nonzero(counts > 0)[0] + 1
    support = np.zeros(101, dtype=np.float64)
    if plausible.size:
        w = counts[plausible]
        support[plausible] = w / w.sum()

    # Smooth density over residual values: probability mass near each r.
    dens = np.convolve(support, _KERNEL, mode="same")[:101]
    if dens.size < 101:
        pad = np.zeros(101, dtype=np.float64)
        pad[: dens.size] = dens
        dens = pad
    mx = dens.max()
    if mx > 0:
        dens = dens / mx
    _FILL = dens

    # Two-item closability: convolution of support with itself gives probability
    # that the sum of two future items lands near r; take cumulative max so a
    # residual >= some common pair-sum is credited.
    conv = np.convolve(support, support)
    pair = np.zeros(101, dtype=np.float64)
    n = min(101, conv.size)
    pair[:n] = conv[:n]
    # Cumulative from the right: P(two items can fit leaving >= 0 slack around r)
    cum = np.cumsum(pair[::-1])[::-1]
    pm = cum.max()
    if pm > 0:
        cum = cum / pm
    _PAIR = cum


def priority(item, bins):
    global _TOTAL, _SIZE_SUM, _SIZE_SQ, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild()

    residual_after = bins - item

    # Fillability of the post-placement residual (one item near r, or two items).
    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)
    fill = 0.6 * _FILL[ri] + 0.4 * _PAIR[ri]

    # Size-aware best-fit pressure: larger arriving items prefer snug bins.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    base_w = 0.02 + 0.06 * frac
    size_lean = (item - 50.0) / 50.0
    fit_weight = base_w * (1.0 + 0.6 * size_lean)

    score = fill - fit_weight * residual_after

    # Guard 1: penalize tiny nonzero residuals no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Guard 2: penalize slivers well below the empirical mean item size.
    if _TOTAL >= 8.0:
        mean = _SIZE_SUM / _TOTAL
        var = max(_SIZE_SQ / _TOTAL - mean * mean, 0.0)
        thr = mean - np.sqrt(var)
        sliver = (residual_after > 0.0) & (residual_after < thr) & (~waste if _MIN_SIZE <= _CAP else True)
        score -= 0.05 * sliver

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    _SIZE_SQ += item * item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END

