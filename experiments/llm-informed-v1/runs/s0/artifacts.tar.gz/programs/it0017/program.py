# EVOLVE-BLOCK-START
"""Adaptive best-fit with residual-compatibility scoring.

Items arrive online with sizes drawn from a fixed Weibull-shaped distribution
(mean ~40, capacity 100). Rather than a fixed harmonic target schedule, we learn
the empirical item-size distribution as items arrive and score each bin by how
likely its post-placement residual is to be closed tightly by a plausible future
item. We reward residuals close to (or slightly above) a typical future item
size, and keep a best-fit secondary term to consolidate partially-filled bins.
"""
import numpy as np

_CAP = 100.0
_MAX_ITEM = 100


def _make_state():
    # Empirical histogram of item sizes seen so far (integers 1..100).
    return np.zeros(_MAX_ITEM + 1, dtype=np.float64)


# Module-level state (fresh per instance/process).
_HIST = _make_state()
_SEEN = 0
# Precompute complement preferences lazily.
_CACHE = {"n": -1, "targets": None, "prior_sizes": None}


def _size_prior():
    """Smoothed distribution over future item sizes, derived from history.

    Early on we fall back to a generic Weibull-ish prior (mean ~40).
    """
    total = _HIST.sum()
    sizes = np.arange(1, _MAX_ITEM + 1, dtype=np.float64)
    if total < 50:
        # Generic prior: Weibull-shaped-ish centered around 40.
        # Use a discretized log-normal-ish shape as a stand-in.
        mu = np.log(38.0)
        sigma = 0.55
        p = np.exp(-0.5 * ((np.log(sizes) - mu) / sigma) ** 2)
        p = p / p.sum()
        return p
    obs = _HIST[1:].copy()
    # Laplace-style smoothing.
    obs = obs + 1.0
    return obs / obs.sum()


def priority(item, bins):
    """Return a priority for every bin; highest score wins (ties -> first bin)."""
    global _SEEN

    # Update the empirical size history with the current item.
    _HIST[item] += 1.0
    _SEEN += 1

    residual_after = bins - item  # new remaining capacity after placing here

    # Refresh the future-size prior occasionally (cheap, not every call).
    if _SEEN % 25 == 1 or _CACHE["prior_sizes"] is None:
        prior = _size_prior()
        sizes = np.arange(1, _MAX_ITEM + 1, dtype=np.float64)
        # Target residuals we'd like to leave: complement so that a future item
        # of a common size fits exactly, i.e. residual ~ size OR just above it.
        # Build weighted target positions from the prior.
        _CACHE["prior_sizes"] = sizes
        _CACHE["targets"] = (sizes, prior)

    sizes, prior = _CACHE["targets"]

    # Score: for each residual, find how well it matches a likely future size.
    # A residual r is "good" if some future size s is close to r (can close the
    # bin), or s slightly less than r (leaves a small but nonzero slack).
    # Approximate: closeness of r to the nearest size, weighted by that size's
    # probability.
    r = residual_after  # shape (nb,)
    # Distance from each residual to each candidate size.
    diff = np.abs(r[:, None] - sizes[None, :])
    # Weighted minimum distance to a plausible future size.
    w = prior[None, :]
    # Use a soft-min over candidate sizes weighted by prior mass: strongly
    # reward residuals near high-probability sizes.
    # score_match = sum_s prior_s * exp(-diff_s^2 / (2*sigma^2))
    sigma = 4.0
    match = (w * np.exp(-(diff ** 2) / (2.0 * sigma * sigma))).sum(axis=1)

    # Secondary: tighter fits consolidate bins (smaller residual better).
    return match - 0.10 * r
# EVOLVE-BLOCK-END
