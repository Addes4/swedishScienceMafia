# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by best fit.

Capacity is 100. Items arrive online. We learn which residual values are actually
useful: the most frequent item sizes seen so far are the residuals a future item
is most likely to exactly fill. We score each bin by how close its
post-placement residual is to a small set of such empirically attractive values,
then break near-ties toward tighter fits (smaller residual). The tie-break
strength is scaled by the observed mean item size so it stays gentle relative to
the main target logic.

Extra guard: a residual that is nonzero but smaller than the sizes that
realistically arrive (below the 5th percentile of seen sizes) can rarely be
filled, so it is wasted space. Such bins get a mild penalty, applied at
tie-break scale so the main target logic still dominates.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0

# Empirical lower cutoff for "fillable" residuals (approx. 5th percentile of sizes).
_SMALL_CUT = 0.0
_SORTED_CACHE = np.zeros(0, dtype=np.float64)
_REFRESH = 32

# Cached target array, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)


def _rebuild_targets():
    global _TARGETS, _SMALL_CUT, _SORTED_CACHE
    counts = _SIZE_COUNT[1:101]
    # Most frequent sizes (ties broken toward larger sizes via ordering).
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:10] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)          # a leftover equal to this size closes cleanly
        targets.add(_CAP - s)   # complement also leaves a fillable residual
    _TARGETS = np.array(sorted(targets), dtype=np.float64)

    # Approximate 5th percentile of observed sizes, for the waste guard.
    if _TOTAL > 0:
        _SORTED_CACHE = np.repeat(np.arange(1, 101, dtype=np.float64),
                                  counts.astype(np.int64))
        if _SORTED_CACHE.size > 0:
            _SMALL_CUT = float(np.percentile(_SORTED_CACHE, 5.0))


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Gentle tie-break pressure: prefer tighter fits, scaled by mean item size
    # so it never overwhelms the primary target-match term.
    mean_size = (_SIZE_SUM / _TOTAL) if _TOTAL > 0 else 40.0
    tie = (item / 100.0) / max(mean_size, 1.0) * 0.05

    # Primary: prefer a residual that matches a commonly arriving size.
    score = -best - tie * residual_after

    # Guard: penalize tiny nonzero residuals that realistically can't be filled.
    if _SMALL_CUT > 0.0:
        waste = (residual_after > 0.0) & (residual_after < _SMALL_CUT)
        score -= 0.02 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END
