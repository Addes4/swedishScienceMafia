# EVOLVE-BLOCK-START
"""Best-fit with harmonic-reserve tie-breaking.

Online bin packing. The dominant robust rule is Best-Fit: place the item into
the bin that leaves the smallest residual capacity (tightest fit). This tends
to consolidate partially-filled bins and is a strong baseline. We refine it with
a harmonic-reserve term: among bins that can still be "reserved" for a size
class, prefer residuals that sit just below a harmonic breakpoint so that the
leftover capacity remains usable by a matching future item.
"""
import numpy as np

_CAP = 100.0

# Harmonic breakpoints scaled to capacity: fractions of 1/k of capacity.
_INV = np.array([1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0], dtype=np.float64)
_BREAKS = _CAP / _INV  # ~100, 50, 33.3, 25, 20, 16.7, 12.5, 10


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual_after = bins - item  # new remaining capacity after placing here

    # Best-fit: prefer the smallest non-negative residual.
    score = -residual_after.astype(np.float64)

    # Harmonic-reserve bonus: reward residuals that fall just below a breakpoint
    # (i.e., small positive distance to the next breakpoint from above).
    # Distance from residual up to the nearest breakpoint >= residual.
    d = _BREAKS[None, :] - residual_after[:, None]
    d = np.where(d >= 0.0, d, np.inf)
    gap = d.min(axis=1)
    score -= 0.10 * gap

    return score
# EVOLVE-BLOCK-END
