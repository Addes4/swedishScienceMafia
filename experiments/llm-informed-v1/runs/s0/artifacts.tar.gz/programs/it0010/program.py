# EVOLVE-BLOCK-START
"""Size-class hybrid: large items use best fit, small items use most-full."""
import numpy as np

# Threshold relative to capacity 100 (items smaller than this are "small").
SMALL_LIMIT = 33


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item <= SMALL_LIMIT:
        # Most-full: prefer the bin with the least remaining capacity
        # (residual after placement is smallest == best fit-like, but we want
        # to consolidate into already-used bins, so prefer smallest residual
        # which is exactly best fit among fitting bins => fullest bin).
        return -(bins - item)
    # Large items: best fit as well but this branch kept explicit for tuning.
    return -(bins - item)
# EVOLVE-BLOCK-END

