# EVOLVE-BLOCK-START
"""Best fit with a penalty for opening brand-new bins when a partial bin is nearly as good."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item  # remaining space after placing the item, >= 0
    # Best fit: prefer the smallest residual. Pure best fit picks the tightest bin.
    score = -residual.astype(np.float64)
    # Penalize opening a fresh bin (residual == 100 - item, i.e. bins was 100) for
    # small items, so we consolidate into partial bins instead of fragmenting.
    fresh = (bins == 100)
    if fresh.any() and item < 100:
        # A small, decreasing penalty for using an empty bin; small items waste a
        # fresh bin the most, so push them toward partial bins.
        score = score - fresh * (0.5 * (100 - item))
    return score
# EVOLVE-BLOCK-END
