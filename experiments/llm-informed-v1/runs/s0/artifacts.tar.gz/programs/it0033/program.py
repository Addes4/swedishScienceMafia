# EVOLVE-BLOCK-START
"""Best-fit consolidation for online bin packing.

For online bin packing a strong, low-variance policy is Best Fit: place the
item into the bin that leaves the smallest residual after placement, which
tightly consolidates partially full bins and leaves large empty bins free for
future large items. Earlier target-residual heuristics diluted this signal;
here the primary (and effectively only) term is best fit, with a very small
secondary nudge toward residuals that are exactly zero so perfectly filled
bins are preferred on near-ties.
"""
import numpy as np

_CAP = 100.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual_after = bins - item  # new remaining capacity after placing here
    # Primary: best fit -> smallest residual after placement consolidates bins.
    # Secondary: tiny nudge rewarding exact fills (residual 0).
    return -residual_after - 0.001 * (residual_after == 0)
# EVOLVE-BLOCK-END


