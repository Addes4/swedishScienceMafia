# EVOLVE-BLOCK-START
"""Best-fit-dominant bin choice with a light target-residual tie-break.

Capacity is 100. Items arrive online and are placed greedily. The dominant
signal is the classical Best-Fit rule: prefer the bin whose remaining capacity
after placement is smallest (tightest fit), which empirically packs well for
Weibull-shaped sizes. A light target-residual term nudges the choice toward
residuals that are attractive harmonic fractions of capacity, and an exact-fit
bonus rewards clean closures.
"""
import numpy as np

_CAP = 100.0

# A few productive harmonic fractions of capacity.
_FRACS = np.array(
    [0.0, 0.25, 1.0 / 3.0, 0.5, 2.0 / 3.0, 0.75, 1.0],
    dtype=np.float64,
)
_TARGETS = _FRACS * _CAP

_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    # Dominant term: Best-Fit, minimize post-placement residual.
    score = -residual_after

    # Light target-residual geometry: reward landing close to a harmonic fraction.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)
    score = score - 0.05 * best

    # Exact-fit bonus: strongly reward clean closure of a bin.
    score = score - 0.5 * np.exp(-0.5 * residual_after)

    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END

