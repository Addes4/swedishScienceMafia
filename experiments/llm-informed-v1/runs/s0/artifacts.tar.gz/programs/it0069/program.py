# EVOLVE-BLOCK-START
"""Target-residual bin choice with empirically-scaled harmonic targets.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual, and reward tighter fits
to consolidate partially-filled bins. The target residuals are the harmonic
fractions of capacity, scaled by the empirical mean item size so that the
attractive residual levels track the actual scale of the distribution.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    # Dynamic target residuals: harmonic fractions of capacity, mixed with
    # multiples/complements of the running mean item size.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.20 * residual_after

    if _TOTAL > 0.0:
        resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
        counts = _SIZE_COUNT[resid_int]
        # Unnormalized empirical frequency bonus, softly capped so that highly
        # frequent residuals give a meaningful but bounded consolidation boost.
        score = score + np.minimum(counts, 25.0) * (3.0 / 25.0)

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END
