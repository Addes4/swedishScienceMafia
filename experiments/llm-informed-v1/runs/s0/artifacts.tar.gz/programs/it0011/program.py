# EVOLVE-BLOCK-START
"""Best fit with a learned near-optimal residual target as secondary tie-break."""
import numpy as np

_state = {}


def priority(item, bins):
    # On first call, remember the total item count (len(bins) == number of items).
    if 'n' not in _state:
        _state['n'] = len(bins)
        _state['count'] = 0
        _state['sum'] = 0.0

    _state['count'] += 1
    _state['sum'] += item

    # Estimate number of bins the optimum will use:
    # total volume / capacity is a lower bound; heuristic optimum ~ that / ~0.95
    total = _state['sum'] + (100.0 * 0.0)  # running total volume so far
    # scale the running total to the full instance using seen fraction
    seen = _state['count']
    n = _state['n']
    full_est = total * (n / seen)
    est_bins = max(1.0, full_est / 100.0)
    # typical residual per nearly-full bin: leftover room on last-open bin
    target_residual = full_est / est_bins * 0.0  # unused
    # Aim each bin's fill toward ~ (full_est / est_bins)
    avg_fill = full_est / est_bins  # ~100 if perfectly packed

    residual = bins - item  # >= 0 for all shown bins

    # Primary: best fit (smallest residual).
    primary = -residual.astype(np.float64)

    # Secondary: prefer residual close to the expected leftover (100 - avg_fill),
    # i.e. prefer bins that end up near the average fill level.
    expected_res = 100.0 - avg_fill
    secondary = -np.abs(residual.astype(np.float64) - expected_res)

    # Keep primary dominant; secondary only breaks near-ties.
    score = primary * 1000.0 + secondary
    return score
# EVOLVE-BLOCK-END
