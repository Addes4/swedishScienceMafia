# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, seal exact fits.

Capacity is 100. Items arrive online. We learn which residual values are
actually useful: the most frequent item sizes seen so far are the residuals a
future item is most likely to exactly fill. Each bin is scored by how close its
post-placement residual is to a small set of such empirically attractive values,
with an extra jackpot bonus when the residual exactly hits a target (so bins
seal cleanly), then a mild best-fit tie-break toward smaller residual.

Guard: a residual that is nonzero but smaller than the smallest item size seen
so far can never be filled by any future item, so it is wasted space. Such bins
get a mild penalty applied at tie-break scale.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached target array, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_REFRESH = 32


def _rebuild_targets():
    global _TARGETS
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:10] + 1
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)
        targets.add(_CAP - s)
    _TARGETS = np.array(sorted(targets), dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Jackpot: exact hit on an attractive residual (0 or a frequent size).
    exact = (best == 0.0).astype(np.float64)

    # Primary: prefer a residual that matches a commonly arriving size.
    # Tie-break: modest best-fit pressure (prefer smaller residual).
    score = -best + 0.5 * exact - 0.05 * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
