# EVOLVE-BLOCK-START
"""Best-fit bin choice.

Capacity is 100. Items arrive online. The classical best-fit heuristic places
each item into the bin that leaves the smallest residual capacity that still
fits the item, which both consolidates partially-filled bins and avoids
wasting room. We use the post-placement residual as the primary key (lower is
better) and add a very small exact-fit bonus so that a placement that closes a
bin cleanly is preferred over an equally tight alternative.
"""
import numpy as np

_CAP = 100.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual_after = bins - item

    # Best-fit: smaller residual after placement is better.
    score = -residual_after.astype(np.float64)

    # Tiny exact-fit bonus: reward perfect closure so the item goes into a bin
    # it fully fills rather than an equivalent near-fit.
    score = score + 1e-3 * (residual_after == 0)

    return score
# EVOLVE-BLOCK-END
