# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by best fit.

Capacity is 100. Items arrive online. We rank bins by how useful their post-placement
residual is for the future: a residual is attractive if it equals a commonly arriving
item size (so a future item fills it exactly) or a complement of one. We estimate this
directly from the observed histogram of item sizes, so the target set adapts online.

Extra guard: a residual that is nonzero but smaller than the smallest item size seen so
far can never be filled by any future item, so it is wasted space. Such bins get a mild
penalty, applied at tie-break scale so the main target logic still dominates.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" value table.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached value table over residuals 0..100 and target array, refreshed as histogram grows.
_VALUES = np.zeros(101, dtype=np.float64)  # value of leaving residual r
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_REFRESH = 32


def _rebuild_targets():
    global _TARGETS, _VALUES
    counts = _SIZE_COUNT[1:101]
    total = counts.sum()
    # Laplace-smoothed probability of each item size 1..100.
    p = (counts + 1.0) / (total + 100.0)

    # Value of a residual r: probability that some future item exactly fills it
    # (size == r), weighted strongly, plus probability that a complement pair
    # (r + s == 100) can close the bin.
    vals = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        ps = p[s - 1]
        # exact fill: leaving residual s is directly consumable
        vals[s] += 2.0 * ps
        # complement: residual r where r + s == 100 leaves a clean close
        c = 100 - s
        if 0 <= c <= 100:
            vals[c] += 0.5 * ps
    # Residual 0 (perfectly full) and 100 (empty) are special.
    vals[0] = 0.0
    vals[100] = 0.0
    _VALUES = vals

    # Most frequent sizes for the distance-based target set (coarse structure).
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:10] + 1
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)
        targets.add(_CAP - s)
    _TARGETS = np.array(sorted(targets), dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item
    idx = np.clip(residual_after, 0, 100).astype(np.int64)

    # Primary: value of the residual we would leave behind.
    value = _VALUES[idx]

    # Secondary: distance to the nearest attractive target (coarse structure).
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Combine: reward high-value residuals, mildly prefer tight fits / target matches.
    score = value - 0.05 * best - 0.02 * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
