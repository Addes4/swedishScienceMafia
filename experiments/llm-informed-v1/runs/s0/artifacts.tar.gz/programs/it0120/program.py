# EVOLVE-BLOCK-START
"""Adaptive residual-target bin choice with empirical fill-likelihood weighting.

Capacity is 100. Items arrive online. The key idea: a bin's leftover residual is
"valuable" if it is likely to be filled (or nearly filled) by a future item.
We learn the empirical distribution of item sizes seen so far and estimate, for
each candidate residual, a fill score equal to the probability mass of future
items that fit exactly into that residual. Residuals near 0 are trivially fine
(bin is sealed); residuals that match frequent item sizes are good. We also
apply best-fit pressure as a tie-break (prefer smaller residuals) and penalize
small non-fillable waste residuals.
"""
import numpy as np

_CAP = 100.0

# Empirical item-size histogram -> drives fill-likelihood estimation.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached fill-likelihood table indexed by residual (0..100).
_FILL = np.zeros(101, dtype=np.float64)
_REFRESH = 32


def _rebuild_fill():
    """Estimate the probability that a future item fits exactly into residual r.

    Uses the empirical size distribution: fill(r) = P(size == r).  We smooth
    slightly toward neighboring sizes so exact-match targets still get credit
    when an item can almost fill the bin (leaving tiny residuals).
    """
    global _FILL
    counts = _SIZE_COUNT[1:101]
    total = counts.sum()
    if total <= 0.0:
        _FILL[:] = 0.0
        return
    p = counts / total
    # Exact-fill probability per residual value 1..100.
    f = np.zeros(101, dtype=np.float64)
    f[1:101] = p
    # Small smoothing: credit residuals a little for near-exact fills.
    sm = f.copy()
    sm[1:100] += 0.5 * f[2:101]
    sm[2:101] += 0.5 * f[1:100]
    # A sealed bin (residual 0) is always valuable.
    sm[0] = 1.0
    _FILL = sm


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_fill()

    residual_after = bins - item
    r = np.clip(residual_after, 0, 100).astype(np.int64)

    # Primary: how likely is this residual to be exactly filled by a future item?
    fill = _FILL[r]

    # Secondary: best-fit pressure, prefer smaller residual (tighter).
    # Tertiary: penalize tiny nonzero residuals no seen item can fill.
    score = fill - 0.05 * residual_after
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
