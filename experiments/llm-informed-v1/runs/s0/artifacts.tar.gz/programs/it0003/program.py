# EVOLVE-BLOCK-START
"""Adaptive best fit: choose the bin that best matches the expected future item size."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Score bins by how well their resulting remaining capacity matches expected future items."""
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    rem = bins - item          # remaining capacity if item goes here
    # Prefer bins that end up close to the average item size (reusable), and among
    # those, tighter (smaller) residual; unused bins are mildly penalized.
    score = -(np.abs(rem - mean)) - 0.001 * rem
    return score
# EVOLVE-BLOCK-END
