# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets, fullness-weighted fit bonus,
and an empirical single-item closure bonus.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic fractions of
capacity), rewarding tighter fits to consolidate partially-filled bins. On top
of that we add a closure bonus: a residual that is close to a likely future item
size (estimated from a smoothed empirical size histogram) is valuable, since one
more item can then finish the bin exactly.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_SIZE_HIST = np.zeros(101, dtype=np.float64)   # smoothed empirical size pmf

_RES_GRID = np.arange(0.0, 101.0, 1.0)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    # Dynamic target residuals: harmonic fractions of capacity, mixed with
    # multiples/complements of the running mean item size.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Fullness-weighted exact-fit bonus: strongly reward placing the item into a
    # bin that becomes tightly packed (small residual) when the bin was already
    # mostly full, i.e. consolidating near-full bins.
    fullness = (bins / _CAP)
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    # Empirical single-item closure bonus: how likely is the residual exactly
    # fillable by one more item, given the observed size distribution?
    if _TOTAL >= 20.0:
        closure = _SIZE_HIST[np.clip(np.round(residual_after), 0, 100).astype(np.int64)]
        score = score + 1.5 * closure

    # Update running statistics after scoring.
    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item

    # Smooth empirical size pmf update (exponential-like smoothing via grid).
    _SIZE_HIST[item] += 1.0
    if _TOTAL % 50.0 == 0.0:
        # Re-smooth periodically: keep mass normalized with light blur.
        h = _SIZE_HIST.copy()
        blur = h.copy()
        blur[1:] += 0.25 * h[:-1]
        blur[:-1] += 0.25 * h[1:]
        s = blur.sum()
        if s > 0.0:
            _SIZE_HIST[:] = blur / s
    return score
# EVOLVE-BLOCK-END
