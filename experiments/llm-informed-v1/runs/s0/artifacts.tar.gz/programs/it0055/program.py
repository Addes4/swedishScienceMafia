# EVOLVE-BLOCK-START
"""Target-residual bin choice with exact-hit emphasis.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic-style structure).
Weights are non-linear: hitting a target exactly is strongly preferred because
that is what lets a partially-filled bin close cleanly on a later item, while
near-misses still get partial credit. A small residual penalty consolidates
bins. A normalized histogram bonus nudges toward residuals some item can fill.
"""
import numpy as np

_CAP = 100.0

_TARGETS = np.array(
    [
        _CAP / 2.0,          # 50
        _CAP / 3.0,          # ~33
        (2.0 * _CAP) / 3.0,  # ~67
        _CAP / 4.0,          # 25
        (3.0 * _CAP) / 4.0,  # 75
        _CAP / 5.0,          # 20
        0.0,                 # perfectly full
    ],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL
    residual_after = bins - item

    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)
    # Non-linear shaping: exact (or near-exact) target hits are strongly preferred.
    score = -best * best - 0.15 * best - 0.15 * residual_after

    if _TOTAL > 0.0:
        resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
        counts = _SIZE_COUNT[resid_int]
        mx = _SIZE_COUNT.max()
        if mx > 0.0:
            score = score + 6.0 * (counts / mx)

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END
