# EVOLVE-BLOCK-START
"""Harmonic-style bin choice blended with best-fit consolidation and
distribution-aware "matching residual" bonus.

The classic weakness of pure best-fit is fragmentation: it scatters leftovers
into many bins with awkward residuals. Harmonic schemes instead try to leave
residuals that future items can close exactly. We keep the smooth harmonic
target structure, but add a bonus when the post-placement residual closely
matches a size class that is common in the empirical item-size distribution
(estimated online from past items only).
"""
import numpy as np

_CAP = 100.0

# Harmonic breakpoints scaled to capacity: remainders we like to leave open so
# later items of the "matching" size class can close them well.
_TARGETS = np.array(
    [
        _CAP / 2.0,          # 50
        _CAP / 3.0,          # ~33
        (2.0 * _CAP) / 3.0,  # ~67
        _CAP / 4.0,          # 25
        (3.0 * _CAP) / 4.0,  # 75
        _CAP / 5.0,          # 20
        0.0,                 # perfectly full
    ],
    dtype=np.float64,
)

# Empirical histogram over integer sizes 0..100, updated from observed items.
_HIST = np.zeros(101, dtype=np.float64)
_SEEN = 0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _SEEN
    residual_after = bins - item  # new remaining capacity after placing here

    # Distance to the nearest attractive target residual (harmonic structure).
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Distribution-aware matching bonus: prefer residuals that equal a commonly
    # seen item size, so a later item can close the bin exactly.
    if _SEEN > 0:
        # Smooth the histogram slightly so nearby sizes are also rewarded.
        h = _HIST
        smooth = h.copy()
        smooth[1:] += 0.5 * h[:-1]
        smooth[:-1] += 0.5 * h[1:]
        # Normalize into a 0..1-ish weight.
        mx = smooth.max() if smooth.max() > 0 else 1.0
        w = smooth / mx
        # Look up weights at the integer residual (clip to valid range).
        idx = np.clip(np.round(residual_after).astype(np.int64), 0, 100)
        match = w[idx]
    else:
        match = np.zeros_like(residual_after)

    # Primary: closeness to an attractive target residual.
    # Secondary: strongly reward residuals that match common item sizes.
    # Tertiary: tighter fits consolidate bins.
    score = -best + 8.0 * match - 0.15 * residual_after

    # Record this item for future distribution estimates.
    if 1 <= item <= 100:
        _HIST[item] += 1.0
    _SEEN += 1

    return score
# EVOLVE-BLOCK-END


