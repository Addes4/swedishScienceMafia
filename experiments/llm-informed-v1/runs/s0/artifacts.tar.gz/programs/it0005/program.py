# EVOLVE-BLOCK-START
"""Best fit with a harmonic fullness bias to reduce fragmentation for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer the bin that ends up fullest (smallest remaining capacity after placement).
    remaining = bins - item
    # Primary: smaller remaining capacity is better -> negative.
    # Secondary harmonic term: among bins with identical remaining capacity, prefer the
    # one that was already more full (lower `bins`), consolidating partial bins.
    # The tiny coefficient keeps best fit dominant while breaking ties toward fuller bins.
    return -(remaining.astype(np.float64) * 1000.0 + bins)
# EVOLVE-BLOCK-END

