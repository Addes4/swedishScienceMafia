# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by
size-aware best fit.

Capacity is 100. Items arrive online. We learn which residual values are actually
useful: the most frequent item sizes seen so far are the residuals a future item
is most likely to exactly fill. We score each bin by how close its post-placement
residual is to a small set of such empirically attractive values, then break
near-ties toward tighter fits, with the strength and *direction* of that pressure
made asymmetric: large arriving items want snug bins, small items prefer roomier
bins that can still host a future large item.

Extra guard 1: a residual that is nonzero but smaller than the smallest item size
seen so far can never be filled by any future item, so it is wasted space. Such
bins get a mild penalty.

Extra guard 2: a residual reachable as a two-item sum is more valuable than one
that is not, graded by a probability-weighted two-item sum table.

Extra guard 3: when a small item is placed, penalize bins whose post-placement
residual would fall below the largest plausible future item size, preserving
slots for big arrivals.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached target array, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
# Cached pair-sum table (probability-weighted two-item sums, indexed 0..100).
_PAIR_SCORE = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)
_BIG = 60.0     # threshold for "large" future item reservation


def _rebuild_targets():
    global _TARGETS, _PAIR_SCORE
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:12] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)          # a leftover equal to this size closes cleanly
        targets.add(_CAP - s)   # complement also leaves a fillable residual
    _TARGETS = np.array(sorted(targets), dtype=np.float64)

    # Probability-weighted two-item sum table over residuals 0..100.
    support = np.zeros(101, dtype=np.float64)
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    if plausible.size:
        w = _SIZE_COUNT[plausible]
        support[plausible] = w / w.sum()
    conv = np.convolve(support, support)
    n = min(101, conv.size)
    pair = np.zeros(101, dtype=np.float64)
    pair[:n] = conv[:n]
    m = pair.max()
    if m > 0:
        pair = pair / m
    _PAIR_SCORE = pair


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Size-aware best-fit pressure: large items prefer snug bins (small positive
    # residual), small items prefer roomier bins so large future items still fit.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    base_w = 0.02 + 0.06 * frac
    # item in 1..100; large -> +1, small -> -1 (roomier bins preferred)
    size_lean = (item - 50.0) / 50.0
    fit_weight = base_w * (1.0 + 0.6 * size_lean)

    score = -best - fit_weight * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Guard 2: graded bonus if the residual can still be closed by two items.
    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)
    score += 0.02 * _PAIR_SCORE[ri]

    # Guard 3: for small items, penalize placements that shrink a bin's free
    # space below a "big" future item, so large arrivals still have a slot.
    if item < 50.0:
        # bins currently holding at least a big slot but losing it get penalized.
        lost_big = (bins >= _BIG) & (residual_after < _BIG)
        score -= 0.03 * lost_big * (1.0 - item / 50.0)

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END

