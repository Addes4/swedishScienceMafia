# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets and a strand-fragment guard.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic fractions of
capacity), rewarding tighter fits to consolidate partially-filled bins. A
fullness-weighted exact-fit bonus prefers sealing nearly-full bins, and a
"strand-fragment" penalty discourages leaving tiny positive residuals that no
single future item is likely to fill.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SEEN = 101.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SEEN
    residual_after = bins - item

    # Dynamic target residuals: harmonic fractions of capacity, mixed with
    # multiples/complements of the running mean item size.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Fullness-weighted exact-fit bonus.
    fullness = bins / _CAP
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    # Strand-fragment guard: penalize leaving a small positive residual that is
    # below the smallest item size seen so far (it can't be filled by a single
    # typical small item and tends to become waste). Zero residual stays good.
    min_seen = _MIN_SEEN if _MIN_SEEN <= 100.0 else 1.0
    small = (residual_after > 0.0) & (residual_after < min_seen)
    frag = residual_after / min_seen  # in (0,1)
    score = score - 1.5 * np.where(small, (1.0 - frag) * frag * 4.0, 0.0)

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SEEN:
        _MIN_SEEN = item
    return score
# EVOLVE-BLOCK-END
