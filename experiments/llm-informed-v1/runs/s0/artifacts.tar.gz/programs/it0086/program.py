# EVOLVE-BLOCK-START
"""Best-fit with packability-aware residual scoring.

Capacity is 100. Items arrive online. Classic best-fit minimizes waste by
choosing the fullest fitting bin, but it produces awkward fragments (residuals
that no future item can fill). We keep the best-fit backbone (dominant term on
the smallest post-placement residual) and add a secondary term that rewards
post-placement residuals lying near an integer multiple of the running mean item
size, so leftovers remain packable by future items. Ties still resolve to the
first (most-filled fitting) bin.
"""
import numpy as np

_CAP = 100.0

_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)

    # Best-fit backbone: strongly prefer the smallest nonnegative residual.
    score = -residual_after

    # Packability term: residual near an integer multiple of a typical item size
    # is easy to consume later; residual near an odd mid-gap is wasteful.
    mult = np.round(residual_after / mean)
    gap = residual_after - mult * mean
    score = score - 0.35 * (gap * gap)

    # Consolidation bonus: reward closing bins that are already mostly full.
    fullness = bins / _CAP
    score = score + 0.8 * np.exp(-0.5 * residual_after) * fullness

    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END
