# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets and a data-driven fillability bonus.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic fractions of
capacity), rewarding tighter fits to consolidate partially-filled bins. On top
of this, we add a fillability bonus: a residual that is close to a commonly
observed item size (empirically estimated online) is likely to be exactly
closed by a single future item, so it is rewarded; awkward small residuals are
tolerated less.
"""
import numpy as np

_CAP = 100.0

_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    fullness = (bins / _CAP)
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    # Fillability bonus: reward residuals near a commonly observed item size,
    # which means a single future item can likely close the bin exactly.
    if _TOTAL > 0.0:
        dist = _SIZE_COUNT / _TOTAL
        # Weight each candidate residual by the probability of a matching item
        # within a small tolerance window (soft, so a residual of 1-100 maps to
        # the empirical distribution).
        r = np.clip(residual_after, 0.0, 100.0)
        lo = np.clip(np.floor(r - 1.5), 0, 100).astype(np.int64)
        hi = np.clip(np.ceil(r + 1.5), 0, 100).astype(np.int64)
        # cumulative sums of the distribution for fast window sums
        csum = np.concatenate([[0.0], np.cumsum(dist)])
        window = csum[hi + 1] - csum[lo]
        # zero residual cannot be filled by future item in the sense of closing
        # (it means the bin is exactly full already), keep its value high too.
        fill = window
        score = score + 1.0 * fill

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END

