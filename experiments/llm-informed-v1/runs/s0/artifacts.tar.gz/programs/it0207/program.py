# EVOLVE-BLOCK-START
"""Adaptive closability bin choice.

Capacity is 100. Items arrive online. For each candidate bin we look at the
post-placement residual r and score how likely r is to be *exactly* closed by
future items, using the empirical distribution of sizes seen so far:

  * exact-fill score  : probability the next item equals r
  * pair-sum score    : probability two future items sum exactly to r
  * near score        : smoothed single-item credit for residuals close to a
                        frequent size

These are combined with a small best-fit pressure (snug residual) so that when
closability is similar we still prefer tighter bins. A mild penalty discourages
leaving tiny nonzero residuals smaller than the smallest item seen so far.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_MIN_SIZE = 101.0

_PAIR_SCORE = np.zeros(101, dtype=np.float64)
_EXACT_SCORE = np.zeros(101, dtype=np.float64)
_NEAR_SCORE = np.zeros(101, dtype=np.float64)
_REFRESH = 8
_N_ITEMS = 0.0

_KERNEL_R = 4
_KR = np.arange(-_KERNEL_R, _KERNEL_R + 1, dtype=np.float64)
_KERNEL = np.exp(-0.5 * (_KR / 2.0) ** 2)


def _rebuild():
    global _PAIR_SCORE, _EXACT_SCORE, _NEAR_SCORE
    support = np.zeros(101, dtype=np.float64)
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    if plausible.size:
        w = _SIZE_COUNT[plausible]
        support[plausible] = w / w.sum()

    # Pair-sum closability.
    conv = np.convolve(support, support)
    pair = np.zeros(101, dtype=np.float64)
    n = min(101, conv.size)
    pair[:n] = conv[:n]
    m = pair.max()
    if m > 0:
        pair = pair / m
    _PAIR_SCORE = pair

    # Exact single-item fill.
    exact = support.copy()
    mx = exact.max()
    if mx > 0:
        exact = exact / mx
    _EXACT_SCORE = exact

    # Smoothed near-frequent-size credit.
    near = np.convolve(support, _KERNEL, mode="same")
    near = near[:101]
    if near.size < 101:
        pad = np.zeros(101, dtype=np.float64)
        pad[: near.size] = near
        near = pad
    mn = near.max()
    if mn > 0:
        near = near / mn
    _NEAR_SCORE = near


def priority(item, bins):
    global _TOTAL, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild()

    residual_after = bins - item

    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)

    # Closability is the dominant signal.
    score = (0.06 * _PAIR_SCORE[ri]
             + 1.2 * _EXACT_SCORE[ri]
             + 0.20 * _NEAR_SCORE[ri])

    # Small best-fit pressure: prefer snug residuals after closability is equal.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    fit_weight = 0.01 + 0.03 * frac
    score -= fit_weight * residual_after

    # Mild guard: tiny nonzero residuals no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.03 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
