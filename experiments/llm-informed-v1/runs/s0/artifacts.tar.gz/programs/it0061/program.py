# EVOLVE-BLOCK-START
"""Best-fit with residual-utility penalty.

Capacity is 100. Items arrive online. The bin-choice rule scores each bin by
the residual left after placing the item (tighter fit better), then subtracts a
penalty for residuals that are "wasteful" — too small to be usefully filled
later but still nonzero. This discourages both over-consolidation (leaving tiny
unusable slivers) and under-filling.

The penalty term measures the expected fraction of the residual that a random
future item cannot use, estimated from the empirical item-size histogram seen so
far. A residual that exactly matches a common size is nearly free; a residual
that leaves a sliver matching nothing is expensive.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL
    residual_after = bins - item

    # Base: tightest fit preferred.
    score = -residual_after.astype(np.float64)

    # Penalty for "unusable" residual: probability mass of future items that
    # could not fit into the residual (i.e. size > residual), plus a small
    # penalty for leaving a nonzero but tiny residue.
    if _TOTAL > 0.0:
        resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
        # fraction of observed items strictly larger than the residual:
        # those items can never be placed in this bin's leftover -> wasted.
        cum = np.cumsum(_SIZE_COUNT[::-1])[::-1]  # cum[s] = count of sizes >= s
        total = _TOTAL
        wasted_frac = cum[resid_int + np.where(resid_int < 100, 1, 0)] / total if False else None
        # safe indexing
        idx = np.clip(resid_int + 1, 0, 100)
        wasted_frac = cum[idx] / total
        # value of the residual: how much of it a future item can actually use
        useful = 1.0 - wasted_frac
        # prefer residuals that are useful (large fraction usable) -> penalize low usefulness
        score = score - 15.0 * wasted_frac
        # slight extra push to leave residuals matching common sizes (exact closure)
        counts = _SIZE_COUNT[resid_int]
        score = score + 3.0 * (counts / (total if total > 0 else 1.0))

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END
