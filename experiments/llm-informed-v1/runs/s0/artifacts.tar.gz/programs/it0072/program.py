# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets, fullness-weighted exact-fit
bonus, and an empirical "matchable residual" reward.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic fractions of
capacity), rewarding tighter fits to consolidate partially-filled bins. A
fullness-weighted exact-fit bonus prefers closing nearly-full bins cleanly.

New: we track the empirical frequency of item sizes seen so far and add a
modest bonus when the post-placement residual equals a size that has actually
been observed frequently, since a future item can then close the bin exactly.
This is a smoothed, unnormalized count reward capped in influence.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    # Dynamic target residuals: harmonic fractions of capacity, mixed with
    # multiples/complements of the running mean item size.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Fullness-weighted exact-fit bonus: strongly reward placing the item into a
    # bin that becomes tightly packed (small residual) when the bin was already
    # mostly full, i.e. consolidating near-full bins.
    fullness = (bins / _CAP)
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    # Empirical "matchable residual" reward: prefer leaving a residual equal to a
    # frequently observed item size, so a future item can close the bin exactly.
    if _TOTAL > 5.0:
        counts = _SIZE_COUNT
        tot = counts.sum()
        # Look up the observed frequency of the integer residual (rounded).
        resid_int = np.clip(np.round(residual_after).astype(np.int64), 0, 100)
        freq = counts[resid_int] / tot
        # Unnormalized, capped contribution.
        score = score + np.minimum(freq * 200.0, 3.0)

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END
