# EVOLVE-BLOCK-START
"""Adaptive combo bin choice with smooth (interpolated) closability signals.

Capacity is 100. Items arrive online. We learn which residual values are useful:
the most frequent item sizes seen so far are the residuals a future item is most
likely to (nearly) fill. Each bin is scored by how close its post-placement
residual is to such empirically attractive values, with a size-aware best-fit
tie-break.

Closability is evaluated smoothly: instead of integer-bin lookups of PAIR/EXACT/
NEAR tables, we use a continuous exact-fill score with a small Gaussian kernel
plus probability-weighted pair-sum credit, interpolated at the (float) residual.
This gives proportional credit to residuals between integer sizes.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_PAIR_CONT = np.zeros(0, dtype=np.float64)   # continuous pair-sum density 0..200
_EXACT_CONT = np.zeros(0, dtype=np.float64)  # continuous single-item density
_REFRESH = 16
_N_ITEMS = 0.0

# Grid for continuous density interpolation.
_GRID_STEP = 1.0
_PAIR_GRID = np.arange(0.0, 200.0 + _GRID_STEP, _GRID_STEP)
_EXACT_GRID = np.arange(0.0, 100.0 + _GRID_STEP, _GRID_STEP)


def _rebuild_targets():
    global _TARGETS, _PAIR_CONT, _EXACT_CONT
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:12] + 1
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)
        targets.add(_CAP - s)
    _TARGETS = np.array(sorted(targets), dtype=np.float64)

    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    if plausible.size:
        w = _SIZE_COUNT[plausible]
        support = np.zeros(101, dtype=np.float64)
        support[plausible] = w / w.sum()
    else:
        support = np.zeros(101, dtype=np.float64)

    # Single-item continuous density: place atom mass at each integer size and
    # convolve with a small Gaussian, then sample on the grid.
    kern_x = np.arange(-3.0, 3.0 + 1e-9, 1.0)
    kern = np.exp(-0.5 * (kern_x / 1.5) ** 2)
    kern /= kern.sum()
    exact_cont = np.convolve(support, kern, mode="same")
    exact_cont = exact_cont[:101]
    if exact_cont.size < 101:
        pad = np.zeros(101)
        pad[: exact_cont.size] = exact_cont
        exact_cont = pad
    _EXACT_CONT = exact_cont

    # Pair-sum continuous density.
    conv = np.convolve(support, support)
    pair = np.zeros(201)
    n = min(201, conv.size)
    pair[:n] = conv[:n]
    # smooth
    pk = np.convolve(pair, kern, mode="same")
    _PAIR_CONT = pk


def _interp(grid, values, x):
    """Linear interpolation of values defined on grid at float points x."""
    x = np.clip(x, grid[0], grid[-1])
    idx = (x - grid[0]) / _GRID_STEP
    i0 = np.floor(idx).astype(np.int64)
    i1 = np.minimum(i0 + 1, values.size - 1)
    frac = idx - i0
    return values[i0] * (1.0 - frac) + values[i1] * frac


def priority(item, bins):
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    base_w = 0.02 + 0.06 * frac
    size_lean = (item - 50.0) / 50.0
    fit_weight = base_w * (1.0 + 0.6 * size_lean)

    score = -best - fit_weight * residual_after

    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Smooth closability: interpolate exact and pair densities at float residual.
    r = np.clip(residual_after, 0.0, _CAP)
    exact = _interp(_EXACT_GRID, _EXACT_CONT, r)
    pair = _interp(_PAIR_GRID, _PAIR_CONT, r)

    em = _EXACT_CONT.max() if _EXACT_CONT.size else 0.0
    pm = _PAIR_CONT.max() if _PAIR_CONT.size else 0.0
    if em > 0:
        exact = exact / em
    if pm > 0:
        pair = pair / pm

    score += 0.5 * exact
    score += 0.02 * pair

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
