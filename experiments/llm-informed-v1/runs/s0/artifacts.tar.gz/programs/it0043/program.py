# EVOLVE-BLOCK-START
"""Target-residual bin choice with a probability-weighted closable-residual bonus.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic-style structure),
reward tighter fits to consolidate partially-filled bins, and add a bonus for
leaving a residual equal to a commonly observed item size (so a later item of
that size can close the bin). The bonus uses the empirical probability of the
residual size, which is stable rather than dominated by a single rare peak.
"""
import numpy as np

_CAP = 100.0

_TARGETS = np.array(
    [
        _CAP / 2.0,          # 50
        _CAP / 3.0,          # ~33
        (2.0 * _CAP) / 3.0,  # ~67
        _CAP / 4.0,          # 25
        (3.0 * _CAP) / 4.0,  # 75
        _CAP / 5.0,          # 20
        0.0,                 # perfectly full
    ],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL
    residual_after = bins - item

    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)
    score = -best - 0.20 * residual_after

    if _TOTAL > 0.0:
        resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
        counts = _SIZE_COUNT[resid_int]
        # Empirical probability of an exact match, a stable O(1) signal.
        prob = counts / _TOTAL
        score = score + 60.0 * prob

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END
