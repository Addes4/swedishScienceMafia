# EVOLVE-BLOCK-START
"""Fillable-residual bin choice driven by the running item-size distribution.

Capacity is 100. Items arrive online. Instead of fixed harmonic target
residuals, we score each candidate bin by how close its post-placement residual
is to a residual that the observed item-size distribution can plausibly fill
exactly: zero (a perfectly sealed bin) plus the empirically frequent item
sizes. A light best-fit tie-break prefers tighter packings, and a mild
fullness bonus consolidates nearly-full bins.
"""
import numpy as np

_CAP = 100.0

# Empirically frequent small item sizes are good targets for a residual:
# a residual equal to a common item size can be closed with a single future item.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0

# Cache the current target set so we only recompute it occasionally.
_CACHED_TARGETS = None
_CACHE_AGE = 0
_CACHE_PERIOD = 25


def _build_targets():
    """Target residuals: 0 plus the most frequent observed item sizes."""
    # 0 is always a target: sealing a bin exactly is ideal.
    targets = [0.0]
    total = _TOTAL
    if total >= 50.0:
        # Common item sizes (that fit) are natural single-item closers.
        counts = _SIZE_COUNT.copy()
        # Probability of a given size as the next item (plus-one smoothing).
        p = (counts + 1.0) / (total + 101.0)
        # Keep sizes whose probability is meaningful; cap count for speed.
        order = np.argsort(-p)
        chosen = []
        for s in order:
            if s == 0:
                continue
            if p[s] < 0.004:
                break
            chosen.append(float(s))
            if len(chosen) >= 60:
                break
        targets.extend(chosen)
    else:
        # Cold start: cover the plausible range of item sizes roughly uniformly.
        targets.extend(np.arange(1.0, 61.0).tolist())
    return np.array(targets, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _CACHED_TARGETS, _CACHE_AGE
    residual_after = bins - item

    _CACHE_AGE += 1
    if _CACHED_TARGETS is None or _CACHE_AGE >= _CACHE_PERIOD:
        _CACHED_TARGETS = _build_targets()
        _CACHE_AGE = 0
    targets = _CACHED_TARGETS

    # Distance from each candidate residual to the nearest fillable target.
    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)

    # Base score: prefer residuals that are exactly fillable.
    score = -best

    # Light best-fit tie-break: among equally fillable residuals, prefer the
    # tighter packing (smaller residual).
    score = score - 0.02 * residual_after

    # Mild fullness bonus: favor consolidating already-nearly-full bins.
    fullness = bins / _CAP
    score = score + 0.5 * np.exp(-0.5 * residual_after) * fullness

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END
