# EVOLVE-BLOCK-START
"""Hybrid: best fit for large items, gap-filling for small ones.

Best-fit is a strong online rule. However, small items can be used to fill
leftover gaps in already-opened bins before opening new ones, and choosing the
tightest fit for them is not always ideal because it may create tiny unusable
residuals. We use best fit for medium/large items and, for small items, prefer
bins that already hold items (partially used), choosing among them the one that
best matches the item, to consolidate leftovers.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    # Unused bins have remaining capacity equal to the full capacity (100).
    unused = bins == 100

    # Best-fit score: prefer tightest fitting bin (smallest residual).
    score = -(bins - item)

    if item <= 30:
        # For small items, deprioritize opening a brand-new bin if there is
        # any partially-filled bin that can take the item. Among partially
        # filled bins, prefer tighter fits too, but boost them above unused.
        partial = ~unused
        if np.any(partial):
            # Large bonus for any partially used bin; keeps small items from
            # opening new bins when there is still room elsewhere.
            score = score + partial * 1000.0
            # Within partially used bins, still pick the tightest fit, which
            # is achieved by the default best-fit term.

    return score
# EVOLVE-BLOCK-END

