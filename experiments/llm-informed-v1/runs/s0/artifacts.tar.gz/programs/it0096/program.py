# EVOLVE-BLOCK-START
"""Best-fit-dominant bin choice with an awkward-residual penalty.

Capacity is 100. Items arrive online. The dominant signal is classic Best-Fit:
prefer the bin with the smallest post-placement residual. On top of that we add
a penalty for leaving a "awkward" small-but-nonzero residual that is unlikely to
be closed by a single future item, and a bonus for exact closure (residual 0).
A mild fullness term encourages consolidating already-full bins.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)

    # Base: best-fit. Smaller residual is better.
    score = -residual_after

    # Exact closure is very valuable: reward residual 0 strongly.
    score = score + 2.0 * np.exp(-residual_after / 2.0)

    # Awkward-residual penalty: a small residual that is below the typical item
    # size wastes capacity because few future items can close it exactly.
    # Scale the penalty to peak for residuals around half the mean item size.
    awkward = residual_after / mean
    penalty = np.exp(-((awkward - 0.4) ** 2) / 0.18)
    score = score - 1.5 * penalty

    # Mild fullness bonus: prefer packing tighter bins further.
    score = score + 0.3 * (bins / _CAP) ** 2

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END
