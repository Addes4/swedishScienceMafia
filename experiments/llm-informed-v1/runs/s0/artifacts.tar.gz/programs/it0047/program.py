# EVOLVE-BLOCK-START
"""Best-fit consolidation with an empirical "closable residual" bonus.

Items arrive online into bins of capacity 100. The primary signal is tight
best-fit (small residual after placement), which consolidates partially filled
bins. On top of that we reward leaving a residual that is likely to be exactly
filled by a later item: the empirical probability that an item of that exact
size will appear. The probability is smoothed with a small prior so the signal
is stable and does not let a single rare size dominate.
"""
import numpy as np

_CAP = 100.0

# Empirical size histogram (index = item size 1..100), plus a small prior.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL
    residual_after = bins - item

    # Primary: tight best-fit (small residual) -> consolidate bins.
    score = -0.55 * residual_after

    # Secondary: reward leaving a residual that is a commonly-seen item size,
    # so a later item of that size can close the bin exactly.
    if _TOTAL > 0.0:
        resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
        # Smoothed empirical probability of that exact size (add-one prior).
        prob = (_SIZE_COUNT[resid_int] + 1.0) / (_TOTAL + 101.0)
        score = score + 500.0 * prob
    else:
        # First item: nothing known yet, pure best-fit.
        score = score

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END
