# EVOLVE-BLOCK-START
"""Best-fit with a squared-fill (harmonic) consolidation objective.

Capacity is 100. Items arrive online. Classic best-fit-decreasing intuition:
filling a bin more fully is good, but a partially-filled bin is only useful if
it can still accept future items. We rank bins to minimize the squared increase
in the "used space" of the chosen bin, which naturally prefers tight fits into
already-open bins (consolidation) while not rewarding leaving unfillable slivers.

Concretely, for each candidate bin with remaining capacity r, placing the item
leaves residual r - item. We score by the harmonic-style increment:
    used_before = 100 - r
    used_after  = 100 - (r - item) = used_before + item
    cost = (used_after)^2 - (used_before)^2 = item^2 + 2*item*used_before
Since item is fixed across bins, cost is monotone increasing in used_before,
i.e. we prefer the *fullest* bin that still fits (best fit). We add a mild
secondary term penalizing leaving a residual that is likely hard to reuse,
estimated online from observed item sizes, to avoid stranding awkward slivers.
"""
import numpy as np

_CAP = 100.0

# Empirical distribution over item sizes (updated online, counts indexed by size).
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL
    residual_after = bins - item
    used_before = _CAP - bins  # space currently used in each shown bin

    # Best-fit: prefer the fullest bin that still fits the item.
    # cost increment = item^2 + 2*item*used_before; minimize => maximize -used_before.
    score = -used_before.astype(np.float64)

    # Secondary: penalize residuals that are unlikely to be filled later.
    # A residual is "good" if it is near 0 (closes the bin) or large enough that
    # a typical future item can still fit. Estimate from observed size histogram.
    if _TOTAL > 0.0:
        probs = _SIZE_COUNT / _TOTAL
        # Probability that a future item is <= residual (can be placed on top):
        cdf = np.cumsum(probs)  # cdf[s] = P(item <= s)
        resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
        fill_prob = cdf[resid_int]
        # Reward residuals with high chance of being usable, and closed bins.
        closed = (resid_int == 0).astype(np.float64)
        score = score + 0.5 * fill_prob + 1.0 * closed

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END
