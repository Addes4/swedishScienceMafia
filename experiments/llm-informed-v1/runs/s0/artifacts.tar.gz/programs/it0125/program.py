# EVOLVE-BLOCK-START
"""Residual fill-probability bin choice.

Capacity is 100. Items arrive online. For each candidate bin we look at the
residual we would leave. A residual r is valuable if a future item is likely to
exactly fill it: the seen item sizes give us an empirical distribution, and we
score p(r) = P(next item size == r summed over the remaining horizon), smoothed
over neighbors. We then add a small best-fit pressure so packed bins are sealed
decisively, plus a guard against leaving tiny nonzero residuals that no seen item
could ever fill.

State kept: histogram of seen sizes, running count, min/max seen size. Cached
fill-probability lookup refreshed periodically.
"""
import numpy as np

_CAP = 100
_N = 101

# Histogram of observed item sizes (index = size), smoothed counts.
_COUNT = np.zeros(_N, dtype=np.float64)
_TOTAL = 0.0
_MIN_SIZE = 101.0

# Lookup: value of a residual -> estimated fill probability density.
_VALUE = np.zeros(_N + 1, dtype=np.float64)
_REFRESH = 16
_STEP = 0


def _rebuild():
    global _VALUE, _STEP
    c = _COUNT.copy()
    c[0] = 0.0
    tot = c.sum()
    if tot <= 0.0:
        _VALUE = np.zeros(_N + 1, dtype=np.float64)
        _STEP = 0
        return
    # Smoothed probability that a future item equals each residual value.
    # Convolve with a small triangular window to tolerate near-misses.
    kern = np.array([1.0, 2.0, 3.0, 2.0, 1.0])
    kern /= kern.sum()
    dens = np.convolve(c, kern, mode="same") / tot
    _VALUE = dens  # index = residual 0..100
    _STEP += 1


def priority(item, bins):
    global _TOTAL, _MIN_SIZE

    if _TOTAL == 0.0 or (_STEP == 0 and _TOTAL > 0.0) or (int(_TOTAL) % _REFRESH == 0):
        _rebuild()

    residual = bins - item  # may be 0..99 range of interest

    # Clip residual to valid lookup range.
    rc = np.clip(residual, 0, _N)

    # Primary: expected fill probability of the chosen residual.
    fill = _VALUE[rc]

    # Tie-break: prefer tighter fits (smaller residual) so bins seal decisively.
    score = fill * 1000.0 - 0.05 * residual

    # Guard: nonzero residual below smallest seen item is unfillable waste.
    if _MIN_SIZE <= _CAP:
        waste = (residual > 0.0) & (residual < _MIN_SIZE)
        score -= 0.5 * waste

    _COUNT[item] += 1.0
    _TOTAL += 1.0
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
