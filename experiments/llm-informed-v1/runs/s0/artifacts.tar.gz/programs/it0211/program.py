# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arriving items are most
likely to fill.

Capacity is 100. Items arrive online. We learn the empirical item-size
distribution online and score each bin by how closable its post-placement
residual is: the probability that a future single item exactly fills it, plus a
smooth near-fill term and a discounted two-item-sum term. A light, size-aware
best-fit term breaks near-ties.

Bins are shown only when the item fits; we do not need the rest of the state,
because the residual-after array already encodes each shown bin's fitness.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_MIN_SIZE = 101.0

_EXACT_SCORE = np.zeros(101, dtype=np.float64)
_NEAR_SCORE = np.zeros(101, dtype=np.float64)
_PAIR_SCORE = np.zeros(101, dtype=np.float64)
_TOPMODE = 0.0
_REFRESH = 16
_N_ITEMS = 1.0

_KERNEL_R = 4
_KR = np.arange(-_KERNEL_R, _KERNEL_R + 1, dtype=np.float64)
_KERNEL = np.exp(-0.5 * (_KR / 1.8) ** 2)


def _rebuild_tables():
    global _EXACT_SCORE, _NEAR_SCORE, _PAIR_SCORE, _TOPMODE
    support = np.zeros(101, dtype=np.float64)
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    if plausible.size:
        w = _SIZE_COUNT[plausible]
        support[plausible] = w / w.sum()
        _TOPMODE = float(plausible[np.argmax(w)])
    else:
        _TOPMODE = 0.0

    # Exact-fill probability: probability a future item equals residual r.
    exact = support.copy()
    mx = exact.max()
    if mx > 0:
        exact = exact / mx
    _EXACT_SCORE = exact

    # Smooth near-fill: residuals a few units from a frequent size still help.
    near = np.convolve(support, _KERNEL, mode="same")[:101]
    if near.size < 101:
        pad = np.zeros(101, dtype=np.float64)
        pad[: near.size] = near
        near = pad
    mn = near.max()
    if mn > 0:
        near = near / mn
    _NEAR_SCORE = near

    # Two-item sum probability (discounted).
    conv = np.convolve(support, support)
    n = min(101, conv.size)
    pair = np.zeros(101, dtype=np.float64)
    pair[:n] = conv[:n]
    mp = pair.max()
    if mp > 0:
        pair = pair / mp
    _PAIR_SCORE = pair


def _interp(table, x):
    """Linear interpolation of a 0..100 table at continuous x."""
    x = np.clip(x, 0.0, _CAP)
    lo = np.floor(x).astype(np.int64)
    hi = np.minimum(lo + 1, 100)
    frac = x - lo
    return table[lo] * (1.0 - frac) + table[hi] * frac


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _MIN_SIZE, _N_ITEMS

    if _TOTAL == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_tables()

    residual_after = bins - item
    mask_fit = residual_after >= 0.0
    # Bins shown always fit, but guard for safety.
    ra = np.where(mask_fit, residual_after, 0.0)

    # Closability score: high when the leftover is likely filled later.
    score = (2.0 * _interp(_EXACT_SCORE, ra)
             + 0.4 * _interp(_NEAR_SCORE, ra)
             + 0.15 * _interp(_PAIR_SCORE, ra))

    # Strong bonus for leaving a residual equal to the most frequent item size.
    if _TOPMODE > 0.0:
        score += 0.5 * np.exp(-0.5 * ((ra - _TOPMODE) / 1.0) ** 2)

    # Light best-fit pressure (prefer snug bins), strength grows with item size.
    size_lean = (item - 50.0) / 50.0
    fit_weight = 0.03 * (1.0 + 0.6 * size_lean)
    score -= fit_weight * ra

    # Penalize tiny nonzero leftovers no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (ra > 0.0) & (ra < _MIN_SIZE)
        score -= 0.05 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
