# EVOLVE-BLOCK-START
"""Adaptive bin choice: leave residuals that a future item is likely to fill.

Capacity is 100. Items arrive online. We keep an empirical histogram of sizes
seen so far and, for each candidate post-placement residual r, estimate the
probability that a future item closes r exactly (single-item fit, Gaussian
smoothed) plus a discounted two-item sum term. Bins whose leftover is likely to
be filled later are preferred; ties are broken toward tighter fits.

Guard 1: a nonzero residual smaller than the smallest size seen so far can never
be filled by any future item (wasted space) -> mild penalty.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" estimate.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_MIN_SIZE = 101.0

# Cached tables, refreshed as the histogram grows.
_PAIR_SCORE = np.zeros(101, dtype=np.float64)
_CLOSE_SCORE = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)

_KERNEL_R = 3
_KR = np.arange(-_KERNEL_R, _KERNEL_R + 1, dtype=np.float64)
_KERNEL = np.exp(-0.5 * (_KR / 1.5) ** 2)


def _rebuild_tables():
    global _PAIR_SCORE, _CLOSE_SCORE
    support = np.zeros(101, dtype=np.float64)
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    if plausible.size:
        w = _SIZE_COUNT[plausible]
        support[plausible] = w / w.sum()

    # Smooth closability: prob a future item equals r (kernel-broadened).
    near = np.convolve(support, _KERNEL, mode="same")[:101]
    if near.size < 101:
        pad = np.zeros(101, dtype=np.float64)
        pad[: near.size] = near
        near = pad
    mn = near.max()
    if mn > 0:
        near = near / mn
    _CLOSE_SCORE = near

    # Two-item sum table (discounted bonus for residuals hittable by a pair).
    conv = np.convolve(support, support)
    n = min(101, conv.size)
    pair = np.zeros(101, dtype=np.float64)
    pair[:n] = conv[:n]
    m = pair.max()
    if m > 0:
        pair = pair / m
    _PAIR_SCORE = pair


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_tables()

    residual_after = bins - item

    # Size-aware best-fit pressure: larger arriving items prefer snug bins.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    base_w = 0.02 + 0.06 * frac
    size_lean = (item - 50.0) / 50.0
    fit_weight = base_w * (1.0 + 0.6 * size_lean)

    score = -fit_weight * residual_after

    # Guard 1: penalize tiny nonzero residuals no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Closability bonus: prefer residuals likely to be filled soon.
    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)
    score += 0.6 * _CLOSE_SCORE[ri]
    score += 0.02 * _PAIR_SCORE[ri]

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
