# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: best-fit primary, empirical-residual tie-break.

Capacity is 100, items arrive online and must be placed immediately. The proven
driver of low bin counts is "best fit": place the item so the leftover is as
small as possible (without wasting space that no future item can use). We make
that the primary signal, and use the learned distribution of item sizes only as
a tie-breaker between residuals that are similarly tight.

Signals, in order of importance:
1. Smallest post-placement residual (primary best-fit pressure).
2. Distance to an empirically attractive residual (a frequent item size or its
   complement), so near-ties prefer leftovers some future item is likely to
   exactly fill.
3. Mild penalty for nonzero residuals smaller than the smallest item seen so far
   (those can never be filled, so the space is wasted).
4. Small bonus for residuals expressible as a sum of two plausible sizes.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached target array, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
# Cached pair-sum set (bools indexed by residual 0..100).
_PAIR_OK = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)


def _rebuild_targets():
    global _TARGETS, _PAIR_OK
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:12] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)          # a leftover equal to this size closes cleanly
        targets.add(_CAP - s)   # complement also leaves a fillable residual
    _TARGETS = np.array(sorted(targets), dtype=np.float64)

    # Pair-fill table: residuals expressible as a sum of two plausible sizes.
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    pair = np.zeros(101, dtype=np.float64)
    if plausible.size:
        support = np.zeros(101, dtype=np.float64)
        support[plausible] = 1.0
        conv = np.convolve(support, support)
        n = min(101, conv.size)
        pair[:n] = (conv[:n] > 0).astype(np.float64)
    _PAIR_OK = pair


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Primary: best-fit -> smaller leftover is better. This is scaled strongly
    # enough to dominate, while the small gains below shape the near-ties.
    fit_weight = 0.05 + 0.15 * ((_N_ITEMS - _TOTAL) / _N_ITEMS if _N_ITEMS > 0.0 else 0.0)
    score = -fit_weight * residual_after

    # Secondary: prefer leftovers close to an attractive empirical residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)
    score -= 0.01 * best

    # Guard 1: penalize nonzero residuals smaller than the smallest seen item.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Guard 2: small bonus if the residual can still be closed by two items.
    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)
    score += 0.015 * _PAIR_OK[ri]

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
