# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by best fit.

Capacity is 100. Items arrive online. We learn which residual values are actually
useful: the most frequent item sizes seen so far are the residuals a future item
is most likely to exactly fill. We score each bin by how close its
post-placement residual is to a small set of such empirically attractive values,
then break near-ties toward tighter fits (smaller residual).

Extra term: use the empirical size histogram to reward residuals that can be
filled by some already-seen item size (cumulative mass up to the residual), plus
a bonus for exact observed sizes, so we keep a healthy stock of "closable" bins.

Guard: a residual that is nonzero but smaller than the smallest item size seen
so far can never be filled by any future item, so it is wasted space.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached target array and cumulative fill mass, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_CUMFILL = np.zeros(101, dtype=np.float64)
_REFRESH = 32


def _rebuild_targets():
    global _TARGETS, _CUMFILL
    counts = _SIZE_COUNT[1:101]
    # Most frequent sizes (ties broken toward larger sizes via ordering).
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:10] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)          # a leftover equal to this size closes cleanly
        targets.add(_CAP - s)   # complement also leaves a fillable residual
    _TARGETS = np.array(sorted(targets), dtype=np.float64)

    # Cumulative probability mass of observed sizes up to each value 0..100.
    tot = counts.sum()
    if tot > 0:
        _CUMFILL = np.cumsum(counts) / tot
    else:
        _CUMFILL = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Future-fit: mass of seen sizes that could land in this residual, plus a
    # bonus if the residual exactly matches a seen size (clean close next time).
    r_idx = np.clip(residual_after.astype(np.int64), 0, 100)
    fit_mass = _CUMFILL[r_idx]
    exact = _SIZE_COUNT[r_idx] > 0

    # Primary: prefer a residual that matches a commonly arriving size.
    # Secondary: reward fillable residuals. Tie-break: modest best-fit pressure.
    score = -best + 0.15 * fit_mass - 0.06 * residual_after
    score += 0.05 * exact

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
