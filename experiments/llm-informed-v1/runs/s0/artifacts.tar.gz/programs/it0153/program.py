# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: close bins when possible, otherwise steer residuals
toward frequently-arriving sizes, with a fill-pressure best-fit tiebreak.

Capacity is 100. Items arrive online. Strategy layers:

1. Exact-fill priority: if placing the item exactly fills a bin (residual == item),
   that bin is strongly preferred. Completing bins is essentially always good: it
   frees a bin and removes leftover capacity that would otherwise be stranded.

2. Target residuals: among non-closing options, steer the post-placement residual
   toward values that a future item is likely to exactly fill -- the sizes that
   arrive most often so far and their complements.

3. Fill-pressure best-fit: as the instance progresses, prefer tighter fits to
   limit the number of bins left open, scaled mildly by progress.

4. Waste guard: a nonzero residual below the smallest item seen can never be
   filled, so it is mildly penalized.

5. Pair guard: a residual expressible as a sum of two plausible sizes gets a
   small bonus.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_PAIR_OK = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0


def _rebuild_targets():
    global _TARGETS, _PAIR_OK
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:12] + 1
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)
        targets.add(_CAP - s)
    _TARGETS = np.array(sorted(targets), dtype=np.float64)

    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    pair = np.zeros(101, dtype=np.float64)
    if plausible.size:
        support = np.zeros(101, dtype=np.float64)
        support[plausible] = 1.0
        conv = np.convolve(support, support)
        n = min(101, conv.size)
        pair[:n] = (conv[:n] > 0).astype(np.float64)
    _PAIR_OK = pair


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    fit_weight = 0.02 + 0.06 * frac

    score = -best - fit_weight * residual_after

    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)
    score += 0.015 * _PAIR_OK[ri]

    # Exact-fill priority: strongly prefer bins this item exactly closes.
    exact = (residual_after == 0.0)
    score += 0.5 * exact

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
