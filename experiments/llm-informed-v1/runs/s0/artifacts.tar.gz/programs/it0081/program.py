# EVOLVE-BLOCK-START
"""Best-fit base ranking with a histogram-based fillable-residual bonus.

Capacity is 100. Items arrive online. The core rule is best-fit: among bins the
item fits in, prefer the one with the smallest remaining capacity (fullest),
which minimizes residual waste. On top of that we add a small bonus for bins
whose post-placement residual equals (or nearly equals) an item size actually
seen so far, since such a fragment is plausibly closeable by a future item of
that size. This keeps the reliable best-fit behaviour while avoiding residues
that no observed item size could ever fill.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_SEEN = np.zeros(101, dtype=bool)  # which sizes have appeared at least once


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    # Base: best-fit -> smaller post-placement residual is better.
    score = -residual_after

    # Bonus: reward residuals that can be closed by an already-seen item size.
    # Build the set of seen sizes as target residuals.
    seen_sizes = np.nonzero(_SEEN)[0].astype(np.float64)
    if seen_sizes.size:
        d = np.abs(residual_after[:, None] - seen_sizes[None, :])
        best = d.min(axis=1)
        score += 0.5 * np.exp(-0.3 * best)

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    _SEEN[item] = True
    return score
# EVOLVE-BLOCK-END
