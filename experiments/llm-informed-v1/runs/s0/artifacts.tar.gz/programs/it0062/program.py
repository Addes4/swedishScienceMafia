# EVOLVE-BLOCK-START
"""State-adaptive residual targeting for online bin packing.

Capacity is 100. Items arrive online and the function must rank bins. The core
idea is to steer partially-filled bins toward residual levels that are
"productive": either near zero (a nearly-closed bin we want to finish) or large
enough to still accept a typical future item. Rather than using a fixed list of
harmonic fractions, we learn the productive residual scale from the running mean
item size and from the observed residual distribution of open bins.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    # Running mean item size, clipped to a sane range for this distribution.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)

    # Productive residual targets: near-zero (finish a bin), and residual levels
    # that still leave room for one or more typical items. These are scale-aware
    # because they are built from the empirical mean.
    small = np.array([0.0, 0.25 * mean, 0.5 * mean], dtype=np.float64)
    tight = np.array([_CAP - 2.0 * mean, _CAP - mean], dtype=np.float64)
    mid = np.array([mean, 2.0 * mean, 0.5 * _CAP], dtype=np.float64)
    targets = np.unique(np.clip(np.concatenate([small, mid, tight]), 0.0, _CAP))

    # Distance to the nearest productive target residual.
    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)

    # Base: prefer tightest fit, then closeness to a productive target.
    score = -0.30 * residual_after - best

    # Exact-closure bonus: strongly reward residuals that match historically
    # common item sizes, since such a bin is likely to be filled exactly soon.
    if _TOTAL > 0.0:
        resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
        counts = _SIZE_COUNT[resid_int]
        total = _TOTAL
        prob = counts / total
        score = score + 8.0 * prob

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END

