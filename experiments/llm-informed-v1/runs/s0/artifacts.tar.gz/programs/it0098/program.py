# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets and a distribution-aware
exact-completion bonus.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic fractions of
capacity), rewarding tighter fits to consolidate partially-filled bins. On top
of this we add a bonus when the post-placement residual matches a common
observed item size, which makes a clean single-item closure of the bin likely.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0

# Cache the common-size vector; rebuilt lazily as counts change.
_LAST_TOTAL = -1.0
_SIZES = np.arange(0, 101, dtype=np.float64)
_COMMON = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _LAST_TOTAL, _COMMON
    residual_after = bins - item

    # Dynamic target residuals from the running mean item size.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Fullness-weighted exact-fit bonus: reward tightly packing near-full bins.
    fullness = (bins / _CAP)
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    # Distribution-aware exact-completion bonus: reward residuals that equal a
    # frequently observed item size (a single later item can seal the bin).
    if _TOTAL != _LAST_TOTAL:
        w = _SIZE_COUNT / max(_TOTAL, 1.0)
        _COMMON = w
        _LAST_TOTAL = _TOTAL
    # residual r can be closed by a single item of size r (r in 1..100)
    close_like = np.zeros_like(residual_after)
    valid = (residual_after >= 1.0) & (residual_after <= 100.0)
    idx = np.clip(residual_after.astype(np.int64), 0, 100)
    close_like[valid] = _COMMON[idx[valid]]
    score = score + 1.5 * close_like

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END
