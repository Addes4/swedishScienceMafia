# EVOLVE-BLOCK-START
"""Frequency-weighted fillability scoring for online bin packing.

Capacity is 100, items arrive online. The central idea: a residual is useful if
some item size that actually tends to arrive can exactly fill it. We maintain the
observed item-size histogram and, for each candidate bin, score the residual
left after placing the item by the total observed frequency of item sizes that
exactly equal that residual (an exact-fit future opportunity), plus a small
best-fit pressure and a guard against unusably tiny residuals.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the fillability score.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached useful arrays, refreshed as the histogram grows.
_WEIGHTS = np.zeros(101, dtype=np.float64)   # frequency per size (normalized)
_REFRESH = 50


def _rebuild_targets():
    global _WEIGHTS
    total = _SIZE_COUNT.sum()
    if total > 0:
        _WEIGHTS = _SIZE_COUNT / total
    else:
        _WEIGHTS = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Residual clamped to integer index range for the fillability lookup.
    idx = np.clip(residual_after, 0, 100).astype(np.int64)
    # Frequency-weighted chance that a future item exactly fills this residual.
    fill = _WEIGHTS[idx]

    # Primary: prefer residuals that some common item size exactly fills.
    # Tie-break: modest best-fit pressure (prefer smaller residual).
    score = fill - 0.05 * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END

