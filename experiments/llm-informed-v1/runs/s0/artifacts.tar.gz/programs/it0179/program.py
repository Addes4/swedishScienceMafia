# EVOLVE-BLOCK-START
"""Adaptive bin choice: best-fit baseline + empirical closability bonuses.

Capacity is 100. Items arrive online. We learn the empirical size distribution
and reward residuals that are likely to be filled later (exactly, in pairs, or
via the complement structure). The core is a clean best-fit (snug) pressure with
a smooth exact-fill bonus driven by the observed item-size histogram.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_MIN_SIZE = 101.0

_PAIR_SCORE = np.zeros(101, dtype=np.float64)
_EXACT_SCORE = np.zeros(101, dtype=np.float64)
_COMPL_SCORE = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)


def _rebuild_tables():
    global _PAIR_SCORE, _EXACT_SCORE, _COMPL_SCORE
    support = np.zeros(101, dtype=np.float64)
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    if plausible.size:
        w = _SIZE_COUNT[plausible]
        support[plausible] = w / w.sum()

    # Two-item sum table over residuals 0..100.
    conv = np.convolve(support, support)
    n = min(101, conv.size)
    pair = np.zeros(101, dtype=np.float64)
    pair[:n] = conv[:n]
    m = pair.max()
    if m > 0:
        pair = pair / m
    _PAIR_SCORE = pair

    # Smooth exact-fill score: empirical probability a future item equals r.
    exact = support.copy()
    mx = exact.max()
    if mx > 0:
        exact = exact / mx
    _EXACT_SCORE = exact

    # Complement score: probability a future item equals 100 - r.
    compl = np.zeros(101, dtype=np.float64)
    for r in range(101):
        c = 100 - r
        if 1 <= c <= 100:
            compl[r] = support[c]
    mx = compl.max()
    if mx > 0:
        compl = compl / mx
    _COMPL_SCORE = compl


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_tables()

    residual_after = bins - item

    # Clean best-fit baseline: prefer the tightest fit (smallest residual),
    # scaled mildly so it does not dominate the closability bonuses.
    score = -0.03 * residual_after

    # Guard 1: tiny nonzero residuals no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Closability bonuses (single-, two-item, and complement).
    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)
    score += 0.6 * _EXACT_SCORE[ri]
    score += 0.05 * _PAIR_SCORE[ri]
    score += 0.1 * _COMPL_SCORE[ri]

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
