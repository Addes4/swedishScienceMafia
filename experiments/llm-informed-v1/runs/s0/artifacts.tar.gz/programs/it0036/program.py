# EVOLVE-BLOCK-START
"""Best-fit consolidation with a smoothed "closable residual" bonus.

Online bin packing decisions here follow a Best-Fit-first principle (prefer the
bin leaving the smallest non-negative residual, which packs tightly), softened
by a bonus when the post-placement residual equals a value a typical upcoming
item could close exactly. The typical item size is estimated online with a
robust smoothed mean rather than a noisy per-size histogram, keeping the signal
stable across the 5,000 arrivals. Bins appear in a fixed order and ties go to
the first, so we keep scores deterministic given the observed history.
"""
import numpy as np

_CAP = 100.0

# Online robust estimate of a "typical" item size, kept in a module-level var.
_TOTAL = 0.0
_MEAN = 40.0          # running mean of item sizes seen so far
_COUNT = 0.0          # number of items seen so far


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _MEAN, _COUNT

    residual_after = bins - item  # new remaining capacity after placing here

    # Primary: best-fit -- strongly prefer the tightest fitting bin to
    # consolidate partially filled bins and avoid opening new ones.
    score = -2.0 * residual_after

    # Secondary: reward residuals that a single typical upcoming item could
    # close exactly. Use the current smoothed mean as the modal estimate; this
    # avoids the noise of a per-size histogram.
    typical = _MEAN
    if typical > 0.0:
        # Distance from residual to the typical size (or to 0 for an exact fill).
        d = np.minimum(np.abs(residual_after - typical), np.abs(residual_after))
        score = score - 1.0 * d

    # Update the smoothed mean with the current item.
    _TOTAL += item
    _COUNT += 1.0
    _MEAN = _TOTAL / _COUNT

    return score
# EVOLVE-BLOCK-END

