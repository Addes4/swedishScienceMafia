# EVOLVE-BLOCK-START
"""Best-fit with harmonic reservation.

Items have mean ~40 out of capacity 100. A simple, robust rule for online
packing is "best fit": put the item into the bin where it leaves the least
residual, consolidating bins. Pure best-fit can be slightly wasteful because it
closes bins at awkward residuals. We refine it with a harmonic reservation idea:
among bins that do NOT leave room for a "small" item afterwards, we prefer the
tightest fit (seal the bin). Among bins that leave a larger residual, we prefer
leaving a residual near a harmonic breakpoint (100/k) so later items of the
matching size class can fill it efficiently.
"""
import numpy as np

_CAP = 100.0
# Harmonic breakpoints / attractive residuals.
_TARGETS = np.array(
    [
        _CAP / 2.0,          # 50
        _CAP / 3.0,          # ~33.3
        (2.0 * _CAP) / 3.0,  # ~66.7
        _CAP / 4.0,          # 25
        (3.0 * _CAP) / 4.0,  # 75
        _CAP / 5.0,          # 20
        0.0,
    ],
    dtype=np.float64,
)


def priority(item, bins):
    residual_after = bins - item  # new remaining capacity after placing here
    # Distance to nearest attractive harmonic residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :]).min(axis=1)
    # Best-fit tie-break: prefer smaller residual_after.
    return -d - 0.15 * residual_after
# EVOLVE-BLOCK-END
