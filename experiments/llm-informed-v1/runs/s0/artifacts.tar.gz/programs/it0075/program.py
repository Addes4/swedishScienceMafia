# EVOLVE-BLOCK-START
"""Target-residual bin choice with data-driven targets.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual. Targets combine
harmonic fractions of capacity with residuals that future items are likely to
fill exactly, derived from the empirical item-size distribution seen so far
(sum/complement of common sizes and the running mean). This keeps the good
consolidation behavior of harmonic targets while adapting to the actual
distribution instead of a fixed guess.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    # Static harmonic targets.
    targets = [_FRACS * _CAP]

    # Dynamic targets: residuals future items can fill exactly.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)
    targets.append(dyn)

    # Data-driven targets from the empirical size distribution: residuals that
    # equal a common item size or the sum/complement of two common sizes.
    if _TOTAL >= 25.0:
        counts = _SIZE_COUNT[1:101]
        total_c = _SIZE_COUNT.sum()
        if total_c > 0.0:
            p = counts / total_c
            # sizes accounting for the top mass
            order = np.argsort(p)[::-1]
            popular = (order[:24] + 1).astype(np.float64)  # sizes 1..100
            sums = popular[:, None] + popular[None, :]
            sums = sums[np.triu_indices(len(popular))]
            emp = np.concatenate([
                popular,
                sums,
                _CAP - popular,
                _CAP - sums,
            ])
            emp = emp[np.isfinite(emp)]
            targets.append(np.clip(emp, 0.0, _CAP))

    targets = np.unique(np.concatenate(targets))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Fullness-weighted exact-fit bonus: strongly reward placing the item into a
    # bin that becomes tightly packed (small residual) when the bin was already
    # mostly full, i.e. consolidating near-full bins.
    fullness = (bins / _CAP)
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END
