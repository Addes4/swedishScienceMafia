# EVOLVE-BLOCK-START
"""Best-fit with quadratic consolidation pressure.

The item distribution has mean ~40, so most bins fill to ~80+. Pure best fit
already ranks well; the main loss comes from leaving small unusable slivers.
We sharpen best fit with a convex penalty on the post-placement residual so
that very tight fits are strongly preferred, while still allowing moderately
full bins to be chosen over opening a fresh bin.
"""
import numpy as np

_CAP = 100.0
_TARGETS = np.array(
    [
        _CAP / 2.0,          # 50
        _CAP / 3.0,          # ~33
        (2.0 * _CAP) / 3.0,  # ~67
        _CAP / 4.0,          # 25
        (3.0 * _CAP) / 4.0,  # 75
        _CAP / 5.0,          # 20
        0.0,                 # perfectly full
    ],
    dtype=np.float64,
)


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    residual_after = bins - item  # remaining capacity after placing here

    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Primary: closeness to an attractive target residual (harmonic structure).
    # Secondary: tight fits (small residual_after) consolidate bins.
    # Tertiary: convex pressure against leaving mid-size slivers, and a soft
    # penalty for opening a fresh empty bin (residual_after == _CAP - item when
    # the bin was empty), encouraging reuse of open bins.
    score = -best - 0.15 * residual_after - 0.004 * (residual_after * residual_after) / _CAP
    # Small explicit bonus for near-perfect closure.
    score += 0.5 * (residual_after < 1.0)
    return score
# EVOLVE-BLOCK-END
