# EVOLVE-BLOCK-START
"""Best-fit variant that avoids leaving small unusable gaps.

Online bin packing with capacity 100 and item sizes from a Weibull-shaped
distribution (mean ~40). Classic best-fit consolidates bins well, but it often
leaves a small awkward residual (e.g. 3-15) that few future items can use,
wasting that bin's capacity. Small items exist, so we don't want to over-penalize
moderate residuals, but we do want to discourage near-zero-but-not-zero gaps.

Scoring (all relative, higher is better):
  - strongly prefer the tightest fit (smallest residual after placement) so
    partially filled bins get consolidated;
  - apply a mild penalty when the residual is small but nonzero (a gap that is
    unlikely to ever be closed), which pushes those items into other bins;
  - everything is continuous so tiny differences still break ties.
"""
import numpy as np

_CAP = 100.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    ra = (bins - item).astype(np.float64)  # residual remaining after placing here

    # Best-fit primary term: smaller residual -> higher score.
    best_fit = -ra

    # Penalty for small but nonzero residuals (awkward gaps). Exact fills (ra==0)
    # are rewarded; residuals >= ~GAP_OK incur no penalty.
    GAP_OK = 18.0
    small = np.clip(ra, 0.0, GAP_OK)
    # Peak penalty at nonzero small residual, zero at ra==0 and ra>=GAP_OK.
    gap_penalty = small * (1.0 - small / GAP_OK) if False else (small * (GAP_OK - small)) / GAP_OK
    # Reward exact fills slightly to encourage finishing bins.
    exact_bonus = np.where(ra < 0.5, 2.0, 0.0)

    return best_fit - 0.8 * gap_penalty + exact_bonus
# EVOLVE-BLOCK-END
