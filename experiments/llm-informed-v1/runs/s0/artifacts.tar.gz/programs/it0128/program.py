# EVOLVE-BLOCK-START
"""Adaptive combo bin choice driven by modal item sizes and fillable residuals.

Capacity is 100. Items arrive online. The most frequent item sizes seen so far
are the residues that a future item is likely to exactly fill. For each candidate
bin we prefer residuals that are (a) exactly one of these frequent sizes, (b) zero,
or (c) reachable by repeatedly subtracting frequent sizes from the capacity
(i.e. values of the form that leave a chain of fillable leftovers). Bins with
residuals that cannot be filled by any seen item are penalized. Ties break toward
tighter fits (smaller residual) to keep bins dense.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_MIN_SIZE = 101.0

# Cached data, refreshed periodically as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_FREQ = np.array([1.0, 1.0], dtype=np.float64)
_REFRESH = 16


def _rebuild_targets():
    global _TARGETS, _FREQ
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:12] + 1
    top = top[counts[top - 1] > 0]
    sizes = [float(s) for s in top]
    freq = {}
    targets = set([0.0, _CAP])
    freq[0.0] = 1.0
    freq[_CAP] = 1.0
    for s in sizes:
        c = float(_SIZE_COUNT[int(s)])
        # residuals that can be sealed by this size
        for d in (s, _CAP - s):
            if 0.0 <= d <= _CAP:
                targets.add(d)
                freq[d] = freq.get(d, 0.0) + c
    # chain-reachable residuals: subtract frequent sizes from capacity repeatedly
    for s in sizes:
        for s2 in sizes:
            d = _CAP - s - s2
            if 0.0 <= d <= _CAP:
                targets.add(d)
                freq[d] = freq.get(d, 0.0) + 0.25 * (
                    float(_SIZE_COUNT[int(s)]) + float(_SIZE_COUNT[int(s2)]))
    tgt = sorted(targets)
    _TARGETS = np.array(tgt, dtype=np.float64)
    _FREQ = np.array([freq[t] for t in tgt], dtype=np.float64)
    # normalize weights
    m = _FREQ.max()
    if m > 0:
        _FREQ = _FREQ / m


def priority(item, bins):
    global _TOTAL, _MIN_SIZE

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Weighted distance to nearest attractive residual: close is good, and
    # matching a high-frequency target is extra good.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    w = np.exp(-d * 0.6) * _FREQ[None, :]
    match = w.max(axis=1)

    # Primary: target-match quality. Tie-break: best fit (smaller residual).
    score = match - 0.02 * residual_after

    # Guard: penalize residuals that no seen item can fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.05 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
