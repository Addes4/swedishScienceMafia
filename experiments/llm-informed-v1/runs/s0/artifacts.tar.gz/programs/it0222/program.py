# EVOLVE-BLOCK-START
"""Adaptive closability bin choice.

Items arrive online; capacity is 100, mean item size ~40, so good packings
mostly pair items whose sizes sum to ~100. We therefore rank a bin by how
likely its post-placement residual r is to be exactly filled by a future item:
score(r) = empirical probability (from the seen-size histogram, Gaussian
smoothed and linearly interpolated) that a future item equals r. Residual 0
(a perfectly full bin) and a residual matching a frequent size get top credit.

A weak size-aware best-fit pressure breaks ties toward snug placements, and a
tiny penalty discourages leaving nonzero residuals below the smallest item seen
(those can never be filled).
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the closability score.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_MIN_SIZE = 101.0

# Cached arrays, refreshed as the histogram grows.
_FILL = np.zeros(101, dtype=np.float64)  # score at integer residual r
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)

_KERNEL_R = 3
_KR = np.arange(-_KERNEL_R, _KERNEL_R + 1, dtype=np.float64)
_KERNEL = np.exp(-0.5 * (_KR / 1.5) ** 2)


def _rebuild_targets():
    global _FILL
    support = np.zeros(101, dtype=np.float64)
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    if plausible.size:
        w = _SIZE_COUNT[plausible]
        support[plausible] = w / w.sum()

    # Smooth the support with a small Gaussian so residuals near a frequent
    # size get partial credit (item sizes are roughly continuous).
    near = np.convolve(support, _KERNEL, mode="same")
    fill = np.zeros(101, dtype=np.float64)
    n = min(101, near.size)
    fill[:n] = near[:n]

    # A perfectly full bin (residual 0) is the best possible outcome.
    fill[0] = max(fill[0], 1.0)

    mx = fill.max()
    if mx > 0:
        fill = fill / mx
    _FILL = fill


def priority(item, bins):
    global _TOTAL, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Dominant term: how close this residual is to a probable future item size,
    # via linear interpolation of the smoothed size histogram.
    r = np.clip(residual_after, 0.0, _CAP)
    lo = np.floor(r).astype(np.int64)
    hi = np.minimum(lo + 1, 100)
    frac = r - lo
    fill_score = _FILL[lo] * (1.0 - frac) + _FILL[hi] * frac

    # Weak size-aware best-fit pressure to break ties toward snug placements.
    prog = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    base_w = 0.005 + 0.02 * prog
    size_lean = (item - 50.0) / 50.0
    fit_weight = base_w * (1.0 + 0.6 * size_lean)

    score = fill_score - fit_weight * residual_after

    # Penalize tiny nonzero residuals no seen item could ever fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.01 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
