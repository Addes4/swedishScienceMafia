# EVOLVE-BLOCK-START
"""Adaptive best-fit bin choice with a learned "closable residual" bonus.

For online bin packing with item sizes bounded by 1 (capacity 100), the
dominant practical rule is Best-Fit: put the item in the bin whose residual
after placement is smallest (tightest fit), which packs tightly and leaves
large empty bins free. We keep that as the primary signal and add a learned
secondary bonus rewarding residuals that a typical future item could close
well, estimated online from the observed size distribution. The estimate is
smoothed toward the theoretical mean (~40) so it stays stable early on.
"""
import numpy as np

_CAP = 100.0
_PRIOR_MEAN = 40.0
_PRIOR_WEIGHT = 25.0  # pseudo-counts for smoothing the size mean

# Online statistics of item sizes.
_SUM = 0.0
_N = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _SUM, _N

    residual_after = bins - item  # new remaining capacity after placing here

    # Primary: tighter fits (smaller residual_after) consolidate bins.
    score = -residual_after

    # Learned estimate of a typical next item size (smoothed).
    mean_item = (_SUM + _PRIOR_WEIGHT * _PRIOR_MEAN) / (_N + _PRIOR_WEIGHT)

    # Bonus: reward residuals close to the typical item size, so an open bin
    # can likely be closed by a future item of a common size.
    score = score - 0.5 * np.abs(residual_after - mean_item)

    _SUM += item
    _N += 1.0
    return score
# EVOLVE-BLOCK-END
