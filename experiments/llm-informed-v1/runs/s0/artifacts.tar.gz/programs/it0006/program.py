# EVOLVE-BLOCK-START
"""Best fit with a mild tie-break that avoids creating tiny unusable gaps."""
import numpy as np

_TOL = 0  # unused; kept for clarity


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary: minimize the residual after placement (best fit).
    Secondary (near-ties): prefer a larger residual so that the smallest leftover gaps
    are not greedily created, which slightly reduces fragmentation on small items.
    """
    residual = bins - item  # remaining capacity after placement, >= 0 for shown bins
    # Best fit: smallest residual is best. Encode as negative residual.
    # Add a tiny tie-break term favoring larger residual (i.e., less-tight placement)
    # only when residuals are extremely close.
    return -(residual.astype(np.float64)) + 1e-6 * residual.astype(np.float64)
# EVOLVE-BLOCK-END
