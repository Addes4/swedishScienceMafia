# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by best fit.

Capacity is 100. Items arrive online. We score each bin by how close its
post-placement residual is to a set of empirically attractive values (frequent
observed item sizes and their complements, plus 0 and 100), then break ties
toward tighter fits scaled by the observed mean item size.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached target array, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_MEAN = 40.0
_REFRESH = 32


def _rebuild_targets():
    global _TARGETS, _MEAN
    counts = _SIZE_COUNT[1:101]
    if _TOTAL > 0.0:
        _MEAN = _SIZE_SUM / _TOTAL
    # Take the most frequent sizes (more of them than before for better coverage).
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:16] + 1
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)
        targets.add(_CAP - s)
    _TARGETS = np.array(sorted(targets), dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Best-fit pressure scaled by the typical item size: prefer tighter fits
    # (smaller residual) but don't over-penalize when residuals are still
    # large relative to what usually arrives.
    bf = 1.0 / max(_MEAN, 1.0)
    score = -best - bf * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.5 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
