# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by
size-aware best fit. Closability credit is evaluated at the fractional
post-placement residual via linear interpolation of the exact/near/pair tables,
so the ranking is smooth rather than snapped to integer grids.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_PAIR_SCORE = np.zeros(101, dtype=np.float64)
_EXACT_SCORE = np.zeros(101, dtype=np.float64)
_NEAR_SCORE = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0

_KERNEL_R = 3
_KR = np.arange(-_KERNEL_R, _KERNEL_R + 1, dtype=np.float64)
_KERNEL = np.exp(-0.5 * (_KR / 1.5) ** 2)


def _lin(table, x):
    """Linear interpolation of a length-101 table at fractional x in [0, 100]."""
    x = np.clip(x, 0.0, _CAP)
    lo = np.floor(x).astype(np.int64)
    hi = np.minimum(lo + 1, 100)
    w = x - lo
    return table[lo] * (1.0 - w) + table[hi] * w


def _rebuild_targets():
    global _TARGETS, _PAIR_SCORE, _EXACT_SCORE, _NEAR_SCORE
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:12] + 1
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)
        targets.add(_CAP - s)
    _TARGETS = np.array(sorted(targets), dtype=np.float64)

    support = np.zeros(101, dtype=np.float64)
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    if plausible.size:
        w = _SIZE_COUNT[plausible]
        support[plausible] = w / w.sum()
    conv = np.convolve(support, support)
    n = min(101, conv.size)
    pair = np.zeros(101, dtype=np.float64)
    pair[:n] = conv[:n]
    m = pair.max()
    if m > 0:
        pair = pair / m
    _PAIR_SCORE = pair

    exact = support.copy()
    mx = exact.max()
    if mx > 0:
        exact = exact / mx
    _EXACT_SCORE = exact

    near = np.convolve(support, _KERNEL, mode="same")
    near = near[:101]
    if near.size < 101:
        pad = np.zeros(101, dtype=np.float64)
        pad[: near.size] = near
        near = pad
    mn = near.max()
    if mn > 0:
        near = near / mn
    _NEAR_SCORE = near


def priority(item, bins):
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    base_w = 0.02 + 0.06 * frac
    size_lean = (item - 50.0) / 50.0
    fit_weight = base_w * (1.0 + 0.6 * size_lean)

    score = -best - fit_weight * residual_after

    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    r = np.clip(residual_after, 0.0, _CAP)
    score += 0.02 * _lin(_PAIR_SCORE, r)
    score += 0.5 * _lin(_EXACT_SCORE, r)
    score += 0.15 * _lin(_NEAR_SCORE, r)

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
