# EVOLVE-BLOCK-START
"""Adaptive combo bin choice driven by empirical closability.

Capacity is 100. Items arrive online. We learn the empirical item-size
distribution from what we have seen, then for each candidate bin we estimate
how likely its post-placement residual is to be *exactly closed* by future
items: either by a single future item (empirical density at r) or by a pair of
future items (pair-sum density). Choosing the bin whose residual is most
closable leaves less stranded space, so fewer bins are opened overall.

Best-fit is used only as a sub-probability tie-breaker, so it can resolve exact
ties without overriding the closability signal.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> empirical size distribution.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_MIN_SIZE = 101.0

# Cached closures, refreshed as the histogram grows.
_PAIR_SCORE = np.zeros(101, dtype=np.float64)
_EXACT_SCORE = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)


def _rebuild_targets():
    global _PAIR_SCORE, _EXACT_SCORE
    support = np.zeros(101, dtype=np.float64)
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    if plausible.size:
        w = _SIZE_COUNT[plausible]
        support[plausible] = w / w.sum()

    # Two-item sum density: probability that a *pair* of future items sums to r.
    conv = np.convolve(support, support)
    pair = np.zeros(101, dtype=np.float64)
    n = min(101, conv.size)
    pair[:n] = conv[:n]
    m = pair.max()
    if m > 0:
        pair = pair / m
    _PAIR_SCORE = pair

    # Single-item exact-fill density.
    exact = support.copy()
    mx = exact.max()
    if mx > 0:
        exact = exact / mx
    _EXACT_SCORE = exact


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item
    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)

    # Primary signal: probability-weighted closability of the residual.
    score = _EXACT_SCORE[ri] + 0.25 * _PAIR_SCORE[ri]

    # Guard: a tiny nonzero residual below the smallest seen item can never be
    # closed, so discourage it (bounded, sub-probability magnitude).
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Best-fit as a small tie-breaker only (always < smallest meaningful gap).
    score -= 1e-4 * residual_after

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END

