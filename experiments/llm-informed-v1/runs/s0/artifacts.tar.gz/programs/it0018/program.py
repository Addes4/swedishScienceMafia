# EVOLVE-BLOCK-START
"""Harmonic-style bin choice blended with best-fit consolidation.

For online bin packing with item sizes bounded by 1 (capacity 100), the
"Harmonic" family classifies items into size classes and packs each class into
reserved bins. A robust, smooth variant: score a bin by how close the residual
after placement is to a "good" residual (a packable remainder), while also
rewarding tighter fits so partially-full bins get consolidated. We combine a
target-proximity term with a best-fit term, giving best-fit the dominant role
(which is empirically strong) and using the harmonic targets only as a gentle
tie-breaker among similarly tight bins.
"""
import numpy as np

_CAP = 100.0

# Harmonic breakpoints scaled to capacity: remainders we like to leave open so
# later items of the "matching" size class can close them well.
_TARGETS = np.array(
    [
        _CAP / 2.0,          # 50
        _CAP / 3.0,          # ~33
        (2.0 * _CAP) / 3.0,  # ~67
        _CAP / 4.0,          # 25
        (3.0 * _CAP) / 4.0,  # 75
        _CAP / 5.0,          # 20
        0.0,                 # perfectly full
    ],
    dtype=np.float64,
)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual_after = bins - item  # new remaining capacity after placing here
    # Distance to the nearest attractive target residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)
    # Primary: tighter fits (smaller residual_after) consolidate bins.
    # Secondary: closeness to an attractive target residual (harmonic structure),
    # used only as a gentle tie-breaker among similarly tight bins.
    return -residual_after * 3.0 - best
# EVOLVE-BLOCK-END


