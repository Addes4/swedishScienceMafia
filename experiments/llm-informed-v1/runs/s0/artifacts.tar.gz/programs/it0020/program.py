# EVOLVE-BLOCK-START
"""Harmonic-style bin choice blended with best-fit consolidation.

Items arrive online into capacity-100 bins. The rule scores each admissible bin
by how close its post-placement residual is to a set of "attractive" residuals
(Harmonic-like structure), plus a best-fit tie-break that consolidates bins.
Additionally, a residual that is small enough to be effectively unusable by any
future item ("sealed") is strongly preferred, since it stops wasting open space.
"""
import numpy as np

_CAP = 100.0

# Harmonic breakpoints scaled to capacity: remainders we like to leave open so
# later items of the "matching" size class can close them well.
_TARGETS = np.array(
    [
        _CAP / 2.0,          # 50
        _CAP / 3.0,          # ~33
        (2.0 * _CAP) / 3.0,  # ~67
        _CAP / 4.0,          # 25
        (3.0 * _CAP) / 4.0,  # 75
        _CAP / 5.0,          # 20
        0.0,                 # perfectly full
    ],
    dtype=np.float64,
)

# Residuals at or below this are assumed unusable by any future item.
_SEAL = 10.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual_after = (bins - item).astype(np.float64)  # new remaining capacity
    # Distance to the nearest attractive target residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)
    # Primary: closeness to an attractive target residual (harmonic structure).
    base = -best - 0.15 * residual_after
    # Strongly reward sealing a bin (residual too small to ever be reused).
    sealed = residual_after <= _SEAL
    # Penalize opening up a previously empty bin a little.
    empty_before = bins >= _CAP - 1e-9
    return base + 3.0 * sealed - 0.05 * empty_before
# EVOLVE-BLOCK-END


