# EVOLVE-BLOCK-START
"""Harmonic-style bin choice blended with best-fit consolidation.

For online bin packing with item sizes bounded by 1 (capacity 100), we score a
bin by how "efficiently fillable" its post-placement residual is: a residual that
is close to a small positive multiple of the typical item size (approx 40) can be
used up by a few future items with little waste. We blend this with a best-fit
term so partially-used bins get consolidated rather than left leaking space.
"""
import numpy as np

_CAP = 100.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual = bins - item  # new remaining capacity after placing here

    # Typical item size ~ 40. Reward residuals that are close to a small positive
    # multiple of the typical size (fillable with little slack).
    t = 40.0
    # Candidate "nice" residuals: multiples of t, plus a closing point near 0.
    targets = np.array([0.0, t, 2.0 * t], dtype=np.float64)
    d = np.abs(residual[:, None] - targets[None, :])
    best = d.min(axis=1)

    # Primary: closeness to a fillable residual. Secondary: tighter fits
    # (smaller residual) consolidate more bins into fewer.
    return -best - 0.2 * residual
# EVOLVE-BLOCK-END
