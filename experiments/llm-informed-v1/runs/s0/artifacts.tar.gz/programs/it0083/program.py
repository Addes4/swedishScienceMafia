# EVOLVE-BLOCK-START
"""Concave best-fit bin choice.

Capacity is 100. Items arrive online and must be placed immediately. Classic
best-fit (smallest residual) is near-optimal for online packing but treats all
waste equally. Here we score each bin by its post-placement residual through a
concave, strictly-decreasing function so that small residuals are strongly
preferred while large residuals (which leave usable room) are penalized only
mildly. This consolidates near-full bins without over-fragmenting.
"""
import numpy as np

_CAP = 100.0

_SIZE_SUM = 0.0
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _SIZE_SUM, _TOTAL
    residual_after = bins - item

    # Concave best-fit: s = -(r ** p) with 0 < p < 1 keeps a strictly decreasing
    # preference for smaller residuals, but flattens the penalty at larger
    # residuals so we do not avoid leaving usable slack.
    r = np.maximum(residual_after, 0.0)
    score = -(r ** 0.5)

    # Small exact-fit bonus: strongly seal bins whose residual becomes 0.
    score += 0.5 * (residual_after == 0)

    _SIZE_SUM += item
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END

