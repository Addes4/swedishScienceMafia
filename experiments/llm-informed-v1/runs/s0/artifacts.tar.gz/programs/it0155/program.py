# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: kernel-smoothed attractive residuals.

Capacity is 100. Items arrive online. We score each bin by how close its
post-placement residual is to a small set of empirically attractive values:
the residuals a future item is most likely to exactly fill. Instead of a hard
min-distance (which is flat inside a basin), we use a Gaussian kernel sum over
the attractive targets, weighted by how frequently the corresponding item size
arrives. This sharpens the guidance toward residuals that real future items
will close.

We also keep a best-fit pressure that grows as the instance fills up, penalize
residuals too small to ever be filled, and reward residuals that can still be
closed by a two-item sum.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached target arrays, refreshed as the histogram grows.
_WEIGHTS = np.zeros(101, dtype=np.float64)  # density over residuals 0..100
_PAIR_OK = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)

# Kernel width for the smoothfalloff around attractive residuals.
_SIGMA = 2.0
_GRID = np.arange(101, dtype=np.float64)[:, None]  # for kernel eval


def _rebuild_targets():
    global _WEIGHTS, _PAIR_OK
    counts = _SIZE_COUNT[1:101]
    total = counts.sum()
    if total <= 0.0:
        _WEIGHTS = np.zeros(101, dtype=np.float64)
        _PAIR_OK = np.zeros(101, dtype=np.float64)
        return

    # Frequency-weighted attractive residuals: a leftover equal to a frequent
    # size (or the complement of a frequent size) closes with a future item.
    freq = counts / total  # probabilities for sizes 1..100

    # support for pair-fill convolution
    support = (counts > 0).astype(np.float64)

    dens = np.zeros(101, dtype=np.float64)
    # exact-fill: residual == size
    dens[1:101] += freq
    # complement: residual == 100 - size (so a size-sized item closes it)
    for s in range(1, 101):
        p = freq[s - 1]
        if p > 0.0:
            dens[100 - s] += p
    # zero residual (fully closed) is always desirable but should not dominate
    dens[0] += 0.5

    # Smooth the density with a Gaussian kernel over the residual axis so that
    # near-misses get partial credit but the peak stays at attractive values.
    k = np.exp(-0.5 * ((_GRID - np.arange(101, dtype=np.float64)[None, :]) / _SIGMA) ** 2)
    k /= k.sum(axis=1, keepdims=True)
    smooth = dens @ k  # weighted sum of kernels centered at each residual
    _WEIGHTS = smooth

    # Pair-fill table: residuals expressible as a sum of two plausible sizes.
    conv = np.convolve(support, support)
    n = min(101, conv.size)
    pair = np.zeros(101, dtype=np.float64)
    pair[:n] = (conv[:n] > 0).astype(np.float64)
    _PAIR_OK = pair


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item
    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)

    # Primary: weighted kernel density at this residual (higher = attractive).
    score = _WEIGHTS[ri]

    # Best-fit pressure grows as the instance fills up: early on, pack freely to
    # keep many bins open; later, prefer tight fits to avoid wasting capacity.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    fit_weight = 0.02 + 0.06 * frac
    score -= fit_weight * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Guard 2: small bonus if the residual can still be closed by two items.
    score += 0.015 * _PAIR_OK[ri]

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
