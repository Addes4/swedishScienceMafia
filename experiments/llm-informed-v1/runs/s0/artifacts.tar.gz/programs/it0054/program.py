# EVOLVE-BLOCK-START
"""Adaptive residual-target bin choice.

Capacity is 100. Items arrive online. Instead of a fixed harmonic target set,
this rule learns from history which residual capacities actually get closed by a
later item. It keeps a count of how often each residual value was *exactly*
matched by a subsequent item (a "closure" event) and a count of how often each
residual value was *left open*. The score for a bin rewards leaving a residual
whose historical closure rate is high, plus a mild best-fit consolidation term.

The closure statistics are updated by remembering, for every open bin, the
residual it currently holds; when an item later fits exactly, that bin's
residual is rewarded as closable.
"""
import numpy as np

_CAP = 100

# residual value -> number of times a bin sat at this residual and was later
# closed exactly by an item of that size.
_CLOSED = np.zeros(101, dtype=np.float64)
# residual value -> number of times a bin was observed at this residual.
_SEEN = np.zeros(101, dtype=np.float64)

# We reconstruct bin residuals ourselves, since `bins` only shows fitting bins.
_OPEN = {}          # bin_index -> residual
_ITER = 0


def priority(item, bins):
    global _ITER

    # --- update closure statistics using our own tracked residuals ---
    # Any open bin whose residual equals `item` gets closed exactly by this item.
    closing = [idx for idx, r in _OPEN.items() if r == item]
    for idx in closing:
        if 0 <= item <= 100:
            _CLOSED[item] += 1.0

    # We can only see fitting bins. Rebuild the full residual picture lazily:
    # bins not shown are those that do not fit (residual < item); keep them.
    # The harness gives us fitting bins in index order but not their indices, so
    # we operate on the shown subset only for scoring, and maintain global state
    # through the mapping below.

    residual_after = bins - item  # numpy array, only fitting bins

    # closure rate estimate for each candidate residual after placement
    resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
    seen = _SEEN[resid_int]
    closed = _CLOSED[resid_int]
    # smoothed closure rate; higher = more likely a future item closes it exactly
    rate = (closed + 0.5) / (seen + 4.0)

    # mild best-fit consolidation term
    score = 40.0 * rate - 0.15 * residual_after

    # --- bookkeeping: score is done; now update our own state ---
    # Record observations of residuals that survive (become the new residual).
    # We record every residual value we will "leave" as an open-bin observation,
    # but only for the chosen placement we can't know here; approximate by
    # counting all candidate residuals as seen once they exist as open bins.
    # Instead: track chosen-bin residual.
    choice = int(np.argmax(score))
    chosen_resid = int(round(residual_after[choice]))
    # increment seen counts for residual values of currently open bins:
    # (we don't know non-fitting bins' indices from here, so we update _OPEN
    #  conservatively using the residuals we can infer)

    # Infer total number of bins = number of items seen so far + 1... but we
    # only reliably know len(bins). Keep _OPEN keyed by residual identity of
    # fitting bins is not possible; so track only the chosen bin's residual.
    # Update seen for all fitting bins' residuals (they are currently open).
    for r in resid_int:
        _SEEN[int(r)] += 1.0

    # The chosen bin's new residual is what it will carry forward.
    if chosen_resid < 0:
        chosen_resid = 0

    # We cannot track non-fitting bins reliably, so we simply record the closure
    # counts via the exact-match test above and leave open-bin identity out.
    _ITER += 1
    return score
# EVOLVE-BLOCK-END
