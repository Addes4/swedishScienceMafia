# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by best fit.

Capacity is 100. Items arrive online. Rather than ranking bins by distance to a
fixed set of harmonic fractions, we learn which residual values are actually
useful: the most frequent item sizes seen so far are the residuals a future item
is most likely to exactly fill. We score each bin by how close its
post-placement residual is to a small set of such empirically attractive values,
then break near-ties toward tighter fits (smaller residual), with the strength of
that best-fit pressure scaled by how full the instance already is.

The tie-break also includes a smoothed "closability value": the probability that
the post-placement residual can be exactly consumed by one future item, or by a
pair of future items. This is computed from a convolution of the observed size
frequency distribution, so near-miss residuals that combine smoothly with common
sizes are favored over residuals that are hard to close.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached target array, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
# Cached closability table (indexed by residual 0..100), refreshed periodically.
_CLOSE_VAL = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)


def _rebuild_targets():
    global _TARGETS, _CLOSE_VAL
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:12] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)          # a leftover equal to this size closes cleanly
        targets.add(_CAP - s)   # complement also leaves a fillable residual
    _TARGETS = np.array(sorted(targets), dtype=np.float64)

    # Closability: probability that residual can be exactly consumed by one item
    # or by a pair of items, using the empirical size distribution.
    freq = _SIZE_COUNT[1:101].copy()
    total = freq.sum()
    if total > 0:
        p = freq / total  # probability mass on each size 1..100
    else:
        p = freq

    # One-item closability: P(item == r).
    one = np.zeros(101, dtype=np.float64)
    one[1:101] = p

    # Pair closability: P(a + b == r) over two independent future items.
    conv = np.convolve(p, p)  # length 199, index k = sum-2
    two = np.zeros(101, dtype=np.float64)
    # conv[k] corresponds to sum (k + 2) for sizes in 1..100
    for r in range(2, 101):
        idx = r - 2
        if 0 <= idx < conv.size:
            two[r] = conv[idx]
    # Residual 100 means empty bin; treat as cleanly closable.
    two[100] = 1.0
    one[100] = 1.0

    _CLOSE_VAL = np.maximum(one, two)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Best-fit pressure grows as the instance fills up: early on, pack freely to
    # keep many bins open; later, prefer tight fits to avoid wasting capacity.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    fit_weight = 0.02 + 0.06 * frac

    # Primary: prefer a residual that matches a commonly arriving size.
    score = -best - fit_weight * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Smoothed closability bonus: reward residuals likely to be exactly closed by
    # one or two future items, at tie-break scale.
    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)
    score += 0.05 * _CLOSE_VAL[ri]

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
