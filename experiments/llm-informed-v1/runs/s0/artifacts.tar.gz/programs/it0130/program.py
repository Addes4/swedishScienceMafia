# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by best fit.

Capacity is 100. Items arrive online. We score each bin by how close its
post-placement residual is to a set of empirically attractive values (frequent
item sizes and their complements), then break near-ties toward residuals that a
typical future item could plausibly fill.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached target array, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_REFRESH = 32


def _rebuild_targets():
    global _TARGETS
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:10] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)          # a leftover equal to this size closes cleanly
        targets.add(_CAP - s)   # complement also leaves a fillable residual
    _TARGETS = np.array(sorted(targets), dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Primary: prefer a residual that matches a commonly arriving size.
    # Tie-break: mild best-fit pressure scaled by mean item size, so
    # near-full bins are preferred only when the residual is plausible.
    mean_size = _SIZE_SUM / _TOTAL if _TOTAL > 0.0 else 40.0
    scale = 0.05 * (40.0 / max(mean_size, 1.0))
    score = -best - scale * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
