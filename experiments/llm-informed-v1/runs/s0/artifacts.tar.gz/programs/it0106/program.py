# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets, fullness-weighted fit
bonus, and an adaptive awkward-residual penalty.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic fractions of
capacity), rewarding tighter fits to consolidate partially-filled bins. An
adaptive penalty discourages leaving tiny residuals that the empirical item
distribution has rarely produced, since those tend to become wasted space.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0

# Smoothed empirical probability that an item of a given integer size appears.
_SIZE_PROB = np.full(101, 1.0 / 100.0, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    # Dynamic target residuals: harmonic fractions of capacity, mixed with
    # multiples/complements of the running mean item size.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Fullness-weighted exact-fit bonus: strongly reward placing the item into a
    # bin that becomes tightly packed (small residual) when the bin was already
    # mostly full, i.e. consolidating near-full bins.
    fullness = (bins / _CAP)
    exact = np.exp(-0.5 * residual_after) * fullness
    score = score + 2.0 * exact

    # Adaptive awkward-residual penalty: for small residuals (<= ~15), penalize
    # values that the empirical distribution rarely produces as item sizes,
    # because such leftovers are unlikely to be exactly filled later.
    r = np.clip(np.round(residual_after).astype(np.int64), 0, 100)
    prob = _SIZE_PROB[r]
    small = residual_after <= 15.0
    # Penalize low-probability small residuals; zero residual (exact fit) is fine.
    awkward = np.where(small & (r > 0), -np.log(np.maximum(prob, 1e-6)), 0.0)
    score = score - 0.35 * awkward

    # Update running statistics.
    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    _SIZE_PROB[:] = (_SIZE_COUNT + 1.0) / (_TOTAL + 101.0)
    return score
# EVOLVE-BLOCK-END


