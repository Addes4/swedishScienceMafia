# EVOLVE-BLOCK-START
"""Harmonic-style bin choice with data-driven best-fit weighting.

Item sizes come from a Weibull-shaped distribution with mean ~40 on a
capacity of 100.  Pure best-fit is strong here, but naive best-fit leaves
many bins with mid-range residuals that later items can only partially fill.
We blend:
  * best-fit (reward small post-placement residual), the dominant term,
  * a soft harmonic target-proximity term using a few canonical residuals,
so that placements leaving "nice" residuals (near 0, 1/2, 1/3, 2/3 of
capacity) are mildly preferred and bins consolidate better.
"""
import numpy as np

_CAP = 100.0

_TARGETS = np.array(
    [
        0.0,                  # perfectly full
        _CAP / 2.0,           # 50
        _CAP / 3.0,           # ~33
        (2.0 * _CAP) / 3.0,   # ~67
        _CAP / 4.0,           # 25
        (3.0 * _CAP) / 4.0,   # 75
        _CAP / 5.0,           # 20
        (2.0 * _CAP) / 5.0,   # 40  (a typical item size)
        (3.0 * _CAP) / 5.0,   # 60
    ],
    dtype=np.float64,
)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual_after = bins - item  # new remaining capacity after placing here
    # Distance to the nearest attractive target residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)
    # Primary: best-fit consolidation, scaled so it dominates.
    score = -1.0 * residual_after
    # Secondary: mild preference for attractive residuals (harmonic structure).
    score -= 0.25 * best
    # Small bonus for sealing a bin almost full, so its residual isn't wasted.
    score += 0.5 * (residual_after < 1.0)
    return score
# EVOLVE-BLOCK-END


