# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by best fit.

Capacity is 100. Items arrive online. We learn which residual values are actually
useful: the most frequent item sizes seen so far are the residuals a future item
is most likely to exactly fill. We score each bin by how close its
post-placement residual is to a small set of such empirically attractive values,
then break near-ties toward tighter fits (smaller residual), with the strength of
that best-fit pressure scaled by how full the instance already is. In the final
stretch, when few items remain, pressure is boosted sharply so bins consolidate.

Extra guard 1: a residual that is nonzero but smaller than the smallest item size
seen so far can never be filled by any future item, so it is wasted space. Such
bins get a mild penalty, applied at tie-break scale so the main target logic
still dominates.

Extra guard 2: a residual that is a plausible two-item sum (pair-fill) is more
valuable than one that is not, because even if no single future item exactly
closes the bin, two items can. We add a small bonus for residuals expressible as
the sum of two frequently-seen sizes.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached target array, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
# Cached pair-sum set (bools indexed by residual 0..100).
_PAIR_OK = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)


def _rebuild_targets():
    global _TARGETS, _PAIR_OK
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:12] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)          # a leftover equal to this size closes cleanly
        targets.add(_CAP - s)   # complement also leaves a fillable residual
    _TARGETS = np.array(sorted(targets), dtype=np.float64)

    # Pair-fill table: residuals expressible as a sum of two plausible sizes.
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    pair = np.zeros(101, dtype=np.float64)
    if plausible.size:
        # convolution of size-support with itself gives 2-item sums
        support = np.zeros(101, dtype=np.float64)
        support[plausible] = 1.0
        conv = np.convolve(support, support)
        n = min(101, conv.size)
        pair[:n] = (conv[:n] > 0).astype(np.float64)
    _PAIR_OK = pair


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Best-fit pressure grows as the instance fills up: early on, pack freely to
    # keep many bins open; later, prefer tight fits to avoid wasting capacity.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    fit_weight = 0.02 + 0.06 * frac

    # Final stretch: when few items remain, boost consolidation pressure so we
    # stop spreading items across many bins and instead tighten existing ones.
    remaining_frac = 1.0 - frac
    if remaining_frac < 0.15:
        fit_weight += 0.15 * (0.15 - remaining_frac) / 0.15

    # Primary: prefer a residual that matches a commonly arriving size.
    score = -best - fit_weight * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Guard 2: small bonus if the residual can still be closed by two items.
    ri = np.clip(residual_after, 0.0, _CAP).astype(np.int64)
    score += 0.015 * _PAIR_OK[ri]

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
