# EVOLVE-BLOCK-START
"""Best-fit with exact-close and productive-gap bonuses.

Capacity is 100, items arrive online. The dominant rule for online bin packing
is best fit: place the item in the bin where the post-placement residual is
smallest. Pure best fit leaves many tiny unfillable fragments, so we slightly
bias the decision toward placements that either close a bin exactly (residual 0)
or leave a residual large enough to be reusable by typical future items. The
threshold adapts to the running mean item size.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)

    # Best fit: strongly prefer the smallest non-negative residual.
    score = -residual_after

    # Exact close bonus: finishing a bin cleanly is very valuable.
    score = score + 12.0 * np.exp(-0.7 * np.abs(residual_after))

    # Productive-gap bonus: leaving a residual at least ~half the mean item
    # size keeps the bin reusable for a typical future item.
    thresh = 0.5 * mean
    big = np.maximum(residual_after - thresh, 0.0)
    score = score + 0.15 * big

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END
