# EVOLVE-BLOCK-START
"""Hybrid: best fit, but for small items prefer the fullest bin to consolidate remnant space."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: smallest remaining capacity after placement => most negative (bins - item).
    best_fit = -(bins - item)

    # For small items, prefer the fullest bin that still fits (most-full) to avoid
    # leaving small unusable remnants. Empty bins are naturally least preferred.
    # Small threshold: items that are at most ~1/4 capacity.
    if item <= 25:
        # Most-full: larger used capacity = smaller remaining capacity = higher score.
        # bins is remaining capacity, so use -bins.
        return -bins
    return best_fit
# EVOLVE-BLOCK-END
