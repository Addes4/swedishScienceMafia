# EVOLVE-BLOCK-START
"""Best-fit with a convex fullness bonus.

Classic Best-Fit (place into the fullest bin that still fits, i.e. minimize the
post-placement residual) is a strong online heuristic for bin packing.  Here we
score every candidate bin by the negative residual after placement, and add a
convex function of the pre-placement fullness so that consolidating nearly-full
bins is rewarded while still strongly preferring tight fits.  No instance
tuning: the coefficients are fixed.
"""
import numpy as np

_CAP = 100.0

_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM

    residual_after = bins - item

    # Core Best-Fit: prefer the smallest post-placement residual.
    score = -residual_after

    # Convex fullness bonus: reward filling bins that are already mostly full so
    # that small fragments get consolidated instead of left stranded.
    fullness = bins / _CAP
    score = score + 15.0 * fullness * fullness

    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END
