# EVOLVE-BLOCK-START
"""Adaptive combo bin choice with interpolated closability scoring.

Capacity is 100. Items arrive online. We maintain an empirical histogram of seen
item sizes and use it to judge how "closeable" a post-placement residual is.

Core idea: the best bin is the one whose leftover can most likely be filled later
by one or two incoming items. We estimate that with:
  - a smoothed, interpolated "single-item fill" curve (continuous, so residuals
    a bit off a frequent size still get graded credit),
  - a two-item pair-sum table,
and we lean ties toward tighter fits, scaled by item size.

Guard 1: residuals that are nonzero but smaller than the smallest seen item can
never be filled -> mild penalty.
Guard 2: empty bins (residual 100) get a persistent slight penalty once past the
early phase so we don't open new bins needlessly, but not so strong that true
slivers still get avoided.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached arrays, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_PAIR_SCORE = np.zeros(101, dtype=np.float64)
_EXACT_SCORE = np.zeros(101, dtype=np.float64)
_FILL_CURVE = np.zeros(101, dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)

# Gaussian-ish kernel used to smooth the size histogram into a continuous curve.
_K = 3
_KS = np.arange(-_K, _K + 1, dtype=np.float64)
_KERNEL = np.exp(-0.5 * (_KS / 1.7) ** 2)


def _rebuild_targets():
    global _TARGETS, _PAIR_SCORE, _EXACT_SCORE, _FILL_CURVE
    counts = _SIZE_COUNT[1:101]
    order = np.argsort(counts, kind="stable")
    top = order[::-1][:12] + 1  # item sizes with the largest counts
    top = top[counts[top - 1] > 0]
    targets = set([0.0, _CAP])
    for s in top:
        s = float(s)
        targets.add(s)          # a leftover equal to this size closes cleanly
        targets.add(_CAP - s)   # complement also leaves a fillable residual
    _TARGETS = np.array(sorted(targets), dtype=np.float64)

    support = np.zeros(101, dtype=np.float64)
    plausible = np.nonzero(_SIZE_COUNT[1:101] > 0)[0] + 1
    if plausible.size:
        w = _SIZE_COUNT[plausible]
        support[plausible] = w / w.sum()

    # Two-item sum table over residuals 0..100.
    conv = np.convolve(support, support)
    n = min(101, conv.size)
    pair = np.zeros(101, dtype=np.float64)
    pair[:n] = conv[:n]
    m = pair.max()
    if m > 0:
        pair = pair / m
    _PAIR_SCORE = pair

    # Exact single-item fill probability, normalized.
    exact = support.copy()
    mx = exact.max()
    if mx > 0:
        exact = exact / mx
    _EXACT_SCORE = exact

    # Continuous fill curve: normalize the smoothed histogram probability mass
    # and scale to the same [0,1] range as the exact score. Full resolution
    # (index = residual 0..100) allows linear interpolation at call time.
    sm = np.convolve(support, _KERNEL, mode="same")
    if sm.size < 101:
        pad = np.zeros(101, dtype=np.float64)
        pad[: sm.size] = sm
        sm = pad
    else:
        sm = sm[:101]
    smn = sm.max()
    if smn > 0:
        sm = sm / smn
    _FILL_CURVE = sm


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual (kept as a coarse structural
    # term for robustness early on).
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Size-aware best-fit pressure: larger arriving items prefer snug bins.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    base_w = 0.02 + 0.06 * frac
    size_lean = (item - 50.0) / 50.0
    fit_weight = base_w * (1.0 + 0.6 * size_lean)

    score = -best - fit_weight * residual_after

    # Guard 1: tiny nonzero residuals no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    # Interpolated closability score: credit a residual by how likely a single
    # future item lands near it (continuous curve) plus two-item closure.
    ri = np.clip(residual_after, 0.0, _CAP)
    lo = np.floor(ri)
    hi = np.minimum(lo + 1.0, _CAP)
    t = ri - lo
    lo_i = lo.astype(np.int64)
    hi_i = hi.astype(np.int64)
    fill = (1.0 - t) * _FILL_CURVE[lo_i] + t * _FILL_CURVE[hi_i]

    score += 0.35 * _PAIR_SCORE[lo_i]
    score += 0.5 * _EXACT_SCORE[lo_i]
    score += 0.45 * fill

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
