# EVOLVE-BLOCK-START
"""Best-fit plus fill-likelihood bin choice.

Capacity is 100. Items arrive online. The primary signal is a tight best fit
(small residual after placement), which consolidates partially-filled bins. A
secondary signal rewards leaving a residual that looks like a real item size
according to an online, smoothed histogram of observed sizes, so a later item
is likely to close the bin exactly. The histogram is normalized by total count
so the signal is a stable probability rather than a noisy peak.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL
    residual_after = bins - item

    # Primary: tight best fit (prefer small nonneg residual, but allow exact fill).
    score = -0.45 * residual_after

    if _TOTAL > 0.0:
        total = _TOTAL
        resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
        # Probability that a random future item exactly matches this residual.
        probs = _SIZE_COUNT[resid_int] / total
        score = score + 8.0 * probs

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END


