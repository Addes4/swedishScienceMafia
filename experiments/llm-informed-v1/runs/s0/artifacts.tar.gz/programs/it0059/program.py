# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets plus exact-closure bonus.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic fractions of
capacity mixed with multiples/complements of the running mean item size), and
we add a decisive bonus when the post-placement residual equals an item size
that has frequently occurred so far (so a future item can close the bin
exactly). A mild residual penalty keeps consolidation toward full bins.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    # Dynamic target residuals: harmonic fractions of capacity, mixed with
    # multiples/complements of the running mean item size.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.20 * residual_after

    # Exact-closure bonus: reward a residual that equals a frequently seen
    # item size, since such a bin can later be closed with zero waste.
    resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
    counts = _SIZE_COUNT[resid_int]
    exact = np.abs(residual_after - resid_int) < 0.5
    mx = _SIZE_COUNT.max()
    if mx > 0.0:
        freq = counts / mx
    else:
        freq = np.zeros_like(counts)
    score = score + 12.0 * freq * exact

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END
