# EVOLVE-BLOCK-START
"""Target-residual bin choice with empirical residual-value scoring.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to attractive target residuals (harmonic fractions of
capacity plus multiples/complements of the running mean item size), and we
discount the value of a leftover residual by the empirical chance that some
future item could still use it. This discourages leaving awkward residuals
that fragment space, favoring bins we can practically close.
"""
import numpy as np

_CAP = 100.0

_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.20 * residual_after

    if _TOTAL > 0.0:
        resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
        # Tail probability: fraction of observed items strictly larger than resid,
        # i.e. how "useless" the leftover residual is (can't be closed by such sizes).
        total = _SIZE_COUNT.sum()
        greater = 0.0
        if total > 0.0:
            # count of items > resid_int
            cum = np.cumsum(_SIZE_COUNT)
            greater = (total - cum[resid_int]) / total
            # zero residual is perfect: fully closed, no waste
            zero_mask = (resid_int == 0)
            score = score + 4.0 * greater
            score = np.where(zero_mask, score + 8.0, score)

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END

