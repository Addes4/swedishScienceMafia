# EVOLVE-BLOCK-START
"""Kernel-smoothed future-fit bin choice.

Capacity is 100. Items arrive online. The useful property of a bin's residual is
how likely a future item is to *fit it well*. Instead of a hard "distance to a
fixed set of attractive residuals" with periodic rebuilds, we build a smooth
kernel density estimate of the item-size distribution seen so far and score each
candidate residual by that density. A residual that is close to a frequently
arriving size is likely to be closed cleanly by a future item; a residual that is
close to a frequent complement (100 - s) is likely to complete a two-item bin.

The kernel is applied both to the residual itself and to (100 - residual), so
both "residual equals a common size" and "residual equals a common complement"
receive credit. A mild best-fit pressure (prefer smaller result residual) breaks
ties toward tighter packs, and a small penalty discourages nonzero residuals
below the smallest size seen (unfillable waste).
"""
import numpy as np

_CAP = 100.0
_SIG = 3.0  # kernel bandwidth in size units

# Histogram of observed item sizes, with light Laplace smoothing.
_SIZE_COUNT = np.ones(101, dtype=np.float64)
_TOTAL = 0.0
_MIN_SIZE = 101.0

# Cache the smoothed density over all integer residuals 0..100.
_DENSITY = np.zeros(101, dtype=np.float64)
_REFRESH = 16


def _rebuild_density():
    global _DENSITY
    counts = _SIZE_COUNT[1:101]
    sizes = np.arange(1, 101, dtype=np.float64)
    total = counts.sum()
    probs = counts / total

    r = np.arange(0, 101, dtype=np.float64)
    # Kernel density of sizes at each residual r.
    dz = (r[:, None] - sizes[None, :]) / _SIG
    defn = np.exp(-0.5 * dz * dz)
    dens_size = defn @ probs
    # Kernel density of complements (100 - size) at each residual r.
    dz2 = (r[:, None] - (_CAP - sizes[None, :])) / _SIG
    dens_comp = np.exp(-0.5 * dz2 * dz2) @ probs

    _DENSITY = np.maximum(dens_size, dens_comp)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _MIN_SIZE

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_density()

    residual_after = bins - item

    # Clip to the valid lookup range; residual is always within [0, 99].
    idx = np.clip(residual_after.astype(np.int64), 0, 100)
    fit_value = _DENSITY[idx]

    # Primary: smooth expected-future-fit value. Tie-break: mild best fit.
    score = fit_value - 0.02 * residual_after

    # Guard: tiny nonzero residuals no seen item can fill are wasted space.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
