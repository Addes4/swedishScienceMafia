# EVOLVE-BLOCK-START
"""Best-fit bin choice with a residual-quality tie-break.

Best-fit (choose the bin with the smallest remaining capacity that still fits
the item) is a very strong online rule for item sizes with mean ~40 and
capacity 100. To squeeze out a bit more, we add a small secondary term that
prefers residuals which are "easy" for the future: values very close to 0
(nearly closed bins) or very close to the full capacity (fresh bins that keep
optionality), while mildly discouraging the awkward mid-range residuals where
future items tend neither to fit nor to be separated cleanly.

The primary term dominates: it is the post-placement residual, scaled so that
one unit of capacity difference outweighs the whole tie-break range.
"""
import numpy as np

_CAP = 100.0

# Smooth "awkwardness" of a residual in [0, 100]: peaks near the middle where
# a leftover is least likely to be tightly filled by a future item.
_MID = _CAP / 2.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual_after = bins - item  # new remaining capacity after placing here

    # Primary: best fit -> smallest residual after placement is best.
    # Tie-break: mild preference for residuals near 0 or near full capacity.
    # awkward = distance from midpoint, so smaller awkward is better.
    awkward = np.abs(residual_after - _MID)

    # Scale primary so the tie-break can never override it.
    return -residual_after * 100.0 - 0.01 * awkward
# EVOLVE-BLOCK-END


