# EVOLVE-BLOCK-START
"""Harmonic-style bin choice blended with best-fit consolidation.

For online bin packing with item sizes bounded by 1 (capacity 100), we score a
bin by how close the residual after placement is to an attractive target
residual, reward tighter fits to consolidate, and give a fixed bonus to
residuals that correspond to small common item sizes so an open bin can later
be closed exactly by a single matching item.
"""
import numpy as np

_CAP = 100.0

# Harmonic breakpoints scaled to capacity: remainders we like to leave open so
# later items of the "matching" size class can close them well.
_TARGETS = np.array(
    [
        _CAP / 2.0,          # 50
        _CAP / 3.0,          # ~33
        (2.0 * _CAP) / 3.0,  # ~67
        _CAP / 4.0,          # 25
        (3.0 * _CAP) / 4.0,  # 75
        _CAP / 5.0,          # 20
        0.0,                 # perfectly full
    ],
    dtype=np.float64,
)

# Fixed bonus for residuals equal to small common item sizes (a single later
# item can close the bin exactly). Indexed by integer residual 0..100.
_FILL_BONUS = np.zeros(101, dtype=np.float64)
for _s in range(1, 51):
    _FILL_BONUS[_s] = 1.0 / _s  # favor small residuals slightly more


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual_after = bins - item  # new remaining capacity after placing here
    # Distance to the nearest attractive target residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)
    # Primary: closeness to an attractive target residual (harmonic structure).
    # Secondary: tighter fits consolidate bins.
    score = -best - 0.2 * residual_after

    # Fixed fill bonus: reward residuals a single later item could close exactly.
    resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
    score = score + 6.0 * _FILL_BONUS[resid_int]
    return score
# EVOLVE-BLOCK-END

