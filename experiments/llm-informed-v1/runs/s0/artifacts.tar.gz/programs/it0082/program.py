# EVOLVE-BLOCK-START
"""Target-residual bin choice with harmonic targets and a narrow seal bonus.

Capacity is 100. Items arrive online. We rank bins by how close the residual
after placement is to an attractive target residual (harmonic fractions of
capacity), rewarding tighter fits to consolidate partially-filled bins. A
narrow Gaussian "seal" bonus centered at residual 0, scaled by how full the bin
already is, strongly prefers cleanly closing nearly-full bins without
disturbing the harmonic-target base ranking.
"""
import numpy as np

_CAP = 100.0

# Static harmonic fractions of capacity that tend to be productive.
_FRACS = np.array(
    [0.0, 0.2, 0.25, 1.0 / 3.0, 0.4, 0.5, 0.6, 2.0 / 3.0, 0.75, 0.8, 1.0],
    dtype=np.float64,
)

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    # Dynamic target residuals: harmonic fractions of capacity, mixed with
    # multiples/complements of the running mean item size.
    mean = (_SIZE_SUM / _TOTAL) if _TOTAL > 0.0 else 40.0
    mean = min(max(mean, 20.0), 60.0)
    mult = np.arange(1.0, 4.0) * mean
    comp = _CAP - mult
    dyn = np.clip(np.concatenate([mult, comp]), 0.0, _CAP)

    targets = np.unique(np.concatenate([_FRACS * _CAP, dyn]))

    d = np.abs(residual_after[:, None] - targets[None, :])
    best = d.min(axis=1)
    score = -best - 0.10 * residual_after

    # Narrow seal bonus: strongly reward closing a bin (residual near 0),
    # weighted by how full the bin already was. The tight Gaussian only fires
    # for genuine near-closes, so it consolidates near-full bins without
    # perturbing the broader target-based ranking.
    fullness = bins / _CAP
    seal = np.exp(-0.5 * (residual_after / 5.0) ** 2) * fullness
    score = score + 2.5 * seal

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return score
# EVOLVE-BLOCK-END


