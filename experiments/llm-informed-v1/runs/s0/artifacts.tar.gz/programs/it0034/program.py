# EVOLVE-BLOCK-START
"""Harmonic-style bin choice blended with best-fit consolidation.

For online bin packing with item sizes bounded by 1 (capacity 100), the
"Harmonic" family classifies items into size classes and packs each class into
reserved bins. A robust, smooth variant: score a bin by how close the residual
after placement is to a "good" residual (a packable remainder), while also
rewarding tighter fits so partially-full bins get consolidated. We combine a
target-proximity term with a best-fit term, plus an online-learned bonus for
residuals that match commonly seen item sizes.
"""
import numpy as np

_CAP = 100.0

# Harmonic breakpoints scaled to capacity: remainders we like to leave open so
# later items of the "matching" size class can close them well.
_TARGETS = np.array(
    [
        _CAP / 2.0,          # 50
        _CAP / 3.0,          # ~33
        (2.0 * _CAP) / 3.0,  # ~67
        _CAP / 4.0,          # 25
        (3.0 * _CAP) / 4.0,  # 75
        _CAP / 5.0,          # 20
        0.0,                 # perfectly full
    ],
    dtype=np.float64,
)

# Online histogram of item sizes (1..100), used to reward residuals that a
# typical future item could close exactly.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL
    residual_after = bins - item  # new remaining capacity after placing here
    # Distance to the nearest attractive target residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)
    # Primary: closeness to an attractive target residual (harmonic structure).
    # Secondary: tighter fits (smaller residual_after) consolidate bins.
    score = -best - 0.15 * residual_after

    # Online-learned bonus: reward residuals matching a commonly observed size,
    # since a later item of that size can close the bin exactly.
    if _TOTAL > 0.0:
        resid_int = np.clip(np.rint(residual_after).astype(np.int64), 0, 100)
        freq = _SIZE_COUNT[resid_int] / _TOTAL
        score = score + 8.0 * freq

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END
