# EVOLVE-BLOCK-START
"""Adaptive combo bin choice: leave residuals that arrive often, break ties by best fit.

Capacity is 100. Items arrive online. Rather than ranking bins by distance to a
fixed set of harmonic fractions, we learn which residual values are actually
useful: the most frequent item sizes seen so far are the residuals a future item
is most likely to exactly fill. We score each bin by how close its
post-placement residual is to a set of such empirically attractive values,
then break near-ties toward tighter fits (smaller residual), with the strength of
that best-fit pressure scaled by how full the instance already is.

Extra guard: a residual that is nonzero but smaller than the smallest item size
seen so far can never be filled by any future item, so it is wasted space. Such
bins get a mild penalty, applied at tie-break scale so the main target logic
still dominates.
"""
import numpy as np

_CAP = 100.0

# Histogram of observed item sizes -> drives the "good residual" targets.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0
_MIN_SIZE = 101.0

# Cached target array, refreshed as the histogram grows.
_TARGETS = np.array([0.0, _CAP], dtype=np.float64)
_REFRESH = 16
_N_ITEMS = 0.0  # number of items in the instance (known on first call)


def _rebuild_targets():
    global _TARGETS
    counts = _SIZE_COUNT[1:101]
    total = counts.sum()
    targets = set([0.0, _CAP])
    if total > 0:
        # Include any size that has appeared often enough to matter, rather than
        # an arbitrarily truncated top-K. Threshold scales with the sample size.
        thresh = max(1.0, total * 0.002)
        sizes = np.nonzero(counts >= thresh)[0] + 1
        for s in sizes:
            s = float(s)
            targets.add(s)          # a leftover equal to this size closes cleanly
            targets.add(_CAP - s)   # complement also leaves a fillable residual
    _TARGETS = np.array(sorted(targets), dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM, _MIN_SIZE, _N_ITEMS

    if _N_ITEMS == 0.0:
        _N_ITEMS = float(len(bins))

    if _TOTAL == 0.0 or (_TOTAL % _REFRESH == 0.0):
        _rebuild_targets()

    residual_after = bins - item

    # Distance to the nearest attractive residual.
    d = np.abs(residual_after[:, None] - _TARGETS[None, :])
    best = d.min(axis=1)

    # Best-fit pressure grows as the instance fills up: early on, pack freely to
    # keep many bins open; later, prefer tight fits to avoid wasting capacity.
    frac = _TOTAL / _N_ITEMS if _N_ITEMS > 0.0 else 0.0
    fit_weight = 0.02 + 0.06 * frac

    # Primary: prefer a residual that matches a commonly arriving size.
    score = -best - fit_weight * residual_after

    # Guard: penalize tiny nonzero residuals that no seen item could fill.
    if _MIN_SIZE <= _CAP:
        waste = (residual_after > 0.0) & (residual_after < _MIN_SIZE)
        score -= 0.02 * waste

    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    if item < _MIN_SIZE:
        _MIN_SIZE = float(item)
    return score
# EVOLVE-BLOCK-END
