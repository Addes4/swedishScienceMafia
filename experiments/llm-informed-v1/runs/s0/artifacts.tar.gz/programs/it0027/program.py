# EVOLVE-BLOCK-START
"""Online bin packing via expected-waste minimization with online size model.

We track an online histogram of item sizes. For each candidate bin we compute
the post-placement residual r and estimate the expected unusable slack: the
part of r that cannot be eliminated by any single future item of typical size,
i.e. the expected distance from r down to the largest item size that fits.
Smaller expected waste -> better. A mild best-fit tie-break consolidates bins.
"""
import numpy as np

_CAP = 100.0

# Module-level online state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)  # counts of observed items sizes 1..100
_n_seen = 0


def _update_hist(item):
    global _n_seen
    si = int(item)
    if 1 <= si <= 100:
        _hist[si] += 1.0
    _n_seen += 1


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    _update_hist(item)

    residual_after = bins - item  # new remaining capacity after placing here

    # Empirical size pmf (smoothed). Fall back to a broad prior until enough data.
    total = _hist.sum()
    if total < 30.0:
        pmf = np.ones(101, dtype=np.float64)
        pmf[0] = 0.0
        pmf /= pmf.sum()
    else:
        pmf = _hist / total
    sizes = np.arange(101, dtype=np.float64)

    # For each candidate residual r, expected waste = E[ r mod s ] over fitting
    # item sizes s <= r, i.e. leftover that a single item leaves behind. We only
    # need it for the distinct residuals present, so vectorize over bins.
    # Compute per-bin expected waste directly.
    r = residual_after
    n = r.shape[0]
    waste = np.zeros(n, dtype=np.float64)
    for i in range(n):
        ri = r[i]
        if ri <= 0.0:
            waste[i] = 0.0 if ri == 0.0 else 1e6
            continue
        cap = int(ri)
        if cap > 100:
            cap = 100
        if cap < 1:
            waste[i] = ri  # tiny residual nothing fits
            continue
        w = pmf[1 : cap + 1]
        s = sizes[1 : cap + 1]
        tot = w.sum()
        if tot <= 0.0:
            waste[i] = ri
        else:
            waste[i] = float(np.dot(w, ri - s)) / tot

    # Primary: minimize expected single-item waste. Secondary: tighter fit.
    return -waste - 0.02 * residual_after
# EVOLVE-BLOCK-END
