# EVOLVE-BLOCK-START
"""Distribution-aware best-fit bin choice.

The instance items are i.i.d. from a fixed Weibull-shaped distribution (mean
~40, capacity 100). A good online rule is: place the item so that the leftover
residual is an amount that a *typical future item* can fill almost exactly.

We estimate the item-size distribution online with a decaying histogram over
observed sizes, then for each candidate bin compute
  - fit:      probability mass of items whose size equals the residual (near fill)
  - waste:    small residual is fine (the bin is nearly sealed), large residual
              above the smallest sizes is wasteful.
We rank primarily by how "fillable" the residual is, and break ties toward the
tightest fit (smallest residual) to consolidate bins.
"""
import numpy as np

_CAP = 100
_MAX = 101  # sizes 1..100

# Module-level state (fresh per instance process).
_hist = np.ones(_MAX, dtype=np.float64)   # Laplace-smoothed size histogram
_seen = 0.0
_DECAY = 0.999  # gentle forgetting so recent sizes matter a bit more


def _update(item):
    global _seen
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    _update(int(item))

    residual_after = bins - item  # new remaining capacity after placing here

    # Empirical probability that a future item exactly fills the residual.
    # residual_after can be 0 (perfect) up to 100.
    r = np.clip(residual_after, 0, _MAX - 1).astype(np.int64)
    weights = _hist / _hist.sum()
    fill_prob = weights[r]

    # Probability that a future item fits into the residual at all (residual>=1).
    # Approx: sum of weight for sizes <= residual.
    cdf = np.cumsum(weights)
    fit_prob = np.where(r <= 0, 1.0, cdf[np.clip(r - 1, 0, _MAX - 1)])

    # Primary: reward near-exact future fills. Secondary: reward residuals that
    # still admit further items, and prefer tighter fits to consolidate.
    score = (
        2.0 * fill_prob
        + 0.5 * fit_prob
        - 0.010 * residual_after
    )
    return score
# EVOLVE-BLOCK-END
