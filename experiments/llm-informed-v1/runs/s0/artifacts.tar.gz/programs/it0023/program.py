# EVOLVE-BLOCK-START
"""Bin choice balancing waste-minimization and best-fit consolidation.

Items have mean ~40 on capacity 100, so bins are typically completed by
combining a few medium items. The key inefficiency is residual capacity that
can never be filled. We estimate the "typical large item" size online and
score each candidate bin by the residual waste modulo that size, plus a small
best-fit term to consolidate partially-full bins.
"""
import numpy as np

_CAP = 100.0

_state = {
    "n_seen": 0,
    "sum": 0.0,
    "sumsq": 0.0,
    "top": 0.0,  # running estimate of a large item size
}


def priority(item, bins):
    """Return a priority for every bin; item goes to highest score."""
    s = _state
    s["n_seen"] += 1
    s["sum"] += item
    s["sumsq"] += item * item
    n = s["n_seen"]
    mean = s["sum"] / n
    var = max(s["sumsq"] / n - mean * mean, 1.0)
    std = var ** 0.5
    # Typical "large" item size: upper part of the distribution.
    large = mean + 0.6 * std
    if large < 10.0:
        large = 10.0
    s["top"] = large

    residual_after = bins - item  # remaining capacity after placing here

    # Waste: leftover residual capacity that no single large item can use.
    # r - floor(r / large) * large is small when r is close to a multiple of
    # the typical item size (i.e., the bin can be neatly filled later).
    q = np.floor(residual_after / large)
    waste = residual_after - q * large

    # Reward small waste; secondary best-fit term consolidates bins.
    return -waste - 0.10 * residual_after
# EVOLVE-BLOCK-END
