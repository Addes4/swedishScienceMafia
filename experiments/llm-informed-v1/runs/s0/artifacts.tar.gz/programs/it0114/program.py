# EVOLVE-BLOCK-START
"""Best-fit with clean-closure tie-break.

Items arrive online. For each item we strongly prefer the bin that leaves the
smallest residual after placement (best fit), which is known to be a strong
online heuristic. As a soft tie-break among placements with similar residuals
we slightly favor residuals that are "awkward-free": we reward residuals just
below a likely future item size so the bin can be closed cleanly, and penalize
tiny non-zero residuals that are unlikely ever to be filled.
"""
import numpy as np

_CAP = 100.0

_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SIZE_SUM = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL, _SIZE_SUM
    residual_after = bins - item

    # Dominant term: best fit (smallest residual). The 1e-4 scale makes it the
    # primary criterion; the additive tie-break below only decides near-equal cases.
    score = -residual_after

    # Soft tie-break: reward residuals that are exactly zero (perfect closure)
    # and penalize tiny non-zero residuals that are hard to fill later.
    score = score - 0.5 * np.exp(-3.0 * residual_after)

    # Record this item for potential future statistics.
    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0
    _SIZE_SUM += item
    return np.asarray(score, dtype=np.float64)
# EVOLVE-BLOCK-END
