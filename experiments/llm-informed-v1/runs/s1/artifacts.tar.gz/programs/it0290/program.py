# EVOLVE-BLOCK-START
"""Best-fit core with an adaptive empirical seal-probability bonus.

Pure best fit (score = -residual) is the proven strongest baseline here.  This
rule keeps it dominant and adds ONE adaptive term: the empirical probability
that the candidate residual is exactly consumable by a future item, read from
the histogram of items seen so far.  Bins whose residual matches a commonly
occurring item size get a bonus, encouraging near-seal placements; everything
else falls back to plain best fit.  No fixed magic regions.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins
    total = max(_seen - 1, 1)

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)

    # Empirical probability that a future item exactly equals this residual.
    fill_mass = _hist[idx].astype(np.float64) / total

    # Dominant best-fit core.
    score = -r

    # Perfect seal (residual already 0) is always good.
    score += (residual == 0).astype(np.float64) * 10.0

    # Adaptive seal bonus: reward residuals matching common item sizes so the
    # bin is likely to be exactly closed by a single future item.
    score += fill_mass * 50.0

    return score
# EVOLVE-BLOCK-END

