# EVOLVE-BLOCK-START
"""Best fit with a mild fullness penalty to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item
    # Best fit: tighter leftover is better (negative leftover).
    score = -rem.astype(np.float64)
    # Mild penalty for leaving a small but nonzero leftover (hard-to-fill bin),
    # which encourages wrapping items tightly and avoids stranding tiny gaps.
    score -= 0.05 * np.where((rem > 0) & (rem < item), rem, 0.0)
    return score
# EVOLVE-BLOCK-END

