# EVOLVE-BLOCK-START
"""Best fit with an adaptive reserve floor.

Classic best fit tends to strand tiny residuals that can never be reused.
Here we compute an empirical "reserve" floor (the median size seen so far) and
give a strong bonus to placements whose residual is either an exact fill or
still large enough to plausibly host a typical future item.  Best fit remains
dominant within either class, so dense packing is preserved while unusable
scraps are avoided.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    # Reserve floor: median observed size, a robust estimate of a "typical"
    # future item that a residual should be able to host.
    reserve = _quantile(0.50)

    score = -residual.astype(np.float64)

    exact = (residual == 0)
    viable = (residual >= reserve) & (residual > 0)

    # Prefer exact fills strongly.
    score += exact.astype(np.float64) * 200.0
    # Then prefer residuals that stay usable for a typical future item.
    score += viable.astype(np.float64) * 100.0

    return score
# EVOLVE-BLOCK-END

