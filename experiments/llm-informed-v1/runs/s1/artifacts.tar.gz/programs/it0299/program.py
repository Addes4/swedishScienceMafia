# EVOLVE-BLOCK-START
"""Best-fit core with a principled exact-seal refinement.

Pure best fit is very strong on Weibull(mean~40) items. Its main regret is
occasionally stranding a small unusable residual. The cleanest fix that does
not perturb the core is:

  score = -residual                      (dominant best-fit term)
          + alpha * seal_prob             (likelihood resulting residual is exactly
                                           fillable by a future item)
          - beta  * unusable_penalty      (resulting residual below the smallest item
                                           seen so far is permanently wasted)

Scales are chosen so that among residuals differing by 1 the best-fit term wins,
but among near-ties (same residual band) the seal/viability terms decide.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_min_item = 101


def _init(n):
    global _n_items, _seen, _hist, _min_item
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.float64)
    _min_item = 101


def priority(item, bins):
    global _seen, _min_item

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1.0
    if item < _min_item:
        _min_item = item

    residual = bins - item  # >= 0 for shown bins
    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)

    total = max(_seen - 1, 1)

    # Probability a future item exactly fills this resulting residual.
    seal_prob = _hist[idx] / total

    # Dominant best-fit term. Scaled so a 1-unit residual difference dominates
    # any of the refinement terms below (max refinement ~ a few units).
    score = -r * 10.0

    # Reward residuals exactly fillable by a future item (seal setup).
    score += seal_prob * 12.0

    # Perfect seal right now: residual 0.
    score += (residual == 0).astype(np.float64) * 6.0

    # Penalize residuals that are permanently unusable (smaller than smallest
    # item seen so far and not zero).
    unusable = ((residual > 0) & (residual < _min_item)).astype(np.float64)
    score -= unusable * 5.0

    return score
# EVOLVE-BLOCK-END
