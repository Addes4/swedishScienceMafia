# EVOLVE-BLOCK-START
"""Best fit with empirical-histogram residual shaping.

Best fit is near-optimal online; its weakness is stranding residuals that no
plausibly small future item can use. We keep the full packing state and an
empirical histogram of item sizes seen so far, and lightly shape the ranking
so that placements leaving dead residuals (below the low end of the size
distribution) or landing in the "common size" band (likely to cause future
stranding) are mildly discouraged, while exact fills are rewarded.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1

    q10 = _quantile(0.10)
    q50 = _quantile(0.50)

    residual = bins - item  # >= 0
    score = -residual.astype(np.float64)

    # Reward exact fills (never harmful).
    score += (residual == 0).astype(np.float64) * (q10 * 0.5 + 0.25)

    # Bonus: leftover stays usable by a plausibly small future item.
    usable = residual >= q10
    score += usable.astype(np.float64) * q10 * 0.4

    # Penalize dead residuals that no realistic future item can use.
    dead = (residual > 0) & (residual < q10)
    score -= dead.astype(np.float64) * q10 * 0.4

    # Mild penalty for residuals sitting near the modal/common size band,
    # where a future item is likely to arrive but not fit cleanly.
    near_common = (residual >= q50 - 2) & (residual <= q50 + 2)
    score -= near_common.astype(np.float64) * 0.05

    return score
# EVOLVE-BLOCK-END

