# EVOLVE-BLOCK-START
"""Best fit.

For a near-continuous size distribution, best fit (choose the bin leaving the
smallest non-negative residual) is essentially near-optimal online. Ad-hoc
residual bonuses tend to hurt more than help, so the score is just the negative
post-placement residual. Ties go to the first bin, which favors older bins.
"""
import numpy as np

_n_items = None
_seen = 0


def _init(n):
    global _n_items, _seen
    _n_items = n
    _seen = 0


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    _seen += 1

    residual = bins - item  # >= 0 for all shown bins
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
