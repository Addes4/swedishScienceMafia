# EVOLVE-BLOCK-START
"""Distribution-aware residual targeting with best-fit core.

The main failure of pure best fit is stranding bins with residuals that no
future item can ever fit.  Since item sizes are drawn from a fixed (Weibull)
distribution with mean ~40, residuals near common item sizes are far more
likely to be filled later than residuals in the sparse tail.

This rule keeps a best-fit core (prefer smaller resulting residual) but adds
a bonus proportional to the empirical probability that *some* future item
fits the resulting residual (exact or close), using a smoothed item-size
histogram.  Denser bins (smaller residuals) get more weight, and residuals
matching frequent item sizes get an extra boost.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for bins the item fits in

    # Smoothed empirical item-size density on residuals 0..100.
    # Laplace smoothing so sparse regions still get a small mass.
    total = _seen
    smoothed = _hist + 1.0
    dens = smoothed / smoothed.sum()

    idx = np.clip(residual, 0, 100)
    exact_mass = dens[idx]

    # Exact-fill probability: chance a future item equals residual exactly.
    rem = max(_n_items - _seen, 1)
    exact_prob = exact_mass * rem

    # Immediate-close reward dominates; best-fit core keeps things packed.
    score = -residual.astype(np.float64)          # best-fit core
    score += (residual == 0).astype(np.float64) * 60.0
    score += np.minimum(exact_prob, 1.0) * 30.0    # distribution-aware fill

    return score
# EVOLVE-BLOCK-END
