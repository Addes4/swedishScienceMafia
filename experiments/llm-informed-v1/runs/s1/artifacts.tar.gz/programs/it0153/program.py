# EVOLVE-BLOCK-START
"""Pure best-fit bin choice.

Items arrive online and must be placed immediately.  The strongest simple
online heuristic for this capacity regime is best fit: put the item in the bin
whose remaining capacity after placement is smallest (without going negative).
This leaves the largest bins empty for large future items and tends to fill
bins tightly, which empirically beats the bonus-laden variants that were
tried.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for every bin shown
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

