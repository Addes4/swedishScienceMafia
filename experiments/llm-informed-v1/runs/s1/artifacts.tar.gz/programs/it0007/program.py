# EVOLVE-BLOCK-START
"""Best fit with reserve of empty bins: prefer tight fits in partially filled bins,
but only open a fresh (empty) bin when the item is large or no partial bin fits well."""
import numpy as np

_state = {"counts": None, "n": 0, "total": 0}

# Simple size histogram buckets (0..100).
_BUCKETS = 15
_BW = 100.0 / _BUCKETS


def priority(item, bins):
    st = _state
    if st["counts"] is None:
        st["counts"] = np.zeros(_BUCKETS, dtype=np.float64)
    st["n"] += 1
    st["total"] += item
    st["counts"][min(_BUCKETS - 1, int(item // _BW))] += 1.0

    n_hist = st["counts"].sum()

    # Fraction of empty bins currently among those shown.
    empty_mask = bins >= 100
    n_empty = int(empty_mask.sum())
    n_bins = bins.shape[0]

    # Reserve: don't touch empty bins unless item is fairly large,
    # or if there are plenty of empty bins left relative to remaining items.
    items_left = max(1, n_bins - st["n"] + 1)

    big = item >= 55

    leftover = bins - item
    score = -leftover.astype(np.float64)  # best fit

    if n_hist > 20:
        # bonus if leftover is a "common" size class
        idx = np.clip((leftover // _BW).astype(np.int64), 0, _BUCKETS - 1)
        freq = st["counts"] / n_hist
        score += 3.0 * freq[idx] * (leftover > 0)

    # Penalize empty bins unless we have surplus empty bins.
    surplus = n_empty > items_left * 0.6
    if not big and not surplus:
        score -= np.where(empty_mask, 200.0, 0.0)

    # penalize perfect-leftover-zero only slightly less; exact fits already best fit
    return score
# EVOLVE-BLOCK-END
