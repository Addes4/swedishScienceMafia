# EVOLVE-BLOCK-START
"""Best fit, with a tiny tie-break for exact fills only.

For online bin packing under a near-continuous size distribution (Weibull, mean ~40),
plain Best Fit (choose the fitting bin with the smallest remaining capacity) is very
close to optimal and hard to beat with clever perturbations. Earlier attempts to add
"reusability" or "reserve" bonuses only perturbed the strict best-fit ordering and
made things slightly worse.

So we revert to strict Best Fit: score = -residual. We add one exact tie-break bonus
for bins that the item fills exactly (residual == 0), which is strictly good and never
displaces a better fit. No other perturbation.

We still track state so we can safely detect the instance length (every bin unused on
first call => len(bins) == n_items).
"""
import numpy as np

# --- persistent state (fresh process per instance) ---
_n_items = None
_seen = 0
_residuals = None


def _init(n):
    global _n_items, _seen, _residuals
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1

    # Strict best fit: smallest post-placement residual wins.
    residual = bins.astype(np.int64) - item
    score = -residual.astype(np.float64)

    # Exact fill is strictly good; denote with a tiny positive bonus that cannot
    # reorder bins with different residuals (residual 0 is already smallest).
    score += (residual == 0).astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END

