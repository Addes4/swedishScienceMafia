# EVOLVE-BLOCK-START
"""Best fit with pair-completion awareness.

Best fit is near-optimal for online bin packing. A key waste source is a bin
whose residual exactly equals a size that will be paired: leaving such a
residual un-sealed wastes capacity. We track the packing state and an item
histogram, and adjust best-fit to prefer sealing pairs (place an item into a
bin whose residual equals the item size) and to avoid creating a residual
equal to the current item size.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0
    score = -residual.astype(np.float64)

    # Bonus when placing this item exactly seals a bin whose residual was the
    # item size (pre-placement residual == item), giving a perfect pair.
    pair = (bins == item)
    score += pair.astype(np.float64) * 1e-3

    # Penalty when the post-placement residual equals the current item size:
    # that creates a new un-sealed half-pair of the same size.
    halfpair = (residual == item) & (residual > 0)
    score -= halfpair.astype(np.float64) * 1e-3

    return score
# EVOLVE-BLOCK-END
