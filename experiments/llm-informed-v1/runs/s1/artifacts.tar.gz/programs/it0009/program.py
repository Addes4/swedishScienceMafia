# EVOLVE-BLOCK-START
"""Best fit, but strongly prioritize exact fills to close bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Large bonus when the item exactly fills the bin (residual == 0),
    # otherwise fall back to tightest fit (smallest residual).
    return np.where(residual == 0, 100000.0, -residual.astype(np.float64))
# EVOLVE-BLOCK-END
