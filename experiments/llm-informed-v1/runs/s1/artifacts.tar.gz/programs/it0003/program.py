# EVOLVE-BLOCK-START
"""Adaptive best-fit: prefer tight fits, but discourage opening fresh bins for small items."""
import numpy as np

_state = {"count": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Strategy: classic best-fit, with an extra penalty applied to completely empty bins
    (remaining capacity 100) so that fresh bins are reserved for items that need them.
    The penalty is applied only when the item is not too large relative to the running mean.
    """
    st = _state
    st["count"] += 1
    st["sum"] += item
    mean = st["sum"] / st["count"]

    # Best fit: higher score for tighter fit (smaller remaining after placement).
    score = -(bins - item).astype(np.float64)

    # Penalize using an empty bin when the item is below ~mean; reserve them for bigger items.
    if item < mean:
        score = np.where(bins == 100, score - 50.0, score)

    return score
# EVOLVE-BLOCK-END
