# EVOLVE-BLOCK-START
"""Best-fit with safe, scaled tie-breaking.

Pure best-fit (choose the bin with the smallest residual that still fits) is
the strongest known online rule here.  Earlier attempts to add residual-shaping
bonuses all regressed because they overwhelmed or perturbed the core choice.

This version makes the core strictly dominant by scaling it up
(score = -residual * 1000), so the bonus terms can only ever decide exact ties
(equal residual).  For those rare ties we prefer the bin whose residual is
usable and likely to be usefully filled by a future item.
"""
import numpy as np

_n_items = None
_residuals = None
_hist = None
_seen = 0
_smallest = 100


def _init(n):
    global _n_items, _residuals, _hist, _seen, _smallest
    _n_items = n
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _seen = 0
    _smallest = 100


def priority(item, bins):
    global _seen, _smallest

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    if item < _smallest:
        _smallest = item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen, 1)
    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total

    # Dominant best-fit core: strictly selects the smallest residual.
    score = -r * 1000.0

    # Tie-breakers only (residual equal):
    # reward residuals that a future item could exactly seal,
    score += fill_mass * 3.0
    # strongly reward a perfect seal,
    score += (residual == 0).astype(np.float64) * 5.0
    # and mildly penalize residuals too small for any item seen so far.
    if _smallest > 1:
        unusable = ((residual > 0) & (residual < _smallest)).astype(np.float64)
        score -= unusable * 2.0

    return score
# EVOLVE-BLOCK-END
