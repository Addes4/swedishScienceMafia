# EVOLVE-BLOCK-START
"""Best fit with a probabilistic reusability bonus.

Best fit (smallest fitting residual) is essentially optimal for online bin packing
under a continuous size distribution; its only real weakness is stranding tiny
residuals that no future item can ever fill.

We keep the full packing state ourselves and an empirical histogram of item sizes
seen so far. Rather than using the observed minimum (which underestimates the
size of future items when few small items have appeared, or overestimates it early),
we estimate the smallest item expected to arrive among the items still to come by
an order-statistic argument: with m items remaining, the expected minimum is around
the (1/(m+1))-quantile of the size distribution. We use that as the "floor" and
give a modest bonus to residuals at or above it, keeping best-fit ordering dominant.
"""
import numpy as np

# --- persistent state (fresh process per instance) ---
_n_items = None          # number of items in the instance
_seen = 0                # items seen so far
_residuals = None        # remaining capacity of every bin, indexed by bin order
_min_seen = 101          # smallest item size observed so far
_hist = None             # counts of item sizes, index 0..100


def _init(n):
    global _n_items, _seen, _residuals, _min_seen, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _min_seen = 101
    _hist = np.zeros(101, dtype=np.int64)


def _floor_estimate(remaining):
    """Estimate the smallest item likely to arrive among `remaining` future items.

    Use observed sizes to build an empirical CDF, then take the (1/(remaining+1))
    quantile. Fall back to a small constant if too little data.
    """
    total = _seen
    if total < 20:
        # not enough data yet; conservative small value
        return 1
    # cumulative counts
    cdf = np.cumsum(_hist[1:101])  # index i-1 -> count of sizes <= i
    if cdf[-1] == 0:
        return 1
    q = 1.0 / (remaining + 1.0)
    target = q * cdf[-1]
    # smallest size s with cdf >= target
    idx = int(np.searchsorted(cdf, target))
    return idx + 1  # size


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    global _seen, _min_seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    if item < _min_seen:
        _min_seen = item
    _hist[item] += 1

    remaining = _n_items - _seen
    floor = _floor_estimate(remaining)
    # clamp floor to something sensible
    if floor < 1:
        floor = 1
    elif floor > 100:
        floor = 100

    residual = bins - item  # >= 0 for all bins shown

    # Best fit dominates: smaller residual -> higher score.
    score = -residual.astype(np.float64)

    # Modest bonus when the leftover stays usable by a likely future item.
    usable = residual >= floor
    score += usable.astype(np.float64) * (floor * 0.5)

    # Strong bonus for exact fills (strictly good, no downside).
    score += (residual == 0).astype(np.float64) * (floor * 0.5 + 0.25)

    return score
# EVOLVE-BLOCK-END
