# EVOLVE-BLOCK-START
"""Distribution-aware residual targeting via expected exact-fill chance.

Pure best fit strands bins whose residual no future item can match.  Since
item sizes come from a fixed distribution, a residual equal to a *frequent*
size is much more likely to be exactly filled later than one in the sparse
tail.  This rule keeps a best-fit core (small residual preferred) but scores
bins primarily by the smoothed empirical probability that a future item
exactly matches the resulting residual, weighted by how many items remain.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_alpha = 0.5  # Laplace smoothing


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for bins the item fits in

    # Smoothed empirical density over sizes 0..100 (index by residual).
    counts = _hist.copy()
    counts[0] = 0.0  # size 0 is not a real item
    smoothed = counts + _alpha
    smoothed[0] = 0.0
    total = smoothed.sum()
    if total <= 0:
        total = 1.0
    pmf = smoothed / total

    idx = np.clip(residual, 0, 100)

    # Probability that a future single item exactly fills this residual.
    exact_p = pmf[idx]

    # Expected number of future exact-fills ~ remaining items * exact_p.
    remaining = _n_items - _seen + 1  # include this item optimistically
    if remaining < 0:
        remaining = 0

    score = exact_p * remaining * 100.0

    # Exact zero residual is a perfectly closed bin: dominant reward.
    score += (residual == 0).astype(np.float64) * 200.0

    # Best-fit core: tie-break toward smaller residuals so we pack tightly.
    score -= residual.astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END

