# EVOLVE-BLOCK-START
"""Best fit with a gentle mode-matching tie-break.

Pure best fit is hard to beat, but it can leave "awkward" residuals that no
future item matches.  We keep the best-fit ordering dominant (tiny epsilon
weight on the tie-break) and add a small bonus for residuals near the mode of
the empirical item-size distribution seen so far, which are the residuals most
likely to be exactly fillable later.
"""
import numpy as np

_state = {"n": 0, "counts": None}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    if _state["counts"] is None or len(_state["counts"]) < 101:
        _state["counts"] = np.zeros(101, dtype=np.float64)
    _state["n"] += 1
    if 1 <= item <= 100:
        _state["counts"][item] += 1.0

    residual = bins - item  # >= 0 for all shown bins

    # Mode of observed item sizes (ignoring size 0 slot).
    counts = _state["counts"]
    if _state["n"] >= 20:
        mode = float(np.argmax(counts[1:])) + 1.0
    else:
        mode = 20.0  # modest prior

    # Dominant term: prefer smaller residual (best fit).
    base = -residual.astype(np.float64)

    # Tiny tie-break: reward residuals close to the current mode.
    closeness = -np.abs(residual.astype(np.float64) - mode)

    return base + 0.01 * closeness
# EVOLVE-BLOCK-END
