# EVOLVE-BLOCK-START
"""Competitive best-fit with future-fill viability (histogram reachability).

This rule keeps best-fit as the core (score = -residual) but:
  * penalizes residuals below the empirical median item size,
  * rewards residuals whose size has high empirical histogram mass,
  * gives a strong reward for residuals that equal 0 (perfect seal),
  * rewards residuals reachable by common small future items,
  * rewards exact-pair-sealing opportunities with other open bins,
  * mildly nudges residuals toward sizes that admit typical items.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0
_cum = None


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum, _cum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _cum = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    # Empirical median item size (approx) via cumulative histogram.
    target = 0.5 * total
    cum = 0.0
    median = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            median = s
            break

    # Cumulative histogram (fraction of items <= s).
    _cum[:] = np.cumsum(_hist) / total

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    fit_mass = _cum[idx]

    # Best-fit core.
    score = -r * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 70.0

    # Smooth penalty for residuals that can accept few future items: the
    # fraction of items too big to fit is (1 - CDF(residual)).  Scale by a
    # steep factor so tiny residuals are strongly discouraged.
    cant_fit = (1.0 - fit_mass)
    # Only penalize the portion that's effectively dead weight; weight the
    # penalty by how far below the median we are to avoid over-penalizing
    # mid residuals that are still useful.
    small_factor = np.clip((median - residual) / np.maximum(median, 1.0), 0.0, 1.0)
    score -= cant_fit * (1.0 + 30.0 * small_factor)

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 55.0

    # Exact-pair-seal: reward residuals whose exact-fill mass combined with
    # flexible future items makes sealing another bin likely.
    if _seen > 1:
        score += (fill_mass * fit_mass) * 15.0

    # Reward residuals in the mid range where chipping is safe.
    in_mid = ((residual >= 20) & (residual <= 70)).astype(np.float64)
    score += in_mid * 3.0

    # Reward residuals that admit at least some future item (flexibility).
    score += fit_mass * 8.0

    # Mild monotone preference for residuals that can still hold median items.
    score += (residual >= median).astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END
