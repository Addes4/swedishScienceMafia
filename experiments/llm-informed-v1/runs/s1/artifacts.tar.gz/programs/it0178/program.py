# EVOLVE-BLOCK-START
"""Best-fit core with empirical exact-fill targeting.

Best fit (score = -residual) is the strongest known core.  Its main weakness
is leaving small unusable residues.  Since item sizes come from one fixed
distribution, a residual is valuable exactly when future items are likely to
land on it.  This rule keeps -residual dominant and adds two mild,
empirically-scaled rewards:

  * a reward for residuals whose size carries high empirical histogram mass
    (likely to be exactly filled by a future item),
  * a strong reward for a perfect seal (residual == 0).

The flexibility bonus is removed because it rewarded many mid-size residuals
broadly and diluted the best-fit behavior.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    # Empirical median item size (approx) via cumulative histogram.
    target = 0.5 * total
    cum = 0.0
    median = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            median = s
            break

    idx = np.clip(residual, 0, 100)
    # Empirical mass at the exact residual size (chance of an exact fill).
    fill_mass = _hist[idx].astype(np.float64) / total

    # Best-fit core.
    score = -residual.astype(np.float64)

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize residuals too small to accept a typical (median) item,
    # but only if they are not a perfect seal.
    too_small = ((residual > 0) & (residual < median)).astype(np.float64)
    score -= too_small * 35.0

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 40.0

    return score
# EVOLVE-BLOCK-END

