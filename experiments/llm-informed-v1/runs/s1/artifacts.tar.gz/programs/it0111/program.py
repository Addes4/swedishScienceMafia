# EVOLVE-BLOCK-START
"""Balanced placement keyed to the empirical residual target.

Best fit fills residuals to the brim and then strands small leftovers that no
future item can use.  Instead we score each candidate bin by how close its
post-placement residual is to the empirical *typical* item size (the median of
sizes seen so far): a residual near the typical size is the one a future item
is most likely to close exactly, so we prefer leaving such residuals while
still rewarding small residuals and exact fills.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def _median():
    total = _seen
    if total <= 0:
        return 1
    target = total * 0.5
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for all shown bins

    med = _median()

    score = -residual.astype(np.float64)          # best fit dominates
    # Reward residuals close to the empirical typical item size: these are the
    # leftovers most likely to be closed exactly by a future item.
    gap = np.abs(residual - med).astype(np.float64)
    score += 40.0 / (1.0 + gap)
    # Exact fills are always best.
    score += (residual == 0).astype(np.float64) * 200.0

    return score
# EVOLVE-BLOCK-END

