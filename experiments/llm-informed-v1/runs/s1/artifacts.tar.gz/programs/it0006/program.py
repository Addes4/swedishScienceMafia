# EVOLVE-BLOCK-START
"""Best fit with a learned size-class tie-breaker and empty-bin reservation."""
import numpy as np

# Module-level state (fresh per instance)
_hist = np.zeros(101, dtype=np.int64)   # count of item sizes seen
_total = 0


def priority(item, bins):
    """Rank bins: prefer tight fits, reserve empty bins for large items,
    and reward leftovers that match common item sizes.
    """
    global _hist, _total
    _hist[item] += 1
    _total += 1

    # Score: higher is better. Best fit => -(bins - item).
    leftover = bins - item

    # Penalize using an empty bin unless the item is large.
    empty_penalty = np.where(bins == 100, -25.0 if item < 60 else 0.0, 0.0)

    # Bonus if the leftover equals a commonly seen item size (helps future fills).
    # Use a small, data-driven bonus based on frequency seen so far.
    # Normalize to a mild additive term.
    freq = _hist[leftover] if _total > 0 else np.zeros_like(leftover)
    # Only penalize leftovers already observed often enough to be likely fillable.
    bonus = np.where(leftover > 0, freq / max(1, _total), 0.0) * 10.0

    return -(bins - item) + empty_penalty + bonus
# EVOLVE-BLOCK-END
