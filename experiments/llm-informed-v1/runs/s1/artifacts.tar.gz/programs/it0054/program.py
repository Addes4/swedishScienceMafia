# EVOLVE-BLOCK-START
"""Best fit with dead-space awareness.

Pure best fit minimizes leftover residual, but because item sizes are continuous
(Weibull-shaped, mean ~40), a bin can end with a residual smaller than every item
we will ever see again. That space is permanently wasted. We track the running
minimum observed item size m and penalize bins whose post-placement residual
falls strictly in (0, m): such residuals can (almost) never be used, so we would
rather leave a slightly larger but still usable residual, or an exact fill.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first bin."""
    # Update the running minimum observed item size, kept in a module-level box.
    m = priority.min_seen
    if m is None or item < m:
        m = item
        priority.min_seen = m

    residual = bins - item  # >= 0 for every bin we are shown

    # Best fit: smaller residual is better.
    score = -residual.astype(np.float64)

    # Dead-space penalty: residual in (0, m) or residual in (0, item_min_possible)
    # is very likely unusable; push it behind any bin with residual 0 or >= m.
    dead = (residual > 0) & (residual < m)
    if m > 1:
        score[dead] -= 1e6 * (m - residual[dead])  # larger residual just below m is worse

    return score


priority.min_seen = None
# EVOLVE-BLOCK-END
