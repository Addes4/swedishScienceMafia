# EVOLVE-BLOCK-START
"""Best-fit with a cheap exact-seal preference.

Pure best fit is the strongest simple rule here.  The only extra signal kept
is a very targeted one: when the residual equals the current item's size, a
later item of the same size can seal the bin exactly, so such a bin is
slightly preferred.  Everything else is plain best fit, which avoids the
fragile statistical terms that misranked near-equal candidates.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for shown bins

    # Best-fit core: prefer the smallest residual that still fits.
    score = -residual.astype(np.float64)

    # Perfect seal bonus.
    score += (residual == 0).astype(np.float64) * 60.0

    # Mild bonus when residual equals this item's size, so a later identical
    # item can seal the bin exactly.  Weight chosen to break ties only.
    score += (residual == item).astype(np.float64) * 3.0

    return score
# EVOLVE-BLOCK-END
