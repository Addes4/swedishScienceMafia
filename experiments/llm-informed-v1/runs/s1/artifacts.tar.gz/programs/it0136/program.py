# EVOLVE-BLOCK-START
"""Best-fit core with a smooth empirical-CDF viability penalty.

Pure best fit strands bins whose residual is too small to admit any future
item.  Instead of hard thresholds with magic constants, we estimate, from the
items seen so far, the probability that at least one future item fits a given
residual r, and penalize residuals with low viability.  This keeps best-fit
behavior (prefer small residuals) but steers away from residuals that are
very likely to become permanent waste.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_P_fit = None  # cache: P(some future item <= r), computed lazily


def _init(n):
    global _n_items, _seen, _residuals, _hist, _P_fit
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _P_fit = None


def _cdf_fit():
    """Return array size 101: empirical CDF of item sizes (P(size <= r))."""
    total = max(_seen, 1)
    cdf = np.cumsum(_hist).astype(np.float64) / total
    return cdf


def priority(item, bins):
    global _seen, _P_fit

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _P_fit = None

    residual = bins - item  # >= 0 for bins the item fits in

    cdf = _cdf_fit()
    # Smallest size that could be used to fill a residual of size r:
    # viability ~ P(size <= r).  Use expected remaining slots to sharpen:
    # with k items still to arrive, chance at least one fits is
    # 1 - (1 - p)^k, but we only want a monotone shaping, so use the
    # geometric-ish form with a moderate effective horizon.
    remaining = max(_n_items - _seen, 1)
    # Cap the exponent so we do not overreact late in the instance.
    k_eff = min(remaining, 40)

    p = cdf[np.clip(residual, 0, 100)]
    # P(no future item fits) = (1 - p)^k_eff
    log_no_fit = k_eff * np.log(np.clip(1.0 - p, 1e-9, 1.0))
    no_fit = np.exp(log_no_fit)  # in (0,1]

    score = -residual.astype(np.float64)  # best-fit core
    # Penalize residuals unlikely to receive any future item.
    score -= no_fit * 200.0
    # Strongly reward exact fills (residual == 0 wastes nothing).
    score += (residual == 0).astype(np.float64) * 50.0

    return score
# EVOLVE-BLOCK-END
