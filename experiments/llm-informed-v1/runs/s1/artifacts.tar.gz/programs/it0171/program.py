# EVOLVE-BLOCK-START
"""Best-fit with a steep near-seal bias.

Pure best fit already performs very well here because it minimizes the leftover
capacity at each step.  The main loss comes from leaving many tiny residuals
that cannot be reused.  Rather than adding noisy histogram-based bonuses (which
tended to hurt), this rule stays essentially best-fit but makes the preference
monotone and steeper as the residual shrinks, so perfectly/near-perfectly
fitting bins are chosen aggressively while distant fits remain ordered by size.
"""
import numpy as np


def priority(item, bins):
    residual = bins.astype(np.float64) - item  # >= 0 for the shown bins
    # Core best-fit ordering.
    score = -residual
    # Extra concave reward for small residuals: seals full bins more eagerly,
    # consolidating packing and reducing unusable leftovers.
    score += 50.0 / (residual + 1.0)
    return score
# EVOLVE-BLOCK-END
