# EVOLVE-BLOCK-START
"""Distribution-aware residual targeting with best-fit core.

Pure best fit strands bins with residuals no future item can fill.  Item
sizes are drawn from a fixed distribution (mean ~40), so residuals that
match frequently-observed item sizes are far more likely to be closed
exactly later.  This rule keeps a best-fit core but rewards candidate
residuals by the empirical probability that a future item exactly fills
them and by a concave desirability term, adapting to the live histogram.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    total = max(_seen, 1)

    # Empirical frequency of each size (smoothing to avoid hard zeros).
    freq = (_hist.astype(np.float64) + 0.5) / (total + 50.0)

    idx = np.clip(residual, 0, 100)

    # Probability a future item exactly matches this residual.
    exact_prob = freq[idx]

    # Cumulative probability that some item fits within the residual
    # (a residual with more usable room admits more future items).
    cum = np.cumsum(freq)  # cum[r] = P(size <= r)
    usable_prob = cum[idx]

    # Denser bins (smaller residuals) are strongly preferred: the
    # reciprocal-like concavity concentrates mass where bins can close.
    # Use a concave transform of the viable room.
    room = residual.astype(np.float64)
    concavity = room / (room + 40.0)  # in [0,1), grows with room

    score = -residual.astype(np.float64) * 0.5   # best-fit core
    score += (residual == 0).astype(np.float64) * 100.0  # exact close
    score += exact_prob * 60.0                   # matchable residuals
    score += usable_prob * 8.0                   # viable residuals
    score -= concavity * 6.0                     # penalize large sparse rooms

    return score
# EVOLVE-BLOCK-END
