# EVOLVE-BLOCK-START
"""Complement-aware best fit.

Items come from a fixed Weibull distribution with mean ~40.  Pure best-fit
strands bins; the classic fix is to combine items into full bins.  Since the
item currently being placed does not know the future, we reward placing it in
a bin whose resulting residual equals (100 - item): that leaves exactly enough
room for another item of the current size, which is a common pairing.
"""
import numpy as np

_n_items = None
_hist = None


def _init(n):
    global _n_items, _hist
    _n_items = n
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in
    residual = residual.astype(np.float64)

    total = max(int(_hist.sum()), 1)

    # Best-fit core: prefer smaller resulting residual.
    score = -residual

    # Exact fill: completing a bin is always great.
    score += (residual == 0).astype(np.float64) * 60.0

    # Complementary pairing: leaving room for another item of this size.
    comp = (residual == item).astype(np.float64)
    # weight by how common this size is
    freq = _hist[item] / total
    score += comp * (20.0 + 40.0 * freq)

    # Mild bonus for residuals that match a frequent future size exactly.
    idx = np.clip(residual, 0, 100).astype(np.int64)
    score += (_hist[idx].astype(np.float64) / total) * 15.0

    return score
# EVOLVE-BLOCK-END
