# EVOLVE-BLOCK-START
"""Best-fit core with a perfect-seal reward.

Pure best fit is essentially optimal for i.i.d. item sizes drawn from a
fixed distribution: packing each item into the tightest bin that still fits
keeps residuals small and rarely strands capacity.  The only clearly
beneficial deviation is to strongly prefer sealing a bin exactly (residual
0), since a sealed bin can never receive anything and frees no future
flexibility.  A mild penalty avoids stranding residuals below the smallest
item size seen so far, which no future item could ever fill.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for shown bins

    r = residual.astype(np.float64)

    # Best-fit core.
    score = -r

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize residuals that no seen item could ever fill (truly stranded),
    # but not a perfect seal.
    smallest = 1
    for s in range(1, 101):
        if _hist[s] > 0:
            smallest = s
            break
    too_small = ((residual > 0) & (residual < smallest)).astype(np.float64)
    score -= too_small * 20.0

    return score
# EVOLVE-BLOCK-END
