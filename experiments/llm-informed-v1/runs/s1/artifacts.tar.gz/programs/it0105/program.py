# EVOLVE-BLOCK-START
"""Balanced placement with graded empirical viability scoring.

Best fit (smallest resulting residual) is the primary signal, but a residual
that is too small to host a typical future item is nearly wasted.  We reward
residuals that are comfortably above a low empirical quantile of the size
distribution, grading the reward so that residuals near the typical item size
are most attractive, and we mildly penalise residuals in the "dead zone" below
that quantile.  Exact fills are always strongly preferred.  The thresholds are
derived from the empirical histogram seen so far, so the rule adapts to the
Weibull shape without tuning to any instance.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in
    score = -residual.astype(np.float64)

    # Empirical quantiles of sizes seen so far.
    q20 = _quantile(0.20)
    q50 = _quantile(0.50)

    # Graded viability: residuals below q20 are near-dead (mild penalty),
    # residuals from q20 up to the median get an increasing bonus, and beyond
    # the median the reward saturates (large residual is good but not free).
    rf = residual.astype(np.float64)
    low = q20 if q20 > 0 else 1
    mid = q50 if q50 > low else low + 1

    # Below low: gentle penalty proportional to how dead the residual is.
    below = rf < low
    score -= below.astype(np.float64) * (low - rf) * 0.5

    # Between low and mid: reward grows linearly.
    band = (rf >= low) & (rf < mid)
    score += band.astype(np.float64) * (30.0 + 20.0 * (rf - low) / max(mid - low, 1))

    # At or above mid: solid, saturated reward.
    above = rf >= mid
    score += above.astype(np.float64) * 50.0

    # Exact fills are always good.
    score += (residual == 0).astype(np.float64) * 80.0

    return score
# EVOLVE-BLOCK-END
