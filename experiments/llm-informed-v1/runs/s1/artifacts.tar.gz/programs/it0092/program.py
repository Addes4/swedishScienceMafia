# EVOLVE-BLOCK-START
"""Best fit with a small dead-space discount.

Pure best fit is near-optimal for online bin packing under this distribution.
Its only systematic waste is leaving residuals that are too small to ever be
usefully filled again. We keep the full packing state and an empirical
histogram of item sizes, and apply a tiny discount to placements that leave a
positive residual below a low quantile of the observed size distribution, so
that among near-equal residuals we prefer the one that stays reusable.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    q05 = _quantile(0.05)

    residual = bins - item  # >= 0
    score = -residual.astype(np.float64)

    # tiny discount for positive residuals below a low quantile (likely dead)
    dead = (residual > 0) & (residual < q05)
    score -= dead.astype(np.float64) * 0.5

    # tiny bonus for exact fills
    score += (residual == 0).astype(np.float64) * 0.25

    return score
# EVOLVE-BLOCK-END
