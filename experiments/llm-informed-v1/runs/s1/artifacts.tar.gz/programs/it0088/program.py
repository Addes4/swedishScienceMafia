# EVOLVE-BLOCK-START
"""Class-based (Harmonic/Sum-of-Squares style) online bin packing.

Pure best fit is near-optimal but strands residuals that no future item can use.
Harmonic-style rules partition items into size classes; a bin is "kept in-class"
when the residual after placement still fits the class of the current item, so the
bin remains usable for another item of that class. We combine this with best fit.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None

# Harmonic class boundaries (as fractions of capacity 100). Items with size in
# (1/(k+1), 1/k] belong to class k. We use a moderate number of classes.
_BOUNDS = np.array([50, 34, 25, 20, 17, 15, 13, 12, 11, 10, 9, 8, 7, 6, 5], dtype=np.int64)


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def _class_cap(item):
    # smallest boundary >= item gives the class's upper size limit
    for b in _BOUNDS:
        if item <= b:
            return b
    return 100


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0
    resid = residual.astype(np.int64)

    cap = _class_cap(item)

    # in-class: residual is big enough to still fit another item of this class,
    # i.e. residual >= item (approx: same class item size >= lower bound of class)
    # lower bound of the class is the next boundary below cap; use item itself as proxy.
    in_class = resid >= item

    score = np.zeros(n, dtype=np.float64)

    # primary: prefer in-class placements (keep bins alive for same-class items)
    score += in_class.astype(np.float64) * 1000.0

    # secondary: best fit among the preferred group (smaller residual first)
    score += -resid.astype(np.float64) * 0.001

    # tertiary: among in-class placements, prefer the bin whose residual is closest
    # to a multiple of item (packing efficiency), mild tie-break
    ratio = resid % max(item, 1)
    score += (1.0 / (ratio + 1.0)) * 0.01

    # reward exact fills strongly inside their own tier
    score += (resid == 0).astype(np.float64) * 500.0

    return score
# EVOLVE-BLOCK-END
