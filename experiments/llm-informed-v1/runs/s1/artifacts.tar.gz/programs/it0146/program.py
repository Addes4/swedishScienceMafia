# EVOLVE-BLOCK-START
"""Distribution-aware residual targeting with a best-fit core.

Pure best fit strands bins whose residual equals a rare item size.  Since
sizes come from a fixed (Weibull) distribution, a residual that matches a
*frequent* item size is far more likely to be exactly filled later.

This rule keeps a best-fit core (prefer smaller resulting residual) and adds
a smooth bonus proportional to the smoothed empirical probability of the
residual being a common future item size, scaled by how many items remain.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.float64)
    _bin_count = 0


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for bins the item fits in
    idx = np.clip(residual, 0, 100)

    total = max(_seen, 1)
    # Laplace-smoothed density over item sizes (denominator ~ total + 101).
    dens = _hist / (total + 101.0)

    # Probability the resulting residual is exactly a common item size.
    exact_p = dens[idx]

    # How many items remain (fraction of instance still to come).
    remaining_frac = (_n_items - _seen) / _n_items

    score = -residual.astype(np.float64)          # best-fit core
    score += (residual == 0).astype(np.float64) * 80.0
    # Smooth, distribution-aware viability bonus: denser residuals of frequent
    # sizes are more likely to be exactly filled by a future item.
    score += exact_p * 200.0 * remaining_frac

    return score
# EVOLVE-BLOCK-END
