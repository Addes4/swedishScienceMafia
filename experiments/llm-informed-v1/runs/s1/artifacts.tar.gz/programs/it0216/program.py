# EVOLVE-BLOCK-START
"""Best-fit with unusable-sliver avoidance and seal reward.

Core is standard best-fit (tightest residual).  Two targeted corrections:
  * perfectly sealing a bin (residual 0) is strongly rewarded, since it
    removes an open bin cheaply and can only help future placements;
  * a positive residual below the smallest item seen so far is a dead
    sliver: no future item can ever use it, so it is penalized.
Both corrections are based on directly observed quantities, avoiding the
noisier histogram/mean heuristics.
"""
import numpy as np

_n_items = None
_residuals = None
_min_item = 101


def _init(n):
    global _n_items, _residuals, _min_item
    _n_items = n
    _residuals = np.full(n, 100, dtype=np.int64)
    _min_item = 101


def priority(item, bins):
    global _min_item

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    if item < _min_item:
        _min_item = item

    residual = bins - item  # >= 0 for shown bins

    score = -residual.astype(np.float64)

    # Strong reward for perfect seals.
    score += (residual == 0).astype(np.float64) * 80.0

    # Penalize dead slivers: positive residual too small for any future item.
    dead = ((residual > 0) & (residual < _min_item)).astype(np.float64)
    score -= dead * 50.0

    return score
# EVOLVE-BLOCK-END
