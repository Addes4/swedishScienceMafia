# EVOLVE-BLOCK-START
"""Best fit with an exact-histogram tie-break.

Best fit (smallest remaining capacity that still fits) is essentially optimal for
online bin packing under a near-continuous size distribution. We keep the full
packing state ourselves and an empirical histogram of item sizes seen so far.

The scoring is pure best fit: the bin with the smallest post-placement residual
scores highest. We add a strictly tie-breaking bonus only among bins with the
same smallest residual: prefer the bin whose leftover equals a size we have
actually observed (so a likely future item can fill it exactly). Because the
bonus is applied uniformly within a residual value, it never reorders bins with
different residuals.
"""
import numpy as np

# --- persistent state (fresh process per instance) ---
_n_items = None          # number of items in the instance
_residuals = None        # remaining capacity of every bin, indexed by bin order
_hist = None             # counts of item sizes, index 0..100


def _init(n):
    global _n_items, _residuals, _hist
    _n_items = n
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    global _hist

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _hist[item] += 1

    # Pure best fit: smallest residual first.
    residual = bins - item  # >= 0 for all bins shown
    score = -residual.astype(np.float64)

    # Strict tie-break: only among bins sharing the same smallest residual, nudge
    # toward leftovers that match an item size we have already observed. Scaled so
    # it can never exceed 0.5 (i.e. never flips a 1-unit residual difference).
    seen_mass = _hist.astype(np.float64)
    seen_mass /= (seen_mass.sum() + 1.0)  # 0..1 per size
    tie_bonus = seen_mass[np.clip(residual, 0, 100)] * 0.5
    score += tie_bonus

    return score
# EVOLVE-BLOCK-END

