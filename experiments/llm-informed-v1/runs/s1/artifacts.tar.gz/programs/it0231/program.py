# EVOLVE-BLOCK-START
"""Best-fit core with frequent-residual sealing bonus.

Best fit (score = -residual) is the strongest simple online rule for this
distribution.  The main remaining waste is bins left with a residual that no
later item exactly fills.  A residual is valuable exactly when some frequent
future item size equals it (perfect seal) -- or is very close to it (near
seal leaving a tiny leftover).  We therefore keep strict best-fit as the core
and add a bonus proportional to the empirical probability that a future item
matches (or nearly matches) each residual.

We estimate the item distribution online from a running histogram, and only
reward residuals whose size actually occurs in the histogram.  This is cheap,
stable, and directly targets sealing.
"""
import numpy as np

_n_items = None
_hist = None
_seen = 0


def _init(n):
    global _n_items, _hist, _seen
    _n_items = n
    _hist = np.zeros(101, dtype=np.float64)
    _seen = 0


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for the bins shown

    idx = np.clip(residual, 0, 100)
    total = max(_seen, 1)

    # Strict best fit core.
    score = -residual.astype(np.float64)

    # Perfect seal: strongest reward (residual exactly zero).
    score += (residual == 0).astype(np.float64) * 100.0

    # Empirical probability that some future item exactly equals the residual.
    seal_prob = _hist[idx] / total
    score += seal_prob * 120.0

    # Near-seal: reward residuals whose neighbors are also frequent item sizes
    # (a slightly smaller future item leaves only a tiny leftover).
    if total > 1:
        left = _hist[np.clip(idx - 1, 0, 100)] / total
        right = _hist[np.clip(idx + 1, 0, 100)] / total
        score += np.maximum(left, right) * 20.0

    return score
# EVOLVE-BLOCK-END
