# EVOLVE-BLOCK-START
"""Best-fit with a mild reserve and a new-bin penalty.

Core idea: greedy best fit (smallest resulting residual) is the strongest
simple online rule.  Two small corrections help it on Weibull(mean~40) sizes:

1. Residuals that are very small but nonzero are nearly unusable and tend to
   strand a bin.  Give a modest bonus to residuals that stay at or above a
   fixed fraction of capacity (20), so we don't create crumbs.
2. Prefer reusing existing bins over opening a fresh one when the resulting
   residual would be similar, by adding a tiny bonus proportional to the
   bin's current load.
"""
import numpy as np

_n_items = None


def _init(n):
    global _n_items
    _n_items = n


def priority(item, bins):
    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    residual = bins - item  # >= 0 for bins the item fits in

    # Base: prefer the smallest resulting residual (best fit).
    score = -residual.astype(np.float64)

    # Small bonus for residuals that keep the bin comfortably usable.
    comfortable = (residual >= 20) & (residual > 0)
    score += comfortable.astype(np.float64) * 5.0

    # Strong bonus for exact fills.
    score += (residual == 0).astype(np.float64) * 40.0

    # Mild preference to reuse already-loaded bins (larger load = smaller
    # remaining capacity originally).  Only breaks near-ties.
    score += (100 - bins).astype(np.float64) * 0.001

    return score
# EVOLVE-BLOCK-END
