# EVOLVE-BLOCK-START
"""Competitive best-fit with exact-fill and pair-seal signals.

Best fit is the core (score = -residual), but pure best fit strands tiny
residuals that no future item can ever use.  Since sizes come from a fixed
Weibull-like distribution (mean ~40), a residual is *useful* only if some
future item fits it and it is *valuable* if future items are likely to
exactly fill it.

Terms:
  * best-fit core: score -= residual
  * strong reward for residuals equal to 0 (perfect seal)
  * penalize residuals too small for a typical (median) item
  * reward residuals whose size has high empirical histogram mass
    (likely to be exactly filled by a future item)
  * exact-pair-seal: strongly reward a resulting residual that equals
    another open bin's residual, so one future item can seal one of them.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0
_cum = None


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum, _cum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _cum = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)
    mean = _sum / _seen

    # Empirical median item size (approx) via cumulative histogram.
    target = 0.5 * total
    cum = 0.0
    median = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            median = s
            break

    # Cumulative histogram (fraction of items <= s).
    _cum[:] = np.cumsum(_hist) / total

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    fit_mass = _cum[idx]

    # Best-fit core.
    score = -r * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 70.0

    # Penalize residuals too small to accept a typical (median) item,
    # but only if they are not a perfect seal.
    too_small = ((residual > 0) & (residual < median)).astype(np.float64)
    score -= too_small * 35.0

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 45.0

    # Exact-pair-seal: strongly reward a resulting residual that matches
    # another open bin's residual, so one future item can seal one of them.
    # Presence-count of residuals in the current open-bin multiset.
    other = np.bincount(_residuals, minlength=101).astype(np.float64)
    # avoid counting the candidate bin's own current residual effect:
    # compare candidate resulting residual against the *other* open residuals.
    exact_match = np.zeros_like(r)
    if _seen > 1:
        present = other[idx] > 0
        exact_match = present.astype(np.float64)
    score += exact_match * 25.0

    # Reward residuals that admit at least some future item (flexibility).
    score += fit_mass * 8.0

    # Nudge residuals toward the running mean: a single typical future item
    # nearly seals such a bin.
    if mean > 0:
        near_mean = np.abs(r - mean)
        score += np.exp(-(near_mean / (0.5 * mean + 1.0)) ** 2) * 4.0

    return score
# EVOLVE-BLOCK-END

