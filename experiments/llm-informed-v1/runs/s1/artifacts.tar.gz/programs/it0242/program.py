# EVOLVE-BLOCK-START
"""Best-fit with future-fill viability (streamlined).

Core is proven best-fit (score = -residual).  We keep only the terms that
consistently helped:
  * a strong reward for a perfect seal (residual == 0),
  * a penalty for nonzero residuals too small to ever be useful,
  * a reward proportional to the empirical mass of the residual (how often a
    future item could exactly fill it),
  * a reward proportional to the flexibility mass (fraction of item sizes
    that fit in the residual).

The median/mean/multiple "nudges" are dropped because they only add variance
without changing the dominant best-fit ordering.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_sum = 0
_mean = 0.0
_min_item = 101


def _init(n):
    global _n_items, _seen, _hist, _sum, _mean, _min_item
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _mean = 0.0
    _min_item = 101


def priority(item, bins):
    global _seen, _sum, _mean, _min_item

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None or len(_hist) != 101:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item
    _mean += (item - _mean) * (1.0 / _seen)
    if item < _min_item:
        _min_item = item

    residual = bins - item  # >= 0 for shown bins

    total = float(max(_seen - 1, 1))

    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    cum_hist = np.cumsum(_hist).astype(np.float64) / total
    fit_mass = cum_hist[idx]

    # Best-fit core.
    score = -residual.astype(np.float64)

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 90.0

    # Penalize residuals too small to accept even the smallest item seen.
    too_small = ((residual > 0) & (residual < _min_item)).astype(np.float64)
    score -= too_small * 50.0

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 35.0

    # Reward residuals that admit at least some future item (flexibility).
    score += fit_mass * 10.0

    return score
# EVOLVE-BLOCK-END
