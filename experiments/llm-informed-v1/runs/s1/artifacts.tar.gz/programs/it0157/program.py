# EVOLVE-BLOCK-START
"""Best-fit core with a de-fragmentation tie-breaker.

Pure best-fit is empirically strong because it continuously fills the
smallest residual that fits.  All previous additive bonuses acted mostly
as noise.  Here we keep best-fit dominant but add a small, smooth bonus
that favors residuals which keep bins reusable: a bin whose remaining
residual is close to the typical item size (empirical mean) is a good
candidate to be filled or absorbed later, whereas an awkward mid-size
residual tends to strand.  The bonus is tiny relative to the -residual
gap so it only acts as a tie-breaker.
"""
import numpy as np

_n_items = None
_seen = 0
_sum = 0.0


def _init(n):
    global _n_items, _seen, _sum
    _n_items = n
    _seen = 0
    _sum = 0.0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    _seen += 1
    _sum += item
    mean_item = _sum / _seen

    residual = bins - item  # >= 0 for bins the item fits in

    # Best-fit core: prefer the smallest resulting residual.
    score = -residual.astype(np.float64)

    # De-fragmentation tie-breaker (bounded, <= 0.5 so it never beats a
    # unit difference in residual).  Prefer residuals near the current
    # empirical mean item size: such bins are likely to be filled/absorbed
    # by a typical future item.
    r = residual.astype(np.float64)
    # 1 / (1 + |r - mean|): peaks when the residual equals a typical item.
    tie = 1.0 / (1.0 + np.abs(r - mean_item))
    # exact-fill gets the strongest nudge
    score += 0.5 * tie + 0.5 * (residual == 0).astype(np.float64)

    return score
# EVOLVE-BLOCK-END
