# EVOLVE-BLOCK-START
"""Competitive best-fit with horizon-aware sealing.

The distribution is fixed (mean ~40), so among bins the item fits in, nearest
residual (best fit) is a strong core.  The main reliable lever to reduce bin
count is to *seal* bins exactly (residual 0), because a sealed bin cannot
receive more items and is fully retired.  Early in the instance we keep
flexibility (avoid over-sealing a bin that could absorb a larger future item),
and as the horizon shrinks we increasingly prefer exact seals.
"""
import numpy as np

_n_items = None
_seen = 0
_sum = 0


def _init(n):
    global _n_items, _seen, _sum
    _n_items = n
    _seen = 0
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    _seen += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    # fraction of the instance already processed: 0 -> start, 1 -> end
    frac = _seen / float(_n_items) if _n_items else 1.0

    score = -residual.astype(np.float64)

    # Perfect seal reward, growing as the horizon tightens.
    seal = (residual == 0).astype(np.float64)
    score += seal * (30.0 + 90.0 * frac)

    # Slight penalty for residuals too small to hold a typical future item,
    # stronger early (when big items are still to come) and weaker late.
    small = ((residual > 0) & (residual < 15)).astype(np.float64)
    score -= small * (20.0 * (1.0 - frac))

    return score
# EVOLVE-BLOCK-END


