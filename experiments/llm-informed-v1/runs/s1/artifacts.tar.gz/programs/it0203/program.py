# EVOLVE-BLOCK-START
"""Best-fit with future-seal viability based on the empirical distribution.

The core is standard best fit (prefer the bin that becomes fullest).  On top
of that we add a principled signal: for a residual r, the next visit to this
bin will place the largest item <= r if any such item arrives, otherwise it
will be skipped.  We estimate, via the running empirical survival function,
the expected leftover r - E[largest item <= r | some item <= r arrives], and
prefer residuals whose leftover is small.  This naturally rewards residuals
that equal a frequent item size (perfect future seal) and penalizes residuals
that sit just below common sizes (leaving a big stranded remainder).

Kept as secondary terms: a strong bonus for an exact seal (residual 0), and
the standard best-fit ordering so the rule never strays far from best fit.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins
    res = residual.astype(np.float64)

    total = float(_seen)

    # Best-fit core: the fuller the bin after placing, the smaller the residual.
    score = -res * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 60.0

    if _seen > 1:
        # Empirical histogram of past items. Counts up to 100.
        h = _hist.astype(np.float64)
        # Distribution restricted to sizes <= r for the current residual.
        # For each residual r we want the mean of items <= r weighted by count.
        counts = h[:101]  # index 1..100 meaningful
        # prefix count and prefix sum over sizes
        pref = np.zeros(101, dtype=np.float64)
        pref[1:] = np.cumsum(counts[1:])
        sizes = np.arange(101, dtype=np.float64)
        psum = np.zeros(101, dtype=np.float64)
        psum[1:] = np.cumsum(counts[1:] * sizes[1:])

        r_int = np.clip(residual, 0, 100)

        # For each shown bin, count of past items <= r_int and their mean.
        cnt_le = pref[r_int]
        sum_le = psum[r_int]
        with np.errstate(invalid="ignore", divide="ignore"):
            mean_le = np.where(cnt_le > 0, sum_le / np.maximum(cnt_le, 1.0), 0.0)

        # Probability that at least one future item <= r arrives.
        p_fit = cnt_le / total  # rough: fraction of items that fit

        # Expected leftover if a fitting item does arrive: r - mean of items <= r.
        leftover = res - mean_le
        leftover = np.maximum(leftover, 0.0)

        # Prefer small expected leftover, weighted by the chance a fit occurs.
        score -= leftover * p_fit * 35.0

        # Penalize residuals that no past item could ever fill (cnt_le == 0):
        # such bins are stranded for good unless a brand-new small item appears.
        stranded = (cnt_le == 0).astype(np.float64)
        score -= stranded * 20.0

    return score
# EVOLVE-BLOCK-END
