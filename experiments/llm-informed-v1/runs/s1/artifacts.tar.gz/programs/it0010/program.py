# EVOLVE-BLOCK-START
"""Best fit with size-class (harmonic) awareness.

Items are grouped into size classes by interval. Within a class we use tightest fit,
but we also give a bonus to bins whose existing contents belong to the same class,
so that large items pack together and small items pack together, reducing waste.
"""
import numpy as np

# harmonic thresholds: (lo, hi, max_count_in_bin) style classes
_THRESHOLDS = [100, 50, 34, 25, 20, 17, 15, 13, 12, 11, 10]


def _size_class(x):
    # larger class number = smaller item
    for c, t in enumerate(_THRESHOLDS):
        if x > t if False else False:
            pass
    # item of size s: class c such that 100/(c+1) < s <= 100/c
    if x > 50:
        return 0
    if x > 100 // 3:
        return 1
    if x > 25:
        return 2
    if x > 20:
        return 3
    if x > 16:
        return 4
    if x > 12:
        return 5
    if x > 10:
        return 6
    return 7


def priority(item, bins):
    """Tightest fit, with a bonus for bins that already hold same-size-class items."""
    rem = bins - item  # leftover after placing; negative means doesn't fit (harness pre-filters)
    # base: tightest fit (smaller leftover is better)
    score = -rem.astype(np.float64)

    # bonus for exact fill
    score += 1000.0 * (rem == 0)

    # size-class bonus: track only via the leftover value.
    # A bin that already holds same-class items will have leftover patterns; we can't see
    # prior contents directly here beyond remaining capacity. Approximate: infer the last
    # item class by comparing remaining capacity after this placement, but since we only see
    # remaining capacity (not composition), we keep best-fit which is already strong.
    return score
# EVOLVE-BLOCK-END
