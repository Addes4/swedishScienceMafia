# EVOLVE-BLOCK-START
"""Best-fit with distribution-aware residue quality.

Sizes come from a fixed Weibull-like distribution (mean ~40).  Pure best fit
is a strong core but leaves residues that no future item can use and rarely
rebalances toward residues that future items can exactly fill.

Rule: score = -residual (best fit), plus:
  * large reward for residual == 0 (perfect seal),
  * small penalty for positive residues below the empirical 15th percentile
    (hard to fill, near-wasteful),
  * modest reward proportional to the empirical exact-fill mass at the residue.
Weights are kept small relative to the 1.0 best-fit slope so ranking stays
close to best fit while breaking ties toward reusable residues.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    # Empirical 15th percentile of item sizes from cumulative histogram.
    target = 0.15 * total
    cum = 0.0
    p15 = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            p15 = s
            break

    idx = np.clip(residual, 0, 100)
    # Empirical mass at the exact residual size (chance of an exact fill).
    fill_mass = _hist[idx].astype(np.float64) / total

    # Best-fit core.
    score = -residual.astype(np.float64)

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize positive residues too small to accept almost any future item.
    too_small = ((residual > 0) & (residual < p15)).astype(np.float64)
    score -= too_small * 25.0

    # Reward residues a future item can exactly fill.
    score += fill_mass * 25.0

    return score
# EVOLVE-BLOCK-END

