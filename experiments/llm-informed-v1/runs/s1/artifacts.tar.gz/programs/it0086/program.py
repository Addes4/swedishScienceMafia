# EVOLVE-BLOCK-START
"""Best fit with empirical match-quality scoring.

Best fit is near-optimal for online bin packing under a near-continuous size
distribution; its weakness is stranding residuals that no realistically small
future item can use. We keep the full packing state and an empirical histogram
of item sizes seen so far. Instead of ad-hoc thresholds, we score each placement
by how *seamless* the resulting bin is: we reward exactly-filled bins and bins
whose residual matches a common future item size (so the bin is likely to be
closed later, as in harmonic-style "match-and-seal"), while always keeping
tightest-fit as the dominant term.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0

    score = -residual.astype(np.float64)

    # "match-and-seal": how likely is this residual to be filled by a future
    # item? Use frequency of sizes close to the residual, weighted so that
    # smaller residuals (closer to closure) get the most credit.
    h = _hist.astype(np.float64)
    total = float(_seen) if _seen > 0 else 1.0
    freq = h / total

    # local mass of item sizes near each residual value
    # build cumulative to compute window mass in [r-2, r+2] cheaply per residual
    for idx in range(len(residual)):
        r = residual[idx]
        if r <= 0:
            continue
        lo = r - 2
        hi = r + 2
        if lo < 1:
            lo = 1
        if hi > 100:
            hi = 100
        mass = freq[lo:hi + 1].sum()
        # weight: nearer-perfect bins benefit more from a likely match
        score[idx] += mass * (100.0 - r) * 0.05

    # exact fill: never harmful, strongly rewarded
    score += (residual == 0).astype(np.float64) * 50.0

    return score
# EVOLVE-BLOCK-END

