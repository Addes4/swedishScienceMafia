# EVOLVE-BLOCK-START
"""Best-fit with a residual-efficacy tiebreak driven by a running size histogram."""
import numpy as np

_state = {"hist": None, "n_seen": 0}

def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Maintain a coarse histogram of observed item sizes (1..100), with a smooth prior.
    h = _state["hist"]
    if h is None:
        h = np.ones(101, dtype=np.float64)
        _state["hist"] = h
    if 1 <= item <= 100:
        h[item] += 1.0
    _state["n_seen"] += 1

    # Probability mass of each possible next item size (normalized).
    total = h.sum()
    p = h / total  # index 1..100 used; p[0] negligible

    residual = bins - item

    # Base: best-fit (tighter is better).
    score = -residual.astype(np.float64)

    # Add a small bonus proportional to the chance that this residual can be
    # exactly filled or usefully continued by a future item of matching size.
    # We look up p[residual] for residual in 1..100.
    r = residual.astype(np.int64)
    fill = np.zeros_like(score)
    valid = (r >= 1) & (r <= 100)
    fill[valid] = p[r[valid]] * 100.0  # scale into comparable range

    # De-prioritize leaving dead space of size 5..19 that no typical item can use well.
    dead = np.zeros_like(score)
    small = (r >= 1) & (r <= 19)
    dead[small] = 0.5

    return score + fill - dead
# EVOLVE-BLOCK-END
