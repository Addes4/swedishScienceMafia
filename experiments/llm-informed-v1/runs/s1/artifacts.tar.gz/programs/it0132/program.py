# EVOLVE-BLOCK-START
"""Distribution-aware best fit.

Core idea: prefer the tightest bin (best fit), because small residuals keep
options open.  But a residual that is below the smallest item ever seen is
dead weight, and a residual that exactly matches a frequent future item size
is very valuable because it closes the bin.  We fold both signals into one
smooth score using the empirical item-size distribution seen so far.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_cum = None


def _init(n):
    global _n_items, _seen, _residuals, _hist, _cum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _cum = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0
    total = max(_seen, 1)

    # Smoothed empirical mass of exact fills for each residual value.
    exact_mass = _hist[np.clip(residual, 0, 100)].astype(np.float64) / total

    # Smallest item size seen so far: residual below this is likely useless.
    nz = np.nonzero(_hist)[0]
    if nz.size:
        lo = nz[0]
    else:
        lo = 1

    score = -residual.astype(np.float64)        # best-fit core
    score += (residual == 0).astype(np.float64) * 120.0  # exact close
    score += exact_mass * 60.0                   # dense-fill bonus
    # penalize residuals that fall below the smallest observed item size
    dead = (residual < lo) & (residual > 0)
    score -= dead.astype(np.float64) * 50.0

    return score
# EVOLVE-BLOCK-END
