# EVOLVE-BLOCK-START
"""Best-fit with a light empirical-mass tie-break.

Pure best fit is already near-optimal for this distribution (mean ~40).  The
only real loss comes from leaving residuals that no future item can exactly
fill, so we keep best-fit as the dominant term and add a small, stable bonus
for residuals whose size has high empirical mass (likely to be sealed by a
future item), plus a mild penalty for leaving a residual too tiny to accept
almost any future item.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for the shown bins

    total = max(_seen - 1, 1)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total

    r = residual.astype(np.float64)

    # Best-fit core dominates.
    score = -r

    # Reward residuals likely to be exactly sealed by a future item.
    score += fill_mass * 30.0

    # Perfect seal is strongly good.
    score += (residual == 0).astype(np.float64) * 50.0

    # Mild penalty for leaving residuals too small to accept most items.
    too_small = ((residual > 0) & (residual < 10)).astype(np.float64)
    score -= too_small * 15.0

    return score
# EVOLVE-BLOCK-END
