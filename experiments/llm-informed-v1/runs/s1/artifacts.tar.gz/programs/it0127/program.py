# EVOLVE-BLOCK-START
"""Viable-window best fit.

Best fit alone strands bins with residuals too small to ever be filled again.
Since sizes come from a fixed distribution with mean ~40, residuals in the
range [low_quantile, mean] are both (a) large enough that some typical future
item can still land there, and (b) small enough to keep bins dense.  We pick,
among bins the item fits in, the one whose resulting residual lies in that
viable window, preferring the LARGEST such residual (to preserve slack), and
fall back to best fit otherwise.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    total = _seen
    # empirical low quantile (~size no future item will fit below)
    target = 0.10 * total
    cum = 0
    q10 = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            q10 = s
            break

    # empirical mean as upper bound of the viable window
    size_sum = 0
    for s in range(1, 101):
        size_sum += s * _hist[s]
    mean = size_sum / total if total else 40.0

    lo = q10
    hi = max(lo, mean)

    in_window = (residual >= lo) & (residual <= hi)

    score = np.full(n, -1e6, dtype=np.float64)

    # Preferred: viable window, prefer larger residual (keep slack).
    if np.any(in_window):
        score[in_window] = residual[in_window].astype(np.float64)
    else:
        # No viable fit: exact fill is best; otherwise best fit (smallest residual).
        exact = residual == 0
        score = np.where(exact, 1e6 + residual.astype(np.float64),
                         -residual.astype(np.float64))

    # Exact fill is always excellent.
    score = np.where(residual == 0, score + 1e6, score)

    return score
# EVOLVE-BLOCK-END
