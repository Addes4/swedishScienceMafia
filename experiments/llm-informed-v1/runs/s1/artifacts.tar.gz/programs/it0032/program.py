# EVOLVE-BLOCK-START
"""Target-residual rule: aim to leave each bin with a residual near the mean item size."""
import numpy as np

_mu = 100.0 * 0.4  # running estimate of mean item size, updated online


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mu
    # Update running mean of item sizes (exponential-ish: simple running average).
    _mu += (item - _mu) * 0.001

    residual = bins - item  # >= 0 for all bins shown
    # Prefer residuals close to the mean item size: not so tight that the bin is dead,
    # not so large that we waste. Score = -(distance to target).
    target = _mu
    return -np.abs(residual - target)
# EVOLVE-BLOCK-END

