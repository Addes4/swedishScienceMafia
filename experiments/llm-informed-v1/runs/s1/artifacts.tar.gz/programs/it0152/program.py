# EVOLVE-BLOCK-START
"""Best-fit core with a principled future-fit value term.

Pure best fit strands small residuals that no future item can fill.  Since
sizes come from a fixed distribution, we can estimate, from the items seen so
far, the probability that *some* future item fits (i.e. is <=) a given residual
r.  A bin is valuable if its residual is exactly fillable now (r == 0) or if it
can still absorb likely future items.  We combine that value with the best-fit
core, and scale the value term by the fraction of the instance remaining so the
endgame is packed tightly.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in
    residual_f = residual.astype(np.float64)

    total = float(_seen)
    # Fraction of the instance already seen (0..1).
    frac_seen = total / float(_n_items) if _n_items else 0.0
    remaining_frac = 1.0 - frac_seen

    # Empirical CDF: P(size <= r) computed for every residual in one shot.
    # cum[r] = sum_{s<=r} hist[s].  We build the cumulative array cheaply.
    cum = np.cumsum(_hist)  # length 101
    r_idx = np.clip(residual, 0, 100)
    # Probability that a random item fits into residual r.
    fit_prob = cum[r_idx].astype(np.float64) / total

    # Exact-fill probability for the resulting residual.
    exact = (_hist[r_idx].astype(np.float64) / total)

    score = -residual_f  # best-fit core

    # Value term: a bin whose residual can absorb likely future items is worth
    # keeping compact; reward high fit-probability for nonzero residuals and
    # reward exact fills strongly.  Scale by remaining share of the instance.
    score += remaining_frac * 60.0 * fit_prob
    score += 120.0 * ((residual == 0).astype(np.float64))
    score += remaining_frac * 40.0 * exact

    return score
# EVOLVE-BLOCK-END
