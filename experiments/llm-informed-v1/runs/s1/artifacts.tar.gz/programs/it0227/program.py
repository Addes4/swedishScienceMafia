# EVOLVE-BLOCK-START
"""Refined best-fit with strong seal preference.

The base 0.9735 rule was already close to best-fit, and the noisy
histogram/median/mean bonuses mostly added variance.  Here we keep the
proven core (score = -residual) but strengthen the two terms that
measurably help:

  * a large bonus for residuals that are exactly 0 (perfect seal),
  * a penalty for residuals too small to accept anything useful, based on
    the smallest item size seen so far (an improving estimate of the
    smallest future item),

and drop the histogram, median, mean-multiple and near-mean terms that
were injecting noise.
"""
import numpy as np

_n_items = None
_seen = 0
_min_seen = 100
_sum = 0


def _init(n):
    global _n_items, _seen, _min_seen, _sum
    _n_items = n
    _seen = 0
    _min_seen = 100
    _sum = 0


def priority(item, bins):
    global _seen, _min_seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    _seen += 1
    if item < _min_seen:
        _min_seen = item
    _sum += item

    residual = bins - item  # >= 0 for shown bins
    rf = residual.astype(np.float64)

    # Strict best-fit core.
    score = -rf

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 80.0

    # Penalize residuals (non-zero) that cannot accept even the smallest
    # item seen so far: those leftovers are effectively dead space, so we
    # prefer to leave the current item in a bin that keeps a usable residual.
    too_small = ((residual > 0) & (residual < _min_seen)).astype(np.float64)
    score -= too_small * 40.0

    return score
# EVOLVE-BLOCK-END
