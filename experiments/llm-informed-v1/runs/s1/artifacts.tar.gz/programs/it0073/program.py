# EVOLVE-BLOCK-START
"""Best fit with a quantile-based reusability floor.

Best fit (smallest remaining capacity that still fits) is near-optimal online under a
near-continuous size distribution. Its weakness is stranding tiny residuals no future
item can use. We keep the full packing state and an empirical size histogram, and we
estimate an online low quantile (the size below which a small fraction of items fall)
as the "smallest item we plausibly still expect". Residuals below that floor are
effectively dead space, so we nudge away from creating them without disturbing the
best-fit ordering among useful residuals.
"""
import numpy as np

# --- persistent state (fresh process per instance) ---
_n_items = None          # number of items in the instance
_seen = 0                # items seen so far
_residuals = None        # remaining capacity of every bin, indexed by bin order
_hist = None             # counts of item sizes, index 0..100
_floor = 1               # online-estimated low quantile of item sizes
_quantile = 0.05         # fraction of items considered "small"


def _init(n):
    global _n_items, _seen, _residuals, _hist, _floor
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _floor = 1


def _estimate_floor():
    """Size below which roughly `_quantile` of seen items fall (robust low quantile)."""
    total = _hist.sum()
    if total < 20:
        return 1
    target = total * _quantile
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    global _seen, _floor

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _floor = _estimate_floor()

    floor = _floor
    residual = bins - item  # >= 0 for all bins shown

    # Best fit: smallest residual first => highest score.
    score = -residual.astype(np.float64)

    # Bonus when the leftover is large enough to be usable by a plausibly small future
    # item. Magnitude < 1 so it only breaks near-ties without reordering distinct
    # best-fit levels.
    usable = residual >= floor
    score += usable.astype(np.float64) * 0.9

    # Exact fills are strictly good: give a slightly stronger nudge.
    score += (residual == 0).astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
