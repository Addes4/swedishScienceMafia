# EVOLVE-BLOCK-START
"""Distribution-aware best fit with density-weighted residual desirability.

Core: best fit (smaller resulting residual is better).
Refinement: reward residuals according to how densely items of the empirical
size distribution can be packed into them.  A residual r is desirable in
proportion to the expected number of future items that fit inside it, capped,
which naturally prefers residuals that are "just above" common size classes
rather than tiny unusable slivers.  An exact-fill bonus handles residuals
that can be perfectly completed.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    total = max(_seen, 1)
    idx = np.clip(residual, 0, 100)
    exact_mass = _hist[idx].astype(np.float64) / total

    # Density desirability: mass of items that fit inside a residual of size r,
    # normalized by total items seen.  Larger residual -> more future items fit,
    # but we prefer the SMALLEST such residual (best-fit core handles that).
    cum = np.cumsum(_hist) / total  # cum[s] = P(size <= s)
    fit_mass = cum[idx]  # probability a random past item fits in residual

    score = -residual.astype(np.float64)         # best-fit core
    score += (residual == 0).astype(np.float64) * 60.0   # exact completion
    score += fit_mass * 20.0                      # fillable residual bonus
    score += exact_mass * 30.0                    # frequent-size residual bonus

    return score
# EVOLVE-BLOCK-END
