# EVOLVE-BLOCK-START
"""Balanced placement with empirical viability threshold.

Instead of best fit (which fills residuals to the brim and then strands them),
place each item into the *most loaded* bin that still has room to breathe: the
bin whose resulting residual is as small as possible while staying at or above
an adaptive threshold.  The threshold is derived from the empirical size
distribution seen so far, so the rule adapts to the Weibull shape without
tuning to any particular instance.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    # Track which bins are "open" (used at least once) for accounting.
    # A bin is open if its remaining capacity is < 100.
    residual = bins - item  # >= 0 for bins the item fits in
    score = -residual.astype(np.float64)

    # Empirical small-item quantiles: residuals below q10 are likely wasted.
    q10 = _quantile(0.10)

    # Prefer residuals that remain >= q10 (still usable by a small future item)
    # but among those, prefer the smallest (denser packing).
    usable = (residual >= q10) & (residual > 0)
    score += usable.astype(np.float64) * 30.0

    # Exact fills are always good.
    score += (residual == 0).astype(np.float64) * 60.0

    return score
# EVOLVE-BLOCK-END
