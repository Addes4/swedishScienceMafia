# EVOLVE-BLOCK-START
"""Best fit with quantile-aware residual scoring.

Pure best fit (smallest post-placement residual) is near-optimal here. Its only
systematic weakness is stranding tiny residuals that no future item can use.
We track an empirical histogram of item sizes and lightly penalize residuals
that fall below a low quantile of the observed size distribution, while
rewarding exact fills so true perfect fits still win ties.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1

    q05 = _quantile(0.05)

    residual = (bins - item).astype(np.float64)  # >= 0

    # primary: smallest residual (best fit)
    score = -residual

    # penalty for stranding residuals too small for any plausible future item
    # (only when not an exact fill). Keep it small so it breaks ties, not
    # overrides clearly better fits.
    dead = (residual > 0) & (residual < q05)
    score -= dead.astype(np.float64) * 0.5

    # tiny bonus for exact fills so perfect fits are never avoided
    score += (residual == 0).astype(np.float64) * 0.25

    return score
# EVOLVE-BLOCK-END
