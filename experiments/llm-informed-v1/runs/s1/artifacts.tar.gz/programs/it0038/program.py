# EVOLVE-BLOCK-START
"""Best fit with a light stateful nudge away from creating low-value residuals."""
import numpy as np

_state = {"sum": 0.0, "n": 0, "resid_ok": {}}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    s = _state
    n = s["n"]
    if n == 0:
        mean = 40.0
    else:
        mean = s["sum"] / n

    resid = bins - item

    # Best-fit base score: higher means the residual after placement is smaller.
    score = -resid.astype(np.float64)

    # Penalize residuals that are too small to be useful when the item is large
    # enough that a "good fit" could still be achieved elsewhere.
    if item >= mean:
        dead = resid < 0.5 * mean
        score += dead * (-0.5)

    # Track stats after deciding.
    best = int(np.argmax(score))
    chosen_resid = int(bins[best]) - item
    s["sum"] += item
    s["n"] = n + 1
    # Record whether this residual could still take at least a small item.
    key = chosen_resid
    cnt = s["resid_ok"].get(key, [0, 0])
    cnt[0] += 1
    if chosen_resid >= 1:
        cnt[1] += 1
    s["resid_ok"][key] = cnt

    return score
# EVOLVE-BLOCK-END

