# EVOLVE-BLOCK-START
"""Competitive best-fit with future-fill viability.

Pure best fit leaves a few bins with tiny residuals that no future item can
ever use, and it never rebalances toward bins that can still accept typical
items.  Since sizes come from a fixed Weibull-like distribution (mean ~40),
a residual is *useful* only if some future item fits it, and it is *valuable*
if future items are likely to exactly fill it.

This rule keeps best-fit as the core (score = -residual) but:
  * penalizes residuals below the empirical median item size,
  * rewards residuals whose size has high empirical histogram mass,
  * gives a strong reward for residuals that equal 0 (perfect seal),
  * nudges residuals toward multiples of the running mean item size so
    future items can stack into them.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)
    mean = _sum / _seen

    # Empirical median item size (approx) via cumulative histogram.
    target = 0.5 * total
    cum = 0.0
    median = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            median = s
            break

    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    cum_hist = np.cumsum(_hist).astype(np.float64) / total
    fit_mass = cum_hist[idx]

    # Best-fit core.
    score = -residual.astype(np.float64) * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize residuals too small to accept a typical (median) item,
    # but only if they are not a perfect seal.
    too_small = ((residual > 0) & (residual < median)).astype(np.float64)
    score -= too_small * 35.0

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 30.0

    # Reward residuals that admit at least some future item (flexibility).
    score += fit_mass * 8.0

    # Nudge residuals toward multiples of the running mean so that future
    # items can stack into them.
    if mean > 0:
        mult = np.round(residual.astype(np.float64) / mean)
        mult = np.maximum(mult, 0.0)
        waste = np.abs(residual.astype(np.float64) - mult * mean)
        score -= waste * 0.15

        # Bonus for residuals near the running mean.
        near_mean = np.abs(residual.astype(np.float64) - mean)
        score += np.maximum(0.0, 12.0 - near_mean) * 0.5

        # Bonus for residuals just above the mean.
        above = residual.astype(np.float64) - mean
        just_above = (above > 0) & (above <= 6.0)
        score += just_above.astype(np.float64) * 1.5

        # Waste-aware term: penalize residuals whose residual-minus-mean is a
        # small positive leftover (a typical future item would strand a tiny
        # unusable remainder). Discourage leaving such bins around.
        leftover = above
        stranded = (leftover > 0) & (leftover < median)
        score -= stranded.astype(np.float64) * 4.0

    return score
# EVOLVE-BLOCK-END
