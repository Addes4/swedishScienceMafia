# EVOLVE-BLOCK-START
"""Competitive best-fit with future-fill viability.

Pure best fit leaves a few bins with tiny residuals that no future item can
ever use, and it never rebalances toward bins that can still accept typical
items.  Since sizes come from a fixed Weibull-like distribution (mean ~40),
a residual is *useful* only if some future item fits it, and it is *valuable*
if future items are likely to exactly fill it.

This rule keeps best-fit as the core (score = -residual) but:
  * rewards residuals that equal 0 (perfect seal),
  * penalizes residuals below the running mean (too small for a typical item),
  * rewards residuals that admit at least some future item,
  * rewards residuals whose value has empirical histogram mass.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen, 1)
    mean = _sum / total

    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    cum_hist = np.cumsum(_hist).astype(np.float64) / total
    fit_mass = cum_hist[idx]

    r = residual.astype(np.float64)

    # Best-fit core.
    score = -r * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize residuals too small to accept a typical (mean-sized) item,
    # but only if they are not a perfect seal.
    too_small = ((residual > 0) & (r < mean)).astype(np.float64)
    score -= too_small * 25.0

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 30.0

    # Reward residuals that admit at least some future item (flexibility).
    score += fit_mass * 8.0

    # Single mean-item completion: if we place a mean-sized item here, the
    # leftover is residual - mean.  A good residual leaves a leftover that is
    # either zero (exact) or large enough to still admit an item; a bad one
    # leaves a small useless sliver.  Reward residuals whose leftover after
    # one mean item is useful.
    if mean > 0:
        leftover = r - mean
        useful = (leftover >= mean) | (np.abs(leftover) < 1e-9)
        sliver = (leftover > 1e-9) & (leftover < mean)
        score += useful.astype(np.float64) * 6.0
        score -= sliver.astype(np.float64) * 6.0

    return score
# EVOLVE-BLOCK-END
