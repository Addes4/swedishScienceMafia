# EVOLVE-BLOCK-START
"""Best-fit with seal bonus and unusable-residual penalty.

Core intuition: bin packing with random items is near-optimal under best fit
(place item into the fullest bin that still fits, i.e. smallest remaining
capacity). Two corrections matter:

  * A residual of exactly 0 is a perfect seal: strong reward.
  * A residual below the smallest item size seen so far can never be used
    again (given observed support), so strand it less eagerly: penalize it.

State kept: histogram of item sizes, running min, running mean, count.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_sum = 0
_min_item = 101


def _init(n):
    global _n_items, _seen, _hist, _sum, _min_item
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _min_item = 101


def priority(item, bins):
    global _seen, _sum, _min_item

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item
    if item < _min_item:
        _min_item = item

    residual = bins - item  # >= 0 for shown bins
    res = residual.astype(np.float64)

    total = max(_seen - 1, 1)
    mean = _sum / _seen

    # Best-fit core.
    score = -res

    # Perfect seal.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize residuals too small to accept even the smallest item ever seen.
    if _min_item <= 100:
        too_small = ((residual > 0) & (residual < _min_item)).astype(np.float64)
        score -= too_small * 40.0

    # Reward residuals that admit at least some future item (flexibility),
    # weighted by the empirical mass of item sizes <= residual.
    if _seen > 1:
        cum = np.cumsum(_hist).astype(np.float64) / total
        idx = np.clip(residual, 0, 100)
        score += cum[idx] * 6.0

        # Nudge residuals toward multiples of the running mean.
        if mean > 0:
            mult = np.round(res / mean)
            mult = np.maximum(mult, 0.0)
            waste = np.abs(res - mult * mean)
            score -= waste * 0.12

    return score
# EVOLVE-BLOCK-END
