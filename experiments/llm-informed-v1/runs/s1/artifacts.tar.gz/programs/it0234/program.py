# EVOLVE-BLOCK-START
"""Clean best-fit with a light exact-fill bonus.

The dominant, reliable signal is best fit: put the item into the bin with the
smallest residual that accepts it.  This minimizes leftover space locally and
is a strong, stable heuristic.  The only extra nudge kept is a small bonus for
residuals that a typical future item is likely to exactly fill, estimated from
a running (laplace-smoothed) frequency table of sizes seen so far.  All the
heavier overlays (median penalty, mean-multiple nudges, horizon-scaled seal
bonuses) measured worse, so they are removed.
"""
import numpy as np

_n_items = None
_seen = 0
_counts = None


def _init(n):
    global _n_items, _seen, _counts
    _n_items = n
    _seen = 0
    _counts = np.zeros(101, dtype=np.float64)
    _counts[1:] = 1.0  # laplace smoothing


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _counts is None:
        _init(n)

    _seen += 1
    _counts[item] += 1.0

    residual = bins - item  # >= 0 for the bins shown

    # Best-fit core: prefer the smallest residual.
    score = -residual.astype(np.float64)

    # Light bonus: residuals likely to be exactly filled by a future item.
    total = _counts.sum()
    idx = np.clip(residual, 0, 100)
    fill_mass = _counts[idx] / total
    score += fill_mass * 12.0

    return score
# EVOLVE-BLOCK-END
