# EVOLVE-BLOCK-START
"""Best-fit with exact-seal targeting.

The strongest signal for reducing bin count is best fit itself: among the bins
the item fits in, choose the one with the smallest residual.  That core is kept
as the dominant term.  On top of it we add a smooth, distribution-aware bonus
for residuals that a future item can exactly fill, and a mild penalty for
residuals below the smallest item seen so far (which no future item can use).

Unlike earlier attempts with heavy hand-tuned constants, the bonuses here are
kept small relative to the integer best-fit step so they only break near-ties
between bins competing at essentially the same residual, never overriding a
strictly better fit.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_min_seen = 100


def _init(n):
    global _n_items, _seen, _hist, _min_seen
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _min_seen = 100


def priority(item, bins):
    global _seen, _min_seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None or len(_hist) != 101:
        _init(n)

    _seen += 1
    _hist[item] += 1
    if item < _min_seen:
        _min_seen = item

    residual = bins - item  # >= 0 for shown bins
    res_f = residual.astype(np.float64)

    total = max(_seen - 1, 1)

    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total

    # Best-fit core: dominant term, unit step per capacity unit.
    score = -res_f

    # Reward residuals matching a frequently observed item size, so a future
    # item can exactly seal the bin.  Magnitude < 1 so it only breaks ties
    # among equal-residual bins (but residuals are distinct here, so it acts
    # as a smooth secondary preference weighted by historical frequency).
    score += fill_mass * 0.9

    # Penalize unusable tiny residuals (positive but below any item seen).
    too_small = ((residual > 0) & (residual < _min_seen)).astype(np.float64)
    score -= too_small * 0.5

    # Perfect seal: reward strongly but still below a full unit of best fit.
    score += (residual == 0).astype(np.float64) * 0.95

    return score
# EVOLVE-BLOCK-END
