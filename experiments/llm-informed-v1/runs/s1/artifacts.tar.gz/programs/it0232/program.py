# EVOLVE-BLOCK-START
"""Best-fit core with a frequency-weighted perfect-seal bonus.

Strict best fit (score = -residual) is the strongest simple online rule and
keeps residuals as small as possible, which maximizes the chance that some
future item exactly seals a bin.  To sharpen that effect we add a bonus for a
residual whose size has high empirical mass, i.e. residuals that exactly match
a commonly-seen item size and are therefore very likely to be sealed later.
The bonus is computed cheaply with np.bincount over the running histogram.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_bonus_table = None
_rebuild = 0


def _init(n):
    global _n_items, _seen, _hist, _bonus_table, _rebuild
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _bonus_table = np.zeros(101, dtype=np.float64)
    _rebuild = 0


def priority(item, bins):
    global _seen, _rebuild, _bonus_table

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None or len(_hist) != 101:
        _init(n)

    _seen += 1
    _hist[item] += 1

    # Refresh the bonus table only occasionally to keep per-call cost low.
    if _seen == 1 or _seen - _rebuild >= 20:
        _rebuild = _seen
        total = max(_seen, 1)
        freq = _hist.astype(np.float64) / total
        # Bonus proportional to probability a future item exactly fills r.
        _bonus_table = freq * 20.0

    residual = bins - item  # >= 0 for shown bins

    score = -residual.astype(np.float64)

    idx = np.clip(residual, 0, 100)
    score += _bonus_table[idx]

    # Perfect seal dominates: closing a bin is always best.
    score += (residual == 0).astype(np.float64) * 50.0

    return score
# EVOLVE-BLOCK-END
