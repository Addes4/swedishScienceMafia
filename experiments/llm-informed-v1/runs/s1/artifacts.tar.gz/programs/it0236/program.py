# EVOLVE-BLOCK-START
"""Best-fit core with a two-item fill-viability bonus.

Pure best fit closes bins greedily but strands residuals that no single future
item can use exactly.  Items come from a fixed Weibull-like distribution
(mean ~40), so residual usefulness is about *combinatorial* fillability: a
residual r is valuable if some small combination of typical future items can
seal it.  In particular residuals achievable as the sum of two common item
sizes are prime targets late in an instance, and this rule rewards them while
keeping the proven best-fit / perfect-seal structure intact.

Score components (all cheap, numpy vectorized, O(100) per call):
  * -residual                     : best-fit core
  * +60 for residual == 0         : perfect seal
  * -35 for 0 < residual < median : too small for a typical item
  * +30 * P(fill by one item)     : smoothed single-item fill mass
  * +14 * P(fill by two items)    : smoothed two-item fill mass (convolution)
  * +6  * P(fill by some item)    : flexibility (cumulative mass)
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0
_two_mass_cache = None
_two_mass_seen = -100000


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum
    global _two_mass_cache, _two_mass_seen
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _two_mass_cache = None
    _two_mass_seen = -100000


def _smoothed_pmf():
    """Normalized, lightly smoothed distribution over sizes 1..100."""
    h = _hist.astype(np.float64)
    # Smooth with a small triangular kernel to avoid zero-mass holes.
    k = np.array([0.05, 0.1, 0.2, 0.3, 0.2, 0.1, 0.05])
    padded = np.concatenate([np.zeros(3), h, np.zeros(3)])
    sm = np.convolve(padded, k, mode="valid")
    tot = sm.sum()
    if tot <= 0:
        sm = np.ones(101)
        tot = sm.sum()
    return sm / tot


def _two_item_mass():
    """Probability mass of residual r as sum of two item sizes (1..100)."""
    global _two_mass_cache, _two_mass_seen
    if _two_mass_cache is not None and _seen - _two_mass_seen < 25:
        return _two_mass_cache
    pmf = _smoothed_pmf()  # length 101, index = size
    # Convolve sizes 1..100 -> sums 2..200; take first 101 entries (0..100).
    conv = np.convolve(pmf[1:101], pmf[1:101], mode="full")  # len 199
    full = np.zeros(201)
    full[2:201] = conv
    _two_mass_cache = full[:101]
    _two_mass_seen = _seen
    return _two_mass_cache


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    # Running median item size, cheaply via cumulative counts + searchsorted.
    cum = np.cumsum(_hist).astype(np.float64)
    target = 0.5 * total
    pos = np.searchsorted(cum, target)
    median = min(max(int(pos) + 1, 1), 100)

    pmf = _smoothed_pmf()

    idx = np.clip(residual, 0, 100)

    # Best-fit core.
    score = -residual.astype(np.float64)

    # Perfect seal.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize residuals too small for a typical (median) item.
    too_small = ((residual > 0) & (residual < median)).astype(np.float64)
    score -= too_small * 35.0

    # Single-item fill mass (smoothed) reward.
    score += pmf[idx] * 30.0

    # Two-item fill mass reward: residuals sealable by two typical items.
    two = _two_item_mass()
    score += two[idx] * 14.0

    # Flexibility: probability some item fits into the residual.
    cum_hist = np.cumsum(_hist).astype(np.float64)
    flex = (cum_hist[idx] / total)
    score += flex * 6.0

    return score
# EVOLVE-BLOCK-END
