# EVOLVE-BLOCK-START
"""Best-fit core with a smoothed exact-fill desirability bonus.

Items come from a fixed distribution (mean ~40).  The dominant way a bin
gets closed is when its residual is exactly matched by a later item.  So we
rank bins by a best-fit core (smaller resulting residual is better) plus a
bonus proportional to how likely the resulting residual is to be exactly
hit by a future item, estimated from the empirical size histogram with
Laplace smoothing.  Residual 0 is a completed bin and gets the top bonus.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.ones(101, dtype=np.float64)  # Laplace smoothing


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for bins the item fits in

    idx = np.clip(residual, 0, 100)
    # Smoothed empirical probability that some future item exactly matches
    # the resulting residual.
    p_exact = _hist[idx] / (_seen + 101.0)

    score = -residual.astype(np.float64)       # best-fit core
    score += p_exact * 120.0                    # reward likely-to-close bins
    score += (residual == 0).astype(np.float64) * 60.0  # completed bin

    return score
# EVOLVE-BLOCK-END
