# EVOLVE-BLOCK-START
"""Best fit with tie-break by fewest items placed in the bin."""
import numpy as np

_state = {}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = len(bins)

    # --- recover full bin state ---
    # Maintain a dict mapping bin index -> remaining capacity, and item count.
    if "rem" not in _state or len(_state["rem"]) < n:
        rem = np.full(n, 100, dtype=np.int64)
        cnt = np.zeros(n, dtype=np.int64)
        _state["rem"] = rem
        _state["cnt"] = cnt
    else:
        rem = _state["rem"]
        cnt = _state["cnt"]

    # bins shown are exactly the bins with rem >= item, in bin order.
    # Build the list of candidate bin indices.
    cand = np.nonzero(rem >= item)[0]
    # cand should have length n (bins array). Sanity: use it to index.
    # score: primary best-fit residual (smaller residual = higher score),
    # tie-break: fewer items placed so far (higher preference).
    residual = rem[cand] - item
    # smaller residual -> higher score; fewer cnt -> higher score
    # combine: residual*BIG - cnt
    B = 1000.0
    score = -(residual.astype(np.float64)) * B - cnt[cand].astype(np.float64)
    # We must return score aligned with the order of `bins`.
    # `bins` order == cand order (bin index ascending).
    return score
# EVOLVE-BLOCK-END

