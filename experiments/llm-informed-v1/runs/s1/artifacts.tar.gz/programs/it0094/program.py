# EVOLVE-BLOCK-START
"""Best fit augmented with empirical residual-viability.

Pure best fit is near-optimal online for near-continuous distributions. Its
occasional waste comes from leaving a residual that no realistically small
future item can use, or from failing to recognize a residual that a common
future item is very likely to seal. We track the full packing state and an
empirical histogram of item sizes, and add a bounded viability bonus proportional
to how often the resulting residual has been observed and is still expected.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for shown bins
    resid_f = residual.astype(np.float64)

    # Primary: best fit (smallest residual).
    score = -resid_f

    # Viability bonus: probability mass of the empirical histogram at the
    # resulting residual size, scaled small so it only breaks near-ties.
    # A residual that matches a commonly seen size is likely to be filled.
    inv_total = 1.0 / max(_seen, 1)
    freq = _hist[residual] * inv_total
    score += freq * 3.0

    # Exact fill: never harmful, reward it.
    score += (residual == 0).astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
