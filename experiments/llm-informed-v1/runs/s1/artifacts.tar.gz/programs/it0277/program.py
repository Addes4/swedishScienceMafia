# EVOLVE-BLOCK-START
"""Best-fit with a small "dead residual" tie-break.

Pure best fit is already near-optimal for this distribution.  The only
consistent loss is leaving tiny residuals (smaller than a typical future
item) that can never be filled, so those bins are effectively wasted space.
We keep best-fit as the dominant signal (score = -residual) and add a small
penalty for residuals below the running empirical median item size, which
only reshuffles near-ties in favour of residuals that future items can use.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_cum = None


def _init(n):
    global _n_items, _seen, _hist, _cum
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _cum = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    # Empirical median item size via cumulative histogram (cheap 100-step).
    target = 0.5 * total
    cum = 0.0
    median = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            median = s
            break

    r = residual.astype(np.float64)

    # Best-fit core.
    score = -r

    # Penalize residuals too small to accept a typical (median) item.
    # Keep this small so it acts mainly as a tie-breaker.
    too_small = ((residual > 0) & (residual < median)).astype(np.float64)
    score -= too_small * 5.0

    # Small reward for exact seals (residual 0) helps prefer them.
    score += (residual == 0).astype(np.float64) * 6.0

    return score
# EVOLVE-BLOCK-END
