# EVOLVE-BLOCK-START
"""Best fit with dead-residual avoidance.

Best fit (smallest remaining capacity that still fits) is near-optimal for online bin
packing under a near-continuous size distribution. Its weakness is stranding residuals
so small no future item can use them.

We track the full packing ourselves and keep the smallest item size observed so far as
a proxy for the smallest future item. Ranking is pure best-fit (smallest post-placement
residual wins), except: finishing a bin exactly (residual 0) is strongly preferred, and
leaving a residual in (0, floor) is slightly penalized because that leftover is very
likely dead space. Residuals >= floor keep their natural best-fit ordering.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_min_seen = 101
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _min_seen, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _min_seen = 101
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen, _min_seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    if item < _min_seen:
        _min_seen = item
    _hist[item] += 1

    floor = _min_seen if _min_seen <= 100 else 1

    residual = bins - item  # >= 0 for the bins shown

    score = -residual.astype(np.float64)

    # Prefer finishing a bin exactly (strictly good, reduces bin count).
    score += (residual == 0).astype(np.float64) * 1000.0

    # Penalize very small (likely dead) residuals in (0, floor).
    dead = (residual > 0) & (residual < floor)
    score -= dead.astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
