# EVOLVE-BLOCK-START
"""Best fit with exact-match-first tie-break.

Pure best fit (smallest resulting residual) is near-optimal for online bin
packing under a near-continuous size distribution.  The main avoidable loss
comes from delaying an exact fill: when the current item exactly equals some
bin's remaining capacity, placing it there closes the bin for free, whereas
placing it elsewhere strands that gap until (if ever) an identical item
arrives.  We therefore rank placements by (resulting residual) but add a
large bonus for a zero residual, and among nonzero residuals prefer the
placement whose *pre-placement* residual exactly matched the item size is
already covered by zero residual.  To keep balance we break remaining ties by
smallest residual, which is plain best fit.
"""
import numpy as np

_n_items = None
_residuals = None


def _init(n):
    global _n_items, _residuals
    _n_items = n
    _residuals = np.full(n, 100, dtype=np.int64)


def priority(item, bins):
    global _residuals

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    residual = bins - item  # >= 0, post-placement residual

    score = -residual.astype(np.float64)

    # Big bonus for closing the bin exactly (resulting residual == 0).
    score += (residual == 0).astype(np.float64) * 200.0

    return score
# EVOLVE-BLOCK-END
