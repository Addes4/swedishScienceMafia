# EVOLVE-BLOCK-START
"""Adaptive Best-Fit / Worst-Fit hybrid.

Large items and exact fits are placed by best fit (minimize resulting residual),
which packs tightly.  Small items -- which otherwise strand bins with tiny,
unusable residuals -- are spread across the emptiest bins that still have room
(worst fit), keeping larger residuals open for the large items that still need
them.  The switch point is the live empirical mean of seen item sizes, so the
rule tracks the Weibull shape of the instance without tuning.
"""
import numpy as np

_n_items = None
_seen = 0
_sum = 0.0
_hist = None


def _init(n):
    global _n_items, _seen, _sum, _hist
    _n_items = n
    _seen = 0
    _sum = 0.0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None or len(_hist) != 101:
        _init(n)

    _seen += 1
    _sum += item
    _hist[item] += 1

    mean = _sum / _seen
    residual = bins - item  # >= 0 for bins the item fits in
    resid = residual.astype(np.float64)

    # Exact fill: always take it.
    score = -resid
    score += (resid == 0).astype(np.float64) * 1000.0

    # For items that are small relative to the empirical mean, strand less:
    # prefer bins with the LARGEST resulting residual (worst fit) so the big
    # future items still have room.  Blend so that exact fills keep priority.
    if item < 0.6 * mean:
        # larger residual -> higher score; dominates the best-fit term
        score += resid * 2.0

    return score
# EVOLVE-BLOCK-END

