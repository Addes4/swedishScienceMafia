# EVOLVE-BLOCK-START
"""Best-fit with exact-fit tie-breaking.

The dominant signal is best-fit: score = -residual (smallest residual wins).
Among bins with equal (or near-equal) residual, prefer the bin whose resulting
residual has the highest empirical probability of being exactly filled by a
future item, since that leaves a bin that a later item can seal perfectly.

Sizes come from one fixed distribution, so the empirical histogram of item
sizes seen so far is a good estimate of future exact-fit probability.  The
tie-break is scaled small so it never overrides the best-fit core.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen, 1)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total

    # Best-fit core, strictly dominant.
    score = -residual.astype(np.float64) * 1000.0

    # Tie-break: prefer residuals likely to be exactly filled by a future item.
    score += fill_mass

    # Record this item for future histogram estimates.
    _hist[item] += 1

    return score
# EVOLVE-BLOCK-END
