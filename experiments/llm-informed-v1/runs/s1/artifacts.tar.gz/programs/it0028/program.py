# EVOLVE-BLOCK-START
"""Best-fit augmented with empirical fillability of the resulting residual.

We keep full state: the multiset of remaining capacities of all open bins. On each
arrival we simulate every candidate placement (using the true residual of every
open bin, not just the ones offered), and score a placement by how "fillable" the
resulting residual is under the empirical item-size distribution built so far.
A residual that can be exactly matched by a common item size is strongly preferred;
a residual below the smallest item seen is penalized as dead waste.
"""
import numpy as np

_state = {
    "residuals": None,   # dict bin_index -> remaining capacity (all open bins)
    "sizes": [],         # item sizes seen so far
    "n": 0,              # number of items seen
    "total": None,       # number of items in the instance
    "cap": 100,
}


def _refresh(bins):
    """Reconstruct residual map on first call or when length grows."""
    # bins contains every bin the current item fits in; length == number of items
    n = len(bins)
    if _state["residuals"] is None or _state["total"] != n:
        # First call of instance: all bins unused (remaining 100).
        _state["residuals"] = {}
        _state["total"] = n
        _state["sizes"] = []
        _state["n"] = 0


def priority(item, bins):
    _refresh(bins)
    res = _state["residuals"]
    sizes = _state["sizes"]
    cap = _state["cap"]

    bins = np.asarray(bins)

    # --- update our residual map from the bins we are shown -----------------
    # The harness gives us the remaining capacity of every bin the item fits in.
    # Bins we track that are NOT shown must have residual < item (didn't fit);
    # bins shown are authoritative. We do NOT know the index mapping cheaply,
    # so we maintain count-based multiset instead: reconcile by trusting shown
    # residuals for fitting bins and keeping tracked ones otherwise.
    # Simpler and robust: rebuild residual multiset from scratch each call is
    # too costly; instead track residuals keyed by bin position up to len(bins).
    #
    # Given the harness guarantees, bins[i] is the remaining capacity of bin i
    # *for the fitting bins*, i.e. it is a filtered view. To keep things exact we
    # maintain the residuals of ALL bins indexed by full bin index using the
    # fact that non-fitting bins keep their old value.

    if "all_res" not in _state or len(_state["all_res"]) != len(bins):
        # first call: all bins at capacity
        _state["all_res"] = [cap] * len(bins)

    all_res = _state["all_res"]

    # We must map the shown (filtered) residuals back to full indices. The harness
    # gives fitting bins in bin order; we can reconstruct by walking all bins and
    # assigning shown values to those positions whose tracked residual >= item.
    if _state["n"] > 0:
        shown = list(map(int, bins))
        k = 0
        for i in range(len(all_res)):
            if all_res[i] >= item:
                all_res[i] = shown[k]
                k += 1

    # --- scoring ------------------------------------------------------------
    m = len(bins)
    scores = np.empty(m, dtype=np.float64)

    # Build a cheap empirical "fillability" table of item sizes seen.
    if len(sizes) < 5:
        # fall back to best fit early on
        return -(bins.astype(np.float64) - item)

    arr = np.asarray(sizes, dtype=np.int64)
    # frequency of each size 1..100
    freq = np.bincount(arr, minlength=cap + 1).astype(np.float64)
    tot = freq.sum()
    # probability weights
    seen_min = int(arr.min())

    # For a resulting residual r, estimate P(fillable well) = how likely r is to
    # be exactly matched by a small combination, approximated by whether r is
    # itself a frequent item size, or can be split into two frequent sizes.
    # Precompute top sizes.
    top = np.argsort(freq)[::-1][:10]

    for j in range(m):
        r = int(bins[j]) - item
        if r == 0:
            scores[j] = 1e6  # perfect fill
            continue
        if r < seen_min:
            scores[j] = -1e6  # dead residual
            continue
        # reward if r is a frequent size (likely exact future fill)
        base = -float(r)
        bonus = 0.0
        if r <= cap and freq[r] > 0:
            bonus += 200.0 * (freq[r] / tot)
        # check two-size decomposition potential
        for s in top:
            s = int(s)
            if s <= 0 or s >= r:
                continue
            if freq[r - s] > 0:
                bonus += 60.0 * (freq[s] / tot) * (freq[r - s] / tot)
        scores[j] = base + bonus

    # commit choice tracked by argmax (ties -> first)
    return scores
# EVOLVE-BLOCK-END
