# EVOLVE-BLOCK-START
"""Competitive best-fit with light future-seal awareness.

Pure best fit (score = -residual) is a strong baseline but leaves many tiny
residuals that no future item can use.  This rule keeps best-fit as the
dominant term and adds only small, price-justified corrections:

  * reward residuals that exactly equal a frequently seen item size, since a
    future item of that size would seal the bin;
  * mildly penalize residuals smaller than the running median item size
    (they rarely accept a typical future item), unless they are a perfect seal.

All corrections are bounded and much smaller than the residual gap, so the
best-fit ordering among shown bins is essentially preserved where it matters.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_sum = 0
_median = 1


def _init(n):
    global _n_items, _seen, _hist, _sum, _median
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _median = 1


def priority(item, bins):
    global _seen, _sum, _median

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = _seen
    # Running median via cumulative histogram.
    target = 0.5 * total
    cum = 0.0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            _median = s
            break
    median = _median

    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total

    # Best-fit core.
    score = -residual.astype(np.float64)

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 40.0

    # Reward residuals a future item can exactly fill.
    score += fill_mass * 20.0

    # Mildly penalize residuals too small for a typical item (not a seal).
    too_small = ((residual > 0) & (residual < median)).astype(np.float64)
    score -= too_small * 18.0

    return score
# EVOLVE-BLOCK-END

