# EVOLVE-BLOCK-START
"""Best-fit with an empirical exact-seal tie-break.

Pure best fit is the strongest known online rule for this distribution, so the
core score is exactly -residual (smaller resulting residual wins).  The only
extra signal is a *tie-break within equal residual*: prefer the bin whose
resulting residual is itself a common item size, because such a bin can be
closed by a single future item that exactly fits it (an immediate perfect
seal).  This never overrides best-fit; it only reorders equal-residual bins,
which is where pure best-fit is arbitrary.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_total = 0


def _init(n):
    global _n_items, _seen, _hist, _total
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.float64)
    _total = 0


def priority(item, bins):
    global _seen, _total

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _total += 1
    if item <= 100:
        _hist[item] += 1.0

    residual = bins - item  # >= 0 for the shown bins

    # Dominant core: strictly prefer the smallest resulting residual.
    score = -residual.astype(np.float64) * 1000.0

    # Tie-break: mass of items exactly equal to the resulting residual,
    # normalized so it can only reorder equal-residual bins.
    idx = np.clip(residual, 0, 100)
    seal_mass = _hist[idx] / _total  # in [0,1]

    # Small, bounded tie-break strictly below 1000 (the core gap is >= 1000).
    score += seal_mass * 500.0

    # For bins with zero mass residual, prefer the smallest residual to keep
    # the ordering deterministic and consistent with best-fit.
    return score
# EVOLVE-BLOCK-END
