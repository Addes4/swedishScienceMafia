# EVOLVE-BLOCK-START
"""Best-fit with a targeted consolidation alternative.

Core: pick the bin that minimizes the leftover residual (classic best fit).
This alone is already near-optimal.

The only way best fit wastes bins is by repeatedly carving tiny slivers that
no future (mean ~40) item can ever fill.  So: normally take the tightest bin,
but if the tightest bin's leftover would leave a sliver below a robustly
estimated "smallest useful residual" (a low quantile of the observed item
distribution), prefer instead a bin whose leftover equals a *frequently seen*
past item size (so the leftover is very likely to be exactly sealed later).
Among such pairable candidates, take the one with the smallest residual, and
leave pure best-fit as the fallback and tie-breaker.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None or _hist.shape[0] != 101:
        _init(n)
    if _seen >= n:
        # safety: never let the instance counter overflow
        _init(n)

    _seen += 1
    _hist[item] += 1

    idx = np.arange(len(bins))
    residual = bins - item
    valid = residual >= 0
    if not np.any(valid):
        return np.zeros(len(bins), dtype=np.float64)

    total = max(_seen, 1)
    cum = np.cumsum(_hist)  # cum[s] = count of items <= s

    # Low quantile of observed items: a residual below this is likely useless.
    thr_count = 0.10 * total
    small = 1
    for s in range(1, 101):
        if cum[s] >= thr_count:
            small = s
            break

    res_f = residual.astype(np.float64)

    # Best fit core.
    score = -res_f.copy()

    # Strong bonus for perfect seal.
    score += (residual == 0).astype(np.float64) * 50.0

    # If residual is positive but below the "smallest useful" threshold, it is
    # a sliver: penalize it so a slightly larger, pairable residual wins.
    sliver = valid & (residual > 0) & (residual < small)
    score -= sliver.astype(np.float64) * 40.0

    # Reward residuals that are frequently seen past sizes AND not slivers,
    # making exact future seals likely.  Use probe values only for valid bins.
    freq = np.zeros(len(bins), dtype=np.float64)
    if total > 1:
        for s in range(max(small, 1), 101):
            c = _hist[s]
            if c:
                hit = valid & (residual == s)
                if np.any(hit):
                    freq[hit] = c / total
    score += freq * 25.0

    return score
# EVOLVE-BLOCK-END
