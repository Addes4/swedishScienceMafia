# EVOLVE-BLOCK-START
"""Competitive best-fit with future-fill viability.

Pure best fit leaves many bins with tiny residuals that no future item can
ever use (wasted capacity).  Since sizes come from a fixed Weibull-like
distribution (mean ~40), a residual is *useful* only if some future item fits
it, and it is *valuable* if future items are likely to exactly fill it.

This rule keeps best-fit as the core (score = -residual) but:
  * strongly rewards residuals that equal 0 (perfect seal), and residuals
    whose size has high empirical histogram mass (likely exact seal later),
  * smoothly penalizes residuals that few future items can fit (low CDF),
    so we don't strand small unusable leftovers,
  * ignores brittle hand-tuned "mid range" nudges.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0
_cum = None


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum, _cum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _cum = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    # Cumulative histogram (fraction of items <= s).
    _cum[:] = np.cumsum(_hist) / total

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total   # prob item size == r
    fit_mass = _cum[idx]                                 # prob item fits (<= r)

    # Best-fit core.
    score = -r * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 70.0

    # Reward residuals that a future item can exactly fill (high histogram mass).
    score += fill_mass * 45.0

    # Smooth penalty: residuals that few future items can fit are prone to
    # becoming permanently wasted capacity.  Penalty grows as fit_mass -> 0,
    # but is suppressed for the perfect seal.
    unusable = (1.0 - fit_mass) * ((residual > 0).astype(np.float64))
    score -= unusable * 25.0

    return score
# EVOLVE-BLOCK-END
