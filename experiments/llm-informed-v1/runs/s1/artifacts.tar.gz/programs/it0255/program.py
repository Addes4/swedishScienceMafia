# EVOLVE-BLOCK-START
"""Competitive best-fit with exact pair-sealing reward.

The proven core is best fit (score = -residual) plus a reward for residuals
that future items can exactly fill (fill_mass) and a strong perfect-seal
reward.  This version adds a grounded structural bonus: since sizes come from
a fixed Weibull-like distribution, a residual r is valuable if some *other*
open bin has residual 100 - r (so a single future item of size 100-r would
exactly seal it into a full bin).  We track the exact residual multiset of all
open bins and reward candidates whose resulting residual matches a complement
present elsewhere, encouraging pairings that leave no unusable leftovers.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0
_count = None


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum, _count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _count = np.zeros(101, dtype=np.int64)  # residual value -> #open bins


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)
    mean = _sum / _seen

    # Empirical median item size (approx).
    target = 0.5 * total
    cum = 0.0
    median = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            median = s
            break

    csum = np.cumsum(_hist)
    _cum = csum / total

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    fit_mass = _cum[idx]

    # Best-fit core.
    score = -r * 1.0

    # Perfect seal.
    score += (residual == 0).astype(np.float64) * 70.0

    # Penalize residuals too small for a typical item.
    too_small = ((residual > 0) & (residual < median)).astype(np.float64)
    score -= too_small * 35.0

    # Reward residuals a future item can exactly fill.
    score += fill_mass * 30.0

    # Reward residuals reachable by future items.
    score += fit_mass * 8.0

    # Pair-sealing: reward a resulting residual whose complement (100-r)
    # appears as another open bin's residual (a matching future item would
    # seal a pair).  Use the residual multiset (excluding this bin).
    cnt = _count
    comp = 100 - residual
    comp_clip = np.clip(comp, 0, 100)
    pair = cnt[comp_clip].astype(np.float64)
    # subtract this bin's own contribution if it equals its complement
    self_match = ((comp == residual) & (cnt[idx] > 0)).astype(np.float64)
    pair = pair - self_match
    pair = np.maximum(pair, 0.0)
    score += (pair > 0).astype(np.float64) * 6.0

    # Nudge toward the running mean.
    if mean > 0:
        near_mean = np.abs(r - mean)
        score += np.exp(-(near_mean / (0.5 * mean + 1.0)) ** 2) * 4.0
        score += (r >= median).astype(np.float64) * 2.0

    # Update tracked residual multiset with the chosen bin (argmax, first tie).
    chosen = int(np.argmax(score))
    old = _residuals[chosen]
    if old > 0:
        _count[old] -= 1
    _residuals[chosen] = residual[chosen]
    newval = residual[chosen]
    if newval > 0:
        _count[newval] += 1

    return score
# EVOLVE-BLOCK-END
