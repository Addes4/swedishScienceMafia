# EVOLVE-BLOCK-START
"""Best fit with exact-completion preference.

Best fit (choose the bin with the smallest remaining capacity that still fits) is
essentially optimal for online bin packing under a near-continuous size distribution.
The one thing that is strictly better than best fit is to prefer a bin that the item
fills exactly (post-placement residual 0), which removes a bin from the pool at no cost.

We keep the full packing state ourselves (the harness only shows us the bins the item
fits in, but we choose the bin, so we can reconstruct everything). We rank bins by the
exact best-fit ordering (smallest post-placement residual), giving a strict bonus only
to bins that become exactly full. No other perturbation is applied, so ordering is exact
and ties fall to the first bin.
"""
import numpy as np

# --- persistent state (fresh process per instance) ---
_n_items = None          # number of items in the instance
_residuals = None        # remaining capacity of every bin, indexed by bin order


def _init(n):
    global _n_items, _residuals
    _n_items = n
    _residuals = np.full(n, 100, dtype=np.int64)


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    # Best fit: smallest post-placement residual first => highest score.
    residual = bins - item  # >= 0 for all bins shown
    score = -residual.astype(np.float64)

    # Strict bonus for exact fills: strictly better than any non-exact best fit.
    score += (residual == 0).astype(np.float64) * 1e6

    return score
# EVOLVE-BLOCK-END
