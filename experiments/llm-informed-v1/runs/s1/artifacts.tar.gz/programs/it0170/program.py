# EVOLVE-BLOCK-START
"""Adaptive best-fit with residual-viability weighting.

Core stays best-fit (score = -residual).  On top of it we add three
distribution-aware, time-aware terms derived from the empirical item
histogram so far:

  * perfect-seal reward for residual == 0 (a bin closed forever),
  * a penalty for residuals too small to accept a likely future item,
    scaled by how many items remain (early: matters a lot; late: less),
  * a bonus proportional to the empirical mass of items that exactly
    fill the residual.

The threshold for "too small" is the empirical 30th percentile of the
observed sizes, which is more robust to the long tail than the median.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)
    remaining = max(_n_items - _seen, 0)

    # Empirical 30th-percentile size (approx) via cumulative histogram.
    target = 0.3 * total
    cum = 0.0
    p30 = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            p30 = s
            break

    idx = np.clip(residual, 0, 100)
    # Empirical mass at the exact residual size (chance of an exact fill).
    fill_mass = _hist[idx].astype(np.float64) / total
    # Empirical mass at sizes <= residual (chance some item fits at all).
    cum_hist = np.cumsum(_hist).astype(np.float64) / total
    fit_mass = cum_hist[idx]

    # Best-fit core.
    score = -residual.astype(np.float64)

    # Perfect seal: strong reward, more valuable when many items remain.
    seal_w = 50.0 + 20.0 * (remaining / max(_n_items, 1))
    score += (residual == 0).astype(np.float64) * seal_w

    # Penalize residuals too small to accept a likely future item.
    small_w = 25.0 + 20.0 * (remaining / max(_n_items, 1))
    too_small = ((residual > 0) & (residual < p30)).astype(np.float64)
    score -= too_small * small_w

    # Reward residuals a future item can exactly fill.
    score += fill_mass * 30.0

    # Reward residuals that admit at least some future item (flexibility).
    score += fit_mass * 8.0

    return score
# EVOLVE-BLOCK-END
