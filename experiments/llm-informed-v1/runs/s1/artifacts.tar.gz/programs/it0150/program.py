# EVOLVE-BLOCK-START
"""Hybridized best-fit / balanced-residual rule.

Best-fit packs tightly but strands small residuals that cannot host future
items.  Balanced fit keeps bins at a healthy residual level so that the
arriving items (drawn from a fixed Weibull-ish distribution with mean ~40)
always have a home.  This rule mixes both: it rewards residuals that are
neither too small (unfillable) nor too large (wasteful), with a strong
exact-fill bonus since a residual of 0 removes a bin permanently.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in
    r = residual.astype(np.float64)

    total = max(_seen, 1)

    # Empirical low quantile as a soft "minimum useful residual" reserve.
    target = 0.15 * total
    cum = 0.0
    q = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            q = s
            break

    # probability mass of exact future fill (smoothed)
    idx = np.clip(residual, 0, 100)
    exact_mass = _hist[idx].astype(np.float64) / total

    # "Healthy" residuals: at least q and not enormous. Reward balance.
    # Map residual to a target zone centered near ~60 (half capacity) while
    # preferring slightly lower residuals for compact packing.
    healthy = np.clip(100.0 - np.abs(r - 55.0), 0.0, 100.0)

    # Best-fit component (strong, but let healthy term compete on ties).
    score = -r * 1.0
    score += healthy * 0.35
    # Viability: residual can host the typical small item.
    score += ((r >= q) & (r > 0)).astype(np.float64) * 15.0
    # Exact-fill bonus (removes a bin entirely), scaled moderately.
    score += exact_mass * 20.0
    score += (residual == 0).astype(np.float64) * 60.0

    return score
# EVOLVE-BLOCK-END

