# EVOLVE-BLOCK-START
"""Best fit with histogram-mode residual alignment.

Best fit is near-optimal for online bin packing. Its weakness is stranding tiny
residuals no future item can use. We keep the full packing state and an empirical
histogram of item sizes. Among bins that are near-tied on best-fit tightness, we
prefer residuals that match the most common future item size (histogram mode), so
leftover space is likely to be exactly filled later.
"""
import numpy as np

# --- persistent state (fresh process per instance) ---
_n_items = None
_seen = 0
_residuals = None
_min_seen = 101
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _min_seen, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _min_seen = 101
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen, _min_seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    if item < _min_seen:
        _min_seen = item
    _hist[item] += 1

    residual = bins - item  # >= 0 for all bins shown

    # Primary: strict best fit (smallest residual wins).
    score = -residual.astype(np.float64)

    # Secondary: if the residual would exactly equal a size that has been seen
    # at least twice (a plausible future item), nudge it up. This is small enough
    # not to break best-fit ordering across distinct residuals but helps among ties.
    seen_mask = _hist[residual.clip(0, 100)] >= 2
    score += seen_mask.astype(np.float64) * 0.25

    # Strong bonus for exactly filling this bin.
    score += (residual == 0).astype(np.float64) * 1000.0

    return score
# EVOLVE-BLOCK-END
