# EVOLVE-BLOCK-START
"""Best-fit core with reachability and dead-residual avoidance."""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_sum = 0
_cum = None


def _init(n):
    global _n_items, _seen, _hist, _sum, _cum
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _cum = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)
    mean = _sum / _seen

    # smallest observed item size (proxy for "tiny but possible" items)
    small = 1
    for s in range(1, 101):
        if _hist[s] > 0:
            small = s
            break

    _cum[:] = np.cumsum(_hist) / total

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    fit_mass = _cum[idx]

    # Best-fit core.
    score = -r * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 70.0

    # Dead residual: too small to accept the smallest item seen -> unusable.
    dead = ((residual > 0) & (residual < small)).astype(np.float64)
    score -= dead * 40.0

    # Reward residuals that a future item can exactly seal.
    score += fill_mass * 50.0

    # Flexibility: residuals that admit many future items.
    score += fit_mass * 10.0

    # Fresh-bin bonus: strongly prefer empty bins over stranding odd residuals
    # when the item fits poorly elsewhere.
    score += (residual == 100 - item).astype(np.float64) * 6.0

    if mean > 0:
        near_mean = np.abs(r - mean)
        score += np.exp(-(near_mean / (0.5 * mean + 1.0)) ** 2) * 4.0

    return score
# EVOLVE-BLOCK-END
