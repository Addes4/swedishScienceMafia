# EVOLVE-BLOCK-START
"""Best fit with empirical-CDF-based residual viability tie-break.

Best fit is near-optimal for online bin packing under a continuous size
distribution. Its weakness is choosing among near-equal residuals that
have very different usefulness for future items. We keep the full packing
state and a running empirical CDF of item sizes, and use the probability
that a residual is "usable" (can still receive a plausible future item)
as a smooth tie-breaker on top of pure best fit.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_cdf = None  # cumulative counts, index 0..100


def _init(n):
    global _n_items, _seen, _residuals, _hist, _cdf
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _cdf = np.zeros(101, dtype=np.float64)


def _rebuild_cdf():
    global _cdf
    totals = np.cumsum(_hist[1:])
    _cdf[1:] = totals / max(_seen, 1)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _rebuild_cdf()

    residual = bins - item  # >= 0, post-placement residual

    # probability that a future item fits in the residual (size <= residual)
    # _cdf[r] = P(item <= r) from empirical distribution
    p_fit = _cdf[np.minimum(residual, 100)]

    # probability that residual is exactly filled by a future item
    p_exact = _hist[np.minimum(residual, 100)].astype(np.float64) / max(_seen, 1)

    score = (
        -residual.astype(np.float64)          # primary: best fit (min residual)
        + 0.75 * p_fit                        # residual stays reachable
        + 2.0 * p_exact                       # reward leaving a "part-match" gap
    )

    return score
# EVOLVE-BLOCK-END

