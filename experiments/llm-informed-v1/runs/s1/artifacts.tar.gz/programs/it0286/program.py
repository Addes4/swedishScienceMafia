# EVOLVE-BLOCK-START
"""Best-fit with convolved future-seal reward.

Pure best fit (score = -residual) is the strongest simple online rule for
this distribution.  Its main weakness is that it never prefers a bin whose
resulting residual can be exactly filled by a future item.  I add one extra
term: the empirical probability that the residual r is exactly reachable by
a *single* future item (histogram mass at r) or by *two* future items
(convolution of the item histogram with itself at r).  This rewards
placements that leave a residual that the item stream itself can consume,
and it is computed from the observed past items only.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_total = 0
_conv = None
_dirty = True


def _init(n):
    global _n_items, _seen, _hist, _total, _conv, _dirty
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.float64)
    _total = 0
    _conv = np.zeros(101, dtype=np.float64)
    _dirty = True


def _recompute_conv():
    global _conv, _dirty
    h = _hist[1:101]  # sizes 1..100
    c = np.convolve(h, h)
    # c[k-2] corresponds to sum k, for k in 2..200
    out = np.zeros(101, dtype=np.float64)
    for k in range(1, 101):
        lo = max(0, k - 2)
        if k - 2 <= len(c) - 1:
            out[k] = c[k - 2] if 0 <= k - 2 < len(c) else 0.0
    _conv = out
    _dirty = False


def priority(item, bins):
    global _seen, _total, _dirty

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None or len(_hist) != 101:
        _init(n)

    _seen += 1
    _hist[item] += 1.0
    _total += 1
    _dirty = True

    residual = bins - item  # >= 0 for shown bins

    # Best-fit core.
    score = -residual.astype(np.float64)

    if _total >= 2:
        # Recompute convolution lazily, but only every few items to save time.
        if _dirty and (_seen % 25 == 0 or _seen < 50):
            _recompute_conv()
        if _conv is not None:
            idx = np.clip(residual, 0, 100)
            one_hit = _hist[idx] / _total
            two_hit = _conv[idx] / (_total * _total)
            score += one_hit * 20.0
            score += two_hit * 10.0

    # Perfect seal.
    score += (residual == 0).astype(np.float64) * 60.0

    return score
# EVOLVE-BLOCK-END
