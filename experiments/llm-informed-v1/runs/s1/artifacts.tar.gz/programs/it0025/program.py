# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware residual value bonus.

Pure best-fit is strong here. This variant keeps best-fit as the dominant term
and adds a small bonus for placements whose resulting residual is a "useful"
value under the empirical item-size distribution (small residuals that are
unlikely to ever be filled count as waste, so slightly larger residuals that
match common item sizes are marginally preferred on near-ties).
"""
import numpy as np

_state = {"sizes": None, "hist": None, "n": 0, "total": 0}
_NUM_BINS_HINT = None


def _ensure(n_bins):
    if _state["hist"] is None or _state["hist"].shape[0] != n_bins:
        _state["hist"] = np.zeros(n_bins, dtype=np.float64)
        _state["n"] = 0
        _state["total"] = 0


def priority(item, bins):
    n = len(bins)
    _ensure(n)
    h = _state["hist"]

    # Empirical CDF over observed item sizes (1..100).
    _state["n"] += 1
    _state["total"] += 1  # count of items seen

    residual = bins - item  # >= 0 for candidate bins

    # Base: best-fit (prefer smallest residual). Larger score = better.
    score = -residual.astype(np.float64)

    # Bonus: a residual that is exactly reachable by common item sizes is good.
    # Use histogram over sizes (1..100) of residuals as a rough "fillability".
    # We approximate fillability by min over a couple of typical future items:
    # residual that can absorb ~mean item (40) is well-used, tiny residuals are
    # not, and residual matching a frequent size is ideal.
    if _state["n"] > 50 and _state["n"] % 1 == 0:
        # histogram of sizes seen (index by size)
        if _state["sizes"] is None:
            _state["sizes"] = np.zeros(101, dtype=np.float64)
        # record current item into histogram for future calls
        _state["sizes"][item] += 1.0
        sz = _state["sizes"]
        tot = sz.sum()
        # probability of each size
        p = sz / tot
        # for each residual r, compute expected "waste": waste of residual r is
        # min over future item x <= r of ... we approximate with the probability
        # that some future item exactly equals r (good) plus ability to combine.
        # Simple heuristic: value(r) = p[r] (exact fill) + smoothed density near r.
        kern = np.array([0.1, 0.2, 0.4, 0.2, 0.1])
        # smooth p
        ps = np.convolve(p[1:101], kern, mode="same")
        r_int = np.clip(residual.astype(np.int64), 0, 100)
        exact = np.where(r_int >= 1, p[r_int] * 0 + ps[np.clip(r_int - 1, 0, 99)], 0.0)
        # Prefer residuals that are large enough to fit a typical item (~40).
        # A residual below ~20 rarely helps; a residual >= ~40 keeps bin reusable.
        util = np.where((residual >= 20), 1.0, 0.0)
        score = score + 0.5 * exact + 0.02 * util

    return score
# EVOLVE-BLOCK-END
