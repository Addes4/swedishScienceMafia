# EVOLVE-BLOCK-START
"""Best fit with residual-reusability awareness.

Best fit (choose the bin with the smallest remaining capacity that still fits) is
essentially optimal for online bin packing under a near-continuous size distribution.
Its one weakness is that it can strand tiny residuals that no future item can ever use.

We keep the full packing state ourselves (the harness only shows us the bins the item
fits in, but we choose the bin, so we can reconstruct everything). We also keep an
empirical record of the smallest item size seen so far. A residual is "reusable" if it
is at least as large as the smallest item we expect to still arrive. We rank bins by
best fit (smallest residual), but give a strictly dominated bonus to bins whose
post-placement residual is exactly zero or still reusable, so we never violate the
best-fit ordering -- the bonus only breaks ties among equal residuals.
"""
import numpy as np

# --- persistent state (fresh process per instance) ---
_n_items = None          # number of items in the instance
_seen = 0                # items seen so far
_residuals = None        # remaining capacity of every bin, indexed by bin order
_min_seen = 101          # smallest item size observed so far


def _init(n):
    global _n_items, _seen, _residuals, _min_seen
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _min_seen = 101


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    global _seen, _min_seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    if item < _min_seen:
        _min_seen = item

    # Smallest size we plausibly still expect still to arrive.
    floor = _min_seen if _min_seen <= 100 else 1

    residual = bins - item  # >= 0 for all bins shown

    # Best fit dominates: a one-unit residual difference outweighs any bonus.
    # K is chosen larger than the maximum possible bonus magnitude (A + B).
    K = 1000.0
    A = 100.0   # exact-fill bonus
    B = 50.0    # reusable-residual bonus

    score = -residual.astype(np.float64) * K
    score += (residual == 0).astype(np.float64) * A
    score += (residual >= floor).astype(np.float64) * B

    return score
# EVOLVE-BLOCK-END

