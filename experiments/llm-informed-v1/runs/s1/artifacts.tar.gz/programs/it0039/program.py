# EVOLVE-BLOCK-START
"""Stateful best-fit with a mild anti-dead-bin nudge.

Pure best-fit is a strong baseline for online bin packing. Its main weakness is
creating bins with tiny residual capacity that no future item can fill. We keep
best-fit in charge, but when the best-fit residual after placement would be very
small (below a small fraction of the running mean item size), we instead mildly
prefer a bin whose post-placement residual is somewhat larger, so those bins
remain usable.
"""
import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of arriving item, 1..100.
    bins: numpy int64 remaining capacity of every bin the item fits in.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    residual = bins - item  # remaining capacity if placed here

    # Best-fit core: smaller residual is better (higher score).
    score = -residual.astype(np.float64)

    # Anti-dead-bin nudge: if the best-fit residual is very small, prefer a
    # bin whose residual is at least a modest fraction of the mean item size.
    target = max(1.0, 0.5 * mean)
    min_res = residual.min()
    if min_res < target:
        # Bonus for bins whose residual is closer to `target` (bounded by mean).
        want = np.minimum(residual.astype(np.float64), target)
        score += 0.02 * want

    return score
# EVOLVE-BLOCK-END
