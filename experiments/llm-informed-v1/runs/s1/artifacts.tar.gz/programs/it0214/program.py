# EVOLVE-BLOCK-START
"""Best-fit with horizon-scaled perfect-seal reward.

Best fit (score = -residual) is an excellent online rule for this
distribution.  The only reliable way to reduce the bin count below pure
best fit is to finish bins off exactly (residual 0) so no untouchable
sliver is left behind.  We therefore keep pure best-fit as the core and
add a perfect-seal reward whose strength scales up as the remaining
horizon shrinks: early on we cannot afford to deviate from best fit,
but late in the instance consolidating a bin to exactly full is nearly
always worth it.
"""
import numpy as np

_n_items = None
_seen = 0


def priority(item, bins):
    global _n_items, _seen

    n = len(bins)
    if _n_items is None or _n_items != n:
        _n_items = n
        _seen = 0

    _seen += 1
    residual = bins - item  # >= 0 for shown bins

    # Pure best-fit core.
    score = -residual.astype(np.float64)

    # Perfect seal: reward filling a bin exactly.  Strength grows with the
    # fraction of the instance already processed so late items consolidate.
    frac = _seen / float(_n_items)
    seal_bonus = 20.0 + 200.0 * frac
    score += (residual == 0).astype(np.float64) * seal_bonus

    return score
# EVOLVE-BLOCK-END
