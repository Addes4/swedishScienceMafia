# EVOLVE-BLOCK-START
"""Best fit with reserved empty bins for large items."""
import numpy as np

LARGE = 50


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit score: prefer bins whose remaining capacity is closest to the item size.
    score = -(bins - item).astype(np.float64)

    if item < LARGE:
        # Penalize opening/using completely empty bins for small items.
        empty = bins == 100
        score[empty] -= 1000.0

    return score
# EVOLVE-BLOCK-END
