# EVOLVE-BLOCK-START
"""Best fit with a mode-matching tie-break.

Best fit (smallest fitting residual) is essentially optimal for online bin packing
when sizes are near-continuous. Its weakness is stranding tiny residuals that no
future item can use. Under a Weibull-shaped distribution with mean ~40, residuals
near a "typical" item size are the most likely to be filled exactly, so we nudge
toward those bins without breaking best-fit ordering.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_min_seen = 101
_hist = None
_mean_seen = 0.0


def _init(n):
    global _n_items, _seen, _residuals, _min_seen, _hist, _mean_seen
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _min_seen = 101
    _hist = np.zeros(101, dtype=np.int64)
    _mean_seen = 0.0


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    global _seen, _min_seen, _mean_seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    if item < _min_seen:
        _min_seen = item
    _hist[item] += 1
    _mean_seen += (item - _mean_seen) / _seen

    residual = bins - item

    # Best fit ordering dominates. Tiny tie-break bonus when the leftover is close
    # to a typical item size seen so far (likely to be fillable), plus a strong
    # bonus for exact fills.
    target = _mean_seen if _mean_seen > 1.0 else 40.0
    closeness = 1.0 - np.abs(residual - target) / 100.0  # in [0,1]

    score = -residual.astype(np.float64)
    score += 0.4 * closeness
    score += (residual == 0).astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
