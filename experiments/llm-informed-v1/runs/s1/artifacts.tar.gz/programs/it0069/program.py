# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference.

For a near-continuous size distribution, Best Fit (place into the fitting bin with
the smallest remaining capacity) is essentially optimal. The only reliable extra
structure is that making a bin exactly full is always beneficial, so we give exact
fills a strictly dominant score. Otherwise we order strictly by smallest residual
(integer-exact), so ties fall to the first bin consistently.
"""
import numpy as np

_n_items = None
_residuals = None


def _init(n):
    global _n_items, _residuals
    _n_items = n
    _residuals = np.full(n, 100, dtype=np.int64)


def priority(item, bins):
    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    residual = bins - item  # >= 0 for all bins shown

    # Exact fill is always good: give it the top score, unique, so it wins outright.
    score = -residual.astype(np.int64) * 2
    score += (residual == 0).astype(np.int64)

    return score
# EVOLVE-BLOCK-END
