# EVOLVE-BLOCK-START
"""Best-fit core with a histogram-mass tiebreaker.

Best fit (score = -residual) is the strongest simple rule here; noise from
extra bonuses hurt in past attempts.  I keep the core dominant, add a strong
perfect-seal reward, and use the empirical histogram mass of future item
sizes only as a *small* tiebreaker so that, among residuals that are close
in magnitude, we prefer residuals that some incoming item is likely to
exactly fill.  The perfect-seal reward prevents stranded tiny residuals.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_sum = 0


def _init(n):
    global _n_items, _seen, _hist, _sum
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total

    # Best-fit core dominates.
    score = -residual.astype(np.float64)

    # Strong perfect-seal reward.
    score += (residual == 0).astype(np.float64) * 80.0

    # Small tiebreaker: prefer residuals a future item is likely to exactly fill.
    score += fill_mass * 12.0

    return score
# EVOLVE-BLOCK-END

