# EVOLVE-BLOCK-START
"""Best fit with exact-fill lookahead.

The dominant term is pure best fit (score = -residual), which is a strong
online rule on its own.  Its known weakness is that it can leave residuals
that no future item can ever use.  Since item sizes come from a fixed
distribution, we can score how valuable a resulting residual is:

  * mass[r] = empirical probability that a future item has size exactly r.
    A residual equal to a common item size is likely to be sealed exactly,
    so reward it.
  * residuals below the smallest size with meaningful mass are dead weight;
    penalize them mildly.

All weights are small relative to the best-fit core so the rule stays close
to best fit and never becomes brittle.
"""
import numpy as np

_n_items = None
_residuals = None
_hist = None
_seen = 0


def _init(n):
    global _n_items, _residuals, _hist, _seen
    _n_items = n
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.float64)
    _seen = 0


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen, 1)
    mass = _hist / total  # empirical PMF over 1..100

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)

    # Best-fit core (dominant).
    score = -r

    # Reward residuals that match a future item size (exact-fill lookahead).
    score += mass[idx] * 30.0

    # Perfect seal gets a strong bonus.
    score += (residual == 0).astype(np.float64) * 50.0

    # Penalize residuals too small to accept any item with meaningful mass.
    # Find the smallest item size with non-negligible empirical probability.
    smalls = np.nonzero(mass[1:] > 1e-3)[0]
    if smalls.size:
        min_useful = smalls[0] + 1
        dead = ((residual > 0) & (residual < min_useful)).astype(np.float64)
        score -= dead * 20.0

    return score
# EVOLVE-BLOCK-END
