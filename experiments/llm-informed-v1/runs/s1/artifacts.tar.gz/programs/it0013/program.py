# EVOLVE-BLOCK-START
"""Best fit with a mild preference to avoid tiny useless leftovers."""
import numpy as np


def priority(item, bins):
    """Score each candidate bin; highest wins (first on ties).

    Core rule: best fit (smallest leftover). We perturb it slightly so that
    leftovers that are extremely small (1..2) are penalized a touch relative to
    leftovers that equal the item size (which allows a future exact fill), and
    so that opening a fresh bin (leftover 100) is mildly discouraged for small
    items where a decent fit likely exists.
    """
    leftover = bins - item  # >= 0 for all shown bins
    score = -leftover.astype(np.float64)

    # Slightly reward leftovers equal to `item`(future exact fill symmetry)
    # and reward leftovers that are large-but-not-100.
    score += 0.35 * (leftover == item)

    # Penalize tiny leftovers (1 or 2): nearly useless residue.
    score -= 0.5 * ((leftover == 1) | (leftover == 2))

    # Mildly discourage wasting a completely empty bin on a small item.
    if item <= 25:
        score -= 0.25 * (leftover == 100)

    return score
# EVOLVE-BLOCK-END

