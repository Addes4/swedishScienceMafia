# EVOLVE-BLOCK-START
"""Best fit with an empirical viability floor.

Rank each candidate bin by its *resulting* residual.  Exact fills are very
good; among the rest, prefer the smallest residual that still stays at or
above an estimate of the smallest items likely to arrive later.  That floor
(an empirical low quantile) prevents stranding a bin with a residual no
future item can use, which is what pure best fit does.

The floor is computed from the empirical size distribution seen so far, so
the rule adapts to the Weibull shape without tuning to any instance.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for the bins shown

    # Empirical low quantile: a robust estimate of the smallest future item.
    floor = _quantile(0.12)
    if floor < 1:
        floor = 1

    score = -residual.astype(np.float64)

    # Exact fills: strongly preferred.
    score += (residual == 0).astype(np.float64) * 100.0

    # Among non-exact residuals, prefer ones that stay above the floor.
    viable = (residual >= floor) & (residual > 0)
    score += viable.astype(np.float64) * 40.0

    return score
# EVOLVE-BLOCK-END
