# EVOLVE-BLOCK-START
"""Best fit with a safe, tie-only nudge against stranding dead space.

Best fit (smallest remaining capacity that still fits) is essentially optimal for
online bin packing under a near-continuous size distribution. Its only weakness is
that it can leave tiny residuals no future item can use. Prior attempts perturbed the
ordering by up to floor/2, which flipped genuine best-fit decisions and hurt.

Fix: keep best-fit ordering *exact* (score dominated by -residual with integer gaps),
and add bonuses strictly smaller than 1.0 so they only resolve exact-residual ties.
Among ties: prefer exact fills, then residuals that are >= the smallest item seen so
far (still usable by some future item).

We track the full packing state ourselves and keep the smallest item observed.
"""
import numpy as np

# --- persistent state (fresh process per instance) ---
_n_items = None          # number of items in the instance
_seen = 0                # items seen so far
_residuals = None        # remaining capacity of every bin, indexed by bin order
_min_seen = 101          # smallest item size observed so far


def _init(n):
    global _n_items, _seen, _residuals, _min_seen
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _min_seen = 101


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    global _seen, _min_seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    if item < _min_seen:
        _min_seen = item

    floor = _min_seen if _min_seen <= 100 else 1

    residual = bins - item  # >= 0 for all bins shown

    # Best-fit ordering: smaller residual => higher score. Integer residuals give
    # unit gaps, so any bonus below 1.0 only breaks exact ties.
    score = -residual.astype(np.float64)

    # Tie-break bonuses (each < 1.0, so ordering among distinct residuals is intact).
    # Prefer residuals still usable by the smallest expected future item.
    score += (residual >= floor).astype(np.float64) * 0.25
    # Prefer exact fills above all.
    score += (residual == 0).astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
