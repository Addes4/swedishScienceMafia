# EVOLVE-BLOCK-START
"""Best-fit with an expected-waste correction.

Pure best fit (choose the smallest residual that still fits) is a strong
online rule for this Weibull-like size distribution (mean ~40).  Its one
weakness is that it can leave residuals that later items can never use
efficiently.  We keep best-fit as the core ordering, but add two
distribution-aware terms computed from the empirical item histogram:

  * a perfect-seal reward for residuals that hit exactly zero,
  * an "expected waste" term: for a residual r, how much capacity would
    likely be left over if we packed r greedily with future items from the
    empirical distribution.  Residuals that are easy to fill exactly or
    nearly exactly get a bonus; awkward residuals (which would strand
    capacity) get a penalty.

The expected-waste function is precomputed as a lookup table over r = 0..100
and refreshed periodically from the running histogram, so per-call cost stays
tiny.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_sum = 0
_waste = None
_waste_seen = -1


def _init(n):
    global _n_items, _seen, _hist, _sum, _waste, _waste_seen
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _waste = None
    _waste_seen = -1


def _rebuild_waste(total):
    """Expected leftover capacity when greedily packing a bin of size r
    with items drawn from the empirical distribution.

    For each start size r we simulate a simple first-fit-decreasing-style
    fill using the mean item and the histogram mass: the dominant effect is
    how close r is to a sum of typical items.  We approximate by the average
    distance from r down to the nearest reachable residual under mean-sized
    items, blended with the empirical chance of sealing r exactly.
    """
    global _waste, _waste_seen
    hist = _hist.astype(np.float64)
    if hist.sum() <= 0:
        return
    p = hist / hist.sum()
    mean = float(_sum) / max(_seen, 1)

    # Probability mass near each size (smoothed) for "can this item be used".
    # P(no item fits residual r)  -> residual is dead weight.
    cum = np.cumsum(p)  # cum[s] = P(item <= s)
    dead = np.ones(101)
    dead[1:] = 1.0 - cum[:100]  # P(item > r-1) = P(item >= r) roughly
    # P(item <= r): chance r can be reduced further.
    usable = np.zeros(101)
    usable[1:] = cum[:100]

    # Expected waste: if the residual is below the smallest likely item and
    # not zero, it tends to stay stranded; otherwise scale by how far it is
    # from a multiple of the mean.
    r = np.arange(101, dtype=np.float64)
    if mean > 1e-9:
        mult = np.round(r / mean)
        mult = np.maximum(mult, 1.0)
        frac = np.abs(r - mult * mean) / mean
    else:
        frac = np.zeros(101)

    # Base waste is the stranded residual; sealing (r=0) has zero waste.
    waste = r * (1.0 - usable) + frac * mean * usable
    waste[0] = 0.0
    # Small positive residuals that no future item fits are pure waste.
    waste[1:] = np.where(r[1:] < mean * 0.5, r[1:], waste[1:])

    _waste = waste
    _waste_seen = total


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None or len(_hist) != 101:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins
    total = _seen

    # Refresh the expected-waste table occasionally (cheap, amortized).
    if _waste is None or total - _waste_seen >= 25 or _waste_seen < 0:
        _rebuild_waste(total)

    idx = np.clip(residual, 0, 100)

    # Best-fit core.
    score = -residual.astype(np.float64)

    # Perfect seal reward.
    score += (residual == 0).astype(np.float64) * 50.0

    # Expected-waste correction: subtract a scaled expected waste so bins
    # whose residual can be used well by future items are preferred.
    if _waste is not None:
        score -= _waste[idx] * 0.5

    return score
# EVOLVE-BLOCK-END
