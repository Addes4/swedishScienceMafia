# EVOLVE-BLOCK-START
"""Best fit with a small empirical-residual bonus.

Primary rule: classic best fit (place item into the fitting bin with the least
remaining capacity). Ties/close calls are nudged toward residuals that have
recently proved reusable (i.e. residuals that equal a size we have seen before),
which lets future items fill bins exactly a bit more often.
"""
import numpy as np

# empirical counters of item sizes seen so far (index by size 0..100)
_SEEN = np.zeros(101, dtype=np.int64)
_TOTAL = 0


def priority(item, bins):
    global _TOTAL

    # record the arriving item before scoring
    _SEEN[item] += 1
    _TOTAL += 1

    residual = bins - item  # capacity left after placing the item here; bins fit so >= 0

    # classic best-fit: smaller residual is strictly preferred.
    # bonus: a small negative offset when the residual is a size we've seen
    # (meaning a future item of that size could exactly close this bin).
    bonus = np.where(residual > 0, _SEEN[np.clip(residual, 0, 100)], 0)
    # scale bonus to stay strictly below the 1-unit gap between residuals
    scale = 0.001 / (1.0 + _TOTAL)
    score = -residual + bonus * scale

    return score
# EVOLVE-BLOCK-END
