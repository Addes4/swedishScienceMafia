# EVOLVE-BLOCK-START
"""Best fit with a soft reserve derived from the empirical size histogram.

The dominant term is classic best fit (place into the bin with the smallest
post-placement residual).  A reserve threshold derived from the low end of the
empirical size distribution prevents stranding residuals that no likely future
item can use: residuals below the reserve are penalised slightly, exact fills
are rewarded.  All quantities are estimated online from observed items, so the
rule adapts without instance-specific tuning.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in
    score = -residual.astype(np.float64)

    # Reserve: smallest item size at the 15th percentile, at least 1.
    q15 = _quantile(0.15)

    # Prefer residuals that stay at or above the reserve (still usable later).
    good = (residual >= q15) & (residual > 0)
    score += good.astype(np.float64) * 25.0

    # Exact fills strongly rewarded.
    score += (residual == 0).astype(np.float64) * 70.0

    return score
# EVOLVE-BLOCK-END

