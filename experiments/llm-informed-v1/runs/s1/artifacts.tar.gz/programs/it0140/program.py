# EVOLVE-BLOCK-START
"""Best-fit core with a distribution-aware exact-fill/viability bonus.

The packer sees a stream of items from a fixed Weibull-ish distribution
(mean ~40).  Pure best-fit strands bins whose residual no future item can
match.  We keep best-fit as the backbone (prefer the smallest resulting
residual) and add a smooth bonus for residuals that are likely to be closed
or usefully used by future items, estimated from the empirical histogram of
items seen so far and the number of remaining items.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_bin_count = None
_cdf = None


def _init(n):
    global _n_items, _seen, _hist, _bin_count, _cdf
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.float64)
    _bin_count = 0
    _cdf = None


def priority(item, bins):
    global _seen, _hist, _bin_count, _cdf

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1.0
    total = _seen
    remaining = _n_items - _seen

    residual = bins - item  # >= 0 for fitting bins

    # Smoothed item-size density (Laplace-style smoothing) and its CDF.
    # p[s] = empirical probability that an item equals s.
    p = (_hist + 0.5) / (total + 50.0)

    # Probability mass of future items that fit *exactly* into residual r:
    exact = np.zeros(residual.shape, dtype=np.float64)
    idx = np.clip(residual, 0, 100)
    exact = p[idx]

    # Probability that a future item fits (can be placed) into residual r,
    # i.e. P(item <= r) using the empirical CDF.
    cdf = np.cumsum(p)  # cdf[k] ~ P(item <= k)
    cdf_clip = np.clip(residual, 0, 100)
    fits_prob = cdf[cdf_clip]

    # Chance that r gets closed by *some* future item, approximated as
    # 1 - (1 - p_r)^remaining, capped to avoid huge values.
    rem = max(remaining, 0)
    # Avoid overflow: only compute where p is sizable.
    close_prob = 1.0 - np.exp(-p[idx] * rem)

    # Best-fit core: prefer smaller residual.
    score = -residual.astype(np.float64)

    # Strong reward for a residual that exactly matches a common future size
    # (full closure) and a smooth reward for general future usability.
    score += 120.0 * close_prob
    score += 25.0 * fits_prob

    # Prefer residuals that leave room for at least a typical item, mildly.
    score += (residual > 0).astype(np.float64) * 5.0

    return score
# EVOLVE-BLOCK-END
