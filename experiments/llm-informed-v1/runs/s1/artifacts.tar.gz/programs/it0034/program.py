# EVOLVE-BLOCK-START
"""Best-fit with gentle residual-usability tie-breaking."""
import numpy as np

_mu = 40.0
_n = 0
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _mu, _n, _total
    _n += 1
    _total += item
    _mu = _total / _n

    residual = bins - item  # what remains after placing
    # primary: smaller residual is better (best fit)
    # tie-break: prefer residual close to current mean item size
    target = _mu
    # combine: best-fit dominates (scale 1000), usability nudge is small
    score = -(residual.astype(np.float64)) * 1000.0 - np.abs(
        residual.astype(np.float64) - target
    ) * 1.0
    return score
# EVOLVE-BLOCK-END
