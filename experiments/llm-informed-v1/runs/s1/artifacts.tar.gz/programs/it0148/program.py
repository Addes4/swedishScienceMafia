# EVOLVE-BLOCK-START
"""Distribution-aware residual targeting with best-fit core.

The main failure of pure best fit is stranding bins with residuals that no
future item can ever fit.  Since item sizes are drawn from a fixed (Weibull)
distribution with mean ~40, residuals near common item sizes are far more
likely to be filled later than residuals in the sparse tail.

This rule keeps a best-fit core (prefer smaller resulting residual) but adds
a bonus proportional to the empirical probability that *some* future item
fits the resulting residual.  Denser bins (smaller residuals) get more weight,
and residuals matching frequent item sizes get an extra boost.  Bonuses are
scaled by the fraction of items remaining so early packing stays tight and
late packing aggressively avoids stranded residuals.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    total = _seen
    idx = np.clip(residual, 0, 100)
    exact_mass = _hist[idx].astype(np.float64) / max(total, 1)

    # Empirical q10 from cumulative histogram.
    target = 0.10 * total
    cum = 0.0
    q10 = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            q10 = s
            break

    # Fraction of items remaining; grows from ~0 to 1.
    frac_left = float(_n_items - _seen) / float(max(_n_items, 1))

    score = -residual.astype(np.float64)  # best-fit core
    # Strong bonus for exact fills.
    score += (residual == 0).astype(np.float64) * 80.0
    # Bonus for residuals >= q10 (still useful).
    usable = (residual >= q10) & (residual > 0)
    score += usable.astype(np.float64) * 40.0
    # Distribution-aware bonus: residuals matching frequent future sizes,
    # scaled by remaining items so the endgame values survivability more.
    score += exact_mass * 25.0 * (0.5 + frac_left)

    return score
# EVOLVE-BLOCK-END

