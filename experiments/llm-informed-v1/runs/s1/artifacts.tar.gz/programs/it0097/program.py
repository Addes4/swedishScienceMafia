# EVOLVE-BLOCK-START
"""Best fit with empirical-residual-probability awareness.

Best fit is near-optimal for online bin packing under a near-continuous size
distribution; its weakness is stranding residuals that no realistically small
future item can use. We keep the full packing state and an empirical histogram
of item sizes seen so far, and reward placements whose leftover residual equals
a size that has been frequently observed (hence is likely to arrive again).
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_pdf = None


def _init(n):
    global _n_items, _seen, _residuals, _hist, _pdf
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _pdf = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen, _pdf

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    # empirical pdf over residuals, updated cheaply
    inv = 1.0 / _seen
    _pdf *= (1.0 - inv)
    _pdf[item] += inv

    residual = bins - item  # >= 0

    # primary: best fit (smallest residual)
    score = -residual.astype(np.float64)

    # secondary: reward residuals that are likely to be fillable later,
    # i.e. residuals whose empirical occurrence probability is high.
    score += _pdf[np.clip(residual, 0, 100)] * 20.0

    # strongly reward exact fills (never harmful)
    score += (residual == 0).astype(np.float64) * 5.0

    return score
# EVOLVE-BLOCK-END
