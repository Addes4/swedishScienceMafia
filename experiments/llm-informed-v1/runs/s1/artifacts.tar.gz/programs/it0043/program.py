# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus.

Put the item in the bin it fits most tightly, but give a strong bonus to any
bin that the item fills exactly (residual 0), since a perfectly filled bin
can never be useful again and is unambiguously the best use of the item.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit -> smaller residual is better.
    score = -residual.astype(np.float64)
    # Strong bonus for exact fills (residual == 0).
    score += 1000.0 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
