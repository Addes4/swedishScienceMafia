# EVOLVE-BLOCK-START
"""Time-aware best-fit with expected-fill look-ahead.

Item sizes are i.i.d. from a fixed (Weibull-shaped) distribution with mean ~40.
Online packing loses mostly by stranding bins whose residual no future item can
fill.  Since we know how many items remain, we can score each candidate bin by

    expected number of future items that fit the resulting residual
    (weighted toward exact fills, which consolidate cleanly)

while keeping a best-fit core so we naturally pack tightly.

- score = -residual                 : best-fit core (prefer tight bins)
- + alpha * expected_fills(r)       : reward residuals likely to be reused
- + beta  * exact_fill_prob(r)      : reward residuals matching common sizes
- strong reward for residual == 0   : perfect consolidation
- penalty when remaining*P(u<=r) < 1 : residual likely to be stranded
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None or len(_hist) != 101:
        _init(n)

    _seen += 1
    _hist[item] += 1

    remaining = max(_n_items - _seen, 0)
    total = max(_seen, 1)

    residual = bins - item  # >= 0 for bins the item fits in

    idx = np.clip(residual, 0, 100)
    p_exact = _hist[idx].astype(np.float64) / total
    expected_exact = remaining * p_exact

    # Cumulative probability that a random future item is <= r (fit probability).
    csum = np.cumsum(_hist).astype(np.float64)  # csum[s] = count of sizes <= s
    p_fit = csum[idx] / total
    expected_fits = remaining * p_fit

    # Empirical low reserve: a residual smaller than this is nearly useless.
    target = 0.10 * total
    q10 = np.searchsorted(csum, target, side='left') + 1
    q10 = int(min(max(q10, 1), 100))

    score = -residual.astype(np.float64)
    score += (residual == 0).astype(np.float64) * 100.0
    # Reward residuals that can still accept many future items.
    score += np.minimum(expected_fits, 30.0) * 1.5
    # Reward residuals matching common item sizes (clean consolidation).
    score += np.minimum(expected_exact, 5.0) * 6.0
    # Penalize residuals that are too small to be useful but not zero.
    unusable = (residual > 0) & (residual < q10)
    score -= unusable.astype(np.float64) * 30.0

    return score
# EVOLVE-BLOCK-END
