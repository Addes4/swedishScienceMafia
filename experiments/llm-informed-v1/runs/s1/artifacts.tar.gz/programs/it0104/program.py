# EVOLVE-BLOCK-START
"""Best viable residual with a graded empirical-viability bonus.

Place each item into the bin whose post-placement residual is smallest, but
reward residuals that remain large enough to host a typical small future item.
The reward is graded continuously by the empirical size distribution seen so
far, avoiding a brittle binary threshold.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    # Base best-fit: prefer smallest residual.
    score = -residual.astype(np.float64)

    # Empirical quantiles of item sizes: use the 10th percentile as a soft
    # reference for "useful leftover space".
    q10 = _quantile(0.10)
    q25 = _quantile(0.25)

    # Graded viability bonus: reward residuals >= q10, more for >= q25.
    usable10 = (residual >= q10).astype(np.float64)
    usable25 = (residual >= q25).astype(np.float64)
    score += usable10 * 20.0 + usable25 * 15.0

    # Exact fills are especially valuable (free a bin from further wear).
    score += (residual == 0).astype(np.float64) * 80.0

    return score
# EVOLVE-BLOCK-END
