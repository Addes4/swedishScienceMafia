# EVOLVE-BLOCK-START
"""Best-fit with expected-waste viability.

Core: pure best fit (score = -residual), which is hard to beat online.
Refinements that only reorder near-tied bins:
  * strong reward for residual == 0 (a perfect seal; do not pass it up),
  * penalty for residuals that are too small to accept the median future
    item (a dead sliver wastes the whole leftover),
  * a light reward for residuals that some future item can exactly fill,
    estimated from the empirical item histogram seen so far.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    # Empirical median item size.
    target = 0.5 * total
    cum = 0.0
    median = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            median = s
            break

    idx = np.clip(residual, 0, 100)
    r = residual.astype(np.float64)
    fill_mass = _hist[idx].astype(np.float64) / total

    # Best-fit core: dominant signal.
    score = -r

    # Perfect seal.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize dead slivers (nonzero but below the median item size).
    too_small = ((residual > 0) & (residual < median)).astype(np.float64)
    score -= too_small * 35.0

    # Reward residuals some future item can exactly fill.
    score += fill_mass * 30.0

    return score
# EVOLVE-BLOCK-END


