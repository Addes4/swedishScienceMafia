# EVOLVE-BLOCK-START
"""Best-fit with residual-usability bias.

Pure best-fit wastes capacity by creating many tiny residuals that no future item
can fill. We keep a running histogram of seen item sizes and, instead of simply
minimizing the residual, we score a placement by how expensive the leftover space
is: a residual that matches a common item size is worth keeping open, while a
residual that is too small for typical items is dead space and should be avoided.

Score = -(residual) + usability_bonus(residual)

The bonus is small so that in the normal case we still behave like best-fit, but
it breaks ties (and near-ties) in favor of leaving fillable residuals.
"""
import numpy as np

# Running histogram of item sizes seen so far (1..100).
_hist = np.zeros(101, dtype=np.float64)
_total = 0


def priority(item, bins):
    global _hist, _total

    # Update the empirical distribution with the current item.
    _hist[item] += 1.0
    _total += 1.0

    # Estimate how "fillable" a residual r is: probability mass of item sizes
    # that could slot neatly into r (i.e. small enough to fit, and ideally close).
    # We keep it cheap: use a coarse kernel over recent distribution.
    probs = _hist / _total if _total > 0 else _hist

    # residual after placing item in each candidate bin
    residual = bins - item  # int64, >= 0

    # Usability of each residual: mass of future items with size <= residual.
    # Cumulative distribution of item sizes.
    cdf = np.cumsum(probs)  # cdf[s] = P(item_size <= s), index 0..100
    # Clip residuals to [0,100] for lookup.
    r_clip = np.clip(residual, 0, 100).astype(np.int64)
    fill_prob = cdf[r_clip]

    # Dead-space penalty: a residual that is too small for most items
    # (fill_prob near 0) is worthless; we prefer to avoid it.
    # Bonus proportional to fill_prob, scaled small relative to residual.
    # residual spans 0..100 so a weight of up to ~5 keeps best-fit dominant.
    usability = 5.0 * fill_prob

    return -(residual) + usability
# EVOLVE-BLOCK-END

