# EVOLVE-BLOCK-START
"""Best-fit with future-fill viability (clean).

Pure best fit leaves bins with tiny residuals that no future item can use.
Sizes come from a fixed Weibull-like distribution (mean ~40).  A residual is
useful only if some future item fits it, and valuable if future items likely
fill it exactly.

Rule: score = -residual (best fit) with a strong perfect-seal reward, a
penalty for unusably small residuals, and moderate rewards for residuals
that future items are likely to exactly fill, based on a smoothed running
item-size histogram.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_sum = 0.0


def _init(n):
    global _n_items, _seen, _hist, _sum
    _n_items = n
    _seen = 0
    _hist = np.zeros(102, dtype=np.float64)
    _sum = 0.0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1.0
    _sum += item
    total = float(_seen)
    mean = _sum / total

    residual = bins - item  # >= 0 for shown bins
    resid_f = residual.astype(np.float64)

    # Smoothed empirical probability that this residual value appears as an
    # item size in the future.
    smoothed = 0.5 * (_hist[:-1] + _hist[1:])
    prob = smoothed / total  # length 101, index = value

    idx = np.clip(residual, 0, 100)
    fill_mass = prob[idx]

    # Best-fit core.
    score = -resid_f * 1.0

    # Perfect seal: strongest term.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize residuals too small to accept a typical item (median ~ 35).
    too_small = ((residual > 0) & (residual < 35)).astype(np.float64)
    score -= too_small * 35.0

    # Reward residuals likely to be exactly filled by a future item.
    score += fill_mass * 40.0

    # Nudge residuals toward multiples of the running mean so future items
    # can stack into them with less leftover waste.
    if mean > 0:
        mult = np.round(resid_f / mean)
        mult = np.maximum(mult, 0.0)
        waste = np.abs(resid_f - mult * mean)
        score -= waste * 0.15

        # Bonus: after subtracting a mean-sized future item, does the leftover
        # still admit a typical item or seal well?
        after = resid_f - mean
        good_after = ((after >= 0) & (after < 8)).astype(np.float64)
        score += good_after * 2.0

    return score
# EVOLVE-BLOCK-END
