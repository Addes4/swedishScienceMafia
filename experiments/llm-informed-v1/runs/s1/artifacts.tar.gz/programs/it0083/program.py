# EVOLVE-BLOCK-START
"""Conditional best fit with empirical-quantile switching.

Best fit is near-optimal when a snug fit exists; its weakness is stranding
medium residuals when no snug fit exists. We keep full state and an empirical
histogram of item sizes, and switch behavior based on whether the item can be
placed snugly anywhere.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    q10 = _quantile(0.10)

    residual = (bins - item).astype(np.float64)  # >= 0
    min_res = np.min(residual)

    if min_res <= q10:
        # Snug fit available: pure best fit, with a decisive exact-fill bonus.
        score = -residual
        score += (residual == 0).astype(np.float64) * (q10 * 0.5 + 0.25)
    else:
        # No snug fit: prefer the fullest fitting bin (smallest residual),
        # but add a mild preference for bins that end up close to empty
        # relative to the smallest expected item, consolidating waste.
        score = -residual
        # small bonus for residuals that stay below q10 (reusable by future
        # small items) so we don't strand medium chunks unnecessarily
        score += (residual < q10).astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
