# EVOLVE-BLOCK-START
"""Soft best-fit with exact-fill attractor.

Sizes are drawn from a fixed Weibull-like distribution (mean ~40).  Pure best
fit strands bins with tiny residuals that no future item fits.  We keep a strong
best-fit pull toward small residuals, but slightly soften it so that a bin whose
residual exactly matches a frequently seen item size is preferred (it can be
sealed by some future item), and a perfect (zero) residual is rewarded most.
All quantities come from a cheap running histogram of past item sizes; no median
or mean-multiple machinery is used.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen, 1)
    idx = np.clip(residual, 0, 100)

    # Probability that a future item exactly equals this residual.
    fill_mass = _hist[idx].astype(np.float64) / total

    r = residual.astype(np.float64)

    # Soft best-fit core: strongly prefer small residuals but not so sharply
    # that an exactly-fillable bin is ignored.
    score = -r

    # Strong reward for a perfect seal.
    score += (residual == 0).astype(np.float64) * 50.0

    # Reward residuals that some previously seen item size can exactly fill.
    score += fill_mass * 260.0

    return score
# EVOLVE-BLOCK-END
