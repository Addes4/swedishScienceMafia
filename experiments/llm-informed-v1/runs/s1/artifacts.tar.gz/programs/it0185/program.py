# EVOLVE-BLOCK-START
"""Waste-aware best fit.

Pure best fit leaves tiny residuals that no future item can use and never
rebalances toward bins whose residual can still be stacked by typical future
items.  Items come from a fixed Weibull-like distribution (mean ~40).

The rule keeps best fit as the core (score = -residual) and adds:
  * a strong reward for a perfect seal (residual == 0),
  * a soft penalty equal to the fraction of the mean item size that would be
    stranded in the residual (residual mod mean) / mean, so residuals that are
    clean multiples of the running mean are favored and awkward residuals are
    mildly discouraged,
  * a reward when the residual is close to one typical item size (likely to be
    exactly filled by the next fitting item).
"""
import numpy as np

_n_items = None
_seen = 0
_sum = 0


def _init(n):
    global _n_items, _seen, _sum
    _n_items = n
    _seen = 0
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    _seen += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins
    resf = residual.astype(np.float64)

    mean = _sum / _seen if _seen > 0 else 40.0

    # Best-fit core.
    score = -resf

    # Perfect seal.
    score += (residual == 0).astype(np.float64) * 60.0

    # Stacking quality: fraction of the mean item size left stranded.
    if mean > 1.0:
        frac = np.mod(resf, mean) / mean
        # If residual < mean, it packs nothing useful -> strong strand.
        small = resf < mean
        frac = np.where(small, 1.0, frac)
        big = resf >= mean
        # For residuals >= mean, leftover fraction is a mild soft penalty.
        penalty = np.where(big, frac, 0.0)
        score -= penalty * 20.0
        # Residuals below the median-useful threshold get a flat penalty only
        # if they are nonzero (perfect seal already handled above).
        score -= (small & (residual > 0)).astype(np.float64) * 12.0

    # Close to one typical item: likely to be exactly filled next.
    if mean > 1.0:
        near = np.abs(resf - mean) / mean
        score += np.exp(-near * 4.0) * 8.0

    return score
# EVOLVE-BLOCK-END

