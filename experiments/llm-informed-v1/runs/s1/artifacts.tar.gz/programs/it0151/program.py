# EVOLVE-BLOCK-START
"""Best-fit core with exact-fill targeting.

Pure best fit (minimize resulting residual) is a strong baseline.  Its main
weakness is stranding residuals that no future item can exactly fill.  Item
sizes come from a fixed distribution, so residuals equal to a common item size
are much more valuable than odd residuals.

This rule keeps best fit as the dominant term and adds a moderate bonus when
the resulting residual exactly equals a frequently seen item size.  Ties in
best fit are broken toward residuals more likely to be filled later.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1

    residual = bins - item  # >= 0 for bins the item fits in
    total = _seen

    # Empirical probability that a future item exactly matches a residual.
    # Normalize histogram counts to probabilities once per call.
    probs = _hist.astype(np.float64) / total

    idx = np.clip(residual, 0, 100)
    match_mass = probs[idx]

    # Best-fit core: prefer smaller residual (dominant).
    score = -residual.astype(np.float64)

    # Exact fill bonus: strong preference for zeroing a bin.
    score += (residual == 0).astype(np.float64) * 1000.0

    # Distribution-aware tie-breaker: residuals equal to common item sizes.
    score += match_mass * 50.0

    # Register this item's size for future statistics.
    _hist[item] += 1

    return score
# EVOLVE-BLOCK-END

