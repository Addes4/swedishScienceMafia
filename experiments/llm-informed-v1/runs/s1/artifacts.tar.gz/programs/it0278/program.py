# EVOLVE-BLOCK-START
"""Best-fit core with exact one-step "sealability" lookup from the empirical PMF.

Pure best fit is near-optimal here.  The remaining loss comes from leaving
residuals that never get sealed.  Since items come from a fixed distribution,
a small residual r is far more valuable if r is a common item size (a single
future item seals it) and even more if placing the current item makes the
resulting residual reach a 0 or a very common size.

We keep score = -residual as the dominant best-fit core, and add:
  * a strong reward for residual == 0 (perfect seal),
  * a reward proportional to the empirical PMF at the resulting residual
    (probability that a single future item exactly seals this bin),
  * a mild penalty for tiny residuals that no typical item fits,
  * a small flexibility bonus for residuals that can still hold items.
Calibrated, smooth, and cheap.
"""
import numpy as np

_n_items = None
_seen = 0
_sum = 0
_hist = None
_pmf = None


def _init(n):
    global _n_items, _seen, _sum, _hist, _pmf
    _n_items = n
    _seen = 0
    _sum = 0
    _hist = np.zeros(101, dtype=np.float64)
    _pmf = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1.0
    _sum += item

    residual = bins - item  # >= 0 for shown bins
    r = residual.astype(np.float64)

    total = max(_seen - 1, 1)
    # Empirical PMF over item sizes; add tiny smoothing so unseen sizes are not
    # treated as impossible.
    _pmf[:] = (_hist + 0.05) / (total + 0.05 * 100.0)

    idx = np.clip(residual, 0, 100)
    seal_mass = _pmf[idx]  # prob a single future item exactly seals this bin

    # Cumulative distribution: fraction of past items <= s.
    cum = np.cumsum(_pmf)
    fit_mass = cum[idx]  # prob a future item fits in this residual

    # Empirical median item size.
    median = int(np.searchsorted(cum, 0.5) + 1)
    if median < 1:
        median = 1

    # Best-fit core.
    score = -r

    # Perfect seal.
    score += (residual == 0).astype(np.float64) * 60.0

    # Reward residuals that a single future item can exactly complete.
    score += seal_mass * 90.0

    # Penalize tiny residuals no typical item can use (but not a perfect seal).
    too_small = ((residual > 0) & (residual < median)).astype(np.float64)
    score -= too_small * 25.0

    # Flexibility: residuals that still hold many item sizes are useful.
    score += fit_mass * 6.0

    # Mild preference for residuals in the mid range where chipping is safe.
    in_mid = ((residual >= 15) & (residual <= 65)).astype(np.float64)
    score += in_mid * 2.0

    return score
# EVOLVE-BLOCK-END
