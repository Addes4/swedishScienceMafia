# EVOLVE-BLOCK-START
"""Best-fit core with exact-fill and residual-usability bonuses.

Pure best fit strands bins with residuals too small for future items.  Since
item sizes come from a fixed distribution, the chance that a leftover residual
r can later be *exactly* filled by one more item is the empirical mass
hist[r]/seen.  We reward exactly that, plus a special bonus for a perfect fill
(residual 0), while keeping -residual dominant so tight packing is preserved.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    idx = np.clip(residual, 0, 100)
    exact_mass = _hist[idx].astype(np.float64) / max(_seen, 1)

    score = -residual.astype(np.float64)          # best-fit core
    score += (residual == 0).astype(np.float64) * 60.0   # perfect fill
    score += exact_mass * 30.0                    # fusable residual

    return score
# EVOLVE-BLOCK-END
