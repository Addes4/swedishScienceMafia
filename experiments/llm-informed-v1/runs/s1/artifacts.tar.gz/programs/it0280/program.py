# EVOLVE-BLOCK-START
"""Best-fit core plus a distribution-aware "future-fill" correction.

Observation from the failed attempts: every hand-tuned additive pile over
best-fit (score = -residual) performed *worse* than plain best-fit, because
the extra terms are noisy and fight the strong signal of best fit near the
optimum. The only term that has a chance to help must be sparse and strong,
not a diffuse weighted pile.

So the rule here is:
    score = -residual                      # best-fit core (dominant)
          + STRONG bonus if residual == 0  # perfect seal
          + bonus if residual equals a common item size
            (a future item can then seal this bin exactly)
          - penalty if residual is positive but too small for
            the bulk of the distribution (a "dead" residual)

The magnitudes are kept on the scale of residuals (a few capacity units),
so the terms only reorder *near ties* rather than overriding best-fit.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_sum = 0
_order = None


def _init(n):
    global _n_items, _seen, _hist, _sum, _order
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.float64)
    _sum = 0
    _order = None


def priority(item, bins):
    global _seen, _sum, _order

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1.0
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    # Empirical CDF and PMF (fraction of items at each size).
    pmf = _hist / total

    # Common item sizes: those with PMF at least half the average PMF.
    # We collapse to a 0/1 "is common" lookup once enough data exists.
    if _order is None or _seen % 64 == 0:
        avg = 1.0 / 100.0
        common = pmf >= 0.5 * avg
        _order = common.astype(np.float64)

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)

    score = -r

    # Perfect seal.
    score += (residual == 0).astype(np.float64) * 6.0

    # Residual equals a common item size -> likely to be exactly sealed.
    score += _order[idx] * 3.0

    # Dead residual: positive but smaller than the bulk of the distribution.
    # Use the 20th percentile of item sizes as the "too small" threshold.
    if _seen > 50:
        cdf = np.cumsum(pmf)
        small_thresh = float(np.searchsorted(cdf, 0.20) + 1)
    else:
        small_thresh = 5.0
    dead = ((residual > 0) & (residual < small_thresh)).astype(np.float64)
    score -= dead * 2.0

    return score
# EVOLVE-BLOCK-END

