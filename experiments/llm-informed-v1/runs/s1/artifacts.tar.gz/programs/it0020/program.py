# EVOLVE-BLOCK-START
"""Best fit with a myopic expected-waste correction using an online size histogram."""
import numpy as np

_state = {
    "hist": np.ones(101, dtype=np.float64),  # Laplace prior, index by size
    "seen": 0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    hist = _state["hist"]
    seen = _state["seen"]

    # update histogram with current item before scoring (distribution estimate)
    hist[item] += 1.0
    _state["seen"] = seen + 1

    total = hist.sum()
    p = hist / total  # p[s] = P(next item size is s)

    # For each bin, residual after placement = bins - item.
    residual = bins - item

    # Expected "usefulness" of a residual r: probability that some future item exactly
    # fills it (size == r) plus a soft bonus for residuals that can still absorb items.
    # We want to prefer placements whose residual is small (tightest fit) AND fillable.
    # Compute q[r] = p[r] for r in 0..100 (exact fill probability) for residual==0 skip.
    r_clip = np.clip(residual, 0, 100)
    exact_fill = p[r_clip]            # prob a future item exactly matches leftover

    # Soft term: residual absorbable mass = expected fraction of an item that fits,
    # but only count sizes <= r, weighted by their probability.
    # Precompute cumulative prob up to each value for speed.
    cum = np.concatenate(([0.0], np.cumsum(p)))  # cum[k] = P(size <= k)
    fit_mass = cum[r_clip]            # prob next item fits in residual

    # Base: tightest fit => prefer smallest residual (tie-break earlier bin handled by order).
    # We reward exact-fill probability strongly and mild fit_mass, subtract leftover waste.
    # Scale residual term so it stays dominant but exact-fill can flip near-ties.
    score = -residual * 1.0 + exact_fill * 40.0 + fit_mass * 0.5
    return score
# EVOLVE-BLOCK-END
