# EVOLVE-BLOCK-START
"""Best-fit with a perfect-seal reward and a small mid-range preference.

Sizes come from a fixed Weibull-like distribution (mean ~40).  Pure best fit
is a strong rule but it can leave many bins with tiny, unusable residuals and
open new bins slightly too eagerly.  A residual is valuable if a future item
can exactly seal the bin, and among residuals that are all "large" (nothing
close to a seal), the one nearest a typical future item size leaves the
least future waste.

The rule keeps best-fit (score = -residual) as the dominant core, adds a
strong reward for a perfect seal (residual == 0, impossible to beat), and a
small, bounded preference for residuals near the running mean item size.
All secondary terms have modest magnitude so they only refine close ties.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_sum = 0


def _init(n):
    global _n_items, _seen, _residuals, _sum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    mean = _sum / _seen

    # Dominant best-fit core.
    score = -residual.astype(np.float64)

    # Perfect seal: strongly prefer sealing a bin exactly.
    score += (residual == 0).astype(np.float64) * 60.0

    # Small preference for residuals near the running mean item size: a single
    # typical future item would nearly seal such a bin.
    if mean > 0:
        near_mean = np.abs(residual.astype(np.float64) - mean)
        score += np.maximum(0.0, 10.0 - near_mean) * 0.4

    return score
# EVOLVE-BLOCK-END


