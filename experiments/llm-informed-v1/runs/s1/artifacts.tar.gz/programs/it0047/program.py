# EVOLVE-BLOCK-START
"""Best fit, with a stateful exact-fill preference.

The function keeps track of the full packing (remaining capacity of every bin it has
ever seen chosen, not just the bins currently shown).  When the arriving item can
exactly fill some open bin (residual == item), that bin is strongly preferred, since a
perfect fill is never worse than best fit.  Otherwise it falls back to best fit.
"""
import numpy as np

# Per-instance state, reset by detecting the first call of a new instance.
_state = {
    "n_bins": 0,        # total bins handed to us on the first call (= number of items)
    "remaining": None,  # list tracking remaining capacity of every bin we've created/seen
    "items": 0,         # items processed so far
}

# item sizes seen so far (kept to optionally fit residual targets); not strictly needed
_seen = []


def _reset(n):
    _state["n_bins"] = n
    _state["remaining"] = [100] * n
    _state["items"] = 0
    _seen.clear()


def priority(item, bins):
    n = len(bins)
    # First call of an instance: everything is unused, so len(bins) == number of items.
    if _state["remaining"] is None or _state["items"] == 0:
        _reset(n)
    elif len(_state["remaining"]) != n:
        # Should not happen, but keep state consistent.
        _reset(n)

    rem = _state["remaining"]

    # Strong preference for an exact perfect fill of some fitting bin.
    score = -(bins - item)  # best fit: smallest positive residual first

    exact = np.where(bins == item)[0]
    if exact.size:
        score = score.astype(np.float64)
        score[exact] += 1e9

    # Record our choice's effect on the bin we will actually use.
    best = int(np.argmax(score))
    rem[best] -= int(item)
    _state["items"] += 1
    _seen.append(int(item))

    return score
# EVOLVE-BLOCK-END

