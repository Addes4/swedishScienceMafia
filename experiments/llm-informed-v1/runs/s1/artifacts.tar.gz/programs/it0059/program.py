# EVOLVE-BLOCK-START
"""Best fit with histogram-driven residual fillability tie-break.

Best fit (choose the bin with the smallest remaining capacity that still fits) is
essentially optimal for online bin packing under a near-continuous size distribution.
Its only real weakness is stranding residuals that no future item can use.

We keep the full packing state ourselves and an empirical histogram of item sizes seen.
We rank bins by best fit (smallest residual). Because best fit is near-optimal, we only
break near-ties: among bins whose residual is within a tiny margin of the minimum, we
prefer the one whose post-placement residual is most likely to be exactly filled by a
future item, estimated from the histogram and the number of items still to come.
"""
import numpy as np

# --- persistent state (fresh process per instance) ---
_n_items = None          # number of items in the instance
_seen = 0                # items seen so far
_residuals = None        # remaining capacity of every bin, indexed by bin order
_hist = None             # counts of item sizes, index 0..100


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown

    # --- best-fit base score: smaller residual => higher score ---
    score = -residual.astype(np.float64)

    # --- near-tie tie-break: fillability of the leftover ---
    # Margin (in residual units) within which we allow the tie-break to act.
    # Keep it small so best-fit ordering is essentially preserved.
    min_res = int(residual.min())
    near = residual <= (min_res + 1)

    if near.any():
        # Probability weight that a future item exactly equals a given residual r.
        # Use the empirical histogram normalized to a distribution, damped to avoid
        # overfitting to rare sizes; smooth with a tiny prior.
        total = _hist.sum()
        p = (_hist + 0.5) / (total + 0.5 * 101.0)  # Laplace-smoothed pmf over 1..100

        # Expected count of remaining items that would exactly fill residual r.
        remaining = max(_n_items - _seen, 0)
        r = residual
        # For r == 0 the bin is exactly full: that's strictly good, reward it.
        fill_pot = np.where(r == 0, 1.0, p[np.clip(r, 0, 100)] * remaining)

        # Convert to a small bonus that can only reorder near-ties.
        # Scale so the max bonus is < 1 residual unit of best-fit difference.
        bonus = np.tanh(fill_pot) * 0.5
        score = score + np.where(near, bonus, 0.0)

    return score
# EVOLVE-BLOCK-END
