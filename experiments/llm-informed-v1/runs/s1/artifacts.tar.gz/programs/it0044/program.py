# EVOLVE-BLOCK-START
"""Best fit with tie-break toward larger residual among near-equal fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, ties to first bin.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in, in bin order.
    """
    resid = bins - item
    # Primary: smallest residual (best fit). Secondary small bonus for larger residual
    # among near-equal choices, to avoid sealing bins with barely-usable holes.
    return -resid + 1e-3 * bins
# EVOLVE-BLOCK-END

