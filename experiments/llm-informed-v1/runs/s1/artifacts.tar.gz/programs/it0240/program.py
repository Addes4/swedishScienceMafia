# EVOLVE-BLOCK-START
"""Best-fit with fillability-aware residual scoring.

Core: pure best fit (score = -residual) makes bins as full as possible,
which is near-optimal for these distributions.

Refinements grounded in the empirical item distribution:
  * strong reward for a residual of 0 (perfect seal),
  * reward for residuals whose exact size has appeared as an item, scaled
    by empirical frequency: such a residual is likely to be exactly filled,
  * penalty for nonzero residuals below the smallest item seen so far,
    which are genuinely unusable by any future item.
"""
import numpy as np

_n_items = None
_seen = 0
_min_item = None
_hist = None


def _init(n):
    global _n_items, _seen, _min_item, _hist
    _n_items = n
    _seen = 0
    _min_item = None
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen, _min_item

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None or len(_hist) != 101:
        _init(n)

    _seen += 1
    if _min_item is None or item < _min_item:
        _min_item = item
    _hist[item] += 1

    residual = bins - item  # >= 0 for shown bins
    total = max(_seen, 1)
    res_f = residual.astype(np.float64)

    # Best-fit core.
    score = -res_f

    # Perfect seal.
    score += (residual == 0).astype(np.float64) * 60.0

    idx = np.clip(residual, 0, 100)
    # Empirical frequency of exactly this residual size as a future item.
    freq = _hist[idx].astype(np.float64) / total
    score += freq * 90.0

    # Penalize residuals that no seen item can fit.
    if _min_item is not None:
        unusable = ((residual > 0) & (residual < _min_item)).astype(np.float64)
        score -= unusable * 40.0

    return score
# EVOLVE-BLOCK-END
