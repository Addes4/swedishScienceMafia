# EVOLVE-BLOCK-START
"""Best-fit core with a light, stable tie-break.

The proven rule is essentially strict best-fit: score = -residual.  Earlier
attempts added heavy histogram/median/mean bonus stacks and consistently lost
score.  This version keeps the core and adds only cheap, stable corrections:

  * a strong reward for residual == 0 (perfect seal), since such a bin is
    finished and can never waste capacity,
  * a small penalty for tiny nonzero residuals that are unlikely to ever
    accept a future item,
  * a light reward for residuals that exactly match a frequently seen item
    size (high chance of a future perfect seal), computed from a smoothed
    running frequency estimate,
  * a very small epsilon tie-break so, among equal residuals, the earlier
    (fuller) bin is preferred.

All terms are cheap (vectorized numpy, O(number of shown bins)).
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_freq = None
_sum = 0
_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _freq, _sum, _count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _freq = np.zeros(101, dtype=np.float64)
    _sum = 0
    _count = 0


def priority(item, bins):
    global _seen, _sum, _count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _sum += item
    _count += 1

    # Smoothed running frequency estimate (Laplace-style).
    _freq *= 0.999
    _freq[item] += 1.0

    residual = bins - item  # >= 0 for shown bins

    total = _freq.sum() + 1.0
    freq_rate = _freq / total

    score = -residual.astype(np.float64)

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 50.0

    # Penalize tiny nonzero residuals unlikely to accept future items.
    tiny = ((residual > 0) & (residual < 8)).astype(np.float64)
    score -= tiny * 6.0

    # Reward residuals matching a common item size (likely perfect seal).
    idx = np.clip(residual, 0, 100)
    score += freq_rate[idx] * 120.0

    # Small epsilon tie-break toward fuller (earlier) bins.
    score -= residual.astype(np.float64) * 1e-4

    return score
# EVOLVE-BLOCK-END


