# EVOLVE-BLOCK-START
"""Best-fit core with endgame-aware perfect-seal pressure.

Sizes come from a fixed Weibull-like distribution (mean ~40), items arrive
online, and we only get to rank the bins the item fits in.  Pure best-fit is
the strongest known core (score = -residual).  The only reliable extra signal
seen in experiments is a small reward for bins that get perfectly sealed.

The refinement here: a residual of 0 is only *achievable* late in the run when
few items remain.  Tracking how many items are still to come lets the seal
reward ramp up as the run approaches its end, so we seal aggressively at the
tail (where it saves bins) without distorting choices early on.
"""
import numpy as np

_n_items = None
_seen = 0
_sum = 0


def _init(n):
    global _n_items, _seen, _sum
    _n_items = n
    _seen = 0
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    _seen += 1
    _sum += item
    remaining = _n_items - _seen

    residual = bins - item  # >= 0 for shown bins
    res = residual.astype(np.float64)

    # Best-fit core (dominant term).
    score = -res

    # Perfect seal reward, ramping up as the item budget shrinks.
    # Early on, sealing is incidental; late on, it directly saves bins.
    pressure = 1.0 - remaining / float(max(_n_items, 1))  # 0 -> 1 over the run
    seal_bonus = 40.0 + 80.0 * pressure
    score += (residual == 0).astype(np.float64) * seal_bonus

    return score
# EVOLVE-BLOCK-END
