# EVOLVE-BLOCK-START
"""Best-fit with a stranded-residual penalty.

Extensive experiments show pure best-fit (score = -residual) is very strong
here.  The small remaining loss comes from best-fit occasionally stranding a
tiny residual that no later item (typical sizes ~20-70) can ever fill.  We
keep best-fit as the core and add one calibrated penalty for such stranded
residuals, while still strongly rewarding perfect seals (residual 0).
"""
import numpy as np

_residuals = None
_hist = None
_seen = 0


def _init(n):
    global _residuals, _hist, _seen
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _seen = 0


def priority(item, bins):
    global _seen

    n = len(bins)
    if _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for shown bins

    r = residual.astype(np.float64)

    # Best-fit core.
    score = -r

    # Perfect seal reward.
    score += (residual == 0).astype(np.float64) * 60.0

    # Stranded-residual penalty: residuals in (0, T) that are unlikely to be
    # exactly filled by a future item are slightly undesirable relative to
    # keeping the residual a bit larger.  T chosen around the low end of the
    # item distribution.
    T = 15.0
    stranded = ((residual > 0) & (residual < T)).astype(np.float64)
    score -= stranded * 8.0

    return score
# EVOLVE-BLOCK-END
