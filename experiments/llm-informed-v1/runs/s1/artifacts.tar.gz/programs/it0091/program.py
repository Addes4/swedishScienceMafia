# EVOLVE-BLOCK-START
"""Best fit with empirical reuse-awareness.

Best fit is near-optimal for online bin packing under a near-continuous size
distribution. Its weakness is stranding residuals that no future item can use.
We track the whole packing plus an empirical histogram of item sizes seen so
far, and reward placements whose leftover capacity matches a plausible future
item size (so it is likely to be reused), while penalizing leftovers that are
too small to ever be refilled.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_freq = None
_norm = 1.0


def _init(n):
    global _n_items, _seen, _hist, _freq, _norm
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _freq = np.zeros(101, dtype=np.float64)
    _norm = 1.0


def priority(item, bins):
    global _seen, _norm, _freq

    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    # empirical probability of each size (smoothed a bit for small samples)
    freq = _hist.astype(np.float64) / _seen
    _freq = freq

    residual = bins - item  # >= 0, int64
    score = -residual.astype(np.float64)

    # probability that each residual can be filled by a future item:
    # p_fill(r) ~= 1 - prod over sizes s<=r of (1 - freq[s])  -> approximate
    # with sum of freq over sizes that fit in r (cheap and monotone-ish).
    csum = np.cumsum(freq)  # csum[r] = sum_{s<=r} freq[s]
    r = residual
    # reward residuals that are large enough to hold a plausible future item
    reuse = csum[np.clip(r, 0, 100)]
    score += reuse * 6.0

    # strongly reward exact fills (never harmful)
    score += (r == 0).astype(np.float64) * 3.0

    return score
# EVOLVE-BLOCK-END
