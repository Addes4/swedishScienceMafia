# EVOLVE-BLOCK-START
"""Distribution-aware residual targeting via smoothed exact-fill probability.

Key idea: the cheapest way to close a bin is to later drop in an item that
exactly matches the residual.  So after tentatively placing the current item,
we estimate the probability (under the empirical item-size distribution seen
so far, smoothed) that a future item will exactly fill the resulting residual,
and give that residual a large bonus.  A best-fit core breaks ties/steers.

Unlike the previous version, the "density" bonus is a smooth kernel-smoothed
estimate rather than a single histogram bin hit, which generalizes better and
avoids spikes at sizes that happen to have appeared once.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_kernel = None


def _init(n):
    global _n_items, _seen, _residuals, _hist, _kernel
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.float64)
    # Triangular smoothing kernel over item sizes
    _kernel = np.array([1.0, 2.0, 3.0, 2.0, 1.0])
    _kernel /= _kernel.sum()


def _density_table():
    # Smooth histogram to get a soft mass estimate per size 0..100.
    h = _hist
    k = _kernel
    m = len(k) // 2
    padded = np.concatenate([np.zeros(m), h, np.zeros(m)])
    dens = np.correlate(padded, k, mode='valid')  # length 101
    return dens


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 where the item fits

    total = max(_seen, 1)
    dens = _density_table() / total  # soft probability mass per size

    idx = np.clip(residual, 0, 100)
    # Probability mass concentrated on exactly matching the residual.
    exact_mass = dens[idx]

    # Also reward residuals that are large enough to host the common item
    # sizes but small enough to be a "tight" fit; use a soft concave tilt.
    score = -residual.astype(np.float64)          # best-fit core
    score += (residual == 0).astype(np.float64) * 120.0
    # Strong distribution-aware term: prefer leaving residuals future items
    # are likely to exactly fill.
    score += exact_mass * 400.0
    # Mild tilt toward residuals near the median item size (a solid packing
    # target), gently, without dominating the best-fit core.
    score += 0.25 * np.minimum(residual, 60).astype(np.float64)

    return score
# EVOLVE-BLOCK-END

