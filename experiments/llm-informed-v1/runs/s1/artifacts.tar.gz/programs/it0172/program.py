# EVOLVE-BLOCK-START
"""Distribution-aware best fit with exact-fill viability.

Best fit (score = -residual) is a strong core rule, but it tends to leave
residuals that no future item can use.  Since item sizes come from a fixed
Weibull-like distribution (mean ~40), the residual r left after placing an
item can be "used" later only if some future item fits it.  The most valuable
residual is one that a future item exactly fills, so we add a bonus equal to
the empirical probability that some future item equals that residual, plus a
smaller term for residuals that can accept at least some item.  This lets the
rule prefer sealing/consolidating bins when the data supports it, while the
unmodified best-fit core still dominates.

State kept: observed item histogram; nothing else is needed because best fit
uses the residual directly.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for shown bins (int64)

    total = max(_seen - 1, 1)  # items seen strictly before this one

    idx = np.clip(residual, 0, 100)

    # Empirical mass at the exact residual size: chance of a perfect fill.
    fill_mass = _hist[idx].astype(np.float64) / total
    # Empirical mass at sizes <= residual: chance some item still fits.
    cum_hist = np.cumsum(_hist).astype(np.float64) / total
    fit_mass = cum_hist[idx]

    # Best-fit core.
    score = -residual.astype(np.float64)

    # Perfect seal: strong but bounded reward.
    score += (residual == 0).astype(np.float64) * 60.0

    # Prefer residuals a future item can exactly fill.
    score += fill_mass * 45.0

    # Mild reward for residuals that admit at least some future item.
    score += fit_mass * 6.0

    return score
# EVOLVE-BLOCK-END
