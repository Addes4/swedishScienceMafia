# EVOLVE-BLOCK-START
"""Best-fit with empirical small-residual suppression and exact-fill reward.

Pure best fit occasionally creates residuals that essentially no future item
can use (too small), permanently wasting that capacity.  Since item sizes
come from a fixed distribution, a residual is wasteful only if it is below
the smallest size we still expect to see, and it is valuable if it matches a
size that future items frequently take (an exact fill).

Rule: score = -residual (best fit) with
  * a strong reward for residual == 0 (perfect seal),
  * a moderate penalty for residuals below the empirical 5th percentile,
  * a small reward proportional to the empirical mass at the exact residual.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    # Empirical 5th percentile of item sizes via cumulative histogram.
    target = 0.05 * total
    cum = 0.0
    p05 = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            p05 = s
            break

    idx = np.clip(residual, 0, 100)
    # Empirical mass at the exact residual size (chance of an exact fill).
    fill_mass = _hist[idx].astype(np.float64) / total

    # Best-fit core.
    score = -residual.astype(np.float64)

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize only residuals below the smallest size we still expect.
    too_small = ((residual > 0) & (residual < p05)).astype(np.float64)
    score -= too_small * 20.0

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 25.0

    return score
# EVOLVE-BLOCK-END


