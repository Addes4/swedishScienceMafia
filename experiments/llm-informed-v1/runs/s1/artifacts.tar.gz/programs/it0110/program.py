# EVOLVE-BLOCK-START
"""Best-fit with a smooth modal-residual bonus.

Best fit alone (pick the smallest post-placement residual) packs tightly but
leaves small residuals that later items cannot use.  Here we keep best fit as
the dominant term, and add a smooth, graded bonus for residuals that sit near
the empirically most common item size (the mode of the seen sizes) -- the size
most likely to arrive next.  A residual close to that mode is "resumable" and
thus valuable; the bonus decays linearly away from the mode, so there is no
hard cliff and no tuning to a specific instance.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def _mode():
    """Empirically most common item size seen so far (1..100)."""
    if _seen <= 0:
        return 1
    return int(np.argmax(_hist))


def _q(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in
    score = -residual.astype(np.float64)

    # "Resumable" targets: the modal size and a small-size floor (q10).
    m = _mode()
    q10 = _q(0.10)

    # Smooth triangular bonus peaked at the modal residual; width scales with m.
    width = max(m, 1)
    dist = np.abs(residual - m).astype(np.float64)
    modal_bonus = np.maximum(0.0, 1.0 - dist / width)
    score += modal_bonus * 20.0

    # Bonus for keeping at least a plausible tiny-item slot open.
    score += (residual >= q10).astype(np.float64) * 10.0

    # Exact fills are always excellent.
    score += (residual == 0).astype(np.float64) * 60.0

    return score
# EVOLVE-BLOCK-END
