# EVOLVE-BLOCK-START
"""Competitive best-fit with future-fill viability (histogram reachability).

Pure best fit leaves a few bins with tiny residuals that no future item can
ever use, and it never rebalances toward bins that can still accept typical
items.  Since sizes come from a fixed Weibull-like distribution (mean ~40),
a residual is *useful* only if some future item fits it, and it is *valuable*
if future items are likely to exactly fill it.

This rule keeps best-fit as the core (score = -residual) but:
  * penalizes residuals below the empirical median item size,
  * rewards residuals whose size has high empirical histogram mass,
  * gives a strong reward for residuals that equal 0 (perfect seal),
  * rewards residuals reachable by common small future items,
  * rewards a candidate residual that pairs with another open bin's residual
    to sum to a size with high empirical histogram mass (future seal pair).
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0
_cum = None


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum, _cum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _cum = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)
    mean = _sum / _seen

    # Empirical median item size (approx) via cumulative histogram.
    target = 0.5 * total
    cum = 0.0
    median = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            median = s
            break

    # Cumulative histogram (fraction of items <= s).
    _cum[:] = np.cumsum(_hist) / total

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    fit_mass = _cum[idx]

    # Best-fit core.
    score = -r * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 70.0

    # Penalize residuals too small to accept a typical (median) item,
    # but only if they are not a perfect seal.
    too_small = ((residual > 0) & (residual < median)).astype(np.float64)
    score -= too_small * 35.0

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 45.0

    # Pairwise-seal signal.  For each candidate bin, its new residual is
    # residual[k].  Another open bin has residual ro (>0).  If
    # residual[k] + ro == s for some common item size s, one future item of
    # size s can exactly seal that other bin (leaving this one with
    # residual[k]-... wait: item of size s = residual[k]+ro can't fit this
    # bin if residual[k] < s.  Reconsider: pairing works when residual[k]
    # itself can be filled by an item whose size equals *another bin's*
    # residual, i.e. residual[k] matches some ro.  More usefully: an item of
    # size equal to residual[k] would seal this bin.  We already capture that
    # via fill_mass.  Additionally reward small residuals which, combined with
    # exactly one more future item of a common size, reach 0 or another
    # fillable value.
    #
    # Practical pairwise term: reward a candidate residual r when there exists
    # another currently open residual ro such that r + ro is a size with high
    # empirical mass (so a future item seals the ro bin), OR ro + r is
    # fillable.  Because the item now goes *into* this bin, this bin's new
    # residual is r; the ro bin remains available for a future item that
    # exactly matches ro.
    pair_score = np.zeros_like(r)
    if _seen > 1:
        # collect unique positive residuals of other open bins
        others = _residuals[_residuals > 0]
        if others.size:
            # empirical mass of item-size == ro (probability a future item
            # exactly fills that other bin)
            uni, cnts = np.unique(others, return_counts=True)
            mass = _hist[np.clip(uni, 0, 100)].astype(np.float64) / total
            # for each candidate residual r, best matching ro whose size has
            # high fill probability
            # candidate pairs: r such that (r + ro) in [1,100] with mass at
            # (r+ro)?  Simpler and effective: reward mass of ro summed over
            # others with ro close to r's complement toward mean.
            # Use vectorized: for each candidate r, compute sum over uni of
            # mass[u] * [r + uni[u] <= 100] * hist_mass_at(r+uni[u])
            # Build a compact lookup of hist fractions.
            hist_frac = _hist.astype(np.float64) / total
            for k in range(len(r)):
                rk = int(residual[k])
                if rk <= 0:
                    continue
                # sums rk + u: reward if that sum has high mass (future item
                # of that size could seal an other bin whose residual is u,
                # given this item leaves rk... actually the future item goes
                # into the other bin, not this one, so just yield mass of u)
                # Here reward presence of others whose residual equals a
                # common item size, weighted by mass -- signals a real seal.
                s = 0.0
                for u, m in zip(uni, mass):
                    uu = int(u)
                    if uu + rk <= 100:
                        col = hist_frac[rk + uu]
                        if col > 0:
                            s += m * col
                pair_score[k] = s
        # scale
        score += pair_score * 25.0

    # Reward residuals reachable by a common small item.
    in_mid = ((residual >= 20) & (residual <= 70)).astype(np.float64)
    score += in_mid * 3.0

    # Reward residuals that admit at least some future item (flexibility).
    score += fit_mass * 8.0

    # Nudge residuals toward the running mean.
    if mean > 0:
        near_mean = np.abs(r - mean)
        score += np.exp(-(near_mean / (0.5 * mean + 1.0)) ** 2) * 4.0
        score += (r >= median).astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END
