# EVOLVE-BLOCK-START
"""Best fit with a decisive exact-fill priority.

Best fit (smallest remaining capacity that still fits) is essentially optimal for
online bin packing under a near-continuous size distribution. The only firm
improvement over pure best fit is to strongly prefer placing an item so that the
bin becomes exactly full: a perfect fill removes a bin from the pool at no cost,
whereas leaving any positive residual can strand space. We therefore rank by
smallest post-placement residual, and add a large bonus for residual == 0 so it
always outranks every non-perfect placement (ties among perfect fills go to the
first bin, which is fine).

No other perturbations are applied, so the underlying best-fit ordering is left
completely intact for all non-perfect placements.
"""
import numpy as np

_residuals = None  # remaining capacity of every bin, indexed by bin order


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    global _residuals

    n = len(bins)
    if _residuals is None or len(_residuals) != n:
        _residuals = np.full(n, 100, dtype=np.int64)

    residual = bins - item  # >= 0 for all bins shown

    score = -residual.astype(np.float64)
    # Decisive bonus: always prefer a placement that fills the bin exactly.
    score += (residual == 0).astype(np.float64) * 1000.0

    return score
# EVOLVE-BLOCK-END
