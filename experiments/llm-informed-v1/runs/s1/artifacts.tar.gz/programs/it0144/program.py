# EVOLVE-BLOCK-START
"""Distribution-aware residual targeting with best-fit core.

Pure best fit strands bins with residuals that no future item can fit.  Item
sizes come from a fixed (Weibull) distribution with mean ~40, so residuals
near common item sizes are far more likely to be reused.  The rule keeps a
best-fit core (prefer the smallest resulting residual), strongly rewards an
exact fill (residual 0), and adds a smooth viability term proportional to the
empirical probability mass of future item sizes that can still fit into the
resulting residual.
"""
import numpy as np

_n_items = None
_seen = 0
_cdf = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _cdf, _bin_count
    _n_items = n
    _seen = 0
    _cdf = np.zeros(101, dtype=np.float64)  # cumulative counts of sizes seen
    _bin_count = 0


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _cdf is None:
        _init(n)

    _seen += 1
    # Update cumulative histogram (counts of sizes <= s).
    _cdf[item:] += 1.0

    residual = bins - item  # >= 0

    total = float(_seen)
    # Empirical CDF of sizes seen so far, evaluated at each residual:
    # P(future size <= r).  This is the chance a future item fits in r.
    r = np.clip(residual, 0, 100)
    cdf_at_r = _cdf[r] / total

    # Chance of an exact fill by a future item (smoothing to avoid zero).
    freq = np.zeros(101, dtype=np.float64)
    freq[1:] = np.diff(_cdf)
    exact = freq[r] / total

    score = -residual.astype(np.float64)          # best-fit core
    score += (residual == 0).astype(np.float64) * 80.0
    score += cdf_at_r * 60.0                       # viability: room for future items
    score += exact * 25.0                          # bonus for likely exact refills

    return score
# EVOLVE-BLOCK-END
