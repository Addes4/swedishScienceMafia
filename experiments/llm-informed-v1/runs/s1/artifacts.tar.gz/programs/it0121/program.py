# EVOLVE-BLOCK-START
"""Harmonic-style online bin packing.

The classic harmonic algorithm partitions item sizes into classes and, for an
item of a given class, targets bins whose residual capacity lies in a specific
class-dependent interval.  This bounds the wasted space per bin better than
plain best fit.  We adapt the class thresholds to the empirical mean of the
items seen so far, and within the target interval we use best-fit tie-breaking.

State kept between calls:
  - seen item count and empirical mean (for class boundaries)
  - the full vector of residuals of every open bin (we only see bins the item
    fits in, but we track all of them ourselves).
"""
import numpy as np

_n_items = None
_seen = 0
_sum = 0.0
_residuals = None


def _init(n):
    global _n_items, _seen, _sum, _residuals
    _n_items = n
    _seen = 0
    _sum = 0.0
    _residuals = np.full(n, 100, dtype=np.int64)


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _sum += item

    # We are shown residuals only for bins the item fits in.  Reconstruct the
    # displayed residuals into our tracked array: bins we track that are not
    # shown are either full-open (residual 100, item fits) or hold residual
    # < item (item does not fit).  The harness passes exactly the fitting bins
    # in bin-index order, so we match them to our tracked residual vector.
    fitted_indices = np.nonzero(_residuals >= item)[0]
    m = len(bins)
    if m == len(fitted_indices):
        # Fast path: residuals in parallel order (usually identical ordering).
        resulting = bins - item
        _residuals[fitted_indices] = resulting
    else:
        # Fallback: match by value multiset in index order.
        order = np.argsort(_residuals, kind="stable")
        resulting = bins - item
        # Should not normally happen; just adopt displayed residuals in order.
        k = 0
        for idx in range(n):
            if _residuals[idx] >= item:
                if k < m:
                    _residuals[idx] = bins[k] - item
                    k += 1
        resulting = None

    # Compute class boundary from empirical mean.
    mean = _sum / _seen
    # Harmonic-style targets scaled by mean.  Large items -> aim to fill bins
    # well (small residual); medium items -> moderate residual; small items ->
    # keep larger residuals (allow more small items to accumulate).
    if item >= 2.0 * mean:
        target_lo = 0
        target_hi = 0
    elif item >= mean:
        target_lo = 0
        target_hi = int(mean)
    elif item >= 0.5 * mean:
        target_lo = max(1, int(0.5 * mean))
        target_hi = int(mean) + int(mean)
    else:
        target_lo = max(1, int(mean))
        target_hi = 101

    residual = bins.astype(np.int64) - item  # >= 0

    # Score: within target [lo, hi] prefer smaller residual (best fit);
    # outside prefer by closeness to the interval, exact fills get a bonus.
    score = -residual.astype(np.float64)
    # Strong bonus for being inside the target interval.
    inside = (residual >= target_lo) & (residual <= target_hi)
    score += inside.astype(np.float64) * 60.0
    # Even stronger for exact fills when the class targets zero.
    score += (residual == 0).astype(np.float64) * 30.0
    # Slightly prefer bigger residual within the interval for small items to
    # avoid stranding tiny residuals; for small items reward larger residual.
    if item < 0.5 * mean:
        w = residual.astype(np.float64)
        score += inside.astype(np.float64) * w * 0.02

    return score
# EVOLVE-BLOCK-END

