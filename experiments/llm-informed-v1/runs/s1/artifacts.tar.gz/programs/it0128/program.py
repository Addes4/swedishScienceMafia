# EVOLVE-BLOCK-START
"""Best fit with an adaptive reserve threshold.

Pure best fit strands bins whose residual is smaller than almost any future
item, so those bins are wasted forever.  The fix is a soft reserve: residuals
below a low quantile of the observed size distribution get a heavy penalty
(they are very unlikely to accept a future item), while among viable bins we
still prefer the smaller residual (best-fit core).  This keeps the strong
packing behavior of best fit but stops it from "wasting" bins on residuals
that can never be filled.

State kept: size histogram, item count, number of bins seen.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins.astype(np.float64) - item

    # Empirical low quantile: smallest size that future items seldom go under.
    total = _seen
    target = 0.05 * total
    cum = 0
    q05 = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            q05 = s
            break

    score = -residual  # best-fit core: smaller residual is better

    # Penalize residuals that are too small to be useful to future items.
    below = residual < q05
    score -= below.astype(np.float64) * 1000.0

    # Exact fills are especially good (they close a bin cleanly).
    score += (residual == 0).astype(np.float64) * 500.0

    return score
# EVOLVE-BLOCK-END
