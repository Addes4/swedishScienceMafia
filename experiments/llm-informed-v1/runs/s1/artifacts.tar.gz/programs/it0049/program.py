# EVOLVE-BLOCK-START
"""Best fit, refined late in the run by a histogram of reusable residual sizes."""
import numpy as np

_S = {}
_HIST = np.zeros(101, dtype=np.int64)
_CENTERS = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = len(bins)
    if 'hist' not in _S:
        _S['hist'] = np.zeros(101, dtype=np.int64)
        _S['count'] = 0
        _S['total'] = n  # number of items in the instance

    _S['hist'][item] += 1
    _S['count'] += 1
    hist = _S['hist']

    residual = bins - item  # remaining capacity after placing the item here

    if _S['count'] * 2 >= _S['total']:
        # second half: prefer placements whose residual matches a common size
        # weight = smoothed historical frequency of that residual as a future item size
        w = hist.astype(np.float64).copy()
        # light smoothing so unseen sizes still considered
        w += 1.0
        match = w[residual]
        # combine: primarily avoid tiny unusable residuals, then maximize reuse
        score = -residual.astype(np.float64) + 0.5 * match
    else:
        score = -residual.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
