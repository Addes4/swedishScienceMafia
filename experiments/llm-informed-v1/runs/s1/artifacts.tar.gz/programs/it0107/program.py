# EVOLVE-BLOCK-START
"""Best fit with a smooth, empirically-graded viability bonus.

The lesson from earlier attempts is that a hard threshold on the post-placement
residual hurts: it strands moderately-full bins and pushes items into emptier
bins, increasing the total count.  Best fit alone is strong, but blindly
filling a bin to a residual that no future item can use wastes that space.

This version keeps best fit dominant and adds a small, smooth bonus for
residuals that are at least the empirical 10th percentile of seen sizes (a
residual likely to be hostable by some future small item), plus a larger
reward for exact fills.  The bonus is graded rather than a cliff so the
ordering between near-threshold residuals stays close to best fit.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    # Dominant term: best fit (smaller residual is better).
    score = -residual.astype(np.float64)

    q10 = _quantile(0.10)

    # Smooth viability bonus: residuals at or above q10 get a graded reward
    # that grows slightly with residual, but capped so best-fit ordering
    # dominates locally.  Below q10, no bonus.
    if q10 > 0:
        frac = np.clip((residual - q10) / float(max(q10, 1)), 0.0, 1.0)
    else:
        frac = np.ones_like(residual, dtype=np.float64)
    viable = (residual > 0).astype(np.float64)
    score += 12.0 * viable * (residual >= q10).astype(np.float64)
    score += 6.0 * frac

    # Exact fills are strongly preferred.
    score += (residual == 0).astype(np.float64) * 40.0

    return score
# EVOLVE-BLOCK-END

