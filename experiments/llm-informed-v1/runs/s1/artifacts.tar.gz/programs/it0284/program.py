# EVOLVE-BLOCK-START
"""Best-fit with a dead-residual penalty and a perfect-seal bonus.

The empirically strongest online rule on this distribution is plain best fit
(score = -residual).  Two small, monotone corrections fix its main weakness:
it sometimes strands tiny positive residuals that no future item can use, and
it doesn't specially celebrate sealing a bin exactly.  Both corrections are
small so the rule stays essentially best fit.
"""
import numpy as np

_n_items = None
_seen = 0
_min_item = 101


def _init(n):
    global _n_items, _seen, _min_item
    _n_items = n
    _seen = 0
    _min_item = 101


def priority(item, bins):
    global _seen, _min_item

    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    _seen += 1
    if item < _min_item:
        _min_item = item

    residual = bins - item  # >= 0 for the shown bins
    r = residual.astype(np.float64)

    # Best-fit core (dominant).
    score = -r

    # Perfect seal: reward a bin that ends up exactly full.
    score += (residual == 0).astype(np.float64) * 50.0

    # Truly dead residual: positive but smaller than the smallest item ever
    # seen, so no arriving item can ever fit it again. Discourage leaving these.
    dead = (residual > 0) & (residual < _min_item)
    score -= dead.astype(np.float64) * 20.0

    return score
# EVOLVE-BLOCK-END
