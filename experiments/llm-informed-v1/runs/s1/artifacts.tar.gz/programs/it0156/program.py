# EVOLVE-BLOCK-START
"""Best-fit core with strictly subordinate distribution-aware tie-breakers.

Empirically, pure best fit (smallest resulting residual) is a very strong
online rule on this distribution.  Every previous attempt that mixed large
additive bonuses into the score perturbed the best-fit ordering and hurt.

The fix: make the best-fit term dominate by a huge constant multiplier, so
the auxiliary terms can only ever break exact ties in residual, never reverse
a strict best-fit preference.  Among ties (equal residual), prefer bins whose
residual matches a common item size (more likely to be exactly filled later).
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = (bins - item).astype(np.float64)  # >= 0 for shown bins

    # Dominant best-fit ordering.  Big multiplier guarantees the auxiliary
    # terms below cannot overturn a strict residual preference.
    score = -residual * 1e6

    # Tie-breaker: empirical probability that the residual equals a common
    # future item size (exact-fill opportunity).  Bounded by 1.
    idx = np.clip(residual, 0, 100).astype(np.int64)
    fill_mass = _hist[idx].astype(np.float64) / max(_seen, 1)

    # Tie-breaker: leaving residual 0 is perfect (finished bin).
    score += (residual == 0).astype(np.float64) * 10.0
    # Tie-breaker: larger residual (less tight packing of this bin) is slightly
    # preferred only among equal residual matches -- here residual is equal so
    # this reduces to preferring denser exact-match sizes; center around the
    # empirical mean so frequent sizes rank above rare ones.
    score += fill_mass * 5.0

    return score
# EVOLVE-BLOCK-END

