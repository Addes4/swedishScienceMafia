# EVOLVE-BLOCK-START
"""Best-fit core with Laplace-smoothed exact-fill lookahead.

The dominant good rule here is best fit: choose the bin that leaves the
smallest nonnegative residual, breaking ties toward residuals that a future
item is most likely to close exactly.  Item sizes come from a fixed
distribution with mean ~40, so the empirical histogram seen so far is a good
proxy for the future.  We smooth it (Laplace) so early decisions are not
driven by noise, and weight the exact-fill bonus by the fraction of items
remaining: early on it pays to keep residuals that match common sizes; near
the end the exact-fill bonus matters less than simply packing tightly.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    # Laplace-smoothed histogram update.
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for bins the item fits in

    total = _hist.sum()
    # Probability that a future item equals residual r, smoothed.
    idx = np.clip(residual, 0, 100)
    # add 1 to every bucket, so denom is total + 101
    mass = (_hist[idx] + 1.0) / (total + 101.0)

    # Fraction of items remaining (0..1); near 1 early, near 0 late.
    frac_left = (_n_items - _seen) / float(_n_items)

    score = -residual.astype(np.float64)
    # Exact closure: strong, and stronger when many items remain.
    score += (residual == 0).astype(np.float64) * (60.0 * frac_left + 20.0)
    # Bonus for residuals matching common upcoming sizes.
    score += mass * (80.0 * frac_left)

    return score
# EVOLVE-BLOCK-END
