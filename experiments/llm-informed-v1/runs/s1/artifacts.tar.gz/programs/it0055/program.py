# EVOLVE-BLOCK-START
"""Best fit with residual-reusability awareness.

Best fit (choose the bin with the smallest remaining capacity that still fits) is
essentially optimal for online bin packing under a near-continuous size distribution.
Its one weakness is that it can strand tiny residuals that no future item can ever use.

We keep the full packing state ourselves (the harness only shows us the bins the item
fits in, but we choose the bin, so we can reconstruct everything). We also keep an
empirical histogram of item sizes seen so far. A residual is "reusable" if it is at
least as large as the smallest item we expect to still arrive. We rank bins by
best fit (smallest residual), but give a bonus to bins whose post-placement residual
stays reusable, so we do not paint ourselves into a corner with dead space.
"""
import numpy as np

# --- persistent state (fresh process per instance) ---
_n_items = None          # number of items in the instance
_seen = 0                # items seen so far
_residuals = None        # remaining capacity of every bin, indexed by bin order
_min_seen = 101          # smallest item size observed so far
_hist = None             # counts of item sizes, index 0..100


def _init(n):
    global _n_items, _seen, _residuals, _min_seen, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _min_seen = 101
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    global _seen, _min_seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    if item < _min_seen:
        _min_seen = item
    _hist[item] += 1

    # Smallest size we plausibly still expect. Use the observed minimum; if we have
    # not seen anything small yet, fall back to a conservative small value.
    if _min_seen <= 100:
        floor = _min_seen
    else:
        floor = 1

    # Best fit: smallest residual first => highest score. Scale by 1 so ordering is
    # dominated by tightness. Add a small bonus when the resulting residual is still
    # large enough to be usable by some future item (>= floor). This only breaks ties
    # among residuals within `floor` of each other, keeping best-fit behavior intact
    # while nudging away from stranding dead space.
    residual = bins - item  # >= 0 for all bins shown
    score = -residual.astype(np.float64)

    # bonus for keeping the leftover reusable
    usable = residual >= floor
    score += usable.astype(np.float64) * (floor * 0.5)

    # Also mildly prefer exact fills (residual == 0) strongly — that is strictly good.
    score += (residual == 0).astype(np.float64) * (floor * 0.5 + 0.25)

    return score
# EVOLVE-BLOCK-END
