# EVOLVE-BLOCK-START
"""Best fit with a bounded residual tie-break.

The classic best-fit rule (tightest residual) is very strong here.  Every attempt
to do "smarter" things (targeting half-full bins, penalising small residuals,
etc.) made the score worse, because the item sizes are independent draws from a
fixed heavy-tailed distribution: there is no exploitable structure beyond what
best-fit already captures.

The only safe tweak is a *tiny, bounded* preference among placements whose
residuals are close, so that we never sacrifice a clearly tighter fit but break
near-ties in favour of the slightly larger residual (which is marginally more
likely to be usable again).  The weight is kept very small so the rule stays
almost identical to best-fit.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for every bin shown
    # Pure best fit: smallest residual is best.
    base = -residual.astype(np.float64)
    # Extremely small bonus for a larger residual among near-ties.
    base += 1e-3 * residual
    return base
