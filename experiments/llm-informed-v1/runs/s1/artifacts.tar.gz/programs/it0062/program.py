# EVOLVE-BLOCK-START
"""Best fit with an exact-tie histogram tie-break.

Best fit (smallest remaining capacity that still fits) is essentially optimal for
online bin packing when sizes come from a near-continuous distribution. Any
perturbation large enough to reorder near-ties tends to hurt, so here we keep the
best-fit ordering exactly and only break *exact* residual ties.

Tie-break: when several bins share the smallest residual, prefer one whose
post-placement residual exactly equals a size we have seen many times (a likely
future item), so a currently unusable gap gets a chance to be filled later. This
never changes the primary best-fit decision.
"""
import numpy as np

# --- persistent state (fresh process per instance) ---
_n_items = None          # number of items in the instance
_seen = 0                # items seen so far
_residuals = None        # remaining capacity of every bin, indexed by bin order
_hist = None             # counts of item sizes, index 0..100


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for all bins shown

    # Primary rule: best fit (smallest residual first).
    score = -residual.astype(np.float64)

    # Exact-tie tie-break: among bins sharing the minimum residual, prefer the one
    # whose leftover can be exactly matched by a likely future item size. The
    # bonus is far smaller than 1, so it can never overturn a strict best-fit
    # ordering; it only resolves exact ties.
    min_r = residual.min()
    tie = residual == min_r
    if tie.sum() > 1:
        # Frequency with which each residual value has been seen as an item size.
        # Counts are bounded by _seen, so normalize to keep the bonus tiny.
        freq = _hist[residual]  # per-bin count of that size among past items
        score += tie.astype(np.float64) * (freq.astype(np.float64) * 1e-6)

    return score
# EVOLVE-BLOCK-END
