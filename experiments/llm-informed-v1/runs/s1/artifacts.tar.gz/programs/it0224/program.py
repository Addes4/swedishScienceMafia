# EVOLVE-BLOCK-START
"""Best-fit core with a future-seal probability tiebreak.

Pure best fit is a strong baseline. The main source of waste is leaving
residuals that no future item can ever fill. Since item sizes come from a
fixed distribution, we can estimate, for each candidate residual r, the
probability that some future item will exactly fill it. We strongly reward
residuals with high seal probability (especially small ones that would
otherwise be stranded), while keeping best-fit (-residual) as the dominant
ordering.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_sum = 0


def _init(n):
    global _n_items, _seen, _hist, _sum
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.float64)
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1.0
    _sum += item

    residual = bins - item  # >= 0 for shown bins
    total = max(_seen, 1)

    # Smoothed empirical distribution over item sizes.
    freq = (_hist + 0.5) / (total + 50.5)

    # Probability that at least one of the remaining future items exactly
    # equals the residual size.  remaining items = n_items - seen.
    remaining = max(_n_items - _seen, 0)
    p_seal = 1.0 - np.power(1.0 - freq[np.clip(residual, 0, 100)], remaining)

    score = -residual.astype(np.float64) * 1.0

    # Strong reward for residuals that a future item can seal.
    score += p_seal * 80.0

    # Extra push for very small residuals that are still sealable (otherwise
    # they are stranded forever).
    small_sealable = ((residual > 0) & (residual <= 15)).astype(np.float64)
    score += small_sealable * p_seal * 40.0

    return score
# EVOLVE-BLOCK-END
