# EVOLVE-BLOCK-START
"""Best fit with a strict lexicographic tie-break on residual viability.

Pure best-fit (smallest post-placement residual) is near-optimal for this
distribution. Previous attempts added residual bonuses that perturbed the
primary best-fit ordering and slightly hurt. Here best-fit is the primary key
and never overridden; the empirical-quantile viability is used only to break
exact ties among equal residuals.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    q10 = _quantile(0.10)

    residual = (bins - item).astype(np.int64)  # >= 0

    # primary: smaller residual is better  -> score = -residual
    score = -residual.astype(np.float64)

    # secondary tie-break, strictly smaller than 1 in magnitude:
    # prefer residuals that are NOT usable by a plausibly small future item
    # (dead space), to avoid freeing bins for tiny items unnecessarily.
    dead = (residual > 0) & (residual < q10)
    score += dead.astype(np.float64) * 1e-3

    return score
# EVOLVE-BLOCK-END
