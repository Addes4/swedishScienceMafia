# EVOLVE-BLOCK-START
"""Best fit, but avoid leaving tiny dead residuals by retargeting to ~50 when the
tightest fit would leave a residual below the mean item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Baseline: best fit -> smallest residual gets the highest score.
    score = -residual.astype(np.float64)
    # If the tightest fit leaves a residual below the typical item size, prefer
    # placements whose residual is closest to 50 (a reusable half-bin).
    best = residual.min()
    if best < 40:
        target = 50.0
        alt = -np.abs(residual.astype(np.float64) - target)
        # Only override for bins that don't leave an even worse tiny residual.
        score = np.where(residual < 40, alt, score)
    return score
# EVOLVE-BLOCK-END
