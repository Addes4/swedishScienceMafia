# EVOLVE-BLOCK-START
"""Harmonic-target best fit: nudge residual-after-placement toward fillable targets."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = _state
    s["sum"] += item
    s["n"] += 1
    mean = s["sum"] / s["n"]

    residual = bins - item  # remaining capacity after placing item here

    # Target residuals: values around which future items (mean ~ mean) can complete
    # the bin nicely. Prefer residuals that are small or near multiples that
    # can be filled by roughly-mean items. Use a modest number of targets.
    targets = np.array([0.0, mean, 2.0 * mean, 3.0 * mean,
                        100.0 - mean, 100.0 - 2.0 * mean])

    # For each bin, distance of residual to nearest target
    d = np.abs(residual[:, None] - targets[None, :])
    best = d.min(axis=1)

    # Primary: best-fit residual preference (small residual is good), plus a small
    # bonus for being on a target.  Keep best-fit dominant so it stays robust.
    score = -residual.astype(np.float64) - 0.02 * best
    return score
# EVOLVE-BLOCK-END
