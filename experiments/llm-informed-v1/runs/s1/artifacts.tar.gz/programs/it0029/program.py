# EVOLVE-BLOCK-START
"""Best fit with a slack guard for nearly-dead residuals.

Items arrive online. Standard best fit packs each item into the bin with the smallest
remaining capacity that still fits it. The known failure mode of best fit is the build-up
of tiny unusable residuals ("nearly-dead" bins): a placement that leaves, say, 3 units of
space can never be filled again by typical items (mean size ~40), so that space is wasted.

Fix: keep a running estimate `mu` of the mean item size seen so far. Place each item with
best fit, except when the tightest placement would strand a residual below mu/4. In that
case, prefer the bin whose residual after placement is closest to mu, a hole large enough
to still admit a typical future item.
"""
import numpy as np

_state = {
    "total": 0.0,   # sum of item sizes seen so far
    "count": 0,     # number of items seen so far
}


def priority(item, bins):
    """Return a score per bin; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every fitting bin (unused bins have capacity 100).
    """
    item = int(item)
    bins = np.asarray(bins)

    # Update our running estimate of the mean item size.
    _state["total"] += item
    _state["count"] += 1
    mu = _state["total"] / _state["count"]

    residual = bins - item                 # capacity left if the item goes here
    slack = mu / 4.0                       # residuals below this are effectively wasted

    # Best-fit score: prefer the tightest fit (smallest residual).
    best_fit = -residual.astype(np.float64)

    # Where a placement would leave a nearly-dead residual, redirect the preference
    # toward a residual near mu, which can still host a typical future item.
    dead = residual < slack
    if dead.any():
        guard = -np.abs(residual - mu).astype(np.float64)
        # Blend: guard dominates only for the dead placements by pushing them below
        # every healthy best-fit score.
        offset = float(np.max(best_fit)) - float(np.min(guard)) + 1.0
        best_fit = np.where(dead, guard - offset, best_fit)

    return best_fit
# EVOLVE-BLOCK-END

