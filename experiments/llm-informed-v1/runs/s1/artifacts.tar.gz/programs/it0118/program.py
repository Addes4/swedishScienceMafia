# EVOLVE-BLOCK-START
"""Adaptive best-fit via a learned residual-desirability weight.

Classic best fit minimizes the resulting residual, which tends to create many
small unusable leftovers.  Here we instead score each candidate bin by how
desirable its *post-placement* residual is, and learn that desirability from the
empirical item-size distribution observed so far.

For a residual r, placing the item leaves r free.  The chance this slot is ever
useful depends on how many future items can still fit into it.  Rather than a
hard cliff, we use a smooth weight w(r) that is high for residuals that are
"comfortably small" (likely to be closed later) and low for residuals that are
either wasteful or so small they will almost surely be stranded.  The weight is
derived from the running histogram, so it adapts to the Weibull shape without
tuning to any single instance.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_mean = 40.0


def _init(n):
    global _n_items, _seen, _hist, _mean
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _mean = 40.0


def _refresh_mean():
    global _mean
    if _seen > 0:
        idx = np.arange(1, 101)
        _mean = float((_hist[1:] * idx).sum()) / float(_seen)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    # Record the item before scoring (distribution seen so far).
    _hist[item] += 1
    _seen += 1
    if (_seen & 63) == 0 or _seen <= 8:
        _refresh_mean()

    residual = bins - item  # >= 0 for bins the item fits in

    # Empirical median-ish scale for the "sweet spot" residual.
    # A residual near the mean (or somewhat below it) is a well-matched slot.
    m = _mean

    # Smooth desirability: quartic-ish hump peaking near r ~ m/2, falling off
    # for tiny residuals (stranded) and for large residuals (under-filled).
    # Computed as: 1/(1 + ((r-target)/scale)^2) form using vectorized ops.
    target = 0.5 * m
    scale = 0.35 * m + 1.0
    d = (residual - target) / scale
    desirability = 1.0 / (1.0 + d * d)

    # Exact fills are almost always good: strongly reward them.
    desirability += 3.0 * (residual == 0)

    # Primary signal: prefer the smallest resulting residual so we still behave
    # like best fit; use desirability as a small tie-breaking adjustment.
    score = -residual.astype(np.float64) + 0.5 * desirability

    return score
# EVOLVE-BLOCK-END

