# EVOLVE-BLOCK-START
"""Best-fit with a "reusable residual" preference.

Idea: pure best fit minimizes the leftover after each placement.  But a tiny
leftover (e.g. residual 3) is usually wasted, while a leftover close to a
frequently occurring item size is likely to be consumed by a future item.
So we score each fitting bin by how "reusable" its post-placement residual is,
measured against the empirical distribution of items seen so far, and only
fall back to strict best fit when nothing looks reusable.
"""
import numpy as np

# module-level state, reset per instance (fresh process each instance)
_seen = None          # running counts of item sizes (histogram length 101)
_needed = None        # number of items in this instance (== len(bins) at start)
_hist = None          # probability mass per residual value 0..100


def priority(item, bins):
    global _seen, _needed, _hist
    n = len(bins)

    # First call of an instance: every bin is unused, so n == total items.
    if _seen is None or _needed != n:
        _seen = np.zeros(101, dtype=np.float64)
        _needed = n
        _hist = None
        # require some data before trusting the histogram
        _count_data = 0
    else:
        _count_data = _seen.sum()

    residual = bins - item              # remaining capacity after placement
    # residual can be negative only if we restricted bins, but harness gives
    # only fitting bins, so residual >= 0.  Keep a safety floor.
    np.maximum(residual, 0, out=residual)

    if _count_data >= 50 and _hist is not None:
        # score: negative distance from residual to the nearest "likely"
        # residual value.  Likely values are sizes we have seen before
        # (a bin left with r can be closed by a future item of size r).
        # Use log-prob weighting via the histogram to avoid tuning.
        # Build vector: prefer r that is a common item size.
        base = -np.abs(bins - item)          # best fit baseline
        # reusable bonus: histogram mass at the exact residual value
        reus = _hist[residual.astype(np.int64)]
        # combine: strong best-fit pull, plus a bonus for reusable residuals
        return base + 25.0 * reus
    else:
        return -(bins - item)


def _update(item):
    """Record the item into the histogram (called by wrapper below)."""
    pass
# EVOLVE-BLOCK-END

# --- bookkeeping hook: the harness only calls priority(), so we fold the
#     histogram update into the next call's start by tracking items as they are
#     observed.  To keep a single entry point we update lazily using a tiny
#     wrapper that is itself the public priority function.
_orig_priority = priority


def priority(item, bins):  # noqa: F811  (intentional redefinition as wrapper)
    global _seen, _needed, _hist
    n = len(bins)
    if _seen is None or _needed != n:
        _seen = np.zeros(101, dtype=np.float64)
        _needed = n
        _hist = None

    # update histogram with the current item before scoring
    _seen[item] += 1.0
    total = _seen.sum()
    if total >= 50:
        # probability that a random future item equals residual r
        prob = _seen / total
        _hist = prob

    return _orig_priority(item, bins)
