# EVOLVE-BLOCK-START
"""Exact-fill targeting: choose the bin whose residual is most likely to be
exactly filled by a future item.

Items come from a fixed Weibull-like distribution.  A residual slot is
"valuable" if some future item can exactly fill it, closing the bin.  Best-fit
minimizes the residual, which often leaves awkward residuals (e.g. 1, 3, 7)
that almost no item will ever fill, permanently stranding the bin.

Instead we score each candidate by the empirical mass of item sizes equal to
the resulting residual, i.e. p(residual) from the running histogram.  This
directly maximizes the chance the bin gets closed later.  A best-fit term is
used only as a tie-breaker so that, among equally likely-to-close residuals,
we still prefer the tighter one.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _hist, _bin_count
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins shown to us

    # Probability that some future item exactly equals the residual.
    idx = np.clip(residual, 0, 100)
    exact_mass = _hist[idx].astype(np.float64)

    # Exact fill now (residual 0) is always a win; boost it strongly.
    score = exact_mass
    score += (residual == 0).astype(np.float64) * 1e6
    # Tie-break: among equal likelihood, prefer the tighter bin (best-fit).
    score -= residual.astype(np.float64) * 1e-3

    return score
# EVOLVE-BLOCK-END

