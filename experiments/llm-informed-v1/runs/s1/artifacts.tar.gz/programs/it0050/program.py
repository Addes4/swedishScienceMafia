# EVOLVE-BLOCK-START
"""Best fit with a reusable-residual buffer.

Pure best fit minimizes the leftover after placement, but on a continuous size
distribution that often leaves tiny (< typical small item) leftovers that can
never be reused, wasting a bin's tail capacity.  This rule uses the full packing
state plus a running histogram of observed item sizes to prefer a placement whose
resulting residual is likely to still admit a future item, while never leaving
more room than needed.
"""
import numpy as np

_state = {
    "total": None,     # number of items in the instance
    "seen": 0,         # items seen so far
    "hist": np.zeros(101, dtype=np.int64),  # histogram of past item sizes
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest."""
    st = _state

    if st["total"] is None:
        # On the first call every bin is unused, so len(bins) == number of items.
        st["total"] = len(bins)

    st["seen"] += 1
    st["hist"][item] += 1
    hist = st["hist"]
    seen = st["seen"]

    # Estimate how many items remain and the smallest common size.
    total = st["total"]
    remaining = total - seen

    residual_after = bins - item  # always >= 0 (bins shown are those that fit)

    if seen >= 30 and remaining > 0:
        # Smallest size that has appeared "commonly" (>= ~2% of seen items).
        counts = hist[1:]
        sizes = np.arange(1, 101)
        thresh = max(2, int(0.02 * seen))
        common = sizes[counts >= thresh]
        if common.size > 0:
            min_common = int(common[0])
        else:
            min_common = 1
    else:
        min_common = 1

    # Reward residuals that can still host a typical small item, scaled so that
    # going from "< min_common (dead leftover)" to "just usable" is a big gain,
    # but extra empty room beyond that is not rewarded.
    usable = np.minimum(residual_after, min_common)
    score = usable.astype(np.float64) * 1000.0 - residual_after.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

