# EVOLVE-BLOCK-START
"""Best-fit with distribution-aware residual valuation.

The distribution of item sizes is fixed (Weibull-like, mean ~40), so a bin's
remaining capacity is only useful if future items tend to leave a small or
zero final residual.  Empirically a plain best-fit (score = -residual) already
performs very well; the main loss comes from a handful of bins stranded with
tiny residuals that no future item can use, plus from occasionally skipping a
perfect seal.

This rule keeps best fit as the dominant core and layers a small, smooth
correction computed from the running histogram of observed item sizes:

  * best-fit core: -residual
  * strong reward for a perfect seal (residual == 0)
  * reward residuals whose exact value has high empirical item-frequency,
    because such residuals are likely to be closed by a single future item
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_sum = 0


def _init(n):
    global _n_items, _seen, _hist, _sum
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = float(_seen)
    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)

    fill_mass = _hist[idx].astype(np.float64) / total

    # Best-fit core (slightly emphasized so distribution terms act only as
    # tie-breakers among near-equal residuals).
    score = -r * 1.15

    # Perfect seal: a bin that ends full can never waste capacity.
    score += (residual == 0).astype(np.float64) * 80.0

    # Residuals that equal a common future item size are likely to seal.
    score += fill_mass * 45.0

    return score
# EVOLVE-BLOCK-END

