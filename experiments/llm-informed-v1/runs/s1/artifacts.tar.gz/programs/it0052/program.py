# EVOLVE-BLOCK-START
"""Best fit with full-state tracking and exact-fill preference."""
import numpy as np

_state = {"open_caps": None, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Base score: best fit -> prefer the smallest residual after placement.
    resid = bins - item
    score = -resid.astype(np.float64)
    # Small bonus for exact/near-exact fills so tight fits win over merely-best fits.
    score += (resid == 0) * 1e-6
    return score
# EVOLVE-BLOCK-END

