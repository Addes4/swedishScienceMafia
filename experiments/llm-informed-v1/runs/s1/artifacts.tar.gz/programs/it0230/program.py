# EVOLVE-BLOCK-START
"""Best-fit core with perfect-seal and adaptive small-residual penalty.

Pure best-fit leaves many tiny residuals that no future item can use.  Since
sizes come from a fixed Weibull-like distribution (mean ~40), we:

  * keep best-fit as the core (score = -residual),
  * strongly reward residuals that equal 0 (perfect seal),
  * penalize residuals too small to accept the smallest item likely to
    still appear, estimated from items seen so far,
  * reward residuals whose size has high empirical histogram mass (likely
    to be exactly filled later),
  * nudge residuals toward multiples of the running mean so future items
    stack cleanly.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0
_sorted_vals = None
_min_item = 101


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum, _min_item
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _min_item = 101


def priority(item, bins):
    global _seen, _sum, _min_item

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item
    if item < _min_item:
        _min_item = item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)
    mean = _sum / _seen

    # Empirical median item size via cumulative histogram.
    target = 0.5 * total
    cum = 0.0
    median = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            median = s
            break

    # Smoothed minimum useful residual: smallest item seen, but bounded so
    # that early (sparse) calls do not over-penalize.
    min_useful = max(1, min(_min_item, 8))

    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    cum_hist = np.cumsum(_hist).astype(np.float64) / total
    fit_mass = cum_hist[idx]

    # Best-fit core.
    score = -residual.astype(np.float64)

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize residuals too small to accept even the smallest likely item.
    too_small = ((residual > 0) & (residual < min_useful)).astype(np.float64)
    score -= too_small * 40.0

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 35.0

    # Reward residuals that admit at least some future item (flexibility).
    score += fit_mass * 8.0

    # Nudge residuals toward multiples of the running mean.
    if mean > 0:
        mult = np.round(residual.astype(np.float64) / mean)
        mult = np.maximum(mult, 0.0)
        waste = np.abs(residual.astype(np.float64) - mult * mean)
        score -= waste * 0.15

        near_mean = np.abs(residual.astype(np.float64) - mean)
        score += np.maximum(0.0, 12.0 - near_mean) * 0.5

        above = residual.astype(np.float64) - mean
        just_above = (above > 0) & (above <= 6.0)
        score += just_above.astype(np.float64) * 1.5

    return score
# EVOLVE-BLOCK-END
