# EVOLVE-BLOCK-START
"""Best-fit with adaptive viability threshold and clingy-bin tie-breaker.

The core is best fit: prefer the smallest post-placement residual.  Two gentle
corrections adapt it to the item distribution:

  * Exact fills (residual 0) are strongly preferred; they never cost us.
  * Bins whose residual would drop below an empirical viability threshold (the
    size of a likely small future item) are mildly penalized, so we stop
    stranding tiny residuals that no future item can use.

A small "clingy" bonus favors bins that are already loaded (smaller current
residual), which nudges us to close out partially-filled bins before starting
new ones.  All terms are smooth, no hard cliffs.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for fitting bins
    current = bins.astype(np.float64)

    # Empirical small-item viability threshold.
    q10 = _quantile(0.10)

    # Core: best fit (smallest resulting residual is best).
    score = -residual.astype(np.float64)

    # Mild penalty for stranding a residual too small to host a likely item.
    too_tight = (residual < q10) & (residual > 0)
    score -= too_tight.astype(np.float64) * 8.0

    # Strong reward for exact fills.
    score += (residual == 0).astype(np.float64) * 200.0

    # Clingy bonus: prefer bins that are already more heavily loaded
    # (smaller current residual), scaled gently so it only breaks near-ties.
    score -= current * 0.05

    return score
# EVOLVE-BLOCK-END
