# EVOLVE-BLOCK-START
"""Distribution-aware residual targeting with best-fit core.

The main failure of pure best fit is stranding bins with residuals that no
future item can ever fit.  Since item sizes are drawn from a fixed (Weibull)
distribution with mean ~40, residuals near common item sizes are far more
likely to be filled later than residuals in the sparse tail.

This rule keeps a best-fit core (prefer smaller resulting residual) but adds
a smooth bonus proportional to the empirical probability that a *future* item
fits within the resulting residual.  Denser bins (smaller residuals) get more
weight, and residuals matching frequent item sizes get an extra boost.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    total = _seen

    # Empirical CDF of sizes <= s (probability an item fits within residual s).
    # cum_le[s] = fraction of seen items with size <= s.
    cum = np.cumsum(_hist)  # length 101
    idx = np.clip(residual, 0, 100)
    cdf = cum[idx].astype(np.float64) / max(total, 1)

    # Exact-fill chance: hist[r]/total (probability next item exactly closes r).
    exact_mass = _hist[idx].astype(np.float64) / max(total, 1)

    score = -residual.astype(np.float64)          # best-fit core

    # Strong bonus for exact fills (zero residual: nothing left stranded).
    score += (residual == 0).astype(np.float64) * 80.0

    # Smooth viability: residuals that admit a typical future item are useful.
    # Weight by how much of the distribution fits within the residual.
    score += cdf * 40.0

    # Distribution-aware bonus: residuals matching frequent future sizes.
    score += exact_mass * 25.0

    return score
# EVOLVE-BLOCK-END

