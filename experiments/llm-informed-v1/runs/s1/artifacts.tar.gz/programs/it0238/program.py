# EVOLVE-BLOCK-START
"""Best-fit with perfect-seal reward and small-crumb penalty.

Core is strict best fit (score = -residual). Two refinements:
  * Strong reward for sealing a bin exactly (residual 0).
  * Penalize nonzero residuals below the smallest item size seen so far,
    since no observed future item could ever use them.
  * Mild reward for residuals equal to a recently common item size, which
    are likely to be exactly filled soon.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0
_min_item = 101


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum, _min_item
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _min_item = 101


def priority(item, bins):
    global _seen, _sum, _min_item

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item
    if item < _min_item:
        _min_item = item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total

    # Best-fit core.
    score = -residual.astype(np.float64)

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize residuals too small for any observed item to fit.
    too_small = ((residual > 0) & (residual < _min_item)).astype(np.float64)
    score -= too_small * 35.0

    # Reward residuals that a recent item can exactly fill.
    score += fill_mass * 25.0

    return score
# EVOLVE-BLOCK-END
