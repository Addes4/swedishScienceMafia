# EVOLVE-BLOCK-START
"""Best-fit core with endgame-aware residual closing.

Pure best fit strands bins whose residual no future item can fill.  Early in
an instance we still want best-fit (small residual) since future items can
fill leftovers.  But near the end of the sequence there are no future items
to recover stranded bins, so a residual that cannot be exactly filled is pure
loss: we should prefer bins that get closed to 0 and avoid opening new bins.

This rule keeps a best-fit core, adds an exact-fill bonus, and scales the
"viability" preference down as the item stream runs out, using the known
number of remaining items to weight how much we care about future fills.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for fitting bins
    total = _seen
    remaining = max(_n_items - _seen, 0)

    # Empirical probability that a random future item exactly equals residual.
    idx = np.clip(residual, 0, 100)
    exact_mass = _hist[idx].astype(np.float64) / max(total, 1)

    # Best-fit core: strongly prefer small residuals.
    score = -residual.astype(np.float64)

    # Exact fill closes a bin: very valuable, more so as items run out.
    score += (residual == 0).astype(np.float64) * 90.0

    # As the stream ends, bias harder toward small residuals (fewer leftovers),
    # since stranded residuals can no longer be recovered.
    if remaining < 0.25 * _n_items:
        score -= residual.astype(np.float64) * 1.5

    # Distribution-aware bonus: residual matching a frequent item size is
    # likely to be exactly filled later (only meaningful while items remain).
    if remaining > 0:
        score += exact_mass * 30.0

    return score
# EVOLVE-BLOCK-END
