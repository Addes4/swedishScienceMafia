# EVOLVE-BLOCK-START
"""Competitive best-fit with a light, adaptive dead-residual penalty.

Pure best fit is the core (score = -residual).  The main correction is to
avoid leaving bins whose residual is too small for any plausible future item:
we estimate a low quantile (5th percentile) of the item-size distribution seen
so far and penalize residuals strictly below it.  A strong reward seals
residuals that hit exactly 0.  Extra histogram-based terms are kept small so
best-fit remains dominant and the rule stays robust across instances.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0
_cum = None


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum, _cum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _cum = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    # 5th percentile of item sizes seen so far (approx): anything below this
    # is very unlikely to be fillable by a future item.
    target = 0.05 * total
    cum = 0.0
    floor = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            floor = s
            break

    _cum[:] = np.cumsum(_hist) / total

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    fit_mass = _cum[idx]

    # Best-fit core.
    score = -r * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize residuals strictly below the low-quantile floor: nearly dead.
    dead = ((residual > 0) & (residual < floor)).astype(np.float64)
    score -= dead * 30.0

    # Small reward for residuals a future item can exactly fill.
    score += fill_mass * 25.0

    # Small flexibility reward for residuals that admit some future item.
    score += fit_mass * 5.0

    return score
# EVOLVE-BLOCK-END

