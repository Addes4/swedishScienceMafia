# EVOLVE-BLOCK-START
"""Balanced placement with empirical viability threshold, plus size-adaptive bias.

Best-fit is near-optimal for large items, but for small items it strands tiny
residuals.  We keep the q10-viability bonus but add a size-adaptive term:
small items (relative to the empirical mean size) get a modest bonus for going
into already-loaded bins (returning to a "spread small items" behavior), while
large items keep pure best-fit dominance.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0
_sum = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count, _sum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0
    _sum = 0


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen, _bin_count, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for bins the item fits in
    score = -residual.astype(np.float64)

    q10 = _quantile(0.10)
    mean = _sum / _seen if _seen > 0 else 50.0

    # Viability bonus: residual at or above q10 and still positive.
    usable = (residual >= q10) & (residual > 0)
    score += usable.astype(np.float64) * 30.0

    # Exact fills always good.
    score += (residual == 0).astype(np.float64) * 60.0

    # Size-adaptive bias: small items prefer returning to loaded bins.
    if item <= mean:
        load = 100.0 - bins.astype(np.float64)
        score += load * 0.8

    return score
# EVOLVE-BLOCK-END

