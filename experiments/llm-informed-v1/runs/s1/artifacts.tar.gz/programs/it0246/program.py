# EVOLVE-BLOCK-START
"""Competitive best-fit with future-fill viability.

Pure best fit leaves a few bins with tiny residuals that no future item can
ever use, and it never rebalances toward bins that can still accept typical
items.  Since sizes come from a fixed Weibull-like distribution (mean ~40),
a residual is *useful* only if some future item fits it, and it is *valuable*
if future items are likely to exactly fill it.

This rule keeps best-fit as the core (score = -residual) but:
  * gives a strong reward for residuals that equal 0 (perfect seal),
  * rewards residuals whose exact size has high empirical histogram mass,
  * rewards residuals that admit at least some future item (flexibility),
    measured by the cumulative histogram mass, which softly subsumes the
    brittle "below median" cutoff,
  * mildly nudges residuals toward the running mean.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)
    mean = _sum / _seen

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    cum_hist = np.cumsum(_hist).astype(np.float64) / total
    fit_mass = cum_hist[idx]

    # Best-fit core.
    score = -r * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 70.0

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 30.0

    # Reward residuals that admit at least some future item (flexibility).
    # Cumulative histogram mass grows with residual, smoothly encouraging
    # leftovers large enough to accept typical items, without a hard cutoff.
    score += fit_mass * 20.0

    # Nudge residuals toward the running mean: a single typical future item
    # nearly seals such a bin, so prefer it.
    if mean > 0:
        near_mean = np.abs(r - mean)
        score += np.exp(-(near_mean / (0.5 * mean + 1.0)) ** 2) * 4.0

    return score
# EVOLVE-BLOCK-END
