# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware seal preference.

The core stays best-fit (choose the tightest residual), which is what
competes with the lower bound.  On top of that we encode two facts about the
fixed Weibull-like item distribution:

  * A residual that equals 0 is a perfect seal: no future item can improve it,
    so it is always the best possible choice when available.
  * A residual that is positive but smaller than the smallest item seen so
    far cannot ever be used again, so it is a sliver we want to avoid
    creating unless nothing better exists.

Between those extremes we simply keep the tightest fit, which minimizes the
waste created by each placement.  Ties are broken by how "fillable" the
resulting residual is under the observed item histogram.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_min_item = 101
_sum = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _min_item, _sum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _min_item = 101
    _sum = 0


def priority(item, bins):
    global _seen, _sum, _min_item

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item
    if item < _min_item:
        _min_item = item

    residual = bins - item  # >= 0 for the bins shown

    total = max(_seen, 1)

    # Smallest item size seen so far: any positive residual below this cannot
    # be used again by a future item (assuming sizes stay >= observed min).
    min_seen = 100 if _min_item > 100 else _min_item

    score = -residual.astype(np.float64)

    # Perfect seal: always take it.
    sealed = (residual == 0).astype(np.float64)
    score += sealed * 1000.0

    # Unusable sliver: positive but below the smallest item seen.
    sliver = ((residual > 0) & (residual < min_seen)).astype(np.float64)
    score -= sliver * 100.0

    # Tiebreak: reward residuals that some observed item size exactly fills.
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    score += fill_mass * 5.0

    return score
# EVOLVE-BLOCK-END
