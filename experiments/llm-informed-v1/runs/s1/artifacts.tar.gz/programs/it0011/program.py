# EVOLVE-BLOCK-START
"""Best fit with a small reservation rule for large items and waste-aware penalties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item
    # Best fit: prefer the tightest fit (smallest leftover).
    score = -leftover.astype(np.float64)
    # Mildly penalize creating a fresh bin so consolidation wins when a good fit exists.
    # An unused bin has leftover == 100 - item; penalize it slightly more than it already is.
    score -= (bins == 100) * 0.5
    return score
# EVOLVE-BLOCK-END

