# EVOLVE-BLOCK-START
"""Best fit with a strict exact-fill bonus.

Best fit (choose the bin with the smallest remaining capacity that still fits) is
essentially optimal for online bin packing under a near-continuous size distribution.
Earlier versions added a "reusability" bonus that could flip the best-fit ordering by
up to floor/2, which measurably hurt. Here we keep best-fit ordering *exact* and only
add a bonus that is strictly larger than any residual-difference term for bins that
become exactly full after placement, so exact fills always win over merely tight fits
without disturbing the rest of the ordering.
"""
import numpy as np


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    # Exact best fit: smallest residual first => highest score.
    score = -residual.astype(np.float64)

    # Strictly prefer exact fills (residual == 0). Add a constant larger than the
    # maximum possible residual (100), so it dominates but never reorders the
    # best-fit ordering among non-exact bins.
    score += (residual == 0).astype(np.float64) * 1000.0

    return score
# EVOLVE-BLOCK-END
