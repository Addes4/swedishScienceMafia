# EVOLVE-BLOCK-START
"""Competitive best-fit with future-fill viability (adaptive scaling).

Keeps the proven best-fit / perfect-seal core but makes the two dominant
terms scale with the running mean item size, and adds a light reward for
residuals exactly reachable by a sum of two frequent item sizes.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)
    mean = _sum / _seen

    # Empirical median item size via searchsorted on cumulative counts.
    cum = np.cumsum(_hist)
    median = int(np.searchsorted(cum, 0.5 * total) + 1)
    if median < 1:
        median = 1
    if median > 100:
        median = 100

    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total

    # Best-fit core.
    score = -residual.astype(np.float64) * 1.0

    # Perfect seal: strong reward, scaled to item scale.
    seal = 40.0 + 0.5 * mean
    score += (residual == 0).astype(np.float64) * seal

    # Penalize residuals too small to accept a typical (median) item,
    # scaled to the median size so the decision matches item scale.
    too_small = ((residual > 0) & (residual < median)).astype(np.float64)
    score -= too_small * (0.6 * median + 5.0)

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 30.0

    # Bonus for residuals reachable by a sum of two frequent item sizes.
    # Use smoothed histogram convolution for a cheap 2-item-sum mass.
    h = _hist.astype(np.float64)
    if total > 0:
        h = h / total
    pair = np.convolve(h, h)[:101]
    pair_mass = pair[idx] if pair.size > 100 else np.zeros_like(residual, dtype=np.float64)
    score += pair_mass * 10.0

    return score
# EVOLVE-BLOCK-END
