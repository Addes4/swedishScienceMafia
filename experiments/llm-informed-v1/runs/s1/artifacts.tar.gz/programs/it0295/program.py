# EVOLVE-BLOCK-START
"""Best-fit with bounded, tie-only viability tie-breaker.

Pure best fit picks the smallest sufficient residual, which minimizes
immediate waste.  The only failures come from ties among bins with the same
resulting residual: we should send the item to the bin whose resulting
residual is most likely to still be usable / exactly sealable by future items.

This rule makes the residual the dominant, exact term and adds a bounded
tie-breaker strictly inside [0, 1) so it can NEVER override a smaller-residual
choice.  The tie-breaker prefers residuals with high empirical "exactly
fillable" mass and high cumulative fit mass.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)  # items seen before this one
    idx = np.clip(residual, 0, 100)

    fill_mass = _hist[idx].astype(np.float64) / total if total > 0 else np.zeros_like(residual, dtype=np.float64)
    cum = np.cumsum(_hist).astype(np.float64) / total if total > 0 else np.zeros(101, dtype=np.float64)
    fit_mass = cum[idx]

    # Bounded tie-breaker strictly in [0, 1).
    tie = 0.6 * fill_mass + 0.4 * fit_mass
    tie = np.clip(tie, 0.0, 1.0) * 0.999

    # Perfect seal gets the top of the tie range.
    tie = np.where(residual == 0, 1.0, tie)

    # Dominant best-fit core: exact integer residual dominates.
    score = -residual.astype(np.float64) * 1000.0 + tie

    return score
# EVOLVE-BLOCK-END
