# EVOLVE-BLOCK-START
"""Best fit with a self-normalizing exact-fit signal and a dead-residual penalty.

Items are iid from a fixed distribution.  Two facts matter:
  * Best fit (smallest residual that still fits) is a strong baseline.
  * A residual can only be used if some future item size fits in it.  Residuals
    below the smallest item size seen so far are effectively dead, so avoid
    creating them, and residuals that exactly equal a frequently seen item size
    are likely to be filled exactly soon.

The rule keeps best-fit dominant and layers two cheap, bounded signals on top:
a dead-residual penalty based on the running minimum item size, and an
exact-fit mass term from the running item-size histogram.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_min_item = 100


def _init(n):
    global _n_items, _seen, _hist, _min_item
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _min_item = 100


def priority(item, bins):
    global _seen, _min_item

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1
    if item < _min_item:
        _min_item = item

    residual = bins - item

    total = max(_seen - 1, 1)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total

    # Best-fit core: prefer the smallest residual that still fits.
    score = -residual.astype(np.float64)

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 60.0

    # Dead residual: cannot be filled by any item seen so far.
    dead = ((residual > 0) & (residual < _min_item)).astype(np.float64)
    score -= dead * 25.0

    # Exact-fit signal: residual matching a frequent past item size.
    score += fill_mass * 20.0

    return score
# EVOLVE-BLOCK-END
