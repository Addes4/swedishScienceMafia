# EVOLVE-BLOCK-START
"""Best fit with a "leave a fillable residual" tie-break.

Best fit (choose the bin with the smallest remaining capacity that still fits) is
essentially optimal for online bin packing under a near-continuous size distribution.

The only improvement we can safely make is in near-ties: when two bins have residuals
within 1 of each other, best-fit's choice barely matters, but the residual left behind
does. We keep the full packing state and an empirical histogram of item sizes and, in
such near-ties, prefer the bin whose post-placement residual matches a size that we
have seen (and thus is likely to recur), so the leftover is more likely to be filled.
"""
import numpy as np

# --- persistent state (fresh process per instance) ---
_n_items = None          # number of items in the instance
_seen = 0                # items seen so far
_residuals = None        # remaining capacity of every bin, indexed by bin order
_hist = None             # counts of item sizes, index 0..100


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    # Best fit: smallest residual first => highest score.  This dominates ordering.
    score = -residual.astype(np.float64)

    # Near-tie tie-break: prefer a residual that matches a size seen before
    # (including 0 = perfect fill, which always matches once seen).
    seen_before = (_hist[r] > 0) & (r >= 0) & (r <= 100)
    score += seen_before.astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END

