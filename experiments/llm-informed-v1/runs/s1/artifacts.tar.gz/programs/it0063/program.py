# EVOLVE-BLOCK-START
"""Plain best fit.

Best fit (choose the bin with the smallest remaining capacity that still fits)
is essentially optimal for online bin packing under a near-continuous size
distribution like the Weibull-shaped one used here. Perturbing its ordering with
heuristic bonuses that act on the scale of `floor` tends to hurt, because it can
flip the choice between residuals that differ by several units. So we keep the
strict best-fit ordering and use the histogram only as a tie-break on an epsilon
scale that cannot disturb the primary comparison.
"""
import numpy as np

# --- persistent state (fresh process per instance) ---
_n_items = None
_hist = None


def _init(n):
    global _n_items, _hist
    _n_items = n
    _hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _hist[item] += 1.0

    residual = bins.astype(np.int64) - item  # >= 0 for all bins shown

    # Primary term: strict best fit (smallest residual -> highest score).
    score = -residual.astype(np.float64)

    # Epsilon-scale tie-break: among bins whose residual is identical, slightly
    # prefer leftovers that exactly match a commonly seen item size, since such a
    # leftover is more likely to be filled by a future item. Magnitude is tiny
    # (< 1e-3) so it never reorders distinct residuals.
    freq = _hist[residual]  # 0 for residuals outside 0..100 (none here)
    score += freq * 1e-4

    return score
# EVOLVE-BLOCK-END
