# EVOLVE-BLOCK-START
"""Best-fit refined by an online-learned item-size distribution.

The key insight: for i.i.d. arrivals, what matters is not just how
tightly an item fits now, but how *fillable* the resulting leftover is
by future items.  A bin whose leftover equals a very common item size
(or a sum of two) is more valuable to keep than one whose leftover is a
rare size.  We estimate the item-size distribution online from the items
seen so far and use it to bias the classic best-fit choice.
"""
import numpy as np

# Module-level state (fresh per instance/process).
_hist = None          # counts of item sizes seen so far, index 1..100
_total = 0            # number of items seen so far


def _ensure_state():
    global _hist, _total
    if _hist is None:
        _hist = np.zeros(101, dtype=np.float64)
        _total = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins."""
    global _hist, _total
    _ensure_state()

    # Base rule: tightest fit -> highest score (best fit).
    leftover = bins - item           # capacity remaining after placement
    score = -leftover.astype(np.float64)

    # Prior: uniform over sizes (plus tiny smoothing).  As we observe more
    # items, the empirical histogram dominates.
    prior = 1.0 / 100.0
    probs = (_hist[1:101] + prior * 8.0) / (_total + 8.0)  # index 0 -> size 1

    # Value of a leftover L: probability that it can be exactly filled by a
    # single future item of size L, or jointly by a common pair (a, L-a).
    # We precompute a compact "fillability" table for leftovers 0..100.
    fill = np.zeros(101, dtype=np.float64)
    for L in range(0, 101):
        if L == 0:
            fill[L] = 1.0
            continue
        v = probs[L - 1]  # exact single-item fill
        # best two-item fill (a + b == L)
        if L >= 2:
            a_lo = 1
            a_hi = L - 1
            aa = np.arange(a_lo, a_hi + 1)
            bb = L - aa
            pair = probs[aa - 1] * probs[bb - 1]
            if pair.size:
                v += 2.0 * pair.max()  # factor 2: order matters
        fill[L] = v

    # Reward bins whose remaining capacity after this item is highly
    # fillable, scaled modestly so it perturbs but does not override
    # best-fit.
    fill_vals = fill[np.clip(leftover, 0, 100)]
    score += 0.35 * fill_vals

    # Slightly prefer not wasting a truly empty bin when another bin can
    # host the item: penalize using bins that are currently full-capacity
    # if the item is small.
    if item <= 40:
        score -= 0.001 * (bins == 100).astype(np.float64)

    # Update learned distribution.
    _hist[item] += 1.0
    _total += 1

    return score
# EVOLVE-BLOCK-END
