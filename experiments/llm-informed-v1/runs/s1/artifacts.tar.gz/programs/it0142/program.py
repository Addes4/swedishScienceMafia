# EVOLVE-BLOCK-START
"""Best-fit core with a future-reuse (leftover value) term.

Pure best fit strands bins whose residual is too small to ever be used
again.  Since sizes come from a fixed Weibull-like distribution (mean ~40),
a residual r is valuable roughly in proportion to how many future items
can still be packed into it.  We estimate that with the empirical CDF of
item sizes seen so far, scaled by the number of remaining items, and blend
it with a mild best-fit core so that among equally-reusable bins we still
prefer the denser one.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    total = _seen
    # Empirical CDF of item sizes: cdf[s] = P(size <= s).
    cdf = np.cumsum(_hist).astype(np.float64) / max(total, 1)

    # Expected number of future items that fit into a residual r:
    #   E[r] ~ (remaining items) * P(size <= r)
    remaining = max(_n_items - _seen, 0)
    idx = np.clip(residual, 0, 100)
    reuse = remaining * cdf[idx]

    # Best-fit core (mild): prefer smaller residual among equally reusable ones.
    score = reuse - 0.05 * residual.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

