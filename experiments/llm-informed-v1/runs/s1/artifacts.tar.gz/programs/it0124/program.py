# EVOLVE-BLOCK-START
"""Distribution-aware residual targeting with best-fit core (refined).

Best fit strands bins with residuals that no future item can fit.  Since
item sizes come from a fixed Weibull distribution (mean ~40), we keep a
best-fit core but adjust it with two smooth, distribution-aware terms:

  * a soft viability penalty for residuals below a low empirical quantile
    (those bins risk never being usable again), implemented with a smooth
    logistic rather than a hard threshold;
  * a bonus proportional to the empirical probability that a future item
    exactly fills the resulting residual.

All terms are normalized to comparable magnitudes so no single term
dominates the ranking.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_csum = None


def _init(n):
    global _n_items, _seen, _residuals, _hist, _csum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _csum = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _csum[item:] += 1

    residual = bins - item  # >= 0 for bins the item fits in
    idx = np.clip(residual, 0, 100)
    total = _seen

    # Empirical low quantile (q10) via prefix cumulative histogram.
    target = 0.10 * total
    # csum[s-1] gives count of items < s
    below = np.searchsorted(_csum, target)
    q10 = int(min(max(below, 1), 100))

    # Exact-fill probability mass and near-fill mass.
    exact_mass = _hist[idx].astype(np.float64) / max(total, 1)

    # Best-fit core (prefer smallest residual).
    score = -residual.astype(np.float64)

    # Strong bonus for exact fills.
    score += (residual == 0).astype(np.float64) * 80.0

    # Smooth viability: penalize residuals below q10 by a logistic ramp,
    # rewarding residuals at or above q10 without a hard cliff.
    width = max(1.0, 0.5 * q10)
    viability = 1.0 / (1.0 + np.exp(-(residual - q10) / width))
    score += viability * 45.0

    # Distribution-aware bonus: residuals matching frequent future sizes.
    score += exact_mass * 30.0

    return score
# EVOLVE-BLOCK-END
