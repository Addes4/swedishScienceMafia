# EVOLVE-BLOCK-START
"""Best-fit with a single dead-residual penalty.

Pure best fit is very strong for this distribution (mean ~40, capacity 100).
The only real waste best-fit creates is the occasional residual smaller than
any item that can still arrive.  So keep score = -residual as the dominant
core and apply ONE small extra signal: penalize residuals that are nonzero but
below the smallest item size observed so far (dead space), and give a tiny
bonus for perfectly sealing a bin (residual 0).  Everything else is left to
best-fit so we don't fight the core rule.
"""
import numpy as np

_min_item = None


def priority(item, bins):
    global _min_item

    if _min_item is None:
        _min_item = item
    else:
        if item < _min_item:
            _min_item = item

    residual = bins - item  # >= 0 for shown bins

    r = residual.astype(np.float64)
    score = -r  # best-fit core

    # Perfect seal: reward strongly enough to prefer it over a tiny nonzero
    # leftover that best-fit might otherwise pick.
    score += (residual == 0) * 50.0

    # Dead residual: nonzero but smaller than any item seen so far means no
    # future item of size >= min_item can use it. Penalize to push the item
    # elsewhere when an alternative exists.
    dead = (residual > 0) & (residual < _min_item)
    score -= dead.astype(np.float64) * 30.0

    return score
# EVOLVE-BLOCK-END
