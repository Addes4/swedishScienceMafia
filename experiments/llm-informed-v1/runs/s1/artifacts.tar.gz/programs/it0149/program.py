# EVOLVE-BLOCK-START
"""Best-fit with a tiny distribution-aware tie-breaker.

Pure best-fit (smallest resulting residual) has proven the strongest core in
this family.  Large bonuses for exact fills or viability repeatedly *hurt*,
because they override the good greedy ordering.  Here the bonus is scaled to
be strictly smaller than the minimum gap between distinct integer residuals,
so it only ever breaks exact ties in residual size.

Among bins with the *same* resulting residual, prefer the one whose residual
is more likely to be exactly consumed by a future item, estimated from the
empirical item-size histogram.  This is free information and never disturbs
the primary best-fit ordering.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    # Primary term: best fit.  Residuals are integers in [0, 100], so any
    # tie-breaker strictly below 1 in magnitude cannot reorder distinct
    # residuals.
    score = -residual.astype(np.float64)

    # Tie-breaker: probability the residual is exactly a future item size.
    idx = np.clip(residual, 0, 100)
    exact_mass = _hist[idx].astype(np.float64) / max(_seen, 1)

    # Keep it well below 1 so it only reorders equal residuals.
    score += exact_mass * 0.5

    return score
# EVOLVE-BLOCK-END
