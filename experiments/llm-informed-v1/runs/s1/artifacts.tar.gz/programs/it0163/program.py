# EVOLVE-BLOCK-START
"""Best-fit core with an expected-exact-fill tie-breaker.

Pure best fit strands bins with residuals that no future item can fill.  Since
items are drawn from a fixed distribution, a residual equal to a *frequent*
item size is far more likely to be perfectly filled before the horizon ends.

For each fitting bin we compute the probability that at least one of the
remaining items exactly equals the resulting residual r:

    p(r) = 1 - (1 - mass(r)/seen)^remaining

where mass(r)/seen is the empirical frequency of size r.  Small residuals are
preferred (best fit), but residuals whose value is a common item size get a
boost proportional to this expected-fill probability.  Priors are smoothed so
early calls behave like plain best fit.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.ones(101, dtype=np.float64)  # Laplace smoothing


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for bins the item fits in

    total = _seen
    remaining = max(_n_items - _seen, 0)

    idx = np.clip(residual, 0, 100)
    freq = _hist[idx] / total                      # empirical P(next item == r)
    with np.errstate(over='ignore', invalid='ignore'):
        p_fill = 1.0 - np.power(np.clip(1.0 - freq, 0.0, 1.0), remaining)

    # Best-fit core (dominant), expected-fill tie-breaker (bounded to <1).
    score = -residual.astype(np.float64) + p_fill * 20.0

    return score
# EVOLVE-BLOCK-END
