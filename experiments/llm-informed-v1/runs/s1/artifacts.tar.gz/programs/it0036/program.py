# EVOLVE-BLOCK-START
"""Best fit with a mild residual-usability nudge based on running statistics."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "mean": 40.0}


def priority(item, bins):
    """Score bins: primarily tightest fit, but nudge toward residuals near the running mean."""
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["mean"] = st["sum"] / st["n"]

    residual = bins - item  # >= 0 for all shown bins
    mean = st["mean"]

    # Base: tightest fit (smaller residual better -> higher score).
    base = -residual.astype(np.float64)

    # Nudge: penalize residuals that are far from the running mean item size,
    # but only mildly, so we keep the strong best-fit ordering.
    # Weight grows when residual is small (a near-dead bin).
    target = mean
    dist = np.abs(residual.astype(np.float64) - target)
    # Small-blame: more penalty when residual is quite small relative to mean.
    smallness = np.clip((mean - residual.astype(np.float64)) / max(mean, 1.0), 0.0, 1.0)
    nudge = -1.5 * dist * smallness

    return base + nudge
# EVOLVE-BLOCK-END

