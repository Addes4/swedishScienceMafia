# EVOLVE-BLOCK-START
"""Best-fit with sliver avoidance and perfect-seal preference.

Pure best-fit is the proven core.  Its only systematic weakness is leaving
residuals too small to ever accept another item.  Since sizes are integers,
a residual r can be reused only if some future item size <= r occurs.  We
track the smallest item seen so far and reshape the best-fit ranking only
when it would otherwise strand such unusable slivers.

Rule:
  score = -residual                     (best fit)
        + SEAL   * (residual == 0)      (prefer exact sealing)
        + SMALLOK* (residual >= min_seen) (reward reusable residuals)
        - SLIVER * (0 < residual < min_seen)  (punish stranded slivers)
"""
import numpy as np

_n_items = None
_seen = 0
_sum = 0
_min_seen = 101
_residuals = None

SEAL = 80.0
SMALLOK = 12.0
SLIVER = 60.0


def _init(n):
    global _n_items, _seen, _sum, _min_seen, _residuals
    _n_items = n
    _seen = 0
    _sum = 0
    _min_seen = 101
    _residuals = np.full(n, 100, dtype=np.int64)


def priority(item, bins):
    global _seen, _sum, _min_seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _sum += item
    if item < _min_seen:
        _min_seen = item

    residual = bins - item  # >= 0 for shown bins
    rf = residual.astype(np.float64)

    # Best-fit core.
    score = -rf

    # Perfect seal.
    score += (residual == 0).astype(np.float64) * SEAL

    # Reward residuals large enough to be reused by any item seen so far.
    usable = residual >= _min_seen
    score += usable.astype(np.float64) * SMALLOK

    # Punish stranded slivers that no seen item can fit into.
    sliver = (residual > 0) & (residual < _min_seen)
    score -= sliver.astype(np.float64) * SLIVER

    return score
# EVOLVE-BLOCK-END
