# EVOLVE-BLOCK-START
"""Best fit bin packing.

Best fit (place into the bin with the smallest remaining capacity that still fits)
is essentially optimal for online bin packing under a near-continuous size
distribution such as this Weibull-shaped one (mean ~40). The harness only shows us
the bins the item fits in, but we choose the bin, so we can rank simply by
remaining capacity: the bin with the smallest residual gets the highest score.

We avoid any perturbation of the ordering: earlier perturbation schemes (reusability
bonuses, histogram tie-breaks) occasionally flipped the best-fit choice and made
packing slightly worse. Pure best-fit, with ties going to the first (lowest-index)
bin as enforced by the harness, is the cleanest and strongest rule here.
"""
import numpy as np


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    # Smaller residual => higher score => chosen first. Exact integer arithmetic,
    # no perturbation, so the best-fit ordering is preserved precisely.
    return -bins
# EVOLVE-BLOCK-END

