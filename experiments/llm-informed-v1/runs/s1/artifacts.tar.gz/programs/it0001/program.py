# EVOLVE-BLOCK-START
"""Best fit with empty-bin reservation.

Pure best fit tends to open new bins for items that don't fit well in existing open bins,
even when those items are small. Reserving empty bins for larger items (which are harder to
place) can reduce the total number of bins. We penalize unused bins (remaining capacity 100)
so that the item prefers any partially-used bin when it fits reasonably, and only falls back
to a fresh bin for relatively large items.
"""
import numpy as np

# Item size above which we are willing to use a fresh (empty) bin.
FRESH_THRESHOLD = 60


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Base score: prefer the tightest fit (least remaining capacity after placing).
    scores = -(bins - item).astype(np.float64)

    # Empty bins have remaining capacity 100. Discourage using them unless the item is large.
    if item < FRESH_THRESHOLD:
        empty = bins == 100
        scores[empty] -= 1000.0

    return scores
# EVOLVE-BLOCK-END
