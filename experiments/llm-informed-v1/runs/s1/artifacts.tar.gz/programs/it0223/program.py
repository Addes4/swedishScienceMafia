# EVOLVE-BLOCK-START
"""Competitive best-fit with small-item-aware sealing.

Best fit is the strongest simple online rule, but it leaves small residuals
that no future item can ever fill.  Because sizes come from a fixed
Weibull-like distribution, very small items still occur (and recur), so a
residual is useful only if some future item fits it, and valuable if a future
item can exactly seal it.

Core: score = -residual  (best fit).
Add:
  * big reward for a perfect seal (residual == 0),
  * penalty for residuals smaller than the smallest item seen so far
    (those can never be used by any future item of that size),
  * reward for residuals equal to a frequently-seen item size, so a future
    item can exactly fill the bin.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0
_min_seen = 101


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum, _min_seen
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _min_seen = 101


def priority(item, bins):
    global _seen, _sum, _min_seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item
    if item < _min_seen:
        _min_seen = item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total

    # Best-fit core.
    score = -residual.astype(np.float64) * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize residuals below the smallest item seen so far: no future item
    # of that (or any smaller) size can use them.
    too_small = ((residual > 0) & (residual < _min_seen)).astype(np.float64)
    score -= too_small * 20.0

    # Reward residuals that exactly match a frequently-seen item size, so a
    # future item can perfectly seal the bin.
    score += fill_mass * 35.0

    return score
# EVOLVE-BLOCK-END
