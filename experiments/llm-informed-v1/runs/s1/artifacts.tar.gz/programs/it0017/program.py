# EVOLVE-BLOCK-START
"""Best fit with a running-histogram tie-breaking on residual usefulness."""
import numpy as np

_size_hist = np.zeros(101, dtype=np.float64)
_calls = 0
_n = 0


def priority(item, bins):
    global _calls, _n
    _calls += 1
    if _calls == 1:
        _n = len(bins)
    # record observed item size
    _size_hist[item] += 1.0

    resid = bins - item  # remaining capacity after placing item in each bin

    # score: tightest fit primarily (-resid), but boost residuals that
    # correspond to sizes commonly seen (likely to be exactly filled later).
    fit_score = -resid.astype(np.float64)

    # usefulness of leftover: probability mass of items equal to exactly the
    # residual, plus near-residual items that would leave a tiny remainder.
    probs = _size_hist / max(_calls, 1)
    usefulness = probs[np.clip(resid, 0, 100)]

    return fit_score + 0.5 * usefulness
# EVOLVE-BLOCK-END

