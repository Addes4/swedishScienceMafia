# EVOLVE-BLOCK-START
"""Best fit with empirical residual-match probability.

Best fit is strong online, but its cost is stranding residuals that no future
item will ever exactly fill. We track the empirical item-size histogram and,
instead of ad-hoc quantile bonuses, score each candidate bin by the estimated
probability that its post-placement residual will later be exactly matched by
an arriving item (with residual 0 treated as a guaranteed save). Small
residuals still win ties, preserving best-fit's compaction.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0

    # probability mass of each residual size in the empirical distribution
    total = _seen
    # normalize histogram once
    probs = _hist / total

    # match probability for each candidate residual
    match_p = probs[residual]

    # baseline: strongest preference for the smallest residual (best fit)
    score = -residual.astype(np.float64)
    # bonus for likely-refillable residuals, scaled above residual differences
    score += match_p * 3.0
    # exact fills are always good
    score += (residual == 0).astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END
