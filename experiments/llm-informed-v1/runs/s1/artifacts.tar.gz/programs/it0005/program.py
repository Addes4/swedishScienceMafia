# EVOLVE-BLOCK-START
"""Best fit with a data-driven "completable leftover" tie-breaker."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_W = 12.0      # weight for "leftover equals a common item size" bonus
_PERFECT = 3.0 # explicit extra bonus for exactly filling a bin


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    Core rule is best fit: prefer the bin left tightest after placing `item`.
    A small learned bonus favours leftovers that match frequent item sizes,
    since such a bin can later be closed exactly.
    """
    global _hist, _n

    r = bins - item  # resulting remaining capacity (>= 0 for the bins shown)

    if _n > 0:
        freq = _hist / _n
        bonus = _W * freq[np.clip(r, 0, 100)]
    else:
        bonus = 0.0

    score = -r.astype(np.float64) + bonus + _PERFECT * (r == 0)

    # update online statistics with the current item
    _hist[item] += 1.0
    _n += 1.0
    return score
# EVOLVE-BLOCK-END
