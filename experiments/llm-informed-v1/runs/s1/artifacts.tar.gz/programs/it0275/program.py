# EVOLVE-BLOCK-START
"""Best-fit core with a calibrated "dead residual" penalty.

Pure best-fit is near-optimal on this distribution; its main loss is leaving
residuals so small that no future item can ever use them.  We estimate the
smallest item size that has non-negligible empirical mass and penalize
residuals strictly below that, while giving a bounded reward to residuals
matching common item sizes (likely exact seals).
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_small = 20  # fallback minimum useful item size


def _init(n):
    global _n_items, _seen, _hist, _small
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _small = 20


def priority(item, bins):
    global _seen, _small

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1

    total = max(_seen, 1)
    residual = bins - item  # >= 0 for shown bins

    # Smallest size with non-trivial empirical mass (>= ~1% of items).
    thresh = max(1, int(0.01 * total))
    s = 1
    while s <= 100 and _hist[s] < thresh:
        s += 1
    if s <= 100:
        _small = s
    minsize = _small

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total

    # Best-fit core.
    score = -r

    # Perfect seal bonus.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize dead residuals smaller than the smallest usable item.
    dead = ((residual > 0) & (residual < minsize)).astype(np.float64)
    score -= dead * 40.0

    # Reward residuals matching common item sizes (exact-seal candidates).
    score += fill_mass * 30.0

    return score
# EVOLVE-BLOCK-END
