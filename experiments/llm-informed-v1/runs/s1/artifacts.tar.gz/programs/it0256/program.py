# EVOLVE-BLOCK-START
"""Best-fit core with empirical exact-fill targeting.

Items come from a fixed Weibull-like distribution (mean ~40).  Pure best fit
is strong, so keep it as the core (score = -residual).  On top, reward
residuals that some future item can exactly fill (high empirical histogram
mass at that residual) and strongly reward perfect seals (residual 0).
Also mildly reward residuals that can still accept a common future item.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_sum = 0


def _init(n):
    global _n_items, _seen, _hist, _sum
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins
    total = max(_seen - 1, 1)

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total

    # Best-fit core.
    score = -r

    # Strong reward for perfect seal.
    score += (residual == 0).astype(np.float64) * 60.0

    # Reward residuals a future item can exactly fill.
    score += fill_mass * 40.0

    # Mild reward for residuals that still admit at least some future item.
    has_fit = (residual >= 1).astype(np.float64)
    score += has_fit * 1.0

    return score
# EVOLVE-BLOCK-END
