# EVOLVE-BLOCK-START
"""Competitive best-fit with future-fill viability (histogram reachability).

Pure best fit leaves a few bins with tiny residuals that no future item can
ever use, and it never rebalances toward bins that can still accept typical
items.  Since sizes come from a fixed Weibull-like distribution (mean ~40),
a residual is *useful* only if some future item fits it, and it is *valuable*
if future items are likely to exactly fill it.

This rule keeps best-fit as the core (score = -residual) but:
  * penalizes residuals below the empirical median item size,
  * rewards residuals whose size has high empirical histogram mass,
  * gives a strong reward for residuals that equal 0 (perfect seal),
  * rewards residuals reachable by common small future items (one-step
    reachability via the empirical histogram),
  * adds a precise exact-pair-seal signal: a candidate residual equal to
    another open bin's residual can be sealed by one future item of that size.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0
_cum = None


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum, _cum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _cum = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)
    mean = _sum / _seen

    # Empirical median item size (approx) via cumulative histogram.
    target = 0.5 * total
    cum = 0.0
    median = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            median = s
            break

    # Cumulative histogram (fraction of items <= s).
    _cum[:] = np.cumsum(_hist) / total

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    fit_mass = _cum[idx]

    # Best-fit core.
    score = -r * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 70.0

    # Penalize residuals too small to accept a typical (median) item,
    # but only if they are not a perfect seal.
    too_small = ((residual > 0) & (residual < median)).astype(np.float64)
    score -= too_small * 35.0

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 45.0

    # Exact-pair-seal: reward a candidate residual r when r equals another
    # currently-open bin's residual AND that value has positive item mass,
    # so a single future item of that size can perfectly seal one of them.
    # This is a precise combinatorial signal, not a mass-product heuristic.
    if _seen > 1:
        # Only among bins the current item does not touch (independent),
        # but using the full residual table is simpler and effectively the
        # same: open-bin residuals are tracked in _residuals.
        open_res = _residuals  # includes all bins' residuals
        # mass of item sizes equal to each residual value
        mass_vec = _hist.astype(np.float64) / total  # index by size
        # For each candidate residual, does some open bin have that residual
        # value with positive mass?  Build a set of open residual values that
        # have positive item mass.
        has_mass = _hist > 0
        present = np.zeros(101, dtype=bool)
        # residuals present among open bins
        valid_res = open_res[(open_res >= 1) & (open_res <= 100)]
        if valid_res.size:
            present[valid_res] = True
        pair_indicator = np.zeros_like(r)
        cand = residual
        mask = (cand >= 1) & (cand <= 100)
        if mask.any():
            ci = cand[mask]
            hit = present[ci] & has_mass[ci]
            pair_indicator[mask] = hit.astype(np.float64) * mass_vec[ci]
        score += pair_indicator * 40.0

    # Reward residuals that admit at least some future item (flexibility).
    score += fit_mass * 8.0

    # Nudge residuals toward the running mean: a single typical future item
    # nearly seals such a bin, so prefer it.
    if mean > 0:
        near_mean = np.abs(r - mean)
        score += np.exp(-(near_mean / (0.5 * mean + 1.0)) ** 2) * 4.0

        # Mild monotone preference for residuals that can still hold typical
        # items, avoiding stranding of mid-sized leftovers.
        score += (r >= median).astype(np.float64) * 2.0

    # Track residuals of all open bins for next call.
    # Determine which bin was chosen: highest score, ties to first.
    chosen = int(np.argmax(score))
    # We cannot directly observe the chosen bin's global index because `bins`
    # is only the subset the item fits in. Reconstruct: bins shows residuals
    # for fitting bins in index order. Map local chosen index to global.
    fitting_idx = np.nonzero(_residuals >= item)[0]
    if fitting_idx.size == len(bins):
        gidx = int(fitting_idx[chosen])
        _residuals[gidx] = _residuals[gidx] - item

    return score
# EVOLVE-BLOCK-END


