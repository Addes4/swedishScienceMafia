# EVOLVE-BLOCK-START
"""Competitive best-fit with smooth stranding-risk and fill-value terms.

Pure best fit strands bins with tiny residuals that no future item can use.
Since sizes come from a fixed Weibull-like distribution (mean ~40), a residual
is useful only if some future item fits it, and valuable if future items are
likely to fill it exactly.

Core: score = -residual (best fit).
Adjustments:
  * strong reward for residual == 0 (perfect seal),
  * reward proportional to empirical histogram mass at that residual size
    (chance a future item exactly fills it),
  * smooth logistic penalty for residuals that admit almost no future item
    (CDF of fitting item sizes near zero), instead of a hard median cutoff,
  * mild reward for residuals that admit many future item sizes.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total

    # Cumulative probability that a future item fits the residual (size <= r).
    cum_hist = np.cumsum(_hist).astype(np.float64) / total
    fit_mass = cum_hist[idx]  # fraction of past items <= residual

    # Best-fit core.
    score = -r * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 70.0

    # Smooth stranding-risk: penalize residuals whose fitting mass is tiny,
    # relative to the typical fit mass under the current distribution.
    # Because mean size ~40, a typical residual should still admit a good
    # fraction of items; scale so fit_mass ~ 0.2 is neutral.
    score += 25.0 * np.log(np.maximum(fit_mass, 1e-6) / 0.2)

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 30.0

    return score
# EVOLVE-BLOCK-END

