# EVOLVE-BLOCK-START
"""Best-fit with expected-future-waste minimization.

The bin-choice rule directly estimates, for each candidate residual r, how
much capacity is expected to be wasted if future items (drawn from the running
empirical size distribution) are greedily packed into a bin of remaining
capacity r.  A residual that can be filled more completely by typical future
items is preferred.  Among residuals with essentially equal expected waste we
fall back to best-fit (-r), which is the classic strong baseline.

The estimate is a backward DP over capacities 0..100 using the running
histogram of item sizes.  It runs in O(101*101) per call, which is cheap.
"""
import numpy as np

_n_items = None
_seen = 0
_sum = 0
_hist = None
# DP value = expected waste-to-go for a bin of capacity c (E[leftover]).
_waste = None


def _build_waste():
    """Compute expected waste-to-go for capacities 0..100.

    For capacity c, the greedy/dynamic choice picks the item size s <= c that
    minimizes the resulting expected future waste: (c - s - waste[c-s]) is the
    "gain" (capacity consumed).  We use the recursion

        waste[c] = min_s E[ (c - s) + waste[c - s] ]   over s <= c

    approximated by taking the expectation over the future item distribution
    for the immediate item, i.e.

        waste[c] = sum_s p(s) * ( c - s + waste[c - s] )   if s <= c
                 (s > c contributes nothing since the item doesn't fit here)

    This is the standard "next-fit into this bin" expected leftover.
    """
    global _waste
    total = max(_seen, 1)
    p = _hist.astype(np.float64) / total  # p[0] unused
    w = np.zeros(101, dtype=np.float64)
    # iterate capacities upward; worst case leftover for capacity c is c
    for c in range(1, 101):
        acc = 0.0
        # expected waste given one future item arrives and we fit it if possible
        for s in range(1, c + 1):
            acc += p[s] * w[c - s]
        # probability an arriving item fits: sum_{s<=c} p[s]
        fitp = p[1:c + 1].sum()
        # if item fits, remaining capacity c-s already accounted; if it does
        # not fit (prob 1-fitp) the bin stays with capacity c unmodified for
        # this step, contributing c as eventual waste only if it never gets
        # used -- we approximate by adding the residual expected waste directly.
        # Simple, smooth estimate: expected leftover of capacity c given the
        # distribution is c - expected_fill, where expected_fill uses fit-mass.
        w[c] = acc + (1.0 - fitp) * c
    _waste = w


def _init(n):
    global _n_items, _seen, _sum, _hist, _waste
    _n_items = n
    _seen = 0
    _sum = 0
    _hist = np.zeros(101, dtype=np.int64)
    _waste = None


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    residual = bins - item  # >= 0 for shown bins

    # Update running stats with current item, then rebuild the waste table.
    _hist[item] += 1
    _sum += item
    _seen += 1
    _build_waste()

    ridx = np.clip(residual, 0, 100)
    exp_waste = _waste[ridx]

    # Primary: minimize expected future waste.  Secondary: best-fit (smaller
    # residual) to preserve classic best-fit behavior on ties.
    score = -exp_waste - residual.astype(np.float64) * 1e-4

    return score
# EVOLVE-BLOCK-END
