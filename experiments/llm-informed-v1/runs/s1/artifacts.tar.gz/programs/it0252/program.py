# EVOLVE-BLOCK-START
"""Competitive best-fit with future-fill viability.

Pure best fit leaves a few bins with tiny residuals that no future item can
ever use, and it never rebalances toward bins that can still accept typical
items.  Since sizes come from a fixed Weibull-like distribution (mean ~40),
a residual is *useful* only if some future item fits it, and it is *valuable*
if future items are likely to exactly fill it.

This rule keeps best-fit as the core (score = -residual) but:
  * smoothly penalizes residuals that admit few future items (via empirical
    CDF), instead of a brittle hard median threshold,
  * rewards residuals whose size has high empirical histogram mass,
  * gives a strong reward for residuals that equal 0 (perfect seal),
  * nudges residuals toward sizes that admit typical items.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0
_cdf = None
_cdf_seen = -1


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum, _cdf, _cdf_seen
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _cdf = np.zeros(101, dtype=np.float64)
    _cdf_seen = -1


def priority(item, bins):
    global _seen, _sum, _cdf, _cdf_seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen, 1)
    mean = _sum / _seen

    # Empirical CDF of item sizes, recomputed cheaply only when needed.
    if _seen != _cdf_seen + 1:
        _cdf = np.cumsum(_hist).astype(np.float64) / total
        _cdf_seen = _seen
    else:
        # incremental: only entry item changed, rebuild CDF from item upward
        # simpler and safe: just recompute (101 ops, negligible)
        _cdf = np.cumsum(_hist).astype(np.float64) / total
        _cdf_seen = _seen

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    fit_mass = _cdf[idx]  # P(item <= residual)

    # Best-fit core.
    score = -r * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 70.0

    # Smooth stranding penalty: residuals admitting few future items (low
    # empirical CDF) are penalized gradually, not by a hard cutoff.
    # P(item <= residual) small  => residual hard to use.
    score += fit_mass * 20.0

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 30.0

    # Nudge residuals toward the running mean: a single typical future item
    # nearly seals such a bin, so prefer it.
    if mean > 0:
        near_mean = np.abs(r - mean)
        score += np.exp(-(near_mean / (0.5 * mean + 1.0)) ** 2) * 4.0

        # Mild monotone preference for residuals that can still hold typical
        # items, avoiding stranding of mid-sized leftovers.
        score += (r >= mean).astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END
