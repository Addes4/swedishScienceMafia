# EVOLVE-BLOCK-START
"""Best fit with a dead-residual guard using a small item-size feasibility DP."""
import numpy as np

_state = {
    "samples": np.zeros(101, dtype=np.float64),  # empirical item count by size
    "total": 0.0,
    "feasible": None,   # cache: bool array of size 101, residual reachable
    "rebuilt": 0,
}


def _rebuild(n_samples_total):
    # Build set of achievable residual sums (0..100) from observed item sizes.
    # Use bounded knapsack with limited multiplicity to keep it cheap.
    reach = np.zeros(101, dtype=bool)
    reach[0] = True
    weights = _state["samples"]
    for s in range(1, 101):
        cnt = int(weights[s])
        if cnt <= 0:
            continue
        # bounded copies
        c = min(cnt, 2 if s > 0 else 0)
        if s >= 1:
            c = min(cnt, max(1, 100 // s))
        for _ in range(c):
            # shift reach upward by s
            reach[s:] |= reach[:-s].copy()
    _state["feasible"] = reach


def priority(item, bins):
    """Return a priority per bin; item goes to highest score (first on ties)."""
    _state["samples"][item] += 1.0
    _state["total"] += 1.0

    # Rebuild feasibility occasionally (cheap relative to 5000 calls).
    _state["rebuilt"] += 1
    if _state["feasible"] is None or (_state["rebuilt"] % 25 == 0):
        _rebuild(_state["total"])

    feasible = _state["feasible"]
    # residual after placing into each bin
    res = bins - item

    # For each bin, score = how "usable" the resulting residual is.
    # Usable residual: 0 (exact fill) is best; else we want residual that is
    # reachable by future items; tiny unreachable residuals are worst.
    scores = np.empty(res.shape[0], dtype=np.float64)
    for i in range(res.shape[0]):
        r = int(res[i])
        if r == 0:
            scores[i] = 1e6
        elif feasible[r]:
            # reward tighter fits, but not as strong as pure best-fit for
            # unreachable-small residuals
            scores[i] = 1000.0 - r
        else:
            # unreachable residual: this bin will likely waste r units.
            # penalize more when r is small (pure best-fit would overvalue it)
            scores[i] = -1000.0 + r
    return scores
# EVOLVE-BLOCK-END
