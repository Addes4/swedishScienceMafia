# EVOLVE-BLOCK-START
"""Best-fit core with calibrated residual-utilization shaping.

Sizes come from a fixed Weibull-like distribution (mean ~40).  Pure best fit
is already near-optimal online; its main loss is stranding small residuals that
no future item can use, and leaving residuals that no common item exactly
seals.  This rule keeps best fit dominant and adds:
  * a penalty, scaled by the empirical histogram mass of the residual's size,
    for residuals below the empirical median item size (unusable leftovers),
  * a reward for residuals equal to a common future item size (likely seals),
  * a strong reward for residuals equal to 0 (perfect seal),
  * a mild monotone bias toward larger residuals when they are already usable.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_sum = 0
_cum = None


def _init(n):
    global _n_items, _seen, _hist, _sum, _cum
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _cum = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    # Empirical median item size via cumulative histogram.
    target = 0.5 * total
    cum = 0.0
    median = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            median = s
            break

    _cum[:] = np.cumsum(_hist) / total

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total  # P(future item == r)

    # Best-fit core.
    score = -r

    # Perfect seal.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize unusable small residuals, scaled by how common this residual
    # size is (only matters below the median item size, excluding exact seal).
    too_small = ((residual > 0) & (residual < median)).astype(np.float64)
    score -= too_small * (20.0 + 40.0 * fill_mass)

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 50.0

    # Mild bias toward residuals that can still hold typical items.
    score += (residual >= median).astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END
