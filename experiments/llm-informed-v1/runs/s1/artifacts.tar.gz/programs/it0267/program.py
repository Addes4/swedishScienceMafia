# EVOLVE-BLOCK-START
"""Competitive best-fit with future-fill viability and residual pairing.

Pure best fit leaves a few bins with tiny residuals that no future item can
ever use, and it never rebalances toward bins that can still accept typical
items.  Since sizes come from a fixed Weibull-like distribution (mean ~40),
a residual is *useful* only if some future item fits it, and it is *valuable*
if future items are likely to exactly fill it.

This rule keeps best-fit as the core (score = -residual) but:
  * penalizes residuals below the empirical median item size,
  * rewards residuals whose size has high empirical histogram mass,
  * gives a strong reward for residuals that equal 0 (perfect seal),
  * rewards residuals reachable by common small future items (one-step
    reachability via the empirical histogram),
  * rewards residuals that, combined with some other open bin's residual,
    equal a common item size (a future item can seal one of the two),
  * mildly nudges residuals toward sizes that admit typical items.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0
_cum = None


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum, _cum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _cum = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)
    mean = _sum / _seen

    # Empirical median item size (approx) via cumulative histogram.
    target = 0.5 * total
    cum = 0.0
    median = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            median = s
            break

    # Cumulative histogram (fraction of items <= s).
    _cum[:] = np.cumsum(_hist) / total

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    fit_mass = _cum[idx]

    # Best-fit core.
    score = -r * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 70.0

    # Penalize residuals too small to accept a typical (median) item,
    # but only if they are not a perfect seal.
    too_small = ((residual > 0) & (residual < median)).astype(np.float64)
    score -= too_small * 35.0

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 45.0

    # Exact-pair-seal: if the resulting residual matches a size that, together
    # with some other open bin's residual, sums to a common item size, then one
    # future item can exactly seal that other bin. Reward such residuals.
    pair_score = np.zeros_like(r)
    if _seen > 1:
        useful = fill_mass * fit_mass
        pair_score = useful * 15.0
    score += pair_score

    # Complementary matching: count current open residuals (mass-weighted by
    # how likely a future item fills that bin) to detect residuals r such that
    # r + other_residual equals a common item size.  This rewards creating a
    # residual that pairs with an existing bin to enable a clean seal.
    if _seen > 1:
        # mass-weighted histogram of currently open residuals (values 1..100).
        open_hist = np.bincount(_residuals, minlength=101).astype(np.float64)
        open_hist[0] = 0.0
        # weight each open residual s by the chance a future item seals it:
        # use histogram mass at s (a future item of size s fills that bin).
        w = open_hist * ( _hist.astype(np.float64) / total )
        # For candidate residual r, sum over s of w[s] where r + s is a common
        # item size.  Equivalent to a correlation: match_sizes[r] = sum_s w[s]*H[r+s].
        H = _hist.astype(np.float64) / total
        match = np.zeros_like(r)
        # vectorized: for each candidate r (<=100), sum_{t} H[t]*w[t-r]
        for t in range(1, 101):
            ht = H[t]
            if ht == 0.0:
                continue
            # s = t - r, need 1 <= s <= 100 => r in [t-100, t-1]
            lo = max(0, t - 100)
            hi = min(100, t - 1)
            if hi < lo:
                continue
            sel = (residual >= lo) & (residual <= hi)
            if not sel.any():
                continue
            rr = residual[sel]
            match[sel] += ht * w[t - rr]
        score += match * 20.0

    # Reward residuals reachable by a common small item.
    in_mid = ((residual >= 20) & (residual <= 70)).astype(np.float64)
    score += in_mid * 3.0

    # Reward residuals that admit at least some future item (flexibility).
    score += fit_mass * 8.0

    # Nudge residuals toward the running mean: a single typical future item
    # nearly seals such a bin, so prefer it.
    if mean > 0:
        near_mean = np.abs(r - mean)
        score += np.exp(-(near_mean / (0.5 * mean + 1.0)) ** 2) * 4.0

        # Mild monotone preference for residuals that can still hold typical
        # items, avoiding stranding of mid-sized leftovers.
        score += (r >= median).astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END

