# EVOLVE-BLOCK-START
"""Best-fit core with a distribution-aware exact-fill bonus.

Pure best fit is strong here.  The only reliable improvement is to break
near-ties toward residuals that a future item is likely to fill exactly,
because that eliminates a bin.  We estimate, from the histogram of seen
items, the log-probability mass near the resulting residual, and add a small
bonus for residuals that are common item sizes.  The bonus is scaled by the
fraction of the instance remaining (early: tight packing dominates; late:
fewer chances remain so the bonus is small).

We keep the score purely best-fit dominant (score = -residual) plus this
tiny, well-scaled tie-breaker so it never disturbs a clear best-fit choice.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    total = _seen
    # Smooth empirical density of item sizes, used as the chance that a
    # future item lands close to a given residual (3-wide window).
    idx = np.clip(residual, 0, 100)
    lo = np.clip(idx - 1, 0, 100)
    hi = np.clip(idx + 1, 0, 100)
    mass = (_hist[lo].astype(np.float64)
            + _hist[idx].astype(np.float64)
            + _hist[hi].astype(np.float64)) / max(total, 1)

    remaining = max(_n_items - _seen, 0) / max(_n_items, 1)

    score = -residual.astype(np.float64)
    # Exact fill (residual 0) is the strongest save.
    score += (residual == 0).astype(np.float64) * 50.0
    # Small tie-breaker: residuals matching frequent item sizes, scaled by
    # the fraction of the instance still to come.
    score += mass * 20.0 * remaining

    return score
# EVOLVE-BLOCK-END
