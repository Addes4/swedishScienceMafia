# EVOLVE-BLOCK-START
"""Best fit with a soft, order-preserving residual-reusability tie-break.

Best fit (smallest remaining capacity that still fits) is essentially optimal for
online bin packing under a near-continuous size distribution. Its one weakness is
stranding sunbins whose residual is too small for any future item.

We keep the full packing state ourselves so we can track the remaining capacity of
every open bin (the harness only shows the bins the item fits in, but we choose the
bin, so we can reconstruct everything). We also track an empirical histogram of item
sizes seen so far.

The scoring is best fit, plus a *tiny* extrapolation-based bonus (< 1 residual unit)
that nudges the choice among near-tied residuals toward leaving reusable space. The
bonus is scaled by an estimate of the smallest item still likely to arrive, derived
from the running minimum and the number of items remaining.
"""
import numpy as np

# --- persistent state (fresh process per instance) ---
_n_items = None          # number of items in the instance
_seen = 0                # items seen so far
_residuals = None        # remaining capacity of every bin, indexed by bin order
_min_seen = 101          # smallest item size observed so far
_hist = None             # counts of item sizes, index 0..100


def _init(n):
    global _n_items, _seen, _residuals, _min_seen, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _min_seen = 101
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    global _seen, _min_seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    if item < _min_seen:
        _min_seen = item
    _hist[item] += 1

    # Estimate the smallest item still likely to arrive. If we have seen small
    # items, the running minimum is a decent proxy; early on it may be too high,
    # so we shrink it slightly while many items remain.
    if _min_seen <= 100:
        floor = _min_seen
    else:
        floor = 1

    # Best fit: smallest residual first => highest score.
    residual = bins - item  # >= 0 for all bins shown
    score = -residual.astype(np.float64)

    # Tiny bonus for keeping the leftover "reusable" relative to the likely floor.
    # Scaled below 1 residual unit so it only breaks near-ties and never overrides
    # best-fit ordering by more than one unit of capacity.
    if floor > 1:
        usable = residual >= floor
        # bonus in [0, 1): larger for smaller floor (more confidence it matters).
        bonus_scale = 1.0 / float(floor)
        score += usable.astype(np.float64) * bonus_scale

    # Exact fills are strictly good: keep a marginal (sub-unit) preference.
    score += (residual == 0).astype(np.float64) * (1.0 / float(floor + 1))

    return score
# EVOLVE-BLOCK-END
