# EVOLVE-BLOCK-START
"""Best fit with a stateful complement-closing bonus.

Pure best fit is very strong for the Weibull(mean~40) item distribution used here,
so we keep its ordering as the default and only perturb it when a placement lands
the bin on a residual value that the empirical history says is frequently filled
by a later item.  Everything the function needs is derivable from its own calls.
"""
import numpy as np

# Empirical item-size histogram (counts per size 1..100), plus running totals.
_counts = np.zeros(101, dtype=np.float64)
_total = 0.0
_n = 0
# residual histogram estimate: how often each residual value has been seen/closed
_res_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _total, _n
    item = int(item)
    b = np.asarray(bins, dtype=np.int64)

    # Default ordering: best fit  (smaller residual-after-placement == higher score).
    # score = -(residual) ; residual = b - item
    scores = -b.astype(np.float64)

    if _n > 200:
        # Probability that a *future* item equals the residual we'd leave behind.
        # Estimate from the empirical histogram; dilate a little to be forgiving.
        p = _counts / _n
        # smoothed density around each candidate residual
        dens = p.copy()
        dens[1:] += p[:-1]
        # small smoothing so exact matches are not overly favored
        dens = 0.5 * dens + 0.5 * np.concatenate(([dens[0]], (dens[:-1] + dens[1:]) * 0.5))

        resid = b - item
        # only consider bins where we leave a small but nonzero residual (closable)
        bonus = np.zeros_like(scores)
        mask = (resid > 0) & (resid <= 60)
        if np.any(mask):
            r = resid[mask]
            # bonus proportional to historical chance this exact residual is later hit,
            # scaled down so it only breaks near-ties in best fit.
            bonus[mask] = 8.0 * dens[np.clip(r, 0, 100)]
        scores = scores + bonus

    # record item for the histogram
    if 1 <= item <= 100:
        _counts[item] += 1.0
        _total += item
        _n += 1

    return scores
# EVOLVE-BLOCK-END

