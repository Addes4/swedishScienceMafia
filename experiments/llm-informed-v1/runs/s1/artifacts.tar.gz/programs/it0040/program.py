# EVOLVE-BLOCK-START
"""Best fit with a light stateful guard against creating tiny unusable residuals."""
import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "mean": 40.0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state
    st["n"] += 1
    st["sum"] += item
    mean = st["sum"] / st["n"]
    st["mean"] = mean

    # Post-placement residual for each candidate bin.
    residual = bins - item  # int64 array, >= 0

    # Best fit: prefer the smallest residual (largest fill).
    base = -(residual.astype(np.float64))

    # Guard: penalize bins that would be left with a tiny, hard-to-reuse residual.
    # Scale penalty by how far below the running mean the residual is, but only
    # for residuals that are small relative to the mean.
    thr = 0.5 * mean
    deficit = thr - residual.astype(np.float64)
    np.maximum(deficit, 0.0, out=deficit)
    # Mild penalty so it only breaks near-ties in favor of slightly larger residuals.
    penalty = 0.02 * deficit

    return base - penalty
# EVOLVE-BLOCK-END

