# EVOLVE-BLOCK-START
"""Best-fit core with a sum-of-squares consolidation bias.

Best fit alone (score = -residual) is already strong for this workload.  Its
weakness is stranding: it keeps shaving the smallest residual, which tends to
fill some bins tightly but leaves many medium bins wide open.

The sum-of-squares (SS) heuristic chooses the bin that most reduces the total
squared residual across all open bins.  Placing an item into a bin with
residual R changes SS by (R-i)^2 - R^2 = i^2 - 2*R*i, so minimizing SS is
exactly maximizing R -- i.e. worst-fit.  Pure SS is bad online (fills worst).

Instead we combine: scale best-fit down and add a *small* SS-consistent term
that biases toward leaving medium residuals rather than squeezing bins to 0 or
stranding them at 99.  The dominant term stays -residual so behavior remains
close to best fit, and the SS term de-fragments ties.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for the bins shown (item fits)

    # Dominant term: best fit (smaller resulting residual wins).
    score = -residual.astype(np.float64)

    # Consolidation term: reduce total squared residual after placement.
    # Change in SS = i^2 - 2*R*i, monotone increasing in R -> rewards larger
    # resulting residuals (toward medium fill), countering best-fit stranding.
    score += (2.0 * residual.astype(np.float64) * item) * 0.0015

    # Prefer sealing a bin completely: strong small bonus for exact fill.
    score += (residual == 0).astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
