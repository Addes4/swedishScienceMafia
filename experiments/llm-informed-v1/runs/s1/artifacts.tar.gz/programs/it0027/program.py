# EVOLVE-BLOCK-START
"""Bounded best fit: tightest fit, but avoid leaving residuals too small to reuse."""
import numpy as np

_STATE = {"floor": 0.0, "seen": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # remaining capacity after placing item here

    # Best-fit score.
    score = -residual.astype(np.float64)

    # Count how many bins the item fits. If we have plenty of alternatives,
    # penalize placements that leave a very small residual (< FLOOR),
    # since such a bin is nearly dead and can rarely be used again.
    FLOOR = 15.0
    small = residual < FLOOR
    if small.any() and not small.all():
        score[small] -= 100.0

    return score
# EVOLVE-BLOCK-END
