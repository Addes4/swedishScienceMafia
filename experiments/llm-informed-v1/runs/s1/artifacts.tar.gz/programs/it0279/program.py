# EVOLVE-BLOCK-START
"""Best-fit with a single principled future-usability signal.

Pure best-fit (choose the bin with the smallest residual >= item) is already
very strong online.  Its main weakness is occasionally stranding a bin with a
residual that no future item can use well.  Rather than a noisy pile of
penalties, we keep best-fit as the core and add one bounded, well-scaled
signal: reward residuals that a common future item could exactly fill (high
empirical histogram mass), scaled so it only breaks near-ties.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)
    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total

    r = residual.astype(np.float64)

    # Best-fit core: prefer the smallest residual that still fits.
    score = -r

    # Reward residuals some common future item could exactly seal. Bounded so
    # it only breaks near-ties in the best-fit core.
    score += fill_mass * 20.0

    # Strongly reward perfect seals (residual exactly 0).
    score += (residual == 0).astype(np.float64) * 25.0

    return score
# EVOLVE-BLOCK-END
