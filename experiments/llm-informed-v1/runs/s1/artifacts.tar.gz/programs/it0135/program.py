# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with smoothed exact-fill weighting.

Pure best fit strands bins with residuals no future item can ever fill.  The
item sizes come from a fixed (Weibull-shaped) distribution, so residuals equal
to frequent item sizes are far more likely to be closed later.  This rule keeps
a best-fit core and adds a bonus proportional to the smoothed empirical
probability of exactly filling the resulting residual, so common residuals are
preferred over rare ones without any hard thresholds.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = None
_smooth = None
_last_update = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count, _smooth, _last_update
    _n_items = n
    _seen = 0
    _residuals = np.full(n + 1, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.float64)
    _bin_count = 0
    _smooth = np.zeros(101, dtype=np.float64)
    _last_update = 0


def _update_smooth():
    global _smooth, _last_update
    # simple 1-2-1 smoothing of the empirical histogram over sizes 1..100
    h = _hist[1:101]
    sm = h.copy()
    sm[1:-1] = 0.25 * h[:-2] + 0.5 * h[1:-1] + 0.25 * h[2:]
    total = sm.sum()
    if total > 0:
        _smooth[1:101] = sm / total
    else:
        _smooth[:] = 0.01


def priority(item, bins):
    global _seen, _bin_count, _last_update

    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    _seen += 1
    _hist[item] += 1.0

    # refresh the smoothed distribution occasionally (cheap)
    if _seen - _last_update >= 16 or _last_update == 0:
        _update_smooth()
        _last_update = _seen

    residual = bins - item  # >= 0 for fitting bins

    idx = residual  # already in [0,100]
    fill_prob = _smooth[idx]

    score = -residual.astype(np.float64)  # best-fit core
    # big reward for closing a bin exactly
    score += (residual == 0).astype(np.float64) * 200.0
    # distribution-aware tie-break: reward residuals that are common sizes
    score += fill_prob * 400.0

    return score
# EVOLVE-BLOCK-END
