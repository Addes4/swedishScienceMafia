# EVOLVE-BLOCK-START
"""Best fit with a mild penalty for near-dead residuals."""
import numpy as np

_mu = 40.0
_n = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mu, _n
    _n += 1
    _mu += (item - _mu) / _n

    residual = bins - item  # >= 0 for all shown bins

    # Best-fit base score: smaller residual -> higher score.
    base = -residual.astype(np.float64)

    # Mild penalty when residual is below the running mean item size,
    # scaling up as the residual shrinks toward 0 (near-dead bin).
    mu = _mu
    dead = residual < mu
    # penalty in [0, ~1]; small so best-fit ordering is mostly preserved
    pen = np.where(dead, (mu - residual) / mu, 0.0)

    return base - pen
# EVOLVE-BLOCK-END
