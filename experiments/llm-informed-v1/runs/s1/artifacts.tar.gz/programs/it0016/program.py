# EVOLVE-BLOCK-START
"""Myopic expected-waste bin choice driven by the observed item-size histogram."""
import numpy as np

# Module-level state, reset per instance (fresh process each instance).
_counts = np.zeros(101, dtype=np.float64)   # histogram of item sizes seen so far
_total = 0


def _reset_if_needed(n):
    global _counts, _total
    if _counts.sum() == 0.0 and n > 0:
        # lazy init done; nothing else to do
        pass


def priority(item, bins):
    """Score each candidate bin by expected future reusability of the residual."""
    global _counts, _total

    # Update histogram with the arriving item (we always see every item).
    if item < len(_counts):
        _counts[item] += 1.0
        _total += 1.0

    leftovers = bins - item  # >= 0 for all bins shown

    # Fallback: pure best-fit until we have a reasonable histogram.
    if _total < 60:
        return -leftovers

    # Probability weights over sizes 1..100 (Laplace-smoothed uniform prior).
    probs = (_counts[1:101] + 0.5) / (_total + 50.0)

    # For each candidate bin, expected "waste" contribution of the residual r:
    # a residual r is reusable if a future item equals r exactly (leftover 0),
    # or can use most of it. We approximate by rewarding residuals whose value
    # has meaningful probability mass near it.
    # Build a per-leftover value using a small smoothing window over probs.
    sizes = np.arange(1, 101, dtype=np.float64)
    p = probs  # length 100 for sizes 1..100

    # Value of a residual r: probability that some future item fits in r and
    # leaves a small residual, weighted by how well it uses r.
    # v(r) = sum_s p(s) * 1[s <= r] * (s / r)   (fraction of r consumed)
    # Compute efficiently: cumulative sums of p(s)*s and 1[s<=r].
    ps = p * sizes
    cum_ps = np.concatenate(([0.0], np.cumsum(ps)))   # cum_ps[r] = sum_{s<=r} p*s
    cum_p = np.concatenate(([0.0], np.cumsum(p)))      # cum_p[r] = sum_{s<=r} p

    r = leftovers.astype(np.float64)
    # clip to valid index range for the value lookup
    ri = np.clip(r, 0, 100).astype(np.int64)

    # value(r): expected fraction of r filled by the next fitting item,
    # scaled by the probability that such an item exists at all.
    with np.errstate(divide="ignore", invalid="ignore"):
        val = np.where(ri > 0,
                       cum_ps[ri] / np.maximum(r, 1.0),
                       0.0)
    # Bonus for high probability that *something* fits (keeps residual attractive).
    val = val + 0.15 * cum_p[ri]

    # Penalize very small residuals (fragments that rarely help).
    small_pen = np.where((ri > 0) & (ri < 8), -0.05, 0.0)

    return val + small_pen
# EVOLVE-BLOCK-END

