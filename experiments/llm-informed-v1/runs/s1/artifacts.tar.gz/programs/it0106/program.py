# EVOLVE-BLOCK-START
"""Lexicographic bin choice: exact-fill, then best viable residual, then most room.

The additive-bonus version could let a large "usable" bonus override a much
better best-fit candidate.  Here the ranking is made explicit:
  1. Any bin that is filled exactly (residual 0) wins outright.
  2. Otherwise prefer the smallest residual that is still >= a viability
     threshold (empirical q10 of seen sizes), i.e. still able to host a common
     small future item -- densest packing without stranding.
  3. If no candidate clears the threshold, prefer the largest residual so the
     bin keeps the most room for future larger items.
The threshold adapts to the Weibull shape via the empirical histogram.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    q10 = _quantile(0.10)
    if q10 < 1:
        q10 = 1

    # Lexicographic score via large weight separation.
    # Ranks (lower is better) combined into a single ascending key.
    exact = (residual == 0)
    viable = (residual >= q10)

    # Tier: 0 = exact fill, 1 = viable residual, 2 = no viable residual
    tier = np.where(exact, 0, np.where(viable, 1, 2))

    # Within tier 1: smaller residual is better.
    # Within tier 2: larger residual is better.
    score = -tier.astype(np.float64) * 1000.0
    score += np.where(tier == 1, -residual, residual).astype(np.float64)

    return score
# EVOLVE-BLOCK-END

