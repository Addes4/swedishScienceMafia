# EVOLVE-BLOCK-START
"""Residual-targeting rule based on the empirical mean item size.

Items are i.i.d. from a fixed distribution (mean ~40).  Best-fit tends to
strand many bins whose residuals are too small to accept typical items.  A
robust alternative is to steer each bin's residual toward the typical item
size: after placing the current item, we prefer the bin whose residual is
closest to the running mean item size.  Such bins remain useful (they can be
finished off by an average-sized item) yet are not left nearly empty, which
would waste capacity.  Unused bins (residual 100) are penalized so the rule
does not keep opening fresh bins unnecessarily.
"""
import numpy as np

_n_items = None
_seen = 0
_sum = 0.0


def _init(n):
    global _n_items, _seen, _sum
    _n_items = n
    _seen = 0
    _sum = 0.0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    _seen += 1
    _sum += item
    mean_item = _sum / _seen if _seen > 0 else 40.0

    residual = bins - item  # >= 0 for fitting bins

    # Prefer residuals close to the typical item size.  Larger residuals than
    # mean are slightly worse than slightly-smaller-but-usable ones, so use a
    # base of -residual to break ties toward tighter bins among equals.
    dist = np.abs(residual.astype(np.float64) - mean_item)

    score = -dist - 0.01 * residual.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
