# EVOLVE-BLOCK-START
"""Best fit with empirical residual-fittability bonus.

Classic best fit (smallest resulting residual) is a strong online rule, but it
can strand residuals that no future item size can fill.  We keep best-fit as the
dominant signal and add a bonus when the resulting residual equals a *common*
recent item size, since such a residual is likely to be filled exactly later.
The frequency of each item size is tracked online, so the rule adapts to the
Weibull distribution without tuning to a specific instance.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    # Best fit: prefer smallest non-negative residual.
    score = -residual.astype(np.float64)

    # Probability mass of "this exact residual will be filled next".
    # Normalized empirical frequency of each candidate residual value.
    if _seen > 0:
        freq = _hist / float(_seen)
    else:
        freq = _hist * 0.0

    # residual values are in [0, 100]; frequency bonus for matching common sizes
    fit_bonus = freq[np.clip(residual, 0, 100)]
    score += fit_bonus * 40.0

    # Exact fills are always best.
    score += (residual == 0).astype(np.float64) * 60.0

    return score
# EVOLVE-BLOCK-END
