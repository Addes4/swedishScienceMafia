# EVOLVE-BLOCK-START
"""Distribution-aware best fit with a viability (median-fit) tie-breaker.

Pure best fit tends to strand bins: it leaves tiny residuals that no future
item fits.  Since sizes come from a fixed Weibull distribution (mean ~40),
we can cheaply estimate the empirical median size from a running histogram.
Bins whose resulting residual is at or above the median can still accept
about half of all future items, so they are far more valuable than bins with
smaller residuals.  We keep best fit as the dominant signal (smaller residual
is better) and add a modest bonus for residuals that remain "viable" (>= the
empirical median), plus a large bonus for exact fills (residual 0).
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    # Empirical median item size from the running histogram.
    target = 0.5 * _seen
    cum = 0
    median = 1
    for s in range(1, 101):
        cum += int(_hist[s])
        if cum >= target:
            median = s
            break

    score = -residual.astype(np.float64)  # best-fit core
    # Exact fills free a bin entirely -- strongly preferred.
    score += (residual == 0).astype(np.float64) * 80.0
    # Viability bonus: residuals still able to accept a typical (median) item.
    score += ((residual >= median) & (residual > 0)).astype(np.float64) * 30.0

    return score
# EVOLVE-BLOCK-END
