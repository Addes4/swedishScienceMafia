# EVOLVE-BLOCK-START
"""Expected-future-fill best fit.

Keep a best-fit core (prefer smaller resulting residual) but weight it by the
expected future value of leaving that residual open.  The value is the
probability that the residual will be exactly filled by some future item,
estimated from the empirical size histogram and the number of items remaining.
Early on we have many future items, so exact-fill probability matters; near the
end we mostly just want to avoid stranding residuals, which the best-fit core
handles.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.ones(101, dtype=np.float64)  # Laplace smoothing


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for bins the item fits in

    total = _hist.sum()
    remaining = max(_n_items - _seen, 0)
    idx = np.clip(residual, 0, 100)
    p_size = _hist[idx] / total  # P(a random item has exactly this size)

    # Expected number of future items equal to the residual size, capped at 1
    # as a rough probability the slot gets exactly filled.
    fill_prob = 1.0 - np.exp(-remaining * p_size)

    # Best-fit core scaled by how much future exposure remains.  When many
    # items remain, exact-fill potential dominates; as the instance ends the
    # pure best-fit term dominates.
    frac_rem = remaining / max(_n_items, 1)
    core = -residual.astype(np.float64)

    # Immediately completing a bin is always great, so boost residual==0.
    score = core * (0.5 + 0.5 * frac_rem)
    score += (residual == 0).astype(np.float64) * 60.0
    score += fill_prob * 30.0

    return score
# EVOLVE-BLOCK-END
