# EVOLVE-BLOCK-START
"""Best-fit core with an empirical "sealability" correction.

Pure best-fit is already very strong here. Its main weakness is leaving small
residuals that no future item can exactly use, and preferring bins whose
residual can be exactly sealed by a likely future item.

We keep score = -residual (best fit) and add a single, calibrated bonus for
residuals whose size carries high empirical histogram mass (i.e. a future item
is likely to exactly fill them), scaled small enough not to distort best fit.
"""
import numpy as np

_n_items = None
_residuals = None
_hist = None
_seen = 0


def _init(n):
    global _n_items, _residuals, _hist, _seen
    _n_items = n
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _seen = 0


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for shown bins
    r = residual.astype(np.float64)

    total = max(_seen - 1, 1)

    # Best-fit core.
    score = -r

    # Empirical probability that a future item exactly matches this residual
    # (i.e. can perfectly seal the bin).
    idx = np.clip(residual, 0, 100)
    seal_mass = _hist[idx].astype(np.float64) / total

    # Reward sealability.
    score += seal_mass * 40.0

    # Strong extra reward for a perfect seal.
    score += (residual == 0).astype(np.float64) * 60.0

    return score
# EVOLVE-BLOCK-END

