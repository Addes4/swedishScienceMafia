# EVOLVE-BLOCK-START
"""Best-fit core with a mild de-fragmentation tie-breaker.

Pure best fit tends to strand slivers that no future item can ever use.  The
item sizes come from a fixed (Weibull-like) distribution with mean ~40, so a
residual that can still accept a median-sized item is much more valuable than
a slightly smaller residual that can only accept rare tiny items.

The rule keeps -residual as the dominant term (so it behaves like best fit),
then adds a modest bonus when the resulting residual is at least the current
empirical median item size, encouraging us to close bins rather than leave
unusable slivers.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for fitting bins
    res_f = residual.astype(np.float64)

    # Empirical median item size from the running histogram.
    total = _seen
    target = 0.5 * total
    cum = 0.0
    median = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            median = s
            break

    score = -res_f                       # best-fit core (dominant)
    score += (residual >= median).astype(np.float64) * 3.0
    score += (residual == 0).astype(np.float64) * 1.0

    return score
# EVOLVE-BLOCK-END

