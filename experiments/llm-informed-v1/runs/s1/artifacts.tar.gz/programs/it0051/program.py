# EVOLVE-BLOCK-START
"""Best fit with slight preference for residual values that future items likely fill.

Items are i.i.d. Weibull-shaped with mean ~40. Best fit minimizes leftover but
often strands tiny residuals. Here we nudge the ranking toward residuals that
match common item sizes (~40) or their complements, without breaking the
strong average behavior of best fit.
"""
import numpy as np

# Residuals that are "useful" because a future item of a typical size,
# or a small number of them, can fill them.
_USEFUL = np.array([0.0, 40.0, 60.0, 80.0, 20.0], dtype=np.float64)
_WEIGHT = np.array([3.0, 1.0, 1.0, 1.0, 0.5], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    r = bins - item  # post-placement residual; bins is a copy
    # Best-fit base: smaller residual is better.
    base = -r.astype(np.float64)
    # Similarity bonus: how close the residual is to a useful value.
    diff = np.abs(r[:, None].astype(np.float64) - _USEFUL[None, :])
    bonus = (np.exp(-diff / 5.0) * _WEIGHT[None, :]).sum(axis=1)
    return base + bonus
# EVOLVE-BLOCK-END
