# EVOLVE-BLOCK-START
"""Best-fit with perfect-seal reward and unusable-sliver penalty.

The empirical evidence from many attempts is that the many overlapping
statistical bonuses (median penalty, fill-mass, fit-mass, mean-multiple
nudges) do not help; they mostly add noise that reorders near-tied bins
away from the strong best-fit choice.

This rule keeps a clean, dominant best-fit core and adds only two sharp
signals that are almost always correct:
  * a strong reward for a perfect seal (residual becomes 0),
  * a penalty for a residual that is smaller than the smallest item size
    seen so far (such a bin can never be filled by any future item of a
    size we have actually observed, so it is effectively dead capacity).
"""
import numpy as np

_n_items = None
_seen = 0
_min_seen = 101


def _init(n):
    global _n_items, _seen, _min_seen
    _n_items = n
    _seen = 0
    _min_seen = 101


def priority(item, bins):
    global _seen, _min_seen

    n = len(bins)
    if _n_items is None or _n_items != n:
        _init(n)

    _seen += 1
    if item < _min_seen:
        _min_seen = item

    residual = bins - item  # >= 0 for shown bins
    r = residual.astype(np.float64)

    # Best-fit core: prefer the tightest remaining capacity.
    score = -r

    # Perfect seal: a bin that becomes exactly full is strictly best.
    score += (residual == 0).astype(np.float64) * 50.0

    # Dead-sliver penalty: a residual smaller than the smallest item ever
    # seen cannot be filled by any item size we have observed.
    dead = ((residual > 0) & (residual < _min_seen)).astype(np.float64)
    score -= dead * 25.0

    return score
# EVOLVE-BLOCK-END


