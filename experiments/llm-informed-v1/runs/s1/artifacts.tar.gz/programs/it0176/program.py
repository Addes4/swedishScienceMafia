# EVOLVE-BLOCK-START
"""Best-fit with a late, capped perfect-seal bonus.

Experiments show that pure best-fit (score = -residual) is a very strong core,
and that all extra distribution-aware terms so far reduced the score.  The one
thing best fit could still do better is to finish off a bin exactly when the
opportunity arises, especially toward the end of the run when a sealed bin
saves a whole future bin.  So we keep best-fit and add a bonus for residuals
that go to exactly zero, scaled by how many items remain: small early, large
late.  Nothing else.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None


def _init(n):
    global _n_items, _seen, _residuals
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    residual = bins - item  # >= 0 for shown bins

    # Fraction of the instance already consumed.
    frac = _seen / float(n) if n > 0 else 1.0

    # Best-fit core.
    score = -residual.astype(np.float64)

    # Perfect seal: reward grows with progress, capped so it never dominates
    # the best-fit ordering except when residuals are nearly equal.
    seal_bonus = 1.0 + 3.0 * frac
    score += (residual == 0).astype(np.float64) * seal_bonus

    return score
# EVOLVE-BLOCK-END

