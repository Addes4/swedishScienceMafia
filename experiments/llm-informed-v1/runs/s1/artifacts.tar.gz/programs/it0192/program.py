# EVOLVE-BLOCK-START
"""Competitive best-fit with empirical exact-fill targeting.

Pure best fit leaves tiny residuals that no future item can use.  Sizes come
from a fixed Weibull-like distribution (mean ~40).  A residual is valuable if
future items are likely to fit it exactly, and a bin whose residual is small
(a single typical item away from sealing) is a good target.

This rule keeps best-fit as the core (score = -residual) and adds:
  * a strong reward for residuals equal to 0 (perfect seal),
  * a data-driven reward for residuals whose value has high empirical mass
    (future item likely to exactly fill it),
  * a light flexibility reward (residual admits some future item),
  * a small preference for residuals near the running mean item size so a
    single typical item nearly seals the bin.
All statistics are updated from items seen so far only (no look-ahead).
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_sum = 0


def _init(n):
    global _n_items, _seen, _hist, _sum
    _n_items = n
    _seen = 0
    _hist = np.zeros(102, dtype=np.float64)
    _sum = 0


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1.0
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = float(max(_seen - 1, 1))
    mean = _sum / _seen

    idx = np.clip(residual, 0, 100).astype(np.int64)

    # Empirical exact-fill mass (smoothed with a small prior).
    mass = (_hist[idx] + 0.5) / (total + 50.0)

    # Flexibility: fraction of past items that fit in this residual.
    cum = np.cumsum(_hist)
    fit_frac = cum[idx] / total

    # Best-fit core.
    score = -residual.astype(np.float64)

    # Perfect seal.
    score += (residual == 0).astype(np.float64) * 60.0

    # Exact-fill likelihood.
    score += mass * 40.0

    # Flexibility (some future item fits).
    score += fit_frac * 6.0

    # Prefer residuals close to the running mean (single item nearly seals).
    if mean > 0:
        near = np.abs(residual.astype(np.float64) - mean)
        score += np.maximum(0.0, 10.0 - near) * 0.4

        # Slight bonus just above the mean (small usable leftover).
        above = residual.astype(np.float64) - mean
        just_above = (above > 0) & (above <= 6.0)
        score += just_above.astype(np.float64) * 1.5

    return score
# EVOLVE-BLOCK-END
