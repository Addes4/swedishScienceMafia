# EVOLVE-BLOCK-START
"""Best-fit core with a distribution-aware exact-fill bonus.

The main failure of pure best fit is stranding bins with residuals that no
future item can ever fit.  Since item sizes come from a fixed (Weibull)
distribution with mean ~40, residuals that equal a frequently-occurring item
size are far more likely to be exactly closed later, which is what actually
removes a bin from the packing.

This rule keeps a best-fit core (prefer the smallest resulting residual) but
adds a bonus proportional to the smoothed empirical probability that the
resulting residual will be exactly matched by some future item.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for bins the item fits in

    # Smoothed empirical distribution of item sizes seen so far (plus a small
    # uniform prior so early calls still discriminate).
    prior = 0.5
    total = _seen + prior * 100.0
    smoothed = (_hist + prior) / total

    idx = np.clip(residual, 0, 100)
    fill_mass = smoothed[idx]

    score = -residual.astype(np.float64)  # best-fit core
    score += (residual == 0).astype(np.float64) * 120.0  # exact closure
    score += fill_mass * 30.0  # likely to be exactly filled later

    return score
# EVOLVE-BLOCK-END
