# EVOLVE-BLOCK-START
"""Competitive best-fit with future-fill viability (time-aware).

Pure best fit leaves a few bins with tiny residuals that no future item can
ever use, and it never rebalances toward bins that can still accept typical
items.  Since sizes come from a fixed Weibull-like distribution (mean ~40),
a residual is *useful* only if some future item fits it, and it is *valuable*
if future items are likely to exactly fill it.

This rule keeps best-fit as the core (score = -residual) but:
  * penalizes residuals below the empirical 25th percentile item size,
  * rewards residuals whose size has high empirical histogram mass,
  * gives a strong reward for residuals that equal 0 (perfect seal),
  * scales the exact-fill reward by the number of items still to come.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)
    remaining = max(_n_items - _seen, 0)
    # Fraction of the instance still to arrive.
    frac_remaining = remaining / max(_n_items, 1)

    # Empirical 25th percentile item size via cumulative histogram.
    target = 0.25 * total
    cum = 0.0
    q25 = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            q25 = s
            break

    idx = np.clip(residual, 0, 100)
    # Empirical mass at the exact residual size (chance of an exact fill).
    fill_mass = _hist[idx].astype(np.float64) / total
    # Empirical mass at sizes <= residual (chance some item fits at all).
    cum_hist = np.cumsum(_hist).astype(np.float64) / total
    fit_mass = cum_hist[idx]

    # Best-fit core.
    score = -residual.astype(np.float64) * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize residuals too small to accept even a small typical item,
    # but only if they are not a perfect seal.  Penalty fades as the run
    # nears its end, when sealing matters less.
    too_small = ((residual > 0) & (residual < q25)).astype(np.float64)
    score -= too_small * (35.0 * (0.4 + 0.6 * frac_remaining))

    # Reward residuals that a future item can exactly fill, weighted by the
    # number of items still to come (more chances late in the run).
    score += fill_mass * (30.0 * (0.3 + 0.7 * frac_remaining))

    # Reward residuals that admit at least some future item (flexibility).
    score += fit_mass * 8.0

    return score
# EVOLVE-BLOCK-END
