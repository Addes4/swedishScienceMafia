# EVOLVE-BLOCK-START
"""Best fit with residual-reusability awareness (tie-break only).

Best fit (choose the bin with the smallest remaining capacity that still fits) is
essentially optimal for online bin packing under a near-continuous size distribution.
Its one weakness is that it can strand tiny residuals that no future item can ever use.

We keep the full packing state ourselves and a histogram of item sizes seen so far.
A residual is "reusable" if it is at least as large as the smallest item we have seen.
We rank bins by best fit, but add only a *tiny* epsilon bonus to bins whose
post-placement residual stays reusable, so the bonus acts purely as a tie-break and
never overrides genuine best-fit ordering (residuals are integers, so eps < 1 is
enough to keep ordering intact while nudging away from stranding dead space).
"""
import numpy as np

# --- persistent state (fresh process per instance) ---
_n_items = None          # number of items in the instance
_seen = 0                # items seen so far
_residuals = None        # remaining capacity of every bin, indexed by bin order
_min_seen = 101          # smallest item size observed so far
_hist = None             # counts of item sizes, index 0..100


def _init(n):
    global _n_items, _seen, _residuals, _min_seen, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _min_seen = 101
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    global _seen, _min_seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    if item < _min_seen:
        _min_seen = item
    _hist[item] += 1

    # Smallest size we plausibly still expect. Use the observed minimum; if we have
    # not seen anything small yet, fall back to a conservative small value.
    floor = _min_seen if _min_seen <= 100 else 1

    residual = bins - item  # >= 0 for all bins shown

    # Best fit: smallest residual first => highest score. Dominant term.
    score = -residual.astype(np.float64)

    # Tie-break only: tiny epsilon bonus for residuals still usable by a future item.
    # eps = 0.5 < 1, so integer-residual ordering is preserved exactly; among bins
    # with equal residual, prefer the one whose leftover is reusable.
    usable = residual >= floor
    score += usable.astype(np.float64) * 0.5

    # Exact fills are strictly good; give them the same half-step (already covered
    # when residual==0 since 0 < floor for floor>=1, so handle explicitly).
    score += (residual == 0).astype(np.float64) * 0.25

    return score
# EVOLVE-BLOCK-END
