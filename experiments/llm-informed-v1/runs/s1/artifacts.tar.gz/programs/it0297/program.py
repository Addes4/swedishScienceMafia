# EVOLVE-BLOCK-START
"""Best-fit with a single principled tie-break.

Pure best fit is extremely strong here.  Earlier versions layered many
hand-tuned residual-shaping bonuses on top of it and regressed.  This
version instead makes best-fit strictly dominant and adds exactly one
small, well-founded tie-break:

    score = -residual * 1000 + seal_weight * P(future item == residual)

where P(...) is the empirical histogram mass of the resulting residual,
computed from items seen so far (Laplace-smoothed so unseen sizes are not
absolutely forbidden).  Because the best-fit term is scaled by 1000 and
residual is integral, the tie-break only ever matters among bins with the
same residual, and even there its magnitude (<=1) is far below 1000, so it
can never change which residual is chosen.  It simply resolves exact ties
in favour of the bin most likely to be perfectly sealed soon.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_total = 1
_smallest = None


def _init(n):
    global _n_items, _seen, _hist, _total, _smallest
    _n_items = n
    _seen = 0
    _hist = np.ones(101, dtype=np.float64)  # Laplace smoothing
    _hist[0] = 0.0
    _total = float(_hist.sum())
    _smallest = None


def priority(item, bins):
    global _seen, _total, _smallest

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    if _smallest is None or item < _smallest:
        _smallest = item
    _hist[item] += 1.0
    _total += 1.0

    residual = bins - item  # >= 0 for shown bins

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)

    # Empirical probability that a future item exactly seals this residual.
    seal_prob = _hist[idx] / _total

    # Strictly dominant best-fit core plus a bounded tie-break.
    score = -r * 1000.0 + seal_prob * 1.0

    # Break remaining ties deterministically toward smaller residuals is
    # already implied; add a tiny nudge so exact residual ties among equal
    # seal_prob go to the first bin (stable, matches harness default).
    return score
# EVOLVE-BLOCK-END
