# EVOLVE-BLOCK-START
"""Best-fit core with a viability floor based on the empirical size quantile.

Pure best fit is strong, but it can strand bins with tiny residuals that no
future item can ever fit.  Since item sizes come from a fixed distribution, we
can estimate a low quantile of the size distribution online and reward leaving
residuals at or above it, while still keeping the best-fit ordering inside the
viable region.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0

    # Empirical q20 from cumulative histogram (cheap, 100-step loop).
    total = _seen
    target = 0.20 * total
    cum = 0
    q20 = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            q20 = s
            break

    r = residual.astype(np.float64)

    # Best-fit core: prefer smaller residual.
    score = -r

    # Strong bonus for exact fill (residual 0) — closes the bin.
    score += (residual == 0).astype(np.float64) * 100.0

    # Viability floor: reward residuals at/above q20 (reusable bins).
    score += (residual >= q20).astype(np.float64) * 50.0

    return score
# EVOLVE-BLOCK-END
