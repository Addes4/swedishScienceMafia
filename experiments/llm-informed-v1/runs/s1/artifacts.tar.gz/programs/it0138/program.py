# EVOLVE-BLOCK-START
"""Distribution-aware residual targeting with best-fit core.

Pure best fit strands bins whose residuals no future item can use.  Since
item sizes come from a fixed (Weibull) distribution with mean ~40, a residual
is valuable when it can still accept a draw from that distribution.  We keep a
best-fit core, add a strong exact-fill bonus (closing a bin is what actually
saves bins), and replace the blunt q10 "usable" jump with a smooth viability
term: the empirical probability that an item drawn from the observed size
distribution fits into the candidate residual.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    total = max(_seen, 1)

    # Exact-fill mass: empirical probability an item equals the residual.
    idx = np.clip(residual, 0, 100)
    exact_mass = _hist[idx].astype(np.float64) / total

    # Smooth viability: empirical probability a future item fits in residual.
    # CDF of observed sizes evaluated at the residual.
    cdf = np.cumsum(_hist).astype(np.float64) / total  # size 101
    fit_prob = cdf[np.clip(residual, 0, 100)]

    score = -residual.astype(np.float64)  # best-fit core
    # Closing a bin is the biggest win.
    score += (residual == 0).astype(np.float64) * 80.0
    # Smooth viability bonus: larger residuals that can still take a typical
    # item are more useful than ones stranded below the smallest likely item.
    score += fit_prob * 40.0
    # Distribution-aware bonus: residuals matching frequent future sizes.
    score += exact_mass * 25.0

    return score
# EVOLVE-BLOCK-END

