# EVOLVE-BLOCK-START
"""Best-fit with empirical fill-probability bonus.

Pure best fit is near-optimal here, so it stays the dominant term
(score = -residual).  On top of it we add one principled, bounded term: the
empirical probability that the resulting residual can be exactly consumed by
one or two future items drawn from the observed size distribution.  Such bins
are "sealable", and preferring them reduces the number of half-empty bins
left behind, without ever overriding the best-fit ordering by much.

Everything is derived from the running histogram of seen item sizes, so the
rule adapts online and uses no future information.
"""
import numpy as np

_n = None
_seen = 0
_hist = None
_pairs = None          # convolution of histogram with itself (mass at each sum)
_pairs_dirty = True


def _init(n):
    global _n, _seen, _hist, _pairs, _pairs_dirty
    _n = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.float64)
    _pairs = np.zeros(201, dtype=np.float64)
    _pairs_dirty = True


def _update_pairs():
    global _pairs, _pairs_dirty
    h = _hist
    # convolution of histogram with itself, mass = prob(i)+prob(j)
    _pairs = np.convolve(h, h)
    _pairs_dirty = False


def priority(item, bins):
    global _seen, _pairs_dirty

    n = len(bins)
    if _n is None or _n != n:
        _init(n)

    _seen += 1
    _hist[item] += 1.0
    _pairs_dirty = True

    total = float(_seen)
    residual = bins - item                     # >= 0 for shown bins

    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)

    # Best-fit core: prefer the smallest non-negative residual.
    score = -r

    # Exact one-item seal: residual equals a size with high mass.
    if _seen > 1:
        if _pairs_dirty:
            _update_pairs()
        one = _hist[idx] / total               # P(future item == residual)
        two = _pairs[idx] / total              # P(pair of future items sums to residual)
        seal = one + 0.5 * two
        # strong but bounded bonus for perfectly sealable residuals
        score += (residual == 0).astype(np.float64) * 30.0
        score += np.minimum(seal * 400.0, 25.0)

    return score
# EVOLVE-BLOCK-END
