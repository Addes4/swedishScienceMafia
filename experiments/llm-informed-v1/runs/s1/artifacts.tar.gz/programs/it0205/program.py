# EVOLVE-BLOCK-START
"""Best fit with a "dead residual" penalty.

Items arrive online from a fixed Weibull-like distribution (mean ~40).  The
classic failure of pure best fit is leaving small residuals that can never be
used again, wasting bins.  This rule keeps a dominant best-fit core plus a
strong perfect-seal reward, and adds a single robust, well-principled signal:
penalize residuals that are too small to admit a typical future item, so the
current item prefers to consolidate into (or avoid creating) likely-dead bins.

The "too small" threshold is a low quantile of the item sizes seen so far, so
it adapts to the distribution without fragile hand-tuning.  The penalty is
kept smaller than the perfect-seal reward so a bin that can be exactly sealed
is never dropped.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    # Low quantile (approx q=0.20) item size seen so far: a residual below this
    # is unlikely to be fillable by a future item.
    target = 0.20 * total
    cum = 0
    thresh = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            thresh = s
            break

    score = -residual.astype(np.float64)

    # Strong reward for a perfect seal.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize likely-dead residuals (too small to fit a typical future item).
    dead = ((residual > 0) & (residual < thresh)).astype(np.float64)
    score -= dead * 25.0

    return score
# EVOLVE-BLOCK-END
