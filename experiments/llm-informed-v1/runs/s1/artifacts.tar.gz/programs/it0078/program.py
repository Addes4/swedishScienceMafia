# EVOLVE-BLOCK-START
"""Best fit with empirical-quantile residual awareness.

Best fit is near-optimal for online bin packing under a near-continuous size
distribution; its weakness is stranding residuals that no realistically small
future item can use. We keep the full packing state and an empirical histogram
of item sizes seen so far, and use a low quantile of that histogram to decide
which residuals are worth preserving.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    # low quantile of sizes seen so far (small items still likely to arrive)
    q10 = _quantile(0.10)
    q05 = _quantile(0.05)

    residual = bins - item  # >= 0
    score = -residual.astype(np.float64)

    # bonus: leftover stays useful for a plausibly small future item
    usable = residual >= q10
    score += usable.astype(np.float64) * q10 * 0.4

    # strongly reward exact fills (never harmful)
    score += (residual == 0).astype(np.float64) * (q10 * 0.5 + 0.25)

    # small extra credit when leftover sits below q05 (truly dead space avoided)
    dead = (residual > 0) & (residual < q05)
    score -= dead.astype(np.float64) * q05 * 0.4

    return score
# EVOLVE-BLOCK-END
