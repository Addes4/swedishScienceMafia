# EVOLVE-BLOCK-START
"""Best fit with dead-zone avoidance: prefer placements that don't create
tiny unusable residuals, otherwise tightest fit."""
import numpy as np

_state = {"min_item": 100, "seen": 0}


def priority(item, bins):
    st = _state
    # track smallest item seen (proxy for usable residual sizes)
    if item < st["min_item"]:
        st["min_item"] = item

    residual = bins - item
    # dead zone: 0 < residual < min_item_seen means the leftover will likely
    # never be filled. Prefer bins that avoid creating such residuals.
    dead = (residual > 0) & (residual < st["min_item"])
    exact = (residual == 0)

    # base: tightest fit (largest -residual => smallest residual)
    base = -residual.astype(np.float64)

    # strong bonus for exact fill, strong penalty for dead-zone leftovers
    score = base - 1000.0 * dead.astype(np.float64) + 500.0 * exact.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
