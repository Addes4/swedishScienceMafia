# EVOLVE-BLOCK-START
"""Best-fit with a soft lower bound on residual viability.

The core rule is best fit: place the item into the bin whose post-placement
residual is smallest.  This keeps bins dense, which historically wins on this
distribution.  The only deviation is discouraging residuals that are too small
to be filled by any realistically small future item: we estimate the smallest
item size likely to appear from a windowed empirical histogram, and only mildly
penalize residuals below that, so best-fit dominance is preserved.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def _small_quantile(q):
    """Empirical q-quantile of item sizes seen so far (small side)."""
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in
    resf = residual.astype(np.float64)

    # Base best-fit: smaller residual is better.
    score = -resf

    # Empirical smallest-likely future item size (5th percentile).
    small = _small_quantile(0.05)

    # Only penalize residuals that are tiny but nonzero and below the size of
    # any plausibly small future item: those are hard to fill and strand space.
    # Keep it mild so best-fit denseness still dominates.
    tiny = (residual > 0) & (residual < small)
    score -= tiny.astype(np.float64) * 5.0

    # Exact fills are always strongly preferred.
    score += (residual == 0).astype(np.float64) * 40.0

    return score
# EVOLVE-BLOCK-END
