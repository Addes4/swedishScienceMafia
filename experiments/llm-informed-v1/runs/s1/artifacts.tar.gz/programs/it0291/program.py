# EVOLVE-BLOCK-START
"""Best-fit with exact-seal probability and an unusable-residual penalty.

Core idea (empirically the strongest known rule here): pure best-fit,
score = -residual, dominated earlier attempts.  We add only two
well-normalized, low-magnitude terms that cannot override best-fit for
clearly distinct residuals:

  * + C_seal * P(item == residual): reward bins a future item can exactly
    seal.  Computed from the empirical histogram of sizes seen so far.
  * - C_useless for 0 < residual < min observed item size: such residuals
    can never be used by any future item of observed smallest size, so
    avoid creating them.

State kept: item histogram, count, running min item size.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_min_item = 101


def _init(n):
    global _n_items, _seen, _residuals, _hist, _min_item
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _min_item = 101


def priority(item, bins):
    global _seen, _min_item

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    # Update stats with the current item.
    _seen += 1
    _hist[item] += 1
    if item < _min_item:
        _min_item = item

    residual = bins - item  # >= 0 for the shown (fitting) bins

    total = _seen  # include current item in the histogram
    r = residual.astype(np.float64)

    # Core: best fit.
    score = -r

    # Probability that a future item exactly seals this bin.
    idx = np.clip(residual, 0, 100)
    seal_prob = _hist[idx].astype(np.float64) / total
    score += seal_prob * 40.0

    # Penalize residuals that no observed item can fill (strictly positive
    # but smaller than the smallest item we have ever seen).
    too_small = ((residual > 0) & (residual < _min_item)).astype(np.float64)
    score -= too_small * 25.0

    return score
# EVOLVE-BLOCK-END
