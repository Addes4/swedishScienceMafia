# EVOLVE-BLOCK-START
"""Best-fit core with empirical exact-fill mass and a learned
"closed-residual" bonus.

Item sizes come from a fixed distribution, so a bin whose resulting residual
r equals a frequently-seen item size is much more likely to be closed exactly
by a future item.  We keep a best-fit core (prefer small resulting residual),
add a bonus for exact fills (r == 0) and a distribution-aware bonus
proportional to the empirical mass of item sizes equal to r.

Additionally we track the histogram of residuals that we have *observed being
closed* (filled exactly) so far, and reward candidate residuals that history
shows actually get closed.  This adapts online to the specific instance while
remaining instance-agnostic.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None          # item size histogram
_closed = None        # histogram of residuals observed to be exactly closed


def _init(n):
    global _n_items, _seen, _residuals, _hist, _closed
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _closed = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in

    total = max(_seen, 1)
    idx = np.clip(residual, 0, 100)
    exact_mass = _hist[idx].astype(np.float64) / total
    closed_mass = _closed[idx].astype(np.float64) / total

    score = -residual.astype(np.float64)  # best-fit core
    # Strong bonus for exact fills.
    score += (residual == 0).astype(np.float64) * 80.0
    # Distribution-aware bonus: residuals matching frequent item sizes.
    score += exact_mass * 25.0
    # Learned bonus: residuals that history shows get closed.
    score += closed_mass * 15.0

    # Record residuals we are closing this step (bins that become exactly 0
    # after this placement, i.e. the chosen bin will be full).
    # We do this lazily by noting which of the shown bins hit residual 0; the
    # chosen one is one of them, but we cannot know the chosen index here.
    # Instead record all residuals that are reachable-and-closeable: this is
    # a mild signal. We count residuals equal to item size (i.e. bin capacity
    # exactly equals item) as "closeable" candidates.
    _closed[idx] += (residual == 0).astype(np.int64)

    return score
# EVOLVE-BLOCK-END
