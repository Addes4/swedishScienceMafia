# EVOLVE-BLOCK-START
"""Best fit with empirical residual-usefulness scoring.

We keep the full packing state and an empirical histogram of item sizes seen
so far. Among bins the item fits in, we prefer the smallest post-placement
residual (best fit), but we perturb that choice by the expected future value
of the leftover: a residual that is likely to be filled exactly (equals a
frequently seen future size) is worth more than an arbitrary leftover of the
same magnitude, and a residual that is too small for any realistic future
item is worth less. The score is smooth and dominated by best fit.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum
    _n_items = n
    _seen = 0
    _sum = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _sum += item
    _hist[item] += 1

    residual = bins - item  # >= 0 post-placement residual

    # Empirical mean size so far (falls back to a sane default at the start).
    mean = (_sum / _seen) if _seen > 0 else 40.0

    score = -residual.astype(np.float64)

    # Empirical probability mass by exact size (smoothed), measuring how
    # likely a future item exactly fills this residual.
    if _seen > 0:
        mass = _hist.astype(np.float64) / _seen
        # 1-step smoothing so unseen but plausible sizes are not zero.
        smooth = (mass + 1.0 / (_seen + 101))
        p_fill = smooth[residual]  # probability future item == residual (per draw)
        # Value of a usable leftover: scaled small relative to best-fit.
        score += p_fill * mean

    # Penalize genuinely dead space that no realistic item can use.
    dead = (residual > 0) & (residual < mean * 0.2)
    score -= dead.astype(np.float64) * mean * 0.05

    return score
# EVOLVE-BLOCK-END
