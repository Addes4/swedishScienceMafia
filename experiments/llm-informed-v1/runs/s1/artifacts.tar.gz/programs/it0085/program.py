# EVOLVE-BLOCK-START
"""Best fit augmented with harmonic-style residual classification.

Plain best-fit is near-optimal for continuous distributions but strands
residuals. Harmonic-type algorithms classify residuals into geometric size
classes and only co-locate items of similar class, which provably improves
the worst-case ratio. We combine both: primary term is best-fit (min residual),
and we add a bonus for placements whose residual falls inside a small
harmonic class that the current item's class can still use, plus a strong
exact-fill reward. Thresholds adapt to the empirical distribution via the
item histogram.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_mean = 0.0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _mean
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _mean = 0.0


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen, _mean

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _mean += (item - _mean) / _seen

    # Adaptive harmonic thresholds from empirical small-item scale.
    q10 = _quantile(0.10)
    q20 = _quantile(0.20)
    q35 = _quantile(0.35)

    residual = bins - item  # >= 0

    # Primary: best fit (smallest post-placement residual).
    score = -residual.astype(np.float64)

    # Harmonic-class bonus: favor residuals that sit in a useful small class,
    # so the bin stays accessible to items of that class rather than becoming
    # dead space.
    t1 = max(1.0, float(q10))
    t2 = max(t1 + 1.0, float(q20))
    t3 = max(t2 + 1.0, float(q35))

    good = (residual > 0) & (residual <= t3)
    score += good.astype(np.float64) * 0.6

    # Slightly larger credit when residual fits the very small class.
    tiny = (residual > 0) & (residual <= t1)
    score += tiny.astype(np.float64) * 0.5

    # Exact fill is always best.
    score += (residual == 0).astype(np.float64) * 1.5

    # Penalize leaving residual just below a class boundary that would then
    # only fit even tinier items (stranded dead space).
    dead = (residual > 0) & (residual < t1 * 0.5)
    score -= dead.astype(np.float64) * 0.4

    return score
# EVOLVE-BLOCK-END
