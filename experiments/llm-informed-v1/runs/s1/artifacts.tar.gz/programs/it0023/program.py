# EVOLVE-BLOCK-START
"""Modified best fit: tightest fit, but avoid leaving a tiny unusable residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: prefer tightest fit (smallest residual).
    score = -residual.astype(np.float64)
    # Discourage leaving a very small dead residual (< threshold) when an
    # alternative with a comfortably larger residual is nearly as tight.
    # Penalize tiny residuals so they lose to placements leaving ~threshold.
    tiny = residual < 8
    score[tiny] -= 50.0
    return score
# EVOLVE-BLOCK-END

