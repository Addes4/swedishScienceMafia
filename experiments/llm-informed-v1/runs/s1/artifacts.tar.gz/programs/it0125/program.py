# EVOLVE-BLOCK-START
"""Distribution-aware residual targeting.

Item sizes come from a fixed Weibull-shaped distribution (mean ~40).  Pure
best fit strands many bins with residuals too small to ever be useful again.
This rule keeps a best-fit core but:
  * strongly rewards exact fills (residual 0),
  * gives a smooth, distribution-aware bonus to residuals that a typical
    future item can still fit, weighted by how much of the distribution mass
    lies at or below that residual,
  * keeps smaller residuals preferred within the viable set.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    total = _seen

    residual = bins - item  # >= 0 for bins the item fits in

    # Cumulative distribution of observed sizes up to each residual value.
    cum = np.cumsum(_hist).astype(np.float64)  # cum[s] = #items with size <= s
    idx = np.clip(residual, 0, 100)
    cdf = cum[idx] / total  # fraction of past items <= resulting residual

    score = -residual.astype(np.float64)  # best-fit core

    # Strong bonus for exact fills.
    score += (residual == 0).astype(np.float64) * 100.0

    # Distribution-aware viability: residuals with a decent chance of being
    # filled later are worth keeping tight; strongly penalize residuals so
    # small that almost no item can ever use them again.
    score += cdf * 60.0

    return score
# EVOLVE-BLOCK-END

