# EVOLVE-BLOCK-START
"""Best fit with a small empirical reserve floor.

Place each item into the bin whose resulting residual is as small as possible,
but mildly prefer residuals that stay at or above a small floor derived from
the smallest item sizes seen so far.  This discourages stranding tiny residuals
that no future item can fill, without the hard q10 cliff that hurt earlier.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_min_seen = 100


def _init(n):
    global _n_items, _seen, _residuals, _hist, _min_seen
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _min_seen = 100


def _low_floor():
    # Small robust floor: smallest sizes that are reasonably likely to recur.
    total = _seen
    if total <= 0:
        return 1
    target = 0.25 * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item
    score = -residual.astype(np.float64)

    floor = _low_floor()

    # Prefer residuals that stay at/above the floor (still useful later).
    usable = (residual >= floor) & (residual > 0)
    score += usable.astype(np.float64) * 20.0

    # Exact fills are especially valuable.
    score += (residual == 0).astype(np.float64) * 50.0

    return score
# EVOLVE-BLOCK-END
