# EVOLVE-BLOCK-START
"""Best-fit with a residual-usefulness bonus based on the empirical item-size histogram."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    """Rank bins: prefer tightest fit, but favor residuals that match common item sizes."""
    h = _state["hist"]
    _state["n"] += 1

    residual = bins - item  # leftover capacity after placing item in each bin

    # Penalize huge residuals (they waste space) and reward residuals that match
    # common future item sizes (so they can be filled later).
    # Score = -residual + bonus for how likely residual equals a frequent size.
    total = h.sum()
    if total > 0:
        prob = h / total
    else:
        prob = None

    if prob is None:
        score = -residual.astype(np.float64)
    else:
        # bonus: probability mass near residual (residual itself or a few around it)
        # index into histogram at residual (clipped)
        idx = np.clip(residual, 0, 100)
        p_here = prob[idx]
        # also small neighborhood smoothing
        idx_lo = np.clip(idx - 1, 0, 100)
        idx_hi = np.clip(idx + 1, 0, 100)
        bonus = 25.0 * (p_here + 0.5 * (prob[idx_lo] + prob[idx_hi]))
        score = -residual.astype(np.float64) + bonus

    # record this item
    _state["hist"][item] += 1.0

    return score
# EVOLVE-BLOCK-END

