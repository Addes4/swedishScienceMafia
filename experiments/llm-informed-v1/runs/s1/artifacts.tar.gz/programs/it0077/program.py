# EVOLVE-BLOCK-START
"""Best fit with residual-reusability awareness (refined).

Best fit chooses the bin with the smallest remaining capacity that still fits.
Its weakness is stranding tiny residuals no future item can use.

We keep the full packing state ourselves, plus an empirical histogram of item
sizes seen so far. A residual is "reusable" if it is at least as large as a low
quantile of the item-size distribution. We rank bins by best fit but give a
bonus for keeping the leftover reusable, using a quantile-derived floor that
stays meaningful instead of collapsing to 1.
"""
import numpy as np

# --- persistent state (fresh process per instance) ---
_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def _floor():
    """Low quantile (~4th percentile) of the item sizes seen so far."""
    total = _hist.sum()
    if total < 20:
        return 1
    target = max(1, int(0.04 * total))
    c = np.cumsum(_hist)
    idx = int(np.searchsorted(c, target))
    if idx < 1:
        idx = 1
    if idx > 100:
        idx = 100
    return idx


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring (first on ties)."""
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    floor = _floor()

    residual = bins - item  # >= 0 for all bins shown
    # Best fit: smallest residual wins.
    score = -residual.astype(np.float64)

    # Bonus for keeping the leftover usable by a plausibly-small future item.
    # Strength is just under 1 so it only breaks ties within a unit of residual,
    # keeping strict best-fit ordering otherwise intact.
    usable = residual >= floor
    score += usable.astype(np.float64) * 0.9

    # Exact fill is strictly good: give it a decisive (but bounded) reward.
    score += (residual == 0).astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END
