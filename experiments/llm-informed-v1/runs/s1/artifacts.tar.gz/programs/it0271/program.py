# EVOLVE-BLOCK-START
"""Best-fit with exact-seal future-value term.

The dominant failure mode of pure best fit here is stranding bins with
residuals no future item can use.  Since sizes come from one fixed
Weibull-like distribution (mean ~40), the *value* of leaving residual r is
the empirical probability that some future item exactly equals r (perfect
seal), plus a mild preference for residuals that can still accept the next
typical item.

So the score is:
    score = -r                       # best-fit core
          + seal_weight * P(item == r)   # exact-seal future value
          + flex_weight * P(item <= r)   # still-usable flexibility
          + big_seal for r == 0
Everything is read off the running empirical histogram, so it is stationary
in expectation and does not tune to a particular instance.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None


def _init(n):
    global _n_items, _seen, _hist
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for shown bins
    r = residual.astype(np.float64)

    total = float(_seen)
    p = _hist / total                 # empirical PMF over sizes 0..100
    cdf = np.cumsum(p)                # P(item <= s)

    idx = np.clip(residual, 0, 100)
    fill_mass = p[idx]                # P(next item exactly equals r)
    fit_mass = cdf[idx]              # P(next item <= r)

    # Best-fit core: smaller residual is better.
    score = -r

    # Exact-seal future value: residual likely to be perfectly completed.
    score += 50.0 * fill_mass

    # Flexibility: residual can still accept some future item.
    score += 8.0 * fit_mass

    # Perfect seal.
    score += (residual == 0).astype(np.float64) * 60.0

    return score
# EVOLVE-BLOCK-END
