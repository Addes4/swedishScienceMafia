# EVOLVE-BLOCK-START
"""Best-fit with a penalty for leaving unusable (dead-zone) residuals.

Pure best-fit minimizes the current residual, but a residual smaller than the
smallest item we expect to see again is permanently wasted.  We track the
smallest item size observed recently and slightly penalize bins whose post-placement
residual falls in the dead zone (0, min_seen), preferring a slightly larger
residual that remains usable.  Otherwise behavior is identical to best-fit.
"""
import numpy as np

_state = {"min_seen": 100, "n": 0}


def priority(item, bins):
    st = _state
    st["n"] += 1
    # track a robust lower bound on future item sizes: the running minimum,
    # but floor it so it does not collapse to 1 too quickly.
    if item < st["min_seen"]:
        st["min_seen"] = item
    # dead-zone threshold: residual below this is (nearly) unusable forever.
    dead = float(st["min_seen"])

    residual = bins - item  # remaining capacity after placing the item

    # Base: best-fit score (prefer smallest residual).
    score = -residual.astype(np.float64)

    # Penalty: if residual is positive but below the dead-zone threshold,
    # it is likely wasted; subtract a penalty proportional to how unusable it is.
    in_dead = (residual > 0) & (residual < dead)
    score -= in_dead * (dead - residual) * 0.5

    return score
# EVOLVE-BLOCK-END
