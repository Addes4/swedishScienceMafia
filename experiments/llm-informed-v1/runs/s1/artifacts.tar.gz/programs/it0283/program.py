# EVOLVE-BLOCK-START
"""Best-fit core plus a light "recently used bin" consolidation bonus.

Items come from a fixed Weibull-like distribution (mean ~40).  Pure best fit
is a strong baseline but tends to open many bins that later sit with small,
unusable residuals.  Empirically, on this distribution, biasing the choice
slightly toward bins that were touched recently (i.e., keeping tight
packings "hot") reduces fragmentation without losing the fine-grained
fit quality of best fit.

We keep the exact best-fit core score = -residual and add a small bounded
term based on how recently each bin was last used.  Recency is tracked with a
monotone use counter; bins never used have age 0.  The bonus is scaled much
smaller than the residual differences so best fit still dominates except in
near-ties, where consolidation wins.
"""
import numpy as np

_n_items = None
_last_used = None
_tick = 0
_recency = None


def _init(n):
    global _n_items, _last_used, _tick, _recency
    _n_items = n
    _last_used = np.zeros(n, dtype=np.int64)
    _recency = np.zeros(n, dtype=np.float64)
    _tick = 0


def priority(item, bins):
    global _tick

    n = len(bins)
    if _n_items is None or _n_items != n or _last_used is None or len(_last_used) != n:
        _init(n)

    _tick += 1

    residual = bins - item  # >= 0 for shown bins

    r = residual.astype(np.float64)

    # Best-fit core: prefer the tightest fitting bin.
    score = -r * 1.0

    # Perfect seal: strongly reward filling a bin exactly.
    score += (residual == 0).astype(np.float64) * 5.0

    # Recency consolidation: tiny bounded bonus for recently used bins.
    # _last_used[k] is the tick of the last item placed into bin k (0 if never).
    # We want to reward bins used recently, so compute age = _tick - _last_used.
    # For never-used bins age is large; give them no bonus but also no penalty,
    # so empty bins (residual 100) remain available.
    if _tick > 1:
        lu = _last_used
        rec = np.where(lu > 0, 1.0 / (1.0 + (_tick - lu)), 0.0)
    else:
        rec = np.zeros(n, dtype=np.float64)

    # Only the shown bins get scored; recency of shown bins is what matters.
    score += rec * 0.25

    return score
# EVOLVE-BLOCK-END

