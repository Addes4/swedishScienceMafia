# EVOLVE-BLOCK-START
"""Best-fit with exact-seal probability.

Core: classic best fit, score = -residual (smallest residual wins).

Improvement: the residual left behind matters mainly through whether it can
be exactly consumed later.  Sizes are drawn i.i.d. from a fixed distribution,
so we can estimate, from the items seen so far, the probability that some
future item (or pair) exactly fills a residual r.  Rewarding residuals that
are likely to be sealed exactly encourages packing that avoids dead space,
without brittle hand-tuned thresholds.

Only the seen-item histogram is used; no future items are peeked at.
"""
import numpy as np

_n = None
_hist = None
_seen = 0
_px = None          # histogram normalized (prob mass)
_pair = None        # distribution of sums of two items (approx)
_dirty = True


def _init(n):
    global _n, _hist, _seen, _px, _pair, _dirty
    _n = n
    _hist = np.zeros(101, dtype=np.float64)
    _seen = 0
    _px = None
    _pair = None
    _dirty = True


def _rebuild():
    global _px, _pair, _dirty
    if _seen <= 0:
        _px = np.zeros(101)
        _pair = np.zeros(201)
        _dirty = False
        return
    px = _hist / _hist.sum()
    _px = px
    # distribution of a single item
    single = np.zeros(201)
    single[1:101] = px[1:]
    # distribution of sum of two independent items (convolution)
    pair = np.convolve(single[1:101], single[1:101])
    _pair = pair  # index k -> prob that two items sum to k+2 (k = sum-2)
    _dirty = False


def priority(item, bins):
    global _seen, _dirty

    n = len(bins)
    if _n is None or _n != n:
        _init(n)

    _seen += 1
    # histogram over sizes 1..100 (index 0 unused)
    if 1 <= item <= 100:
        _hist[item] += 1
    _dirty = True

    # rebuild distributions periodically to bound cost
    if _px is None or (_seen % 25 == 1):
        _rebuild()

    residual = bins - item  # >= 0 for shown bins
    r = residual.astype(np.float64)
    idx = np.clip(residual, 0, 100)

    # best-fit core
    score = -r

    # exact-seal probability for a single future item
    p_single = _px[idx]
    # exact-seal probability for a pair of future items summing to r
    pair = _pair
    p_pair = np.where((residual >= 2) & (residual <= 200),
                      pair[np.clip(residual, 2, 200) - 2],
                      0.0)

    # reward likely exact seals; single-item seal is strongest
    score += p_single * 600.0
    score += p_pair * 120.0

    # exact seal now (residual 0) is best
    score += (residual == 0).astype(np.float64) * 40.0

    return score
# EVOLVE-BLOCK-END

