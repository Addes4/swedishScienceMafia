# EVOLVE-BLOCK-START
"""Best-fit with distribution-aware expected-waste scoring.

Items are drawn i.i.d. from a fixed distribution (mean ~40).  Pure best fit
is a strong baseline but strands a few tiny residuals that no future item can
use.  Instead of many hand-tuned bonuses, we score each candidate bin by how
"reusable" its resulting residual is, using the empirical item histogram.

For a resulting residual r we look one step ahead: for each possible future
item size w that fits (w <= r), the leftover r - w is itself judged by the
fraction of items that fit it (cumulative histogram).  A residual is good if
its one-step successors are still flexible (can accept typical future items)
or are exactly sealed (residual 0).  Best-fit is kept as a mild tie-breaker.
"""
import numpy as np

_n_items = None
_seen = 0
_hist = None
_sum = 0
_cum = None


def _init(n):
    global _n_items, _seen, _hist, _sum, _cum
    _n_items = n
    _seen = 0
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _cum = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen, _sum

    n = len(bins)
    if _n_items is None or _n_items != n or _hist is None:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins
    idx = np.clip(residual, 0, 100)
    r = residual.astype(np.float64)

    total = max(_seen - 1, 1)
    # Empirical CDF of item sizes: fraction of items <= s.
    _cum[:] = np.cumsum(_hist) / total
    fit_mass = _cum[idx]                     # P(future item fits residual)
    fill_mass = _hist[idx].astype(np.float64) / total  # P(exact fill)

    # Expected one-step reusability: weight each possible chipping size w by
    # its probability and by the flexibility of the leftover.  We approximate
    # this cheaply using cumulative mass of items up to r and the typical
    # leftover flexibility.  Define a "utility" per residual in [0,1].
    # residual 0 => perfect (already sealed): best.
    sealed = (residual == 0).astype(np.float64)

    # probability that some future item can still fit and leave a usable bin
    # (a conservative proxy: fraction of items that fit, capped).
    reuse = fit_mass

    # one-step: if residual r can be exactly hit by a frequent size, great.
    fill = fill_mass

    # Best-fit core (mild): prefer smaller residual to pack tightly.
    score = -r * 1.0

    # Strong reward for sealed bins.
    score += sealed * 60.0

    # Reward residuals likely to be exactly sealed by a future item.
    score += fill * 400.0

    # Reward residuals that keep future flexibility (slack utility).
    score += reuse * 20.0

    # Penalize residuals so small that almost no future item fits them and
    # they cannot be sealed: they are wasted capacity.
    small = ((residual > 0) & (fit_mass < 0.05)).astype(np.float64)
    score -= small * 30.0

    # Mild nudge toward residuals that can hold a typical future item.
    if _seen > 1:
        mean = _sum / _seen
        near_mean = np.abs(r - mean)
        score += np.exp(-(near_mean / (0.5 * mean + 1.0)) ** 2) * 3.0

    return score
# EVOLVE-BLOCK-END
