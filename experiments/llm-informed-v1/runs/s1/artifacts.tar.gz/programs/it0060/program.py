# EVOLVE-BLOCK-START
"""Best fit with dead-space avoidance.

Best fit (smallest residual that still fits) is near-optimal here. Its weakness is
stranding tiny residuals no future item can ever use. We keep the observed minimum
item size; a residual below that minimum is provably dead. We rank by best fit but
apply a penalty to any post-placement residual that is provably unusable (residual > 0
and residual < min item seen), scaled small so it only breaks near-ties.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_min_seen = 101
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _min_seen, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _min_seen = 101
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen, _min_seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    if item < _min_seen:
        _min_seen = item
    _hist[item] += 1

    if _min_seen <= 100:
        floor = _min_seen
    else:
        floor = 1

    residual = bins - item  # >= 0
    score = -residual.astype(np.float64)

    # Penalize residuals that are provably dead: positive but smaller than any item
    # we have ever seen (so no future item can fill them). Small scale keeps best-fit
    # ordering dominant; this only breaks near-ties.
    dead = (residual > 0) & (residual < floor)
    score -= dead.astype(np.float64) * 0.5

    # Slight preference for exact fills.
    score += (residual == 0).astype(np.float64) * 0.25

    return score
# EVOLVE-BLOCK-END
