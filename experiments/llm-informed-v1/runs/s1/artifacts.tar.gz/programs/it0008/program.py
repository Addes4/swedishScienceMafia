# EVOLVE-BLOCK-START
"""Best fit, but reserve empty bins for larger items to reduce early fragmentation."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tightest fit, but penalize opening a fresh (empty) bin
    unless the incoming item is large enough to justify it."""
    leftover = bins - item
    # Base score: best fit (tighter leftover => higher score).
    score = -leftover.astype(np.float64)
    # Penalize using a completely empty bin for small/medium items, so fresh
    # bins are preserved for large items that would otherwise fragment.
    if item < 50:
        score = np.where(bins == 100, score - 1000.0, score)
    return score
# EVOLVE-BLOCK-END
