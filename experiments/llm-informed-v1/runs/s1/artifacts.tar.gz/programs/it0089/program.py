# EVOLVE-BLOCK-START
"""Best fit with empirical-quantile residual shaping.

Best fit remains the primary rule. The only add-on is a tie-break that
discounts residuals that are too small to be useful to future items but
too large to ignore: residuals below the 10th percentile of observed sizes
tend to strand unusable space, while large residuals stay fillable. Exact
fills are always strictly best.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    q10 = _quantile(0.10)
    q90 = _quantile(0.90)

    residual = bins - item  # >= 0
    r = residual.astype(np.float64)

    # Primary: best fit (smallest residual wins)
    score = -r

    # Exact fill: strictly best
    score += (residual == 0).astype(np.float64) * 200.0

    # Large residual that can still accept a big future item: rewarded
    big = residual >= q90
    score += big.astype(np.float64) * 2.0

    # Dead residual: nonzero but too small for typical small items
    dead = (residual > 0) & (residual < q10)
    score -= dead.astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END
