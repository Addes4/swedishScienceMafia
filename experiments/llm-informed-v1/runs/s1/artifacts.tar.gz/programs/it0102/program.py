# EVOLVE-BLOCK-START
"""Balanced placement with empirical viability bands.

Best fit tends to strand tiny residuals; worst fit wastes capacity.  This rule
scores each candidate bin by its post-placement residual, with extra credit when
the residual lands in a band that the empirical size distribution says is still
useful (>= a low quantile, so a typical small item can still fill it), and a
strong bonus for exact fills.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_bin_count = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _bin_count
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _bin_count = 0


def _quantile(q):
    total = _seen
    if total <= 0:
        return 1
    target = q * total
    cum = 0
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            return s
    return 100


def priority(item, bins):
    global _seen, _bin_count

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in
    score = -residual.astype(np.float64)

    # Empirical small-item quantiles: residuals below the low quantile are
    # likely to be stranded, so we de-prioritize leaving such residuals.
    q05 = _quantile(0.05)
    q25 = _quantile(0.25)

    # Tier 1: residual still large enough for a typical small item.
    usable = (residual >= q05) & (residual > 0)
    score += usable.astype(np.float64) * 20.0

    # Tier 2: residual in the "just-right" band (small but still usable),
    # which keeps bins dense without stranding them.
    band = (residual >= q05) & (residual <= q25) & (residual > 0)
    score += band.astype(np.float64) * 20.0

    # Exact fills are always good.
    score += (residual == 0).astype(np.float64) * 60.0

    return score
# EVOLVE-BLOCK-END

