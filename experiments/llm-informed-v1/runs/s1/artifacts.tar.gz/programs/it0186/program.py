# EVOLVE-BLOCK-START
"""Competitive best-fit with future-fill viability and endgame sealing.

Sizes come from a fixed Weibull-like distribution (mean ~40). Pure best fit
leaves tiny unusable residuals and never rebalances toward bins that can still
accept typical items.  This rule keeps best-fit as the core (score = -residual)
but:
  * penalizes residuals below the empirical median item size,
  * rewards residuals with high empirical histogram mass (likely exact fills),
  * strongly rewards perfect seals (residual 0),
  * nudges residuals toward multiples of the running mean,
  * during the endgame (few items left) boosts residuals whose size is a
    common item size in the empirical histogram, to favor sealing.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_sum = 0
_remaining_sum = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _sum, _remaining_sum
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _sum = 0
    _remaining_sum = 0


def priority(item, bins):
    global _seen, _sum, _remaining_sum

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)
    mean = _sum / _seen

    # Empirical median item size (approx) via cumulative histogram.
    target = 0.5 * total
    cum = 0.0
    median = 1
    for s in range(1, 101):
        cum += _hist[s]
        if cum >= target:
            median = s
            break

    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    cum_hist = np.cumsum(_hist).astype(np.float64) / total
    fit_mass = cum_hist[idx]

    # Best-fit core.
    score = -residual.astype(np.float64) * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 60.0

    # Penalize residuals too small to accept a typical (median) item,
    # but only if they are not a perfect seal.
    too_small = ((residual > 0) & (residual < median)).astype(np.float64)
    score -= too_small * 35.0

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 30.0

    # Reward residuals that admit at least some future item (flexibility).
    score += fit_mass * 8.0

    # Nudge residuals toward multiples of the running mean so that future
    # items can stack into them.
    if mean > 0:
        mult = np.round(residual.astype(np.float64) / mean)
        mult = np.maximum(mult, 0.0)
        waste = np.abs(residual.astype(np.float64) - mult * mean)
        score -= waste * 0.15

    # Endgame sealing: when few items remain relative to what the residual
    # mass could hold, boost residuals that are common item sizes (so they
    # are likely to be exactly filled by a late item).
    if mean > 0:
        remaining_items = max(_n_items - _seen, 0)
        bins_needed_est = _remaining_sum / mean if mean > 0 else 0.0
        # scarcity in [0, 1]: 1 when very few items left vs. open bins
        open_bins = float(np.count_nonzero(bins < 100) + 1)
        scarcity = 1.0 - min(remaining_items / max(open_bins, 1.0), 1.0)
        if scarcity > 0:
            score += fill_mass * 40.0 * scarcity

    _remaining_sum = _sum

    return score
# EVOLVE-BLOCK-END
