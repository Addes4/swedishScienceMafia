# EVOLVE-BLOCK-START
"""Best fit with data-driven residual reusability.

Pure best fit is near-optimal under a near-continuous size distribution, but it
strands residuals no plausible future item can fill. Instead of a hand-tuned
quantile threshold, we estimate for each candidate post-placement residual how
likely it is to be filled well by future items, using a smoothed online
histogram of the item sizes seen so far. The score is best-fit (minimize
residual) plus a small data-driven bonus for residuals that future items are
likely to consume.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.float64)


def _reuse_value(res):
    """Expected fraction of a residual 'res' that future items can reclaim.

    Uses the smoothed empirical size histogram accumulated so far. A residual is
    valuable if some commonly observed size matches (or nearly matches) it, so
    the next similar item can be packed snugly. We compute, for each residual,
    the mass of observed sizes near that residual.
    """
    total = _seen
    if total <= 0:
        return np.zeros_like(res, dtype=np.float64)

    # smoothed histogram: spread each observed size over a small window
    hist = _hist
    window = np.convolve(hist, np.ones(5, dtype=np.float64), mode="same")
    window = window / max(window.sum(), 1.0)

    r = np.clip(res, 0, 100).astype(np.int64)
    # value = probability mass of sizes that would fill this residual snugly
    # i.e. sizes s with r - s small; approximate by mass at s == r
    return window[r]


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1.0

    residual = bins - item  # >= 0
    score = -residual.astype(np.float64)

    # data-driven bonus: reward residuals a future item is likely to fill snugly
    reuse = _reuse_value(residual)
    score += reuse * 40.0

    # exact fills are always good
    score += (residual == 0).astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
