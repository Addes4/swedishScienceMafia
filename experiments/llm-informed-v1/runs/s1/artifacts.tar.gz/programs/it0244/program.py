# EVOLVE-BLOCK-START
"""Competitive best-fit with future-fill viability.

Pure best fit leaves a few bins with tiny residuals that no future item can
ever use.  Since sizes come from a fixed Weibull-like distribution (mean ~40),
a residual is useful only if some future item fits it, and it is more valuable
if future items are likely to exactly fill it or pair with it.

This rule keeps best-fit as the core (score = -residual) but:
  * gives a strong reward for residuals that equal 0 (perfect seal),
  * rewards residuals whose size has high empirical histogram mass,
  * rewards residuals that admit at least some future item (flexibility),
  * rewards residuals that can be exactly completed by a pair of common items.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None
_pair = None
_sum = 0
_pair_dirty = 0


def _init(n):
    global _n_items, _seen, _residuals, _hist, _pair, _sum, _pair_dirty
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)
    _pair = None
    _sum = 0
    _pair_dirty = 0


def _recompute_pair():
    global _pair, _pair_dirty
    h = _hist.astype(np.float64)
    p = np.convolve(h, h)[:101]
    tot = h.sum()
    if tot > 0:
        p = p / tot
    _pair = p
    _pair_dirty = 0


def priority(item, bins):
    global _seen, _sum, _pair_dirty

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1
    _sum += item
    _pair_dirty += 1

    residual = bins - item  # >= 0 for shown bins

    total = max(_seen - 1, 1)

    idx = np.clip(residual, 0, 100)
    fill_mass = _hist[idx].astype(np.float64) / total
    cum_hist = np.cumsum(_hist).astype(np.float64) / total
    fit_mass = cum_hist[idx]

    # Pair-completion mass, refreshed periodically to save time.
    if _pair is None or _pair_dirty >= 50:
        _recompute_pair()
    pair_mass = _pair[idx]

    # Best-fit core.
    score = -residual.astype(np.float64) * 1.0

    # Perfect seal: strong reward.
    score += (residual == 0).astype(np.float64) * 60.0

    # Reward residuals that a future item can exactly fill.
    score += fill_mass * 30.0

    # Reward residuals that admit at least some future item (flexibility).
    score += fit_mass * 8.0

    # Reward residuals that can be exactly completed by two typical items.
    score += pair_mass * 6.0

    return score
# EVOLVE-BLOCK-END
