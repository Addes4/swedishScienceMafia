# EVOLVE-BLOCK-START
"""Best fit with exact-fit preference, using trackable packing state."""
import numpy as np


def priority(item, bins):
    """Highest score wins; ties to first bin.

    item: integer size 1..100.
    bins: remaining capacities of fitting bins (unused ones have capacity 100).
    """
    resid = bins - item
    # Prefer exact fills; otherwise best fit (smallest non-negative residual).
    # Exactly filled bins (resid == 0) get the top score.
    return -resid - 1000.0 * (resid == 0)
# EVOLVE-BLOCK-END
