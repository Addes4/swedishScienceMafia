# EVOLVE-BLOCK-START
"""Best fit with a mild histogram-based residual bonus."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_SEEN = 0
_N = 0


def priority(item, bins):
    global _SEEN, _N
    if _SEEN == 0:
        _N = len(bins)
    _SEEN += 1

    # Update running histogram of item sizes seen so far (previous items only).
    # Note: item itself is current, so we score using the histogram before including it.
    hist = _HIST
    # Normalize lazily
    total = hist.sum()

    res = bins - item  # leftover after placing

    # Base: tightest fit (negative leftover, larger = better)
    score = -res.astype(np.float64)

    if total > 0:
        p = hist / total
        # bonus for leftovers that are plausible future item sizes, weighted by frequency
        # res in 0..100
        r = np.clip(res, 0, 100)
        bonus = p[r]
        # exact fill gets extra
        bonus = np.where(res == 0, bonus + 0.5, bonus)
        score = score + 2.0 * bonus

    # record this item
    if 1 <= item <= 100:
        hist[item] += 1.0

    return score
# EVOLVE-BLOCK-END

