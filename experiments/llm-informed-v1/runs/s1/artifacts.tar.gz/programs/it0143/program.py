# EVOLVE-BLOCK-START
"""Best-fit core plus a strong exact-fill reward.

Pure best fit (smallest residual) is a very strong baseline for this
distribution.  The main improvement is to reward the case where a candidate
bin's resulting residual exactly matches a *frequent* item size, because such
a residual is much more likely to be closed later.  We keep the best-fit
core dominant (so behavior degrades gracefully to best fit) and add a
bounded exact-fill bonus driven by the empirical frequency of the residual
size.
"""
import numpy as np

_n_items = None
_seen = 0
_residuals = None
_hist = None


def _init(n):
    global _n_items, _seen, _residuals, _hist
    _n_items = n
    _seen = 0
    _residuals = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    global _seen

    n = len(bins)
    if _n_items is None or _n_items != n or _residuals is None or len(_residuals) != n:
        _init(n)

    _seen += 1
    _hist[item] += 1

    residual = bins - item  # >= 0 for bins the item fits in
    r = residual.astype(np.float64)

    # Best-fit core: prefer the smallest remaining residual.
    score = -r

    # Exact-fill reward: a residual that matches a frequently seen size is
    # likely to be closed by a future item.
    total = max(_seen, 1)
    idx = np.clip(residual, 0, 100)
    exact_mass = _hist[idx].astype(np.float64) / total

    # Bounded, best-fit-compatible bonus.  residual 0 (perfect fill) is
    # rewarded the most.
    score += (residual == 0).astype(np.float64) * 30.0
    score += exact_mass * 20.0

    return score
# EVOLVE-BLOCK-END
