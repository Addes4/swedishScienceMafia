# EVOLVE-BLOCK-START
"""Best fit with a small-item consolidation bias.

Pure best fit minimizes the residual after placement. For this Weibull-like
distribution (mean ~40), many items are small, and greedily filling small gaps
with small items tends to fragment space that larger items could use better.
We keep best fit as the primary key, but break close calls to prefer used bins
and to avoid leaving tiny unusable slivers.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    residual = bins - item  # >= 0 for all shown bins (they all fit)

    if item >= 40:
        # Large/medium items: strict best fit.
        return -residual.astype(np.float64)

    # Small items: best fit, but strongly penalize leaving a tiny residual
    # (a sliver that a future item is unlikely to use) and mildly prefer
    # already-used bins (residual < 100) over fresh empty ones.
    score = -residual.astype(np.float64)
    # Penalize residuals that are too small to plausibly be reused (< 15).
    small = residual < 15
    score[small] -= 30.0 * (15 - residual[small])
    # Slightly discourage opening brand-new bins for small items.
    fresh = bins == 100
    score[fresh] -= 3.0
    return score
# EVOLVE-BLOCK-END
