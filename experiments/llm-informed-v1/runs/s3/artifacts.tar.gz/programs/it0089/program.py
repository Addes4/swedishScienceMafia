# EVOLVE-BLOCK-START
"""Best fit, with exact completion (residual 0) preferred on near-ties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit -> most negative residual is best.
    score = -residual.astype(np.float64)
    # Tiny bonus for exact completion (residual == 0), enough to break near-ties
    # toward closing bins exactly, but too small to overwhelm a strictly better fit.
    score += 1e-3 * (residual == 0)
    return score
# EVOLVE-BLOCK-END

