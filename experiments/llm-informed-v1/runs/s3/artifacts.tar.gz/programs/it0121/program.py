# EVOLVE-BLOCK-START
"""Best fit with empirical future-fill lookahead and complementary pairing."""
import numpy as np

_state = {
    "n": 0.0,
    "N": 0.0,                                   # total items in this instance
    "hist": np.zeros(101, dtype=np.float64),    # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    if st["N"] == 0.0:
        st["N"] = float(len(bins))
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]
    remaining = st["N"] - total
    if remaining < 0.0:
        remaining = 0.0

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Lookahead: reward residuals likely to be exactly filled later. Weight the
    # empirical (Laplace-smoothed) probability of a future item equal to the
    # residual, scaled by how many items remain so the term fades near the end
    # where no future item can complete a bin.
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    if valid.any():
        idx = post_idx[valid]
        prob = (hist[idx] + 1.0) / (total + 100.0)
        # Expected number of future exact matches to this residual.
        exp_fill = prob * remaining
        score[valid] += exp_fill * 250.0

    # Complementary pair: residual equal to current item can close exactly
    # with a repeat of this size; also completing a bin whose residual now
    # equals the item is a planned perfect pair.
    score += (post == item).astype(np.float64) * 400.0
    score += (bins == item).astype(np.float64) * 400.0

    # Anti-orphan guard for tiny non-zero residuals (1..4): rarely fillable.
    small_orphan = (post >= 1) & (post <= 4)
    score -= small_orphan.astype(np.float64) * 3.0

    return score
# EVOLVE-BLOCK-END
