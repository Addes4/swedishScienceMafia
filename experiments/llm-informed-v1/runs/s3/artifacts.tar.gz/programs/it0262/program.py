# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference plus multi-item reachability lookahead
computed by a small DP over the empirical item-size distribution."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
}

_DECAY = 0.999


def priority(item, bins):
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))
    post = bins - item
    post_idx = post.astype(np.int64)

    # Base: best fit -> smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)
    p = prob[1:101].copy()

    valid = (post_idx >= 1) & (post_idx <= 100)

    # Single-item exact-fill probability.
    p_single = np.zeros_like(score)
    if valid.any():
        p_single[valid] = p[post_idx[valid] - 1]

    remaining = max(n_items - st["n"], 0.0)
    score += p_single * 300.0

    # Reward closing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0

    # Single-item expected future fill count.
    score += (remaining * p_single) * 60.0

    # Multi-item reachability: probability that the residual can be exactly
    # filled by some subset of future items (bounded subset-sum DP).
    # dp[r] = probability that residual r is achievable by a subset sum of
    # up to a few items drawn from the empirical distribution.
    K = 8  # max items considered in a fill combination
    reach = np.zeros(101, dtype=np.float64)
    reach[0] = 1.0
    dp = np.zeros(101, dtype=np.float64)
    dp[0] = 1.0
    for _ in range(K):
        new = np.zeros(101, dtype=np.float64)
        for s in range(101):
            v = dp[s]
            if v > 1e-12:
                # convolve with p but cap sums at 100
                hi = 100 - s
                new[s + 1:s + 1 + hi] += v * p[:hi]
        dp = new
        reach += dp
    # reach[r] = expected number of distinct subset-sums equal to r up to K items
    # (approximate reachability). Clip to [0,1] for a probability-like value.
    reach = np.clip(reach, 0.0, 1.0)

    p_multi = np.zeros_like(score)
    if valid.any():
        p_multi[valid] = reach[post_idx[valid]]

    # Weight multi-item reachability by remaining items; only matters early.
    multi_weight = min(remaining / max(n_items, 1.0), 1.0)
    score += p_multi * multi_weight * 500.0

    return score
# EVOLVE-BLOCK-END
