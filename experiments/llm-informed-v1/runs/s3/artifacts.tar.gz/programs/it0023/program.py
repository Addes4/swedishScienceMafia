# EVOLVE-BLOCK-START
"""Best fit with a reusable-residual preference inside a tolerance band."""
import numpy as np

_state = {"n": None, "sizes": []}


def priority(item, bins):
    if _state["n"] is None:
        _state["n"] = len(bins)
    _state["sizes"].append(item)

    residual = bins - item  # post-placement residual for each candidate bin

    # minimum residual (tightest fit)
    rmin = residual.min()
    # tolerance band: consider bins within a small slack of the tightest fit
    slack = max(1, item // 4)
    mask = residual <= rmin + slack

    # score: base is negative residual (tighter better), plus a bonus when the
    # resulting residual is a "reusable" capacity likely to be filled exactly.
    # We derive reusable targets from observed item sizes (common mod-100 residues)
    # and from half the capacity.
    sizes = _state["sizes"]
    # build a small set of candidate reusable targets from recent item sizes
    targets = set()
    for s in sizes[-64:]:
        targets.add(s)
    targets.add(50)
    targets.add(25)
    targets.add(33)
    targets.add(20)

    score = -residual.astype(np.float64)
    # only apply bonus where inside band; elsewhere heavily deprioritize
    big_penalty = (residual - rmin)  # grows with looser fit
    score -= np.where(mask, 0.0, big_penalty * 0.0 + 1e6 * (residual - rmin - slack) + 0.5)

    # bonus: residual close to a reusable target is good (leaves room for an exact fill)
    tvals = np.array(sorted(targets), dtype=np.float64)
    # distance from residual to nearest target
    d = np.abs(residual[:, None] - tvals[None, :]).min(axis=1)
    bonus = np.where(mask & (residual > 0), 0.25 - d * 0.02, 0.0)
    score += bonus

    return score
# EVOLVE-BLOCK-END
