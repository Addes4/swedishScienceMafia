# EVOLVE-BLOCK-START
"""Best fit with a small state-aware tie-break that favors residuals usable by common item sizes."""
import numpy as np

_counts = np.zeros(101, dtype=np.int64)
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _seen
    _counts[item] += 1
    _seen += 1

    # Primary best-fit ordering: tightest residual after placement.
    residual = bins - item
    base = -residual.astype(np.float64)

    # Find the most common item sizes seen so far (small set of useful residuals).
    common = np.argsort(_counts)[-4:]
    # Bonus for bins whose post-placement residual equals a common item size.
    bonus = np.zeros_like(base)
    for c in common:
        if _counts[c] > 0:
            bonus += (residual == c) * (0.05 * (_counts[c] / _seen))

    return base + bonus
# EVOLVE-BLOCK-END
