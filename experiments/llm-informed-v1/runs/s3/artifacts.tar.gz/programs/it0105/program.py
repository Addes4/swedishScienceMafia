# EVOLVE-BLOCK-START
"""Best fit with a learned residual-value lookahead and exact-fill preference."""
import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),
    "n": 0.0,
}


def priority(item, bins):
    """Rank bins: prefer tight fits, exact fills, and residuals likely to be reused.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of bins the item fits in, in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item
    postf = post.astype(np.float64)

    # Primary signal: best fit (smallest residual) dominates.
    score = -postf

    # Exact fill is always the best possible outcome.
    score += (post == 0).astype(np.float64) * 5000.0

    # Residual-value lookahead: prefer residuals that are common item sizes,
    # so a future item can close the bin exactly.  Scaled small so it only
    # breaks ties among near-equal best fits.
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    freq = np.zeros_like(score)
    idx = post_idx[valid]
    p = hist[idx] / total
    # value of a residual = probability it gets matched exactly soon
    freq[valid] = p * (1.0 - p)  # peaks at p ~ 0.5, avoids over-trusting rare sizes
    score += freq * 400.0

    # Completing a bin whose residual equals the item (planned pair): strong.
    score += (bins == item).astype(np.float64) * 800.0

    return score
# EVOLVE-BLOCK-END
