# EVOLVE-BLOCK-START
"""Best fit with empirical future-fill lookahead and complementary pairing."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Lookahead: probability that a future single item exactly equals the
    # residual, estimated from the running histogram (smoothed with +1).
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        prob = (hist[idx] + 1.0) / (total + 100.0)
        p_fill[valid] = prob
    score += p_fill * 300.0

    # Pairing bonus: residual equals the item size -> a future identical
    # item can close it exactly.
    score += (post == item).astype(np.float64) * 400.0

    # Reward completing a bin whose residual before placement equals item.
    score += (bins == item).astype(np.float64) * 400.0

    # Robust orphan guard: penalize small residuals (1..4) that are hard to
    # fill exactly, scaled by their (low) empirical fill probability so the
    # penalty never overrides a genuinely good exact-fill chance.
    small_orphan = (post >= 1) & (post <= 4)
    if small_orphan.any():
        so_idx = post[small_orphan].astype(np.int64)
        so_prob = (hist[so_idx] + 1.0) / (total + 100.0)
        score[small_orphan] -= (1.0 - so_prob * 60.0) * 4.0

    return score
# EVOLVE-BLOCK-END

