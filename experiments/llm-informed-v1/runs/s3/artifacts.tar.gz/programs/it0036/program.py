# EVOLVE-BLOCK-START
"""Best fit, with a small-item guard to avoid leaving tiny unusable gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer the tightest residual (smallest bins-item).
    # Guard: for small items, if a placement leaves a very tiny residual
    # (a gap too small to hold almost anything useful), slightly deprioritize it
    # so the small item lands in a bin leaving a more reusable residual.
    residual_after = bins - item
    score = -residual_after.astype(np.float64)
    small = residual_after < 5
    # penalize creating tiny slivers, but never below leaving 0 (perfect fit is great)
    tiny = small & (residual_after > 0)
    score[tiny] -= 2.0
    return score
# EVOLVE-BLOCK-END
