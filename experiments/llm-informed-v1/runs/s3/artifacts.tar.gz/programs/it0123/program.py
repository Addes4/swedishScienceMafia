# EVOLVE-BLOCK-START
"""Best fit with empirical future-fill lookahead and complementary pairing."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and future-usability of residual.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Lookahead: probability that a future single item exactly equals the
    # residual, estimated from the running histogram (smoothed with +1).
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        prob = (hist[idx] + 1.0) / (total + 100.0)
        p_fill[valid] = prob
    score += p_fill * 300.0

    # Future usability: expected chance a future item still fits in the
    # residual (i.e. residual is not too small to be used) and its expected
    # fill fraction. This rewards residuals that can still absorb typical
    # items, discouraging hard-to-complete tiny orphans beyond pure best-fit.
    if valid.any():
        # distribution over sizes 1..100
        dist = (hist[1:101] + 1.0)
        dist /= dist.sum()
        sizes = np.arange(1, 101, dtype=np.float64)
        fill_frac = np.zeros_like(score)
        idx = post_idx[valid]
        # For each valid residual r, expected fraction (sum of min(size,r)*p)
        # divided by r, weighted by whether any item fits.
        # Compute per-residual using cumulative mass for efficiency.
        cum_p = np.cumsum(dist)          # cum_p[k-1] = P(size<=k)
        cum_ps = np.cumsum(dist * sizes)  # E[size * 1{size<=k}]
        r = idx.astype(np.float64)
        fits_mass = cum_p[idx - 1]                    # P(size <= r)
        exp_fill = cum_ps[idx - 1] + r * (1.0 - fits_mass)  # min(size,r) sum
        fill_frac[valid] = (exp_fill / r) * fits_mass
        score += fill_frac * 5.0

    # Pairing bonus: if the residual after placement equals the item size,
    # a future identical item can close it exactly.
    score += (post == item).astype(np.float64) * 400.0

    # Reward completing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0

    # Small anti-orphan guard for tiny non-zero residuals (1..4).
    small_orphan = (post >= 1) & (post <= 4)
    score -= small_orphan.astype(np.float64) * 3.0

    return score
# EVOLVE-BLOCK-END
