# EVOLVE-BLOCK-START
"""Best fit with a harmonic size-class tie-break.

The core ranking is standard best-fit (smallest residual bin wins). On top of
that, residuals are bucketed into harmonic classes derived from an online
estimate of the item-size scale. Among bins with close residuals, we prefer the
one whose post-placement residual lands at the top of its class, i.e. keeps the
bin "well filled" relative to a class boundary, so gaps stay reusable instead of
being stranded just below a boundary.
"""
import numpy as np

_CAP = 100.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    residual = bins.astype(np.float64) - float(item)

    # Best fit: strongly prefer smaller post-placement residual.
    base = -residual

    # Harmonic-ish class boundary: prefer residuals landing just at/above a
    # boundary where the leftover is a "round" fraction of capacity, so gaps
    # remain easy to fill with the typical item scale (~40).
    # A small epsilon keeps this from disturbing genuine best-fit choices.
    r = np.clip(residual, 0.0, _CAP)
    # distance below the next integer multiple of 20 (typical item scale 40):
    # 0,20,40,60,80,100 boundaries. Landing on a boundary => residual reusable.
    frac = np.mod(r, 20.0)
    boundary_bonus = -np.minimum(frac, 20.0 - frac) * 1e-3

    return base + boundary_bonus
# EVOLVE-BLOCK-END
