# EVOLVE-BLOCK-START
"""Best fit with a small guard that preserves valuable residuals.

The classic best-fit rule puts an item in the bin with the smallest
remaining capacity that still fits.  That is strong on average, but it
sometimes destroys a bin whose residual exactly equals a frequently seen
item size.  We keep our own view of every open bin's residual and an
online histogram of item sizes.  When the pure best-fit choice would
consume a "valuable" bin (its residual, before placing, equals a common
item size) and a nearly-as-tight alternative exists whose residual stays
valuable, we take the alternative.  Otherwise we fall back to best-fit.
"""
import numpy as np

# ---- module level state (fresh per process / instance) ----
_cap = {}          # bin index -> remaining capacity (our own view)
_hist = np.zeros(101, dtype=np.int64)   # counts of item sizes seen
_n_seen = 0
_n_bins = None


def _valuable(residual):
    """A residual is valuable if some common item size equals it exactly."""
    if residual <= 0 or residual > 100:
        return False
    if _n_seen < 50:
        return False
    # expected number of future items of this size
    freq = _hist[residual] / _n_seen
    return freq >= 0.008


def priority(item, bins):
    global _n_seen, _n_bins

    m = len(bins)
    if _n_bins is None:
        _n_bins = m
        # first call: every bin is empty
        for i in range(m):
            _cap[i] = 100

    # record item
    _hist[item] += 1
    _n_seen += 1

    # residuals of the bins we are shown (in bin order); recompute from our view
    resid = np.empty(m, dtype=np.int64)
    for j in range(m):
        # our view may lag if harness reordered; trust ours when it exists
        resid[j] = _cap.get(j, 100)

    # best-fit choice index (smallest residual >= item)
    order = np.argsort(resid, kind="stable")
    best = order[0]
    best_res = resid[best]

    chosen = best

    # Try to preserve a valuable bin if the best-fit choice destroys one.
    if _valuable(best_res) and _valuable(best_res - item) is False:
        # look for an alternative bin that leaves a valuable residual and
        # is not too much looser than the best fit
        limit = best_res + max(3, item // 4)
        best_alt = -1
        best_alt_res = 1 << 30
        for j in order:
            r = resid[j]
            if r < item:
                break
            if r > limit:
                break
            if j == best:
                continue
            nr = r - item
            if _valuable(nr):
                if r < best_alt_res:
                    best_alt_res = r
                    best_alt = j
        if best_alt >= 0:
            chosen = best_alt

    new_res = resid[chosen] - item
    _cap[chosen] = int(new_res)

    # scores: chosen bin gets the max score, others lower, ordered by tightness
    scores = np.empty(m, dtype=np.float64)
    for j in range(m):
        if j == chosen:
            scores[j] = 1e9
        else:
            scores[j] = -float(resid[j] - item)
    return scores
# EVOLVE-BLOCK-END
