# EVOLVE-BLOCK-START
"""Best fit with small-item consolidation preference."""
import numpy as np


def priority(item, bins):
    """Best fit for most items, but for small items prefer bins where the
    resulting residual (r - item) can still hold another typical small item,
    consolidating smalls and reducing the number of lightly-used bins."""
    r = bins.astype(np.int64)
    if item <= 20:
        newres = r - item
        # Prefer bins whose leftover after placing can still hold a small item (>= item),
        # then tightest fit (smallest leftover), then fuller bin (smaller r).
        can_pair = (newres >= item).astype(np.int64)
        # big bonus for keeping a usable remainder; then tightest fit.
        return can_pair * 1000 + (100 - newres) - (100 - r)
    # default: best fit -> highest score = smallest leftover
    return -(r - item)
# EVOLVE-BLOCK-END

