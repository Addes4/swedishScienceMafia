# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference, empirical future-fill lookahead
scaled by the number of items left, complementary pairing, and a
pair-closure signal, with exponential forgetting of past items."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
    "closures": 0.0,                           # exact-fill placements observed
}

_DECAY = 0.999


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future fill."""
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    score = -post.astype(np.float64)

    mean_item = float((hist * np.arange(101, dtype=np.float64)).sum() / max(total, 1.0))
    if mean_item < 1.0:
        mean_item = 40.0
    small_resid = np.count_nonzero((bins > 0) & (bins < mean_item))
    frac_small = small_resid / max(len(bins), 1)

    score *= (1.0 + 3.0 * frac_small)

    exact = (post == 0)
    score += exact.astype(np.float64) * 10000.0

    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    remaining = max(n_items - st["n"], 0.0)
    exp_fill = remaining * p_fill

    # Adaptive consolidation pressure: if exact closures are rarer than the
    # smoothed distribution predicts, lean harder on fill/consolidation terms.
    n = st["n"]
    expected_closures = n * float(prob[item]) if n > 0 else 0.0
    obs_closures = st["closures"]
    if n >= 20:
        rarity = expected_closures / max(obs_closures, 1.0)
        rarity = min(max(rarity, 0.5), 4.0)
    else:
        rarity = 1.0
    st["closures"] += 1.0 if bool(exact.any()) else 0.0

    score += p_fill * 300.0 * rarity

    closing = (bins == item).astype(np.float64)
    score += closing * 400.0 * rarity

    score += exp_fill * 60.0 * rarity

    pair_prob = np.zeros(101, dtype=np.float64)
    p = prob[1:101]
    conv = np.convolve(p, p)
    pair_prob[1:101] = conv[:100]
    p_pair = np.zeros_like(score)
    if valid.any():
        p_pair[valid] = pair_prob[post_idx[valid]]

    n_pairs = remaining * max(remaining - 1.0, 0.0) * 0.5
    pair_weight = min(n_pairs / max(n_items, 1.0), 5.0)
    score += p_pair * pair_weight * 4000.0

    mode_idx = int(np.argmax(prob[1:101])) + 1
    p_mode = float(prob[mode_idx])
    score += (post_idx == mode_idx).astype(np.float64) * p_mode * 800.0 * rarity

    return score
# EVOLVE-BLOCK-END
