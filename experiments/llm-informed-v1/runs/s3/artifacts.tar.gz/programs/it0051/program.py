# EVOLVE-BLOCK-START
"""Best fit with residual-utility adjustment.

Tracks all bins' residual capacities. For each arriving item, ranks feasible bins
by how tight the fit is (best fit), but adjusts the score so that leftovers that
can be usefully reused (exactly matched by a small future item, or avoiding a dead
zone too small for any observed item) are mildly preferred. Choose the highest
score; ties go to the first bin.
"""
import numpy as np

_state = {
    "n": 0,          # items seen so far
    "total": None,   # total number of items (from first call's len(bins))
    "min_size": 101, # smallest item observed
    "counts": None,  # histogram of observed sizes (index 1..100)
}


def priority(item, bins):
    st = _state
    if st["counts"] is None:
        st["total"] = int(len(bins))
        st["counts"] = np.zeros(102, dtype=np.int64)

    st["n"] += 1
    if item < st["min_size"]:
        st["min_size"] = item
    st["counts"][item] += 1

    # residual after placing item into each shown bin
    residual_after = bins - item  # >= 0 since only feasible bins are shown

    # Base: tightest fit first (minimize residual_after) -> score = -residual_after
    score = -residual_after.astype(np.float64)

    counts = st["counts"]
    n_seen = st["n"]

    # A "dead zone" is a residual smaller than the smallest item we've seen:
    # such a bin can never take another item. Heavily penalize creating one
    # (unless the bin is exactly full, residual 0, which is ideal).
    m = st["min_size"]
    if n_seen >= 50 and m > 1:
        dead = (residual_after > 0) & (residual_after < m)
        score -= 5.0 * dead.astype(np.float64)

    # Tiny semantic nudge: prefer residuals that have historically been common
    # complements (i.e., a leftover size we've often seen items of), so it can
    # be exactly filled later. Only active for large items, where waste matters.
    if n_seen >= 200 and item >= 60:
        # frequency weight of the residual value as a future item size
        idx = residual_after.astype(np.int64)
        idx = np.clip(idx, 0, 101)
        freq = counts[idx].astype(np.float64)
        score += 0.02 * freq

    return score
# EVOLVE-BLOCK-END
