# EVOLVE-BLOCK-START
"""Best fit with a principled residual-satisfiability lookahead: reward
residuals that are likely to be exactly completed by future items (single or
pair sums), computed from the smoothed empirical item distribution."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit plus residual-completion probability.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item                    # residual after placing item here
    post_idx = post.astype(np.int64)

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 100000.0

    # Laplace-smoothed item-size distribution (probability mass on 1..100).
    prob = (hist + 1.0) / (total + 100.0)

    valid = (post_idx >= 1) & (post_idx <= 100)
    if valid.any():
        idx = post_idx[valid]

        # Probability the residual is exactly filled by one future item.
        p1 = prob[idx]

        # Probability the residual is exactly filled by a sum of two future
        # items: p2[s] = sum_{a+b=s} prob[a]*prob[b], s in 2..200.
        p2 = np.convolve(prob[1:101], prob[1:101])
        sums2 = idx + 1  # placeholder, overwritten below
        p2v = np.zeros_like(p1)
        # only residuals >= 2 can be a sum of two positive items
        big = idx >= 2
        if big.any():
            p2v[big] = p2[idx[big] - 2]

        # Combined completion probability (single item dominates).
        comp = p1 + 0.5 * p2v

        # Reward residuals that are likely completable; the larger the
        # residual's completion chance, the less likely it becomes dead waste.
        bonus = np.zeros_like(score)
        bonus[valid] = comp * 500.0
        score += bonus

    return score
# EVOLVE-BLOCK-END

