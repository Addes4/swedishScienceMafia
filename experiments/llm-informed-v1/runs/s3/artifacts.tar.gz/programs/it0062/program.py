# EVOLVE-BLOCK-START
"""Targeted best fit: minimize residual, but bias toward useful residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Primary: prefer small residual (classic best fit) -> negate.
    # Piecewise target: residual 0 is great; a residual near 40 (mean item) is
    # second best because a future average item may complete the bin.
    # Score is higher for good residuals.
    r = residual.astype(np.float64)
    # Strong bonus for exact fill
    exact = (r == 0).astype(np.float64)
    # Desirability of residual as a target for a future ~40 item:
    # closer to 40 is better, capped.
    target = -np.abs(r - 40.0) / 100.0
    score = -r / 100.0 + 0.5 * exact + 0.05 * target
    return score
# EVOLVE-BLOCK-END

