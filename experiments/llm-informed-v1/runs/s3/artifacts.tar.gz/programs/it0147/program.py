# EVOLVE-BLOCK-START
"""Best fit with empirical distribution completion-probability lookahead."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
    "csum": None,   # cached pairwise-sum distribution
    "csum_n": -1.0,
}


def priority(item, bins):
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item
    post_idx = post.astype(np.int64)

    # Base best fit: prefer smallest residual.
    score = -post.astype(np.float64)

    # Exact fill dominates.
    score += (post == 0).astype(np.float64) * 1e9

    prob = (hist + 1.0) / (total + 100.0)

    # Precompute pairwise-sum distribution of items (sums 2..200).
    if st["csum"] is None or (total - st["csum_n"]) >= 25.0:
        p = prob[1:101]
        st["csum"] = np.convolve(p, p)   # index s-2 for sum s
        st["csum_n"] = total
    p2 = st["csum"]

    valid = (post_idx >= 1) & (post_idx <= 100)
    fill1 = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        fill1[valid] = prob[idx]
    score += fill1 * 600.0

    # Two-item sum-completion probability at the residual.
    sumv = np.zeros_like(score)
    v2 = (post_idx >= 2) & (post_idx <= 200)
    if v2.any():
        sums = post_idx[v2]
        sumv[v2] = p2[sums - 2]
    score += sumv * 250.0

    # Favor residuals that are a common single item size (pairing solidity):
    # such a bin can be closed by the modal future item.
    pair = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        pair[valid] = prob[idx]
    score += pair * 200.0

    # Goodness relative to uniform baseline: reward common residuals.
    cmn = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        cmn[valid] = (prob[idx] - 0.01)
    score += cmn * 200.0

    return score
# EVOLVE-BLOCK-END

