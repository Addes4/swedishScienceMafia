# EVOLVE-BLOCK-START
"""Best fit with a learned value of the residual left behind.

The key insight: a bin's post-placement residual r is "good" if it is likely to be
exactly filled by a future item. From the observed item-size histogram we estimate
p(r) = probability the next item has size exactly r, and also the chance that the
bin gets closed within a couple of items. We combine:
  * strong best-fit term (-post)
  * exact-fill / perfect-pair bonuses
  * a learned residual value proportional to how often size (post) has been seen,
    which approximates the value of leaving that residual open.
"""
import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),
    "n": 0,
    "capacity": 100,
}


def priority(item, bins):
    st = _state
    st["n"] += 1
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # remaining capacity after placing item here

    # Primary: best fit (smallest post-placement residual is best).
    score = -post.astype(np.float64)

    # Exact fill is always ideal.
    score += (post == 0).astype(np.float64) * 1000.0

    # Perfect complementary pair: residual equals item => a future same-size
    # item could fill it exactly.
    score += (post == item).astype(np.float64) * 400.0

    # We are completing a pending bin (its residual before placement == item):
    # this was a planned perfect pair.
    score += (bins == item).astype(np.float64) * 400.0

    # Learned value of leaving residual `post`: proportional to how often that
    # exact size has been observed (probability a future item closes it).
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_close = np.zeros_like(score)
    idx = post_idx[valid]
    p_close[valid] = hist[idx] / total
    # Scale modestly; exact-fill bonus already dominates the closing case.
    score += p_close * 300.0

    # Small preference for closing near-empty bins (residual small but nonzero):
    # among equal best-fit residuals, prefer smaller absolute residual.
    score += (post > 0).astype(np.float64) * (1000.0 / (post.astype(np.float64) + 1000.0))

    return score
# EVOLVE-BLOCK-END
