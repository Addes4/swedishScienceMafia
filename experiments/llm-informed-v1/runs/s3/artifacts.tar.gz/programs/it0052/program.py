# EVOLVE-BLOCK-START
"""Best fit with a residual-usefulness tie-breaker to reduce fragmentation."""
import numpy as np

_state = {}


def priority(item, bins):
    """Rank bins: primary = best fit; secondary = prefer residuals likely to be reused.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # remaining capacity after putting the item in each candidate bin
    resid = bins - item  # all >= 0 since only feasible bins are shown

    # Best fit: smallest resulting residual is best -> negative residual.
    score = -resid.astype(np.float64)

    # Track smallest and typical item sizes seen so far to judge "usable" residuals.
    st = _state
    if 'min_size' not in st:
        st['min_size'] = item
        st['sum'] = 0
        st['cnt'] = 0
    if item < st['min_size']:
        st['min_size'] = item
    st['sum'] += item
    st['cnt'] += 1
    mean = st['sum'] / st['cnt']

    # A residual is "useful" if some plausible future item can still fit well.
    # Approximate: residuals that are large enough to hold roughly a typical small item
    # are better than near-zero leftovers that strand capacity.
    # Small nudge only, to break ties toward reusable leftovers without hurting best fit.
    useful = np.clip(resid, 0, mean) / (mean + 1e-9)
    score += 0.02 * useful

    return score
# EVOLVE-BLOCK-END
