# EVOLVE-BLOCK-START
"""Best fit with twin-pairing tie-break on exact residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins: closest fit first (best fit); among equal residuals prefer
    leaving a residual equal to the item (twin pairing), else lower bin index.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins we are shown
    # Primary: smaller residual is better -> use negative residual.
    # Secondary: prefer residual == item (twin), i.e. bins == 2*item.
    twin = (bins == 2 * item)
    # Combine into a single float score; twin bonus is a tiny positive epsilon
    # scaled so it never overrides the primary residual ordering (residual is
    # integer, so 0.5 offset cannot cross integer boundaries).
    return -(residual.astype(np.float64)) + 0.5 * twin
# EVOLVE-BLOCK-END

