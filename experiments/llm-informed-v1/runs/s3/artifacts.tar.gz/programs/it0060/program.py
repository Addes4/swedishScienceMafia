# EVOLVE-BLOCK-START
"""Best fit with a mild twin-residual tie-break: minimize resulting residual,
slightly favoring bins that would be left with exactly `item` free."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smaller resulting residual is better (best fit).
    score = -residual.astype(np.float64)
    # Tiny bonus when the resulting residual equals the item size (perfect twin pair).
    score += 1e-3 * (residual == item)
    return score
# EVOLVE-BLOCK-END

