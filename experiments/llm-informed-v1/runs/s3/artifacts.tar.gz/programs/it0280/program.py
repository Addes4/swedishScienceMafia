# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference plus a calibrated single-item
closability lookahead, using a smoothed empirical distribution blended
with a fixed Weibull-ish prior. Exponential forgetting of past items."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.999

# Fixed prior over item sizes (Weibull-shaped, mean ~40), smoothed.
_prior = np.zeros(101, dtype=np.float64)
for _s in range(1, 101):
    _x = (_s / 100.0)
    _prior[_s] = (_x ** 4) * np.exp(-(_x ** 4))
_prior /= _prior.sum()


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and single-item closability.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed empirical distribution blended with a fixed prior.
    emp = (hist + 1.0)
    emp /= emp.sum()
    prob = 0.7 * emp + 0.3 * _prior    # index 0 unused

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Expected number of future single items that exactly close this residual.
    remaining = max(n_items - st["n"], 0.0)
    exp_fill = remaining * p_fill

    # Reward closable residuals, scaled moderately so best-fit still leads.
    score += p_fill * 250.0
    score += exp_fill * 40.0

    # Closing preference: residual before placement == item.
    score += (bins == item).astype(np.float64) * 300.0

    return score
# EVOLVE-BLOCK-END
