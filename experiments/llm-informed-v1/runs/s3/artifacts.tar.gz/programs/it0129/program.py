# EVOLVE-BLOCK-START
"""Best fit with empirical future-fill lookahead and load concentration."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
    "cap": None,       # remaining capacity of every bin (our own view), by bin index
    "filled": None,    # total item size placed in every bin, by bin index
    "nitems": 0,       # expected number of items (set on first call)
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    # On the first call, len(bins) equals the number of items in the instance.
    if st["cap"] is None:
        nb = len(bins)
        st["cap"] = np.full(nb, 100, dtype=np.int64)
        st["filled"] = np.zeros(nb, dtype=np.int64)
        st["nitems"] = nb

    cap = st["cap"]      # our tracked remaining capacity per bin
    filled = st["filled"]

    # Map the shown bins array back to bin indices: the harness shows only bins
    # that fit, in bin order.  Reconstruct which indices those are from cap.
    demo = cap >= item
    idx = np.nonzero(demo)[0]

    # Defensive: if width mismatches (shouldn't happen), fall back to positions.
    if len(idx) != len(bins):
        idx = np.arange(len(bins))

    # post-placement residual as the harness would compute it.
    post = bins - item

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Lookahead: probability that a future single item exactly equals the
    # residual, estimated from the running histogram (Laplace smoothed).
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        ii = post_idx[valid]
        prob = (hist[ii] + 1.0) / (total + 100.0)
        p_fill[valid] = prob
    score += p_fill * 300.0

    # Pairing bonus: residual equals the item size (a future identical item can
    # close it exactly), and completing a planned perfect pair.
    score += (post == item).astype(np.float64) * 400.0
    score += (bins == item).astype(np.float64) * 400.0

    # Load concentration: among comparable residuals, prefer bins that already
    # carry more load (subtle term, keeps best-fit dominant).
    load = filled[idx].astype(np.float64)
    score += load * 0.02

    # Anti-orphan guard for tiny non-zero residuals.
    small_orphan = (post >= 1) & (post <= 4)
    score -= small_orphan.astype(np.float64) * 3.0

    # Record our own choice: highest score, ties to first.
    best = int(np.argmax(score))
    chosen = int(idx[best])
    cap[chosen] -= item
    filled[chosen] += item

    return score
# EVOLVE-BLOCK-END

