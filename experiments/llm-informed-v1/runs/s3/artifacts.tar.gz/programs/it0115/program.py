# EVOLVE-BLOCK-START
"""Best fit plus exact-fill bonuses and a data-driven small-orphan guard."""
import numpy as np

_state = {"item": 0.0, "hist": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    """Rank bins: prefer tight fits, exact fills, and avoid stranded small residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    hist = st["hist"]
    hist[item] += 1.0

    post = bins - item
    # Base: best fit => smallest post-placement residual is best.
    score = -post.astype(np.float64)

    # Bonus: exact fill (no residue left) — always good.
    score += (post == 0).astype(np.float64) * 1000.0

    # Bonus: residual exactly equals the item size, so a future same-size item
    # could fill it exactly (perfect complementary pair).
    score += (post == item).astype(np.float64) * 500.0

    # Bonus: we are completing a bin whose current residual matches the item
    # (residual before placement == item), i.e. a planned perfect pair.
    score += (bins == item).astype(np.float64) * 500.0

    seen = hist
    total = st["n"]
    post_idx = post.astype(np.int64)

    # Bonus: post-placement residual is a frequently seen item size, so it is
    # likely to be filled exactly by a future item of that size.
    valid = (post_idx >= 1) & (post_idx <= 100)
    freq = np.zeros_like(score)
    idx = post_idx[valid]
    freq[valid] = seen[idx] / total
    score += freq * 200.0

    # Data-driven orphan guard: penalize small residuals only when they are
    # unlikely to be matched exactly by a future item (low empirical frequency).
    # Scaled small enough to remain a tie-breaker under the best-fit base.
    small = (post_idx >= 1) & (post_idx <= 5)
    orphan_pen = np.zeros_like(score)
    orphan_pen[small] = (1.0 - freq[small])
    score -= orphan_pen * 2.0

    return score
# EVOLVE-BLOCK-END


