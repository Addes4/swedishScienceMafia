# EVOLVE-BLOCK-START
"""Best fit with empirical future-fill lookahead, complementary pairing,
two-item sum-completion lookahead, and a recency-weighted size estimate."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),     # cumulative counts
    "rhist": np.zeros(101, dtype=np.float64),    # recency-weighted counts
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    rhist = st["rhist"]
    # decay recency weights and add current item
    rhist *= 0.995
    hist[item] += 1.0
    rhist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution (cumulative).
    prob = (hist + 1.0) / (total + 100.0)

    # Recency-weighted distribution, normalized.
    rsum = rhist.sum()
    rprob = (rhist + 1.0) / (rsum + 100.0)

    # Blend: mostly recency-weighted but anchored by cumulative estimate.
    blend = 0.5 * prob + 0.5 * rprob

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = blend[idx]

    # Lookahead: probability that a future single item exactly equals the
    # residual, estimated from the blended distribution.
    score += p_fill * 300.0

    # Pairing bonus: if the residual after placement equals the item size,
    # a future identical item can close it exactly.
    score += (post == item).astype(np.float64) * 400.0

    # Reward completing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0

    # Two-sided commonness signal: reward residuals whose size is more common
    # than average, penalize rare residuals.
    common = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        common[valid] = (blend[idx] - 0.01) * 100.0   # 0.01 ~ uniform baseline
    score += common * 150.0

    # Two-item sum-completion lookahead using the blended distribution.
    if valid.any():
        p2 = np.convolve(blend[1:101], blend[1:101])  # index s-2 -> sum s
        pw = np.zeros_like(score)
        sums = post_idx[valid]
        p2v = p2[sums - 2]
        pw[valid] = p2v
        score += pw * 120.0

    return score
# EVOLVE-BLOCK-END
