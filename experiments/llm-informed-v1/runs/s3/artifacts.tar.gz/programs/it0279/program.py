# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference plus a clean, well-scaled
"closable residual" lookahead: prefer leaving a residual that a future
item is likely to fill exactly. Uses exponential forgetting."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.999


def priority(item, bins):
    """Rank bins by best-fit plus a smoothed closable-residual reward.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    post = bins - item  # residual after placing item here

    # Laplace-smoothed item-size distribution over 1..100 (index 0 unused).
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    p_fill = np.zeros_like(bins, dtype=np.float64)
    if valid.any():
        p_fill[valid] = prob[post_idx[valid]]

    # Base: best fit -> prefer the smallest post-placement residual, expressed
    # as a negative residual so smaller is better.
    score = -post.astype(np.float64)

    # Exact fill is essentially always right.
    score += (post == 0).astype(np.float64) * 1e6

    # Closable residual: reward a residual that a future item is likely to
    # fill exactly, with the weight scaled so it can override small differences
    # in residual (i.e. a closable leftover beats a slightly smaller unclosable
    # one).  Multiply by the smoothing prior so common sizes dominate.
    score += p_fill * 500.0

    # Also gently reward leaving a residual equal to a frequently seen size,
    # capturing the "wait for a likely future match" behaviour without the
    # noise of a mode lookup.
    score += prob[1:101].max() * 0.0  # no-op keeps structure explicit

    return score
# EVOLVE-BLOCK-END

