# EVOLVE-BLOCK-START
"""Best fit with a soft penalty against stranding very small residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: prefer tightest fit (smallest residual).
    score = -residual.astype(np.float64)
    # Soft penalty for leaving a tiny unusable sliver (residual in 1..threshold).
    # Slivers below the item count can rarely be reused; penalize slightly so a
    # modestly looser bin can win when the trade-off is small.
    small = (residual > 0) & (residual < 4)
    score -= small * 0.25
    # Reward bins that end exactly full (residual 0) a touch.
    score += (residual == 0) * 0.01
    return score
# EVOLVE-BLOCK-END
