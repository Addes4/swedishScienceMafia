# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus and a modest empirical
residual-desirability term based on the decayed item-size distribution."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.999


def priority(item, bins):
    """Rank bins by best-fit plus empirical residual desirability.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Strong exact-fill preference.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        p_fill[valid] = prob[post_idx[valid]]

    # Modest reward for residuals likely to be exactly fillable later.
    score += p_fill * 300.0

    return score
# EVOLVE-BLOCK-END
