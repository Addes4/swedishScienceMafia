# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and a modest bonus for leaving a
residual that matches a common recent item size. Distribution estimated
from full history of seen items."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here
    post_idx = post.astype(np.int64)

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Exact fill: strongly preferred but scaled modestly.
    score += (post == 0).astype(np.float64) * 2000.0

    # Modest reward for leaving a residual likely to be filled by a single
    # future item (probability of that exact size).
    score += p_fill * 200.0

    # Reward closing a bin exactly (residual before placement == item).
    score += (bins == item).astype(np.float64) * 500.0

    return score
# EVOLVE-BLOCK-END
