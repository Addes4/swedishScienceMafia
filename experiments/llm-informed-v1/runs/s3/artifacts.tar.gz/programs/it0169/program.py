# EVOLVE-BLOCK-START
"""Best fit with a calibrated, distribution-aware completion potential."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
    "pmf": None,
}


def _build_pmf():
    hist = _state["hist"]
    total = _state["n"]
    p = (hist[1:101] + 1.0) / (total + 100.0)
    # two-item pairwise sum pmf: p2[s] for s in 2..200
    p2 = np.convolve(p, p)
    return p, p2


def priority(item, bins):
    st = _state
    st["n"] += 1.0
    st["hist"][item] += 1.0
    # rebuild pmf occasionally (cheap enough to do every call at this scale)
    p, p2 = _build_pmf()

    post = bins - item                      # residual after placement
    score = -post.astype(np.float64)        # best fit base

    # Exact fill is strongly preferred but not explosively.
    score += (post == 0).astype(np.float64) * 50.0

    # Reward residuals that a single future item can fill, weighted by how
    # common that size is.  Moderate scale so best-fit stays dominant.
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    single = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        single[valid] = p[idx - 1]
    score += single * 40.0

    # Reward residuals fillable by the sum of two future items.
    two = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        two[valid] = p2[idx - 2]
    score += two * 20.0

    return score
# EVOLVE-BLOCK-END
