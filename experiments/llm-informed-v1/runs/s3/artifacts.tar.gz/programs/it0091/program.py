# EVOLVE-BLOCK-START
"""Best fit with a reservation bonus: avoid stranding bins below the large-item threshold."""
import numpy as np

_LARGE = 65          # items >= this are "large"
_residuals = None    # our own view of every bin's remaining capacity
_initialized = False


def priority(item, bins):
    """Best-fit primary score, plus a bonus for keeping big bins available for large items."""
    global _residuals, _initialized

    n = len(bins)
    if not _initialized or _residuals is None or len(_residuals) != n:
        # bins is a copy of all bins the item fits in; at first call all bins are unused,
        # and len(bins) equals the total number of items -> number of bins we may use.
        _residuals = np.full(n, 100, dtype=np.int64)
        _initialized = True

    res = _residuals  # remaining capacity of every bin (our own tracking)

    post = res - item  # post-placement residual for the candidate bins

    # Primary: best fit (smallest post residual). Score = -post.
    score = -(post.astype(np.float64))

    # Reservation bonus: if this placement would create a residual in (0, _LARGE),
    # that bin can never accept a large item afterwards; penalize it slightly unless
    # the bin gets closed (post == 0) which is always good.
    small_res = (post > 0) & (post < _LARGE)
    score -= small_res.astype(np.float64) * 0.5

    # Exact completion is always excellent.
    score += (post == 0).astype(np.float64) * 1.0

    best = int(np.argmax(score))
    _residuals[best] -= item
    return score
# EVOLVE-BLOCK-END

