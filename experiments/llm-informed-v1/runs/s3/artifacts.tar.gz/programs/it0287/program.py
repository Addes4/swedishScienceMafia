# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and a stable, fixed Weibull-shaped
prior for future-fill lookahead. State only tracks the number of items seen
so we can scale the lookahead by the number of items remaining."""
import numpy as np

_state = {"n": 0.0, "n_items": 0.0}

# Fixed Weibull-shaped prior over item sizes 1..100 (mean ~40).
_SIZES = np.arange(1, 101, dtype=np.float64)
_K = 2.0
_LAM = 40.0 / 0.886226925452758  # Gamma(1+1/k) = 0.8862... so mean = lam*0.8862
_w = (_K / _LAM) * (_SIZES / _LAM) ** (_K - 1.0) * np.exp(-((_SIZES / _LAM) ** _K))
_prior = np.zeros(101, dtype=np.float64)
_prior[1:101] = _w
_prior /= _prior.sum()

# Convolution of the prior with itself: probability a pair of items sums to s.
_conv = np.convolve(_prior[1:101], _prior[1:101])
_pair = np.zeros(101, dtype=np.float64)
_pair[1:101] = _conv[:100]
_pair /= max(_pair.sum(), 1e-12)


def priority(item, bins):
    """Rank bins by best fit, exact fill, and future-close probability."""
    st = _state
    if st["n"] == 0.0:
        st["n_items"] = float(len(bins))
    st["n"] += 1.0

    post = bins - item  # residual after placing item here
    n_items = st["n_items"]
    remaining = max(n_items - st["n"], 0.0)

    score = -post.astype(np.float64)        # base: best fit

    score += (post == 0).astype(np.float64) * 10000.0   # exact fill

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    p_fill = np.zeros_like(score)
    p_pair = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = _prior[idx]
        p_pair[valid] = _pair[idx]

    # Expected number of future exact single-item fills for this residual.
    exp_single = remaining * p_fill
    # Expected number of future item-pairs that would exactly close the bin.
    n_pairs = remaining * max(remaining - 1.0, 0.0) * 0.5
    pair_scale = min(n_pairs / max(n_items, 1.0), 5.0)
    exp_pair = remaining * p_pair * pair_scale

    score += p_fill * 200.0
    score += exp_single * 40.0
    score += exp_pair * 60.0

    # Reward closing a bin whose residual before placement already equals item.
    score += (bins == item).astype(np.float64) * 300.0

    return score
# EVOLVE-BLOCK-END
