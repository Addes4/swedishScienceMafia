# EVOLVE-BLOCK-START
"""Best fit with empirical future-fill lookahead and complementary pairing."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
    "res_filled": np.zeros(101, dtype=np.float64),  # residuals that got hit exactly
    "res_open": np.zeros(101, dtype=np.float64),     # residuals created
}


def priority(item, bins):
    """Rank bins by best-fit plus a learned residual-quality term."""
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    # Record that any bin whose residual equals this item is being exactly filled.
    # bins holds remaining capacities before placement; a bin with bins==item becomes full.
    st["res_filled"][item] += float(np.count_nonzero(bins == item))

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Lookahead: probability a future single item exactly equals the residual,
    # estimated from the running histogram (Laplace-smoothed).
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        prob = (hist[idx] + 1.0) / (total + 100.0)
        p_fill[valid] = prob
    score += p_fill * 300.0

    # Pairing bonus: residual equals the item size (future identical item closes it).
    score += (post == item).astype(np.float64) * 400.0

    # Reward completing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0

    # Learned residual quality: residual sizes that have historically been
    # exactly filled often are more valuable to create. Track creation counts.
    if valid.any():
        idx = post_idx[valid]
        st["res_open"][idx] += 1.0

    filled = st["res_filled"]
    opened = st["res_open"]
    # Empirical fill rate per residual size (smoothed); higher is better.
    filled_rate = (filled + 0.5) / (opened + 1.0)
    quality = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        quality[valid] = filled_rate[idx]
    score += quality * 30.0

    # Tiny anti-orphan guard for very small non-zero residuals.
    small_orphan = (post >= 1) & (post <= 4)
    score -= small_orphan.astype(np.float64) * 3.0

    return score
# EVOLVE-BLOCK-END

