# EVOLVE-BLOCK-START
"""Best fit with a small fullness bonus to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: tightest fit (smallest leftover after placement) -> best fit.
    # bins - item is the leftover; smaller leftover is better, so negate.
    # Add a tiny fullness bonus to prefer fuller bins among near-ties,
    # reducing fragmentation across many partially-filled bins.
    leftover = bins - item
    return -leftover.astype(np.float64) - 0.01 * bins
# EVOLVE-BLOCK-END
