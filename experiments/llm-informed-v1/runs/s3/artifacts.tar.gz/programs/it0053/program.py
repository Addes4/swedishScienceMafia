# EVOLVE-BLOCK-START
"""Best fit with a small pairing tie-break: prefer leaving a residual that matches a common item size."""
import numpy as np

_counts = np.zeros(101, dtype=np.int64)
_calls = 0
_total = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _calls, _total
    if _calls == 0:
        # bins length equals number of items on the first call
        _total = len(bins)
        _counts[:] = 0

    # Base best-fit score
    base = -(bins - item).astype(np.float64)

    # Tie-break: bonus if residual-after-placement matches a common seen item size
    residual = bins - item
    # tiny bonus proportional to how often that residual size has occurred
    freq = _counts[np.clip(residual, 0, 100)]
    tie = freq.astype(np.float64) * 1e-6

    score = base + tie

    # update statistics after scoring (item is now "seen")
    _counts[item] += 1
    _calls += 1
    return score
# EVOLVE-BLOCK-END
