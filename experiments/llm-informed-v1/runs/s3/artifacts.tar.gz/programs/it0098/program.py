# EVOLVE-BLOCK-START
"""Best fit plus bonuses for exact fills and perfect complementary pairs."""
import numpy as np

_state = {"item": 0.0, "hist": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    """Rank bins: prefer tight fits, exact fills, and bins whose residual complements item.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    hist = st["hist"]
    hist[item] += 1.0

    post = bins - item
    # Base: best fit => smallest post-placement residual is best.
    score = -post.astype(np.float64)
    # Bonus: exact fill (no residue left) — always good.
    score += (post == 0).astype(np.float64) * 1000.0
    # Bonus: residual exactly equals the item size, so a future same-size item
    # could fill it exactly (perfect complementary pair).
    score += (post == item).astype(np.float64) * 500.0

    # Bonus: we are completing a bin whose current residual matches the item
    # (residual before placement == item), i.e. a planned perfect pair.
    score += (bins == item).astype(np.float64) * 500.0

    # Bonus: post-placement residual is a frequently seen item size, so it is
    # likely to be filled exactly by a future item of that size.
    seen = hist
    total = st["n"]
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    freq = np.zeros_like(score)
    idx = post_idx[valid]
    freq[valid] = seen[idx] / total
    score += freq * 200.0

    return score
# EVOLVE-BLOCK-END
