# EVOLVE-BLOCK-START
"""Best fit with a consolidation preference against opening fresh bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = -(bins - item)  # best fit: smaller resulting residual is better
    # Penalize placing into a completely empty bin unless best fit is a
    # near-exact fill, to encourage consolidation.
    empty_penalty = np.where(bins == 100, 1e6, 0.0)
    return residual - empty_penalty
# EVOLVE-BLOCK-END
