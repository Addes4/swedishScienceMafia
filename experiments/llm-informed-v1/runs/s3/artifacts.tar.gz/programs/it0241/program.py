# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and a calibrated residual-
desirability lookahead (single- and pair-fill probabilities from the
empirical item distribution), with exponential forgetting."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.999


def priority(item, bins):
    """Rank bins by best-fit plus a calibrated probability of future fills.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))
    post = bins - item  # residual after placing item here

    # Core: best fit dominates.
    score = -post.astype(np.float64)

    # Exact fill: strongly preferred (deterministic).
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    p = prob[1:101]
    # Single-fill probability for each residual.
    p_fill = np.zeros_like(score)
    if valid.any():
        p_fill[valid] = prob[post_idx[valid]]

    # Pair-fill probability: residual can be closed by two typical items.
    pair_prob = np.zeros(101, dtype=np.float64)
    conv = np.convolve(p, p)
    pair_prob[1:101] = conv[:100]
    p_pair = np.zeros_like(score)
    if valid.any():
        p_pair[valid] = pair_prob[post_idx[valid]]

    remaining = max(n_items - st["n"], 0.0)
    # Number of future items / pairs still available (capped influence).
    n_pairs = remaining * max(remaining - 1.0, 0.0) * 0.5

    # Calibrated lookahead: expected number of exact future closes weighted
    # by how valuable closing this residual is (smaller residual = more value).
    exp_single = remaining * p_fill
    exp_pair = min(n_pairs, 25.0 * remaining) * p_pair

    # Single fills are nearly always worth pursuing; pairs only when residual
    # is reasonably small (otherwise the bin isn't near closure).
    value_single = exp_single * 3.0
    value_pair = exp_pair * 0.6 / np.maximum(post.astype(np.float64), 1.0)

    score += value_single + value_pair

    # Closing a bin exactly (residual before placement equals item).
    score += (bins == item).astype(np.float64) * 200.0

    return score
# EVOLVE-BLOCK-END
