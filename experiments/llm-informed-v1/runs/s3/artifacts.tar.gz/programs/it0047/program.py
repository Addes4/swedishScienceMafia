# EVOLVE-BLOCK-START
"""Online bin packing: best fit enhanced with residual usability scoring.

The idea: pure best fit minimizes the immediate residual, but a residual that is
just below a typical future item size is effectively wasted, whereas a residual
that exactly or nearly matches common item sizes can be reused.  We track the
observed item-size distribution online and score each feasible bin by its
post-placement residual `r`:

    score(bin) = -r + bonus(r)

where bonus(r) rewards residuals that are likely to be filled well by future
items (near observed sizes / large enough to matter) and slightly penalizes
residuals sitting in a "dead zone" just below observed item sizes.  Ties fall
back to best fit (first bin).
"""
import numpy as np

_STATE = {
    "counts": None,      # histogram of observed item sizes (index 1..100)
    "n": 0,              # number of items seen
}


def _ensure():
    if _STATE["counts"] is None:
        _STATE["counts"] = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    _ensure()
    counts = _STATE["counts"]
    counts[item] += 1
    _STATE["n"] += 1
    n = _STATE["n"]

    # After placing into a bin with remaining capacity b, residual r = b - item.
    r = bins - item  # non-negative for feasible bins (all shown fit)

    # --- Residual usability bonus -------------------------------------------
    # Estimate a smoothed probability that a *future* item size fits nicely into
    # a residual of size r.  We use a trailing window of recently observed sizes
    # (all sizes seen, weighted towards small so gaps can be filled).
    # Simple, cheap proxy: empirical CDF of observed sizes.
    if n >= 20:
        total = counts.sum()
        cdf = np.cumsum(counts) / total  # cdf[k] = P(size <= k)
        # Probability an item fits in residual r
        fit_prob = cdf[r]  # array over bins
        # Probability of an item landing *exactly* in r (good pairing)
        exact = counts[r] / total
        bonus = 6.0 * fit_prob + 40.0 * exact
    else:
        bonus = 0.0

    # Primary: best fit (smaller residual better).  Add usability bonus.
    return -(r.astype(np.float64)) + bonus
# EVOLVE-BLOCK-END
