# EVOLVE-BLOCK-START
"""First fit: put the item in the earliest bin it fits (lowest bin index)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = len(bins)
    return -np.arange(n, dtype=np.float64)
# EVOLVE-BLOCK-END

