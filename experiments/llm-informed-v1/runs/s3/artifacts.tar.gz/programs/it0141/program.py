# EVOLVE-BLOCK-START
"""Best fit with empirical future-fill lookahead, complementary pairing,
weighted by remaining-item probability."""
import numpy as np

_state = {
    "n": 0.0,
    "N": None,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    if st["N"] is None:
        st["N"] = float(len(bins))
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    # Count of items still to arrive (including possibly this one already counted).
    remaining = max(1.0, st["N"] - total + 1.0)

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Lookahead: probability that a future single item exactly equals the
    # residual, estimated from the running histogram.  Scaled down as few
    # items remain (harder to realize), and up when many items remain.
    decay = remaining / st["N"]
    score += p_fill * 300.0 * (0.5 + 0.5 * decay)

    # Pairing bonus: if the residual after placement equals the item size,
    # a future identical item can close it exactly.
    score += (post == item).astype(np.float64) * 400.0

    # Reward completing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0

    # Two-sided commonness signal: reward residuals whose size is more common
    # than average, penalize rare residuals.
    common = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        common[valid] = (prob[idx] - 0.01) * 100.0   # 0.01 ~ uniform baseline
    score += common * 150.0

    return score
# EVOLVE-BLOCK-END

