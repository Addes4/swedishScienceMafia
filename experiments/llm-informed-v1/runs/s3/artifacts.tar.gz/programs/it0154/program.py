# EVOLVE-BLOCK-START
"""Best fit with calibrated single-item completion lookahead."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit plus a mild single-item completion lookahead.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here
    post_f = post.astype(np.float64)

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post_f

    # Exact fill: strongly preferred.
    score += (post == 0).astype(np.float64) * 1000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Mild lookahead: probability that a future single item exactly equals the
    # residual.  Kept small so it refines close best-fit ties without
    # overriding the primary best-fit ordering.
    score += p_fill * 50.0

    return score
# EVOLVE-BLOCK-END
