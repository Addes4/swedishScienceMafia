# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference, a fixed Weibull-shaped prior for
single-fill and pair-closure lookahead, mode-residual bonus, and an
empirical mean-item-based fragmentation scaling."""
import numpy as np

# Fixed prior over item sizes 1..100 (Weibull-shaped, mean ~40).
# Built once at import time; no per-instance estimation noise.
def _build_prior():
    n = 100000
    # Weibull with shape k=1.5, scale chosen so mean ~40.
    k = 1.5
    lam = 40.0 / 0.9027  # Gamma(1+1/k) = Gamma(1.6667) ~ 0.9027
    u = (np.arange(n) + 0.5) / n
    x = lam * (-np.log(1.0 - u)) ** (1.0 / k)
    idx = np.round(x).astype(np.int64)
    idx = np.clip(idx, 1, 100)
    counts = np.bincount(idx, minlength=101).astype(np.float64)
    p = counts / counts.sum()
    p[0] = 0.0
    return p


_PRIOR = _build_prior()
# Precompute pair convolution of the prior (sum of two items).
_pair_conv = np.convolve(_PRIOR[1:101], _PRIOR[1:101])

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
}

_DECAY = 0.999


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future fill."""
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Fragmentation scaling using empirical mean item size.
    mean_item = float((hist * np.arange(101, dtype=np.float64)).sum() / max(total, 1.0))
    if mean_item < 1.0:
        mean_item = 40.0
    small_resid = np.count_nonzero((bins > 0) & (bins < mean_item))
    frac_small = small_resid / max(len(bins), 1)
    score *= (1.0 + 3.0 * frac_small)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        p_fill[valid] = _PRIOR[post_idx[valid]]

    remaining = max(n_items - st["n"], 0.0)
    exp_fill = remaining * p_fill

    score += p_fill * 300.0

    # Reward placing into a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0

    score += exp_fill * 60.0

    # Pair-closure lookahead using the fixed prior convolution.
    pair_prob = np.zeros(101, dtype=np.float64)
    pair_prob[1:101] = _pair_conv[:100]
    p_pair = np.zeros_like(score)
    if valid.any():
        p_pair[valid] = pair_prob[post_idx[valid]]

    n_pairs = remaining * max(remaining - 1.0, 0.0) * 0.5
    pair_weight = min(n_pairs / max(n_items, 1.0), 5.0)
    score += p_pair * pair_weight * 4000.0

    # Mode-residual bonus based on the fixed prior's dominant size.
    mode_idx = int(np.argmax(_PRIOR[1:101])) + 1
    p_mode = float(_PRIOR[mode_idx])
    score += (post_idx == mode_idx).astype(np.float64) * p_mode * 800.0

    return score
# EVOLVE-BLOCK-END

