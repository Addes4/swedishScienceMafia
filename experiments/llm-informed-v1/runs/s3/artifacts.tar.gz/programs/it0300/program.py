# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and a stable expected-future-fill
lookahead based on an exponentially-forgotten empirical item-size
distribution."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.999
_IDX = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred (kept moderate so best-fit
    # still orders the remaining choices).
    score += (post == 0).astype(np.float64) * 1000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Reward residuals that a single future item is likely to exactly fill,
    # weighted by how many items still remain.
    remaining = max(n_items - st["n"], 0.0)
    exp_fill = remaining * p_fill
    score += p_fill * 200.0
    score += exp_fill * 40.0

    return score
# EVOLVE-BLOCK-END
