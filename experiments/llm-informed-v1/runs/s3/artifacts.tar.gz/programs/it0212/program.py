# EVOLVE-BLOCK-START
"""Best fit with a clean tie-break: prefer residuals that are likely to be
exactly closed by a single future item or by a complementary pair, using the
full-history empirical item-size distribution."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
}


def priority(item, bins):
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = float(hist.sum())
    n_items = float(len(bins))

    post = bins - item
    post_idx = post.astype(np.int64)

    # Base: best fit (smallest residual) dominates ties.
    score = -post.astype(np.float64)

    # Exact fill is always best.
    score += (post_idx == 0).astype(np.float64) * 1.0e6

    # Empirical distribution over item sizes 1..100.
    prob = hist[1:101]
    if total > 0.0:
        prob = prob / total

    valid = (post_idx >= 1) & (post_idx <= 100)
    p_single = np.zeros_like(score)
    if valid.any():
        p_single[valid] = prob[post_idx[valid] - 1]

    p_pair = np.zeros_like(score)
    if valid.any():
        p = prob
        # probability that two independent future items sum to r (r=1..100)
        conv = np.convolve(p, p)[:100]
        p_pair[valid] = conv[post_idx[valid] - 1]

    remaining = max(n_items - st["n"], 0.0)
    # Expected number of single fills / pair fills in the future.
    exp_single = remaining * p_single
    n_pairs = 0.5 * remaining * max(remaining - 1.0, 0.0)
    exp_pair = n_pairs * p_pair

    # Modest close-fit bonuses as tie-breaks (small vs. best-fit steps).
    score += exp_single * 1.0e4
    score += np.minimum(exp_pair, 1.0) * 2.0e4

    return score
# EVOLVE-BLOCK-END
