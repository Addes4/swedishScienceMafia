# EVOLVE-BLOCK-START
"""Modified best fit: best fit, but avoid creating small unusable residuals with small items."""
import numpy as np

_state = {"min_size": 100, "count": 0, "total": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Track observed minimum item size (proxy for smallest common size).
    if item < _state["min_size"]:
        _state["min_size"] = item
    _state["count"] += 1
    _state["total"] += item

    residual = bins - item  # leftover capacity if placed here

    # Dead zone: residuals that are too small to be reusable by a typical small item.
    # Use a modest threshold derived from observations, capped.
    if _state["count"] > 20:
        avg = _state["total"] / _state["count"]
        small = max(1, min(_state["min_size"], int(avg * 0.5)))
    else:
        small = 5

    # Penalize residuals in (0, small) so small items avoid creating dead space,
    # but only for items that are themselves at most 2*small (i.e., "small" items).
    if item <= 2 * small:
        bad = (residual > 0) & (residual < small)
        score = -residual.astype(np.float64)
        score -= bad.astype(np.float64) * 1000.0
        return score

    return -residual
# EVOLVE-BLOCK-END
