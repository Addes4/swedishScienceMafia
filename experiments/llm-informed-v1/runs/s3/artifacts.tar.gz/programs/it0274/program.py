# EVOLVE-BLOCK-START
"""Best fit with a stable, prior-smoothed single-item exact-fill lookahead."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.999

# Fixed Weibull-shaped prior (mean ~40), used to stabilize early estimates.
_PRIOR = np.zeros(101, dtype=np.float64)
_k = 1.6
_lam = 44.0
for _i in range(1, 101):
    _x = _i / _lam
    _PRIOR[_i] = (_k / _lam) * (_x ** (_k - 1.0)) * np.exp(-(_x ** _k))
_PRIOR /= _PRIOR.sum()


def priority(item, bins):
    """Rank bins by best-fit plus a smoothed probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here
    score = -post.astype(np.float64)

    # Exact fill: perfect.
    score += (post == 0).astype(np.float64) * 10000.0

    # Blend empirical histogram with a fixed prior.
    w = total / (total + 200.0)
    prob = w * (hist / max(total, 1.0)) + (1.0 - w) * _PRIOR

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        p_fill[valid] = prob[post_idx[valid]]

    # Reward leaving a residual that a single future item likely fills.
    score += p_fill * 600.0

    # Reward closing a bin exactly where the residual already equals the item.
    score += (bins == item).astype(np.float64) * 500.0

    # Mild expected-fill lookahead scaled by items remaining.
    remaining = max(n_items - st["n"], 0.0)
    score += (remaining * p_fill) * 4.0

    return score
# EVOLVE-BLOCK-END
