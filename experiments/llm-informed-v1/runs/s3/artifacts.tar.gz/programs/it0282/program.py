# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and a complementary-pair signal.

Uses a fixed Weibull-shaped prior over item sizes (mean ~40) rather than
tracking recent items, to keep the rule low-variance and avoid over-fitting
to the running empirical distribution.
"""
import numpy as np

# Fixed prior over item sizes 1..100, Weibull-ish shape with mean ~40.
_SIZES = np.arange(101, dtype=np.float64)
# Weibull k=2, lambda chosen so the mean over 1..100 is ~40.
_LAM = 44.0
_pdf = np.zeros(101, dtype=np.float64)
_s = _SIZES[1:101]
_pdf[1:101] = (_s / _LAM) * np.exp(-(_s / _LAM) ** 2)
_pdf[1:101] /= _pdf[1:101].sum()

# Pair probability: convolution of the prior with itself, clamped to 1..100.
_conv = np.convolve(_pdf[1:101], _pdf[1:101])
_pair = np.zeros(101, dtype=np.float64)
_pair[1:101] = _conv[:100]
_pair[1:101] /= max(_pair[1:101].sum(), 1e-12)


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and complementary-pair likelihood.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    idx = post.astype(np.int64)
    score += (idx == 0).astype(np.float64) * 10000.0

    # Complementary pairing: reward leaving a residual that is likely to be
    # closed exactly by a pair of typical future items.
    valid = (idx >= 1) & (idx <= 100)
    p_pair = np.zeros(bins.shape[0], dtype=np.float64)
    if valid.any():
        p_pair[valid] = _pair[idx[valid]]
    score += p_pair * 2000.0

    # Mild single-item fill preference: a residual equal to a common item size.
    p_single = np.zeros(bins.shape[0], dtype=np.float64)
    if valid.any():
        p_single[valid] = _pdf[idx[valid]]
    score += p_single * 200.0

    return score
# EVOLVE-BLOCK-END

