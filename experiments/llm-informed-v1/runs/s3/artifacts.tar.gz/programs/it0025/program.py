# EVOLVE-BLOCK-START
"""Stateful best-fit with a big-item safeguard.

Tracks every open bin's remaining capacity. Normally uses best fit (tightest
residual). But for large items, it avoids dumping them into very tight gaps
(where they'd leave a useless sliver and possibly waste the large item),
preferring a bin whose residual is at least the item size but not absurdly large.
"""
import numpy as np

_rem = None      # list of remaining capacities of all bins, indexed by bin id
_n = 0           # items seen so far
_total = 0       # total number of items (== number of bins) on first call
_sum = 0         # sum of seen item sizes
_maxseen = 0     # max seen item size
_cnt = 0         # count of seen items


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _rem, _n, _total, _sum, _maxseen, _cnt

    # First call of an instance: every bin is unused, len(bins) == number of items.
    if _rem is None:
        _total = len(bins)
        _rem = [100] * _total

    # The bins array corresponds to open bins (those the item fits in), in bin order.
    # We need to map positions in `bins` to our internal bin ids.  We keep the
    # invariant that _rem is synchronized with actual placements.
    n_open_shown = len(bins)

    # Track item stats
    _sum += item
    _cnt += 1
    if item > _maxseen:
        _maxseen = item

    mean = _sum / _cnt

    # Decide threshold for "large" items.
    large = item >= max(mean, 0.7 * _maxseen)

    # Build candidate list: (bin_id, remaining)
    # We reconstruct which internal bins are shown: those with _rem >= item,
    # in bin order.  This mirrors the harness exactly because we track all placements.
    cand = []
    for bid in range(_total):
        r = _rem[bid]
        if r >= item:
            cand.append((bid, r))
            if len(cand) == n_open_shown:
                break
    # Fallback safety: if mismatch, just scan all
    if len(cand) != n_open_shown:
        cand = [(bid, _rem[bid]) for bid in range(_total) if _rem[bid] >= item]

    scores = np.full(n_open_shown, -1e18, dtype=np.float64)

    if not large:
        # Best fit: highest score = smallest residual (bins - item is residual here).
        for idx, (bid, r) in enumerate(cand):
            residual = r - item
            scores[idx] = -residual
    else:
        # Large item safeguard: prefer residual >= item (can host another large item),
        # then among those prefer the smallest such residual; else best fit.
        for idx, (bid, r) in enumerate(cand):
            residual = r - item
            if residual >= item:
                # good: small residual but >= item
                scores[idx] = 1000.0 - residual
            else:
                # penalty scaled by how tight
                scores[idx] = 0.0 - residual

    # Pick best
    best_idx = int(np.argmax(scores))
    best_bid = cand[best_idx][0]

    # Update our tracked remaining capacity
    _rem[best_bid] -= item

    return scores
# EVOLVE-BLOCK-END

