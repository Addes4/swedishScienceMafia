# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference, empirical future-fill lookahead
scaled by the number of items left, complementary pairing, and a
pair-closure signal, with exponential forgetting of past items."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.999


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    # exponential forgetting so the distribution reflects recent items
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Scale best-fit strength with fragmentation: when many open bins have
    # small residuals, consolidating (best-fit) matters more.
    mean_item = float((hist * np.arange(101, dtype=np.float64)).sum() / max(total, 1.0))
    if mean_item < 1.0:
        mean_item = 40.0
    small_resid = np.count_nonzero((bins > 0) & (bins < mean_item))
    frac_small = small_resid / max(len(bins), 1)
    score *= (1.0 + 3.0 * frac_small)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Expected number of future exact single-item fills for this residual.
    remaining = max(n_items - st["n"], 0.0)
    exp_fill = remaining * p_fill

    score += p_fill * 300.0

    # Reward placing into a bin whose residual before placement == item,
    # closing the bin exactly.
    score += (bins == item).astype(np.float64) * 400.0

    score += exp_fill * 60.0

    # Pair-closure lookahead: probability that this residual can be exactly
    # filled by a *pair* of typical future items (convolution of prob with
    # itself), which consolidates leftovers that a single item cannot close.
    pair_prob = np.zeros(101, dtype=np.float64)
    p = prob[1:101]
    conv = np.convolve(p, p)
    pair_prob[1:101] = conv[:100]
    p_pair = np.zeros_like(score)
    if valid.any():
        p_pair[valid] = pair_prob[post_idx[valid]]

    # Scale by estimated number of future item-pairs available.
    n_pairs = remaining * max(remaining - 1.0, 0.0) * 0.5
    # Only meaningful while plenty of items remain; shrink near the end.
    pair_weight = min(n_pairs / max(n_items, 1.0), 5.0)
    score += p_pair * pair_weight * 4000.0

    # Mode-residual bonus: prefer leaving a residual equal to the most common
    # recent item size, weighted by how common it is.
    mode_idx = int(np.argmax(prob[1:101])) + 1
    p_mode = float(prob[mode_idx])
    score += (post_idx == mode_idx).astype(np.float64) * p_mode * 800.0

    # One-step lookahead: expected quality of the residual after the *next*
    # item. For each candidate residual, estimate the chance that a typical
    # next item lands it near an exact/close fill (i.e. becomes closable soon).
    # This consolidates leftovers toward sizes future items can actually close.
    if valid.any():
        # Probability mass of items that would leave a small residual (<= some
        # threshold) minus prob mass that would perfectly fill it.
        idx = post_idx[valid]
        # closability after one more item: P(next <= residual clears to small)
        cum = np.cumsum(prob)  # cum[s] = P(item <= s), indices 0..100
        # chance a single future item fits without overflowing AND leaves a
        # tiny residual gap (within a small tolerance) -> near-perfect close
        tol = 3
        near = np.zeros_like(score)
        lo = np.clip(idx - tol, 0, 100)
        hi = np.clip(idx, 0, 100)
        near[valid] = cum[hi] - cum[lo]
        score += near * 1200.0

        # Also reward residuals that are themselves a common item size so a
        # single future item can zero them exactly strongly (already in p_fill,
        # but add small extra for near-common sizes).
        near_common = np.zeros_like(score)
        lo2 = np.clip(idx - 2, 1, 100)
        hi2 = np.clip(idx + 2, 1, 100)
        # approximate p of being within 2 of a heavily probable size
        local = np.array([prob[j:j+5].sum() for j in range(101)])  # windowed mass
        near_common[valid] = local[np.clip(idx, 0, 100)]
        score += near_common * 400.0

    return score
# EVOLVE-BLOCK-END

