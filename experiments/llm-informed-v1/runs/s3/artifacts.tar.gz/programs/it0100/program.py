# EVOLVE-BLOCK-START
"""Best fit with complementary-pair completion driven by observed item frequencies."""
import numpy as np

_state = {"n": 0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Rank bins: best fit, with a bonus for completions that match likely future items.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    hist = st["hist"]
    hist[item] += 1.0

    post = bins - item
    # Base: best fit => smallest post-placement residual is best.
    score = -post.astype(np.float64)
    # Bonus: exact fill (no residue left) — always good.
    score += (post == 0).astype(np.float64) * 1000.0
    # Bonus: residual exactly equals the item size, so a future same-size item
    # could fill it exactly (perfect complementary pair).
    score += (post == item).astype(np.float64) * 500.0
    # Bonus: we are completing a bin whose current residual matches the item.
    score += (bins == item).astype(np.float64) * 500.0

    # Bonus weighted by how likely the post-placement residual is to be matched
    # exactly by a future item, estimated from the empirical item-size distribution.
    total = st["n"]
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    freq = np.zeros_like(score)
    idx = post_idx[valid]
    freq[valid] = hist[idx] / total
    score += freq * 400.0

    return score
# EVOLVE-BLOCK-END

