# EVOLVE-BLOCK-START
"""Best-fit with exact-fill dominance and a mild anti-fragmentation bias.

Simpler, more stable variant: the empirical-distribution bonuses in the
previous version were noisy and over-tuned. Here we keep the two robust
signals (best fit and exact fill) and add a small, deterministic preference
for keeping consolidation pressure low.
"""
import numpy as np

_state = {
    "n": 0.0,
}


def priority(item, bins):
    """Rank bins: best-fit with exact-fill dominance.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0

    bins = np.asarray(bins)
    post = bins - item  # residual after placing item here

    # Exact fill: strongly preferred.
    score = -(post.astype(np.float64))
    score += (post == 0).astype(np.float64) * 1e9

    # Slight preference for smaller residual among non-exact choices is already
    # encoded by the -post base term.

    return score
# EVOLVE-BLOCK-END
