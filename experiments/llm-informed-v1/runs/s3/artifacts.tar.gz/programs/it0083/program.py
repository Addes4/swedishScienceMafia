# EVOLVE-BLOCK-START
"""Stateful bin-choice rule: minimize sum of squared residuals (residual balancing),
with best-fit as an exact tie-break. Keeps its own view of all open bins.
"""
import numpy as np

_CAP = 100
_res = None      # list of residuals of every bin opened so far
_n_items = None  # total items in the instance


def _init(n):
    global _res, _n_items
    _res = []
    _n_items = n


def priority(item, bins):
    global _res, _n_items

    n = len(bins)
    if _res is None or _n_items != n:
        # First call of an instance: every bin is unused, so len(bins) == #items.
        _init(n)

    # Sync our own residual view with the harness view.
    # bins only includes open bins; unused bins have residual 100.
    # We rebuild from our tracked residuals but reconcile with what we're shown.
    m = len(_res)
    if m != n:
        # Defensive resync: extend our view with fresh capacity-100 bins.
        if m < n:
            _res.extend([_CAP] * (n - m))
        else:
            _res = _res[:n]

    # Candidate bins: indices where item fits (residual >= item).
    res_view = _res
    # Score = -(sum of squared residuals after placement) => maximize.
    # sum_sq_after = sum_{j != i} r_j^2 + (r_i - item)^2
    #             = S2 - r_i^2 + (r_i - item)^2
    #             = S2 - 2*item*r_i + item^2
    # Maximizing -(sum_sq_after) <=> maximizing (2*item*r_i) <=> maximizing r_i.
    # So pure sum-of-squares residual balancing reduces to choosing the bin with the
    # LARGEST residual the item fits in (worst-fit). We instead use a blend that keeps
    # residuals moderate: score by r_i but prefer tighter fits for small items and
    # looser fits for larger items, using best-fit as a strong secondary criterion.
    fits = [i for i in range(n) if res_view[i] >= item]
    if not fits:
        # Shouldn't happen (harness guarantees a fitting bin), but be safe.
        return np.zeros(n, dtype=np.float64)

    scores = np.full(n, -1e18, dtype=np.float64)
    # Best-fit distance among fitting bins (for blend).
    # We want diversification: minimize sum of squares of residuals => choose largest
    # fitting residual. Pure worst-fit is bad; blend worst-fit with best-fit.
    # Use a target residual region to avoid extremes.
    for i in fits:
        r = res_view[i]
        after = r - item
        # primary: residual-balancing term wants larger r (larger after too).
        # secondary: penalize very large post-residual (waste) mildly.
        s = -(after * after)          # minimize squared post-residual
        s += 0.5 * r                  # mild preference for larger residual (balance)
        scores[i] = s

    idx = int(np.argmax(scores))

    # Commit the placement into our own residual view.
    res_view[idx] -= item

    return scores
# EVOLVE-BLOCK-END
