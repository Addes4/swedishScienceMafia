# EVOLVE-BLOCK-START
"""Best-fit with exact-fill preference, distribution-based completion bonus,
and a mild penalty for leaving large residuals (near-empty bins)."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and completion likelihood.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    # Completion bonus: probability a future single item exactly equals the
    # residual (estimated from the running histogram).
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]
    score += p_fill * 300.0

    # Reward completing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0

    # Mild penalty for leaving a large residual (near-empty bin), so we
    # consolidate rather than spread items across many barely-used bins.
    # Decays smoothly with residual size; strongest for near-full residuals.
    score += (100.0 - post.astype(np.float64)) * 0.5

    return score
# EVOLVE-BLOCK-END
