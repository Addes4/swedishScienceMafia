# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus and a lightweight residual-pairability bonus."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Rank bins: prefer tight fits, exact fills, and residuals likely to be exactly refilled.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0

    post = bins - item
    # Base: best fit => smallest post-placement residual is best.
    score = -post.astype(np.float64)
    # Bonus: exact fill (no residue left) — always good.
    score += (post == 0).astype(np.float64) * 1000.0
    # Bonus: residual equals the current item, so a future same-size item can
    # complete this bin exactly (strong complementary pairing).
    score += (post == item).astype(np.float64) * 500.0
    # Bonus: we are exactly completing a bin whose residual already equals the
    # item size, i.e. a planned perfect pair.
    score += (bins == item).astype(np.float64) * 500.0

    # Bonus: post-placement residual is a frequently observed item size, hence
    # likely to be filled exactly by a future item of that size.
    total = st["n"]
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    freq = np.zeros_like(score)
    idx = post_idx[valid]
    freq[valid] = hist[idx] / total
    score += freq * 200.0

    return score
# EVOLVE-BLOCK-END
