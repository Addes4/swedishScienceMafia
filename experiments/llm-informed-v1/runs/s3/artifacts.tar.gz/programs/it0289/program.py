# EVOLVE-BLOCK-START
"""Best fit with a strong exact-fill bonus and a stable harmonic
"expected future fills" lookahead based on a fixed Weibull-shaped
item-size prior estimated once per instance."""
import numpy as np

_state = {
    "n": 0.0,
    "sizes": [],          # raw sizes seen so far
    "prior": None,        # fixed prior over residuals 1..100 (set once)
    "prior_ready": False,
}

# Weibull(k=2, lambda) roughly matches the described distribution
# (mean ~40, right-skewed, support 1..100).
_WEIBULL_K = 2.0
_WEIBULL_LAMBDA = 45.0


def _build_prior():
    """Fixed Weibull-shaped prior probability over residual sizes 1..100."""
    x = np.arange(1, 101, dtype=np.float64)
    probs = np.zeros(101, dtype=np.float64)
    denom = _WEIBULL_LAMBDA ** _WEIBULL_K
    pdf = (_WEIBULL_K / _WEIBULL_LAMBDA) * (x / _WEIBULL_LAMBDA) ** (_WEIBULL_K - 1.0) \
        * np.exp(-(x ** _WEIBULL_K) / denom)
    s = pdf.sum()
    if s <= 0.0:
        probs[1:101] = 1.0 / 100.0
    else:
        probs[1:101] = pdf / s
    return probs


def priority(item, bins):
    """Rank bins by best-fit with exact-fill and harmonic fill lookahead.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    st["sizes"].append(int(item))

    n_items = float(len(bins))

    # Build the prior once, after a warm-up of observed sizes; keep it fixed
    # afterward so the function is deterministic and low-noise.
    if not st["prior_ready"]:
        prior = _build_prior()
        if len(st["sizes"]) >= 400:
            # Blend the fixed Weibull shape with the empirical sizes seen so far.
            emp = np.zeros(101, dtype=np.float64)
            for sz in st["sizes"]:
                if 1 <= sz <= 100:
                    emp[sz] += 1.0
            if emp.sum() > 0:
                emp /= emp.sum()
                prior = 0.5 * prior + 0.5 * emp
            st["prior"] = prior
            st["prior_ready"] = True
        else:
            st["prior"] = prior
    prior = st["prior"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 1e6

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    # Harmonic expected number of future exact fills at this residual.
    # residual r can be closed by an item of size exactly r.
    p_fill = np.zeros_like(score)
    if valid.any():
        p_fill[valid] = prior[post_idx[valid]]

    remaining = max(n_items - st["n"], 0.0)

    # Expected single-item fills over the remaining horizon.
    score += p_fill * remaining * 2.0

    # Complementary closing: bin currently holds capacity exactly equal to item,
    # placing here closes it exactly.
    score += (bins == item).astype(np.float64) * 5e5

    return score
# EVOLVE-BLOCK-END
