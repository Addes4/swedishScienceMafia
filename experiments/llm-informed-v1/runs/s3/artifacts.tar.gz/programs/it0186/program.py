# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference, histogram-driven future-fill lookahead,
and a late-phase consolidation term targeting the modal item size."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
    "recent": np.zeros(101, dtype=np.float64), # recent-item counts
    "seen": 0.0,
    "mode": 0.0,                               # running modal item size
}


def priority(item, bins):
    """Rank bins by best fit, exact fill, probability of a future exact fill,
    and (late) consolidation toward the modal item size.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    recent = st["recent"]
    hist[item] += 1.0
    recent[item] += 1.0
    total = st["n"]

    # Track a running modal size (cheap: recompute every 25 items).
    if (int(total) % 25) == 0:
        st["mode"] = float(np.argmax(recent))

    n_items = float(len(bins))
    remaining = max(n_items - total, 0.0)

    post = bins - item            # residual after placing item here
    score = -post.astype(np.float64)   # base: best fit

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Reward placing into a bin whose residual before placement == item,
    # closing the bin exactly.
    score += (bins == item).astype(np.float64) * 400.0

    # Expected number of future exact single-item fills for this residual,
    # scaled to shrink as the instance ends.
    score += remaining * p_fill * 60.0

    # Late-phase consolidation: when few items remain, strongly prefer leaving
    # a residual equal to the running modal size, since a large fraction of
    # remaining items will hit that exact residual.
    mode = st["mode"]
    if mode >= 1.0 and remaining < 40.0:
        score += (post_idx == int(mode)).astype(np.float64) * (200.0 - 3.0 * remaining)

    return score
# EVOLVE-BLOCK-END

