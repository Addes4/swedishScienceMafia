# EVOLVE-BLOCK-START
"""Best fit nudged by a distribution-aware residual reuse bonus."""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.float64), "total": 0.0}


def priority(item, bins):
    """Rank bins: prefer tight fits, but reward residuals that match typical item sizes."""
    counts = _state["counts"]
    counts[item] += 1.0
    _state["total"] += 1.0

    residual = bins - item  # leftover capacity after placing the item

    # Probability-weighted "usefulness" of a residual: how likely a future item
    # is to exactly use up that residual (or come close). Built from observed sizes.
    total = _state["total"]
    if total >= 8.0:
        hist = counts / total  # empirical pmf over sizes 1..100
        p = hist[1:101]
        # probability mass near each residual value (within +/- 3), via cumulative sums
        csum = np.concatenate(([0.0], np.cumsum(p)))
        r = np.clip(residual, 0, 100).astype(np.int64)
        lo = np.clip(r - 3, 0, 101)
        hi = np.clip(r + 4, 0, 101)
        usefulness = csum[hi] - csum[lo]
    else:
        usefulness = np.zeros_like(residual, dtype=np.float64)

    # Best-fit is primary; add a modest bonus for reusable residuals.
    return -residual.astype(np.float64) + 6.0 * usefulness
# EVOLVE-BLOCK-END
