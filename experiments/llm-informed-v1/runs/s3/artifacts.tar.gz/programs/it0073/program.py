# EVOLVE-BLOCK-START
"""Best fit with a mild large-item reservation bias.

The rule ranks bins primarily by best fit (tightest residual for the arriving item),
but applies a size-dependent scaling so that large items slightly prefer less-full
bins while small items prefer tighter fits. This mimics an online variant that
keeps a few partially filled bins open for future large items.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of bins the item fits in.
    """
    residual = bins - item
    # Base: best fit -> most negative residual first. We return residual directly since
    # lower residual should win, so negate.
    base = -residual
    # Large items: mild bonus for bins that will still have room, encouraging them to
    # not waste an almost-empty bin's space; small items: no change.
    if item >= 60:
        base = base - 0.15 * residual
    return base
# EVOLVE-BLOCK-END
