# EVOLVE-BLOCK-START
"""Residual-aware best fit: classic best fit plus a tiny bonus for leaving a
residual equal to a commonly-seen item size (likely to be filled exactly later)."""
import numpy as np

# ---- module-level state, reset per instance (fresh process each time) ----
_size = 0          # number of items in this instance (== len(bins) on first call)
_resid = None      # our own copy of remaining capacity per bin index
_hist = None       # histogram of seen item sizes (index 1..100)
_N = 100


def _init(n):
    global _resid, _hist
    _resid = np.full(n, 100, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    n = len(bins)
    if _resid is None or len(_resid) != n:
        _init(n)

    # record the item
    _hist[item] += 1

    # candidate bins = the ones shown (item fits)
    # best fit: minimize resulting residual (_resid - item)
    new_resid = _resid[:n] - item

    # primary key: tightest fit (smallest new residual) -> higher score
    # secondary: tiny bonus if new residual is a frequently seen size
    # (a common future item size) -> helps exact complement pairing.
    # use a small weight so it only breaks near-ties.
    freq = _hist / max(1, _hist.sum())
    useful = freq[new_resid]  # 0 for out-of-range handled below

    score = -new_resid.astype(np.float64) + 1e-3 * useful

    best = int(np.argmax(score))
    _resid[best] -= item
    return score
# EVOLVE-BLOCK-END
