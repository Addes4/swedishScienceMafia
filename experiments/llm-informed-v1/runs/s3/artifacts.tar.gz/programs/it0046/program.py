# EVOLVE-BLOCK-START
"""Best fit with exact-fit priority and split-aware tiebreak."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    sizes = _state["sizes"]
    sizes.append(item)

    # Exact-fit gets a strong bonus: place item where residual == item.
    exact = (bins == item)
    # Base: best fit (tightest that still fits), i.e. smallest residual.
    base = -bins.astype(np.float64)

    # Small bonus if residual-after-placement equals a commonly seen size.
    # Use a simple presence check over the last 200 sizes.
    recent = sizes[-200:]
    if recent:
        seen = set(recent)
        after = bins - item
        hit = np.array([1.0 if (a in seen and a > 0) else 0.0 for a in after])
    else:
        hit = np.zeros(len(bins))

    score = base + 1000.0 * exact.astype(np.float64) + 0.5 * hit
    return score
# EVOLVE-BLOCK-END

