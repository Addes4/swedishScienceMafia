# EVOLVE-BLOCK-START
"""Blend of best-fit tightness and worst-fit spread to limit stranded residuals."""
import numpy as np

_ALPHA = 0.85


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item          # >= 0 for all shown bins
    # tightness: prefer small leftover (best-fit). Negate so larger is better.
    tight = -leftover.astype(np.float64)
    # spread: prefer bins with more room remaining after placement.
    spread = leftover.astype(np.float64)
    return _ALPHA * tight + (1.0 - _ALPHA) * spread
# EVOLVE-BLOCK-END

