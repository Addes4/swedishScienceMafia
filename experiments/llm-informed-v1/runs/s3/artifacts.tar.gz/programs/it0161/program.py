# EVOLVE-BLOCK-START
"""Best fit with a bounded empirical completion bonus.

The base rule is best fit (prefer the smallest post-placement residual).
On top of it, two small, bounded bonuses derived from the observed histogram
refine close ties:
  * exact fill (residual 0) is strongly preferred;
  * leaving a residual equal to a frequent item size is mildly preferred,
    since a future item is more likely to close it;
  * using a bin whose current residual equals the arriving item is mildly
    preferred (guaranteed immediate completion).
The bonuses are kept small enough that they only act as tie-breakers.
"""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Dominant base: best fit.
    score = -post.astype(np.float64)

    # Perfect fill: strongly preferred.
    score += (post == 0).astype(np.float64) * 1000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Bounded completion bonus: stays below 1 so it only breaks near-ties.
    score += np.minimum(p_fill * 200.0, 0.9)

    # Immediate completion bonus (residual before placement == item), bounded.
    score += (bins == item).astype(np.float64) * 0.8

    return score
# EVOLVE-BLOCK-END
