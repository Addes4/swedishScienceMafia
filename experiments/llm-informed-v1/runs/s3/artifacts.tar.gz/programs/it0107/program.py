# EVOLVE-BLOCK-START
"""Best fit plus learned completion-value of the residual (waste-aware)."""
import numpy as np

_state = {"n": 0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Rank bins: prefer tight fits, exact fills, and residuals likely to be filled later.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    hist = st["hist"]
    hist[item] += 1.0

    post = bins - item
    post = post.astype(np.int64)
    score = -post.astype(np.float64)

    # Exact fill is always best.
    score += (post == 0).astype(np.float64) * 1000.0

    # Learn completion probability: how often has a residual value r been
    # exactly matched by a later item of the same size? Approximate this with the
    # empirical frequency of item sizes, since a residual r is closed exactly
    # when an item of size r arrives.
    total = st["n"]
    freq = hist / total  # freq[i] = P(next item == i), empirical

    valid = (post >= 1) & (post <= 100)
    p_close = np.zeros_like(score)
    idx = post[valid]
    p_close[valid] = freq[idx]

    # Reward residuals that are likely to be exactly filled soon (good pairing).
    score += p_close * 300.0

    # Waste-aware guard: residuals that are rarely/never matchable strand capacity.
    # Penalize them beyond their best-fit magnitude so that, all else equal, a bin
    # whose residual is pairable is preferred over one that is not.
    unmatched = valid & (hist[np.clip(idx, 0, 100)] == 0.0)
    score[valid] -= unmatched.astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END
