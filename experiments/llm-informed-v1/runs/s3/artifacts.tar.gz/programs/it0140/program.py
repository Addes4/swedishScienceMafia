# EVOLVE-BLOCK-START
"""Best fit with empirical future-fill lookahead, complementary pairing, and
two-item sum-completion lookahead."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Lookahead: probability that a future single item exactly equals the
    # residual, estimated from the running histogram.
    score += p_fill * 300.0

    # Pairing bonus: if the residual after placement equals the item size,
    # a future identical item can close it exactly.
    score += (post == item).astype(np.float64) * 400.0

    # Reward completing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0

    # Two-sided commonness signal: reward residuals whose size is more common
    # than average, penalize rare residuals.
    common = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        common[valid] = (prob[idx] - 0.01) * 100.0   # 0.01 ~ uniform baseline
    score += common * 150.0

    # Two-item sum-completion lookahead: probability that the residual can be
    # exactly filled by the sum of two future items.  Computed only at the
    # residual values actually present (small set), using a cheap convolution
    # of the smoothed distribution restricted to reachable sums.
    if valid.any():
        idx = post_idx[valid]
        # Build pairwise-sum probability mass for sums up to 100.
        # p2[s] = sum_{a+b=s} prob[a]*prob[b]
        # We only need p2 at the distinct residual values.
        uniq = np.unique(idx)
        # Full pairwise convolution is 100x100 = 10k ops, cheap per call.
        p2 = np.convolve(prob[1:101], prob[1:101])  # index s-2 -> sum s
        pw = np.zeros_like(score)
        sums = post_idx[valid]
        # map sum s (2..200) to p2 index s-2
        p2v = p2[sums - 2]
        pw[valid] = p2v
        score += pw * 120.0

    # Sum-of-two-most-common stress: boost residuals that are exactly the sum
    # of the two currently most probable item sizes, so we steer toward
    # completions reachable by the two most likely future items.
    if valid.any():
        # Top-2 most probable item sizes (excluding residual 0 placeholder).
        order = np.argsort(prob[1:101])[::-1]
        a = order[0] + 1
        b = order[1] + 1
        target = a + b
        score += (post == target).astype(np.float64) * 200.0

    return score
# EVOLVE-BLOCK-END

