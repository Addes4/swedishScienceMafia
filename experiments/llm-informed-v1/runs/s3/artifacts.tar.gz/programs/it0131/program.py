# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and small-orphan avoidance."""
import numpy as np

_state = {
    "n": 0.0,
}


def priority(item, bins):
    """Rank bins by best-fit, with strong exact-fill preference.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1.0

    post = bins - item  # residual after placing item here

    # Dominant term: best fit (smallest post-placement residual).
    score = -post.astype(np.float64) * 10.0

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 1000.0

    # Prefer placing into a bin whose current residual exactly equals the item
    # (i.e. a planned pair) — outcomes well.
    score += (bins == item).astype(np.float64) * 50.0

    # Reward residual matching the item size (a future identical item fills it).
    score += (post == item).astype(np.float64) * 30.0

    # Discourage leaving tiny residuals (1..2), they are hard to fill exactly.
    small = (post >= 1) & (post <= 2)
    score -= small.astype(np.float64) * 20.0

    return score
# EVOLVE-BLOCK-END

