# EVOLVE-BLOCK-START
"""Best fit, with a tiny stateful tie-break that favors residuals that match
frequently seen small item sizes (helps consolidation without disturbing the
dominant best-fit ordering)."""
import numpy as np

_sizes = []
_hist = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    """Best-fit ranking plus a small residual-usefulness tie-break."""
    _sizes.append(item)
    _hist[item] += 1
    n = len(_sizes)

    # post-placement residual for every shown bin
    residual = bins - item

    # dominant term: tighter fit is better
    score = -residual.astype(np.float64)

    # small tie-break: reward residuals that are "useful" (match a common
    # small item size seen so far, avoiding stranded gaps)
    if n >= 50:
        # pick the most frequent small size (<= 40) seen so far
        small = _hist[1:41]
        if small.sum() > 0:
            common = int(np.argmax(small)) + 1
            # small bonus when post-placement residual can host that size
            # strictly, bonus is < 1 so it only breaks ties
            hit = (residual == common)
            score += 0.5 * hit

    return score
# EVOLVE-BLOCK-END
