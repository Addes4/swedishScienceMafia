# EVOLVE-BLOCK-START
"""Best fit plus a waste-aware penalty for residuals too small to ever fill."""
import numpy as np

_state = {"n": 0, "min_item": 101, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Rank bins: prefer tight fits, exact fills, and penalize unusable residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    hist = st["hist"]
    hist[item] += 1.0
    if item < st["min_item"]:
        st["min_item"] = item
    min_item = st["min_item"]

    post = bins - item
    # Base: best fit => smallest post-placement residual is best.
    score = -post.astype(np.float64)

    # Exact fill is always best.
    score += (post == 0).astype(np.float64) * 1000.0

    # Penalize residuals that are non-zero but smaller than the smallest item
    # seen so far: such gaps can never be closed and strand capacity.
    wasted = (post > 0) & (post < min_item)
    score -= wasted.astype(np.float64) * 500.0

    return score
# EVOLVE-BLOCK-END


