# EVOLVE-BLOCK-START
"""Best fit, but avoid leaving unusable dead-zone gaps in bins."""
import numpy as np

_SMALLEST = [100]  # mutable state: smallest item size seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item < _SMALLEST[0]:
        _SMALLEST[0] = item

    residual = bins - item  # remaining capacity after placing the item

    # Dead-zone threshold: residuals below this are likely unusable by future items.
    dead = _SMALLEST[0]

    # Best fit wants small residual. But residuals in (0, dead) are wasteful,
    # so treat them as if they were large (avoid creating them).
    effective = np.where((residual > 0) & (residual < dead), 1000 - residual, residual)

    return -effective.astype(np.float64)
# EVOLVE-BLOCK-END

