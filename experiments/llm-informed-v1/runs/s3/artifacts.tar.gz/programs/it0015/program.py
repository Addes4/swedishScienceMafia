# EVOLVE-BLOCK-START
"""Best fit with a small-residual guard to avoid creating unfillable slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Tightest fit first.
    best = -(residual.astype(np.float64))

    # Discourage leaving a very small residual (a sliver) when a
    # slightly looser bin would still leave room to fit another item.
    sliver = residual < item
    usable = residual >= item
    if usable.any():
        best = best + sliver * (-2.0 * item)

    return best
