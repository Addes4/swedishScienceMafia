# EVOLVE-BLOCK-START
"""Best fit with a nonlinear preference for near-exact fills."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Reward exact/near-exact fills strongly; penalize large leftovers.
    # Smaller residual -> higher score. Use reciprocal weighting on (residual + 1).
    return -residual.astype(np.float64) - 50.0 / (residual + 1.0)
# EVOLVE-BLOCK-END
