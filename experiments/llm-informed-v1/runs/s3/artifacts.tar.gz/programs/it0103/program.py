# EVOLVE-BLOCK-START
"""Best fit with an empirically learned "residual is closeable" bonus.

We keep best-fit as the primary ordering (smallest post-residual wins), then add a
bonus when the post-placement residual equals a value that we have frequently
observed being exactly filled in the past (residual == arriving item). This steers
open bins toward residuals that the item stream actually tends to close, reducing
long-lived half-full bins.
"""
import numpy as np

_state = {
    "n": 0,
    "open_res": {},          # residual -> count of open bins (our own tracking)
    "close_ok": np.zeros(101, dtype=np.float64),  # times residual r was exactly filled
    "r_seen": np.zeros(101, dtype=np.float64),     # times we left residual r
}


def priority(item, bins):
    """Rank bins: best fit first, plus bonus for residuals that historically get closed.

    item: integer size 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    st = _state
    st["n"] += 1
    close_ok = st["close_ok"]
    r_seen = st["r_seen"]

    post = bins - item
    # Primary: best fit => smallest post-placement residual is best.
    score = -post.astype(np.float64)

    # Exact fill is always best.
    exact = (post == 0)
    score += exact.astype(np.float64) * 1000.0

    post_idx = np.clip(post, 0, 100).astype(np.int64)
    rate = close_ok[post_idx] / (r_seen[post_idx] + 8.0)  # smoothed closure rate
    score += rate * 300.0

    # We are completing a bin whose residual matches the item: strong signal.
    score += (bins == item).astype(np.float64) * 400.0

    # Update empirical stats with this decision's outcome for the chosen bin
    # (approx: mark the residual we are leaving, and mark closures).
    # Determine chosen bin (max score, first tie).
    best = int(np.argmax(score))
    r = int(post[best])
    if 1 <= r <= 100:
        r_seen[r] += 1.0
    cur = int(bins[best])
    if 1 <= cur <= 100:
        # we exactly filled a bin that had residual == item
        if cur == item:
            close_ok[cur] += 1.0

    return score
# EVOLVE-BLOCK-END
