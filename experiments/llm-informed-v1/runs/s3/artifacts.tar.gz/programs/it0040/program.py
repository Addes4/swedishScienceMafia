# EVOLVE-BLOCK-START
"""Best fit, with a dead-gap-aware rule for large items."""
import numpy as np

_state = {"res": None}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = len(bins)
    # Reconstruct/lazy-init our own residual view from the harness array.
    # bins is a copy of the full residual array for bins that fit; but we only see
    # fitting bins. On the first call every bin has residual 100.
    if _state["res"] is None or len(_state["res"]) != n:
        _state["res"] = np.full(n, 100, dtype=np.int64)

    res = _state["res"]
    # bins corresponds to bins where res >= item. Since harness shrinks the array to
    # only fitting bins, we need to map. We use the fact that we tracked residuals.
    fits_mask = res >= item
    fit_idx = np.nonzero(fits_mask)[0]

    # If harness provided a different-length array (fits only), rely on our own view.
    if len(fit_idx) == len(bins):
        cur = res[fit_idx]
    else:
        cur = bins  # fall back to what we were given
        fit_idx = np.arange(len(bins))

    after = cur - item

    if item >= 70:
        # Large item: avoid leaving a tiny dead gap.
        # Reward exact fill (after==0) most; else prefer after>=30 (still usable); else small after.
        score = np.empty(len(cur), dtype=np.float64)
        exact = after == 0
        usable = (after >= 30) & (after <= 69)
        score[exact] = 3.0
        score[usable] = 2.0 - after[usable] / 1000.0
        dead = ~exact & ~usable
        score[dead] = 1.0 - after[dead] / 1000.0
    else:
        score = -after.astype(np.float64)

    # Update our residual tracking: chosen bin is argmax (first on ties).
    choice = int(np.argmax(score))
    chosen_bin = int(fit_idx[choice])
    res[chosen_bin] -= item

    # The harness will not call us for bins that don't fit, but we still track them.
    # Note: we don't know when the harness rejects; but harness never rejects since we pick a fitting bin.
    out = np.full(n, -np.inf)
    out[fit_idx] = score
    return out
# EVOLVE-BLOCK-END

