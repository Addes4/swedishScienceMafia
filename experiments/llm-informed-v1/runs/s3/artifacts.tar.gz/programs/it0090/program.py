# EVOLVE-BLOCK-START
"""Hybrid: best-fit for small items, worst-fit for large items.

We track our own view of every open bin's residual (the harness only shows bins the
current item fits in, but we chose the bin ourselves, so we can rebuild full state).
For large items we prefer the fullest bin that still fits (worst-fit / least residual),
which keeps larger open bins available for future large items.  For small items we use
classic best-fit.
"""
import numpy as np

_cap = 100
_res = []          # residual capacity of every bin we know about, in bin order
_thresh = 66       # items > 2/3 capacity are "large"


def priority(item, bins):
    global _res
    n = len(bins)

    # Rebuild / sync our view of all bins from the visible ones.
    # bins holds residual of bins the item fits in, in bin order; bins it does not
    # fit in have residual < item.  We cannot see those, so we track them ourselves.
    if len(_res) < n:
        # New bins appeared: fill unknown slots.  Unknown ones are bins the item
        # does not fit into; we have no exact value, so use a sentinel below item.
        known = list(bins)
        new = [100] * n
        # Map visible residuals onto our tracked array in order.
        # We know our tracked residuals for existing indices; overwrite with truth
        # where the harness shows them (these are exactly the fitting bins in order).
        vis_iter = iter(known)
        for i in range(n):
            if i < len(_res):
                new[i] = _res[i]
        # Now correct entries the harness reports: it gives residuals for fitting bins
        # in bin order; we re-derive by matching.  Simpler: trust _res where set, and
        # for any bin we don't know set to item-1 (does not fit).
        _res = new

    # Update our knowledge lazily: bins array only contains fitting bins.  We cannot
    # map them by index reliably, so instead maintain state purely from our choices.
    # Use the visible array only to build the candidate scores via our residuals.
    scores = np.empty(len(bins), dtype=np.float64)

    if item > _thresh:
        # Worst-fit among fitting bins: choose the fullest (smallest residual).
        # Post-placement residual = bins - item; smaller means fuller.
        return -(bins - item) * -1.0  # maximize residual -> worst fit
    else:
        # Best-fit.
        return -(bins - item)
# EVOLVE-BLOCK-END

