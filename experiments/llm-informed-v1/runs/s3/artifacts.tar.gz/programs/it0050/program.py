# EVOLVE-BLOCK-START
"""Best fit with exact-complement pairing: try to find a bin whose residual after
placing the item equals the item size (i.e. residual_before == 2*item), so that the
leftover gap can hold an identical item; otherwise use tightest (best) fit.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual_after = bins - item
    # Exact-complement pairing: prefer residual_after == item (gap can hold another copy).
    exact = (residual_after == item).astype(np.float64) * 1000.0
    # Otherwise tightest fit: smaller residual_after is better.
    return exact - residual_after
# EVOLVE-BLOCK-END

