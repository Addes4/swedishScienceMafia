# EVOLVE-BLOCK-START
"""Harmonic-style bin choice: route items by size class to reduce fragmentation."""
import numpy as np

# State: classify items online into coarse size classes and steer residuals.
_state = {"count": 0}


def _class_of(item):
    # Harmonic-like size classes for capacity 100.
    if item > 50:
        return 5
    if item > 33:
        return 4
    if item > 25:
        return 3
    if item > 20:
        return 2
    if item > 10:
        return 1
    return 0


def priority(item, bins):
    """Score bins by a harmonic-style rule; higher wins, ties to earlier bin."""
    # Pure best-fit score baseline.
    tight = -(bins - item)
    if item > 50:
        # Large items: best fit (tightest feasible residual).
        return tight.astype(np.float64)

    # For smaller items, prefer residuals that fall just below a class boundary,
    # i.e. place the item so the leftover is as small as possible but if the
    # leftover would cross into a "useful" class boundary, take that bin.
    residual = bins - item  # >= 0 for feasible bins
    cls = _class_of(item)

    # Compute score: strongest preference for tightest fit, but add a bonus
    # when the resulting residual sits at or just below a class boundary
    # (boundaries chosen so remaining chunks remain combinable).
    boundaries = np.array([0, 10, 20, 25, 33, 50], dtype=np.int64)
    # Distance of residual to nearest boundary from above.
    dist = np.full(residual.shape, 10**6, dtype=np.int64)
    for b in boundaries:
        mask = residual >= b
        cand = residual - b
        dist = np.where(mask & (cand < dist), cand, dist)

    # Lower residual is better (best fit); smaller distance to a boundary is
    # a mild secondary bonus.
    score = -(residual.astype(np.float64)) * 4.0 - dist.astype(np.float64)
    return score


# EVOLVE-BLOCK-END
