# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and an adaptive, distribution-calibrated
future-fill lookahead scaled by the number of items left."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Adaptive calibrator: average probability of a random item size, so we can
    # express fill likelihood as a dimensionless ratio relative to the typical size.
    mean_prob = prob[1:101].mean()
    if mean_prob <= 0.0:
        mean_prob = 1.0 / 100.0
    fill_ratio = p_fill / mean_prob  # 1.0 ~ typical, >1 ~ unusually common residual

    # Expected number of future exact single-item fills for this residual.
    remaining = max(n_items - total, 0.0)
    exp_fill = remaining * p_fill

    # Lookahead: reward residuals whose size is unusually likely relative to the
    # distribution (dimensionless), staying a mild tie-breaker behind best-fit.
    score += fill_ratio * 40.0

    # Reward placing into a bin whose residual before placement == item,
    # closing the bin exactly.
    score += (bins == item).astype(np.float64) * 400.0

    # Expected-exact-fill term: mildly prefer residuals that are likely to
    # be closed by a future item, and shrink as the instance ends so we stop
    # hoarding residuals we can no longer fill.
    score += exp_fill * 60.0

    return score
# EVOLVE-BLOCK-END

