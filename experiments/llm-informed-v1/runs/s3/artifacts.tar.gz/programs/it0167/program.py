# EVOLVE-BLOCK-START
"""Best-fit with a stable distribution-aware completion lookahead.

The item-size distribution is Weibull-shaped with mean ~40.  Instead of relying
on a noisy running histogram for the lookahead probabilities (which is poor
early in an instance), we build a smooth static PMF over sizes 1..100 and use
it for the exact-fill / single-item-completion probabilities.  Best-fit remains
the dominant base; exact fill is strongly preferred.
"""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
    "pmf": None,
}


def _build_pmf(hist, total):
    """Smooth item-size PMF over 1..100 blending a running histogram with a
    Weibull-shaped prior (mean ~40).  Returns array indexed 1..100."""
    # Weibull prior matched to mean ~40 with moderate shape (k=2, lambda such
    # that mean = lambda*Gamma(1+1/k) = 40 -> lambda ~ 45.1).
    k = 2.0
    lam = 45.0
    sizes = np.arange(1, 101, dtype=np.float64)
    cdf = 1.0 - np.exp(-(sizes / lam) ** k)
    cdf_lo = 1.0 - np.exp(-((sizes - 1.0) / lam) ** k)
    prior = np.clip(cdf - cdf_lo, 1e-6, None)
    prior = prior / prior.sum()

    # Empirical with Laplace smoothing.
    emp = (hist[1:101] + 1.0)
    emp = emp / emp.sum()

    # Weight empirical more as data accumulates.
    w = min(1.0, total / 500.0)
    pmf = w * emp + (1.0 - w) * prior
    pmf = pmf / pmf.sum()
    return pmf


def priority(item, bins):
    """Rank bins by best-fit plus a distribution-aware completion bonus.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Distribution-aware single-item completion probability.
    pmf = st["pmf"]
    if pmf is None or (int(total) % 250) == 0:
        pmf = _build_pmf(hist, total)
        st["pmf"] = pmf

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = pmf[idx - 1]

    # Expected future completion signal (calibrated, modest weight so best-fit
    # stays dominant).
    score += p_fill * 300.0

    # Pairing bonus: residual equals item -> a future identical item closes it.
    score += (post == item).astype(np.float64) * 400.0

    # Reward completing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0

    # Two-item sum-completion lookahead using the static PMF.
    if valid.any():
        p2 = np.convolve(pmf, pmf)  # index s-2 -> sum s
        pw = np.zeros_like(score)
        sums = post_idx[valid]
        p2v = p2[sums - 2]
        pw[valid] = p2v
        score += pw * 120.0

    return score
# EVOLVE-BLOCK-END
