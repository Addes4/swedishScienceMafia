# EVOLVE-BLOCK-START
"""Best fit with frequency-weighted residual desirability."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of item sizes seen
}


def priority(item, bins):
    """Rank bins by best-fit, plus how fillable the leftover residual is.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Dominant term: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: strongly preferred (residual 0 is the perfect closure).
    score += (post == 0).astype(np.float64) * 1000.0

    # Desirability of leaving residual r: if r is a common item size, a future
    # item is likely to fill this bin exactly, which is good. Estimate the
    # probability a random future item equals r (Laplace-smoothed) and scale it
    # so it can only break near-ties among similar residuals.
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        prob = (hist[idx] + 1.0) / (total + 100.0)
        p_fill[valid] = prob
    # Weight by residual magnitude: leaving a small residual that is common is
    # much better than leaving a larger or rarer one.
    score += p_fill * 120.0

    return score
# EVOLVE-BLOCK-END

