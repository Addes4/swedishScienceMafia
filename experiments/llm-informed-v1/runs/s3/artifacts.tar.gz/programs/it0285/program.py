# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and a consolidation term that rewards
leaving a residual matching the residual already present in many open bins,
so partial bins are completed rather than proliferated."""
import numpy as np

_state = {
    "open_resid": {},   # residual capacity -> count of open bins (our own bookkeeping)
}

_INIT_DONE = {"done": False}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and residual consolidation.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    post = bins - item  # residual after placing item here
    post_f = post.astype(np.float64)

    # Base: best fit -> smallest residual after placement.
    score = -post_f

    # Exact fill is strongly preferred (closes a bin).
    score += (post == 0).astype(np.float64) * 10000.0

    # Consolidation: prefer residuals that already exist among the bins the
    # item fits in, so that equal residuals can later be merged by a matching
    # item. Count how often each post residual occurs in this array.
    counts = {}
    for r in post.tolist():
        if r >= 1:
            counts[r] = counts.get(r, 0) + 1

    for i in range(len(post)):
        r = int(post[i])
        if r >= 1:
            c = counts.get(r, 0)
            # reward matching an existing residual; small bins (close to full)
            # get slightly more weight since completing them is cheaper.
            score[i] += c * 40.0 + (100 - r) * 0.5

    return score
# EVOLVE-BLOCK-END
