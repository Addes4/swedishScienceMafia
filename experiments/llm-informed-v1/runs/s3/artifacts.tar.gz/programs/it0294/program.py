# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference, a stable priors-blended empirical
future-fill lookahead scaled by items left, complementary pairing, and a
pair-closure signal. Decayed item histogram is blended with a fixed
Weibull-shaped prior so lookahead probabilities are stable from the start."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.999


def _weibull_prior():
    """Fixed discrete Weibull(shape~1.5, scale~44) prior over item sizes 1..100."""
    j = np.arange(1, 101, dtype=np.float64)
    shape = 1.5
    scale = 44.0
    surv = np.exp(-(j / scale) ** shape)
    surv = 1.0 - surv
    pmf = np.diff(np.concatenate(([0.0], surv)))
    pmf = np.clip(pmf, 1e-6, None)
    pmf /= pmf.sum()
    return pmf  # length 100, index 0 -> size 1


_PRIOR = _weibull_prior()


def priority(item, bins):
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Fragmentation scaling, stable additive-on-magnitude version.
    mean_item = float((hist * np.arange(101, dtype=np.float64)).sum() / max(total, 1.0))
    if mean_item < 1.0:
        mean_item = 40.0
    small_resid = np.count_nonzero((bins > 0) & (bins < mean_item))
    frac_small = small_resid / max(len(bins), 1)
    score *= (1.0 + 3.0 * frac_small)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Blend decayed empirical histogram with fixed prior for stability.
    emp = (hist[1:101] + 1.0) / (total + 100.0)   # over sizes 1..100
    prior = _PRIOR                                  # over sizes 1..100
    w = total / (total + 150.0)                     # weight toward empirical
    prob = w * emp + (1.0 - w) * prior

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        p_fill[valid] = prob[post_idx[valid] - 1]

    remaining = max(n_items - st["n"], 0.0)
    exp_fill = remaining * p_fill

    score += p_fill * 300.0

    # Closing residual == item.
    score += (bins == item).astype(np.float64) * 400.0

    score += exp_fill * 60.0

    # Pair-closure lookahead.
    conv = np.convolve(prob, prob)
    # pair_prob[s] for s = 1..100 is conv index s-2
    p_pair = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_pair[valid] = conv[idx - 2]

    n_pairs = remaining * max(remaining - 1.0, 0.0) * 0.5
    pair_weight = min(n_pairs / max(n_items, 1.0), 5.0)
    score += p_pair * pair_weight * 4000.0

    # Mode-residual bonus.
    mode_idx = int(np.argmax(prob)) + 1
    p_mode = float(prob[mode_idx - 1])
    score += (post_idx == mode_idx).astype(np.float64) * p_mode * 800.0

    return score
# EVOLVE-BLOCK-END
