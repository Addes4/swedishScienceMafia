# EVOLVE-BLOCK-START
"""Best fit with a tie-break toward completing likely exact pairs."""
import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.int64),   # count of items of each size seen so far
    "count": 0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary rule: best fit (smallest resulting residual).
    Tie-break: prefer a bin whose resulting residual is a size frequently seen before
    (a likely future complement), which helps complete exact pairs.
    """
    h = _state["hist"]
    n = _state["count"]

    # resulting residual for each shown bin
    res = bins - item  # >= 0 since item fits

    # base best-fit score: prefer smaller residual
    score = -res.astype(np.float64)

    # tie-break bonus: small, strictly below 1 so it never overrides the base ordering
    # (base differences between distinct residuals are at least 1)
    if n >= 50:
        # relative frequency of each candidate residual size, smoothed
        total = float(n)
        freq = h.astype(np.float64) / total
        bonus = 0.5 * freq[res]  # in [0, 0.5)
        score = score + bonus

    _state["hist"][item] += 1
    _state["count"] = n + 1

    return score
# EVOLVE-BLOCK-END
