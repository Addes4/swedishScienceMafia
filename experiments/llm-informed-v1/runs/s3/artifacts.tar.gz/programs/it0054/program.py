# EVOLVE-BLOCK-START
"""Graded best-fit: classic tightest-fit, tie-broken by expected future reuse of the residual.

Idea: best-fit leaves the tightest residual, which is optimal locally. To avoid leaving
"dead" residuals that no future item can fill, we break near-ties (ties within a small
tolerance) in favor of residuals whose size is empirically common among items seen so far.

State:
- counts: histogram of item sizes seen so far (1..100).
- All ranking is derived from numpy operations on `bins`, plus the histogram for ties.
"""
import numpy as np

# Histogram of observed item sizes (index 0 unused). Module state persists across calls
# within one instance; each instance runs in a fresh process so it starts empty.
_hist = np.zeros(101, dtype=np.float64)
_seen = 0
_alpha = 3.0  # strength of the residual-utility tie-break term


def priority(item, bins):
    global _seen
    # Record the arriving item before deciding (it is part of the observed stream).
    _hist[item] += 1.0
    _seen += 1.0

    b = np.asarray(bins, dtype=np.float64)
    residual = b - float(item)  # remaining capacity after placing the item

    # Base score: exact best-fit (smaller residual -> higher score).
    base = -residual

    # Utility of a residual: how often items up to that size occurred, normalized.
    # A residual r is "useful" if many observed items could fit exactly into it,
    # i.e. hist of sizes <= r is large relative to r. We use the empirical density
    # of exact identity (hist[r]) with a fallback to cumulative feasibility.
    if _seen >= 8:
        # density at exact residual size
        dens = _hist
        cum = np.cumsum(dens)
        total = cum[-1]
        denom = np.maximum(cum, 1.0)
        # exact-size frequency, plus a small term for cumulative fillability
        util = (dens / total) + 0.02 * (cum / total)
        r_idx = np.clip(residual.astype(np.int64), 0, 100)
        util_r = util[r_idx]
    else:
        util_r = np.zeros_like(residual)

    # Only apply the tie-break within a narrow tolerance band around the best residual
    # to preserve classic best-fit ordering.
    best_res = residual.min()
    near = (residual <= best_res + 2.0).astype(np.float64)

    score = base + _alpha * near * util_r
    return score
# EVOLVE-BLOCK-END
