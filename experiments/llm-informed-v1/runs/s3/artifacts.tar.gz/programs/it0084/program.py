# EVOLVE-BLOCK-START
"""Best fit with a residual-completion bonus using online item-size statistics."""
import numpy as np

_state = {
    "seen": None,
    "last_bin": None,   # index of bin chosen for the last item (not used directly)
}


def priority(item, bins):
    """Rank bins: prefer tightest fit, with a bonus for making exact/complementary residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = len(bins)
    # Update running histogram of seen item sizes.
    if _state["seen"] is None:
        _state["seen"] = np.zeros(101, dtype=np.int64)
    _state["seen"][item] += 1
    seen = _state["seen"]

    # Base score: best fit -> most negative residual (i.e., tightest).
    resid = bins - item
    score = -(resid.astype(np.float64))

    # Frequent item sizes (count >= small threshold) among small items.
    # A residual matching a frequent small size can likely be filled later.
    # We add a small bonus for residuals equal to a frequent small size.
    total = seen.sum()
    if total > 50:
        # Frequent sizes (up to 50) that appear reasonably often.
        freq = seen[1:51]
        # normalize
        maxc = freq.max()
        if maxc > 0:
            freq_mask = freq >= max(1, int(0.02 * total))
            # Build a lookup: bonus for residual r = r if r in frequent set
            bonus_val = 0.5  # small relative to 1-unit residual differences
        else:
            freq_mask = np.zeros(50, dtype=bool)
            bonus_val = 0.0
    else:
        freq_mask = np.zeros(50, dtype=bool)
        bonus_val = 0.0

    # Apply bonus where residual is a frequent small size.
    if bonus_val > 0 and n > 0:
        r = resid
        mask = (r >= 1) & (r <= 50)
        idx = r[mask]
        add = freq_mask[idx - 1].astype(np.float64) * bonus_val
        score[mask] += add

    # Strong bonus for exact fit (residual 0): completing a bin is very valuable.
    score += (resid == 0).astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END
