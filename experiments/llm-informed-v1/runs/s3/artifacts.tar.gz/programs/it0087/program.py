# EVOLVE-BLOCK-START
"""Hybrid: best-fit for small items, worst-fit for large items."""
import numpy as np

THRESH = 50.0  # distinguish "large" (>=) from "small" (<) items


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item
    if item >= THRESH:
        # Large item: prefer the fullest bin it still fits in (worst-fit),
        # so big open bins stay available for many future small items.
        return residual.astype(np.float64)
    # Small item: best-fit, tightest pack.
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

