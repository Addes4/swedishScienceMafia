# EVOLVE-BLOCK-START
"""Best-fit with a residual-usefulness correction to avoid stranded fragments."""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Rank bins: maximize packing quality, i.e. minimize wasted leftover.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item
    # Best-fit base: strongly prefer tightest fitting bin (smallest leftover).
    score = -leftover.astype(np.float64)
    # Small bonus for leftovers that are more "useful" (close to typical item size),
    # so that a bin left with a moderate gap can still absorb another item well.
    # Penalize tiny stranded fragments slightly more than perfectly full bins.
    useful = np.exp(-((leftover - _MEAN) ** 2) / (2.0 * (25.0 ** 2)))
    score += 0.5 * useful
    return score
# EVOLVE-BLOCK-END
