# EVOLVE-BLOCK-START
"""Best fit with probabilistic future-exact-fill lookahead."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit plus probability a future item exactly fills the residual.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Lookahead: probability that a future single item exactly equals the
    # residual, estimated from the running histogram (Laplace-smoothed).
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    if valid.any():
        idx = post_idx[valid]
        prob = (hist[idx] + 1.0) / (total + 100.0)
        # Weight by the probability mass: filling a bin saves a full bin later.
        score[valid] += prob * (post[valid].astype(np.float64)) * 8.0

    return score
# EVOLVE-BLOCK-END

