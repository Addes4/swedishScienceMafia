# EVOLVE-BLOCK-START
"""Best fit with empirical future-fill lookahead and complementary pairing."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    # Number of items still to arrive (len(bins) == total items in instance).
    remaining = float(len(bins)) - total

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    # Expected number of future items that would exactly complete the residual,
    # using the fraction of items remaining to scale down as the instance ends.
    frac_rem = remaining / float(len(bins)) if len(bins) > 0 else 0.0
    scale = 300.0 * max(frac_rem, 0.0)
    fill_term = np.zeros_like(score)
    common = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p = prob[idx]
        fill_term[valid] = p * scale
        common[valid] = (p - 0.01) * 100.0

    score += fill_term
    score += common * 150.0

    return score
# EVOLVE-BLOCK-END
