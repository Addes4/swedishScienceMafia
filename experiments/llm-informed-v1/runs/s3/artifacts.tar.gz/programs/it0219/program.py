# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference, a stable empirical distribution
blended with a Weibull-shaped prior, future-fill probability weighting by
items remaining, and complementary single-item closure rewards."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
}

# Prior over item sizes: Weibull-shaped, mean ~40, mode ~35.
def _make_prior():
    k, lam = 2.0, 45.0
    x = np.arange(101, dtype=np.float64)
    pdf = np.where(x >= 1, (k / lam) * (x / lam) ** (k - 1.0) *
                   np.exp(-(x / lam) ** k), 0.0)
    pdf[0] = 0.0
    pdf /= pdf.sum()
    return pdf

_PRIOR = _make_prior()

_PRIOR_WEIGHT = 200.0  # strength of prior in Laplace smoothing


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future fill."""
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    # Laplace-smoothed distribution blending empirical counts with the prior.
    prob = (hist + _PRIOR_WEIGHT * _PRIOR) / (total + _PRIOR_WEIGHT)
    prob = prob / prob.sum()

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill is always best; scale modestly to avoid over-committing.
    score += (post == 0).astype(np.float64) * 50.0

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Prefer leaving residuals that a future single item can exactly fill,
    # weighted by how much of the instance remains.
    remaining = max(n_items - st["n"], 0.0)
    frac_remaining = remaining / max(n_items, 1.0)
    score += p_fill * 200.0 * frac_remaining

    # Prefer placing into a bin whose residual now equals the item, closing it.
    score += (bins == item).astype(np.float64) * 80.0

    return score
# EVOLVE-BLOCK-END
