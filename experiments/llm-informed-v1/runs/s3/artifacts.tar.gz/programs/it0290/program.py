# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference, complementary pairing, and a
pair-closure signal.  Item-size probabilities come from a fixed
Weibull-shaped prior (mean ~40) so the lookahead terms are stable and
noise-free, while a decayed histogram only mildly informs the mode term."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.999

# Fixed Weibull-shaped size prior, mean about 40.  Built once at import.
def _build_prior():
    rng = np.random.default_rng(12345)
    # Weibull with shape k=1.5 gives a skewed distribution; scale chosen so
    # the rounded, clipped mean is about 40.
    k = 1.5
    lam = 44.0
    samples = lam * rng.weibull(k, size=400000)
    idx = np.clip(np.round(samples).astype(np.int64), 1, 100)
    counts = np.bincount(idx, minlength=101).astype(np.float64)
    p = counts / counts.sum()
    return p

_PRIOR = _build_prior()          # index 0 unused (probability 0)
_PRIOR_PAIR = np.zeros(101, dtype=np.float64)
_conv = np.convolve(_PRIOR[1:101], _PRIOR[1:101])
_PRIOR_PAIR[1:101] = _conv[:100]


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    # exponential forgetting so the histogram reflects recent items
    hist *= _DECAY
    hist[item] += 1.0

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Scale best-fit strength with fragmentation: when many open bins have
    # small residuals, consolidating (best-fit) matters more.
    small_resid = np.count_nonzero((bins > 0) & (bins < 40))
    frac_small = small_resid / max(len(bins), 1)
    score *= (1.0 + 3.0 * frac_small)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    # Probability of a future exact single-item fill, from fixed prior.
    p_fill = np.zeros_like(score)
    if valid.any():
        p_fill[valid] = _PRIOR[post_idx[valid]]

    remaining = max(n_items - st["n"], 0.0)
    exp_fill = remaining * p_fill

    score += p_fill * 300.0

    # Reward placing into a bin whose residual before placement == item,
    # closing the bin exactly.
    score += (bins == item).astype(np.float64) * 400.0

    score += exp_fill * 60.0

    # Pair-closure lookahead: probability that this residual can be exactly
    # filled by a pair of typical future items (fixed prior convolution).
    p_pair = np.zeros_like(score)
    if valid.any():
        p_pair[valid] = _PRIOR_PAIR[post_idx[valid]]

    n_pairs = remaining * max(remaining - 1.0, 0.0) * 0.5
    pair_weight = min(n_pairs / max(n_items, 1.0), 5.0)
    score += p_pair * pair_weight * 4000.0

    # Mode-residual bonus: prefer leaving a residual equal to the most common
    # recent item size, weighted by how common it is.
    total = float(hist.sum())
    if total > 0:
        mode_idx = int(np.argmax(hist[1:101])) + 1
        p_mode = float(hist[mode_idx] / total)
    else:
        mode_idx = 40
        p_mode = 0.0
    score += (post_idx == mode_idx).astype(np.float64) * p_mode * 800.0

    return score
# EVOLVE-BLOCK-END

