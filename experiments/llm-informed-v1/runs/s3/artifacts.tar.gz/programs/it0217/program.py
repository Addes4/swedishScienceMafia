# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and empirical future-fill lookahead
scaled by the number of items left, with exponential forgetting of past items."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.9995


def priority(item, bins):
    """Rank bins by best-fit and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    # exponential forgetting so the distribution reflects recent items
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros(len(bins), dtype=np.float64)
    if valid.any():
        p_fill[valid] = prob[post_idx[valid]]

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred but bounded.
    score += (post == 0).astype(np.float64) * 200.0

    # Reward placing into a bin whose residual before placement == item,
    # closing the bin exactly.
    score += (bins == item).astype(np.float64) * 50.0

    # Expected future exact single-item fill for this residual.
    remaining = max(n_items - st["n"], 0.0)
    score += p_fill * 300.0

    # Future-fill lookahead scaled by remaining items (bounded).
    frac_remaining = remaining / max(n_items, 1.0)
    score += p_fill * frac_remaining * 800.0

    return score
# EVOLVE-BLOCK-END
