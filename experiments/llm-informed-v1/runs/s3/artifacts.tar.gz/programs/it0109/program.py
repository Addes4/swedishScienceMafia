# EVOLVE-BLOCK-START
"""Best fit with a bonus for leaving a residual matching a large seen item."""
import numpy as np

_state = {"n": 0, "hist": np.zeros(101, dtype=np.float64), "max_seen": 0}


def priority(item, bins):
    """Rank bins: prefer tight fits, exact fills, and residuals a big item can close.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    hist = st["hist"]
    hist[item] += 1.0
    if item > st["max_seen"]:
        st["max_seen"] = item

    post = bins - item
    # Base: best fit => smallest post-placement residual is best.
    score = -post.astype(np.float64)

    # Bonus: exact fill (no residue left) — always good.
    score += (post == 0).astype(np.float64) * 1000.0

    # Bonus: residual exactly equals the item size (perfect same-size pair).
    score += (post == item).astype(np.float64) * 500.0

    # Bonus: completing a bin whose current residual == item (planned pair).
    score += (bins == item).astype(np.float64) * 500.0

    # Bonus: leave a residual that a large already-seen item can close exactly.
    # Large items are hardest to place, so a residual equal to the largest seen
    # item is the most valuable to preserve/match.
    m = st["max_seen"]
    if m >= 1:
        score += (post == m).astype(np.float64) * 300.0

    # Anti-orphan guard: tiny non-zero residual (1..4) tends to strand capacity.
    small_orphan = (post >= 1) & (post <= 4)
    score -= small_orphan.astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END


