# EVOLVE-BLOCK-START
"""Best fit, but avoid stranding tiny residuals when placing large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base best-fit: prefer smaller residual (higher score).
    score = -residual.astype(float)
    if item >= 60:
        # For large items, penalize placements that leave a nearly-useless tiny gap,
        # and reward residuals that stay around 60 (can host another large item).
        bad = (residual < 15) & (residual > 0)
        score = score - 1000.0 * bad
        # Slight bonus for residuals close to 60 among used bins (residual < 100).
        used = bins < 100
        close60 = used & (np.abs(residual - 60) <= 5)
        score = score + 5.0 * close60
    return score
# EVOLVE-BLOCK-END

