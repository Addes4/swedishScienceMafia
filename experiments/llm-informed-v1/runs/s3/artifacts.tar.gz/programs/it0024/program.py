# EVOLVE-BLOCK-START
"""Best fit with an empty-bin reservation for large items.

Tracks the full packing state itself so it can make decisions using bins the
current item does not fit into, and keeps a policy that avoids stranding tiny
useless residuals when large items arrive.
"""
import numpy as np

_state = {
    "remaining": None,   # list of remaining capacities for all bins opened so far
    "n_items": 0,
    "seen": 0,
    "large_sum": 0,
}


def _init(n):
    _state["remaining"] = []
    _state["n_items"] = n
    _state["seen"] = 0
    _state["large_sum"] = 0


def priority(item, bins):
    n = len(bins)
    if _state["remaining"] is None or _state["n_items"] != n:
        _init(n)

    rem = _state["remaining"]

    # On the first call, bins is just the full set of unused bins.
    if _state["seen"] == 0:
        rem.clear()
        rem.extend([100] * n)

    _state["seen"] += 1

    # Build mapping from visible bins (those with remaining >= item) to my indices.
    # bins gives remaining capacities of fit bins in bin order; I reconstruct the
    # fit bins by scanning my own state.
    #
    # I need to return one score per entry of `bins`.  The entries of `bins`
    # correspond, in order, to the bins in my `rem` with rem[i] >= item.
    fit_indices = [i for i, r in enumerate(rem) if r >= item]

    # Guard: if my state diverged, fall back to best fit on given bins.
    if len(fit_indices) != len(bins):
        return -(bins - item)

    # Decide policy for this item.
    # Use observed large-item statistic to define "large".
    seen = _state["seen"]
    mean_large = (_state["large_sum"] / seen) if seen else 0.0

    # Prefer best fit (smallest usable residual), but if the best residual would
    # drop below a floor AND there is an unused bin available, consider opening a
    # fresh bin when the item is large enough that a stranded sliver would hurt.
    best_pos = -1
    best_res = None
    empty_pos = -1

    for pos, idx in enumerate(fit_indices):
        r = rem[idx]
        res = r - item
        if r == 100 and empty_pos < 0:
            empty_pos = pos
        if best_res is None or res < best_res:
            best_res = res
            best_pos = pos

    # Floor below which a residual is considered "stranded" for large items.
    floor = 15
    use_empty = False
    if item >= 30 and empty_pos >= 0 and best_res is not None and best_res < floor:
        # Opening a fresh bin: acceptable only if we don't already have many empties.
        n_empty = sum(1 for r in rem if r == 100)
        if n_empty <= 1:
            use_empty = True

    scores = np.zeros(len(bins), dtype=np.float64)
    if use_empty:
        scores[empty_pos] = 1.0
        scores[best_pos] = 0.0
    else:
        for pos, idx in enumerate(fit_indices):
            scores[pos] = -(rem[idx] - item)

    # Update my state: the chosen bin is the first with the highest score.
    chosen_pos = int(np.argmax(scores))
    chosen_idx = fit_indices[chosen_pos]
    rem[chosen_idx] -= item
    if item >= 30:
        _state["large_sum"] += item

    return scores
# EVOLVE-BLOCK-END
