# EVOLVE-BLOCK-START
"""Best fit that avoids opening fresh bins while a partially-filled bin fits."""
import numpy as np

_used = None  # boolean array: has this bin index ever received an item


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _used
    n = len(bins)
    if _used is None or len(_used) != n:
        _used = np.zeros(n, dtype=bool)

    # Which bin indices are these? The harness shows a subset (those fitting item),
    # in bin order. We reconstruct indices by matching residuals against our own view
    # is unreliable; instead we access residuals directly. `bins` here are the real
    # remaining capacities of the shown bins, but we don't know their global index.
    #
    # Simpler approach: distinguish used vs unused purely by capacity. An unused bin
    # has remaining capacity exactly 100. A used bin also can have 100 only if empty
    # of items, which is false by definition. So capacity==100 <=> unused open bin.
    is_unused = bins == 100

    # Best fit: minimize post-placement residual = bins - item.
    post = bins - item

    # Primary: prefer already-used bins (post-placement residual as tiebreak).
    # Secondary: among used bins, smallest residual (best fit).
    # Unused bins get a large penalty so they are only chosen if nothing used fits.
    # Note: penalty must dominate the residual range (0..99) but stay finite.
    score = -post.astype(np.float64)
    score = np.where(is_unused, score - 1e6, score)
    return score
# EVOLVE-BLOCK-END
