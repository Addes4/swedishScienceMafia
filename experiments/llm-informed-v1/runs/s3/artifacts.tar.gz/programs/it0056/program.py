# EVOLVE-BLOCK-START
"""Best fit with a penalty for creating useless tiny residual slivers."""
import numpy as np

_state = {"min_seen": 101}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    if item < _state["min_seen"]:
        _state["min_seen"] = item
    min_seen = _state["min_seen"]

    r = bins - item  # resulting residual, >= 0 for shown bins

    # Base: best fit -> prefer smallest residual.
    score = -r.astype(np.float64)

    # Penalize useless tiny slivers: residual in (0, min_seen) can never be filled
    # by any item seen so far (best-case), so discourage creating them.
    unusable = (r > 0) & (r < min_seen)
    score[unusable] -= 0.5

    return score
# EVOLVE-BLOCK-END
