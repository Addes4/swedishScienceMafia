# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference, parametric future-fill lookahead
scaled by items left, complementary pairing, and a pair-closure signal.
The future item-size distribution is approximated by a fixed Weibull-shaped
pmf (mean ~40) rather than a noisy running empirical histogram."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
}

_DECAY = 0.999


def _build_pmf():
    """Discrete pmf on 1..100 from a Weibull-shaped (k=1.5) distribution
    scaled to mean ~40, then truncated and renormalized."""
    # Weibull with shape k, scale lam => mean = lam * Gamma(1 + 1/k)
    k = 1.5
    from math import gamma
    lam = 40.0 / gamma(1.0 + 1.0 / k)
    x = np.arange(0.5, 100.5, 1.0)  # bin centers for integer sizes 1..100
    # survival-based discrete mass on integers 1..100
    cdf = 1.0 - np.exp(-((x / lam) ** k))
    cdf = np.concatenate([[0.0], cdf])  # edges
    pm = np.diff(cdf)  # mass for sizes 1..100 (approx)
    pm = np.maximum(pm, 0.0)
    pm = pm / pm.sum()
    return pm  # length 100, index i-1 for size i


_PMF = _build_pmf()


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Scale best-fit strength with fragmentation.
    mean_item = float((hist * np.arange(101, dtype=np.float64)).sum() / max(total, 1.0))
    if mean_item < 1.0:
        mean_item = 40.0
    small_resid = np.count_nonzero((bins > 0) & (bins < mean_item))
    frac_small = small_resid / max(len(bins), 1)
    score *= (1.0 + 3.0 * frac_small)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Parametric single-item fill probability for the residual.
    prob = (hist + 1.0) / (total + 100.0)  # used only for mode detection
    pmf = _PMF  # index i-1 for size i

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = pmf[idx - 1]

    remaining = max(n_items - st["n"], 0.0)
    exp_fill = remaining * p_fill

    score += p_fill * 300.0

    # Reward closing a bin exactly.
    score += (bins == item).astype(np.float64) * 400.0

    score += exp_fill * 60.0

    # Pair-closure lookahead using the parametric pmf.
    pair_prob = np.zeros(101, dtype=np.float64)
    conv = np.convolve(pmf, pmf)
    pair_prob[1:101] = conv[:100]
    p_pair = np.zeros_like(score)
    if valid.any():
        p_pair[valid] = pair_prob[post_idx[valid]]

    n_pairs = remaining * max(remaining - 1.0, 0.0) * 0.5
    pair_weight = min(n_pairs / max(n_items, 1.0), 5.0)
    score += p_pair * pair_weight * 4000.0

    # Mode-residual bonus (empirical mode, cheap and stable enough).
    mode_idx = int(np.argmax(prob[1:101])) + 1
    p_mode = float(prob[mode_idx])
    score += (post_idx == mode_idx).astype(np.float64) * p_mode * 800.0

    return score
# EVOLVE-BLOCK-END
