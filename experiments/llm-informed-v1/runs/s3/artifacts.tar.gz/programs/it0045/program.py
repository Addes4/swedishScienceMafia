# EVOLVE-BLOCK-START
"""Best fit with exact-residual matching from observed item sizes."""
import numpy as np

_seen = {}
_items = []


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Residual after placing this item in each bin.
    residual = bins - item

    # Exact-fill bonus: if a candidate bin's residual equals a size we've seen often,
    # that bin is likely to be completed by a future item of that size.
    # Score = tighter fit, but strongly prefer perfect residuals matching common sizes.
    score = -residual.astype(np.float64)

    # small bonus for residuals that exactly match a frequently seen item size
    if _seen:
        # count how many candidate residuals match a seen size (weight small)
        seen_sizes = np.fromiter(_seen.keys(), dtype=np.int64, count=len(_seen))
        for i, r in enumerate(residual):
            if r > 0 and int(r) in _seen:
                score[i] += 0.5

    # Track this item size for future exact-match bonuses.
    _seen[item] = _seen.get(item, 0) + 1
    return score
# EVOLVE-BLOCK-END

