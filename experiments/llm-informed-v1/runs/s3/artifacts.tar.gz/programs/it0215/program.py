# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and a Laplace-smoothed empirical
fill-probability term, with a mild penalty for leaving residuals that are
rare (hard to close later)."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
}

_DECAY = 0.999


def priority(item, bins):
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item
    score = -post.astype(np.float64)

    # Exact fill strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed probability of a future single item exactly filling
    # the residual.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        p_fill[valid] = prob[post_idx[valid]]

    remaining = max(n_items - st["n"], 0.0)

    # Reward residuals that a future item can exactly close.
    score += p_fill * 300.0
    score += remaining * p_fill * 60.0

    # Mild penalty for leaving a residual that is hard to fill (rare size):
    # prefer residuals whose expected future fill probability is higher.
    # Since p_fill already rewards likely-fillable residuals, this is handled.

    # Reward placing into a bin whose current residual == item (closes it exact).
    score += (bins == item).astype(np.float64) * 400.0

    return score
# EVOLVE-BLOCK-END
