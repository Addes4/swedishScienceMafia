# EVOLVE-BLOCK-START
"""Best fit, with protection of bins needed for large items."""
import numpy as np

# module-level state, reset each instance
_res = None          # residual capacity of every bin (list of ints)
_cap = 100


def priority(item, bins):
    global _res

    n = len(bins)

    # (Re)initialize my own residual view of the world.
    # On the first call all bins are unused (capacity 100).
    if _res is None or len(_res) != n:
        _res = [100] * n

    # --- scalar score per bin: classic best fit (smaller residual after placement is better)
    after = bins - item
    score = -after.astype(np.float64)

    # --- protection: for small items, mildly discourage dropping a bin's residual
    #     below a threshold that would waste the slot for a large item.
    if item <= 25:
        # a bin is "valuable" if its current residual is large enough to still
        # hold a big item; placing a small item there risks losing that slot.
        cur = np.asarray(_res, dtype=np.int64)
        # only these bins are the ones shown; they index into the same order
        # (bins array is the subset that fits, in bin order) -> we must map.
        # We rely on: bins passed == residuals of bins it fits in, same order as _res filtered.
        # Since we can't easily map, reconstruct scores only for shown bins:
        cur_shown = bins
        penalty = np.zeros(n, dtype=np.float64)
        # discourage: current residual big (room for a large item) AND after-placement
        # residual small (slot wasted) AND not a perfect/very-tight fit
        big_now = cur_shown >= 60
        small_after = after < 40
        tight = after < item          # would leave a small leftover
        waste = big_now & small_after
        penalty[waste] = 0.5
        # exact-fit placements are always good; don't penalize them
        penalty[after == 0] = 0.0
        # if the leftover is at least a decent item size, it's fine
        penalty[after >= 30] = 0.0
        score = score - penalty

    # update my residual tracker: we don't know which bin was chosen here,
    # so we only update on the next call by trusting the new `bins` values.
    # Instead: refresh residuals for shown bins from `bins`; unknown bins stay.
    if len(_res) == n:
        # best effort: `bins` are residuals of a subset; sync the whole array when
        # the subset length equals n (early phase) else leave as is.
        pass

    return score
# EVOLVE-BLOCK-END
