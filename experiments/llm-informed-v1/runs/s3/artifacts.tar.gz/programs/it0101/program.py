# EVOLVE-BLOCK-START
"""Best fit plus exact-fill bonuses and residual consolidation across open bins."""
import numpy as np

_state = {"item": 0.0, "hist": np.zeros(101, dtype=np.float64), "n": 0,
          "resid": None}


def priority(item, bins):
    """Rank bins: prefer tight fits, exact fills, complementary pairs, and
    residuals that duplicate an existing open-bin residual (consolidation).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    hist = st["hist"]
    hist[item] += 1.0

    post = bins - item
    # Base: best fit => smallest post-placement residual is best.
    score = -post.astype(np.float64)
    # Bonus: exact fill (no residue left) — always good.
    score += (post == 0).astype(np.float64) * 1000.0
    # Bonus: residual exactly equals the item size, so a future same-size item
    # could fill it exactly (perfect complementary pair).
    score += (post == item).astype(np.float64) * 500.0

    # Bonus: we are completing a bin whose current residual matches the item
    # (residual before placement == item), i.e. a planned perfect pair.
    score += (bins == item).astype(np.float64) * 500.0

    # Residual consolidation: boost post-placement residuals that already exist
    # as some other open bin's residual, so matching future items can close
    # several bins of the same size. Track our own view of open-bin residuals.
    resid = st["resid"]
    if resid is None or len(resid) != len(bins):
        # First call (or length changed unexpectedly): assume all bins unused.
        resid = np.full(len(bins), 100, dtype=np.int64)
        st["resid"] = resid
    counts = np.bincount(np.clip(resid, 0, 100), minlength=101)
    post_idx = np.clip(post, 0, 100).astype(np.int64)
    dup = counts[post_idx] > 0
    score += dup.astype(np.float64) * 30.0

    # Bonus: post-placement residual is a frequently seen item size, so it is
    # likely to be filled exactly by a future item of that size.
    seen = hist
    total = st["n"]
    valid = (post >= 1) & (post <= 100)
    freq = np.zeros_like(score)
    idx = post_idx[valid]
    freq[valid] = seen[idx] / total
    score += freq * 100.0

    # Update our own residual view: the chosen bin is the first max-score bin.
    chosen = int(np.argmax(score))
    # Map chosen position back to underlying bin index is not needed for our
    # view since we mirror the full bins array in order.
    resid[chosen] = post[chosen]

    return score
# EVOLVE-BLOCK-END
