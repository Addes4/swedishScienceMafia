# EVOLVE-BLOCK-START
"""Best fit with an online frequency-weighted residual-reuse bonus."""
import numpy as np

_state = {"counts": None, "seen": 0, "total": 0}


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties).

    Primary: tightest fit (smallest post-placement residual).
    Secondary: small bonus when the post-placement residual matches a frequently
    seen item size, so the leftover can likely be perfectly filled later.
    """
    k = len(bins)
    residual = bins - item  # all >= 0 since these bins fit

    # Maintain an empirical histogram of observed item sizes.
    counts = _state["counts"]
    if counts is None:
        counts = np.zeros(101, dtype=np.float64)
        _state["counts"] = counts
    counts[item] += 1.0
    _state["seen"] += 1

    # Frequency of each possible size (smoothed), normalized.
    freq = counts.copy()
    tot = freq.sum()
    if tot > 0:
        freq = freq / tot
    else:
        freq = freq * 0.0
    # size 0 (perfect fill) is always valuable
    freq[0] = freq.max() if tot > 0 else 1.0

    bonus = freq[np.clip(residual, 0, 100)]

    # Combine: tightness dominates; bonus only breaks near-ties.
    scale = 0.5
    return -(residual.astype(np.float64)) + scale * bonus
# EVOLVE-BLOCK-END

