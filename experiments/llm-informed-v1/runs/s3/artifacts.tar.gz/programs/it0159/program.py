# EVOLVE-BLOCK-START
"""Best fit with a calibrated single-item completion-probability bonus."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit plus a calibrated completion probability.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Laplace-smoothed item-size distribution (probability of each size).
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    # Calibrated single-item completion probability in [0,1]:
    # probability that some future item exactly equals the residual.
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Weight chosen to span roughly one item-size unit so it refines
    # best-fit ties without overwhelming the -post base.
    score += p_fill * 50.0

    # Exact fill is strictly optimal: strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    return score
# EVOLVE-BLOCK-END
