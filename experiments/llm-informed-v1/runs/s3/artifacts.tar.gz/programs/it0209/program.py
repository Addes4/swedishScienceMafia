# EVOLVE-BLOCK-START
"""Best fit with a light empirical future-fill preference and exact-fill
preference, using a stable full-history item-size distribution."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 100.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Reward leaving a residual that a typical future item can exactly fill.
    score += p_fill * 20.0

    # Reward placing into a bin whose residual before placement == item,
    # closing the bin exactly.
    score += (bins == item).astype(np.float64) * 30.0

    return score
# EVOLVE-BLOCK-END
