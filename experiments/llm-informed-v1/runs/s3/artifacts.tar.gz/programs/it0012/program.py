# EVOLVE-BLOCK-START
"""Best-fit with a mild distribution-aware residual preference."""
import numpy as np

_seen = None
_hist = None


def priority(item, bins):
    global _seen, _hist
    if _seen is None:
        _seen = np.zeros(101, dtype=np.int64)
    _seen[item] += 1

    residual = bins - item  # remaining capacity after placing the item (>= 0)
    # Base: prefer tightest fit (small residual)
    score = -residual.astype(np.float64)

    # Mild bonus: residual values that are common observed item sizes are more
    # likely to be exactly filled by a future item, so slightly prefer them.
    # Normalize the histogram to [0,1].
    total = _seen.sum()
    if total > 0:
        counts = _seen[1:101].astype(np.float64) / total
        # residual in 0..100 -> index residual-1 for residual>=1; residual 0 gets max importance
        idx = np.clip(residual, 1, 100) - 1
        bonus = counts[idx]
        bonus = np.where(residual == 0, 1.0, bonus)
        score = score + 0.5 * bonus

    return score
# EVOLVE-BLOCK-END
