# EVOLVE-BLOCK-START
"""Best fit with empirical single-item completion lookahead and exact-fill bias.

The item goes into the bin that leaves the residual most likely to be exactly
filled by a future item (estimated from the running histogram), with a strong
preference for perfect fills and a best-fit tie-break.
"""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Lookahead: probability that a future single item exactly equals the
    # residual after placement. Scaled to only refine among near-best-fit
    # candidates (max contribution ~ few residual units).
    score += p_fill * 300.0

    # Pairing bonus: if the residual after placement equals the item size,
    # a future identical item can close it exactly.
    score += (post == item).astype(np.float64) * 400.0

    # Reward completing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0

    return score
# EVOLVE-BLOCK-END
