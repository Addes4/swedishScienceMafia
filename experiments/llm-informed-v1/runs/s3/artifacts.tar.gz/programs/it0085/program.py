# EVOLVE-BLOCK-START
"""Best fit with a small secondary bias toward filling bins tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize residual after placement (best fit).
    # Secondary: prefer bins whose residual is small relative to the item,
    # which corresponds to placing the item where it nearly saturates the bin.
    return -residual - 0.001 * (residual - item)
# EVOLVE-BLOCK-END
