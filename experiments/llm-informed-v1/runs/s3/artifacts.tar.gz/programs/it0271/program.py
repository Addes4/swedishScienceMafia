# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference, a prior-blended future-fill
lookahead scaled by items remaining, and a complementary-pair closure
signal, with exponential forgetting of past items."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.998

# Fixed Weibull-shaped prior (mean ~40) used to stabilize early estimates.
_prior = None


def _build_prior():
    global _prior
    xs = np.arange(0, 101, dtype=np.float64)
    k, lam = 2.0, 45.0
    pdf = (k / lam) * (xs / lam) ** (k - 1.0) * np.exp(-(xs / lam) ** k)
    pdf[0] = 0.0
    s = pdf.sum()
    if s > 0:
        pdf = pdf / s
    _prior = pdf


if _prior is None:
    _build_prior()


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of future fills."""
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))
    remaining = max(n_items - st["n"], 0.0)

    post = bins - item
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    # Base: best-fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Blend empirical histogram with the fixed prior for stability.
    emp = hist[1:101]
    emp_sum = emp.sum()
    # weight grows with evidence
    w = emp_sum / (emp_sum + 200.0)
    prob_body = (1.0 - w) * (_prior[1:101] / max(_prior[1:101].sum(), 1.0)) \
                + w * ((emp + 1.0) / (emp_sum + 100.0))
    prob = np.zeros(101, dtype=np.float64)
    prob[1:101] = prob_body

    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Expected number of future exact single-item fills for residual.
    exp_fill = remaining * p_fill
    score += p_fill * 250.0
    score += exp_fill * 50.0

    # Pair-closure lookahead: probability residual is exactly filled by a
    # pair of typical future items.
    p = prob[1:101]
    conv = np.convolve(p, p)
    pair_prob = np.zeros(101, dtype=np.float64)
    pair_prob[1:101] = conv[:100]

    p_pair = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_pair[valid] = pair_prob[idx]

    n_pairs = remaining * max(remaining - 1.0, 0.0) * 0.5
    pair_weight = min(n_pairs / max(n_items, 1.0), 4.0)
    score += p_pair * pair_weight * 2500.0

    return score
# EVOLVE-BLOCK-END
