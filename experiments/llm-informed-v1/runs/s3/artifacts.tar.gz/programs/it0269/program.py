# EVOLVE-BLOCK-START
"""Robust best-fit with exact-fill preference and a mild capacity-usage
tie-break. Uses a light empirical histogram only for a small residual-usability
signal, avoiding high-variance convolution terms."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
}

_DECAY = 0.999
# A coarse fixed prior for item sizes (Weibull-shaped, mean ~40).
_PRIOR = np.zeros(101, dtype=np.float64)
for _s in range(1, 101):
    _PRIOR[_s] = (0.0206 * (_s / 20.0) ** 1.5) * np.exp(-((_s / 20.0) ** 1.5))
_PRIOR[0] = 0.0
_PRIOR /= _PRIOR.sum()


def priority(item, bins):
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))
    n_seen = st["n"]

    bins_f = bins.astype(np.float64)
    post = bins_f - item  # residual after placing item here

    # Base: best fit -> smallest post-placement residual.
    score = -post

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Usability of the leftover: reward residuals that match a common item size,
    # using a blend of the fixed prior and the empirical histogram (smoothed).
    if total > 0:
        emp = hist / total
    else:
        emp = _PRIOR
    w = min(n_seen / 500.0, 1.0)  # trust empirical more as data accumulates
    prob = w * emp + (1.0 - w) * _PRIOR
    prob = (prob + 1e-3) / (prob.sum() + 0.101)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        p_fill[valid] = prob[post_idx[valid]]

    # Mild preference for residuals that are likely to be filled exactly soon.
    score += p_fill * 40.0

    # Small tie-break: prefer bins whose pre-placement residual is closer to a
    # common item size (i.e., bins that are "about to be usable").
    return score
# EVOLVE-BLOCK-END
