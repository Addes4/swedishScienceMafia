# EVOLVE-BLOCK-START
"""Best fit with exact-complement pairing, weighted by the likelihood that a
future item actually realizes the complementary residual."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    # Laplace-smoothed probability that a future item exactly equals the residual.
    p_match = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_match[valid] = (hist[idx] + 1.0) / (total + 100.0)

    # Lookahead: probability that a future single item exactly fills the residual.
    score += p_match * 300.0

    # Pairing bonus: residual equals the item size -> a future identical item can
    # close it exactly. Weight it by how likely such an item actually arrives, so
    # we only create complementary residuals that have a real chance of closing.
    pair_ok = (post == item)
    pair_ok &= (p_match > 1.5 / (total + 100.0))  # only if size is not vanishingly rare
    score += pair_ok.astype(np.float64) * 400.0

    # Reward completing a bin whose residual before placement == item (a planned pair).
    score += (bins == item).astype(np.float64) * 400.0

    # Reward residuals that are themselves common item sizes (likely to be
    # matched soon by a future item of that exact size).
    common = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        common[valid] = np.minimum(hist[idx] / (total + 1.0), 0.05)
    score += common * 8000.0

    # Small anti-orphan guard for tiny non-zero residuals (1..4).
    small_orphan = (post >= 1) & (post <= 4)
    score -= small_orphan.astype(np.float64) * 3.0

    return score
# EVOLVE-BLOCK-END


