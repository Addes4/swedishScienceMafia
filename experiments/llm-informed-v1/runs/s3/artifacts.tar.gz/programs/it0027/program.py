# EVOLVE-BLOCK-START
"""Bounded best-fit: tightest fit, but break near-ties in favor of a residual
that is itself a likely future item size."""
import numpy as np

_state = {"seen": 0, "hist": np.zeros(101, dtype=np.int64)}


def priority(item, bins):
    st = _state
    st["seen"] += 1

    # strict best fit residual
    resid = bins - item  # residual after placing
    best = resid.min()

    # tolerance band: within a small slack of the tightest fit
    tol = max(1, item // 8)
    mask = resid <= best + tol

    # among near-ties, prefer a residual likely to be reused: high-frequency
    # residuals from the observed history get a bonus (bin with residual ->
    # after placement leaves `resid`; we want resid to be a common item size).
    hist = st["hist"]
    # score: prefer smaller residual, plus bonus if residual is a frequent size
    score = -resid.astype(np.float64)
    # bonus for common future-item residuals, scaled small
    bonus = hist[np.clip(resid, 0, 100)].astype(np.float64)
    total = hist.sum()
    if total > 0:
        score = score + (bonus / total) * 5.0

    # outside the tolerance band, strictly worse
    score = np.where(mask, score, score - 1000.0)

    return score
# EVOLVE-BLOCK-END
