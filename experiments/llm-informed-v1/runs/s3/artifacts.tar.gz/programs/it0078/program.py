# EVOLVE-BLOCK-START
"""Distribution-aware best fit: reward post-residuals that match frequent item sizes."""
import numpy as np

_state = {"hist": None, "seen": 0, "n": 0, "conf": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state
    if st["hist"] is None:
        st["hist"] = np.zeros(101, dtype=np.float64)
        st["n"] = len(bins)  # first call: len(bins) == total items
    st["seen"] += 1

    residual = bins.astype(np.int64)
    post = residual - item

    # Base: best fit (smallest nonneg post residual preferred).
    score = -post.astype(np.float64)

    # Perfect fit gets a strong bonus.
    score[post == 0] += 2.0

    # Utility: fraction of past items whose size == post residual (how likely
    # this leftover can be exactly filled by one future item).
    seen = st["seen"]
    if seen > 20:
        hist = st["hist"]
        # match probability for each candidate post residual
        prob = hist[post] / seen
        # only reward reasonable residuals (1..99)
        bonus = np.where((post > 0) & (post < 100), prob, 0.0)
        # scale so it breaks ties without overturning clear best-fit gains
        score += bonus * 3.0

    # record this item AFTER scoring
    st["hist"][item] += 1.0

    return score
# EVOLVE-BLOCK-END
