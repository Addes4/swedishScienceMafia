# EVOLVE-BLOCK-START
"""Best fit with a smoothed, prior-blended 'closable residual' lookahead."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
}

_DECAY = 0.999


def priority(item, bins):
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))
    post = bins - item
    post_f = post.astype(np.float64)

    # Base: best fit -> smallest residual after placing item here.
    score = -post_f

    # Fragmentation pressure: when many bins have tiny residuals, consolidating
    # (best-fit) matters more.
    mean_item = float((hist * np.arange(101, dtype=np.float64)).sum() / max(total, 1.0))
    if mean_item < 1.0:
        mean_item = 40.0
    small_resid = np.count_nonzero((bins > 0) & (bins < mean_item))
    frac_small = small_resid / max(len(bins), 1)
    score *= (1.0 + 3.0 * frac_small)

    # Exact fill is essentially perfect.
    score += (post == 0).astype(np.float64) * 100000.0

    # Laplace-smoothed empirical distribution blended with a Weibull prior.
    prob = (hist + 1.0) / (total + 100.0)
    prior = _weibull_prior()
    prob = 0.7 * prob + 0.3 * prior
    prob /= prob.sum()

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    # Reward leaving a residual that a single future item is likely to close
    # exactly. This strongly prefers commonly-fillable leftovers.
    p_fill = np.zeros_like(score)
    if valid.any():
        p_fill[valid] = prob[post_idx[valid]]
    score += p_fill * 400.0

    # Multiple-opportunity single-fill lookahead, scaled by remaining items.
    remaining = max(n_items - st["n"], 0.0)
    score += p_fill * remaining * 3.0

    # Reward choosing a bin whose current residual exactly equals this item
    # (closes the bin by this placement).
    score += (bins == item).astype(np.float64) * 800.0

    return score


_prior_cache = {}


def _weibull_prior():
    if "p" in _prior_cache:
        return _prior_cache["p"]
    # Weibull-shaped prior, mean ~40, over sizes 1..100, normalised.
    x = np.arange(101, dtype=np.float64)
    k, lam = 1.5, 45.0
    shape = (k / lam) * (x / lam) ** (k - 1.0) * np.exp(-((x / lam) ** k))
    shape[0] = 0.0
    s = shape[1:101].sum()
    p = np.zeros(101, dtype=np.float64)
    p[1:101] = shape[1:101] / max(s, 1e-12)
    _prior_cache["p"] = p
    return p
# EVOLVE-BLOCK-END

