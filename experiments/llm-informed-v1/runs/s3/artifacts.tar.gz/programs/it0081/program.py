# EVOLVE-BLOCK-START
"""Size-class aware best-fit with frequency-weighted residual pairing.

Pure best-fit is already strong, so this rule keeps best-fit as the primary
order but nudges the choice among near-ties using an online estimate of the
item-size distribution: a bin whose post-placement residual matches a
frequently seen item size is slightly preferred, because such gaps are more
likely to be filled exactly later.
"""
import numpy as np

_state = {
    "seen": None,      # histogram of item sizes seen so far (index 1..100)
    "count": 0,
    "resid": None,     # my own tracking of every bin's remaining capacity
    "n": 0,            # total number of items in the instance
}


def priority(item, bins):
    st = _state
    L = len(bins)

    # First call of an instance: total items == number of bins shown.
    if st["seen"] is None:
        st["seen"] = np.zeros(101, dtype=np.float64)
        st["count"] = 0
        st["resid"] = np.full(L, 100, dtype=np.int64)
        st["n"] = L

    # --- update our own model of the item stream ---
    st["seen"][item] += 1.0
    st["count"] += 1
    hist = st["seen"]
    total = st["count"]

    # Empirical frequency of each size, smoothed; only used for tie-breaking.
    freq = hist / total  # 0..1

    # --- identify which global bin indices are shown and their residuals ---
    resid = st["resid"]
    # bins is the residual of every bin the item fits in, in bin order.
    # Reconstruct the index list by matching against our tracked residuals.
    # Because we track every placement, we can find the shown bins by index.
    idx = np.flatnonzero(resid >= item)
    # Safety: if our tracked state disagrees (should not happen), fall back.
    if len(idx) != L:
        # Recover conservatively: assume the shown bins are the fitting ones
        # but we can't map them; just do pure best-fit.
        return -(bins - item)

    # Primary score: best fit (more negative residual => tighter).
    new_resid = resid[idx] - item

    # Secondary: frequency-weighted bonus if new residual matches a common size.
    # Normalize bonus so it never dominates: scale by tiny epsilon.
    f = freq[new_resid] if new_resid.max() <= 100 else np.zeros(L)
    # Bonus is at most ~epsilon; ties in best-fit are common with integer sizes.
    eps = 1e-3
    score = -(new_resid.astype(np.float64)) + eps * f

    return score
# EVOLVE-BLOCK-END
