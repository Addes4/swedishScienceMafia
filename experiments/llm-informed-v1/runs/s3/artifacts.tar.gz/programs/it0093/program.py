# EVOLVE-BLOCK-START
"""Refined-harmonic-style stateful bin choice.

Keeps its own view of every open bin's residual. For an arriving item of size s,
candidate bins are scored by the class of the post-placement remainder r = residual - s:

  - r == 0            : perfect fill, best.
  - small r (<= SMALL): leftover gap too small to hold a typical item, very good.
  - r in a "useful" window that matches a common item size class: good.
  - large r (unused-ish 100-ish after placement): penalized, because it means we
    barely used a fresh bin for a small item.

Unused bins (residual 100) are additionally penalized for items that could fit
comfortably elsewhere, so small items pack into partially filled bins and fresh
bins are saved for large items.
"""
import numpy as np

_CAP = 100
# thresholds (size classes) tuned to a Weibull mean ~40 distribution
_SMALL = 20       # remainder small enough to be nearly useless
_MED = 40         # a "typical" item size
_LARGE = 60       # a large item size


def priority(item, bins):
    s = int(item)

    # Post-placement remainder for each candidate bin.
    rem = bins - s  # >= 0 by contract

    score = np.empty(len(bins), dtype=np.float64)

    # base score: prefer tightest fit (small remainder) -> refined harmonic style
    # map remainder to class desirability
    # 0 remainder best; then small remainders; then medium; penalize huge remainders.
    # Use piecewise mapping so exact fills and near-fills dominate.
    sc = np.where(
        rem == 0, 3.0,
        np.where(
            rem <= _SMALL, 2.0,
            np.where(
                rem <= _MED, 1.0,
                np.where(rem <= _LARGE, 0.5, 0.0)
            )
        )
    )

    # Secondary: finer tie-break = smaller remainder is better.
    score[:] = sc * 1000.0 - rem

    # Penalize leaving a fresh (previously unused) bin only slightly used for a
    # small item: if bin residual == 100 and item is small, subtract a bit so
    # partially filled bins are preferred.
    unused = (bins == _CAP)
    if s <= _MED:
        score -= unused * 250.0

    return score
# EVOLVE-BLOCK-END
