# EVOLVE-BLOCK-START
"""Best-fit with state tracking and small-item consolidation bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item
    # Pure best fit: smaller residual after placement is better.
    score = -residual.astype(np.float64)
    # For small items, mildly reward tightening existing (more loaded) bins to cut fragmentation.
    if item <= 30:
        score += 0.001 * (100 - bins).astype(np.float64)
    return score
# EVOLVE-BLOCK-END

