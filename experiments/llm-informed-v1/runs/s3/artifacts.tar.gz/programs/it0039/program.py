# EVOLVE-BLOCK-START
"""Best fit with an adaptive penalty for creating tiny unusable gaps."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, ties to first bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    sizes = _state["sizes"]
    sizes.append(item)

    residual = bins - item  # >= 0 for all shown bins

    # Estimate a small-item threshold from observed sizes (10th percentile-ish).
    # Using a running min-ish quantile cheaply: track a small threshold as a fraction.
    # Penalize creating residuals below `thresh` (near-useless gaps) so we avoid
    # wasting bin space on gaps that small future items may fail to fill.
    n = len(sizes)
    if n >= 20:
        # cheap approximate 10th percentile using a sorted sample every so often
        # (keep it fast: sample up to 200 recent sizes)
        samp = sizes[-200:] if n > 200 else sizes
        arr = np.asarray(samp)
        thresh = float(np.percentile(arr, 8))
    else:
        thresh = 0.0

    score = -(residual.astype(np.float64))

    if thresh > 1.0:
        # For residuals strictly between 0 and thresh (non-empty but tiny), add a
        # penalty so we prefer slightly larger residuals that can still fit items,
        # unless residual is 0 (perfectly full is good).
        tiny = (residual > 0) & (residual < thresh)
        score = score - tiny * 5.0

    return score
# EVOLVE-BLOCK-END
