# EVOLVE-BLOCK-START
"""Hybrid: best fit, with exact-residual matching for small and fill-tightening for large items."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["sizes"].append(item)
    n = len(_state["sizes"])

    # residual after placement for feasible bins
    residual = bins - item

    # base score: best fit (smallest residual) -> high score
    score = -residual.astype(np.float64)

    # Fraction matching: strongly prefer placing into a bin whose residual exactly
    # equals the item size (would let a future item of this size fill exactly).
    # Weight grows as we accumulate more info, but keep it modest.
    score += np.where(residual == item, 1.0, 0.0)

    # For large items, avoid opening/prefer filling bins: penalize choosing an empty
    # bin (residual 100) when non-empty alternatives exist, via a tie-break bonus.
    # Empty bin: residual == 100 - item.
    empty_resid = 100 - item
    nonempty = (residual != empty_resid)
    if nonempty.any():
        score += np.where(residual == empty_resid, -0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
