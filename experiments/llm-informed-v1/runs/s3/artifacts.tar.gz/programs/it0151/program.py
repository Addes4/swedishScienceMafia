# EVOLVE-BLOCK-START
"""Best fit with a calibrated exact-fill / pairing bonus and a mildly
informative common-residual signal; noisy convolution dropped."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    # Single-item completion probability: chance a future item exactly equals
    # the residual.  Scaled moderately so it refines best-fit rather than
    # dominating it.
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]
    score += p_fill * 250.0

    # Pairing bonus: residual equals the item size, so a future identical
    # item can close the bin exactly.
    score += (post == item).astype(np.float64) * 350.0

    # Reward completing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 350.0

    # Mild commonness signal: prefer residuals that are common item sizes
    # (0.01 = uniform baseline), penalize rare ones.
    if valid.any():
        idx = post_idx[valid]
        common = np.zeros_like(score)
        common[valid] = (prob[idx] - 0.01) * 60.0
        score += common

    return score
# EVOLVE-BLOCK-END

