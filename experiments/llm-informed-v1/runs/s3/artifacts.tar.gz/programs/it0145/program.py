# EVOLVE-BLOCK-START
"""Best fit with empirical future-fill lookahead, complementary pairing,
two-item sum-completion lookahead, and a guard that reserves empty bins."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Lookahead: probability that a future single item exactly equals the
    # residual, estimated from the running histogram.
    score += p_fill * 300.0

    # Pairing bonus: if the residual after placement equals the item size,
    # a future identical item can close it exactly.
    score += (post == item).astype(np.float64) * 400.0

    # Reward completing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0

    # Two-sided commonness signal: reward residuals whose size is more common
    # than average, penalize rare residuals.
    common = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        common[valid] = (prob[idx] - 0.01) * 100.0   # 0.01 ~ uniform baseline
    score += common * 150.0

    # Two-item sum-completion lookahead: probability that the residual can be
    # exactly filled by the sum of two future items.
    if valid.any():
        idx = post_idx[valid]
        uniq = np.unique(idx)
        p2 = np.convolve(prob[1:101], prob[1:101])  # index s-2 -> sum s
        pw = np.zeros_like(score)
        sums = post_idx[valid]
        p2v = p2[sums - 2]
        pw[valid] = p2v
        score += pw * 120.0

    # Reserve-empty-bins guard: don't open a fresh empty bin (pre-placement
    # remaining capacity 100) for items that still fit alongside others.
    # Penalize this, scaled by how small the item is, so large bins stay
    # available for large future items that cannot share.
    is_empty = (bins == 100)
    if is_empty.any():
        # penalty grows for smaller items; large items (>=60) are almost exempt
        reserve = np.where(is_empty, np.maximum(0.0, 60.0 - item), 0.0)
        score -= reserve * 2.0

    return score
# EVOLVE-BLOCK-END

