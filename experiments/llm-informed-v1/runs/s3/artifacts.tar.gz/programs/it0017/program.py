# EVOLVE-BLOCK-START
"""Best fit with a residual-floor guard tracked over all open bins."""
import numpy as np

_state = {"bins": None, "n": None, "seen": 0, "sizes": []}


def priority(item, bins):
    st = _state
    L = len(bins)
    if st["bins"] is None or len(st["bins"]) != L:
        st["bins"] = [100] * L
        st["n"] = L
        st["seen"] = 0
        st["sizes"] = []

    # reconstruct which bin corresponds to which entry in `bins`
    # bins given are the ones with remaining >= item, in bin order.
    all_bins = st["bins"]

    # median of seen sizes as a floor for useful residual
    seen = st["sizes"]
    if seen:
        srt = sorted(seen)
        med = srt[len(srt) // 2]
    else:
        med = 40
    floor = max(1, med // 2)

    # map fitting entries back to global indices
    scores = np.empty(L, dtype=np.float64)
    j = 0
    for i in range(len(all_bins)):
        rem = all_bins[i]
        if rem >= item:
            res = rem - item
            # base: prefer tight fit (larger rem closer to item => smaller residual)
            s = -res
            # guard: penalize leaving a sliver below floor unless exact fit
            if res != 0 and res < floor:
                s -= 1000.0
            scores[j] = s
            j += 1

    # update state: choose the argmax bin globally
    best_j = int(np.argmax(scores))
    # find global index
    j = 0
    chosen = -1
    for i in range(len(all_bins)):
        if all_bins[i] >= item:
            if j == best_j:
                chosen = i
                break
            j += 1
    if chosen >= 0:
        all_bins[chosen] -= item

    st["seen"] += 1
    st["sizes"].append(item)
    if len(st["sizes"]) > 500:
        st["sizes"] = st["sizes"][-500:]

    return scores
# EVOLVE-BLOCK-END

