# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference plus a calibrated expected single-item
completion signal based on the empirical item-size distribution."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and expected future exact-fill count.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    # Expected number of future items that would exactly close this residual:
    # remaining items * probability of that exact size.
    remaining = float(len(bins)) - total  # total items = len(bins) on first call
    if remaining < 0.0:
        remaining = 0.0
    exp_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        exp_fill[valid] = prob[idx] * remaining

    # Mild calibrated tie-breaker: rewarding residuals likely to be closed soon.
    score += exp_fill * 5.0

    return score
# EVOLVE-BLOCK-END

