# EVOLVE-BLOCK-START
"""Best fit plus a calibrated lookahead on residual fillability."""
import numpy as np

_state = {"n": 0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Rank bins: best fit, with lookahead on how fillable the residual is.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item
    score = -post.astype(np.float64)

    # Exact fill is always ideal.
    score += (post == 0).astype(np.float64) * 1000.0

    # Completing a bin whose residual before placement equals the item
    # (a planned perfect pair).
    score += (bins == item).astype(np.float64) * 500.0

    # Lookahead: reward a post-placement residual r by the empirical chance
    # that a future item equals r exactly (perfect fill of this bin).
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    prob = np.zeros_like(score)
    idx = post_idx[valid]
    prob[valid] = hist[idx] / total
    score += prob * 300.0

    # Small asymmetric guard: a nonzero residual that is too small to be a
    # plausible single future item is weak; mildly demote it without breaking
    # the best-fit ordering.
    tiny = (post >= 1) & (post <= 3)
    score -= tiny.astype(np.float64) * 1.5

    return score
# EVOLVE-BLOCK-END

