# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference, complementary pairing, and a
probability-of-future-fill lookahead estimated from a smoothed item-size
distribution (decayed empirical counts pooled with a fixed Weibull prior)."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.997

# Fixed Weibull-shaped prior over sizes 1..100, mean ~40 (k=2, lambda=45).
_sizes = np.arange(101, dtype=np.float64)
_k = 2.0
_lam = 45.0
_raw = (_sizes / _lam) ** (_k - 1.0) * np.exp(-((_sizes / _lam) ** _k))
_raw[0] = 0.0
_prior = _raw / _raw.sum()


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future fill."""
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    # Smoothed distribution: pool decayed empirical counts with fixed prior.
    # Prior gets weight proportional to a pseudo-count scale.
    w_prior = 40.0
    prob = (hist + w_prior * _prior) / (total + w_prior)

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Reward placing into a bin whose residual before placement == item,
    # closing the bin exactly.
    score += (bins == item).astype(np.float64) * 400.0

    # Expected number of future exact single-item fills for this residual.
    remaining = max(n_items - st["n"], 0.0)
    exp_fill = remaining * p_fill
    score += exp_fill * 60.0
    score += p_fill * 300.0

    # Pair-closure lookahead: probability this residual can be exactly filled
    # by a pair of typical future items.
    p = prob[1:101]
    conv = np.convolve(p, p)
    pair_prob = np.zeros(101, dtype=np.float64)
    pair_prob[1:101] = conv[:100]
    p_pair = np.zeros_like(score)
    if valid.any():
        p_pair[valid] = pair_prob[post_idx[valid]]

    n_pairs = remaining * max(remaining - 1.0, 0.0) * 0.5
    pair_weight = min(n_pairs / max(n_items, 1.0), 5.0)
    score += p_pair * pair_weight * 2000.0

    # Mode-residual bonus.
    mode_idx = int(np.argmax(prob[1:101])) + 1
    p_mode = float(prob[mode_idx])
    score += (post_idx == mode_idx).astype(np.float64) * p_mode * 800.0

    return score
# EVOLVE-BLOCK-END
