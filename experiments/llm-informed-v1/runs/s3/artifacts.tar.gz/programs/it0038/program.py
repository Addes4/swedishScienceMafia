# EVOLVE-BLOCK-START
"""Best fit with a small bonus for leaving a residual that can still hold a typical item."""
import numpy as np

_state = {"mean": 40.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest score.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    # Update running mean item size (cheap, online).
    st = _state
    st["n"] += 1
    n = st["n"]
    st["mean"] += (item - st["mean"]) / n
    mean = st["mean"]

    # Base: tightest fit (largest score for smallest residual).
    score = -remaining.astype(np.float64)

    # Small bonus if the residual can still hold a typical item (avoids dead gaps),
    # scaled by item size so it only breaks near-ties among similar residuals.
    usable = (remaining >= mean).astype(np.float64)
    score += usable * 0.5

    return score
# EVOLVE-BLOCK-END
