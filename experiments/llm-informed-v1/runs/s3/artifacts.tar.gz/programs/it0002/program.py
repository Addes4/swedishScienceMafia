# EVOLVE-BLOCK-START
"""Best fit with a soft tie-break that favors residuals equal to frequent item sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smaller residual (best fit). Secondary: prefer residuals that are
    # themselves common item sizes, making the bin easy to fill exactly later.
    # A residual of 0 is perfect; residuals matching plausible item sizes (roughly
    # 1..100) get a mild bonus, with peak weight around the distribution mean (~40).
    bonus = np.zeros(residual.shape, dtype=np.float64)
    mask = (residual >= 1) & (residual <= 100)
    # Gaussian-ish bump centered at 40 with width 25, scaled small so primary fit dominates.
    r = residual[mask].astype(np.float64)
    bonus[mask] = 0.02 * np.exp(-0.5 * ((r - 40.0) / 25.0) ** 2)
    return -residual + bonus
# EVOLVE-BLOCK-END

