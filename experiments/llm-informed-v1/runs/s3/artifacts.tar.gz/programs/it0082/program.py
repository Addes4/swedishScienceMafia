# EVOLVE-BLOCK-START
"""Best fit with online residual-size matching tie-break."""
import numpy as np

_state = {}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    if not st:
        st["n"] = len(bins)
        st["seen"] = np.zeros(101, dtype=np.int64)
        st["count"] = 0

    # Update observed item-size histogram.
    if 0 <= item <= 100:
        st["seen"][item] += 1
    st["count"] += 1

    # Best-fit baseline: residual after placement = bins - item.
    residual = bins - item  # >= 0

    # Small bonus for residuals that match frequently seen item sizes.
    seen = st["seen"]
    n_seen = st["count"]
    # Rank by residual ascending (i.e. -residual), and add tiny tie-break using frequency
    # of the residual value as an item size, normalized.
    freq = seen[residual.clip(0, 100)]
    bonus = freq.astype(np.float64) / max(n_seen, 1)

    # Primary term: prefer smallest post-placement residual.
    return -(residual.astype(np.float64)) + 1e-6 * bonus
# EVOLVE-BLOCK-END
