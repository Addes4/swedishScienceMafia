# EVOLVE-BLOCK-START
"""Best-fit with a small-item consolidation rule that preserves room for large items."""
import numpy as np

_state = {"bins": {}, "n": 0}


def priority(item, bins):
    """Rank bins (highest score wins) for an arriving item.

    item: integer size 1..100.
    bins: numpy int64 array, remaining capacity of each bin the item fits in, in bin order.
    """
    st = _state
    st["n"] += 1

    # Maintain our own full picture of bin residuals (bins dict: index -> residual).
    # On the first call, all bins are empty. len(bins) == number of items.
    if st["n"] == 1:
        total = len(bins)
        st["total"] = total
        st["bins"] = {}

    # ids: which bin indices correspond to this sub-array. The harness passes bins the item
    # fits in, but in this environment it passes all bins (fits filter is our job anyway),
    # in fixed bin order, so indices align with our internal numbering.
    rem = np.asarray(bins)
    n_fit = rem.shape[0]

    # Ensure internal tracking is sized to total bins seen.
    total = st.get("total", n_fit)
    mybins = st["bins"]

    # The passed array may be a subset; map entries by matching residuals is unreliable,
    # so instead treat each entry as a bin slot in order (harness uses fixed order).
    # Sync: if we've seen fewer bins than passed, initialize the new empty ones.
    while len(mybins) < n_fit:
        mybins[len(mybins)] = 100

    # Build score array: base is best-fit = -(residual - item).
    residual_after = rem - item
    scores = -residual_after.astype(np.float64)

    # Small-item consolidation: for small items, prefer bins where the resulting residual
    # is still "useful" (>= 60) so a large item can still land there, rather than closing
    # a gap and creating a useless fragment.
    if item <= 30:
        # Prefer packing into already-used bins whose residual stays >= 60.
        used = rem < 100
        good_room = rem - item >= 60
        bonus = np.where(used & good_room, 200.0, 0.0)
        # Slight extra bonus for tightest among those useful bins.
        bonus += np.where(used & good_room, -(rem - item).astype(np.float64) * 0.5, 0.0)
        scores = scores + bonus

    # Update internal residuals for the bin we will most likely choose (best score, ties first).
    best = int(np.argmax(scores))
    if best < len(mybins):
        mybins[best] = int(rem[best]) - item

    return scores
# EVOLVE-BLOCK-END

