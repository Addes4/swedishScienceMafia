# EVOLVE-BLOCK-START
"""Best fit plus bonuses for exact fills, complementary pairs, and near-full bins."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tight fits, exact fills, complementary residuals, near-full bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    post = bins - item
    # Base: best fit => smallest post-placement residual is best.
    score = -post.astype(np.float64)
    # Bonus: exact fill (no residue left) — always good.
    score += (post == 0).astype(np.float64) * 1000.0
    # Bonus: residual exactly equals the item size, so a future same-size item
    # could fill it exactly (perfect complementary pair).
    score += (post == item).astype(np.float64) * 500.0
    # Small bonus: near-full bins (tiny nonzero residual) are nearly closed; prefer
    # them over bins leaving larger gaps, without disturbing the main best-fit order.
    near_full = (post > 0) & (post <= 3)
    score += near_full.astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END

