# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and a clean pairwise-sum residual match."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
}


def priority(item, bins):
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Dominant: best fit -> smallest post-placement residual.
    score = -post.astype(np.float64) * 1.0

    # Exact fill: perfect completion.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 2) & (post_idx <= 100)
    if valid.any():
        # Pairwise-sum probability p2[s] for sums s = 2..200.
        p2 = np.convolve(prob[1:101], prob[1:101])
        # Probability mass at residual: how likely two future items fill it.
        idx = post_idx[valid]
        pw = p2[idx - 2]
        # Normalize roughly to keep magnitude small relative to best-fit.
        bonus = np.zeros_like(score)
        bonus[valid] = pw * 300.0
        score += bonus

    # Reward completing a bin whose current residual equals the item exactly
    # (this item fits perfectly with no leftover).
    score += (bins == item).astype(np.float64) * 400.0

    # Moderate pairing: residual equals item size -> a future identical item
    # closes it exactly.
    score += (post == item).astype(np.float64) * 400.0

    return score
# EVOLVE-BLOCK-END
