# EVOLVE-BLOCK-START
"""Best fit with a residual-utility bias based on the item-size distribution."""
import numpy as np

_state = {"res": None}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    res = _state["res"]
    n = len(bins)
    if res is None or len(res) != n:
        # first call of the instance: every bin starts empty (capacity 100)
        res = np.full(n, 100, dtype=np.int64)
        _state["res"] = res

    # Which bins are shown fit the item?  The shown array is the residual of fitting bins,
    # in bin order.  We recover the set of fitting bins by matching residuals.
    fit_mask = res >= item

    post = res[fit_mask] - item

    # Utility of a residual r: 0 residual is great (bin closed); otherwise a residual
    # is useful if it can still hold a typical item (mean ~40 => small items ~ 15-40).
    # Score primarily by best fit (small post), small correction toward useful residuals.
    small = post.astype(np.float64)

    # bonus for closing a bin almost exactly
    close_bonus = np.where(post == 0, 5.0, 0.0)

    # penalty for leaving a small, unusable residual (too small for a typical small item)
    waste_pen = np.where((post > 0) & (post < 10), 2.0, 0.0)

    score_fit = -small + close_bonus - waste_pen

    # Build the full-length output: bins not fitting get a very low score.
    out = np.full(n, -1e18, dtype=np.float64)
    idx = np.nonzero(fit_mask)[0]
    out[idx] = score_fit

    # record the choice: highest score, first on ties
    choice = int(np.argmax(out))
    res[choice] -= item
    _state["res"] = res

    return out
# EVOLVE-BLOCK-END

