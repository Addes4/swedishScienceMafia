# EVOLVE-BLOCK-START
"""Best fit with an expected future exact-fill term using a stable
empirical item-size histogram (distribution is fixed per instance, so no
decay). Best fit dominates; the fill term resolves ties toward bins whose
residual is likely to be closed by a future item."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit plus expected future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))
    remaining = max(n_items - st["n"], 0.0)

    post = bins - item              # residual after placing item here
    post_f = post.astype(np.float64)

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post_f

    # Laplace-smoothed probability of a given future item size.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    p_fill = np.zeros_like(score)
    if valid.any():
        p_fill[valid] = prob[post_idx[valid]]

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 1e6

    # Expected number of future exact single-item fills for this residual.
    # Scaled to be a tie-breaker alongside best fit.
    score += p_fill * remaining * 8.0

    # Reward closing a bin whose current residual equals the item.
    score += (bins == item).astype(np.float64) * 5000.0

    return score
# EVOLVE-BLOCK-END

