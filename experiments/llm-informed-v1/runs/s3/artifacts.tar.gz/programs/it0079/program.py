# EVOLVE-BLOCK-START
"""Best-fit plus a small look-ahead reward for residuals that can likely be filled later."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Standard best fit: prefer the bin with the smallest post-placement residual.
    return -(bins - item)
# EVOLVE-BLOCK-END
