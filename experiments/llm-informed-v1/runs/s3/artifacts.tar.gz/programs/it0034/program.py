# EVOLVE-BLOCK-START
"""Hybrid: harmonic size-class routing combined with tightest fit.

Items are grouped into size classes with boundaries from a harmonic-style
partition of the capacity (100).  For the largest class we keep tightest
fit (best fit), which is close to optimal for big items.  For smaller items
we prefer bins whose residual after placement falls onto a coarse class
boundary, reducing fragmentation of large bins while still keeping the
placement tight.
"""
import numpy as np

# Class boundaries (item size).  A size s belongs to class k where
# BOUNDS[k-1] < s <= BOUNDS[k].
_BOUNDS = np.array([10, 20, 34, 50, 67, 100], dtype=np.int64)
# Preferred residual levels we like to leave behind after a placement.
_LEVELS = np.array([0, 10, 20, 34, 50, 67], dtype=np.int64)


def priority(item, bins):
    residual = bins - item  # >= 0 for all provided bins
    # Primary term: tightest fit (smallest residual) dominates.
    score = -residual.astype(np.float64) * 4.0

    # Secondary term: reward leaving residuals that hit a desired level,
    # which keeps reuse of bins along harmonic boundaries.
    dist = np.abs(residual[:, None] - _LEVELS[None, :]).min(axis=1)
    score += (8.0 - dist.astype(np.float64)) * 0.5

    # Small extra: strongly prefer exact fills.
    score += (residual == 0).astype(np.float64) * 6.0

    return score
# EVOLVE-BLOCK-END

