# EVOLVE-BLOCK-START
"""Best-fit with a future-aware residual preference.

The baseline best-fit packs tightly but can strand small unusable residuals.
This version keeps its own view of all open bins (using module state) plus a
running histogram of observed item sizes, and slightly adjusts the best-fit
score so that, among near-tied bins, it prefers placements whose residual is a
common item size seen so far (and thus likely reusable).  Exact best-fit
behavior is preserved when there is a clear tightest bin.
"""
import numpy as np

_state = {
    "n": None,
    "hist": None,      # histogram of observed item sizes, index 1..100
    "seen": 0,
    "remaining": None,  # remaining capacity of every bin we know about
    "bins": 0,
}


def _init(n):
    _state["n"] = n
    _state["hist"] = np.zeros(101, dtype=np.float64)
    _state["seen"] = 0
    _state["remaining"] = np.full(n, 100, dtype=np.int64)
    _state["bins"] = 0


def priority(item, bins):
    """Score each candidate bin; highest score wins (first on ties)."""
    n = len(bins)
    if _state["n"] is None or _state["n"] != n:
        _init(n)

    hist = _state["hist"]
    seen = _state["seen"]

    # Update the observed size distribution with the current item.
    hist[item] += 1.0
    seen += 1
    _state["seen"] = seen

    # Probability-weighted "common size" mass, used to value a residual.
    if seen > 8:
        total = hist.sum()
        p = hist / total  # p[s] = fraction of items of size s

        # For each possible residual r, fraction of items with size <= r
        # that would fit exactly into r (cumulative mass up to r).
        cum = np.cumsum(p)  # cum[r] = P(size <= r)

        residual = bins - item  # residual after placing item into each bin
        residual = np.clip(residual, 0, 100)

        # Value of a residual: how much mass of common small items it can still
        # hold.  Larger residuals can hold more, but we weight by observed mass
        # so that residuals matching frequent sizes are favored.
        value = cum[residual]

        # Base: best fit (most negative residual = tightest).  We keep this
        # dominant so packing stays tight, and add a small future-aware bonus.
        base = -(residual.astype(np.float64))
        bonus = 0.35 * value
        return base + bonus

    # Warm-up: pure best fit.
    return -(bins - item).astype(np.float64)
# EVOLVE-BLOCK-END
