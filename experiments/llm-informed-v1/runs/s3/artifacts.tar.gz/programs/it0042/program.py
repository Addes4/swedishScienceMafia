# EVOLVE-BLOCK-START
"""Best fit with a tiny bonus when the leftover exactly matches a seen item size."""
import numpy as np

_seen = set()
_count = 0


def priority(item, bins):
    """Return a priority per bin; highest score wins (ties to first bin).

    Primary: tightest fit (smallest residual after placement).
    Tie-break: small bonus when the resulting residual equals a previously seen item size,
    so that a future item of that size can complete the bin exactly.
    """
    global _seen, _count
    residual = bins - item  # >= 0 since item fits
    # base score: prefer smallest residual
    score = -residual.astype(np.float64)
    # small bonus for residuals that match a seen size (usable gap)
    if _seen:
        for i in range(score.shape[0]):
            if residual[i] in _seen:
                score[i] += 0.5
    _count += 1
    _seen.add(int(item))
    return score
# EVOLVE-BLOCK-END
