# EVOLVE-BLOCK-START
"""Best-fit with a pairing bonus: prefer tight fits, and among them, prefer
residuals that are close to typical item sizes so future items can complete the bin."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Primary: best fit (minimize leftover). We negate so higher = better.
    score = -residual.astype(np.float64)
    # Secondary bonus: reward leaving a residual near a typical item size (~40),
    # which tends to enable completing the bin on the next matching item.
    # Bonus is bounded well below 1 so it only breaks near-ties in residual.
    bonus = np.exp(-((residual - 40.0) ** 2) / (2.0 * 12.0 ** 2))
    score += 0.5 * bonus
    return score
# EVOLVE-BLOCK-END
