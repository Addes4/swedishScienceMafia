# EVOLVE-BLOCK-START
"""Best fit with an empirical-residual tie-break to reduce stranded gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    res = bins - item  # remaining capacity after placing the item
    # Primary: best fit (smallest residual after placement).
    # Tie-break within a small band: prefer a residual near the typical item size (~40),
    # so leftover gaps remain usable for future items rather than becoming stranded.
    band = 3
    tight = -res.astype(np.float64)
    # Penalize residuals that are far from the typical item size only among near-best bins.
    close = (res <= (res.min() + band)).astype(np.float64)
    usefulness = close * (1.0 / (1.0 + np.abs(res - 40)))
    return tight + 0.5 * usefulness
# EVOLVE-BLOCK-END

