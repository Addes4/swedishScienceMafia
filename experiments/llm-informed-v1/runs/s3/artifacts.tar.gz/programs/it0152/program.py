# EVOLVE-BLOCK-START
"""Best fit with empirical future-fill lookahead, complementary pairing,
and a bounded two-item sum-completion tie-breaker."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
    "p2": None,                                # cached pairwise-sum pmf
    "p2_n": -1.0,
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Lookahead: probability that a future single item exactly equals the
    # residual, estimated from the running histogram.
    score += p_fill * 300.0

    # Pairing bonus: if the residual after placement equals the item size,
    # a future identical item can close it exactly.
    score += (post == item).astype(np.float64) * 400.0

    # Reward completing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0

    # Bounded two-item sum-completion tie-breaker.
    # Only apply among bins whose residual is within a small window of the
    # best (smallest) residual, so it never overrides best-fit ranking.
    if valid.any():
        # Cache the pairwise-sum pmf; recompute occasionally.
        if st["p2"] is None or (total - st["p2_n"]) >= 25.0:
            p = prob[1:101]
            st["p2"] = np.convolve(p, p)  # index s-2 -> sum s
            st["p2_n"] = total
        p2 = st["p2"]

        post_min = int(post_idx[valid].min())
        window = post_min + 8
        near = valid & (post_idx <= window)

        pw = np.zeros_like(score)
        sums = post_idx[near]
        # map sum s (2..200) to p2 index s-2
        pw[near] = p2[sums - 2]
        # Scale so it only nudges ties within best-fit (residuals differ by
        # at most a few units), never dominates.
        score += pw * 30.0

    return score
# EVOLVE-BLOCK-END
