# EVOLVE-BLOCK-START
"""Two-item lookahead best fit using an online size histogram."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.int64), "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    hist = _state["hist"]
    n = _state["n"]

    # Update histogram with this item (we know it now).
    hist[item] += 1
    n += 1
    _state["n"] = n

    # Estimated distribution over sizes: exclude the current item lightly so the
    # "future" estimate isn't dominated by the item just seen.
    if n > 50:
        w = hist.astype(np.float64).copy()
        w[item] = max(w[item] - 1.0, 0.0)
        tot = w.sum()
        if tot > 0:
            probs = w / tot
        else:
            probs = np.ones(101) / 101.0
    else:
        probs = np.ones(101) / 101.0

    rem_after = bins - item  # residual if we place item here (>=0)

    # For each bin, compute expected best-followup leftover.
    # Followup: pick a future size s <= rem; leftover = rem - s. To save bins we want
    # the followup to fill the bin well, i.e. minimize leftover. Best achievable per s is
    # leftover = rem mod s ... but simpler: expected leftover over the distribution.
    R = rem_after.astype(np.float64)
    # Expected leftover given a random future size s ~ probs (conditioned s <= R)
    # E[max(R - s, ?)] approximated as R - E[s | s<=R]
    sizes = np.arange(101, dtype=np.float64)
    cum_p = np.cumsum(probs)
    # For each distinct R we compute E[min(s,R)] via prefix sums of probs*sizes.
    ps = probs * sizes
    # Prefix sums for conditional expectation.
    cum_ps = np.cumsum(ps)

    # E[s | s <= R] = cum_ps[R] / cum_p[R]
    Rr = np.clip(R.astype(np.int64), 0, 100)
    denom = cum_p[Rr]
    num = cum_ps[Rr]
    with np.errstate(divide="ignore", invalid="ignore"):
        cond_mean = np.where(denom > 0, num / np.maximum(denom, 1e-12), 0.0)
    # Expected leftover after placing the best-fitting single future item.
    exp_left = R - cond_mean

    # Also encourage exact fits now (tightest fits reduce waste): breaks ties toward best-fit.
    score = -exp_left - 1e-3 * R

    # Guard: NaN safety.
    score = np.nan_to_num(score, nan=-1e18, posinf=-1e18, neginf=-1e18)
    return score
# EVOLVE-BLOCK-END
