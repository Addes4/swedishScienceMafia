# EVOLVE-BLOCK-START
"""Best fit with empirical future-fill lookahead, complementary pairing, and
two-item sum-completion lookahead."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    # Keep this small so lookahead terms can break near-ties.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Lookahead: probability that a future single item exactly equals the
    # residual, estimated from the running histogram.
    score += p_fill * 1000.0

    # Two-item sum-completion lookahead: probability that the residual can be
    # exactly filled by the sum of two future items.
    if valid.any():
        p2 = np.convolve(prob[1:101], prob[1:101])  # index s-2 -> sum s
        pw = np.zeros_like(score)
        sums = post_idx[valid]
        p2v = p2[sums - 2]
        pw[valid] = p2v
        score += pw * 300.0

    return score
# EVOLVE-BLOCK-END
