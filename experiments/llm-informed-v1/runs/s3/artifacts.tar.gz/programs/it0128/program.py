# EVOLVE-BLOCK-START
"""Best fit with a calibrated empirical residual-match lookahead."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen so far
}


def priority(item, bins):
    """Rank bins by best-fit plus an empirically estimated residual-fill value.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Probability that a future single item exactly equals the residual,
    # Laplace-smoothed from the running histogram over sizes 1..100.
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        prob = (hist[idx] + 1.0) / (total + 100.0)
        p_fill[valid] = prob

    # Exact fill: a residual of 0 is completed perfectly.
    score += (post == 0).astype(np.float64) * 10000.0

    # Expected value of leaving this residual: an exact future match closes the
    # bin completely, worth roughly one bin. Scale with a modest weight so it
    # refines near-ties between best-fit candidates without overriding best fit.
    score += p_fill * 600.0

    # Complementary pairing: a residual equal to the current item size is a very
    # common exact-fill target; reward both leaving it and completing it.
    score += (post == item).astype(np.float64) * 300.0
    score += (bins == item).astype(np.float64) * 300.0

    return score
# EVOLVE-BLOCK-END
