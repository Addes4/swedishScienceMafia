# EVOLVE-BLOCK-START
"""Critical-fill best fit: dominant best-fit with strong exact-fill priority."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
}


def priority(item, bins):
    """Rank bins by best fit, with a strong preference for exact fills.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Planned pair completion: a bin whose residual currently equals item
    # can be closed perfectly by placing this item.
    score += (bins == item).astype(np.float64) * 500.0

    # Pseudo-exact: reward residuals that are themselves plausible item sizes,
    # weighted by how often such sizes have appeared (smoothed).
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    if valid.any():
        idx = post_idx[valid]
        prob = (hist[idx] + 1.0) / (total + 100.0)
        score[valid] += prob * 200.0

    # Anti-orphan: tiny non-zero residuals rarely get filled exactly.
    small_orphan = (post >= 1) & (post <= 4)
    score -= small_orphan.astype(np.float64) * 3.0

    return score
# EVOLVE-BLOCK-END
