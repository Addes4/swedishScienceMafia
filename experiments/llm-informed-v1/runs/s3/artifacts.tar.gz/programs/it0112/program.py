# EVOLVE-BLOCK-START
"""Best fit plus bonuses for exact fills, complementary pairs, and a learned
lookahead bonus rewarding residuals likely to be exactly filled by a future item."""
import numpy as np

_state = {"n": 0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Rank bins: prefer tight fits, exact fills, and residuals likely to be
    matched exactly by a future item (learned from the running histogram).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item
    postf = post.astype(np.float64)

    # Base: best fit => smallest post-placement residual is best.
    score = -postf

    # Big bonus: exact fill (no residue left) — always good.
    score += (post == 0).astype(np.float64) * 1000.0

    # Complementary-pair bonuses.
    score += (post == item).astype(np.float64) * 500.0
    score += (bins == item).astype(np.float64) * 500.0

    # Learned lookahead: reward leaving a residual r that a future item is
    # likely to match exactly (probability r has been seen so far).
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    freq = np.zeros_like(score)
    if total > 0:
        idx = post_idx[valid]
        freq[valid] = hist[idx] / total
    score += freq * 300.0

    # Anti-orphan guard: tiny non-zero residuals (1..4) rarely get filled exactly
    # and tend to strand capacity; nudge them down slightly.
    small_orphan = (post >= 1) & (post <= 4)
    score -= small_orphan.astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END

