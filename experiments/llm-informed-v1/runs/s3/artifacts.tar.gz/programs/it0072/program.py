# EVOLVE-BLOCK-START
"""Best fit with a consolidation tie-break on equal residual."""
import numpy as np

_counts = {}


def priority(item, bins):
    """Rank bins for the arriving item.

    Primary: smallest post-placement residual (classic best fit).
    Tie-break: prefer the bin already holding the most items (consolidation),
    which is tracked via module-level state keyed by object identity of the
    residual value we ourselves produce. Because we only see residuals here,
    we approximate occupancy by residual: bins with smaller residual have
    accumulated more. This is exactly best fit, so we instead use a light
    residual-band preference.
    """
    residual = bins - item
    # Best fit primary key: smallest residual.
    # Secondary key: prefer residuals that are NOT tiny leftovers (which waste
    # capacity) but exactly 0 when possible, then small.
    # We encode: sort by residual, but nudge exact-zero slightly ahead.
    score = -residual.astype(np.float64)
    score += (residual == 0).astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END
