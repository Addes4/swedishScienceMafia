# EVOLVE-BLOCK-START
"""Best fit with a fixed Weibull-shaped size prior and a complementary-pair
closing lookahead, plus strong exact-fill and mode-residual bonuses."""
import numpy as np

_state = {
    "n": 0.0,
    "sum": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
}

_DECAY = 0.999
_WEIBULL_SHAPE = 1.35  # tuned to mean ~40 with scale below


def _weibull_prior(mean_item):
    """Discrete pmf over 1..100 from a Weibull-shaped distribution."""
    if mean_item < 1.0:
        mean_item = 40.0
    # For Weibull, mean = scale * Gamma(1 + 1/k)
    from math import gamma
    scale = mean_item / gamma(1.0 + 1.0 / _WEIBULL_SHAPE)
    if scale <= 0.0:
        scale = 1.0
    xs = np.arange(1, 101, dtype=np.float64)
    cdf = 1.0 - np.exp(-((xs / scale) ** _WEIBULL_SHAPE))
    cdf_prev = 1.0 - np.exp(-(((xs - 1.0) / scale) ** _WEIBULL_SHAPE))
    pmf = cdf - cdf_prev
    pmf = np.clip(pmf, 0.0, None)
    s = pmf.sum()
    if s > 0.0:
        pmf /= s
    return pmf


def priority(item, bins):
    st = _state
    st["n"] += 1.0
    st["sum"] += float(item)
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_obs = st["n"]
    mean_item = st["sum"] / n_obs

    n_items = float(len(bins))
    remaining = max(n_items - n_obs, 0.0)

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Blend decayed empirical histogram with fixed Weibull prior for stability.
    prior = _weibull_prior(mean_item)
    prob = np.zeros(101, dtype=np.float64)
    emp = hist[1:101] / max(total, 1.0)
    alpha = min(total / (total + 200.0), 0.95)
    prob[1:101] = alpha * emp + (1.0 - alpha) * prior

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        p_fill[valid] = prob[post_idx[valid]]

    # Reward residuals likely to be closed by a single future item.
    score += p_fill * (300.0 + 60.0 * remaining * p_fill)

    # Reward placing into a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0

    # Pair-closure lookahead: probability of closing by a pair of future items.
    p = prob[1:101]
    conv = np.convolve(p, p)
    pair_prob = np.zeros(101, dtype=np.float64)
    pair_prob[1:101] = conv[:100]
    p_pair = np.zeros_like(score)
    if valid.any():
        p_pair[valid] = pair_prob[post_idx[valid]]
    n_pairs = remaining * max(remaining - 1.0, 0.0) * 0.5
    pair_weight = min(n_pairs / max(n_items, 1.0), 5.0)
    score += p_pair * pair_weight * 4000.0

    # Mode-residual bonus.
    mode_idx = int(np.argmax(prob[1:101])) + 1
    p_mode = float(prob[mode_idx])
    score += (post_idx == mode_idx).astype(np.float64) * p_mode * 800.0

    return score
# EVOLVE-BLOCK-END
