# EVOLVE-BLOCK-START
"""Residual-aware policy: keep bins at a moderate fill level to preserve room for large items."""
import numpy as np

_state = {"cap": 100.0, "count": 0, "total": 0.0, "size": 100}


def priority(item, bins):
    """Score bins for the arriving item; highest score wins (first on ties)."""
    n = len(bins)
    if _state["count"] == 0:
        # bins length equals number of items on the first call
        _state["size"] = n
    _state["count"] += 1
    _state["total"] += item

    # Target residual after placing an item: leave roughly room for one more mean item.
    mean_item = _state["total"] / _state["count"]
    # Ideal resulting residual is around mean item size (keeps bins from being too tight
    # for a large item but still packs reasonably). But we still want tightness overall;
    # use a cap on how full a bin becomes: prefer bins where residual-after >= 0 is close
    # to max(mean_item, item) but penalize going below a small floor.
    target = max(mean_item, float(item))
    post = bins - item  # residual after placing
    # Prefer residual-after as close to target as possible (from either side), with a
    # slight preference for larger residuals (leaves room). Then best-fit tie-break.
    score = -np.abs(post - target) - 0.001 * post
    return score
# EVOLVE-BLOCK-END
