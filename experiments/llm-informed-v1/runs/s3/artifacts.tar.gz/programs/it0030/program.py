# EVOLVE-BLOCK-START
"""Best fit with online exact-fit residual bonus."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    """Rank bins: mostly tightest fit, with a bonus for residuals matching frequent sizes."""
    st = _state
    st["hist"][item] += 1.0
    st["n"] += 1
    n = st["n"]
    hist = st["hist"]

    # Best fit baseline: prefer smaller residual (bins - item).
    score = -(bins - item).astype(np.float64)

    # Bonus when residual equals a frequently seen item size (likely reusable exactly).
    resid = bins - item
    counts = hist[resid]
    freq = counts / n
    # small bonus scaled to distribution mass (kept small so tight fit dominates)
    score += 3.0 * freq

    return score
# EVOLVE-BLOCK-END

