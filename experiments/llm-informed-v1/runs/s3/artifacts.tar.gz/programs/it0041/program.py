# EVOLVE-BLOCK-START
"""Best fit with an online residual-quality bonus derived from seen items."""
import numpy as np

_state = {"sizes": [], "n_expected": None, "ready": False}


def priority(item, bins):
    st = _state
    if not st["ready"]:
        # first call: len(bins) equals total number of items
        st["n_expected"] = len(bins)
        st["ready"] = True

    # record this item's size
    st["sizes"].append(item)
    n_seen = len(st["sizes"])

    # estimate empirical CDF of item sizes only occasionally (cheap)
    # compute the mean and a "typical" residual target.
    sizes = np.asarray(st["sizes"], dtype=np.int64)
    # use mean of seen items as scale; Weibull mean ~40
    mu = sizes.mean() if n_seen > 0 else 40.0

    # "optimal residual" heuristic: a residual slightly above the median item
    # maximizes the chance of fitting a future item while not wasting space.
    med = float(np.median(sizes)) if n_seen > 0 else 40.0
    target = max(float(item), med)

    residual = bins - item  # residual after placing here (>=0 for shown bins)

    # base: best fit (smallest residual)
    base = -residual.astype(np.float64)

    # bonus: residuals near `target` are preferred; huge residuals (empty bins)
    # get a mild penalty so we pack tightly, tiny residuals get a mild penalty too.
    diff = np.abs(residual.astype(np.float64) - target)
    bonus = 1.0 - diff / 100.0

    return base + 0.15 * bonus
# EVOLVE-BLOCK-END
