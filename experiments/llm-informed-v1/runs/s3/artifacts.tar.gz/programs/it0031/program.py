# EVOLVE-BLOCK-START
"""Best fit with a slight preference for minimizing (residual^2) to keep large gaps usable."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Exact fits are always best.
    exact = residual == 0
    # Otherwise prefer small residual (best fit), with a mild quadratic push.
    score = -(residual.astype(np.float64)) - 0.001 * (residual.astype(np.float64)) ** 2
    score = np.where(exact, 1e6, score)
    return score
# EVOLVE-BLOCK-END

