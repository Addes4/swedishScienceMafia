# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference, empirical future-fill lookahead
scaled by the number of items left, and a coarse-prior blended item model,
with exponential forgetting of past items."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.999

# Coarse fixed prior over item sizes (1..100) matching a Weibull-like
# distribution with mean ~40.  Used to stabilize early estimates.
_PRIOR = None


def _build_prior():
    global _PRIOR
    # Weibull(k=2, lambda ~ 45) discretized and truncated to 1..100.
    k = 2.0
    lam = 45.0
    x = np.arange(0, 102, dtype=np.float64)
    # crude CDF of Weibull: F(t) = 1 - exp(-(t/lam)^k)
    cdf = 1.0 - np.exp(-np.power(np.clip(x, 0.0, None) / lam, k))
    pmf = np.diff(cdf)  # length 101, index 0 unused
    pmf = np.clip(pmf, 1e-6, None)
    pmf[0] = 0.0
    pmf[1:101] /= pmf[1:101].sum()
    _PRIOR = pmf


_build_prior()


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future fill."""
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Blend empirical histogram with the fixed prior, so estimates are
    # reasonable early on but adapt as items are seen.
    emp = hist[1:101]
    emp_sum = emp.sum()
    emp_norm = emp / emp_sum if emp_sum > 0 else np.zeros(100)
    prior_norm = _PRIOR[1:101]
    weight = min(emp_sum / (emp_sum + 200.0), 1.0)  # prior dominates early
    prob = weight * emp_norm + (1.0 - weight) * prior_norm
    prob = np.clip(prob, 1e-6, None)
    prob /= prob.sum()

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx - 1]

    remaining = max(n_items - st["n"], 0.0)

    # Reward residuals likely fillable exactly by a single future item.
    score += p_fill * 300.0
    score += (p_fill * remaining) * 60.0

    # Reward placing into a bin whose residual before placement == item,
    # closing the bin exactly.
    score += (bins == item).astype(np.float64) * 400.0

    # Mode-residual bonus: prefer leaving a residual equal to the most common
    # item size, weighted by how common it is.
    mode_idx = int(np.argmax(prob)) + 1
    p_mode = float(prob[mode_idx - 1])
    score += (post_idx == mode_idx).astype(np.float64) * p_mode * 800.0

    return score
# EVOLVE-BLOCK-END
