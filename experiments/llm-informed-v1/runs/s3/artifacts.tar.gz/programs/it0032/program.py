# EVOLVE-BLOCK-START
"""Best fit enhanced with a one-step lookahead: prefer placements whose residual
is likely to be filled exactly by a typical upcoming item, estimated online."""
import numpy as np

_state = {
    "residuals": None,        # array of remaining capacity of all bins (my view)
    "item_sizes": None,       # list of observed item sizes
    "counts": None,           # histogram of observed sizes 1..100
    "n": 0,
}


def _init(n_bins):
    _state["residuals"] = np.full(n_bins, 100, dtype=np.int64)
    _state["counts"] = np.zeros(101, dtype=np.int64)
    _state["item_sizes"] = []
    _state["n"] = 0


def priority(item, bins):
    n_bins = len(bins)
    if _state["residuals"] is None or len(_state["residuals"]) != n_bins:
        _init(n_bins)
    st = _state
    res = st["residuals"]

    # Record observation (item sizes seen so far)
    st["counts"][item] += 1
    st["item_sizes"].append(item)
    st["n"] += 1

    # Map: bins shown are those with residual >= item. Find their indices.
    # We reconstruct by matching: bins array is in bin order, containing residuals
    # of fitting bins. We know our own full residual vector; pick indices where
    # residual >= item, in order.
    fit_mask = res >= item
    fit_idx = np.nonzero(fit_mask)[0]
    # bins corresponds to res[fit_idx] (same order, copy)
    # Safety: lengths should match.
    if len(fit_idx) != len(bins):
        # fall back: rebuild from scratch by assuming bins are the fitting ones
        fit_idx = None

    # Build a distribution over upcoming item sizes from observed histogram.
    # Laplace-smoothed; also weight toward the mean region.
    counts = st["counts"].astype(np.float64)
    total = counts.sum()
    if total < 10:
        # Not enough data: pure best fit.
        return -(bins - item)

    # Probability an upcoming item has size s.
    # Smooth heavily to avoid overfitting; use a mixture with overall shape.
    sizes = np.arange(1, 101, dtype=np.float64)
    # Add pseudocount proportional to a broad prior (uniform).
    prior = 0.5
    p = (counts[1:101] + prior)
    p = p / p.sum()

    # For a candidate residual r after placing item, the "value" of leaving r
    # is the probability mass on item sizes that fit snugly into r, plus the
    # chance it's nearly filled. We want to avoid leaving unusable slivers.
    # Score = fit_quality (tightness) + expected fill bonus of residual.
    if fit_idx is None:
        # Degenerate fallback
        return -(bins - item)

    r_after = res[fit_idx] - item  # residual after placement for each candidate

    # Expected bonus: probability that a future item exactly fills r_after
    # (or fits leaving small waste). Compute for each candidate.
    # Use cumulative: fraction of upcoming-item mass with size <= r_after that
    # is "large enough to matter" -> reward residuals that can host a typical item.
    cum = np.cumsum(p)  # cum[s-1] = P(size <= s)
    # Probability a random item fits in residual r: P(size <= r)
    fit_prob = np.where(r_after > 0, cum[np.clip(r_after - 1, 0, 99)], 0.0)
    # Probability a random item *exactly* fits, weighted (encourage exact packing)
    exact_prob = np.where((r_after >= 1) & (r_after <= 100), p[np.clip(r_after - 1, 0, 99)], 0.0)

    # Combined score: prefer tight fit (small r_after) but also reward residuals
    # that are likely reusable. Tightness dominates.
    score = -(r_after.astype(np.float64)) + 30.0 * exact_prob + 8.0 * fit_prob

    # Update our recorded residual for the chosen bin after harness places it.
    # We don't know which bin harness picks yet; it picks max score (first tie).
    best = int(np.argmax(score))
    chosen_idx = int(fit_idx[best])
    res[chosen_idx] -= item

    return score
# EVOLVE-BLOCK-END
