# EVOLVE-BLOCK-START
"""Best fit with a small reward for leaving room for another item of the same size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit -> smaller residual is better.
    score = -residual.astype(np.float64)
    # Small bonus when the residual can still hold another item of this same size.
    score += 0.05 * (residual >= item)
    return score
# EVOLVE-BLOCK-END
