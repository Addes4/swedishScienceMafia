# EVOLVE-BLOCK-START
"""Best fit plus exact-fill and perfect-pair bonuses."""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Rank bins: prefer tight fits, exact fills, and complementary pairs.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1

    post = bins - item
    # Base: best fit => smallest post-placement residual is best.
    score = -post.astype(np.float64)

    # Bonus: exact fill (no residue left).
    score += (post == 0).astype(np.float64) * 1000.0

    # Bonus: perfect complementary pair, post-placement residual equals item size.
    score += (post == item).astype(np.float64) * 500.0

    # Bonus: completing a planned pair (residual before placement == item).
    score += (bins == item).astype(np.float64) * 500.0

    return score
# EVOLVE-BLOCK-END


