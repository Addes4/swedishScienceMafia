# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference, lookahead bonuses computed from a
smoothed item-size distribution (decayed counts pooled with a fixed prior),
complementary pairing, and a pair-closure signal."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.999

# Fixed prior shape (roughly Weibull-like, mean ~40) used to smooth the
# empirical item-size distribution.  precomputed once.
_PRIOR = None


def _build_prior():
    """A smooth, unimodal density over item sizes 1..100 matching the known
    Weibull-shaped distribution (mean about 40)."""
    x = np.arange(101, dtype=np.float64)
    # Weibull shape k=1.5, scale lam chosen so mean ~40.
    k = 1.5
    from math import gamma
    lam = 40.0 / gamma(1.0 + 1.0 / k)
    dens = (k / lam) * (x / lam) ** (k - 1.0) * np.exp(-((x / lam) ** k))
    dens[0] = 0.0
    dens /= dens.sum()
    return dens


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and likelihood of a future fill."""
    global _PRIOR
    if _PRIOR is None:
        _PRIOR = _build_prior()

    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Scale best-fit strength with fragmentation.
    mean_item = float((hist * np.arange(101, dtype=np.float64)).sum() / max(total, 1.0))
    if mean_item < 1.0:
        mean_item = 40.0
    small_resid = np.count_nonzero((bins > 0) & (bins < mean_item))
    frac_small = small_resid / max(len(bins), 1)
    score *= (1.0 + 3.0 * frac_small)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Smoothed item-size distribution: pool empirical counts with the fixed
    # prior so probability estimates are stable even early on.
    prior_count = 100.0
    emp = hist.copy()
    emp[0] = 0.0
    prob = (emp + prior_count * _PRIOR) / (total + prior_count)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    remaining = max(n_items - st["n"], 0.0)
    exp_fill = remaining * p_fill

    score += p_fill * 300.0

    # Reward closing a bin exactly.
    score += (bins == item).astype(np.float64) * 400.0

    score += exp_fill * 60.0

    # Pair-closure lookahead from the smoothed distribution.
    pair_prob = np.zeros(101, dtype=np.float64)
    p = prob[1:101]
    conv = np.convolve(p, p)
    pair_prob[1:101] = conv[:100]
    p_pair = np.zeros_like(score)
    if valid.any():
        p_pair[valid] = pair_prob[post_idx[valid]]

    n_pairs = remaining * max(remaining - 1.0, 0.0) * 0.5
    pair_weight = min(n_pairs / max(n_items, 1.0), 5.0)
    score += p_pair * pair_weight * 4000.0

    # Mode-residual bonus.
    mode_idx = int(np.argmax(prob[1:101])) + 1
    p_mode = float(prob[mode_idx])
    score += (post_idx == mode_idx).astype(np.float64) * p_mode * 800.0

    return score
# EVOLVE-BLOCK-END
