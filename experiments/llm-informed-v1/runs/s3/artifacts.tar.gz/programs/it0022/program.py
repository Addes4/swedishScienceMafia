# EVOLVE-BLOCK-START
"""Best fit with a learned tie-break that favors leaving a reusable residual.

The classic best fit chooses the bin minimizing the post-placement residual
(bins - item), i.e. maximizing -residual.  We keep that as the dominant term, but
add a small bonus when the resulting residual exactly equals a size that has been
seen frequently so far.  A residual equal to a common item size is much more
likely to be reused exactly, so it is not a wasted sliver.
"""
import numpy as np

# module-level state (fresh per instance/process)
_seen = None
_counts = None
_seen_total = 0
_last_len = 0


def _update(item):
    global _seen, _counts, _seen_total, _last_len
    if _seen is None:
        # sizes 1..100
        _seen = np.zeros(101, dtype=np.float64)
        _counts = np.zeros(101, dtype=np.float64)
    _seen[item] += 1.0
    _seen_total += 1


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, first on ties."""
    # Track the item-size histogram to know which residuals are "common".
    _update(item)

    residual = bins - item  # post-placement remaining capacity (>= 0 for shown bins)

    # Dominant term: tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Small bonus proportional to how common the resulting residual size is.
    # Normalized frequency in [0, 1], scaled to stay well below the tightest-fit gap.
    if _seen_total > 8:
        freq = _seen / _seen_total
        # only reward exact reusable residuals (residual in 1..100)
        idx = np.clip(residual, 0, 100).astype(np.int64)
        bonus = np.where(residual > 0, freq[idx], 0.0)
        score = score + 0.5 * bonus

    return score
# EVOLVE-BLOCK-END
