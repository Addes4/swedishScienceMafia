# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference, empirical future-fill lookahead
scaled by the number of items left, complementary pairing, and a
pair-closure signal, with bucket-smoothed item-size distribution."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.999
_BUCKET = 4


def _bucketize(hist):
    """Smooth the empirical item-size counts into coarse buckets.

    Returns a length-101 float array `bprob` where bprob[s] is the smoothed
    probability mass assigned to item size s (each size gets the average of
    its bucket), which greatly reduces sampling noise.
    """
    counts = hist[1:101].copy()
    # Bucket sums.
    nb = (100 + _BUCKET - 1) // _BUCKET
    bs = np.zeros(nb, dtype=np.float64)
    idx = np.arange(100)
    bidx = idx // _BUCKET
    np.add.at(bs, bidx, counts)
    bcount = np.bincount(bidx, minlength=nb).astype(np.float64)
    mean_per = bs / np.maximum(bcount, 1.0)
    # Distribute each size the mean of its bucket.
    prob = np.zeros(101, dtype=np.float64)
    prob[1:101] = mean_per[bidx]
    total = prob.sum()
    if total <= 0.0:
        prob[1:101] = 1.0
        total = prob.sum()
    return prob / total, counts


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Scale best-fit strength with fragmentation: when many open bins have
    # small residuals, consolidating (best-fit) matters more.
    mean_item = float((hist * np.arange(101, dtype=np.float64)).sum() / max(hist.sum(), 1.0))
    if mean_item < 1.0:
        mean_item = 40.0
    small_resid = np.count_nonzero((bins > 0) & (bins < mean_item))
    frac_small = small_resid / max(len(bins), 1)
    score *= (1.0 + 3.0 * frac_small)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Bucket-smoothed item-size distribution (much less noisy).
    prob, counts = _bucketize(hist)
    total = float(counts.sum())

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        p_fill[valid] = prob[post_idx[valid]]

    remaining = max(n_items - st["n"], 0.0)
    exp_fill = remaining * p_fill

    score += p_fill * 300.0

    # Reward placing into a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0

    score += exp_fill * 60.0

    # Pair-closure lookahead using the smoothed distribution.
    p = prob[1:101]
    conv = np.convolve(p, p)
    pair_prob = np.zeros(101, dtype=np.float64)
    pair_prob[1:101] = conv[:100]
    p_pair = np.zeros_like(score)
    if valid.any():
        p_pair[valid] = pair_prob[post_idx[valid]]

    n_pairs = remaining * max(remaining - 1.0, 0.0) * 0.5
    pair_weight = min(n_pairs / max(n_items, 1.0), 5.0)
    score += p_pair * pair_weight * 4000.0

    # Mode-residual bonus using smoothed distribution.
    mode_idx = int(np.argmax(prob[1:101])) + 1
    p_mode = float(prob[mode_idx])
    score += (post_idx == mode_idx).astype(np.float64) * p_mode * 800.0

    return score
# EVOLVE-BLOCK-END
