# EVOLVE-BLOCK-START
"""Best-fit bin choice with exact-fill priority and a fuller-bin tie-break."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit: prefer smallest post-placement residual.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    post = bins - item  # residual after placing the item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 1e6

    # Tie-break toward the fuller bin (smaller pre-placement capacity),
    # which is the standard best-fit tie-break and reduces fragmentation
    # versus an arbitrary first-bin tie.
    score -= bins.astype(np.float64) * 1e-3

    return score
# EVOLVE-BLOCK-END
