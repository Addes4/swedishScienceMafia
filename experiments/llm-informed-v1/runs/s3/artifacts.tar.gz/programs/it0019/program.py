# EVOLVE-BLOCK-START
"""Best fit with a gentle sliver guard driven by observed item statistics."""
import numpy as np

_state = {"sum": 0.0, "n": 0, "max": 0}


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties).

    Base rule is best-fit (smallest post-placement residual).  We add a small
    penalty for residuals that are too small to be plausibly reusable by a
    future item (estimated from the running mean of observed sizes), which
    discourages stranding unusable slivers without losing tight packing.
    """
    # Update running statistics of observed items.
    st = _state
    st["sum"] += item
    st["n"] += 1
    if item > st["max"]:
        st["max"] = item

    mean = st["sum"] / st["n"]

    residual = bins - item  # post-placement residual for each fitting bin

    # Penalty grows as the residual falls below roughly half the mean item size
    # (such slivers are unlikely to be exactly reusable).
    thresh = 0.5 * mean
    # Smooth penalty: 0 when residual >= thresh, ramps up as residual shrinks.
    pen = np.where(residual < thresh, (thresh - residual) / max(thresh, 1e-9), 0.0)

    # Best-fit primary term plus a small sliver penalty.
    score = -residual - 0.5 * pen
    return score
# EVOLVE-BLOCK-END
