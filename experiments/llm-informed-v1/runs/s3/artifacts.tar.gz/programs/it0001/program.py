# EVOLVE-BLOCK-START
"""Best-fit with a reserved empty bin to reduce fragmentation."""
import numpy as np

_state = {"n": None, "seen": 0, "remaining": None, "chosen": None}


def priority(item, bins):
    """Best fit, but keep one empty bin in reserve once packing is under way."""
    n = len(bins)
    st = _state
    if st["n"] != n:
        st["n"] = n
        st["seen"] = 0
        st["remaining"] = np.full(n, 100, dtype=np.int64)
    st["seen"] += 1

    # best fit score: prefer smallest residual capacity that still fits
    score = -(bins - item).astype(np.float64)

    # Reserve one empty bin: if we're past the first item and there is more than
    # one completely empty bin available, penalize all but the last one slightly
    # so they aren't each nibbled at, delaying the need for a new bin.
    empties = np.nonzero(bins == 100)[0]
    if st["seen"] > 1 and len(empties) > 1:
        score[empties[:-1]] -= 1000.0

    idx = int(np.argmax(score))
    st["remaining"][idx] -= item
    return score
# EVOLVE-BLOCK-END

