# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference plus a calibrated single-item
expected-fill lookahead, using a decayed empirical item distribution.
Best-fit is the primary signal; the lookahead only breaks near-ties."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.999


def priority(item, bins):
    """Rank bins by best fit, exact fill, and expected future exact fill."""
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))
    remaining = max(n_items - st["n"], 0.0)

    post = bins - item  # residual after placing item here
    post_idx = post.astype(np.int64)

    # Primary signal: best fit (smallest post-placement residual).
    score = -post.astype(np.float64)

    # Exact fill: strongly preferred, but the best-fit term already puts it
    # at the top; keep a modest bonus for safety against float ties.
    score += (post == 0).astype(np.float64) * 1000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        p_fill[valid] = prob[post_idx[valid]]

    # Expected number of future exact single-item fills for this residual,
    # calibrated to act only as a tie-breaker among similar residuals.
    exp_fill = remaining * p_fill
    score += exp_fill * 1.0

    # Bonus for filling a bin whose residual already equals the item
    # (closing it exactly), scaled to stay secondary to best-fit.
    score += (bins == item).astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
