# EVOLVE-BLOCK-START
"""Best fit plus targeted bonuses for exact and high-probability future fills."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tight fits, exact fills, and residuals likely to be refilled.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    post = bins - item
    # Base: best fit => smallest post-placement residual is best.
    score = -post.astype(np.float64)
    # Bonus: exact fill (no residue left) — always good.
    score += (post == 0).astype(np.float64) * 1000.0
    # Bonus: residual exactly equals the item size, so a future same-size item
    # could fill it exactly (perfect complementary pair).
    score += (post == item).astype(np.float64) * 500.0
    # Bonus: residual is large enough to still hold a typical (mean-size) item,
    # which is more likely to be usable than a tiny wasted gap.
    score += (post >= 40).astype(np.float64) * 5.0
    # Mild penalty: residual too small to ever hold another item wastes capacity.
    score -= ((post > 0) & (post < 10)).astype(np.float64) * 5.0
    return score
# EVOLVE-BLOCK-END

