# EVOLVE-BLOCK-START
"""Distribution-aware best fit: avoid stranding tiny residuals, favor reusable residuals."""
import numpy as np

_state = {
    "counts": np.zeros(101, dtype=np.int64),  # histogram of seen item sizes
    "n": 0,
}


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties).

    Primary: best fit (smallest resulting residual).
    Adjustment: penalize resulting residuals that are too small to be reusable
    (they waste capacity), and give a small bonus to residuals that exactly
    match a frequently observed item size (reusable later).
    """
    counts = _state["counts"]
    n = _state["n"]

    residual = bins - item  # >= 0 for bins that fit

    # Reusability estimate for a residual r: probability-like frequency of an
    # item of size r appearing (relative to typical), computed cheaply.
    # Avoid heavy per-bin loops: use vectorized histogram lookup.
    idx = residual  # in 0..100
    freq = counts[idx] / (n + 1.0)  # relative frequency of exact size match

    # Penalty for tiny stranded residuals (dead space) that fit no common item.
    # dead[r] grows as r gets small.
    tiny_pen = np.where(idx <= 3, (4.0 - idx), 0.0)

    # Score: strongly prefer small residual (best fit), but subtract tiny
    # residual penalty and add reuse bonus scaled to match frequency.
    score = -(residual.astype(np.float64)) - 8.0 * tiny_pen + 6.0 * freq

    # Update statistics (item just seen, before it is placed, is fine to count).
    counts[item] += 1
    _state["n"] = n + 1

    return score
# EVOLVE-BLOCK-END

