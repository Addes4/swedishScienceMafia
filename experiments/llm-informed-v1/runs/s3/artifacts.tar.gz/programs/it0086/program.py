# EVOLVE-BLOCK-START
"""Online bin packing: best fit, but open a fresh bin only when it is worthwhile."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: smallest post-placement residual wins.
    residual = bins - item

    # Ties (equal residual) are broken to the earlier bin by the harness,
    # which is what we want.
    return -residual
# EVOLVE-BLOCK-END

