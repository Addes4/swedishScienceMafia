# EVOLVE-BLOCK-START
"""Best fit with empirical future-fill lookahead, complementary pairing, and
single-partner completion lookahead."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
    "mode": 0,
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 20000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    # Probability mass of a single future item matching the residual.
    p_mass_total = 1.0 - prob[0]  # prob[0] unused, prob has len 101

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]
    score += p_fill * 500.0

    # Pairing bonus: residual equals the item size -> future identical item
    # closes it exactly.
    score += (post == item).astype(np.float64) * 800.0

    # Reward completing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 800.0

    # Single-partner completion: the most likely remaining capacity that the
    # residual could be filled by in one more item is itself just prob[idx];
    # additionally reward residuals whose size is common (above uniform).
    common = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        common[valid] = (prob[idx] - 0.01) * 100.0   # 0.01 ~ uniform baseline
    score += common * 150.0

    return score
# EVOLVE-BLOCK-END

