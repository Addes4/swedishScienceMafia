# EVOLVE-BLOCK-START
"""Best fit with exact-fill dominance and a calibrated future-completion
lookahead based on remaining items."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
    "N": 0.0,                                   # total items in instance
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and expected future completion.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    # On the first call every bin is unused, so len(bins) == number of items.
    if st["N"] == 0.0:
        st["N"] = float(len(bins))
    remaining = st["N"] - total  # items still to arrive after this one

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    # Expected number of future items that could exactly fill this residual.
    # Calibrated so it refines ties among comparable best-fit residuals but
    # never overrides the primary best-fit ordering beyond small nudges.
    if valid.any():
        idx = post_idx[valid]
        exp_fill = prob[idx] * max(remaining, 0.0)
        log_factor = np.minimum(exp_fill, 5.0)   # bounded so it can't dominate
        score[valid] += log_factor * 20.0

    # Reward using a bin whose current residual equals the item (immediate fill).
    score += (bins == item).astype(np.float64) * 400.0

    return score
# EVOLVE-BLOCK-END

