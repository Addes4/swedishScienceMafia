# EVOLVE-BLOCK-START
"""Best fit with a tie-break that favors leaving a residual equal to a common item size."""
import numpy as np

_state = {"sizes": None, "counts": None, "n": 0}


def priority(item, bins):
    st = _state
    if st["sizes"] is None or len(st["sizes"]) != len(bins) + st["n"]:
        # initialize per-instance state on first call
        st["sizes"] = np.zeros(len(bins), dtype=np.int64)
        st["counts"] = np.zeros(101, dtype=np.int64)
        st["n"] = 0
    # record this item
    st["sizes"][st["n"]] = item
    st["n"] += 1
    st["counts"][item] += 1

    residual = bins - item  # resulting remaining capacity (>= 0 for fitting bins)

    # best fit: smallest resulting residual first
    score = -residual.astype(np.float64)

    # Build a lookup of which residuals are "good" (equal a frequent seen size).
    counts = st["counts"]
    # rank sizes by frequency, take those with count >= 2 as useful targets
    # bonus for leaving residual equal to a commonly seen item size
    bonus = np.zeros(len(bins), dtype=np.float64)
    # Only consider residuals up to 100
    valid = residual >= 0
    # For each bin, check if its residual matches a frequent size
    freq = counts
    # bonus amount: small relative to 1 (residual granularity), used only for tie-breaking
    # use 0.001 * frequency weight to stay sub-unit so best-fit ordering dominates
    for i in range(len(bins)):
        r = residual[i]
        if r <= 100 and freq[r] >= 2:
            bonus[i] = 0.001 * (freq[r] - 1)

    score = score + bonus
    return score
# EVOLVE-BLOCK-END
