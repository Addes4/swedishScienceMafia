# EVOLVE-BLOCK-START
"""Best fit with empirical future-fill lookahead, complementary pairing,
two-item sum-completion lookahead, and remaining-items scaling."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    # Number of items remaining after this one; len(bins) equals total items
    # for the instance (all bins shown on the first call are unused).
    remaining_frac = max(0.0, (float(len(bins)) - total) / float(len(bins)))

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred (kept dominant, unscaled).
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Lookahead: probability that a future single item exactly equals the
    # residual, estimated from the running histogram.  Scaled by remaining
    # fraction so it matters more when future items can still arrive.
    score += p_fill * 300.0 * remaining_frac

    # Pairing bonus: if the residual after placement equals the item size,
    # a future identical item can close it exactly.
    score += (post == item).astype(np.float64) * 400.0 * remaining_frac

    # Reward completing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0 * remaining_frac

    # Two-sided commonness signal: reward residuals whose size is more common
    # than average, penalize rare residuals.
    common = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        common[valid] = (prob[idx] - 0.01) * 100.0   # 0.01 ~ uniform baseline
    score += common * 150.0 * remaining_frac

    # Two-item sum-completion lookahead: probability that the residual can be
    # exactly filled by the sum of two future items.
    if valid.any():
        p2 = np.convolve(prob[1:101], prob[1:101])  # index s-2 -> sum s
        pw = np.zeros_like(score)
        sums = post_idx[valid]
        p2v = p2[sums - 2]
        pw[valid] = p2v
        score += pw * 120.0 * remaining_frac

    return score
# EVOLVE-BLOCK-END

