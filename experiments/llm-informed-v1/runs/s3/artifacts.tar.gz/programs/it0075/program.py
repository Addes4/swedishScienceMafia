# EVOLVE-BLOCK-START
"""Stateful best-fit variant: strong bonus for exact fits, mild preference for
residuals near the empirical median item size, computed online."""
import numpy as np

_state = {"seen": [], "n": None}

def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins."""
    seen = _state["seen"]
    if _state["n"] is None:
        _state["n"] = len(bins)
    seen.append(item)

    # empirical median item size so far (robust, cheap enough with sampling)
    if len(seen) >= 16:
        # sample the recent history to keep cost low
        s = seen[-512:]
        med = float(np.median(np.asarray(s, dtype=np.float64)))
    else:
        med = 40.0

    residual = bins - item  # post-placement residual
    # best-fit base: larger residual (less tight) => lower score
    score = -residual.astype(np.float64)

    # strong bonus for exact fit
    score += 1e6 * (residual == 0)

    # mild bonus for residuals close to the empirical median item size,
    # which keeps partially filled bins useful for future typical items
    score -= 0.05 * np.abs(residual - med)

    return score
# EVOLVE-BLOCK-END
