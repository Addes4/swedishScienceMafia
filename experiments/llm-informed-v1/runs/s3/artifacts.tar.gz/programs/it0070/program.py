# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a slack-target refinement.

Pure best fit (place the item in the bin where it fits most tightly) is a strong
online rule for this distribution.  The one systematic weakness is that it keeps
fragmenting bins: after placing a medium item we often leave a small residual
that no future item can fill, wasting the bin.

We track the sizes of all items seen so far (we can see every item size, and we
know how many items remain).  From those sizes we estimate the smallest common
item size ("filler size").  When ranking bins we still primarily use best fit,
but we nudge the choice toward bins whose *post-placement* residual will be at
least the filler size, so that the leftover space remains usable by a future
small item instead of being an unfillable sliver.  Ties and near-ties are broken
by true best fit, so we never do worse than best fit on exact matches.
"""
import numpy as np

# module level state, reset for each fresh process/instance
_sizes = []          # all item sizes seen so far
_filler = 0          # estimated smallest common item size


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest score.

    item: integer size of the arriving item (1..100).
    bins: numpy int64 array of remaining capacities of fitting bins, in bin order.
    """
    global _filler

    # --- remember this item and keep a cheap running estimate of the filler size
    n = len(_sizes)
    _sizes.append(item)
    if n < 200:
        # warm-up: just use best fit until we know something about the sizes
        return -(bins - item)

    if (n & 63) == 0:
        # recompute a robust "small common size" every 64 items.
        # use the 10th percentile of sizes seen, which tends to be a size that
        # occurs often enough to be a good gap filler.
        arr = np.asarray(_sizes, dtype=np.int64)
        _filler = int(np.percentile(arr, 10))
        if _filler < 1:
            _filler = 1

    # --- best fit residual
    residual = bins - item

    # --- secondary term: reward post-placement residuals that are >= filler,
    #     penalize unfillable slivers (0 < residual < filler).
    f = _filler
    # 0 residual is perfect (bin exactly filled) -> always good.
    sliver = (residual > 0) & (residual < f)

    # primary score: tighter fit is better.
    score = -residual.astype(np.float64)

    # penalty for leaving an unusable sliver; magnitude smaller than 1 so it only
    # breaks ties / near-ties and cannot override a genuinely better fit.
    score -= 0.5 * sliver

    return score
# EVOLVE-BLOCK-END
