# EVOLVE-BLOCK-START
"""Best fit with a large-item reservation rule."""
import numpy as np

_state = {}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    n = len(bins)

    # Initialize per-instance state on the first call.
    if not _state or _state.get("n") != n:
        _state.clear()
        _state["n"] = n
        _state["res"] = np.full(n, 100, dtype=np.int64)   # my view of all residuals
        _state["count"] = 0
        _state["sum"] = 0.0
        _state["max_seen"] = 0

    res = _state["res"]
    seen = _state["count"]
    s = _state["sum"]
    max_seen = _state["max_seen"]
    total = n  # number of items in the instance

    # Estimated mean of the distribution (Weibull-shaped, mean ~40).
    mean_est = (s + item) / (seen + 1) if seen > 0 else 40.0

    # A size is "large" if it is well above the running mean.
    large_threshold = 1.15 * mean_est

    is_small = item < large_threshold

    # Prefer a fitting bin that isn't a fresh, empty (residual == 100) bin
    # when the item is small, but never override an exact fit.
    caps = bins  # residual capacities of fitting bins (remaining capacity after is item-agnostic)
    post = caps - item  # residual after placing this item in each shown bin

    # Bonus for non-empty bins when item is small: penalize fresh bins.
    score = -(post.astype(np.float64))

    if is_small:
        # small penalty to placing into a completely unused bin (residual 100)
        fresh = (caps == 100)
        score = score - fresh.astype(np.float64) * 5.0

    # exact-fit bonus
    exact = (post == 0)
    score = score + exact.astype(np.float64) * 1.0

    # Update our full-residual view: find which underlying bin got chosen.
    # We can't directly know the index mapping, so reconstruct: choose best idx in shown array.
    best_i = int(np.argmax(score))
    chosen_cap = int(caps[best_i])

    # Update state.
    _state["count"] = seen + 1
    _state["sum"] = s + item
    _state["max_seen"] = max(max_seen, item)

    # Try to mirror the choice in our residual array: match chosen_cap among bins with that cap.
    if seen == 0:
        # first item: bins are all fresh; just mark one
        res[0] = 100 - item
    else:
        # find a bin in res with residual == chosen_cap (approx; capacities in `bins` are a subset)
        match = np.where(res == chosen_cap)[0]
        if len(match) > 0:
            # prefer the one that wasn't fresh if item is small
            idx = match[0]
            if is_small:
                for m in match:
                    if res[m] != 100:
                        idx = m
                        break
            res[idx] -= item

    return score
# EVOLVE-BLOCK-END
