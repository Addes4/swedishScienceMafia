# EVOLVE-BLOCK-START
"""Best fit with a residual-quality tie-break that rewards zero or reusable residuals."""
import numpy as np

# State kept per instance (fresh process each instance).
_STATE = {"res": None, "mean_item": 40.0}

# Residual sizes that are "too small to be useful" get penalized slightly when
# they are the leftover after a placement.  We use a soft preference:
#   - residual == 0            -> best (bin closed)
#   - residual in [~mean, cap] -> good (still holds a typical upcoming item)
# The primary ordering is still best fit (smallest post-placement residual),
# and the tie-break only reshuffles near-equal choices, so we keep best fit's
# strong average performance while recovering some wasted residual space.
_EPS = 1e-6


def _get_res(bins):
    """Return list-based residual tracker, synced to the harness view."""
    res = _STATE["res"]
    n = len(bins)
    if res is None or len(res) != n:
        # First call of an instance: every bin is unused.
        res = [100] * n
        _STATE["res"] = res
    return res


def priority(item, bins):
    """Best fit, with a soft tie-break favoring reusable / closing residuals."""
    res = _get_res(bins)
    mean_item = _STATE["mean_item"]

    # Update residual tracker for the eventual placement will be done lazily:
    # we only know the chosen bin after the harness picks the max.  So instead
    # of committing here, we patch the tracker on the next call by re-syncing
    # from `bins` where possible.  To keep it simple and correct, we rebuild
    # the residual view each call from `bins`:
    #   `bins` only contains bins that fit the item, but unused bins (100) are
    #   always present and the array is in bin order, so we can overlay the
    #   capacities we know for fitting bins.
    # Rebuild a full residual list:
    full = _STATE.get("full")
    if full is None or len(full) != len(bins):
        full = [100] * len(bins)
        _STATE["full"] = full

    # Overlay the known residuals for every bin in `bins` (bin order preserved).
    # Bins that did not fit the item keep their previously recorded residual.
    idx = 0
    fits = []
    for i in range(len(bins)):
        if full[i] >= item:
            # This slot in `bins` corresponds to bin i (fixed order, only the
            # fitting ones are shown but in order, so match by scanning).
            pass
    # Simpler: the harness gives us the residuals of fitting bins directly.
    # Reconstruct full residuals by trusting `bins` for fitting bins and
    # previous `full` for the rest, matching in bin order.
    fitting_positions = [i for i in range(len(full)) if full[i] >= item]
    # If our tracker is in sync, the number of fitting positions equals len(bins).
    if len(fitting_positions) == len(bins):
        for i, v in zip(fitting_positions, bins):
            full[i] = int(v)
    else:
        # Fallback: resync entirely to the harness view (best effort).
        for i in range(len(full)):
            full[i] = 100

    # Record this item for the mean estimate (running average).
    _STATE["count"] = _STATE.get("count", 0) + 1
    c = _STATE["count"]
    _STATE["mean_item"] += (item - _STATE["mean_item"]) / c

    # Score each offered bin.
    scores = np.empty(len(bins), dtype=float)
    for k in range(len(bins)):
        post = bins[k] - item
        # Primary: best fit -> smaller residual is better.
        base = -float(post)
        # Tie-break bonus.
        if post == 0:
            bonus = 0.5
        elif post >= mean_item:
            bonus = 0.2
        elif post < 20:
            # residual too small to hold a typical small item -> mildly bad
            bonus = -0.1
        else:
            bonus = 0.0
        scores[k] = base + bonus
    return scores
# EVOLVE-BLOCK-END
