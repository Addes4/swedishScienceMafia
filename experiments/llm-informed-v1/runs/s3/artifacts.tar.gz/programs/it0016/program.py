# EVOLVE-BLOCK-START
"""Best fit with a light distribution-aware tie-breaker.

Main rule: strongly prefer the tightest fit (smallest residual after placement).
Tie-breaker: among bins with the same minimal residual, prefer residuals that are
likely to be exactly fillable later, based on the observed item-size histogram.
This keeps best-fit's strong packing behaviour while occasionally preserving
"perfect fit" residuals for the future.
"""
import numpy as np

# module state (fresh per instance)
_count = None      # counts of item sizes seen so far (size 1..100)
_total = 0         # number of items seen so far
_scale = 1.0       # small bonus scale


def priority(item, bins):
    global _count, _total, _scale

    if _count is None:
        _count = np.zeros(101, dtype=np.float64)

    residual = bins - item  # post-placement remaining capacity (>=0)

    # small bonus if the residual matches a frequently seen item size,
    # so it can be exactly filled later; scaled to be << 1 so it only
    # breaks ties among equal residuals.
    if _total > 0:
        freq = _count / _total
        # bonus for residuals that are plausible future item sizes
        r = np.clip(residual, 0, 100)
        bonus = freq[r.astype(np.int64)]
    else:
        bonus = np.zeros_like(residual)

    score = -residual.astype(np.float64) + _scale * bonus

    # record the item for future histogram use
    _count[item] += 1.0
    _total += 1
    # keep bonus comfortably below 1 so it never overrides residual ordering
    _scale = 1.0 / (1.0 + _total)
    return score
# EVOLVE-BLOCK-END

