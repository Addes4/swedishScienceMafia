# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and a bounded, empirically-estimated
lookahead term (single-item and pair fill probability) that can only break
near-ties among similar residuals, keeping consolidation dominant."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.998


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and bounded future-fill likelihood.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here
    post_f = post.astype(np.float64)

    # Base: best fit -> smallest post-placement residual dominates.
    score = -post_f

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 1e6

    # Laplace-smoothed item-size distribution (over sizes 1..100).
    prob = (hist[1:101] + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    # Single-item fill probability for the residual.
    p_single = np.zeros_like(score)
    if valid.any():
        p_single[valid] = prob[post_idx[valid] - 1]

    # Pair-fill probability: residual can be exactly covered by two future
    # items (convolution of the distribution with itself).
    conv = np.convolve(prob, prob)          # index s-2 -> P(sum == s)
    pair_prob = np.zeros(101, dtype=np.float64)
    for s in range(2, 101):
        pair_prob[s] = conv[s - 2]
    p_pair = np.zeros_like(score)
    if valid.any():
        p_pair[valid] = pair_prob[post_idx[valid]]

    # How much future opportunity remains (fraction of instance still to come).
    remaining = max(n_items - st["n"], 0.0)
    frac_left = remaining / max(n_items, 1.0)

    # Expected number of future fill events for this residual.
    exp_single = remaining * p_single
    exp_pair = (remaining * remaining * 0.5) * p_pair

    # Bounded desirability: combine the two fill channels, saturate so it can
    # never dominate the best-fit ordering for clearly different residuals.
    desirability = exp_single + 0.25 * exp_pair
    desirability = np.minimum(desirability, 5.0)

    # Lookahead can only break ties among residuals within ~1 unit of best fit,
    # so scale it modestly and taper near the end of the instance.
    score += desirability * (0.20 + 0.80 * frac_left)

    return score
# EVOLVE-BLOCK-END
