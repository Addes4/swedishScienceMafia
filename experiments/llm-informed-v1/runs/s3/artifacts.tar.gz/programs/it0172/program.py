# EVOLVE-BLOCK-START
"""Best fit with exact-fill and future-completion lookahead scaled by the
number of items still to come."""
import numpy as np

_state = {
    "n": 0.0,
    "total": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and expected future completion.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    if st["n"] == 0.0:
        # first call: len(bins) == number of items in the instance
        st["total"] = float(len(bins))
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)

    # Expected number of future items that would exactly fill this residual:
    # p(residual) * (items remaining).
    remaining = max(st["total"] - total, 0.0)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    exp_fill = p_fill * remaining

    # Reward residuals likely to be closed within the remaining horizon.
    score += np.minimum(exp_fill, 3.0) * 150.0

    # Pairing bonus: if the residual after placement equals the item size,
    # a future identical item can close it exactly.
    score += (post == item).astype(np.float64) * 400.0

    # Reward completing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0

    # Two-item sum-completion lookahead via cheap convolution.
    if valid.any():
        p2 = np.convolve(prob[1:101], prob[1:101])  # sum s -> index s-2
        sums = post_idx[valid]
        pw = np.zeros_like(score)
        pw[valid] = p2[sums - 2]
        score += pw * 120.0

    return score
# EVOLVE-BLOCK-END
