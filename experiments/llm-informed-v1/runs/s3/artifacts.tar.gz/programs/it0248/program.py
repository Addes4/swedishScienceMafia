# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference, complementary closure, and a
self-calibrating exact-fill weight that grows when the packing lags the
lower bound, with exponential forgetting of past items."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
    "opens": 0.0,                              # estimated number of open bins
    "used": 0.0,                               # estimated bins used so far
    "closed": 0.0,                             # exact closures achieved
}

_DECAY = 0.999


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and complementary closure.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Consolidation scaling: stronger best-fit when many bins have small residuals.
    mean_item = float((hist * np.arange(101, dtype=np.float64)).sum() / max(total, 1.0))
    if mean_item < 1.0:
        mean_item = 40.0
    small_resid = np.count_nonzero((bins > 0) & (bins < mean_item))
    frac_small = small_resid / max(len(bins), 1)
    score *= (1.0 + 3.0 * frac_small)

    # Self-calibrating exact-fill weight: grows while lagging the lower bound.
    # Lower bound estimate: sum(item sizes)/100.
    total_size = float((hist * np.arange(101, dtype=np.float64)).sum())
    lb = max(total_size / 100.0, 1.0)
    used = max(st["n"] - st["closed"], lb)
    lag = used / lb
    fill_w = 10000.0
    if lag > 1.02:
        fill_w *= min(1.0 + 0.5 * (lag - 1.0), 2.5)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * fill_w

    if (post == 0).any():
        st["closed"] += 1.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    remaining = max(n_items - st["n"], 0.0)
    exp_fill = remaining * p_fill

    score += p_fill * 300.0

    # Reward closing a bin exactly (bin residual before placement == item).
    score += (bins == item).astype(np.float64) * 400.0

    score += exp_fill * 60.0

    # Pair-closure lookahead: probability this residual can be exactly filled
    # by a pair of typical future items.
    pair_prob = np.zeros(101, dtype=np.float64)
    p = prob[1:101]
    conv = np.convolve(p, p)
    pair_prob[1:101] = conv[:100]
    p_pair = np.zeros_like(score)
    if valid.any():
        p_pair[valid] = pair_prob[post_idx[valid]]

    n_pairs = remaining * max(remaining - 1.0, 0.0) * 0.5
    pair_weight = min(n_pairs / max(n_items, 1.0), 5.0)
    score += p_pair * pair_weight * 4000.0

    # Mode-residual bonus: prefer leaving residual equal to a common item size.
    mode_idx = int(np.argmax(prob[1:101])) + 1
    p_mode = float(prob[mode_idx])
    score += (post_idx == mode_idx).astype(np.float64) * p_mode * 800.0

    return score
# EVOLVE-BLOCK-END
