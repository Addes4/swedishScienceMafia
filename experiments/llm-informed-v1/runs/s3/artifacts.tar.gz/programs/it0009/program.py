# EVOLVE-BLOCK-START
"""Best fit with a pairing-aware tie-break on the residual after placement."""
import numpy as np

# Module state, reset per instance (fresh process).
_state = {"n": None, "seen": 0, "cap": None, "open": None}

import bisect


def _reset(n, cap):
    _state["n"] = n
    _state["seen"] = 0
    _state["cap"] = cap          # dict bin_index -> capacity
    _state["open"] = []          # sorted list of remaining capacities of open bins


def priority(item, bins):
    """Return priority per bin; highest score wins (ties to first)."""
    if _state["cap"] is None:
        # len(bins) == number of items only on the very first call.
        cap = {}
        for i in range(len(bins)):
            cap[i] = int(bins[i])
        _state["cap"] = cap
        _state["open"] = []
        _state["n"] = len(bins)

    cap = _state["cap"]
    n = _state["n"]

    # On the first call every bin has capacity 100.
    if _state["seen"] == 0:
        for i in range(len(bins)):
            cap[i] = int(bins[i])
        _state["open"] = [100] * len(bins)

    seen = _state["seen"]

    # Map the shown `bins` array back to global bin indices.
    # `bins` holds the capacities of the bins the item fits in, in bin order.
    idx = [i for i in range(n) if cap.get(i, -1) >= item]

    res_after = [int(bins[j]) - item for j in range(len(bins)) if int(bins[j]) >= item]
    # Minimal residual = best fit.
    min_res = min(res_after) if res_after else 0

    # Window of tie candidates.
    win = 2
    residuals = sorted(_state["open"])
    scores = np.empty(len(bins), dtype=np.float64)

    for j in range(len(bins)):
        r = int(bins[j]) - item
        if r < 0:
            scores[j] = -1e18
            continue
        s = -float(r)
        if r - min_res <= win and r > 0:
            # Pairing bonus: does some open bin have residual close to r?
            # (an item of size r would then fill that other bin exactly)
            pos = bisect.bisect_left(residuals, r)
            best_d = 1e9
            if pos < len(residuals):
                best_d = abs(residuals[pos] - r)
            if pos > 0:
                d = abs(residuals[pos - 1] - r)
                if d < best_d:
                    best_d = d
            s += 0.5 * (1.0 / (1.0 + best_d))
        scores[j] = s

    # Commit the chosen bin into tracked state.
    choice = int(np.argmax(scores))
    chosen_bin = idx[choice] if choice < len(idx) else idx[-1]
    old = cap.get(chosen_bin, 100)
    cap[chosen_bin] = old - item
    # Update sorted open residuals.
    try:
        p = bisect.bisect_left(_state["open"], old)
        _state["open"].pop(p)
    except Exception:
        pass
    if cap[chosen_bin] > 0:
        bisect.insort(_state["open"], cap[chosen_bin])
    _state["seen"] = seen + 1

    return scores
# EVOLVE-BLOCK-END
