# EVOLVE-BLOCK-START
"""Best fit with a soft residual-usefulness bonus for the typical item size."""
import numpy as np

# Expected mean item size for the Weibull-shaped distribution (~40).
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item

    # Base: prefer tightest fit (smallest leftover) => highest score.
    score = -leftover.astype(np.float64)

    # Soft bonus when the leftover is close to a multiple of the typical item size,
    # so the gap can still be filled later. Strongest for near-zero leftovers (exact fit).
    # Distance to nearest multiple of _MEAN in [0, _MEAN/2].
    r = np.mod(leftover, _MEAN)
    dist = np.minimum(r, _MEAN - r)  # 0 = perfectly usable, grows toward _MEAN/2
    # Small bonus relative to unit capacity steps so tightness still dominates.
    score += 0.5 * (1.0 - dist / (_MEAN * 0.5))

    return score
# EVOLVE-BLOCK-END

