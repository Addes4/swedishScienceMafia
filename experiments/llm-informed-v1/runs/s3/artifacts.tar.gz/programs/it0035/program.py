# EVOLVE-BLOCK-START
"""Best fit with a gentle pull toward residual ~50 (two-item-friendly bins)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (minimize residual).
    # Secondary: mild preference for residuals near half capacity (~50),
    # which keeps bins in a state where roughly one more average item fits.
    return -residual - 0.02 * np.abs(residual - 50)
# EVOLVE-BLOCK-END

