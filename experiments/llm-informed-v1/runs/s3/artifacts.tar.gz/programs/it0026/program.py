# EVOLVE-BLOCK-START
"""Best fit with a size-class (harmonic-style) preference.

Items are grouped into size classes. To pack well, items of the same class are
routed into the same bins so that bins end up with a homogeneous set of residual
capacities, which tends to fill bins more completely than pure best fit and
avoids scattering many tiny unusable residual slivers.
"""
import numpy as np

# Size-class thresholds (multiplicative, harmonic-like).
_CLASS_CUTS = (17, 26, 34, 50)  # 5 classes: <=17, <=26, <=34, <=50, >50


def _class_of(item):
    for c, cut in enumerate(_CLASS_CUTS):
        if item <= cut:
            return c
    return len(_CLASS_CUTS)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest."""
    # Primary: tightest fit (smallest usable residual) -> best fit.
    # Secondary (encoded via a small bonus): prefer bins whose residual is a
    # multiple-friendly capacity for this size class, keeping classes together.
    residuals = bins - item  # nonnegative for all shown bins

    # Base best-fit score (higher = tighter fit).
    score = -residuals.astype(np.float64)

    # Add a mild preference for bins that are NOT empty (capacity 100), so we
    # avoid opening new bins when an existing bin fits well. This is encoded by
    # a tiny bonus proportional to how full the bin already is.
    used = 100.0 - bins.astype(np.float64)  # amount already used
    score += 0.25 * used / 100.0

    return score
# EVOLVE-BLOCK-END
