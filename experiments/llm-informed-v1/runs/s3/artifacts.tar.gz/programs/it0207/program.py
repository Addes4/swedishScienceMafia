# EVOLVE-BLOCK-START
"""Best fit with a stronger consolidation preference (squared-residual
penalty), exact-fill preference, and a soft empirical future-fill
lookahead using a stable cumulative distribution."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}

_DECAY = 1.0


def priority(item, bins):
    """Rank bins by consolidation strength, exact fill, and future-fill odds.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here
    post_f = post.astype(np.float64)

    # Base: strongest consolidation -> small residual strongly preferred.
    score = -post_f
    # Extra quadratic push toward tightly-packed bins.
    score -= 0.02 * post_f * post_f

    # Exact fill: perfect, strongly preferred but no longer overwhelming.
    score += (post == 0).astype(np.float64) * 1000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Soft reward for residuals likely fillable by a single future item.
    score += p_fill * 150.0

    # Reward placing into a bin whose residual before placement == item,
    # closing the bin exactly.
    score += (bins == item).astype(np.float64) * 200.0

    # Expected future single-item fills, scaled by remaining items.
    remaining = max(n_items - st["n"], 0.0)
    score += remaining * p_fill * 3.0

    # Pair-closure lookahead: probability this residual can be exactly
    # filled by a pair of typical future items.
    pair_prob = np.zeros(101, dtype=np.float64)
    p = prob[1:101]
    conv = np.convolve(p, p)
    pair_prob[1:101] = conv[:100]
    p_pair = np.zeros_like(score)
    if valid.any():
        p_pair[valid] = pair_prob[post_idx[valid]]

    n_pairs = remaining * max(remaining - 1.0, 0.0) * 0.5
    pair_weight = min(n_pairs / max(n_items, 1.0), 5.0)
    score += p_pair * pair_weight * 300.0

    return score
# EVOLVE-BLOCK-END


