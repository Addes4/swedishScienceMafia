# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and a fixed parametric (Weibull-shaped)
item-size distribution used to value post-placement residuals by their
probability of being exactly closed by a single future item."""
import numpy as np

# Build a parametric model of the item-size distribution once.
# Sizes are drawn from a Weibull-shaped distribution with mean ~40 on 1..100.
def _build_pmf():
    # Weibull with shape k, scale lam, truncated to integers 1..100, mean ~40.
    from math import exp
    best = None
    # coarse search over (k, lam) to match mean ~40 and a plausible spread
    for k in np.arange(1.2, 3.2, 0.2):
        for lam in np.arange(30.0, 55.0, 1.0):
            x = np.arange(1, 101, dtype=np.float64)
            # discrete weights: difference of CDF between x-0.5 and x+0.5
            def C(t):
                t = np.clip(t, 0.0, None)
                return 1.0 - np.exp(-(t / lam) ** k)
            w = C(x + 0.5) - C(x - 0.5)
            if w.sum() <= 0:
                continue
            p = w / w.sum()
            mean = float((p * x).sum())
            err = abs(mean - 40.0)
            if best is None or err < best[0]:
                best = (err, p)
    return best[1]

_PMF = _build_pmf()


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a single future fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    pmf = _PMF
    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        p_fill[valid] = pmf[post_idx[valid] - 1]

    # Reward residuals likely to be exactly closed by one future item.
    score += p_fill * 300.0

    # Reward placing into a bin whose residual before placement == item,
    # closing the bin exactly.
    score += (bins == item).astype(np.float64) * 400.0

    n_items = float(len(bins))
    remaining = max(n_items - st_count(), 0.0)
    score += remaining * p_fill * 60.0

    return score


_count = {"n": 0.0}


def st_count():
    _count["n"] += 1.0
    return _count["n"]
# EVOLVE-BLOCK-END
