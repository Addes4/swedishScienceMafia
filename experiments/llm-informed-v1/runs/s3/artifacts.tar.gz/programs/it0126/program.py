# EVOLVE-BLOCK-START
"""Best fit with strong complementary-pair matching and exact-fill preference."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and complementary pairing.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Complementary pairing: placing into a bin whose residual already equals
    # the item closes it exactly (great), and leaving a residual equal to the
    # item size invites a future identical item.
    score += (bins == item).astype(np.float64) * 1500.0
    score += (post == item).astype(np.float64) * 800.0

    # Lookahead: probability that a future single item exactly equals the
    # residual, estimated from the running histogram.
    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        prob = (hist[idx] + 1.0) / (total + 100.0)
        p_fill[valid] = prob
    score += p_fill * 300.0

    return score
# EVOLVE-BLOCK-END

