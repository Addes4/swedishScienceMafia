# EVOLVE-BLOCK-START
"""Best fit with empirical future-fill lookahead, complementary pairing, and
two-item sum-completion lookahead (scaled, calibrated weights)."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
}


def priority(item, bins):
    """Rank bins by best-fit, exact fill, and probability of a future exact fill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    # Number of items still to come (len(bins) == total items in instance).
    remaining = max(float(len(bins)) - total, 0.0)
    rem_frac = remaining / float(len(bins)) if len(bins) > 0 else 0.0

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 5000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Lookahead: probability that a future single item exactly equals the
    # residual, estimated from the running histogram.  Scaled by remaining
    # fraction so late in the instance best-fit dominates.
    scale = 0.5 + 2.0 * rem_frac
    score += p_fill * 300.0 * scale

    # Pairing bonus: if the residual after placement equals the item size,
    # a future identical item can close it exactly.
    score += (post == item).astype(np.float64) * 400.0 * scale

    # Reward completing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 400.0 * scale

    # Two-sided commonness signal.
    common = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        common[valid] = (prob[idx] - 0.01) * 100.0
    score += common * 150.0 * scale

    # Two-item sum-completion lookahead.
    if valid.any():
        p2 = np.convolve(prob[1:101], prob[1:101])
        pw = np.zeros_like(score)
        sums = post_idx[valid]
        pw[valid] = p2[sums - 2]
        score += pw * 120.0 * scale

    return score
# EVOLVE-BLOCK-END

