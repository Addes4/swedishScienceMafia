# EVOLVE-BLOCK-START
"""Best fit with scaled single-item completion and pairing rewards."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # counts of items seen
    "total": 0.0,
}


def priority(item, bins):
    """Rank bins: best-fit dominant, with scaled completion rewards.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist[item] += 1.0
    total = st["n"]

    # On the first call, len(bins) == number of items in the instance.
    if st["total"] == 0.0:
        st["total"] = float(len(bins)) if len(bins) > 0 else 1.0

    remaining = max(st["total"] - total, 0.0)
    frac = remaining / st["total"] if st["total"] > 0 else 0.0
    # Decay factor: large early, ~0 late, so late behavior is pure best-fit.
    w = 0.5 + 0.5 * frac   # in [0.5, 1.0]

    post = bins - item  # residual after placing item here

    # Base: best fit -> prefer smallest post-placement residual.
    score = -post.astype(np.float64)

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        idx = post_idx[valid]
        p_fill[valid] = prob[idx]

    # Single-item completion reward, scaled by how many items remain.
    score += p_fill * 300.0 * w

    # Pairing: residual equals item -> a future identical item can close it.
    score += (post == item).astype(np.float64) * 200.0 * w

    # Reward completing a bin whose residual before placement == item.
    score += (bins == item).astype(np.float64) * 200.0

    return score
# EVOLVE-BLOCK-END
