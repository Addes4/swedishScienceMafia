# EVOLVE-BLOCK-START
"""Best fit with exact-fill and complementary-pair preference, plus a
stable consolidation bonus based on how common each residual is among the
currently open bins."""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # decayed counts of items seen
}

_DECAY = 0.999


def priority(item, bins):
    """Rank bins by best-fit, exact fill, complementary closure and
    consolidation of common residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1.0
    hist = st["hist"]
    hist *= _DECAY
    hist[item] += 1.0
    total = float(hist.sum())

    n_items = float(len(bins))

    post = bins - item  # residual after placing item here
    post_f = post.astype(np.float64)

    # Base: best fit -> prefer the smallest post-placement residual.
    score = -post_f

    # Exact fill: perfect, strongly preferred.
    score += (post == 0).astype(np.float64) * 10000.0

    # Laplace-smoothed item-size distribution for complementary lookahead.
    prob = (hist + 1.0) / (total + 100.0)

    post_idx = post.astype(np.int64)
    valid = (post_idx >= 1) & (post_idx <= 100)
    p_fill = np.zeros_like(score)
    if valid.any():
        p_fill[valid] = prob[post_idx[valid]]

    # Reward leaving a residual likely to be exactly filled by a future item.
    remaining = max(n_items - st["n"], 0.0)
    score += p_fill * 300.0
    score += (remaining * p_fill) * 60.0

    # Complementary pairing: item + residual exactly closes via one other item.
    score += (bins == item).astype(np.float64) * 400.0

    # Consolidation bonus: reward leaving a residual equal to the most common
    # residual currently present among open bins, so leftovers can be merged.
    # Count residuals of currently open bins (bins that still have space).
    open_mask = bins > 0
    open_res = bins[open_mask]
    if open_res.size > 0:
        res_counts = np.bincount(open_res.astype(np.int64), minlength=101)
        # exclude capacity-100 (unused) from being a "common residual" target
        res_counts[100] = 0
        denom = max(float(open_res.size), 1.0)
        p_res = np.zeros_like(score)
        if valid.any():
            idx = post_idx[valid]
            p_res[valid] = res_counts[idx] / denom
        score += p_res * 500.0

    # Mode residual: prefer residual equal to the most common recent item size.
    mode_idx = int(np.argmax(prob[1:101])) + 1
    score += (post_idx == mode_idx).astype(np.float64) * 200.0

    return score
# EVOLVE-BLOCK-END
