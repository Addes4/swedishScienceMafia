# EVOLVE-BLOCK-START
"""Lookahead best-fit: best fit, but among near-ties prefer placements whose leftover
capacity is itself a good fit for future items (using observed item statistics)."""
import numpy as np

_STATE = {"cap": None, "seen": [], "n": None}


def _get_caps(bins, fit_mask_item):
    return _STATE["cap"]


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    n = len(bins)
    cap = _STATE["cap"]
    if cap is None or len(cap) != n:
        cap = np.full(n, 100, dtype=np.int64)
        _STATE["cap"] = cap
        _STATE["seen"] = []

    # bins here is a copy of remaining capacities of the bins this item fits in.
    # We reconstruct the full capacity vector from our tracked state.
    seen = _STATE["seen"]
    seen.append(item)

    # Best-fit base score: tighter fit preferred -> -(bins - item)
    base = -(bins - item).astype(np.float64)

    # Estimate typical future item size from observed items.
    if len(seen) >= 8:
        arr = np.asarray(seen, dtype=np.float64)
        m = arr.mean()
    else:
        m = 40.0

    # Lookahead bonus: after placing, leftover = bins - item.
    leftover = (bins - item).astype(np.float64)

    # Prefer leftovers that are "almost full" (small residual) strongly;
    # among those, prefer residuals that can still hold a typical item, i.e.
    # residuals near a multiple-ish useful size, or near 0.
    # Small residual that is a good candidate for exact/near-exact future fits.
    # Score: primary tight fit, secondary: residual closeness to a typical item
    # or to 0 (perfect fill). This mildly reshuffles near-ties.
    bonus = np.where(
        (leftover > 0) & (leftover <= m),
        -np.abs(leftover - m * np.round(np.maximum(leftover, 1e-9) / m)) * 0.001,
        0.0,
    )
    # Extra: strongly favor perfect/zero leftovers.
    bonus += np.where(leftover == 0, 0.01, 0.0)

    return base + bonus
# EVOLVE-BLOCK-END
