# EVOLVE-BLOCK-START
"""Best-fit backbone with an empirical residual-reusability term."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_total_items = 1


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _total_items

    if _n == 0:
        # len(bins) equals number of items in the instance on first call.
        _total_items = max(len(bins), 1)

    _sum += item
    _n += 1
    _hist[item] += 1.0

    # Empirical item-size distribution seen so far (probability mass per size).
    total = _hist[1:101].sum()
    if total <= 0:
        prob = np.full(101, 1.0 / 100.0)
    else:
        prob = _hist / total  # index 0 unused

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Cumulative probability that a future item is <= r (usable in this gap).
    cum = np.cumsum(prob[1:101])  # cum[i-1] = P(size <= i)
    ri = np.clip(np.rint(r).astype(np.int64), 0, 100)
    reuse = np.where(ri > 0, cum[np.maximum(ri - 1, 0)], 0.0)
    # Fraction of mass usable is bounded; use complement of emptiness instead.
    useful = 1.0 - cum[np.maximum(ri - 1, 0)]  # P(size > r): too big to fit
    # A residual is "good" if it can likely be topped off (some mass <= r)
    # but not so large that it is basically an empty bin (waste).

    exact = (r < 0.5).astype(np.float64)

    # Reuse value: residual can be filled by a future item with prob mass p.
    # p = P(size == r) essentially; approximate via local histogram density.
    dens = prob[ri]
    # Penalize leftover waste proportionally.
    waste = r / 100.0

    # Dominant best-fit: smaller residual preferred, stronger for small gaps.
    score = -(waste + 1e-3 * r) + 0.6 * dens + 3.0 * exact

    return score
# EVOLVE-BLOCK-END
