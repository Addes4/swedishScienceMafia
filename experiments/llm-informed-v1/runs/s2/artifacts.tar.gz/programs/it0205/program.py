# EVOLVE-BLOCK-START
"""Best-fit backbone with empirical one-step look-ahead residual utility."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_mean = 40.0
_pmax = 0.02


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _mean, _pmax

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        total = _n
        _mean = _sum / _n
        _pmax = max(float(np.max(_hist[1:101]) / total), 1e-3)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Exact fill: residual is 0 -> perfect, huge bonus (scaled by likelihood).
    exact = (r < 0.5).astype(np.float64)

    # Look-ahead utility: expected chance a future item exactly fits the
    # resulting residual (leaving 0 waste) versus the residual being wasted.
    # Probability mass of item sizes <= r that can land near-exactly.
    # Use histogram as a coarse distribution over sizes 1..100.
    if _n >= 30:
        total = _hist[1:101].sum()
        probs = _hist[1:101] / total
    else:
        probs = None

    # Reward residuals that are exactly achievable by a likely future item:
    # For each bin's residual r, sum prob[s] for s near r (within tolerance).
    score = np.zeros_like(r)

    if probs is not None:
        # near-exact fillability: weight of item sizes in [r-1, r] window.
        # Vectorized: build cumulative sums and evaluate per-bin.
        cdf = np.concatenate(([0.0], np.cumsum(probs)))
        ri = np.clip(np.round(r).astype(np.int64), 0, 100)
        lo = np.clip(ri - 1, 0, 100)
        hi = np.clip(ri, 0, 100)
        near_fill = cdf[hi] - cdf[lo]  # prob mass of sizes matching r
        score += 12.0 * near_fill * (r > 0.5)

        # Expected remaining usefulness: prob that some future item fits and
        # leaves a small residual (tight packing favored).
        # Approximate by weighting small residuals higher.
        smallness = np.where(r > 0.5, (100.0 - r) / 100.0, 0.0)
        score += 3.0 * smallness * (r > 0.5)

    score += 5.0 * exact + 20.0 * _pmax * exact

    # Sliver penalty: residual too small to ever be usefully filled.
    sliver = np.where((r > 0) & (r < 5.0), 5.0 - r, 0.0)
    score -= 1.5 * sliver

    # Waste-fraction (harmonic-style) penalty.
    used = 100.0 - r
    frac = np.where(used > 0, r / used, 0.0)
    score -= 1.2 * frac

    # Mild best-fit tie-break: smaller residual preferred.
    score -= 1e-3 * r

    return score
# EVOLVE-BLOCK-END
