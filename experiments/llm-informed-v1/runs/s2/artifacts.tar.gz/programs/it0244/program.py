# EVOLVE-BLOCK-START
"""Best-fit with an empirical exact-fill bonus: items prefer the fullest bin,
except when a residual exactly equals a frequently seen item size (which is
likely to be closed exactly by that size soon). Tiny size-frequency table
rebuilt periodically for speed."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)

_pfreq_tab = np.zeros(101, dtype=np.float64)
_last_build = -1


def _rebuild():
    global _pfreq_tab
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    _pfreq_tab[:] = _hist / total


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    r = bins.astype(np.float64) - item  # >= 0 for shown bins

    # Dominant term: best fit = smallest residual.
    score = -r

    # Exact-fill bonus: if residual equals a frequently observed size, that
    # size can close the bin exactly. Weight by empirical frequency.
    if _n >= 30:
        ri = np.clip(np.rint(r), 0.0, 100.0).astype(np.int64)
        pfreq = _pfreq_tab[ri]
        near = np.exp(-((r - ri) ** 2) / (2.0 * 1.0))
        exact = (r < 0.5).astype(np.float64)
        score = score + 12.0 * pfreq * near + 3.0 * exact

    return score
# EVOLVE-BLOCK-END
