# EVOLVE-BLOCK-START
"""Best fit with a preference for reusing already-open bins over empty ones."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    base = -(bins - item)  # best fit: prefer the tightest remaining capacity after placing
    # bonus for bins that are already in use (capacity < 100): reuse before opening a new bin
    used = bins < 100
    return base + used * 0.5
# EVOLVE-BLOCK-END

