# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus and unusable-sliver penalty."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _min_item

    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    r = residual

    # Reward exact fits strongly (no waste).
    exact = (r < 0.5).astype(np.float64)

    # Penalize residuals that are positive but smaller than the smallest
    # item seen: such gaps may never be fillable.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Best-fit backbone: prefer the fullest bin (smallest residual).
    score = -r + 5.0 * exact - 0.5 * tiny

    # Mild tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
