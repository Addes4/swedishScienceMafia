# EVOLVE-BLOCK-START
"""Residual-utility best fit using empirical CDF to value leftover gaps."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_cdf = np.zeros(101, dtype=np.float64)  # cdf[v] = P(item <= v), estimate


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n

    _sum += item
    _n += 1
    _hist[item] += 1.0
    mean = _sum / _n
    m = max(mean, 1.0)

    if _n >= 30:
        cum = np.cumsum(_hist[1:101])
        total = cum[-1]
        _cdf[1:101] = cum / total
        cdf = _cdf
    else:
        # Uniform-ish prior over 1..100.
        cdf = np.arange(0, 101, dtype=np.float64) / 100.0

    residual = bins.astype(np.float64) - item  # >= 0 for shown bins
    r = residual

    # Exact fill: essentially free capacity.
    exact = (r < 0.5).astype(np.float64)

    # Value a leftover gap g by the expected number of future items that fit:
    #   E[#fit] = sum over sizes s of P(size=s) * (g // s)
    # Approximated via the empirical distribution (probability mass at each size).
    # Use probability that a random item is <= g (single-item "fillability"),
    # plus a term rewarding gaps that can hold multiple typical items.
    idx = np.clip(np.rint(r).astype(np.int64), 0, 100)
    pf = cdf[idx]                      # P(item <= residual)
    # Reward residual near multiples of the mean (multiple small items can fit).
    t = m
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Penalize tiny unusable slivers (nonzero residual too small for a typical item).
    sliver = np.where((r > 0) & (r < 0.3 * t), 0.3 * t - r, 0.0)

    # Combine: prefer gaps that are likely fillable AND close to clean multiples.
    score = -(dist + 0.5 * sliver) + 3.0 * pf + 6.0 * exact

    # Slight tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
