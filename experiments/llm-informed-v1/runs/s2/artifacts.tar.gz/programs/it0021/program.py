# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus keyed to empirical item distribution."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_freq_size = 40.0          # most probable item size so far
_prob_hot = 0.0            # probability mass of top-probability sizes


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _freq_size, _prob_hot

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        # Most frequent size seen so far (mode of empirical distribution).
        _freq_size = float(np.argmax(_hist[1:101]) + 1)
        _prob_hot = float(_hist[int(_freq_size)]) / total
    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Distance to nearest multiple of typical fill size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Residuals smaller than the typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Bonus for residuals that match the most frequent observed item size
    # (high probability a future item exactly fills the gap).
    hot = np.exp(-2.0 * np.abs(r - _freq_size))

    score = -(dist + 0.75 * sliver) + 5.0 * exact + 2.0 * _prob_hot * hot

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
