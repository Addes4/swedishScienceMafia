# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus and unusable-sliver penalty."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_min_item = 100.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _min_item

    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        # Smallest observed item size so far (empirical minimum).
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Exact fits: finish the bin exactly, no waste at all.
    exact = (r < 0.5).astype(np.float64)

    # Positive residuals below the smallest item seen can likely never be
    # filled again -> strong penalty for leaving such unusable slivers.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Primary term: best-fit (prefer the tightest fit that still leaves room).
    score = -r - 2.0 * tiny + 10.0 * exact

    return score
# EVOLVE-BLOCK-END
