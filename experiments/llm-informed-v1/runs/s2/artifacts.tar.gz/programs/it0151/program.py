# EVOLVE-BLOCK-START
"""Best-fit with an exact-fit bonus and a soft closeable-residual bonus."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)

    typical = max(min(_median, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Best-fit backbone: prefer smaller residual.
    score = -r

    # Strongly reward exact fits (no waste).
    exact = (r < 0.5)
    score = score + 4.0 * exact

    # Soft bonus if the residual is close to a typical item size, i.e. the
    # gap can plausibly be filled by one more likely item.
    d = np.abs(r - typical)
    closeable = np.clip(1.0 - d / (0.5 * typical), 0.0, 1.0)
    score = score + 0.3 * closeable

    return score
# EVOLVE-BLOCK-END
