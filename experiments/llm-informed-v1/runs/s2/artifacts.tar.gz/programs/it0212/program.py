# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus, empirical future-fit term, and a
histogram-weighted residual reward that favors residuals matching common
future item sizes (likely to be completed exactly)."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0
_pmax = 0.02  # max single-size probability estimate
_q25 = 25.0
_q75 = 55.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _mean, _pmax, _q25, _q75

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        i25 = np.searchsorted(cdf, 0.25 * total)
        i75 = np.searchsorted(cdf, 0.75 * total)
        _q25 = float(i25 + 1)
        _q75 = float(i75 + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        _mean = _sum / _n
        _pmax = max(float(np.max(_hist[1:101]) / total), 1e-3)

    typical = max(min(_median, 100.0), 1.0)
    mean = max(min(_mean, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Exact fill: residual is 0 -> perfect, huge bonus.
    exact = (r < 0.5).astype(np.float64)

    # Distance of residual to multiples of a typical item size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Reward residuals that can host a typical (median/mean) future item well.
    fit_future = np.abs(r - mean)

    # Sliver penalty: too small to be usefully filled.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Harmonic-style waste fraction term.
    used = 100.0 - r
    frac = np.where(used > 0, r / used, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact

    # Moderate reward for residuals that can host a future average item.
    score = score - 1.0 * fit_future * 0.05

    score = score - 1.5 * frac

    # Expected exact-completion value: sum empirical probability mass of item
    # sizes that could exactly fill this residual, with a soft kernel so that
    # near-fills also count a bit. This rewards residuals whose leftover space
    # is genuinely reachable by common sizes.
    if _n >= 30:
        total = float(np.sum(_hist[1:101]))
        p = _hist[1:101] / max(total, 1.0)  # prob for sizes 1..100
        sizes = np.arange(1, 101, dtype=np.float64)
        # For each residual, prob mass of sizes near it (exact fill by one item).
        # Vectorize: r shape (m,), sizes shape (100,).
        rg = r[:, None]                    # (m,1)
        sg = sizes[None, :]                # (1,100)
        diff = rg - sg                     # (m,100)
        # hard exact match within 0.5 plus soft Gaussian halo width ~1.5
        near = np.exp(-(diff * diff) / (2.0 * 1.5 * 1.5))
        near = np.where(np.abs(diff) < 0.5, 1.0, near)
        fill_mass = near @ p               # (m,) prob that one future item fills it

        # Complementary mass: prob that two items (common sizes) together fill it.
        # Approximate via convolution of the empirical distribution with itself,
        # truncated to size <= 100 (residuals can be up to 100).
        conv = np.convolve(p, p)           # length 199, support sums 2..200
        # Map residual to nearest sum-index for pair fills; soft kernel.
        # sums index s corresponds to total = s+2 (since sizes 1..100)
        pair_totals = np.arange(2, 201, dtype=np.float64)
        ptg = pair_totals[None, :]         # (1,199)
        pdiff = rg - ptg                   # (m,199)
        pnear = np.exp(-(pdiff * pdiff) / (2.0 * 4.0 * 4.0))
        # Normalize each residual's pair kernel so tails don't inflate scores.
        pnorm = pnear / np.maximum(np.sum(pnear, axis=1, keepdims=True), 1e-9)
        pair_mass = pnorm @ conv           # (m,) prob that a pair fills it

        # Combine: exact single-item fills dominate; pair fills weakly.
        complete_val = fill_mass + 0.25 * pair_mass
        score = score + 8.0 * complete_val

    # Soft residual-conservation kernel: gentle bonus for residuals in the
    # common future-item size range (25-75 percentile).
    lo = _q25
    hi = _q75
    width = max(hi - lo, 1.0) * 0.5 + 1.0
    mid = 0.5 * (lo + hi)
    band_fit = np.exp(-((r - mid) ** 2) / (2.0 * width * width))
    score = score + 0.3 * band_fit

    # Exact fits get extra weight proportional to how likely that item is.
    score = score + 20.0 * _pmax * exact

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
