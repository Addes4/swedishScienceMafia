# EVOLVE-BLOCK-START
"""Best-fit backbone with an empirical exact-fill reward on the residual."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_cum = np.zeros(101, dtype=np.float64)  # cdf over size classes


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _median, _cum

    _n += 1
    _hist[item] += 1.0

    if _n >= 50:
        _cum = np.cumsum(_hist[1:101])  # _cum[k-1] = count of items <= k
        total = _cum[-1]
        idx = np.searchsorted(_cum, 0.5 * total)
        _median = float(idx + 1)

    residual = bins.astype(np.float64) - item  # >= 0 for shown bins

    # Probability mass at/near each residual value: reward residuals that
    # correspond to a common item size (so an exact fill is likely later).
    # Use the raw histogram smoothed a little.
    hist = _hist
    # exact-fill mass at residual r (item == r) plus close neighbours
    r_idx = np.clip(residual.astype(np.int64), 0, 100)
    fill_mass = hist[r_idx]

    # sliver: residuals below the typical item can rarely be reused
    t = max(min(_median, 100.0), 1.0)
    sliver = np.where((residual > 0) & (residual < 0.5 * t), 0.5 * t - residual, 0.0)

    # Best-fit backbone plus small exact-fill preference, tiny tie-break.
    score = -residual - 0.4 * sliver + 0.05 * fill_mass
    score = score - 1e-4 * residual

    return score
# EVOLVE-BLOCK-END
