# EVOLVE-BLOCK-START
"""Best fit with a mild reservoir bias: prefer non-empty bins whose resulting gap
is still useful, delaying fresh-bin starts so partially-filled bins absorb items."""
import numpy as np

_state = {"cap": None, "mean": 40.0, "seen": 0}


def priority(item, bins):
    st = _state
    # Update running mean of observed item sizes.
    st["seen"] += 1
    st["mean"] += (float(item) - st["mean"]) / st["seen"]

    residual = bins - item  # remaining space after placing here

    # Best fit: smaller residual is better.
    score = -residual.astype(np.float64)

    # Mild bonus for non-empty bins (residual was less than a full empty bin,
    # i.e. bins[i] < 100) when the resulting gap is still meaningfully large,
    # so we fill existing bins before opening new ones.
    nonempty = bins < 100
    useful_gap = residual >= (st["mean"] * 0.4)
    score += (nonempty & useful_gap).astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
