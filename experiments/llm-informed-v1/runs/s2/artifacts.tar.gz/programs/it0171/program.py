# EVOLVE-BLOCK-START
"""Best-fit backbone with a smoothed CDF-based residual-closability bonus."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_min_item = 100.0
_cdf = np.zeros(101, dtype=np.float64)  # smoothed CDF of item sizes
_dirty = True


def _rebuild_cdf():
    global _cdf, _dirty
    counts = _hist[1:101].astype(np.float64)
    # Light smoothing so early estimates are not zero everywhere.
    kernel = np.array([1.0, 2.0, 3.0, 2.0, 1.0])
    counts = np.convolve(counts, kernel, mode="same")
    total = counts.sum()
    if total <= 0:
        _cdf = np.zeros(101, dtype=np.float64)
    else:
        _cdf = np.zeros(101, dtype=np.float64)
        _cdf[1:101] = np.cumsum(counts) / total
    _dirty = False


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _min_item, _dirty

    _sum += item
    _n += 1
    _hist[item] += 1.0
    if item < _min_item:
        _min_item = float(item)
    _dirty = True

    if _dirty:
        _rebuild_cdf()

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Best-fit primary signal: prefer small residual (fuller bins).
    score = -r

    # Strong bonus for exact fits.
    exact = (r < 0.5).astype(np.float64)
    score = score + 5.0 * exact

    # Sliver penalty: residuals too small to ever be filled (below min item seen)
    # are wasted capacity.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)
    score = score - 0.5 * tiny

    # Closability bonus: reward leaving a residual that is itself a plausible
    # future item size (measured via smoothed empirical CDF increments).
    ri = np.clip(r.astype(np.int64), 0, 100)
    # Density around the residual value (local mass in a small window).
    lo = np.clip(ri - 2, 0, 100)
    hi = np.clip(ri + 2, 0, 100)
    dens = _cdf[hi] - _cdf[lo]
    # Only meaningful for non-zero residuals.
    dens = np.where(r > 0.5, dens, 0.0)
    score = score + 1.5 * dens

    # Deterministic tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

