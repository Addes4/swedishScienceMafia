# EVOLVE-BLOCK-START
"""Best-fit + exact-fit with a future-fill bonus based on the empirical item histogram."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_freq = np.zeros(101, dtype=np.float64)   # smoothed relative frequency of item sizes
_freq_ready = False


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _freq, _freq_ready

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        # Smallest observed item size so far (empirical minimum).
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        # Smoothed relative frequency over sizes 1..100.
        if _n % 25 == 0 or not _freq_ready:
            raw = _hist[1:101].copy()
            # Light smoothing so sizes near common ones still get credit.
            sm = raw.copy()
            sm[1:] += 0.5 * raw[:-1]
            sm[:-1] += 0.5 * raw[1:]
            sm = sm / max(sm.sum(), 1.0)
            _freq[1:101] = sm
            _freq_ready = True

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Distance to nearest multiple of typical fill size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Residuals smaller than a typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact

    # Future-fill bonus: reward residuals equal to a common future item size.
    if _freq_ready:
        ri = np.clip(np.rint(r).astype(np.int64), 0, 100)
        good_gap = np.where(r >= _min_item, _freq[ri], 0.0)
        score = score + 3.0 * good_gap

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
