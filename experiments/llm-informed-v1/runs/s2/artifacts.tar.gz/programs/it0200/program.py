# EVOLVE-BLOCK-START
"""Best-fit with a bonus for residuals near high-probability item sizes."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_targets = np.array([40.0], dtype=np.float64)
_recent = np.zeros(101, dtype=np.float64)   # decaying recent histogram


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _targets, _recent

    _sum += item
    _n += 1
    _hist[item] += 1.0
    _recent *= 0.99
    _recent[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

        # Most probable item sizes (recent, smoothed) become residual targets.
        w = 0.5 * _hist[1:101] + _recent[1:101]
        # Consider sums of a target with itself and pairs of common sizes.
        top = np.argsort(w)[::-1][:6] + 1
        cand = []
        for a in top:
            cand.append(float(a))
            for b in top:
                cand.append(float(a + b))
        cand = np.array(cand, dtype=np.float64)
        cand = cand[cand <= 100.0]
        if cand.size:
            _targets = cand

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item
    r = residual

    exact = (r < 0.5).astype(np.float64)

    # Bonus if residual is very close to a likely reusable target.
    tgt = _targets
    dist_t = np.min(np.abs(r[:, None] - tgt[None, :]), axis=1) if tgt.size else r

    # Distance to nearest multiple of typical fill size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    base = np.minimum(d0, dk)

    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(base + 0.6 * sliver + 0.5 * tiny) + 5.0 * exact
    score = score - 0.4 * dist_t
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

