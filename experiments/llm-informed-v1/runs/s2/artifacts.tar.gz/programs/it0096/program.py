# EVOLVE-BLOCK-START
"""Best-fit with exact-fit reward and a mild usable-gap penalty."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_min_item = 100.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _min_item

    _n += 1
    _hist[item] += 1.0
    if item < _min_item:
        _min_item = float(item)

    r = bins.astype(np.float64) - item  # residual after placing, >= 0

    # Strongly reward exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Penalize residuals too small to be filled by the smallest item seen so
    # far (a forward-looking estimate of the future minimum item size).
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Backbone: minimize residual (best-fit), with exact-fit bonus and a
    # mild penalty for unusable tiny gaps.
    score = -r + 5.0 * exact - 0.5 * tiny

    return score
# EVOLVE-BLOCK-END
