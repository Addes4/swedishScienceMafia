# EVOLVE-BLOCK-START
"""Best-fit with a fillability bonus keyed to a low empirical quantile,
which better matches the small residuals best-fit tends to leave."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_typical = 30.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _typical, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        # Use a low quantile (around 1/3) of observed item sizes: best-fit
        # tends to leave small residuals, so target small fillable gaps.
        idx = np.searchsorted(cdf, (1.0 / 3.0) * total)
        _typical = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    t = max(min(_typical, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Distance to nearest multiple of the typical fill size.
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Residuals smaller than a typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
