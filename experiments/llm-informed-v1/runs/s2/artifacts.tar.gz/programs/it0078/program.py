# EVOLVE-BLOCK-START
"""Best-fit with exact-fit reward and a light 'leave a usable residual' bias."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_typical = 40.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _typical

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
            _typical = float(np.mean(np.repeat(nz + 1, _hist[1:101][nz].astype(np.int64)))) if total > 0 else 40.0
        else:
            _typical = 40.0
    else:
        _typical = 40.0

    typical = max(min(_typical, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Exact fit: strongly preferred (zero waste).
    exact = (r < 0.5).astype(np.float64)

    # Increase the exact-fit bonus so it dominates the tie-break noise.
    score = 8.0 * exact

    # Distance to nearest multiple of typical fill size: gaps fillable later
    # by typical items get a bonus.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Residuals smaller than a typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Light bonus for leaving a residual that at least one typical item fits.
    usable = (r >= typical).astype(np.float64)

    score = score - (dist + 0.75 * sliver + 0.5 * tiny) + 0.15 * usable

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
