# EVOLVE-BLOCK-START
"""Best-fit dominated by a strong exact-fit bonus, with a small fillability bonus."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)

    typical = max(min(_median, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Primary: best fit -> smallest residual gets highest score.
    score = -r

    # Strong bonus for exact fits.
    score += 200.0 * (r < 0.5)

    # Small bonus when residual is close to a multiple of the typical item size
    # (a gap likely to be filled later by one or a few typical items).
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    score += 0.5 * (1.0 / (1.0 + dk))

    return score
# EVOLVE-BLOCK-END
