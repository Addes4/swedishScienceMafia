# EVOLVE-BLOCK-START
"""Fillability model: reward residuals near multiples of the typical item size."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_scale = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _scale, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        # Empirical mode is a robust estimate of the dominant item size.
        mode_idx = int(np.argmax(_hist[1:101])) + 1
        # Robust central scale: median of observed items.
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        med = float(np.searchsorted(cdf, 0.5 * total) + 1)
        # Blend mode and median; both are stable targets for this distribution.
        _scale = max(1.0, min(100.0, 0.5 * mode_idx + 0.5 * med))
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    t = _scale
    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    exact = (r < 0.5).astype(np.float64)

    # How many typical items fit, and the leftover after filling with them.
    k = np.floor(r / t)
    leftover = r - k * t
    # Distance to the nearest integer multiple of t (zero = perfectly fillable).
    dist = np.minimum(leftover, t - leftover)

    # Count of full typical items the residual can absorb (more = better).
    usable = np.minimum(k, 4.0)

    # Residuals smaller than a typical item can never be used well.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    # Truly unusable residuals below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(dist + 0.5 * sliver + 0.5 * tiny) + 0.4 * usable + 5.0 * exact

    # Slight tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
