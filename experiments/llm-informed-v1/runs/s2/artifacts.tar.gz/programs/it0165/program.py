# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus and adaptive unusable-sliver penalties."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _mean

    _sum += item
    _n += 1
    _hist[item] += 1.0
    _mean = _sum / _n

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)
    minit = max(_min_item, 1.0)

    r = bins.astype(np.float64) - item  # >= 0 for shown bins

    # Strongly reward exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Base: best-fit => prefer the smallest nonnegative residual.
    base = -r

    # Penalize remaining waste that is below the smallest item seen:
    # such residual can likely never be reused.
    tiny = np.where((r > 0) & (r < minit), minit - r, 0.0)

    # Penalize sliver band below typical item size (hard to reuse).
    sliver = np.where((r > 0) & (r < 0.5 * typical), 0.5 * typical - r, 0.0)

    # Bonus when the residual is just above the smallest item seen:
    # keeps the bin usable for a future small item.
    usable = np.where((r >= minit) & (r < minit + 0.5 * minit), 0.3, 0.0)

    score = base + 5.0 * exact - 0.6 * tiny - 0.3 * sliver + usable

    # Tie-break toward full placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

