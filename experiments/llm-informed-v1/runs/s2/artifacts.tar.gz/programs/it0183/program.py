# EVOLVE-BLOCK-START
"""Best-fit backbone with exact-fit and bin-closing bonuses."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)
    r = bins.astype(np.float64) - item  # residual; >= 0 for shown bins

    # Strong reward for exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Bonus when the residual is below the smallest observed item: the bin is
    # effectively closed and won't be fragmented by future items.
    closed = ((r > 0) & (r < _min_item)).astype(np.float64)

    # Mild bonus when residual cannot hold a typical item (below half-median).
    unusable = ((r > 0) & (r < 0.5 * typical)).astype(np.float64)

    # Primary term: best-fit (smaller residual is better).
    score = -r + 5.0 * exact + 0.75 * closed + 0.25 * unusable

    return score
# EVOLVE-BLOCK-END

