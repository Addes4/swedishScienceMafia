# EVOLVE-BLOCK-START
"""Best-fit backbone with exact-fit, close-to-full, and unusable-sliver shaping."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)
    r = bins.astype(np.float64) - item  # post-placement residual, >= 0

    # Exact fit: residual 0 -> very strong reward.
    exact = (r < 0.5).astype(np.float64)

    # Unusable slivers: positive residual too small to ever fit a min item.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Residuals below a typical item are risky (may never be filled).
    sliver = np.where((r > 0) & (r < 0.5 * typical), 0.5 * typical - r, 0.0)

    # Primary: best-fit (smallest residual). Bonus for closing a bin to a
    # residual equal to a common item size (likely fillable exactly later).
    score = -r - 0.8 * tiny - 0.6 * sliver + 6.0 * exact

    # Small extra tie-break toward larger residuals matching a common size.
    if _n >= 30:
        match = _hist[np.clip(r.astype(np.int64), 0, 100)] / max(_n, 1)
        score = score + 2.0 * match * (r > 0.5)

    return score
# EVOLVE-BLOCK-END
