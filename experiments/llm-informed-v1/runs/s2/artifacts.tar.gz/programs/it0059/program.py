# EVOLVE-BLOCK-START
"""Best-fit with a gentle sliver penalty keyed to empirical statistics."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    r = bins.astype(np.float64) - item  # residual >= 0

    # Best-fit backbone: prefer smallest usable residual.
    score = -r

    # Bonus for exact fits (free bin closed perfectly).
    score = score + 3.0 * (r < 0.5).astype(np.float64)

    # Gentle penalty for leaving an unusable sliver below the smallest
    # item seen so far (those residuals can never be filled).
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)
    score = score - 0.5 * tiny

    # Mild bonus for residuals large enough to hold a typical (median) item.
    score = score + 0.02 * (r >= _median).astype(np.float64)

    return score
# EVOLVE-BLOCK-END
