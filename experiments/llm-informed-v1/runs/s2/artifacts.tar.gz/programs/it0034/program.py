# EVOLVE-BLOCK-START
"""Best-fit style rule keyed to the empirical mean item size."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_mean = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _mean, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        total = _hist[1:101].sum()
        _mean = _sum / _n
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_mean, 100.0), 1.0)
    t = typical

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Asymmetric waste: charge only what is likely unusable. Round residual
    # down to the nearest multiple of the typical fill size; the remainder is
    # the leftover we can't easily refill, while the multiples are usable.
    k = np.floor(r / t)
    leftover = r - k * t

    # If leftover itself is >= typical it could host a typical item, so it is
    # usable too; otherwise it is wasted space.
    waste = np.where(leftover < 0.5 * t, leftover, 0.0)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(waste + 0.5 * tiny) + 5.0 * exact

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
