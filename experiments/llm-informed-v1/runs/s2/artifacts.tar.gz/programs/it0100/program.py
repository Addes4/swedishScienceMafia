# EVOLVE-BLOCK-START
"""Best-fit with an empirical fillability bonus based on frequent item sizes."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_top_sizes = np.array([40.0])
_top_mass = np.array([1.0])
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _hist, _top_sizes, _top_mass, _min_item

    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n % 25 == 0 or _n == 30):
        h = _hist[1:101]
        total = h.sum()
        # Most frequent item sizes (by histogram mass).
        order = np.argsort(h)[::-1]
        k = 12
        idx = order[:k]
        sizes = (idx + 1).astype(np.float64)
        mass = h[idx] / max(total, 1.0)
        keep = mass > 0
        _top_sizes = sizes[keep]
        _top_mass = mass[keep]
        nz = np.nonzero(h)[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    exact = (r < 0.5).astype(np.float64)

    # Fillability: how much probability mass of frequent item sizes sits
    # exactly at this residual (bin completable by a typical future item).
    if r.size:
        diff = np.abs(r[:, None] - _top_sizes[None, :])
        fill = (diff < 0.5) @ _top_mass
    else:
        fill = np.zeros_like(r)

    # Penalize tiny unusable residuals (below smallest item seen).
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -r + 3.0 * fill - 0.5 * tiny + 20.0 * exact
    return score
# EVOLVE-BLOCK-END

