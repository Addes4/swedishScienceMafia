# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus and an adaptive sliver penalty keyed to
the empirical quartile/median of item sizes seen so far."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_q25 = 20.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _median, _q25, _min_item

    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx_med = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx_med + 1)
        idx_q = np.searchsorted(cdf, 0.25 * total)
        _q25 = float(idx_q + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    median = max(min(_median, 100.0), 1.0)
    q25 = max(min(_q25, median), 1.0)
    min_item = max(min(_min_item, q25), 1.0)

    r = bins.astype(np.float64) - item  # residual >= 0 for shown bins

    # Strongly reward exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Best-fit dominant term: smaller residual is better.
    score = -r

    # Penalize leaving a residual that future items will very likely not fit:
    # residuals below q25 (and especially below min_item) are near-wasted.
    sliver = np.clip(q25 - r, 0.0, None)
    tiny = np.clip(min_item - r, 0.0, None)

    score -= 0.6 * sliver + 1.5 * tiny

    # Mild reward for staying reusable (residual at least a median item),
    # so we prefer closing nearly-full bins before they become slivers.
    reusable = (r >= median - 0.5).astype(np.float64)
    score += 0.4 * reusable

    score += 5.0 * exact

    return score
# EVOLVE-BLOCK-END
