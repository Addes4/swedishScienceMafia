# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus, empirical future-fit term, and a
histogram-weighted residual reward that favors residuals matching common
future item sizes (likely to be completed exactly). Uses a periodically
rebuilt lookup table to stay fast, plus a grounded per-residual
"expected leftover utility" table derived from the empirical item distribution."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0
_pmax = 0.02  # max single-size probability estimate
_q25 = 25.0
_q75 = 55.0

# Cached lookup tables (rebuilt periodically, cheap).
_pfreq_tab = np.zeros(101, dtype=np.float64)   # surviving frequency prob per integer size
_band_tab = np.zeros(101, dtype=np.float64)    # band kernel per residual 0..100
_util_tab = np.zeros(101, dtype=np.float64)    # expected leftover utility per residual 0..100
_last_build = -1


def _rebuild():
    global _pfreq_tab, _band_tab, _util_tab, _median, _min_item, _mean, _pmax, _q25, _q75
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    cdf = np.cumsum(_hist[1:101])
    idx = np.searchsorted(cdf, 0.5 * total)
    _median = float(idx + 1)
    i25 = np.searchsorted(cdf, 0.25 * total)
    i75 = np.searchsorted(cdf, 0.75 * total)
    _q25 = float(i25 + 1)
    _q75 = float(i75 + 1)
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _mean = _sum / _n
    _pmax = max(float(np.max(_hist[1:101]) / total), 1e-3)

    pfreq = _hist / total
    _pfreq_tab[:] = pfreq
    sizes = np.arange(1, 101, dtype=np.float64)
    p = pfreq[1:101]

    # Build expected-leftover utility per residual r in 0..100.
    # Utility(r) = P(some future item exactly fills r)
    #            + P(r >= next item) * E[1 - leftover/r | fits]
    # This captures both exact closures and how well a residual can host
    # typical future items with minimal waste.
    util = np.zeros(101, dtype=np.float64)
    for r in range(0, 101):
        if r == 0:
            util[r] = 1.0
            continue
        fits = sizes <= r
        if not np.any(fits):
            util[r] = 0.0
            continue
        pf = p[fits]
        sf = sizes[fits]
        pfit = float(np.sum(pf))
        # probability of exact fit
        pexact = float(np.sum(pf[sf == r])) if r <= 100 else 0.0
        # expected relative remaining capacity after best typical placement
        # weight by how much we reduce the residual (larger placed item better)
        placed = float(np.sum(pf * sf))  # expected size placed (given it fits)
        placed = placed / max(pfit, 1e-9)
        leftover_frac = max(r - placed, 0.0) / r
        util[r] = 1.5 * pexact + pfit * (1.0 - leftover_frac)
    _util_tab[:] = util

    # band kernel over residual integer values 0..100
    lo, hi = _q25, _q75
    width = max(hi - lo, 1.0) * 0.5 + 1.0
    mid = 0.5 * (lo + hi)
    x = np.arange(101, dtype=np.float64)
    _band_tab[:] = np.exp(-((x - mid) ** 2) / (2.0 * width * width))


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _mean, _pmax, _q25, _q75, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    typical = max(min(_median, 100.0), 1.0)
    mean = max(min(_mean, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Exact fill: residual is 0 -> perfect, huge bonus.
    exact = (r < 0.5).astype(np.float64)

    # Distance of residual to multiples of a typical item size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Harmonic-style waste fraction term.
    used = 100.0 - r
    frac = np.where(used > 0, r / used, 0.0)

    score = -dist + 5.0 * exact

    score = score - 1.5 * frac

    if _n >= 30:
        # Grounded per-residual expected utility from empirical distribution.
        ri = np.clip(np.rint(r), 0.0, 100.0).astype(np.int64)
        util = _util_tab[ri]
        # fractional distance to that integer residual to soften lookup
        near = np.exp(-((r - ri) ** 2) / (2.0 * 1.0))
        score = score + 3.0 * util * near

        # nearest integer size frequency bonus
        sizei = np.clip(np.rint(r), 1.0, 100.0).astype(np.int64)
        pfreq = _pfreq_tab[sizei]
        score = score + 4.0 * pfreq * near

    # Exact fits get extra weight proportional to how likely that item is.
    score = score + 20.0 * _pmax * exact

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
