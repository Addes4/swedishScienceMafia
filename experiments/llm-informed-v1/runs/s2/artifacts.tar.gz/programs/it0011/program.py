# EVOLVE-BLOCK-START
"""Best fit with residual-value awareness.

Choose the bin that the item fits in most tightly, but only when the resulting
residual is "useful" (likely to be filled by a future item). Otherwise prefer a
slightly larger residual that matches common item sizes, keeping bins cleanly
fillable. Uses online item-size statistics for the usefulness estimate.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    s = _state
    s["n"] += 1
    s["sum"] += item
    mean = s["sum"] / s["n"]

    # resulting residual for every bin
    res = bins - item

    # A residual r is "useful" if some typical future item can fill it well.
    # Score = tightness, but penalize residuals that are unlikely to be filled:
    # small residuals (< ~0.5*mean) are bad (hard to fill, waste), and residuals
    # far from any likely item size are mildly bad.
    # We want the most tightly fitting bin among those whose residual is useful;
    # if none is useful, fall back to plain best fit.

    # usefulness: 1 if residual close to a multiple that helps, else small penalty
    # Heuristic: reward residuals that are either very small (near 0 = perfect fit)
    # or near mean (a single future item likely fits). Penalize mid residuals.
    r = res.astype(np.float64)
    # distance to nearest of {0, mean}: closeness gives bonus
    d0 = np.abs(r)
    dm = np.abs(r - mean)
    d = np.minimum(d0, dm)
    # normalized usefulness in [0,1]
    usefulness = 1.0 - np.minimum(d / mean, 1.0)

    # base: prefer tight fit (small residual)
    score = -r + 0.5 * mean * usefulness
    return score
# EVOLVE-BLOCK-END

