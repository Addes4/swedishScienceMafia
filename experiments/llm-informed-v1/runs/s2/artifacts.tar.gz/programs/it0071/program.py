# EVOLVE-BLOCK-START
"""Best-fit with a smoothed exact-fill probability bonus estimated from the empirical size distribution."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_fill_prob = None      # prob[r] = P(next item exactly fits residual r), smoothed
_dirty = True
_median = 40.0
_min_item = 1.0


def _rebuild():
    global _fill_prob, _median, _min_item, _dirty
    total = _hist[1:101].sum()
    if total < 1:
        return
    p = _hist / max(total, 1.0)  # p[s] for s in 0..100
    # exact-fit probability for residual r equals p[r] (item size == r)
    exact = p.copy()
    # Light smoothing so unseen-but-adjacent sizes still get tiny credit.
    sm = np.convolve(exact, np.array([0.2, 0.6, 0.2]), mode="same")
    _fill_prob = sm
    cdf = np.cumsum(_hist[1:101])
    idx = np.searchsorted(cdf, 0.5 * total)
    _median = float(idx + 1)
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _dirty = False


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _dirty

    _sum += item
    _n += 1
    _hist[item] += 1.0
    _dirty = True

    if _n == 1 or _n % 37 == 0:
        _rebuild()

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    if _fill_prob is not None:
        ri = np.clip(r.astype(np.int64), 0, 100)
        exact_bonus = _fill_prob[ri]
    else:
        exact_bonus = np.zeros_like(r)

    # Best-fit backbone: smaller residual is better.
    base = -r

    # Reward residuals likely to be exactly consumed by a future item.
    score = base + 30.0 * exact_bonus

    # Penalize unusable tiny leftovers.
    tiny = np.where((r > 0) & (r < _min_item), (_min_item - r), 0.0)
    score = score - 0.5 * tiny

    # Tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
