# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus keyed to the empirical item-size distribution."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_freq = np.zeros(101, dtype=np.float64)  # normalized empirical pmf


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _freq

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        _freq = _hist / total

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Exact fits: free capacity, no waste.
    exact = (r < 0.5).astype(np.float64)

    # Value of leaving this residual: probability a single future item exactly
    # fills it (residual equals a frequently-seen item size).
    ri = np.clip(np.rint(r).astype(np.int64), 0, 100)
    p_exact_fill = _freq[ri]

    # Distance to nearest multiple of typical fill size (gaps fillable by
    # typical items).
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    dist = np.minimum(r, dk)

    # Residuals smaller than a typical item may be hard to reuse.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Unusable slivers below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact + 8.0 * p_exact_fill

    # Mild tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
