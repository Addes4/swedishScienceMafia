# EVOLVE-BLOCK-START
"""Best-fit backbone with a CDF-based residual-usefulness tie-breaker."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_cdf = None
_total = 0.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _cdf, _total

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        _cdf = cdf
        _total = total
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strong reward for exact fits (no waste left over at all).
    exact = (r < 0.5).astype(np.float64)

    # Distance to nearest multiple of typical fill size (gaps fillable later).
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    dist = np.minimum(r, dk)

    # Residuals smaller than a typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact

    # CDF-based residual usefulness: how much probability mass of future
    # items can exactly fit the residual, or fill it to a nice complement.
    if _cdf is not None and _total > 0:
        ri = np.clip(np.floor(r).astype(np.int64), 0, 99)
        p_fit = _cdf[ri] / _total                       # P(item <= r)
        comp = np.clip(100.0 - r, 0, 100.0)
        ci = np.clip(np.floor(comp).astype(np.int64) - 1, 0, 99)
        # P(item <= comp) where comp is what would exactly complete the bin.
        p_comp = np.where((comp >= 1) & (comp <= 100),
                          np.where(ci >= 0, _cdf[np.maximum(ci, 0)] / _total, 0.0),
                          0.0)
        # Prefer residuals that are themselves likely fillable AND whose
        # complement is a likely future item (bins finish cleanly).
        useful = 0.5 * p_fit + 0.5 * p_comp
        score = score + 0.25 * useful

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
