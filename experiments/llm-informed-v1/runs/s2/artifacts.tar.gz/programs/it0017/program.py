# EVOLVE-BLOCK-START
"""Best-fit with exact-fill bonus and sliver penalty tuned online."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties).

    item: integer size of arriving item (1..100).
    bins: remaining capacity of every bin the item fits in (inclusive of unused = 100).
    """
    global _sum, _n

    _sum += item
    _n += 1
    _hist[item] += 1.0
    mean = _sum / _n
    m = max(mean, 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Exact / near-exact fill is essentially free capacity.
    exact = (r < 0.5).astype(np.float64)

    # Prefer smaller residuals (best fit), but treat a "sliver" leftover
    # (tiny positive but less than a small item) as undesirable.
    t = min(max(m, 1.0), 100.0)

    score = -r + 5.0 * exact
    # Penalize tiny unusable slivers slightly.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    score = score - 0.75 * sliver

    return score
# EVOLVE-BLOCK-END
