# EVOLVE-BLOCK-START
"""Residual-utility best fit tuned to the item-size distribution's mode."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties).

    item: integer size of arriving item (1..100).
    bins: remaining capacity of every bin the item fits in (inclusive of unused = 100).
    """
    global _sum, _n

    _sum += item
    _n += 1
    _hist[item] += 1.0
    mean = _sum / _n
    m = max(mean, 1.0)

    # Estimate a "typical fill size": the mode of observed item sizes,
    # restricted to a sensible range, blended toward the mean.
    if _n >= 30:
        counts = _hist[1:101]
        # weighted centroid of the densest region: use the max-count bucket
        mode = float(np.argmax(counts) + 1)
        typical = 0.5 * mode + 0.5 * m
    else:
        typical = m
    typical = min(max(typical, 1.0), 100.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    r = residual

    # Exact fill is essentially free capacity; strongly reward it.
    exact = (r < 0.5).astype(np.float64)

    # Distance to nearest multiple of the typical fill size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r

    dist = np.minimum(d0, dk)

    # Penalize tiny unusable slivers (nonzero residual smaller than typical).
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    score = -(dist + 0.75 * sliver) + 5.0 * exact

    # Slight tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
