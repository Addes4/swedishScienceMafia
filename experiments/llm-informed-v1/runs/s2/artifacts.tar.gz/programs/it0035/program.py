# EVOLVE-BLOCK-START
"""Best-fit with empirical-support fillability bonus and late-instance tightness."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0
_total_items = 0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _median, _min_item, _mean, _total_items

    if _n == 0:
        _total_items = len(bins)

    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        counts = _hist[1:101]
        cdf = np.cumsum(counts)
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(counts)[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        _mean = float(np.dot(np.arange(1, 101), counts) / total)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Exact fit: completely free capacity, huge bonus.
    exact = (r < 0.5).astype(np.float64)

    # Empirical support: residuals that match a commonly-seen item size
    # are much more likely to be filled exactly later.
    ri = np.clip(np.rint(r).astype(np.int64), 0, 100)
    support = _hist[ri] / max(_n, 1)
    support = np.where(r < 0.5, 0.0, support)

    # Usable-gap: distance to nearest multiple of the typical fill size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    dist = np.minimum(r, dk)

    # Residuals smaller than a typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact

    # Reward residuals likely to be exactly closed later.
    score = score + 3.0 * support * (r / max(t, 1.0))

    # Late-instance tightness: as remaining items shrink, prefer fuller bins.
    remaining = _total_items - _n
    frac_left = remaining / max(_total_items, 1)
    tight_w = 0.02 * (1.0 - frac_left)
    score = score - tight_w * r

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
