# EVOLVE-BLOCK-START
"""Best-fit with exact-fit reward and a fillability bonus based on the
empirical distribution of seen item sizes, using a coarse histogram."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_typical = 40.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _typical

    _n += 1
    _hist[item] += 1.0

    if _n >= 50:
        sizes = np.arange(1, 101, dtype=np.float64)
        w = _hist[1:101]
        tot = w.sum()
        if tot > 0:
            _typical = float((sizes * w).sum() / tot)

    t = max(min(_typical, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strong reward for perfect fits.
    exact = (r < 0.5).astype(np.float64)

    # Fillability: small residuals (fittable by typical/small future items)
    # are good; very large residuals waste space. Prefer minimizing residual
    # but give a bonus when residual is close to a typical item size, since
    # that gap is likely fillable by one future item.
    d_typ = np.abs(r - t)
    within = np.minimum(r, d_typ)  # distance to "empty" (0) or "one typical item"

    # Penalize unusable tiny slivers relative to smallest likely item.
    small = np.maximum(t * 0.25, 1.0)
    sliver = np.where((r > 0) & (r < small), small - r, 0.0)

    score = -(0.5 * within + 0.5 * r + 0.5 * sliver) + 6.0 * exact
    score = score - 1e-4 * r

    return score
# EVOLVE-BLOCK-END

