# EVOLVE-BLOCK-START
"""Best-fit with exact-fit reward plus a histogram-weighted 'closable residual' bonus."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_p = np.zeros(101, dtype=np.float64)  # normalized probability of each size


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _p

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        _p = _hist / total

    typical = max(min(_median, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Strongly reward exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Distance to nearest multiple of typical fill size (gaps fillable later).
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Residuals smaller than a typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Truly unusable slivers below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Bonus for residuals that a single common item size can close exactly.
    ri = np.rint(r).astype(np.int64)
    valid = (ri >= 1) & (ri <= 100)
    close_bonus = np.where(valid, _p[np.clip(ri, 0, 100)], 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny)
    score = score + 5.0 * exact + 2.0 * close_bonus
    score = score - 1e-3 * r  # tie-break toward fuller placements

    return score
# EVOLVE-BLOCK-END
