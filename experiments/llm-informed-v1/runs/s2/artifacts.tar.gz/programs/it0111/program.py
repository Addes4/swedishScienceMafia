# EVOLVE-BLOCK-START
"""Best-fit with a graded near-fit tier plus the empirical fillability backbone."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_p10 = 10.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _p10

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        jdx = np.searchsorted(cdf, 0.10 * total)
        _p10 = float(jdx + 1)

    typical = max(min(_median, 100.0), 1.0)
    small = max(min(_p10, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Graded near-fit tier: reward leaving a small residual that is itself
    # a likely small future item size (cheap to fill), decaying with size.
    near = np.where((r > 0) & (r <= small), (small - r) / small, 0.0)

    # Distance to nearest multiple of typical fill size (fillability).
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    dist = np.minimum(r, dk)

    # Residuals smaller than a typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact + 2.0 * near
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
