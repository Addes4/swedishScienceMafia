# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus, empirical exact-match term, and a
histogram-based 2-item pairing completion reward. Uses a periodically
rebuilt lookup table to stay fast."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0
_pmax = 0.02
_q25 = 25.0
_q75 = 55.0

# Cached lookup tables.
_pfreq_tab = np.zeros(101, dtype=np.float64)
_pair_tab = np.zeros(101, dtype=np.float64)    # prob residual fillable by sum of 2 items (near)
_band_tab = np.zeros(101, dtype=np.float64)
_last_build = -1


def _rebuild():
    global _pfreq_tab, _pair_tab, _band_tab, _median, _min_item, _mean, _pmax, _q25, _q75
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    cdf = np.cumsum(_hist[1:101])
    idx = np.searchsorted(cdf, 0.5 * total)
    _median = float(idx + 1)
    i25 = np.searchsorted(cdf, 0.25 * total)
    i75 = np.searchsorted(cdf, 0.75 * total)
    _q25 = float(i25 + 1)
    _q75 = float(i75 + 1)
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _mean = _sum / _n
    _pmax = max(float(np.max(_hist[1:101]) / total), 1e-3)

    _pfreq_tab[:] = _hist / total

    # 2-item sum density: distribution of s1+s2 where s1,s2 ~ histogram.
    p = _hist[1:101] / total          # index i -> size i+1
    conv = np.convolve(p, p)          # index j -> sum (j+2)
    sums = np.arange(2, 2 + conv.size)
    # map to residual value (1..200 clamp to 0..100); values >100 irrelevant
    pair = np.zeros(101, dtype=np.float64)
    for j, s in enumerate(sums):
        if s <= 100:
            pair[int(s)] = conv[j]
    _pair_tab[:] = pair

    # band kernel over residual values 0..100
    lo, hi = _q25, _q75
    width = max(hi - lo, 1.0) * 0.5 + 1.0
    mid = 0.5 * (lo + hi)
    x = np.arange(101, dtype=np.float64)
    _band_tab[:] = np.exp(-((x - mid) ** 2) / (2.0 * width * width))


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _mean, _pmax, _q25, _q75, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    typical = max(min(_median, 100.0), 1.0)
    mean = max(min(_mean, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # >= 0

    exact = (r < 0.5).astype(np.float64)

    # Distance to multiples of a typical item size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    dist = np.minimum(r, dk)

    fit_future = np.abs(r - mean)

    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    used = 100.0 - r
    frac = np.where(used > 0, r / used, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact
    score = score - 0.05 * fit_future
    score = score - 1.2 * frac

    if _n >= 30:
        # Exact single-item completion: residual close to a frequent size.
        ri = np.clip(np.rint(r), 1.0, 100.0)
        pfreq = _pfreq_tab[ri.astype(np.int64)]
        near = np.exp(-((r - ri) ** 2) / (2.0 * 1.0))
        score = score + 8.0 * pfreq * near

        # Pairing completion: residual fillable by sum of two common items.
        rpair = np.clip(np.rint(r), 0.0, 100.0).astype(np.int64)
        score = score + 12.0 * _pair_tab[rpair]

        # Gentle band conservation term.
        score = score + 0.3 * np.interp(r, np.arange(101, dtype=np.float64), _band_tab)

    score = score + 20.0 * _pmax * exact
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
