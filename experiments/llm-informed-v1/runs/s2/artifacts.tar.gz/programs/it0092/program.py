# EVOLVE-BLOCK-START
"""Best-fit with exact-fit reward and forward-looking sliver penalties."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_total_items = 0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _total_items

    if _n == 0:
        _total_items = len(bins)

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    # Fraction of items still to arrive (1.0 early, -> 0 late).
    remaining_frac = max(0.0, (_total_items - _n) / max(_total_items, 1))

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Forward-looking minimum usable item: only the smallest observed can
    # arrive, and future minimums can only decrease.
    min_use = max(_min_item, 1.0)

    # Gaps smaller than any item that could arrive are wasted.
    tiny = np.where((r > 0) & (r < min_use), min_use - r, 0.0)

    # Residuals smaller than a typical item can rarely be used.
    sliver = np.where((r > 0) & (r < 0.5 * typical), 0.5 * typical - r, 0.0)

    # Best-fit distance term.
    dist = r

    # Late in packing, closing bins tightly matters more.
    sliver_w = 0.6 + 0.5 * remaining_frac
    tiny_w = 0.5 + 0.5 * remaining_frac

    score = -(dist + sliver_w * sliver + tiny_w * tiny) + 6.0 * exact

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
