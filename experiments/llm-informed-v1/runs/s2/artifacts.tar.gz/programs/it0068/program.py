# EVOLVE-BLOCK-START
"""Best-fit with an empirical expected-residual-waste term."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_median = 40.0
_min_item = 1.0
_mean = 40.0
# Cached empirical distribution quantities.
_cache_n = -1
_bin_pmf = None  # pmf over coarse size classes
_class_rep = None  # representative sizes per class


def _rebuild_cache():
    """Coarse discretization of observed item sizes for waste estimation."""
    global _cache_n, _bin_pmf, _class_rep
    hist = _hist[1:101]
    total = hist.sum()
    if total <= 0:
        _cache_n = _n
        return
    # Go up in steps of 5 to keep it cheap; variable classes near small sizes.
    classes = []
    reps = []
    p = 1
    step_small, step_big = 2, 5
    while p <= 100:
        step = step_small if p <= 10 else step_big
        hi = min(100, p + step - 1)
        mass = hist[p - 1:hi].sum()
        if mass > 0:
            # representative = mass-weighted mean size in class
            szs = np.arange(p, hi + 1, dtype=np.float64)
            w = hist[p - 1:hi]
            reps.append(float((szs * w).sum() / mass))
            classes.append(mass / total)
        p = hi + 1
    _bin_pmf = np.array(classes)
    _class_rep = np.array(reps)
    _cache_n = _n


def _expected_waste(r, reps, pmf):
    """Greedy expected leftover of filling residual r with typical items."""
    if r <= 0:
        return 0.0
    # Deterministic greedy: keep taking the item size closest <= remaining
    # that has positive probability; expected waste accumulated over the
    # ensemble approximated by a small DP over remaining capacity.
    R = int(round(r))
    if R <= 0:
        return 0.0
    # DP over capacity up to R: prob of each achievable room level via items.
    # Cap capacity bucket to keep it fast.
    size = R
    reach = np.zeros(size + 1, dtype=np.float64)
    reach[size] = 1.0
    # Not full DP; instead approximate waste via best single-item fill:
    # use expected leftover after greedy choice distribution.
    waste = 0.0
    rem = size
    while rem > 0:
        # items that fit
        fits = reps <= rem
        if not fits.any():
            break
        mask = fits
        # choose mass-weighted best fill (smallest leftover)
        leftovers = rem - reps[mask]
        # probability each item gets placed as next "typical" item
        w = pmf[mask]
        wsum = w.sum()
        if wsum <= 0:
            break
        # expected leftover contributed when this rem is the state
        # approximate single-step: pick the leftover-weighting
        exp_left = (leftovers * w).sum() / wsum
        # expected reduction added to waste if we stop here:
        waste += exp_left * wsum  # weight by landing mass
        # advance remaining by expected fill
        rem = int(round(exp_left))
        if wsum < 1e-9:
            break
    return waste


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _hist, _n, _median, _min_item, _mean

    _hist[item] += 1.0
    _n += 1

    if _n >= 50 and (_n - _cache_n) >= 25:
        total = _hist[1:101].sum()
        if total > 0:
            _mean = float((np.arange(1, 101) * _hist[1:101]).sum() / total)
            cdf = np.cumsum(_hist[1:101])
            idx = np.searchsorted(cdf, 0.5 * total)
            _median = float(idx + 1)
            nz = np.nonzero(_hist[1:101])[0]
            if nz.size > 0:
                _min_item = float(nz[0] + 1)
        _rebuild_cache()

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    exact = (r < 0.5).astype(np.float64)

    t = max(min(_median, 100.0), 1.0)

    # Distance to nearest multiple of typical fill size.
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    dist = np.minimum(r, dk)

    # Unusable slivers.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
