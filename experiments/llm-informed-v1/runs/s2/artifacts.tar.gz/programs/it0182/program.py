# EVOLVE-BLOCK-START
"""Best-fit backbone with a refined sliver penalty based on the mean item size."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_mean = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _mean, _min_item

    _sum += item
    _n += 1
    if _n >= 30:
        _mean = _sum / _n
    if item < _min_item:
        _min_item = float(item)

    typical = min(max(_mean, 1.0), 100.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Penalize unusable slivers (residual too small to host another item).
    unusable_thresh = min(_min_item, 0.5 * typical)
    sliver = np.where((r > 0) & (r < unusable_thresh),
                      unusable_thresh - r, 0.0)

    # Best-fit primary: smaller residual preferred. Exact fit dominates.
    score = -r - 0.75 * sliver + 5.0 * exact

    return score
# EVOLVE-BLOCK-END
