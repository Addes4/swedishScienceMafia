# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus and a robust small-residual (sliver) penalty."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_mean = 40.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _mean

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 20:
        _mean = _sum / _n
    typical = max(min(_mean, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Penalty for residuals too small to be refilled by a typical item.
    sliver = np.where((r > 0) & (r < 0.4 * typical), 0.4 * typical - r, 0.0)

    # Best-fit primary signal: prefer smaller residual.
    score = -(r + 0.5 * sliver) + 5.0 * exact

    return score
# EVOLVE-BLOCK-END
