# EVOLVE-BLOCK-START
"""Best-fit with a strong exact-fit bonus."""
import numpy as np


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Primary: prefer the smallest usable residual (classic Best Fit).
    score = -residual

    # Secondary: strongly reward exact fits (residual == 0).
    score = score + 5.0 * (residual < 0.5)

    # Tiny tie-break toward fuller placements.
    score = score - 1e-3 * residual

    return score
# EVOLVE-BLOCK-END

