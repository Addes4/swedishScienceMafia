# EVOLVE-BLOCK-START
"""Best-fit backbone with exact-fit reward and residual-fillability shaping.

Kept from the proven version: strong exact-fit reward, best-fit (minimize
residual), penalize unusable slivers.  Replaced the fragile
"distance to nearest multiple of median" term with a coarse, robust
fillability measure: a gap is valuable when it can still host a whole typical
item, which favors leaving residuals near a typical item size instead of
chasing noisy multiples.
"""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # A residual that can still host a whole typical item is valuable; one that
    # cannot (but is nonzero) is a wasted sliver.  This coarse split is more
    # robust than chasing noisy multiples of the median.
    can_hold = (r >= typical).astype(np.float64)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Reward residuals close to a typical fill (good future socket).
    socket = np.exp(-np.abs(r - typical) / typical) * 1.5

    score = -1.0 * r + 2.0 * can_hold + 5.0 * exact + socket - 0.5 * tiny

    return score
# EVOLVE-BLOCK-END
