# EVOLVE-BLOCK-START
"""Best-fit with a calibrated empirical exact-closure bonus.

Pure minimize-residual is the dominant signal for bin packing. On top of it we
add one robust, cheap correction: reward residuals equal to a frequently
observed item size (so a future item of that size can close the bin exactly),
and lightly penalize useless slivers. All noisy multi-term heuristics are
removed.
"""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_min_item = 1.0
_pmax = 0.02

_pfreq_tab = np.zeros(101, dtype=np.float64)   # surviving frequency prob per integer size
_bonus_tab = np.zeros(101, dtype=np.float64)   # log-ish bonus per residual
_last_build = -1


def _rebuild():
    global _pfreq_tab, _bonus_tab, _min_item, _pmax
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _pmax = max(float(np.max(_hist[1:101]) / total), 1e-3)

    _pfreq_tab[:] = _hist / total
    # Bonus proportional to probability the residual equals a future item.
    _bonus_tab[:] = _pfreq_tab


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _min_item, _pmax, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Core: minimize residual (best fit). Exact fill gets the strongest pull.
    score = -r

    # Exact-closure bonus: residual equal to a frequent item size is likely to
    # be closed by a later item of that size.
    if _n >= 30:
        ri = np.clip(np.rint(r), 0.0, 100.0).astype(np.int64)
        bonus = _bonus_tab[ri] * np.exp(-((r - ri) ** 2) / 2.0)
        score = score + 30.0 * bonus

    # Sliver penalty scaled to the observed minimum item size.
    m = _min_item
    sliver = np.where((r > 0) & (r < m), (m - r) * 0.1, 0.0)
    score = score - sliver

    return score
# EVOLVE-BLOCK-END
