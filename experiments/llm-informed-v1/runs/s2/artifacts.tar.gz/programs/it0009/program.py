# EVOLVE-BLOCK-START
"""Best fit with a mild consolidation bonus for already-open bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best fit: smaller residual is better.
    score = -residual.astype(np.float64)
    # Mild bonus for reusing an already-open (non-empty) bin, so we avoid
    # opening fresh bins when a used bin can absorb the item reasonably well.
    # Only applies to used bins; scaled small to not override fit quality.
    used = bins < 100
    score += used * 1.0
    return score
# EVOLVE-BLOCK-END
