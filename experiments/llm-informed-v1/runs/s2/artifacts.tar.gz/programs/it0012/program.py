# EVOLVE-BLOCK-START
"""Residual-utility best fit: prefer placements whose leftover gap is easy to fill later."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties).

    item: integer size of arriving item (1..100).
    bins: remaining capacity of every bin the item fits in (inclusive of unused = 100).
    """
    global _sum, _n

    # Update online mean item size (excludes first call's own item? include it).
    _sum += item
    _n += 1
    mean = _sum / _n

    # Residual capacity after placing the item in each bin.
    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # We want to leave residuals that are "useful": either 0 (perfect fill),
    # or a value we're likely to fill with a future item (near the mean size),
    # rather than a tiny sliver we can never use.
    # Utility peaks at residual == 0 and at residual ~ mean, low in tiny gaps.
    m = max(mean, 1.0)

    # Distance to the nearest "useful" target: 0 or mean (and multiples of mean).
    r = residual
    # distance to 0
    d0 = r
    # distance to nearest multiple of mean
    k = np.rint(r / m)
    dk = np.abs(r - k * m)
    dist = np.minimum(d0, dk)

    # Smaller distance is better; small residual slivers (r small but > 0) are penalized
    # because d0 is small there too, so add a penalty for residuals below a threshold
    # that aren't exactly zero (unusable slivers).
    sliver = np.where((r > 0) & (r < 0.5 * m), 0.5 * m - r, 0.0)

    score = -(dist + 0.75 * sliver)

    # Tie-break toward best fit: slightly prefer smaller residual when utilities equal.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
