# EVOLVE-BLOCK-START
"""Best-fit with a histogram-based future-fill reward for near-tie breaking."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n

    _hist[item] += 1.0
    _n += 1

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Best-fit backbone: strongly prefer the smallest usable residual.
    # Exact fits get a large bonus.
    exact = (r < 0.5).astype(np.float64)

    # Probability that a future item exactly fills this residual, from a
    # smoothed histogram (add-one smoothing so unseen sizes still count a bit).
    if _n >= 30:
        total = _n + 99.0
        smoothed = (_hist[1:101] + 1.0) / total  # indices 1..100
        idx = np.clip(np.rint(r).astype(np.int64), 1, 100)
        p_fill = smoothed[idx - 1]
    else:
        p_fill = np.zeros_like(r)

    score = -r - 1e-3 * r * r + 5.0 * exact + 8.0 * p_fill

    return score
# EVOLVE-BLOCK-END

