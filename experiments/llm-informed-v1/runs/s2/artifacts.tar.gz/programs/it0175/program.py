# EVOLVE-BLOCK-START
"""Best-fit backbone with exact-fit bonus and a mild balanced-residual bonus."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_mean = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _mean, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 25:
        total = _hist[1:101].sum()
        if total > 0:
            sizes = np.arange(1, 101)
            _mean = float((_hist[1:101] * sizes).sum() / total)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_mean, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for shown bins

    r = residual

    # Exact fits are strongly preferred.
    exact = (r < 0.5).astype(np.float64)

    # Primary signal: best-fit (smaller residual is better).
    # Secondary: mild bonus for residuals near half a typical item, which
    # tend to be well-usable by future items.
    target = 0.5 * typical
    balance = -np.abs(r - target) / (typical + 1.0)

    score = -1.0 * r + 8.0 * exact + 0.6 * balance

    return score
# EVOLVE-BLOCK-END
