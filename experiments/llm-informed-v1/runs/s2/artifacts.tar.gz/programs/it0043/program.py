# EVOLVE-BLOCK-START
"""Best-fit with a data-driven fillability bonus from the running histogram."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _median, _min_item

    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # residual after placement, >= 0

    # Fillability: probability that residual equals some likely future item size.
    # Use a smoothed histogram over item sizes 1..100.
    h = _hist[1:101]
    hsum = h.sum()
    if hsum > 0:
        # Smooth with a small triangular kernel (width ~ typical/8) so we
        # generalize to nearby sizes the distribution plausibly produces.
        w = max(int(round(typical / 8.0)), 1)
        kern = 1.0 - np.abs(np.arange(-w, w + 1)) / (w + 1.0)
        kern = kern / kern.sum()
        dens = np.convolve(h, kern, mode="same")
        dens = dens / dens.sum()
    else:
        dens = np.full(100, 1.0 / 100.0)

    # Index 0 of dens -> size 1. Residual r maps to size round(r).
    ri = np.rint(r).astype(np.int64)
    ri = np.clip(ri, 1, 100)
    fill = dens[ri - 1]

    # Exact fits are always best.
    exact = (r < 0.5).astype(np.float64)

    # Slivers smaller than the smallest item seen are wasted.
    sliver = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Best-fit backbone (prefer smallest residual).
    score = -r - 0.5 * sliver + 5.0 * exact

    # Fillability bonus: reward residuals that are likely exact future fits.
    score = score + 12.0 * fill

    return score
# EVOLVE-BLOCK-END
