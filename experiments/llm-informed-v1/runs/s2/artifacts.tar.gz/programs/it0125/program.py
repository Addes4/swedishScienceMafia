# EVOLVE-BLOCK-START
"""Best-fit backbone plus a light, distribution-aware residual bonus."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_freq = np.zeros(101, dtype=np.float64)
_maxfreq = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _maxfreq

    _n += 1
    _hist[item] += 1.0

    # Smoothed empirical frequency over item sizes (probability an item of
    # that size shows up). Used to value fillable residuals.
    total = _n if _n > 0 else 1.0
    _freq = (_hist + 0.5) / (total + 50.0)
    # Normalize by max so the bonus stays O(1).
    _maxfreq = _freq[1:101].max()
    if _maxfreq <= 0:
        _maxfreq = 1.0

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Base: pure best-fit -> prefer smallest usable residual.
    score = -residual

    # Light bonus: residuals that are exact fits (0) or that match a
    # reasonably common item size can likely be fully consumed later.
    rf = np.rint(residual).astype(np.int64)
    safe = np.clip(rf, 0, 100)
    rarity = _freq[safe] / _maxfreq  # in (0, 1]
    exact = (residual < 0.5).astype(np.float64)

    score = score + 0.5 * exact + 0.3 * rarity

    return score
# EVOLVE-BLOCK-END

