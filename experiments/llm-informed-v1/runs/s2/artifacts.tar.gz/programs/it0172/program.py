# EVOLVE-BLOCK-START
"""Threshold best-fit (residual below an adaptive bound) with exact-fit bonus.

Primary signal: prefer the smallest residual that fits (best-fit), but only
distinguish among "tight" bins whose residual is below a threshold derived from
the empirical item distribution.  Among these tight bins, pick the fullest one
(largest item, i.e. smallest residual after placing).  When no tight bin exists,
fall back to pure best-fit.  This is the classic harmonic/threshold best-fit
idea: it keeps bins full without creating many tiny unusable slivers.
"""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_sum_sq = 0.0
_n = 0
_mean = 40.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _sum_sq, _n, _mean

    _sum += item
    _sum_sq += item * item
    _n += 1

    # Estimate the mean item size so we can set a sensible threshold.
    if _n >= 30:
        _mean = _sum / _n
    typical = min(max(_mean, 1.0), 100.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    r = residual

    # Threshold: residuals no larger than one typical item are "tight" and
    # should be closed aggressively (best-fit); larger residuals just take the
    # tightest fit available.
    tight = r <= typical

    # Base: best-fit -> smaller residual is better.
    score = -r

    # Among tight bins, strongly prefer the largest residual (fullest bin
    # after placing) so we don't create unusable slivers.
    score = np.where(tight, -r + 0.0, -r - typical)

    # Exact fits get a decisive bonus (free capacity, zero waste).
    exact = (r < 0.5).astype(np.float64)
    score = score + 5.0 * exact

    # Tiny tie-break toward smaller residual for determinism.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
