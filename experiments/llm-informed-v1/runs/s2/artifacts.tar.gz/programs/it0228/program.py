# EVOLVE-BLOCK-START
"""Best-fit with exact-fill bonus.

Items arrive online; classic best-fit (place into the bin whose residual after
placement is smallest) is a strong, robust rule for these Weibull-sized items.
We add a large bonus for placements that leave zero residual (exact fill) and a
mild penalty for tiny unusable slivers, plus a gentle tie-break toward fuller
bins. No histogram matching to avoid overfitting to the sampled sizes.
"""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _min_item

    _n += 1
    if item < _min_item:
        _min_item = float(item)

    r = bins.astype(np.float64) - item  # residual >= 0 for all shown bins

    # Classical best-fit: smaller residual is better.
    score = -r

    # Exact fill: residual zero -> perfect, strongly reward.
    exact = (r < 0.5).astype(np.float64)
    score = score + 50.0 * exact

    # Mild penalty for residuals that are too small to usefully fill later.
    sliver = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)
    score = score - 0.5 * sliver

    # Tiny tie-break toward fuller placements (redundant with -r but keeps
    # ordering stable against the exact/sliver terms).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
