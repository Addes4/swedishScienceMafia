# EVOLVE-BLOCK-START
"""Best-fit with an adaptive "usable residual" bonus keyed to empirical size quantiles."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_q_small = 40.0   # a typical small item scale (~15th percentile)
_q_med = 40.0     # median item size


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _q_small, _q_med

    _n += 1
    _hist[item] += 1.0

    if _n >= 40:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        if total > 0:
            _q_med = float(np.searchsorted(cdf, 0.50 * total) + 1)
            _q_small = float(np.searchsorted(cdf, 0.15 * total) + 1)

    med = max(min(_q_med, 100.0), 1.0)
    small = max(min(_q_small, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Strongly reward exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Residuals below the small-item scale are likely dead space -> penalize.
    dead = np.where((r > 0) & (r < small), small - r, 0.0)

    # Prefer residuals that are large enough to still hold a median item,
    # since those bins remain useful; mildly prefer residuals near a multiple
    # of the median so they can be filled exactly with typical items.
    k = np.rint(r / med)
    dist_med = np.abs(r - k * med)

    # Slight preference for residuals that can still accept a median-sized item.
    usable = np.where(r >= med, 1.0, 0.0)

    score = -1.0 * r - 0.6 * dead - 0.3 * dist_med + 0.4 * usable + 20.0 * exact
    return score
# EVOLVE-BLOCK-END

