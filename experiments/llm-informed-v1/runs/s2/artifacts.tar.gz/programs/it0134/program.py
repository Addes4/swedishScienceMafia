# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware one/two-item fillability bonus."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _median, _min_item

    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # residual after placement, >= 0

    # Probabilities of future item sizes from the empirical histogram.
    counts = _hist[1:101]
    tot = counts.sum()
    if tot > 0:
        p = counts / tot
    else:
        p = np.ones(100) / 100.0

    # Exact fit is the best outcome: leaves zero wasted space.
    exact = (r < 0.5).astype(np.float64)

    # Fillability: probability the residual can be exactly covered by one
    # future item, or by two future items whose sizes sum to the residual.
    fill_one = np.zeros_like(r)
    fill_two = np.zeros_like(r)

    # Residual sizes are integers in [0, 100].
    r_int = np.rint(r).astype(np.int64)
    valid = (np.abs(r - r_int) < 1e-6)
    r_int = np.clip(r_int, 0, 100)

    # one-item cover: p[r]
    ridx = r_int - 1
    one_ok = valid & (r_int >= 1)
    fill_one = np.where(one_ok, p[np.clip(ridx, 0, 99)], 0.0)

    # two-item cover prob: sum over s of p[s]*p[r-s]
    for s in range(1, 100):
        if p[s - 1] <= 0.0:
            continue
        rem = r_int - s
        ok = valid & (rem >= 1) & (rem <= 100)
        fill_two += np.where(ok, p[s - 1] * p[np.clip(rem - 1, 0, 99)], 0.0)

    fillability = np.maximum(fill_one, 0.6 * fill_two)

    # Waste penalty: large residuals waste more absolute space.
    waste = r * 0.01

    # Score: maximize fillability of leftover space, penalize waste, big
    # bonus for exact fits, prefer fuller placements slightly.
    score = 3.0 * exact + 6.0 * fillability - waste - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
