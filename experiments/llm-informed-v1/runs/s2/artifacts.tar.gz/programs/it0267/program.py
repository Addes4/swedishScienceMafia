# EVOLVE-BLOCK-START
"""Best-fit with exact-fill bonus, a smooth capacity-profile reward based on
the empirical item distribution, and a two-item sum-completion bonus.
Uses periodically rebuilt lookup tables to stay fast."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0
_pmax = 0.02
_q25 = 25.0
_q75 = 55.0

# Cached lookup tables.
_two_tab = np.zeros(101, dtype=np.float64)     # P(residual fillable by sum of two common items)
_prof_tab = np.zeros(101, dtype=np.float64)    # smooth capacity-profile reward per residual
_last_build = -1


def _rebuild():
    global _two_tab, _prof_tab, _median, _min_item, _mean, _pmax, _q25, _q75
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    cdf = np.cumsum(_hist[1:101])
    idx = np.searchsorted(cdf, 0.5 * total)
    _median = float(idx + 1)
    i25 = np.searchsorted(cdf, 0.25 * total)
    i75 = np.searchsorted(cdf, 0.75 * total)
    _q25 = float(i25 + 1)
    _q75 = float(i75 + 1)
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _mean = _sum / _n
    _pmax = max(float(np.max(_hist[1:101]) / total), 1e-3)

    freq = _hist / total  # freq[s] for s in 0..100

    # Two-item sum completion probability: for residual r, P(an ordered pair
    # of items sums to r) ~ sum_{s} f(s) f(r-s).
    conv = np.convolve(freq[1:101], freq[1:101])  # index i = sum of two sizes minus 2
    _two_tab[:] = 0.0
    for s in range(2, 101):
        _two_tab[s] = conv[s - 2]
    # Normalize so values fall in a sane range (avoid explosion of conv peak).
    mx = np.max(_two_tab)
    if mx > 0:
        _two_tab /= mx

    # Smooth capacity-profile reward: residuals near the median/mode are good
    # because a single typical item likely closes the bin.
    x = np.arange(101, dtype=np.float64)
    sig = max((_q75 - _q25) * 0.5, 1.0)
    _prof_tab[:] = np.exp(-((x - _median) ** 2) / (2.0 * sig * sig))
    _prof_tab[0] = 0.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _mean, _pmax, _q25, _q75, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    typical = max(min(_median, 100.0), 1.0)
    mean = max(min(_mean, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # residual (>= 0)

    # Exact fill: residual 0 -> perfect.
    exact = (r < 0.5).astype(np.float64)

    # Best-fit core: distance of residual to a typical item multiple.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Sliver and tiny penalties.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Waste fraction.
    used = 100.0 - r
    frac = np.where(used > 0, r / used, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact

    # Reward residuals that host a future average item.
    score = score - 0.05 * np.abs(r - mean)

    score = score - 1.5 * frac

    if _n >= 30:
        ri = np.clip(np.rint(r), 0.0, 100.0).astype(np.int64)
        # Two-item sum-completion bonus (bins closed by pairs of items).
        score = score + 3.0 * _two_tab[ri]
        # Smooth capacity-profile reward.
        score = score + 0.5 * _prof_tab[ri]

    # Extra exact-fill weight from empirical max probability.
    score = score + 20.0 * _pmax * exact

    # Tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
