# EVOLVE-BLOCK-START
"""Best-fit with fillability guard keyed to empirical minimum item size."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_min_item = 40.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _min_item

    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    r = residual

    # Rewards.
    exact = (r < 0.5).astype(np.float64)

    # Fillability guard: residual that can still accept the smallest item seen
    # is "usable"; a smaller positive residual is a dead sliver.
    m = _min_item
    sliver = np.where((r > 0) & (r < m), m - r, 0.0)

    # Best-fit backbone: prefer smaller residual (fuller bins).
    score = -r - 1.5 * sliver + 1e6 * exact

    return score
# EVOLVE-BLOCK-END
