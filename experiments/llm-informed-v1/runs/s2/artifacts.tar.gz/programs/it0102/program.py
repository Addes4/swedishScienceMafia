# EVOLVE-BLOCK-START
"""Best-fit with exact-fit reward and empirical residual-fillability bonus."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    # Empirical distribution updates (cheap, O(101)).
    cdf = np.cumsum(_hist[1:101])
    total = cdf[-1]
    if _n >= 30 and total > 0:
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Empirical probability that a random future item fits in each residual.
    # P(fit) ~ (fraction of mass with size <= r).
    if total > 0:
        p_fit = cdf[np.clip((r - 1).astype(np.int64), 0, 99)] / total
    else:
        p_fit = np.zeros_like(r)

    # Expected usable capacity: how much of the residual is likely consumable.
    usable = r * p_fit

    # Penalty for residuals that are small relative to typical items (slivers).
    sliver = np.where((r > 0) & (r < 0.5 * typical), 0.5 * typical - r, 0.0)

    # Truly unusable slivers below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Best-fit backbone: prefer smaller residual, but reward fillable residuals.
    score = -1.0 * r + 0.5 * usable - 0.75 * sliver - 0.5 * tiny + 5.0 * exact
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
