# EVOLVE-BLOCK-START
"""Best-fit backbone plus a reward for residuals completable by a single
observed item size (two-item exact-fill lookahead)."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_total = 0.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _total

    _sum += item
    _n += 1
    _hist[item] += 1.0
    _total += 1.0

    if _n >= 40:
        cdf = np.cumsum(_hist[1:101])
        tot = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * tot)
        _median = float(idx + 1)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Empirical probability that some observed size exactly equals residual.
    # Use histogram smoothed by frequency counts.
    prob = _hist[1:101] / max(_total, 1.0)

    ri = np.clip(np.rint(r).astype(np.int64), 0, 100)
    exact_prob = prob[np.clip(ri - 1, 0, 99)]  # P(next item exactly fills r)

    # Best-fit dominant term: prefer small residual.
    score = -r

    # Reward residuals that a typical future item can exactly fill.
    score = score + 30.0 * exact_prob

    # Reward exact zero residual strongly.
    score = score + 5.0 * (r < 0.5)

    # Penalize unusable slivers below the empirical minimum observed item.
    nz = np.nonzero(_hist[1:101])[0]
    min_item = float(nz[0] + 1) if nz.size > 0 else 1.0
    score = score - np.where((r > 0) & (r < min_item), 3.0 * (min_item - r), 0.0)

    # Slight tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

