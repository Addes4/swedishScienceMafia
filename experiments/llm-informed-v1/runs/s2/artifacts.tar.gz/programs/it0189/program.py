# EVOLVE-BLOCK-START
"""Best-fit dominant rule with exact-fit bonus and mean-residual closure bonus."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n

    _sum += item
    _n += 1.0
    mean = _sum / _n

    r = bins.astype(np.float64) - item  # residual after placement, >= 0

    # Dominant term: pure best-fit (prefer smallest residual).
    score = -r

    # Exact fit: free capacity, no waste -> strong bonus.
    exact = (r < 0.5).astype(np.float64)
    score = score + 5.0 * exact

    # Closure bonus: if the residual can exactly hold one typical (mean-sized)
    # future item, the bin may be perfectly closed later.
    t = mean if mean > 0.5 else 40.0
    close = np.exp(-((r - t) ** 2) / (2.0 * (0.15 * t) ** 2))
    score = score + 0.25 * close

    # Slight penalty for leaving a tiny positive sliver that no item can use.
    sliver = ((r > 0) & (r < 1.0)).astype(np.float64)
    score = score - 0.1 * sliver

    return score
# EVOLVE-BLOCK-END
