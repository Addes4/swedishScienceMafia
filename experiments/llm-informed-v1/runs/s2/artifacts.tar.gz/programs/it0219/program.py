# EVOLVE-BLOCK-START
"""Best-fit driven mainly by the empirical probability that a candidate
residual is exactly settled by a future item (histogram-match), plus a strong
exact-fit bonus. Weak hand-tuned terms are removed to reduce noise."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0
_pmax = 0.02
_pfreq_tab = np.zeros(101, dtype=np.float64)   # surviving frequency prob per size
_last_build = -1


def _rebuild():
    global _pfreq_tab, _median, _min_item, _mean, _pmax
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    cdf = np.cumsum(_hist[1:101])
    idx = np.searchsorted(cdf, 0.5 * total)
    _median = float(idx + 1)
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _mean = _sum / _n
    _pmax = max(float(np.max(_hist[1:101]) / total), 1e-3)
    _pfreq_tab[:] = _hist / total


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    residual = bins.astype(np.float64) - item
    r = residual

    # Exact fill: residual 0 -> perfect placement (always take it).
    exact = (r < 0.5).astype(np.float64)

    # Dominant signal: probability that residual is exactly settled by a
    # future item (residual equals a commonly seen item size).
    if _n >= 30:
        ri = np.clip(np.rint(r), 1.0, 100.0).astype(np.int64)
        pfreq = _pfreq_tab[ri]
        near = np.exp(-((r - ri) ** 2) / (2.0 * 1.0))
        hist_match = pfreq * near
    else:
        hist_match = np.zeros_like(r)

    # Strong exact-fit reward, scaled by how likely such an exact item is.
    score = 60.0 * exact + 12.0 * hist_match

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
