# EVOLVE-BLOCK-START
"""Best-fit backbone with exact-fit reward and a frequency-weighted fillability bonus."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _hist

    _n += 1
    _hist[item] += 1.0

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Strong reward for perfectly filling a bin.
    exact = (r < 0.5).astype(np.float64)

    # Frequency-weighted fillability: how likely this residual can be
    # matched by a future item (residual equals a commonly seen size).
    idx = np.clip(r.astype(np.int64), 0, 100)
    freq = _hist[idx] / _n  # in [0,1], probability the gap is a seen size

    # Best-fit backbone: minimize residual strongly.
    score = -(r) + 5.0 * exact + 2.0 * freq

    # Mild tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
