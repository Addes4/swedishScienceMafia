# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus and a cheap histogram-driven gap bonus."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _hist

    _n += 1
    _hist[item] += 1.0

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Base: best-fit (prefer smallest residual).
    score = -residual

    # Strong reward for exact fits (perfect, no waste at all).
    score += 6.0 * (residual < 0.5)

    # Bonus if this residual could be exactly completed by some item size
    # that is common in the observed stream so far. Uses the running
    # histogram (cheap: only the residual bin index is looked up).
    if _n >= 20:
        # Normalize histogram into a probability over residual values 1..100.
        total = _hist.sum()
        if total > 0:
            # residual values are integers in [0, 100]; exact match bonus.
            r = residual.astype(np.int64, copy=False)
            valid = (r >= 1) & (r <= 100)
            prob = np.zeros_like(residual)
            prob[valid] = _hist[r[valid]] / total
            # Scale bonus by how likely that exact size is.
            score += 3.0 * prob

    return score
# EVOLVE-BLOCK-END
