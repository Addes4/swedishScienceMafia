# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus keyed to the empirical item distribution."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
# Cached distribution-derived quantities.
_sizes = None          # array of item sizes with positive empirical mass
_freq = None           # normalized frequencies
_fill = None           # fill[g] = fraction of mass packable into gap g
_last_update = -1


def _recompute():
    """Rebuild best-packable-fraction lookup over gaps 0..100."""
    global _sizes, _freq, _fill
    counts = _hist[1:101]
    total = counts.sum()
    if total <= 0:
        return
    nz = np.nonzero(counts)[0]
    sizes = (nz + 1).astype(np.int64)
    freq = counts[nz] / total
    # Fill fraction: probability that a future item fits into the gap
    # (mass of sizes <= g) plus that the remaining space is itself usable.
    cdf = np.cumsum(counts) / total          # cdf[g-1] = P(size <= g)
    usable = np.zeros(101, dtype=np.float64)
    for g in range(101):
        if g <= 0:
            usable[g] = 0.0
            continue
        # expected usable mass via one greedy future item packing
        acc = 0.0
        rem = g
        # bounded: test a handful of largest feasible sizes greedily
        best = 0.0
        for s, f in zip(sizes[::-1], freq[::-1]):
            if s <= rem:
                # gain: this item placed, plus fraction of its mass pondered
                val = f * (s + 0.5 * cdf[min(rem - s, 100) - 1] if rem - s > 0 else f * s)
                if val > best:
                    best = val
        # base: probability some item fits at all weighted by its size
        acc = 0.0
        for s, f in zip(sizes, freq):
            if s <= g:
                acc += f * s
        usable[g] = acc
    _sizes = sizes
    _freq = freq
    _fill = usable


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _last_update

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    r = residual

    # Exact fits are always great.
    exact = (r < 0.5).astype(np.float64)

    # Distance to nearest multiple of typical fill size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Residuals smaller than a typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Fill potential: fraction of empirical mass that can still be packed.
    # Recompute lazily every few calls to stay cheap.
    global _fill
    if _fill is None or (_n % 50 == 0):
        _recompute()
    if _fill is not None:
        ri = np.clip(np.rint(r).astype(np.int64), 0, 100)
        fillpot = _fill[ri]
    else:
        fillpot = 0.0

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact + 2.0 * fillpot

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

