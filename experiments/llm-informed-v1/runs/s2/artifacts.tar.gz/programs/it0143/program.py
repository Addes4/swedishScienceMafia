# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus and robust unusable-gap penalty."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_small = 1.0  # robust estimate of a small-but-plausible item size
_median = 40.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _small, _median

    _n += 1
    _hist[item] += 1.0

    if _n >= 50:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        # 10th percentile: robust "small usable item" threshold.
        idx10 = np.searchsorted(cdf, 0.10 * total)
        _small = float(idx10 + 1)
        idx50 = np.searchsorted(cdf, 0.50 * total)
        _median = float(idx50 + 1)

    residual = bins.astype(np.float64) - item  # >= 0

    r = residual
    small = max(_small, 1.0)

    # Strong exact-fit reward.
    exact = (r < 0.5).astype(np.float64)

    # Penalize leaving a gap below the robust small-item threshold: such a
    # gap is likely wasted since few items will fit it.
    wasted = np.where((r > 0) & (r < small), small - r, 0.0)

    # Mild preference for residuals large enough to host a typical item.
    med = max(_median, 1.0)
    shortfall = np.where(r < med, med - r, 0.0)

    score = -(r) - 0.5 * wasted - 0.15 * shortfall + 6.0 * exact

    return score
# EVOLVE-BLOCK-END

