# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus and an empirical-CDF fillability penalty for gaps."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_min_item = 1.0
_bins_total = 0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    r = residual

    # Strongly reward exact fits (zero residual -> no waste).
    exact = (r < 0.5).astype(np.float64)

    # Penalize gaps that are too small to hold the smallest item seen so far:
    # such residual can never be used again.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Best-fit backbone: prefer leaving the smallest residual.
    score = -r + 5.0 * exact - 0.75 * tiny

    return score
# EVOLVE-BLOCK-END

