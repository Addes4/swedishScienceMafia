# EVOLVE-BLOCK-START
"""Best-fit plus exact-completion bonus weighted by the empirical
probability of seeing a future item equal to the residual (or close to it),
scaled by the observed small-item mass. Kept deliberately simple: the
best-fit structure dominates and only clearly useful signals are added."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0
_pmax = 0.02

# Cached lookup table (rebuilt periodically, cheap).
_pfreq_tab = np.zeros(101, dtype=np.float64)  # empirical prob per integer size
_last_build = -1


def _rebuild():
    global _pfreq_tab, _median, _min_item, _mean, _pmax
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    cdf = np.cumsum(_hist[1:101])
    idx = np.searchsorted(cdf, 0.5 * total)
    _median = float(idx + 1)
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _mean = _sum / _n
    _pmax = max(float(np.max(_hist[1:101]) / total), 1e-3)
    _pfreq_tab[:] = _hist / total


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _mean, _pmax, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    r = bins.astype(np.float64) - item  # residual, >= 0 for shown bins

    # Core best-fit: prefer the smallest usable residual.
    score = -r

    # Strong reward for a perfect fill (residual 0).
    exact = (r < 0.5).astype(np.float64)
    score = score + 100.0 * exact

    # Reward residuals that equal a commonly observed item size: that residual
    # is likely to be closed exactly by a future item, saving a bin.
    if _n >= 30:
        ri = np.clip(np.rint(r), 1.0, 100.0).astype(np.int64)
        pfreq = _pfreq_tab[ri]
        near = (np.abs(r - ri) < 0.5).astype(np.float64)
        score = score + 30.0 * pfreq * near

    # Small tie-break weight on exact-fit likelihood at the current residual.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
