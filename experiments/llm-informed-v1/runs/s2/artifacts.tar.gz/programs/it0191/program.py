# EVOLVE-BLOCK-START
"""Aggressive best-fit with a strong exact-fit bonus."""
import numpy as np


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Strongly reward exact fits (zero waste).
    exact = (residual < 0.5).astype(np.float64)

    # Dominant term: prefer the fullest bin (smallest residual = best fit).
    score = -residual + 5.0 * exact

    return score
# EVOLVE-BLOCK-END
