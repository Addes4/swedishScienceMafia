# EVOLVE-BLOCK-START
"""Best-fit with a distribution-weighted residual fill-efficiency bonus."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_cdf = np.zeros(102, dtype=np.float64)  # _cdf[r] = P(size <= r)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _cdf

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        counts = _hist[1:101]
        total = counts.sum()
        _cdf[1:101] = np.cumsum(counts) / total
        _cdf[101] = 1.0
        idx = np.searchsorted(_cdf[1:101], 0.5)
        _median = float(idx + 1)
        nz = np.nonzero(counts)[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Expected fraction of the residual that future typical items can fill:
    # integral of CDF over (0, r], normalized by r, gives a per-unit
    # "fillability" of the leftover space. Use a look-up of precomputed CDF.
    ridx = np.clip(r.astype(np.int64), 0, 100)
    # approximate E[min(X, r)] where X ~ empirical item size, via CDF integral
    # E[min(X,r)] = sum_{s=1..r} P(X >= s) = r - sum_{s=1..r} P(X <= s-1)
    # Use cumulative of CDF.
    fill = np.zeros_like(r)
    # Precompute prefix sums once per call using _cdf
    cdf_prefix = np.concatenate(([0.0], np.cumsum(_cdf[0:101])))  # length 102
    # sum_{s=1..r} P(X <= s-1) = sum_{k=0..r-1} cdf[k]
    fill = r - cdf_prefix[ridx]
    efficiency = np.where(r > 0, fill / np.maximum(r, 1e-9), 0.0)

    # Residuals smaller than a typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * typical), 0.5 * typical - r, 0.0)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Best-fit backbone via -r, with fill-efficiency bonus and penalties.
    score = -r / 100.0 + 1.5 * efficiency - 0.75 * sliver - 0.5 * tiny + 5.0 * exact

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-6 * r

    return score
# EVOLVE-BLOCK-END
