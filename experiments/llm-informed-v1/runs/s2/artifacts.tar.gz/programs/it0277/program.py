# EVOLVE-BLOCK-START
"""Best-fit ranking enhanced by empirical residual-closure probability.

The score for each bin is composed of:
  * a strong exact-fill bonus (residual == 0),
  * the probability that the residual after placing can be exactly closed by a
    single future item, estimated from the observed item distribution,
  * a small sliver penalty and a tie-break toward fuller bins.

State is tracked across calls (fresh per instance)."""
import numpy as np

_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_last_build = -1
_pclose_tab = np.zeros(101, dtype=np.float64)  # closure prob per residual 0..100
_median = 40.0


def _rebuild():
    global _pclose_tab, _median
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    freq = _hist / total
    # Smooth the empirical frequency over integer sizes so unseen sizes get
    # a small but nonzero probability (helps generalization).
    kernel = np.array([1, 2, 3, 2, 1], dtype=np.float64)
    smooth = np.convolve(freq[1:101], kernel, mode="same")
    smooth = smooth / np.sum(smooth) if np.sum(smooth) > 0 else freq[1:101]
    _pclose_tab[:] = 0.0
    _pclose_tab[1:101] = smooth  # closure prob for residual r is P(item == r)
    # median for a far-fit tie-break
    cdf = np.cumsum(freq[1:101])
    _median = float(np.searchsorted(cdf, 0.5 * total) + 1)


def priority(item, bins):
    global _sum, _n, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 40 and (_last_build < 0 or _n - _last_build >= 150):
        _rebuild()
        _last_build = _n

    residual = bins.astype(np.float64) - item  # >= 0 for shown bins
    r = residual

    score = np.zeros_like(r)

    # Strong exact-fill bonus.
    score += 50.0 * (r < 0.5)

    # Empirical closure probability of the residual.
    ri = np.clip(np.rint(r), 0.0, 100.0).astype(np.int64)
    pclose = _pclose_tab[ri]
    near = np.exp(-((r - ri) ** 2) / (2.0 * 1.0))
    score += 25.0 * pclose * near

    # Sliver penalty: residual too small to be useful.
    sliver = np.where((r > 0) & (r < 0.35 * _median), 0.35 * _median - r, 0.0)
    score -= 0.6 * sliver

    # Prefer leaving a residual that can still host a typical item.
    score -= 0.02 * np.abs(r - _median)

    # Tie-break toward the fullest bin.
    score -= 1e-3 * r

    return score
# EVOLVE-BLOCK-END
