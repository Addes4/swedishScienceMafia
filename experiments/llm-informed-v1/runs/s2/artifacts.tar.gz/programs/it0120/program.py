# EVOLVE-BLOCK-START
"""Best-fit with fill-efficiency and sliver-avoidance keyed to running stats."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_mean = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _mean, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0
    _mean = _sum / _n

    if _n >= 20:
        # Empirical minimum item size observed so far.
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Pure best-fit backbone: prefer the smallest usable residual.
    # Reward residuals that are a whole multiple of the average item,
    # i.e. gaps a stream of average items could refill nearly exactly.
    t = max(_mean, 1.0)
    k = np.rint(r / t)
    mult_err = np.abs(r - k * t)
    fill_bonus = -mult_err

    # Penalize unusable slivers (positive but below the smallest item seen).
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Strong reward for exact fits.
    exact = (r < 0.5).astype(np.float64)

    score = -(r / t) + 0.15 * fill_bonus - 0.6 * tiny + 4.0 * exact

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
