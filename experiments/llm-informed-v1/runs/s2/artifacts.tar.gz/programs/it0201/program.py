# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus and unusable-sliver penalty."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _min_item

    _n += 1
    _hist[item] += 1.0
    if _n >= 30:
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    r = bins.astype(np.float64) - item  # residual, >= 0

    exact = (r < 0.5).astype(np.float64)

    # Penalize residuals too small to ever hold another item.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Best-fit dominates via -r; exact fits get a strong bonus.
    score = -r - 0.5 * tiny + 5.0 * exact

    return score
# EVOLVE-BLOCK-END
