# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus keyed to empirical fill-mass of residuals."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_cdf = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _total

    _sum += item
    _n += 1
    _hist[item] += 1.0
    _total += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        tot = cdf[-1]
        _cdf = cdf / tot if tot > 0 else cdf
        idx = np.searchsorted(cdf, 0.5 * tot)
        _median = float(idx + 1)

    typical = max(min(_median, 100.0), 1.0)
    cdf = _cdf  # CDF over sizes 1..100; cdf[i-1] = P(size <= i)

    residual = bins.astype(np.float64) - item  # >= 0 for shown bins
    r = residual

    # Probability that a residual r is "usable": there exists a future item <= r.
    # Approximate by P(size <= r) using the empirical CDF.
    ridx = np.clip(r.astype(np.int64), 0, 100)
    usable = np.where(ridx >= 1, cdf[np.maximum(ridx - 1, 0)], 0.0)

    # Small residuals are less usable; large residuals leave lots of free space.
    # We reward moderate residuals that are likely to be filled.
    # Distance to the "typical" fill target, but scaled by usable probability.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Penalize small-but-nonzero residuals (slivers) more when unusable.
    sliver = np.where((r > 0) & (r < 0.5 * t), (0.5 * t - r) * (1.0 - usable), 0.0)

    exact = (r < 0.5).astype(np.float64)

    # Reward residuals that are very likely fillable (high usable prob).
    fill_bonus = usable

    score = -(dist + 0.75 * sliver) + 5.0 * exact + 1.5 * fill_bonus
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

