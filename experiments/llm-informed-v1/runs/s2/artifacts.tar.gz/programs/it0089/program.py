# EVOLVE-BLOCK-START
"""Best-fit with exact-fit reward, sliver penalties, and a large-item reserve term."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_q90 = 70.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _q90

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        ix90 = np.searchsorted(cdf, 0.90 * total)
        _q90 = float(ix90 + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)
    big = max(min(_q90, 100.0), 1.0)

    residual = bins.astype(np.float64) - item
    r = residual

    exact = (r < 0.5).astype(np.float64)

    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Reserve capacity for large items: if this item is small, penalize
    # creating a residual that is just below a common large size.
    reserve = np.where((item < big) & (r > 0) & (r < big), (big - r) / big, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 6.0 * exact - 0.25 * reserve

    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
