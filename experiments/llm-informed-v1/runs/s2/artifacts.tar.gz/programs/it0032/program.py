# EVOLVE-BLOCK-START
"""Score each fitting bin by closeness to an exact fill, with best-fit dominance."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    t = max(min(_median, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Usable-gap bonus: residuals near a multiple of typical item size.
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    dist = np.minimum(r, dk)

    # Penalize residuals too small to ever be filled again.
    tiny = np.where((r > 0) & (r < _min_item), 1.0, 0.0)

    # Best-fit dominance: smaller residual is generally better.
    score = -r - 0.15 * dist - 3.0 * tiny

    return score
# EVOLVE-BLOCK-END
