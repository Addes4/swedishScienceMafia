# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus and a reserve-for-large-items correction."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Distance to nearest multiple of typical fill size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact

    # Reserve correction: a bin that currently holds a large residual (>= 50)
    # is the only fit for future large items. If placing this item drops the
    # residual below 50, penalize; if it keeps it >= 50, lightly reward.
    before_big = bins.astype(np.float64) >= 50.0
    after_big = r >= 50.0
    downgrade = (before_big & (~after_big)).astype(np.float64)
    keep_big = (before_big & after_big).astype(np.float64)
    small_item = 1.0 if item < 30 else 0.0
    score = score - 3.0 * downgrade * small_item + 0.2 * keep_big * small_item

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

