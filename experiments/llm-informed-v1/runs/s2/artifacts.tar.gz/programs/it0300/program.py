# EVOLVE-BLOCK-START
"""Best-fit with an exact-fit bonus: place the item into the bin whose
remaining residual after placement is smallest, strongly preferring residuals
that reach exactly zero (a perfect fill)."""
import numpy as np


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Perfect fill gets a huge bonus; otherwise smaller residual wins.
    exact = (r < 0.5).astype(np.float64)
    score = -r + 100.0 * exact

    return score
# EVOLVE-BLOCK-END
