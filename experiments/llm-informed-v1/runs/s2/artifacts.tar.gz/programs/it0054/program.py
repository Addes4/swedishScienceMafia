# EVOLVE-BLOCK-START
"""Best-fit with multiplicative (log-ratio) fillability spacing."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Exact fits are best: no waste.
    exact = (r < 0.5).astype(np.float64)

    # Multiplicative spacing: gap that can be closed by k typical items.
    # Use log-ratio to typical size; integer k => log(k*typical) grid.
    t = typical
    safe_r = np.maximum(r, 1e-6)
    ratio = safe_r / t
    k = np.maximum(np.rint(ratio), 1.0)          # nearest positive integer
    # log-space distance to nearest integer multiple of t
    logdist = np.abs(np.log(safe_r) - np.log(k * t))

    # Sliver regions: residual below t can hold at most a few small items;
    # penalize gaps that are awkward (not near an integer multiple in ratio).
    frac = ratio - np.floor(ratio)                 # 0..1 within next multiple
    sliver = np.where((r > 0) & (r < t), 1.0 - np.abs(2.0 * frac - 1.0), 0.0)

    # Truly unusable slivers below empirical minimum item.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(logdist + 1.0 * sliver + 0.5 * tiny) + 5.0 * exact
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

