# EVOLVE-BLOCK-START
"""Best-fit with reuse-aware residuals keyed to the empirical size histogram."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n

    _sum += item
    _n += 1
    _hist[item] += 1.0

    total = float(_n)
    # Probability mass of a future item exactly hitting a residual r.
    if total > 0:
        prob = _hist / total
    else:
        prob = _hist

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Expected chance that residual r can be exactly consumed by a single
    # typical future item: mass at r (clip to valid range).
    ri = np.clip(r.astype(np.int64), 0, 100)
    reuse = prob[ri]

    # Exact fit -> free, small bonus.
    exact = (r < 0.5).astype(np.float64)

    # Residuals below the smallest common item size are near-certain waste.
    # Use empirical lower tail (5th percentile) as the reuse threshold.
    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        tot = cdf[-1]
        idx = np.searchsorted(cdf, 0.05 * tot)
        low = float(idx + 1)
    else:
        low = 1.0

    sliver = np.where((r > 0) & (r < low), low - r, 0.0)

    # Dominant term: smallest residual (best-fit). Reuse bonus refines ties.
    score = -r + 5.0 * exact - 0.8 * sliver + 2.0 * reuse

    return score
# EVOLVE-BLOCK-END
