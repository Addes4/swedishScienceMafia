# EVOLVE-BLOCK-START
"""Best-fit with a histogram-based exact-fill (collision) bonus."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_mode = 40.0
_psize = None  # cached fillability lookup, rebuilt periodically


def _rebuild(remaining):
    """Build a lookup of how fillable each residual value is.

    For residual r, score is high if r equals a common item size, or if r can
    be tiled by a small number of the most common item sizes.
    """
    global _psize, _mode
    h = _hist[1:101]
    total = h.sum()
    if total <= 0:
        return
    p = h / total
    # Mode (most common item size) is the main fill unit.
    _mode = float(np.argmax(h) + 1)

    # Build a "tileability" measure: for each residual 0..100, the best
    # probability-weighted match.  A residual is valuable if it is close to
    # an integer combination of the dominant item sizes.
    sizes = np.arange(1, 101)
    # top few most probable sizes as candidate fill tiles
    order = np.argsort(-p)
    tiles = sizes[order[:5]]
    tiles = tiles[tiles > 0].astype(np.float64)
    wt = p[order[:5]]

    res = np.arange(0, 101).astype(np.float64)
    # distance to nearest size (single item) and to nearest integer combo
    d_single = np.min(np.abs(res[:, None] - sizes[None, :]), axis=1)

    # best tiling score: smallest distance to nearest tile-multiple
    best = np.full(101, 1e9)
    for s, w in zip(tiles, wt):
        if s <= 0:
            continue
        k = np.rint(res / s)
        d = np.abs(res - k * s)
        best = np.minimum(best, d)
    # fillability: 1 - normalized distance
    _psize = best / 100.0
    _psize = np.clip(_psize, 0.0, 1.0)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n

    _hist[item] += 1.0
    _n += 1
    if _n % 8 == 1 or _psize is None:
        _rebuild(0)

    residual = bins - item

    r = np.clip(residual, 0, 100).astype(np.int64)
    # fillability cost of the residual (higher = worse)
    cost = _psize[r]
    # prefer tighter fits
    score = -cost - 1e-4 * residual
    return score
# EVOLVE-BLOCK-END
