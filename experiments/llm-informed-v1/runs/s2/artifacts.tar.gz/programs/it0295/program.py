# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus, median-aware residual usefulness, and a
moderate fuller-bin preference. Simple and fast, no noisy histogram kernels."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_mean = 40.0
_min_item = 1.0
_last_build = -1


def _rebuild():
    global _median, _mean, _min_item, _last_build
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    cdf = np.cumsum(_hist[1:101])
    idx = np.searchsorted(cdf, 0.5 * total)
    _median = float(idx + 1)
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _mean = _sum / _n


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    typical = max(min(_median, 100.0), 1.0)
    mean = max(min(_mean, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Exact fill: residual is 0 -> perfect placement, huge bonus.
    exact = (r < 0.5).astype(np.float64)

    # Distance of residual to nearest multiple of a typical item size:
    # rewards residuals that can be tiled well by common item sizes.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    dist = np.minimum(r, dk)

    # Reward residuals that can host a typical/mean future item well
    # (residual close to the mean future item size is "complete-able").
    fit_future = np.abs(r - mean)

    # Sliver / tiny penalty: residual too small to be usefully filled.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Harmonic-style waste fraction: prefer fuller bins.
    used = 100.0 - r
    frac = np.where(used > 0, r / used, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny)
    score = score - 0.05 * fit_future
    score = score - 1.5 * frac
    score = score + 5.0 * exact

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
