# EVOLVE-BLOCK-START
"""Best-fit with a histogram-frequency fillability bonus and sliver penalties."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    exact = (r < 0.5).astype(np.float64)

    # Histogram-frequency reward: residuals equal to a common observed item
    # size are exactly closeable by one future item -> very valuable.
    ri = np.clip(np.rint(r).astype(np.int64), 0, 100)
    freq = _hist[ri] / max(_n, 1)          # probability residual is hittable
    tok = (np.abs(r - ri) < 0.5).astype(np.float64)

    # Distance to nearest multiple of typical fill size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Residuals smaller than a typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Truly unusable slivers below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Reward residuals that exactly match an observed item size, scaled by how
    # common that size is.
    fill_bonus = 6.0 * freq * tok

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact + fill_bonus

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
