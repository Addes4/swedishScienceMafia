# EVOLVE-BLOCK-START
"""Best-fit core with an expected-waste lookahead term.

The proven strong baseline is: place the item so that the resulting residual is
as small as possible (best fit), with a large bonus for exact fills. On top of
this we add a cheap one-step lookahead: for a bin with residual r, estimate the
probability mass of future items that would not fit or would leave a large
leftover, using the empirical histogram. Bins whose residual matches a common
future item size are rewarded, since they are likely to be closed exactly.
"""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0
_pmax = 0.02

# Cached lookup tables (rebuilt periodically, cheap).
_emptab = np.zeros(101, dtype=np.float64)  # P(no future item fits in residual)
_filltab = np.zeros(101, dtype=np.float64) # P(a future item exactly fills residual soon)
_last_build = -1
_dist = None  # normalized histogram over 1..100


def _rebuild():
    global _emptab, _filltab, _median, _min_item, _mean, _pmax, _last_build, _dist
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    dist = _hist[1:101] / total  # dist[i-1] = P(item == i)
    _dist = dist
    cdf = np.cumsum(dist)
    _median = float(np.searchsorted(cdf, 0.5) + 1)
    nz = np.nonzero(dist)[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _mean = _sum / _n
    _pmax = max(float(np.max(dist)), 1e-3)

    # For a residual r (1..100): probability that no item of size <= r exists
    # (i.e. bin becomes unusable), and probability that exactly an item of
    # size r arrives (exact fill) for the *next* item.
    x = np.arange(1, 101, dtype=np.float64)
    for r in range(0, 101):
        if r <= 0:
            continue
        # next-item exact fill prob
        _filltab[r] = dist[r - 1] if r <= 100 else 0.0
        # prob next item is larger than r (cannot use this bin)
        if r >= 100:
            _emptab[r] = 0.0
        else:
            _emptab[r] = float(np.sum(dist[r:]))  # items > r
    _last_build = _n


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _mean, _pmax, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()

    typical = max(min(_median, 100.0), 1.0)
    mean = max(min(_mean, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # >= 0 for shown bins

    # Exact fill: residual 0 -> perfect.
    exact = (r < 0.5).astype(np.float64)

    # Best-fit core: minimize residual, but discourage residuals that are
    # too small to be usefully filled (sliver) or below the min item size.
    sliver = np.where((r > 0) & (r < 0.5 * typical), 0.5 * typical - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Waste fraction (harmonic-style).
    used = 100.0 - r
    frac = np.where(used > 0, r / used, 0.0)

    score = -r - 0.5 * sliver - 0.3 * tiny - 1.0 * frac + 5.0 * exact

    if _n >= 30:
        ri = np.clip(np.rint(r), 0.0, 100.0).astype(np.int64)
        # Reward residuals likely to be exactly closed by an upcoming item
        # (empirical single-item fill probability), softened by proximity.
        pf = _filltab[ri]
        near = np.exp(-((r - ri) ** 2) / (2.0 * 1.5))
        score = score + 10.0 * pf * near

        # Slight penalty for residuals too small for most future items
        # (likely to become permanently unusable / wasted).
        pen = _emptab[ri]
        score = score - 2.0 * pen

    # Tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
