# EVOLVE-BLOCK-START
"""Best-fit plus an empirical one/two-item fillability bonus for residuals."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_freq = np.zeros(101, dtype=np.float64)  # normalized frequency of sizes 1..100


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _hist, _n, _freq

    _hist[item] += 1.0
    _n += 1

    # Update normalized frequency estimate (with light smoothing).
    if _n >= 50:
        total = _hist[1:101].sum()
        if total > 0:
            _freq[1:101] = _hist[1:101] / total
    else:
        _freq[1:101] = 1.0 / 100.0

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Probability a single future item exactly fills the residual.
    p1 = np.zeros_like(r)
    mask1 = (r >= 1.0) & (r <= 100.0)
    ri = np.clip(np.rint(r), 1, 100).astype(np.int64)
    p1[mask1] = _freq[ri[mask1]]

    # Probability some pair (a, b) with a+b == residual fills it.
    # Use the cumulative distribution of sizes: for gap g, integral over a of
    # f(a) * f(g - a) approximated by summing over observed integer sizes.
    p2 = np.zeros_like(r)
    mask2 = (r >= 2.0) & (r <= 200.0)
    f = _freq[1:101]
    cdf = np.cumsum(f)  # cdf[k-1] = P(size <= k)
    g = np.clip(np.rint(r), 2, 200).astype(np.int64)
    gg = g[mask2]
    # Sum over a in 1..gg-1 of f(a)*f(gg-a); vectorized per unique gap.
    uniq = np.unique(gg)
    pair_val = {}
    for gap in uniq:
        hi = min(gap - 1, 100)
        lo = max(1, gap - 100)
        if hi < lo:
            pair_val[gap] = 0.0
            continue
        a = np.arange(lo, hi + 1)
        b = gap - a
        ok = (b >= 1) & (b <= 100)
        pair_val[gap] = float(np.sum(f[a[ok] - 1] * f[b[ok] - 1]))
    for i, gap in enumerate(gg):
        pass
    # Vectorized mapping via searchsorted on sorted unique gaps.
    sorted_u = np.sort(np.array(list(pair_val.keys()), dtype=np.int64))
    vals = np.array([pair_val[k] for k in sorted_u], dtype=np.float64)
    if sorted_u.size > 0:
        pos = np.searchsorted(sorted_u, gg)
        p2[mask2] = vals[pos]

    exact = (r < 0.5).astype(np.float64)

    # Reward likely-fillable residuals; dominant term is best-fit (-r).
    fill = np.maximum(p1, 1.5 * p2)

    score = -r + 4.0 * exact + 12.0 * fill
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

