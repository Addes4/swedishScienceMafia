# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus and a reserve for large-item bins."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_big = 70.0          # empirical threshold above which items count as "large"
_frac_big = 0.0      # observed fraction of large items


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _big, _frac_big

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        # Empirical threshold for "large" items: 80th percentile.
        b_idx = np.searchsorted(cdf, 0.80 * total)
        _big = float(b_idx + 1)
        # Fraction of mass above the big threshold.
        mass_big = total - cdf[min(int(_big) - 1, 99)] if _big >= 1 else 0.0
        _frac_big = mass_big / total if total > 0 else 0.0

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Distance to nearest multiple of typical fill size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    dist = np.minimum(r, dk)

    # Residuals smaller than a typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Truly unusable slivers below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Reserve large-capacity bins: penalize a placement that drops the bin
    # below the large-item threshold, scaled by how common large items are.
    big = _big
    cross = np.where((r > 0) & (r < big - item * 0.0) & (r < big), big - r, 0.0)
    # extra weight so large items still have somewhere to go
    reserve = cross * (2.0 * _frac_big)

    score = -(dist + 0.75 * sliver + 0.5 * tiny + reserve) + 5.0 * exact

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
