# EVOLVE-BLOCK-START
"""Best-fit backbone with a gentle exact-fill bonus weighted by empirical
item-frequency, plus a small sliver/unusable-residual penalty."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)   # counts of item sizes 1..100
_n = 0
_total_items = 0
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _total_items, _median, _min_item

    if _n == 0:
        # len(bins) on the very first call equals number of items in instance.
        _total_items = len(bins)

    _hist[item] += 1.0
    _n += 1

    if _n >= 40:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        if total > 0:
            idx = np.searchsorted(cdf, 0.5 * total)
            _median = float(idx + 1)
            nz = np.nonzero(_hist[1:101])[0]
            if nz.size > 0:
                _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Probability mass function estimate per residual value (1..100).
    total_cnt = _hist[1:101].sum()
    if total_cnt > 0:
        p_hist = _hist[1:101] / total_cnt
    else:
        p_hist = np.zeros(100, dtype=np.float64)

    # Exact-fit bonus.
    exact = (r < 0.5).astype(np.float64)

    # Bonus for leaving a residual that equals a *frequently occurring* item
    # size: such residuals are likely to be exactly filled by a future item.
    ri = np.clip(np.rint(r).astype(np.int64), 1, 100)
    p_match = p_hist[ri - 1]

    # Distance to nearest multiple of typical fill size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    dist = np.minimum(r, dk)

    # Residuals below the smallest item seen can never be used -> penalize.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(dist + 0.5 * tiny) + 5.0 * exact + 2.0 * p_match

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

