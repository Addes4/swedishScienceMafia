# EVOLVE-BLOCK-START
"""Best-fit backbone with a mild fillability bonus on the residual."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Core: best-fit (prefer the smallest usable leftover).
    score = -r

    # Reward residuals that a typical future item can exactly fill.
    score += 0.5 * (np.abs(r - typical) < 0.5).astype(np.float64)

    # Penalize residuals below the smallest item ever seen (truly unusable).
    score -= 1.0 * np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Small bonus for exact fits.
    score += 2.0 * (r < 0.5).astype(np.float64)

    return score
# EVOLVE-BLOCK-END
