# EVOLVE-BLOCK-START
"""Best-fit with exact-fit dominance, fillability bonus, and sliver penalty.

The score is dominated by a best-fit backbone (prefer small residual), then
sharpened so that residuals which a real future item (or a pair of items) can
fill exactly are preferred, and unusable slivers below the empirical minimum
item size are avoided.
"""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_pseen = np.zeros(101, dtype=np.float64)  # seen item sizes (mass)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0
    _pseen[item] = 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # --- best-fit backbone -------------------------------------------------
    # Primary: smallest residual wins. Scale so subsequent bonuses nudge.
    score = -r

    # --- exact fit dominance ----------------------------------------------
    exact = (r < 0.5).astype(np.float64)
    score = score + 3.0 * exact

    # --- fillability: residual equals a previously seen item size ----------
    seen_gap = np.zeros_like(r)
    mask = (r >= 1.0) & (r <= 100.0)
    if np.any(mask):
        idxs = np.rint(r[mask]).astype(np.int64)
        idxs = np.clip(idxs, 1, 100)
        hit = _pseen[idxs]
        # close fit: |r - round(r)| tiny and that size was seen
        dclose = np.abs(r[mask] - idxs)
        seen_gap[mask] = hit * np.where(dclose < 0.5, 1.0, 0.0)
    score = score + 1.2 * seen_gap

    # --- fillability: residual is a small sum of two typical items ---------
    # Reward residuals near k*typical for small integer k (1..3).
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    # only count k in [1,3] as genuinely likely-fillable
    valid_k = ((k >= 1) & (k <= 3)).astype(np.float64)
    fill = valid_k * np.where(dk < 0.5 * t, (0.5 * t - dk) / t, 0.0)
    score = score + 0.6 * fill

    # --- sliver penalty ----------------------------------------------------
    # Positive residuals below the smallest item seen are unusable.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)
    score = score - 0.8 * tiny

    # --- gentle tie-break toward fuller placements -------------------------
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
