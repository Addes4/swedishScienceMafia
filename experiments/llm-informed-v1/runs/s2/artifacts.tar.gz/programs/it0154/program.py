# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus and empirical pair-completion reward."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_min_item = 1.0
_frac = np.zeros(101, dtype=np.float64)  # running normalized histogram


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _min_item, _frac

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        total = _hist[1:101].sum()
        if total > 0:
            _frac[1:101] = _hist[1:101] / total
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    r = bins.astype(np.float64) - item  # residual >= 0 for shown bins

    # Pure best-fit backbone: prefer smallest usable residual.
    score = -r

    # Strong exact-fit reward.
    exact = (r < 0.5).astype(np.float64)
    score = score + 5.0 * exact

    # Pair-completion reward: residual r can be exactly filled by a future
    # item of size r, whose empirical probability is _frac[r].
    ri = np.clip(np.rint(r).astype(np.int64), 0, 100)
    pair = _frac[ri]
    score = score + 8.0 * pair

    # Penalize residuals below the smallest item seen (unusable slivers).
    tiny = np.where((r > 0) & (r < _min_item), (_min_item - r), 0.0)
    score = score - 0.5 * tiny

    return score
# EVOLVE-BLOCK-END
