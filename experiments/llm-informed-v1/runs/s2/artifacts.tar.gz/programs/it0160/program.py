# EVOLVE-BLOCK-START
"""Best-fit backbone with calibrated sliver penalties from empirical support."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        # Empirical minimum item size.
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        # Median used as a rough scale.
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strong reward for exact fits (bin closed perfectly).
    exact = (r < 0.5).astype(np.float64)

    # Unusable slivers: positive residual below the smallest observed item.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Mild penalty for residuals too small relative to typical item size.
    sliver = np.where((r > 0) & (r < 0.5 * typical), 0.5 * typical - r, 0.0)

    # Best-fit backbone: prefer smallest usable residual.
    score = -r - 0.75 * sliver - 0.5 * tiny + 5.0 * exact

    # Tiny tie-break to keep behavior deterministic and stable.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
