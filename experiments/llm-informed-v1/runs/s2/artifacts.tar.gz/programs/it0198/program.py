# EVOLVE-BLOCK-START
"""Best-fit backbone with a reuse-value tie-break based on residual fillability."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_typical = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _typical, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        # Empirical mean of observed items as a robustness anchor.
        mean = _sum / _n
        _typical = max(min(mean, 100.0), 1.0)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    t = _typical
    r = bins.astype(np.float64) - item  # residual (>=0 for shown bins)

    # Dominant: reward exact fits heavily.
    exact = (r < 0.5).astype(np.float64)

    # Value of the leftover gap: a residual that is close to a typical item
    # size is likely reusable; a residual far from any typical size (or tiny)
    # is waste. Use distance to nearest multiple of typical.
    k = np.rint(r / t)
    dist_mult = np.abs(r - k * t)
    dist_zero = r
    dist = np.minimum(dist_mult, dist_zero)

    # Penalize unusable slivers (positive residual below the smallest item).
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(dist + 0.6 * tiny) + 6.0 * exact - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

