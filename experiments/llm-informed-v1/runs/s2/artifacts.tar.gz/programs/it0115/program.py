# EVOLVE-BLOCK-START
"""Best-fit with a distribution-based expected-leftover-waste penalty.

For each candidate residual r (capacity left after placing the item), we estimate
how much space will likely remain permanently unusable in that bin, using the
empirical item-size distribution observed so far. Bins whose residual can be
filled more completely by future items receive a smaller penalty.
"""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
# Cached lookup table: for residual 0..100, expected leftover waste.
_waste_table = np.zeros(101, dtype=np.float64)
_waste_cache_key = None


def _rebuild_waste_table():
    """Compute expected unfillable leftover for each residual 0..100.

    Model: the remaining space in a bin is a knapsack we will try to fill with
    future items. As a tractable proxy, we compute the expected leftover of a
    greedy fill using the empirical size distribution: repeatedly, the leftover
    is reduced by the largest item size <= leftover weighted by its probability;
    the expected fractional remainder is accumulated as waste.
    """
    hist = _hist[1:101]
    total = hist.sum()
    if total <= 0:
        _waste_table[:] = 0.0
        return
    probs = hist / total
    sizes = np.arange(1, 101)
    # Expected waste for each residual via a simple recursion using the mean
    # size to advance. We approximate: leftover L -> expected next draw m,
    # if m <= L we'd pack it; we advance by expected usable fill fraction.
    table = np.zeros(101, dtype=np.float64)
    mean_size = float((sizes * probs).sum())
    # fraction of mass at or below each L
    cdf = np.cumsum(probs)  # cdf[i] = P(size <= i+1)
    for L in range(0, 101):
        if L == 0:
            table[L] = 0.0
            continue
        # probability an arriving item fits in L
        pfit = cdf[L - 1] if L - 1 < 100 else 1.0
        if pfit <= 0:
            table[L] = float(L)
            continue
        # conditional mean size given it fits
        mass = probs[:L]
        cond_mean = float((sizes[:L] * mass).sum() / mass.sum())
        # Expected usable fill per "fitting" event; iterate the recursion a
        # bounded number of steps to estimate cumulative expected waste.
        rem = float(L)
        waste = 0.0
        for _ in range(200):
            if rem < 1.0:
                break
            pf = cdf[int(rem) - 1] if int(rem) - 1 < 100 else 1.0
            if pf <= 0:
                waste += rem
                break
            cmass = probs[:int(rem)]
            cmean = float((sizes[:int(rem)] * cmass).sum() / cmass.sum())
            # apply one expected packing step
            step = pf * cmean
            if step < 1e-9:
                waste += rem
                break
            rem -= step
        if rem > 0:
            waste += rem
        table[L] = waste
    _waste_table[:] = table


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _waste_cache_key

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    # Rebuild waste table occasionally (cheap, every 25 items).
    if _n < 30:
        key = 0
    else:
        key = _n // 25
    if key != _waste_cache_key and _n >= 30:
        _rebuild_waste_table()
        _waste_cache_key = key

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    ri = np.clip(residual.astype(np.int64), 0, 100)

    exact = (residual < 0.5).astype(np.float64)

    # Expected leftover waste after choosing this bin.
    waste = _waste_table[ri]

    # Penalize expected waste; reward exact fits strongly.
    score = -waste + 5.0 * exact
    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * residual

    return score
# EVOLVE-BLOCK-END

