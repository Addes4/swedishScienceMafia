# EVOLVE-BLOCK-START
"""Best fit with reserved empty bins for large items."""
import numpy as np

_state = {"n": None}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    if _state["n"] is None:
        _state["n"] = len(bins)
    # Base: best fit -> higher score for smaller remaining capacity (tighter fit)
    score = -(bins - item).astype(np.float64)
    # If the item is large, avoid opening a fresh bin when a used bin fits.
    if item >= 50:
        is_empty = bins == 100
        if np.any(~is_empty):
            score = np.where(is_empty, score - 1000.0, score)
    return score
# EVOLVE-BLOCK-END

