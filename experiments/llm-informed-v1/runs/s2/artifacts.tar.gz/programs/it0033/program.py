# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus keyed to the empirical median item size,
plus a phase-aware large-residual penalty that tightens fits near the end."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_total_items = 0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _total_items

    if _total_items == 0 and len(bins) > 0:
        # On the first call every bin is unused, so len(bins) == #items.
        _total_items = len(bins)

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        # Smallest observed item size so far (empirical minimum).
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Distance to nearest multiple of typical fill size: gaps that can be
    # filled later by typical items get a bonus.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Residuals smaller than a typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Phase-aware tightening: near the end, large leftover gaps are unlikely
    # to be filled, so prefer tighter fits more strongly.
    if _total_items > 0:
        remain_frac = max(0.0, 1.0 - _n / float(_total_items))
    else:
        remain_frac = 1.0
    # Grows from 0 early to ~1 near the end.
    phase = 1.0 - remain_frac
    phase = phase * phase  # emphasize the late phase
    big = np.maximum(0.0, r - t)  # leftover beyond one typical item

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact

    # Tightening term: penalize big residuals, scaled by lateness.
    score = score - (0.3 + 1.5 * phase) * big * 0.01

    # Tie-break toward fuller placements (smaller residual).
    score = score - (1e-3 + 1e-2 * phase) * r

    return score
# EVOLVE-BLOCK-END

