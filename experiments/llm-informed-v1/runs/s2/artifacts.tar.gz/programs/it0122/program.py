# EVOLVE-BLOCK-START
"""Best-fit with light usable-residual shaping keyed to the empirical minimum item."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _median, _min_item

    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Backbone: best-fit = smallest usable residual first.
    score = -r

    # Reward exact fits modestly (don't dominate best-fit ordering much).
    exact = (r < 0.5).astype(np.float64)
    score = score + 1.5 * exact

    # Light penalty for creating truly unusable slivers (below min item seen).
    tiny = np.where((r > 0) & (r < _min_item), (_min_item - r), 0.0)
    score = score - 0.4 * tiny

    # Very small tie-break toward leaving at least a median-usable gap.
    med = max(min(_median, 100.0), 1.0)
    usable = (r >= med).astype(np.float64)
    score = score + 0.01 * usable

    return score
# EVOLVE-BLOCK-END

