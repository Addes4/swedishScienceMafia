# EVOLVE-BLOCK-START
"""Best-fit with exact-fit reward and a data-driven closeable-residual bonus."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_q10 = 20.0
_targets = np.array([1.0], dtype=np.float64)
_next_refresh = 0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _q10, _targets, _next_refresh

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and _n >= _next_refresh:
        _next_refresh = _n + 50
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        idx10 = np.searchsorted(cdf, 0.10 * total)
        _q10 = float(idx10 + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        # Most frequent item sizes seen so far become "closeable" targets.
        cnts = _hist[1:101]
        order = np.argsort(-cnts)
        top = order[:8]
        top = top[cnts[top] > 0]
        _targets = (top + 1).astype(np.float64)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Reward exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Distance from residual to the nearest frequent item size (closeable gap).
    if _targets.size > 0:
        diff = np.abs(r[:, None] - _targets[None, :])
        dist_t = diff.min(axis=1)
    else:
        dist_t = r

    # Penalize residuals that are too small to ever be filled.
    sliver = np.where((r > 0) & (r < _q10), _q10 - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(0.5 * dist_t + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact
    # Best-fit tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

