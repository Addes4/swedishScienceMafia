# EVOLVE-BLOCK-START
"""Best-fit + exact-fit + empirical future-fill reward."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
# Cached fill-reward lookup table indexed by residual (integer 0..100).
_fillw = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _fillw

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

        # Fill reward: probability that a residual of size g can be exactly
        # matched by a (smoothed) frequent future item size.
        w = _hist[1:101] / total  # empirical pmf over sizes 1..100
        # Smooth over +/-1 to be less brittle.
        ws = np.copy(w)
        ws[1:] += 0.5 * w[:-1]
        ws[:-1] += 0.5 * w[1:]
        # fillw[g] for g in 0..100; index 100 handled below.
        table = np.ones(101, dtype=np.float64)
        table[1:101] = ws
        table[0] = 0.0
        _fillw = table

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual
    ri = np.rint(r).astype(np.int64)
    ri = np.clip(ri, 0, 100)

    # Strongly reward exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Primary: best-fit (small residual preferred).
    score = -r

    # Reward residuals that a future frequent item can exactly fill.
    score = score + 30.0 * _fillw[ri]

    # Truly unusable slivers: positive residual below smallest item seen.
    tiny = np.where((r > 0.5) & (r < _min_item), _min_item - r, 0.0)

    score = score - 0.5 * tiny + 5.0 * exact - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
