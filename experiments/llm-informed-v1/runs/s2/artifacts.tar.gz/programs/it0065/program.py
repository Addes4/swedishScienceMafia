# EVOLVE-BLOCK-START
"""Best-fit driven by an empirical expected-waste estimate of the residual.

We track the empirical distribution of item sizes seen so far.  For a candidate
residual r (>= 0) we estimate the expected capacity that will be "wasted" if we
leave r in a bin, using the current item-size distribution.  The item goes into
the bin whose resulting residual has the smallest expected waste, with a strong
bonus for exact fits (zero-waste placements).
"""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)   # counts of item sizes 1..100
_n = 0
_mean = 40.0
_min_item = 1.0

# Cached distribution quantities.
_probs = np.zeros(101, dtype=np.float64)   # prob of size i (index i)
_cum = np.zeros(101, dtype=np.float64)     # cdf up to i
_ready = False


def _refresh():
    global _mean, _min_item, _probs, _cum, _ready
    total = _hist[1:101].sum()
    if total <= 0:
        return
    _probs[1:101] = _hist[1:101] / total
    _cum[1:101] = np.cumsum(_probs[1:101])
    _mean = float((np.arange(1, 101) * _probs[1:101]).sum())
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _ready = True


def _expected_waste(r):
    """Estimate waste left in a bin with residual r, given current distribution.

    We take a one-step lookahead: over the observed item sizes, the best
    immediate use of the gap, then value the leftover heuristically.
    Returned per-bin score should be *higher* for better bins.
    """
    if r <= 0.0:
        return 0.0  # exact fit: no waste

    # Best single fill of this gap: the largest item size <= r gives the
    # least immediate leftover.  Weighted by how likely that size is.
    # Use the empirical distribution over sizes <= r.
    lo = _min_item
    # Fast path: no size fits => entire residual is waste.
    if r < lo:
        return -r

    # Find probability mass of sizes that can make progress and approximate
    # expected leftover after the best greedy fill.
    int_r = int(r)
    if int_r > 100:
        int_r = 100
    # probability that some item fits in the gap
    p_fit = _cum[int_r] if int_r >= 1 else 0.0
    # expected leftover after placing a fitting item: weighted by prob of sizes
    # (unfilled gap persists if no item fits; then it likely stays wasted).
    save = 0.0
    if p_fit > 1e-12:
        sizes = np.arange(1, int_r + 1)
        w = _probs[1:int_r + 1]
        # leftover if we drop a size-i item into gap r
        leftover = r - sizes
        # recurse one more level: approximate value of leftover by -leftover
        # scaled by how fillable it is; keep it shallow for speed.
        save = float((w * leftover).sum()) / p_fit  # avg leftover if fit
    # Expected residual waste: with prob (1-p_fit) the whole gap is wasted,
    # with prob p_fit an average leftover save remains.
    return -(1.0 - p_fit) * r - p_fit * save


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _hist, _n

    _hist[item] += 1.0
    _n += 1
    if _n >= 20:
        _refresh()

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Vectorized expected-waste scoring.
    r = residual
    exact = r < 0.5

    # Expected-waste estimate (vector form matching _expected_waste).
    int_r = np.clip(r.astype(np.int64), 0, 100)
    p_fit = np.where(int_r >= 1, _cum[int_r], 0.0)
    p_fit = np.where(exact, 1.0, p_fit)

    # avg leftover after a fitting item (only where p_fit > 0)
    sizes = np.arange(1, 101, dtype=np.float64)
    # weight leftover by prob of each size for each r -- do it per distinct r
    # to keep it cheap; group by integer residual.
    avg_leftover = np.zeros_like(r)
    if _ready:
        uniq = np.unique(int_r)
        for u in uniq:
            if u < 1:
                continue
            w = _probs[1:u + 1]
            s = sizes[:u]
            tot = w.sum()
            if tot > 1e-12:
                avg_leftover[int_r == u] = float((w * (u - s)).sum() / tot)
            else:
                avg_leftover[int_r == u] = 0.0

    score = -(1.0 - p_fit) * r - p_fit * avg_leftover
    score = np.where(exact, 0.0, score)

    # Strong preference for exact fits, then for smaller residual.
    score = score + 5.0 * exact.astype(np.float64)
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
