# EVOLVE-BLOCK-START
"""Best-fit with exact-fit reward and empirical residual-match bonus."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_probs = np.zeros(101, dtype=np.float64)
_update_every = 25


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _probs

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n % _update_every == 0 or _probs.sum() == 0.0):
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        # Empirical item-size probabilities (normalized).
        tot = _hist[1:101].sum()
        if tot > 0:
            _probs = _hist[1:101] / tot
        else:
            _probs = np.zeros(100, dtype=np.float64)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Distance to nearest multiple of typical fill size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Residual-match bonus: how probable is it that a future item exactly
    # fills this residual? Look up the empirical probability of size ~r.
    ri = np.rint(r).astype(np.int64)
    ri = np.clip(ri, 1, 100)
    match = _probs[ri - 1] if _probs.sum() > 0 else np.zeros_like(r)

    # Penalties for unusable slivers.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = (-(dist + 0.75 * sliver + 0.5 * tiny)
             + 5.0 * exact
             + 40.0 * match)

    # Tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
