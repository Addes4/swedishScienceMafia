# EVOLVE-BLOCK-START
"""Residual-value best fit using the empirical item distribution."""
import numpy as np

_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _sum, _n

    _sum += item
    _n += 1
    _hist[item] += 1.0
    mean = _sum / _n

    # Empirical CDF of observed item sizes.
    counts = _hist[1:101]
    total = counts.sum()
    if total > 0:
        cdf = np.cumsum(counts) / total  # cdf[k-1] = P(size <= k)
    else:
        cdf = np.linspace(0.0, 1.0, 100)

    residual = bins.astype(np.float64) - item  # >= 0 for shown bins
    r = residual

    # Expected number of future items that fit in residual r: approximate
    # by summing P(an item fits) over a horizon proportional to remaining slots,
    # but here we just use the expected remaining capacity fraction.
    # Build a per-residual "value" via the empirical survival function.
    # Value(r) = integral_0^r S(x) dx  ~ expected usable size fraction.
    idx = np.clip(np.rint(r).astype(int), 0, 100)
    surv = 1.0 - cdf  # S(k) = P(size > k)
    # prefix cumulative of survival: E[usable] approximated as area under S
    # precompute once per call (100 entries, cheap)
    area = np.concatenate(([0.0], np.cumsum(surv)))

    # Expected number of items that can be packed in r: r / mean is a rough cap,
    # but reward residuals that are likely fillable and small.
    # Score = (value of residual) - penalty for large leftover.
    val = area[idx]
    # normalize by mean so scale-invariant-ish
    norm = max(mean, 1.0)

    # Prefer placing so leftover is small (best fit) but not unusable:
    # reward expected fillability, penalize raw leftover to encourage packing.
    score = val / norm - 1.5 * r / 100.0

    # Strong bonus for exact fits.
    exact = (r < 0.5).astype(np.float64)
    score = score + 5.0 * exact

    # Tie-break toward fuller bins.
    score = score - 1e-4 * r

    return score
# EVOLVE-BLOCK-END
