# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus keyed to high-mass empirical fill points."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_targets = None  # cached array of fill-point targets


def _recompute_targets():
    """Pick candidate residual targets: the highest-mass item sizes."""
    global _targets
    total = _hist[1:101].sum()
    if total < 30:
        _targets = None
        return
    # top item sizes by probability mass
    sizes = np.nonzero(_hist[1:101])[0] + 1
    masses = _hist[1:101][sizes - 1]
    order = np.argsort(-masses)
    chosen = []
    for i in order[:6]:
        chosen.append(float(sizes[i]))
    # also include a couple of useful two-item sums from the most common sizes
    if len(sizes) > 0:
        s1 = float(sizes[order[0]])
        s2 = float(sizes[order[min(1, len(order) - 1)]])
        for cand in (s1 + s2, 2.0 * s1):
            if cand <= 100.0:
                chosen.append(cand)
    _targets = np.array(chosen, dtype=np.float64) if chosen else None


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _targets is None or _n % 25 == 0:
        _recompute_targets()

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Distance to the nearest candidate fill point (a gap likely fillable
    # by a future item). Also compare to leaving the residual empty (r==0).
    if _targets is not None and _targets.size > 0:
        # broadcast: r[:,None] - targets[None,:]
        diff = np.abs(r[:, None] - _targets[None, :])
        dist = diff.min(axis=1)
    else:
        t = 40.0
        k = np.rint(r / t)
        dist = np.minimum(r, np.abs(r - k * t))

    # Residuals far from any usable target are penalized more when small.
    score = -dist + 5.0 * exact

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
