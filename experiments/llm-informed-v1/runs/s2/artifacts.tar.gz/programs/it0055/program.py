# EVOLVE-BLOCK-START
"""Best-fit backbone with gentle sliver penalty and mild exact-fit tie-break."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Best-fit backbone: prefer smaller residuals (dominant term).
    score = -r

    # Penalize residuals that are uselessly small: positive residual below the
    # smallest item we've seen can basically never be filled.
    tiny = np.where((r > 0) & (r < _min_item), (_min_item - r), 0.0)

    # Penalize residuals smaller than a typical item (poor future fillability).
    sliver = np.where((r > 0) & (r < 0.5 * typical), (0.5 * typical - r), 0.0)

    # Mild preference for residuals close to being exactly fillable by a
    # typical item (gap ~ k * typical).
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    fill_bonus = np.where(r > 0, np.maximum(0.0, t - dk), 0.0)

    # Exact fits are good but only a mild nudge, not overriding best-fit.
    exact = (r < 0.5).astype(np.float64)

    score = score - 0.35 * tiny - 0.20 * sliver + 0.02 * fill_bonus + 0.5 * exact

    return score
# EVOLVE-BLOCK-END
