# EVOLVE-BLOCK-START
"""Best-fit with a light mean-based fillability tie-break."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_mean = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _mean, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 20:
        _mean = _sum / _n
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_mean, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # residual after placing

    # Best-fit backbone: smaller residual is better.
    score = -r

    # Bonus for residuals that are multiples of the typical item size
    # (can likely be filled later without leaving waste).
    k = np.rint(r / typical)
    dist = np.abs(r - k * typical)
    score -= 0.5 * dist

    # Penalize unusable slivers (positive residual below smallest item).
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)
    score -= 0.5 * tiny

    # Reward exact fits.
    exact = (r < 0.5).astype(np.float64)
    score += 2.0 * exact

    return score
# EVOLVE-BLOCK-END
