# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus keyed to the empirical median item size,
plus an empirical exact-fill probability bump."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_pmf = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _pmf

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        _pmf = _hist / total

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    exact = (r < 0.5).astype(np.float64)

    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact

    # Exact-fill probability bump: residual matching a frequent item size
    # is likely to be closed by a single future item.
    if _n >= 30:
        ri = np.clip(np.rint(r).astype(np.int64), 0, 100)
        p_exact = _pmf[ri]
        # Residuals that can still accept the smallest item are safe.
        usable = (r + 0.5 >= _min_item).astype(np.float64)
        score = score + 2.0 * p_exact + 0.3 * usable

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
