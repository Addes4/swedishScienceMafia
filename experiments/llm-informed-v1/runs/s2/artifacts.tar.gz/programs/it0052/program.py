# EVOLVE-BLOCK-START
"""Best-fit backbone with exact-fit and reachable-gap bonuses."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_seen = np.zeros(101, dtype=bool)
_min_item = 100.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _min_item

    _n += 1
    _hist[item] += 1.0
    _seen[item] = True
    if item < _min_item:
        _min_item = float(item)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    r = residual

    # Pure best-fit backbone: prefer smaller residual (fuller bin).
    score = -r

    # Reward exact fits strongly.
    exact = (r < 0.5).astype(np.float64)

    # Reward residuals equal to a previously seen item size (a future item may
    # close this gap exactly), but only mildly so it does not dominate best-fit.
    reachable = np.zeros_like(r)
    rf = np.floor(r + 0.5)
    mask = (np.abs(r - rf) < 0.5) & (rf >= 1) & (rf <= 100)
    ri = rf.astype(np.int64)
    reachable = np.where(mask, _seen[np.clip(ri, 0, 100)].astype(np.float64), 0.0)

    # Penalize unusable slivers below the smallest item seen.
    sliver = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = score + 2.0 * exact + 0.3 * reachable - 0.6 * sliver

    return score
# EVOLVE-BLOCK-END

