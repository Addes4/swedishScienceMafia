# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus, exact-fit reward, and a smooth
histogram-based completion reward for residuals likely to be filled soon.
Uses a periodically rebuilt smoothed frequency table to stay fast."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0
_pmax = 0.02  # max single-size probability estimate
_q25 = 25.0
_q75 = 55.0

# Cached lookup tables (rebuilt periodically, cheap).
_smooth_tab = np.zeros(101, dtype=np.float64)  # smoothed completion prob per integer size
_last_build = -1


def _rebuild():
    global _smooth_tab, _median, _min_item, _mean, _pmax, _q25, _q75
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    cdf = np.cumsum(_hist[1:101])
    idx = np.searchsorted(cdf, 0.5 * total)
    _median = float(idx + 1)
    i25 = np.searchsorted(cdf, 0.25 * total)
    i75 = np.searchsorted(cdf, 0.75 * total)
    _q25 = float(i25 + 1)
    _q75 = float(i75 + 1)
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _mean = _sum / _n
    _pmax = max(float(np.max(_hist[1:101]) / total), 1e-3)

    freq = _hist / total
    # Smooth the frequency over a small window so nearby residuals share credit.
    x = np.arange(101, dtype=np.float64)
    width = 3.0
    kernel = np.exp(-0.5 * (np.arange(-8, 9, dtype=np.float64) / width) ** 2)
    kernel /= np.sum(kernel)
    sm = np.convolve(freq, kernel, mode="same")
    _smooth_tab[:] = sm


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    typical = max(min(_median, 100.0), 1.0)
    mean = max(min(_mean, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Exact fill: residual is 0 -> perfect, huge bonus.
    exact = (r < 0.5).astype(np.float64)

    # Reward residuals that can host a typical (median/mean) future item well.
    fit_future = np.abs(r - mean)

    # Sliver penalty: too small to be usefully filled.
    sliver = np.where((r > 0) & (r < 0.5 * typical), 0.5 * typical - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Harmonic-style waste fraction term.
    used = 100.0 - r
    frac = np.where(used > 0, r / used, 0.0)

    # Base score: prefer filling bins well, penalize useless slivers.
    score = -(0.5 * r + 1.0 * sliver + 0.5 * tiny) + 5.0 * exact
    score = score - 0.05 * fit_future
    score = score - 1.0 * frac

    # Smooth histogram-based completion reward: residual near a common item
    # size is likelier to be completed exactly by a future item.
    if _n >= 30:
        ri = np.clip(np.rint(r), 0.0, 100.0).astype(np.int64)
        score = score + 15.0 * _smooth_tab[ri]

    # Exact fits get extra weight proportional to how likely that item is.
    score = score + 20.0 * _pmax * exact

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
