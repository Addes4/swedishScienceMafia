# EVOLVE-BLOCK-START
"""Gap-aware best fit.

Score bins by the remaining capacity after placing the item (best fit), but add a
small bonus when the resulting residual capacity is close to a typical item size
observed so far. This encourages leaving gaps that future items can fill exactly,
rather than an assortment of odd-sized residues.
"""
import numpy as np

_state = {
    "sum": 0.0,
    "count": 0,
    "seen": 0,
    "total": 0,
}


def priority(item, bins):
    st = _state
    if len(bins) != st["total"]:
        st["total"] = len(bins)
    st["seen"] += 1
    st["sum"] += item
    st["count"] += 1
    mean = st["sum"] / st["count"]
    # typical residual we'd like to leave for future items
    target = mean

    resid = bins - item  # remaining capacity after placing (>= 0 since item fits)

    # Base: best fit -> prefer smallest residual (negative resid, smaller is better)
    score = -resid.astype(np.float64)

    # Bonus for residuals close to a typical item size (helps future exact fits)
    closeness = np.abs(resid - target)
    score += 1.5 * (1.0 / (1.0 + closeness))

    # Slight bonus for exact fits (residual 0)
    score += 0.75 * (resid == 0).astype(np.float64)

    return score
# EVOLVE-BLOCK-END
