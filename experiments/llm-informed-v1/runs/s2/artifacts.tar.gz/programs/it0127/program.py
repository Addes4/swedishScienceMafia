# EVOLVE-BLOCK-START
"""Best-fit with smoothed empirical fillability bonus for zero/small residuals."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_smoothed = np.zeros(101, dtype=np.float64)
_ready = False


def _update_smoothed():
    global _smoothed, _ready
    # Simple 3-tap smoothing over the histogram; cheap and stable.
    h = _hist
    s = h.copy()
    s[1:100] += 0.5 * (h[0:99] + h[2:101])
    _smoothed = s
    _ready = True


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n

    _n += 1
    _hist[item] += 1.0
    if _n % 25 == 0 or not _ready:
        _update_smoothed()

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    freq = _smoothed
    total = freq[1:101].sum() or 1.0

    # Probability that some future item exactly matches residual r (>=1).
    ri = np.clip(np.rint(r).astype(np.int64), 0, 100)
    p_match = freq[ri] / total
    p_match = np.where(r < 0.5, 0.0, p_match)

    # Exact fits: strong bonus.
    exact = (r < 0.5).astype(np.float64)

    # Sliver penalty for tiny positive residuals unlikely to be filled.
    sliver = np.where((r > 0) & (r < 10.0), (10.0 - r) / 10.0, 0.0)

    score = -(r) - 8.0 * sliver + 20.0 * p_match + 6.0 * exact

    return score
# EVOLVE-BLOCK-END

