# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus keyed to the empirical mode item size."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_mode = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _mode, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        # Empirical mode over a small window of sizes for robustness.
        h = _hist[1:101]
        best = 0.0
        mstart = 40
        for s in range(1, 101):
            w = h[max(0, s - 1 - 1):s + 2]  # s-1 .. s+1 (size window)
            pass
        # Compute a smoothed mode: for each size, count of items within +-1.
        cs = np.concatenate(([0.0], np.cumsum(h)))
        # counts in window [s-1, s+1]
        lo = np.maximum(np.arange(1, 101) - 2, 0)
        hi = np.minimum(np.arange(1, 101) + 1, 100)
        window_counts = np.array([cs[hi[i]] - cs[lo[i]] for i in range(100)])
        k = int(np.argmax(window_counts))
        _mode = float(k + 1)
        nz = np.nonzero(h)[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_mode, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Reward residuals close to a multiple of the mode (gaps fillable later).
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    dist = np.minimum(r, dk)

    # Residuals smaller than a typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
