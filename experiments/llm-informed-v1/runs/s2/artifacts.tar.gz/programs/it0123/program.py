# EVOLVE-BLOCK-START
"""Best-fit that avoids leaving unusable slivers below the smallest item seen."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _min_item

    _n += 1
    _hist[item] += 1.0

    if _n >= 20:
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits (no waste).
    exact = (r < 0.5).astype(np.float64)

    # Penalize positive residuals that are below the smallest item seen:
    # such gaps likely can never be refilled.
    unusable = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Base rule: best-fit (smaller residual is better).
    score = -r

    # Big penalty for creating unusable slivers, tiered so usable > exact > sliver.
    score = score - 200.0 * unusable

    # Exact fits beat usable-but-not-exact placements.
    score = score + 100.0 * exact

    return score
# EVOLVE-BLOCK-END
