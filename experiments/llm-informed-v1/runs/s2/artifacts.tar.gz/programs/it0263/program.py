# EVOLVE-BLOCK-START
"""Best-fit core with an empirical exact-fill bonus.

Key idea: minimize the residual (best-fit is a strong, robust online rule),
but reward residuals that equal a frequently observed item size, since future
items are drawn from the same distribution and will often close such a bin
exactly. A periodic lookup table keeps it fast.
"""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0
_pmax = 0.02

# Cached table: smoothed probability that a future item equals integer size r.
_pfreq_tab = np.zeros(101, dtype=np.float64)
_last_build = -1


def _rebuild():
    global _pfreq_tab, _median, _min_item, _mean, _pmax
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    cdf = np.cumsum(_hist[1:101])
    idx = np.searchsorted(cdf, 0.5 * total)
    _median = float(idx + 1)
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _mean = _sum / _n
    _pmax = max(float(np.max(_hist[1:101]) / total), 1e-3)

    # Smoothed frequency: add small prior so unseen sizes get tiny weight.
    p = (_hist + 0.5) / (total + 0.5 * 101.0)
    _pfreq_tab[:] = p


def priority(item, bins):
    global _sum, _n, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    residual = bins.astype(np.float64) - item
    r = residual

    t = max(min(_median, 100.0), 1.0)

    # Strong best-fit core: smaller residual is better.
    score = -r

    # Exact fill bonus.
    exact = (r < 0.5).astype(np.float64)
    score = score + 30.0 * exact

    # Empirical exact-fill reward: residual equal or near a common item size
    # is likely to be closed exactly by a future item.
    if _n >= 30:
        ri = np.clip(np.rint(r), 1.0, 100.0).astype(np.int64)
        pfreq = _pfreq_tab[ri]
        near = np.exp(-((r - ri) ** 2) / (2.0 * 1.0))
        score = score + 25.0 * pfreq * near

    # Sliver penalty: residual too small to be usefully filled later.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)
    score = score - 1.5 * sliver - 1.0 * tiny

    # Tiny tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

