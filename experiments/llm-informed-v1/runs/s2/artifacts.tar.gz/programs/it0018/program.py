# EVOLVE-BLOCK-START
"""Residual-utility best fit with count-aware new-bin discouragement."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _total

    if _n == 0:
        _total = float(len(bins))

    _sum += item
    _n += 1
    _hist[item] += 1.0
    mean = _sum / _n
    m = max(mean, 1.0)

    # Typical fill size from mode, blended toward mean.
    if _n >= 30:
        counts = _hist[1:101]
        mode = float(np.argmax(counts) + 1)
        typical = 0.5 * mode + 0.5 * m
    else:
        typical = m
    typical = min(max(typical, 1.0), 100.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    r = residual

    # Exact fill is essentially free capacity; strongly reward it.
    r_frac = r / 100.0
    exact = (r < 0.5).astype(np.float64)

    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r

    dist = np.minimum(d0, dk)

    # Penalize tiny unusable slivers (nonzero residual smaller than typical).
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    score = -(dist + 0.75 * sliver) + 5.0 * exact

    # Discourage starting a brand-new bin: penalize bins that were empty
    # (residual before placement == 100) unless this is a clearly good fit.
    new_bin = (r_frac >= (100.0 - item) / 100.0 - 1e-9).astype(np.float64)
    # Weight grows as instance progresses (opening new bins is wasteful later).
    progress = _n / max(_total, 1.0)
    score = score - (0.3 + 0.7 * progress) * typical * new_bin

    # Slight tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
