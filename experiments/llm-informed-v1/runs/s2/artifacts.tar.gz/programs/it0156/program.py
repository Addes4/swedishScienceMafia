# EVOLVE-BLOCK-START
"""Best-fit, deferring to worst-fit when the placement would create an unusable sliver."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 20:
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    r = bins.astype(np.float64) - item  # residual after placing here

    exact = (r < 0.5).astype(np.float64)

    # Usable if the leftover can still hold the smallest item we've seen.
    usable = (r >= _min_item).astype(np.float64)

    # Best-fit: prefer small usable residuals. Worst-fit among unusable: prefer
    # the largest unusable residual (least number of wasted near-empty bins).
    score = -usable * r + (1.0 - usable) * r

    score = score + 5.0 * exact - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

