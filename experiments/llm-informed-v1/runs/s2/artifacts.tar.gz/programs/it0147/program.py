# EVOLVE-BLOCK-START
"""Best-fit backbone with a frequency-weighted 'closeable residual' bonus."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_min_item = 1.0
# Top-K most frequent item sizes (as a small array, refreshed periodically).
_top_sizes = np.zeros(0, dtype=np.float64)
_top_w = np.zeros(0, dtype=np.float64)
_phase = 0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _min_item, _top_sizes, _top_w, _phase

    _n += 1
    _hist[item] += 1.0

    # Refresh derived statistics a few times over the instance (cheap amortized).
    if _n == 30 or (_n > 30 and (_n % 200 == 0)):
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        counts = _hist[1:101]
        total = counts.sum()
        if total > 0:
            k = min(12, int(nz.size))
            if k > 0:
                # Pick the k most frequent observed sizes.
                order = np.argsort(counts)[::-1][:k]
                sizes = (order + 1).astype(np.float64)
                weights = counts[order] / total
                mask = weights > 0
                _top_sizes = sizes[mask]
                _top_w = weights[mask]

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strong reward for exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Reward residuals that equal a likely future item size (closeable gaps).
    closeable = np.zeros_like(r)
    if _top_sizes.size > 0:
        # distance from r to nearest frequent size
        diff = np.abs(r[:, None] - _top_sizes[None, :])
        best = diff.min(axis=1)
        closeable = np.where(best < 0.5, 1.0, 0.0)

    # Penalize slivers below the smallest observed item (never fillable).
    tiny = np.where((r > 0) & (r < _min_item - 0.5), _min_item - r, 0.0)

    # Best-fit: minimize residual. Distribute bonus/penalty on top.
    score = -r - 0.6 * tiny + 1.5 * closeable + 4.0 * exact

    return score
# EVOLVE-BLOCK-END
