# EVOLVE-BLOCK-START
"""Best-fit backbone plus empirical exact-completion likelihood bonus."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # residual>=0 for shown bins

    # Strongly reward exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Best-fit backbone: prefer smaller residual.
    best_fit = -r

    # Empirical probability that a future item exactly equals residual r.
    # Use histogram over seen items, smoothed. Residual r in [0,100].
    h = _hist[1:101]  # index i -> size i+1
    tot = h.sum()
    if tot > 0:
        # map residual to integer size (round), probability of that exact size
        ri = np.clip(np.rint(r).astype(np.int64), 1, 100)  # 1..100
        # probability mass of that size (normalized)
        p_exact = h[ri - 1] / tot  # array matching r
    else:
        p_exact = np.zeros_like(r)

    # Reward residuals that can likely be exactly completed (large residual
    # sizes are rarer per-size but more valuable; keep bounded).
    match_bonus = 30.0 * p_exact

    score = best_fit + match_bonus + 5.0 * exact

    # Mild tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

