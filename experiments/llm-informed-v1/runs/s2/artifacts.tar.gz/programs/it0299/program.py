# EVOLVE-BLOCK-START
"""Best-fit core plus an empirical future-fit bonus based on the probability
that the resulting residual can be completed exactly by a future item, using a
smoothed histogram of observed item sizes."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)

# Cached lookup of smoothed frequency probabilities per residual 0..100.
_pfreq_smooth = np.ones(101, dtype=np.float64)
_pmax = 0.02
_last_build = -1


def _rebuild():
    global _pfreq_smooth, _pmax
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    p = _hist / total
    # Smooth with a small kernel so nearby residuals get some credit without
    # being dominated by sparse single-bin spikes.
    x = np.arange(101, dtype=np.float64)
    sigma = 2.0
    k = np.exp(-((x[:, None] - x[None, :]) ** 2) / (2.0 * sigma * sigma))
    k /= np.sum(k, axis=1, keepdims=True)
    _pfreq_smooth[:] = p @ k
    _pmax = max(float(np.max(p[1:101])), 1e-3)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 100 or _last_build < 0):
        _rebuild()
        _last_build = _n

    residual = bins.astype(np.float64) - item  # resulting residual >= 0
    r = residual

    # Core: minimize resulting residual (best fit).
    score = -r

    # Exact fill: strong bonus, scaled by how common such completions are.
    exact = (r < 0.5).astype(np.float64)
    score = score + (5.0 + 20.0 * _pmax) * exact

    if _n >= 30:
        # Reward residuals that match a frequent future item size (likely to be
        # completed exactly soon), using the smoothed probability lookup.
        ri = np.clip(np.rint(r), 0.0, 100.0).astype(np.int64)
        score = score + 6.0 * _pfreq_smooth[ri]

    # Tiny tie-break toward fuller bins.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
