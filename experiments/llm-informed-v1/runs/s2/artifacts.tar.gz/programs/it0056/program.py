# EVOLVE-BLOCK-START
"""Best-fit backbone with a sub-minimum-item sliver penalty."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_min_item = 100.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _min_item

    _n += 1
    _hist[item] += 1.0

    # Track empirical minimum item size seen so far.
    if item < _min_item:
        _min_item = float(item)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Pure best-fit backbone: prefer the smallest residual.
    score = -r

    # Penalize residuals that are positive but too small to ever hold the
    # smallest item observed so far (unusable slivers).
    if _min_item > 1.0:
        tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)
        score = score - 0.5 * tiny

    return score
# EVOLVE-BLOCK-END
