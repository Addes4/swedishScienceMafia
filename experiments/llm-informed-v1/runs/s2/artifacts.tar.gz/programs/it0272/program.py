# EVOLVE-BLOCK-START
"""Best-fit core with usable-gap bonus, empirical distribution-based
residual reward, and a periodically rebuilt smooth "future closure"
table that estimates how likely a residual is to be exactly filled soon."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0
_pmax = 0.02
_q25 = 25.0
_q75 = 55.0

# Cached tables (rebuilt periodically).
_pfreq_tab = np.zeros(101, dtype=np.float64)   # freq prob per integer size 0..100
_closure_tab = np.zeros(101, dtype=np.float64) # smooth closure reward per residual 0..100
_usef_tab = np.zeros(101, dtype=np.float64)    # expected future usefulness per residual
_last_build = -1


def _rebuild():
    global _pfreq_tab, _closure_tab, _usef_tab
    global _median, _min_item, _mean, _pmax, _q25, _q75
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    cdf = np.cumsum(_hist[1:101])
    _median = float(np.searchsorted(cdf, 0.5 * total) + 1)
    _q25 = float(np.searchsorted(cdf, 0.25 * total) + 1)
    _q75 = float(np.searchsorted(cdf, 0.75 * total) + 1)
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _mean = _sum / _n
    _pmax = max(float(np.max(_hist[1:101]) / total), 1e-3)

    p = _hist / total
    _pfreq_tab[:] = p

    # Smooth closure reward: a residual r is good if some frequent item size
    # is close to r (so the bin can be closed exactly by one future item),
    # OR if r is near the sum of two common sizes (closed by two items).
    x = np.arange(101, dtype=np.float64)
    S = _q75  # search range for two-item sums
    sz = x[1:101]
    closure = np.zeros(101, dtype=np.float64)
    # one-item closure: sum over sizes s of p[s] * kernel(r - s)
    for s in range(1, 101):
        ps = p[s]
        if ps > 0.0:
            closure += ps * np.exp(-((x - s) ** 2) / (2.0 * 2.0 * 2.0))
    # two-item closure: reward r that is a sum of two likely sizes
    two = np.zeros(101, dtype=np.float64)
    for s1 in range(1, 101):
        p1 = p[s1]
        if p1 <= 0.0:
            continue
        # sizes s2 with p2 notable and s1+s2 <= 100
        s2max = 100 - s1
        if s2max < 1:
            continue
        idx = np.arange(1, s2max + 1)
        p2 = p[idx]
        contrib = p1 * p2
        # accumulate into two at positions s1+idx
        np.add.at(two, s1 + idx, contrib)
    # normalize two-item contribution scale to be comparable
    if np.max(two) > 0:
        two = two / np.max(two) * np.max(closure)
    _closure_tab[:] = closure + 0.6 * two

    # Expected future usefulness: for a residual r, the number (weighted by
    # probability) of typical upcoming items it could host, plus closure.
    usef = np.zeros(101, dtype=np.float64)
    for r in range(101):
        # probability-weighted count of single items fitting in r
        s = np.arange(1, r + 1)
        if r >= 1:
            usef[r] = float(np.sum(p[1:r + 1] * (1.0 + _closure_tab[r])))
    _usef_tab[:] = usef


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    typical = max(min(_median, 100.0), 1.0)
    mean = max(min(_mean, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    exact = (r < 0.5).astype(np.float64)

    # Distance of residual to multiples of a typical item size (best-fit core).
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    fit_future = np.abs(r - mean)

    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    used = 100.0 - r
    frac = np.where(used > 0, r / used, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact
    score = score - 1.0 * fit_future * 0.05
    score = score - 1.5 * frac

    # Empirical closure / usefulness reward.
    if _n >= 30:
        rc = np.clip(r, 0.0, 100.0)
        tbl_c = _closure_tab
        score = score + 8.0 * np.interp(rc, np.arange(101, dtype=np.float64), tbl_c)

        # Mild reward for residuals that can host many typical items (good
        # "reusable" gaps), scaled small so best-fit core dominates.
        # Use integer lookup for speed via rounding.
        ri = np.clip(np.rint(r), 0.0, 100.0).astype(np.int64)
        score = score + 0.5 * _usef_tab[ri]

    score = score + 20.0 * _pmax * exact
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

