# EVOLVE-BLOCK-START
"""Best-fit with empirical-CDF-based sliver penalty keyed to observed item sizes."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_cdf = None  # empirical CDF over sizes 0..100 (P(item <= x))


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _cdf

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        # P(item <= x) for x = 0..100, with a small uniform smoothing so that
        # unseen small sizes are not treated as impossible.
        p = np.concatenate(([0.0], cdf / total))
        p = (p * total + 0.5) / (total + 1.0)
        _cdf = p

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Probability that a future item fits into the residual gap.
    if _cdf is not None:
        ri = np.clip(np.rint(r).astype(np.int64), 0, 100)
        pfit = _cdf[ri]
    else:
        pfit = np.clip(r / 100.0, 0.0, 1.0)

    # Probability that the residual cannot hold ANY typical future item:
    # this is a "dead sliver" and should be penalized smoothly.
    dead = 1.0 - pfit

    # Prefer residuals that can still hold at least one more typical item,
    # expressed via the CDF of typical-size fills; plus a mild best-fit pull.
    fit_typical = (r >= typical).astype(np.float64)

    score = (
        -2.0 * dead
        + 0.5 * pfit
        + 0.3 * fit_typical
        + 5.0 * exact
        - 1e-3 * r
    )

    return score
# EVOLVE-BLOCK-END

