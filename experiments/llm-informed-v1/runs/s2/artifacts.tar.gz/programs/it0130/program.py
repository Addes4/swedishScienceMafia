# EVOLVE-BLOCK-START
"""Best-fit with a bonus when the resulting residual matches a seen item size."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _median, _min_item

    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # residual after placement, >= 0

    # Exact fit bonus.
    exact = (r < 0.5).astype(np.float64)

    # Bonus if residual corresponds to an item size that has been seen
    # (so it can plausibly be filled exactly later), scaled by frequency.
    ri = np.rint(r).astype(np.int64)
    ri = np.clip(ri, 0, 100)
    freq = _hist[ri] / max(_n, 1)
    match = np.where(r > 0.5, freq, 0.0)

    # Penalty for leaving a positive residual smaller than the smallest
    # item seen so far (an unusable sliver).
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Base: prefer the tightest fit; add bonuses for exact/fillable residuals.
    score = -r + 3.0 * exact + 2.0 * match - 0.5 * tiny

    # Tiny tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
