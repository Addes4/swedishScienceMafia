# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus, empirical future-fit, and mode-fit term."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0
_mode = 40.0
_pmax = 0.02  # max single-size probability estimate


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _mean, _mode, _pmax

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
            _mode = float(nz[np.argmax(_hist[1:101][nz])] + 1)
        _mean = _sum / _n
        _pmax = max(float(np.max(_hist[1:101]) / total), 1e-3)

    typical = max(min(_median, 100.0), 1.0)
    mean = max(min(_mean, 100.0), 1.0)
    mode = max(min(_mode, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Exact fill: residual is 0 -> perfect, huge bonus.
    exact = (r < 0.5).astype(np.float64)

    # Distance of residual to multiples of a typical item size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Reward residuals that can host a typical (mean/median) future item well.
    fit_future = np.abs(r - mean)

    # Mode-fit: how close residual is to a multiple of the most probable size.
    km = np.rint(r / mode)
    dmod = np.abs(r - km * mode)
    dmod0 = r
    fit_mode = np.minimum(dmod0, dmod)

    # Sliver penalty: too small to be usefully filled.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Harmonic-style waste fraction term.
    used = 100.0 - r
    frac = np.where(used > 0, r / used, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact

    # Moderate reward for residuals that can host a future average item.
    score = score - 1.0 * fit_future * 0.05

    # Reward residuals likely fillable exactly by the most common future item.
    score = score - 0.3 * fit_mode

    score = score - 1.0 * frac

    # Exact fits get extra weight proportional to how likely that item is.
    score = score + 20.0 * _pmax * exact

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
