# EVOLVE-BLOCK-START
"""Best-fit with exact-fit reward plus a lightweight expected-fill term."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_quant25 = 10.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _quant25

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 50 and (_n % 25 == 0 or _median == 40.0):
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        if total > 0:
            _median = float(np.searchsorted(cdf, 0.5 * total) + 1)
            _quant25 = float(np.searchsorted(cdf, 0.25 * total) + 1)
            nz = np.nonzero(_hist[1:101])[0]
            if nz.size > 0:
                _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)
    small = max(min(_quant25, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits (no waste at all).
    exact = (r < 0.5).astype(np.float64)

    # Best-fit backbone: prefer the smallest usable residual, but leave
    # some room so that residuals smaller than a typical item are penalized.
    # Residuals at least as large as a typical item are preferred over
    # middling ones that are hard to fill later.
    big = (r >= typical).astype(np.float64)

    # Residuals smaller than the smallest item seen are pure waste.
    sliver = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Main term: best-fit distance (smaller residual better), nudged down for
    # big-residual bins so we don't fill the most flexible bins too early.
    score = -r + 6.0 * exact + 0.35 * small * big - 0.6 * sliver

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
