# EVOLVE-BLOCK-START
"""Best-fit rule: place the item so the resulting residual is as small as
possible, with a strong bonus for exact fills and a penalty for residuals that
are too small to be usefully filled later. Simple and robust."""
import numpy as np

_min_item = 1.0
_sum = 0.0
_n = 0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _min_item

    _sum += item
    _n += 1
    # Track a rough estimate of the smallest observed item to size the
    # sliver penalty (items can be as small as 1, so this stays mild).
    if item < _min_item:
        _min_item = float(item)

    r = bins.astype(np.float64) - item  # leftover capacity if placed here, >= 0

    # Exact fill gets a big bonus.
    exact = (r < 0.5).astype(np.float64)

    # Small residual sliver penalty: residual too small to be usefully filled.
    sliver = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Best-fit: smaller residual is better. Fractional waste term smooths it.
    used = 100.0 - r
    frac = np.where(used > 0, r / used, 0.0)

    score = -r - 1.5 * frac - 0.5 * sliver + 1000.0 * exact

    return score
# EVOLVE-BLOCK-END
