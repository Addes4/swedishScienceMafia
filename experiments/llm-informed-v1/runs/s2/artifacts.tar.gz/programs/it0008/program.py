# EVOLVE-BLOCK-START
"""Best fit with residual-aware tie-break using online item statistics."""
import numpy as np

_state = {"n": 0, "hist": None, "sum_sq": 0.0, "means": None}


def _init(num_items):
    # histogram of item sizes 1..100 bucket by 5
    _state["hist"] = np.zeros(21, dtype=np.float64)  # 0..20 index = size//5
    _state["n"] = 0


def priority(item, bins):
    if _state["n"] == 0 or _state["hist"] is None:
        _init(len(bins))
    # update stats
    _state["n"] += 1
    _state["hist"][min(20, item // 5)] += 1.0

    # residual after placing
    resid = bins - item  # >= 0 since these bins fit

    # base: best fit (smaller residual better)
    score = -resid.astype(np.float64)

    # Bonus: if residual is a "common" leftover size, future items may fill it cleanly.
    # Estimate probability mass that an item size equals the residual.
    n = _state["n"]
    hist = _state["hist"]
    # probability of exact size resid (using bucket frequency / bucket width + smoothing)
    idx = np.minimum(20, resid // 5)
    # freq of bucket ~ size//5
    freq = hist[idx] / (n + 1.0)
    # bigger bonus for residuals that are frequent sizes, and for smaller residuals.
    # scale small so best-fit dominates.
    bonus = 0.05 * freq
    # small penalty for large residuals (prefer tighter fits slightly more)
    score = score - 0.001 * resid

    return score + bonus
# EVOLVE-BLOCK-END
