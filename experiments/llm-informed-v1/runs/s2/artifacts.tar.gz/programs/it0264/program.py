# EVOLVE-BLOCK-START
"""Best-fit with exact-fill bonus, usable-gap terms, and empirical
future-fit reward. Adds a cached "two-item complement" table: residuals that
equal the sum of two likely future item sizes get a bonus, since two arriving
items can then close the bin exactly."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0
_pmax = 0.02
_q25 = 25.0
_q75 = 55.0

# Cached lookup tables.
_pfreq_tab = np.zeros(101, dtype=np.float64)   # surviving frequency prob per integer size
_band_tab = np.zeros(101, dtype=np.float64)    # band kernel per residual 0..100
_pair_tab = np.zeros(101, dtype=np.float64)    # prob two future items sum to ~ residual
_last_build = -1


def _rebuild():
    global _pfreq_tab, _band_tab, _pair_tab, _median, _min_item, _mean, _pmax, _q25, _q75
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    cdf = np.cumsum(_hist[1:101])
    idx = np.searchsorted(cdf, 0.5 * total)
    _median = float(idx + 1)
    i25 = np.searchsorted(cdf, 0.25 * total)
    i75 = np.searchsorted(cdf, 0.75 * total)
    _q25 = float(i25 + 1)
    _q75 = float(i75 + 1)
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _mean = _sum / _n
    _pmax = max(float(np.max(_hist[1:101]) / total), 1e-3)

    p = _hist / total
    _pfreq_tab[:] = p

    # band kernel over residual integer values 0..100
    lo, hi = _q25, _q75
    width = max(hi - lo, 1.0) * 0.5 + 1.0
    mid = 0.5 * (lo + hi)
    x = np.arange(101, dtype=np.float64)
    _band_tab[:] = np.exp(-((x - mid) ** 2) / (2.0 * width * width))

    # Two-item complement: empirical probability that one future item equals s
    # (from histogram), convolved to give P(s1 + s2 == R) for R in 0..100.
    # Restrict to plausible sizes to keep the convolution cheap and meaningful.
    q = p[1:101].copy()
    # zero out near-impossible tiny-prob sizes to reduce noise
    thr = 0.25 / total if total > 0 else 0.0
    q[q < thr] = 0.0
    # convolution of q with itself gives sums 2..200
    conv = np.convolve(q, q)
    pair = np.zeros(101, dtype=np.float64)
    # index into conv: sum - 2
    for R in range(2, 101):
        pair[R] = conv[R - 2]
    # normalize to a reasonable scale
    mx = np.max(pair)
    if mx > 0:
        pair = pair / mx
    _pair_tab[:] = pair
    _pair_tab[0] = 0.0
    _pair_tab[1] = 0.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _mean, _pmax, _q25, _q75, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    typical = max(min(_median, 100.0), 1.0)
    mean = max(min(_mean, 100.0), 1.0)

    r = bins.astype(np.float64) - item

    exact = (r < 0.5).astype(np.float64)

    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    fit_future = np.abs(r - mean)

    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    used = 100.0 - r
    frac = np.where(used > 0, r / used, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact
    score = score - 1.0 * fit_future * 0.05
    score = score - 1.5 * frac

    if _n >= 30:
        ri = np.clip(np.rint(r), 1.0, 100.0).astype(np.int64)
        pfreq = _pfreq_tab[ri]
        near = np.exp(-((r - ri) ** 2) / (2.0 * 1.0))
        score = score + 8.0 * pfreq * near

        ri2 = np.clip(r, 0.0, 100.0)
        score = score + 0.3 * np.interp(ri2, np.arange(101, dtype=np.float64), _band_tab)

        # Two-item complement bonus: residual that two likely future items can
        # together close exactly.
        ri3 = np.clip(np.rint(r), 0.0, 100.0).astype(np.int64)
        score = score + 3.0 * _pair_tab[ri3] * near

    score = score + 20.0 * _pmax * exact
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
