# EVOLVE-BLOCK-START
"""Best fit, but reserve empty bins for smaller items when the item is large."""
import numpy as np

_state = {"num_bins": None, "remaining": None, "counts": None}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = len(bins)

    # Initialize per-instance state on first call: total bin count == total items.
    if _state["num_bins"] != n:
        _state["num_bins"] = n
        _state["remaining"] = np.full(n, 100, dtype=np.int64)
        _state["counts"] = np.zeros(n, dtype=np.int64)

    rem = _state["remaining"]
    counts = _state["counts"]

    # Best fit: most negative leftover => tightest fit.
    base = -(bins - item)

    if item >= 50:
        # Prefer tightest-fitting used bin over opening a fresh bin.
        # bins here are the remaining capacities of bins that fit the item.
        # A used bin is one whose index has counts > 0.
        # Penalize empty bins strongly so used ones win when available.
        empty_mask = (bins == 100) & (counts[:n] == 0)
        base = base - 1000000.0 * empty_mask

    best_idx = int(np.argmax(base))

    # Record the choice into our state.
    rem[best_idx] -= item
    counts[best_idx] += 1

    return base
# EVOLVE-BLOCK-END
