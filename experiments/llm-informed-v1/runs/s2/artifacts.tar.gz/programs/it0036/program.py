# EVOLVE-BLOCK-START
"""Best-fit augmented by empirical probability that the residual is closeable."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_min_item = 1.0
_mean = 40.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _hist, _n, _min_item, _mean

    _n += 1
    _hist[item] += 1.0

    if _n >= 1:
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        total = _hist[1:101].sum()
        if total > 0:
            sizes = np.arange(1, 101, dtype=np.float64)
            _mean = float((sizes * _hist[1:101]).sum() / total)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Empirical probability that some single observed item size equals r.
    ri = np.clip(np.rint(r).astype(np.int64), 1, 100)
    prob_exact = _hist[ri] / max(_n, 1.0)

    # Probability that r can be filled by a small number of common items:
    # use cumulative mass of item sizes <= r as a proxy for "fillable gap".
    cdf = np.cumsum(_hist[1:101]) / max(_n, 1.0)
    fillable = cdf[ri - 1]

    exact = (r < 0.5).astype(np.float64)

    # Sliver penalty: positive residual below smallest item can never be used.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Best-fit term: prefer tightest fits, but weight by fillability so that
    # residuals unlikely to be closed are penalized.
    score = (
        6.0 * exact
        + 2.0 * prob_exact
        + 1.0 * fillable
        - 0.02 * r
        - 0.5 * tiny
    )

    return score
# EVOLVE-BLOCK-END

