# EVOLVE-BLOCK-START
"""Balanced-fit: strongly prefer exact fits, otherwise fill the fullest bin
whose residual is still large enough to be usable, with a light preference
for balancing (smaller residual but not tiny) rather than pure best-fit."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_mean = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _mean, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        counts = _hist[1:101]
        total = counts.sum()
        cdf = np.cumsum(counts)
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        if total > 0:
            sizes = np.arange(1, 101)
            _mean = float((counts * sizes).sum() / total)
        nz = np.nonzero(counts)[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)
    r = bins.astype(np.float64) - item  # >= 0

    exact = (r < 0.5).astype(np.float64)

    # Sliver penalty: residual too small to be useful.
    sliver = np.where((r > 0) & (r < 0.5 * typical), 0.5 * typical - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Balancing term: prefer placing into fuller bins (smaller residual),
    # but not into near-empty slivers, to keep many bins densely packed.
    # Use a soft balance: reward smaller residual mildly.
    balance = -1.0 / (r + 1.0)

    score = balance + 6.0 * exact - 0.75 * sliver - 0.5 * tiny

    return score
# EVOLVE-BLOCK-END

