# EVOLVE-BLOCK-START
"""Best-fit refined by empirical fillability of the residual gap."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_n_since_update = 0
# Cached arrays recomputed occasionally.
_fill_prob = np.zeros(101, dtype=np.float64)   # prob. some future item == size s
_cdf = np.zeros(101, dtype=np.float64)


def _refresh():
    """Recompute cached distribution statistics from the histogram."""
    global _fill_prob, _cdf
    tot = _hist[1:101].sum()
    if tot <= 0:
        return
    p = _hist[1:101] / tot            # empirical pmf of item sizes
    # Probability that a single future item exactly equals size s.
    _fill_prob[1:101] = p
    _cdf[1:101] = np.cumsum(p)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _n_since_update

    _sum += item
    _n += 1
    _hist[item] += 1.0
    _n_since_update += 1
    if _n_since_update >= 25:
        _n_since_update = 0
        _refresh()

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Best-fit term: prefer the tightest fit (smallest leftover) as the base.
    score = -residual

    # Fillability bonus: reward residuals that likely match a future single
    # item exactly, so that gap can be closed rather than wasted.
    # Look up P(item == residual) from the empirical pmf, with smoothing.
    ri = residual.astype(np.int64)
    ri = np.clip(ri, 0, 100)
    fill = _fill_prob[ri]

    # Weight the bonus by fraction of the instance still expected to arrive.
    score += 60.0 * fill

    # Exact fits are almost always good.
    exact = (residual < 0.5).astype(np.float64)
    score += 4.0 * exact

    # Penalize unusable slivers whose residual mass is very unlikely to be
    # fillable (low empirical fill probability) and is small.
    small = np.clip(50.0 - residual, 0.0, None) / 50.0  # near 1 for small r
    score -= 3.0 * small * (1.0 - np.clip(20.0 * fill, 0.0, 1.0))

    return score
# EVOLVE-BLOCK-END
