# EVOLVE-BLOCK-START
"""Best-fit backbone with an empirical sample-fit residual preference."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_min_item = 1.0
_join_pmf = None
_join_values = None


def _rebuild_join():
    """Distribution of pairwise item-size sums (bounded), used to score
    how likely a residual gap can be closed by future items."""
    global _join_pmf, _join_values
    counts = _hist[1:101]
    total = counts.sum()
    if total <= 0:
        _join_pmf = None
        _join_values = None
        return
    p = counts / total
    # Convolve item distribution with itself (size distribution of pairs).
    conv = np.convolve(p, p)
    _join_values = np.arange(2, len(conv) + 2).astype(np.float64)  # sums 2..200
    _join_pmf = conv


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        if _n % 25 == 0:
            _rebuild_join()

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strong exact-fit reward.
    exact = (r < 0.5).astype(np.float64)

    # Fillability: reward residuals that equal a likely item size (single fit)
    # or a likely pair-sum (two-item fit), i.e. gaps we can close later.
    if _join_pmf is not None and _join_values is not None:
        # probability the residual matches a single item exactly (within 0.5)
        ints = np.rint(r).astype(np.int64)
        ints = np.clip(ints, 0, 100)
        single_p = _hist[ints] / max(_n, 1.0)
    else:
        single_p = np.zeros_like(r)

    if _join_pmf is not None and _join_values is not None:
        ints = np.rint(r).astype(np.int64)
        ints = np.clip(ints - 2, 0, len(_join_pmf) - 1)
        pair_p = _join_pmf[ints]
    else:
        pair_p = np.zeros_like(r)

    # Unusable slivers: positive residual below smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Main term: minimize residual (best fit), lightly corrected by fillability.
    score = -r
    score = score + 3.0 * exact
    score = score + 8.0 * single_p
    score = score + 2.0 * pair_p
    score = score - 0.5 * tiny

    return score
# EVOLVE-BLOCK-END

