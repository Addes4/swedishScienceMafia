# EVOLVE-BLOCK-START
"""Best-fit with a sharp two-regime unusable-sliver penalty.

The dominant term is best-fit (smallest residual wins).  But leaving a
positive residual below the smallest item we have ever seen is essentially
dead space, so such placements are ordered by a secondary rule that
prefers residuals that are close to (but below) a frequently-seen item
size, i.e. residues that a common companion item could still fill.
"""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_min_item = 1.0
_median = 40.0


def priority(item, bins):
    global _hist, _n, _min_item, _median

    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)

    m = max(_min_item, 1.0)
    r = bins.astype(np.float64) - item  # residual, >= 0 for shown bins

    # Distance to the nearest common item size <= residual (a future companion
    # could exactly top the bin up).  Sizes seen frequently get more weight.
    bonus = np.zeros_like(r)
    # frequency-weighted closeness to any observed item size <= r
    sizes = np.nonzero(_hist[1:101])[0] + 1
    if sizes.size:
        freq = _hist[sizes] / max(_n, 1)
        for s, f in zip(sizes, freq):
            near = np.abs(r - s) <= 0.5
            bonus += f * near

    # Regime 1: residual >= smallest item -> these bins are usable; just
    # best-fit them (subtract a tiny bonus so exact-ish tops are preferred).
    usable = r >= m
    # Regime 2: residual < smallest item -> dead space, strongly penalized,
    # tie-broken toward residuals a companion item can still fill exactly.
    dead_pen = np.where(usable, 0.0, 1.0)
    # For unusable bins, more free capacity is not better: prefer the one
    # whose residual matches a frequent item size (fillable), else smaller r.
    dead_score = np.where(usable, 0.0, -r + 10.0 * bonus)

    score = -r + 10.0 * bonus - 100.0 * dead_pen + dead_score

    return score
# EVOLVE-BLOCK-END
