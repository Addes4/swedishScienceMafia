# EVOLVE-BLOCK-START
"""Harmonic-style best fit.

Rank bins by remaining capacity, but give a bonus to bins whose remaining capacity
falls into a logarithmic size class that the item still fits into. This mimics
Harmonic bin packing: items are effectively matched to bins scaled by size class,
which curbs the fraction of waste from partially filled bins.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # remaining capacity after placing item (>= 0 since bins fit)

    # Bin capacity classes sized relative to item: prefer bins that become small
    # residuals (tight fit) but avoid leaving slivers that no future item fits.
    # Score = -residual, with a slight penalty for residual in (0, item//2)
    # since those slivers tend to be wasted; encourage exact/near-exact fits
    # and fully-absorbing many small items into already-open bins.
    score = -rem.astype(np.float64)

    # Slight preference against leaving unusable tiny slivers.
    tiny = (rem > 0) & (rem * 4 < item)
    score[tiny] -= 0.5 * item

    # Slight preference for bins that were already fuller (helps consolidation):
    # a bin that was nearly full before is good to top off.
    score += 0.001 * (100.0 - bins)

    return score
# EVOLVE-BLOCK-END
