# EVOLVE-BLOCK-START
"""Best-fit distance core plus a periodically rebuilt lookup table that scores
each possible residual by the estimated probability of an exact future closure
over the next few items, minus a small expected-waste term. Keeps the strong
exact-fill bonus and a light sliver penalty; removes noisy auxiliary terms."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0
_pmax = 0.02

# Lookup tables rebuilt periodically.
_closure_tab = np.zeros(101, dtype=np.float64)  # prob a residual closes exactly soon
_last_build = -1
_horizon = 4  # items ahead considered for exact closure


def _rebuild():
    global _closure_tab, _median, _min_item, _mean, _pmax
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    cdf = np.cumsum(_hist[1:101])
    idx = np.searchsorted(cdf, 0.5 * total)
    _median = float(idx + 1)
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _mean = _sum / _n
    p = _hist[1:101] / total  # probs for sizes 1..100
    _pmax = max(float(np.max(p)), 1e-3)

    # Distribution of the sum of up to `_horizon` future items (approximate:
    # convolution of the empirical size distribution with itself, truncated).
    # We only need, for each residual r, the probability that a single future
    # item equals r exactly (strongest signal) plus a small chance the sum of a
    # couple of items equals r.
    one_s = np.zeros(101, dtype=np.float64)
    one_s[1:101] = p  # P(item == r)

    # sum of two items
    two_s = np.zeros(101, dtype=np.float64)
    conv = np.convolve(p, p)  # index k -> P(sum == k+2), k in 0..198
    m = min(101, conv.size)
    two_s[0:m] = conv[0:m]

    # Build closure table: for residual r, a future exact single item closure
    # is best; a two-item closure is possible but less likely useful.
    x = np.arange(101, dtype=np.float64)
    _closure_tab[:] = one_s + 0.35 * two_s
    # Expected waste avoided: residual that matches the mean leaves least waste.
    # Fold in a gentle preference for residuals near the mean (good future fit).
    sigma = max(_mean * 0.6, 5.0)
    _closure_tab[:] += 0.02 * np.exp(-((x - _mean) ** 2) / (2.0 * sigma * sigma))


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _mean, _pmax, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    typical = max(min(_median, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # residual, >= 0

    # Exact fill.
    exact = (r < 0.5).astype(np.float64)

    # Distance of residual to multiples of a typical item size (best-fit core).
    k = np.rint(r / typical)
    dk = np.abs(r - k * typical)
    dist = np.minimum(r, dk)

    # Sliver penalty: small residues are hard to fill usefully.
    sliver = np.where((r > 0) & (r < 0.5 * typical), 0.5 * typical - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact

    # Empirical closure reward: residual likely to be filled exactly soon.
    if _n >= 30:
        ri = np.clip(np.rint(r), 0.0, 100.0).astype(np.int64)
        near = np.exp(-((r - ri) ** 2) / (2.0 * 0.7))
        score = score + 10.0 * _closure_tab[ri] * near

    # Extra exact-fill weight proportional to max item probability.
    score = score + 20.0 * _pmax * exact

    # Tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

