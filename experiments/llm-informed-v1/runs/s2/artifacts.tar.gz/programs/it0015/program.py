# EVOLVE-BLOCK-START
"""Best fit augmented by empirical future-fill value of the resulting residual."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n

    _sum += item
    _n += 1
    _hist[item] += 1.0
    mean = _sum / _n
    m = max(mean, 1.0)

    # Empirical weights for future items: blend observed histogram with a
    # prior concentrated on the current mean (the Weibull mode region).
    counts = _hist[1:101]
    total = counts.sum()
    if total >= 20.0:
        w = counts / total
    else:
        # crude prior: weight sizes near the running mean
        sizes = np.arange(1, 101, dtype=np.float64)
        w = np.exp(-0.5 * ((sizes - m) / max(m * 0.5, 1.0)) ** 2)
        w = w / w.sum()

    residual = bins.astype(np.float64) - item  # >= 0
    r = residual

    # Probability mass of future items that fit exactly into residual r
    # (i.e. an item of size r can close the bin). Use a small tolerance band.
    ridx = np.rint(r).astype(np.int64)
    ridx = np.clip(ridx, 0, 100)
    fill_val = np.where(r > 0, w[np.clip(ridx - 1, 0, 99)], 0.0)
    # Full bins (r == 0) are perfectly packed.
    fill_val = np.where(r < 0.5, 3.0, fill_val)

    # Best fit: prefer smaller residual, but weight by future-fill value.
    score = -r + 8.0 * fill_val - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
