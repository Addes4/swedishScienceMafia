# EVOLVE-BLOCK-START
"""Best-fit core: minimize residual (waste), with a strong exact-fill bonus
and a light empirical bonus for residuals matching common future item sizes."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_pfreq_tab = np.zeros(101, dtype=np.float64)
_last_build = -1


def _rebuild():
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    _pfreq_tab[:] = _hist / total


def priority(item, bins):
    global _n, _last_build

    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Best-fit: smaller residual is better (less waste).
    score = -r

    # Strong bonus when the bin is filled exactly.
    exact = (r < 0.5).astype(np.float64)
    score = score + 10.0 * exact

    # Light empirical bonus: residual matching a commonly observed item size
    # is more likely to be completed exactly by a future item.
    if _n >= 30:
        ri = np.clip(np.rint(r), 0.0, 100.0).astype(np.int64)
        pfreq = _pfreq_tab[ri]
        near = np.exp(-((r - ri) ** 2) / 2.0)
        score = score + 5.0 * pfreq * near

    # Tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
