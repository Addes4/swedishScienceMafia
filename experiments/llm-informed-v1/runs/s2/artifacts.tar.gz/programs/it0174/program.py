# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus plus a smoothed likely-future-size bonus on residual."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_prob = np.zeros(101, dtype=np.float64)   # smoothed relative frequency of sizes 0..100
_ready = False


def _rebuild():
    global _prob, _ready
    total = _hist[1:101].sum()
    if total <= 0:
        return
    p = _hist[1:101] / total  # index i corresponds to size i+1
    # Smooth with a small triangular kernel to avoid brittleness.
    kern = np.array([1.0, 4.0, 6.0, 4.0, 1.0])
    kern /= kern.sum()
    ps = np.convolve(p, kern, mode="same")
    out = np.zeros(101, dtype=np.float64)
    out[1:101] = ps
    _prob = out
    _ready = True


def priority(item, bins):
    global _sum, _n, _ready

    _sum += item
    _n += 1
    _hist[item] += 1.0
    _ready = False

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    r = residual
    exact = (r < 0.5).astype(np.float64)

    # Primary: best-fit (smaller residual is better).
    score = -r

    # Strong reward for exact fits.
    score = score + 5.0 * exact

    # Light bonus if residual is a plausible future item size (smoothed freq).
    _rebuild()
    idx = np.clip(r.astype(np.int64), 0, 100)
    score = score + 3.0 * _prob[idx]

    return score
# EVOLVE-BLOCK-END

