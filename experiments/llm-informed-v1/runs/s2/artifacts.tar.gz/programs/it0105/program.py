# EVOLVE-BLOCK-START
"""Best-fit backbone with multiple-of-median fillability bonus and hard
exact-fit preference, plus a sliver penalty based on the smallest item seen."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Strongly reward exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Fillability: distance from residual to nearest multiple of typical.
    k = np.rint(r / typical)
    dk = np.abs(r - k * typical)
    dist = np.minimum(r, dk)

    # Penalize residuals smaller than the smallest item seen (unusable).
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Small sliver penalty relative to a typical item.
    sliver = np.where((r > 0) & (r < 0.5 * typical), 0.5 * typical - r, 0.0)

    score = -(0.5 * dist + 0.5 * sliver + 1.0 * tiny) + 5.0 * exact

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
