# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus keyed to an adaptive fill target."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_total_items = None
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_avg = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _total_items, _median, _avg, _min_item

    if _total_items is None:
        _total_items = int(len(bins))

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        _avg = _sum / _n
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    # Fraction of the instance still to come.
    remaining_frac = max(0.0, (_total_items - _n) / float(_total_items))
    # Early: small gaps are the safest to fill. Late: accept larger gaps.
    typical = _min_item + (1.0 - remaining_frac) * max(_median - _min_item, 0.0)
    typical = max(min(typical, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Distance to nearest multiple of typical fill size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Residuals smaller than a typical item are hard to use -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

