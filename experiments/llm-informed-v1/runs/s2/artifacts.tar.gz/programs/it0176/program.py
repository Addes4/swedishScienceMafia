# EVOLVE-BLOCK-START
"""Best-fit with a targeted bonus for residuals that can still hold future items."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_mean = 40.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _mean

    _sum += item
    _n += 1
    _hist[item] += 1.0

    _mean = _sum / _n

    t = max(_mean, 1.0)
    # A residual is "useful" if it can still hold roughly a typical item.
    useful_floor = 0.5 * t

    residual = bins.astype(np.float64) - item  # >= 0 for shown bins

    r = residual

    # Strongly reward exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Penalize residuals too small to be filled by a future typical item.
    sliver = np.where((r > 0) & (r < useful_floor), useful_floor - r, 0.0)

    # Core: best-fit = smallest residual that fits (negate).
    score = -r - 0.5 * sliver + 5.0 * exact

    # Tiny tie-break toward fuller bins already handled by -r; keep scale clean.
    return score
# EVOLVE-BLOCK-END

