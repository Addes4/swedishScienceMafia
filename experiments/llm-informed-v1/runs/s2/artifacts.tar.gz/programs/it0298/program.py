# EVOLVE-BLOCK-START
"""Best-fit with a single empirical "residual matches a common future item"
bonus. Past attempts showed that stacking many overlapping heuristic terms
(median-multiple distance, percentile band, sliver, harmonic waste) added
noise and hurt. This keeps the packing rule clean: strongly prefer the
fullest bin (best fit), with one data-driven tiebreaker favoring residuals
that equal a frequently observed item size (likely to be completed exactly)."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_pfreq_tab = np.zeros(101, dtype=np.float64)  # smoothed frequency prob per integer size
_last_build = -1


def _rebuild():
    global _pfreq_tab
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    raw = _hist / total
    # Smooth with a small window so rare sizes still get nonzero weight.
    kern = np.array([0.25, 0.5, 0.25], dtype=np.float64)
    smoothed = np.convolve(raw[1:101], kern, mode="same")
    _pfreq_tab[1:101] = smoothed
    _pfreq_tab[0] = 0.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    r = bins.astype(np.float64) - item  # resulting residual, >= 0

    # Core rule: prefer the fullest bin (smallest resulting residual).
    score = -r

    # Single data-driven tiebreaker: reward residuals equal (within a small
    # tolerance) to a common observed item size, since a future item of that
    # size could complete the bin exactly.
    if _n >= 30:
        ri = np.clip(np.rint(r), 1.0, 100.0).astype(np.int64)
        pfreq = _pfreq_tab[ri]
        near = np.exp(-((r - ri) ** 2) / (2.0 * 1.0))
        score = score + 15.0 * pfreq * near

    return score
# EVOLVE-BLOCK-END
