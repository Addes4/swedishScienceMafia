# EVOLVE-BLOCK-START
"""Best-fit with exact-fit reward and empirical residual-utility bonus."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_mean = 40.0
_small = 5.0  # rough scale of "typical small fillable gap"


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _mean, _small

    _n += 1
    _hist[item] += 1.0

    if _n >= 50:
        total = _n
        _mean = float(np.dot(np.arange(1, 101), _hist[1:101]) / total)
        # typical small gap: 25th percentile-ish scale
        cdf = np.cumsum(_hist[1:101])
        idx = np.searchsorted(cdf, 0.20 * total)
        _small = float(max(idx + 1, 5))

    typical = max(min(_mean, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for shown bins
    r = residual

    # Strong reward for exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Best-fit backbone: prefer smallest usable residual.
    score = -r

    # Bonus for residuals that are a "clean" typical fill away from zero,
    # i.e. residuals that look like they could be completed by a typical item
    # or left as a nice usable gap. Reward residuals near a common item size.
    # Probability-mass utility: weight by histogram mass at nearest size.
    near = np.clip(np.rint(r), 0, 100).astype(np.int64)
    mass = np.where(r < 0.5, 0.0, _hist[near] / max(_n, 1))
    # normalize mass into a modest bonus
    score = score + 8.0 * mass

    # Penalize unusable tiny slivers below the smallest typical size.
    sliver = np.where((r > 0) & (r < 0.5 * _small), 0.5 * _small - r, 0.0)

    score = score + 5.0 * exact - 0.75 * sliver - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

