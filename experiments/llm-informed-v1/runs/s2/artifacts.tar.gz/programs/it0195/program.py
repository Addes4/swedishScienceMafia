# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus and an empirical 'reusable residual' bonus."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_min_item = 1.0
_norm_hist = np.zeros(101, dtype=np.float64)  # probability mass of item==r


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _min_item, _hist, _norm_hist

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        total = _hist[1:101].sum()
        if total > 0:
            _norm_hist[1:101] = _hist[1:101] / total
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Exact fit: free capacity, no waste.
    exact = (r < 0.5).astype(np.float64)

    # Reusable-gap bonus: probability that a future item exactly fills this gap.
    # Round residual to nearest integer and look up its empirical probability.
    ri = np.rint(r).astype(np.int64)
    ri = np.clip(ri, 0, 100)
    reuse = _norm_hist[ri]

    # Penalize truly unusable slivers: positive residual below smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -r - 0.5 * tiny + 5.0 * exact + 12.0 * reuse

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

