# EVOLVE-BLOCK-START
"""Best-fit with a small empirical exact-fill bonus keyed to recent item sizes."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_recent = np.zeros(101, dtype=np.float64)  # recency-weighted size frequencies
_median = 40.0
_min_item = 1.0

DECAY = 0.97


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0
    _recent *= DECAY
    _recent[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Primary term: best fit (prefer smallest residual).
    score = -r

    # Small bonus for exact fit.
    exact = (r < 0.5).astype(np.float64)
    score += 1.5 * exact

    # Bonus when residual can likely be filled exactly later: residual equals
    # a recently-seen item size, scaled by its recency frequency.
    ri = np.rint(r).astype(np.int64)
    valid = (ri >= 1) & (ri <= 100)
    fs = np.zeros_like(r)
    ri_clip = np.clip(ri, 0, 100)
    fs[valid] = _recent[ri_clip[valid]]
    fs = fs / (fs.max() + 1e-9)
    score += 0.6 * fs

    # Penalize unusable slivers (residual positive but too small to fit any
    # future item, approximated by the empirical minimum).
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)
    score -= 0.35 * tiny

    # Strong tie-break toward fuller placements.
    score = score - 1e-4 * r

    return score
# EVOLVE-BLOCK-END
