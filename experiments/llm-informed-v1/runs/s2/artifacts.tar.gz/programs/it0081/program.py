# EVOLVE-BLOCK-START
"""Best-fit backbone with distribution-aware sliver penalty and usable-gap bonus."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_q25 = 25.0   # empirical first quartile item size
_q50 = 40.0   # empirical median item size
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _hist, _n, _q25, _q50, _min_item

    _hist[item] += 1.0
    _n += 1

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        _q25 = float(np.searchsorted(cdf, 0.25 * total) + 1)
        _q50 = float(np.searchsorted(cdf, 0.50 * total) + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_q50, 100.0), 1.0)
    small = max(min(_q25, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # residual after placement, >= 0

    # Exact fit: free capacity, strongly reward.
    exact = (r < 0.5).astype(np.float64)

    # Best-fit backbone: prefer smallest residual.
    score = -r

    # Penalize unusable slivers: residual positive but below the typical small item.
    sliver = np.where((r > 0) & (r < small), small - r, 0.0)

    # Reward residuals big enough to host a typical item later (usable gap).
    usable = (r >= typical).astype(np.float64)

    # Penalize positive residuals below the empirical minimum item (never fillable).
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = score - 0.6 * sliver - 0.4 * tiny - 2.0 * usable + 8.0 * exact

    return score
# EVOLVE-BLOCK-END
