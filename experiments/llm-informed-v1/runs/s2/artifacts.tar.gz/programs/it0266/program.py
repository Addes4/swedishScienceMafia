# EVOLVE-BLOCK-START
"""Best-fit core (minimize residual) plus a sharp exact-closure bonus:
a residual equal to a frequently observed future item size is rewarded
because that bin can be closed exactly by one more item. Auxiliary sliver
and tiny penalties use the observed minimum item size. Kept lightweight
and robust, no noisy mean/band terms."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_min_item = 1.0

# Cached frequency table (rebuilt periodically).
_pfreq_tab = np.zeros(101, dtype=np.float64)
_last_build = -1


def _rebuild():
    global _pfreq_tab, _min_item
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _pfreq_tab[:] = _hist / total


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _min_item, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Exact fill: residual 0 -> perfect, huge bonus.
    exact = (r < 0.5).astype(np.float64)

    # Sliver / tiny penalties: residuals too small to be useful.
    sliver = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Best-fit core: prefer the smallest positive residual.
    score = -1.0 * r - 0.5 * sliver + 5.0 * exact

    # Exact-closure bonus: reward residuals equal to a frequent item size.
    if _n >= 30:
        ri = np.clip(np.rint(r), 1.0, 100.0).astype(np.int64)
        score = score + 30.0 * _pfreq_tab[ri]

    return score
# EVOLVE-BLOCK-END
