# EVOLVE-BLOCK-START
"""Best-fit with a light empirical reward for leaving a reusable residual."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_total_items = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _total_items

    if _n == 0:
        _total_items = len(bins)
    _sum += item
    _n += 1
    _hist[item] += 1.0

    # Empirical CDF of sizes seen so far, used to value leftover capacity.
    if _n >= 20:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        # Probability that a random future item is <= x.
        def p_le(x):
            if x <= 0.0:
                return 0.0
            xi = int(min(x, 100.0))
            return cdf[xi - 1] / total
    else:
        def p_le(x):
            if x <= 0.0:
                return 0.0
            return min(x, 100.0) / 100.0

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    exact = (r < 0.5).astype(np.float64)

    # Value of a residual = expected fraction of a future "typical" item that
    # can still fit, weighted so near-total leftovers are preferred but
    # unusable slivers (too small for most items) are penalized.
    fill_val = np.array([p_le(x) for x in r], dtype=np.float64)

    # Penalize slivers: positive residual that can hold only tiny fractions.
    sliver = np.where((r > 0) & (r < 10.0), (10.0 - r) / 10.0, 0.0)

    score = fill_val - 0.8 * sliver + 3.0 * exact
    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

