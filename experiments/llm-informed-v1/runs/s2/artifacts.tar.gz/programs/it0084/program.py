# EVOLVE-BLOCK-START
"""Best-fit backbone with an empirical "residual is a common item size" bonus."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_common = np.zeros(101, dtype=np.float64)  # normalized mass of observed sizes


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _common

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        total = _hist[1:101].sum()
        if total > 0:
            _common[1:101] = _hist[1:101] / total
        cdf = np.cumsum(_hist[1:101])
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Best-fit backbone: nearest residual to zero.
    base = -r

    # Bonus if the residual is itself a plausible future item size: the bin
    # can still be completed exactly by a common item, avoiding stranded gaps.
    ri = np.clip(np.rint(r), 0, 100).astype(np.int64)
    mass = _common[ri]
    # Scale so the bonus is comparable to a few units of residual.
    use_bonus = 6.0 * mass

    # Penalize truly unusable slivers below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = base + use_bonus - 0.5 * tiny + 5.0 * exact

    return score
# EVOLVE-BLOCK-END

