# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus keyed to an empirical upper-quantile item size."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_typical = 40.0
_min_item = 1.0


def _refresh():
    """Recompute the target fill size and empirical minimum from the histogram."""
    global _typical, _min_item
    cdf = np.cumsum(_hist[1:101])
    total = cdf[-1]
    if total <= 0:
        return
    # Upper quantile: a gap of this size is likely to be exactly filled by one
    # of the larger (but not extreme) items, which are common in this Weibull
    # distribution where the mass sits well above the median.
    idx = np.searchsorted(cdf, 0.70 * total)
    _typical = float(idx + 1)
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n % 10 == 0):
        _refresh()

    t = max(min(_typical, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Strongly reward exact fits (no waste).
    exact = (r < 0.5).astype(np.float64)

    # Distance to nearest multiple of the target fill size: gaps that can be
    # filled later by typical items get a bonus.
    k = np.rint(r / t)
    dist = np.minimum(r, np.abs(r - k * t))

    # Residuals smaller than a typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
