# EVOLVE-BLOCK-START
"""Lookahead bin choice: estimate future bins needed from empirical size distribution.

For each candidate bin we compute the residual capacity r = cap - item. We then
estimate how many *future* bins would be consumed to cover that residual, using
the classic harmonic/first-fit continuous bound computed from the empirical item
size histogram. Prefer the bin whose residual leaves the least expected future
work per unit of capacity already committed, i.e. the densest plausible closure.
"""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)   # counts of item sizes seen
_n = 0

# Precomputed distribution-derived quantities (refreshed periodically).
_avg = 40.0
_p = np.full(101, 1.0 / 100.0)   # smoothed size distribution over 1..100


def _refresh():
    """Rebuild smoothed empirical distribution and mean."""
    global _avg, _p
    counts = _hist[1:101]
    total = counts.sum()
    if total < 20:
        return
    # Laplace smoothing so unseen sizes keep small but nonzero probability.
    sm = counts + 0.5
    p = sm / sm.sum()
    _p = p
    sizes = np.arange(1, 101, dtype=np.float64)
    _avg = float(np.dot(p, sizes))


def _expected_waste(residual):
    """Estimate expected leftover capacity when best-filling a residual."""
    # Probability-weighted harmonic estimate of how many items fill a gap.
    # Approximate E[waste] via E[len] - sum over achievable lengths.
    if residual <= 0:
        return 0.0
    # Build cumulative distribution of achievable sums up to residual using
    # the "expected number of items" continuous approximation:
    # min number of bins to pack residual capacity is roughly residual/mean
    # but a residual slightly above an integer number of typical items is bad.
    #
    # Here we use a simple density argument: the fraction of capacity in the
    # residual that is plausibly filled equals the probability the residual is
    # reachable closely by sums of item sizes. Reward residuals whose value
    # equals a common item size or integer combination.
    sizes = np.arange(1, 101, dtype=np.float64)
    # kernel: probability mass near this residual modulo any single item
    d = np.abs(residual - sizes)
    single = float(np.exp(-(d * d) / (2.0 * 4.0 * 4.0)).dot(_p))
    # Also reward residuals near integer multiples of the mean.
    if _avg > 0:
        k = round(residual / _avg)
        dk = abs(residual - k * _avg)
        multi = float(np.exp(-(dk * dk) / (2.0 * 8.0 * 8.0)))
    else:
        multi = 0.0
    return single + 0.5 * multi


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n
    _n += 1
    _hist[item] += 1.0
    if _n % 25 == 0 or _n == 30:
        _refresh()

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    r = residual

    # Exact fit: maximal immediate reward.
    exact = (r < 0.5).astype(np.float64)

    # Fillability of the resulting residual by future single/multiple items.
    fill = _expected_waste(r)

    # Penalize unusable slivers (residual that no single item can use and is
    # too small to be worth keeping).
    sliver = np.where((r > 0) & (r < 0.5 * _avg), (0.5 * _avg - r) / max(_avg, 1.0), 0.0)

    score = fill - 0.6 * sliver + 3.0 * exact

    # Tie-break: mildly prefer fuller bins (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

