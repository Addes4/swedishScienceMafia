# EVOLVE-BLOCK-START
"""Best fit with a mild consolidation bonus toward fuller existing bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining_after = bins - item
    fullness = 100 - bins
    return -(remaining_after) + 0.05 * fullness
# EVOLVE-BLOCK-END
