# EVOLVE-BLOCK-START
"""Best-fit with exact-fit reward, sliver penalty, and empirical peak-residual bonus."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_peak = 40.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _peak

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        # Smallest observed item size so far (empirical minimum).
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        # Empirical mode (most common item size seen so far).
        pk = int(np.argmax(_hist[1:101]))
        _peak = float(pk + 1)

    typical = max(min(_median, 100.0), 1.0)
    peak = max(min(_peak, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Distance to nearest multiple of typical fill size: gaps that can be
    # filled later by typical items get a bonus.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Residuals smaller than a typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Bonus if residual exactly matches a common (modal) item size.
    peakfit = np.where(np.abs(r - peak) < 0.5, 1.0, 0.0)

    score = -(dist + 0.9 * sliver + 0.6 * tiny) + 5.0 * exact + 0.6 * peakfit

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
