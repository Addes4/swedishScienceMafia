# EVOLVE-BLOCK-START
"""Best-fit restricted to residuals that remain reachable by the item
distribution: rank bins by the smallest "usable" residual after placing."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n

    _sum += item
    _n += 1
    _hist[item] += 1.0

    residual = bins.astype(np.float64)

    # Usable residual: 0 if we can finish a bin, else the residual itself.
    # Reward keeping bins packed tight (best-fit) and finishing bins.
    score = -residual + 1e-9 * 0.0

    # Strong preference for exact fits.
    exact = (residual < 0.5).astype(np.float64)
    score = score + 1000.0 * exact

    return score
# EVOLVE-BLOCK-END
