# EVOLVE-BLOCK-START
"""Best-fit backbone plus empirical "completability" of the residual gap."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)   # counts of item sizes seen
_median = 40.0
_min_item = 1.0
_mean = 40.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _median, _min_item, _mean

    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        _mean = float(np.dot(np.arange(1, 101), _hist[1:101]) / total)

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # --- Backbone: best fit (minimize residual), strongly. ---
    score = -r

    # --- Exact fit: dominant reward. ---
    exact = (r < 0.5).astype(np.float64)
    score += 1e6 * exact

    # --- Completability of the residual: reward gaps that can still host
    #     a typical future item, especially gaps close to a common item size
    #     (so the bin gets refilled) or near 0/typical boundary. ---
    # Probability mass of item sizes <= r, and density-ish near r.
    t = typical
    # Reward residual near an integer multiple of the median: such a gap can
    # be cleaned out by one or more typical items.
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    # Also reward residual exactly equal to a frequently seen item size
    # (that bin can absorb a future item cleanly, freeing the bin).
    fr = _hist[np.clip(r.astype(np.int64), 1, 100)] / max(_n, 1.0)

    # Penalize unusable slivers (smaller than any item we've seen).
    sliver = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score -= 0.05 * dk
    score -= 0.10 * sliver
    score += 2.0 * fr

    # Mild tie-break toward fuller placements.
    score -= 1e-3 * r

    return score
# EVOLVE-BLOCK-END

