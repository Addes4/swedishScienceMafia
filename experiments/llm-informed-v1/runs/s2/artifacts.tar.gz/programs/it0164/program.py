# EVOLVE-BLOCK-START
"""Best-fit with unusable-sliver cascade, keyed to empirical min item size."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _hist, _n, _min_item

    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins

    m = _min_item
    r = residual

    # Exact fits: closing a bin exactly is always best.
    exact = (r < 0.5).astype(np.float64)

    # A residual is "usable" if some future item (min size seen) can still enter.
    usable = (r >= m).astype(np.float64)

    # For usable placements: pure best-fit (prefer smallest residual).
    # For unusable slivers: prefer the *smallest* positive residual so we pack
    # the slack into already-nearly-full bins and keep big bins flexible.
    # Combine: primary = -residual, but add a penalty for unusable residuals
    # to push them behind usable ones.
    score = -r + 5.0 * exact - 100.0 * (1.0 - usable) * (r > 0.5)

    # Tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

