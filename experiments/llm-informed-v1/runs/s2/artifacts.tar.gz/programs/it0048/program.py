# EVOLVE-BLOCK-START
"""Best-fit augmented with exact-completion bonuses from observed small item sizes."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_e = 0.0  # second smallest observed item


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _e

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
            _e = float(nz[1] + 1) if nz.size > 1 else _min_item

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Distance to nearest multiple of typical fill size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    # Residuals smaller than a typical item can never be used -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Bonus: residual exactly fillable by one small item, or by a small item
    # plus the next-smallest, i.e. completable without opening a new bin soon.
    a = _min_item
    b = _e
    comp1 = (np.abs(r - a) < 0.5).astype(np.float64)
    comp2 = (np.abs(r - (a + b)) < 0.5).astype(np.float64)
    comp = 1.5 * comp1 + 1.0 * comp2

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact + comp

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
