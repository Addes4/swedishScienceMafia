# EVOLVE-BLOCK-START
"""Best-fit backbone plus empirical fillability bonus from the observed histogram."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_min_item = 1.0
_prob = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _min_item, _prob

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        total = _hist[1:101].sum()
        if total > 0:
            _prob[1:101] = _hist[1:101] / total
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Best-fit backbone: prefer smaller usable residual.
    score = -r

    # Exact fill bonus.
    score = score + 5.0 * (r < 0.5)

    # Empirical fillability: reward residuals that the observed item
    # distribution could exactly complete later.
    ri = r.astype(np.int64)
    valid = (r > 0) & (r <= 100)
    fill = np.where(valid, _prob[np.clip(ri, 0, 100)], 0.0)
    score = score + 3.0 * fill

    # Penalize unusable slivers below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)
    score = score - 0.2 * tiny

    # Tiny tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
