# EVOLVE-BLOCK-START
"""Best-fit backbone with an item-centric usable-gap bonus."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_min_item = 100.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _min_item

    _n += 1
    _hist[item] += 1.0
    if item < _min_item:
        _min_item = float(item)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Exact fits are strongly preferred (no waste, no fragmentation).
    exact = (r < 0.5).astype(np.float64)

    # Item-centric "usable gap" bonus: residuals that can be exactly filled by
    # copies of the current item size are attractive for small items.
    t = float(item)
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    dist = np.minimum(r, dk)

    # Residuals smaller than the smallest item seen can never be reused.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    large = item > 50
    if large:
        # For large items, pure best-fit: minimize residual.
        score = -r
    else:
        score = -(dist + 0.5 * tiny)

    score = score + 5.0 * exact
    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
