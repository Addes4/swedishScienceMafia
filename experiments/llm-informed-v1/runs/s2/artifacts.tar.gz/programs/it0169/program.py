# EVOLVE-BLOCK-START
"""Best-fit with a histogram-weighted future-fit score for the residual."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n

    _hist[item] += 1.0
    _n += 1

    r = bins.astype(np.float64) - item  # residual for every shown bin

    # Empirical probability weights over item sizes seen so far.
    if _n >= 30:
        c = _hist[1:101]
        total = c.sum()
        if total > 0:
            w = c / total
        else:
            w = None
    else:
        w = None

    # Reward residuals that can still be filled by likely future items.
    # future_fit[b] = sum of weights of sizes <= residual[b].
    if w is not None:
        cdf = np.cumsum(w)  # cdf[k] = P(size <= k+1)
        ridx = np.clip(r.astype(np.int64), 0, 100) - 1
        ridx = np.clip(ridx, 0, 99)
        future_fit = cdf[ridx]
    else:
        future_fit = np.where(r >= 0.5, 1.0, 0.0)

    # Exact fit: capacity fully consumed, always good.
    exact = (r < 0.5).astype(np.float64)

    # Primary signal: prefer residuals matching common future items; then
    # fall back to best-fit (smallest residual) for tie-breaking.
    score = future_fit + 2.0 * exact - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

