# EVOLVE-BLOCK-START
"""Best-fit backbone with exact-fit bonus and an empirical 'expected leftover' term."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_psmall = np.zeros(101, dtype=np.float64)  # P(item < r) estimates, updated lazily


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _psmall

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        if total > 0:
            idx = np.searchsorted(cdf, 0.5 * total)
            _median = float(idx + 1)
            # P(random future item < s) for s = 0..100 (strictly less than s).
            # cdf counts items with size <= s, so strictly-less-than s is cdf at s-1.
            p = np.empty(101, dtype=np.float64)
            p[0] = 0.0
            p[1:101] = cdf[0:100] / total
            _psmall = p
            nz = np.nonzero(_hist[1:101])[0]
            if nz.size > 0:
                _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)
    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    exact = (r < 0.5).astype(np.float64)

    # Estimate probability that the residual becomes a permanent sliver:
    # roughly P(item < r) weighted toward small residuals. The residual is
    # "usable" if a future item fits into it; the leftover waste is the
    # expected smallest unfillable remainder.
    ri = np.clip(np.rint(r).astype(np.int64), 0, 100)
    p_smaller = _psmall[ri]

    # Expected fraction of the residual that will stay wasted: small residuals
    # are mostly waste; large residuals up to full bins are good (best-fit).
    waste = p_smaller * r

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Best-fit backbone: prefer smallest usable residual.
    score = -r - 0.5 * waste - 0.5 * tiny + 5.0 * exact

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END

