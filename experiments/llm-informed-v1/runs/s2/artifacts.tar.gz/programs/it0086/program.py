# EVOLVE-BLOCK-START
"""Best-fit backbone with exact-fit reward and stronger sliver avoidance."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _min_item

    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Strong reward for exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Penalize residuals that are too small to ever be useful.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Best-fit distance + exact reward + sliver penalty.
    score = -r + 5.0 * exact - 2.0 * tiny

    return score
# EVOLVE-BLOCK-END

