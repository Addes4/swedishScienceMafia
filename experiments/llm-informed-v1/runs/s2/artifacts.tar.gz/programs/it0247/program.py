# EVOLVE-BLOCK-START
"""Best-fit with a strong exact-fill bonus, a sliver penalty, and a
harmony-style waste-fraction term. Kept intentionally simple: past
experiments showed that extra histogram/multiples terms hurt."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0
_last_build = -1


def _rebuild():
    global _median, _min_item, _mean
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    cdf = np.cumsum(_hist[1:101])
    idx = np.searchsorted(cdf, 0.5 * total)
    _median = float(idx + 1)
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _mean = _sum / _n


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _mean, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    typical = max(min(_median, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Exact fill: residual is 0 -> perfect, huge bonus.
    exact = (r < 0.5).astype(np.float64)

    # Best-fit core: prefer the smallest residual (tightest placement).
    score = -r

    # Sliver penalty: too small to be usefully filled.
    sliver = np.where((r > 0) & (r < 0.5 * typical), 0.5 * typical - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = score - 0.75 * sliver - 0.5 * tiny

    # Harmony-style waste fraction term.
    used = 100.0 - r
    frac = np.where(used > 0, r / used, 0.0)
    score = score - 1.5 * frac

    # Strong bonus for exact completion.
    score = score + 5.0 * exact

    return score
# EVOLVE-BLOCK-END

