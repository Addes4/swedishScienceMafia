# EVOLVE-BLOCK-START
"""Best-fit backbone augmented with a distribution-aware expected-wastage term.

For each candidate residual r (after placing the current item), we estimate how
much capacity is likely to be wasted in that bin given the empirical item-size
distribution seen so far. The score combines a pure best-fit backbone (smaller
residual is better) with a value that rewards residuals likely to be filled by
future typical items.
"""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
# Cache for the lookahead value table; invalidated every few observations.
_value = None
_value_version = -1
_version = 0


def _build_value_table():
    """value[r] = expected usable fill probability-weighted score for residual r."""
    global _value, _value_version
    total = _hist[1:101].sum()
    if total <= 0:
        probs = np.ones(100, dtype=np.float64) / 100.0
    else:
        probs = _hist[1:101] / total

    # Expected future "waste" if we leave residual r in a bin: approximate by
    # the mean of (r mod s) over item sizes s weighted by probability, plus a
    # penalty for residuals that cannot be filled by any item at all.
    sizes = np.arange(1, 101, dtype=np.float64)
    r_vals = np.arange(0, 101, dtype=np.float64)

    # rem[r, s] = leftover after greedily packing items of size s into residual r
    rem = r_vals[:, None] % sizes[None, :]

    # Probability-weighted expected leftover residual.
    exp_waste = rem @ probs  # shape (101,)

    # A residual is "usable" if some frequent item can still fit into it.
    usable_mass = (sizes[None, :] <= r_vals[:, None]).astype(np.float64) @ probs

    val = -(exp_waste) + 2.0 * usable_mass

    _value = val
    _value_version = _version


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _version

    _sum += item
    _n += 1
    _hist[item] += 1.0
    _version += 1

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    # Build (and cache) the residual-value lookup table.
    if _value is None or (_version - _value_version) >= 25:
        _build_value_table()

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    r_int = np.clip(np.rint(r).astype(np.int64), 0, 100)
    table_val = _value[r_int]

    # Pure best-fit backbone: smaller residual is better.
    best_fit = -r

    # Exact fits are strictly optimal (no waste).
    exact = (r < 0.5).astype(np.float64)

    # Truly unusable slivers below the smallest item are penalized.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    score = best_fit + 1.5 * table_val + 3.0 * exact - 0.75 * tiny

    # Small tie-break toward fuller placements.
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
