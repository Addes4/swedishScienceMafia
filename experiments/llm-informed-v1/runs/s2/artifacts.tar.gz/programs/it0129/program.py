# EVOLVE-BLOCK-START
"""Best-fit with an empirical fillability bonus for the residual it leaves."""
import numpy as np

# Module-level state (fresh per instance).
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_median = 40.0
_min_item = 1.0
# fillable[r] ~ probability that some future item has size exactly r
_fillable = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _median, _min_item, _fillable

    _hist[item] += 1.0
    _n += 1

    if _n >= 20:
        total = float(_n)
        # Empirical probability mass at each exact residual value.
        _fillable = _hist / total

        cdf = np.cumsum(_hist[1:101])
        idx = np.searchsorted(cdf, 0.5 * cdf[-1])
        _median = float(idx + 1)

        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    t = max(min(_median, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # residual, >= 0 for shown bins

    # Best-fit backbone: prefer small usable residual.
    score = -r

    ri = np.clip(np.rint(r), 0, 100).astype(np.int64)

    # Bonus if the residual matches a frequently seen exact item size
    # (so a later item can complete the bin perfectly).
    score += 3.0 * _fillable[ri]

    # Big bonus for an exact fit (no waste at all).
    exact = (r < 0.5).astype(np.float64)
    score += 5.0 * exact

    # Penalize unusable positive slivers below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)
    score -= 0.5 * tiny

    # Penalty for residuals far from any typical fill multiple of the median.
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    dist = np.minimum(r, dk)
    score -= 0.15 * dist

    return score
# EVOLVE-BLOCK-END
