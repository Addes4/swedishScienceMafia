# EVOLVE-BLOCK-START
"""Best-fit with reuse-aware ordering keyed to the empirical 25th percentile."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_q25 = 20.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _q25

    _n += 1
    _hist[item] += 1.0

    if _n >= 50:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.25 * total)
        _q25 = float(max(idx + 1, 1))

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    reuse_floor = _q25

    # Buckets: exact fit best, then reusable gaps, then tiny/unusable gaps.
    exact = (r < 0.5).astype(np.float64)
    reusable = ((r >= reuse_floor) & (r >= 0.5)).astype(np.float64)

    score = 2.0 * exact + 1.0 * reusable

    # Within a bucket, prefer the fullest bin (smallest residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
