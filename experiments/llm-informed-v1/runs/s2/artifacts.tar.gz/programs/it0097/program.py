# EVOLVE-BLOCK-START
"""Best-fit with sum-of-squares gap shaping and exact-fit reward."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_total_items = 0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _total_items

    _sum += item
    _n += 1
    _hist[item] += 1.0
    if _total_items == 0:
        _total_items = len(bins)

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        if total > 0:
            idx = np.searchsorted(cdf, 0.5 * total)
            _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(_median, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # residual after placing (>=0)

    # Exact fit is ideal.
    exact = (r < 0.5).astype(np.float64)

    # Sum-of-squares style: prefer leaving the smallest squared residual
    # (concentrates gaps into few large holes rather than many mid gaps).
    # Normalize roughly to [0,1].
    sq = (r / 100.0) ** 2

    # Penalize residuals too small to be useful but nonzero.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0) / 100.0

    # Reward residuals that are near multiples of typical fill size (cleanly
    # completable), using distance only as a mild shaping term.
    t = typical
    k = np.rint(r / t)
    dist = np.abs(r - k * t) / 100.0

    score = -(sq + 0.5 * tiny + 0.15 * dist) + 5.0 * exact

    # Small tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
