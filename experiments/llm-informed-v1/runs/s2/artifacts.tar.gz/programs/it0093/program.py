# EVOLVE-BLOCK-START
"""Best-fit with exact-fit reward plus empirical residual-fillability bonus."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits (free capacity, no waste).
    exact = (r < 0.5).astype(np.float64)

    # Empirical fillability: probability that a future item exactly equals r,
    # estimated from the observed histogram of item sizes. High mass -> the
    # residual gap is likely to be closed cleanly by a later item.
    total = _hist[1:101].sum()
    if total > 0:
        counts = _hist[1:101]
        # normalized mass for integer residual values 1..100
        prob = counts / total
    else:
        prob = np.zeros(100, dtype=np.float64)

    ri = np.clip(np.rint(r).astype(np.int64), 0, 100)
    mass = np.where((ri >= 1) & (ri <= 100), prob[np.clip(ri - 1, 0, 99)], 0.0)

    # Residuals smaller than the smallest item seen can never be used -> penalize.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Normalize r for the best-fit tie-break term.
    score = -r + 20.0 * mass + 5.0 * exact - 0.5 * tiny

    return score
# EVOLVE-BLOCK-END
