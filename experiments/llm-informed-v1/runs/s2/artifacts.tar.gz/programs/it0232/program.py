# EVOLVE-BLOCK-START
"""Best-fit with usable-gap bonus and an online empirical distribution used
sparingly to reward residuals that are likely to be filled exactly by the
next item. Backed by a periodically rebuilt lookup table to stay fast."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_mean = 40.0
_pmax = 0.02
_q25 = 25.0
_q75 = 55.0

_near_tab = np.zeros(101, dtype=np.float64)   # P(next item == rounded residual)
_band_tab = np.zeros(101, dtype=np.float64)   # smooth completion kernel
_last_build = -1


def _rebuild():
    global _near_tab, _band_tab, _median, _min_item, _mean, _pmax, _q25, _q75
    total = float(np.sum(_hist[1:101]))
    if total <= 0:
        return
    cdf = np.cumsum(_hist[1:101])
    idx = np.searchsorted(cdf, 0.5 * total)
    _median = float(idx + 1)
    i25 = np.searchsorted(cdf, 0.25 * total)
    i75 = np.searchsorted(cdf, 0.75 * total)
    _q25 = float(i25 + 1)
    _q75 = float(i75 + 1)
    nz = np.nonzero(_hist[1:101])[0]
    if nz.size > 0:
        _min_item = float(nz[0] + 1)
    _mean = _sum / _n
    _pmax = max(float(np.max(_hist[1:101]) / total), 1e-3)

    # P(next item == r): modest, directly targets exact completion without
    # the spikiness of a full per-size match bonus.
    _near_tab[:] = _hist / total

    # Gently smoothed kernel over the common item-size band for soft guidance.
    lo, hi = _q25, _q75
    width = max(hi - lo, 1.0) * 0.5 + 1.0
    mid = 0.5 * (lo + hi)
    x = np.arange(101, dtype=np.float64)
    _band_tab[:] = np.exp(-((x - mid) ** 2) / (2.0 * width * width))


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _mean, _pmax, _q25, _q75, _last_build

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n - _last_build >= 200 or _last_build < 0):
        _rebuild()
        _last_build = _n

    typical = max(min(_median, 100.0), 1.0)
    mean = max(min(_mean, 100.0), 1.0)

    r = bins.astype(np.float64) - item  # >= 0 for all shown bins

    exact = (r < 0.5).astype(np.float64)

    # Distance of residual to multiples of a typical item size.
    t = typical
    k = np.rint(r / t)
    dk = np.abs(r - k * t)
    d0 = r
    dist = np.minimum(d0, dk)

    fit_future = np.abs(r - mean)

    sliver = np.where((r > 0) & (r < 0.5 * t), 0.5 * t - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    used = 100.0 - r
    frac = np.where(used > 0, r / used, 0.0)

    score = -(dist + 0.75 * sliver + 0.5 * tiny) + 5.0 * exact
    score = score - 1.0 * fit_future * 0.05
    score = score - 1.5 * frac

    if _n >= 30:
        # Direct exact-completion probability for the next item (small weight).
        ri = np.clip(np.rint(r), 1.0, 100.0).astype(np.int64)
        p_exact = _near_tab[ri]
        # fractional distance to that integer size
        near = np.exp(-((r - ri) ** 2) / (2.0 * 1.0))
        score = score + 4.0 * p_exact * near

        # Very gentle pull toward the common item-size band.
        ri2 = np.clip(r, 0.0, 100.0)
        score = score + 0.15 * np.interp(ri2, np.arange(101, dtype=np.float64), _band_tab)

    score = score + 20.0 * _pmax * exact
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
