# EVOLVE-BLOCK-START
"""Best-fit backbone with an empirical value-of-residual estimate."""
import numpy as np

# Module-level state (fresh per instance).
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_pmf = None  # normalized pmf over sizes 1..100, refreshed periodically
_refresh = 0


def _build_pmf():
    total = _hist[1:101].sum()
    if total <= 0:
        return np.full(101, 1.0 / 100.0)
    return _hist / total


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _n, _pmf, _refresh

    _n += 1
    _hist[item] += 1.0

    if _pmf is None or _refresh <= 0:
        _pmf = _build_pmf()
        _refresh = 25
    _refresh -= 1

    residual = bins.astype(np.float64) - item  # >= 0 for shown bins

    # Empirical value of a residual c: expected number of items that fit into a
    # slot of size c (approximated via the mean number of expected fills using
    # the empirical distribution restricted to sizes <= c).
    pmf = _pmf
    cdf = np.cumsum(pmf)              # cdf[s] = P(size <= s)
    cdf[100] = 1.0

    # Vectorized expected fill count for each residual value.
    # value(c) = sum_{s<=c} p(s) * (1 + value(c - s)), capped by c.
    # Use a simple DP over integer capacities 0..100.
    val = np.zeros(101, dtype=np.float64)
    for c in range(1, 101):
        ps = pmf[1:c + 1]
        ss = np.arange(1, c + 1)
        acc = 0.0
        if ps.sum() > 0:
            acc = np.dot(ps, 1.0 + val[c - ss])
        val[c] = acc

    ci = np.clip(np.rint(residual).astype(np.int64), 0, 100)

    # Value of packing now (we consume this bin) vs leaving residual.
    # We prefer bins where placing here leaves a residual of high future value,
    # but also prefer tight fits (small residual) as a tie-break.
    score = val[ci]

    # Best-fit tie-break: mildly prefer smaller residual.
    score = score - 1e-3 * residual

    return score
# EVOLVE-BLOCK-END
