# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus, sliver penalties, and a histogram-based
"residual matches a common item size" reward to encourage near-perfect packing."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item

    _sum += item
    _n += 1
    _hist[item] += 1.0

    typical = _median
    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        typical = _median
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)

    typical = max(min(typical, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Strongly reward exact fits.
    exact = (r < 0.5).astype(np.float64)

    # Residuals smaller than a typical item can never be used again -> penalize.
    sliver = np.where((r > 0) & (r < 0.5 * typical), 0.5 * typical - r, 0.0)

    # Truly unusable slivers: positive residual below the smallest item seen.
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)

    # Reward residuals that look like a likely future item size (fillable gap).
    ri = np.rint(r).astype(np.int64)
    valid = (ri >= 1) & (ri <= 100) & (np.abs(r - ri) < 1.0)
    idxs = np.clip(ri, 1, 100)
    prob = np.where(valid, _hist[idxs] / max(_n, 1), 0.0)

    # Best-fit backbone: prefer smallest usable residual.
    score = -r + 4.0 * exact + 0.4 * prob - 2.0 * sliver - 1.0 * tiny

    return score
# EVOLVE-BLOCK-END

