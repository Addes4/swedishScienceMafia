# EVOLVE-BLOCK-START
"""Best-fit with a mild preference against opening fresh bins."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties).

    item: integer size of arriving item (1..100).
    bins: remaining capacity of every bin the item fits in (inclusive of unused = 100).
    """
    global _sum, _n

    _sum += item
    _n += 1
    mean = _sum / _n

    residual_full = bins.astype(np.float64) - item  # >= 0 for all shown bins

    # Best fit: smallest residual gets the highest score.
    score = -residual_full

    # Slight preference against opening brand-new bins (residual_full == 100 - item
    # implies the bin was empty). This keeps bin count lower early on.
    empty_resid = 100.0 - item
    is_empty = (bins >= 100).astype(np.float64)
    score = score - 0.1 * is_empty

    return score
# EVOLVE-BLOCK-END
