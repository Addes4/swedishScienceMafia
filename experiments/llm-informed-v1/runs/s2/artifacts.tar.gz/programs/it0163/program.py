# EVOLVE-BLOCK-START
"""Best-fit backbone with a light, smoothed exact-fit continuation reward."""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_min_item = 1.0
_pmf = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n, _median, _min_item, _pmf

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30:
        cdf = np.cumsum(_hist[1:101])
        total = cdf[-1]
        idx = np.searchsorted(cdf, 0.5 * total)
        _median = float(idx + 1)
        nz = np.nonzero(_hist[1:101])[0]
        if nz.size > 0:
            _min_item = float(nz[0] + 1)
        # Smoothed PMF over item sizes (add-one smoothing across 1..100).
        pmf = (_hist[1:101] + 1.0)
        pmf /= pmf.sum()
        _pmf = pmf

    typical = max(min(_median, 100.0), 1.0)

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Exact fit: free capacity, no waste.
    exact = (r < 0.5).astype(np.float64)

    # Best-fit primary term: prefer smallest usable residual.
    score = -r

    # Strongly reward exact fits.
    score = score + 5.0 * exact

    # Penalize residuals too small to ever be used by a future item.
    sliver = np.where((r > 0) & (r < 0.5 * typical), 0.5 * typical - r, 0.0)
    tiny = np.where((r > 0) & (r < _min_item), _min_item - r, 0.0)
    score = score - 0.75 * sliver - 0.5 * tiny

    # Light reward if the leftover residual is itself a likely future item size
    # (so the bin can probably be closed exactly later). Kept small to avoid noise.
    if _n >= 30:
        ri = np.clip(np.rint(r).astype(np.int64), 1, 100)
        prob = _pmf[ri - 1]
        score = score + 1.5 * prob

    # Tie-break toward fuller placements (smaller residual).
    score = score - 1e-3 * r

    return score
# EVOLVE-BLOCK-END
