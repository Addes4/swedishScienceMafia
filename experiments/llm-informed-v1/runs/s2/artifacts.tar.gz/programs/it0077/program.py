# EVOLVE-BLOCK-START
"""Best-fit backbone plus an empirical exact-completion bonus.

The key idea: a bin's residual r is valuable if some future item is likely to
land exactly on r (making the bin perfectly full and unusable-but-free), OR if
r is a residual that tends to get exactly completed after one more typical
placement.  We estimate this from the observed item-size histogram, and use it
as a smooth bonus on top of a best-fit backbone.
"""
import numpy as np

# Module-level state (fresh per instance).
_sum = 0.0
_n = 0
_hist = np.zeros(101, dtype=np.float64)
_median = 40.0
_pmf = np.zeros(101, dtype=np.float64)      # smoothed item-size pmf
_exact_prob = np.zeros(101, dtype=np.float64)  # P(residual r can be exactly hit)


def _recompute():
    """Rebuild smoothed pmf and exact-hit probability from the histogram."""
    global _median, _pmf, _exact_prob
    total = _hist[1:101].sum()
    if total <= 0:
        return
    counts = _hist[1:101].copy()
    _pmf[1:101] = counts / total

    # Empirical median.
    cdf = np.cumsum(counts)
    idx = np.searchsorted(cdf, 0.5 * total)
    _median = float(idx + 1)

    # Probability that the residual r can be exactly hit by an immediate item,
    # or by a two-step pattern: item a then item b with a + b == r.
    # approx with a convolution to capture "settle to zero in <=2 items".
    p = _pmf[1:101]
    # 1-step exact hit prob for residual r:
    one = np.zeros(101)
    one[1:101] = p
    # 2-step: prob that some a with p[a]>0 and p[r-a]>0
    two = np.convolve(p, p)  # index k = sum of two sizes
    exact = one.copy()
    for r in range(2, 101):
        # prob of at least one decomposition r = a + b, both in support
        # approx: sum over a of p[a]*p[r-a] but capped at 1
        s = two[r - 2] if (r - 2) < len(two) else 0.0
        exact[r] = min(1.0, one[r] + s)
    # small floor so every residual keeps a chance
    _exact_prob = exact


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    global _sum, _n

    _sum += item
    _n += 1
    _hist[item] += 1.0

    if _n >= 30 and (_n % 25 == 0 or _exact_prob[1] == 0.0):
        _recompute()

    residual = bins.astype(np.float64) - item  # >= 0 for all shown bins
    r = residual

    # Best-fit backbone: prefer the smallest usable residual.
    # Add an exact-completion bonus: residuals with a good chance of being
    # perfectly filled by 1-2 future items are more valuable.
    prob = _exact_prob[np.clip(residual.astype(np.int64), 0, 100)]

    # Reward exact fits strongly (bin becomes free / perfectly full).
    exact_fit = (r < 0.5).astype(np.float64)

    # Unusable slivers (positive residual below the smallest item seen):
    nz = np.nonzero(_hist[1:101])[0]
    min_item = float(nz[0] + 1) if nz.size > 0 else 1.0
    tiny = np.where((r > 0) & (r < min_item), min_item - r, 0.0)

    # Score: best-fit (small residual) + completion bonus - sliver penalty.
    score = -r + 25.0 * prob + 12.0 * exact_fit - 0.6 * tiny

    return score
# EVOLVE-BLOCK-END
