# EVOLVE-BLOCK-START
"""Best fit with a smooth near-exact-fit reward and mild remainder shaping."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Base best fit: smaller remainder is better.
    score = -rem
    # Reward near-exact fills (remainder close to 0) smoothly.
    score += 3.0 * np.exp(-rem / 3.0)
    # Mildly penalize leaving a moderately large remainder (avoid wasting bins
    # on mediocre fits) using a small linear tilt on large remainders.
    score -= 0.03 * rem
    return score
# EVOLVE-BLOCK-END

