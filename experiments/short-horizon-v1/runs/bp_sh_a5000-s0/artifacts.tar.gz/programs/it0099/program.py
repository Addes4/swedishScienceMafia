# EVOLVE-BLOCK-START
"""Distribution-aware best fit: exact fits first, then reusable-gap target.

Items come from a fixed Weibull-shaped distribution with mean about 40, but the
density is skewed: most items are well below the mean.  Ranking leftover gaps by
distance to the mean strands many gaps that could hold a small item.  Instead:
  1. exact fills (remainder 0) get top priority;
  2. among the rest, prefer the post-placement remainder closest to a target
     derived from the lower part of the distribution (so common small items can
     reuse the gap), using an online estimate of that target.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0, "small": 25.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    n = _state["n"]
    m = _state["mean"]
    s = _state["small"]
    fi = float(item)
    # Online estimates: overall mean and a lower-target (items below the mean).
    _state["mean"] = (m * n + fi) / (n + 1.0)
    alpha = 0.01
    if fi <= m:
        _state["small"] = (1.0 - alpha) * s + alpha * fi
    _state["n"] = n + 1.0

    target = _state["small"]
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Prefer leftovers close to a typical small item size (reusable gaps).
    gap_score = -np.abs(rem - target)

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return gap_score + exact_bonus
# EVOLVE-BLOCK-END
