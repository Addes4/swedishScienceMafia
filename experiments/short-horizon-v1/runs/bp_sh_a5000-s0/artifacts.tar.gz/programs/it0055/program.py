# EVOLVE-BLOCK-START
"""Best fit with a concave near-zero emphasis on the post-placement remainder.

Ranking a bin by the post-placement remainder r = rem - item is equivalent to
plain best fit.  We add a bounded bonus b(r) that is largest at r = 0 and decays
to zero for larger r, so that exact/near-exact fills are strictly preferred over
merely-small remainders, without disturbing the best-fit ordering among bins
whose remainders are all large.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Dominant term: best fit (smaller remainder is better).
    # Bonus: concave in (100 - rem) so it rises steeply for very small
    # remainders and saturates for large ones; this targets exact fills while
    # keeping the relative order of large remainders essentially unchanged.
    # weight is small enough that it never overrides a strict best-fit win
    # by a non-trivial margin, but sharp enough near zero to matter.
    bonus = 0.06 * np.sqrt(np.maximum(0.0, 20.0 - rem))

    return -rem + bonus
# EVOLVE-BLOCK-END

