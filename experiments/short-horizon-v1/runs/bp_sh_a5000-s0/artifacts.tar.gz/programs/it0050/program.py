# EVOLVE-BLOCK-START
"""Best fit, lightly augmented by expected-waste from a fitted item distribution.

The dominant term is classic best fit (prefer the smallest post-placement
remainder). On top we add a small correction based on the expected number of
future items that will fit in the remainder, computed from the marginal
distribution of a single item (Weibull-shaped, mean ~40). This nudges ties and
near-ties toward remainders that are more likely to be usefully reused.
"""
import numpy as np

# Precompute the marginal pmf of item sizes for a Weibull(shape~1.4, scale~44)
# truncated to integers 1..100 (mean ~40). This is a fixed, distribution-level
# prior, so it needs no per-stream state.
_SIZE_GRID = np.arange(1, 101, dtype=np.float64)


def _weibull_pmf():
    # Lightweight Weibull-like pmf over 1..100 with support mass mean ~40.
    k, lam = 1.4, 44.0
    # Weibull pdf on continuous support, discretized to integer sizes.
    pdf = (k / lam) * (_SIZE_GRID / lam) ** (k - 1.0) * np.exp(-(_SIZE_GRID / lam) ** k)
    # Single point at size 100 to absorb overflow mass (items >100 impossible).
    pmf = pdf / pdf.sum()
    return pmf


_PMF = _weibull_pmf()
# Expected count of a future single item that fits in remainder r is the
# cumulative pmf up to r, scaled to a per-item count in [0, 1].
_CDF = np.cumsum(_PMF)

_CDF_TABLE = np.concatenate([[0.0], _CDF])  # index by remainder 0..100


def priority(item, bins):
    rem = (bins - item).astype(np.int64)  # remaining capacity after placing, 0..100
    # Best fit: smaller remainder is better (negative score dominates).
    score = -rem.astype(np.float64)
    # Small expected-waste correction: expected number of *future* items that
    # would fit in this remainder. A remainder that can swallow more future
    # items is (weakly) better, so add a small positive bonus.
    score += 0.03 * _CDF_TABLE[rem]
    return score
# EVOLVE-BLOCK-END
