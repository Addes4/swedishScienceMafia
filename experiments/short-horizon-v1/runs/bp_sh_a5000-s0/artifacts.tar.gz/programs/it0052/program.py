# EVOLVE-BLOCK-START
"""Best fit with a bonus favoring remainders that can still absorb typical
future items, while keeping best-fit dominant for near-exact fills."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Best fit: smaller remainder is better (negative score).
    score = -rem
    # Bonus: reward remainders that leave room for a typical (~40) future item
    # without being wasteful; peak around the mean item size region.
    score += 0.05 * np.exp(-((rem - 40.0) ** 2) / (2.0 * 15.0 ** 2))
    # Strong bonus for near-exact fills.
    score -= 0.02 * (100.0 - rem) * (rem < 5)
    return score
# EVOLVE-BLOCK-END
