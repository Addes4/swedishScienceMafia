# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware "usable remainder" emphasis.

We still favor small remainders (best fit), but we add a small bonus for bins
whose post-placement remainder is at least the smallest item size we have seen
so far. Such remainders can still be filled by future small items; remainders
just below the smallest seen size tend to become stranded waste.
"""
import numpy as np

_state = {"min_seen": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    if item < _state["min_seen"]:
        _state["min_seen"] = item
    min_seen = _state["min_seen"]

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Best fit: smaller remainder is better (negative score).
    score = -rem

    # Small bonus for remainders that are still >= the smallest item seen, so
    # the leftover gap remains fillable by a future small item.
    score += 0.5 * (rem >= min_seen)

    return score
# EVOLVE-BLOCK-END
