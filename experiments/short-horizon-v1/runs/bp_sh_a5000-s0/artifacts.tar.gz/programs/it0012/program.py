# EVOLVE-BLOCK-START
"""Convex best fit: minimize a mildly superlinear power of the post-placement
remainder, plus a small bonus when the leftover remainder looks like a likely
future item size (so the bin can still be usefully topped off later)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    rem = np.maximum(rem, 0.0)
    # Mildly superlinear penalty: smaller remainder is better, extra convexity
    # sharpens the preference for tight fits without discarding moderate ones.
    score = -(rem ** 1.3)
    # Small bonus: prefer leftovers close to a typical item size (~40), so the
    # remaining space can be filled by a later item rather than being stranded.
    score += 0.5 * np.exp(-((rem - 40.0) ** 2) / (2.0 * 18.0 * 18.0))
    return score
# EVOLVE-BLOCK-END

