# EVOLVE-BLOCK-START
"""Best fit with a tiny quadratic tight-fit bias.

Primary rule: ascending post-placement remainder (classic Best Fit).
Tie-break: a strictly increasing, sub-unit convex bonus toward smaller
remainders, scaled small enough that it can never override a one-unit
difference in remainder. This keeps the online best-fit ordering intact
while gently favoring tighter residual gaps.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # integer post-placement remainder, >= 0
    rem = rem.astype(np.float64)
    # Best fit: smaller remainder is better.
    # Convex bias: reward small remainders smoothly; alpha chosen so that
    # alpha * max(rem^2 - (rem+1)^2 magnitude) < 0.5, never flipping a
    # genuine best-fit advantage of one unit.
    alpha = 0.001
    return -rem - alpha * (100.0 - rem) * (100.0 - rem)
# EVOLVE-BLOCK-END

