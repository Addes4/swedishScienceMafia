# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware tie-breaker.

Only bins the item fits are shown, so we mostly want classic Best Fit
(minimize the post-placement remainder) which packs tightly.  The known
weakness of best fit is the small "leftover dust" it can leave; we add a
small secondary term that mildly prefers leave a remainder that a future
small item can still use, based on an online mean estimate. The secondary
term is small enough that it never overrides best fit.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin; highest wins, ties to first."""
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    rem = (bins - item).astype(np.float64)  # remainder after placing

    # Primary: classic best fit -> smaller remainder is better.
    # Scale so remainder (0..100) dominates the secondary signal.
    best_fit = -rem

    # Secondary: mild preference for leaving a remainder that a typical
    # future small item could still use (rather than near-zero dust).
    # Use a soft floor around a fraction of the mean.
    target = 0.5 * _state["mean"]
    usable = np.minimum(rem, target)  # saturate once the gap is "usable"
    tail_bonus = 0.05 * usable

    return best_fit + tail_bonus
# EVOLVE-BLOCK-END
