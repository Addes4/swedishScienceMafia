# EVOLVE-BLOCK-START
"""Hybrid best-fit with a mild mode-targeted gap bonus.

Items come from a fixed Weibull-shaped distribution (mean ~40).  Pure best
fit minimizes the immediate remainder and is a strong baseline; its weakness
is leaving tiny unusable gaps.  The previous pure target-gap rule fixed some
of that but lost on the overall score.  Here we keep best-fit (dot the
remainder down) as the dominant signal, and add a *small* bonus that nudges
choices toward leaving a remainder close to a typical future item size,
estimated online from a running histogram of past item sizes.  Exact fills
get a strong bonus so fully-closed bins always win.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0, "mode": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0
    # Rolling mode proxy: track an EMA skewed toward typical (smaller) items,
    # which is where the Weibull mass concentrates.
    _state["mode"] = 0.995 * _state["mode"] + 0.005 * float(item)

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Dominant term: classic best fit (prefer the smallest non-negative rem).
    best_fit = -rem

    # Mild correction: prefer remainders near a typical item size so gaps stay
    # reusable.  Scaled small so it only breaks near-ties in the best-fit sense.
    target = _state["mode"]
    gap_bonus = -0.02 * np.abs(rem - target)

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return best_fit + gap_bonus + exact_bonus
# EVOLVE-BLOCK-END
