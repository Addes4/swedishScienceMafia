# EVOLVE-BLOCK-START
"""Best fit with strong preference for exact fills.

Between calls the module keeps no state. The rule is plain best fit (minimize
the post-placement remainder) except that a zero remainder (a perfectly filled
bin) receives a large additional bonus, since exact fills directly reduce the
number of bins required.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    score = -rem
    # Strongly reward exact fills.
    score += 1000.0 * (rem == 0.0)
    return score
# EVOLVE-BLOCK-END
