# EVOLVE-BLOCK-START
"""Best fit with a mild "future-fit" bonus: strongly prefer small remainders,
and additionally reward remainders that a typical future item can fill well."""
import numpy as np

# Typical item size for the Weibull-shaped distribution (mean about 40).
_TYPICAL = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Dominant term: best fit (smaller remainder better).
    score = -rem
    # Small bonus for very tight fills to concentrate packing density.
    score -= 0.02 * (100.0 - rem) * (rem < 5)
    # Mild bonus for remainders that a typical future item can nearly fill
    # (i.e. remainder close to a multiple of the typical size), promoting
    # reuse of bins over opening new ones.
    centered = np.abs(rem - _TYPICAL)
    score -= 0.01 * np.maximum(0.0, 1.0 - centered / _TYPICAL)
    return score
# EVOLVE-BLOCK-END

