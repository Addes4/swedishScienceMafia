# EVOLVE-BLOCK-START
"""Best-fit with exact-fill preference and gap-shaping tie-break.

Items are drawn from a fixed Weibull-shaped distribution with mean about 40.
Pure best fit (smallest post-placement remainder) is a robust near-optimal
online rule for this workload. We keep that as the primary signal, but:
  1. exact fills (remainder 0) are strongly preferred, then
  2. among bins whose remainder is close to the smallest fitting remainder,
     prefer the one whose leftover gap is nearest a typical future item size
     (the online-estimated mean), so gaps stay reusable rather than tiny.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0}
_WINDOW = 8.0  # how close a remainder must be to the minimum to matter for shaping


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Online estimate of the mean item size (starts at 40).
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    target = _state["mean"]
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Primary signal: best fit ranks smaller remainders higher.
    best_fit = -rem

    # Secondary signal: among near-best remainders, prefer a reusable gap size.
    rmin = rem.min()
    near = rem <= (rmin + _WINDOW)
    gap_score = -np.abs(rem - target)
    gap_score = np.where(near, gap_score, -1e9)

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1e6, 0.0)

    return best_fit + gap_score * 0.5 + exact_bonus
# EVOLVE-BLOCK-END
