# EVOLVE-BLOCK-START
"""Capacity-probability best fit: rank bins by ascending post-placement
remainder (best fit), with a bonus for remainders that a future item is
likely to fill exactly, estimated from the known Weibull-like item
distribution (mean ~40, integer sizes 1..100)."""
import numpy as np

# Precompute log-probability of each item size 1..100 under a Weibull-like
# distribution with mean ~40.  Discrete Weibull-ish: use a gamma-like shaped
# pmf truncated to 1..100 and normalized.
_SIZES = np.arange(1, 101, dtype=np.float64)


def _build_pmf():
    # Weibull shape ~ mean 40.  Choose k=1.5, lambda s.t. mean ~40.
    k = 1.5
    # mean of Weibull = lam * Gamma(1 + 1/k)
    from math import gamma
    lam = 40.0 / gamma(1.0 + 1.0 / k)
    pmf = (k / lam) * (_SIZES / lam) ** (k - 1.0) * np.exp(-(_SIZES / lam) ** k)
    pmf = np.where((_SIZES >= 1) & (_SIZES <= 100), pmf, 0.0)
    pmf = np.maximum(pmf, 1e-12)
    pmf /= pmf.sum()
    return pmf


_PMF = _build_pmf()
# cumulative probability that a *single* random item has size <= s
_CDF = np.cumsum(_PMF)
_CDF = np.concatenate(([0.0], _CDF))  # _CDF[s] = P(item <= s), s in 0..100

_LOGPMF = np.log(_PMF)


def priority(item, bins):
    """Return a priority per bin; highest wins (ties to first)."""
    rem = bins.astype(np.int64) - item  # remaining capacity after placement
    rem = np.clip(rem, 0, 100)

    # Dominant term: best fit (smaller remainder preferred).
    score = -rem.astype(np.float64)

    # Bonus: reward remainders that could be exactly closed by one future item.
    # Use the (sub)probability that a future item equals this remainder.
    # Only meaningful for rem in 1..100; rem==0 is already perfect.
    safe = np.clip(rem, 1, 100)
    logp = _LOGPMF[safe - 1]
    future_fill = np.exp(logp)  # approx P(next item == rem)
    # Scale small enough to only break near-ties.
    score += 0.5 * future_fill

    # Slight extra bonus for exact fills (remainder 0).
    score += 0.5 * (rem == 0).astype(np.float64)

    return score
# EVOLVE-BLOCK-END
