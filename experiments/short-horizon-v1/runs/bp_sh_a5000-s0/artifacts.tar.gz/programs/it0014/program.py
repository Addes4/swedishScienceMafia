# EVOLVE-BLOCK-START
"""Best fit with small penalty for leaving useless tiny remainders.

Base rule is classic best fit (minimize post-placement remainder). On top of
that, add a mild reward for remainders that are large enough to still accept a
typical small future item, so we don't prematurely create bins with almost no
usable space. Kept deliberately gentle to avoid over-tuning.
"""
import numpy as np


def priority(item, bins):
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Base: best fit -> smaller remainder is better.
    score = -rem

    # Mild bonus: prefer bins whose leftover can still hold a small item
    # (remainder >= ~5) over bins that leave a nearly useless sliver.
    # Scaled so it never overrides the dominant best-fit ordering by much.
    useful = (rem >= 5.0).astype(np.float64)
    score = score + 0.01 * useful

    return score
# EVOLVE-BLOCK-END

