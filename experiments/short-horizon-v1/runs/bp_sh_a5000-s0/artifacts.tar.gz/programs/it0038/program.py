# EVOLVE-BLOCK-START
"""Harmonic best/worst-fit hybrid for online bin packing.

Plain best-fit is near-optimal but can waste capacity by fragmenting large bins
with small items. Blending toward worst-fit preserves empty room for future
large items. A single tuned mixing weight keeps it simple and fast.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Best-fit component: smaller post-placement remainder is better.
    # Worst-fit component: larger remainder (emptier bin after placing) is better.
    # Blend with a small weight toward worst-fit to preserve large bins.
    w = 0.15
    # Normalize the remainder to [0, 1] for a stable scale.
    r = rem / 100.0
    return -(r) + w * r
# EVOLVE-BLOCK-END

