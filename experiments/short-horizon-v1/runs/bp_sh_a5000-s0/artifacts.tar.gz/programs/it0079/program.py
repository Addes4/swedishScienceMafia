# EVOLVE-BLOCK-START
"""Best fit with exact-fit priority and stale-remainder avoidance."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.int64)  # remaining capacity after placing

    score = -rem.astype(np.float64)

    # Strong bonus for exact fills (remainder 0).
    score += 10.0 * (rem == 0)

    # Penalize remainders that are too small to ever be useful again
    # (smaller than the smallest item likely to appear), since they waste space.
    score -= 1.5 * ((rem > 0) & (rem < 8))

    return score
# EVOLVE-BLOCK-END

