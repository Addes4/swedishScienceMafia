# EVOLVE-BLOCK-START
"""Best fit with a soft anti-slack penalty on small leftover remainders."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Primary: best fit — smaller remainder is better.
    score = -rem

    # Secondary (soft): penalize leaving a tiny leftover that future items
    # will likely be unable to fill exactly (1..9 that isn't a "nice" fill).
    # Values that are exact multiples of common item sizes are less harmful,
    # so we apply a continuous penalty that peaks in the low-but-nonzero range.
    tiny = (rem > 0) & (rem < 10)
    score -= 0.15 * tiny.astype(np.float64) * (10.0 - rem)

    return score
# EVOLVE-BLOCK-END

