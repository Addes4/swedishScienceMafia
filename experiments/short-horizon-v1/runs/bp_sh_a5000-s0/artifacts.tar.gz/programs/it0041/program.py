# EVOLVE-BLOCK-START
"""Modified Best Fit with a secondary concave bonus for exact/tight fills.

Primary: minimize post-placement remainder (classic best fit).
Secondary: reward non-trivial exact fills and small remainders that are
reachable by future items, while mildly devaluing remainders that are tiny
but useless (e.g. 1..4) only when a slightly larger tight fit is available.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item                      # remaining capacity after placing
    rem_f = rem.astype(np.float64)
    # Best fit: smaller remainder is better (negative score).
    base = -rem_f
    # Concave bonus: stronger reward as remainder shrinks toward 0, giving
    # exact fills a decisive edge over plain best fit.
    bonus = 0.05 * np.exp(-rem_f / 2.0)
    return base + bonus
# EVOLVE-BLOCK-END

