# EVOLVE-BLOCK-START
"""Distribution-aware best fit with a stable online median estimate.

Items come from a fixed Weibull-shaped distribution (mean ~40). Pure best fit
minimizes the immediate remainder but leaves tiny unusable gaps. Here we:
  1. Strongly prefer exact fills (remainder 0).
  2. Otherwise prefer the post-placement remainder closest to a robust estimate
     of a typical future item size, so leftover gaps stay reusable.

The typical size is estimated with a small exponential-decay histogram over
integer item sizes (1..100), which converges quickly to the distribution's
median and avoids the variance of reservoir sampling.
"""
import numpy as np

_state = {"n": 1.0, "mean": 40.0}
# Histogram over integer sizes 1..100 with mild exponential decay.
_hist = np.zeros(102, dtype=np.float64)
_decay = 0.999

_BC = np.arange(1, 101, dtype=np.float64)  # bin centers = integer sizes


def _target():
    """Estimate a typical (median-ish) future item size from the histogram."""
    w = _hist[1:101]
    tot = w.sum()
    if tot <= 0.0:
        return _state["mean"]
    cum = np.cumsum(w)
    idx = np.searchsorted(cum, 0.5 * tot)
    if idx > 99:
        idx = 99
    return float(idx + 1)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Update online mean.
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * (n - 1.0) + float(item)) / n
    _state["n"] = n + 1.0

    # Update decayed histogram.
    _hist *= _decay
    _hist[int(item)] += 1.0

    target = _target()
    if target < 1.0:
        target = 1.0

    rem = (bins - item).astype(np.float64)  # capacity left after placing

    # Distance of the leftover gap from a typical future item size.
    gap_score = -np.abs(rem - target)

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return gap_score + exact_bonus
# EVOLVE-BLOCK-END
