# EVOLVE-BLOCK-START
"""Best fit with expected-future-usability: prefer bins that stay useful."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Primary: best fit (smaller post-placement remainder is better).
    score = -rem

    # Secondary: keep bins "useful" -- reward remainders that are at least a
    # typical item size (mean ~40), so we avoid leaving bins with tiny,
    # unusable leftovers while still preferring tighter fits via the -rem term.
    # A smooth saturating bonus centered near a common item size.
    useful = 1.0 - np.exp(-rem / 40.0)
    score = score + 25.0 * useful

    return score
# EVOLVE-BLOCK-END
