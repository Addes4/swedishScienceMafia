# EVOLVE-BLOCK-START
"""Distribution-aware best fit: exact fills first, then keep usable gaps.

Items are drawn from a fixed Weibull-shaped distribution with mean about 40.
Pure best fit minimizes the immediate remainder, which often leaves tiny
unusable gaps. Instead, after guaranteeing the item fits (it always does, since
only fitting bins are shown), we rank bins so that:
  1. exact fills (remainder 0) are strongly preferred, then
  2. among remaining bins, the post-placement remainder closest to a typical
     future item size is preferred, keeping gaps reusable.

The empirical item distribution is Weibull-shaped (left-skewed, mean ~40), so
the most reusable gap size is below the mean.  We target mean - 0.5*std, which
tracks the bulk of the distribution closer than the mean alone.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0, "m2": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Online estimate of mean and variance of item sizes.
    n = _state["n"]
    m = _state["mean"]
    m2 = _state["m2"]
    n1 = n + 1.0
    delta = float(item) - m
    m_new = m + delta / n1
    m2_new = m2 + delta * (float(item) - m_new)
    _state["mean"] = m_new
    _state["m2"] = m2_new
    _state["n"] = n1

    if n1 > 1.0:
        var = m2_new / n1
        std = var ** 0.5 if var > 0.0 else 0.0
    else:
        std = 20.0
    target = m_new - 0.5 * std
    if target < 1.0:
        target = 1.0

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Distance of the leftover gap from a typical future item size.
    gap_score = -np.abs(rem - target)

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return gap_score + exact_bonus
# EVOLVE-BLOCK-END
