# EVOLVE-BLOCK-START
"""Best fit with an empirical exact-fill bonus driven by a running size histogram."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Best fit: smaller remainder is better (dominant term).
    score = -rem
    # Near-exact-fill bonus: strongly reward placing the item so the leftover
    # gap is tiny, since such bins are essentially sealed at high density.
    score += 1.5 * np.exp(-rem / 3.0)
    return score
# EVOLVE-BLOCK-END
