# EVOLVE-BLOCK-START
"""Best fit with concave remainder shaping: reward near-exact fills strongly
while adding a mild convex penalty for leaving very large remainders, so fresh
bins are consumed only when necessary."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Base: best fit (smaller remainder is better) -> negative remainder.
    score = -rem

    # Strong bonus for near-exact fills: reward very small remainders.
    score += 0.05 * (rem < 3)

    # Mild convex penalty against leaving very large remainders, so we avoid
    # grabbing a fresh (near-empty) bin when a tighter fit is not available
    # only marginally; discourages premature consumption of empty bins.
    large = np.clip(rem - 60.0, 0.0, None)
    score -= 0.005 * large * large

    return score
# EVOLVE-BLOCK-END

