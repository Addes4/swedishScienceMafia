# EVOLVE-BLOCK-START
"""Best fit with smooth convex tight-fit emphasis: minimize remainder plus a
quadratic penalty that grows as the remainder grows, so near-exact fills are
favored with strength increasing as tightness improves."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Minimize rem + c * rem^2. The linear term is best fit; the quadratic term
    # smoothly strengthens the preference for very tight fits without any
    # threshold, so it changes the argmax more often than a piecewise bonus.
    return -(rem + 0.05 * rem * rem)
# EVOLVE-BLOCK-END

