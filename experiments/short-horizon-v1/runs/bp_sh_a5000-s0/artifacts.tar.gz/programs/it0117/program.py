# EVOLVE-BLOCK-START
"""Best fit with tiny-gap avoidance.

Items are drawn from a fixed Weibull-shaped distribution (mean about 40).
Classic Best Fit (smallest post-placement remainder) is a strong online rule,
but it frequently leaves remainders too small to ever be reused, which wastes
capacity. We keep Best Fit as the primary signal, add a strong bonus for exact
fills, and add a modest bonus for remainders that are at least as large as a
typical small item (estimated online via a small quantile of observed items),
avoiding the creation of unusable slivers.
"""
import numpy as np

_state = {"n": 0.0, "small": None, "buf": []}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Online estimate of a typical small item size (approx 25th percentile).
    buf = _state["buf"]
    buf.append(float(item))
    if len(buf) > 200:
        del buf[0]
    q = float(np.percentile(buf, 25))
    _state["small"] = q

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Primary: Best Fit -> prefer smallest remainder.
    bestfit = -rem

    # Small bonus for not creating an unusable sliver: prefer remainder >= q.
    usable = np.where(rem >= q, 1.0, 0.0) * 5.0

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return bestfit + usable + exact_bonus
# EVOLVE-BLOCK-END

