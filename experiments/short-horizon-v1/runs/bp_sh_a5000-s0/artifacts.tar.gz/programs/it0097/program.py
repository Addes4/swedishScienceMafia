# EVOLVE-BLOCK-START
"""Distribution-aware best fit with a smooth usable-gap value.

Items are drawn from a fixed Weibull-shaped distribution with mean about 40.
Pure best fit minimizes the immediate remainder, which often leaves tiny
unusable gaps. Instead, after guaranteeing the item fits (only fitting bins are
shown), we rank bins so that:
  1. exact fills (remainder 0) are strongly preferred, then
  2. among remaining bins, the post-placement remainder is scored by a smooth
     value that rewards gaps likely to hold a future item while still favoring
     tighter packing, based on an online estimate of the item distribution.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0, "m2": 0.0, "last": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Online estimate of mean and std of item sizes (Welford-ish, simple form).
    n = _state["n"]
    m = _state["mean"]
    new_n = n + 1.0
    delta = float(item) - m
    m_new = m + delta / new_n
    _state["m2"] += delta * (float(item) - m_new)
    _state["mean"] = m_new
    _state["n"] = new_n

    target = _state["mean"]
    var = _state["m2"] / new_n if new_n > 0 else 0.0
    sd = var ** 0.5 if var > 0 else 1.0

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Reward remainders that are at least a typical item, so the gap stays
    # usable; discourage tiny stranded gaps. Smooth logistic on the gap.
    usable = 1.0 / (1.0 + np.exp(-(rem - target) / max(sd, 1.0)))

    # Among usable gaps, prefer smaller remainders (best-fit behavior).
    tightness = -rem / 100.0

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return 2.0 * usable + tightness + exact_bonus
# EVOLVE-BLOCK-END

