# EVOLVE-BLOCK-START
"""Best fit plus distribution-aware exact-fit tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Best fit: smaller remainder is better (negative score).
    score = -rem
    # Strong bonus for exact fills, moderate bonus for small remainders.
    score += 0.02 * (rem == 0.0)
    # Tiny tie-break: prefer remainders that closely match the typical
    # item size (~30) so future items can fill bins neatly.
    score += 0.001 * np.exp(-0.05 * (rem - 30.0) ** 2)
    return score
# EVOLVE-BLOCK-END
