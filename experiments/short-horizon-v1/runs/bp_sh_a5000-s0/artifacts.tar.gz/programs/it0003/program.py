# EVOLVE-BLOCK-START
"""Best fit with a leftover-usability tie-breaker."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Primary: prefer tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Tie-breaker: mildly prefer residuals that are still usable for future items,
    # i.e. penalize leaving a tiny useless fragment.
    # A residual near 0 wastes the bin; small residuals in (0, ~item_mean) are the worst.
    # Add a small concave bonus so larger useful residuals break near-ties.
    score += 0.02 * np.sqrt(residual.astype(np.float64) + 1.0)

    return score
# EVOLVE-BLOCK-END
