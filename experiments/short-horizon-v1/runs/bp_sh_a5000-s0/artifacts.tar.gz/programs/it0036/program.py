# EVOLVE-BLOCK-START
"""Best fit with unusable-remainder avoidance.

Standard best fit (choose the bin leaving the smallest remainder) is near
optimal for this distribution. The main loss comes from leaving tiny
unfillable remainders. We keep best fit as the dominant term but add a small
penalty that discourages leaving a remainder that no future integer item can
fill exactly-ish, nudging the choice toward remainders reachable by likely
item sizes.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Primary: best fit -> smaller remainder is better.
    score = -rem

    # Small bonus for exact fills and for remainders that equal a typical
    # item size (so the bin can likely be closed later); slight penalty for
    # tiny remainders below the smallest common item size that tend to be
    # wasted if no size-1 items arrive.
    small = (rem > 0) & (rem < 5)
    score = score - 0.5 * small + 1e-6 * rem  # tie-break toward fuller bins

    return score
# EVOLVE-BLOCK-END
