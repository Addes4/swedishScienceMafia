# EVOLVE-BLOCK-START
"""Best fit with concave remainder penalty: exact fits first, then
prefer fuller bins using a sub-linear (square-root) penalty on remainder."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Concave penalty: sqrt grows slowly, so all non-zero remainders are
    # penalized mildly, keeping best-fit ordering while nudging toward
    # fuller bins that leave compact, reusable gaps.
    return -np.sqrt(rem) - 1e-6 * rem
# EVOLVE-BLOCK-END

