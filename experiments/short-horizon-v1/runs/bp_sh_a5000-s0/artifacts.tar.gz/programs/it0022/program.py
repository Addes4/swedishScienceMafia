# EVOLVE-BLOCK-START
"""Blend of best fit with an occupancy-based tie-breaker to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins.astype(np.float64) - float(item)   # capacity after placing
    # Base: best fit (smaller remainder is better -> negative score).
    # Tie-breaker: mildly reward bins that are already more occupied
    # (i.e. have less remaining capacity), encouraging consolidation of
    # partially filled bins and reducing fragmentation.
    return -rem - 0.01 * bins
# EVOLVE-BLOCK-END

