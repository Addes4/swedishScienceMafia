# EVOLVE-BLOCK-START
"""Best fit with a penalty on unusable slivers and a reward for exact fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Best fit: smaller remainder is better (base score = -rem).
    # Penalize bins that would be left with a tiny, hard-to-reuse sliver
    # (remainder in {1,2,3}) since that wastes capacity, but reward exact fits.
    sliver = (rem >= 1) & (rem <= 3)
    exact = (rem == 0)
    score = -rem
    score -= 0.5 * sliver.astype(np.float64)
    score += 0.5 * exact.astype(np.float64)
    return score
# EVOLVE-BLOCK-END

