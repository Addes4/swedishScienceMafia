# EVOLVE-BLOCK-START
"""Best fit with a mild preference to consolidate into less-empty bins.

Primary criterion: minimize the post-placement remainder (classic best fit).
Secondary, small term: add a bonus proportional to the bin's pre-placement
remaining capacity, so among near-tied remainders we slightly prefer placing
into an already-used bin rather than consuming a nearly-empty one. This keeps
best-fit behavior while reducing premature use of fresh capacity.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Best fit: smaller remainder is better (negative score), dominant term.
    # Mild secondary bonus: prefer bins that already had less free space, so
    # we consolidate rather than exhausting fresh near-empty bins.
    return -rem + 0.03 * bins.astype(np.float64)
# EVOLVE-BLOCK-END

