# EVOLVE-BLOCK-START
"""Distribution-aware best fit with a lightweight filler target.

Items come from a fixed Weibull-shaped distribution (mean ~40). Pure best fit
minimizes the immediate remainder but leaves tiny unusable gaps. Here we:
  1. Strongly prefer exact fills (remainder 0).
  2. Otherwise prefer the post-placement remainder closest to a typical
     "filler" size (about half of the running mean), so leftover gaps stay
     reusable by future items.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    # A typical filler size: half the mean item size.
    target = 0.5 * _state["mean"]
    if target < 1.0:
        target = 1.0

    rem = (bins - item).astype(np.float64)  # capacity left after placing

    # Distance of the leftover gap from a typical filler item size.
    gap_score = -np.abs(rem - target)

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return gap_score + exact_bonus
# EVOLVE-BLOCK-END


