# EVOLVE-BLOCK-START
"""Best fit with a convex exponent on the post-placement remainder.

The item goes to the bin minimizing (remaining capacity after placing)^p,
with p slightly above 1.  This is a smooth generalization of best fit
(p = 1) and sum-of-powers style heuristics, giving a mild extra push toward
near-exact fills without the crude cutoff of the previous bonus term.
"""
import numpy as np

_P = 1.4  # exponent on the post-placement remainder


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Minimize rem**p  <=>  maximize -rem**p.  p > 1 sharpens preference for
    # tight fits beyond plain linear best fit.
    return -(rem ** _P)
# EVOLVE-BLOCK-END

