# EVOLVE-BLOCK-START
"""Best fit with distribution-calibrated "fillable leftover" bonus.

Plain best-fit leaves small remainders that may be unfillable by future items.
We keep best-fit as the dominant term but add a bonus for remainders that have
high probability of being exactly filled by a future item, estimated online
from the empirical distribution of arriving items.
"""
import numpy as np


class _State:
    def __init__(self):
        # histogram of item sizes seen so far (1..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def update(self, item):
        self.hist[item] += 1.0
        self.total += 1.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    _state.update(int(item))

    rem = (bins - item).astype(np.int64)  # remainder after placing item; >=0

    # Best-fit primary: smaller remainder is better.
    score = -rem.astype(np.float64)

    # Empirical distribution-based bonus: reward remainders that can likely be
    # exactly filled (remainder r has future item equal to r) or nearly filled.
    if _state.total >= 20:
        probs = _state.hist / _state.total  # probability mass per size
        # Probability that a single future item exactly equals the remainder.
        # Also give partial credit for remainders within +-1 (near exact fill).
        exact = probs[rem]  # rem is an array of remainders in 0..100
        # avoid index issues: rem could be 100
        near_lo = np.where(rem >= 1, probs[np.clip(rem - 1, 0, 100)], 0.0)
        near_hi = np.where(rem <= 99, probs[np.clip(rem + 1, 0, 100)], 0.0)
        fill_score = exact + 0.5 * near_lo + 0.5 * near_hi
        score += 5.0 * fill_score

    return score
# EVOLVE-BLOCK-END

