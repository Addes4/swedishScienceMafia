# EVOLVE-BLOCK-START
"""Distribution-aware best fit: exact fills first, then reusable gaps.

Items come from a fixed Weibull-shaped distribution (mean ~40). Pure best fit
leaves many tiny unusable gaps. Instead we:
  1. strongly prefer exact fills (close the bin),
  2. otherwise prefer a remainder close to a *frequently occurring* item size,
     estimated online from a histogram of observed items, so leftover gaps can
     actually be filled by common future items.
"""
import numpy as np

_state = {
    "n": 0.0,
    "hist": np.zeros(101, dtype=np.float64),  # counts of observed item sizes
    "targets": None,
}


def _refresh_targets():
    hist = _state["hist"]
    total = hist.sum()
    if total < 30:
        _state["targets"] = np.array([40.0])
        return
    # Top few most frequent item sizes (excluding empty cells).
    counts = hist.copy()
    k = min(5, int((counts > 0).sum()))
    if k <= 0:
        _state["targets"] = np.array([40.0])
        return
    idx = np.argpartition(-counts, k - 1)[:k]
    idx = idx[counts[idx] > 0]
    # Keep only targets with meaningful frequency.
    thresh = 0.02 * total
    idx = idx[counts[idx] >= thresh]
    if idx.size == 0:
        idx = np.argpartition(-counts, k - 1)[:k]
        idx = idx[counts[idx] > 0]
    _state["targets"] = idx.astype(np.float64)


def priority(item, bins):
    """Return a priority for every bin; highest wins, ties to first."""
    hist = _state["hist"]
    hist[int(item)] += 1.0
    _state["n"] += 1.0
    if _state["targets"] is None or int(_state["n"]) % 25 == 0:
        _refresh_targets()
    targets = _state["targets"]

    rem = (bins - item).astype(np.float64)  # remainder after placing item

    # Distance from remainder to the nearest common future item size.
    diff = np.abs(rem[:, None] - targets[None, :])
    gap_score = -diff.min(axis=1)

    # Strong bonus for exact fills.
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return gap_score + exact_bonus
# EVOLVE-BLOCK-END

