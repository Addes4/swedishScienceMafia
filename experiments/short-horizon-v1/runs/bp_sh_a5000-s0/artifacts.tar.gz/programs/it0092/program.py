# EVOLVE-BLOCK-START
"""Distribution-aware best fit: exact fits first, then keep usable gaps.

Items are drawn from a fixed Weibull-shaped distribution with mean about 40.
Pure best fit minimizes the immediate remainder, which often leaves tiny
unusable gaps. Instead, after guaranteeing the item fits (it always does, since
only fitting bins are shown), we rank bins so that:
  1. exact fills (remainder 0) are strongly preferred, then
  2. among remaining bins, the post-placement remainder closest to a typical
     future item size (mean ~40) is preferred, keeping gaps reusable.
"""
import numpy as np

_TARGET = 40.0  # approximate mean item size of the fixed distribution


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Distance of the leftover gap from a typical future item size.
    gap_score = -np.abs(rem - _TARGET)

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return gap_score + exact_bonus
# EVOLVE-BLOCK-END

