# EVOLVE-BLOCK-START
"""Reserved-threshold fit: prefer the fullest bin that still leaves room for a
typical future item; otherwise plain best-fit."""
import numpy as np


_TARGET = 40.0  # roughly the mean item size of the distribution


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Among bins leaving at least _TARGET free (so a typical future item still
    # fits comfortably), prefer the fullest (smallest rem). Bins leaving less
    # are lower priority but still ranked by smallest rem (best-fit fallback).
    good = rem >= _TARGET
    return good.astype(np.float64) * 1e6 - rem
# EVOLVE-BLOCK-END
