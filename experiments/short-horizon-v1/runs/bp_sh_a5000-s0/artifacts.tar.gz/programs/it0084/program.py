# EVOLVE-BLOCK-START
"""Best fit with a stronger, wider near-exact-fill bonus.

The idea: plain best fit is already strong, but it occasionally wastes gaps
that end up too small for any future item. We keep remainder-ascending order
as the dominant signal while adding a smooth bonus for small remainders and a
separate bonus for exact fills, biasing toward dense/tight packings without
overriding a clear best-fit advantage.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Dominant term: best fit (smaller remainder is better).
    score = -rem

    # Smooth bonus for small remainders, strongest as rem -> 0, using a
    # decaying band that covers the region where usable gaps live.
    score = score - 3.0 * np.exp(-rem / 8.0)

    # Extra push for exact / near-exact fills.
    score = score - 2.0 * (rem < 2)

    return score
# EVOLVE-BLOCK-END

