# EVOLVE-BLOCK-START
"""Blended best-fit with distribution-aware gap shaping.

Items come from a fixed Weibull-shaped distribution (mean ~40). Classic Best
Fit (minimize post-placement remainder) is a strong, robust rule. We blend it
with a mild distribution-aware term that nudges remainders toward a typical
future item size (online-estimated mean), plus a strong exact-fill bonus.
The best-fit term dominates so behavior stays close to the reliable baseline.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    target = _state["mean"]
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Classic best fit: smaller remainder is better.
    best_fit = -rem

    # Mild gap-shaping: prefer remainders close to a typical future item.
    gap_score = -np.abs(rem - target)

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    # Best-fit dominates; gap shaping only breaks near-ties.
    return 10.0 * best_fit + 1.0 * gap_score + exact_bonus
# EVOLVE-BLOCK-END
