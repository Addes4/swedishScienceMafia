# EVOLVE-BLOCK-START
"""Best fit with an online future-fit bonus: prefer small remainders (best fit),
but also give a small bonus to bins whose post-placement remainder is likely to
be usable by future items, estimated from an online histogram of seen sizes."""
import numpy as np

# Module-level state; reset per stream by the harness importing fresh, but we
# also guard with a size-101 histogram that only accumulates counts.
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    global _HIST, _TOTAL

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Update online histogram of item sizes (Laplace-smoothed later).
    _HIST[int(item)] += 1.0
    _TOTAL += 1.0

    # Expected future-fit bonus: for a post-placement remainder r, estimate the
    # probability that a future item will fit in r (i.e., size <= r), weighted
    # toward filling it well. We approximate with the smoothed CDF-like mass.
    probs = (_HIST + 1.0) / (_TOTAL + 101.0)
    cdf = np.cumsum(probs)  # cdf[k] ~ P(size <= k)
    idx = np.clip(rem.astype(np.int64), 0, 100)
    fitmass = cdf[idx]  # P(future item fits into this remainder)

    # Dominant: best fit (smaller remainder better). Small bonus: reward bins
    # whose remainder is likely to be filled by a future item (higher fitmass),
    # scaled small so best fit stays dominant.
    return -rem + 0.06 * fitmass
# EVOLVE-BLOCK-END
