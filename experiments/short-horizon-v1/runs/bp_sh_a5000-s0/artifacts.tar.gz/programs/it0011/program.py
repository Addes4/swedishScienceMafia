# EVOLVE-BLOCK-START
"""Best fit with a sharper convex remainder penalty plus a bonus for leaving
remainders that match likely future item sizes (near the distribution mean)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Convex power penalty on the post-placement remainder: prefer tight fits,
    # but slightly sharpen preference for very tight fits over merely tight ones.
    score = -(rem ** 1.15)
    # Bonus for leaving a remainder that future items (drawn ~mean 40) can fill
    # exactly-ish. Gaussian-ish reward centered near the distribution mean.
    target = 40.0
    score += 0.6 * np.exp(-((rem - target) ** 2) / (2.0 * 12.0 ** 2))
    # Extra reward for near-exact fills (remainder ~ 0).
    score += 0.4 * np.exp(-((rem) ** 2) / (2.0 * 6.0 ** 2))
    return score
# EVOLVE-BLOCK-END
