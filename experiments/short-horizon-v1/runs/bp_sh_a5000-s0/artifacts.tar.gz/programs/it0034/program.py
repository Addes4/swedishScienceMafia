# EVOLVE-BLOCK-START
"""Best fit with a fuller-bin tie-break: minimize the post-placement
remainder first, then prefer the already-fuller bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem_after = bins - item          # remainder after placing (smaller better)
    # Primary: smallest remainder after placement (best fit).
    # Secondary: among near-equal remainders, prefer the fuller bin (smaller
    # pre-placement remainder), i.e. keep packing existing bins densely.
    # Combine lexicographically with a tiny epsilon so primary dominates.
    return -rem_after.astype(np.float64) - 1e-4 * bins.astype(np.float64)
# EVOLVE-BLOCK-END
