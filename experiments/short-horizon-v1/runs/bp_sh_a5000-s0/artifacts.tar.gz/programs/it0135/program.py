# EVOLVE-BLOCK-START
"""Distribution-aware best fit with histogram-based remainder matching.

Items come from a fixed Weibull-shaped distribution (mean ~40). Pure best fit
minimizes the immediate remainder but leaves tiny unusable gaps. Here we:
  1. Strongly prefer exact fills (remainder 0).
  2. Otherwise prefer post-placement remainders that match a *common* item
     size, so the leftover gap can be exactly refilled by one future item.
We estimate the item-size distribution online via a histogram over sizes
1..100 and score remainders by that histogram density.
"""
import numpy as np

# Histogram of observed item sizes (index = size, 1..100).
_counts = np.zeros(101, dtype=np.float64)
_seen = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    global _seen
    _counts[int(item)] += 1.0
    _seen += 1.0

    rem = (bins - item).astype(np.int64)  # capacity left after placing

    # Probability mass of past items at each possible remainder size. A gap that
    # equals a frequent item size can be closed tightly by a future item.
    # Smooth the histogram slightly so unseen sizes are not totally excluded.
    prob = _counts / _seen if _seen > 0 else np.ones(101) / 101.0
    # Small smoothing toward uniform over 1..100.
    prob = prob * 0.9 + (1.0 / 100.0) * 0.1

    r = np.clip(rem, 0, 100)
    density = prob[r]  # "how reusable" the leftover gap is

    # Strong bonus for exact fills (bin fully closed).
    exact_bonus = np.where(rem <= 0, 50.0, 0.0)

    # Prefer usable gaps (high density); tie-break toward smaller remainders
    # via a tiny best-fit nudge so nearly equal-density gaps go to the tightest.
    tie = -1e-3 * np.abs(rem)

    return density + exact_bonus + tie
# EVOLVE-BLOCK-END

