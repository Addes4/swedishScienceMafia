# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus.

Items are drawn from a fixed Weibull-shaped distribution with mean about 40.
Pure best fit (smallest post-placement remainder) is a robust, near-optimal
online rule for this distribution; the main correction is to make sure exact
fills (remainder 0) are always chosen first, which closes bins cleanly.
Since the harness only shows bins the item fits in, every remainder is >= 0.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Primary: best fit -> smaller remainder is better (negative remainder).
    best_fit = -rem

    # Exact fills (remainder 0) always win.
    exact_bonus = np.where(rem <= 0.0, 1e6, 0.0)

    return best_fit + exact_bonus
# EVOLVE-BLOCK-END
