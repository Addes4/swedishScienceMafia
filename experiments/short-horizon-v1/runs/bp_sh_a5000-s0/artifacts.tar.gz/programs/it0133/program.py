# EVOLVE-BLOCK-START
"""Distribution-aware packing using an online size histogram.

Items are Weibull-shaped (mean ~40). Pure best fit minimizes the immediate
remainder but can strand small unusable gaps. Here we:
  1. Strongly prefer exact fills (remainder 0).
  2. Otherwise favor smaller remainders (best-fit tightness).
  3. Add a bonus when the leftover remainder equals a *common* item size,
     estimated online via a coarse histogram of past items, so the gap is
     reusable by a likely future item.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Online running mean.
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    # Online histogram of past item sizes.
    hist = _state["hist"]
    hist[item] += 1.0
    total = _state["n"]

    rem = (bins - item).astype(np.float64)  # capacity left after placing

    # Best-fit tightness: smaller remainder preferred (negate).
    tight_score = -rem

    # Bonus: how common is a future item equal to this remainder?
    # Use a local smoothing window around the remainder to be robust to noise.
    freq = np.zeros_like(rem)
    if total > 0.0:
        idx = np.clip(rem.astype(np.int64), 0, 100)
        # smoothed frequency: count of items within +/-3 of the remainder
        for d in range(-3, 4):
            j = np.clip(idx + d, 0, 100)
            freq += hist[j]
        freq /= (total * 7.0)

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return tight_score + 50.0 * freq + exact_bonus
# EVOLVE-BLOCK-END
