# EVOLVE-BLOCK-START
"""Distribution-aware best fit with fill-sensitive gap targeting.

Items come from a fixed Weibull-shaped distribution (mean about 40). Pure best
fit minimizes the immediate remainder, which can leave tiny unusable gaps.
Here we:
  1. always take an exact fill (remainder 0),
  2. otherwise prefer the bin whose post-placement remainder best matches a
     target that adapts to how full the current packing is: when the average
     bin usage is high we shift toward best-fit (small remainders), and when
     bins still have room we shift toward the estimated mean item size so gaps
     stay reusable.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0, "used_frac": 0.5}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    target = _state["mean"]

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Fraction of bins that have already been touched (used).
    used_frac = np.mean(bins < 100)
    _state["used_frac"] = used_frac

    # Blend best-fit toward mean-target as packing gets more crowded.
    # "crowd" in [0,1]: higher => more crowded => weigh best-fit more.
    crowd = min(1.0, max(0.0, (used_frac - 0.5) * 2.5))

    # Best-fit signal: smaller remainder is better.
    best_fit = -rem
    # Mean-target signal: remainder close to a typical future item.
    mean_target = -np.abs(rem - target)

    gap_score = (1.0 - crowd) * mean_target + crowd * best_fit

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return gap_score + exact_bonus
# EVOLVE-BLOCK-END
