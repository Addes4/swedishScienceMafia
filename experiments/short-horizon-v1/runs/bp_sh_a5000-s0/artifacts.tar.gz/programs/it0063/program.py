# EVOLVE-BLOCK-START
"""Best fit with a smooth strictly-convex tightness term.

Primary criterion: minimize post-placement remainder (best fit).
Tie-break: reward bins whose remainder is closer to 0 via a smooth convex
term, so exact fills are the unique optimum without a discontinuous step.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Dominant best-fit: smaller remainder is better.
    # Smooth strictly-convex tie-break: penalize larger remainders
    # quadratically so near-exact fills are favored continuously.
    # We keep best-fit dominant by scaling the quadratic term small but
    # monotone, ensuring it only decides near-ties.
    return -rem - 1e-4 * rem * rem
# EVOLVE-BLOCK-END
