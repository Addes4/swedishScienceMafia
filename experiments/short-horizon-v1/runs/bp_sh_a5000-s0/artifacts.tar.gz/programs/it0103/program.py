# EVOLVE-BLOCK-START
"""Best fit with exact-fill priority and a mild reusable-gap bias.

Items are drawn from a fixed Weibull-shaped distribution with mean about 40.
Pure best fit minimizes the immediate remainder, which is a strong baseline.
The one clear improvement is to guarantee that exact fills (remainder 0) are
chosen whenever available, since closing a bin is always beneficial.

So the rule is lexicographic:
  1. exact fills (remainder 0) win outright,
  2. otherwise prefer the smallest remainder (classic best fit),
  3. with a very mild bias that nudges the remainder toward a reusable gap
     near the online-estimated mean item size (kept small so it only breaks
     near-ties and never overrides the best-fit ordering).
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Online estimate of the mean item size (starts at 40).
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    target = _state["mean"]
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Classic best-fit signal: prefer small remainders.
    best_fit = -rem

    # Very mild bias toward leaving a reusable gap close to a typical item.
    gap_bias = -0.01 * np.abs(rem - target)

    # Exact fills must win outright.
    exact_bonus = np.where(rem <= 0.0, 1e6, 0.0)

    return exact_bonus + best_fit + gap_bias
# EVOLVE-BLOCK-END

