# EVOLVE-BLOCK-START
"""Best fit enhanced with an empirical 'future exact-fill' bonus.

Primary signal remains best fit (smallest remainder wins). On top of that,
we keep a smoothed histogram of item sizes seen so far in this stream and add
a bonus for bins whose post-placement remainder is likely to be exactly filled
by a future item, i.e. remainders that are common item sizes.
"""
import numpy as np


def priority(item, bins):
    rem = (bins - item).astype(np.float64)

    # Base: best fit (smaller remainder better).
    score = -rem

    # Convex emphasis on near-exact fills: strong reward for tiny remainders.
    score = score - 0.02 * (100.0 - rem) * (rem < 5)

    # Distribution-aware bonus: reward remainders matching likely future items.
    hist = priority.hist
    total = priority.total

    # Build smoothed per-size probability for the remainder values.
    # hist has counts for sizes 1..100; apply Laplace smoothing.
    if total > 0:
        probs = (hist + 1.0) / (total + 100.0)
    else:
        probs = np.full(101, 1.0 / 101.0)

    # Map each remainder (integer value 0..100) to its probability.
    rem_int = np.clip(np.rint(rem), 0, 100).astype(np.int64)
    # Make sure we index probs with valid range (hist indexed 0..100).
    fill_prob = probs[rem_int]

    # Small weight so it does not distort the main best-fit ordering.
    score = score + 0.05 * fill_prob

    return score


# Per-stream state: histogram of observed item sizes (index 0..100).
priority.hist = np.zeros(101, dtype=np.float64)
priority.total = 0.0


def _update_state(item):
    idx = int(item)
    if 0 <= idx <= 100:
        priority.hist[idx] += 1.0
        priority.total += 1.0


# Wrap priority so state updates happen per arriving item without changing the
# required external name/signature: we hook via a module-level call counter.
_orig_priority = priority
_call_count = [0]


def priority(item, bins):  # noqa: F811
    _update_state(item)
    return _orig_priority(item, bins)
# EVOLVE-BLOCK-END

