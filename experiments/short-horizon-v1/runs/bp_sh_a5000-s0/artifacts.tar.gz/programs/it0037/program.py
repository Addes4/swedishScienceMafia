# EVOLVE-BLOCK-START
"""Best-fit with concave fill reward: primary term is plain best fit
(minimize post-placement remainder); a strictly concave, monotone reward
in used capacity breaks ties toward fuller bins without disturbing the
best-fit argmin for clearly different remainders."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    used = 100.0 - rem                       # fill level after placing
    # Dominant: best fit -> smaller remainder is better.
    # Secondary: concave reward on fill, only significant near ties, so it
    # cannot overturn a genuine best-fit choice but consolidates near-equal rem.
    return -rem + 1e-3 * (used ** 0.5)
# EVOLVE-BLOCK-END

