# EVOLVE-BLOCK-START
"""Distribution-aware best fit with a robust reusable-gap target.

Items are drawn from a fixed Weibull-shaped distribution with mean about 40
(right-skewed). Pure best fit minimizes the immediate remainder, often leaving
tiny unusable gaps. Instead:
  1. exact fills (remainder 0) get a strong bonus, then
  2. among remaining bins, prefer the post-placement remainder closest to a
     typical future item size. Because the distribution is right-skewed, the
     median is a more robust target than the mean, so we track an online
     median estimate via a small reservoir of recent item sizes.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0, "recent": []}
_RECENT_MAX = 256


def _median_estimate():
    r = _state["recent"]
    if not r:
        return _state["mean"]
    return float(np.median(np.asarray(r, dtype=np.float64)))


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    r = _state["recent"]
    r.append(float(item))
    if len(r) > _RECENT_MAX:
        del r[0]

    target = _median_estimate()
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Distance of the leftover gap from a typical future item size.
    gap_score = -np.abs(rem - target)

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return gap_score + exact_bonus
# EVOLVE-BLOCK-END

