# EVOLVE-BLOCK-START
"""Best fit with a fine-grained tie-break toward denser bins.

Plain best fit (smallest post-placement remainder) is near-optimal for this
distribution. Prior bonus terms rarely changed the argmax because remainders
are integers and ties are broken to the first bin. Here we keep best fit as
the dominant term but add a very small secondary term that only distinguishes
bins whose remainders are equal (or nearly so), preferring the bin that is
already more densely packed. This nudges near-tied choices toward fuller bins
without disturbing the primary best-fit ordering.
"""
import numpy as np


def priority(item, bins):
    rem = (bins - item).astype(np.int64)
    # Primary: minimize remainder (best fit). Secondary: prefer denser bins
    # (smaller current remaining capacity) only as a tie-break; scaled so it
    # can never overturn a difference of one unit in the remainder.
    used = (100 - bins).astype(np.int64)
    return -rem.astype(np.float64) * 101.0 - used.astype(np.float64) * 1.0
# EVOLVE-BLOCK-END

