# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware tie-break among near-equal remainders.

Primary order is plain best fit: smaller post-placement remainder wins.
Only when two bins' remainders are within TOL do we consult an online
histogram of observed item sizes and prefer the remainder whose gap is more
likely to be exactly filled by a future item (reusable gaps). This keeps the
proven best-fit behavior while recovering density where ties allow choice.
"""
import numpy as np

# state (persist across calls within a stream)
_hist = np.zeros(101, dtype=np.float64)  # counts of observed item sizes 1..100
_total = 0.0

_TOL = 2.0          # remainders within this window are treated as tied
_TIE_WEIGHT = 0.35  # weight of the histogram bonus inside the tie window


def priority(item, bins):
    """Rank bins for best fit, breaking near-ties by future-fit likelihood."""
    global _hist, _total

    # update online histogram with the observed item
    if 1 <= item <= 100:
        _hist[item] += 1.0
        _total += 1.0

    rem = (bins - item).astype(np.float64)  # remainder after placing

    # probability that a future item exactly equals each remainder value
    if _total > 0.0:
        prob = _hist / _total
    else:
        prob = np.zeros(101, dtype=np.float64)

    ridx = np.clip(rem.astype(np.int64), 0, 100)
    bonus = prob[ridx]

    # Base best-fit: smaller remainder better (more negative).
    score = -rem

    # Apply the histogram bonus only among bins whose remainder is within
    # TOL of the best (smallest) remainder, so best-fit ordering is preserved
    # for clearly different remainders.
    rmin = rem.min()
    near = rem <= (rmin + _TOL)
    score = score - _TIE_WEIGHT * bonus * near

    return score
# EVOLVE-BLOCK-END

