# EVOLVE-BLOCK-START
"""Distribution-aware best fit with histogram-based gap matching.

Items are drawn from a fixed Weibull-shaped distribution with mean about 40.
After guaranteeing the item fits, we rank bins so that:
  1. exact fills (remainder 0) are strongly preferred, then
  2. among remaining bins, the post-placement remainder is judged by how
     "fillable" it is: remainders that match common item sizes are preferred,
     since they can be closed exactly by a single future item. This keeps
     gaps reusable better than targeting a single mean size.
"""
import numpy as np

_state = {"n": 0.0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Update online item-size histogram.
    hist = _state["hist"]
    hist[int(item)] += 1.0
    _state["n"] += 1.0
    n = _state["n"]

    # Empirical probability that a future item exactly matches a remainder r.
    # Use the histogram directly (0..100). Add a smoothed prior for stability.
    probs = (hist + 0.5) / (n + 50.0)

    rem = (bins - item).astype(np.int64)
    rem_clipped = np.clip(rem, 0, 100)

    # Reusability: probability a future item exactly fills the leftover gap.
    reuse_score = probs[rem_clipped]

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0, 1000.0, 0.0)

    return reuse_score + exact_bonus
# EVOLVE-BLOCK-END
