# EVOLVE-BLOCK-START
"""Best fit with a smooth near-exact-fill bonus.

Prefer small post-placement remainders (best fit), but add a continuous bonus
that grows sharply as the remainder approaches zero, so bins that can be almost
exactly filled are preferred. The bonus is smooth (no discontinuous threshold)
and decays quickly, keeping best-fit dominant for ordinary remainders.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Best fit: smaller remainder is better (negative score dominates).
    # Smooth tight-fit bonus: 1/(1+rem) is large only when rem is tiny,
    # rewarding near-exact fills without a hard cutoff.
    bonus = 1.0 / (1.0 + rem)
    return -rem + 0.5 * bonus
# EVOLVE-BLOCK-END
