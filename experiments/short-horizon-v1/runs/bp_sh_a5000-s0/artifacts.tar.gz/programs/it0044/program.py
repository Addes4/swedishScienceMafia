# EVOLVE-BLOCK-START
"""Stateful best-fit that preserves bins usable by large future items.

We track the running maximum item size seen (a cheap proxy for the largest
future item). When placing, we first prefer bins whose leftover is still at
least this maximum (so they remain "universally usable"), and among those
minimize the leftover; if none qualify, we fall back to plain best fit.
This avoids fragmenting bins with remainders too small to be useful.
"""
import numpy as np

_STATE = {"max_seen": 1}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    global _STATE

    # Update running max item size (proxy for largest plausible future item).
    if item > _STATE["max_seen"]:
        _STATE["max_seen"] = item
    m = _STATE["max_seen"]

    rem = (bins - item).astype(np.float64)  # capacity left after placing here

    # Residual that remains >= m keeps the bin useful for the largest item.
    usable = (rem >= m)

    # Base preference: smaller leftover is better.
    score = -rem

    # If the placement leaves too little for the largest item, mildly penalize
    # it, but not so strongly that tight fills are avoided when unavoidable.
    score = score + 0.5 * usable.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

