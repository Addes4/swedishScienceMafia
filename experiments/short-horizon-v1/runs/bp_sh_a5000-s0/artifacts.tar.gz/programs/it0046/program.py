# EVOLVE-BLOCK-START
"""Best fit with smooth convex tight-fit emphasis plus a near-exact bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Best fit: smaller remainder is better (negative score).
    # Smooth convex emphasis: reward small remainders slightly more than the
    # linear term alone, promoting denser packing without a hard threshold.
    score = -rem - 0.1 * (rem * rem) / 100.0
    # Near-exact fill bonus: strongly prefer (near) exact fills.
    score -= 0.02 * (100.0 - rem) * (rem < 5)
    return score
# EVOLVE-BLOCK-END

