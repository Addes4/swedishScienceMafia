# EVOLVE-BLOCK-START
"""Scale-aware convex best fit with an occupancy tie-breaker.

Core rule: minimize the post-placement remainder rem = cap - item, sharpened
by a mildly superlinear exponent (p > 1) so that near-exact fits dominate.
Tie-breaker: mildly prefer consolidating into bins that are already partly
full (smaller new remainder AND leaving fewer near-empty bins around),
deterring premature opening of fresh bins on a mean-~40 stream.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)   # capacity left after placing
    occ = (100.0 - bins).astype(np.float64)  # current occupancy of the bin

    # Convex best fit: smaller remainder strongly preferred.
    p = 1.15
    score = -(rem ** p)

    # Occupancy tie-breaker: among similar remainders, favor filling bins
    # that already carry some load (avoid consuming fresh bins too early).
    score += 0.03 * occ

    return score
# EVOLVE-BLOCK-END

