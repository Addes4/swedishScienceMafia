# EVOLVE-BLOCK-START
"""Distribution-aware best fit via empirical residual matching.

Items come from a fixed Weibull-shaped distribution (mean ~40). Pure best fit
minimizes the immediate remainder but leaves gaps that no future item can fill.
Here we score each candidate remainder by how *fillable* it is: we keep an
online reservoir sample of past item sizes and reward remainders that are close
to a size we have actually seen. Exact fills get the strongest reward, and we
add a mild tie-break toward tighter packs so near-ties stay compact.
"""
import numpy as np
import random


_state = {"n": 0.0, "mean": 40.0, "res": [], "seen": 0}
_RES_N = 256


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Online estimates of the item size distribution.
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    # Reservoir sample of past item sizes.
    _state["seen"] += 1
    res = _state["res"]
    if len(res) < _RES_N:
        res.append(float(item))
    else:
        j = random.randint(0, _state["seen"] - 1)
        if j < _RES_N:
            res[j] = float(item)

    rem = (bins - item).astype(np.float64)  # capacity left after placing

    # Exact fill (bin becomes full) is always best.
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    if res:
        sample = np.asarray(res, dtype=np.float64)
        # For each bin's remainder, reward closeness to *some* observed item
        # size. Distances are computed against the (small) reservoir sample.
        # shape (len(rem), len(sample)) would be large; cap work with a
        # quantile-based representative set instead.
        qs = np.linspace(0.05, 0.98, 24)
        reps = np.quantile(sample, qs)
        d = np.abs(rem[:, None] - reps[None, :])          # (B, R)
        fill = np.exp(-d / 3.0).max(axis=1) * 3.0          # best match score
    else:
        fill = np.zeros_like(rem)

    # Mild tie-break toward tighter packs when fillability is similar.
    tie = -0.02 * rem

    return fill + exact_bonus + tie
# EVOLVE-BLOCK-END
