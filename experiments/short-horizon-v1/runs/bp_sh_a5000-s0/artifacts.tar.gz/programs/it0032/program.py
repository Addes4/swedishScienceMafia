# EVOLVE-BLOCK-START
"""Best fit with exact-fill and equal-pairing tie-breaks."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # remaining capacity after placing; >= 0 by construction

    # Primary: best fit (smaller remainder better).
    score = -rem.astype(np.float64)

    # Secondary tie-break: strongly prefer exact fills, then bins whose
    # remainder equals the current item size so identical items pair up.
    score += 10.0 * (rem == 0)
    score += 1.0 * (rem == item)

    return score
# EVOLVE-BLOCK-END
