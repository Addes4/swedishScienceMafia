# EVOLVE-BLOCK-START
"""Best fit with smooth convex tight-fit bonus: strictly prefer small
remainders, with a continuous convex reward for near-exact fills."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Best fit dominates: smaller remainder is better.
    # Smooth convex bonus: reward near-exact fills continuously, making
    # remainder 0 the unique optimum without a discontinuous threshold.
    return -rem - 0.05 * (100.0 - rem) ** 2
# EVOLVE-BLOCK-END

