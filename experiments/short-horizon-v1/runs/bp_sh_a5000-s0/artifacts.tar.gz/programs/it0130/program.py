# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference.

Items are drawn from a fixed Weibull-shaped distribution with mean about 40.
For this distribution, classic best fit (place into the bin with the smallest
feasible remaining capacity after placement) is a strong online packing rule.
We keep a strong preference for exact fills (fully closing a bin), which avoids
leaving a near-closed bin with a tiny unusable gap when a perfect fill exists.
Ties go to the first bin.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Best fit: prefer the smallest leftover remainder.
    score = -rem

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return score + exact_bonus
# EVOLVE-BLOCK-END

