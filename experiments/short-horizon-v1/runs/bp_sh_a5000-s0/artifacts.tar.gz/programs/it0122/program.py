# EVOLVE-BLOCK-START
"""Distribution-aware best fit: exact fills first, then reusable gaps.

Items come from a fixed Weibull-shaped distribution (mean ~40, mode ~30).
Best fit minimizes each immediate remainder but tends to leave many tiny
unusable gaps. This rule instead rewards leftover gaps that match a likely
future item size, using a concave utility peaking near the distribution's
mode, while still taking exact fills eagerly.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0, "mode": 30.0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Online statistics of past items.
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0
    it = int(item)
    if 1 <= it <= 100:
        h = _state["hist"]
        h[it] += 1.0
        # Refresh mode estimate occasionally.
        if n % 25.0 == 0.0:
            total = h.sum()
            if total > 50.0:
                # Smoothed histogram peak.
                k = np.ones(5) / 5.0
                sh = np.convolve(h, k, mode="same")
                _state["mode"] = float(np.argmax(sh[1:101])) + 1.0

    target = _state["mode"]
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Concave utility: best around `target`, gently worse for larger gaps,
    # and appreciably worse for tiny (unusable) gaps.
    rel = rem / max(target, 1.0)
    util = -np.abs(rel - 1.0)

    # Penalize tiny remainders (0 < rem < ~10) so we don't strand scraps,
    # but exact fills (rem <= 0) get the big bonus and dominate.
    tiny_penalty = np.where((rem > 0.0) & (rem < 10.0), -0.5, 0.0)

    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return util + tiny_penalty + exact_bonus
# EVOLVE-BLOCK-END

