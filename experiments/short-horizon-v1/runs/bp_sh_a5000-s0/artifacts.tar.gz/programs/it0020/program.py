# EVOLVE-BLOCK-START
"""Best fit augmented with a symmetry bonus that favors leaving a remainder
equal to the current item's size, promoting item pairing/density."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remainder after placing
    # Base: best fit (smaller remainder better).
    score = -rem
    # Pairing bonus: reward remainders close to the current item size so that
    # a matching item can later complete the bin, improving density.
    score += 2.0 * np.exp(-((rem - item) ** 2) / (2.0 * 4.0 ** 2))
    return score
# EVOLVE-BLOCK-END
