# EVOLVE-BLOCK-START
"""Distribution-aware best fit with a reusable-gap target.

Items are drawn from a fixed Weibull-shaped distribution with mean about 40.
Pure best fit minimizes the immediate remainder but can leave gaps that later
items cannot use. We rank bins so that:
  1. exact fills (remainder 0) are strongly preferred, then
  2. among remaining bins, the post-placement remainder is encouraged to sit
     just above a frequently occurring item size (estimated online via the
     running upper-percentile of observed items), so leftover gaps stay
     reusable by the common large items.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0, "p80": 40.0, "buf": []}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Online estimate of the item mean and an upper percentile (typical big item).
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    buf = _state["buf"]
    buf.append(float(item))
    if len(buf) > 400:
        del buf[:200]
    if len(buf) >= 5:
        _state["p80"] = float(np.percentile(buf, 80))
    target = _state["p80"]

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Reward leftovers that can still hold a common large item.
    gap_score = -np.abs(rem - target)

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return gap_score + exact_bonus
# EVOLVE-BLOCK-END
