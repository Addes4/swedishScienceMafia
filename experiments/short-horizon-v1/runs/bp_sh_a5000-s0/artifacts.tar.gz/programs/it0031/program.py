# EVOLVE-BLOCK-START
"""Best fit with a light empirical-lookahead tie-break on the remainder."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def _expected_waste(rem):
    """Estimate future waste for bins whose remainder is `rem`.

    For each possible future item s <= rem, placing s gives a new remainder
    rem - s; smaller resulting remainders are better. We sum a weighting
    that rewards remainders reachable by likely future items.
    """
    # Probability distribution over item sizes (smoothed empirical).
    if _COUNT < 20:
        return 0.0
    p = _HIST / _COUNT
    rem_i = int(rem)
    # Score = sum over feasible future items p[s] * (benefit of leaving rem-s)
    # benefit decreases as resulting remainder grows, so use -(new_rem).
    total = 0.0
    # Only look at sizes up to rem.
    s_idx = np.arange(1, rem_i + 1)
    ps = p[1:rem_i + 1]
    new_rem = rem_i - s_idx
    # Prefer small new_rem; weight by probability.
    total = float(np.dot(ps, -new_rem.astype(np.float64)))
    return total


def priority(item, bins):
    global _COUNT
    _HIST[item] += 1.0
    _COUNT += 1.0

    rem = (bins - item).astype(np.float64)  # remaining after placing
    # Dominant term: best fit (smaller remainder better).
    score = -rem
    # Light lookahead tie-break: bins whose remainder can be well used by
    # likely future items get a small convex bonus, breaking ties among
    # near-equal remainders toward denser packing.
    la = np.array([_expected_waste(r) for r in rem], dtype=np.float64)
    score += 0.05 * la
    # Slight extra push for near-exact fills.
    score -= 0.02 * (100.0 - rem) * (rem < 5)
    return score
# EVOLVE-BLOCK-END

