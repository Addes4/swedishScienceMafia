# EVOLVE-BLOCK-START
"""Tight-fit best fit with an online estimate of typical item size used to
break ties: among near-equal remainders, prefer the one that can still host a
typical future item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Best fit: smaller remainder is better (negative score).
    # Convex bonus over the small-remainder region: exact fills are best, and
    # near-exact fills are rewarded continuously.
    score = -rem

    # Smooth bonus on the region where the remainder is small enough that a
    # future item is likely to close it, strongest at remainder 0.
    small = rem < 6.0
    # quadratic taper: bonus = 0.05 * (1 - rem/6)^2 in [0, 0.05]
    t = 1.0 - rem / 6.0
    score += np.where(small, 0.05 * t * t, 0.0)

    return score
# EVOLVE-BLOCK-END

