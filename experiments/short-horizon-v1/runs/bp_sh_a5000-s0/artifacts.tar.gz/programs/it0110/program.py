# EVOLVE-BLOCK-START
"""Distribution-aware rule: exact fills first, then gaps tuned to small items.

Items come from a fixed Weibull-shaped distribution (mean ~40), so many items
are small. Pure best fit minimizes the immediate remainder, which frequently
leaves tiny unusable slivers. Instead, after guaranteeing the item fits, we:
  1. strongly prefer exact fills (close the bin), then
  2. among remaining bins, prefer leaving a remainder close to a typical small
     future item size, so leftover gaps can actually be reused.

The "typical small item" target is estimated online as the running median of
observed item sizes (robust and small-ish given the right-skewed Weibull shape).
"""
import numpy as np

_state = {"k": 0, "mean": 40.0, "median": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Online estimate of a typical (median) item size, for gap shaping.
    k = _state["k"] + 1
    mean = (_state["mean"] * _state["k"] + float(item)) / k
    # Exponential moving approximation of the median via mean of recent items.
    med = _state["median"]
    med = med + 0.05 * (float(item) - med)
    _state["k"] = k
    _state["mean"] = mean
    _state["median"] = med

    target = med
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Prefer leftovers close to a typical (median) future item size.
    gap_score = -np.abs(rem - target)

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return gap_score + exact_bonus
# EVOLVE-BLOCK-END
