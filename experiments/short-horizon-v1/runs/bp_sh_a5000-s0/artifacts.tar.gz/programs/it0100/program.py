# EVOLVE-BLOCK-START
"""Distribution-aware best fit with reusable-gap thresholding.

Items come from a fixed Weibull-shaped distribution (mean ~40). Pure best fit
can strand tiny unusable gaps, while aggressive worst-fit wastes capacity.
This rule:
  1. always strongly prefers an exact fill (remainder 0), then
  2. among other bins, prefers the smallest remainder that is still at least
     a typical future item size (the online-estimated mean), keeping the gap
     reusable, and
  3. if no bin leaves such a gap, falls back to best fit (smallest remainder).
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Online estimate of the mean item size (starts at 40).
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    target = _state["mean"]
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Tier 2: smallest remainder that still leaves a reusable gap (>= target).
    reusable = np.where(rem >= target, -rem, -1e9)

    # Tier 3: best fit (smallest remainder).
    best_fit = -rem

    # Tier 1: exact fills dominate everything.
    exact_bonus = np.where(rem <= 0.0, 1e6, 0.0)

    return reusable + 0.001 * best_fit + exact_bonus
# EVOLVE-BLOCK-END

