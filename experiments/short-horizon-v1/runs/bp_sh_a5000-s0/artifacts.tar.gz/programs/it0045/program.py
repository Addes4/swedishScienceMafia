# EVOLVE-BLOCK-START
"""Sum-of-Squares (SS) online bin packing rule.

For each candidate bin, the post-placement load is L = 100 - rem (where rem is
the remaining capacity after placing the current item). The SS score is L^2, and
we choose the bin minimizing L^2, i.e. the bin with the smallest resulting load.
This is the deterministic SS heuristic, which for item sizes <= 100 is known to
have better competitive behavior than Best Fit on skewed distributions.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    load = 100.0 - rem                      # resulting load of the bin
    # Minimize load^2 -> maximize negative squared load.
    return -load * load
# EVOLVE-BLOCK-END

