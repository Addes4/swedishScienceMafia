# EVOLVE-BLOCK-START
"""Distribution-aware best fit: exact fills first, then reuse-friendly gaps.

Items come from a fixed Weibull-shaped distribution with mean about 40. Pure
best fit minimizes the immediate remainder but often leaves unusable slivers.
Here we keep a small online histogram of observed item sizes, and after place-
ment we score each bin's leftover remainder by how likely it is that a future
item will *exactly* consume that remainder (peak of the estimated distribution
below the remainder). Exact fills get a large constant bonus so bins are closed
cleanly and preferentially.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0, "hist": None}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    # Maintain an online histogram over item sizes 1..100.
    hist = _state["hist"]
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        _state["hist"] = hist
    hist[int(item)] += 1.0

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Probability that a future item exactly fills each remainder: we want the
    # leftover to be a commonly occurring item size. Use the empirical
    # frequency at the remainder minus a small penalty for gaps that are too
    # large (they represent under-filled bins) so we also favor tighter fits.
    r = np.clip(rem, 0, 100)
    lo = np.floor(r).astype(np.int64)
    hi = np.minimum(lo + 1, 100)
    frac = r - lo
    # linear interpolation of histogram lookup at remainder values
    freq_at_rem = hist[lo] * (1.0 - frac) + hist[hi] * frac
    total = max(hist.sum(), 1.0)
    reuse = freq_at_rem / total

    # Mild best-fit pressure: prefer smaller remainders (tighter packing).
    best_fit = -rem * 1e-3

    # Strong bonus for exact fills so bins close preferentially.
    exact_bonus = np.where(rem <= 0.0, 1e6, 0.0)

    return reuse + best_fit + exact_bonus
# EVOLVE-BLOCK-END
