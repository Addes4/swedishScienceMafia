# EVOLVE-BLOCK-START
"""Best fit with exact-fill shortcut: always take an exact fit when available,
otherwise use plain best fit (smallest post-placement remainder)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # remaining capacity after placing (int64)
    # Primary: best fit -> smaller remainder is better (negative score).
    score = -rem.astype(np.float64)
    # Strong bonus for exact fits so an exactly-fillable bin is always chosen.
    score += 1000.0 * (rem == 0)
    return score
# EVOLVE-BLOCK-END

