# EVOLVE-BLOCK-START
"""Best fit with a usability threshold.

Items are Weibull-shaped with mean ~40, so a leftover remainder that is
positive but small is usually wasted (no future item fits it). Exact fills
(remainder 0) are perfect. Otherwise we prefer the smallest remainder that
is still large enough to be useful (>= T), and we penalize remainders that
fall into the useless "dead zone" (0 < remainder < T).
"""
import numpy as np


def priority(item, bins):
    rem = (bins - item).astype(np.float64)  # capacity left after placing

    T = 40.0  # typical future item size
    # Base: prefer small remainder (best fit direction).
    score = -rem
    # Strong bonus for exact fits.
    score += 1e6 * (rem == 0)
    # Penalize dead-zone remainders (positive but too small to be useful).
    dead = (rem > 0) & (rem < T)
    score -= 100.0 * dead
    return score
# EVOLVE-BLOCK-END

