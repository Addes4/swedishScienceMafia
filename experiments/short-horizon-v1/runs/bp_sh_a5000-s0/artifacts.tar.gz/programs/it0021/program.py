# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware remainder value term.

The item sizes come from a fixed Weibull-shaped distribution with mean about
40.  Plain best fit minimizes the immediate remainder but can strand bins with
tiny, useless remainders.  We instead score a bin by how well the remainder it
would leave matches a typical future item, while still strongly preferring
tight fits.
"""
import numpy as np

# Approximate (smooth) discrete density of the item-size distribution,
# Weibull-shaped with mean ~40, size 1..100.  Used to value remainders.
_SIZES = np.arange(0, 101, dtype=np.float64)
# Shape loosely matching mean~40 Weibull; normalized so it is a weighting only.
_lambda = 45.0
_k = 1.6
_p = (_k / _lambda) * (_SIZES / _lambda) ** (_k - 1.0) * np.exp(-(_SIZES / _lambda) ** _k)
_p[0] = 0.0
_p = _p / _p.sum()

# Cumulative usefulness: probability that a future item is <= remainder.
_CDF = np.cumsum(_p)


def priority(item, bins):
    rem = (bins - item).astype(np.float64)  # remainder after placing item
    # Base: best fit (smaller remainder better).
    # Tie-break/small correction: value of being able to still accept a future
    # item, i.e. how usable the leftover remainder is.  This is bounded in [0,1]
    # and multiplied by a small weight so tightness dominates.
    usable = _CDF[np.clip(rem, 0, 100).astype(np.int64)]
    return -rem + 4.0 * usable
# EVOLVE-BLOCK-END
