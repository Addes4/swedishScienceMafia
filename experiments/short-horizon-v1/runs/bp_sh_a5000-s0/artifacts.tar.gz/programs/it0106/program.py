# EVOLVE-BLOCK-START
"""Best-fit with distribution-aware residual utility.

Items arrive online from a fixed Weibull-shaped distribution (mean ~40).
Classic Best Fit (minimize post-placement remainder) is a strong baseline and
near-optimal on these instances, but it can leave tiny unusable gaps. We keep
Best Fit as the primary signal and add a bounded bonus when a bin's
post-placement remainder matches the size of a likely future item, estimated
from an online histogram of observed item sizes. Exact fills are strongly
preferred.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0, "hist": None, "values": None}


def _init_hist():
    # Buckets of width 5 over 1..100 -> 20 buckets, indexed 0..19.
    _state["hist"] = np.zeros(20, dtype=np.float64)
    _state["values"] = np.arange(20, dtype=np.float64) * 5.0 + 2.5


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    if _state["hist"] is None:
        _init_hist()

    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    # Update online histogram of observed item sizes.
    b = int(min(19, max(0, (int(item) - 1) // 5)))
    _state["hist"][b] += 1.0

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Probability that the next item fits exactly into the leftover gap.
    # Use the histogram: a gap of size g is "good" if some bucket center is
    # near g and that bucket has high mass.
    hist = _state["hist"]
    total = hist.sum()
    centers = _state["values"]
    # Normalized mass, smoothed.
    prob = (hist + 0.5) / (total + 10.0)

    # For each bin's remainder, find the bucket most worth leaving.
    # Utility = max over buckets of prob[b] where center <= rem (a future item
    # of that size fits), scaled by how close center is to rem (smaller waste).
    r = rem[:, None]                      # (B,1)
    c = centers[None, :]                  # (1,20)
    fits = c <= r + 1e-9                  # future item of this size fits
    # Closeness: reward remainders near a bucket center (low waste).
    closeness = np.exp(-np.abs(r - c) / 8.0)   # (B,20)
    util = np.max(prob[None, :] * closeness * fits, axis=1)

    # Primary: Best Fit -> smaller remainder better.
    best_fit = -rem

    # Exact fills dominate.
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    # Secondary distribution-aware utility kept small so it only breaks ties.
    return best_fit + 0.6 * util + exact_bonus
# EVOLVE-BLOCK-END

