# EVOLVE-BLOCK-START
"""Best fit with an adaptive tie-break: prefer small remainders, but add a
smooth bonus when the leftover capacity matches a frequently seen item size,
so future items are more likely to fill bins exactly."""
import numpy as np


class _State:
    def __init__(self):
        # online histogram of observed item sizes (1..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0

    def observe(self, item):
        self.hist[item] += 1.0
        self.count += 1.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins.astype(np.int64) - item  # leftover after placing (>= 0)
    _state.observe(item)

    # Empirical probability that a future item equals a given size.
    if _state.count > 0:
        freq = _state.hist / _state.count
    else:
        freq = np.zeros(101, dtype=np.float64)

    # Expected chance the leftover capacity can be exactly filled by a common
    # item size: sum of freq over sizes <= rem, weighting larger (more likely
    # second-fill) sizes more.  This is the probability the bin is "closable".
    # Cumulative mass of sizes <= rem.
    cum = np.cumsum(freq)  # cum[r] = P(item <= r)
    cum = np.concatenate(([0.0], cum))  # index by rem 0..100

    rem_clip = np.clip(rem, 0, 100)
    closable = cum[rem_clip]  # P(next fitting item can still fit) in [0,1]

    # Dominant rule: best fit (small remainder is better).
    # Secondary: reward remainders that are more likely to be exactly filled
    # (higher closable mass).  Small weight keeps best-fit dominant.
    return -rem.astype(np.float64) + 0.05 * closable
# EVOLVE-BLOCK-END

