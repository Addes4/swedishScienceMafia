# EVOLVE-BLOCK-START
"""Pure best fit: prefer the smallest post-placement remainder, with a
priority boost for exact fills. Best fit is a strong, well-understood
rule for this item distribution; avoid extra heuristics that perturb it."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Strict best fit: smaller remainder is better.
    score = -rem
    # Strongly prefer exact fills so bins get closed completely.
    score += 1000.0 * (rem == 0.0)
    return score
# EVOLVE-BLOCK-END

