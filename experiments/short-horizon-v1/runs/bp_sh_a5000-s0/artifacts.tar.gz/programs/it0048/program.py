# EVOLVE-BLOCK-START
"""Best fit with a smooth, peaked exact-fill bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Best fit: smaller remainder is better (negative score).
    # Smooth peaked bonus: strongly reward near-exact fills, peaking at rem==0.
    bonus = 2.0 * np.exp(-(rem * rem) / 8.0)
    return -rem - bonus
# EVOLVE-BLOCK-END

