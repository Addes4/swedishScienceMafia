# EVOLVE-BLOCK-START
"""Best fit with nonlinear tight-fit emphasis: prefer small remainders,
with a convex bonus rewarding near-exact fills."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Best fit: smaller remainder is better (negative score).
    # Convex bonus: strongly reward near-exact fills (small remainder) to
    # improve packing density beyond plain linear best fit.
    return -rem - 0.02 * (100.0 - rem) * (rem < 5)
# EVOLVE-BLOCK-END
