# EVOLVE-BLOCK-START
"""Best fit with an online item-size-distribution tie-breaker.

Dominant criterion: minimize the post-placement remainder (best fit).
Tie-breaker: when two bins give a similar remainder, prefer the remainder that
matches the most frequently observed item sizes so far, so that future items
are likely to close the bin exactly.
"""
import numpy as np

# Module-level state (one histogram per stream lifetime).
_counts = None
_total = 0


def _ensure():
    global _counts
    if _counts is None:
        # counts for sizes 1..100 (index 0 unused)
        _counts = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    global _counts, _total
    _ensure()

    item = int(item)

    rem = (bins - item).astype(np.float64)  # remainder after placing

    # Best fit: smaller remainder is better.
    base = -rem

    # Distribution-based tie-break: reward remainders that are common item sizes.
    # Normalize counts into a probability-like weight per remainder value.
    tot = _total + 1.0
    probs = _counts / tot  # probs[r] approx P(item == r), r=0 means exact close

    # Map remainder (integer) to weight; only consider small remainders.
    r_int = np.clip(np.rint(rem).astype(np.int64), 0, 100)
    match = probs[r_int].copy()
    # Exact fill (remainder 0) is the best possible outcome.
    match[rem == 0.0] = match.max() + 1.0 if match.size else 1.0

    # Combine: dominant best-fit plus a gentle distribution match bonus that is
    # only significant among near-tied remainders.
    score = base + 0.5 * match

    # Update histogram with the current item after scoring.
    _counts[item] += 1.0
    _total += 1.0

    return score
# EVOLVE-BLOCK-END

