# EVOLVE-BLOCK-START
"""Best fit augmented with an empirical exact-fill probability bonus.

Primary rule: ascending post-placement remainder (best fit).
Tie-break/bonus: reward bins whose remainder matches a frequently seen item
size, using a running histogram of the stream so far (never future items).
"""
import numpy as np

# Module-level state: running histogram of item sizes seen (index 1..100).
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    global _TOTAL
    rem = (bins - item).astype(np.float64)  # remaining after placing

    # Update running histogram with the current item.
    _HIST[item] += 1.0
    _TOTAL += 1.0

    # Empirical probability that a future item exactly fills each remainder.
    # Keep it small so it never overrides a clear best-fit advantage.
    fill_prob = _HIST / _TOTAL  # length 101

    idx = rem.astype(np.int64)
    np.clip(idx, 0, 100, out=idx)
    bonus = fill_prob[idx]

    # Best fit dominant; small empirical exact-fill bonus as tie-break.
    return -rem + 0.05 * bonus
# EVOLVE-BLOCK-END

