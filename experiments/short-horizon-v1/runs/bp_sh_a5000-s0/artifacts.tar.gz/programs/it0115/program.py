# EVOLVE-BLOCK-START
"""Best-fit with exact-fill preference and reusable-gap tie-break.

Items arrive online from a fixed Weibull-shaped distribution (mean ~40).
The robust near-optimal online rule here is classic Best Fit: place the item
in the fitting bin that leaves the smallest remainder, keeping bins full and
minimizing waste.  Exact fills (remainder 0) are already the extreme case of
this, so they win automatically.  We add only a tiny tie-break that, among
bins with nearly equal remainder, prefers remainders close to the typical
future item size (running mean), so leftover gaps stay reusable.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Online estimate of the mean item size (starts at 40).
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    target = _state["mean"]
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Primary: smallest remainder (best fit). Negated so higher score wins.
    main = -rem

    # Tiny tie-break: prefer remainders close to a typical future item size,
    # so leftover gaps are reusable.  Scale stays small relative to 1 unit of
    # remainder, so it only breaks near-ties.
    tie = -0.01 * np.abs(rem - target)

    return main + tie
# EVOLVE-BLOCK-END

