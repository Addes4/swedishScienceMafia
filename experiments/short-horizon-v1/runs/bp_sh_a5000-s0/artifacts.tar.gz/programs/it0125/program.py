# EVOLVE-BLOCK-START
"""Distribution-aware best fit using a running item-size histogram.

Items come from a fixed distribution (mean ~40). Pure best fit is strong but
sometimes leaves tiny unusable gaps. We therefore:
  1. Strongly prefer bins the item exactly fills (remainder 0).
  2. For other bins, prefer the *smallest* remainder (classic best fit), but
     add a distribution-aware bonus for remainders that themselves look like
     common future item sizes, so leftover gaps stay reusable.

Future item sizes are estimated online with a simple running histogram over
the observed stream, kept cheap (O(1) per item, size-101 array).
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Online update of statistics over past (and current) items.
    _state["mean"] = (_state["mean"] * _state["n"] + float(item)) / (_state["n"] + 1.0)
    _state["n"] += 1.0
    hist = _state["hist"]
    hist[int(item)] += 1.0

    n = _state["n"]
    # Estimate probability that a future item exactly matches a given remainder.
    prob = hist / n  # prob[r] ~ P(item == r)

    rem = (bins - item).astype(np.float64)  # remainder after placing

    exact_mask = rem <= 0.0
    # Usability of the leftover gap: probability it is filled by a future item,
    # smoothed so small nonzero remainders still get some credit.
    usable = np.zeros_like(rem)
    idx = np.clip(rem.astype(np.int64), 0, 100)
    usable = prob[idx]
    # Fallback when histogram is empty / no mass: mild preference for smaller gaps.
    usable = usable + 1e-6 / (rem + 1.0)

    # Primary best-fit signal (smaller remainder better) plus usability bonus.
    gap_score = -0.01 * rem + 10.0 * usable
    exact_bonus = np.where(exact_mask, 1000.0, 0.0)

    return gap_score + exact_bonus
# EVOLVE-BLOCK-END
