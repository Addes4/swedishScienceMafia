# EVOLVE-BLOCK-START
"""Distribution-aware best fit: exact fits first, then keep reusable gaps."""
import numpy as np

_state = {"n": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    target = _state["mean"]
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Asymmetric distance: penalize remainders smaller than the target more,
    # since tiny stranded gaps are useless, but modestly favor larger gaps.
    diff = rem - target
    dist = np.where(diff >= 0.0, diff * 0.8, -diff * 1.2)

    gap_score = -dist

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    # Mild bias toward bins that keep more total capacity (useful for big items).
    cap_bias = 0.01 * bins.astype(np.float64)

    return gap_score + exact_bonus + cap_bias
# EVOLVE-BLOCK-END
