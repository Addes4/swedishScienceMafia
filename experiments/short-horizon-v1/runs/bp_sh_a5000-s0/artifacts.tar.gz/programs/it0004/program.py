# EVOLVE-BLOCK-START
"""Best fit with a mild distribution-aware tie-breaker.

Pure best fit packs tightly, but a tiny bias toward leaving a residual close to the
typical item size helps reduce fragmented leftovers (bins that are too empty to be
useful but too full to accept medium items). We keep best fit as the dominant term
and add a small correction based on a running mean of item sizes seen so far.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    # Update running statistics of arrived items (online, no future info).
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    # Dominant term: best fit wants the smallest remaining capacity that still fits.
    tightness = -(bins - item)

    # Residual after placing: prefer it to be close to the mean item size so the
    # leftover space can hold a typical future item rather than being wasted.
    residual = bins - item
    residual_bonus = -np.abs(residual - mean_item)

    # Small weight so this only breaks near-ties, never overrides tightness.
    return tightness * 1000.0 + residual_bonus
# EVOLVE-BLOCK-END

