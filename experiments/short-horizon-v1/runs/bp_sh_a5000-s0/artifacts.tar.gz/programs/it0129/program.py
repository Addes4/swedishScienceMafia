# EVOLVE-BLOCK-START
"""Distribution-aware best fit guided by pair-ability of leftovers.

Items come from a fixed Weibull-shaped distribution with mean about 40.
Pure best fit minimizes the immediate remainder but frequently strands tiny
unusable gaps. Here, after the (always-fitting) bins are shown, we rank them:
  1. exact fills (remainder 0) get a strong bonus, then
  2. among the rest, we prefer remainders that combine with the online-estimated
     mean item size to exactly fill another bin, i.e. rem close to (100 - mean),
     keeping leftover space reusable by a typical future item.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    mean = _state["mean"]
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Reward remainders that a typical future item (mean-sized) can pair with
    # to fill a fresh bin; also modestly prefer smaller gaps (tie-break).
    pair_target = 100.0 - mean
    pair_score = -np.abs(rem - pair_target)
    small_gap = -0.5 * rem

    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return pair_score + small_gap + exact_bonus
# EVOLVE-BLOCK-END

