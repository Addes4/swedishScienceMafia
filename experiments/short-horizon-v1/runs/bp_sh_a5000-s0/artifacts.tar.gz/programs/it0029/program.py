# EVOLVE-BLOCK-START
"""Best fit with unused-bin deferral: prefer the tightest fitting partial bin,
only open a fresh bin when no partial bin gives a sufficiently tight fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    unused = bins == 100  # never-used bins

    # Base: best fit -> smaller post-placement remainder is better.
    score = -rem

    # Defer opening fresh bins: penalize unused bins so any fitting partial bin
    # (even a loose one) wins over opening a new bin. Fresh bins only win when
    # no partial bin can hold the item at all.
    score = score - 1000.0 * unused

    # Strong bonus for closing a bin exactly.
    score = score + 50.0 * (rem == 0)

    return score
# EVOLVE-BLOCK-END
