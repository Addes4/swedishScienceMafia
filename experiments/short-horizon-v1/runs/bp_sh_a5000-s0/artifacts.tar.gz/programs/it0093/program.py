# EVOLVE-BLOCK-START
"""Distribution-aware best fit with reusable-gap preference.

Items are drawn from a fixed Weibull-shaped distribution with mean about 40.
Pure best fit minimizes the immediate remainder, which often leaves tiny
unusable gaps. We rank bins so that:
  1. exact fills (remainder 0) are strongly preferred, then
  2. among remaining bins, a remainder that is still large enough to hold a
     typical future item is preferred over a tiny stranded gap; among usable
     remainders we still favor the smaller one (best-fit-like consolidation).
"""
import numpy as np

_target = 40.0  # online estimate of the mean item size


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    global _target
    # Gentle online estimate of the mean item size.
    _target = 0.999 * _target + 0.001 * float(item)

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    # Reusable-gap score: a remainder >= target is "usable"; smaller remainders
    # are penalized so best-fit still consolidates but avoids tiny gaps.
    usable = rem >= _target
    gap_score = np.where(usable, -rem, -(2.0 * _target - rem))

    return gap_score + exact_bonus
# EVOLVE-BLOCK-END
