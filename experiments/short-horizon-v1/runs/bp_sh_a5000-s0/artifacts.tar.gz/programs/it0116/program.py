# EVOLVE-BLOCK-START
"""Distribution-aware best fit with a mode-based reusable-gap target.

Items come from a fixed Weibull-shaped distribution (mean ~40). Pure best fit
minimizes the immediate remainder but leaves tiny unusable gaps. Here we:
  1. strongly prefer exact fills (remainder 0),
  2. otherwise prefer leaving a remainder equal to the most common item size
     seen so far (online histogram mode), so leftover gaps are likely to be
     filled by a frequent future item.
"""
import numpy as np

_state = {"n": 0.0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    hist = _state["hist"]
    hist[int(item)] += 1.0
    _state["n"] += 1.0

    # Empirical mode of item sizes seen so far (fallback to mean ~40).
    if _state["n"] > 0:
        target = float(np.argmax(hist))
    else:
        target = 40.0

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    gap_score = -np.abs(rem - target)
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return gap_score + exact_bonus
# EVOLVE-BLOCK-END
