# EVOLVE-BLOCK-START
"""Best-fit with a mean-aligned tie-break and exact-fill preference.

Pure best fit (smallest post-placement remainder) is a strong near-optimal
online rule for this Weibull-shaped item distribution. We keep that as the
dominant signal, add a strong bonus for exact fills, and use a weak
mean-alignment term so that among bins with nearly equal remainders the one
whose leftover gap best matches a typical future item size is preferred.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Online estimate of the mean item size (starts at 40).
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    item = float(item)
    target = _state["mean"]
    rem = bins.astype(np.float64) - item  # remaining capacity after placing

    # Dominant signal: prefer the smallest post-placement remainder (best fit).
    best_fit = -rem

    # Weak tie-break: prefer remainders close to a typical future item size.
    mean_align = -np.abs(rem - target) * 0.05

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return best_fit + mean_align + exact_bonus
# EVOLVE-BLOCK-END
