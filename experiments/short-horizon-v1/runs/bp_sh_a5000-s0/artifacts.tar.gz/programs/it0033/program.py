# EVOLVE-BLOCK-START
"""Best fit + cheap online-histogram "fillability" bonus.

Primary term: best fit (smaller post-placement remainder wins).
Secondary term: reward bins whose post-placement remainder is a likely
future item size, so the bin can be closed exactly soon. The histogram is
updated incrementally; a single length-101 weight table is used so the
lookup is O(len(bins)) and fast even on 5000-item streams.
"""
import numpy as np

_CAP = 100


def priority(item, bins):
    rem = bins - item  # int64, remaining capacity after placing

    # Build/refresh a length-(_CAP+1) "fillability" weight table.
    # weight[r] = relative likelihood that a future item has size r.
    # We approximate with an online histogram of observed items.
    hist = getattr(priority, "_hist", None)
    if hist is None:
        hist = np.ones(_CAP + 1, dtype=np.float64)
        priority._hist = hist
        priority._count = 0.0

    # Incremental update (Laplace-smoothed histogram).
    hist[item] += 1.0
    priority._count += 1.0

    # Smoothed probability weights. Normalize lazily.
    c = priority._count
    # weights proportional to (hist), but keep a small floor so unseen sizes
    # still get nonzero weight.
    w = hist / (c + _CAP)

    # Score: best fit dominant (negative remainder), plus a bonus when the
    # leftover remainder is a plausible future item size (fillable soon).
    # Clip indices to valid range.
    idx = np.clip(rem, 0, _CAP)
    fill_bonus = w[idx]

    # Convex tight-fit bonus for near-exact fills (small remainder).
    tight = np.where(rem <= 20, (21 - rem), 0).astype(np.float64)
    tight_bonus = 0.0008 * tight * tight

    return -rem.astype(np.float64) + 0.5 * fill_bonus + tight_bonus
# EVOLVE-BLOCK-END
