# EVOLVE-BLOCK-START
"""Best fit with smooth tight-fit emphasis."""
import numpy as np


def priority(item, bins):
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Base: best fit (smaller remainder preferred).
    # Smooth bonus: reward near-exact fills more strongly and continuously,
    # scaling with how tight the fit is relative to the item size.
    return -rem - 0.05 * np.exp(-rem / 8.0)
# EVOLVE-BLOCK-END
