# EVOLVE-BLOCK-START
"""Best fit with slack reservation: prefer small remainders, but among
near-ties avoid creating residues smaller than the smallest item seen."""
import numpy as np


def priority(item, bins):
    rem = (bins - item).astype(np.float64)
    # Track smallest item seen so far (module-level state persists per stream).
    global _min_seen
    try:
        _min_seen
    except NameError:
        _min_seen = 100

    if item < _min_seen:
        _min_seen = item
    m = float(_min_seen)

    # Dominant term: best fit (smaller remainder better).
    score = -rem
    # Penalize residues that are too small to ever be filled (< smallest item),
    # unless they are exactly zero (perfect fill).
    tiny = (rem > 0) & (rem < m)
    score -= 0.5 * tiny.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
