# EVOLVE-BLOCK-START
"""Best fit with a tie-break that favors fuller existing bins.

Plain best fit minimizes the post-placement remainder. Ties (and near-ties
within a small slack) are common with integer sizes; resolving them in favor
of the bin that is already fuller (smaller remaining capacity before the
placement) keeps leftovers concentrated so they are more likely to be filled
later, instead of spreading capacity thinly across many bins.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item            # remaining capacity after placing the item
    # Primary term: minimize the resulting remainder (best fit).
    # Secondary term: slightly favor bins that were fuller before placement,
    # i.e. smaller pre-placement capacity, to consolidate leftovers.
    return -rem.astype(np.float64) - 0.001 * bins.astype(np.float64)
# EVOLVE-BLOCK-END
