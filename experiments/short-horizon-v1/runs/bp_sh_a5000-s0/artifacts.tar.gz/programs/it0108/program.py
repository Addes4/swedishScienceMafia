# EVOLVE-BLOCK-START
"""Distribution-aware best fit using the most probable reusable gap.

Items come from a fixed Weibull-shaped distribution (mean about 40). Pure best
fit leaves many tiny gaps that can never be reused. Here we estimate an online
histogram of observed item sizes and, for each bin, ask: what is the most
probable item size that could still fit into this bin after placement? We then
prefer bins whose post-placement remainder is close to such a "reusable" size,
which keeps gaps useful for future items. Exact fills get a strong bonus.
"""
import numpy as np

_MAXSIZE = 101
_state = {"n": 0.0, "mean": 40.0, "hist": np.zeros(_MAXSIZE, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0
    _state["hist"][int(item)] += 1.0

    rem = (bins - item).astype(np.int64)  # remaining capacity after placing

    # Estimate the most probable future item size that fits in some remainder.
    # Use the running histogram; fall back to the mean before enough data.
    hist = _state["hist"]
    total = float(n + 1.0)
    target = _state["mean"]
    if total >= 30.0:
        # Most probable item size (mode) over observed sizes.
        best_s, best_p = int(target), -1.0
        for s in range(1, _MAXSIZE):
            p = hist[s]
            if p > best_p:
                best_p = p
                best_s = s
        target = float(best_s)

    rem_f = rem.astype(np.float64)

    # Prefer remainders that match a typical future item size (reusable gap).
    gap_score = -np.abs(rem_f - target)

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0, 1000.0, 0.0)

    return gap_score + exact_bonus
# EVOLVE-BLOCK-END
