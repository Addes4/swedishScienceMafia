# EVOLVE-BLOCK-START
"""Best fit with a smooth near-exact-fill bonus over a wider band."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Best fit: smaller remainder is better (negative score).
    # Smooth bonus strongly rewarding near-exact fills over a wider band,
    # decaying quadratically so it never overrides a clear best-fit advantage.
    bonus = 0.05 * np.exp(-rem / 8.0) * item
    return -rem - bonus
# EVOLVE-BLOCK-END

