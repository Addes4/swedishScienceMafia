# EVOLVE-BLOCK-START
"""Best fit with a data-driven "useful remainder" preference.

Plain best fit minimizes the leftover space. A pure tiny-remainder bias can
hurt because a nearly-full bin is dead weight. Instead we favor remainders
that are just below a typical future item size (so the bin can still accept
a common item) while still penalizing wasted space.
"""
import numpy as np

# Running statistics of items seen in the current stream.
_count = 0
_mean = 40.0


def priority(item, bins):
    global _count, _mean
    # Update running mean of item sizes (Welford-free simple average).
    _count += 1
    _mean += (float(item) - _mean) / _count

    rem = (bins - item).astype(np.float64)  # capacity left after placing

    # Base: best fit, prefer smaller remainder (negative score).
    score = -rem

    # Reward bins whose remainder stays useful: remainders close to a typical
    # item size (mean) can still fit a common future item. Remainders that are
    # small (useless dead space) or large (fresh bin) are less favored.
    target = _mean
    # A smooth bump centered at `target`, width about half the mean, capped.
    diff = rem - target
    bonus = np.exp(-(diff * diff) / (2.0 * (target * 0.5 + 1.0) ** 2))
    # Only mildly weight this against the base best-fit term.
    score += 1.5 * bonus * (rem < target)

    return score
# EVOLVE-BLOCK-END
