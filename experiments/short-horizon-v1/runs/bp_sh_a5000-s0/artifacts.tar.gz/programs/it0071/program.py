# EVOLVE-BLOCK-START
"""Best fit with exact-fill bonus and flexible tie-breaking."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)
    # Dominant term: best fit (smaller post-placement remainder is better).
    score = -rem
    # Strong reward for exact fills.
    score += 50.0 * (rem == 0)
    # Tiny nudge: among nonzero remainders, slightly prefer larger ones so
    # flexible bins are not prematurely closed into useless tiny residues.
    score += 1e-3 * (100.0 - rem) * (rem > 0)
    return score
# EVOLVE-BLOCK-END

