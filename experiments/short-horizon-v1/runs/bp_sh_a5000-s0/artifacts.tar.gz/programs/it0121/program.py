# EVOLVE-BLOCK-START
"""Distribution-aware best fit with exact-fill and reusable-gap shaping.

Items come from a fixed Weibull-shaped distribution (mean ~40). Bin selection
only sees bins that already fit the item. We rank bins so that:
  1. exact fills (remainder 0) are taken with a large bonus, then
  2. among other bins, we prefer remainders that are "reusable": either close
     to a typical future item size (the running mean), so the leftover gap can
     accept a common item, using a multiplicative closeness rather than an
     absolute difference (more forgiving for large mean), and
  3. a small best-fit tie-break pushes toward smaller remainders to keep the
     overall waste low (best fit is near-optimal for this distribution).
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    target = _state["mean"]
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Prefer remainders that are close to a typical future item size.
    # Use a relative closeness so gaps around the mean are favored symmetric-ish.
    closeness = -np.abs(rem - target) / (target + 1.0)

    # Small best-fit pull: slightly favor smaller remainders among otherwise
    # equivalent candidates, reducing residual waste without dominating.
    best_fit = -rem / (target + 1.0)

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return closeness * 0.6 + best_fit * 0.2 + exact_bonus
# EVOLVE-BLOCK-END

