# EVOLVE-BLOCK-START
"""Best fit with exact-fill bonus and usable-remainder tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Base: best fit (smaller remainder better).
    score = -rem

    # Strong bonus for exact fills.
    score += 2.0 * (rem == 0)

    # Among very close remainders (within 3 of each other), prefer the larger
    # remainder when it is still "usable" (>= 10), to keep bins flexible for
    # future small items; this softens best-fit's tendency to leave tiny,
    # hard-to-fill residues.
    near = (rem > 0) & (rem < 10)
    score += 0.3 * (rem >= 10)

    return score
# EVOLVE-BLOCK-END

