# EVOLVE-BLOCK-START
"""Best fit with exact-fit preference.

Standard Best Fit minimizes the post-placement remainder.  Empirically the
main source of extra bins in online packing is failing to recognize exact or
near-exact fills, so we add a large bonus when the item fits exactly (zero
remainder) and a graded bonus for very small remainders, without disturbing
the primary best-fit ordering elsewhere.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remainder after placing
    # Primary: best fit (smaller remainder better).
    score = -rem
    # Strongly reward exact fills, then near-exact fills, to close gaps.
    score += 200.0 * (rem == 0.0)
    score += 50.0 * ((rem > 0.0) & (rem <= 2.0))
    score += 10.0 * ((rem > 2.0) & (rem <= 5.0))
    return score
# EVOLVE-BLOCK-END

