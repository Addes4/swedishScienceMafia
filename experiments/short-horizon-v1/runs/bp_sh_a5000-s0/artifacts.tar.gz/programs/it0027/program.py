# EVOLVE-BLOCK-START
"""Best fit with an opening guard.

Standard online best fit: place the item into the fitting bin that leaves the
smallest remainder. The refinement here is a guard: when the only available fits
leave a remainder that is larger than what we'd typically want, we compare
against the fully-empty bin (remainder 100). This avoids committing items into
bins that will end up fragmenting, and instead lets a fresh bin start, which
tends to reduce total bin count on heavy-tailed item distributions.
"""
import numpy as np


def priority(item, bins):
    rem = bins - item  # post-placement remainder for every fitting bin

    # Base: strict best fit prefers the smallest remainder (negative score).
    score = -rem.astype(np.float64)

    # Opening guard: discourage leaving large remainders so that, when no tight
    # fit exists, a fresh bin (rem == 100 - item, i.e. an empty bin) can win.
    # Any bin that would leave a remainder above a soft threshold is penalized
    # proportionally to how fragmented it is.
    thr = float(item)
    excess = (rem.astype(np.float64) - thr)
    score -= 0.5 * np.maximum(excess, 0.0)

    return score
# EVOLVE-BLOCK-END

