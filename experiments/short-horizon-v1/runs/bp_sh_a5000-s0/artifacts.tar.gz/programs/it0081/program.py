# EVOLVE-BLOCK-START
"""Best fit with an empirical "fill-probability" bonus.

Primary rule stays best-fit (ascending post-placement remainder). We add a
small bonus to a bin if its post-placement remainder equals a size that has
been frequently seen, raising the chance that leftover gap actually gets filled
by a future item, which reduces total bins.
"""
import numpy as np

_SIZE = 101


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    # Lazily initialised histogram of observed item sizes (shared across calls
    # within a stream via an attribute on the function object).
    hist = getattr(priority, "_hist", None)
    total = getattr(priority, "_total", 0)
    if hist is None:
        hist = np.zeros(_SIZE, dtype=np.float64)
        priority._hist = hist
    # Update with the current item (it has now been "seen").
    if 1 <= item < _SIZE:
        hist[item] += 1.0
        total += 1.0
    priority._total = total

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Best fit: smaller remainder is strictly better (negative score).
    score = -rem

    # Empirical fill bonus: how often have we seen an item of size == rem?
    if total > 0:
        remi = np.clip(rem, 0, _SIZE - 1).astype(np.int64)
        # Only reward genuinely reusable remainders (skip 0 and huge gaps).
        prob = hist[remi] / total
        score += prob

    return score
# EVOLVE-BLOCK-END

