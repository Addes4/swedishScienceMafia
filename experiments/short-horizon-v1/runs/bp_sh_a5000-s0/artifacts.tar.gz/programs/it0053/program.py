# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware sweet-spot bonus for reusable remainders."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Base: best fit (smaller remainder is better).
    score = -rem
    # Sweet-spot bonus: a post-placement remainder near a typical item size
    # (~40, the distribution mean) can be closed by a single future item, so
    # leaving such a remainder is slightly more valuable than a very small but
    # useless remainder. Give a gentle secondary reward.
    # Gaussian bump centered at ~40 with modest width, scaled small so it only
    # breaks near-ties and never overrides strong best-fit preference.
    bump = np.exp(-((rem - 40.0) ** 2) / (2.0 * 15.0 * 15.0))
    # Only relevant when there is a meaningful remainder left (not near-full).
    score += 0.05 * bump * (rem >= 20.0)
    # Keep an edge for near-exact fills so packing density is not lost.
    score += 0.02 * (rem < 5)
    return score
# EVOLVE-BLOCK-END
