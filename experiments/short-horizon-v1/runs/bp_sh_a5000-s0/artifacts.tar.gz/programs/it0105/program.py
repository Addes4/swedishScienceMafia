# EVOLVE-BLOCK-START
"""Best fit with exact-fill priority.

Items arrive online into capacity-100 bins. Pure Best Fit (place into the bin
that leaves the smallest non-negative remainder) is a strong baseline for this
Weibull-shaped distribution. We reinforce it with a single lexicographic bonus
for exact fills so that any bin closed perfectly is chosen over a near fill,
which prevents a slightly-worse near-exact placement from blocking a perfect one.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Best fit: smaller remainder is better.
    score = -rem

    # Strong lexicographic bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return score + exact_bonus
# EVOLVE-BLOCK-END
