# EVOLVE-BLOCK-START
"""Best fit with a "useful remainder" bonus.

Base rule is classic best fit (prefer the bin leaving the smallest remainder),
but we add a small bonus when the post-placement remainder is close to a
typical item size (~mean 40 of the Weibull item distribution).  Leave-behind
space that can plausibly accept an average future item is more valuable than
space that is too small to be filled, which improves density on mean-40
streams without over-tuning to any single instance.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Best fit: smaller remainder is better -> negative score.
    # Bonus (bounded, [0,1]) peaking when the leftover is around a typical
    # future item size (~40), so bins left with useful space are preferred.
    mu = 40.0
    useful = np.exp(-((rem - mu) ** 2) / (2.0 * 25.0 ** 2))

    return -rem + 1.5 * useful
# EVOLVE-BLOCK-END

