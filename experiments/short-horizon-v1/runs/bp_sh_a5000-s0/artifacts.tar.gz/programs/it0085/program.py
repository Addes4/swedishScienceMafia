# EVOLVE-BLOCK-START
"""Plain best fit: prefer the bin that leaves the smallest remainder."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # remaining capacity after placing
    return -rem.astype(np.float64)
# EVOLVE-BLOCK-END

