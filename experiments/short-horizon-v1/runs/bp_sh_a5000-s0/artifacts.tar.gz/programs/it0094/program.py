# EVOLVE-BLOCK-START
"""Best-fit with exact-fit priority and reusable-gap tie-break.

Items come from a fixed Weibull-shaped distribution with mean ~40. Pure best
fit leaves many tiny stranded remainders. We keep best fit's core (push items
into the fullest fitting bin) but add a reusable-gap objective so that leftover
space stays large enough to hold a typical future item.
"""
import numpy as np

_MEAN = 40.0  # approximate mean item size of the fixed distribution


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Favor reusable gaps: reward remainders that stay at least one typical
    # item, and mildly prefer larger but still packable gaps.
    reusable = np.where(rem >= _MEAN, 1.0, 0.0)
    # Best-fit core: smaller remainder is better (already-filling bins first).
    best_fit = -rem

    # Strong bonus for exact fills.
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return best_fit + 0.5 * reusable + exact_bonus
# EVOLVE-BLOCK-END
