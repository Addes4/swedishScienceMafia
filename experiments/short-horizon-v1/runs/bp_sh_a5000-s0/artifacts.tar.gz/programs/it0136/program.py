# EVOLVE-BLOCK-START
"""Distribution-aware best fit with histogram-based gap fillability.

Items come from a fixed Weibull-shaped distribution (mean ~40). Pure best fit
minimizes the immediate remainder but leaves tiny unusable gaps.

We maintain an online histogram of past item sizes and score each bin by:
  1. A strong bonus for exact fills (remainder 0).
  2. Otherwise, how "fillable" the resulting remainder is: the probability
     that one of the common past item sizes lands exactly on the gap, which
     keeps gaps reusable without relying on a single noisy median.
  3. A mild best-fit tie-break (prefer smaller remainders when equal).
"""
import numpy as np

# 100 buckets, one per possible item size 1..100
_state = {"n": 0.0, "mean": 40.0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    hist = _state["hist"]
    hist[item] += 1.0

    total = _state["n"]
    # Probability mass that each candidate remainder r would be exactly hit
    # by a future item of size r.  Use a soft window of +/-1 to be robust to
    # integer rounding and nearby sizes.
    fill = hist + np.roll(hist, 1) + np.roll(hist, -1)
    # Simple Laplace-style smoothing so unseen sizes aren't fully excluded.
    prob = (fill + 0.5) / (3.0 * total + 100.0)

    rem = (bins - item).astype(np.int64)
    rem_clipped = np.clip(rem, 0, 100)

    # Fillability of the leftover gap: high when a common item closes it.
    fill_score = 50.0 * prob[rem_clipped]

    # Strong bonus for exact fills.
    exact_bonus = np.where(rem <= 0, 1000.0, 0.0)

    # Mild best-fit tie-break: slightly prefer tighter remainders.
    tight = -0.05 * rem_clipped

    return fill_score + exact_bonus + tight
# EVOLVE-BLOCK-END
