# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and density tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # remaining capacity after placing (int64)
    # Best fit: smaller remainder is better.
    score = -rem.astype(np.float64)
    # Slight bonus for exact fills to break ties toward closing bins.
    score += 0.5 * (rem == 0)
    return score
# EVOLVE-BLOCK-END

