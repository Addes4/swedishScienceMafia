# EVOLVE-BLOCK-START
"""Best fit with a smooth tie-break toward residuals that remain useful for
future items, using an online estimate of the mean item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    # Online estimate of the mean item size (running average), used to define a
    # "useful residual" target. State kept on the function object.
    if not hasattr(priority, "n"):
        priority.n = 0
        priority.total = 0.0
    priority.n += 1
    priority.total += item
    mean_item = priority.total / priority.n

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Dominant term: Best Fit (smaller remainder is better).
    score = -rem

    # Smooth tie-break: reward remainders that are close to a productive
    # residual (~ the typical item size), so bins stay fillable by future items.
    # This is small relative to the 1-unit spacing of remainders, so it only
    # resolves near-ties in favor of more useful residuals.
    diff = rem - mean_item
    score += 0.05 * np.exp(-(diff * diff) / (2.0 * (mean_item * mean_item + 1.0)))

    return score
# EVOLVE-BLOCK-END
