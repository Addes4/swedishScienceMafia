# EVOLVE-BLOCK-START
"""Density-first bin choice: maximize the fraction of capacity filled after
placement, so existing bins are packed as densely as possible before new
(100-capacity) bins are opened."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    filled = (100.0 - (bins - item)).astype(np.float64)  # capacity used after placing
    frac = filled / 100.0
    # Prefer denser bins; small penalty for opening a brand-new empty bin.
    penalty = 0.03 * (bins == 100)
    return frac - penalty
# EVOLVE-BLOCK-END
