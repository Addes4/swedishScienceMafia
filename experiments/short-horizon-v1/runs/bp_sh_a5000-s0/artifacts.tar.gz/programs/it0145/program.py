# EVOLVE-BLOCK-START
"""Distribution-aware best fit with online kernel density of remainder fit.

Items come from a fixed Weibull-shaped distribution (mean ~40). Pure best fit
minimizes the immediate remainder but leaves tiny unusable gaps. Here we:
  1. Strongly prefer exact fills (remainder 0).
  2. Otherwise prefer the post-placement remainder that is most likely to be
     hit exactly by some future item, estimated with an online kernel density
     over past item sizes (rewards remainders near probable future sizes).
"""
import numpy as np

_state = {"res": [], "seen": 0}

_MAX_RES = 256
_BW = 6.0            # kernel bandwidth in item-size units
_GRID_STEP = 1.0     # remainder axis is integer-sized


def _kde_weights(sample):
    """Return a dict-free array of sample sizes to use as kernels."""
    return sample


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Maintain a bounded reservoir sample of past item sizes.
    _state["seen"] += 1
    res = _state["res"]
    if len(res) < _MAX_RES:
        res.append(float(item))
    else:
        j = int(np.random.randint(0, _state["seen"]))
        if j < _MAX_RES:
            res[j] = float(item)

    rem = (bins - item).astype(np.float64)  # capacity left after placing

    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    if res:
        sample = np.asarray(res, dtype=np.float64)
        # Gaussian-kernel density of the item distribution evaluated at each rem.
        # fit[r] = sum_s exp(-0.5*((r - s)/bw)^2)
        d = (rem[:, None] - sample[None, :]) / _BW
        fit = np.exp(-0.5 * d * d).sum(axis=1)
    else:
        fit = np.zeros_like(rem)

    # Only consider positive remainders for the gap-reuse reward.
    fit = np.where(rem > 0.0, fit, 0.0)

    return fit + exact_bonus
# EVOLVE-BLOCK-END
