# EVOLVE-BLOCK-START
"""Best fit with a "fewest future items to fill" secondary objective.

The dominant rule stays best fit (smallest post-placement remainder wins),
which is a very strong online rule for this distribution. As a refinement,
bins whose post-placement remainder would still accommodate our estimated
typical item size (~40) are mildly de-ranked, because they tend to be filled
by best fit leaving awkward fragments; bins that are nearly full are favored
so their slot is retired cheaply.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Best fit: smaller remainder is better.
    score = -rem
    # Small extra reward for near-exact fills (creates clean, low-waste bins).
    score -= 0.15 * (rem == 0)
    score -= 0.05 * ((rem > 0) & (rem < 5))
    return score
# EVOLVE-BLOCK-END
