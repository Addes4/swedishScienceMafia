# EVOLVE-BLOCK-START
"""Best fit with a gentle reusable-gap tie-break.

Items come from a fixed distribution (mean ~40). Pure best fit (minimize the
post-placement remainder) is near-optimal here. We keep that as the dominant
signal but scale the remainder down so that bins whose leftover gap is close to
a typical future item size are mildly preferred among similar remainders. This
avoids fragmenting bins into tiny unusable gaps without disturbing the strong
best-fit ordering.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    target = _state["mean"]
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Dominant: minimize remainder (best fit). Scaled small so the secondary
    # reusable-gap term only breaks near-ties.
    best_fit = -rem / 1000.0

    # Secondary: prefer leaving a remainder near a typical future item size.
    gap_score = -np.abs(rem - target) / 1.0e6

    return best_fit + gap_score
# EVOLVE-BLOCK-END
