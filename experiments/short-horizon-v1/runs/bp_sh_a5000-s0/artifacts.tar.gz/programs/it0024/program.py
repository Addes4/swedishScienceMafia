# EVOLVE-BLOCK-START
"""Best fit with exact-pair preference: fill near-exact bins, and when placing
an item, prefer a bin whose post-placement remainder equals the item size
(so two equal items share a bin)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # remaining capacity after placing (int64)
    # Best fit: smaller remainder is better.
    score = -rem.astype(np.float64)
    # Exact-pair bonus: if this bin would be left holding capacity equal to the
    # current item, a future identical item completes it exactly.
    score += 0.5 * (rem == item)
    return score
# EVOLVE-BLOCK-END

