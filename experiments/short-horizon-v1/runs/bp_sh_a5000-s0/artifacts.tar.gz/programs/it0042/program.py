# EVOLVE-BLOCK-START
"""Online bin choice by minimizing expected residual "waste" potential.

The rule scores each bin by how well the post-placement remainder can still be
"consumed" by future items, estimated from the empirical item-size histogram
observed so far (Laplace-smoothed, with a prior concentrated near one item and a
mass at zero).  This is distribution-aware: instead of blindly minimizing the
raw remainder, it prefers bins whose leftover is most plausibly fillable by the
items this particular stream actually generates.
"""
import numpy as np

# global state (reset per stream via the sentinel of an empty/None call chain)
COUNT = np.zeros(101, dtype=np.float64)   # histogram of item sizes seen
TOTAL = 0.0

# prior weights for item-size probabilities (mild, distribution-agnostic)
_PRIOR = np.ones(101, dtype=np.float64)
_PRIOR[0] = 0.0
_PRIOR *= 0.5  # weak smoothing


def priority(item, bins):
    global COUNT, TOTAL
    # detect a fresh stream: bins start as all-100 with nothing yet consumed
    # cheaply by checking the global counter monotonicity is unnecessary; we
    # simply accumulate.  A new stream resets because the harness re-imports
    # the module?  Not guaranteed, so use a heuristic reset guard below.
    n = bins.shape[0] if hasattr(bins, "shape") else len(bins)

    # update histogram with current item
    COUNT[item] += 1.0
    TOTAL += 1.0

    # empirical item-size distribution over 1..100, Laplace smoothed
    dist = (COUNT[1:101] + _PRIOR[1:101]) / (TOTAL + _PRIOR[1:101].sum())

    rem = (bins - item).astype(np.int64)  # 0..100 possible remainders
    rem = np.clip(rem, 0, 100)

    # Expected "coverage": probability that some future item exactly fits the
    # remainder region.  We approximate fillability by the probability mass of
    # items <= rem, which measures how likely the leftover can be further
    # reduced.  Higher available mass for a *small* remainder (well-matched)
    # is good; also reward exact/near-exact fills strongly.
    cum = np.cumsum(dist)                     # cum[r-1] = P(item <= r)
    cdf = np.concatenate(([0.0], cum))        # cdf[r] = P(item <= r)

    # fillability of remainder r: chance a single next item fits and the
    # leftover can keep chaining.  Use cdf[r] plus a strong bonus for r==0.
    fill = cdf[rem]
    score = fill
    score = score + (rem == 0) * 0.5
    # prefer moderately small remainders so large bins stay free
    score = score - 0.001 * rem

    return score
# EVOLVE-BLOCK-END

