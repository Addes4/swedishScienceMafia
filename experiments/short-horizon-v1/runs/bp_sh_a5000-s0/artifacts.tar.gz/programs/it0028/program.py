# EVOLVE-BLOCK-START
"""Expected-waste best fit with a fresh-bin (open-a-new-bin) penalty."""
import numpy as np

# Discretized Weibull-shaped item distribution (mean ~40), sizes 1..100.
_sizes = np.arange(1, 101, dtype=np.float64)

# Weibull with shape k=1.5, scale chosen so mean ~= 40  (mean = scale*Gamma(1+1/k)).
_k = 1.5
import math
_scale = 40.0 / math.gamma(1.0 + 1.0 / _k)

# probability mass for integer sizes via CDF differences (small sample approximation)
_cdf = 1.0 - np.exp(-(_sizes / _scale) ** _k)
_cdf_prev = np.concatenate(([0.0], _cdf[:-1]))
_p = _cdf - _cdf_prev
_p = np.clip(_p, 0.0, None)
_p = _p / _p.sum()

# Precompute expected residual waste for a bin with remainder r (0..100).
# After placing future items greedily... we approximate: expected min waste
# as the shifted expected absolute deviation of sizes near r.
_waste = np.zeros(101, dtype=np.float64)
for r in range(101):
    # expected leftover after one more ideal fit: if the bin can take a future
    # item of size s, the best leftover is (r - s) mod-ish; approximate with the
    # expectation of min(r - s, waste if not fitting). Simple closed form:
    fit = _sizes <= r
    if not fit.any():
        _waste[r] = float(r)
    else:
        s_fit = _sizes[fit]
        p_fit = _p[fit]
        resid = r - s_fit
        # prefer the smallest non-negative residual; expectation of residuals
        _waste[r] = float((p_fit * resid).sum() / p_fit.sum())


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # remaining capacity after placement, int64
    rem_clip = np.clip(rem, 0, 100).astype(np.int64)
    waste = _waste[rem_clip]  # expected future waste in this bin
    # Prefer bins minimizing expected waste (negative score).
    score = -waste
    # Penalize opening fresh (empty) bins slightly so we fill partial bins first.
    fresh = bins == 100
    score = score - 3.0 * fresh
    return score
# EVOLVE-BLOCK-END
