# EVOLVE-BLOCK-START
"""Distribution-aware best fit: exact fills first, then keep usable gaps.

Items are drawn from a fixed Weibull-shaped distribution with mean about 40.
Pure best fit minimizes the immediate remainder, which often leaves tiny
unusable gaps. Instead, after guaranteeing the item fits (it always does, since
only fitting bins are shown), we rank bins so that:
  1. exact fills (remainder 0) are strongly preferred, then
  2. among remaining bins, the post-placement remainder closest to a typical
     future item size (the online-estimated median) is preferred, keeping gaps
     reusable.
"""
import numpy as np

_state = {"n": 0.0, "counts": None, "total": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Online histogram of observed item sizes (1..100).
    counts = _state["counts"]
    if counts is None:
        counts = np.zeros(101, dtype=np.float64)
        _state["counts"] = counts
    counts[item] += 1.0
    _state["n"] += 1.0
    _state["total"] += 1

    # Median of observed items (robust typical size).
    cdf = np.cumsum(counts)
    half = _state["n"] / 2.0
    idx = int(np.searchsorted(cdf, half))
    if idx < 1:
        idx = 1
    if idx > 100:
        idx = 100
    target = float(idx)

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Distance of the leftover gap from a typical future item size.
    gap_score = -np.abs(rem - target)

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return gap_score + exact_bonus
# EVOLVE-BLOCK-END
