# EVOLVE-BLOCK-START
"""Best fit with reuse-aware remainder matching.

Items come from a fixed Weibull-shaped distribution (mean ~40). Pure best fit
minimizes the immediate remainder but can leave tiny unusable gaps. We:
  1. Strongly prefer exact fills (remainder 0).
  2. Otherwise reward a remainder that equals some recently-seen item size,
     so the leftover capacity is likely reusable by a future item.
  3. Mildly penalize remainders too small to ever fit another item.
Implemented with a small reservoir; O(#bins) per call using numpy.
"""
import numpy as np
import random

_CAP = 100.0
_RES_N = 96

_state = {"n": 0.0, "mean": 40.0, "res": [], "seen": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    _state["seen"] += 1
    res = _state["res"]
    if len(res) < _RES_N:
        res.append(float(item))
    else:
        j = random.randint(0, _state["seen"] - 1)
        if j < _RES_N:
            res[j] = float(item)

    rem = (bins - item).astype(np.float64)  # capacity left after placing

    # Distance from remainder to nearest observed past item size:
    # small distance => leftover matches a plausible future item.
    if res:
        rs = np.asarray(res, dtype=np.float64)
        # distance from each remainder to nearest reservoir sample
        d = np.abs(rem[:, None] - rs[None, :]).min(axis=1)
    else:
        d = np.abs(rem - _state["mean"])

    match_score = -d

    # Strong bonus for exact fills.
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    # Mild penalty for leaving a tiny (hard to reuse) positive gap.
    tiny_pen = np.where((rem > 0.0) & (rem < 3.0), (3.0 - rem) * 0.5, 0.0)

    return match_score + exact_bonus - tiny_pen
# EVOLVE-BLOCK-END
