# EVOLVE-BLOCK-START
"""Best fit with online item-size histogram used to avoid tiny unusable
remainders and reward remainders likely to be closed exactly by future items."""
import numpy as np

_HIST = None
_TOTAL = 0

def _hist():
    global _HIST
    if _HIST is None:
        _HIST = np.zeros(101, dtype=np.float64)
    return _HIST

def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    global _TOTAL
    h = _hist()
    h[int(item)] += 1.0
    _TOTAL += 1

    rem = bins - item  # remaining capacity after placing

    # Best-fit baseline: smaller remainder better.
    score = -rem.astype(np.float64)

    # Probability-mass that some observed future item size equals each remainder.
    # Use Laplace-smoothed histogram normalised once total is large enough.
    if _TOTAL >= 50:
        p = h / _TOTAL
        # reward remainders that match a frequently seen size (exact closes)
        # small remainder must still be valid (>=0 handled by harness fit).
        idx = np.clip(rem, 0, 100).astype(np.int64)
        match = p[idx]
        score += 8.0 * match
        # penalise creating tiny remainders that are unlikely to be filled
        tiny = (rem >= 1) & (rem <= 8)
        score -= 0.05 * tiny * (1.0 - match)
    return score
# EVOLVE-BLOCK-END
