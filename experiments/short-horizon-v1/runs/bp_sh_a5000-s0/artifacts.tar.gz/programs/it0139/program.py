# EVOLVE-BLOCK-START
"""Distribution-aware best fit with quantile-based residual matching.

Items come from a fixed Weibull-shaped distribution (mean ~40). Pure best fit
minimizes the immediate remainder but leaves tiny unusable gaps. Here we:
  1. Strongly prefer exact fills (remainder 0).
  2. Otherwise prefer the post-placement remainder closest to a robust estimate
     of a typical *small* future item size (an online low-quantile estimate),
     so leftover gaps stay reusable by the many small filler items.
"""
import numpy as np

_state = {"n": 0.0, "res": [], "seen": 0}

# Keep a bounded sample and estimate a low quantile (small filler sizes).
_Q = 0.30
_CAP = 256


def _quantile(res, q):
    """Linear-interpolation quantile of a list."""
    a = np.sort(np.asarray(res, dtype=np.float64))
    m = a.shape[0]
    if m == 1:
        return float(a[0])
    pos = q * (m - 1)
    lo = int(np.floor(pos))
    hi = int(np.ceil(pos))
    frac = pos - lo
    return float(a[lo] * (1.0 - frac) + a[hi] * frac)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    # Reservoir sample of past item sizes (updated after using it).
    _state["seen"] += 1
    res = _state["res"]
    if len(res) < _CAP:
        res.append(float(item))
    else:
        # Deterministic-ish replacement of a fixed slot to keep state bounded.
        res[_state["seen"] % _CAP] = float(item)

    target = _quantile(res, _Q)
    if target < 1.0:
        target = 1.0

    rem = (bins - item).astype(np.float64)  # capacity left after placing

    # Distance of the leftover gap from a typical small filler item size.
    gap_score = -np.abs(rem - target)

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return gap_score + exact_bonus
# EVOLVE-BLOCK-END
