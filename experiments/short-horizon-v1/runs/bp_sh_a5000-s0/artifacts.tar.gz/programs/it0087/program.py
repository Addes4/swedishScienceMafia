# EVOLVE-BLOCK-START
"""Best fit with a light distribution-aware tie-break that keeps gaps usable."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    global _count, _sum

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Update running mean of item sizes (cheap online statistic).
    _count += 1
    _sum += item
    mean_item = _sum / _count

    # Primary: best fit (smaller remainder better) -> -rem.
    # Secondary: among near-equal small remainders, prefer the one closest to
    # the typical item size so the leftover gap can still be reused later.
    # Very small weight so it only breaks near-ties.
    gap_pref = -np.abs(rem - mean_item)
    # Only meaningful for moderately small remainders (otherwise best fit wins).
    weight = 1e-3 * (rem < mean_item)
    return -rem + weight * gap_pref


_count = 0
_sum = 0.0
# EVOLVE-BLOCK-END

