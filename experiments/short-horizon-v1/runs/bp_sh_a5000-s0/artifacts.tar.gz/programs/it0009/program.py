# EVOLVE-BLOCK-START
"""Best fit with a smooth saturating reward for tight fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Best fit: smaller remainder is better.
    # Smooth saturating bonus that peaks at rem = 0 and decays with a scale k.
    k = 8.0
    return -rem - 3.0 * (rem / (rem + k))
# EVOLVE-BLOCK-END

