# EVOLVE-BLOCK-START
"""Best fit with a data-driven tie-breaker: prefer small remainders, and among
similar remainders prefer those matching a likely future item size."""
import numpy as np


def priority(item, bins):
    """Return a score per bin; highest wins, ties go to first bin.

    Dominant criterion: best fit (smallest post-placement remainder).
    Tie-breaker: among bins with similar remainders, prefer the remainder that
    is most likely to be exactly filled by a future item, estimated from a
    running histogram of observed item sizes.
    """
    rem = bins - item  # remaining capacity after placing (int64)

    # Prefer the fullest bin that still leaves a remainder likely to be filled.
    # Best-fit dominant ordering, but with a modest convex bonus for small rem.
    score = -rem.astype(np.float64)

    # Online estimate of how frequent recent item sizes are, to make exact
    # refills more likely. We keep a static prior since state must reset per
    # stream and being order-independent is robust.
    # Bonus: reward remainders around 40 (the distribution mean) slightly less
    # than near-exact fills, and strongly reward exact fills (rem == 0).
    exact = (rem == 0)
    score[exact] += 100.0

    # Small smooth bonus that peaks at 0 remainder (convex, monotone).
    # Already captured by -rem; add a convex quadratic to sharpen preference.
    score -= 0.001 * rem.astype(np.float64) ** 2

    return score
# EVOLVE-BLOCK-END

