# EVOLVE-BLOCK-START
"""Worst-fit variant tuned for the skewed (mean ~40) Weibull item distribution.

Best-fit tends to leave many tiny unusable gaps. Instead we prefer bins whose
post-placement remainder is still close to a typical item size, so leftover
capacity can actually be reused, while not fragmenting bins unnecessarily.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remaining capacity after placing
    # Prefer remainders that are large enough to accept a typical future item
    # (~40) but avoid leaving bins nearly empty for too long (which wastes space
    # by not consolidating). Peak preference around rem ~= 40, gentle elsewhere.
    return -np.abs(rem - 40.0)
# EVOLVE-BLOCK-END

