# EVOLVE-BLOCK-START
"""Best fit with a gentle near-exact-fill bonus.

The strongest simple online rule for this distribution is plain best fit
(place the item so the leftover remainder is as small as possible).  A tiny
convex bonus for near-exact fills breaks the occasional tie in favour of
fully packing a bin, while remaining weak enough not to disturb the linear
best-fit ordering that drives density.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remainder after placing
    # Base: best fit -> smaller remainder is better.
    score = -rem
    # Gentle convex bonus for near-exact fills (small remainder).
    score += 0.05 * (5.0 - rem) * (rem < 5)
    return score
# EVOLVE-BLOCK-END
