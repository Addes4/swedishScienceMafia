# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware packing-value tie-break.

Primary order is best fit (smaller post-placement remainder wins). We add a
small bonus reflecting the estimated packing value of the remaining gap: the
expected number of future items (drawn from the running empirical item-size
distribution) that fit in it, capped at 1, so near-exact fills and reusable
gaps are both rewarded without overriding best fit.
"""
import numpy as np

# Running histogram of past item sizes (state per stream/module).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0

# Precompute for a gap g (0..100) the capped expected reuse count.
# We update lazily using current histogram each call via cached vector.
_CACHE = {"count": -1.0, "best": None}


def _gap_value():
    """Return array value[g] = expected #future items fitting gap g, capped 1."""
    global _COUNT
    if _CACHE["count"] == _COUNT and _CACHE["best"] is not None:
        return _CACHE["best"]
    # probability of item size s is _HIST[s] / total
    total = _HIST.sum()
    if total <= 0:
        vals = np.zeros(101, dtype=np.float64)
    else:
        p = _HIST / total
        # For gap g, value = sum_{s<=g} p[s] (prob a next item fits)
        cdf = np.cumsum(p)
        vals = cdf[:101].copy()  # vals[g] = P(item <= g)
        vals[0] = 0.0
    _CACHE["count"] = _COUNT
    _CACHE["best"] = vals
    return vals


def priority(item, bins):
    global _COUNT
    rem = bins - item  # post-placement remainder, fits guaranteed >= 0

    vals = _gap_value()
    # value of the remaining gap: probability the next item fits there.
    gap_score = vals[np.clip(rem, 0, 100)]

    # update histogram after computing (doesn't affect this call's ordering
    # beyond distribution already seen)
    if 0 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1.0

    # Best fit dominant: -rem. Small bonus for bins whose leftover gap is
    # likely reusable by a future item (gap_score near 1 means plenty of room
    # for a typical item; near-zero means a nearly-full bin).
    # Reward moderately-full bins that still leave a high-probability-fit gap,
    # but never let the bonus outweigh the smallest-remainder choice.
    return -rem + 0.5 * gap_score
# EVOLVE-BLOCK-END
