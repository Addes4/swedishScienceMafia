# EVOLVE-BLOCK-START
"""Distribution-aware best fit with a reusable-gap value estimate.

Items are drawn from a fixed Weibull-shaped distribution with mean about 40.
Pure best fit minimizes the immediate remainder, which often leaves tiny
unusable gaps. Instead, after guaranteeing the item fits, we rank bins by an
online estimate of how many future items a leftover gap can still absorb,
while strongly preferring exact fills (fully closed bins).
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0, "hist": None}

# Buckets for an empirical size distribution (1..100).
_BUCKETS = np.arange(1, 101, dtype=np.float64)


def _ensure_hist():
    if _state["hist"] is None:
        _state["hist"] = np.ones(100, dtype=np.float64)  # Laplace smoothing


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    _ensure_hist()
    hist = _state["hist"]

    # Online estimate of the mean item size (starts at 40).
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + float(item)) / (n + 1.0)
    _state["n"] = n + 1.0

    # Update empirical histogram (size = index+1).
    hist[int(item) - 1] += 1.0
    total = float(hist.sum())

    rem = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Probability mass of items fitting within a gap of size r, weighted by
    # how "fillable" the gap is: expected count of typical items packable.
    # E[count] approx = sum_r P(size <= r) scaled by r / mean(size).
    cdf = np.cumsum(hist) / total  # P(size <= s) for s = 1..100

    # For each remainder r, estimate expected number of items it can still hold.
    # Use r / mean as an approximate capacity count times the probability that
    # at least a typical item fits (cdf at r).
    r_clipped = np.clip(rem, 0.0, 100.0)
    idx = np.clip(r_clipped.astype(np.int64), 0, 99)
    p_fit = cdf[idx]  # probability a random item fits in the gap
    fill_value = (r_clipped / max(_state["mean"], 1.0)) * p_fit

    # Strong bonus for exact fills (fully closed bins).
    exact_bonus = np.where(rem <= 0.0, 1000.0, 0.0)

    return fill_value + exact_bonus
# EVOLVE-BLOCK-END

