# EVOLVE-BLOCK-START
"""Best fit with a mild fullness tie-break.

Primary rule: ascending post-placement remainder (classic best-fit), which
minimizes wasted slack per placement.  Secondary rule: among near-ties
(remainders within a small window), prefer the bin that is already fuller,
since it is more likely to be closed out by future small items and reduces
the number of bins carrying open slack.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # remainder after placing
    # Best fit: smaller remainder is strictly better.
    base = -rem
    # Fullness tie-break: bins that are already fuller (smaller pre-placement
    # remaining capacity) get a tiny extra bonus, but only enough to break
    # near-ties in remainder, not to override a clearly better fit.
    fullness = (100.0 - bins.astype(np.float64))  # used capacity pre-placement
    return base + 1e-3 * fullness * np.exp(-rem / 8.0)
# EVOLVE-BLOCK-END
