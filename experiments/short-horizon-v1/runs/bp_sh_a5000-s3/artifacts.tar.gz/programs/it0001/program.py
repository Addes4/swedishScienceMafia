# EVOLVE-BLOCK-START
"""Best fit with a slight preference for partially-used bins over fresh bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item  # >= 0 for bins the item fits in
    # Classic best fit: prefer the smallest leftover.
    score = -leftover.astype(np.float64)
    # Mildly avoid opening a brand-new bin until it is actually the tightest fit.
    score += np.where(bins == 100, -0.5, 0.0)
    return score
# EVOLVE-BLOCK-END

