# EVOLVE-BLOCK-START
"""Best fit with a small fragmentation guard for Weibull-shaped items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Classic best fit: smaller residual is better.
    score = -residual.astype(np.float64)
    # If the residual would be too small to plausibly fit a future item,
    # slightly penalize that bin so tiny unusable gaps are avoided.
    small = residual < 10
    score[small] -= (10 - residual[small]) * 0.25
    return score
# EVOLVE-BLOCK-END
