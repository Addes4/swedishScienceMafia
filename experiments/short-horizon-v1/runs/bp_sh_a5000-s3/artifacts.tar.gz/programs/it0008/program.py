# EVOLVE-BLOCK-START
"""Best fit with a capacity-aware switch for large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Prefer the tightest fit (smallest residual after placement) in general.
    tight = -(bins - item)

    # For relatively large items, prefer the emptiest bin to avoid stranding
    # medium residual gaps that future (typically smaller) items cannot fill.
    if item >= 60:
        return bins.astype(np.float64)
    return tight
# EVOLVE-BLOCK-END
