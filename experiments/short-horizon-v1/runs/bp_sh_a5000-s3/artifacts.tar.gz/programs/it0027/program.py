# EVOLVE-BLOCK-START
"""Best-fit with a small tie-break toward reusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # core: best fit => prefer smallest non-negative residual
    # small tie-break: within a tolerance of the best fit, prefer a residual
    # large enough that a typical item (~40) can still fit cleanly, avoiding
    # stranding tiny leftovers.
    r = residual
    # strongly rank by (residual // 8) blocks so tiny differences don't dominate
    key = r // 8
    return -key * 1000 - r
# EVOLVE-BLOCK-END
