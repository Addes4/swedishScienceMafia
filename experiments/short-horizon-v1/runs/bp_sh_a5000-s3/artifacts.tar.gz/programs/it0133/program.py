# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit with a closability prior and dead-leftover guard."""
import numpy as np


_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0
_DIRTY = True

_REACH = np.zeros(101, dtype=np.float64)
_MIN_ITEM = 1


def _rebuild():
    global _REACH, _DIRTY, _MIN_ITEM
    probs = _COUNTS / _TOTAL

    top = np.argsort(probs)[::-1][:16]
    top = [int(t) for t in top if probs[t] > probs.mean()]

    # Smallest item size with non-negligible probability.
    m = 1
    if top:
        m = min(top)
    # account for a few small sizes with tiny probability
    small = np.where(probs[1:11] > 0.002)[0]
    if small.size:
        m = min(m, int(small[0]) + 1)
    _MIN_ITEM = max(1, m)

    # reach[s]: weight that residual s can be exactly closed by 1..3 future items
    reach = np.zeros(101, dtype=np.float64)
    for s in top:
        if 0 < s <= 100:
            reach[s] = max(reach[s], probs[s])
    for a in top:
        if a <= 0 or a > 100:
            continue
        pa = probs[a]
        for b in top:
            s = a + b
            if 0 < s <= 100:
                w = pa * probs[b]
                reach[s] = max(reach[s], w)
            for c in top:
                t = a + b + c
                if 0 < t <= 100:
                    reach[t] = max(reach[t], pa * probs[b] * probs[c])

    _REACH = reach
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    # Best-fit: prefer the smallest residual.
    score = -residual

    # Reward residuals that are likely to be exactly closed soon.
    score += 4.0 * _REACH[ri]

    # Decisive exact-fit bonus.
    score += (residual == 0.0).astype(np.float64) * 50.0

    # Penalize "dead" leftovers that are smaller than the smallest likely item:
    # such residuals can almost never be exactly closed again.
    dead = (residual > 0.0) & (residual < _MIN_ITEM)
    score -= dead.astype(np.float64) * 3.0

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
