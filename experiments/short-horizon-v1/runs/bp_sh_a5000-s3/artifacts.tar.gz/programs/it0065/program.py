# EVOLVE-BLOCK-START
"""Best fit with an online, distribution-aware residual-utility tie-break.

Primary signal is best fit: prefer the smallest post-placement residual, which
keeps bins tightly packed.  We add a *secondary* signal only to break near-ties:
a residual is more valuable if it can be filled exactly by a future item, so we
reward residuals that coincide with item sizes frequently seen so far (online
histogram).  This turns "leave 30" into a useful slot when 30 is a common item,
instead of a stranded gap.
"""
import numpy as np

# Module-level state: online histogram of observed item sizes (1..100).
_HIST = np.zeros(101, dtype=np.float64)
_SEEN = 0.0


def priority(item, bins):
    global _HIST, _SEEN

    # --- update online statistics with the arriving item ---
    _HIST[item] += 1.0
    _SEEN += 1.0

    residual = bins - item  # post-placement remaining capacity, >= 0

    # Normalized frequency of each possible residual size (1..100).
    # residual 0 => perfect fill, treat as maximally useful (count as 1.0).
    total = _SEEN if _SEEN > 0 else 1.0
    freq = _HIST / total

    # Frequency of the exact residual value (0 gets an artificial high value
    # so perfect fits are always preferred within the tie-break layer).
    f = freq[residual]
    perfect = (residual == 0)
    f = np.where(perfect, 1.0, f)

    # Reusability also matters for residuals that are sums of two common items;
    # approximate by adding a small term for residuals near the mean item size
    # (most likely to be consumed by one future item).
    mean_item = (np.arange(101) * _HIST).sum() / total
    near_mean = -np.abs(residual - mean_item) / 100.0

    # Dominant term: best fit.  Tie-break term: small, bounded in [-0.5, 0.5].
    base = -residual.astype(np.float64)
    tie = 0.5 * f + 0.1 * near_mean

    return base + tie
# EVOLVE-BLOCK-END
