# EVOLVE-BLOCK-START
"""Best-fit with a reusable-residual preference: prefer tight fits, but break
near-ties toward leaving a residual equal to a common future item size."""
import numpy as np

# Empirical histogram of item sizes (index 1..100), accumulated across the stream.
_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _counts, _total

    # Update the running histogram (past items only, this one not yet placed).
    item_i = int(item)
    if 1 <= item_i <= 100:
        _counts[item_i] += 1.0
        _total += 1.0

    residual = bins - item_i  # residual after placing the item in each bin
    rmin = int(residual.min())

    # Weight of an item size in the observed distribution (smoothing keeps small
    # counts nonzero so early stream behavior stays close to pure best-fit).
    counts = _counts
    tot = _total
    if tot > 0.0:
        freq = (counts + 0.5) / (tot + 50.0)
    else:
        freq = counts + 0.0  # all zeros -> empty bonus below

    # Bonus for bins whose post-placement residual equals a commonly seen item
    # size: such a residual can be filled by a future item.
    reuse = freq[residual]  # gathers only where 0<=residual<=100; others invalid

    # Primary key is still tightness (best fit): bins must be within a small
    # window of the minimum residual to be eligible for the reuse bonus.
    window = 1 + item_i // 20  # small relative tolerance
    eligible = (residual - rmin) <= window

    # Score: smaller residual is better; among near-ties, larger reuse is better.
    # Use a scale that makes reuse a tie-breaker, not an override.
    tight = -(residual.astype(np.float64))
    bonus = reuse * eligible
    # Normalize the bonus so it only shifts ordering within the tolerance window.
    maxfreq = float(freq.max()) if freq.size else 0.0
    if maxfreq > 0.0:
        bonus = bonus / maxfreq  # in [0, 1]
    return tight + bonus
# EVOLVE-BLOCK-END
