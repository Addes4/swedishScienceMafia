# EVOLVE-BLOCK-START
"""Best-fit with a stranding-aware residual shaping.

Score = prefer small post-placement residual, but treat residuals that are too
small to hold any *small* future item as worthless (they get the same score as
residual 0 only when they are 0). Uses a running estimate of a low quantile of
the item size distribution as the "minimum useful residual".
"""
import numpy as np

_state = {"n": 0, "min_seen": 100}


def priority(item, bins):
    global _state
    # running estimate of a small item size (a low quantile proxy)
    if item < _state["min_seen"]:
        _state["min_seen"] = item
    _state["n"] += 1
    n = _state["n"]

    resid = bins - item  # post-placement residual, >= 0

    # "minimum useful residual": grow from observed small items, but keep it
    # modest; represent how small a gap can still be worth preserving.
    small = _state["min_seen"]
    # as we see more items, allow the useful threshold to be a bit below min_seen
    useful = max(1, small)

    # Base preference: smaller residual is better.
    score = -resid.astype(np.float64)

    # Penalize non-zero residuals that are below `useful` (stranded space),
    # pushing the item toward perfect fills or clearly-usable gaps.
    stranded = (resid > 0) & (resid < useful)
    score = score - stranded * 200.0

    return score
# EVOLVE-BLOCK-END
