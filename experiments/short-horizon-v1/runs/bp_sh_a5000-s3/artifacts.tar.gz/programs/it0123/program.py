# EVOLVE-BLOCK-START
"""Best-fit with an online one-step closability value estimate."""
import numpy as np


_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

_VAL = np.zeros(101, dtype=np.float64)
_DIRTY = True


def _smooth(arr, sigma=1.0):
    k = int(3 * sigma)
    xs = np.arange(-k, k + 1, dtype=np.float64)
    w = np.exp(-0.5 * (xs / sigma) ** 2)
    w /= w.sum()
    padded = np.concatenate([np.full(k, arr[0], dtype=np.float64), arr,
                             np.full(k, arr[-1], dtype=np.float64)])
    return np.convolve(padded, w, mode='valid')


def _rebuild_val():
    global _VAL, _DIRTY
    probs = _COUNTS / _TOTAL

    # support: most probable item sizes
    top = np.argsort(probs)[::-1][:16]
    top = [int(t) for t in top if probs[t] > probs.mean()]

    # closability: probability residual r can be exactly filled by 1..3 items
    close = np.zeros(101, dtype=np.float64)
    close[0] = 1.0
    for a in top:
        if 0 < a <= 100:
            close[a] = max(close[a], probs[a])
    for a in top:
        if a <= 0 or a > 100:
            continue
        pa = probs[a]
        for b in top:
            s = a + b
            if 0 < s <= 100:
                close[s] = max(close[s], pa * probs[b])
            for c in top:
                t = a + b + c
                if 0 < t <= 100:
                    close[t] = max(close[t], pa * probs[b] * probs[c])

    # Best-fit baseline: smaller residual is better (scaled to unit range).
    bestfit = 1.0 - np.arange(101, dtype=np.float64) / 100.0

    val = bestfit + 1.5 * close
    _VAL = _smooth(val, sigma=1.0)
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild_val()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)
    score = _VAL[ri]

    m = _COUNTS / _TOTAL
    modal_p = float(m.max())

    # Decisive exact-fit bonus: closing a bin now is strongly preferred.
    score += (residual == 0.0).astype(np.float64) * (7.0 + 3.0 * modal_p)

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
