# EVOLVE-BLOCK-START
"""Best fit with a residual-target tie-break targeting the typical item size.

Pure best-fit is hard to beat, but its main inefficiency is creating residuals
that are slightly too small to accept a typical future item, stranding space.
We augment best-fit with a tiny tie-break (bounded window) that, among placements
whose post-placement residual is close to the minimum achievable, prefers the bin
whose residual is nearest to a "good" target: values that can be exactly closed
by a likely future item, i.e. near the running-estimated typical item size, or
near 0.
"""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    # Running estimate of the typical (mean) item size.
    _state["sum"] += float(item)
    _state["n"] += 1
    mean_item = _state["sum"] / _state["n"]

    resid = bins - item  # post-placement residual for each bin

    tightness = -resid.astype(np.float64)

    # Good leftover targets: ~0 (exact fill) or ~ a typical future item size.
    hi = mean_item
    d_zero = np.abs(resid - 0.0)
    d_mean = np.abs(resid - hi)
    target_dist = np.minimum(d_zero, d_mean)

    # Window: only allow tie-break among near-tightest placements.
    min_t = tightness.max()
    in_window = tightness >= (min_t - 2.0)

    score = tightness.copy()
    # Small bonus (does not override window ordering beyond tie-break scale).
    bonus = np.where(in_window, -0.25 * target_dist, 0.0)
    score = score + bonus

    return score
# EVOLVE-BLOCK-END
