# EVOLVE-BLOCK-START
"""Best fit with harmonic residual snapping.

Choose the bin whose post-placement residual is close to a "useful" leftover size.
We score by preferring small residuals (best fit), but break near-ties by how well
the residual aligns to a coarse ladder (multiples of 10), which keeps leftover gaps
around the size of typical future items so they can be filled by later items.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # post-placement remaining capacity, >= 0

    # Base: prefer the tightest fit (small residual).
    base = -residual.astype(np.float64)

    # Harmonic alignment: residual close to a multiple of 10 is more reusable
    # (later items are Weibull-ish with mean ~40, so gaps near 10/20/... get filled).
    # Distance below the next coarse boundary, normalized.
    rem = residual % 10
    align = np.where(rem == 0, 0.0, rem.astype(np.float64))

    # Small tie-break bonus: prefer residuals just above a coarse boundary
    # (i.e. minimal positive remainder), which mirrors best fit while
    # nudging away from stranding tiny unusable gaps.
    tie = -align * 0.5

    return base + tie
# EVOLVE-BLOCK-END
