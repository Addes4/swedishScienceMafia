# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit with reachable-residual bonus.

Score each bin by an estimate of how valuable its post-placement residual is.
A residual is valuable if it is likely to be exactly filled by a later item,
or more generally if it can be completed by a small combination of likely
item sizes (e.g. 40+60). We learn the item distribution online and maintain
a reachability set over residuals 0..100 built from common observed sizes.
"""
import numpy as np


# Online histogram of observed item sizes (Laplace-smoothed).
_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

# Reachability/utility cache keyed by rounded residual -> value.
_UTIL = np.zeros(101, dtype=np.float64)
_DIRTY = True


def _rebuild_util():
    """Compute utility of each residual r in 0..100.

    Base value = probability that a single future item exactly equals r.
    Additional value = whether r is expressible as a sum of 2 (or 3) likely
    items, using the most probable sizes.
    """
    global _UTIL, _DIRTY
    probs = _COUNTS / _TOTAL

    # Most likely item sizes (top few) for combination building.
    top = np.argsort(probs)[::-1][:12]
    top = [int(t) for t in top if probs[t] > probs.mean()]

    util = probs.copy()

    # Two-item sums.
    if len(top) >= 1:
        for a in top:
            if a <= 0 or a > 100:
                continue
            for b in top:
                s = a + b
                if 0 < s <= 100:
                    util[s] += 0.5 * probs[a] * probs[b]
    # Three-item sums (small contribution).
    if len(top) >= 1:
        for a in top:
            for b in top:
                for c in top:
                    s = a + b + c
                    if 0 < s <= 100:
                        util[s] += 0.15 * probs[a] * probs[b] * probs[c]

    _UTIL = util
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild_util()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    # Value of leaving this residual (higher = better).
    val = _UTIL[ri]

    # Log-scale for stability, plus strong perfect-fill bonus.
    score = np.log(val + 1e-9)
    score += (residual == 0.0).astype(np.float64) * 5.0

    # Mild best-fit pressure to break ties sensibly.
    score -= residual * 0.005

    # Update online histogram.
    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
