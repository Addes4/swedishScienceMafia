# EVOLVE-BLOCK-START
"""Residual-matching best fit for online bin packing.

Place the arriving item in the bin that leaves the smallest residual, but when
several bins leave a similar residual, prefer the one whose residual is closest
to the observed mean item size (so the leftover space stays usable for future
items).  A small bonus is given to bins that would be filled almost exactly.
"""
import numpy as np

_state = {"n": 0.0, "s": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _state["n"] += 1.0
    _state["s"] += float(item)
    mean = _state["s"] / _state["n"]
    if mean < 1.0:
        mean = 1.0

    residual = bins - item

    # Base: prefer smallest residual (tightest fit).
    score = -residual.astype(np.float64)

    # Bonus: reward residuals close to the running mean item size, so leftover
    # space remains usable by future items (keeps bins "open" for more).
    score += 0.6 * np.exp(-((residual - mean) ** 2) / (2.0 * (0.35 * mean) ** 2))

    # Small extra bonus when the residual is exactly zero-ish (perfect fill).
    score += 1.0 / (1.0 + np.abs(residual))

    return score
# EVOLVE-BLOCK-END
