# EVOLVE-BLOCK-START
"""Best-fit with an adaptive stranded-space penalty.

Pure best-fit minimizes the immediate residual, which tends to strand small
unusable gaps.  We keep preferring tight fits, but among bins whose residual
would be "awkward" we slightly favor residuals that a typical future item can
still use (residual close to the running mean item size).
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest."""
    residual = bins - item  # >= 0 by construction (bins only contains fitting bins)

    # Running estimate of typical item size (Weibull-ish, mean ~40).
    global _sum, _n
    try:
        _sum += item
        _n += 1
    except NameError:
        _sum = item
        _n = 1
    mean = _sum / _n
    target = max(1.0, mean)

    # Base score: tighter fit (smaller residual) is better.
    score = -residual.astype(np.float64)

    # Penalty for stranded space: residuals that are small but not zero are
    # likely unusable.  Reward residuals near the typical item size, i.e. ones
    # a future item can fill.
    r = residual.astype(np.float64)
    # closeness of residual to a usable target (in [0,1]); zero residual also good
    usable = np.exp(-((r - target) ** 2) / (2.0 * (0.5 * target) ** 2))
    # only matters for small residuals where stranding happens
    strand = np.exp(-((r - 0.5 * target) ** 2) / (2.0 * (0.5 * target) ** 2))
    score += 0.25 * usable - 0.2 * strand

    return score
# EVOLVE-BLOCK-END
