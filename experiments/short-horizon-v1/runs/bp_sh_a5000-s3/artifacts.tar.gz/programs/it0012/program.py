# EVOLVE-BLOCK-START
"""Adaptive best-fit: prefer tight fits but reward residuals that are likely reusable."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Score: strongly prefer leaving a small residual, but give an extra bonus when the
    # residual can plausibly be filled by one typical item (residual ~ mean item size),
    # so gaps don't get stranded as unusable tiny slivers.
    return -(residual.astype(np.float64)) - 0.05 * np.maximum(
        residual.astype(np.float64) - 40.0, 0.0
    )
# EVOLVE-BLOCK-END

