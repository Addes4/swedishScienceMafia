# EVOLVE-BLOCK-START
"""Best fit, but avoid stranding a residual too small to fit a common item.

Pure best-fit minimizes the immediate residual, which tends to leave tiny unusable
gaps.  Instead we track a running histogram of observed item sizes and prefer the
placement whose post-placement residual is smallest among residuals that are still
at least the size of a "typical" (low percentile) item.  This keeps bins reusable
without needing any lookahead.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    n = bins.shape[0]
    residual = bins - item  # post-placement residual for each bin

    # Maintain a running histogram of item sizes over the stream (module-level state).
    hist = priority.hist
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        priority.hist = hist
    hist[item] += 1.0
    total = hist.sum()

    # A "typical small item": a low percentile of the observed distribution.
    # Start pessimistic (assume ~1) and adapt as items are seen.
    if total < 20:
        thr = 1.0
    else:
        csum = np.cumsum(hist)
        # ~10th percentile of observed sizes, but never below 1.
        target = 0.10 * total
        idx = int(np.searchsorted(csum, target))
        thr = float(max(idx, 1))

    # Prefer residuals >= thr (fillable); among those, smallest residual.
    # If none qualify, fall back to plain best fit (smallest residual overall).
    claimable = residual >= thr
    if claimable.any():
        # Large bonus for claimable bins, then tightest fit.
        return np.where(claimable, 1000.0 - residual, -1e6 - residual)
    return -residual


priority.hist = None
# EVOLVE-BLOCK-END

