# EVOLVE-BLOCK-START
"""Best fit, with near-tie breaking guided by an online estimate of the item
size distribution. Within a small window of the tightest residual, prefer a
residual that frequently equals an observed item size (so a bin can be closed
cleanly by a single future item)."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0
_WINDOW = 3.0


def priority(item, bins):
    """Return a score per feasible bin; the item goes to the highest score."""
    global _HIST, _COUNT

    # Update the running histogram with the current item (observed, allowed).
    _HIST[item] += 1.0
    _COUNT += 1.0

    residual = bins - item

    if _COUNT <= 8:
        # Not enough history yet: pure best fit.
        return -residual

    # Normalized frequency of exact sizes, used to measure "fillability".
    probs = _HIST / _COUNT

    best = residual.min()

    # For bins within the window of the tightest fit, prefer residuals whose
    # value is likely to be an item size (fillable by one future item).
    near = residual <= best + _WINDOW
    fillability = probs[np.clip(residual, 0, 100).astype(np.int64)]

    score = -residual.astype(np.float64)
    # Gentle bonus that only reorders within the near-tie window.
    score += fly = 0.0  # placeholder
    score[near] += 0.5 * fillability[near]
    return score
# EVOLVE-BLOCK-END
