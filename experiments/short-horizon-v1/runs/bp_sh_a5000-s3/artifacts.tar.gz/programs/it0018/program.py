# EVOLVE-BLOCK-START
"""Best fit with a tiny, tie-breaking residual-shape preference."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary rule: best fit (smallest post-placement residual).
    Secondary (tiny, only breaks ties/near-ties): mildly prefer residuals that are
    neither zero-plus-tiny nor just below a "useful" size, which helps avoid stranding.
    """
    residual = bins - item  # >= 0 since bins shown all fit the item
    # Primary: best fit. Use a small multiplier on residual so secondary terms
    # (bounded by ~1) can only matter when residuals are essentially equal.
    score = -10.0 * residual
    # Secondary preference: slight bonus for residuals that are either 0 (perfect fill)
    # or reasonably large; small nonzero residuals are most likely to be stranded.
    small_penalty = np.where((residual > 0) & (residual < 10), 0.5, 0.0)
    score = score - small_penalty
    return score
# EVOLVE-BLOCK-END
