# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference: prefer a perfect fit, else tightest fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer exact fits (residual == 0): largest bonus to those, else tightest fit.
    return -(residual) + (residual == 0) * 1000.0
# EVOLVE-BLOCK-END

