# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit with reachable-residual and cover utility.

Score each bin by an estimate of how valuable its post-placement residual is.
A residual is valuable if it is likely to be exactly filled by a later item,
or if it can be completed efficiently by a small combination of likely item
sizes. We learn the item distribution online and maintain a reachability /
coverability set over residuals 0..100.
"""
import numpy as np


# Online histogram of observed item sizes (Laplace-smoothed).
_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

# Reachability/utility cache keyed by residual 0..100 -> value.
_UTIL = np.zeros(101, dtype=np.float64)
_DIRTY = True

# Sizes sorted descending among "likely" sizes (probability above mean).
_LIKELY = np.array([], dtype=np.int64)
_LIKELY_PROB = np.array([], dtype=np.float64)


def _rebuild_util():
    """Compute utility of each residual r in 0..100.

    Base value = probability a single future item exactly equals r.
    Added value = probability that r is a sum of 2 (or 3) likely items.
    Added cover value = how densely r can be packed by likely items
    (i.e. low unavoidable waste), which favors residuals that later items
    can collectively use with little leftover.
    """
    global _UTIL, _DIRTY, _LIKELY, _LIKELY_PROB
    probs = _COUNTS / _TOTAL

    order = np.argsort(probs)[::-1]
    top = [int(t) for t in order[:12] if probs[t] > probs.mean()]
    if not top:
        top = [int(order[0])]

    util = probs.copy()

    # Two-item sums.
    for a in top:
        pa = probs[a]
        for b in top:
            s = a + b
            if 0 < s <= 100:
                util[s] += pa * probs[b]
    # Three-item sums (discounted due to sequential alignment).
    for a in top:
        pa = probs[a]
        for b in top:
            pab = pa * probs[b]
            for c in top:
                s = a + b + c
                if 0 < s <= 100:
                    util[s] += 0.35 * pab * probs[c]

    # Cover utility: for each residual, greedily pack with likely sizes and
    # reward high achieved fill fraction with a modest weight. This captures
    # residuals that later items can reduce with little waste even if not
    # exactly representable as a small sum.
    cover = np.zeros(101, dtype=np.float64)
    desc = sorted(top, reverse=True)
    for r in range(1, 101):
        rem = r
        filled = 0
        for s in desc:
            if s <= rem:
                k = rem // s
                filled += k * s
                rem -= k * s
            if rem == 0:
                break
        cover[r] = filled / r
    util = util + 0.25 * cover * probs.max()

    _UTIL = util

    _LIKELY = np.array(desc, dtype=np.int64)
    _LIKELY_PROB = probs[desc].copy() if len(desc) else np.array([])
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild_util()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    val = _UTIL[ri]
    score = np.log(val + 1e-9)

    # Strong bonus for perfect fits.
    score += (residual == 0.0).astype(np.float64) * 5.0

    # Mild best-fit pressure to break ties sensibly.
    score -= residual * 0.005

    # Update online histogram.
    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
