# EVOLVE-BLOCK-START
"""Best fit with a bonus for nearly-full residues."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: tightest fit (smallest residual gets highest priority).
    score = -residual.astype(np.float64)
    # Strongly prefer bins that become almost exactly full (residual <= 5),
    # since leftover tiny space is hard to reuse.
    score += np.where(residual <= 5, 1000.0, 0.0)
    return score
# EVOLVE-BLOCK-END

