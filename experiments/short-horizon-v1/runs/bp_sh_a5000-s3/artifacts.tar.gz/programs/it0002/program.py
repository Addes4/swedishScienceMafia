# EVOLVE-BLOCK-START
"""Best fit with residual-friendly tie-breaking for Weibull-shaped items (mean ~40)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity if the item goes here
    # Classic best fit: prefer the smallest residual.
    # Mild bonus when residual is near a typical item size (~40), which reduces waste.
    bonus = -np.abs(residual - 40) * 0.05
    return -residual + bonus
# EVOLVE-BLOCK-END

