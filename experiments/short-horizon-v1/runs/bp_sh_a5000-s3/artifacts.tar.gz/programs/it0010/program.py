# EVOLVE-BLOCK-START
"""Best-fit with a light, stateful residual preference tuned to the item distribution."""
import numpy as np


# module-level state shared across calls within a stream (reset happens because the
# harness reloads/restarts the module per stream; we also guard by size).
_hist = np.zeros(101, dtype=np.float64)   # counts of item sizes seen
_mean = 40.0
_n = 0


def priority(item, bins):
    global _hist, _mean, _n
    # update running statistics of arriving items
    _hist[item] += 1.0
    _n += 1
    _mean += (item - _mean) / _n

    # post-placement residual for every bin
    resid = bins - item

    # base score: tightest fit -> smallest residual (most negative residual is best)
    score = -resid.astype(np.float64)

    # When the item is small relative to the mean, a bin leaving a residual near the
    # mean size is slightly more valuable (it can host one more typical item). Give a
    # small bonus to residuals within a band around the running mean.
    if item < _mean:
        target = _mean
        band = 0.15 * _mean + 1.0
        bonus = np.clip(1.0 - np.abs(resid - target) / band, 0.0, 1.0)
        score += 0.35 * bonus

    return score
# EVOLVE-BLOCK-END
