# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit favoring residuals likely to close exactly."""
import numpy as np


_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

_VALUE = np.zeros(101, dtype=np.float64)
_DIRTY = True


def _smooth(arr, sigma=1.0):
    k = int(3 * sigma)
    xs = np.arange(-k, k + 1, dtype=np.float64)
    w = np.exp(-0.5 * (xs / sigma) ** 2)
    w /= w.sum()
    padded = np.concatenate([np.full(k, arr[0], dtype=np.float64), arr,
                             np.full(k, arr[-1], dtype=np.float64)])
    return np.convolve(padded, w, mode='valid')


def _rebuild_value():
    """V(r) ~ probability residual r is exactly closable by 1..3 future items."""
    global _VALUE, _DIRTY
    probs = _COUNTS / _TOTAL

    top = np.argsort(probs)[::-1][:12]
    top = [int(t) for t in top if probs[t] > 0 and t > 0]

    reach = np.zeros(101, dtype=np.float64)
    reach[0] = 1.0
    for a in top:
        if a <= 100:
            reach[a] = max(reach[a], probs[a])
        pa = probs[a]
        for b in top:
            s = a + b
            if 0 < s <= 100:
                reach[s] = max(reach[s], pa * probs[b])
            for c in top:
                t = a + b + c
                if 0 < t <= 100:
                    reach[t] = max(reach[t], pa * probs[b] * probs[c])

    _VALUE = _smooth(reach, sigma=1.2)
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)
    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    if _DIRTY:
        _rebuild_value()

    m = _COUNTS / _TOTAL
    anchor = int(np.argmax(m[1:]) + 1)
    modal_p = m[anchor]

    # Base: prefer residuals that can be exactly closed later (higher value).
    val = _VALUE[ri]
    score = 2.0 * np.clip(val, 0.0, 1.0)

    # Decisive exact-fit bonus: closing a bin now is the best outcome.
    score += (residual == 0.0).astype(np.float64) * (6.0 + 3.0 * modal_p)

    # Best-fit prior: favor smaller residuals, but only mildly so consolability
    # dominates.
    score += (0.5 + 0.6 * modal_p) * np.exp(-0.5 * (residual / 3.0) ** 2)

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END

