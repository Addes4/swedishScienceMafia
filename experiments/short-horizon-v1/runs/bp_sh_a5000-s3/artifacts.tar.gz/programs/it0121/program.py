# EVOLVE-BLOCK-START
"""Best-fit dominated rule with a small distribution-adaptive closability correction."""
import numpy as np


_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

_REACH = np.zeros(101, dtype=np.float64)
_DIRTY = True


def _smooth(arr, sigma=1.0):
    """Small Gaussian smoothing over the integer residual axis."""
    k = int(3 * sigma)
    xs = np.arange(-k, k + 1, dtype=np.float64)
    w = np.exp(-0.5 * (xs / sigma) ** 2)
    w /= w.sum()
    padded = np.concatenate([np.full(k, arr[0], dtype=np.float64), arr,
                             np.full(k, arr[-1], dtype=np.float64)])
    return np.convolve(padded, w, mode='valid')


def _rebuild_reach():
    """reach[s]: weight that residual s can be exactly closed later."""
    global _REACH, _DIRTY
    probs = _COUNTS / _TOTAL

    top = np.argsort(probs)[::-1][:14]
    top = [int(t) for t in top if probs[t] > probs.mean()]

    reach = np.zeros(101, dtype=np.float64)
    reach[0] = 1.0
    for s in top:
        if 0 < s <= 100:
            reach[s] = max(reach[s], probs[s])

    for a in top:
        if a <= 0 or a > 100:
            continue
        pa = probs[a]
        for b in top:
            s = a + b
            if 0 < s <= 100:
                reach[s] = max(reach[s], pa * probs[b])
            for c in top:
                t = a + b + c
                if 0 < t <= 100:
                    reach[t] = max(reach[t], pa * probs[b] * probs[c])

    _REACH = _smooth(reach)
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild_reach()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    m = _COUNTS / _TOTAL
    modal_p = float(np.max(m[1:]))

    # Classic best-fit dominates: smaller leftover is better.
    score = -residual

    # Small distribution-adaptive correction: prefer leftovers that are
    # likely to be exactly closed by a future item.
    score += (0.5 + 1.5 * modal_p) * _REACH[ri]

    # Decisive exact-fit bonus.
    score += (residual == 0.0).astype(np.float64) * (10.0 + 5.0 * modal_p)

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
