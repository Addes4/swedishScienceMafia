# EVOLVE-BLOCK-START
"""Best fit with a data-driven pairing bonus.

Core is best fit: put the item in the bin it fits most tightly (smallest residual).
Ties (and near-ties) are broken by preferring a residual that looks "fillable":
the empirical distribution of item sizes is tracked, and we favor residuals that
are close to a frequently observed item size, so a future item can complete the bin.
"""
import numpy as np

# module-level state (persists within a stream, reset per stream by the harness)
_SIZES = np.zeros(101, dtype=np.float64)   # histogram of observed item sizes
_COUNT = 0.0

# weight of the fillability bonus relative to the (unit) tightness term
_BONUS_W = 0.35


def priority(item, bins):
    global _COUNT

    # update the empirical size distribution
    _SIZES[item] += 1.0
    _COUNT += 1.0

    # tightness: smaller residual -> higher score
    residual = bins - item

    # ---- fillability of each residual ----
    # Probability mass of observed sizes that, when placed into a bin leaving
    # `residual`, would fill it exactly or nearly exactly. We compute, for each
    # candidate residual r, a score = sum over observed sizes s of mass(s) * g(r, s)
    # where g is high when s can fill r well (s == r) and slightly lower when s
    # is a good partner (s small enough to leave a small r-s that is itself common).
    #
    # To keep it cheap, evaluate fillability only on the distinct residual values
    # present among feasible bins.
    uniq_res, inv = np.unique(residual, return_inverse=True)
    k = uniq_res.size

    if _COUNT > 8.0:
        prob = _SIZES / _COUNT
        # sizes with non-negligible probability
        s_idx = np.nonzero(prob)[0].astype(np.float64)
        s_mass = prob[s_idx.astype(np.int64)]

        # r shape (k,1), s shape (1,m)
        r = uniq_res.astype(np.float64)[:, None]
        s = s_idx[None, :]

        # exact-fill indicator: s == r  (best possible completion)
        exact = (s == r).astype(np.float64)
        # partial-fill: s < r, reward leaving a small residual that is itself common
        # reward based on leftover = r - s, scaled down as leftover grows
        leftover = r - s
        partial = np.where((leftover > 0.0), 1.0 / (1.0 + leftover), 0.0)

        fill = (exact * 2.0 + partial) @ s_mass
        # also normalize so it is a per-residual density-like quantity in [0, ~]
        fill = fill / (1.0 + fill)  # squash into [0,1)

        fill_per_bin = fill[inv]
    else:
        fill_per_bin = np.zeros(bins.shape, dtype=np.float64)

    # Primary: tightness.  Secondary: fillability bonus.
    # Represent tightness as a large-scale term so best fit always dominates
    # among clearly different residuals, while the bonus resolves close calls.
    return -residual.astype(np.float64) + _BONUS_W * fill_per_bin
# EVOLVE-BLOCK-END
