# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit with reachable-residual bonus.

Score each bin by blending a strong best-fit term with an estimate of how
valuable its post-placement residual is.  A residual is valuable if a future
item is likely to exactly fill it, or if it can be completed by a small
combination of likely item sizes.  We learn the item distribution online and
maintain a reachability set over residuals 0..100.
"""
import numpy as np


# Online histogram of observed item sizes (Laplace-smoothed).
_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

# Reachability/utility cache for residuals 0..100.
_UTIL = np.zeros(101, dtype=np.float64)
_DIRTY = True

# Number of items seen so far (for blending weight).
_SEEN = 0.0


def _rebuild_util():
    """Utility of each residual r in 0..100 under the learned distribution."""
    global _UTIL, _DIRTY
    probs = _COUNTS / _TOTAL

    top = np.argsort(probs)[::-1][:12]
    top = [int(t) for t in top if probs[t] > probs.mean()]

    util = probs.copy()

    for a in top:
        if a <= 0 or a > 100:
            continue
        for b in top:
            s = a + b
            if 0 < s <= 100:
                util[s] += 0.5 * probs[a] * probs[b]
    for a in top:
        for b in top:
            for c in top:
                s = a + b + c
                if 0 < s <= 100:
                    util[s] += 0.15 * probs[a] * probs[b] * probs[c]

    _UTIL = util
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY, _SEEN

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild_util()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)
    val = _UTIL[ri]

    # Blend: early in the stream trust best-fit, later trust the learned
    # residual utility.  Weight ramps from 0.35 to 1.0.
    w = 0.35 + 0.65 * min(1.0, _SEEN / 800.0)

    logval = np.log(val + 1e-9)
    lmin, lmax = logval.min(), logval.max()
    if lmax > lmin:
        logval = (logval - lmin) / (lmax - lmin)

    best_fit = -residual * 0.05

    score = w * logval + best_fit
    score += (residual == 0.0).astype(np.float64) * 6.0

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _SEEN += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
