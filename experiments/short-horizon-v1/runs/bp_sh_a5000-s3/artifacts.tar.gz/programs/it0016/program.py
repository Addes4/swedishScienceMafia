# EVOLVE-BLOCK-START
"""Hybrid best-fit: tightest fit, but bias large items toward bins that keep a usable gap."""
import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.mean = 40.0
        self.m2 = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Online estimate of the item-size mean (Welford) to classify "large" items.
    s = _state
    s.count += 1
    delta = item - s.mean
    s.mean += delta / s.count
    s.m2 += delta * (item - s.mean)

    residual = bins - item  # remaining capacity after placing the item

    # Base score: best fit (smaller residual is better).
    score = -residual.astype(np.float64)

    # For large items, nudge toward bins whose residual stays usefully large.
    # "Large" is anything above the running mean; use a soft bonus that never
    # overrides the tight fit ordering among comparable residuals.
    if item > s.mean:
        # Prefer residuals that are at least the size of a typical large item,
        # so the leftover can still host a future item; scale gently.
        bonus = np.minimum(residual, item) * 0.05
        score = score + bonus

    return score
# EVOLVE-BLOCK-END
