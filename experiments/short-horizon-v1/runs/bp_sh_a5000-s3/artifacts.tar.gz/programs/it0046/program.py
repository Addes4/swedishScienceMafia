# EVOLVE-BLOCK-START
"""Best fit with a sliver-avoidance fallback.

Mostly classic best fit (tightest post-placement residual). But when the
tightest placement would leave a tiny residual (a useless sliver) while a
completely fresh bin (remaining capacity 100) is available, send the item to
the fresh bin instead. This trades a slightly worse immediate fit for avoiding
fragments too small to be filled later, which tends to reduce the bin count on
Weibull-shaped streams.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (ties: first bin)."""
    residual = bins - item
    # Sliver threshold: residuals below this are likely unusable.
    SLIVER = 8

    scores = -residual.astype(np.float64)

    best = int(np.argmin(residual))
    # If the tightest fit would create a sliver and a fresh bin exists,
    # strongly prefer the emptiest (fresh) bin instead.
    if residual[best] < SLIVER:
        # locate a fresh bin (remaining capacity == 100)
        fresh = np.flatnonzero(bins == 100)
        if fresh.size:
            scores[:] = -residual.astype(np.float64)
            # give fresh bins a large bonus so one is chosen
            scores[fresh] += 1e6
    return scores
# EVOLVE-BLOCK-END
