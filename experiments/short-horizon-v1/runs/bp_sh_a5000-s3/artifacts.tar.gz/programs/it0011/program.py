# EVOLVE-BLOCK-START
"""Best fit with a tiny priority for near-exact fills.

Pure best-fit already performs well here. The classic weakness of best-fit is
that it leaves many tiny stranded gaps (residual capacity too small to hold any
future item). A simple, robust way to recover some of that space is to prefer
bins that would be *exactly* filled (residual 0) or filled to a small residual
by the current item, since those residuals are the most likely to be wasted.
We therefore minimize the post-placement residual as the primary key, but add a
small fractional bonus when the residual is 0, so that exact-fill bins are
chosen first among equal residuals.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # always >= 0 because only fitting bins are shown
    # Primary term: strongly prefer the smallest residual (tightest fit).
    # Secondary term: tiny bonus for an exact fill (residual == 0) so that
    # perfectly filling a bin is chosen whenever it is available.
    exact = (residual == 0).astype(np.float64)
    return -residual.astype(np.float64) + 1e-3 * exact
# EVOLVE-BLOCK-END
