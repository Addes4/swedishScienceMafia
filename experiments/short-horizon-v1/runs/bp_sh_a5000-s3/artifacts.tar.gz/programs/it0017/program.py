# EVOLVE-BLOCK-START
"""Best fit with a worst-fit tie-break within a small residual band."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # post-placement leftover capacity
    # Primary: minimize residual (tightest fit). Secondary: prefer larger pre-placement
    # capacity to keep big free spaces intact, but only within a small band.
    # Encode lexicographically with a band small enough not to override tight fits.
    band = 2.0
    # Higher score is better:
    #  - tighter fit gives higher score (less residual)
    #  - within band, larger 'bins' (pre-placement capacity) gives higher score
    primary = -residual.astype(np.float64)
    # Normalize bins into [0,1) so it only acts as a tie-break inside the band.
    secondary = bins.astype(np.float64) / 1000.0
    # Gate the secondary so it only matters when residuals are close.
    return primary + band * secondary
# EVOLVE-BLOCK-END
