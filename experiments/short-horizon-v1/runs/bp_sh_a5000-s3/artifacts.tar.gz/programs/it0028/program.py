# EVOLVE-BLOCK-START
"""Best fit with a small bonus for residuals likely to be filled by a future item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit: tighter remaining capacity after placement is better.
    score = -(bins - item)
    # Small bonus when the post-placement residual leaves room for exactly one more
    # typical item, encouraging bins to be closed rather than left half-full.
    # residual range is 0..(100-item); a residual of 0 is already best-fit-optimal.
    return score
# EVOLVE-BLOCK-END
