# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit using a subset-sum closability prior."""
import numpy as np


_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

# _CLOSE[r] ~ probability-like weight that residual r is exactly fillable by
# a small multiset of future items (subset-sum style knapsack reachability).
_CLOSE = np.zeros(101, dtype=np.float64)
_DIRTY = True


def _smooth(arr, sigma=1.0):
    k = int(3 * sigma)
    xs = np.arange(-k, k + 1, dtype=np.float64)
    w = np.exp(-0.5 * (xs / sigma) ** 2)
    w /= w.sum()
    padded = np.concatenate([np.full(k, arr[0], dtype=np.float64), arr,
                             np.full(k, arr[-1], dtype=np.float64)])
    return np.convolve(padded, w, mode='valid')


def _rebuild_close():
    global _CLOSE, _DIRTY
    probs = _COUNTS / _TOTAL
    m = probs[1:101]
    support = np.nonzero(m > 0.0)[0] + 1  # item sizes with observed mass

    # forward DP: reach[s] = max probability of forming sum s with up to K items.
    # We use max-product so it approximates the "best chance" of closing.
    reach = np.zeros(101, dtype=np.float64)
    reach[0] = 1.0
    for _ in range(4):  # up to 4 items
        new = reach.copy()
        for s in support:
            if s <= 0 or s > 100:
                continue
            ps = probs[s]
            shifted = reach[:101 - s] * ps
            np.maximum(new[s:], shifted, out=new[s:])
        reach = new

    _CLOSE = _smooth(reach, sigma=0.6)
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild_close()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    m = _COUNTS / _TOTAL
    modal_p = m[1:].max()

    # Base value: closability of the leftover for future items.
    val = _CLOSE[ri]
    score = np.log(val + 1e-9)

    # Decisive exact-fit bonus (residual 0 is best).
    score += (residual == 0.0).astype(np.float64) * (6.0 + 3.0 * modal_p)

    # Classic best-fit tiebreak: prefer residues that score well as closable
    # but also smaller leftovers when closability is similar.
    score += (0.7 + 0.8 * modal_p) * np.exp(-0.5 * (residual / 3.5) ** 2)

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
