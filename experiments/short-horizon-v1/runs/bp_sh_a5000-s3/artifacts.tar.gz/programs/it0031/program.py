# EVOLVE-BLOCK-START
"""Best fit with a fillability-aware tie-break.

Core policy: prefer the tightest fit (smallest post-placement residual). Among placements
whose residual is close to the tightest, break the tie by preferring residuals that are
more likely to be exactly filled by a single future item, using a running histogram of
observed sizes. This keeps best-fit behavior for clearly distinct fits and only nudges
choices within a small window.
"""
import numpy as np

_resid_hist = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    global _total
    res = bins - item  # post-placement residual, >= 0 since bins only contains feasible bins
    best = res.min()
    # window: consider residuals within a small margin of the best
    window = np.maximum(1.0, 0.02 * best)
    close = res <= (best + window)

    # fillability score: how often a residual value close to r has been exactly matched
    # by an arriving item. Use observed histogram, smoothed toward 0.
    fill = np.zeros(res.shape, dtype=np.float64)
    for idx in range(res.shape[0]):
        r = res[idx]
        if r <= 100:
            # count probability mass of items that exactly equal r (approx via neighborhood)
            lo = int(max(0, r - 1))
            hi = int(min(100, r + 1))
            fill[idx] = _resid_hist[lo:hi + 1].sum()

    # primary: tightness (negate residual); secondary: fillability among close candidates
    score = -res.astype(np.float64) + 0.001 * close * fill

    # update state with observed item
    _resid_hist[item] += 1.0
    _total += 1.0
    return score
# EVOLVE-BLOCK-END
