# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit with probabilistic completion bonus."""
import numpy as np


_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0
_DIRTY = True

# cached distribution-derived tables
_CDF = None
_P1 = None
_P2 = None
_ANCHOR = 40


def _rebuild():
    """Recompute cheap distribution statistics: exact-1 completion prob and
    one/two-item reachability probability for each residual 0..100."""
    global _CDF, _P1, _P2, _ANCHOR, _DIRTY

    probs = _COUNTS / _TOTAL
    probs[0] = 0.0
    _ANCHOR = int(np.argmax(probs[1:]) + 1)

    # probability that residual r can be matched exactly by one future item
    p1 = np.zeros(101, dtype=np.float64)
    p1[:] = probs[:101]

    # probability that residual r can be split into two items (a + b = r)
    # computed by convolution of the item distribution with itself
    conv = np.convolve(probs, probs)
    p2 = np.zeros(101, dtype=np.float64)
    n = min(101, len(conv))
    p2[:n] = conv[:n]
    # caution: pure raw conv overweights a==b combos slightly; fine here

    _P1 = p1
    _P2 = p2
    _CDF = np.cumsum(probs)
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)
    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    if _DIRTY:
        _rebuild()

    # Best-fit base: prefer the tightest residual (smallest leftover).
    # Scale gently so it doesn't dominate.
    score = -0.010 * residual

    # Probabilistic completion bonus: how likely can this residual be filled
    # exactly by one, or by a pair of, future items.
    score += 1.00 * _P1[ri]
    score += 0.35 * _P2[ri]

    # Strong bonus for a perfect fit (residual == 0).
    score += (residual == 0.0).astype(np.float64) * 4.0

    # Lightly discourage leaving exactly a residual that equals the modal item
    # size in a still-open bin (premature locking).
    modal_p = _P1[_ANCHOR]
    avoid = (ri == _ANCHOR) & (bins > item)
    score -= avoid.astype(np.float64) * (0.25 * modal_p)

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
