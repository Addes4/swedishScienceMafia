# EVOLVE-BLOCK-START
"""Best fit with an anti-fragmentation fallback.

Primary rule: best fit (place item in the bin leaving the smallest residual).
Fallback: if the tightest fit would leave a residual too small to ever hold a typical
item (a "stranded" gap), and there is another bin whose residual after placement
equals a small integer that is at least the minimum item size seen so far, prefer
that bin instead. This rescues space that would otherwise be wasted, without
changing behavior in the common case.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    residual = bins - item              # >= 0 since bins only shows fitting bins
    # Primary: best fit -> smallest residual gets highest score.
    score = -residual.astype(np.float64)

    r_min = residual.min()
    # Only intervene when the tightest gap is small (likely to be stranded).
    # Items are integers 1..100 with mean ~40, so gaps below ~8 are usually dead.
    if r_min <= 7 and bins.max() >= 100:
        # Look for an alternative bin whose resulting residual is a "nice" gap,
        # i.e. at least 8 (usable) but not wasteful. We gently boost such bins.
        usable = residual >= 8
        if usable.any() and not usable[residual.argmin()]:
            # Boost usable bins slightly above the tightest (stranding) bin,
            # preferring the smallest usable residual (still tightish).
            score = np.where(usable, -residual.astype(np.float64) + 1e6, score)

    return score
# EVOLVE-BLOCK-END
