# EVOLVE-BLOCK-START
"""Best fit with a tiny epsilon that discourages opening fresh bins."""
import numpy as np


def priority(item, bins):
    """Best-fit score, with a micro-bias toward bins that are already in use.

    Primary term: -(bins - item), i.e. prefer the tightest post-placement residual.
    Secondary term: a tiny penalty for large remaining capacities (fresh/unused bins),
    which only matters when residuals are effectively tied, so best-fit behavior is
    preserved while ties nudge toward packed bins.
    """
    residual = bins - item
    # micro-bias: prefer bins with smaller pre-placement remaining capacity on ties
    return -residual.astype(np.int64) * 1024 - bins.astype(np.int64)
# EVOLVE-BLOCK-END
