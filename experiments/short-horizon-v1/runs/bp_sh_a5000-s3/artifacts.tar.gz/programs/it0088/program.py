# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit using online exact-completion probabilities."""
import numpy as np


_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

_PROB = _COUNTS / _TOTAL
_DIRTY = True

# Best-fit table: for two observed sizes, prefer minimal feasible residual.
_BF = np.zeros(101, dtype=np.float64)
for _r in range(101):
    _BF[_r] = -float(_r)


def _rebuild():
    global _PROB, _DIRTY
    _PROB = _COUNTS / _TOTAL
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    # Probability the residual is exactly completed by one future item.
    p_exact = _PROB[ri]

    score = np.log(p_exact + 1e-9)

    # Best-fit preference: smaller feasible residual is better.
    score += _BF[ri] * 0.02

    # Slight bonus for leaving a bit of slack room for pairing.
    score += (residual > 0.0).astype(np.float64) * 0.05
    # Emphasize exact fills.
    score += (residual == 0.0).astype(np.float64) * 3.0

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
