# EVOLVE-BLOCK-START
"""Best fit with a data-driven residual-utility tie-break.

Dominant term is classic best fit (prefer the smallest feasible post-placement
residual). The tie-break uses an online histogram of observed item sizes:
a residual is more useful if it is large enough to still hold commonly seen
small items, and slightly wasteful if it sits just short of a frequent size.
"""
import numpy as np

# module-level online state (reset happens on module reimport per stream)
_SIZE_BUCKETS = 32  # buckets over [1, 100]
_hist = np.zeros(_SIZE_BUCKETS, dtype=np.float64)
_n = 0.0


def _bucket(s):
    b = int((s - 1) * _SIZE_BUCKETS // 100)
    if b < 0:
        b = 0
    elif b >= _SIZE_BUCKETS:
        b = _SIZE_BUCKETS - 1
    return b


def priority(item, bins):
    global _hist, _n

    residual = bins - item  # >= 0, post-placement capacity

    # Dominant: best fit -> largest score for smallest residual.
    base = -residual.astype(np.float64)

    # Update online item-size histogram (after computing, no future info used).
    b = _bucket(item)
    _hist[b] += 1.0
    _n += 1.0

    # Typical "small" item sizes actually seen so far (use histogram mass below
    # a threshold) to judge whether a residual can hold another item.
    if _n > 32.0:
        # probability-weighted demand for residuals of a given size is roughly
        # the fraction of items that fit. Approximate by counting, for each
        # residual value, how much probability mass of item sizes <= residual
        # exists: a residual is useful if it can hold a non-trivial fraction.
        # Bucket edges.
        edges_lo = np.arange(_SIZE_BUCKETS) * 100.0 / _SIZE_BUCKETS + 1.0
        edges_hi = edges_lo + 100.0 / _SIZE_BUCKETS - 1.0
        r = residual.astype(np.float64)
        # mass of items with size <= residual (approx): sum hist where edge_hi <= r
        # plus partial for the straddling bucket.
        cum = np.cumsum(_hist)
        # index of last bucket fully below residual
        idx = np.searchsorted(edges_hi, r, side='right') - 1
        usable = np.where(idx >= 0, cum[np.clip(idx, 0, _SIZE_BUCKETS - 1)], 0.0)
        utility = usable / _n  # in [0, 1]
        # Prefer residuals that can hold at least ~15% of item mass.
        bonus = np.minimum(utility, 0.5)
    else:
        bonus = np.zeros_like(residual, dtype=np.float64)

    # Small weight so best fit stays dominant.
    return base + 0.6 * bonus
# EVOLVE-BLOCK-END
