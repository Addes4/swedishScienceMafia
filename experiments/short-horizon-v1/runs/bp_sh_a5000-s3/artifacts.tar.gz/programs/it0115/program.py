# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit via a learned residual value function."""
import numpy as np


_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

# value[s] = learned value of leaving residual capacity s (higher = better)
_VALUE = np.zeros(101, dtype=np.float64)
_PROB = np.ones(101, dtype=np.float64) / 101.0
_DIRTY = True


def _smooth(arr, sigma=1.0):
    k = int(3 * sigma)
    xs = np.arange(-k, k + 1, dtype=np.float64)
    w = np.exp(-0.5 * (xs / sigma) ** 2)
    w /= w.sum()
    padded = np.concatenate([np.full(k, arr[0], dtype=np.float64), arr,
                             np.full(k, arr[-1], dtype=np.float64)])
    return np.convolve(padded, w, mode='valid')


def _rebuild():
    """Build a residual value function from the observed item histogram.

    The key idea: a residual s is good if it equals 0 (bin closes exactly),
    or if it can likely be exactly consumed by a single or short combination
    of future items.  We estimate, for each residual s, the probability mass
    of future single items that exactly match s, plus a discounted bonus for
    residuals reachable via 2-item sums.
    """
    global _VALUE, _PROB, _DIRTY

    probs = _COUNTS / _TOTAL

    # Restrict to the observed support (items seen at least once beyond prior).
    support = [s for s in range(1, 101) if probs[s] > probs.mean()]
    if not support:
        support = list(range(1, 101))

    # p_single[s]: probability a future item is exactly s.
    p_single = probs.copy()

    # p_pair[s]: probability some pair of future items sums to exactly s,
    # approximated as the mass of matching pairs.
    p_pair = np.zeros(101, dtype=np.float64)
    for a in support:
        pa = probs[a]
        for b in support:
            s = a + b
            if 0 < s <= 100:
                p_pair[s] += pa * probs[b]

    # Value of a residual: strongly reward exact closures, gently reward
    # residuals that a future item will complete.
    value = 1.0 * p_single
    value += 0.5 * p_pair
    value[0] = 1.0 + 2.0 * np.max(p_single[1:]) if np.max(p_single[1:]) > 0 else 1.0

    _VALUE = _smooth(value, sigma=1.0)
    _PROB = probs
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    val = _VALUE[ri]
    score = val.copy()

    # Strong exact-fit preference: closing a bin now dominates everything.
    score += (residual == 0.0).astype(np.float64) * 10.0

    # Best-fit: among non-exact placements, prefer the smallest residual,
    # realized through the value function's natural decay plus a small
    # tie-break toward near-zero residuals.
    modal_p = float(np.max(_PROB[1:]))
    score += (0.5 + 0.5 * modal_p) * np.exp(-0.5 * (residual / 2.0) ** 2)

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
