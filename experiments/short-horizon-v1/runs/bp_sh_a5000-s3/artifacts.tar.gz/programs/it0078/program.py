# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit with reachable-residual bonus.

Score each bin by an estimate of how valuable its post-placement residual is.
A residual is valuable if it is likely to be exactly filled by a later item,
or more generally if it can be completed by a small combination of likely
item sizes (e.g. 40+60). We learn the item distribution online and maintain
a reachability set over residuals 0..100 built from common observed sizes.
"""
import numpy as np


# Online histogram of observed item sizes (Laplace-smoothed).
_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

# Reachability/utility cache over residuals 0..100.
_UTIL = np.zeros(101, dtype=np.float64)
_DIRTY = True


def _rebuild_util():
    """Compute utility of each residual r in 0..100."""
    global _UTIL, _DIRTY
    probs = _COUNTS / _TOTAL

    # Most likely item sizes (top few) for combination building.
    top = np.argsort(probs)[::-1][:12]
    top = [int(t) for t in top if probs[t] > probs.mean()]

    util = probs.copy()

    # Two-item sums.
    for a in top:
        if a <= 0 or a > 100:
            continue
        for b in top:
            s = a + b
            if 0 < s <= 100:
                util[s] += probs[a] * probs[b]
    # Three-item sums, discounted.
    for a in top:
        for b in top:
            for c in top:
                s = a + b + c
                if 0 < s <= 100:
                    util[s] += 0.35 * probs[a] * probs[b] * probs[c]

    _UTIL = util
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild_util()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    val = _UTIL[ri]
    # Log-scaled utility is the dominant ranking signal.
    score = np.log(val + 1e-9) * 1.0

    # Very strong preference for perfect fits.
    score += (residual == 0.0).astype(np.float64) * 6.0

    # Best-fit pressure: prefer the tightest bin among comparable utilities.
    # Applied additively but scaled so it breaks ties without dominating.
    score -= residual * 0.02

    # Small bonus for leaving a residual that is itself a plausible item size.
    score += probs_lookup(ri) * 2.0

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score


def probs_lookup(ri):
    """Probability that a future item equals each rounded residual."""
    probs = _COUNTS / _TOTAL
    return probs[np.clip(ri, 0, 100)]
# EVOLVE-BLOCK-END

