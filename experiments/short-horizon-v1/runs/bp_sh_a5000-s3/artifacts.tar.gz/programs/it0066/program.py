# EVOLVE-BLOCK-START
"""Best fit with a smoothed small-residual penalty.

Dominant term is best fit (prefer smallest post-placement residual), but we add a
decisive penalty for residuals that are too small to be useful (below ~10, where
few future items fit) and a bonus for exact fills. This changes the ranking among
near-equal fits rather than acting as a negligible tie-break.
"""
import numpy as np


def priority(item, bins):
    residual = (bins - item).astype(np.float64)  # >= 0

    # Dominant: prefer tightest fit.
    base = -residual

    # Penalize stranded tiny gaps smoothly: residuals in (0, 10) are largely
    # unusable (items are ~Weibull with mean 40, few are smaller than 10).
    # penalty is strongest just above 0 and fades to 0 by residual >= 10.
    gap_pen = np.where(
        (residual > 0) & (residual < 10),
        (10.0 - residual) * 0.5,
        0.0,
    )

    # Bonus for exact fill (residual == 0), which is always ideal.
    exact = np.where(residual == 0, 0.5, 0.0)

    return base + exact - gap_pen
# EVOLVE-BLOCK-END
