# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit with exact-fill priority.

Score each bin by the estimated value of its post-placement residual. The
dominant signal is the probability that a single later item exactly equals the
residual, with a secondary reachability term for residuals completable by a
small combination of common sizes, and a strong perfect-fit bonus.
"""
import numpy as np


# Online histogram of observed item sizes (Laplace-smoothed).
_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

# Utility / reachability caches keyed by rounded residual.
_UTIL = np.zeros(101, dtype=np.float64)
_REACH = np.zeros(101, dtype=np.float64)
_EXACT = np.zeros(101, dtype=np.float64)
_DIRTY = True


def _rebuild_util():
    """Compute value of each residual r in 0..100."""
    global _UTIL, _DIRTY, _REACH, _EXACT
    probs = _COUNTS / _TOTAL

    # Most likely item sizes for combination building.
    top = np.argsort(probs)[::-1][:12]
    top = [int(t) for t in top if probs[t] > probs.mean()]

    util = probs.copy()      # exact single-item fill probability
    exact = probs.copy()
    reach = np.zeros(101, dtype=np.float64)
    reach[0] = 1.0
    for s in top:
        if 0 < s <= 100:
            reach[s] = 1.0

    # Two-item sums.
    for a in top:
        if a <= 0 or a > 100:
            continue
        pa = probs[a]
        for b in top:
            s = a + b
            if 0 < s <= 100:
                util[s] += pa * probs[b]
                reach[s] = 1.0
    # Three-item sums, discounted.
    for a in top:
        pa = probs[a]
        for b in top:
            pab = pa * probs[b]
            for c in top:
                s = a + b + c
                if 0 < s <= 100:
                    util[s] += 0.35 * pab * probs[c]
                    reach[s] = 1.0

    _UTIL = util
    _REACH = reach
    _EXACT = exact
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild_util()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    # Base value of leaving this residual.
    val = _UTIL[ri]
    score = np.log(val + 1e-9)

    # Reward residuals that a single later item can exactly fill.
    score += 1.2 * np.log(_EXACT[ri] + 1e-6)

    # Bonus for residuals decomposable into common sizes.
    score += 0.15 * _REACH[ri]

    # Strong bonus for perfect fits.
    score += (residual == 0.0).astype(np.float64) * 5.0

    # Mild best-fit pressure.
    score -= residual * 0.005

    # Update online histogram.
    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END

