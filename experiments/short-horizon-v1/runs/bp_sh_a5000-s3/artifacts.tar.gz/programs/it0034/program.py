# EVOLVE-BLOCK-START
"""Best fit with a small residual-aware tie-break to reduce fragmentation."""
import numpy as np

# Running histogram of observed item sizes (index 1..100).
_count = np.zeros(101, dtype=np.int64)
_total = 0


def priority(item, bins):
    """Rank bins: prefer near-tight fits, but favor residuals matching common item sizes."""
    global _count, _total
    _count[item] += 1
    _total += 1

    residuals = bins - item  # post-placement remaining capacity
    n = len(residuals)

    # Estimate a "common small-ish" target from the histogram: weighted mean of
    # observed sizes capped below 100, so pairing is plausible.
    if _total > 0:
        sizes = np.arange(101, dtype=np.float64)
        w = _count.astype(np.float64)
        mean_size = float((sizes * w).sum() / max(1.0, w.sum()))
    else:
        mean_size = 40.0

    # Target residual: prefer leaving room for roughly the mean item size.
    target = max(1.0, min(99.0, mean_size))

    # Base score: best fit (smaller residual is better).
    base = -residuals.astype(np.float64)

    # Bonus for residuals that can still accept a typical item (>= target),
    # but only a mild one so tight fits still dominate when close.
    fits_next = (residuals >= target).astype(np.float64)

    # Penalize zero residuals slightly less than tiny unusable slivers.
    score = base + 0.5 * fits_next

    return score
# EVOLVE-BLOCK-END

