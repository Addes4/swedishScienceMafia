# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit with reachable-residual and future-fit bonus."""
import numpy as np


_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

_UTIL = np.zeros(101, dtype=np.float64)
_REACH = np.zeros(101, dtype=np.float64)
_FUT = np.zeros(101, dtype=np.float64)
_DIRTY = True


def _rebuild_util():
    global _UTIL, _DIRTY, _REACH, _FUT
    probs = _COUNTS / _TOTAL

    top = np.argsort(probs)[::-1][:12]
    top = [int(t) for t in top if probs[t] > probs.mean()]

    util = probs.copy()
    reach = np.zeros(101, dtype=np.float64)
    reach[0] = 1.0
    for s in top:
        if 0 < s <= 100:
            reach[s] = 1.0

    if len(top) >= 1:
        for a in top:
            if a <= 0 or a > 100:
                continue
            for b in top:
                s = a + b
                if 0 < s <= 100:
                    util[s] += probs[a] * probs[b]
                    reach[s] = 1.0

    # Future-fit: for each residual r, the probability mass of item sizes that
    # can be placed into a bin with residual r (i.e. remaining sizes <= r).
    cdf = np.cumsum(probs)
    fut = cdf.copy()  # fut[r] = P(size <= r)
    fut[0] = 0.0

    _UTIL = util
    _REACH = reach
    _FUT = fut
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild_util()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    val = _UTIL[ri]
    score = np.log(val + 1e-9)

    score += 0.15 * _REACH[ri]

    # Reward residuals that can still accept a broad range of future items.
    score += 0.35 * _FUT[ri]

    m = _COUNTS / _TOTAL
    anchor = int(np.argmax(m[1:]) + 1)
    modal_p = m[anchor]

    exact_fit = (residual == 0.0).astype(np.float64) * (5.0 + 2.0 * modal_p)
    score += exact_fit

    near_exact = np.exp(-0.5 * (residual - anchor) ** 2)
    score += 0.4 * modal_p * near_exact

    score -= np.abs(residual - anchor) * 0.004

    avoid = (np.abs(residual - anchor) < 1e-9) & (bins > item)
    score -= avoid.astype(np.float64) * (0.3 * modal_p)

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
