# EVOLVE-BLOCK-START
"""Best fit, refined: prefer residuals that can actually be filled by a future item.

Items arrive one at a time.  Pure best-fit (choose the smallest residual) is a strong
online rule, but it frequently leaves a residual that no future item can fill, wasting
the leftover space.  We keep the tight-fit preference but re-rank using a running
histogram of observed item sizes: among the feasible bins we prefer the residual that
a commonly seen upcoming item size could "close" (leaving a small leftover), which
makes the residual actually usable.
"""
import numpy as np


def priority(item, bins):
    """Return a priority score per bin; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Running histogram of observed item sizes (a simple, self-contained statistic).
    hist = priority.hist
    hist[item] += 1
    n = priority.count + 1
    priority.count = n

    residual = bins - item  # >= 0 for all shown bins

    # Probability that a future item exactly closes a residual r (within a tolerance):
    # use the running frequency of item sizes.  For a residual r, the best "filler"
    # is the most frequent item size not exceeding r, leaving leftover r - s.
    # Score = prefer small leftover after the best filler, then small residual.
    # Build a small lookup only over the distinct residuals present.
    uniq, inv = np.unique(residual, return_inverse=True)

    # Cumulative counts over sizes (index 0..100), used to find the most frequent s <= r.
    freq = hist.astype(np.float64)
    # best_remaining[r] = r - (argmax over s<=r of freq[s] == 0 -> 0)
    # We compute cheaply by scanning sizes once, tracking prefix-best.
    best_s = np.zeros(101, dtype=np.int64)  # best filler size <= r
    cur_best_size = 0
    cur_best_val = -1.0
    for s in range(0, 101):
        if freq[s] > cur_best_val:
            cur_best_val = freq[s]
            cur_best_size = s
        best_s[s] = cur_best_size
    # if no observations yet, freq all zero -> best_s stays 0; leftover = r (harmless)

    leftover = np.empty(uniq.shape[0], dtype=np.float64)
    for i in range(uniq.shape[0]):
        r = int(uniq[i])
        if r > 100:
            r = 100
        s = int(best_s[r])
        leftover[i] = r - s  # >= 0 leftover after the most likely filler

    lo = leftover[inv]

    # Primary: smallest leftover (residual is actually fillable).
    # Secondary: smallest residual (classic best fit behaviour, tightest fit).
    # Encode as a single score: maximize (-leftover, -residual).
    # Use a large multiplier on the first term to make it lexicographic.
    return -(lo * 1000.0 + residual.astype(np.float64))


priority.hist = np.zeros(101, dtype=np.int64)
priority.count = 0
# EVOLVE-BLOCK-END

