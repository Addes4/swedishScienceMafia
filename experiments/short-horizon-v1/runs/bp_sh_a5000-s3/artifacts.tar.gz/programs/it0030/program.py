# EVOLVE-BLOCK-START
"""Best-fit with a complement-awareness bonus estimated from observed item sizes."""
import numpy as np


class _State:
    def __init__(self):
        # histogram of item sizes seen so far (1..100)
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def observe(self, item):
        self.counts[item] += 1.0
        self.total += 1.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # post-placement residual, all >= 0 since item fits

    # base: best fit -> prefer smallest residual
    score = -residual.astype(np.float64)

    # complement bonus: reward residuals that the observed stream tends to fill exactly.
    # Estimate fill probability for residual value r as P(next item == r) using counts.
    if _state.total > 0:
        p = _state.counts / _state.total
    else:
        p = np.zeros(101, dtype=np.float64)

    # For each bin, look up fill probability of its residual (clip to 0..100).
    r = np.clip(residual, 0, 100).astype(np.int64)
    bonus = p[r]

    # weight the bonus so it can overturn the best-fit ordering when meaningful
    score += 4.0 * bonus

    # observe this item after scoring (state used for future decisions only)
    _state.observe(item)

    return score
# EVOLVE-BLOCK-END
