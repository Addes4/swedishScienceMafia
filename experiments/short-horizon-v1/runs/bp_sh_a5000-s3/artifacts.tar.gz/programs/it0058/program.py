# EVOLVE-BLOCK-START
"""Best fit with a small correction against stranding unusable residual gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit ordering: smaller residual is better.
    score = -residual.astype(np.float64)

    # A residual of 0 is perfect; small positive residuals below the
    # smallest likely next item are wasted.  Penalize those hard so the
    # rule looks for a slightly looser bin when the tightest leaves dust.
    tiny = residual > 0
    tiny &= residual < 6
    score[tiny] -= 1.5

    # Among non-tiny placements, mildly prefer residuals that are near
    # common future item sizes (~multiples of 10) so the gap can be reused.
    ok = residual >= 6
    reuse_gain = (residual % 10 == 0).astype(np.float64) * 0.25
    score[ok] += reuse_gain[ok]

    return score
# EVOLVE-BLOCK-END
