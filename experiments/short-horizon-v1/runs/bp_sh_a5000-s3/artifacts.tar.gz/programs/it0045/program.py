# EVOLVE-BLOCK-START
"""Best-fit with a learned histogram bonus: prefer tightly fitting bins, but
slightly favor placements whose resulting residual matches a frequently seen
item size (so a future item is likely to fill it exactly)."""
import numpy as np

# Running histogram of item sizes (1..100), accumulated across the stream.
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest."""
    global _count

    # Update running histogram with the current item.
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # post-placement residual for each bin (>= 0)

    # Smoothed density of the item-size histogram: probability that a future
    # item equals a given residual value.  A Gaussian-ish smoothing of the
    # histogram clipped to valid residual range.
    dens = _hist / _count if _count > 0 else np.zeros(101)

    r = residual.astype(np.float64)
    np.clip(r, 0, 100, out=r)

    # Density at the resulting residual (0 residual is best: bin becomes full).
    idx = r.astype(np.int64)
    bonus = dens[idx]

    # Base: tightest fit.  Small weight on the histogram bonus so that we only
    # break near-ties, never override a strictly better fit.
    return -(r) + 0.75 * bonus
# EVOLVE-BLOCK-END
