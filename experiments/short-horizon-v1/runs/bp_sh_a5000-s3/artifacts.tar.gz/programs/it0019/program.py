# EVOLVE-BLOCK-START
"""Tuned best-fit: prefer exact fills and avoid stranding tiny residuals."""
import numpy as np


def priority(item, bins):
    """Score every bin; item goes to highest score (first on ties).

    We compute the post-placement residual r = bins - item (all >= 0).
    Base behavior is best-fit: smaller r is better, so score = -r.
    Added rule: a residual that is a small but non-zero amount is likely to
    become unusable stranded space, so penalize residuals in a small band.
    Exact fill (r == 0) gets a strong bonus.
    """
    r = bins - item
    # Base: best-fit (smaller residual preferred).
    score = -r.astype(np.float64)

    # Bonus for exact fill.
    score += 2.0 * (r == 0)

    # Penalize small but nonzero residuals (stranded space), smoothly.
    # A residual in (0, ~10) is unlikely to fit a future item (mean item ~40,
    # but small items exist); penalize the sweet spot of stranding most.
    small = (r > 0) & (r < 12)
    score -= 1.5 * small.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
