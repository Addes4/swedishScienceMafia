# EVOLVE-BLOCK-START
"""Best-fit with a residual-utility correction driven by a running item histogram.

Pure best-fit minimizes the residual after placing the item.  The weakness is that
it happily creates tiny residuals that no future item can ever use, wasting that
space forever.  Here we keep the tight-fit preference but add a small correction
that rewards residuals which are likely to be usable later: we maintain a running
histogram of observed item sizes and score the post-placement residual by how
"fillable" it is (probability that some commonly seen item fits it), softly, so
that ties and near-ties are broken toward less fragmented leftover space.
"""
import numpy as np

# module state (reinitialised implicitly by the harness between streams is not
# guaranteed, so we keep everything self-contained and cheap)
_hist = np.zeros(101, dtype=np.float64)   # counts of observed sizes
_total = 0.0


def _fillability(res, hist, total):
    """Estimated probability that a future item fits in a bin with residual `res`.

    Uses the running empirical distribution; falls back to a smooth prior when
    little data is available.
    """
    r = int(res)
    if r <= 0:
        return 0.0
    if r >= 100:
        return 1.0
    if total < 20.0:
        # weak prior: roughly uniform-ish over 1..100, heavier tail allowed
        return min(1.0, r / 60.0)
    # empirical: fraction of past items <= r
    return float(hist[1:r + 1].sum()) / total


def priority(item, bins):
    """Rank bins: tight fit first, but slight preference for usable residuals."""
    global _total
    it = int(item)

    # residual after placing item into each candidate bin
    res = bins - it

    # size of the smallest item we have seen "often" (proxy for a typical filler)
    if _total >= 20.0:
        # cumulative distribution to find a low-percentile item size
        c = np.cumsum(_hist)
        # 25th percentile size (a common small filler)
        thr = np.searchsorted(c, 0.25 * _total)
        small = max(1, min(100, int(thr)))
    else:
        small = 1

    # base: prefer small residual (tightest fit).  Use a mild concave transform so
    # that the difference between residual 0 and 5 is large, but 60 vs 65 is not.
    base = -res.astype(np.float64)

    # correction: reward residuals that can still accept a common small item,
    # and penalise tiny residuals that are almost certainly dead space.
    fill = np.array([_fillability(r, _hist, _total) for r in res], dtype=np.float64)

    # also mildly reward residuals close to 0 when they are exactly 0 (perfect fit)
    perfect = (res == 0).astype(np.float64)

    score = base + 3.0 * fill + 2.0 * perfect

    # update running histogram AFTER scoring (we only see current item now)
    _hist[it] += 1.0
    _total += 1.0

    return score
# EVOLVE-BLOCK-END
