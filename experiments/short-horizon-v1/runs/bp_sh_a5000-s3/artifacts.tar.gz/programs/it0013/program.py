# EVOLVE-BLOCK-START
"""Best-fit with a light tie-break toward residuals that match recently seen item sizes."""
import numpy as np

# Running histogram of item sizes seen in the current stream (1..100).
_HIST = np.zeros(101, dtype=np.int64)
_TOTAL = 0


def priority(item, bins):
    """Rank bins: minimize post-placement residual, breaking near-ties toward fillable residuals."""
    global _TOTAL

    # Update running statistics with the current item before scoring.
    if 1 <= item <= 100:
        _HIST[item] += 1
        _TOTAL += 1

    residual = bins - item  # remaining capacity after placing the item

    # Base score: smaller residual is better.
    base = -residual.astype(np.float64)

    # Small bonus for residuals whose size has been observed as an item before
    # (so the leftover gap may be exactly fillable by a future item).
    if _TOTAL > 0:
        freq = _HIST[residual] if residual.max() <= 100 else _HIST[np.clip(residual, 0, 100)]
        bonus = freq.astype(np.float64) / _TOTAL
    else:
        bonus = np.zeros_like(base)

    # Bonus must not override a strictly smaller residual: keep it tiny.
    return base + 1e-6 * bonus
# EVOLVE-BLOCK-END
