# EVOLVE-BLOCK-START
"""Best fit with online distribution-aware residual scoring.

We prefer tight fits (small post-placement residual), but give a bonus when the
residual lands near a size that we have observed frequently in the stream so far.
Those leftover gaps are the ones most likely to be filled by a later item,
reducing stranded space without needing to know the item distribution in advance.
"""
import numpy as np

# Module-level histogram of observed item sizes (bucketed by 5).
_SIZE = 101
_HIST = np.zeros(_SIZE, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    global _COUNT
    # Update online statistics with the current item (past items only matter).
    _HIST[item] += 1.0
    _COUNT += 1.0

    residual = bins - item  # post-placement remaining capacity, >= 0
    resp = residual.astype(np.float64)

    # Base: prefer the tightest fit (small residual).
    base = -resp

    # Utility: reward residuals that match a frequently seen item size.
    # Smooth the histogram a bit so nearby sizes also count.
    freq = _HIST.copy()
    freq[1:] += _HIST[:-1] * 0.5
    freq[:-1] += _HIST[1:] * 0.5

    # For each bin, look up the frequency of its residual size (clipped to range).
    idx = np.clip(residual, 0, _SIZE - 1).astype(np.int64)
    utility = freq[idx] / (_COUNT + 1.0)

    return base + utility * 5.0
# EVOLVE-BLOCK-END
