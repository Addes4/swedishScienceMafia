# EVOLVE-BLOCK-START
"""Best-fit with online-learned residual matching.

Primary rule: strict best fit (minimize post-placement residual).
Tie-break / near-tie nudge: bins whose residual after placement equals a
currently-common item size are slightly preferred, so that later items can
fill them exactly. The empirical histogram is learned online from past items,
so no future information is used.
"""
import numpy as np

_item_hist = np.zeros(101, dtype=np.float64)
_n_seen = 0.0


def priority(item, bins):
    global _n_seen
    _n_seen += 1.0

    residual = bins - item   # >= 0 for all bins shown (item fits)

    # Base score: tightest fit -> highest score.
    score = -residual.astype(np.float64)

    # Online histogram of observed item sizes (fraction).
    _item_hist[item] += 1.0

    # Small bonus for residuals that equal a frequently seen item size,
    # making those bins fillable by a future item.
    freq = _item_hist / _n_seen
    # residual values are 0..100; look up frequency of that exact size
    idx = residual.astype(np.int64)
    np.clip(idx, 0, 100, out=idx)
    bonus = freq[idx]

    # Bonus magnitude kept well below a single capacity unit so best-fit
    # ordering is only broken for exact ties / within-unit residuals.
    score += 0.3 * bonus

    return score
# EVOLVE-BLOCK-END
