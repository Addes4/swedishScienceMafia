# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus and a small dead-leftover penalty."""
import numpy as np


_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0
_DIRTY = True
_MODAL_P = 0.1
_MIN_ITEM = 1


def _rebuild():
    global _DIRTY, _MODAL_P, _MIN_ITEM
    probs = _COUNTS / _TOTAL
    _MODAL_P = float(np.max(probs[1:])) if np.max(probs[1:]) > 0 else 0.1
    nz = np.nonzero(_COUNTS[1:])[0]
    _MIN_ITEM = int(nz[0] + 1) if len(nz) else 1
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    if _DIRTY:
        _rebuild()

    residual = bins.astype(np.float64) - float(item)

    # Backbone: strict best-fit ordering.
    score = -residual

    # Dominant exact-fit bonus.
    score += (residual == 0.0).astype(np.float64) * (50.0 + 20.0 * _MODAL_P)

    # Penalize tiny positive leftovers below the smallest observed item: such
    # bins are effectively stranded until a very small item arrives.
    dead = (residual > 0.0) & (residual < float(_MIN_ITEM))
    score -= dead.astype(np.float64) * (0.5 * _MODAL_P)

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
