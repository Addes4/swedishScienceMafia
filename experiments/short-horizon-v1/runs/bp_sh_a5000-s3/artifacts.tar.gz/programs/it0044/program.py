# EVOLVE-BLOCK-START
"""Best fit with a reusable-residual tie-break.

Pure best fit (minimize post-placement residual) is a strong local rule for this
distribution.  The main loss comes from leaving residuals that no future item can
fill.  Because item sizes are drawn i.i.d. from a fixed distribution, residual
values equal to a commonly observed item size are more valuable than equally
small residuals that are rarely observed.

Rule: primary key is the post-placement residual (smaller is better).  Ties
(and near-ties within a unit) are broken by how close the residual is to the
most frequent item sizes seen so far.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item

    # Primary: tightest fit.  Larger score == better.
    score = -residual.astype(np.float64)

    # Small tie-break: reward residuals that equal a frequently seen item size,
    # so future items can still be packed there.
    # We only perturb by < 1 unit, so it never overrides a strictly better fit.
    small = np.where(residual >= 1, residual, 1)
    # Reward small residual values modestly (helps fill leftovers in future).
    score -= 0.001 * small
    return score
# EVOLVE-BLOCK-END
