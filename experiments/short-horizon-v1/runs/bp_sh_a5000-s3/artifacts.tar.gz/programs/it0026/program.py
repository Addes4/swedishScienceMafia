# EVOLVE-BLOCK-START
"""Best-fit with a learned residual-target tie-break.

Core policy: best fit (smallest post-placement residual). Among placements whose residual is
within a small window of the best residual, prefer residuals that match item sizes seen often
in the stream (so a future item can fill the leftover) or an exact fill (residual 0).
"""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (ties to first)."""
    # Update running histogram of observed item sizes.
    _state["hist"][item] += 1.0
    _state["count"] += 1

    residual = bins - item  # post-placement residual, >= 0 for feasible bins

    # Best fit: smaller residual is better.
    base = -residual.astype(np.float64)

    # Learned target preference: fraction of past items equal to this residual value.
    hist = _state["hist"]
    total = _state["count"]
    if total > 0:
        frac = hist[residual] / total
    else:
        frac = np.zeros_like(base)

    # Exact fill is always good.
    frac = frac + np.where(residual == 0, 1.0, 0.0)

    # Small bonus only breaks near-ties; magnitude stays well below 1 unit of residual.
    return base + 0.4 * frac
# EVOLVE-BLOCK-END
