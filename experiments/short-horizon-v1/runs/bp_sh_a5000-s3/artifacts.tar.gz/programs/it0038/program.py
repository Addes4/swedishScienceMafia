# EVOLVE-BLOCK-START
"""Distribution-aware best fit: prefer tight fits but reward residuals that are
either nearly-closed (small leftover) or large enough to hold a typical item."""
import numpy as np

_state = {"n": 0, "mean": 40.0}

_size = 100.0


def priority(item, bins):
    # Update running estimate of item size (residuals that matter).
    _state["n"] += 1
    m = _state["mean"]
    m += (item - m) / min(_state["n"], 200.0)
    _state["mean"] = m

    residual = bins - item  # >= 0 for feasible bins

    # Reward: bins that become very full (residual near 0) are best.
    # Secondary: residuals around the typical item size are also valuable
    # because they can host a future average item cleanly.
    target = m
    near_full = -residual.astype(np.float64)
    # bump for residuals close to a typical remaining item size
    gap = np.abs(residual.astype(np.float64) - target)
    bonus = -0.5 * gap
    return near_full + bonus
# EVOLVE-BLOCK-END
