# EVOLVE-BLOCK-START
"""Best fit with a residual-utility guard.

Pure best-fit leaves many mid-sized stranded gaps. For a Weibull-shaped item
distribution (mean ~40) it is more valuable to either fill a bin perfectly
(residual 0) or leave a residual that can still hold a typical future item.
We keep a mild best-fit term so packing stays tight, but add a utility bonus
that rewards perfect fills and residuals at/above a reusable size threshold.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # post-placement remaining capacity, >= 0
    residual = residual.astype(np.float64)

    # Dominant term: prefer the tightest fit (small residual).
    base = -residual

    # Utility bonus:
    #  - perfect fill (residual == 0) is the best possible outcome,
    #  - otherwise residual should remain large enough to hold a typical
    #    future item (~40), not strand a mid-sized useless gap.
    threshold = 40.0
    # Normalized "reusability": 1 for residual==0 (perfect) or residual>=threshold,
    # decaying for mid-sized residuals.
    util = np.where(
        residual == 0.0,
        1.0,
        np.where(
            residual >= threshold,
            1.0,
            residual / threshold,  # mid gaps get less credit the smaller they are
        ),
    )

    return base + util
# EVOLVE-BLOCK-END
