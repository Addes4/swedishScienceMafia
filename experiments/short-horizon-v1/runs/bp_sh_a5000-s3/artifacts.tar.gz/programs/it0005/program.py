# EVOLVE-BLOCK-START
"""Residual-target best fit.

Classic best fit minimizes the leftover capacity after placing the item, which
tends to strand tiny unusable slivers.  Since item sizes follow a fixed
distribution (Weibull-shaped, mean ~40), a small non-zero leftover is often
worse than a larger leftover that a future item can still fit.  Here we score
each bin by how close the resulting residual is to a fixed target waste
value, mildly modulated by the residual itself, then pick the best.
"""
import numpy as np

_TARGET = 8.0  # preferred leftover capacity after placement
_W = 0.15      # gentle tie-break toward smaller residuals


def priority(item, bins):
    residual = bins - item
    # Higher score = better.  Prefer residuals near _TARGET, then smaller.
    return -np.abs(residual - _TARGET) - _W * residual
# EVOLVE-BLOCK-END
