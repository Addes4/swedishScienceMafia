# EVOLVE-BLOCK-START
"""Best-fit with a small bonus for leaving a residual that equals a common item size,
so the leftover space is more likely to be reusable by a future item."""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for all bins shown
    # Primary: best fit (smallest residual wins -> highest score).
    score = -residual.astype(np.float64)
    # Tiny secondary bonus: residuals that exactly match a "reusable" size are slightly better.
    # Reusable sizes are those small enough to likely appear again (empirically ~around 20-40),
    # but we avoid over-tuning by only nudging, not overriding best-fit.
    reusable = ((residual >= 1) & (residual <= 40)).astype(np.float64)
    score += 0.25 * reusable
    return score
