# EVOLVE-BLOCK-START
"""Best-fit restricted to already-used bins when a tight fit exists."""
import numpy as np

_state = {"seen": False, "counts": None}


def _common_sizes(counts, item, total):
    """Return a set of item sizes that occur reasonably often (for residual matching)."""
    if total <= 0:
        return set()
    thresh = max(1, total // 200)
    return {s for s, c in counts.items() if c >= thresh and s != item}


def priority(item, bins):
    counts = _state["counts"]
    total = _state.get("total", 0)

    # Update simple frequency stats for past items.
    if counts is None:
        counts = {}
        _state["counts"] = counts
    counts[item] = counts.get(item, 0) + 1
    _state["total"] = total + 1

    residual = bins - item  # >= 0 for all shown bins

    # Tighter fit = higher priority. Strict best fit ordering.
    score = -residual.astype(np.float64)

    # Identify unused bins (remaining capacity 100).
    used = bins < 100
    if used.any():
        # Common sizes we might like to leave as residual (bias existing bins).
        common = _common_sizes(counts, item, _state["total"])
        if common:
            cmask = np.zeros_like(score)
            for s in common:
                cmask += (residual == s)
            # Small bonus for leaving a reusable residual in an existing bin.
            score += 0.5 * cmask * used

        # Very small nudge to prefer existing bins over empty ones when fits are close.
        best = score.max()
        near = score >= best - 1e-9
        if near.any():
            score[near & ~used] -= 1e-6

    return score
# EVOLVE-BLOCK-END
