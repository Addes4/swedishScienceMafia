# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit with an expected-closability value."""
import numpy as np


_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

# P[s] = probability-like weight that residual s can be exactly filled by a
# small multiset (1..3) of future items drawn from the observed distribution.
_CLOSE = np.zeros(101, dtype=np.float64)
_BASE = np.zeros(101, dtype=np.float64)
_DIRTY = True


def _smooth(arr, sigma=1.0):
    if sigma <= 0:
        return arr
    k = int(3 * sigma)
    xs = np.arange(-k, k + 1, dtype=np.float64)
    w = np.exp(-0.5 * (xs / sigma) ** 2)
    w /= w.sum()
    padded = np.concatenate([np.full(k, arr[0], dtype=np.float64), arr,
                             np.full(k, arr[-1], dtype=np.float64)])
    return np.convolve(padded, w, mode='valid')


def _rebuild():
    global _CLOSE, _BASE, _DIRTY
    probs = _COUNTS / _TOTAL

    # Restrict to support that actually appears (ignore the unit prior).
    top = np.argsort(probs)[::-1][:12]
    top = [int(t) for t in top if probs[t] > probs.mean()]

    close = np.zeros(101, dtype=np.float64)

    # 1-item exact fill
    for a in top:
        if 0 < a <= 100:
            close[a] += probs[a]
    # 2-item exact fill
    for a in top:
        if a <= 0 or a > 100:
            continue
        pa = probs[a]
        for b in top:
            s = a + b
            if s <= 100:
                close[s] += pa * probs[b]
    # 3-item exact fill
    for a in top:
        if a <= 0 or a > 100:
            continue
        pa = probs[a]
        for b in top:
            w = pa * probs[b]
            for c in top:
                t = a + b + c
                if t <= 100:
                    close[t] += w * probs[c]

    # A closed bin saves a whole bin; probability is capped at 1.
    close = np.clip(close, 0.0, 1.0)

    # Base value = expected waste reduction (best-fit prior). Smaller residual
    # is better; exponential decay approximates the value of tight packing.
    base = np.exp(-0.05 * np.arange(101, dtype=np.float64))

    _CLOSE = _smooth(close, sigma=0.6)
    _BASE = _smooth(base, sigma=0.6)
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    if _DIRTY:
        _rebuild()

    residual = (bins - item).astype(np.float64)
    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    # Primary: expected benefit of leaving this residual (closability).
    score = 8.0 * _CLOSE[ri]

    # Secondary: classic best-fit tiebreak (tighter is mildly better).
    score += 1.0 * _BASE[ri]

    # Decisive exact-fit bonus so we always close when possible.
    score += (residual == 0.0).astype(np.float64) * 4.0

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END

