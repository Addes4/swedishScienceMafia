# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit with reachable-residual bonus.

Score each bin by an estimate of how valuable its post-placement residual is.
A residual is valuable if it is likely to be exactly filled by a later item,
or more generally if it can be completed by a small combination of likely
item sizes (e.g. 40+60). We learn the item distribution online and maintain
a reachability set over residuals 0..100 built from common observed sizes.
"""
import numpy as np


# Online histogram of observed item sizes.
# Start from a weak prior shaped like the known Weibull-like distribution
# (mean ~40), so early-stream estimates are already informative instead of
# being dominated by the Laplace-smoothed uniform prior.
_COUNTS = None
_TOTAL = 0.0

# Decay factor: keeps the histogram responsive to the true distribution
# while still smoothing. 1.0 = plain cumulative histogram.
_DECAY = 0.9995

# Reachability/utility cache keyed by rounded residual -> value.
_UTIL = np.zeros(101, dtype=np.float64)
_DIRTY = True


def _make_prior():
    """Weak Weibull-like prior over sizes 1..100 with mean ~40."""
    x = np.arange(101, dtype=np.float64)
    # Weibull shape k~1.8, scale ~45 gives mean ~40 and a long right tail.
    k = 1.8
    lam = 45.0
    pdf = (k / lam) * (x / lam) ** (k - 1.0) * np.exp(-((x / lam) ** k))
    pdf[0] = 0.0
    pdf = np.clip(pdf, 0.0, None)
    s = pdf.sum()
    if s <= 0:
        pdf = np.ones(101, dtype=np.float64)
        pdf[0] = 0.0
        s = pdf.sum()
    pdf /= s
    # Weak prior mass (equivalent to ~50 pseudo-observations).
    prior = pdf * 50.0
    prior[0] = 0.0
    return prior


def _rebuild_util():
    """Compute utility of each residual r in 0..100.

    Base value = probability that a single future item exactly equals r.
    Additional value = whether r is expressible as a sum of 2 (or 3) likely
    items, using the most probable sizes.
    """
    global _UTIL, _DIRTY
    probs = _COUNTS / _TOTAL

    # Most likely item sizes (top few) for combination building.
    top = np.argsort(probs)[::-1][:12]
    top = [int(t) for t in top if probs[t] > probs.mean()]

    util = probs.copy()

    # Two-item sums.
    for a in top:
        if a <= 0 or a > 100:
            continue
        for b in top:
            s = a + b
            if 0 < s <= 100:
                util[s] += 0.5 * probs[a] * probs[b]
    # Three-item sums (small contribution).
    for a in top:
        for b in top:
            for c in top:
                s = a + b + c
                if 0 < s <= 100:
                    util[s] += 0.15 * probs[a] * probs[b] * probs[c]

    _UTIL = util
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    if _COUNTS is None:
        _COUNTS = _make_prior()
        _TOTAL = float(_COUNTS.sum())

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild_util()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    # Value of leaving this residual (higher = better).
    val = _UTIL[ri]

    # Log-scale for stability, plus strong perfect-fill bonus.
    score = np.log(val + 1e-9)
    score += (residual == 0.0).astype(np.float64) * 5.0

    # Mild best-fit pressure to break ties sensibly.
    score -= residual * 0.005

    # Update online histogram with decay (discounted counts) for faster
    # adaptation to the true size distribution.
    _COUNTS *= _DECAY
    _COUNTS[item] += 1.0
    _TOTAL = float(_COUNTS.sum())
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
