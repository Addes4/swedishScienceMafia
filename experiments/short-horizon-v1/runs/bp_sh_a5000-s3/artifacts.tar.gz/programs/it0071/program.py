# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit with exact-fill probability bonus.

Score each bin by an estimate of how likely its post-placement residual can be
exactly filled by a later item, blended with mild best-fit pressure.

The key signal: residual r is valuable iff P(next item == r) is high. We learn
P online from observed item sizes via a smoothed histogram, so the rule adapts
to the true item distribution (Weibull-ish, mean ~40) rather than a fixed
harmonic ladder. Perfect fill (r=0) always gets a strong bonus.
"""
import numpy as np


# Histogram over residuals 0..100, smoothed counts of observed item sizes.
_COUNTS = np.ones(101, dtype=np.float64)  # Laplace smoothing
_TOTAL = 101.0


def priority(item, bins):
    global _COUNTS, _TOTAL

    residual = (bins - item).astype(np.float64)  # post-placement, >= 0

    # Learned probability that a future item exactly equals each residual r.
    # r is integer-valued here (items and capacities are integers).
    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)
    p_fill = _COUNTS[ri] / _TOTAL  # P(item size == r)

    # Log-probability is a better scaled "value of leaving residual r".
    # Perfect fill always highly valuable.
    logp = np.log(p_fill)

    # Reward exact perfect fills strongly (independent of estimate noise).
    perfect = (residual == 0.0).astype(np.float64) * 5.0

    # Mild best-fit pressure so ordering stays sane between equal-prob residuals.
    mild_best_fit = -residual * 0.005

    score = logp * 1.0 + perfect + mild_best_fit

    # Update the histogram with the observed item (online learning).
    _COUNTS[item] += 1.0
    _TOTAL += 1.0

    return score
# EVOLVE-BLOCK-END
