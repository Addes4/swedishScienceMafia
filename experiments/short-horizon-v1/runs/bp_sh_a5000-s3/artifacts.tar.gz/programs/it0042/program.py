# EVOLVE-BLOCK-START
"""Refined best fit: prefer tight fits, break near-ties toward fuller-used bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize post-placement residual (classic best fit).
    # Secondary: among near-equal residuals, prefer the bin that was already
    # more loaded (smaller pre-placement capacity), keeping larger bins open.
    return -(residual.astype(np.float64) * 1.0e6 + bins.astype(np.float64))
# EVOLVE-BLOCK-END
