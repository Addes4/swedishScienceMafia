# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware tie-break among near-optimal bins."""
import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),
    "n": 0,
}


def priority(item, bins):
    """Rank bins: prefer tightest fit, break near-ties toward reusable residuals."""
    # Update running histogram of observed item sizes (state persists per stream).
    _state["hist"][item] += 1.0
    _state["n"] += 1

    residual = bins - item  # remaining capacity after placing this item

    # Tightest fit has the smallest residual.
    best = residual.min()

    # Tolerance: treat residuals within `tol` of best as near-ties.
    tol = 2
    mask = residual <= best + tol

    if mask.sum() <= 1:
        return -residual

    # Among near-tie bins, prefer the residual that is most "fillable":
    # how often have we seen an item that exactly matches this residual?
    hist = _state["hist"]
    # fillability: counts of exact matching items, with a mild prior
    fill = np.zeros_like(residual, dtype=np.float64)
    # only residuals in [0, 100] are meaningful
    idx = np.clip(residual, 0, 100).astype(np.int64)
    fill = hist[idx] + 0.01 * (residual >= 1)  # tiny bonus for leaving some hole

    score = fill.copy()
    # Outside the near-tie mask, strongly demote via a large negative shift.
    score = np.where(mask, score, score - 1e6)
    return score
# EVOLVE-BLOCK-END
