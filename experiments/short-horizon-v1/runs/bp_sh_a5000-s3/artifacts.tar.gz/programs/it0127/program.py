# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit using subset-sum closability probabilities."""
import numpy as np


_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0
_DIRTY = True

# Precomputed lookups indexed by residual 0..100
_CLOSE1 = np.zeros(101, dtype=np.float64)   # P(exact close by a single item)
_CLOSE2 = np.zeros(101, dtype=np.float64)   # P(exact close by sum of two items)
_CLOSE3 = np.zeros(101, dtype=np.float64)   # P(exact close by sum of three items)


def _rebuild():
    global _CLOSE1, _CLOSE2, _CLOSE3, _DIRTY
    p = _COUNTS / _TOTAL          # p[s] = prob a future item has size s
    p[0] = 0.0
    p /= p.sum()

    c1 = p.copy()

    # two-item sum distribution
    c2 = np.zeros(101, dtype=np.float64)
    for a in range(1, 101):
        if p[a] == 0.0:
            continue
        hi = 100 - a
        if hi <= 0:
            continue
        c2[a + 1:101] += p[a] * p[1:hi + 1]

    # three-item sum distribution via convolution of c1 and c2
    c3 = np.zeros(101, dtype=np.float64)
    for a in range(1, 101):
        if c1[a] == 0.0:
            continue
        hi = 100 - a
        if hi <= 0:
            continue
        c3[a + 1:101] += c1[a] * c2[1:hi + 1]

    _CLOSE1 = c1
    _CLOSE2 = c2
    _CLOSE3 = c3
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    if _DIRTY:
        _rebuild()

    residual = bins - item
    ri = np.clip(residual.astype(np.int64), 0, 100)

    exact = (residual == 0)

    # Closability: probability the leftover can be exactly filled by 1-3 items.
    close = _CLOSE1[ri] + _CLOSE2[ri] + _CLOSE3[ri]
    close = 1.0 - np.exp(-close)      # squash, always >=0

    # Best-fit preference: smaller residual is generally better.
    bestfit = -residual.astype(np.float64) / 100.0

    score = 1.6 * close + 0.5 * bestfit
    score += exact.astype(np.float64) * 8.0

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
