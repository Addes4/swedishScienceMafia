# EVOLVE-BLOCK-START
"""Best fit with a residual-utility reshaping.

Pure best fit minimizes the post-placement residual, which strands medium-sized
gaps that future items cannot use. Instead, score each bin by how "useful" the
resulting residual is: residuals that are either tiny (near-perfect fill) or
large enough to accept a typical next item (mean item ~40) are good; medium
residuals just below a typical item are penalized. This is a smooth,
distribution-free reshaping of best fit.
"""
import numpy as np


def priority(item, bins):
    residual = (bins - item).astype(np.float64)  # >= 0

    # Best-fit backbone: tightest fit is best.
    base = -residual

    # Utility reshaping: reward residual when it can hold a typical item again.
    # A residual r is "useful" if r is small (near 0) or r is at least the
    # typical item size (~40). Penalize the awkward middle band (1..39).
    # Smooth quadratic bump that is zero at r=0, peaks around r=25, back to
    # zero at r=40: u = r*(40-r) for 0<=r<=40, else 0.
    bump = np.where(residual < 40.0, residual * (40.0 - residual), 0.0)

    # Subtract the bump so awkward medium residuals are less attractive, while
    # keeping best-fit as the dominant term.
    return base - 0.05 * bump
# EVOLVE-BLOCK-END

