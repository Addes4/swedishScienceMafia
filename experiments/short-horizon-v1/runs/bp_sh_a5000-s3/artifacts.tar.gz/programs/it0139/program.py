# EVOLVE-BLOCK-START
"""Best-fit with a learned per-residual 'soon-closable' value estimate."""
import numpy as np


# --- observed item histogram ------------------------------------------------
_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

# --- learned residual value ------------------------------------------------
# For each integer residual r (0..100), _FILL[r] ~ smoothed probability that a
# bin whose leftover equals r gets exactly closed by the next single item.
_FILL = np.zeros(101, dtype=np.float64)
_DIRTY = True


def _smooth(arr, sigma=1.5):
    k = int(3 * sigma)
    xs = np.arange(-k, k + 1, dtype=np.float64)
    w = np.exp(-0.5 * (xs / sigma) ** 2)
    w /= w.sum()
    padded = np.concatenate([np.full(k, arr[0], dtype=np.float64), arr,
                             np.full(k, arr[-1], dtype=np.float64)])
    return np.convolve(padded, w, mode='valid')


def _rebuild():
    """Estimate, per integer residual, how likely a future item closes it."""
    global _FILL, _DIRTY
    m = _COUNTS / _TOTAL
    # one-item closure probability: P(next item == r) for residual r
    fill = m.copy()
    # plus a modest contribution from two-item closures (r = a + b)
    top = np.argsort(m)[::-1][:10]
    top = [int(t) for t in top if 0 < t <= 100 and m[t] > m.mean()]
    for a in top:
        for b in top:
            s = a + b
            if 0 < s <= 100:
                fill[s] += m[a] * m[b]
    _FILL = _smooth(fill)
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    if _DIRTY:
        _rebuild()

    residual = (bins - item).astype(np.float64)
    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    m = _COUNTS / _TOTAL
    modal_p = float(m[1:].max())

    # Scale that makes the exact-fit bonus dominate but bounded.
    scale = 8.0 + 6.0 * modal_p

    score = np.log(_FILL[ri] + 1e-9)

    # Dominant exact-fit bonus: closing a bin right now is the best outcome.
    score += (residual == 0.0).astype(np.float64) * scale

    # Monotone best-fit tie-break: prefer the smallest positive leftover.
    score += -0.02 * residual

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END

