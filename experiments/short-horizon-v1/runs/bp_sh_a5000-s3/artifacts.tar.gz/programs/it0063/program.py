# EVOLVE-BLOCK-START
"""Best fit with an online-estimated residual floor.

Pure best fit is already strong at 0.959. Small fixed-ladder tie-breaks barely
move the needle and risk overfitting. Here we keep best-fit as the dominant
term and only add a tiny, distribution-aware nudge: maintain an online estimate
of the typical item size, and give a small bonus to placements that keep the
residual at or above roughly half of that typical size (so the leftover bin
stays useful for a future item), while penalizing placements that strand a
useless tiny gap. The bonus magnitude is kept far below 1 so it only breaks
near-ties and never overrides best fit.
"""
import numpy as np

# Online state of past item sizes (mean and count), reset per stream is handled
# by the harness re-importing / restarting the module for each stream.
_state = {"n": 0.0, "mean": 40.0}


def priority(item, bins):
    # Update online statistics of observed item sizes.
    _state["n"] += 1.0
    a = 1.0 / _state["n"]
    _state["mean"] += a * (float(item) - _state["mean"])
    typical = _state["mean"]

    residual = bins - item  # post-placement remaining capacity, >= 0 (int64)

    # Dominant term: best fit (prefer smallest residual).
    base = -residual.astype(np.float64)

    # Residual floor: a leftover bin is "useful" if it can still hold a
    # substantial fraction of a typical item. Bonus for staying at/above it,
    # small penalty for stranding a tiny gap (below ~quarter typical).
    floor = 0.5 * typical
    tiny = 0.25 * typical
    r = residual.astype(np.float64)
    nudge = np.where(r >= floor, 0.3,
                     np.where(r <= tiny, -0.3, 0.0))
    # Perfect fill is always best: give exact-fit a clear but small bonus.
    nudge = np.where(residual == 0, 1.0, nudge)

    return base + nudge
# EVOLVE-BLOCK-END
