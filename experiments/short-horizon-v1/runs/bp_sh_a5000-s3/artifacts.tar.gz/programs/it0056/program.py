# EVOLVE-BLOCK-START
"""Best fit variant: prefer tight fits that do not strand a tiny residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Penalize placing into a bin that leaves a tiny, likely-unusable residual.
    # A residual of 0 is perfect; residuals >= item_min (1) are usable.
    # Score: primarily best-fit (smallest residual), but push tiny nonzero
    # residuals below zero-residual and below usable residuals.
    wasted = (residual > 0) & (residual < 40)
    score = -residual.astype(np.float64)
    score[wasted] -= 0.5
    return score
# EVOLVE-BLOCK-END
