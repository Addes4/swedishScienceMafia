# EVOLVE-BLOCK-START
"""Best fit with a secondary preference for already-fuller bins.

Primary rule: minimize the post-placement residual (tightest fit).
Tie-break: among bins with equal residual, prefer the bin that had the least
remaining capacity before placement (i.e. the more loaded bin), which gently
consolidates load and avoids opening fresh bins unnecessarily.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Tiny secondary term: prefer fuller (smaller remaining) bins on residual ties.
    return -residual * 1000 - bins
# EVOLVE-BLOCK-END

