# EVOLVE-BLOCK-START
"""Best fit with a running minimum-size correction for unusable slivers."""
import numpy as np

# Module state: smallest item size seen so far in the current stream.
_min_seen = [101]


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item < _min_seen[0]:
        _min_seen[0] = item

    residual = bins - item  # post-placement remaining capacity, >= 0 for shown bins
    m = _min_seen[0]

    # Base: prefer the tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Penalize residuals that are small but still cannot hold the smallest item
    # seen so far: those slivers are effectively wasted, so avoid creating them
    # when a nearly-equally-tight alternative exists.
    unusable = (residual > 0) & (residual < m)
    score -= 1e-6 * unusable.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
