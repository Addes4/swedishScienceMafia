# EVOLVE-BLOCK-START
"""Worst-fit placement.

For Weibull-shaped item sizes with mean ~40, best-fit tends to strand small
unusable residuals, wasting capacity. Worst-fit (place the item into the bin
with the largest remaining capacity) keeps those bins open and available for
future items, which typically yields fewer bins. We add a mild preference for
larger post-placement residuals and break ties by index order.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # post-placement remaining capacity, >= 0
    # Prefer the bin that stays as empty as possible after placement.
    return residual.astype(np.float64)
# EVOLVE-BLOCK-END

