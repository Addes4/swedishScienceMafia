# EVOLVE-BLOCK-START
"""Best-fit variants inspired by harmonic/guide packing for a Weibull-shaped item stream."""
import numpy as np

# Harmonic-like residual targets: leave a residual that a common item can still fill.
# We approximate the "guide" idea by preferring bins whose post-placement residual is
# close to one of these target levels, with strong emphasis on tight fits.
_TARGETS = np.array([0.0, 25.0, 33.0, 50.0, 20.0, 10.0], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base: prefer tight fits (small residual).
    base = -residual.astype(np.float64)

    # Guide bonus: reward residuals near a target level (small ones weighted more).
    d = np.abs(residual[:, None] - _TARGETS[None, :])
    closeness = np.exp(-d / 8.0)
    weights = np.array([4.0, 1.0, 1.0, 0.5, 0.8, 0.6], dtype=np.float64)
    bonus = closeness @ weights

    # Slight preference for emptier bins is usually harmful, so keep it minimal:
    # only lightly discourage leaving a tiny unusable residual.
    scale = 1.0
    return base * scale + bonus
# EVOLVE-BLOCK-END
