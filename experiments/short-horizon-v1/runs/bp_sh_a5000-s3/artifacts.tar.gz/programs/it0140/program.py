# EVOLVE-BLOCK-START
"""Robust best-fit: monotone preference for smaller leftover, exact fits dominates."""
import numpy as np


def priority(item, bins):
    residual = (bins - item).astype(np.float64)

    # Strict monotone best-fit ordering: smaller leftover is always better.
    # Smooth decreasing function so near-ties stay close but ordering is strict.
    score = -residual

    # Dominant bonus for exactly closing a bin now.
    score += (residual == 0.0).astype(np.float64) * 1000.0

    return score
# EVOLVE-BLOCK-END
