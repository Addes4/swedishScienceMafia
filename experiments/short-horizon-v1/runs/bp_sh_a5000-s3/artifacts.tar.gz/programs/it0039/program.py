# EVOLVE-BLOCK-START
"""Almost-best-fit: behave like best fit, but occasionally accept a near-tight bin
chosen by a deterministic rotating counter to escape best-fit's fragmentation pattern."""
import numpy as np

_state = {"tick": 0, "window": 0}


def priority(item, bins):
    residuals = bins - item
    # best (smallest) residual; residuals are >= 0 since bins shown all fit the item
    best = residuals.min()

    _state["tick"] += 1
    # vary the tolerance window over time to avoid a fixed pathological pattern
    tol = _state["window"]
    if _state["tick"] % 7 == 0:
        _state["window"] = (_state["window"] + 1) % 4

    near = residuals <= best + tol
    if tol == 0 or near.sum() == 1:
        # pure best fit: highest score = smallest residual
        return -(residuals.astype(np.float64))

    # among near-best bins, rotate the choice deterministically by tick count
    idx = np.flatnonzero(near)
    chosen = idx[_state["tick"] % idx.size]
    out = np.full(bins.shape, -1e9, dtype=np.float64)
    out[chosen] = 0.0
    # make sure the strict best is still preferred if not in the rotated pick set
    out += -(residuals.astype(np.float64)) * 1e-6
    return out
# EVOLVE-BLOCK-END

