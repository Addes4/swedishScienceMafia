# EVOLVE-BLOCK-START
"""Best fit with a penalty for residuals likely to become stranded small gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer tight fits (small residual); penalize residuals in the "stranded" band.
    # The distribution is Weibull-shaped with mean ~40; residuals much smaller than
    # the mean may never be usable. Add a small penalty for residuals in (0, T).
    T = 15
    stranded = (residual > 0) & (residual < T)
    return -residual - 2.0 * stranded
# EVOLVE-BLOCK-END
