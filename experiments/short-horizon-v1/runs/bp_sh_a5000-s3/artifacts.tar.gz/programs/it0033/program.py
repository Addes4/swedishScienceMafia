# EVOLVE-BLOCK-START
"""Best fit with a small-item pairing bonus based on a running size histogram."""
import numpy as np


_state = {"hist": np.zeros(101, dtype=np.float64), "count": 0.0, "small": 20.0}


def priority(item, bins):
    """Rank feasible bins; item goes to the highest score (first on ties).

    Core is best-fit (tightest residual), plus a mild bonus for placements whose
    post-placement residual is large enough to still take a typical small item.
    """
    # Update running histogram of observed item sizes.
    _state["hist"][item] += 1.0
    _state["count"] += 1.0

    # Estimate a "typical small item" size: 25th percentile of the observed
    # distribution (falls back to 20 initially).
    n = _state["count"]
    if n >= 20.0:
        cdf = np.cumsum(_state["hist"]) / n
        idx = int(np.searchsorted(cdf, 0.25))
        small = float(max(1, min(100, idx)))
    else:
        small = _state["small"]
    _state["small"] = small

    residual = bins - item  # post-placement residual for each bin

    # Base: prefer small residual (best fit).  Bonus: residual at least ~small,
    # so the bin can still absorb a typical small item afterwards.
    bonus = np.where(residual >= small, small * 0.5, 0.0)

    return bonus - residual
# EVOLVE-BLOCK-END
