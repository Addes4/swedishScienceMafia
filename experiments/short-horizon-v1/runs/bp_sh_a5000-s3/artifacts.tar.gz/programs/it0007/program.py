# EVOLVE-BLOCK-START
"""Best fit with a mild harmonic preference for residuals near the item mean."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest wins, ties go to the first bin.

    Base rule: best fit (minimize residual after placement = bins - item).
    Bonus: slightly prefer bins whose residual after placement is close to a
    typical future item size (~40), which tends to fill such gaps exactly.
    """
    residual = bins - item
    # Mild harmonic term: prefer residuals near the item distribution mean.
    # Smaller residual is generally better, so weight the proximity bonus
    # much less than the residual-ordering term.
    bonus = -0.05 * np.abs(residual - 40)
    return -residual.astype(np.float64) + bonus
# EVOLVE-BLOCK-END

