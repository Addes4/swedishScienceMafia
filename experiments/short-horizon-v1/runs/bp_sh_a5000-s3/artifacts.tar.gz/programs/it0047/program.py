# EVOLVE-BLOCK-START
"""Best fit with anti-sliver guard: avoid leaving unusable tiny residuals."""
import numpy as np

_MIN_ITEM = 5  # roughly the smallest item size we expect to matter


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # post-placement remaining capacity

    # Base: prefer the tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Anti-sliver guard: penalize placements that leave a residual in [1, _MIN_ITEM-1],
    # which is too small to be usable by almost any future item. Such bins become wasted.
    sliver = (residual >= 1) & (residual < _MIN_ITEM)
    score -= sliver * 200.0

    # Strongly reward exact fills (residual 0) so tidy packing is kept.
    exact = residual == 0
    score += exact * 50.0

    return score
# EVOLVE-BLOCK-END
