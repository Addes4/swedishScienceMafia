# EVOLVE-BLOCK-START
"""Distribution-aware best fit.

Pure best-fit (smallest post-placement residual) is already strong for Weibull-ish
sizes. The main loss comes from stranding residuals that no future item can fill.
We keep best-fit as the dominant term but add a moderate tie-break bonus that
prefers residuals matching frequently-seen item sizes, tracked via an online
histogram. This keeps ordering almost identical to best-fit while nudging ties
toward residuals that are themselves fillable.
"""
import numpy as np

# Online histogram over item sizes (1..100), shared across calls per stream.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    global _COUNT
    # Update histogram (state persists within a stream; reset externally is not
    # required because we normalize by total count).
    _HIST[item] += 1.0
    _COUNT += 1.0

    residual = bins - item  # post-placement remaining capacity, >= 0

    # Dominant term: best fit (prefer small residual).
    base = -residual.astype(np.float64)

    # Tie-break: reward residuals that match a frequently observed item size.
    # freq[r] = fraction of past items of size r (and small multiples thereof).
    freq = _HIST / _COUNT

    # A residual of r is "useful" if some item of size ~r arrives; also reward
    # residuals that are exact sums of two common small items (captured by
    # convolving freq with itself coarsely). To keep it cheap, use freq[r] plus
    # freq[r - 40] style lookups via a small set of candidate anchors.
    useful = freq[residual].copy()

    # Also value residuals right at a perfect fill.
    useful[residual == 0] += 1.0

    return base + 0.3 * useful
# EVOLVE-BLOCK-END
