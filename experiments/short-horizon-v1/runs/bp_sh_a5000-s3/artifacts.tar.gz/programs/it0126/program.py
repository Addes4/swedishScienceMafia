# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit with closedness and bin-aging preference."""
import numpy as np


_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

_UTIL = np.zeros(101, dtype=np.float64)
_REACH = np.zeros(101, dtype=np.float64)
_DIRTY = True

# aging bookkeeping: map from residual-key at last touch to time, per call we
# only have the residual array (copies of bins), so we approximate aging by a
# per-residual "last seen" index. A bin's identity is not exposed, only its
# residual, so we track last-touch time keyed by exact residual value.
_AGE = np.zeros(101, dtype=np.float64)
_CLOCK = 0.0


def _smooth(arr, sigma=1.0):
    k = int(3 * sigma)
    xs = np.arange(-k, k + 1, dtype=np.float64)
    w = np.exp(-0.5 * (xs / sigma) ** 2)
    w /= w.sum()
    padded = np.concatenate([np.full(k, arr[0], dtype=np.float64), arr,
                             np.full(k, arr[-1], dtype=np.float64)])
    return np.convolve(padded, w, mode='valid')


def _rebuild_util():
    global _UTIL, _DIRTY, _REACH
    probs = _COUNTS / _TOTAL

    top = np.argsort(probs)[::-1][:14]
    top = [int(t) for t in top if probs[t] > probs.mean()]

    util = probs.copy()

    reach = np.zeros(101, dtype=np.float64)
    reach[0] = 1.0
    for s in top:
        if 0 < s <= 100:
            reach[s] = max(reach[s], probs[s])

    for a in top:
        if a <= 0 or a > 100:
            continue
        pa = probs[a]
        for b in top:
            s = a + b
            if 0 < s <= 100:
                w = pa * probs[b]
                util[s] += w
                reach[s] = max(reach[s], w)
            for c in top:
                t = a + b + c
                if 0 < t <= 100:
                    reach[t] = max(reach[t], pa * probs[b] * probs[c])

    _UTIL = _smooth(util)
    _REACH = _smooth(reach)
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY, _CLOCK

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild_util()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    val = _UTIL[ri]
    score = np.log(val + 1e-9)

    score += 0.15 * _REACH[ri]

    m = _COUNTS / _TOTAL
    anchor = int(np.argmax(m[1:]) + 1)
    modal_p = m[anchor]

    score += (residual == 0.0).astype(np.float64) * (6.0 + 3.0 * modal_p)

    score += (0.6 + 0.8 * modal_p) * np.exp(-0.5 * (residual / 3.0) ** 2)

    # Mild aging: prefer bins whose exact residual has not been touched for a
    # while, encouraging old partially-filled bins to be revisited/closed.
    age = _CLOCK - _AGE[ri]
    score += 0.02 * np.tanh(age * 0.01)

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    # mark chosen residual as freshly touched
    best = residual
    if residual.size > 0:
        j = int(np.argmax(score))
        bj = int(np.clip(round(best[j]), 0, 100))
        _AGE[bj] = _CLOCK
    _CLOCK += 1.0

    return score
# EVOLVE-BLOCK-END

