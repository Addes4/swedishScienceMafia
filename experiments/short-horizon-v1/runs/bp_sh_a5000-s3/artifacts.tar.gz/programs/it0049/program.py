# EVOLVE-BLOCK-START
"""Best fit that avoids opening fresh bins until necessary."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    score = -residual.astype(np.float64)
    # Penalize completely empty bins (remaining 100) so partial bins are preferred.
    score[bins == 100] -= 1000.0
    return score
# EVOLVE-BLOCK-END
