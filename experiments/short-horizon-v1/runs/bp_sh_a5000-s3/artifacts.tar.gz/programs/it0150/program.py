# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit with a robust closeability term."""
import numpy as np


_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

_PROB = np.ones(101, dtype=np.float64) / 101.0
_DIRTY = True


def _smooth(arr, sigma=1.2):
    k = int(3 * sigma)
    xs = np.arange(-k, k + 1, dtype=np.float64)
    w = np.exp(-0.5 * (xs / sigma) ** 2)
    w /= w.sum()
    padded = np.concatenate([np.full(k, arr[0], dtype=np.float64), arr,
                             np.full(k, arr[-1], dtype=np.float64)])
    return np.convolve(padded, w, mode='valid')


def _rebuild():
    global _PROB, _DIRTY
    probs = _COUNTS / _TOTAL
    _PROB = _smooth(probs, sigma=1.2)
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    # Base: smooth monotone best-fit term. Residual 0 strongly favored,
    # larger leftovers gently penalized.
    score = -0.05 * residual

    # Crisp exact-fit bonus: closing a bin is decisively good.
    score += (residual == 0.0).astype(np.float64) * 5.0

    # Single-item closeability: residual that matches a common future item
    # size is worth keeping around.
    score += 4.0 * _PROB[ri]

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
