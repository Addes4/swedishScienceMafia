# EVOLVE-BLOCK-START
"""Distribution-aware best fit with residual-utility tie-break.

Items are integer sizes 1..100 from a fixed (Weibull-ish, mean ~40) distribution.
Pure best-fit leaves many tiny unusable residuals. We keep best-fit as the
dominant ordering but break close ties by estimating, from an online histogram
of observed item sizes, how "useful" the post-placement residual is: a residual
that is large enough to be filled by a typical future item is good, a residual
below nearly all observed items is wasted space.

Scoring: primary key = residual (smaller better). Tie-break within a small band
around the minimum residual uses residual utility u(r) = P(a future item <= r),
i.e. the chance the leftover can later be consumed, favoring reusable gaps.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def _utility(residual):
    # P(future item <= residual) estimated from the online histogram.
    # Keep a small floor so empty residual (0) is not special-cased oddly.
    c = np.cumsum(_HIST)
    if _TOTAL <= 0:
        # No data yet: fall back to a smooth prior centered near mean 40.
        return np.clip(residual, 0, 100) / 100.0
    return c[np.clip(residual, 0, 100).astype(np.int64)] / _TOTAL


def priority(item, bins):
    global _TOTAL
    residual = bins - item  # post-placement remaining capacity, >= 0

    # Best-fit dominant term.
    base = -residual.astype(np.float64)

    # Residual utility: prefer leftovers that some future item can still fill.
    u = _utility(residual)

    # Band-limited tie-break: only matters among near-best-fit bins.
    r = residual.astype(np.float64)
    rmin = r.min()
    band = np.exp(-(r - rmin) / 4.0)  # ~1 for residuals near the tightest fit
    tie = band * u

    score = base * 1000.0 + tie

    # Update online histogram AFTER scoring (item was just placed).
    H = min(max(int(item), 1), 100)
    _HIST[H] += 1.0
    _TOTAL += 1.0

    return score
# EVOLVE-BLOCK-END
