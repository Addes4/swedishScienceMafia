# EVOLVE-BLOCK-START
"""Distribution-adaptive residual-utility bin ranking.

For each candidate bin we compute the residual r = capacity_left - item and
score it by how likely r is to be "useful" later: the chance a future item
exactly fills it, plus the discounted chance a pair of future items fills it.
We also down-weight residuals that are unlikely to be reachable at all
(waste penalty).  The item distribution is learned online via a decayed
histogram so the estimate adapts within a stream.
"""
import numpy as np

_N = 101
# Decayed Laplace-smoothed histogram of observed item sizes.
_COUNTS = np.ones(_N, dtype=np.float64)
_PRIOR_MEAN = 40.0
# seed prior lightly around the known mean
for _s in range(1, _N):
    _COUNTS[_s] += 0.3 * np.exp(-((_s - _PRIOR_MEAN) ** 2) / (2 * 20.0 ** 2))
_TOTAL = float(_COUNTS.sum())

_UTIL = np.zeros(_N, dtype=np.float64)
_REACH = np.zeros(_N, dtype=np.float64)
_DIRTY = True


def _rebuild():
    global _UTIL, _REACH, _DIRTY
    probs = _COUNTS / _TOTAL

    # Candidate "common" sizes: any size with non-trivial probability.
    thresh = probs.mean() * 0.5
    common = np.nonzero(probs > thresh)[0]
    if common.size == 0:
        common = np.array([int(round(_PRIOR_MEAN))], dtype=np.int64)
    # Cap the number of sizes used for pair sums for speed.
    if common.size > 40:
        order = np.argsort(probs[common])[::-1][:40]
        common = common[order]

    util = probs.copy()          # single-item exact fill
    reach = (probs > 0).astype(np.float64)
    reach[0] = 1.0

    # Pair sums: probability exactly two later items (in sequence) fill r.
    cp = probs[common]
    for i, a in enumerate(common):
        if a <= 0:
            continue
        b = common
        s = a + b
        mask = (s > 0) & (s <= 100)
        if not np.any(mask):
            continue
        sm = s[mask]
        contrib = cp[i] * cp[mask]
        np.add.at(util, sm, contrib)
        reach[sm] = 1.0

    # Three-item sums with a discount (more alignment needed).
    if common.size <= 15:
        c2 = cp
        for i, a in enumerate(common):
            for j, b in enumerate(common):
                base = a + b
                s = base + common
                mask = (s > 0) & (s <= 100)
                if not np.any(mask):
                    continue
                sm = s[mask]
                contrib = 0.25 * cp[i] * c2[j] * c2[mask]
                np.add.at(util, sm, contrib)
                reach[sm] = 1.0

    _UTIL = util
    _REACH = reach
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = bins - item  # exact integer residual (bins int64)

    if _DIRTY:
        _rebuild()

    ri = np.clip(residual.astype(np.int64), 0, 100)

    val = _UTIL[ri]
    # Log-compress so ordering is stable and large values don't dominate.
    score = np.log(val + 1e-6)

    # Bonus for reachable residuals (can be completed by common sizes).
    score += 0.20 * _REACH[ri]

    # Waste penalty: residual whose reachability is low is penalized.
    score -= 0.30 * (1.0 - _REACH[ri])

    # Strong bonus for a perfect fit.
    score += (residual == 0).astype(np.float64) * 3.0

    # Gentle best-fit pressure as a tie-breaker.
    score -= residual.astype(np.float64) * 0.004

    # Decayed histogram update.
    _COUNTS *= 0.999
    _TOTAL *= 0.999
    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
