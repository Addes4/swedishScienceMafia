# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit with reachable-residual bonus.

Score each bin by an estimate of how valuable its post-placement residual is.
A residual is valuable if it is likely to be exactly filled by a later item,
or more generally if it can be completed by a small combination of likely
item sizes (e.g. 40+60). We learn the item distribution online and maintain
a reachability set over residuals 0..100 built from common observed sizes.
"""
import numpy as np


# Online histogram of observed item sizes (Laplace-smoothed).
_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

# Reachability/utility cache keyed by rounded residual -> value.
_UTIL = np.zeros(101, dtype=np.float64)
# Fraction of residual mass that is "reachable" by likely item sums.
_REACH = np.zeros(101, dtype=np.float64)
_DIRTY = True


def _rebuild_util():
    """Compute utility of each residual r in 0..100.

    Base value = probability that a single future item exactly equals r.
    Additional value = whether r is expressible as a sum of 2 or 3 likely
    items, using the most probable sizes. We also track, for each residual,
    the total reachability mass so we can penalize residuals that are hard
    to ever fill.
    """
    global _UTIL, _REACH, _DIRTY
    probs = _COUNTS / _TOTAL

    # Most likely item sizes (top few) for combination building.
    order = np.argsort(probs)[::-1]
    top = [int(t) for t in order[:16] if probs[t] > probs.mean()]

    util = probs.copy()
    reach = probs.copy()

    # Two-item sums.
    for a in top:
        if a <= 0 or a > 100:
            continue
        pa = probs[a]
        for b in top:
            s = a + b
            if 0 < s <= 100:
                w = pa * probs[b]
                util[s] += 0.6 * w
                reach[s] += 0.6 * w
        # complement single (a + x = 100): value of reaching full-ish
    # Two-item complements toward 100 handled implicitly by single terms.

    # Three-item sums (smaller contribution).
    for a in top:
        pa = probs[a]
        for b in top:
            pab = pa * probs[b]
            for c in top:
                s = a + b + c
                if 0 < s <= 100:
                    w = pab * probs[c]
                    util[s] += 0.25 * w
                    reach[s] += 0.25 * w

    _UTIL = util
    _REACH = reach
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild_util()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    # Value of leaving this residual (higher = better).
    val = _UTIL[ri]
    reach = _REACH[ri]

    # Log-scale for stability, plus strong perfect-fill bonus.
    score = np.log(val + 1e-9)
    score += (residual == 0.0).astype(np.float64) * 6.0

    # Penalize residuals that are hard to ever fill (low reachability).
    score -= np.log(reach + 1e-6) * 0.5

    # Mild best-fit pressure to break ties sensibly.
    score -= residual * 0.004

    # Update online histogram.
    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END
