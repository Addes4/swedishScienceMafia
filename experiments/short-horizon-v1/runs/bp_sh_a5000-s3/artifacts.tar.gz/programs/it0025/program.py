# EVOLVE-BLOCK-START
"""Best fit with a learned residual-value preference for near-ties.

Core policy: pack the item as tightly as possible (best fit), which is strong for
Weibull-shaped sizes.  To squeeze out stranded space, we keep a running histogram
of the residual capacities that actually got "used up" by later items, and among
bins whose post-placement residual is close to the tightest possible residual we
prefer the one whose residual is most likely to be filled by a future item.
"""
import numpy as np

# running statistics of past items (state kept across calls within a stream)
_hist = np.zeros(101, dtype=np.float64)   # counts of item sizes seen
_n = 0.0


def priority(item, bins):
    global _hist, _n

    residuals = bins - item                     # post-placement residual (>=0)
    best = residuals.min()
    # tiny window around the tightest fit: candidates considered "near ties"
    window = 3
    cand = residuals <= best + window

    # score: prefer small residual (best fit), tie-broken by how often a residual
    # close to this value got consumed by a subsequent item in the past.
    if _n > 0.0:
        # smoothed probability that a future item has a size near this residual
        # (residual r is fillable by items of size ~r)
        prob = _hist / _n
        # weight bins by best-fit tightness plus a small learned bonus
        learned = prob[np.clip(residuals.astype(np.int64), 0, 100)]
    else:
        learned = np.zeros_like(residuals, dtype=np.float64)

    score = -(residuals.astype(np.float64)) + 2.0 * learned * cand

    # update statistics with the current item (after scoring, uses only past info
    # for the current decision which is already done for this item size)
    _hist[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
