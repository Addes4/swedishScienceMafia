# EVOLVE-BLOCK-START
"""Distribution-adaptive best-fit with a stable stranding-avoidance term."""
import numpy as np


_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0
_DIRTY = True

# cached per-residual "closability" and small-item info
_UTIL = np.zeros(101, dtype=np.float64)


def _rebuild_util():
    """Estimate, per residual s, how plausibly it can be closed by a single
    future item.  Uses the observed histogram directly (no combinatorial
    blow-up) which keeps the signal low-variance."""
    global _UTIL, _DIRTY
    probs = _COUNTS / _TOTAL
    util = probs[1:101].copy()  # util[s] ~ P(next item == s) closes residual s
    # smooth lightly so sparse high residuals aren't over-rewarded
    k = 1
    xs = np.arange(-k, k + 1, dtype=np.float64)
    w = np.exp(-0.5 * (xs / 1.0) ** 2)
    w /= w.sum()
    padded = np.concatenate([np.full(k, util[0]), util, np.full(k, util[-1])])
    sm = np.convolve(padded, w, mode='valid')
    out = np.zeros(101, dtype=np.float64)
    out[1:101] = sm
    _UTIL = out
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild_util()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    # Primary: crisp best-fit ordering.  Dominant exact-fit bonus, then a
    # smooth, strictly monotone penalty so smaller positive leftovers win.
    score = -0.05 * residual

    # Exact fit dominates everything.
    score += (residual == 0.0).astype(np.float64) * 8.0

    # Avoid stranding tiny leftovers that no plausible item can close: reward
    # residuals the observed distribution can actually fill.
    score += 1.2 * _UTIL[ri]

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END

