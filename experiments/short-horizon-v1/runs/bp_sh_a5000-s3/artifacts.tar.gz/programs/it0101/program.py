# EVOLVE-BLOCK-START
"""Adaptive best-fit: prefer tight fits, weighted by residual usefulness."""
import numpy as np


_COUNTS = np.ones(101, dtype=np.float64)
_TOTAL = 101.0

# Utility of a residual r: probability that some future item can reduce it
_UTIL = np.zeros(101, dtype=np.float64)
_DIRTY = True


def _rebuild_util():
    global _UTIL, _DIRTY

    m = _COUNTS / _TOTAL
    # Top probable sizes form the basis for combination estimates.
    top = np.argsort(m)[::-1]
    top = [int(t) for t in top if t > 0 and m[t] > 0.0][:16]

    util = np.zeros(101, dtype=np.float64)
    # A residual can be closed by 1, 2 or 3 typical items; weight by prob mass.
    for a in top:
        if a <= 100:
            util[a] += m[a]
        for b in top:
            s = a + b
            if 0 < s <= 100:
                util[s] += m[a] * m[b]
            for c in top:
                t = a + b + c
                if 0 < t <= 100:
                    util[t] += m[a] * m[b] * m[c]

    _UTIL = util
    _DIRTY = False


def priority(item, bins):
    global _COUNTS, _TOTAL, _DIRTY

    residual = (bins - item).astype(np.float64)

    if _DIRTY:
        _rebuild_util()

    ri = np.clip(np.round(residual).astype(np.int64), 0, 100)

    # Base: best-fit (smaller residual is better).
    score = -residual * 0.01

    # Reward residuals that are likely to be closed by future items.
    score += np.log(_UTIL[ri] + 1e-9) * 0.3

    # Strong reward for exact fit.
    score += (residual == 0.0).astype(np.float64) * 4.0

    _COUNTS[item] += 1.0
    _TOTAL += 1.0
    _DIRTY = True

    return score
# EVOLVE-BLOCK-END

