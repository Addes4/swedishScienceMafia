# EVOLVE-BLOCK-START
"""Best fit with a fillable-residual tie-break learned from a running size histogram."""
import numpy as np

_FILLABLE = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    global _COUNT
    # update running histogram (decayed so it adapts but is stable)
    _FILLABLE *= 0.9995
    _FILLABLE[item] += 1.0
    _COUNT += 1.0

    residual = bins - item  # post-placement remaining capacity

    # base: prefer tightest fit (residual closest to 0)
    # transform so higher score = better: negative residual
    score = -residual.astype(np.float64)

    # fillable bonus: how likely this residual can be exactly filled by a common item
    # normalize histogram to probabilities
    tot = _COUNT if _COUNT > 0 else 1.0
    prob = _FILLABLE / tot  # index by residual size (0..100)

    # residual may be >=0; clip index
    idx = residual.copy()
    np.clip(idx, 0, 100, out=idx)
    bonus = prob[idx]

    # small weight so it only breaks near-ties of tightness
    return score + 0.35 * bonus
# EVOLVE-BLOCK-END
