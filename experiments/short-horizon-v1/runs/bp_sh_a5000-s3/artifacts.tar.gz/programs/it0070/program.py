# EVOLVE-BLOCK-START
"""Harmonic residual scoring.

Instead of pure best-fit, score post-placement residuals by how "fillable" the
leftover gap is. A residual of 0 is ideal. Residuals close to typical item sizes
(Weibull mean ~40) or simple fractions of capacity (25, 50) are more likely to be
exactly filled by a later item than arbitrary mid-size gaps. Large residuals are
nearly neutral since they remain usable.

This shifts the dominant ranking away from best-fit, which the evaluator shows
sits on a plateau near 0.959.
"""
import numpy as np


# Residual values we consider "attractive" leftovers, lower is better to hit.
# 0 = perfect fill; then a coarse harmonic ladder of common item sizes/fractions.
_TARGETS = np.array([0.0, 25.0, 40.0, 50.0, 60.0, 75.0, 80.0], dtype=np.float64)
_WEIGHTS = np.array([10.0, 2.0, 3.0, 1.5, 1.0, 0.5, 0.3], dtype=np.float64)


def priority(item, bins):
    residual = (bins - item).astype(np.float64)  # post-placement, >= 0

    # Attraction to the nearest target residual.
    d = np.abs(residual[:, None] - _TARGETS[None, :])
    best_d = d.min(axis=1)
    # bonus: peak value at distance 0, decaying with distance.
    bonus = np.exp(-best_d / 12.0)

    # Very slight preference for smaller residuals (mild best-fit pressure),
    # small enough not to dominate the fillability signal.
    mild_best_fit = -residual * 0.01

    return bonus + mild_best_fit
# EVOLVE-BLOCK-END
