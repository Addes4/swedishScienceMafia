# EVOLVE-BLOCK-START
"""Best-Fit dominated rule: exact/tight fits first, then smallest leftover."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Exact fits dominate, then very tight fits.
    exact_bonus = np.where(leftover == 0, 1e9, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1e6

    # Among the rest, prefer smallest leftover (Best-Fit), mildly scaled.
    return exact_bonus + tight_bonus - leftover
# EVOLVE-BLOCK-END
