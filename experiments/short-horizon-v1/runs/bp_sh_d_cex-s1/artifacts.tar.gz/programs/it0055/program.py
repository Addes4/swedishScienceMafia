# EVOLVE-BLOCK-START
"""Worst-fit-with-fit-protection: spread into emptier bins, but never pass up a good fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item.astype(bins.dtype)

    # Dominant rewards for exact fits and very tight fits: never pass these up.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Otherwise prefer emptier bins (larger leftover), which keeps residuals open
    # for the many small items of the Weibull tail.
    return exact_bonus + tight_bonus + leftover
# EVOLVE-BLOCK-END
