# EVOLVE-BLOCK-START
"""Target-residual fit with a repeat-fit bonus: prefer bins whose leftover is close to a target
and whose leftover after placement can still admit another common-sized item."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits and small leftovers (Best-Fit dominance).
    exact_bonus = np.where(leftover == 0, 1e9, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Steer toward a target residual to reduce fragmentation.
    residual_penalty = np.abs(leftover - _TARGET)

    # Gentle bonus when the leftover can still fit a typical item (~40) or a repeat of this item:
    # favor residuals that are >= item (room for a repeat) but not wastefully large.
    repeat_fit = np.where(leftover >= item, 1.0 / (1.0 + np.abs(leftover - 2.0 * item)), 0.0)

    return exact_bonus + tight_bonus - residual_penalty + 5.0 * repeat_fit
# EVOLVE-BLOCK-END

