# EVOLVE-BLOCK-START
"""Adaptive target-residual fit: prefer bins whose leftover after placement is closest to a
target that tracks the running mean of observed item sizes, with strong near-fit bonuses."""
import numpy as np

# Per-stream running statistics; keyed by the length of the bins array seen on first call
# of a stream (bins length == number of items already placed + 1, roughly), and reset when
# that length jumps back to a small value.
_state = {"n": 0, "sum": 0.0, "len": -1}


def _maybe_reset(bins):
    # Heuristic stream detection: a fresh stream typically starts with many unused bins (==100)
    # and lengths grow monotonically within a stream. Track a monotone count of placed items.
    full = np.count_nonzero(bins >= 100)
    # If number of full bins (untouched) is large relative to our tracked n, likely new stream.
    if _state["n"] > 0 and full > _state["n"]:
        _state["n"] = 0
        _state["sum"] = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, first on ties."""
    _maybe_reset(bins)

    n = _state["n"]
    mean = (_state["sum"] / n) if n > 0 else 40.0

    leftover = bins - item

    # Strongly reward near-perfect fits so Best-Fit dominance is preserved.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Adaptive residual target: aim to leave room for roughly half a typical item, which
    # reduces fragmentation while still packing densely.
    target = 0.5 * mean

    score = exact_bonus + tight_bonus - np.abs(leftover - target)

    # Update running statistics for future items in this stream.
    _state["n"] = n + 1
    _state["sum"] += float(item)
    _state["len"] = len(bins)

    return score
# EVOLVE-BLOCK-END

