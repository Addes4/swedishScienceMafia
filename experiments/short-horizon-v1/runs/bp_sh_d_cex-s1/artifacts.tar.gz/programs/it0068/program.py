# EVOLVE-BLOCK-START
"""Best-fit core with exact/tight bonuses plus an item-scaled residual steer."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Dominant: reward near-perfect fits so existing bins get filled tightly first.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Mild, item-scaled steer: leave a residual proportional to the item size.
    # Larger items prefer larger leftovers (room for another medium item);
    # small items prefer tight residuals. Scale-invariant so it helps short streams too.
    target = 0.75 * item
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
