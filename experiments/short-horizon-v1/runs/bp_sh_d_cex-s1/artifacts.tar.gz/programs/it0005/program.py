# EVOLVE-BLOCK-START
"""Best-fit: prefer the bin leaving the smallest non-negative residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item
    # Highest score = smallest leftover (best fit). Negate leftover so the tightest fit wins.
    return -leftover
# EVOLVE-BLOCK-END
