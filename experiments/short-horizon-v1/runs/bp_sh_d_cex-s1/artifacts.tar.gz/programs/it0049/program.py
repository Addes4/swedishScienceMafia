# EVOLVE-BLOCK-START
"""Target-residual fit with best-fit tie-break: prefer bins whose leftover after placement is
closest to a target, and among equally good residuals prefer the fullest bin."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Base target-residual cost.
    cost = np.abs(leftover - _TARGET)

    # Tie-break: among bins with (almost) equal cost, prefer the fullest bin (smallest leftover).
    # This is a tiny monotone nudge that only matters on near-ties, tightening packing without
    # disturbing the exact-fit / short-stream behaviour.
    tie_break = -leftover * 1e-3

    return exact_bonus + tight_bonus - cost + tie_break
# EVOLVE-BLOCK-END
