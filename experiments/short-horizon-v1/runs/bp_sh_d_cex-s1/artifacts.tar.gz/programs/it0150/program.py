# EVOLVE-BLOCK-START
"""Asymmetric residual steering: prefer bins whose leftover can still fit a typical next item."""
import numpy as np

_TARGET_SHORT = 30.0
_WARMUP = 35

_count = 0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum

    leftover = bins - item

    # Determine a typical item size: fixed until warmed up (protects short streams),
    # then the running mean of observed item sizes.
    if _count < _WARMUP:
        typical = _TARGET_SHORT
    else:
        typical = _sum / _count

    _count += 1
    _sum += item

    # Huge bonus for exact fits.
    exact_bonus = np.where(leftover == 0, 1e9, 0.0)
    # Keep tight-fit bonus so near-perfect placements are strongly favored.
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Asymmetric residual steering: reward bins that leave at least one typical item's
    # worth of room, and among those prefer the tightest leftover still >= typical.
    spacious = leftover >= typical
    # Among spacious bins: smaller leftover (closer to typical) is better.
    spacious_score = np.where(spacious, 1000.0 - leftover, 0.0)
    # Among cramped bins (leftover < typical): prefer the smallest leftover (best-fit).
    cramped_score = np.where(spacious, 0.0, -leftover)

    return exact_bonus + tight_bonus + spacious_score + cramped_score
# EVOLVE-BLOCK-END
