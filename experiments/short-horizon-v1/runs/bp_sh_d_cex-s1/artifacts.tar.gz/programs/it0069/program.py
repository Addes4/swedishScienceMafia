# EVOLVE-BLOCK-START
"""Target-residual fit with an adaptive near-Best-Fit steer derived from bin occupancy."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Estimate a target residual from current occupancy: bins are capacity 100.
    # Full bins have small remaining capacity; use the mean remaining capacity of
    # bins that could still fit something meaningful as a rough density signal.
    # Keep it simple and stable: target ~ half the mean item size (~20), clipped.
    used = 100.0 - bins
    filled = used > item  # bins already holding items of at least this size
    if np.any(filled):
        mean_used = float(np.mean(used[filled]))
        target = min(35.0, max(10.0, 0.5 * mean_used))
    else:
        target = 20.0

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
