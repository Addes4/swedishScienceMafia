# EVOLVE-BLOCK-START
"""Adaptive target-residual fit: prefer bins whose leftover after placement is closest to a
running-mean item size (so ~one more average item still fits), with strong near-exact bonuses."""
import numpy as np

_sum = 0.0
_count = 0
_INIT_TARGET = 40.0  # prior mean of the item distribution


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _sum, _count
    target = _sum / _count if _count > 0 else _INIT_TARGET

    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward the target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    score = exact_bonus + tight_bonus - np.abs(leftover - target)

    # Update running statistics after scoring (no future information used).
    _sum += item
    _count += 1
    return score
# EVOLVE-BLOCK-END

