# EVOLVE-BLOCK-START
"""Asymmetric fit: strongly prefer smallest positive leftover while keeping exact-fit bonuses."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    # Best-fit: prefer the tightest positive leftover.
    return exact_bonus - leftover
# EVOLVE-BLOCK-END

