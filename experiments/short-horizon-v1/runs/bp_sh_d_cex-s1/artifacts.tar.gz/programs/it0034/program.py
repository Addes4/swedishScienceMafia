# EVOLVE-BLOCK-START
"""Target-residual fit with a Best-Fit fallback and strong exact-fit bonuses."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers) so short streams pack tightly.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Target-residual steering (favors a moderate leftover).
    target_term = -np.abs(leftover - _TARGET)

    # Best-Fit fallback: mildly prefer the smallest positive leftover (tight packing).
    positive_leftover = np.where(leftover > 0, leftover, 1e6)
    best_fit_term = -positive_leftover / 100.0

    return exact_bonus + tight_bonus + target_term + best_fit_term
# EVOLVE-BLOCK-END

