# EVOLVE-BLOCK-START
"""Target-residual fit: prefer bins whose leftover after placement is closest to a target.
The target adapts slowly toward a pairing value after a long warm-up."""
import numpy as np

_TARGET0 = 30.0
_WARMUP = 1200


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Adaptive target: stays 30.0 for long warm-up so short streams are untouched.
    n = getattr(priority, "_n", 0)
    s = getattr(priority, "_s", 0.0)
    if n >= _WARMUP and n > 0:
        mean_item = s / n
        # Pairing target: complement toward a roughly two-item fill.
        target = 0.5 * (_TARGET0 + max(5.0, min(60.0, 100.0 - 2.0 * mean_item)))
    else:
        target = _TARGET0

    priority._n = n + 1
    priority._s = s + item

    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
