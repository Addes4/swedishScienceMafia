# EVOLVE-BLOCK-START
"""Adaptive target-residual fit: target tracks the running mean item size (clipped to a safe range)."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update running mean of item sizes seen so far.
    _state["sum"] += item
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]

    # Target residual: aim to leave roughly a typical item's worth of space so future
    # items can slot in cleanly. Clip to a reasonable band around the known mean ~40.
    target = 0.75 * mean
    if target < 20.0:
        target = 20.0
    elif target > 45.0:
        target = 45.0

    leftover = bins - item

    # Strongly reward near-perfect fits, then a graduated tight-fit bonus, then target pull.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END

