# EVOLVE-BLOCK-START
"""Target-residual fit with a penalty for wasting tiny residuals that no item can reuse."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Core: steer toward the target residual.
    score = exact_bonus + tight_bonus - np.abs(leftover - _TARGET)

    # Mildly penalize residuals in (0, threshold) that are too small to be reused
    # (below the smallest likely item ~1-6), since that space is effectively wasted.
    tiny = (leftover > 0) & (leftover < 8.0)
    score = score - np.where(tiny, (8.0 - leftover) * 3.0, 0.0)

    return score
# EVOLVE-BLOCK-END
