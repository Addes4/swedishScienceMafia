# EVOLVE-BLOCK-START
"""Adaptive fill: prefer near-exact fits, else steer leftover toward matching the running mean item size."""
import numpy as np

_MEAN_INIT = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Running mean item size estimate (kept in a function attribute for per-stream state).
    prev = getattr(priority, "n", 0)
    mean = getattr(priority, "mean", _MEAN_INIT)
    mean = (mean * prev + item) / (prev + 1)
    priority.mean = mean
    priority.n = prev + 1

    leftover = bins - item

    # Dominant: exact and near-exact fits.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Secondary steer: prefer residuals close to the running mean (so a future
    # average item fills the bin), scaled small so it never overrides tight fits.
    target = mean
    steer = -np.abs(leftover - target)

    return exact_bonus + tight_bonus + steer
# EVOLVE-BLOCK-END
