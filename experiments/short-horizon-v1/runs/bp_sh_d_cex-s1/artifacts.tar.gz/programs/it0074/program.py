# EVOLVE-BLOCK-START
"""Residual steering that fills toward a likely next item, softened for small/fragmented states."""
import numpy as np

_TARGET = 30.0
_NEXT = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Dominant: reward near-perfect fits and tight residuals (preserves best-fit behavior).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Base residual steer toward a moderate leftover.
    steer = -np.abs(leftover - _TARGET)

    # Extra: favor residuals that can still host a probable next item (~40) nicely.
    next_fit = np.exp(-((leftover - _NEXT) ** 2) / (2.0 * 15.0 * 15.0))

    # Soften the extra term when few bins are in play (short/fragmented streams),
    # so short-stream behavior stays close to the proven residual fit.
    occupied = np.count_nonzero(bins < 100)
    scale = occupied / (occupied + 8.0)

    return exact_bonus + tight_bonus + steer + scale * 2.0 * next_fit
# EVOLVE-BLOCK-END

