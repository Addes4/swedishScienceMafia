# EVOLVE-BLOCK-START
"""Adaptive residual-target fit: prefer bins whose leftover after placement is closest to a
running estimate of the typical complementary residual (running mean item size)."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _mean, _count
    _count += 1
    _mean += (item - _mean) / _count

    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Steer toward a target residual derived from the running mean item size:
    # leave room for roughly one more typical item.
    target = _mean
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
