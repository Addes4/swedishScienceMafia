# EVOLVE-BLOCK-START
"""Target-residual fit for short streams, best-fit blend for long streams."""
import numpy as np

_TARGET = 30.0
_WARMUP = 60  # items seen before enabling the best-fit blend


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    base = exact_bonus + tight_bonus - np.abs(leftover - _TARGET)

    n = getattr(priority, "_n", 0)
    priority._n = n + 1
    if n < _WARMUP:
        return base

    # Gated best-fit: prefer the smallest leftover that still fits (leftover >= 0),
    # so long streams pack bins more tightly. Kept below the exact/tight bonuses' scale.
    best_fit = -leftover.astype(np.float64)
    return base + 0.5 * best_fit
# EVOLVE-BLOCK-END
