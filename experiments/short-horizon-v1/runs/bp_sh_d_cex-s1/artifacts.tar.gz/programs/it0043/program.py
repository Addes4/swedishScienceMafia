# EVOLVE-BLOCK-START
"""Item-size-aware residual target: leave room for a typical next item."""
import numpy as np

_MEAN_SEED = 40.0
_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    cnt = _state["count"]
    mean = _state["sum"] / cnt if cnt > 0 else _MEAN_SEED

    leftover = bins - item

    # Update running mean (past items only).
    _state["sum"] += item
    _state["count"] = cnt + 1

    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Target leftover: room for a typical next item so the bin fills well on average.
    target = np.minimum(mean, 100.0)
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
