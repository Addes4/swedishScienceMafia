# EVOLVE-BLOCK-START
"""Target-residual fit with an adaptive target tracking the running mean item size."""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _state["sum"] += item
    _state["count"] += 1
    mean_item = _state["sum"] / _state["count"]

    # Target residual: half the running mean item size tends to fit well for this distribution.
    target = mean_item * 0.5

    leftover = bins - item

    # Strongly reward near-perfect fits; identical to the original so short streams don't regress.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
