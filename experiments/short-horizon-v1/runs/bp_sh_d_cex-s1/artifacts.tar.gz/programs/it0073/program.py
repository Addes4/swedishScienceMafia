# EVOLVE-BLOCK-START
"""Target-residual fit with an exact-fit emphasis plus a sum-fill term targeting the mean item size."""
import numpy as np

_TARGET = 30.0
_FUTURE = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Reward leaving a residual that can be exactly paired with a typical future item.
    future_bonus = -np.abs(leftover - _FUTURE)

    return exact_bonus + tight_bonus + future_bonus - np.abs(leftover - _TARGET)
# EVOLVE-BLOCK-END

