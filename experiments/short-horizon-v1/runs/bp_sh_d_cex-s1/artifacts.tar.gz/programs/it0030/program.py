# EVOLVE-BLOCK-START
"""Target-residual fit: prefer bins whose leftover after placement is closest to a target."""
import numpy as np

_TARGET = 30.0

# Running statistics across the stream (reset per stream via size heuristic).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties to first bin."""
    # Track a running mean of item sizes; reset detection is handled by the harness
    # (fresh module state per stream), so we just accumulate.
    _state["n"] += 1
    _state["sum"] += float(item)
    mean_item = _state["sum"] / _state["n"]

    # Target residual: slightly below mean item size to encourage fuller bins
    # (Best-Fit-like), but never extreme.
    target = 0.75 * mean_item

    leftover = bins - item

    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END

