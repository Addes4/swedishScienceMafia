# EVOLVE-BLOCK-START
"""Target-residual fit with size-aware packing steer toward multiples of the mean item size."""
import numpy as np

_TARGET = 30.0
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    base = exact_bonus + tight_bonus - np.abs(leftover - _TARGET)

    # Small steer: prefer leftovers that leave room for a whole mean-sized item to nearly fill
    # the bin (i.e. leftover near a multiple of the mean), improving long-stream utilization.
    mod = np.mod(leftover, _MEAN)
    pack_bonus = -np.minimum(mod, _MEAN - mod)

    return base + 0.5 * pack_bonus
# EVOLVE-BLOCK-END
