# EVOLVE-BLOCK-START
"""Fit-aware packing: prefer near-perfect fits, else chain leftovers toward a running target."""
import numpy as np

# running statistics of seen items (per stream, reset when a fresh bins array is observed)
_state = {"n": 0, "sum": 0.0, "target": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # update running mean item size
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]
    # target residual: a leftover that one more average item could fill
    target = mean

    leftover = bins - item

    # Exact fits and very tight fits are crucial for short streams; keep them dominant.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Steer leftovers toward the running target, but strongly prefer smaller waste
    # after that so we don't strand big gaps on long streams.
    return exact_bonus + tight_bonus - np.abs(leftover - target) - 0.05 * leftover
# EVOLVE-BLOCK-END
