# EVOLVE-BLOCK-START
"""Size-aware Best-Fit: exact/tight-fit bonuses dominate, otherwise prefer leftovers near the item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Dominant: reward exact fits and very tight fits (preserves short-stream behavior).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight = leftover < 5.0
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Among non-tight bins, prefer a leftover close to the item size (anticipate a same-size partner),
    # with a mild Best-Fit bias toward smaller leftovers.
    size_aware = -np.abs(leftover - item)
    best_fit = -leftover

    base = 0.5 * size_aware + 0.1 * best_fit
    base = np.where(tight, 0.0, base)

    return exact_bonus + tight_bonus + base
# EVOLVE-BLOCK-END
