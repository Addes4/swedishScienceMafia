# EVOLVE-BLOCK-START
"""Best-fit with exact-fit priority: fill the tightest bin that still leaves room."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward exact fits, then near-perfect fits (these dominate short streams).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Best-fit flavor: among non-exact bins, prefer the one with the smallest post-placement
    # leftover (i.e. the fullest bin that still fits), which packs tightly on long streams.
    best_fit = -leftover

    return exact_bonus + tight_bonus + best_fit
# EVOLVE-BLOCK-END
