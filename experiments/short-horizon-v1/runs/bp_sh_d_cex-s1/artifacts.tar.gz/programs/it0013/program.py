# EVOLVE-BLOCK-START
"""Target-residual fit with a graduated tight-fit bonus and a mild best-fit nudge."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strong bonuses for perfect and near-perfect fits (drives short-stream behavior).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Main steering: prefer residuals near the target.
    target_term = -np.abs(leftover - _TARGET)

    # Mild secondary nudge: among similarly good options, prefer tighter (smaller) residuals.
    best_fit_nudge = -0.5 * leftover

    return exact_bonus + tight_bonus + target_term + best_fit_nudge
# EVOLVE-BLOCK-END

