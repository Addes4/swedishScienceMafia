# EVOLVE-BLOCK-START
"""Target-residual fit with a smooth future-fit window, tuned for long streams."""
import numpy as np

_TARGET = 22.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Smooth steer toward a target residual, favoring residuals that can still
    # accommodate a typical future item without leaving too much wasted space.
    steer = -np.abs(leftover - _TARGET)

    return exact_bonus + tight_bonus + steer
# EVOLVE-BLOCK-END
