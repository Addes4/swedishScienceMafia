# EVOLVE-BLOCK-START
"""Best-fit dominated: strongly reward near-exact fits, otherwise minimize leftover (Best-Fit)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Exact and tight fits dominate: these largely determine short-stream quality.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Among the rest, Best-Fit: prefer the smallest non-negative leftover.
    # leftover can be negative (bins where item doesn't fit), those are penalized.
    return exact_bonus + tight_bonus - leftover
# EVOLVE-BLOCK-END

