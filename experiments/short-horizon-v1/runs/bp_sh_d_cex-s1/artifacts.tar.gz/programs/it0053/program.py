# EVOLVE-BLOCK-START
"""Best-fit with a pairing-aware target: strong exact-fit bonus, then minimize leftover,
with a mild reward for leaving a residual near half the running mean item size."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _state["sum"] += item
    _state["n"] += 1
    mean_item = _state["sum"] / _state["n"]
    target = 0.5 * mean_item

    leftover = bins - item

    # Huge reward for exact fits, then a big bonus for near-perfect fits.
    exact_bonus = np.where(leftover == 0, 1e9, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1e6

    # Primary: minimize leftover (Best-Fit). Secondary: steer residual toward target.
    return exact_bonus + tight_bonus - leftover - 0.5 * np.abs(leftover - target)
# EVOLVE-BLOCK-END
