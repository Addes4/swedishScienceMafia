# EVOLVE-BLOCK-START
"""Best-fit ordering: prefer bins with the smallest post-placement leftover."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Reward near-perfect fits, then prefer the tightest remaining space (best-fit).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - leftover
# EVOLVE-BLOCK-END
