# EVOLVE-BLOCK-START
"""Target-residual fit with a gated online pair-fit bonus.

Base rule (unchanged): strongly reward exact fits, reward tiny leftovers, and steer leftover
toward a fixed target residual. On top of that, among bins that are already meaningfully
filled, reward leftovers that look like they will be exactly filled by a future item, using an
online estimate of the item-size distribution. The pair-fit term is gated to leftover < 80 so
that near-empty bins (dominant in short streams) keep the original ordering.
"""
import numpy as np

_TARGET = 30.0
_HISTORY = []          # item sizes seen so far in this stream
_MIN_HISTORY = 5
_WINDOW = 300
_PAIR_WEIGHT = 500.0
_LEFT_LO = 1e-9
_LEFT_HI = 80.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # --- original base rule, byte-identical ---
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    base = exact_bonus + tight_bonus - np.abs(leftover - _TARGET)

    # --- gated online pair-fit bonus ---
    if len(_HISTORY) >= _MIN_HISTORY:
        arr = np.asarray(_HISTORY[-_WINDOW:], dtype=float)
        mu = float(arr.mean())
        sd = float(arr.std()) + 1.0
        fit = np.exp(-0.5 * ((leftover - mu) / sd) ** 2)
        gate = ((leftover >= _LEFT_LO) & (leftover < _LEFT_HI)).astype(float)
        base = base + _PAIR_WEIGHT * fit * gate

    _HISTORY.append(item)
    return base
# EVOLVE-BLOCK-END
