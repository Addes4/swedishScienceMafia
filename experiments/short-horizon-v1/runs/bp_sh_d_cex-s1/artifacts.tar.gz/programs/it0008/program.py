# EVOLVE-BLOCK-START
"""Adaptive target-residual fit: prefer bins whose leftover after placement is closest to a
target residual that self-tunes to the observed item sizes."""
import numpy as np

# State kept across calls within a stream.
_count = 0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum, _mean

    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Target residual: a fraction of the running mean item size.
    target = 0.7 * _mean

    # Core score: closest to the target residual, plus a mild best-fit nudge.
    core = -np.abs(leftover - target) - 0.01 * leftover

    score = exact_bonus + tight_bonus + core

    # Update running statistics after scoring.
    _count += 1
    _sum += item
    _mean = _sum / _count

    return score
# EVOLVE-BLOCK-END

