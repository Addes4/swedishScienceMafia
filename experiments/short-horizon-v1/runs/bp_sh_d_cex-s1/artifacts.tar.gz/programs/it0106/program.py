# EVOLVE-BLOCK-START
"""Best-fit with soft exact/tight bonuses: pack tightly, keep short-stream precision."""
import numpy as np

_TARGET = 5.0  # small residual target ~ best-fit


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Dominant exact-fit bonus (perfect fill) and tight-fit bonus to preserve short-stream behavior.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - _TARGET)
# EVOLVE-BLOCK-END

