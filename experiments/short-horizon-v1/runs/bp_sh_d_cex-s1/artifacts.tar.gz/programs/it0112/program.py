# EVOLVE-BLOCK-START
"""Fit-driven priority: perfect/tight fits first, otherwise prefer the emptiest bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers) so short streams pack tightly.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Otherwise, prefer emptier bins (larger post-placement leftover) to avoid premature
    # fragmentation of bins and keep flexible room for future, variable-sized items.
    return exact_bonus + tight_bonus + leftover
# EVOLVE-BLOCK-END
