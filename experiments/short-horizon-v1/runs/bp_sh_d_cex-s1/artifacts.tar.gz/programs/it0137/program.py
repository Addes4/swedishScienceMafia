# EVOLVE-BLOCK-START
"""Threshold best-fit: reward leftovers too small to hold another copy of the item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Preserve the original exact-fit and tight-fit bonuses byte-identical.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Two-regime term:
    #  - If the leftover can't hold another copy of this item, it's a "dead" residual: prefer
    #    the smallest such leftover (best-fit) to keep bins tightly packed.
    #  - Otherwise prefer leaving about half the item's size as reusable headroom.
    dead = leftover < item
    best_fit = np.where(dead, -leftover, 0.0)
    headroom = -np.abs(leftover - 0.5 * item)
    regime = np.where(dead, 0.0, 1.0)
    return exact_bonus + tight_bonus + best_fit + headroom * regime
# EVOLVE-BLOCK-END
