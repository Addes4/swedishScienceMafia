# EVOLVE-BLOCK-START
"""Target-residual fit with an adaptive target based on the running mean item size."""
import numpy as np

_MEAN = 40.0
_COUNT = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _MEAN, _COUNT
    _MEAN = (_MEAN * _COUNT + item) / (_COUNT + 1)
    _COUNT += 1

    # Steer toward leaving a residual around half the typical item size.
    target = 0.55 * _MEAN

    leftover = bins - item

    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
