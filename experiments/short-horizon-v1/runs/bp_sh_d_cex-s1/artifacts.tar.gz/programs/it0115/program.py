# EVOLVE-BLOCK-START
"""Target-residual fit: prefer bins whose leftover after placement is close to a target."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Steer toward a residual equal to half the item's own size so similar items pair up.
    target = 0.5 * item
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
