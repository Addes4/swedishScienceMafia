# EVOLVE-BLOCK-START
"""Best-Fit core with an adaptive exact-fit credit toward frequently seen residuals."""
import numpy as np

# Running histogram of observed item sizes (indices 1..100), module state.
_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL

    leftover = bins - item

    # Best-Fit dominance: prefer the smallest non-negative leftover.
    score = -leftover.astype(np.float64)

    # Adaptive credit: reward leftovers that match a frequently observed item size.
    # Only meaningful for strictly positive leftovers (a zero leftover already best-fits).
    freq = _COUNT / _TOTAL if _TOTAL > 0 else np.zeros(101, dtype=np.float64)
    # Probability weight for each bin's leftover, if within histogram range and > 0.
    valid = (leftover >= 1) & (leftover <= 100)
    idx = np.where(valid, leftover, 0).astype(np.int64)
    credit = np.where(valid, freq[idx], 0.0)

    # Small weight so it only breaks ties among comparable Best-Fit choices.
    result = score + 0.5 * credit

    # Update histogram with the current item after scoring.
    _COUNT[item] += 1.0
    _TOTAL += 1.0

    return result
# EVOLVE-BLOCK-END
