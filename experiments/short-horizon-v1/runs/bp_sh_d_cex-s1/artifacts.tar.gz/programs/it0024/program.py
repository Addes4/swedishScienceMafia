# EVOLVE-BLOCK-START
"""Target-residual fit with a coarse Best-Fit tie-break among near-target bins."""
import numpy as np

_TARGET = 35.0
_QUANT = 4.0  # residual differences below this are treated as equal


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Coarse quantization of the residual so small differences are ignored,
    # then prefer the smaller residual (Best-Fit direction) within the target band.
    q = np.floor(leftover / _QUANT)
    quant_penalty = q  # prefer fuller bins (smaller leftover) when clearly different

    return exact_bonus + tight_bonus - np.abs(leftover - _TARGET) - quant_penalty
# EVOLVE-BLOCK-END
