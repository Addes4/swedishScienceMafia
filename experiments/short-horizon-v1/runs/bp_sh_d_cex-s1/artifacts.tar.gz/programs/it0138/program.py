# EVOLVE-BLOCK-START
"""Adaptive target-residual fit: steer residuals toward the mean item size on used bins,
while preferring tight fills when a bin is still largely empty (short-stream behavior)."""
import numpy as np

_MEAN_ITEM = 40.0
_FULLISH = 70.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Bin capacity *before* placing the item.
    cap = bins
    # For already partially used bins, target leaving room for one typical item;
    # for still-nearly-empty bins, prefer tighter fills (small leftover).
    target = np.where(cap <= _FULLISH, 0.0, _MEAN_ITEM)
    residual_term = -np.abs(leftover - target)

    return exact_bonus + tight_bonus + residual_term
# EVOLVE-BLOCK-END
