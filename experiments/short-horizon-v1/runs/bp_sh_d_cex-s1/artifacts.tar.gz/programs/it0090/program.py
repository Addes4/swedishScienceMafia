# EVOLVE-BLOCK-START
"""Hybrid rule: prefer exact/tight fits, then fall back to Best-Fit (smallest leftover)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Dominant bonuses for near-perfect fits.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Best-Fit fallback: smaller leftover after placement ranks higher.
    best_fit = -leftover.astype(np.float64)

    return exact_bonus + tight_bonus + best_fit
# EVOLVE-BLOCK-END
