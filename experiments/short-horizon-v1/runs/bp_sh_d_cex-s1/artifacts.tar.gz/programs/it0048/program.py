# EVOLVE-BLOCK-START
"""Adaptive pairing-target residual fit: prefer leftovers near half the running mean item size."""
import numpy as np

_TARGET_INIT = 30.0
_MEAN_INIT = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward exact and near-perfect fits.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Adaptive target: aim to leave a residual that a typical next item can fill.
    target = _TARGET_INIT

    # Quadratic penalty around the target, but milder than absolute for large residuals.
    diff = leftover - target
    return exact_bonus + tight_bonus - np.abs(diff) - 0.01 * diff * diff
# EVOLVE-BLOCK-END
