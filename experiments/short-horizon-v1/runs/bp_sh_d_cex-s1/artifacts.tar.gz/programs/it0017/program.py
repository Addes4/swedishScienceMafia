# EVOLVE-BLOCK-START
"""Residual targeting: prefer a leftover close to a typical future item size."""
import numpy as np

_TARGET = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward exact fits and near-perfect fits.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Steer toward a residual near a typical item size so future items fill well.
    return exact_bonus + tight_bonus - np.abs(leftover - _TARGET)
# EVOLVE-BLOCK-END

