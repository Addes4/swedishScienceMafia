# EVOLVE-BLOCK-START
"""Best-fit with a soft residual-matching bonus toward the typical item size."""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Dominant bonus for exact fits and very tight fits (classic best-fit bias).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.where((leftover > 0) & (leftover <= 5), 1000.0 - leftover, 0.0)

    # Best-fit base: prefer the smallest non-negative leftover.
    base = -leftover

    # Soft bonus when the residual left behind matches a likely future item size (~mean).
    match_bonus = -np.abs(leftover - _MEAN) * 0.05

    return exact_bonus + tight_bonus + base + match_bonus
# EVOLVE-BLOCK-END
