# EVOLVE-BLOCK-START
"""Target-residual fit with an adaptive, length-gated Best-Fit nudge."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    base = exact_bonus + tight_bonus - np.abs(leftover - _TARGET)

    # Mild Best-Fit nudge, active only when the bin array is large (long streams).
    # A small weight keeps it from overriding the exact-fit / near-exact decisions.
    if bins.size > 64:
        base = base - 0.05 * leftover

    return base
# EVOLVE-BLOCK-END
