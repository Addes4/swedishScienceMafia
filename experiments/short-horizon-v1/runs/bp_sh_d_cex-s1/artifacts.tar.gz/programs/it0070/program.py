# EVOLVE-BLOCK-START
"""Best-fit core with a gentle residual steer toward accommodating a typical future item."""
import numpy as np

# module-level running state (per-process); used only as a soft steer, not a hard rule
_count = 0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _count, _sum
    _count += 1
    _sum += item
    mean_item = _sum / _count

    leftover = bins - item

    # Core: prefer the tightest fit (smallest leftover). This is the dominant term.
    score = -leftover.astype(np.float64)

    # Strong but bounded reward for exact fits (avoid huge cliffs that distort ordering).
    score += np.where(leftover == 0, 50.0, 0.0)

    # Gentle steer: mildly prefer leftovers that can still fit a typical future item,
    # and mildly prefer not leaving a nearly-useless tiny residual.
    target = mean_item  # want leftover able to accept an average-sized item
    score -= 0.02 * np.abs(leftover - target)

    return score
# EVOLVE-BLOCK-END
