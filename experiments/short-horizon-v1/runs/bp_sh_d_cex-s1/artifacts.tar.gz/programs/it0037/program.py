# EVOLVE-BLOCK-START
"""Target-residual fit: prefer bins whose leftover after placement is closest to a target.

The target starts at the tuned value 30.0.  On long streams (once enough items have been
seen) it gradually shifts toward a value inferred from the running mean item size, which
matches the typical leftover of a well packed bin for the underlying Weibull distribution.
Short streams never reach the warm-up threshold, so they keep the exact original rule.
"""
import numpy as np

_TARGET = 30.0
_WARMUP = 800          # items before adaptation kicks in
_RAMP = 1500.0         # items over which adaptation fully blends in

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # --- running statistics of past items -------------------------------
    _state["n"] += 1
    _state["sum"] += float(item)
    n = _state["n"]
    mu = _state["sum"] / n

    # --- adaptive target (no effect on short streams) -------------------
    if n <= _WARMUP:
        target = _TARGET
    else:
        blend = min(1.0, (n - _WARMUP) / _RAMP)
        # leftover expected when a bin is filled to a near-optimal degree:
        # roughly one half item plus a small gap, tied to the mean size.
        adaptive = 0.35 * mu + 6.0
        adaptive = min(45.0, max(8.0, adaptive))
        target = (1.0 - blend) * _TARGET + blend * adaptive

    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
