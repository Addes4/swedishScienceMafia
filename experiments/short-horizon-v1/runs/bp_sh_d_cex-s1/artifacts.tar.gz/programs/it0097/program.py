# EVOLVE-BLOCK-START
"""Exact/tight-fit bonuses with a Best-Fit fallback (smallest leftover) for other bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits so short streams keep their near-optimal behavior.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Fallback: Best-Fit among non-tight bins -> prefer the smallest leftover after placement.
    return exact_bonus + tight_bonus - leftover
# EVOLVE-BLOCK-END
