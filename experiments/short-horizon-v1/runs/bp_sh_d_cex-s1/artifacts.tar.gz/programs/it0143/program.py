# EVOLVE-BLOCK-START
"""Best-fit with a typical-item floor: prefer exact fits, then residuals just above ~40, else smallest leftover."""
import numpy as np

_FLOOR = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Byte-identical exact/tight bonuses keep short-stream behavior intact.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Prefer residuals close to a typical item size (floored to leave room for one more item),
    # scaled small enough never to dominate the exact/tight bonuses but able to break ties
    # among loose bins to pack streams more densely.
    return exact_bonus + tight_bonus - np.abs(leftover - _FLOOR)
# EVOLVE-BLOCK-END

