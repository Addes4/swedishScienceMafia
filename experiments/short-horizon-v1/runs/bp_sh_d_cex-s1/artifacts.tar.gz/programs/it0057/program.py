# EVOLVE-BLOCK-START
"""Target-residual fit plus pairing bonus: prefer bins whose leftover can pair with this item size."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    # Pairing bonus: leftover equal (or close) to the item size makes a clean future pair.
    pair_bonus = np.maximum(0.0, 3.0 - np.abs(leftover - item)) * 50.0
    return exact_bonus + tight_bonus + pair_bonus - np.abs(leftover - _TARGET)
# EVOLVE-BLOCK-END

