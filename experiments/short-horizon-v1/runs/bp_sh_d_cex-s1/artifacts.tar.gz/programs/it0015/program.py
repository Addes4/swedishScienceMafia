# EVOLVE-BLOCK-START
"""Target-residual fit: prefer bins whose leftover after placement is closest to a target,
using an adaptive target derived from the running mean item size."""
import numpy as np

# Running statistics of the item stream (module state, reset per stream by the harness).
_count = 0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum
    _count += 1
    _sum += item
    mean = _sum / _count
    target = 0.5 * mean

    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Asymmetric penalty: leaving a tiny positive residual is bad (wasted fragment),
    # while being below the target is only mildly penalized.
    below = np.maximum(0.0, target - leftover)
    above = np.maximum(0.0, leftover - target)
    penalty = 1.5 * above + 0.5 * below

    return exact_bonus + tight_bonus - penalty
# EVOLVE-BLOCK-END

