# EVOLVE-BLOCK-START
"""Exact/tight-fit bonuses, plus classic Best-Fit for the remaining bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), extra for exact fits.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Best-Fit: among non-tight bins, prefer the smallest leftover (fullest remaining bin).
    return exact_bonus + tight_bonus - leftover
# EVOLVE-BLOCK-END
