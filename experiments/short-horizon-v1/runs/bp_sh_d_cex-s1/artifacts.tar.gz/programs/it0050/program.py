# EVOLVE-BLOCK-START
"""Hybrid best-fit with a pairing-aware residual target."""
import numpy as np

_MEAN_INIT = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, ties to first."""
    leftover = bins - item

    # Exact fits are almost always optimal: place immediately.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)

    # Pairing target: after placement, a residual close to the mean item size lets a
    # typical future item fill this bin tightly (large items pair with mid gaps).
    target = _MEAN_INIT
    pair_cost = np.abs(leftover - target)

    # Best-fit backbone: strongly prefer the fullest bin the item fits into.
    # (Smaller leftover -> better; keep it dominant but subservient to exact fits.)
    best_fit = leftover.astype(np.float64)

    return exact_bonus - 2.0 * best_fit - pair_cost
# EVOLVE-BLOCK-END

