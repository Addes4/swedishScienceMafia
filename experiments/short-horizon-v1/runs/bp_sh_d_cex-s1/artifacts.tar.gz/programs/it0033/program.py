# EVOLVE-BLOCK-START
"""Target-residual fit: prefer bins whose leftover after placement is closest to a target."""
import numpy as np

_TARGET = 30.0

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _state["sum"] += item
    _state["count"] += 1
    mean_item = _state["sum"] / _state["count"]

    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    base = exact_bonus + tight_bonus - np.abs(leftover - _TARGET)

    # Adaptive Best-Fit signal, applied only when there are many bins (long streams).
    # Blend a preference for small leftovers so packing tightens on long streams.
    n = bins.shape[0]
    if n >= 32:
        # weight grows slowly with array size but stays mild
        w = min(1.0, (n - 32) / 512.0) * (mean_item / 40.0) * 4.0
        base = base - w * leftover

    return base
# EVOLVE-BLOCK-END
