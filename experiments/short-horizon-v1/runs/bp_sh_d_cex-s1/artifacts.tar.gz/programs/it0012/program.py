# EVOLVE-BLOCK-START
"""Target-residual fit with a dual preference: perfect fits and good setup residuals."""
import numpy as np

_TARGET = 33.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Steer toward a target residual that sets up good future placements.
    residual_penalty = -np.abs(leftover - _TARGET)

    return exact_bonus + tight_bonus + residual_penalty
# EVOLVE-BLOCK-END

