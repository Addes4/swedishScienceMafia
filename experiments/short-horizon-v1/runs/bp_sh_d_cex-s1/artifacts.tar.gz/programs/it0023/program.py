# EVOLVE-BLOCK-START
"""Target-residual fit with a Best-Fit blend on long streams."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    base = exact_bonus + tight_bonus - np.abs(leftover - _TARGET)

    # On long streams (many candidate bins), the array is large; blend in a mild Best-Fit
    # tendency so the fullest fitting bin is modestly preferred, which improves packing density
    # without disturbing the short-stream behavior where near-exact fits dominate.
    if bins.shape[0] > 40:
        base = base - leftover * 0.5
    return base
# EVOLVE-BLOCK-END

