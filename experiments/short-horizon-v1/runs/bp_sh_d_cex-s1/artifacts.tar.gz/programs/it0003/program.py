# EVOLVE-BLOCK-START
"""Adaptive target-residual fit: target scales with item size, with strong best-fit bias."""
import numpy as np

_ALPHA = 0.55


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Target residual scales with the item size: larger items prefer leaving a moderate
    # residual so that they don't waste a large bin, small items prefer tight fits.
    target = _ALPHA * item

    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Prefer small positive leftovers (best fit) but steer toward the adaptive target.
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
