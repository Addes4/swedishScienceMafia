# EVOLVE-BLOCK-START
"""Best-Fit with strong exact/tight-fit bonuses."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Among non-tight bins, prefer the smallest leftover (Best-Fit), scaled above the residual noise.
    best_fit = -leftover
    return exact_bonus + tight_bonus + best_fit
# EVOLVE-BLOCK-END
