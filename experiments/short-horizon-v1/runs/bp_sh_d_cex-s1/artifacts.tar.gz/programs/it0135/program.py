# EVOLVE-BLOCK-START
"""Target-residual fit with a soft best-fit plus headroom preference."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Base rule preserved: closest leftover to the target residual.
    base = -np.abs(leftover - _TARGET)

    # Soft best-fit: prefer smaller leftovers, but only mildly, and only when the bin
    # would be left unable to comfortably take another typical item (leftover < item).
    soft_best_fit = -0.05 * np.where(leftover < item, leftover, 0.0)

    return exact_bonus + tight_bonus + base + soft_best_fit
# EVOLVE-BLOCK-END
