# EVOLVE-BLOCK-START
"""Target-residual fit with an adaptive target based on observed item sizes."""
import numpy as np

# Running estimate of item size statistics (per stream, reset implicitly by re-import).
_state = {"n": 0, "mean": 30.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state
    st["n"] += 1
    # Exponentially weighted mean item size, initialized at a reasonable prior.
    alpha = 1.0 / min(st["n"], 200.0)
    st["mean"] = (1.0 - alpha) * st["mean"] + alpha * float(item)

    target = 0.5 * st["mean"] + 5.0

    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
