# EVOLVE-BLOCK-START
"""Quadratic target-residual fit: prefer bins whose leftover after placement is close to a target."""
import numpy as np

_TARGET = 30.0
_LAMBDA = 0.05


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    # Quadratic residual penalty: sharper preference for residuals near the target than |x-target|.
    return exact_bonus + tight_bonus - _LAMBDA * (leftover - _TARGET) ** 2
# EVOLVE-BLOCK-END

