# EVOLVE-BLOCK-START
"""Target-residual fit with a squandered-capacity tiebreaker among non-tight bins."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Secondary signal: among non-tight bins, prefer placements that minimize the squared
    # leftover relative to the remaining capacity, which discourages leaving awkward gaps.
    leftover_f = leftover.astype(np.float64)
    squander = -(leftover_f * leftover_f) / (bins.astype(np.float64) + 1.0)

    return exact_bonus + tight_bonus + 0.25 * squander - np.abs(leftover - _TARGET)
# EVOLVE-BLOCK-END
