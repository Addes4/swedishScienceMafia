# EVOLVE-BLOCK-START
"""Target-residual fit: prefer bins whose leftover after placement is closest to a target."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    # Graduated bonus: strongest for a perfect fit, tapering off as leftover grows.
    tight_bonus = np.exp(-leftover / 3.0) * 2000.0
    return exact_bonus + tight_bonus - np.abs(leftover - _TARGET)
# EVOLVE-BLOCK-END

