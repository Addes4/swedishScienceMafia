# EVOLVE-BLOCK-START
"""Target-residual fit: steer leftovers toward a target, with a best-fit nudge and exact-fit bonus."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits; preserve strong behavior on short streams.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Prefer residuals near the target, and among those nudge toward the tightest fit.
    target_term = -np.abs(leftover - _TARGET)
    best_fit_nudge = -0.05 * leftover

    return exact_bonus + tight_bonus + target_term + best_fit_nudge
# EVOLVE-BLOCK-END
