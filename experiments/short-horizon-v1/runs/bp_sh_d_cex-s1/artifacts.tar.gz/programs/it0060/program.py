# EVOLVE-BLOCK-START
"""Best-Fit dominance with a soft bonus for residuals matching a running item-size estimate."""
import numpy as np

_alpha = 0.02
_state = {"mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update running estimate of the mean item size (proxy for likely residual).
    _state["mean"] = (1.0 - _alpha) * _state["mean"] + _alpha * float(item)
    mu = _state["mean"]

    leftover = bins - item

    # Dominant term: strongly prefer exact fits, then Best-Fit (smallest leftover).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    best_fit = -leftover.astype(np.float64)

    # Soft preference for leaving a residual close to the running mean item size.
    residual_bonus = -np.abs(leftover.astype(np.float64) - mu)

    return exact_bonus + best_fit + residual_bonus
# EVOLVE-BLOCK-END
