# EVOLVE-BLOCK-START
"""Best-fit core: rank bins by leftover after placement, smoothly (concave) decreasing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item
    # Concave, strictly decreasing in leftover: best-fit dominates, ties broken smoothly.
    return -np.log1p(leftover)
# EVOLVE-BLOCK-END

