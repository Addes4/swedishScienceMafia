# EVOLVE-BLOCK-START
"""Target-residual fit plus an online pair-fit estimate of future exact fills."""
import numpy as np

_TARGET = 30.0
_SIGMA = 4.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Online estimate of the item-size distribution from past items (stored on the function).
    hist = getattr(priority, "_hist", None)
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        hist[1:] = 1.0  # mild uniform prior over plausible sizes 1..100
        priority._hist = hist
    n = getattr(priority, "_n", 0)

    # Kernel density estimate p(leftover) = probability a future item exactly fills this bin.
    lv = np.clip(np.round(leftover).astype(np.int64), 0, 100)
    xs = np.arange(101)
    # Cheap Gaussian kernel weights, reused for all bins.
    w = np.exp(-0.5 * ((xs[:, None] - xs[None, :]) / _SIGMA) ** 2)
    p = (w @ hist) / max(hist.sum(), 1.0)
    pair_bonus = p[lv] * 300.0
    pair_bonus = np.where(leftover < 0, 0.0, pair_bonus)

    score = exact_bonus + tight_bonus + pair_bonus - np.abs(leftover - _TARGET)

    # Update the estimate with the current item (deferred: only past items influence scoring).
    hist[item] += 1.0
    priority._hist = hist
    priority._n = n + 1

    return score
# EVOLVE-BLOCK-END

