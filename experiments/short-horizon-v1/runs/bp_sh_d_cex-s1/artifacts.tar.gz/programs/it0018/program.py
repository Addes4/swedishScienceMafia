# EVOLVE-BLOCK-START
"""Best-fit with an explicit exact-fit bonus: prefer the tightest bin that still fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Exact fit is always best; then prefer the smallest leftover (best fit / tightest bin).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    return exact_bonus - leftover
# EVOLVE-BLOCK-END
