# EVOLVE-BLOCK-START
"""Best-fit with a soft leftover floor: prefer bins whose leftover stays at least one item's worth when possible."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Soft "at least one more item's worth" preference: peak near leftover == item,
    # gently favoring leftovers a bit above item and mildly penalizing below.
    scaled = leftover / max(item, 1)
    soft = -np.abs(np.log(np.clip(scaled, 1e-6, None)))
    soft = np.where(leftover >= item, soft + 0.5, soft - 0.5)

    return exact_bonus + tight_bonus + soft - np.abs(leftover - 30.0) * 0.01
# EVOLVE-BLOCK-END

