# EVOLVE-BLOCK-START
"""Hybrid fit: exact-fit bonus, plus prefer bins that can still take a typical item."""
import numpy as np

_TARGET_SHORT = 30.0
_WARMUP = 35

_count = 0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum

    leftover = bins - item

    # Adapt the target residual to the running mean item size; fall back to a fixed
    # short-stream target until enough items have been observed.
    if _count < _WARMUP:
        target = _TARGET_SHORT
    else:
        target = _sum / _count

    _count += 1
    _sum += item

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Among general bins, prefer those that can still accept a typical next item
    # (leftover >= target): reward them, and among them minimize leftover.
    can_fit_typical = leftover >= target
    typical_bonus = np.where(can_fit_typical, 500.0 - np.abs(leftover - target), 0.0)
    # Best-fit among tight bins (leftover < target): prefer smallest leftover.
    tight_fit = np.where(can_fit_typical, 0.0, -leftover)

    return exact_bonus + tight_bonus + typical_bonus + tight_fit
# EVOLVE-BLOCK-END
