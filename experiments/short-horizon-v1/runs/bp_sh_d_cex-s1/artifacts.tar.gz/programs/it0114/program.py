# EVOLVE-BLOCK-START
"""Probability-aware bin choice: maximize the chance the post-placement leftover equals a future item."""
import numpy as np

_TARGET = 30.0
# Empirical item-size histogram (1..100) updated online; starts uniform.
_counts = np.ones(101) * 0.05
_total = float(_counts.sum())


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _counts, _total
    # Update running estimate of the item-size distribution.
    _counts[item] += 1.0
    _total += 1.0
    prob = _counts / _total  # prob[s] = P(next item = s)

    leftover = bins - item

    # Exact fill now is best.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    # Reward leftovers that are likely to be exactly matched by a future item.
    # prob_match[leftover] = P(some future single item == leftover)
    idx = np.clip(leftover, 0, 100).astype(np.int64)
    prob_match = prob[idx]
    # Slight push toward tighter fills when no exact match is expected.
    return exact_bonus + prob_match * 1e3 - np.abs(leftover - _TARGET) * 0.01
# EVOLVE-BLOCK-END

