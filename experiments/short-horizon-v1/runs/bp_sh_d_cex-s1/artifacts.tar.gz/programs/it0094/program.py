# EVOLVE-BLOCK-START
"""Target-residual fit with a tie-breaking partner-fit preference."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Primary rule: strongly reward near-perfect fits, otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    primary = exact_bonus + tight_bonus - np.abs(leftover - _TARGET)

    # Secondary tie-breaker: among (near-)equal primary scores, prefer leftover == item size,
    # anticipating a same-size partner to fill the bin. Scaled tiny so it never overrides primary.
    partner = -np.abs(leftover - item)

    return primary + partner * 1e-3
# EVOLVE-BLOCK-END
