# EVOLVE-BLOCK-START
"""Target-residual fit with an item-scaled leftover target plus exact/tight bonuses."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), preserving short-stream behavior.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Item-scaled target residual: leaving a leftover proportional to the item size
    # tends to pack bins tightly on long streams while staying near-perfect on short ones.
    target = 0.5 * item
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
