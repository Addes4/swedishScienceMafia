# EVOLVE-BLOCK-START
"""Best-Fit with small exact-fit reinforcement: choose the fullest bin the item fits in."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Primary: strict best-fit ranking (smallest leftover scored highest).
    score = -leftover.astype(np.float64)

    # Reinforce exact fits (redundant with best-fit but harmless and tie-safe).
    score += np.where(leftover == 0, 1e-3, 0.0)
    return score
# EVOLVE-BLOCK-END

