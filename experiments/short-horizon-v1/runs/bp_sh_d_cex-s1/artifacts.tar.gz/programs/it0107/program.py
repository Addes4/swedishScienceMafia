# EVOLVE-BLOCK-START
"""Target-residual fit: prefer bins whose leftover after placement is closest to a target,
where the target tracks the running mean item size via an exponential moving average."""
import numpy as np

_ALPHA = 0.05
_state = {"mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Maintain a running mean of item sizes (adapts to the actual distribution).
    _state["mean"] += _ALPHA * (item - _state["mean"])
    target = _state["mean"]

    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers); otherwise steer toward target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
