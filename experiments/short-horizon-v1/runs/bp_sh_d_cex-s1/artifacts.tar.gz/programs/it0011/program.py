# EVOLVE-BLOCK-START
"""Adaptive target-residual fit with exact-fit bonus and anti-fragmentation bias."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update running mean of observed items.
    _state["sum"] += item
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]

    leftover = bins - item

    # Target residual: half the running mean item size (self-tuning).
    target = 0.5 * mean

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Steer toward target residual, with a mild bias toward fuller bins (smaller bins).
    residual_term = -np.abs(leftover - target)
    full_bias = -0.05 * bins

    return exact_bonus + tight_bonus + residual_term + full_bias
# EVOLVE-BLOCK-END

