# EVOLVE-BLOCK-START
"""Best-fit: choose the bin leaving the smallest non-negative residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item  # all >= 0 since bins is pre-filtered to fitting bins

    # Primary objective: minimize the leftover (tightest fit).
    # Use a steep negative slope so best-fit dominates, exactly filling is the extreme case.
    score = -leftover.astype(np.float64)

    # Small deterministic nudge: on equal leftover prefer the earlier (fuller) bin,
    # which slightly favors consolidating fill and avoids scattering equal fits.
    score -= 1e-6 * np.arange(bins.shape[0], dtype=np.float64)

    return score
# EVOLVE-BLOCK-END
