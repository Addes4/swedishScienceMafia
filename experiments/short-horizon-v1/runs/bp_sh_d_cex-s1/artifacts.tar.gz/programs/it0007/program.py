# EVOLVE-BLOCK-START
"""Target-residual fit with an adaptive target based on running item statistics."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update running mean of past items (online, Welford-style).
    _state.n += 1
    delta = item - _state.mean
    _state.mean += delta / _state.n

    # Adaptive target residual: a fraction of the running mean item size.
    target = 0.75 * _state.mean

    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
