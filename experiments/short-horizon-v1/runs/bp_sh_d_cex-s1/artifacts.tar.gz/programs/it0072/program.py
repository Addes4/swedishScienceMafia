# EVOLVE-BLOCK-START
"""Concave best-fit: minimize leftover, with extra pull toward near-exact fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Dominant reward for near-exact fits (small leftovers), ramping up sharply as leftover -> 0.
    exact_bonus = np.where(leftover == 0, 1e7, 0.0)
    tight_bonus = np.maximum(0.0, 4.0 - leftover) * 2000.0

    # Best-fit flavor: concave, monotone-decreasing penalty on the leftover so smaller is better,
    # but the gaps between large residuals are compressed (smooths discrimination near the top).
    base = -np.sqrt(np.maximum(leftover, 0.0))

    return exact_bonus + tight_bonus + base
# EVOLVE-BLOCK-END

