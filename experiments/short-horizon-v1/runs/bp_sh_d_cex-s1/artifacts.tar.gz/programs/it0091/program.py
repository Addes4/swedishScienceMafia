# EVOLVE-BLOCK-START
"""Target-residual fit: prefer bins whose leftover after placement is closest to a target."""
import numpy as np

_TARGET = 30.0
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    s = _state
    s["n"] += 1
    s["sum"] += item
    mean = s["sum"] / s["n"]
    # Blend toward the running mean as more items are observed, stay near default early.
    w = s["n"] / (s["n"] + 100.0)
    target = (1.0 - w) * _TARGET + w * mean

    leftover = bins - item

    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END

