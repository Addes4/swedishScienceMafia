# EVOLVE-BLOCK-START
"""Adaptive best-fit with exact-fit dominance and fragmentation-aware residual target."""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update running mean of item sizes (online statistic).
    _state["sum"] += float(item)
    _state["count"] += 1
    mean = _state["sum"] / _state["count"]
    target = 0.5 * mean

    leftover = bins - item

    # Dominant: exact fits and very tight fits.
    exact_bonus = np.where(leftover == 0, 1e7, 0.0)
    tight_bonus = np.maximum(0.0, 3.0 - leftover) * 10000.0

    # Secondary: steer toward a residual near half the mean item size,
    # which balances repacking opportunities on Weibull-shaped tails.
    shape_penalty = np.abs(leftover - target)

    return exact_bonus + tight_bonus - shape_penalty
# EVOLVE-BLOCK-END
