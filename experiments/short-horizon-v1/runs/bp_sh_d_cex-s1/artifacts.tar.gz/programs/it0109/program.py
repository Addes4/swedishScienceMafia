# EVOLVE-BLOCK-START
"""Best-fit style: reward small positive leftovers over wasteful ones, keep exact/tight bonuses."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Best-fit-decreasing flavor: among non-tight options, prefer the smallest leftover
    # so that remaining gaps stay fillable by future (smaller) items.
    return exact_bonus + tight_bonus - leftover
# EVOLVE-BLOCK-END

