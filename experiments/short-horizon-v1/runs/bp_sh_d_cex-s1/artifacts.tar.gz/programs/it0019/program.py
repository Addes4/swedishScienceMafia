# EVOLVE-BLOCK-START
"""Best-fit rule: prefer the fullest bin the item still fits in, with a mild residual steer."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _mean, _count

    # Running estimate of the mean item size (initialized to the known ~40 mean).
    _count += 1
    _mean += (item - _mean) / _count

    leftover = bins - item

    # Primary: best-fit (most negative leftover = fullest bin that fits).
    # Secondary: steer residual toward the running mean so future items slot in.
    return -leftover - 1e-3 * np.abs(leftover - _mean)
# EVOLVE-BLOCK-END

