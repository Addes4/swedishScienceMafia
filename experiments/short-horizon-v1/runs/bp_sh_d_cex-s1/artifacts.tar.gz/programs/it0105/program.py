# EVOLVE-BLOCK-START
"""Hybrid: exact/tight-fit bonuses plus leftover steered toward the running mean item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Running mean of item sizes seen so far (this instance), used as the residual target.
    if not hasattr(priority, "sum_items"):
        priority.sum_items = 0.0
        priority.count = 0
    priority.sum_items += float(item)
    priority.count += 1
    mean_item = priority.sum_items / priority.count
    target = float(np.clip(mean_item, 1.0, 100.0))

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END

