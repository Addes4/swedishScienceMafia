# EVOLVE-BLOCK-START
"""Target-residual fit with a mild best-fit quantization tie-break."""
import numpy as np

_TARGET = 30.0
_QUANT = 8.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Coarse distance to target: residuals within the same bucket are treated as equal,
    # so a mild best-fit nudge can act as a tie-break inside a bucket.
    coarse = np.floor(np.abs(leftover - _TARGET) / _QUANT) * _QUANT
    fit = -coarse

    # Mild best-fit nudge: prefer the fuller bin (smaller leftover) within a bucket.
    bestfit = -0.5 * leftover

    return exact_bonus + tight_bonus + fit + bestfit
# EVOLVE-BLOCK-END
