# EVOLVE-BLOCK-START
"""Best-fit with dominant exact/tight-fit bonuses for short streams."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Dominant rewards for near-perfect fits.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Best-fit: prefer the smallest leftover after placement.
    return exact_bonus + tight_bonus - leftover
# EVOLVE-BLOCK-END
