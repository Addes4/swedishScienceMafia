# EVOLVE-BLOCK-START
"""Target-residual fit: prefer bins whose leftover after placement is closest to a target."""
import numpy as np

# Running state for an adaptive target residual.
_sum = 0.0
_count = 0
_TARGET_INIT = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _sum, _count

    # Adaptive target: aim to leave a residual near the running mean item size.
    if _count > 0:
        target = _sum / _count
    else:
        target = _TARGET_INIT

    leftover = bins - item

    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    score = exact_bonus + tight_bonus - np.abs(leftover - target)

    # Update running mean with the current item (seen only after scoring).
    _sum += item
    _count += 1

    return score
# EVOLVE-BLOCK-END
