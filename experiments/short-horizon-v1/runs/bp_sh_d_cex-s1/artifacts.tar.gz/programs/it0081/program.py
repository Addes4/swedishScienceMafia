# EVOLVE-BLOCK-START
"""Best-Fit with exact/tight bonuses plus a same-size pairing steer."""
import numpy as np

_MEAN_ITEM = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Dominant bonuses: exact fits and very tight fits should always win.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Best-fit: prefer the smallest non-negative leftover (reduces fragmentation).
    best_fit = -leftover.astype(np.float64)

    # Pairing steer: reward leaving a leftover equal to the arriving item's size,
    # so a future same-sized item can complete the bin to 100.
    pair_bonus = np.where(leftover == item, 2.0, 0.0)

    return exact_bonus + tight_bonus + best_fit + pair_bonus
# EVOLVE-BLOCK-END
