# EVOLVE-BLOCK-START
"""Target-residual fit: prefer bins whose leftover after placement is closest to a target."""
import numpy as np

_TARGET = 30.0
_MEAN = 40.0
_ALPHA = 0.02


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    state = priority.state
    if state['n']:
        state['mean'] += _ALPHA * (item - state['mean'])
    else:
        state['mean'] = float(item)
        state['n'] = 1
    target = state['mean']

    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)


priority.state = {'n': 0, 'mean': _MEAN}
# EVOLVE-BLOCK-END
