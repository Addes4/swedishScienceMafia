# EVOLVE-BLOCK-START
"""Target-residual fit with an adaptive target learned from the running mean item size."""
import numpy as np

# Fallback target if we have no history yet (close to the mean item size ~40 * 0.75).
_DEFAULT_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Adaptive target: a fraction of the running mean item size, so the residual target
    # self-tunes to the actual distribution as the stream progresses.
    state = priority.state
    n, total = state
    mean_item = (total / n) if n > 0 else 0.0
    target = 0.75 * mean_item if mean_item > 0.0 else _DEFAULT_TARGET

    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers); large constant keeps short
    # streams behaving near-optimally while the target shapes long-stream packing.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - np.maximum(leftover, 0.0)) * 1000.0
    score = exact_bonus + tight_bonus - np.abs(leftover - target)

    # Update running statistics of placed items.
    state[0] = n + 1
    state[1] = total + item
    return score


priority.state = [0, 0.0]
# EVOLVE-BLOCK-END
