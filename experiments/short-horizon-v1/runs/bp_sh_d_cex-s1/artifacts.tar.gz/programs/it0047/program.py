# EVOLVE-BLOCK-START
"""Target-residual fit with a Best-Fit tie-breaker among far-from-exact placements."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Primary signal: prefer leftovers close to target; secondary: smaller leftover (Best-Fit).
    return exact_bonus + tight_bonus - 10.0 * np.abs(leftover - _TARGET) - leftover
# EVOLVE-BLOCK-END
