# EVOLVE-BLOCK-START
"""Best-Fit with an adaptive residual-matching tiebreak."""
import numpy as np

# Running statistics of the item stream (reset per stream via module reload in harness).
_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Update running mean item size.
    _state["sum"] += item
    _state["n"] += 1
    mean_item = _state["sum"] / _state["n"]

    # Strong bonus for exact fits, and a smaller bonus for near-perfect fits.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Primary: Best-Fit -- strongly prefer the smallest nonnegative leftover.
    best_fit = -leftover

    # Secondary: steer leftover toward the running mean item size so future items
    # can still fit well (mild, so it never overrides the bonuses).
    target = mean_item
    residual_penalty = -np.abs(leftover - target) * 0.01

    return exact_bonus + tight_bonus + best_fit + residual_penalty
# EVOLVE-BLOCK-END
