# EVOLVE-BLOCK-START
"""Target-residual fit: prefer bins whose leftover after placement is closest to a target."""
import numpy as np

_sum = 0.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _sum, _count

    leftover = bins - item

    # Adaptive target: a fraction of the running mean item size (Weibull, mean ~40).
    if _count >= 8:
        mean_item = _sum / _count
    else:
        mean_item = 40.0
    target = 0.75 * mean_item

    _sum += item
    _count += 1

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
