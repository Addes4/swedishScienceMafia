# EVOLVE-BLOCK-START
"""Prefer bins whose leftover after placement is at a favorable gap for the item distribution."""
import numpy as np

_HALF = 20.0
_PERIOD = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Steer toward leftovers that are a near-multiple of the typical item size,
    # preferring a residual near half the mean item so bins can be completed later.
    res = np.mod(leftover - _HALF + _PERIOD * 0.5, _PERIOD) - _PERIOD * 0.5
    gap_term = -np.abs(res)

    return exact_bonus + tight_bonus + gap_term
# EVOLVE-BLOCK-END
