# EVOLVE-BLOCK-START
"""Target-residual fit with recency tie-breaking among equal residuals."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Small index-based tie-break: favor later (more recently opened) bins slightly,
    # so among equal residuals we consolidate rather than opening/spreading bins.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    tie_break = idx * 1e-3

    return exact_bonus + tight_bonus - np.abs(leftover - _TARGET) + tie_break
# EVOLVE-BLOCK-END

