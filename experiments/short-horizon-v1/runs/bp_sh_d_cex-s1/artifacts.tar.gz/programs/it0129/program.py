# EVOLVE-BLOCK-START
"""Best-fit with exact/tight bonuses and a soft capacity-usage penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers); preserves short-stream behavior.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Soft best-fit: penalize leftover, scaled by item size so packing stays tight but
    # small residuals (which leave room for more items) are mildly preferred over larger ones.
    penalty = leftover * (1.0 + leftover / (item * 4.0))

    return exact_bonus + tight_bonus - penalty
# EVOLVE-BLOCK-END

