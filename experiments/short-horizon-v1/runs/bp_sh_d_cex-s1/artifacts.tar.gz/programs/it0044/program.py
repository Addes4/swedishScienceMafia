# EVOLVE-BLOCK-START
"""Target-residual fit with a running-mean complement preference."""
import numpy as np

_TARGET = 30.0
_state = {"sum": 0.0, "count": 0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update running mean of past items (used as an estimate of a typical future item).
    s = _state
    s["sum"] += item
    s["count"] += 1
    s["mean"] = s["sum"] / s["count"]

    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward a target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Prefer a leftover close to a typical item size so a later item can fill the bin well.
    complement = -np.abs(leftover - s["mean"]) * 0.5

    return exact_bonus + tight_bonus + complement - np.abs(leftover - _TARGET)
# EVOLVE-BLOCK-END

