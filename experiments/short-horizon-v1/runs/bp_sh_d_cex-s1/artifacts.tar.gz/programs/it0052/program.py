# EVOLVE-BLOCK-START
"""Best-Fit: choose the fullest bin the item still fits in (smallest leftover)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Primary term: strongly prefer smaller leftover (fuller bin). The tiny tick
    # keeps it a strict, near-monotone Best-Fit ranking without overflow.
    return -leftover
# EVOLVE-BLOCK-END

