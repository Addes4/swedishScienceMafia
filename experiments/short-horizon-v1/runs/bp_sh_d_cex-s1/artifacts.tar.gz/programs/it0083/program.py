# EVOLVE-BLOCK-START
"""Target-residual fit with an average-item partner tie-breaker."""
import numpy as np

_TARGET = 30.0
_MEAN0 = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers); these dominate so short
    # streams behave exactly as before.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Base steer: distance to the target residual.
    base = -np.abs(leftover - _TARGET)

    # Tie-break only among non-tight bins: gently reward leaving room for roughly
    # one more average-sized item (bins tend to fill toward ~80/100), and a similar
    # bonus for a near-zero leftover that is not exactly zero.
    # Keep magnitude small so it cannot overturn exact/tight bonuses.
    small = 1.0 - np.minimum(1.0, np.abs(leftover - _MEAN0) / _MEAN0)
    return exact_bonus + tight_bonus + base + 0.5 * small
# EVOLVE-BLOCK-END
