# EVOLVE-BLOCK-START
"""Target-residual fit with exact/tight bonuses, tuned for both short and long streams."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers); dominant so short streams are preserved.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Secondary steer: prefer leaving a small, "fillable" residual; concave reward centered low.
    # Also mildly prefer fuller bins (deeper placement) to consolidate long streams.
    fill_reward = 1.0 / (1.0 + leftover) * 50.0
    depth_reward = (100.0 - bins) * 0.02

    return exact_bonus + tight_bonus + fill_reward + depth_reward
# EVOLVE-BLOCK-END
