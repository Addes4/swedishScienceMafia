# EVOLVE-BLOCK-START
"""Target-residual fit: prefer bins whose leftover after placement is closest to a target."""
import numpy as np

_MEAN0 = 40.0
_ALPHA = 0.02


class _State:
    mean = _MEAN0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    target = _state.mean
    score = exact_bonus + tight_bonus - np.abs(leftover - target)

    # update running mean toward observed item sizes
    _state.mean += _ALPHA * (item - _state.mean)

    return score
# EVOLVE-BLOCK-END

