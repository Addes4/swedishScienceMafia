# EVOLVE-BLOCK-START
"""Best-Fit core with a fit-future bonus based on observed item-size frequencies."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Fit-future bonus: prefer leftovers that are likely future item sizes (~40 mean).
    # Soft bias toward residual near 40 (mode of Weibull-ish distribution) reduces fragmentation.
    future = np.exp(-((leftover - 40.0) ** 2) / (2 * 15.0 ** 2)) * 3.0

    # Core monotone Best-Fit bias: smaller leftover is better.
    return exact_bonus + tight_bonus + future - leftover * 0.01
# EVOLVE-BLOCK-END
