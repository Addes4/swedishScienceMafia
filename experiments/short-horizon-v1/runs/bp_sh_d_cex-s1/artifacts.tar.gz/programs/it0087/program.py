# EVOLVE-BLOCK-START
"""Target-residual fit with an item-size partner tie-breaker among non-tight bins."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Primary non-tight steer: closeness to the fixed residual target.
    base = -np.abs(leftover - _TARGET)

    # Secondary tie-breaker among non-tight bins: prefer a leftover equal to the
    # current item size (an equal-sized partner would fill the bin exactly).
    partner = -np.abs(np.maximum(leftover, 0.0) - item) * 0.01

    return exact_bonus + tight_bonus + base + partner
# EVOLVE-BLOCK-END
