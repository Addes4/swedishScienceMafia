# EVOLVE-BLOCK-START
"""Adaptive target-residual fit: target residual scales with the observed mean item size."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update running mean of item sizes seen so far.
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]
    # Target residual proportional to the running mean (self-tuning), bounded.
    target = 0.5 * mean_item
    if target < 5.0:
        target = 5.0
    elif target > 35.0:
        target = 35.0

    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers).
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END

