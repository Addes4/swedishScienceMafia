# EVOLVE-BLOCK-START
"""Adaptive target-residual fit: prefer bins whose leftover after placement is closest to a
target proportional to the running mean of observed items."""
import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.mean = 40.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update running mean of past items (Welford-style incremental mean).
    s = _state
    s.count += 1
    s.mean += (item - s.mean) / s.count

    target = 0.5 * s.mean

    leftover = bins - item

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward the target residual.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END

