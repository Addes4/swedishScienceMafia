# EVOLVE-BLOCK-START
"""Best fit with a tie-breaking "worst fit" bias for larger items.

Pure best fit packs tightly, but on heavy-tailed item sizes it can fragment
bins that are already fairly full, leaving small unusable gaps. A common
improvement is to combine best fit with a mild preference for fuller/emptier
bins depending on how large the item is.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest score.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    # Best-fit component: prefer bins whose residual capacity after placing
    # the item is smallest (i.e. tightest fit). This dominates.
    tightness = -(bins - item)

    # Fragmentation guard: if putting the item leaves a very small residual
    # (< some threshold), reward it slightly more; if the item is large and
    # the bin is nearly full, avoid overfilling to reduce leftover gaps.
    residual = bins - item

    # Mild bonus for residuals that are either near-zero (perfect fit) or
    # that leave a bin comfortably open, penalizing mid-size gaps.
    # Scale small relative to tightness so best-fit ordering is preserved
    # except among near-equal residuals.
    bonus = np.where(residual == 0, 1e6,
                     np.where(residual <= 2, 100.0,
                              -np.minimum(residual, 20) * 0.001))
    return tightness + bonus
# EVOLVE-BLOCK-END
