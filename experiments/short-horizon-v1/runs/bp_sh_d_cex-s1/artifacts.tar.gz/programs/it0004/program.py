# EVOLVE-BLOCK-START
"""Best-fit with a near-half-item target only when no very tight fit exists."""
import numpy as np

_NEW_BIN = 100.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Best-fit: strongly prefer the smallest leftover, but not super-tightly so
    # that exact fits dominate cleanly.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    # Prefer tight fits. Score decreases with leftover.
    base = -leftover.astype(np.float64)
    # Extra push for leftovers below half the item on the margin.
    tight_bonus = np.maximum(0.0, 20.0 - leftover) * 10.0
    return exact_bonus + base + tight_bonus
# EVOLVE-BLOCK-END
