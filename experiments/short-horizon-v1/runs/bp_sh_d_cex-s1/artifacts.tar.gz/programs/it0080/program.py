# EVOLVE-BLOCK-START
"""Best-Fit scaling: tighten exact-fit priority while gently steering to mean-sized residuals."""
import numpy as np

_TARGET = 30.0
_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _state["sum"] += float(item)
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]

    leftover = bins - item

    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Best-fit-flavored: smaller leftover is better (negative leftover), gentle scale.
    bestfit = -leftover * 0.05

    # Steer toward residuals near the running mean item size (fills bins with ~2 items).
    steer = -np.abs(leftover - mean) * 0.5

    # Tiny extra push for residuals just under the mean (leaves room for a mean-sized item).
    under = np.where((leftover >= 0) & (leftover <= mean), (mean - leftover) * 0.3, 0.0)

    return exact_bonus + tight_bonus + bestfit + steer + under
# EVOLVE-BLOCK-END
