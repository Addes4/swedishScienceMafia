# EVOLVE-BLOCK-START
"""Adaptive target-residual fit: target scales with the number of candidate bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item
    n = bins.size

    # Target residual: ~30 when few bins compete (short streams), drifting toward ~40
    # when many bins are available (long streams), matching the mean item size.
    target = 30.0 + 10.0 * (1.0 - np.exp(-(n - 1) / 8.0))

    # Strongly reward near-perfect fits (small leftovers), otherwise steer toward the target.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
