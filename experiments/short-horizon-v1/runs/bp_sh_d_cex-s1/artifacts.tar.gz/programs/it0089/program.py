# EVOLVE-BLOCK-START
"""Target-residual fit with a dimension-aware, gradually-learned target."""
import numpy as np

_TARGET = 30.0  # stable default before enough items are seen


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Maintain a running mean of item sizes across this stream.
    state = priority.__dict__
    n = state.get("n", 0)
    total = state.get("total", 0.0)
    total += item
    n += 1
    state["n"] = n
    state["total"] = total
    mean_item = total / n

    # Trust the dynamic target only as observations accumulate; start at the stable default.
    w = min(1.0, n / 20.0)
    target = w * mean_item + (1.0 - w) * _TARGET

    leftover = bins - item

    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    return exact_bonus + tight_bonus - np.abs(leftover - target)
# EVOLVE-BLOCK-END
