# EVOLVE-BLOCK-START
"""Target-residual fit: prefer bins whose leftover after placement is closest to a target."""
import numpy as np

_TARGET = 30.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Smooth, saturating reward for small leftovers; peaks at zero without a huge constant.
    fit_reward = 1000.0 / (1.0 + np.abs(leftover))
    return fit_reward - np.abs(leftover - _TARGET)
# EVOLVE-BLOCK-END

