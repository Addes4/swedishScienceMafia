# EVOLVE-BLOCK-START
"""Target-residual fit with a gated best-fit term for long streams."""
import numpy as np

_TARGET = 30.0
_state = {"n": 0}
_GATE = 200  # items before best-fit term activates


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0
    score = exact_bonus + tight_bonus - np.abs(leftover - _TARGET)

    _state["n"] += 1
    if _state["n"] > _GATE:
        # Prefer tight packing among non-perfect fits: penalize leftover quadratically.
        score = score - 0.05 * (leftover.astype(np.float64) ** 2)
    return score
# EVOLVE-BLOCK-END
