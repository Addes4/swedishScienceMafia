# EVOLVE-BLOCK-START
"""Target-residual fit with a small residual-to-average pull for long-stream packing."""
import numpy as np

_TARGET = 30.0
_AVG = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item

    # Dominant: strongly reward exact fits, then very tight fits. Keeps short streams optimal.
    exact_bonus = np.where(leftover == 0, 1e6, 0.0)
    tight_bonus = np.maximum(0.0, 5.0 - leftover) * 1000.0

    # Main steer toward a moderate residual (fragmentation control).
    steer = -np.abs(leftover - _TARGET)

    # Small secondary pull: leaving ~ one average item fits lets a future item fill near-exactly.
    avg_pull = -np.abs(leftover - _AVG) * 0.25

    return exact_bonus + tight_bonus + steer + avg_pull
# EVOLVE-BLOCK-END

