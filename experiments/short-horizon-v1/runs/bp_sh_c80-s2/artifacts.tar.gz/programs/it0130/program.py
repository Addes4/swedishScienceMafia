# EVOLVE-BLOCK-START
"""Best-fit with an adaptive small-residual floor to avoid stranding tiny gaps."""
import numpy as np

_TOTAL = 0
_COUNT = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT

    _TOTAL += item
    _COUNT += 1
    mean = _TOTAL / _COUNT

    residual = bins - item

    # Classic best fit: smallest non-negative residual is best.
    score = -residual.astype(np.float64)

    # Mild penalty for leaving a gap too small to be useful for a typical item:
    # such gaps tend to get stranded, inflating the bin count.
    if _COUNT >= 30:
        floor = 0.30 * mean
        tight_penalty = np.where(residual < floor, (floor - residual) * 2.0, 0.0)
    else:
        floor = 12.0
        tight_penalty = np.where(residual < floor, (floor - residual) * 2.0, 0.0)

    return score - tight_penalty
# EVOLVE-BLOCK-END
