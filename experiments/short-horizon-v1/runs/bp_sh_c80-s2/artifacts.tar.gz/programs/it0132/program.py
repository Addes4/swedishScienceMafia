# EVOLVE-BLOCK-START
"""Residual sweet spot learned from the empirical item distribution."""
import numpy as np

_MAX = 100
_HIST = np.zeros(_MAX + 1, dtype=np.float64)
_TOTAL = 0
_COUNT = 0

# Precompute: for a residual r, estimate expected value of packing it.
# We reward residuals that are likely to be exactly matched (or nearly) by
# a future item, since that yields perfect fills.
_CACHE_MEAN = -1.0
_CACHE_SD = -1.0
_CACHE_TARGET = 0.0


def _recompute_target():
    """Choose the residual sweet spot maximizing expected future matching."""
    global _CACHE_TARGET, _CACHE_MEAN, _CACHE_SD
    n = _COUNT
    mean = _TOTAL / n
    # second moment
    sq = 0.0
    for s in range(1, _MAX + 1):
        sq += _HIST[s] * s * s
    var = max(sq / n - mean * mean, 0.0)
    sd = var ** 0.5
    _CACHE_MEAN = mean
    _CACHE_SD = sd

    # Empirical pmf of item sizes.
    pmf = _HIST / n
    # For each candidate residual r, expected fill quality = sum over items s<=r of
    # (prob of landing exactly near) weighted by how well it fills.
    # Reward r that is exactly hit: score(r) = P(item == r) + 0.5*P(item == r-1).
    # Add a soft term so r has slight preference to be >= mean.
    best_r = 1
    best_v = -1e18
    for r in range(1, _MAX + 1):
        exact = pmf[r] if r <= _MAX else 0.0
        near = pmf[r - 1] if r - 1 >= 0 else 0.0
        v = exact + 0.5 * near
        # mild preference toward a residual near the mean (fills whole bin nicely)
        v += 1e-4 * (-abs(r - mean))
        if v > best_v:
            best_v = v
            best_r = r
    _CACHE_TARGET = float(best_r)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT

    _TOTAL += item
    _COUNT += 1
    _HIST[item] += 1.0

    if _COUNT >= 40 and (_COUNT % 5 == 0 or _CACHE_TARGET == 0.0):
        _recompute_target()

    if _CACHE_TARGET == 0.0:
        target = 38.0
    else:
        target = _CACHE_TARGET

    residual = bins.astype(np.float64) - float(item)

    # Distance from sweet-spot residual; prefer residuals near the learned target.
    score = -np.abs(residual - target)

    # Small completion bonus for near-empty gaps to finish bins.
    tight = np.where((residual >= 0) & (residual <= 3), 100.0 - residual, 0.0)
    return score + tight
# EVOLVE-BLOCK-END
