# EVOLVE-BLOCK-START
"""Target-residual best fit: aim for a post-placement residual near a sweet spot."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Sweet spot near the mean item size (~40) so leftover gaps are likely to be
    # filled by a single later item.
    target = 35.0
    score = -np.abs(residual - target)

    # Strong reward for tight fits, but capped: exact fits and near-exact fits
    # (residual 0..3) all get a huge edge over the target-shaped region, while
    # residuals 4..8 decay so that we still prefer the genuinely tightest fit
    # among those that are close, avoiding wasteful slivers where possible.
    bonus = np.where(residual <= 3, 1e6,
                     np.where(residual <= 8, 1e6 - (residual - 3) * 5e4, 0.0))
    return score + bonus
# EVOLVE-BLOCK-END

