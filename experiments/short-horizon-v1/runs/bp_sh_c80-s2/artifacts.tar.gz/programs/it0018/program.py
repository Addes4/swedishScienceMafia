# EVOLVE-BLOCK-START
"""Capped best-fit with a light residual-reusability tie-break.

Primary rule: best fit (tightest residual), but residual capped at a floor so
that tiny slivers are not preferred over a slightly looser fit. As a secondary
criterion among bins with nearly equal capped residual, prefer residuals that
are more likely to be exactly fillable by future items (residuals near a small
multiple of the running mean item size).
"""
import numpy as np


# Persistent stream statistics (module state, reset externally per stream start
# is not available, so we keep a simple running estimate that self-heals).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins."""
    # Update running item-size estimate.
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    residual = bins - item
    capped = np.minimum(residual, 25)

    # Primary: tighter capped residual is better (negate).
    score = -capped.astype(np.float64)

    # Secondary: among near-equal capped residuals, slightly prefer residuals
    # that are close to a small multiple of the mean item size, since those are
    # more likely to be exactly refilled later. Tiny weight so it only breaks
    # ties / near-ties.
    if mean > 0:
        m = max(1.0, mean)
        # distance from the nearest multiple of m
        dist = np.abs(residual - np.round(residual / m) * m)
        # but never favor non-positive residuals over positive ones:
        dist = np.where(residual <= 0, 0.0, dist)
        score -= (dist / m) * 0.5

    return score
# EVOLVE-BLOCK-END
