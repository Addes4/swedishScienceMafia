# EVOLVE-BLOCK-START
"""Weighted best fit: minimize residual, with a small preference for fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best fit: prefer the tightest fit, but cap the reward for extremely tight
    # fits so unusable slivers aren't strongly preferred. Add a small bonus for
    # using bins that are already partially filled (i.e., not the untouched 100s)
    # which tends to consolidate packing and reduce the number of opened bins.
    tight = -np.minimum(residual, 25)
    fullness = (100 - bins)  # higher for already-used bins
    return tight + 0.02 * fullness
# EVOLVE-BLOCK-END

