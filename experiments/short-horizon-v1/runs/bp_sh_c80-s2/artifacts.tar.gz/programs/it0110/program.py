# EVOLVE-BLOCK-START
"""Target-residual best fit with an adaptive, distribution-shape-aware sweet spot.

The key idea: instead of fixing the target residual from the running mean/std, we
estimate a robust central tendency of the item sizes (a blend of mean and a quick
EMA of recent items) and use it directly as the follow-up size we want room for.
We also keep a soft best-fit completion bonus so near-exact fits win.
"""
import numpy as np

_TOTAL = 0
_COUNT = 0
_EMA = 0.0
_ALPHA = 0.08


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _EMA

    _TOTAL += item
    _COUNT += 1
    # Recency-weighted estimate: reacts to local drifts in the item distribution.
    if _COUNT == 1:
        _EMA = float(item)
    else:
        _EMA += _ALPHA * (float(item) - _EMA)

    mean = _TOTAL / _COUNT
    # Blend global mean with a local EMA; lean on mean early, EMA once warmed up.
    w = min(_COUNT / 60.0, 1.0)
    central = (1.0 - w) * mean + w * (0.5 * mean + 0.5 * _EMA)

    residual = bins - item

    if _COUNT >= 30:
        # We want to leave room for a typical follow-up item.  Slightly below the
        # central size avoids leaving residuals nobody can fill (Weibull is right-skewed).
        target = 0.88 * central
    else:
        target = 36.0

    score = -np.abs(residual - target)

    # Soft completion bonus: reward small residuals with an increasing, smooth slope
    # so exact and near-exact fits are chosen decisively (no hard threshold jump).
    tight = -residual * residual / (1.0 + residual * 0.15) * 60.0

    return score + tight
# EVOLVE-BLOCK-END
