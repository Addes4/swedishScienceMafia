# EVOLVE-BLOCK-START
"""Target-residual best fit with an adaptive sweet spot and soft completion bonus."""
import numpy as np

_TOTAL = 0
_COUNT = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _TOTAL, _COUNT

    _TOTAL += item
    _COUNT += 1
    mean = _TOTAL / _COUNT

    residual = bins - item

    # Sweet spot scaled to the observed mean: aim to leave a gap a typical future
    # item can fill, but stay near the proven value early on.
    target = 0.92 * mean if _COUNT >= 20 else 38.0

    score = -np.abs(residual - target)

    # Soft completion bonus: strongly reward small residuals, decaying with a
    # mean-scaled scale so tight fits get finished without a hard cutoff.
    scale = max(8.0, 0.25 * mean)
    bonus = 2.0e5 * np.exp(-np.maximum(residual, 0.0) / scale)

    return score + bonus
# EVOLVE-BLOCK-END

