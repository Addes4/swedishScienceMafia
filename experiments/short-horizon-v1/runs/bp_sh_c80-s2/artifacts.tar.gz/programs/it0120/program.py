# EVOLVE-BLOCK-START
"""Target-residual best fit with a distribution-derived sweet spot."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    if _COUNT >= 30:
        # Proven target residual: aim to leave a gap a typical item can fill.
        base_target = 0.90 * mean + 0.15 * sd
    else:
        base_target = 38.0

    # For large items, leaving a residual exactly the item's own size enables a
    # same-size pair to complete a bin (100 -> 2*item).  For small items trust
    # the distribution target.  Blend based on how large the item is.
    pair_target = item
    w = min(max((item - mean) / (mean + 1.0), 0.0), 0.5)
    target = (1.0 - w) * base_target + w * np.minimum(pair_target, base_target * 1.6)

    score = -np.abs(residual - target)

    tight = np.where(residual <= 10, 4e4 - residual * 2e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END
