# EVOLVE-BLOCK-START
"""Target-residual best fit with an adaptive sweet spot."""
import numpy as np

_TOTAL = 0
_COUNT = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _TOTAL, _COUNT

    # Running estimate of the item mean (fall back to the known ~40 before warm-up).
    _TOTAL += item
    _COUNT += 1
    mean = _TOTAL / _COUNT

    residual = bins - item

    # Sweet spot scaled to the observed mean: aim to leave a gap a typical future
    # item can fill, but stay near the proven value early on. Slightly lower target
    # keeps bins fuller to reduce unusable leftover space.
    target = 0.85 * mean if _COUNT >= 20 else 34.0

    score = -np.abs(residual - target)

    # Strongly reward near-exact tight fits so full bins get finished.
    tight = np.where(residual <= 8, 1e6 - residual * 1e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END

