# EVOLVE-BLOCK-START
"""Target-residual best fit with a distribution-derived sweet spot, blended with best-fit under pressure."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    if _COUNT >= 30:
        # Target residual: aim to leave a gap a typical item can fill.
        target = 0.90 * mean + 0.15 * sd
    else:
        target = 38.0

    # Base: closeness of residual to the sweet-spot target.
    base = -np.abs(residual - target)

    # Best-fit component: prefer the smallest non-negative residual (tightest bin).
    num_bins = bins.shape[0]
    # pressure in [0,1]: how many bins are open per item placed so far.
    pressure = min(1.0, num_bins / max(_COUNT, 1))

    # Normalize residual to a comparable scale (mean-based) to mix the two terms.
    scale = max(mean, 1.0)
    bestfit = -residual / scale

    # Blend: more pressure -> more weight on tight packing.
    w = 1.5 * pressure
    score = base + w * bestfit

    # Gentle completion bonus: reward small residuals softly.
    tight = np.where(residual <= 10, 4e4 - residual * 2e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END

