# EVOLVE-BLOCK-START
"""Best fit with a residual cap so unusable slivers are not preferred."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Cap small residuals so unusable slivers are not preferred over a slightly
    # looser fit that may still accommodate future items; ties -> earliest bin.
    # Tie-break among equally capped residuals by preferring a slightly larger
    # residual (less tight-but-usable) to keep flexibility, encoded as a tiny
    # secondary term on the true residual.
    capped = -np.minimum(residual, 25)
    return capped - 1e-4 * residual
# EVOLVE-BLOCK-END

