# EVOLVE-BLOCK-START
"""Size-proportional target-residual best fit with a distribution-adapted sweet spot."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0
_MED_EST = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ, _MED_EST

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    # Cheap running median approximation (exponential-ish move toward observed sizes).
    _MED_EST += 0.02 * (item - _MED_EST)
    med = _MED_EST

    residual = bins - item

    # Sweet-spot target: proportional to the current item, blended with the running
    # median of the stream.  A residual near this target leaves room for a typical
    # follow-up item, which balances packing efficiency across the skewed size mix.
    if _COUNT >= 30:
        target = 0.55 * item + 0.35 * med
    else:
        target = 0.55 * item + 14.0

    score = -np.abs(residual - target)

    # Completion bonus: reward small residuals so near-full bins are finished off.
    # Scale relative to the item size so it stays useful for both small and large items.
    window = max(4.0, 0.20 * item)
    tight = np.where(
        residual <= window,
        5e4 - (residual / window) * 4e4,
        0.0,
    )
    return score + tight
# EVOLVE-BLOCK-END

