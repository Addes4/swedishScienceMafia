# EVOLVE-BLOCK-START
"""Best fit with a small tie-break that avoids unusable slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    The dominant term is the tightest fit (minimize residual). A tiny tie-breaking
    bonus prefers residuals large enough to still fit a typical future item, so that
    a barely-usable sliver is not chosen over an equally tight but more useful fit.
    """
    residual = bins - item
    # Dominant: prefer the tightest fit.
    score = -residual.astype(np.float64)
    # Tiny bonus: residuals that are themselves non-trivial (>= 2) are slightly favored
    # because they remain usable for at least the smallest common items.
    score += 1e-3 * (residual >= 2)
    return score
# EVOLVE-BLOCK-END

