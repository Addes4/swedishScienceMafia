# EVOLVE-BLOCK-START
"""Best fit with a soft penalty on tiny residual slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer tight fits (small residual), but softly avoid leaving tiny slivers
    # (residual in 0..~2) that are hard to reuse. Base score is -residual;
    # a smooth term penalizes small positive residuals relative to larger ones.
    r = residual.astype(np.float64)
    penalty = np.exp(-r / 2.0)  # ~1 at r=0, decaying; large for tiny slivers
    # Only penalize slivers (r>0); exact fits (r==0) are best.
    sliver_pen = np.where(r > 0, penalty, 0.0)
    return -r - 20.0 * sliver_pen
# EVOLVE-BLOCK-END
