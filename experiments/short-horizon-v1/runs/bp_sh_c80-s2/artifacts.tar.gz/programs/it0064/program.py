# EVOLVE-BLOCK-START
"""Target-residual best fit with sliver-completion bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: shape the leftover gap toward a sweet spot near the mean item size,
    # so the remaining capacity is likely to be usable by a single later item.
    target = 35.0
    score = -np.abs(residual - target)

    # Sliver completion: strongly prefer finishing a bin whose residual exactly
    # matches a common small item size, so tiny leftovers don't become waste.
    # These bonuses dwarf the base shaping for the relevant residuals.
    exact = np.where(residual == 0, 3.0e6,
             np.where(residual <= 6, 1.5e6,
              np.where(residual <= 8, 5.0e5, 0.0)))
    return score + exact
# EVOLVE-BLOCK-END
