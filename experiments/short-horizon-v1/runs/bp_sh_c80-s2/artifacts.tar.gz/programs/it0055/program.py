# EVOLVE-BLOCK-START
"""Target-residual best fit: aim for a post-placement residual near a sweet spot.

The sweet spot is driven by the empirical mean item size seen so far in the
stream (stateful), so leftover residual gaps are statistically likely to be
filled by a single later item of typical size.
"""
import numpy as np

# Module-level stream state: running sum and count of item sizes seen.
_SUM = 0.0
_COUNT = 0
_PREV = 0  # detect a fresh stream (item stat resets when a huge bin array appears)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _SUM, _COUNT

    # Heuristic stream reset: number of bins cannot exceed items placed so far.
    # On a fresh stream the harness passes a large array of fresh 100s while our
    # count is small; detect that and reset statistics.
    if bins.size > _COUNT + 1 and _COUNT > 0:
        _SUM = 0.0
        _COUNT = 0

    # Empirical mean of past items (fall back to the known distribution mean ~40).
    if _COUNT >= 5:
        mean_item = _SUM / _COUNT
    else:
        mean_item = 40.0

    # Update state with the current item (it arrives now, will be a future item
    # for subsequent calls, so include it).
    _SUM += item
    _COUNT += 1

    # Sweet spot near the typical item size: leftover gaps of this size are
    # likely to be finished by one future item.
    target = mean_item

    residual = bins - item
    # Prefer a residual near the target; tighter fits (residual <= target) are
    # rewarded monotonically via the negative absolute deviation.
    score = -np.abs(residual - target)
    # Strongly reward exact/near-exact tight fits so full bins get finished.
    tight = np.where(residual <= 8, 1e6 - residual * 1e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END
