# EVOLVE-BLOCK-START
"""Target-residual best fit with a distribution-aware fillability bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _total
    try:
        _hist
    except NameError:
        _hist = np.zeros(101, dtype=np.float64)
        _total = 0.0

    residual = bins - item

    # Proven sweet-spot base: residual near ~35 keeps leftover gaps usable.
    target = 35.0
    score = -np.abs(residual - target)

    # Strongly reward tight fits so full bins get finished.
    tight = np.where(residual <= 8, 1e6 - residual * 1e3, 0.0)

    # Distribution-aware fillability bonus: reward residuals whose value is a
    # likely future item size (smoothed estimate from the running histogram).
    # This gently guides gaps toward sizes that can be exactly filled later,
    # without overriding the base sweet-spot preference.
    if _total > 20:
        probs = _hist / _total
        res_idx = np.clip(residual.astype(np.int64), 0, 100)
        fill_bonus = probs[res_idx] * 200.0
    else:
        fill_bonus = 0.0

    result = score + tight + fill_bonus

    # Update histogram with the current item for future calls.
    if 1 <= item <= 100:
        _hist[item] += 1.0
        _total += 1.0

    return result
# EVOLVE-BLOCK-END
