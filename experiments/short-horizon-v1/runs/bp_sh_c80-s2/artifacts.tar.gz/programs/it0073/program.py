# EVOLVE-BLOCK-START
"""Target-residual best fit with an explicit sliver penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Primary term: prefer a residual near a sweet spot (~mean item size) so that
    # leftover gaps are likely filled by a single later item.
    target = 35.0
    score = -np.abs(residual - target)

    # Strongly reward tight fits so nearly-full bins get finished rather than
    # leaving capacity stranded elsewhere.
    tight = np.where(residual <= 10, 1e6 - residual * 1e3, 0.0)

    # Extra penalty for leaving an unusable tiny sliver (worse than a moderate gap).
    sliver = np.where(residual < 5, -(5.0 - residual) * 2.0, 0.0)

    return score + tight + sliver
# EVOLVE-BLOCK-END

