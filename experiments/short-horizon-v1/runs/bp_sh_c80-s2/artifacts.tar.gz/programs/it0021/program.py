# EVOLVE-BLOCK-START
"""Bounded best-fit with a harmonic preference for reusable residuals.

Best fit alone leaves awkward slivers. Here we still prefer tight fits
(negative residual), but cap how much a "too tight" sliver can be preferred,
and gently reward residuals that are likely to be exactly refilled by the
typical item size observed so far.
"""
import numpy as np

# module-level state: running estimate of the mode-ish common item size
_STATE = {"mode_size": 40, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins."""
    # Track a coarse running estimate of the typical (small-ish) item size.
    st = _STATE
    st["count"] += 1
    # exponential-ish update toward the current item size, but only record
    # sizes that are more "typical" (not the occasional huge item)
    if item <= 100:
        # keep a simple running mean of item sizes seen, clipped sensibly
        prev = st["mode_size"]
        st["mode_size"] = prev + (item - prev) / min(st["count"], 100)

    residual = bins - item

    # Primary: prefer tight fits, but cap the advantage of tiny slivers so
    # they are not hoarded over slightly looser fits that future items can use.
    capped = np.minimum(residual, 25)
    score = -capped.astype(np.float64)

    # Secondary: small bonus when the residual is close to a multiple of the
    # running typical item size (a residual that a future item could refill).
    m = max(1.0, float(st["mode_size"]))
    frac = np.abs(residual / m - np.round(residual / m))
    score += 0.01 * (1.0 - frac)

    return score
# EVOLVE-BLOCK-END
