# EVOLVE-BLOCK-START
"""Waste-aware best fit.

Place the item in the bin that fits most tightly, but treat post-placement
residuals that fall in the "no-item-fits" sliver range as if they were a full
waste unit, so tiny unusable leftovers are not created at the cost of a
slightly looser (but still usable) fit.
"""
import numpy as np

# Items are drawn from a Weibull-shaped distribution with mean ~40.
# Residuals below this threshold are likely to be a permanent dead sliver.
_SLIVER = 10


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (100), in bin order.
    """
    residual = bins - item

    # Effective leftover: dead slivers (0 < residual < _SLIVER) are treated as
    # pure waste (equivalent to residual == _SLIVER-1 being "as bad as nothing
    # usable left"), so we avoid manufacturing them. A residual of 0 (perfect
    # fill) stays strictly best.
    eff = np.where((residual > 0) & (residual < _SLIVER),
                   _SLIVER - 1.0,
                   residual)

    # Prefer smaller effective residual (tightest fit).
    return -eff
# EVOLVE-BLOCK-END
