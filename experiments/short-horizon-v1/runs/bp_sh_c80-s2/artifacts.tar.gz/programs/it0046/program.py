# EVOLVE-BLOCK-START
"""Best fit with a mild gap-reuse prior on the resulting residual."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Primary: tightest fit (smallest residual).  Secondary: prefer residuals that
    # look like they could be filled by a typical future item (peak of the
    # Weibull-ish size distribution), which avoids shredding bins into useless
    # tiny slivers that pure best-fit tends to create.
    r = residual.astype(np.float64)
    # reward residuals near common item sizes (~30) a little; keep best-fit dominant
    gap_bonus = 0.02 * np.exp(-((r - 30.0) ** 2) / (2.0 * 12.0 * 12.0))
    return -r + gap_bonus
# EVOLVE-BLOCK-END

