# EVOLVE-BLOCK-START
"""Best fit with a harmonic reward for near-perfect fits.

Score = 1/(residual+1). Maximizing this minimizes the residual, giving best-fit
behaviour, but the reciprocal makes a bin that becomes exactly full (residual 0)
stand out strongly over one leaving a small sliver, encouraging consolidation.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    return 1.0 / (residual + 1.0)
# EVOLVE-BLOCK-END
