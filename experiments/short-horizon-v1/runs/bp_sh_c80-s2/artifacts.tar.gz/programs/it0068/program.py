# EVOLVE-BLOCK-START
"""Target-residual best fit: aim for a post-placement residual near a sweet spot."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Score is highest when the residual lands near a sweet spot (~mean item size),
    # so leftover gaps are likely to be filled exactly by one future item.
    target = 30.0
    score = -np.abs(residual - target)
    # Strongly reward near-exact tight fits so full bins get finished.
    tight = np.where(residual <= 6, 1e6 - residual * 1e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END

