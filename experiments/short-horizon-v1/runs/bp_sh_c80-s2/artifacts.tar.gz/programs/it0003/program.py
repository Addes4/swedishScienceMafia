# EVOLVE-BLOCK-START
"""Best fit with a residual-usability nudge.

Best fit (tightest remaining capacity) is a strong rule for this stream.
The refinement here penalizes residuals that are too small to fit many
items, since a residual just under a common item size is wasted, while a
residual that exactly matches a plausible item is valuable. Since we cannot
know the distribution, we use a smooth, monotone penalty on the post-place
residual r = bins - item: tighter fits (smaller r) are better, but among
similar residuals we slightly prefer ones that are not in the very bottom
range (which can only hold tiny items).
"""
import numpy as np


def priority(item, bins):
    residual = bins - item          # remaining capacity after placing item
    # Base: best fit -> smaller residual is better.
    # Nudge: tiny residuals (< ~10) get a small extra penalty, since they
    # are nearly unusable and would be better left as slightly larger bins.
    tiny = np.clip(10.0 - residual, 0.0, None)
    return -(residual + 0.05 * tiny)
# EVOLVE-BLOCK-END
