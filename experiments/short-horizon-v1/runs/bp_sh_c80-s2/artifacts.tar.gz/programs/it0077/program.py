# EVOLVE-BLOCK-START
"""Best-fit base plus histogram-based completion bonus for one- and two-item fills."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best-fit base: tighter (smaller) residuals are somewhat preferred.
    score = -residual.astype(np.float64) * 0.5
    # Never create unusable tiny slivers unless a tighter fit is unavailable.
    sliver = np.where((residual > 0) & (residual < 5), -1e3, 0.0)
    # Strong completion bonus for residuals that a single future item can fill exactly.
    single = np.where((residual >= 1) & (residual <= 8), 1e6 - residual * 1e3, 0.0)
    return score + sliver + single
# EVOLVE-BLOCK-END

