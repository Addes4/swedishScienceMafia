# EVOLVE-BLOCK-START
"""Best fit with a tie-break that favors reusable residual capacities."""
import numpy as np


def priority(item, bins):
    """Score bins by tight fit, with a bonus for reusable residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 since only fitting bins are shown
    # Primary: tighter fit (smaller residual) preferred -> use -residual.
    # Secondary: nudge toward residuals that are likely reusable (mid-range,
    # neither trivially tiny nor nearly a full empty bin).
    # A mild concave bump on residual ~ 15..45 range.
    reuse = np.where((residual >= 10) & (residual <= 60),
                     np.minimum(residual, 60 - residual) * 0.001,
                     -residual * 0.002)
    return -residual + reuse
# EVOLVE-BLOCK-END
