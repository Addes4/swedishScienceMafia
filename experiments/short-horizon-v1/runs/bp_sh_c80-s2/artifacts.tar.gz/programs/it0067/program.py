# EVOLVE-BLOCK-START
"""Expected-waste scoring using a running item-size histogram.

For a candidate bin, placing the item leaves a residual r.  A bin ends up
"full enough" if some later item exactly fits into r, otherwise r stays as
slack.  We estimate, from a running histogram of observed item sizes,
P(some future item can complete the residual) and score bins so that the
expected final slack per placement is small.  Unused bins (residual 100)
stay attractive so the item is not needlessly crammed.

This keeps the strong best-fit preference (small residuals are good) but
rewards residuals that later items are actually likely to fill, avoiding
slivers that will never be completed.
"""
import numpy as np

# Running histogram of past item sizes (index 0..100 unused, 1..100 real).
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def _reset_if_needed():
    # Module state persists within a stream; harness resets modules between
    # streams.  Nothing to do here, kept for clarity.
    pass


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest
    (first on ties).
    """
    global _TOTAL
    item = int(item)
    residual = bins - item  # candidate leftover after placing

    # --- update running histogram with the current item (before choosing) ---
    _HIST[item] += 1.0
    _TOTAL += 1.0

    # Probability that a fresh random item exactly equals a given residual.
    # Smoothed so unseen sizes are not zero-probability forever.
    probs = (_HIST + 0.5) / (_TOTAL + 50.5)  # over sizes 1..100, with smoothing

    # Completion probability for a residual r: chance some later single item
    # exactly fits r.  Approximate by probs[r] plus a small spread around it so
    # near-misses still count a little.
    idx = np.clip(residual, 0, 100).astype(np.int64)
    exact = probs[idx]
    # small spread: average probs over r-1..r+1
    lo = np.clip(idx - 1, 0, 100)
    hi = np.clip(idx + 1, 0, 100)
    spread = (probs[lo] + probs[idx] + probs[hi]) / 3.0

    # Expected waste: a bin that stays open with slack r is "wasted" unless
    # completed.  We want to prefer placements whose residual leads to low
    # long-run waste.  Small residuals are intrinsically good (best-fit), and
    # high completion probability is good.  Unused/full bins (r near 100 or 0)
    # are treated favourably.
    #
    # Score: reward tightness strongly, modulated by completion probability.
    tightness = -np.abs(residual - 0.0)  # prefer finishing bins (r->0)
    # but avoid creating tiny uncompletable slivers: penalize small nonzero r
    # whose completion chance is low.
    sliver_penalty = np.where((residual > 0) & (residual <= 12),
                              (12.0 - residual) * (0.02 - spread) * 100.0,
                              0.0)

    # Base: best-fit-like, with a mild preference for residuals matching the
    # distribution mean (so leftover gaps are likely fillable by one item).
    score = tightness

    # Reward high completion probability residuals (fills future slivers).
    score = score + spread * 40.0

    # Keep unused bins reasonably attractive early (avoid odd packings).
    score = np.where(residual == 100.0, score - 5.0, score)

    score = score - sliver_penalty
    return score
# EVOLVE-BLOCK-END
