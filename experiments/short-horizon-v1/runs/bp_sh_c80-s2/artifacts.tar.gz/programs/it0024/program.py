# EVOLVE-BLOCK-START
"""Best-fit with a clean-retirement bonus: prefer tightest fit, and among
equally tight fits prefer bins that end up (nearly) empty so they can be
retired instead of leaving half-used bins around to clutter later choices."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Dominant term: prefer the tightest fit (smallest residual).
    score = -np.minimum(residual, 25).astype(np.float64)
    # Secondary term: reward bins that become nearly empty after placement,
    # i.e. cleanly retired bins rather than lingering partial bins.
    # residual==0 is already best; calm tiny residuals get a small nudge.
    score += 0.5 * np.exp(-residual / 2.0)
    return score
# EVOLVE-BLOCK-END
