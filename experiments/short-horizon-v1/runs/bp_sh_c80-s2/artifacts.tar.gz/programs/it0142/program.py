# EVOLVE-BLOCK-START
"""Target-residual best fit with a distribution-derived sweet spot."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    if _COUNT >= 30:
        # Target residual: aim to leave a gap a typical item can fill.  A slightly
        # sub-mean target reduces large residual waste for skewed (Weibull) sizes.
        target = 0.90 * mean + 0.15 * sd
    else:
        target = 38.0

    score = -np.abs(residual - target)

    # Smooth, monotone best-fit bonus: the closer the residual is to zero, the
    # larger the reward.  Use a sharp exponential so near-perfect fills strongly
    # dominate, and it decays smoothly instead of a hard step.
    score = score + 200.0 * np.exp(-np.maximum(residual, 0.0) / 6.0)
    return score
# EVOLVE-BLOCK-END

