# EVOLVE-BLOCK-START
"""Best fit with earliest-bin tie-breaking on equal residual capacity."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smallest residual (tightest fit). Tie-break: earliest bin index.
    idx = np.arange(bins.shape[0])
    return -residual.astype(np.float64) - idx * 1e-6
# EVOLVE-BLOCK-END
