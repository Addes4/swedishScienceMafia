# EVOLVE-BLOCK-START
"""Best fit with a fill-first tie-break among equal residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Dominant term: minimize residual (tightest fit).
    # Tie-break: prefer the bin that was more full before placement (smaller bins).
    return -residual.astype(np.float64) * 1000.0 - (100 - bins).astype(np.float64)
# EVOLVE-BLOCK-END

