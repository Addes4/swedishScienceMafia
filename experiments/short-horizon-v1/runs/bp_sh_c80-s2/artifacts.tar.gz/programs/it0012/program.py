# EVOLVE-BLOCK-START
"""Best fit with a strong bonus for bins that the item fills exactly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    score = -residual.astype(np.float64)
    # Strong bonus when the item exactly fills a bin (residual == 0),
    # i.e. remaining capacity equals the item size.
    score += 1000.0 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
