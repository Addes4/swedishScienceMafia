# EVOLVE-BLOCK-START
"""Bounded best-fit with a size-conditional tie-break on true residual capacity."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit, but cap slivers below ~25 so they are not over-preferred.
    score = -np.minimum(residual, 25).astype(np.float64)

    # Secondary, only for relatively large items: among the capped class, prefer bins
    # that are not already near-full slivers, i.e. keep larger true remaining capacity.
    if item >= 40:
        # small additive term (kept below 1 so it only breaks ties within the cap class)
        score = score + 0.5 * (bins.astype(np.float64) / 100.0)

    return score
# EVOLVE-BLOCK-END

