# EVOLVE-BLOCK-START
"""Target-residual best fit with a distribution-derived sweet spot and smooth completion term."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item

    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    if _COUNT >= 30:
        # Target residual: aim to leave a gap a typical item can fill.
        target = 0.90 * mean + 0.15 * sd
    else:
        target = 38.0

    score = -np.abs(residual - target)

    # Smooth completion bonus: reward small residuals exponentially, scaled by the
    # running mean so the effect is size-invariant and dominated by the sweet-spot
    # term except when a bin is nearly perfectly filled.
    scale = max(mean, 1.0)
    bonus = 3.0 * np.exp(-np.maximum(residual, 0.0) / (0.35 * scale))
    return score + bonus
# EVOLVE-BLOCK-END
