# EVOLVE-BLOCK-START
"""Target-residual best fit with an empirical-distribution expected-waste sweet spot."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0
_HIST = np.zeros(101, dtype=np.float64)  # empirical counts of item sizes 1..100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ, _HIST

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    if item <= 100:
        _HIST[item] += 1.0

    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item  # remaining capacity after placing item here

    # Empirical distribution of item sizes (smoothed toward uniform for cold start).
    if _COUNT >= 40:
        p = _HIST.copy()
        # Add-one smoothing so unseen sizes still count.
        p += 1.0
        p /= p.sum()
    else:
        p = np.full(101, 1.0 / 100.0)
        p[0] = 0.0

    # For a bin with residual r, expected waste of leaving r unused is approximated by
    # the expected amount of a future item that would NOT fit (r - size) when size <= r,
    # plus the residual itself when no future item fits (size > r). We want to minimize
    # expected waste, i.e. maximize score = -expected_waste.
    #
    # Compute expectation efficiently using cumulative sums.
    sizes = np.arange(101, dtype=np.float64)
    p = p.copy()
    p[0] = 0.0
    p = p / p.sum()

    # cumulative probability that a size <= x
    cdf = np.cumsum(p)
    # E[size * 1{size <= x}]
    esz_le = np.cumsum(p * sizes)

    r = residual.astype(np.float64)
    r_clip = np.clip(r, 0, 100).astype(int)

    # For size <= r: waste contributed is (r - size). For size > r: the bin keeps residual r
    # (can't be filled now) -> contributes r in waste. Probability size > r is (1 - cdf[r]).
    p_le = cdf[r_clip]
    p_gt = 1.0 - p_le
    e_sz_le = esz_le[r_clip]

    exp_waste = (r * p_le - e_sz_le) + r * p_gt

    score = -exp_waste

    # Small best-fit tiebreak: among equal expected waste prefer tighter residual,
    # but keep it much weaker than the expected-waste term.
    score = score - 1e-3 * residual

    # Tiny completion bonus for residuals small enough to likely be filled by a mean-ish item.
    bonus = np.where((residual > 0) & (residual < 100), np.exp(-((residual - 0.5 * mean) ** 2) / (2 * (sd + 1.0) ** 2)) * 1e-2, 0.0)
    return score + bonus
# EVOLVE-BLOCK-END

