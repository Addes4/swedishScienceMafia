# EVOLVE-BLOCK-START
"""Adaptive capped best-fit: prefer tight fits, with a data-driven sliver cap."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]
    # Cap residuals so tiny unusable slivers are not strictly preferred over
    # slightly looser fits. The cap tracks about half the running mean item.
    cap = max(4.0, min(25.0, 0.5 * mean))
    residual = bins - item
    return -np.minimum(residual, cap)
# EVOLVE-BLOCK-END
