# EVOLVE-BLOCK-START
"""Best-fit bin choice with a small perfect-fit preference."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Best fit: prefer the smallest residual (tightest fit).
    score = -residual.astype(np.float64)

    # Small nudge: fully exact fits are slightly favored to keep bins tidy.
    score += np.where(residual == 0, 1e-3, 0.0)

    return score
# EVOLVE-BLOCK-END
