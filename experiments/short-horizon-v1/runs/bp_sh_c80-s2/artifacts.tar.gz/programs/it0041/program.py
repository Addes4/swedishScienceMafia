# EVOLVE-BLOCK-START
"""Best fit with a mild residual-quality term and light adaptive state."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: strongly prefer tight fits (small residual).
    base = -residual.astype(np.float64)
    # Secondary: mildly penalize residuals that are useless slivers (0 < r < ~30),
    # since they tend to be orphaned; a residual slightly larger is often more reusable.
    r = residual.astype(np.float64)
    sliver_penalty = np.where((r > 0) & (r < 30), (30.0 - r) * 0.05, 0.0)
    return base - sliver_penalty
# EVOLVE-BLOCK-END

