# EVOLVE-BLOCK-START
"""Best fit with a recency tie-break among near-equal fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    n = len(bins)
    idx = np.arange(n)
    # Primary: tightest fit (smallest residual). Secondary: prefer most recently
    # opened bins (larger index) among nearly equal fits, to keep older bins free.
    return -residual.astype(np.float64) * 1e6 + idx
# EVOLVE-BLOCK-END
