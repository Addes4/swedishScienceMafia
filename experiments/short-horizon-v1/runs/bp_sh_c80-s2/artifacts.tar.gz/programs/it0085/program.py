# EVOLVE-BLOCK-START
"""Target-residual best fit with an adaptive sweet spot (median-based)."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_HIST = np.zeros(101, dtype=np.int64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _TOTAL, _COUNT, _HIST

    # Running statistics for the observed item distribution.
    _TOTAL += item
    _COUNT += 1
    _HIST[item] += 1
    mean = _TOTAL / _COUNT

    # Estimate the median item size from the running histogram.
    if _COUNT >= 20:
        half = _COUNT // 2
        csum = np.cumsum(_HIST)
        median = int(np.searchsorted(csum, half)) or item
    else:
        median = 35

    residual = bins - item

    # Sweet spot scaled to the observed median: aim to leave a gap a typical future
    # item can fill. Blend toward the proven value early on.
    if _COUNT >= 20:
        target = 1.05 * median
    else:
        target = 38.0

    score = -np.abs(residual - target)

    # Strongly reward near-exact tight fits so full bins get finished.
    tight = np.where(residual <= 8, 1e6 - residual * 1e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END

