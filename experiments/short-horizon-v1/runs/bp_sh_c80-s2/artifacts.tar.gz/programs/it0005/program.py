# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware residual nudge."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Running estimate of the item distribution (mean), stored on the function object.
    state = priority.__dict__
    n = state.get("n", 0)
    mean = state.get("mean", 40.0)
    n += 1
    mean += (item - mean) / n
    state["n"] = n
    state["mean"] = mean

    # Primary: tightest fit (small residual). Secondary: keep residual near mean so that
    # leftover capacity remains a plausible slot for a future item.
    return -(residual) - 0.02 * np.abs(residual - mean)
# EVOLVE-BLOCK-END
