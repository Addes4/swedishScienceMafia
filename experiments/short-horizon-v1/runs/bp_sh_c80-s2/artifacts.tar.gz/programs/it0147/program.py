# EVOLVE-BLOCK-START
"""Target-residual best fit with a smooth fillability estimate."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    # Sweet-spot target: leave a gap a typical item can absorb, slightly sub-mean
    # to account for the right skew of the Weibull-shaped size distribution.
    if _COUNT >= 30:
        target = 0.90 * mean + 0.15 * sd
    else:
        target = 38.0
    scale = max(target, 5.0)

    # base: distance from the sweet-spot residual
    score = -np.abs(residual - target)

    # smooth fillability: reward residuals near zero (a near-exact fill is great),
    # shaped as a Gaussian bump of width ~ half the mean item size, so it never
    # dominates the sweet-spot ranking but consolidates tight fits.
    tight_sigma = max(0.5 * mean, 8.0)
    score += 3.0 * np.exp(-(residual / tight_sigma) ** 2)

    return score
# EVOLVE-BLOCK-END

