# EVOLVE-BLOCK-START
"""Target-residual best fit with a subtle preference for fillable tiny gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Sweet spot near the mean item size (~40) so leftover gaps are likely to be
    # filled by a single later item; tight fits beyond it are penalized.
    target = 35.0
    score = -np.abs(residual - target)
    # Reward near-exact tight fits so full bins get finished.
    tight = np.where(residual <= 8, 1e6 - residual * 1e3, 0.0)
    # Tiny extra nudge: residuals that exactly match very common small item sizes
    # are slightly preferred, reducing permanently wasted slivers.
    fillable = np.where((residual >= 1) & (residual <= 6), 50.0 - residual, 0.0)
    return score + tight + fillable
# EVOLVE-BLOCK-END

