# EVOLVE-BLOCK-START
"""Best-fit with an adaptive completion bonus."""
import numpy as np

_TOTAL = 0
_COUNT = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _TOTAL, _COUNT

    _TOTAL += item
    _COUNT += 1
    mean = _TOTAL / _COUNT

    residual = bins - item

    # Base: best fit (smaller residual is better) so bins stay tightly packed.
    score = -residual.astype(np.float64)

    # Completion bonus: strongly prefer near-exact fills, window scaled to the mean.
    window = 0.25 * mean if _COUNT >= 20 else 10.0
    tight = np.where(residual <= window, 1e6 - residual * 1e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END

