# EVOLVE-BLOCK-START
"""Target-residual best fit with an adaptive sweet spot and completion bonus."""
import numpy as np

_TOTAL = 0
_COUNT = 0
# Histogram of past item sizes (1..100), used to estimate a robust sweet spot.
_HIST = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _TOTAL, _COUNT, _HIST

    # Update running statistics with the current item.
    _TOTAL += item
    _COUNT += 1
    _HIST[item] += 1.0
    mean = _TOTAL / _COUNT

    # Robust sweet spot: the median future item size is a better estimator of a
    # typical filler than the mean (the Weibull shape has a long right tail).
    if _COUNT >= 20:
        cdf = np.cumsum(_HIST)
        median = float(np.searchsorted(cdf, 0.5 * _COUNT) + 1)
        target = 0.95 * median
    else:
        target = 38.0

    residual = bins - item

    # Base: prefer residuals near the sweet spot.
    score = -np.abs(residual - target)

    # Completion bonus: reward near-exact fits (small residuals), which finish bins.
    tight = np.where(residual <= 10, 1e6 - residual * 1e5, 0.0)
    return score + tight
# EVOLVE-BLOCK-END
