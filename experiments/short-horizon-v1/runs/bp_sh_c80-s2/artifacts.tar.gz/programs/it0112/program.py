# EVOLVE-BLOCK-START
"""Target-residual best fit with near-exact completion bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item

    # Sweet spot: prefer leaving a residual that a typical (mean~40) follow-up item
    # can fill.  A slightly sub-mean target (~34) balances skewed Weibull sizes.
    target = 34.0
    score = -np.abs(residual - target)

    # Strong bonus for near-exact fits: reward small residuals decisively so that
    # bins that become nearly full are preferred without a hard discontinuity.
    tight = -2000.0 * np.maximum(residual, 0.0)

    return score + tight
# EVOLVE-BLOCK-END
