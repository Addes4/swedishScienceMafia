# EVOLVE-BLOCK-START
"""First fit: put the item in the earliest bin (lowest index) that it fits in.

The harness passes all bins the item fits in, in bin order, so ranking by
decreasing bin index (i.e. preferring the smallest index) implements First Fit.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    return -np.arange(len(bins), dtype=float)
# EVOLVE-BLOCK-END
