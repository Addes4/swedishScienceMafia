# EVOLVE-BLOCK-START
"""Target-residual score with a distribution-adaptive exact-fit completion bonus."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_total = 0.0
_last_size = -1


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _total, _last_size

    # Update running histogram of past item sizes (state persists within a stream).
    if item != _last_size:
        pass
    if 1 <= item <= 100:
        _hist[item] += 1.0
        _total += 1.0
    _last_size = item

    residual = bins - item

    # Base: prefer a residual near a sweet spot (mean item size).
    target = 35.0
    score = -np.abs(residual - target)

    # Tight-fit reward so full bins get finished.
    tight = np.where(residual <= 8, 1e6 - residual * 1e3, 0.0)

    # Distribution-adaptive completion bonus: reward residuals that match a
    # commonly seen item size, since such a leftover is likely to be filled
    # exactly by a single future item.
    if _total > 20.0:
        probs = _hist / _total
        r = residual
        valid = (r >= 1) & (r <= 100)
        rc = np.clip(r, 1, 100)
        fit_prob = probs[rc]
        fit_prob = np.where(valid, fit_prob, 0.0)
    else:
        fit_prob = np.zeros_like(residual, dtype=np.float64)

    return score + tight + 50.0 * fit_prob
# EVOLVE-BLOCK-END
