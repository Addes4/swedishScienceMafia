# EVOLVE-BLOCK-START
"""Best-fit in the smallest viable bin, with a distribution-derived gap target."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0
_HIST = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ, _HIST

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    _HIST[item] += 1.0

    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item
    res = residual.astype(np.float64)

    # Base preference: best fit = smallest non-negative residual (classic best-fit).
    # This minimizes leftover fragments and is the workhorse for packing efficiency.
    score = -res

    if _COUNT >= 30:
        # Estimate the smallest item size we're likely to see again soon, using a low
        # quantile of the empirical histogram. Bins with residual below this threshold
        # are essentially dead space for future items, so demote them slightly.
        freq = _HIST / _COUNT
        cdf = np.cumsum(freq)
        # 20th percentile item size
        idx = np.searchsorted(cdf, 0.20)
        low_item = float(max(idx, 1))
        # Small penalty for residuals too small to hold a typical low-quantile item.
        dead = np.where(res < low_item, low_item - res, 0.0)
        score = score - 0.35 * dead

        # Slight pull toward the mean-fill sweet spot to avoid always squeezing the
        # smallest bin (which can strand medium gaps).
        target = 0.85 * mean
        score = score - 0.02 * np.abs(res - target)
    else:
        score = score - 0.02 * np.abs(res - 38.0)

    return score
# EVOLVE-BLOCK-END
