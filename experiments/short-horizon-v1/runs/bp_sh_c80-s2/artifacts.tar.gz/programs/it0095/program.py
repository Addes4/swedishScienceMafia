# EVOLVE-BLOCK-START
"""Adaptive best-fit: target residual tuned per arriving item."""
import numpy as np

_TOTAL = 0.0
_COUNT = 0
_RECENT = 0.0
_RECENT_COUNT = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _RECENT, _RECENT_COUNT

    # Update running statistics before scoring.
    _TOTAL += item
    _COUNT += 1
    # Exponential decay estimate of recent item sizes.
    if _RECENT_COUNT == 0:
        _RECENT = float(item)
    else:
        _RECENT = 0.9 * _RECENT + 0.1 * float(item)
    _RECENT_COUNT += 1

    mean = _TOTAL / _COUNT

    residual = bins - item

    # Sweet-spot target: aim to leave a gap a typical future item can fill.
    # Use the observed mean, but shift with the current item so larger items
    # prefer slightly smaller residuals (more room for a partner) and smaller
    # items leave room near a full item's worth.
    target = 0.92 * mean
    if item >= mean:
        target -= 0.15 * (item - mean)
    else:
        target += 0.1 * (mean - item)
    if target < 0.0:
        target = 0.0
    if target > 100.0:
        target = 100.0

    score = -np.abs(residual - target)

    # Reward near-exact tight fits so full bins get finished.
    tight = np.where(residual <= 8, 1e6 - residual * 1e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END
