# EVOLVE-BLOCK-START
"""Best fit with a small bonus for residuals that a later item can fill exactly."""
import numpy as np

# Cache for the set of plausible item sizes (approximate Weibull, mean ~40).
_SIZE_GRID = None


def _grid():
    global _SIZE_GRID
    if _SIZE_GRID is None:
        _SIZE_GRID = np.arange(1, 101, dtype=np.float64)
    return _SIZE_GRID


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest score."""
    residual = bins - item  # post-placement residual, >= 0

    # Base: exact best fit (smaller residual better).
    score = -residual.astype(np.float64)

    # Mild bonus when the residual is a "clean" leftover: 0 or near a size that
    # a single future item is likely to consume exactly, reducing orphaned slivers.
    grid = _grid()
    # distance to the nearest plausible single-item size (including 0)
    d0 = residual.astype(np.float64)
    # nearest grid size <= residual and nearest >= handled by simple min over grid
    # (grid is small enough: 100 entries)
    diffs = np.abs(residual[:, None] - grid[None, :])
    nearest = diffs.min(axis=1)
    bonus = np.exp(-nearest / 3.0)  # ~1 when residual matches a likely size, decays

    # keep best-fit dominance; bonus is a small tie-breaking nudge
    return score + 0.5 * bonus
# EVOLVE-BLOCK-END
