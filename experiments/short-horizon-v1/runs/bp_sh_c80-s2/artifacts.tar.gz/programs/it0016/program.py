# EVOLVE-BLOCK-START
"""Capped best fit with an adaptive cap based on the smallest item seen so far.

Put the item in the bin it fits most tightly, but treat residuals smaller than the
smallest positive item observed so far as equivalent slivers (they cannot be filled
by a future item of the typical magnitude), so we do not over-prefer useless slivers.
State (min positive item size) persists between calls within a stream.
"""
import numpy as np

# Module-level state: smallest positive item size seen so far in the current stream.
# 0 means "not yet observed"; we fall back to the historical default cap of 25.
_min_item = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _min_item
    if item > 0 and (_min_item == 0 or item < _min_item):
        _min_item = item

    # Cap: residuals below the smallest item seen are useless slivers -> equal.
    # Start conservatively high (25) until we have observed enough small items.
    cap = _min_item if _min_item > 0 else 25
    # Keep the cap within a sane range so behavior doesn't collapse to pure best fit
    # or to plain first fit.
    if cap < 5:
        cap = 5
    elif cap > 40:
        cap = 40

    residual = bins - item
    return -np.minimum(residual, cap)
# EVOLVE-BLOCK-END
