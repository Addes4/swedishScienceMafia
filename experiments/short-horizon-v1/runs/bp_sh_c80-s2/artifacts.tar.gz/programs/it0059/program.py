# EVOLVE-BLOCK-START
"""Capped best-fit with a mild gap-shaping tiebreak."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Primary: capped best-fit.  Tightest fit (smallest residual) is best because it
    # finishes bins and preserves large open bins for future large items.  Cap the
    # penalty so that among very loose bins we don't waste precision ranking them.
    score = -np.minimum(residual, 20.0)

    # Secondary: among near-tie residuals (< ~1 item), prefer the one whose leftover
    # gap is closest to the typical item size (~40), so the leftover is likely to be
    # filled by a single later item instead of becoming a wasted sliver.
    target = 38.0
    small = residual < 6.0
    score = score - np.where(small, np.abs(residual - target) * 1e-3, 0.0)

    # Tertiary: strongly reward exact/near-exact tight fits so full bins get finished.
    tight = np.where(residual <= 4, 1e6 - residual * 1e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END

