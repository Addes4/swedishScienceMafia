# EVOLVE-BLOCK-START
"""Target-residual best fit with a distribution-adaptive sweet spot."""
import numpy as np

# State (per stream): frequency table of item sizes seen so far.
_hist = np.zeros(101, dtype=np.float64)
_total = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _total

    residual = bins - item

    # Update the running histogram of item sizes (after this item is placed).
    _hist[item] += 1.0
    _total += 1

    # Choose the target residual as the most frequent item size seen so far that
    # is at least a bit smaller than the current item (so the leftover gap can be
    # filled by a typical future item). Fall back to ~35 (near the mean) early on.
    if _total >= 20:
        counts = _hist[1:101]
        # Favor sizes that can plausibly fill gaps; weight by frequency.
        candidates = np.arange(1, 101, dtype=np.float64)
        # We want the mode of the item distribution as the target residual.
        target = float(candidates[np.argmax(counts)])
    else:
        target = 35.0

    # Score highest when the residual lands near the target; tighter is better
    # below target, larger residuals break a fuller bin so they are penalized.
    score = -np.abs(residual - target)

    # Strongly reward exact/near-exact tight fits so full bins get finished.
    tight = np.where(residual <= 8, 1e6 - residual * 1e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END

