# EVOLVE-BLOCK-START
"""Target-residual best fit with a distribution-derived sweet spot."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    if _COUNT >= 30:
        target = 0.90 * mean + 0.15 * sd
    else:
        target = 38.0

    score = -np.abs(residual - target)

    # Slight completion bonus for near-full bins.
    tight = np.where(residual <= 10, 4e4 - residual * 2e3, 0.0)
    score = score + tight

    # Penalise opening a brand-new bin: only worth doing when no partial bin is a
    # reasonable fit.  This mimics best-fit's reluctance to waste empty capacity.
    fresh = (bins == 100) & (item < 100)
    score = score - fresh * 1e5

    return score
# EVOLVE-BLOCK-END
