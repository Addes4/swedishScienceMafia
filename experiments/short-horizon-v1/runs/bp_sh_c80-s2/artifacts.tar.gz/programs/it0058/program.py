# EVOLVE-BLOCK-START
"""Target-residual best fit with distribution-adaptive tight-fit bonus."""
import numpy as np

# Module-level state: histogram of item sizes seen so far in the current stream.
_SIZE = 101
_hist = np.zeros(_SIZE, dtype=np.float64)
_total = 0


def _fit_prob(residual):
    """Probability (estimated from past items) that a future item fits `residual`."""
    r = int(residual)
    if r <= 0:
        return 0.0
    if r >= 100:
        return 1.0
    if _total == 0:
        # Prior: roughly uniform-ish, mild preference for tiny gaps being useless.
        return r / 100.0
    return float(_hist[1:r + 1].sum()) / float(_total)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _total
    residual = bins - item

    target = 35.0
    score = -np.abs(residual - target).astype(np.float64)

    # Reward residuals that are likely to be exactly filled by a single future item,
    # using the empirical item distribution.  Bin residuals are at most 99 here.
    bonus = np.zeros(residual.shape, dtype=np.float64)
    for i in range(residual.shape[0]):
        r = int(residual[i])
        if r <= 0:
            continue
        if r <= 100:
            if _total > 0:
                p = float(_hist[r]) / float(_total)
            else:
                p = 1.0 / 100.0
            # Exact-match bonus proportional to how common that item size is,
            # plus a small term for small residuals likely to be fillable.
            bonus[i] = 1e4 * p
    score = score + bonus

    # Strongly reward exact/near-exact tight fits so full bins get finished.
    tight = np.where(residual <= 8, 1e6 - residual * 1e3, 0.0)
    score = score + tight

    # Update histogram with the current item (after scoring, item belongs to this stream).
    if 1 <= item <= 100:
        _hist[item] += 1.0
        _total += 1

    return score
# EVOLVE-BLOCK-END
