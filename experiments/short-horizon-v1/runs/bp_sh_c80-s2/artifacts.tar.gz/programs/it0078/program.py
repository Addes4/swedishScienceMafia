# EVOLVE-BLOCK-START
"""Best-fit base plus a completion bonus tuned to the item distribution."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Base: pure best fit -- smaller residual is always better, since it packs
    # the bin tighter and preserves the larger open gaps for larger items.
    score = -residual.astype(np.float64)

    # Completion bonus: a residual close to a common item size (mean ~40) is
    # likely to be filled exactly by a single later item, so finishing that bin
    # now is worthwhile.  Reward residuals in the sweet spot near 35-45.
    target = 38.0
    width = 9.0
    bonus = np.clip(width - np.abs(residual - target), 0.0, None)
    bonus = bonus * 2.0

    # Strong extra reward for near-exact tight fits so full bins get finished.
    tight = np.where(residual <= 6, 1e5 - residual.astype(np.float64), 0.0)

    return score + bonus + tight
# EVOLVE-BLOCK-END
