# EVOLVE-BLOCK-START
"""Target-residual best fit with distribution-adaptive sliver completion."""
import numpy as np

# State: histogram of past item sizes (per stream).
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _n

    residual = bins - item

    # Update running histogram of arrivals.
    _hist[item] += 1.0
    _n += 1.0

    # Shaping target near the mean item size (~40).
    target = 35.0
    score = -np.abs(residual - target)

    # Distribution-adaptive sliver completion: reward residuals that exactly match
    # a frequently-seen small item size, so leftover gaps get filled later.
    if _n > 0:
        # Probability mass that a future item equals each candidate residual value.
        freq = _hist / _n  # index = size
        # Only small residuals matter for sliver completion.
        r = np.clip(residual, 0, 100).astype(np.int64)
        fit_prob = freq[r]
        sliver = np.where(residual <= 20, fit_prob * 1e3, 0.0)
        # Ensure any tight exact fit is strongly preferred regardless of history.
        exact = np.where(residual == 0, 5e5, 0.0)
        return score + sliver + exact

    # Cold start: prefer tight fits.
    return score
# EVOLVE-BLOCK-END
