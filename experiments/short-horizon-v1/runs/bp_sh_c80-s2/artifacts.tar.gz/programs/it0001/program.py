# EVOLVE-BLOCK-START
"""Best-fit with a learned penalty for leaving awkward remainders.

Pure best fit minimizes the immediate remainder, but it can strand bins with a small
remaining capacity that few future items will fill.  Instead of only minimizing the
resulting remainder, we penalize remainders that are unlikely to be matched by an
item drawn from the observed distribution.  We keep a lightweight running histogram
of past item sizes (state lives inside the module across calls within a stream) and
use the empirical fraction of items that would exactly fill a bin as an estimate of
how "useful" a leftover capacity is.

The score keeps the fit term dominant (so the rule behaves like best fit) and adds a
small bonus for remainders whose capacity is a commonly seen item size, encouraging
bins to end in states that future items can complete.
"""
import numpy as np

# Running histogram of item sizes observed so far. Index 0 unused.
_counts = np.zeros(101, dtype=np.float64)
_total = 0.0
_UPPER = 1  # initialize lazily


def _reset_if_needed():
    global _total
    if _total > 200000.0:
        # keep weights bounded (should not trigger in normal streams)
        _counts *= 0.5
        _total *= 0.5


def priority(item, bins):
    global _total

    # Update the empirical distribution with the newly observed item.
    _reset_if_needed()
    _counts[item] += 1.0
    _total += 1.0

    bins = np.asarray(bins)
    # Remaining capacity after placing the item in each bin.
    remain = bins - item

    # Primary signal: prefer tight fits (small remainders).  Equivalent ordering to
    # the classic best-fit rule, so ties fall back to earliest bin.
    score = -remain.astype(np.float64)

    # Empirical probability that a future item exactly equals the remainder; this is
    # how "completable" the leftover capacity is.  Remainder 0 (perfect fit) is the
    # best possible and needs no help.  We only nudge non-perfect remainders.
    if _total >= 20.0:
        prob = _counts / _total
        # A remainder r is useful if some item of size r is common; giving those bins
        # a tiny extra bump lets them be filled later instead of wasting capacity.
        useful = prob[np.clip(remain, 0, 100)]
        # Zero-weight the perfect-fit case so tight fits stay strongly preferred.
        useful = np.where(remain == 0, 0.0, useful)
        score = score + 0.5 * useful

    return score
# EVOLVE-BLOCK-END
