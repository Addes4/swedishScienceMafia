# EVOLVE-BLOCK-START
"""Adaptive capped best-fit: tighten the residual cap using observed item sizes."""
import numpy as np

_mean = 0.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count
    # Update running mean of item sizes (bounded work per call).
    _count += 1
    _mean += (item - _mean) / _count

    # Adaptive cap: shrinks toward ~half the mean item size for large items,
    # never exceeding 25 and never below a small floor.
    cap = int(min(25, max(4, round(0.5 * _mean))))

    residual = bins - item
    return -np.minimum(residual, cap)
# EVOLVE-BLOCK-END
