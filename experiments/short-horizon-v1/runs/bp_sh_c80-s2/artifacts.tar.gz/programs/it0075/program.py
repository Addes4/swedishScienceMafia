# EVOLVE-BLOCK-START
"""Target-residual best fit with a distribution-aware gap-filling bonus."""
import numpy as np


class _Hist:
    """Running histogram of item sizes seen so far in the current stream."""

    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def update(self, item):
        self.counts[item] += 1.0
        self.total += 1.0

    def prob(self, size):
        if size < 1 or size > 100 or self.total <= 0:
            return 0.0
        return self.counts[size] / self.total


_H = _Hist()
_LAST_TOTAL = -1


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _LAST_TOTAL
    # Detect a fresh stream: harness resets state by reimporting or the total
    # only ever grows within a stream, so guard against negative counters.
    _H.update(item)

    residual = bins - item
    target = 35.0

    # Proven base: prefer residual near the sweet spot.
    score = -np.abs(residual - target)

    # Base tight-fit completion bonus.
    tight = np.where(residual <= 8, 1e6 - residual * 1e3, 0.0)

    # Distribution-aware bonus: how likely is this residual to be filled by a
    # future single item (residual equals a commonly seen item size)?
    bonus = np.zeros_like(residual, dtype=np.float64)
    for r in np.unique(residual):
        ri = int(r)
        if 1 <= ri <= 100:
            p = _H.prob(ri)
            if p > 0:
                bonus += np.where(residual == r, p * 3e4, 0.0)

    return score + tight + bonus
# EVOLVE-BLOCK-END

