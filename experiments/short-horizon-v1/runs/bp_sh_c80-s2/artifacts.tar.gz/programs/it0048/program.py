# EVOLVE-BLOCK-START
"""Best fit with a small penalty on unusable tiny slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    score = -np.minimum(residual, 25)
    # Penalize residuals (1..4) that are too small to fit most future items.
    tiny = (residual >= 1) & (residual <= 4)
    score = score - 0.5 * tiny
    return score
# EVOLVE-BLOCK-END

