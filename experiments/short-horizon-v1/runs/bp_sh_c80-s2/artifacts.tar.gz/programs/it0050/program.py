# EVOLVE-BLOCK-START
"""Best fit with a mild consolidation bias toward already-fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best fit: prefer smallest residual. Cap so slivers aren't over-preferred.
    capped = np.minimum(residual, 25)
    # Mild consolidation bias: prefer bins that are already more filled
    # (smaller remaining capacity => higher score), which tends to reduce bin count.
    used = 100.0 - bins
    return -capped + 0.05 * used
# EVOLVE-BLOCK-END

