# EVOLVE-BLOCK-START
"""Soft-sliver best-fit: minimize residual, with a soft penalty for tiny unusable gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)
    # Primary: smaller residual is better (best fit).
    # Secondary: softly penalize very small residuals so useless slivers
    # (which can never fit another item) are not preferred over slightly
    # looser fits that remain reusable.
    penalty = 6.0 / (residual + 1.0)
    return -residual - penalty
# EVOLVE-BLOCK-END
