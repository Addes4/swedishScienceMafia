# EVOLVE-BLOCK-START
"""Capped best-fit with exact-fill bonus scaled by item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    score = -np.minimum(residual, 25).astype(np.float64)
    # Strongly prefer bins that the item exactly fills: zero leftover is never worse
    # than any positive leftover, so reward exact fits proportionally to item size.
    exact = (residual == 0)
    score = score - exact * (50.0 + item)
    return score
# EVOLVE-BLOCK-END

