# EVOLVE-BLOCK-START
"""Target-residual best fit with a smooth always-active best-fit term."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    if _COUNT >= 30:
        # Sweet-spot target: leave a gap a typical item can fill. Slightly sub-mean
        # target reduces residual waste for skewed (Weibull) sizes.
        target = 0.90 * mean + 0.15 * sd
    else:
        target = 38.0

    score = -np.abs(residual - target)

    # Smooth best-fit preference: reward small residuals with a hyperbolic-like
    # slope so exact/near-exact fits are always selected, without a hard cutoff.
    # Continuously active (no threshold), and penalizes large residuals modestly.
    tight = -1.0 / (residual + 2.0) * 60.0
    return score + tight
# EVOLVE-BLOCK-END

