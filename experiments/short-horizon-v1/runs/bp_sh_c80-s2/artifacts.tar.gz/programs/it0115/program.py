# EVOLVE-BLOCK-START
"""Target-residual best fit with a sharpened deviation penalty."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    if _COUNT >= 30:
        target = 0.90 * mean + 0.15 * sd
    else:
        target = 38.0

    dev = residual - target
    # Sharpen: quadratic deviation makes near-target bins dominate, but cap the
    # magnitude so far bins still get a comparable gradient.
    denom = max(target, 1.0)
    score = -(dev * dev) / denom

    # Near-exact completion bonus, softer slope.
    tight = np.where(residual <= 10, 4e4 - residual * 2e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END
