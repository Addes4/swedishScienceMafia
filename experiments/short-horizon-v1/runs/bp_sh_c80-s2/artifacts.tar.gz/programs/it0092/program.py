# EVOLVE-BLOCK-START
"""Target-residual best fit with an adaptive sweet spot and exact-fill bonus."""
import numpy as np

_TOTAL = 0
_COUNT = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _TOTAL, _COUNT

    # Running estimate of the item mean (fall back to the known ~40 before warm-up).
    _TOTAL += item
    _COUNT += 1
    mean = _TOTAL / _COUNT

    residual = bins - item

    # Sweet spot scaled to the observed mean.
    target = 0.92 * mean if _COUNT >= 20 else 38.0

    base = -np.abs(residual - target)

    # Exact-fill bonus: a residual is "reachable" if it can be produced by summing
    # a small number of typical future items (around the running mean). Reward
    # residuals that are exact multiples / simple sums of typical sizes.
    typ = mean if mean > 1.0 else 40.0
    # number of typical items that would fill the residual (closest integer)
    k = residual / typ
    k_int = np.rint(k)
    reachable = np.where((k_int >= 1) & (np.abs(k - k_int) <= 0.09), 1.0, 0.0)

    # Strong reward for exactly fillable residuals, scaled so it dominates the
    # continuous sweet-spot but stays bounded.
    exact = reachable * (1e5 + residual)
    return base + exact
# EVOLVE-BLOCK-END
