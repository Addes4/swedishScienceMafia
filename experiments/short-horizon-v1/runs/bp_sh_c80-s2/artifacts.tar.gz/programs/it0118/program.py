# EVOLVE-BLOCK-START
"""Target-residual best fit with a distribution-derived sweet spot."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    if _COUNT >= 30:
        base = 0.90 * mean + 0.15 * sd
    else:
        base = 38.0

    # Blend in the item's own complement gap (100 - item): favor residuals that
    # let this item pair with a same-sized follow-up, nudging complementary fits.
    target = 0.75 * base + 0.25 * (100.0 - item)

    score = -np.abs(residual - target)

    # Gentle completion bonus: reward small residuals.
    tight = np.where(residual <= 10, 4e4 - residual * 2e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END

