# EVOLVE-BLOCK-START
"""Target-residual best fit with a distribution-derived sweet spot that migrates
toward tight packing as the stream fills up."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    if _COUNT >= 30:
        sweet = 0.90 * mean + 0.15 * sd
    else:
        sweet = 38.0

    # Late in the stream (few open bins relative to items seen) favor tight packing:
    # lower the target residual so best-fit-like behavior dominates.
    open_bins = float(np.count_nonzero(bins < 100))
    frac = open_bins / max(_COUNT, 1.0)  # ~1 early, small late
    # Map frac from [0.05, 1.0] to blend weight in [0,1]; more slack -> use sweet target.
    w = min(max((frac - 0.05) / 0.95, 0.0), 1.0)
    target = w * sweet + (1.0 - w) * (0.15 * sweet)

    score = -np.abs(residual - target)

    tight = np.where(residual <= 10, 4e4 - residual * 2e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END
