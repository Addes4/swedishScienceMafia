# EVOLVE-BLOCK-START
"""Target-residual best fit with an adaptive sweet spot and smooth completion bonus."""
import numpy as np

_TOTAL = 0
_COUNT = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _TOTAL, _COUNT

    # Running estimate of the item mean (fall back to the known ~40 before warm-up).
    _TOTAL += item
    _COUNT += 1
    mean = _TOTAL / _COUNT

    residual = bins - item

    # Sweet spot scaled to the observed mean: aim to leave a gap a typical future
    # item can fill, but stay near the proven value early on.
    target = 0.92 * mean if _COUNT >= 20 else 38.0

    score = -np.abs(residual - target)

    # Smooth completion bonus: reward near-exact fits, with the window scaled to the
    # mean so full bins get finished but tiny residuals aren't over-favoured.
    window = 10.0
    slope = 1e5 / window
    tight = np.where(residual <= window, 1e6 - residual * slope, 0.0)
    return score + tight
# EVOLVE-BLOCK-END
