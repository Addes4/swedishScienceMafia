# EVOLVE-BLOCK-START
"""Capped best-fit with a tiny "leftover is a valid item size" tie-breaker."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Dominant term: tighter fit is better, but cap the reward so we never prefer
    # an unusable sliver over a slightly looser (still usable) fit.
    capped = -np.minimum(residual, 25)
    # Secondary term: gently prefer residuals that equal a valid item size
    # (1..100), i.e. leftovers that could be exactly refilled later.
    usable = ((residual >= 1) & (residual <= 100)).astype(np.float64)
    return capped + 0.01 * usable
# EVOLVE-BLOCK-END

