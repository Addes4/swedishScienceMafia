# EVOLVE-BLOCK-START
"""Target-residual best fit with an adaptive sweet spot (EWMA estimate)."""
import numpy as np

_MEAN = 40.0
_INIT = False


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _MEAN, _INIT

    # Exponentially weighted estimate of the recent item mean.
    if not _INIT:
        _MEAN = float(item)
        _INIT = True
    else:
        _MEAN = 0.99 * _MEAN + 0.01 * item
    mean = _MEAN

    residual = bins - item

    # Sweet spot scaled to the observed recent mean: aim to leave a gap a typical
    # future item can fill, but stay near the proven value early on.
    target = 0.92 * mean

    score = -np.abs(residual - target)

    # Strongly reward near-exact tight fits so full bins get finished.
    tight = np.where(residual <= 8, 1e6 - residual * 1e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END
