# EVOLVE-BLOCK-START
"""Best-fit with a learned residual-utility tie-breaker.

Pure best-fit puts the item in the bin whose residual after placement is smallest.
That minimizes immediate waste but can leave tiny unusable slivers.  Here we keep
best-fit as the dominant criterion (so behavior only changes among bins whose
residuals are close) and break near-ties using an estimate of how "reusable" the
resulting residual is given the observed item-size distribution: residuals that
are exact item sizes or match common small item sizes are favored, tiny unusable
slivers are penalized.
"""
import numpy as np


class _State:
    def __init__(self):
        # histogram of item sizes seen so far (index 0..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.total = 0.0
        # cache of utility table keyed by total count bucket (cheap recalcs)
        self.util = None
        self.util_at = -1


_S = _State()


def _build_utility():
    """Utility of a residual value r in 0..100: chance it can be filled later."""
    hist = _S.hist
    total = _S.total
    util = np.zeros(101, dtype=np.float64)
    if total < 1.0:
        return util
    p = hist / total  # probability of each item size
    # probability mass of item sizes <= r (a single item can still fit)
    cum = np.cumsum(p)  # cum[s] = P(size <= s)
    for r in range(101):
        if r == 0:
            util[r] = 1.0  # perfectly filled, fully "useful"
            continue
        if r == 100:
            util[r] = 0.0  # empty leftover, no benefit
            continue
        # probability a future item exactly fits into r
        pexact = p[r] if r <= 100 else 0.0
        # probability some item fits at all
        pfit = cum[r]
        # expected fraction of r consumable: weight exact fits highly,
        # and value residuals that can still host a typical small item.
        # combine: exact fill bonus + general reusability, normalized by r
        utility = (3.0 * pexact + 0.7 * pfit) / (1.0 + 0.05 * r)
        util[r] = utility
    return util


def priority(item, bins):
    """Rank bins: best fit first, near-ties broken by residual reusability."""
    _S.hist[item] += 1.0
    _S.total += 1.0

    residual = bins - item  # >= 0 since item fits

    # Base: pure best-fit -> smaller residual is better.
    base = -residual.astype(np.float64)

    # Build/refresh utility table occasionally.
    if _S.util is None or (_S.total - _S.util_at) >= 50.0:
        _S.util = _build_utility()
        _S.util_at = _S.total

    util = _S.util
    # clip residuals into 0..100 for lookup (they always are)
    ur = util[np.clip(residual, 0, 100)]

    # Combine: best-fit dominates, utility breaks near-ties.
    # Scale base so a residual difference of 1 unit outweighs utility differences
    # (utility is in [0, ~1.1]), i.e. base_range ~ 100 dominates util_range ~ 1.
    score = base * 1.0 + ur * 0.9
    return score
# EVOLVE-BLOCK-END
