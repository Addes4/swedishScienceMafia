# EVOLVE-BLOCK-START
"""Adaptive best-fit: avoid unusable slivers, but keep leftovers refillable by typical items."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "min_size": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = _state["n"]
    s = _state["sum"]
    _state["n"] = n + 1
    _state["sum"] = s + item
    if item < _state["min_size"]:
        _state["min_size"] = item

    mn = _state["min_size"]
    # cap at the smallest item seen so far (at least 1): leftovers smaller than that
    # can never be filled by a single future item, so treat them as equally bad.
    cap = max(mn, 1)

    residual = bins - item
    score = -np.minimum(residual, cap)

    # Gentle bonus for leftovers near the running mean item size, i.e. leftovers
    # that a single typical future item could refill exactly.
    if n >= 8:
        mean = s / n
        if mean >= 1.0:
            score = score - 0.01 * np.abs(residual - mean)

    return score
# EVOLVE-BLOCK-END

