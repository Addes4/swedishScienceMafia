# EVOLVE-BLOCK-START
"""Target-residual best fit with a distribution-adaptive sweet spot."""
import numpy as np

# State shared across calls within a stream.
_count = 0
_mean = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _count, _mean
    # Update running mean of past items to set an adaptive sweet spot.
    _count += 1
    _mean += (item - _mean) / _count
    # Sweet spot near mean item size: leftover gaps shaped to fit one later item.
    target = float(_mean) if _count > 1 else 35.0
    target = min(max(target, 30.0), 45.0)

    residual = bins - item
    score = -np.abs(residual - target)
    tight = np.where(residual <= 8, 1e6 - residual * 1e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END

