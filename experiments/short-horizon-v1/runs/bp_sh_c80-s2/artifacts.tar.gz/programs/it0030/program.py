# EVOLVE-BLOCK-START
"""Best fit with a smooth reward for usable leftovers.

Placing the item in the bin with the smallest residual (best fit) minimizes
waste. We keep that as the dominant term but break near-ties in favor of
residuals that are themselves reusable, and strongly discourage tiny slivers
by a smooth reciprocal penalty rather than a hard cap.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest
    score (first bin on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacities of every fitting bin, in bin order.
    """
    residual = bins - item
    # Dominant term: prefer tightest fit (smallest residual).
    tight = -residual.astype(np.float64)
    # Smooth penalty for tiny unusable slivers; vanishes for residuals >= 1.
    sliver = 1.0 / (residual.astype(np.float64) + 1.0)
    return tight + sliver
# EVOLVE-BLOCK-END

