# EVOLVE-BLOCK-START
"""Target-residual best fit with a distribution-derived sweet spot."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    if _COUNT >= 30:
        target = 0.90 * mean + 0.15 * sd
    else:
        target = 38.0

    # Base: prefer residual close to the distribution sweet spot.
    score = -np.abs(residual - target)

    # Best-fit tilt: among bins with small residual, strongly prefer the tightest
    # fits so we keep packing into partially filled bins before opening new ones.
    score -= 0.06 * residual

    # Gentle completion bonus for near-exact fits.
    tight = np.where(residual <= 10, 4e4 - residual * 2e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END
