# EVOLVE-BLOCK-START
"""Target-residual bin choice: prefer tight fits, but steer residuals away from
useless slivers toward sizes that can still be filled by future items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Prefer tight fits (small residual), but reward residuals that are 0 (perfect fill)
    # or large enough to accept another typical item, penalizing stranded slivers.
    # A sliver is a residual too small to fit most future items.
    score = -residual.astype(np.float64)

    # Perfect fill: strongly preferred.
    perfect = (residual == 0)
    score[perfect] += 500.0

    # Penalize unusable slivers (1..15) - these often become wasted space.
    sliver = (residual > 0) & (residual < 16)
    score[sliver] -= 40.0

    # Reward residuals near a common mid item size so the bin stays useful.
    useful = (residual >= 16) & (residual < 45)
    score[useful] += 5.0

    return score
# EVOLVE-BLOCK-END
