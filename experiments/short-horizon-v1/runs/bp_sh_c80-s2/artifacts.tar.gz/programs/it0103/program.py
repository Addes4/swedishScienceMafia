# EVOLVE-BLOCK-START
"""Probability-of-exact-match bin choice driven by a running item-size histogram."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)  # counts of item sizes seen so far
_COUNT = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _COUNT

    _HIST[item] += 1.0
    _COUNT += 1

    residual = bins.astype(np.float64) - float(item)

    if _COUNT < 20:
        # Not enough history: fall back to best-fit (smallest nonnegative residual).
        score = -residual
        # strong completion bonus to finish near-full bins
        score = score + np.where(residual <= 8, 5e4 - residual * 3e3, 0.0)
        return score

    freq = _HIST / _COUNT  # empirical pmf over item sizes

    # Sharp completion term: reward residuals that a plausible future item can exactly fill.
    r = np.clip(residual.astype(np.int64), 0, 100)
    match_prob = freq[r]           # probability a future item equals this residual
    # Also reward residuals that can be finished with a small number of items:
    # approximate by near-residual probability over a small window.
    window = np.zeros_like(residual)
    for d in range(-4, 5):
        idx = np.clip(r + d, 0, 100)
        window += freq[idx]
    # weight window by how close it is (tighter windows more valuable)
    window /= 9.0

    # Base: prefer bins that leave a residual likely to be filled, plus mild best-fit.
    score = 6e4 * match_prob + 4e3 * window - 0.35 * residual
    return score
# EVOLVE-BLOCK-END
