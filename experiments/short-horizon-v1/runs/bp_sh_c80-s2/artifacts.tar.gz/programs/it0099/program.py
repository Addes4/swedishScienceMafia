# EVOLVE-BLOCK-START
"""Best-fit-first with target-residual tie-breaking."""
import numpy as np

_TOTAL = 0
_COUNT = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _TOTAL, _COUNT

    # Running estimate of the item mean (fall back to the known ~40 before warm-up).
    _TOTAL += item
    _COUNT += 1
    mean = _TOTAL / _COUNT

    residual = bins - item

    # Primary key: prefer the tightest fit (smallest residual). Bins with residual
    # equal to 0 (exact fill) rank highest.
    tight_score = -residual.astype(np.float64)

    # Secondary key: among near-equal fits, prefer a residual near the sweet spot
    # so that remaining gaps can still absorb typical future items.
    target = 0.92 * mean if _COUNT >= 20 else 38.0
    sweet_score = -np.abs(residual - target)

    # Combine: tight fit dominates, sweet spot breaks close ties.
    return tight_score * 1.0 + sweet_score * 1e-3
# EVOLVE-BLOCK-END
