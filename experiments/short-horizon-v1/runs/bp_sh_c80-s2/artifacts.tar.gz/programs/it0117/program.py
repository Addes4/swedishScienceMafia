# EVOLVE-BLOCK-START
"""Target-residual best fit with a smooth exponential completion bonus."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    if _COUNT >= 30:
        target = 0.90 * mean + 0.15 * sd
    else:
        target = 38.0

    # Dominant term: prefer residuals near the sweet spot.
    score = -np.abs(residual - target)

    # Smooth completion bonus: peaks at exact fit, decays smoothly with no discontinuity.
    # Scale grows with item size (waste matters more for big items).
    scale = 6e4 * (1.0 + item / 100.0)
    completion = scale * np.exp(-residual * residual / 200.0)
    # Only reward genuine near-exact fits; ignore large residuals.
    completion = np.where(residual <= 25, completion, 0.0)

    return score + completion
# EVOLVE-BLOCK-END

