# EVOLVE-BLOCK-START
"""Target-residual best fit with a distribution-derived sweet spot."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0
_PLACED = 0
_OPEN = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ, _PLACED, _OPEN

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    # Count currently used (non-empty) bins for a density signal.
    used = int(np.count_nonzero(bins < 100))
    _OPEN = used

    if _COUNT >= 30:
        # Target residual: aim to leave a gap a typical item can fill.  A slightly
        # sub-mean target reduces large residual waste for skewed (Weibull) sizes.
        target = 0.90 * mean + 0.15 * sd
    else:
        target = 38.0

    score = -np.abs(residual - target)

    # Completion bonus strength adapts to packing density: when few bins are open
    # relative to items seen, favor the soft sweet-spot ranking; once space is
    # fragmented, strongly reward near-perfect fills to consolidate leftovers.
    density = used / max(_PLACED, 1)
    strength = 2.0e4 * min(1.0, density * 1.5)
    tight = np.where(residual <= 10, strength - residual * (strength / 5.0), 0.0)

    return score + tight


def _update_placed():
    global _PLACED
    _PLACED += 1
# EVOLVE-BLOCK-END
