# EVOLVE-BLOCK-START
"""Target-residual best fit with an item-aware sweet spot."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    if _COUNT >= 30:
        # Distribution-derived sweet spot: leave a gap a typical item can fill.
        target = 0.90 * mean + 0.15 * sd
    else:
        target = 38.0

    # Blend in the item's own complement: if the residual equals `item`, the bin can
    # be exactly completed by another item of this size.  Weight grows with item size
    # so large items (which are harder to place) get more of this pairing preference.
    w = item / 100.0
    target = (1.0 - 0.35 * w) * target + (0.35 * w) * item

    score = -np.abs(residual - target)

    # Gentle completion bonus: reward small residuals.
    tight = np.where(residual <= 10, 4e4 - residual * 2e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END

