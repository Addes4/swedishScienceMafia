# EVOLVE-BLOCK-START
"""Target-residual best fit with distribution-aware exact-completion bonus."""
import numpy as np

# Module-level running histogram of item sizes (persists across calls in a stream).
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SEEN = np.zeros(101, dtype=bool)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL
    residual = bins - item

    # Update running histogram with the current item (represents past arrivals).
    if item <= 100:
        _HIST[item] += 1.0
        _SEEN[item] = True
        _TOTAL += 1.0

    target = 35.0
    score = -np.abs(residual - target)

    # Distribution-aware completion bonus: residual r is attractive if r equals
    # some item size observed so far (so a future item can fill it exactly).
    # Weight by observed frequency (smoothed) so common sizes matter more.
    r = residual
    valid = (r >= 1) & (r <= 100)
    ri = np.clip(r, 0, 100).astype(np.int64)
    freq = _HIST[ri] / (_TOTAL + 1.0) if _TOTAL > 0 else np.zeros_like(r, dtype=np.float64)
    # Reward exact-match residuals strongly, scaled by how common that size is.
    match = valid & _SEEN[ri]
    bonus = np.where(match, 1e6 + freq * 1e6, 0.0)

    # Also keep a mild bonus for very tight fits (small residuals) so near-full
    # bins are finished even if that exact size hasn't been seen yet.
    tight = np.where(valid & (r <= 8), 1e3 - r * 10.0, 0.0)

    return score + bonus + tight
# EVOLVE-BLOCK-END
