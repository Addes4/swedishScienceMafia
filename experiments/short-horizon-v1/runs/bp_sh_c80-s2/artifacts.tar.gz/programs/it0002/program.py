# EVOLVE-BLOCK-START
"""Best fit with a small nudge to avoid tiny unusable residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, with a tiny preference for exact fits and against tiny gaps."""
    residual = bins - item
    # Base: prefer smallest resulting residual (classic best fit).
    score = -residual.astype(np.float64)
    # Bonus for exact fits (residual == 0): strongly rewarding leaves no waste.
    score += (residual == 0) * 0.5
    # Slight penalty for leaving a tiny residual (1..3), which tends to be hard to reuse.
    tiny = (residual > 0) & (residual <= 3)
    score -= tiny * 0.25
    return score
# EVOLVE-BLOCK-END
