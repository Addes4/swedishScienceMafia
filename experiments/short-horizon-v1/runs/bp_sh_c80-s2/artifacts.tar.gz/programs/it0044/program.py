# EVOLVE-BLOCK-START
"""Harmonic best fit: strongly prefer the bin that the item fills most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)
    # Reciprocal residual: 1/residual grows without bound as residual -> 0, so near-exact
    # fills dominate; +1 keeps it finite and monotone. This concentrates fill into the
    # tightest bins, which greedy packing on this distribution generally likes.
    return 1.0 / (residual + 1.0)
# EVOLVE-BLOCK-END

