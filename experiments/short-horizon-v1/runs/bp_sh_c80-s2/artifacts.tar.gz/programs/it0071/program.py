# EVOLVE-BLOCK-START
"""Best-fit dominant ranking with a gentle sweet-spot bias for loose fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for every bin shown

    # Primary: best fit -- prefer the smallest residual.  Tighter fits leave
    # less fragmentation and are almost always the right call in online packing.
    # Use a steep monotone decreasing function of residual so the ordering is
    # strictly by tightness.
    primary = -residual.astype(np.float64)

    # Secondary: among similarly tight fits, bias residual toward a sweet spot
    # slightly below the mean item size so leftover gaps tend to be filled by a
    # single later item.  Scaled small so it never overrides a tighter fit.
    target = 35.0
    secondary = -0.05 * np.abs(residual - target)

    return primary + secondary
# EVOLVE-BLOCK-END
