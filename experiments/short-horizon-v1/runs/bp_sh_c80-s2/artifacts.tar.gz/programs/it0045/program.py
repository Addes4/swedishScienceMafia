# EVOLVE-BLOCK-START
"""Harmonic best fit: strongly prefer tight fills, gently prefer flexible gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: harmonic term strongly rewards tight fits (residual 0 best).
    # Secondary: tiny linear bonus for larger residual to avoid shredding gaps.
    return 1.0 / (1.0 + residual) + 0.0005 * residual
# EVOLVE-BLOCK-END
