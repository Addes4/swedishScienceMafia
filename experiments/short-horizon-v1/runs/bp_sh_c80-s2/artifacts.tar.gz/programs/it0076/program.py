# EVOLVE-BLOCK-START
"""Target-residual best fit with mild two-item fillability bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item

    # Proven base: symmetric distance to a sweet-spot residual.
    target = 35.0
    score = -np.abs(residual - target)

    # Strongly reward exact/near-exact tight fits so full bins get finished.
    tight = np.where(residual <= 8, 1e6 - residual * 1e3, 0.0)

    # Mild lookahead: bias larger residuals toward values that are likely sums of
    # two future items, without disturbing tight-fit behaviour.
    # Use a fixed, distribution-informed table of common 2-item sums (mean ~40).
    # Build a coarse weight: residuals near multiples/typical combos of items get a boost.
    # Only apply for residuals well above the tight window.
    look = np.zeros_like(residual, dtype=np.float64)
    mask = residual > 8
    r = residual[mask]
    # approximate two-item-sum density by a smooth bump around ~40+40=80 and ~40+20=60,
    # with broad support; scaled small enough not to override the base ordering.
    w = np.exp(-((r - 80.0) ** 2) / (2 * 18.0 ** 2)) + 0.6 * np.exp(-((r - 60.0) ** 2) / (2 * 15.0 ** 2))
    look[mask] = 200.0 * w

    return score + tight + look
# EVOLVE-BLOCK-END
