# EVOLVE-BLOCK-START
"""Best fit with a stateful gap-filling bonus for residuals matching common item sizes."""
import numpy as np

# State kept across calls within a stream.
_hist = np.zeros(101, dtype=np.float64)
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _seen

    residual = bins - item
    # Base: capped best fit, preferring tight fits but flattening among slivers.
    score = -np.minimum(residual, 25).astype(np.float64)

    # Gap-filling bonus: prefer a residual whose value is a common recent item size,
    # so leftover gaps get closed by items that fit them exactly.
    if _seen > 20:
        freq = _hist / _seen
        # Only look at plausible residuals (items fit in these bins, residual >= 0).
        r = residual
        valid = (r >= 0) & (r <= 100)
        idx = np.where(valid, r, 0).astype(np.int64)
        commonness = freq[idx]
        bonus = 20.0 * commonness
        score = score + np.where(valid, bonus, 0.0)

    # Record this item size for future gap estimation.
    _hist[item] += 1.0
    _seen += 1
    return score
# EVOLVE-BLOCK-END
