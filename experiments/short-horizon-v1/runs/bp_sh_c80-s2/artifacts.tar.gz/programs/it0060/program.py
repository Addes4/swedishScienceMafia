# EVOLVE-BLOCK-START
"""Best-fit core with a mild sweet-spot tie-breaker."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Core: best-fit.  Tighter fits are strongly preferred so full bins get finished.
    score = -residual.astype(np.float64)

    # Secondary: among comparably tight fits, mildly reward residuals near a sweet
    # spot (~ mean item size) so leftovers are shaped to fit a likely future item.
    target = 32.0
    near = -np.abs(residual.astype(np.float64) - target) * 0.05

    # Strong reward for exact/near-exact tight fits so bins nearing full get closed.
    tight = np.where(residual <= 6, 1e5 - residual * 1e2, 0.0)

    return score + near + tight
# EVOLVE-BLOCK-END
