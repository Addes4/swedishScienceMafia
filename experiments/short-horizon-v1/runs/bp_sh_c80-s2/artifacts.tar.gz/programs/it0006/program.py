# EVOLVE-BLOCK-START
"""Best fit with a nudge away from unusable tiny residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 because bins only contains fitting bins
    # Base: prefer tight fits (small residual).
    score = -residual.astype(np.float64)
    # Penalize unusable tiny slivers (residual in 1..4) that can't hold many future items.
    small = (residual >= 1) & (residual <= 4)
    score[small] -= 3.0
    return score
# EVOLVE-BLOCK-END

