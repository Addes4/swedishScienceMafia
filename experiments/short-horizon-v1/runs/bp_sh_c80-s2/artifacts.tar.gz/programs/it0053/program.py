# EVOLVE-BLOCK-START
"""Target-residual best fit: aim for a post-placement residual near a sweet spot."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer a residual near a target sweet spot.
    target = 26.0
    # For tight fits (residual <= target) tighter is always better; beyond the
    # target larger residuals are gently penalized (not fully flattened), so
    # among roomy bins we still avoid wasting the fullest ones.
    score = -np.abs(residual - target)
    # Strongly reward exact/near-exact tight fits so full bins get finished.
    tight = np.where(residual <= 5, 1e6 - residual * 1e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END

