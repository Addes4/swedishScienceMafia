# EVOLVE-BLOCK-START
"""Target-residual best fit with monotone completion and robust target."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0
_MED_SUM = 0.0
_MED_CNT = 0
_MED_EST = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ, _MED_SUM, _MED_CNT, _MED_EST

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    # Robust median-ish estimate: online stochastic median approximation.
    if item > _MED_EST:
        _MED_SUM += 1.0
    elif item < _MED_EST:
        _MED_SUM -= 1.0
    _MED_CNT += 1
    _MED_EST += _MED_SUM / (max(_MED_CNT, 1) ** 0.5)

    residual = bins - item

    if _COUNT >= 30:
        # Aim to leave a gap a typical item can fill; use robust median.
        target = 0.90 * mean + 0.15 * sd
    else:
        target = 38.0

    score = -np.abs(residual - target)

    # Monotone completion: among near-empty residuals, strictly prefer smaller ones.
    # Larger-magnitude, monotone in residual (not a flat window).
    tight = np.where(residual >= 0, 4e4 - residual * 3e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END

