# EVOLVE-BLOCK-START
"""Concave residual-gap ranking with a distribution-derived sweet spot."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = (bins - item).astype(np.float64)

    if _COUNT >= 30:
        # Sweet-spot residual: leave a gap a typical item can fill.  Slightly below
        # the mean to counter Weibull skew.
        target = 0.90 * mean + 0.15 * sd
    else:
        target = 38.0

    scale = 0.35 * mean + 0.10 * sd
    if scale < 1e-6:
        scale = 1.0

    # Concave utility: penalize distance from the sweet-spot target, but with a
    # saturating slope so far-off bins aren't over-penalized relative to near ones.
    d = np.abs(residual - target) / scale
    score = -np.sqrt(d * d + 1.0)

    # Exact-fill bonus: strongly prefer residuals very close to zero so leftover
    # space is consolidated instead of fragmented.
    tight = np.where(residual <= 8, 5000.0 - residual * 400.0, 0.0)
    return score + tight
# EVOLVE-BLOCK-END
