# EVOLVE-BLOCK-START
"""Best fit with a strong bonus for exact fits (zero residual)."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Prefer tightest fit (smallest residual). Exact fits get a tiny extra edge so
    # perfectly filled bins are chosen over equally-tight alternatives that leave residue.
    return -(residual) + (residual == 0).astype(np.int64) * 1e-6
# EVOLVE-BLOCK-END

