# EVOLVE-BLOCK-START
"""Empirical size-frequency matching: prefer bins whose residual is a likely future item size."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _total

    # Update empirical histogram of observed item sizes.
    _counts[item] += 1.0
    _total += 1.0

    residual = bins - item  # remaining capacity if this item is placed here

    # Probability that a future item exactly fills the residual (residual is an
    # integer size 0..100). Add-one smoothing so all residuals get some weight.
    freq = _counts / (_total + 1.0) + 1.0 / ((_total + 1.0) * 101.0)

    # Residue that can't hold any item (0) is useless; small residues are risky.
    prob_match = freq[residual]
    # Bonus for small residual (near-complete bins are good) with diminishing weight,
    # but dominated by the empirical "will this residual get filled" signal.
    small = 100.0 / (residual + 2.0)

    # Reward expected future fill of this residual, lightly favoring tight fits.
    return prob_match * 1e6 + small
# EVOLVE-BLOCK-END
