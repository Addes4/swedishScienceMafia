# EVOLVE-BLOCK-START
"""Best-fit base with a completion bonus for residuals matching likely item sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Best-fit base: smaller residual is always better (fills bins tightly and
    # avoids opening new bins).  Scale dominates the bonus tie-breaking below.
    score = -residual.astype(np.float64)

    # Completion bonus: a residual is wasted unless a later item can fill it.
    # Bias toward residuals that match likely future item sizes and, most of
    # all, toward residuals small enough to be finished by a common item.
    r = residual
    # Reward residuals likely to be filled by a single later item: the smaller
    # the residual, the more likely a matching item arrives.
    bonus = np.where((r >= 0) & (r <= 40), 5.0 * (41.0 - r), 0.0)
    # Explicit strong reward for very small residuals (finish the bin now).
    bonus += np.where((r >= 0) & (r <= 12), 30.0 * (13.0 - r), 0.0)
    # Avoid creating residuals in the awkward mid-range that tends to be wasted.
    penalty = np.where((r > 12) & (r < 55), 0.5, 0.0)

    return score + bonus - penalty
# EVOLVE-BLOCK-END
