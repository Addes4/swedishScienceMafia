# EVOLVE-BLOCK-START
"""Best fit with a smooth concave residual transform."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Smooth concave penalty: strongly prefer tight fits, but never fully
    # flatten the ranking of looser bins, so large gaps stay distinguishable.
    return -np.sqrt(residual.astype(np.float64))
# EVOLVE-BLOCK-END
