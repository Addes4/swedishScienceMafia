# EVOLVE-BLOCK-START
"""Target-residual best fit with a distribution-derived sweet spot."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0
# Simple running histogram of item sizes to estimate the distribution shape.
_HIST = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ, _HIST

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    _HIST[item] += 1.0

    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    if _COUNT >= 30:
        # Estimate a good target residual using the empirical distribution:
        # the target is the size s (1..100) maximizing  P(item == s)  weight on
        # "a future item exactly fills this bin", i.e. weight by frequency and
        # by how likely such an item is to drop into an opened bin.  We approximate
        # by choosing the size near the mean-to-median region with high frequency.
        total = _HIST.sum()
        # Candidate sizes in a plausible range; pick the most frequent size that is
        # at least a bit below the mean, favoring a fillable-but-not-wasteful gap.
        lo = max(1, int(mean * 0.35))
        hi = min(100, int(mean * 1.15))
        if hi < lo:
            hi = lo
        window = _HIST[lo:hi + 1]
        if window.size > 0 and window.max() > 0:
            best_local = int(np.argmax(window))
            target_pick = lo + best_local
        else:
            target_pick = 0.90 * mean + 0.15 * sd
        # Blend the empirical mode with the affine formula for stability.
        target = 0.6 * target_pick + 0.4 * (0.90 * mean + 0.15 * sd)
    else:
        target = 38.0

    score = -np.abs(residual - target)

    # Completion bonus: reward small residuals so near-perfect fills win.
    tight = np.where(residual <= 10, 4e4 - residual * 2e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END

