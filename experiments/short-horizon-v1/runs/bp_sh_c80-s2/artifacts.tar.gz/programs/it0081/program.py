# EVOLVE-BLOCK-START
"""Target-residual best fit: aim for a post-placement residual near a sweet spot."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer a residual near a target sweet spot, but never create a tiny sliver
    # if a tighter fit is available.  Score is highest when residual ~= target.
    # Sweet spot chosen near the mean item size (~40) so leftover gaps are likely
    # to be filled by a single later item.
    target = 38.0
    # For tight fits (residual <= target) tighter is always better; beyond the
    # target, larger residuals are penalized since they break a fuller bin.
    score = -np.abs(residual - target)
    # Strongly reward exact/near-exact tight fits so full bins get finished.
    tight = np.where(residual <= 8, 1e6 - residual * 1e3, 0.0)
    return score + tight
# EVOLVE-BLOCK-END
