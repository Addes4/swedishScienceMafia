# EVOLVE-BLOCK-START
"""Target-residual best fit with a distribution-derived sweet spot."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    if _COUNT >= 30:
        target = 0.90 * mean + 0.15 * sd
    else:
        target = 38.0

    score = -np.abs(residual - target)

    # Tight completion reward.  Scale the slope with item size so that heavy items
    # aggressively prefer near-exact fills (where fragmentation hurts most),
    # while light items keep the sweet-spot behavior.
    slope = 2e3 * (1.0 + item / 40.0)
    tight = np.where(residual <= 10, 4e4 - residual * slope, 0.0)
    return score + tight
# EVOLVE-BLOCK-END
