# EVOLVE-BLOCK-START
"""Target-residual best fit with a completion-probability tight bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Base shaping: prefer a residual near a target sweet spot, favoring tighter
    # fits below the target (they leave less slack in fuller bins).
    target = 35.0
    score = -np.abs(residual - target)

    # Tight-fit completion bonus: within the proven window, reward residuals that
    # a future single item is most likely to exactly fill.  Probability is read
    # from a running histogram of past item sizes (Laplace-smoothed).
    hist = _state["hist"]
    total = _state["total"]
    prob = np.zeros(101, dtype=np.float64)
    if total > 0:
        prob = (hist + 1.0) / (total + 100.0)

    r = np.clip(residual, 1, 100).astype(np.int64)
    completion = prob[r]

    in_window = residual <= 8
    # Scale completion prob into a bonus comparable to the base score differences,
    # amplifying so that a well-filled sliver strongly beats leaving slack.
    bonus = np.where(in_window, completion * 4e4, 0.0)

    # Also record this item into the histogram for future calls.
    _update(item)

    return score + bonus


_state = {"hist": np.zeros(101, dtype=np.float64), "total": 0}


def _update(item):
    if 1 <= item <= 100:
        _state["hist"][item] += 1.0
        _state["total"] += 1
# EVOLVE-BLOCK-END
