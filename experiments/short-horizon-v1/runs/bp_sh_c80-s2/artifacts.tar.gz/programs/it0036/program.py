# EVOLVE-BLOCK-START
"""Harmonic best-fit: strongly prefer near-exact fills over merely tight fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Reciprocal score: a bin that becomes exactly full (residual 0) scores 1.0,
    # and the score decays sharply as the leftover grows. This makes the rule
    # favor near-exact fills much more strongly than any linear/ capped best-fit,
    # reducing fragmentation from intermediate leftovers.
    return 1.0 / (residual + 1.0)
# EVOLVE-BLOCK-END
