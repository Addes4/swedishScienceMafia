# EVOLVE-BLOCK-START
"""Target-residual best fit with an asymmetric completion bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Sweet spot near the mean item size (~40) so leftover gaps can be filled later.
    target = 35.0
    score = -np.abs(residual - target)

    # Completion bonus: strongly reward residuals that are small (bin nearly full),
    # so full bins get finished; tighter fits are always preferred.
    completion = np.where(residual <= 10, 1e6 - residual * 1e3, 0.0)

    # Mild penalty for parking an item in a nearly empty bin, which wastes space;
    # this pushes items into already-open bins and reduces bin count.
    waste = -residual * 0.5

    return score + completion + waste
# EVOLVE-BLOCK-END

