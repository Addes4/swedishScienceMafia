# EVOLVE-BLOCK-START
"""Target-residual best fit with a distribution-derived sweet spot."""
import numpy as np

_TOTAL = 0
_COUNT = 0
_SQ = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _COUNT, _SQ

    _TOTAL += item
    _COUNT += 1
    _SQ += float(item) * item
    mean = _TOTAL / _COUNT
    var = max(_SQ / _COUNT - mean * mean, 0.0)
    sd = var ** 0.5

    residual = bins - item

    if _COUNT >= 30:
        # Target residual: aim to leave a gap a typical item can fill.
        target = 0.90 * mean + 0.15 * sd
    else:
        target = 38.0

    score = -np.abs(residual - target)

    # Strong reward for landing very close to an exact fill (residual near 0),
    # which consolidates leftover space and reduces the number of bins used.
    exact = np.where(residual <= 3, 1e5 - residual * 1e3, 0.0)

    # Gentle completion bonus for moderately tight bins keeps medium bins useful.
    tight = np.where((residual > 3) & (residual <= 10), 8e3 - residual * 6e2, 0.0)

    return score + exact + tight
# EVOLVE-BLOCK-END

