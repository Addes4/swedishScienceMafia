# EVOLVE-BLOCK-START
"""Best fit with stateful reusable-residual preference.

Rank bins by tightest fit (largest bin residual after placement, i.e. smallest
post-placement residual), but among near-tight fits prefer a residual that is a
near-multiple of the running mean item size, so gaps stay reusable. State is a
simple running mean of observed item sizes, which adapts to the distribution
without seeing the future.
"""
import numpy as np

_STATE = {"sum": 0.0, "count": 0}


def priority(item, bins):
    # Update running mean of item sizes (state persists within a stream).
    st = _STATE
    st["sum"] += item
    st["count"] += 1
    mean = st["sum"] / st["count"]
    if mean < 1.0:
        mean = 40.0

    residual = bins - item  # >= 0 for bins shown

    # Primary: best fit -> smaller residual is better (negative residual).
    # Secondary bonus: reward residuals near a multiple of the running mean,
    # scaled small so it only breaks near-ties.
    m = residual.astype(np.float64) / mean
    frac = m - np.round(m)
    bonus = -np.abs(frac)  # in [-0.5, 0]

    return -residual.astype(np.float64) + 0.5 * bonus
# EVOLVE-BLOCK-END
