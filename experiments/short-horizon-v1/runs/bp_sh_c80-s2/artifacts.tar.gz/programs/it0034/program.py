# EVOLVE-BLOCK-START
"""Best fit with a sliver penalty calibrated to the item distribution."""
import numpy as np

# Module-level running state (reset per stream by the harness loading fresh modules).
_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties).

    Prefer the tightest fit, but mildly penalize creating a residual so small it is
    unlikely to ever be filled again (a sliver). Sliver threshold scales with the
    running mean item size so it adapts to the distribution.
    """
    s = _state
    s["sum"] += item
    s["count"] += 1
    mean_item = s["sum"] / s["count"]

    residual = bins - item  # >= 0 for all shown bins

    # Sliver guard: penalize residuals smaller than roughly a quarter of a typical item.
    sliver = mean_item * 0.25
    penalty = np.where(residual < sliver, (sliver - residual), 0.0)

    # Rank: smallest residual first (best fit), then avoid slivers.
    return -residual.astype(np.float64) - penalty
# EVOLVE-BLOCK-END
