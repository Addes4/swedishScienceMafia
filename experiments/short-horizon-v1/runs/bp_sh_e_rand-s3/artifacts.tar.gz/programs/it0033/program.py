# EVOLVE-BLOCK-START
"""Best fit, with a slight preference to reuse fuller bins on ties."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit (smallest residual), tie-broken to reuse fuller bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary: prefer the smallest residual (tightest fit).
    score = -residual.astype(np.float64)

    # Tiebreak: among comparable residuals, prefer fuller bins (smaller remaining
    # capacity means the bin is closer to full and reusing it conserves empty bins).
    score += (100 - bins).astype(np.float64) * 1e-3

    return score
# EVOLVE-BLOCK-END

