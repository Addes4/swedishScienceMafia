# EVOLVE-BLOCK-START
"""Best fit with a mean-aligned tiebreaker for residual reuse."""
import numpy as np

_mean = None
_count = 0


def priority(item, bins):
    """Rank bins by best fit; break near-ties toward reusable residuals."""
    global _mean, _count

    # Update running estimate of the mean item size.
    _count += 1
    if _mean is None:
        _mean = float(item)
    else:
        _mean += (item - _mean) / _count
    mu = _mean if _mean and _mean > 1.0 else 40.0

    residual = bins - item  # >= 0

    # Strict best-fit dominance: each unit of residual costs 1.
    score = -residual.astype(np.float64)

    # Tiebreaker: among bins with equal residual, prefer residuals that are
    # close to a multiple of the typical item size (reusable gaps). This is a
    # small, sub-unit perturbation so it never overrides best fit.
    nonzero = residual > 0
    r = residual.astype(np.float64)
    # distance to nearest multiple of mu
    k = np.round(r / mu)
    dist = np.abs(r - k * mu)
    # closeness bonus in [0, 1), scaled to < 1 so it cannot beat 1 unit of residual
    bonus = np.where(nonzero, 1.0 - dist / (0.5 * mu), 0.0)
    bonus = np.clip(bonus, 0.0, 0.999)
    score += bonus

    return score
# EVOLVE-BLOCK-END

