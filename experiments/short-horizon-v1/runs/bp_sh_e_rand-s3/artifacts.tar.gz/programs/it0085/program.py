# EVOLVE-BLOCK-START
"""Best fit with adaptive residual valuation from a rolling item-size histogram."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "count": 0.0}


def priority(item, bins):
    residual = bins - item  # >= 0

    # Update rolling histogram of past item sizes (exponential decay).
    hist = _state["hist"]
    hist *= 0.995
    hist[item] += 1.0
    _state["count"] = _state["count"] * 0.995 + 1.0
    total = hist.sum()

    score = -residual.astype(np.float64)

    if total > 50.0:
        freq = hist / total  # probability mass over sizes 1..100
        # Bonus if residual can be exactly refilled by a common item size.
        r = residual
        # gather freq at those residuals that are valid sizes 1..100
        valid = (r >= 1) & (r <= 100)
        refill_bonus = np.zeros_like(score)
        idx = np.where(valid)[0]
        if idx.size:
            refill_bonus[idx] = freq[r[idx].astype(np.int64)]
        # weight the bonus enough to break near-ties in best-fit
        score += 3.0 * refill_bonus

    # Penalize tiny nonzero residuals that are effectively stranded.
    tiny = (residual > 0) & (residual < 3)
    score -= tiny.astype(np.float64) * 1.2

    return score
# EVOLVE-BLOCK-END
