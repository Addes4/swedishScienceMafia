# EVOLVE-BLOCK-START
"""Best fit with a mild penalty for stranded tiny residuals and a
usability bonus for keeping a full average-sized slot free."""
import numpy as np

_state = {"mean": 40.0, "n": 0.0}


def priority(item, bins):
    """Rank bins by best fit, penalizing useless tiny residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Update a running estimate of the typical item size.
    n = _state["n"]
    _state["mean"] = (_state["mean"] * n + item) / (n + 1.0)
    _state["n"] = n + 1.0
    mean_item = _state["mean"]

    score = -residual.astype(np.float64)

    # Penalize tiny nonzero residuals (likely stranded capacity); exact fills unpenalized.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny.astype(np.float64) * 1.5

    # Mild bonus when the leftover can still hold a typical future item.
    usable = (residual > 0) & (residual >= mean_item)
    score += usable.astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
