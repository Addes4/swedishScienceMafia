# EVOLVE-BLOCK-START
"""Best fit that avoids stranding unusable residuals."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Rank bins preferring the best fit with a reusable residual.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Track the smallest item size seen so far as a proxy for the smallest
    # residual that might still be reusable by a future item.
    if item < _state["min_item"]:
        _state["min_item"] = item
    m = _state["min_item"]

    score = np.zeros(residual.shape, dtype=np.float64)

    # Exact fills are always best.
    exact = residual == 0
    # Usable residuals: keep the gap >= m so future items can still fit.
    usable = residual >= m

    # Best usable fit: smaller usable residual preferred (large bonus range).
    score += np.where(usable, 100.0 - residual.astype(np.float64), 0.0)
    # Exact fills dominate everything.
    score += np.where(exact, 1000.0, 0.0)
    # Remaining (unusable, nonzero) bins: fall back to plain best fit.
    fallback = ~usable & ~exact
    score += np.where(fallback, 50.0 - residual.astype(np.float64), 0.0)

    return score
# EVOLVE-BLOCK-END
