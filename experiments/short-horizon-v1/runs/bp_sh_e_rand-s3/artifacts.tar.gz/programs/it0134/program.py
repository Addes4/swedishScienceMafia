# EVOLVE-BLOCK-START
"""Best fit with a smooth, item-size-aware penalty for stranded residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals that are hard to reuse.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins
    r = residual.astype(np.float64)

    # Base best-fit preference: smaller residual is better.
    score = -r

    # A residual is "usable" if a typical future item (mean ~40, mostly >= ~15)
    # could reasonably fill it. Penalize small nonzero residuals, which tend to
    # become stranded capacity. Exact fills (residual 0) are ideal: no penalty.
    # Use a smooth, size-aware threshold so large items don't strand medium gaps.
    thresh = 12.0
    small = (residual > 0) & (residual < thresh)
    score -= small.astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END
