# EVOLVE-BLOCK-START
"""Best fit softened by a concave utility on the residual.

The item goes to the bin that, after placement, leaves a residual that is
either exactly zero (perfect fill) or as large/usable as possible.  Pure
best-fit aggressively minimizes the residual, which strands small gaps; a
concave utility -1/(r+1) keeps exact fills dominant while a tiny linear
push toward larger usable gaps reduces fragmentation.
"""
import numpy as np


def priority(item, bins):
    residual = (bins - item).astype(np.float64)  # >= 0

    # Concave utility: r = 0 -> -1 (best), decreasing magnitude for larger r.
    score = -1.0 / (residual + 1.0)

    # Mild preference for larger usable residuals so tiny stranded gaps
    # are avoided when a looser bin fits just as well.
    score += 0.002 * residual

    return score
# EVOLVE-BLOCK-END

