# EVOLVE-BLOCK-START
"""Best fit with residual scoring tied to the empirical item-size distribution."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Rank bins by best fit, with a mild residual-quality bonus.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    # Update running statistics from past items (does not include current item).
    n = _state["n"]
    s = _state["sum"]
    hist = _state["hist"]
    if 1 <= item <= 100:
        hist[item] += 1.0
    _state["n"] = n + 1
    _state["sum"] = s + item

    residual = bins - item  # >= 0 for all shown bins

    # Primary: best fit (smaller residual better).
    score = -residual.astype(np.float64)

    # Estimate P(future item == r) from rolling histogram.
    total = hist.sum()
    if total > 0:
        p = hist / total
    else:
        p = np.zeros(101, dtype=np.float64)

    res_int = residual.astype(np.int64)
    res_clip = np.clip(res_int, 0, 100)
    # Bonus: probability that the exact residual can be perfectly refilled.
    bonus = p[res_clip]
    score += 50.0 * bonus

    # Mild penalty for tiny stranded residuals (can't fit most items).
    if total > 1:
        mean_size = _state["sum"] / _state["n"]
    else:
        mean_size = 40.0
    # Probability that a random future item fits into the residual.
    frac_fits = np.array(
        [p[: int(r) + 1].sum() if r >= 0 else 0.0 for r in res_clip],
        dtype=np.float64,
    )
    score += 10.0 * frac_fits / max(mean_size, 1.0)

    return score
# EVOLVE-BLOCK-END
