# EVOLVE-BLOCK-START
"""Pure best fit: choose the bin with the smallest non-negative residual."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit (smallest residual after placing the item).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
