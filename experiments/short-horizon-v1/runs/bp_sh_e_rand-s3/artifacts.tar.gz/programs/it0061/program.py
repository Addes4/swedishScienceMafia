# EVOLVE-BLOCK-START
"""Best fit with an adaptive penalty for residuals smaller than observed items."""
import numpy as np

_MIN_ITEM = 100  # smallest positive item seen so far (persistent state)


def priority(item, bins):
    """Rank bins by best fit; penalize gaps too small to ever be reused."""
    global _MIN_ITEM
    if item < _MIN_ITEM:
        _MIN_ITEM = item

    residual = bins - item  # >= 0 for all shown bins

    # Best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Residuals strictly between 0 and the smallest item seen so far are
    # stranded; penalize them so we prefer slightly looser usable bins.
    # Scale the penalty by how far below the reusable threshold the gap is.
    threshold = _MIN_ITEM
    if threshold > 1:
        gap = residual.astype(np.float64)
        # For 0 < residual < threshold, penalty grows as residual is smaller.
        usable = residual >= threshold
        stranded = (residual > 0) & (~usable)
        # Strength up to 1.5, larger for very small gaps.
        strength = 1.5 * (threshold - gap) / max(threshold - 1, 1)
        score -= np.where(stranded, strength, 0.0)

    return score
# EVOLVE-BLOCK-END
