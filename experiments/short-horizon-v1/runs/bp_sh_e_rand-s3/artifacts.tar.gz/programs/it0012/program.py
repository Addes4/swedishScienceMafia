# EVOLVE-BLOCK-START
"""Fill-ratio targeting: aim to leave each bin with a moderate residual,
balancing tight packing against stranding unusable leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # post-item remaining capacity, >= 0 by construction
    # Target: leave the bin at a fill ratio near 0.85 (residual ~15),
    # so we neither waste by overflowing a bin's slack nor strand a
    # tiny unusable leftover. Score = closeness of residual to target.
    target = 15.0
    return -(np.abs(residual - target))
# EVOLVE-BLOCK-END
