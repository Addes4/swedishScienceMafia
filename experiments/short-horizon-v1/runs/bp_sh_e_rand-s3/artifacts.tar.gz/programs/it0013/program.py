# EVOLVE-BLOCK-START
"""Best fit with a residual-utility adjustment for future items.

Pure best fit minimizes the immediate leftover, but that often strands a bin
with a residual smaller than almost any future item, wasting the bin.  Here we
rank bins primarily by the post-placement residual (best fit), but add a small
bonus for residuals that are still large enough to accept a typical future
item.  The bonus is small so exact/tight fits are still strongly preferred.
"""
import numpy as np

# Items are ~Weibull with mean ~40; a residual near this is "useful".
_TYP = 40.0


def priority(item, bins):
    residual = bins - item  # bins already only contains fitting bins, so >= 0
    # Best fit: smaller residual is better -> negative residual.
    score = -residual.astype(np.float64)
    # Mild bonus for residuals that remain useful for a typical future item,
    # tapering off once the residual is comfortably large (avoid hoarding).
    useful = np.clip(residual / _TYP, 0.0, 1.0)
    score += 0.5 * (useful * (1.0 - 0.5 * useful))
    return score
# EVOLVE-BLOCK-END
