# EVOLVE-BLOCK-START
"""Waste-aware best fit.

The stream's item sizes are Weibull-shaped with mean ~40.  Plain best fit
minimises the immediate residual, but a residual of e.g. 12 is often just as
"dead" as 20 (few items that small arrive), while a residual of ~40 is very
reusable.  We score each bin by how *usable* the residual left behind is,
estimated from the assumed item-size distribution, and combine that with the
classic best-fit tendency to prefer tighter fits.
"""
import numpy as np

# Assumed item-size distribution (Weibull, shape ~2, scale ~45, clipped to 1..100)
# -> approximate probability that a future item exactly / nearly fits a residual r.
_S = np.arange(0, 101, dtype=np.float64)
# Weibull(shape=2, scale=45) pdf on integer sizes, renormalised over 1..100.
_shape, _scale = 2.0, 45.0
_pdf = (_shape / _scale) * (_S / _scale) ** (_shape - 1.0) * np.exp(-(_S / _scale) ** _shape)
_pdf[0] = 0.0
_pdf[1:] = _pdf[1:]  # keep as-is; item sizes start at 1
_pdf = _pdf / _pdf[1:].sum()

# Probability mass that fits in a residual r (size <= r).
_cdf = np.cumsum(_pdf)
_cdf = np.clip(_cdf, 0.0, 1.0)


def _usability(residual):
    """How likely a fresh item is to fit into `residual` capacity."""
    r = np.clip(residual, 0, 100)
    return _cdf[r.astype(np.int64)]


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    post = bins - item  # remaining capacity after placing the item (>= 0 by construction)

    # Preferred: smallest post-residual (classic best fit), scaled to [0,1].
    best_fit = -(post.astype(np.float64))

    # Secondary: prefer a bin whose leftover is more likely to be reusable later.
    # Multiply by a small weight so it only breaks near-ties in the best-fit order.
    reuse = _usability(post)

    return best_fit * 100.0 + reuse
# EVOLVE-BLOCK-END
