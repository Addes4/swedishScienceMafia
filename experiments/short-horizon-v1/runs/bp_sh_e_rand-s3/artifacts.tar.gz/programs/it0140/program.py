# EVOLVE-BLOCK-START
"""Best fit, with a strong exact-fill reward for large items only."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit; reward exact fills when the item is large.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary key: smaller residual is better (best fit).
    score = -residual.astype(np.float64)

    # Exact fills are always valuable, but for small items exact fills are common
    # and best-fit already finds them. For large items an exact fill is rare and
    # saves a whole bin's worth of stranded capacity, so boost those strongly.
    if item >= 30:
        exact = (residual == 0)
        score += exact.astype(np.float64) * (item * 0.5)

    return score
# EVOLVE-BLOCK-END

