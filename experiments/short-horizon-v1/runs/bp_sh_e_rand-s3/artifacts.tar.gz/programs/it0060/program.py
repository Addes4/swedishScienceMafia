# EVOLVE-BLOCK-START
"""Best fit with a bonus for leaving a residual that matches recent item sizes."""
import numpy as np

_FREQ = np.zeros(101, dtype=np.float64)
_SEEN = 0


def priority(item, bins):
    """Rank bins by best fit, with a bonus for reusable residuals.

    Primary: smaller residual is better.
    Secondary: among similar residuals, prefer a residual equal to a size that has
    recently appeared (so the leftover gap is likely to be reused by a future item).
    Exact fills are always best.
    """
    global _SEEN

    residual = bins - item  # >= 0

    # Update frequency of observed item sizes (exponential forgetting).
    _FREQ *= 0.995
    _FREQ[item] += 1.0
    _SEEN += 1

    # Base best-fit preference.
    score = -residual.astype(np.float64)

    # Bonus if the residual is a historically frequent item size (reusable gap).
    freq_norm = _FREQ / (_FREQ.sum() + 1e-12)
    bonus = freq_norm[residual] * 1.0
    score += bonus

    return score
# EVOLVE-BLOCK-END
