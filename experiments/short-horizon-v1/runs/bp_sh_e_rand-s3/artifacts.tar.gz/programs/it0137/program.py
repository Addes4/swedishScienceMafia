# EVOLVE-BLOCK-START
"""Best fit enriched with exact-completion rewards learned from the stream.

The item distribution is fixed and discrete (items are integers 1..100). When we place an
item we leave a residual; if that residual equals a size that commonly appears, the gap is
likely to be fillable, which is good. We track, online, how often each integer size has been
seen, and reward residuals that match a frequent future item size.
"""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, floating unused-capacity bins down.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = (bins - item).astype(np.float64)  # >= 0 for all shown bins

    # Get the module-level histogram (lazily created).
    hist = _get_hist()

    # Primary: strict best fit (smallest residual). Secondary: reward residuals that
    # exactly match a frequently-seen item size, so the leftover gap is fillable.
    freq = hist[bins - item] if True else None  # placeholder, replaced below
    res_int = (bins - item)
    freq_weights = hist[res_int]  # counts of items equal to the residual

    total = hist.sum()
    if total > 0:
        freq = freq_weights.astype(np.float64) / float(total)
    else:
        freq = np.zeros_like(freq_weights, dtype=np.float64)

    # Small weight: best fit dominates, frequency breaks ties toward fillable gaps.
    score = -residual + 2.0 * freq

    # Record this item for future frequency estimates.
    hist[item] += 1
    return score


def _get_hist():
    global _HIST
    try:
        return _HIST
    except NameError:
        _HIST = np.zeros(101, dtype=np.int64)
        return _HIST
# EVOLVE-BLOCK-END
