# EVOLVE-BLOCK-START
"""Best fit with an adaptive penalty for genuinely stranded residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small to ever be reused.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    state = priority.state
    # Track the minimum item size observed so far in this stream.
    if item < state['min_item']:
        state['min_item'] = item
    if state['count'] < 200:
        state['count'] += 1

    residual = bins - item  # >= 0 for all shown bins

    # Dominant best-fit preference: smaller residual is much better.
    score = -residual.astype(np.float64) * 10.0

    # Penalize residuals that cannot hold even the smallest item seen so far
    # (genuinely stranded capacity). Exact fills (residual 0) must not be
    # penalized, since they are ideal.
    squeezed = (residual > 0) & (residual < state['min_item'])
    score -= squeezed.astype(np.float64) * 3.0

    return score


priority.state = {'min_item': 101, 'count': 0}
# EVOLVE-BLOCK-END
