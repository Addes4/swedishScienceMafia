# EVOLVE-BLOCK-START
"""Adaptive best fit with a learned "unusable residual" penalty."""
import numpy as np


class _State:
    def __init__(self):
        self.sum = 0.0
        self.count = 0


_state = _State()


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small to be reusable.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Learn the typical item size from the stream so far (includes current item).
    # A residual below the typical size is unlikely to be exactly reused, so treat
    # it as (nearly) stranded capacity and softly discourage it.
    mean_size = (_state.sum + item) / (_state.count + 1)

    # A residual is "usable" if it is at least the typical item size. Penalize
    # residuals below that threshold, scaling with how far below they fall.
    # Exact fills (residual 0) are ideal and never penalized.
    deficit = mean_size - residual
    penalty = np.where((residual > 0) & (deficit > 0),
                       np.minimum(deficit, mean_size) / max(mean_size, 1.0),
                       0.0)
    score -= penalty

    # Update running statistics.
    _state.sum += item
    _state.count += 1

    return score
# EVOLVE-BLOCK-END
