# EVOLVE-BLOCK-START
"""Best fit with a target-residual preference based on the running mean item size."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, nudging toward residuals close to a typical item size.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins
    residual_f = residual.astype(np.float64)

    # Dominant term: strict best fit (smaller residual strongly preferred).
    score = -residual_f * 1000.0

    # Secondary term: among effectively equal residuals, prefer the one closest to a
    # target gap size (approx. mean item size), which tends to leave usable space.
    mean = getattr(priority, "_mean", 40.0)
    n = getattr(priority, "_n", 0)
    # update running mean with current item
    n += 1
    mean = mean + (item - mean) / n
    priority._mean = mean
    priority._n = n

    score -= np.abs(residual_f - mean)

    return score
# EVOLVE-BLOCK-END
