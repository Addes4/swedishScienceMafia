# EVOLVE-BLOCK-START
"""Pure best fit: place each item in the bin with the smallest sufficient residual."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit (smallest remaining capacity that still fits the item).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Smaller residual is strictly better; ties break to the earliest bin.
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

