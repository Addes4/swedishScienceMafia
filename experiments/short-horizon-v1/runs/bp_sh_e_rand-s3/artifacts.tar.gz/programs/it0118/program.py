# EVOLVE-BLOCK-START
"""Best fit with a learned usefulness score for the resulting residual."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, breaking ties via residual usefulness.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better (dominant term).
    score = -residual.astype(np.float64) * 1000.0

    # Tie-break among near-equal residuals: prefer resulting residuals that can still
    # hold reasonably-sized future items rather than a sliver. Exact fill (0) is best.
    # Value residuals by how many "typical" (~40) items they could still shelter, but
    # gently: this only reshuffles near-ties, it never overrides a clearly smaller fit.
    useful = residual.astype(np.float64)
    # bonus for being able to host another medium item, decayed smoothly
    score += 0.5 * np.minimum(useful, 60.0)

    # exact fill is ideal
    score += (residual == 0).astype(np.float64) * 200.0

    # tiny slivers are wasteful
    score -= ((residual > 0) & (residual < 10)).astype(np.float64) * 5.0

    return score
# EVOLVE-BLOCK-END
