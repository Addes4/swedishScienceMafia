# EVOLVE-BLOCK-START
"""Best-fit with a tail-aware reserve: keep a small buffer of near-empty bins for large items."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, but nudge small items away from pristine (empty) bins
    so the empty bins remain available for large items from the Weibull tail.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    # Base: tightest fit (most negative residual -> we negate later)
    score = -(bins - item)

    # Nudge small items away from pristine bins (bins[..] == 100) so they stay
    # as overflow buffers for the long right tail of the size distribution.
    if item <= 60:
        # small penalty for choosing an unused bin
        score -= (bins == 100) * 1e-3
    return score
# EVOLVE-BLOCK-END

