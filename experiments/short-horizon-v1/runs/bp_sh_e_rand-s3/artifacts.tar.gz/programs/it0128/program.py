# EVOLVE-BLOCK-START
"""Best fit with a gentle exact-fit bonus and mild tiny-residual penalty."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit; prefer exact fills, gently avoid tiny residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Strict best-fit: smaller residual is better.
    score = -residual.astype(np.float64)

    # Reward exact fills slightly.
    score += (residual == 0).astype(np.float64) * 0.25

    # Gently penalize tiny nonzero residuals (stranded capacity) without
    # disturbing the strong best-fit ordering.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny.astype(np.float64) * 0.25

    return score
# EVOLVE-BLOCK-END
