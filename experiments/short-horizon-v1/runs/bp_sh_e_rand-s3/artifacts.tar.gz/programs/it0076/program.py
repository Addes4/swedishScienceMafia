# EVOLVE-BLOCK-START
"""Best fit with residual-quality scaling to reduce stranded space."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals that are likely stranded.

    Primary signal is best fit (smallest residual).  A residual that is smaller
    than the typical future item tends to be wasted; scale that penalty by the
    residual so it never overrides a real best-fit preference for equal-quality
    residuals, and never penalize an exact fill.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize small nonzero residuals that are hard to refill later.  The
    # penalty grows as the residual shrinks toward 1, but stays small enough
    # not to distort meaningful best-fit gaps.
    small = (residual > 0) & (residual < 6)
    penalty = np.where(small, (6.0 - residual) / 6.0, 0.0)
    score -= penalty

    return score
# EVOLVE-BLOCK-END
