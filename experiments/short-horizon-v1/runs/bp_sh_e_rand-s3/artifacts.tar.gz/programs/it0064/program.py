# EVOLVE-BLOCK-START
"""Best fit with a small penalty for leaving unusable tiny residuals."""
import numpy as np

_state = {"min_item": 101}


def priority(item, bins):
    """Rank bins by best fit, but penalize residuals too small to be useful.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    if item < _state["min_item"]:
        _state["min_item"] = item
    m = _state["min_item"]

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize nonzero residuals smaller than the smallest item seen so far,
    # since such gaps can never be reused by a future item.
    tiny = (residual > 0) & (residual < m)
    score -= tiny.astype(np.float64) * 1.5

    return score
# EVOLVE-BLOCK-END

