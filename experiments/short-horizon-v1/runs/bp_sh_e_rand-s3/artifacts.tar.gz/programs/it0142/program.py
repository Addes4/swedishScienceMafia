# EVOLVE-BLOCK-START
"""Best fit with a decaying item-size histogram tiebreaker."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_seen = 0


def priority(item, bins):
    """Strict best-fit; break near-ties using a decaying item-size histogram.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _seen
    _seen += 1

    residual = bins - item  # >= 0 for all shown bins

    # Strict best-fit ordering on the residual (smaller is better).
    score = -residual.astype(np.float64)

    # Decaying histogram of recent item sizes: boost bins whose residual exactly
    # matches a frequently-seen recent item size (enables exact fills later).
    decay = 0.99
    _hist *= decay
    _hist[item] += 1.0

    # Only as a tiny tiebreaker so best-fit ordering is preserved.
    match_bonus = _hist[residual] * 1e-4
    score += match_bonus

    return score
# EVOLVE-BLOCK-END
