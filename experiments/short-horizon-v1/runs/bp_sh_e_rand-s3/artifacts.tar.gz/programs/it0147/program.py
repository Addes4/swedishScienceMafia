# EVOLVE-BLOCK-START
"""Best fit with a graded penalty for residuals that strand capacity."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, mildly penalizing residuals too small to reuse.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # A residual of 0 is a perfect fill and must never be penalized.
    # Small nonzero residuals below a typical item size tend to strand capacity,
    # so apply a mild, graded penalty that grows as the residual shrinks toward 1.
    # We use a fixed, well-below-1 scale so exact-fit ordering is preserved by a
    # full unit of residual, but fractions still influence near-ties.
    tiny = (residual > 0) & (residual < 8)
    score -= tiny.astype(np.float64) * (
        1.0 - (residual.astype(np.float64) - 1.0) / 7.0
    ) * 0.5

    return score
# EVOLVE-BLOCK-END

