# EVOLVE-BLOCK-START
"""Best fit with a small-residual avoidance tweak.

Pure best fit places an item into the bin it fits most tightly, which minimizes
immediate waste but frequently strands bins with tiny residuals that no future
Weibull item (mean ~40) can use.  Keep best fit as the dominant rule but prefer
bins whose post-placement residual is at least a small floor, only falling back
to the tightest residual when nothing else is available.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first tie)."""
    residual = bins - item  # remaining capacity after placing the item

    # A bin is "usable afterwards" if its residual could still hold a small item.
    # Items are Weibull with mean ~40, so residuals below a few units are wasted.
    floor = 3
    usable = residual >= floor

    # Primary: usable bins first.  Secondary: smallest usable residual (best fit).
    # Fallback: if a bin is not usable, order by smallest residual.
    score = np.where(usable, 1000.0 - residual, -residual.astype(np.float64))
    return score
# EVOLVE-BLOCK-END
