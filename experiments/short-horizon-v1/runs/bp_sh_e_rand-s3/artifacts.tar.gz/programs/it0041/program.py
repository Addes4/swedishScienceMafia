# EVOLVE-BLOCK-START
"""Best fit with an adaptive penalty for unusable tiny residuals."""
import numpy as np


class _State:
    def __init__(self):
        self.min_seen = 100  # smallest item size observed so far
        self.n = 0

    def update(self, item):
        if item < self.min_seen:
            self.min_seen = item
        self.n += 1


_state = _State()


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals below the observed min item size.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    _state.update(item)

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # A residual below the smallest item seen so far can never be reused by a future
    # item of that size or larger; penalize such stranded capacity (but not residual 0,
    # which is a perfect fill).
    limit = _state.min_seen
    stranded = (residual > 0) & (residual < limit)
    score -= stranded.astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END
