# EVOLVE-BLOCK-START
"""Best fit with a small penalty for leaving an unfillable residual hole."""
import numpy as np

_state = {"min_size": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Track the smallest item seen so far as an estimate of the smallest gap
    # that is still useful. Residuals below this are likely unfillable holes.
    m = _state["min_size"]
    if item < m:
        m = item
        _state["min_size"] = m

    residual = bins - item

    # Best fit: minimize residual. Add a small penalty when the residual is a
    # small positive hole below the smallest observed item size (likely wasted),
    # which nudges ties toward not stranding tiny gaps.
    hole_penalty = np.where((residual > 0) & (residual < m), 0.5, 0.0)
    return -(residual + hole_penalty)
# EVOLVE-BLOCK-END
