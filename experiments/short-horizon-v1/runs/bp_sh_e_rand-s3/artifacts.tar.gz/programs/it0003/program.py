# EVOLVE-BLOCK-START
"""Best fit with a mild concave residual preference and tie-breaking on "useful" leftovers."""
import numpy as np


def priority(item, bins):
    """Score bins: primary best-fit, secondary preference for useful residual capacities.

    The item goes into the bin with the highest score (first on ties).
    """
    residual = bins - item  # >= 0 since bins only contains fitting bins
    # Primary: best fit -- smaller residual is better.
    # Use a concave transform so that very tight fits stay strongly preferred,
    # while among larger residuals we still favor tighter fits but less sharply,
    # reducing wasted stranded space across many bins.
    fit_score = -np.sqrt(residual.astype(np.float64) + 1.0)

    # Secondary: after placing, which residual capacities are "useful"?
    # Capacities near 0 (empty after fill) are ideal; bins ending full-ish are good.
    # Prefer residual small, but also avoid leaving the bin just barely too small
    # for a typical item. We add a small bonus for residual near 0.
    bonus = 1.0 / (residual.astype(np.float64) + 1.0)

    return fit_score + 0.01 * bonus
# EVOLVE-BLOCK-END
