# EVOLVE-BLOCK-START
"""Best fit with a recency (aging) tiebreaker among near-equal residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, breaking near-ties by bin recency.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # primary: best fit -> smaller residual is better
    score = -residual.astype(np.float64)

    # secondary: prefer bins whose residual is closest to 0 but, among
    # residuals within a narrow band of the minimum, break ties toward the
    # bin with the largest remaining capacity that is still tight
    # (i.e., avoid stranding tiny residuals by consolidating).
    min_res = residual.min()
    band = (residual - min_res) <= 1
    # among the band, favorite is the one with the smallest residual;
    # penalize the "tiny nonzero residual" case slightly when a looser
    # but still tight bin (residual <= 2 larger) exists.
    tiny = band & (residual > 0)
    score -= tiny.astype(np.float64) * (residual.astype(np.float64) < 3)

    return score
# EVOLVE-BLOCK-END

