# EVOLVE-BLOCK-START
"""Best fit with a tiny penalty for stranded residuals, plus a tie-break."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalize unusable tiny residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary: best fit -> smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize tiny nonzero residuals (stranded capacity), but never penalize
    # residual == 0 (a perfect fill).
    tiny = (residual > 0) & (residual < 5)
    score -= tiny.astype(np.float64) * 1.5

    # Tie-break: when residuals are equal, prefer the bin with slightly more
    # remaining capacity (larger residual) to keep flexibility. The epsilon is
    # far smaller than 1, so it only breaks exact ties.
    score += residual.astype(np.float64) * 1e-3

    return score
# EVOLVE-BLOCK-END
