# EVOLVE-BLOCK-START
"""Best fit with a convex penalty on residual, amplifying tight fits."""
import numpy as np


def priority(item, bins):
    """Rank bins by a convex (squared) best-fit key.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = (bins - item).astype(np.float64)  # >= 0 for all shown bins

    # Convex penalty: strongly prefers tighter fits, but never rewards leaving
    # large free space (unlike worst-fit). Exact fills (residual 0) dominate.
    return -(residual * residual)
# EVOLVE-BLOCK-END

