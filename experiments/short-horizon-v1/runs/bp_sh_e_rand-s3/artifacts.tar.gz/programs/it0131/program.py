# EVOLVE-BLOCK-START
"""Best fit with a stateful, distribution-aware residual penalty."""
import numpy as np


_state = {"min_item": 101, "small_items": 0, "count": 0}


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small to be refilled.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    # Track the smallest item seen so far; residuals below this are likely stranded.
    if item < _state["min_item"]:
        _state["min_item"] = item
    _state["count"] += 1

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Smallest usable future item (stateful estimate of the distribution floor).
    min_item = _state["min_item"]
    if min_item < 1:
        min_item = 1

    # Penalize positive residuals too small to fit the smallest item seen so far.
    stranded = (residual > 0) & (residual < min_item)
    score -= stranded.astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END
