# EVOLVE-BLOCK-START
"""Best fit with a small bonus for residuals that match common future item sizes."""
import numpy as np

_TARGET_RESIDUALS = (20, 25, 30, 35, 40, 45, 50)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Dominant term: best fit (smallest residual is best).
    score = -residual.astype(np.float64)
    # Tiny bonus when the residual matches a common item size, so that a future
    # item can complete the bin cleanly. Keep it small to not override best fit.
    for t in _TARGET_RESIDUALS:
        score += 1e-3 * (residual == t).astype(np.float64)
    return score
# EVOLVE-BLOCK-END
