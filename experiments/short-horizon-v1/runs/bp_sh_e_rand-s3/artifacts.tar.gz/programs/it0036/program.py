# EVOLVE-BLOCK-START
"""Best-fit with a worst-fit tiebreak among near-tight bins."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tight fits, but among near-tight bins prefer larger residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary key: smaller residual is better.  Secondary: among the tightest
    # handful of bins, prefer the one leaving the most reusable free space.
    # Implement as a base score of -residual plus a bounded bonus for bins
    # whose residual is close to the minimum feasible residual.
    min_res = residual.min()
    near = residual <= min_res + 2  # tolerance window
    score = -residual.astype(np.float64)
    score += near.astype(np.float64) * (residual.astype(np.float64) * 0.5)
    return score
# EVOLVE-BLOCK-END

