# EVOLVE-BLOCK-START
"""Best fit with graded penalties for stranded residuals and a small bonus for reusable ones."""
import numpy as np

# Bounded memory of recently seen item sizes (module state per stream).
_recent = []
_RECENT_CAP = 32


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small to be reused.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _recent
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Graded penalty for tiny nonzero residuals (likely stranded capacity).
    tiny = (residual > 0) & (residual < 5)
    score[tiny] -= (5 - residual[tiny]) * 0.4

    # Small bonus when the leftover equals a size we've recently seen as an item,
    # since such a residual is more likely to be filled exactly later.
    if _recent:
        recent = np.array(_recent, dtype=np.int64)
        reusable = np.isin(residual, recent)
        score[reusable] += 0.3

    # Update bounded history (keep it cheap).
    _recent.append(int(item))
    if len(_recent) > _RECENT_CAP:
        _recent.pop(0)

    return score
# EVOLVE-BLOCK-END
