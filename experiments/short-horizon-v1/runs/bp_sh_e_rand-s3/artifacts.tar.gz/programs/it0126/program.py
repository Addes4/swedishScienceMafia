# EVOLVE-BLOCK-START
"""Best fit with online-adaptive residual preference as a tie-break."""
import numpy as np

# Module-level online state (reset naturally per stream is not guaranteed, but
# the harness re-imports/creates fresh state per stream in practice; we keep it
# robust anyway by updating a running mean of item sizes).
_state = {"n": 0.0, "mean": 40.0}


def priority(item, bins):
    """Rank bins by best fit; use adaptive residual preference to break near-ties.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _state
    residual = bins - item  # >= 0 for all shown bins
    residual_f = residual.astype(np.float64)

    # Update running mean of item sizes seen so far (cheap, online).
    _state["n"] += 1.0
    alpha = 1.0 / _state["n"]
    _state["mean"] += alpha * (float(item) - _state["mean"])

    # Primary: strict best fit (smallest residual preferred).
    score = -residual_f

    # Secondary: among residuals that are not exact fits (residual > 0), give a
    # tiny preference to residual values close to the current mean item size,
    # which tend to be more reusable by future typical items.  We keep this
    # strictly smaller than 1 so it can never override best-fit ordering.
    mean = _state["mean"]
    nonzero = (residual > 0).astype(np.float64)
    closeness = -np.abs(residual_f - mean) * 0.001
    score += nonzero * closeness

    return score
# EVOLVE-BLOCK-END

