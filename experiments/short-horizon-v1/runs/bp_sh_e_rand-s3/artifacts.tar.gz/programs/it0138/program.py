# EVOLVE-BLOCK-START
"""Best fit, plus a small bonus for residuals that match a common item size."""
import numpy as np


class _State:
    def __init__(self):
        # histogram of recent item sizes (1..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0


_state = _State()


def priority(item, bins):
    """Rank bins by best fit, with a small bonus for a likely-fillable residual.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Small stateful bonus: if the residual equals a size that has appeared
    # frequently recently, a future item may fill this bin exactly. Only apply
    # once enough history exists so short streams keep pure best-fit (score 1.0).
    if _state.count >= 40:
        freq = _state.hist / _state.count
        # bonus proportional to recent frequency of the residual size, capped
        # so it never overturns a genuinely tighter fit by much.
        idx = np.clip(residual, 0, 100).astype(np.int64)
        score += freq[idx] * 2.0

    # update history after scoring (exclude very first items gently)
    _state.hist[item] += 1.0
    _state.count += 1

    return score
# EVOLVE-BLOCK-END
