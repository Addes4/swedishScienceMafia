# EVOLVE-BLOCK-START
"""Balance-aware fit: prefer tight fits while avoiding stranded capacity."""
import numpy as np


def priority(item, bins):
    """Rank bins using a best-fit base plus a waste-balancing term.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item          # >= 0
    r = residual.astype(np.float64)

    # Primary: tightest fit (smaller residual better).
    score = -r

    # Secondary, tiny: avoid leaving residuals that are too small to be reusable,
    # but never let this override a strictly tighter fit by more than a fraction.
    # Waste term grows as residual shrinks toward 0 but is capped below 1 unit.
    waste = 1.0 / (r + 1.0)         # larger for small residuals
    score -= 0.5 * waste

    return score
# EVOLVE-BLOCK-END
