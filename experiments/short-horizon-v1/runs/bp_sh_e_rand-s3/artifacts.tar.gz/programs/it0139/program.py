# EVOLVE-BLOCK-START
"""Best fit with a bonus for leaving a residual that matches common item sizes."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Rank bins by best fit, rewarding residuals that match frequent item sizes.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    hist = _state["hist"]
    hist[item] += 1.0
    _state["n"] += 1.0

    residual = bins - item  # >= 0 for all shown bins

    # Primary best-fit signal: smaller residual is better.
    score = -residual.astype(np.float64)

    # Secondary: reward leaving a residual that equals a reasonably frequent item
    # size (ideal for exact fills), weighted small enough not to disturb best fit.
    freq = hist / _state["n"]
    matched = freq[np.clip(residual, 0, 100)]
    # zero out residual==0 bonus path conflict: exact fill already best, but keep reward
    score += matched * 3.0

    return score
# EVOLVE-BLOCK-END
