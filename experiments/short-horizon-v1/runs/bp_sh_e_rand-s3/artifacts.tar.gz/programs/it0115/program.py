# EVOLVE-BLOCK-START
"""Harmonic-style classification: bucket bins by residual/item ratio."""
import numpy as np


def priority(item, bins):
    """Rank bins by a harmonic-style ratio rule.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins.astype(np.float64) - float(item)  # >= 0 for all shown bins

    # ratio of the item's "fill fraction" of the bin: item / (item + residual)
    # Prefer bins where the item fills a large fraction but leaves a residual that
    # is at least a decent chunk (classic harmonic buckets).
    total = residual + float(item)
    fill = float(item) / total  # in (0, 1], higher = fuller

    # Harmonic-style penalty: group residuals into relative buckets. Bins whose
    # residual is a small fraction of the item's size are penalized because they
    # tend to strand tiny unusable gaps.
    rel = residual / float(item)
    penalty = np.where((rel > 0.0) & (rel < 0.5), 0.25, 0.0)

    # Primary: best fit (smaller residual better), refined by harmonic penalty.
    score = -residual - penalty * float(item)

    return score
# EVOLVE-BLOCK-END
