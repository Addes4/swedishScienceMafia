# EVOLVE-BLOCK-START
"""Best fit with an adaptive penalty for residuals that are likely unusable."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small to ever be refilled.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.

    Primary key: smaller residual (best fit).  Secondary, small tie-break: a
    residual that cannot fit the smallest item observed so far is degraded, since
    that capacity is effectively stranded.  The penalty is small so it only
    reorders near-equal fits and never disturbs a clear best fit or an exact fill.
    """
    state = priority.state
    m = state.get("min_item", 100)
    if item < m:
        state["min_item"] = item
        m = item

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Degrade residuals in (0, m): capacity that no seen item can refill.
    if m > 1:
        unusable = (residual > 0) & (residual < m)
        score -= unusable.astype(np.float64) * 0.25

    return score


priority.state = {"min_item": 100}
# EVOLVE-BLOCK-END

