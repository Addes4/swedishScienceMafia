# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus and a mild preference for reusable residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, with a strong exact-fill bonus.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins
    r = residual.astype(np.float64)

    # Primary: best fit (smaller residual better), scaled so differences dominate.
    score = -r * 10.0

    # Strong bonus for an exact fill (residual == 0). Exact fills are almost always
    # beneficial: they close a bin perfectly with no wasted capacity.
    score += (residual == 0).astype(np.float64) * 5.0

    # Mild preference among comfortably usable residuals for the largest residual,
    # which tends to reduce stranded small gaps. Tiny nonzero residuals get no bonus.
    usable = residual >= 10
    score += usable.astype(np.float64) * (r * 0.05)

    return score
# EVOLVE-BLOCK-END
