# EVOLVE-BLOCK-START
"""Best fit with an adaptive penalty for unusable residuals."""
import numpy as np

_MIN_SEEN = [101]  # smallest nonzero item size observed in this stream


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small to ever be used.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    if 0 < item < _MIN_SEEN[0]:
        _MIN_SEEN[0] = item
    tiny_size = _MIN_SEEN[0]  # smallest item we know can appear

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize nonzero residuals strictly below the smallest item ever seen,
    # since no future item can ever fill such a gap. Exact fills (0) are ideal.
    stranded = (residual > 0) & (residual < tiny_size)
    score -= stranded.astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END
