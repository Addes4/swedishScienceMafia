# EVOLVE-BLOCK-START
"""Best fit with a mild pull of residual capacity toward the typical item size."""
import numpy as np

TARGET = 40.0  # approximate mean item size of the distribution


def priority(item, bins):
    """Rank bins by best fit, with a small tiebreak moving residuals toward TARGET.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = (bins - item).astype(np.float64)  # >= 0 for all shown bins

    # Primary: tightest fit (exact fill = 0 residual is best).
    score = -residual

    # Secondary: mildly prefer leftovers near the typical item size, away from
    # both stranded tiny gaps (near 0) and overly large open bins (near 100).
    # Scaled small so it only breaks near-ties and never overrides a tighter fit
    # by more than a fraction of one capacity unit.
    deviation = np.abs(residual - TARGET)
    score -= 0.01 * deviation

    return score
# EVOLVE-BLOCK-END
