# EVOLVE-BLOCK-START
"""Best fit with adaptive residual-usefulness scoring."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, with a mild bonus for residuals near the running mean.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    state = priority.state
    # Running mean / count of items seen (Welford).
    state["n"] += 1
    delta = item - state["mean"]
    state["mean"] += delta / state["n"]

    residual = bins - item  # >= 0 for all shown bins

    # Primary: strict best fit -> smaller residual is better.
    score = -residual.astype(np.float64)

    # Secondary: very mild preference for residuals close to the running mean,
    # so stranded capacity near typical item sizes is slightly favored. Exact
    # fills (residual 0) get a small explicit bonus instead.
    mean = state["mean"]
    if state["n"] > 20:
        close = np.abs(residual - mean)
        score -= 0.02 * close
    # Exact fill bonus (dominant enough to prefer over near fits).
    score += (residual == 0).astype(np.float64) * 0.5

    return score


priority.state = {"n": 0, "mean": 0.0}
# EVOLVE-BLOCK-END
