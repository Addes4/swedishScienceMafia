# EVOLVE-BLOCK-START
"""Best fit with a size-relative penalty for stranding unusable residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals small relative to the item.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize nonzero residuals that are small relative to the item just placed:
    # such a residual is hard to fill with future items of similar/larger size.
    # The threshold scales with the item size so large items don't strand slivers.
    thresh = max(1.0, item * 0.15)
    stranded = (residual > 0) & (residual < thresh)
    score -= stranded.astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END
