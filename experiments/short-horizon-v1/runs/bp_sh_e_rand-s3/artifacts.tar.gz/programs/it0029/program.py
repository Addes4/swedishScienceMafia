# EVOLVE-BLOCK-START
"""Pure best fit: pick the bin with the smallest residual capacity after placing the item.

Best fit is a strong online heuristic for this distribution. Ties (equal residuals) are
broken by preferring the earlier bin index, matching the default tie-breaking rule.
"""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit: smallest remaining capacity after placing the item.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

