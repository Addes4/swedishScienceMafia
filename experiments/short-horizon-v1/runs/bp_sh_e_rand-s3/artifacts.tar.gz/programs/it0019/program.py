# EVOLVE-BLOCK-START
"""Best fit with a residual-utility bonus based on the item-size distribution.

Items are Weibull-ish with mean ~40.  Pure best fit minimizes the leftover, which is
usually good, but it can strand tiny residuals that no future item can use while
leaving larger bins under-used.  We keep best-fit as the dominant term and add a small
bonus that rewards leaving a residual that matches a typical future item size (i.e. a
residual our next item is likely to consume exactly or nearly exactly).
"""
import numpy as np

# Representative Weibull(size=100*scale) with mean ~40.  We use a simple discrete
# approximation of the item size distribution to build a residual-utility table.
# U(a) = expected fraction of a residual a that a random arriving item would fill,
# i.e. P(item <= a) weighted toward tight matches.
_rng = np.random.default_rng(12345)
# Weibull with shape k=1.4 gives mean near 40 for scale chosen below.
_k = 1.4
_scale = 40.0 / 0.9114  # gamma(1+1/k) ~= 0.9114 for k=1.4
_samples = np.clip(np.round(_scale * _rng.weibull(_k, size=20000)), 1, 100).astype(np.int64)

# Empirical survival / matching profile: for each residual value a in 0..100,
# score how likely the residual is to be "just fillable" by a future item.
_counts = np.bincount(_samples, minlength=101).astype(np.float64)
_counts /= _counts.sum()

# Build utility: a residual is useful if some common item fits it tightly.
# For residual a, utility = sum_p p(item=s) for s in common sizes <= a, discounted
# by how much slack remains after placing s (tight fit preferred).
_sizes = np.arange(1, 101)
_p = _counts[1:101]
_util = np.zeros(101, dtype=np.float64)
for a in range(0, 101):
    if a == 0:
        _util[a] = 1.0  # perfect completion is best
        continue
    fit = _sizes <= a
    if not np.any(fit):
        _util[a] = 0.0
        continue
    slack = a - _sizes[fit]
    w = _p[fit] * (1.0 / (1.0 + slack))
    _util[a] = w.sum()

# Normalize to reasonable magnitude for the bonus term.
_util = _util / max(_util.max(), 1e-9)


def priority(item, bins):
    """Rank bins: tightest fit first, small bonus for leaving a usable residual."""
    residual = bins - item
    # Base best-fit score: prefer smallest residual (largest score).
    score = -residual.astype(np.float64)
    # Bonus: reward residuals that a future item is likely to consume tightly.
    clipped = np.clip(residual, 0, 100).astype(np.int64)
    score += 0.30 * _util[clipped]
    return score
# EVOLVE-BLOCK-END
