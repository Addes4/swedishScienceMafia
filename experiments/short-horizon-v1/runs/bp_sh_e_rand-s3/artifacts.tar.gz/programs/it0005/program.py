# EVOLVE-BLOCK-START
"""Best fit with a slight reserve of large-empty bins for future large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: strongly prefer small residuals (best fit).
    # Secondary: mildly prefer not to consume the very largest empty bins, so that
    # future large items still have a home. We penalize placing into a leftover-that-was
    # a completely empty bin (residual was 100 before placing) a tiny amount.
    was_empty = (bins == 100)
    return -residual.astype(np.float64) - 0.02 * was_empty
# EVOLVE-BLOCK-END
