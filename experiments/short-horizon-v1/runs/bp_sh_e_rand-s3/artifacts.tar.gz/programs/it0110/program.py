# EVOLVE-BLOCK-START
"""Best fit, refined by distinguishing useful residuals from stranded ones."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Rank bins by best fit, breaking near-ties toward more useful residuals.

    Primary order remains best fit (smallest non-negative residual). We only
    adjust the *relative* ordering among bins whose residuals differ slightly,
    by giving a bonus to residuals that leave room for a typical small item.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item
    m = _state["min_item"]

    residual = (bins - item).astype(np.float64)

    # Strict best fit as the dominant term (scale large enough to be primary).
    score = -1000.0 * residual

    # Secondary: prefer residuals large enough to hold a smallest-seen item
    # (i.e. not stranded), and strongly reward an exact fill.
    useful = residual >= m
    score += useful.astype(np.float64) * 1.0
    score += (residual == 0).astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END
