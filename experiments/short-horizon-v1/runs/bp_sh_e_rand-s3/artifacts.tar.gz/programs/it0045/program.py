# EVOLVE-BLOCK-START
"""Best fit, with a tie-break that prefers the more-filled bin on equal residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit; on equal residual, prefer the smaller remaining capacity.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for every shown bin

    # Primary key: smaller residual is better.
    # Secondary key: on equal residual, prefer the bin with smaller remaining capacity
    # (i.e. the more-filled bin), which mildly consolidates usage.
    # Encode as a single float: residual * BIG + remaining.
    score = -(residual.astype(np.float64) * 1000.0 + bins.astype(np.float64))

    return score
# EVOLVE-BLOCK-END

