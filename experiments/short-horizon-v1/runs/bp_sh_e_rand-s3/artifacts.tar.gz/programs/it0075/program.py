# EVOLVE-BLOCK-START
"""Best fit with a stateful bonus for residuals that match recent item sizes."""
import numpy as np

# Module-level state, reset per stream by reinitialization when needed.
_hist = np.zeros(101, dtype=np.float64)  # counts of recent item sizes 1..100
_count = 0


def priority(item, bins):
    """Rank bins by best fit; mildly reward residuals that recent items can refill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _hist, _count

    residual = (bins - item).astype(np.float64)  # >= 0 for all shown bins

    # Primary: best fit (smallest residual is best).
    score = -residual

    # Exact fill (residual 0) is ideal and must dominate.
    exact = (residual == 0)
    score += exact.astype(np.float64) * 0.5

    # Penalize stranded tiny nonzero residuals that are hard to refill.
    tiny = (residual > 0) & (residual < 4)
    score -= tiny.astype(np.float64) * 1.5

    # Stateful bonus: reward residuals equal to a commonly seen recent item size
    # (likely to be refilled exactly by some future item).
    # Normalize histogram into probabilities.
    if _count > 0:
        probs = _hist / _count
    else:
        probs = _hist
    # Map residual -> probability of that exact size; clip index safely.
    idx = np.clip(residual.astype(np.int64), 0, 100)
    prob = probs[idx]
    score += prob * 3.0

    # Update histogram with a decay so it tracks the distribution.
    _hist *= 0.999
    _count *= 0.999
    _hist[item] += 1.0
    _count += 1.0

    return score
# EVOLVE-BLOCK-END
