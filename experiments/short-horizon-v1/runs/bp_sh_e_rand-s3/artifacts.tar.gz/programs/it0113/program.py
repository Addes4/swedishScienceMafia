# EVOLVE-BLOCK-START
"""Best-fit variant with adaptive anti-fragmentation based on observed items."""
import numpy as np

_state = {"min_item": 100, "count": 0}


def priority(item, bins):
    """Rank bins to reduce stranded tiny residuals while keeping good fits.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _state
    # Update running statistics (only past items are seen).
    if item < _state["min_item"]:
        _state["min_item"] = item
    _state["count"] += 1

    residual = bins - item  # >= 0 for all shown bins
    residual_f = residual.astype(np.float64)

    # Primary: prefer exact fills very strongly.
    score = np.where(residual == 0, 1000.0, 0.0)

    # Secondary: best fit, but with a mild bonus for larger residuals among
    # non-exact fits to preserve room for subsequent medium/small items.
    score -= residual_f

    # Adaptive penalty: residuals too small to fit the smallest item seen so far
    # are likely stranded; penalize them mildly so a slightly looser bin wins.
    min_item = _state["min_item"]
    stranded = (residual > 0) & (residual < min_item)
    score -= stranded.astype(np.float64) * (min_item * 0.5)

    return score
# EVOLVE-BLOCK-END

