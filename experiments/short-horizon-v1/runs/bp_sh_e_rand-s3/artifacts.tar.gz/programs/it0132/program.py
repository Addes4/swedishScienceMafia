# EVOLVE-BLOCK-START
"""Best fit, with a size-scaled bonus for exact fills on large items."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, rewarding exact fills more for large items.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary: best fit (smaller residual is better).
    score = -residual.astype(np.float64)

    # Exact fills are irreversible good moves; for large items they matter much more,
    # since a big bin-consumer is hard to place well later. Reward residual==0 with a
    # bonus proportional to item size (small items keep essentially pure best fit).
    exact = (residual == 0).astype(np.float64)
    score += exact * item

    return score
# EVOLVE-BLOCK-END

