# EVOLVE-BLOCK-START
"""Best fit with a small "exact-fit residual" bonus.

Pure best fit minimizes the post-item residual.  With Weibull-shaped item sizes
(mean ~40) many residuals can never be filled exactly, and a small bonus for
residuals that are *plausible* item sizes nudges the packer to leave holes that
a later item can actually occupy.  This keeps best fit's tendency to pack
tightly while reducing stranded leftover space.
"""
import numpy as np

# Rough support of the item distribution: items are integers 1..100 with a
# Weibull shape centred near 40.  Residuals in this band are worth keeping as
# they have a decent chance of being closed exactly by a future item.
_LOW = 5
_HIGH = 95
_BONUS = 0.5


def priority(item, bins):
    residual = bins - item
    bonus = np.where((residual >= _LOW) & (residual <= _HIGH), _BONUS, 0.0)
    return -residual.astype(np.float64) + bonus
# EVOLVE-BLOCK-END
