# EVOLVE-BLOCK-START
"""Best fit with a smooth anti-fragmentation tie-breaker."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit; break ties so leftover capacity stays usable.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Dominant: strict best fit (smaller residual better).
    score = -1000.0 * residual.astype(np.float64)

    # Secondary: among bins with equal residual, prefer one whose residual is a
    # "useful" size. Residual 0 (exact fill) is best; otherwise a residual at least
    # ~ the mean item size (~40) can still host a typical future item, while tiny
    # nonzero residuals (1..3) are likely stranded. Smooth, bounded so it never
    # overrides the primary best-fit ordering (max swing < 1000).
    r = residual.astype(np.float64)
    # Map residual -> usefulness in [0,1]; peak near 0 and near large residuals,
    # trough for small nonzero residuals.
    useful = np.where(
        r == 0.0,
        1.0,
        1.0 - np.exp(-((r - 40.0) ** 2) / (2.0 * 25.0 ** 2)),
    )
    score += 50.0 * useful
    return score
# EVOLVE-BLOCK-END
