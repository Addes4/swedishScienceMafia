# EVOLVE-BLOCK-START
"""Best fit augmented with a learned lower bound on item size to avoid stranding gaps."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small to ever be refilled.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Track the smallest item size seen so far across the stream (module-level state).
    global _min_seen
    try:
        _min_seen
    except NameError:
        _min_seen = item
    if item < _min_seen:
        _min_seen = item

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize only residuals that are positive but smaller than the smallest item
    # we have ever seen: those gaps can never be filled and are pure waste.
    # Exact fills (residual 0) remain optimal and unpenalized.
    thr = _min_seen if _min_seen > 1 else 1
    stranded = (residual > 0) & (residual < thr)
    score -= stranded.astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END

