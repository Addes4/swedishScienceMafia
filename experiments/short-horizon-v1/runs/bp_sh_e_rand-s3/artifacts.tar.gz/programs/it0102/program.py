# EVOLVE-BLOCK-START
"""Best fit with a small penalty for residuals that no future item can fill."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals smaller than the smallest item seen.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Running minimum item size seen so far (state kept on the function object).
    prev = getattr(priority, "_min_seen", item)
    min_seen = prev if prev < item else item
    priority._min_seen = min_seen

    # Dominant term: strict best fit (smaller residual is better).
    score = -residual.astype(np.float64)

    # Penalize nonzero residuals that are strictly smaller than the smallest item
    # ever seen: such gaps can never be exactly filled and are stranded capacity.
    # A residual of 0 (exact fill) is ideal and must NOT be penalized.
    stranded = (residual > 0) & (residual < min_seen)
    score -= stranded.astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
