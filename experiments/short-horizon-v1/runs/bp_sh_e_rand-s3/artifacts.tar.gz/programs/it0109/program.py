# EVOLVE-BLOCK-START
"""Best fit with a stable secondary tiebreaker toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Rank bins by strict best fit, breaking residual ties toward fuller bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary key: smaller residual is better (best fit).
    # Secondary key: among equal residuals, prefer the bin that is already fuller
    # (smaller remaining capacity), which tends to consolidate free space.
    # Combine so best fit dominates: residual spans 0..99, so weight secondary
    # by a small epsilon that cannot cross an integer residual boundary.
    score = -residual.astype(np.float64) - 1e-3 * bins.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

