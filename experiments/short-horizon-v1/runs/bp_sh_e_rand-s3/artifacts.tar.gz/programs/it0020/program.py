# EVOLVE-BLOCK-START
"""Best fit with a gentle nudge: prefer tightest fit, break near-ties by
choosing the residual that keeps leftover space usable for future items."""
import numpy as np

# A gentle tie window: residuals within this many units of the best residual
# are considered "near ties" and re-ranked.
_WINDOW = 6


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: tightest fit (smallest residual) gets the highest score.
    base = -residual.astype(np.float64)

    # Among bins whose residual is within _WINDOW of the minimum, give a tiny
    # bonus to residuals that are small-but-nonzero (more useful leftover than 0)
    # and penalize leaving an exactly-empty residual (wasting a bin's slot) only
    # very slightly, so plain best-fit stays dominant.
    mn = residual.min()
    near = (residual - mn) <= _WINDOW
    # Prefer residuals in [1, _WINDOW]: small usable gaps.
    useful = (residual >= 1) & (residual <= _WINDOW)
    bonus = np.where(near & useful, 0.5, 0.0)
    # Slight penalty for perfectly completing a bin only when there exist near
    # alternatives, to keep some slack; weight is tiny so best-fit dominates.
    return base + bonus
# EVOLVE-BLOCK-END

