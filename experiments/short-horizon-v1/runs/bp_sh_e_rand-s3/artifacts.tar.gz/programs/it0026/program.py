# EVOLVE-BLOCK-START
"""Best fit with exact-fill reward and distribution-aware residual scoring."""
import numpy as np


def priority(item, bins):
    """Rank bins using best fit plus rewards for residuals fillable by common items.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base: strongly prefer tighter fits (best fit).
    score = -residual.astype(np.float64)

    # Exact fill is ideal: no residual stranded, no future item needed.
    exact = (residual == 0)
    score += exact.astype(np.float64) * 50.0

    # Residuals around common small/medium item sizes are likely fillable later,
    # so they are less "stranded" than arbitrary residuals. Reward them modestly.
    # Weibull-ish mean ~40, but small items are most frequent, so weight low residuals.
    usable = (residual > 0)
    # Smooth triangular bonus peaking near small common sizes (~10-30).
    bonus = np.where(
        usable,
        np.clip(1.0 - np.abs(residual - 20.0) / 25.0, 0.0, 1.0),
        0.0,
    )
    score += bonus.astype(np.float64) * 1.0

    return score
# EVOLVE-BLOCK-END
