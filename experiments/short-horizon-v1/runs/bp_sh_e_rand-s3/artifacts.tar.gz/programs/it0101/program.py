# EVOLVE-BLOCK-START
"""Best fit with an adaptive penalty for residuals below the minimum item seen."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals that can never be exactly filled.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    # Track smallest item size observed so far (state across calls in a stream).
    prev = getattr(priority, "_min_seen", None)
    if prev is None or item < prev:
        priority._min_seen = item
    m = priority._min_seen

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # A nonzero residual smaller than the smallest item ever seen can never be
    # exactly filled; penalize it, scaling the penalty by how stranded it is.
    if m > 1:
        tiny = (residual > 0) & (residual < m)
        # Deeper waste (residual near 0) gets a slightly bigger penalty, but the
        # effect stays small relative to the best-fit ordering.
        frac = (m - residual).astype(np.float64) / float(m)
        score -= tiny.astype(np.float64) * (1.0 + frac)

    return score
# EVOLVE-BLOCK-END

