# EVOLVE-BLOCK-START
"""Best fit with a residual-value penalty scaled by the observed mean item size."""
import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.total = 0.0


_S = _State()


def priority(item, bins):
    """Rank bins by best fit, but penalize residuals too small to be useful.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    _S.count += 1
    _S.total += item
    mean_item = _S.total / _S.count
    # Threshold below which a residual is considered "stranded": it is smaller than
    # what a typical future item would need, so filling it exactly is unlikely.
    threshold = max(2.0, 0.28 * mean_item)

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize nonzero residuals that are too small to be useful, with a smooth
    # ramp so that a larger (more useful) residual is preferred over a tiny one.
    stranded = (residual > 0) & (residual < threshold)
    # Penalty grows as the residual shrinks toward 1.
    ramp = np.where(stranded, (threshold - residual) / threshold, 0.0)
    score -= ramp * 1.5

    return score
# EVOLVE-BLOCK-END
