# EVOLVE-BLOCK-START
"""Best fit with exact-fill dominance and a running-mean "nice residual" bonus."""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    """Rank bins by best fit, strongly preferring exact fills and residuals that
    match the typical (running mean) future item size.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    s = _state
    s["sum"] += item
    s["count"] += 1
    mean = s["sum"] / s["count"]

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Strong preference for exact fills (residual == 0).
    exact = (residual == 0)
    score += exact.astype(np.float64) * 2.0

    # Penalize stranded tiny nonzero residuals.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny.astype(np.float64) * 1.5

    # Bonus for residuals near the running mean (good future-fit leftovers).
    near_mean = np.exp(-((residual - mean) ** 2) / (2.0 * (mean * 0.5 + 1e-9) ** 2))
    score += near_mean * 0.3

    return score
# EVOLVE-BLOCK-END
