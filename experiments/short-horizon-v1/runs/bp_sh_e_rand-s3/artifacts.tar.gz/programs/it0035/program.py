# EVOLVE-BLOCK-START
"""Best fit with a smooth, self-limiting penalty on stranded tiny residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, softly penalizing unusable tiny residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = (bins - item).astype(np.float64)  # >= 0 for all shown bins

    # Primary key: best fit (smaller residual better).
    score = -residual

    # Soft penalty for small positive residuals (likely stranded capacity),
    # scaled so it never overturns a meaningful fit difference. Exact fills
    # (residual == 0) are never penalized.
    # penalty grows as residual shrinks toward 1, but max magnitude < 1.
    small = (residual > 0.0) & (residual < 5.0)
    pen = np.where(small, (5.0 - residual) / 5.0 * 0.9, 0.0)
    score -= pen

    return score
# EVOLVE-BLOCK-END

