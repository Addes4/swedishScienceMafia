# EVOLVE-BLOCK-START
"""Best fit blended with a pull toward keeping medium residual capacity reusable."""
import numpy as np

# Expected item size under the Weibull-shaped distribution (mean about 40).
MEAN_ITEM = 40.0


def priority(item, bins):
    """Rank bins by best fit, softened toward residues near the mean item size.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = (bins - item).astype(np.float64)  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual

    # Among non-exact fits, prefer residuals that a typical future item can still use
    # well, i.e. residuals close to the mean item size. This keeps bins reusable and
    # avoids stranding capacity, while exact fills remain strictly best.
    # Pull is applied only away from 0 and scaled so it never overrides exact fill.
    pull = -0.05 * np.abs(residual - MEAN_ITEM)
    nonzero = residual > 0.0
    score += np.where(nonzero, pull, 0.0)

    return score
# EVOLVE-BLOCK-END
