# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware penalty for unusable tiny residuals."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small to be reusable.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Track the empirical minimum item size seen so far (excluding zero).
    if item < _state["min_item"]:
        _state["min_item"] = item
    min_item = _state["min_item"]

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize tiny nonzero residuals: capacity that is likely stranded because it is
    # smaller than the smallest item we have observed (so it can never fit anything).
    # Exact fills (residual 0) are ideal and stay unpenalized.
    threshold = max(min_item, 5)
    tiny = (residual > 0) & (residual < threshold)
    score -= tiny.astype(np.float64) * 1.5

    return score
# EVOLVE-BLOCK-END
