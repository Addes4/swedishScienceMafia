# EVOLVE-BLOCK-START
"""Best fit with preference for residuals near the typical item size."""
import numpy as np


def priority(item, bins):
    """Rank bins: exact fits first, then residuals closest to a reusable size.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base: prefer exact fits strongly (residual 0).
    score = -residual.astype(np.float64)

    # Among non-exact residuals, prefer residuals near the typical item size so
    # that the leftover space stays reusable by a common future item.
    target = 40.0
    non_exact = residual > 0
    score[non_exact] -= 0.05 * np.abs(residual[non_exact].astype(np.float64) - target)

    return score
# EVOLVE-BLOCK-END
