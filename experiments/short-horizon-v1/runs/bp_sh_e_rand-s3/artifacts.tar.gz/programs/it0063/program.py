# EVOLVE-BLOCK-START
"""Best fit with a stateful bonus for leaving a reusable residual near the mean item size."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, with a bonus for residuals close to the running mean item size.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    # Maintain running mean item size (stateful, per stream).
    s = getattr(priority, "sum", 0.0) + item
    c = getattr(priority, "count", 0) + 1
    priority.sum = s
    priority.count = c
    mean_item = s / c

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Encourage leaving a residual that future average items can reuse:
    # reward residuals near the running mean, but keep exact fills dominant.
    target = mean_item
    diff = np.abs(residual.astype(np.float64) - target)
    bonus = np.maximum(0.0, 1.0 - diff / max(target, 1.0))  # in [0,1]
    nonzero = residual > 0
    score += bonus * 2.0 * nonzero

    return score
# EVOLVE-BLOCK-END
