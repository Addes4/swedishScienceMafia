# EVOLVE-BLOCK-START
"""Best fit with an adaptive penalty for useless tiny residuals.

Idea: classic best fit (smallest residual) is near-optimal for this Weibull-shaped
distribution (mean ~40). The main loss comes from leaving *tiny* nonzero residuals
that can never be filled again. We keep strict best-fit ordering but add an
adaptive penalty for small residuals, calibrated from a running estimate of the
smallest typical item size seen so far. Exact fills (residual 0) are never
penalized.
"""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small to be reused.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins
    score = -residual.astype(np.float64)

    # Tiny nonzero residuals are likely stranded capacity; penalize mildly so
    # that when a slightly looser bin is available we prefer the looser one.
    # Residual 0 (exact fill) is ideal and is never penalized.
    tiny = (residual > 0) & (residual < 6)
    score -= tiny.astype(np.float64) * 2.0

    # Extra preference for the residual matching a small common item size
    # (approx 1..5), which can actually be refilled later.
    refill = (residual >= 1) & (residual <= 5)
    score += refill.astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
