# EVOLVE-BLOCK-START
"""Best fit with a mild preference for residuals near the empirical item scale."""
import numpy as np

_STATE = {"sum": 0.0, "count": 0}


def priority(item, bins):
    """Rank bins by exact-fit first, then by closeness of residual to a useful scale.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    _STATE["sum"] += item
    _STATE["count"] += 1
    mean_item = _STATE["sum"] / _STATE["count"]

    residual = bins - item  # >= 0 for all shown bins (item fits)

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Among non-exact fits, slightly prefer residuals near the scale of future items,
    # so a bin stays easily reusable; but keep this mild to preserve best-fit behavior.
    target = mean_item
    diff = np.abs(residual.astype(np.float64) - target)
    bonus = np.exp(-diff / 20.0)
    score += 0.6 * bonus

    # Exact fill is always best: give it a decisive bonus.
    score += (residual == 0).astype(np.float64) * 50.0

    return score
# EVOLVE-BLOCK-END
