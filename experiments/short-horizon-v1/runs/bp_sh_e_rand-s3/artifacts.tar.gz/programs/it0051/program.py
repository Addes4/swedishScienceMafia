# EVOLVE-BLOCK-START
"""Best fit, but avoid leaving residuals that no future item can ever fill."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, avoiding unusably small residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

