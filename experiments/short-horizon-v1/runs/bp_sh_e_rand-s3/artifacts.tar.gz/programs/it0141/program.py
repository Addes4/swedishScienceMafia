# EVOLVE-BLOCK-START
"""Best fit with a stateful, minimum-item-aware stranded-residual penalty."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Rank bins by best fit, penalizing only genuinely stranded residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item
    min_item = _state["min_item"]

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize nonzero residuals strictly smaller than the smallest item seen so far:
    # these slots can never be filled by a future item and are truly stranded waste.
    tiny = (residual > 0) & (residual < min_item)
    score -= tiny.astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END

