# EVOLVE-BLOCK-START
"""Strict best fit: choose the bin with the smallest residual capacity."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit (smallest post-placement residual).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    # Best fit: smaller residual is better. Exact fill (residual 0) is best.
    residual = bins - item
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
