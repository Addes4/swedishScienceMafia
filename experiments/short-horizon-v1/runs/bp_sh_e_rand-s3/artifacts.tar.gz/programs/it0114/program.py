# EVOLVE-BLOCK-START
"""Best fit with a dynamic avoidance of unusably small residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, but treat residuals smaller than the smallest item
    seen so far as effectively wasted, and prefer residuals that can still hold
    a future item.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    min_item = getattr(priority, "_min_item", 100)
    if item < min_item:
        min_item = item
        priority._min_item = min_item
    if not hasattr(priority, "_min_item"):
        priority._min_item = min_item

    r = residual.astype(np.float64)

    # Base: strict best fit.
    score = -r

    # Residuals too small to ever hold an item again are bad; exact fill is fine.
    too_small = (r > 0) & (r < min_item)
    score -= too_small.astype(np.float64) * (r + 1.0)

    return score
# EVOLVE-BLOCK-END

