# EVOLVE-BLOCK-START
"""Best fit with a size-aware tiebreak for large items."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, with a consolidation tiebreak for large items.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # For large items, nudge toward the bin that had the most room (least full),
    # so big items consolidate instead of fragmenting partially filled bins.
    if item > 50:
        score += bins.astype(np.float64) * 0.25

    return score
# EVOLVE-BLOCK-END

