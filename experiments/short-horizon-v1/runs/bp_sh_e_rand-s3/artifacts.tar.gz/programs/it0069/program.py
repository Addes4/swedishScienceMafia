# EVOLVE-BLOCK-START
"""Best fit with a smooth bonus rewarding residuals that can absorb mean-sized items."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, plus a smooth bonus for reusable residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins
    r = residual.astype(np.float64)

    # Base best-fit preference: smaller residual is better.
    score = -r

    # Smooth bonus encouraging residuals large enough to hold at least one
    # typical (mean-sized) future item, since such gaps are reusable; tiny
    # stranded gaps get no bonus. This is a mild secondary term so best-fit
    # remains the primary rule and exact fills (r == 0) stay ideal.
    m = _mean_item
    if m > 1.0:
        # Number of mean-sized items the residual could still absorb.
        k = r / m
        # Concave: diminishing returns after the first reusable slot.
        score += 2.0 * (1.0 - 1.0 / (1.0 + k))

    return score


# Stateful running estimate of the mean item size within a stream.
_mean_item = 40.0
_count = 0


def _update(item):
    global _mean_item, _count
    _count += 1
    _mean_item += (item - _mean_item) / _count
# EVOLVE-BLOCK-END
