# EVOLVE-BLOCK-START
"""Best fit with a learned penalty for residuals that match frequent item sizes."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Rank bins by best fit, preferring residuals that match frequent item sizes.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _HIST, _COUNT

    # Update running histogram of item sizes (state persists within a stream).
    _HIST[item] += 1.0
    _COUNT += 1.0

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Learn which residual sizes are "useful": residuals that equal a frequently
    # seen item size are more likely to be exactly filled later.  Give a small
    # bonus proportional to that frequency, but keep best-fit dominant.
    if _COUNT > 1.0:
        freq = _HIST / _COUNT
        # bonus in [0, ~1.0): weight by normalized frequency of the residual value
        r = residual.astype(np.int64)
        r = np.clip(r, 0, 100)
        bonus = freq[r] * 2.0
        # exact fill (residual 0) is ideal; never penalize it, always best
        score += bonus

    return score
# EVOLVE-BLOCK-END
