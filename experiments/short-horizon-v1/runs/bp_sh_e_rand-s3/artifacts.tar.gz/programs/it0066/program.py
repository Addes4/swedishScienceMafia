# EVOLVE-BLOCK-START
"""Best fit with a tiny-residual penalty plus a bonus for reusable leftovers."""
import numpy as np


class _State:
    def __init__(self):
        # Counts of item sizes seen so far (1..100).
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0


_state = _State()


def priority(item, bins):
    """Rank bins by best fit, penalizing stranded tiny residuals and rewarding
    residuals that match common past item sizes (so leftovers stay reusable).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins
    residual = residual.astype(np.float64)

    # Base best-fit preference: smaller residual is better.
    score = -residual

    # Tiny nonzero residuals are likely stranded capacity; add a mild penalty so
    # that when a slightly looser bin is available, we prefer it. A residual of 0
    # (exact fill) is ideal and must NOT be penalized.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny.astype(np.float64) * 1.5

    # Bonus for residuals that match a frequently seen item size: such a leftover
    # can absorb a future item exactly, so it is valuable capacity.
    if _state.total > 0:
        freq = _state.counts / _state.total
        # Map each residual to a reusable-value term (only integer residuals matter).
        idx = np.clip(residual.astype(np.int64), 0, 100)
        # Weight by how common that size is, scaled modestly so best-fit dominates.
        score += freq[idx] * 4.0

    # Update state with the current item.
    _state.counts[item] += 1.0
    _state.total += 1.0

    return score
# EVOLVE-BLOCK-END

