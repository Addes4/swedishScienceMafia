# EVOLVE-BLOCK-START
"""Best fit with a small penalty for tiny residuals and a large-item reuse bonus."""
import numpy as np

_max_item = 0


def priority(item, bins):
    """Rank bins by best fit, penalizing tiny residuals and rewarding reusable gaps.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _max_item
    if item > _max_item:
        _max_item = item

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Tiny nonzero residuals are likely stranded capacity; add a mild penalty so that
    # when a slightly looser bin is available, we prefer it (reduces fragmentation).
    # A residual of 0 (exact fill) is ideal and must NOT be penalized.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny.astype(np.float64) * 1.5

    # Small tie-break: slightly prefer leaving a residual near the largest item
    # seen so far, so the leftover capacity stays reusable for future large items.
    if _max_item > 0:
        reuse = -0.05 * np.abs(residual.astype(np.float64) - _max_item)
        score += reuse

    return score
# EVOLVE-BLOCK-END
