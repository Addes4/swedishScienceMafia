# EVOLVE-BLOCK-START
"""Best fit with an adaptive residual-usability bonus."""
import numpy as np

# Running statistics of observed item sizes (per stream state).
_mean = 40.0
_n = 0.0


def priority(item, bins):
    """Rank bins by best fit, gently preferring residuals that stay usable.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _mean, _n

    # Update running mean of item sizes.
    _n += 1.0
    _mean += (item - _mean) / _n

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better. Scale by 1.0 so this
    # dominates.
    score = -residual.astype(np.float64)

    # Residual-usability bonus: a residual that can still hold a typical future
    # item is more valuable than a stranded tiny gap. Exact fill (residual 0) is
    # ideal and gets no penalty. Bonus is small (< 1) so best-fit stays primary.
    target = _mean
    usable = np.minimum(residual.astype(np.float64) / max(target, 1.0), 1.0)
    bonus = usable * 0.4
    bonus = np.where(residual == 0, 0.0, bonus)

    score += bonus

    return score
# EVOLVE-BLOCK-END
