# EVOLVE-BLOCK-START
"""Best fit with a mild penalty for stranding tiny residual capacities."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since bins only contains bins the item fits in

    # Best fit: prefer the smallest residual. Add a tiny bonus that mildly
    # discourages leaving a residual of 1..small (hard to reuse), without
    # disturbing the dominant best-fit ordering for larger differences.
    # The bonus is zero for residual==0 (exact fit stays best) and for
    # residuals that are comfortably usable.
    pen = np.where((residual > 0) & (residual < 8),
                   (8 - residual) * 0.02,
                   0.0)

    score = -residual.astype(np.float64) - pen
    return score
# EVOLVE-BLOCK-END

