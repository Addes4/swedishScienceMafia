# EVOLVE-BLOCK-START
"""Best fit with exact-fill dominance and a usefulness band for residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, prioritizing exact fills and useful residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary: strict best fit (smaller residual better).
    score = -residual.astype(np.float64)

    # Strong bonus for exact fill: clearly dominate any nonzero residual.
    score += (residual == 0).astype(np.float64) * 5.0

    # Small penalty for residuals that are nonzero but too small to be very useful
    # (likely stranding capacity), so a slightly looser bin is preferred on near-ties.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny.astype(np.float64) * 0.25

    return score
# EVOLVE-BLOCK-END
