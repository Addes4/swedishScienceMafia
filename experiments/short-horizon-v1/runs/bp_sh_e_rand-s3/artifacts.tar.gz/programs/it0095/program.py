# EVOLVE-BLOCK-START
"""Best fit with an adaptive preference for residuals likely to be refilled exactly."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, breaking near-ties toward useful residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = (bins - item).astype(np.float64)  # >= 0 for all shown bins

    # Primary criterion: strict best fit (smaller residual is better).
    score = -residual

    # Break near-ties: among residuals within 1 of each other, prefer residuals
    # equal to a common small item size (likely to be filled exactly later),
    # which reduces stranded capacity. Exact fill (residual 0) is always best.
    # Use a bounded, tiny bonus so it only matters when best-fit residuals tie.
    common = (residual == 1) | (residual == 2) | (residual == 3) | (residual == 4)
    score[common] += 0.01

    return score
# EVOLVE-BLOCK-END
