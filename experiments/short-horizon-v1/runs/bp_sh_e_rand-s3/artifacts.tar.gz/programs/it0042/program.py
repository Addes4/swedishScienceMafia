# EVOLVE-BLOCK-START
"""Best fit with an online-learned exact-fit bonus."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, boosting residuals that have historically been filled exactly.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Track a running histogram of item sizes seen so far (module-level state).
    hist = priority.hist
    hist[item] += 1
    total = priority.total
    priority.total = total + 1

    # Boost bins whose residual equals a likely future item size: those residuals
    # can be filled exactly, saving a bin. Scale bonus small enough to only break ties.
    freq = hist.astype(np.float64) / max(priority.total, 1)
    bonus = freq[residual]  # residual is 0..100, freq indexed same
    score += bonus * 0.5

    # Exact fill is still strictly best.
    score += (residual == 0).astype(np.float64) * 100.0

    return score


priority.hist = np.zeros(101, dtype=np.int64)
priority.total = 0
# EVOLVE-BLOCK-END
