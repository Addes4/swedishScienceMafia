# EVOLVE-BLOCK-START
"""Best fit with an item-size-scaled penalty for stranding medium residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small for a future item.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Small items can still fill small gaps later, so they tolerate tight residuals.
    # Large items tend to strand medium gaps, so penalize risky residuals more.
    # Threshold scales up with item size; exact fills (residual 0) never penalized.
    threshold = 3.0 + 0.06 * item
    risky = (residual > 0) & (residual < threshold)
    score -= risky.astype(np.float64) * 1.5

    return score
# EVOLVE-BLOCK-END

