# EVOLVE-BLOCK-START
"""Best fit with a mild preference for residuals near the typical item size."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit; nudge near-ties toward refillable residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary: strict best fit (smaller residual better).
    score = -residual.astype(np.float64)

    # Exact fills are ideal and must always win.
    exact = residual == 0

    # For near-ties (residuals within a small window), prefer residuals close to a
    # typical item size, since those gaps are most likely to be filled exactly later.
    # Use a fixed-ish target: ~40 (mean of the Weibull-shaped distribution).  We only
    # perturb within a tiny window so strict best fit dominates.
    target = 40.0
    closeness = -np.abs(residual - target)
    # Scale down so it never overtakes the best-fit ordering across distinct residuals
    # by more than a fraction; combine only as a sub-integer tiebreak.
    tie = (residual > 0) & (residual <= 6)
    score += tie.astype(np.float64) * 0.25 * np.tanh(closeness / 10.0)

    # Exact fills dominate.
    score += exact.astype(np.float64) * 1e6

    return score
# EVOLVE-BLOCK-END
