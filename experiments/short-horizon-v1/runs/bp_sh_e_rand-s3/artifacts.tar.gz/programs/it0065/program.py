# EVOLVE-BLOCK-START
"""Best fit with a stateful penalty for residuals that cannot hold future items."""
import numpy as np


class _State:
    def __init__(self):
        self.min_size = 100
        self.small_sizes = []


_state = _State()


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small for likely future items.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    # Update state with the observed item size.
    if item < _state.min_size:
        _state.min_size = item
    # Keep a rough estimate of a "small but plausible" future item size via a
    # decaying approximation of the low quantile of the item distribution.
    _state.small_sizes.append(item)
    if len(_state.small_sizes) > 200:
        _state.small_sizes.pop(0)

    # Estimate the threshold below which a residual is unlikely to be usable.
    # Use a blend of the observed minimum and a low quantile of recent items.
    recent = np.asarray(_state.small_sizes)
    q10 = float(np.percentile(recent, 10))
    threshold = max(_state.min_size, q10 * 0.75)
    if threshold < 1.0:
        threshold = 1.0

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize residuals that are nonzero but below the usability threshold:
    # such gaps are likely to be stranded. Exact fills (residual 0) are free.
    stranded = (residual > 0) & (residual < threshold)
    score -= stranded.astype(np.float64) * (threshold + 1.0)

    return score
# EVOLVE-BLOCK-END
