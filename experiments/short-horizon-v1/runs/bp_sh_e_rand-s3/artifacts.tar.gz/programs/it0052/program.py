# EVOLVE-BLOCK-START
"""Best fit that gently steers residuals toward recently seen item sizes."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit; mildly prefer residuals matching recent item sizes.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary key: best fit (smaller residual is better).
    score = -residual.astype(np.float64)

    # Secondary, stateful nudge: a residual is more useful if some item size that may
    # still arrive fits it exactly-ish. We keep a small rolling record of recent item
    # sizes via a module-level list guarded by its length.
    hist = priority._hist
    hist.append(item)
    if len(hist) > 64:
        del hist[:len(hist) - 64]

    # Bonus for residuals that are close to a size seen recently (reusable pocket).
    # 0 residual is already optimal via the primary key; only nudge positive residuals.
    bonus = np.zeros(residual.shape, dtype=np.float64)
    for s in hist:
        bonus += np.exp(-0.25 * np.abs(residual - s))
    # Scale small so it never overrides a difference of 1 in the primary key.
    score += 0.35 * bonus

    return score


priority._hist = []
# EVOLVE-BLOCK-END
