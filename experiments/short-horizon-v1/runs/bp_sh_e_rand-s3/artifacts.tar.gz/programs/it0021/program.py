# EVOLVE-BLOCK-START
"""Best fit with a tiny guard against stranding very small residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit (most negative residual = smallest leftover).
    score = -residual.astype(np.float64)
    # Penalize residuals that are small but nonzero (likely wasted space),
    # nudging toward the next-tightest bin which keeps leftover usable.
    waste = (residual > 0) & (residual < 8)
    score -= waste * (8 - residual) * 0.25
    return score
# EVOLVE-BLOCK-END
