# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware penalty on unusable residuals."""
import numpy as np


class _State:
    min_item = 100
    max_item = 1
    count = 0


_state = _State()


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals below the smallest item seen.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _state

    # Update observed item-size statistics (uses only past items).
    if item < _state.min_item:
        _state.min_item = item
    if item > _state.max_item:
        _state.max_item = item
    _state.count += 1

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Estimate a threshold below which future items are unlikely to fit: use the
    # smallest item seen so far, but guard against early-stream noise by requiring
    # a few observations before trusting it.
    if _state.count >= 20:
        thr = _state.min_item
    else:
        thr = 1

    # Penalize nonzero residuals strictly below the threshold: no observed item
    # could reuse that leftover space, so it is effectively wasted.
    stranded = (residual > 0) & (residual < thr)
    score -= stranded.astype(np.float64) * 1.5

    return score
# EVOLVE-BLOCK-END
