# EVOLVE-BLOCK-START
"""Best fit with a steeper penalty on residual: prefer near-exact fits strongly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest score.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    residual = bins - item  # >= 0 because only fitting bins are shown
    # Linear best fit plus a strong bonus for (near-)exact fits.
    return -residual + 100.0 * (residual == 0)
# EVOLVE-BLOCK-END
