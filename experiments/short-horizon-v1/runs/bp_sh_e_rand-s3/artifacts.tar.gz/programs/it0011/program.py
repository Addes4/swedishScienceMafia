# EVOLVE-BLOCK-START
"""Best fit with a small-item fit bonus: prefer tightest fit, reward near-exact fills."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit (smallest post-item residual is best).
    score = -residual.astype(np.float64)
    # Reward near-exact fits: residuals in [0, 3] get a small bonus so that
    # near-perfect packing is preferred even among close candidates.
    score += 2.0 * (residual <= 3)
    return score
# EVOLVE-BLOCK-END
