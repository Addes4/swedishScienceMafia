# EVOLVE-BLOCK-START
"""Best fit with a lookahead penalty for residuals that are unlikely to be reused well."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals that look costly to reuse.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = (bins - item).astype(np.float64)  # >= 0

    # Strong base preference: best fit (smallest residual).
    score = -residual

    # Lookahead penalty: a residual is easy to reuse if it can be exactly filled by
    # a common single item (roughly near the distribution mean ~40) or if it is large
    # enough to accept most items. Penalize residual values that are neither small
    # exact fits nor comfortably large.
    # Heuristic "usefulness": worth keeping if large, or if close to a typical item.
    r = residual
    exact = (r == 0)
    large = r >= 40.0
    near_typical = (np.abs(r - 40.0) < 12.0)
    useless = (r > 0) & (r < 20.0)  # too small to help much, not a fill

    score = score - 0.9 * useless.astype(np.float64)
    score = score + 0.15 * (large | near_typical | exact).astype(np.float64)

    return score
# EVOLVE-BLOCK-END
