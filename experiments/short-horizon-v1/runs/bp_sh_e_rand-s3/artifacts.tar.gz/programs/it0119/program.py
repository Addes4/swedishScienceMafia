# EVOLVE-BLOCK-START
"""Best fit with a bonus for residues matching common item sizes."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    global _total
    residual = bins - item

    # Update running estimate of item-size distribution.
    _counts[item] += 1.0
    _total += 1.0

    score = -residual.astype(np.float64)

    # Bonus: prefer residuals that are close to a frequently seen item size (the
    # residual will be easy to exactly fill later).  Use a soft likelihood that
    # peaks near the empirical mode of the item distribution.
    if _total >= 30.0:
        freq = _counts / _total
        # For each residual value r, value = max frequency over sizes near r.
        best_freq = np.zeros(residual.shape[0], dtype=np.float64)
        for r_size in range(1, 101):
            f = freq[r_size]
            if f <= 0.0:
                continue
            best_freq = np.maximum(best_freq, np.where(np.abs(residual - r_size) <= 1, f, 0.0))
        # Scale bonus modestly so it only breaks near-ties in base best-fit.
        score += best_freq * 6.0

    return score
# EVOLVE-BLOCK-END
