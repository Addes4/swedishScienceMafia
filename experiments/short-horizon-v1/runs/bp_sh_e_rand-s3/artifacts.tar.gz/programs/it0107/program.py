# EVOLVE-BLOCK-START
"""Best fit, softened only when the residual would be too small to reuse."""
import numpy as np


def priority(item, bins):
    """Rank bins preferring best fit, but avoid leaving stranded tiny residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = (bins - item).astype(np.float64)  # >= 0

    min_size = state.get('min_size', item)
    if item < min_size:
        state['min_size'] = item
        min_size = item
    # Track a rough typical item size for gauging useful residuals.
    count = state.get('count', 0)
    mean = state.get('mean', float(item))
    mean = (mean * count + item) / (count + 1)
    state['mean'] = mean
    state['count'] = count + 1

    # Dominant best-fit ordering (smaller residual better).
    score = -residual

    # Penalize only residuals that are non-zero and below the smallest item
    # seen so far, since such space can never be exactly filled.
    stranded = (residual > 0) & (residual < min_size)
    score -= stranded.astype(np.float64) * 1.5

    return score


state = {}
# EVOLVE-BLOCK-END
