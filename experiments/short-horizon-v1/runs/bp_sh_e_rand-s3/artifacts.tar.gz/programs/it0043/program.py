# EVOLVE-BLOCK-START
"""Best fit, but avoid creating residuals that can never hold a future item."""
import numpy as np

_state = {"min_item": 101}


def priority(item, bins):
    """Rank bins by best fit, discouraging residuals below the smallest item seen.

    We set a per-call cutoff s = smallest item size observed so far (including this
    item). A residual below s (and > 0) is likely stranded capacity, so it gets a
    modest penalty. Exact fills (residual 0) stay optimal. When no useful cutoff is
    known yet (s == 101), this reduces to plain best fit.
    """
    if item < _state["min_item"]:
        _state["min_item"] = item
    s = _state["min_item"]

    residual = bins - item  # >= 0

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize stranded capacity: nonzero residual smaller than the smallest item.
    stranded = (residual > 0) & (residual < s)
    score -= stranded.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
