# EVOLVE-BLOCK-START
"""Best fit with a smooth penalty for stranding a narrow band of small residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, softly penalizing residues too small to be reused.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Discourage leaving a small nonzero residual that is likely to be stranded
    # forever (never reused by any future item).  Exact fill (0) is ideal, so the
    # penalty is a smooth bump that is zero at 0 and fades out for larger gaps.
    r = residual.astype(np.float64)
    bump = np.exp(-0.5 * ((r - 3.0) / 3.0) ** 2)
    score -= bump

    return score
# EVOLVE-BLOCK-END
