# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware residual preference."""
import numpy as np

# Persistent state: histogram of past post-placement residuals (bin gaps).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0
_DECAY = 0.995


def priority(item, bins):
    """Rank bins: strict best-fit, tie-broken by empirical usefulness of residual.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _HIST, _COUNT

    residual = bins - item  # >= 0 for all shown bins
    r_int = residual.astype(np.int64)

    # Primary: best-fit -> smaller residual preferred.
    score = -residual.astype(np.float64)

    # Secondary bonus: residuals that historically appeared often as resulting gaps
    # are more likely to be refillable later. Rescale to a small magnitude so it
    # only acts as a tie-breaker, not overriding best-fit ordering.
    if _COUNT > 1.0:
        freq = _HIST[np.clip(r_int, 0, 100)] / _COUNT
        score += 0.05 * freq

    # Update histogram with the residual we are about to create.
    # We do it after scoring so the choice uses only past information.
    chosen = int(np.argmax(score))
    r_chosen = int(r_int[chosen])

    _HIST *= _DECAY
    _COUNT = _COUNT * _DECAY + 1.0
    _HIST[r_chosen] += 1.0

    return score
# EVOLVE-BLOCK-END
