# EVOLVE-BLOCK-START
"""Best fit with a stateful penalty for residuals that no future item could use."""
import numpy as np


class _State:
    def __init__(self):
        # Smallest item size observed so far. Gaps smaller than this are
        # effectively unusable by any later item from the same stream.
        self.min_item = 1


_state = _State()


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small to be reusable.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _state

    # Update the running minimum item size (kept conservative: never above item).
    if item < _state.min_item or _state.min_item <= 0:
        _state.min_item = item
    min_item = _state.min_item

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize positive residuals that are smaller than the smallest item seen;
    # such gaps can never be filled again. A residual of 0 (exact fill) is ideal
    # and must NOT be penalized.
    if min_item > 1:
        unusable = (residual > 0) & (residual < min_item)
        score -= unusable.astype(np.float64) * 3.0

    return score
# EVOLVE-BLOCK-END
