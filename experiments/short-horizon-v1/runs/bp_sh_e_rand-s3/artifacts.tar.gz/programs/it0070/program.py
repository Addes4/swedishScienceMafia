# EVOLVE-BLOCK-START
"""Best fit augmented by rewarding residuals that past items have exactly filled."""
import numpy as np

_state = {"seen": None}


def priority(item, bins):
    """Rank bins by best fit, with a mild bonus for leaving a reusable residual.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary term: best fit (smaller residual better). Scale large enough that
    # the secondary bonuses only ever break near-ties.
    score = -residual.astype(np.float64) * 10.0

    # Reward a residual that has previously been exactly filled by some item,
    # since such leftovers are demonstrably reusable. Keep a histogram of item
    # sizes observed so far to estimate this cheaply.
    seen = _state["seen"]
    if seen is None:
        seen = np.zeros(101, dtype=np.float64)
        _state["seen"] = seen

    # Refillable residuals: item sizes that have appeared at least once.
    res_clip = residual.astype(np.int64)
    usable = np.zeros(residual.shape, dtype=np.float64)
    mask = (res_clip > 0) & (res_clip <= 100)
    usable[mask] = seen[res_clip[mask]]

    # Small bonus for reusable residuals, and a bigger one for exact fills.
    score += usable
    score += (residual == 0).astype(np.float64) * 5.0

    # Record this item for future calls.
    seen[item] += 1.0

    return score
# EVOLVE-BLOCK-END

