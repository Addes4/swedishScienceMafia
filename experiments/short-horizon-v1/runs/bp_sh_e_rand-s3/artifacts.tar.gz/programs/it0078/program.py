# EVOLVE-BLOCK-START
"""Best fit with a residual-value bonus from the observed item-size histogram."""
import numpy as np


class _State:
    def __init__(self):
        # rolling histogram of observed item sizes (1..100)
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0


_state = _State()


def priority(item, bins):
    """Rank bins by best fit, favoring residuals that common future items can refill.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # all >= 0 for the bins shown

    # Update rolling histogram with the arriving item (state persists across the stream).
    st = _state
    st.counts[item] += 1.0
    st.total += 1.0

    # Probability that a residual r can be exactly filled by a future item,
    # estimated from the empirical item-size distribution so far.
    freq = st.counts / st.total if st.total > 0 else st.counts

    # Base best-fit preference: exact fills dominate, then smaller residuals.
    score = -residual.astype(np.float64) * 1000.0

    # Residual-value bonus: favor residuals that match frequent item sizes.
    # For residual 0 (perfect fill) treat as maximally good.
    r = residual.astype(np.int64)
    valid = r >= 0
    bonus = np.zeros_like(residual, dtype=np.float64)
    safe = np.clip(r, 0, 100)
    bonus[valid] = freq[safe[valid]]
    # exact fill (residual 0) gets a strong extra bonus
    bonus[r == 0] += 1.0

    score += bonus

    return score
# EVOLVE-BLOCK-END
