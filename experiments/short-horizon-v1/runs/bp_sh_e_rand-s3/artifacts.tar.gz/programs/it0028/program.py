# EVOLVE-BLOCK-START
"""Best fit with an adaptive median-based penalty for unusable residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small to be useful.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Adaptive usability threshold: estimate a typical item size from past items
    # using the running maximum seen so far as a proxy for the smallest useful
    # residual.  This adapts to the distribution instead of a fixed constant.
    state = getattr(priority, "_state", None)
    if state is None:
        state = {"max_size": 1}
        priority._state = state
    if item > state["max_size"]:
        state["max_size"] = item

    # A residual that is nonzero but below the smallest item seen so far is
    # likely stranded capacity; mildly penalize it (exact fills stay ideal).
    thr = state["max_size"]
    tiny = (residual > 0) & (residual < thr)
    score -= tiny.astype(np.float64) * 1.5

    return score
# EVOLVE-BLOCK-END
