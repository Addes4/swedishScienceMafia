# EVOLVE-BLOCK-START
"""Best fit with a stateful bonus for residuals that match a typical next item."""
import numpy as np

_alpha = 0.01
_mean = 40.0
_count = 0


def priority(item, bins):
    global _mean, _count
    _count += 1
    if _count > 1:
        _mean += _alpha * (item - _mean)

    residual = bins - item  # >= 0

    # Primary: best fit (smaller residual better).
    score = -residual.astype(np.float64)

    # Secondary: prefer residuals that could cleanly absorb a typical next item.
    # Bonus scaled small so it only breaks ties among similar residuals.
    target = _mean
    score += 0.05 * np.exp(-((residual - target) ** 2) / (2.0 * 15.0 ** 2))

    # Penalize stranded tiny residuals (but not exact fills).
    tiny = (residual > 0) & (residual < 5)
    score -= tiny.astype(np.float64) * 1.5

    return score
# EVOLVE-BLOCK-END
