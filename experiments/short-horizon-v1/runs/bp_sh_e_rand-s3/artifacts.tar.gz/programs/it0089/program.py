# EVOLVE-BLOCK-START
"""Best fit, tie-broken by matching the residual to a common item size."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit; break near-ties toward refillable residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins (item fits)

    # Strict best-fit backbone: smaller residual is always better.
    score = -residual.astype(np.float64)

    # Running tally of item sizes seen so far (module-level state).
    hist = priority.hist
    if item < 100:
        hist[item] += 1

    # Most common item size seen so far (excluding tiny ones) is the value most
    # likely to refill a gap exactly; small bonus for residuals matching it.
    if priority.count > 20:
        mode = int(np.argmax(hist[1:100]) + 1)
        if residual.min() > 0:
            match = residual == mode
            score += match.astype(np.float64) * 0.25

    priority.count += 1
    return score


priority.hist = np.zeros(101, dtype=np.int64)
priority.count = 0
# EVOLVE-BLOCK-END

