# EVOLVE-BLOCK-START
"""Best fit with tie-break toward fuller bins and exact-fill bonus."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit; exact fills are best.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = (bins - item).astype(np.float64)  # >= 0 for all shown bins

    # Primary: smaller residual is better (best fit). Ties (equal integer residual)
    # are broken by preferring the bin with the smallest remaining capacity before
    # placement, i.e. the fuller bin, which tends to reduce fragmentation.
    # Use a tiny scaled tie-break that cannot overcome a 1-unit residual difference.
    score = -residual - 1e-4 * bins.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
