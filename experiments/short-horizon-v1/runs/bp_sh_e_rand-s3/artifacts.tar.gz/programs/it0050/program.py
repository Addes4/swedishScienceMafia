# EVOLVE-BLOCK-START
"""Best fit, with exact-fit priority and worst-fit spreading otherwise.

The classic best-fit rule leaves many small unusable residuals. Taking an
exact fill whenever one exists is always good; when no exact fill is
available, spreading the item into the emptiest fitting bin (worst-fit)
keeps residuals large and more likely to be usable by future items,
reducing fragmentation compared with always minimizing the residual.
"""
import numpy as np


def priority(item, bins):
    """Rank bins: exact fills first, then prefer the largest residual."""
    residual = bins - item  # >= 0 for all shown bins

    score = residual.astype(np.float64)

    # Exact fill is ideal: give it a strong bonus so it always wins.
    exact = (residual == 0)
    score += exact.astype(np.float64) * 1000.0

    return score
# EVOLVE-BLOCK-END

