# EVOLVE-BLOCK-START
"""Best fit with adaptive residual-utility thresholds learned online."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, with adaptive preference for usable residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Running mean of past items (state kept as attribute on the function object).
    state = priority.__dict__
    n = state.get("n", 0)
    total = state.get("total", 0)
    mean_item = (total / n) if n > 0 else 40.0
    state["n"] = n + 1
    state["total"] = total + item

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Prefer residuals that are still large enough to matter for future items.
    # A residual near/above the mean item size keeps the bin useful; tiny positive
    # residuals are stranded capacity and get a mild penalty.
    usable = mean_item  # adaptive threshold from observed sizes
    tiny = (residual > 0) & (residual < usable * 0.5)
    score -= tiny.astype(np.float64) * 1.5

    return score
# EVOLVE-BLOCK-END

