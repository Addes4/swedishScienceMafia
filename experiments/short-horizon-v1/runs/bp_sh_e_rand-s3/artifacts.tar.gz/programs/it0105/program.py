# EVOLVE-BLOCK-START
"""Best fit with a relative penalty for stranding capacity relative to item size."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals that strand capacity.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better. Scale by 100 so the
    # fill preference dominates any tie-breaking penalty below.
    score = -residual.astype(np.float64) * 100.0

    # A post-placement residual r is "stranded" if it is smaller than the gap we
    # would likely want to leave usable: relate it to the item size itself.
    # Penalize small nonzero residuals proportionally to how small they are
    # relative to the item, without ever penalizing an exact fill (residual 0).
    threshold = max(0.5 * item, 1.0)
    small = (residual > 0) & (residual < threshold)
    penalty = np.where(small, threshold - residual, 0.0)
    score -= penalty

    return score
# EVOLVE-BLOCK-END

