# EVOLVE-BLOCK-START
"""Hybrid: best fit, but avoid consuming nearly-empty bins unless the item benefits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item  # post-placement residual (>= 0 since item fits)
    # Base: tightest fit (best fit)
    score = -resid.astype(np.float64)
    # Penalize filling a large-residual (near-empty) bin when the item is small:
    # we want to keep large bins available for future large items.
    large = resid >= 40.0
    if item < 40:
        score[large] -= 30.0
    return score
# EVOLVE-BLOCK-END
