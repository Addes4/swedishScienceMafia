# EVOLVE-BLOCK-START
"""Best fit, but never knowingly strand a residual too small to reuse."""
import numpy as np


def priority(item, bins):
    """Rank bins so exact fills win, then usable residuals, then best fit.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # A residual of 0 is a perfect fill: leave it unpenalized and best.
    # A nonzero residual too small to hold a typical future item is largely
    # stranded capacity, so add a mild penalty there. The threshold scales
    # with the item size so small items aren't over-penalized.
    tiny_limit = max(2, item // 4)
    tiny = (residual > 0) & (residual < tiny_limit)
    score -= tiny.astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END

