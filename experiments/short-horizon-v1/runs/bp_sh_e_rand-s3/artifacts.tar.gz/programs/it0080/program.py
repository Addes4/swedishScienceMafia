# EVOLVE-BLOCK-START
"""Best fit with an adaptive penalty for residuals too small to be refilled."""
import numpy as np

# Rolling statistics of observed item sizes (per-stream reset is handled by the harness
# starting a fresh module? It is not; state persists across an instance's streams, but the
# distribution is identical across streams, so accumulating across streams is fine.)
_seen = np.zeros(101, dtype=np.float64)  # counts of item sizes 1..100
_total = 0.0


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals unlikely to be refilled.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _total
    # Update empirical item-size histogram.
    if 1 <= item <= 100:
        _seen[item] += 1.0
        _total += 1.0

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Probability that a random future item does NOT fit in a residual r is
    # P(next item > r). Estimate from the empirical histogram of past sizes.
    if _total > 0:
        cum = np.cumsum(_seen)  # cum[r] = #items with size <= r
        # fraction of items with size <= r
        frac_le = cum / _total
        # index safely for residual values up to 100
        r_clip = np.clip(residual, 0, 100).astype(np.int64)
        p_no_fit = 1.0 - frac_le[r_clip]  # prob next item won't fit in residual
    else:
        p_no_fit = (residual > 0).astype(np.float64) * 0.5

    # Penalize residuals that are (a) nonzero and (b) likely to be stranded.
    # residual 0 (exact fill) is always best and gets no penalty.
    stranded = (residual > 0).astype(np.float64)
    score -= stranded * p_no_fit * 3.0

    return score
# EVOLVE-BLOCK-END

