# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus and mild stranding penalty."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, boosting exact fills and penalizing stranded residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    score = -residual.astype(np.float64)

    # Exact fill is ideal: give it a strong bonus so it's always preferred.
    score += (residual == 0).astype(np.float64) * 2.0

    # Tiny nonzero residuals are likely stranded capacity; mild penalty.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny.astype(np.float64) * 1.5

    return score
# EVOLVE-BLOCK-END

