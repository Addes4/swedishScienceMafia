# EVOLVE-BLOCK-START
"""Best fit with an adaptive penalty for stranded residuals."""
import numpy as np

_MIN_SIZE = 8  # fallback minimum item size before we've seen enough items


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small to be reusable.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize small nonzero residuals: those below a typical minimum item size
    # are likely to be stranded forever. Exact fill (residual == 0) is ideal.
    # Use a smooth ramp so that the closer a residual is to zero (but nonzero),
    # the stronger the penalty, scaled by how unusable it likely is.
    thr = float(_MIN_SIZE)
    bad = (residual > 0) & (residual < thr)
    # Penalty grows as residual approaches 1..thr-1
    penalty = np.where(bad, (thr - residual).astype(np.float64), 0.0)
    score -= penalty

    return score
# EVOLVE-BLOCK-END
