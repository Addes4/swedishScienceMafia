# EVOLVE-BLOCK-START
"""Best fit with a mild, online-adaptive reward for residuals that later items can fill."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, with a small bonus for residuals that are likely usable.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary key: best fit (smallest residual). Weight large enough that this
    # dominates any secondary bonuses below (residuals differ by >= 1).
    score = -residual.astype(np.float64) * 1000.0

    # Secondary: exact fills are ideal.
    score += (residual == 0).astype(np.float64) * 100.0

    # Secondary: mildly reward residuals that are at least a "usable" size,
    # estimated adaptively. We track a running small quantile of seen item sizes
    # via a simple exponential estimator biased toward small values.
    state = priority.state
    if state is None:
        state = {"small": float(item)}
        priority.state = state
    small = state["small"]
    # Update a lower-ish estimate of typical small item sizes (slow EMA toward min).
    if item < small:
        small = small * 0.7 + item * 0.3
    else:
        small = small * 0.97 + item * 0.03
    small = max(1.0, small)
    state["small"] = small

    # Reward residuals >= small (likely fillable later); small nonzero gaps slightly penalized.
    usable = residual >= small
    score += usable.astype(np.float64) * 1.0
    tiny = (residual > 0) & (residual < small)
    score -= tiny.astype(np.float64) * 1.0

    return score


priority.state = None
# EVOLVE-BLOCK-END
