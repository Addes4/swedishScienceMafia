# EVOLVE-BLOCK-START
"""Best fit with a stronger graded penalty for stranded residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small to be reused.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Graded penalty on small nonzero residuals: the smaller the gap, the more
    # likely it is stranded, so penalize it more. Exact fill (residual 0) is free.
    r = residual.astype(np.float64)
    penalty = np.where(r > 0, np.maximum(0.0, 10.0 - r) * 0.5, 0.0)
    score -= penalty

    return score
# EVOLVE-BLOCK-END

