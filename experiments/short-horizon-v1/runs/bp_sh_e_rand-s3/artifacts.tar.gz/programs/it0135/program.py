# EVOLVE-BLOCK-START
"""Best fit with distribution-aware residual targeting."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, softly steering residuals toward reusable sizes.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.

    The item distribution has mean about 40, so residuals near a typical item size
    (or 0) are more likely reusable later; very small nonzero residuals are usually
    stranded.  Primary ordering stays best-fit (smallest residual) to preserve the
    strong behavior on short streams; the penalty only refines near-ties.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary best-fit preference.
    score = -residual.astype(np.float64)

    # Softly penalize residuals too small to fit a typical future item.
    small = (residual > 0) & (residual < 20)
    score -= small.astype(np.float64) * 1.0

    return score
# EVOLVE-BLOCK-END

