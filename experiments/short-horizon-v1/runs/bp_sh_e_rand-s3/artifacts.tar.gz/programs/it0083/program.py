# EVOLVE-BLOCK-START
"""Best fit with adaptive penalty, plus a bonus for residual reuse and exact fills.

Ties in best-fit are broken by preferring residuals that the stream has already
shown to be reusable (frequent post-placement residual sizes), which helps pack
bins more tightly over long streams.
"""
import numpy as np

# Post-placement residual histogram (residual -> observed count).
_res_hist = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Rank bins by best fit, penalizing stranded tiny residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _res_hist, _total

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Tiny nonzero residuals are likely stranded capacity; add a mild penalty so
    # that when a slightly looser bin is available, we prefer it.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny.astype(np.float64) * 1.5

    # Bonus for residuals that historically turned out to be frequent sizes
    # (i.e. likely to be refilled by a future item). Exact fill (residual 0)
    # is always ideal and gets the largest bonus implicitly via best-fit.
    if _total > 5:
        frac = _res_hist[residual] / _total  # safe: residual bounded 0..100
        score += frac * 2.0

    # Update state with the residual we are about to create.
    best = int(np.argmax(score))
    r = int(residual[best])
    _res_hist[r] += 1.0
    _total += 1.0

    return score
# EVOLVE-BLOCK-END

