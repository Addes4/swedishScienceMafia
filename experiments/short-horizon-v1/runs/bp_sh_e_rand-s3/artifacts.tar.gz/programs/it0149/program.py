# EVOLVE-BLOCK-START
"""Best fit with a stateful bonus for residuals matching common item sizes."""
import numpy as np

# running histogram of item sizes seen so far (1..100)
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Rank bins by best fit, with a bonus when the residual matches a common size.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _COUNT

    # update running histogram with the current item (before scoring is fine;
    # it does not see future items)
    _HIST[item] += 1.0
    _COUNT += 1

    residual = bins - item  # >= 0 for all shown bins

    # Probability-like weight of each residual = how often that size has been seen.
    # Normalize by count so the bonus is on the same scale as the best-fit term.
    w = _HIST[residual] / _COUNT  # shape matches bins

    # Base strict best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Bonus (small) for residuals that match a frequently-seen item size,
    # making exact future fills more likely. Cap the residual range to avoid
    # rewarding large residuals.
    bonus = np.where(residual <= 60, w, 0.0)
    score += 2.0 * bonus

    return score
# EVOLVE-BLOCK-END

