# EVOLVE-BLOCK-START
"""Best fit, slightly biased toward residuals that history says get filled later.

The pure best-fit rule (place into the bin with the smallest remaining capacity
that still fits the item) is already very strong for this distribution.  The only
knob that has shown any hope of helping is the treatment of the leftover
capacity: a residual that cannot be exactly filled by a future item is stranded
capacity, whereas a residual that frequently appears as an item size can be
recovered.

We keep best fit as the dominant term and add a *tiny* bonus proportional to the
observed relative frequency of the resulting residual being a realisable item
size, estimated online from past items.  Because the bonus is tiny (< 1) it can
never override the primary best-fit ordering except between residuals that are
essentially indistinguishable, and exact fills (residual 0) still win because the
frequency of residual 0 is 0 while their primary score is maximal.
"""
import numpy as np


_FREQ = np.zeros(101, dtype=np.float64)  # observed item-size histogram (per stream, reset externally)
_SEEN = 0.0


def priority(item, bins):
    """Rank bins by best fit; break near-ties toward recoverable residuals."""
    global _SEEN

    residual = bins - item  # >= 0 for all shown bins (harness guarantees the item fits)

    # Primary term: best fit.  Smaller residual is strictly better.
    score = -residual.astype(np.float64)

    # Tiny secondary bonus: how often has this exact residual size occurred as an
    # item size in the past?  Such leftovers can later be filled exactly.
    # Laplace-smoothed relative frequency, scaled down so it only breaks ties.
    total = _SEEN + 101.0
    recoverable = _FREQ[residual] / total  # 0..1
    score += 0.5 * recoverable

    # Update the running histogram with the current item *after* scoring.
    _FREQ[item] += 1.0
    _SEEN += 1.0

    return score
# EVOLVE-BLOCK-END

