# EVOLVE-BLOCK-START
"""Best fit with a utility-aware tie-break on residual usefulness."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, with a mild preference for useful residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = (bins - item).astype(np.float64)  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual

    # Penalize stranded tiny nonzero residuals (space too small to be reused).
    # Exact fill (residual 0) is ideal and not penalized.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny * 1.5

    # Mild bonus for residuals that can still hold a "typical" item, encouraging
    # bins that remain productive rather than fragmenting into unusable capacity.
    useful = residual >= 40
    score += useful * 0.25

    return score
# EVOLVE-BLOCK-END

