# EVOLVE-BLOCK-START
"""Best fit refined with a size-aware residual-usefulness score."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, adjusted for how reusable the leftover capacity is.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Discourage tiny nonzero residuals: capacity too small to be reused by
    # typical items. Exact fill (residual 0) stays ideal and is not penalized.
    tiny = (residual > 0) & (residual < 10)
    score -= tiny.astype(np.float64) * 2.0

    # Gently prefer leaving a residual that is close to a typical item size
    # (~40) only when the residual is itself still substantial, encouraging
    # bins to remain reusable by a single future item.
    r = residual.astype(np.float64)
    usable = (r >= 20) & (r <= 60)
    score += usable.astype(np.float64) * (1.0 - np.abs(r - 40.0) / 40.0)

    return score
# EVOLVE-BLOCK-END
