# EVOLVE-BLOCK-START
"""Best fit enhanced with a stateful bonus for residuals equal to a common item size.

The core rule stays best-fit (smaller residual is better). On top of that we keep a
running histogram of past item sizes and give a small bonus to a placement whose
resulting residual equals the most frequent small item size seen so far, since such a
gap can likely be filled exactly by a future item. Exact fills (residual 0) always win.
"""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    residual = bins - item  # >= 0 for all shown bins

    # Update state with the current item (visible now, no future info).
    h = _state["hist"]
    h[item] += 1.0
    _state["n"] += 1

    n = _state["n"]
    score = -residual.astype(np.float64)

    if n > 20:
        sizes = np.arange(1, 101)
        freq = h[1:101] / n
        # Most common plausible-size gap (ignore very large gaps which are rare to fill).
        plausible = freq.copy()
        plausible[sizes >= item + 30] = 0.0
        if plausible.sum() > 0:
            target = sizes[int(np.argmax(plausible))]
            match = (residual == target) & (residual > 0)
            score += match.astype(np.float64) * 0.4

        # Mild penalty for tiny residuals that strand just a little capacity.
        tiny = (residual > 0) & (residual < 5)
        score -= tiny.astype(np.float64) * 1.0

    return score
# EVOLVE-BLOCK-END
