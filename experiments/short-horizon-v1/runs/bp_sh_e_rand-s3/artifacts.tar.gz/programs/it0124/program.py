# EVOLVE-BLOCK-START
"""Best fit with a residual-value function learned online from the item stream.

Classic best-fit minimizes the leftover residual, which greedily packs but can
strand small unusable capacities.  We keep the strong preference for exact fits
(residual 0) and, among the rest, prefer the bin whose leftover capacity is most
"useful": likely to be exactly consumed by a single future item.  The usefulness
of each residual level is estimated from the empirical item-size distribution
observed so far.
"""
import numpy as np


class _State:
    def __init__(self):
        # histogram of item sizes seen (index 1..100), and count
        self.hist = np.zeros(101, dtype=np.float64)
        self.n = 0.0
        # cached usefulness table indexed by residual 0..100
        self.table = None

    def observe(self, item):
        self.hist[item] += 1.0
        self.n += 1.0
        self.table = None  # invalidate cache

    def usefulness(self):
        """usefulness[r] ~ probability a residual r is exactly hit by one item."""
        if self.table is not None:
            return self.table
        if self.n < 50.0:
            # not enough data: fall back to flat (best-fit only)
            self.table = np.zeros(101, dtype=np.float64)
            return self.table
        p = self.hist / self.n
        # exact-hit probability for residual r is p[r] (r in 1..100)
        # weight it slightly by how "concentrated" that is; keep it simple & additive
        t = np.zeros(101, dtype=np.float64)
        t[1:101] = p[1:101]
        self.table = t
        return t


_STATE = _State()


def priority(item, bins):
    """Rank bins: exact fits best, then highest expected future usefulness."""
    _STATE.observe(item)

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference (smaller residual better), scaled to dominate the
    # usefulness term so we never stray far from best-fit's packing quality.
    score = -residual.astype(np.float64)

    # Add a small bonus for residuals that are likely to be exactly filled later.
    u = _STATE.usefulness()
    score += 5.0 * u[residual]

    # Strong reward for exact fill.
    exact = residual == 0
    score += exact.astype(np.float64) * 10.0

    return score
# EVOLVE-BLOCK-END
