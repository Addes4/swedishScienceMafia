# EVOLVE-BLOCK-START
"""Best fit with a stateful bonus for residuals that match common item sizes."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, with a bonus for residuals likely to be filled later.

    We keep best fit as the primary signal (smaller residual is better). To reduce
    stranded tiny residuals, we add a small stateful bonus when the residual after
    placement equals a size we have seen arriving recently in this stream — such a
    residual is likely to be exactly filled by a future item of that size.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    # Maintain a running histogram of item sizes seen so far in this stream.
    hist = getattr(priority, "_hist", None)
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        priority._hist = hist

    # Record current item (before scoring) so the histogram reflects the stream.
    hist[item] += 1.0

    residual = bins - item  # >= 0 for all shown bins

    # Normalize histogram to a frequency distribution over sizes.
    total = hist.sum()
    freq = hist / total

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Bonus: residuals that equal a recently-seen item size are more valuable,
    # since exact fills are more likely. Weight by how frequently that size occurs.
    safe_res = np.clip(residual, 0, 100)
    bonus = freq[safe_res] * 50.0  # scale to be a tie-breaker, not a primary term

    # Do not give the exact-fill bonus extra weight beyond being the best fit;
    # a residual of 0 is naturally best in the primary term.
    score += bonus

    return score
# EVOLVE-BLOCK-END

