# EVOLVE-BLOCK-START
"""Adaptive best fit: penalize residuals below the smallest item seen so far."""
import numpy as np


class _State:
    min_item = 100


_state = _State()


def priority(item, bins):
    """Rank bins by best fit, penalizing truly stranded residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    if item < _state.min_item:
        _state.min_item = item

    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize residuals that are positive but too small to ever host another item
    # (strictly smaller than the smallest item seen so far) -> stranded capacity.
    stranded = (residual > 0) & (residual < _state.min_item)
    score -= stranded.astype(np.float64) * 2.0

    return score
# EVOLVE-BLOCK-END
