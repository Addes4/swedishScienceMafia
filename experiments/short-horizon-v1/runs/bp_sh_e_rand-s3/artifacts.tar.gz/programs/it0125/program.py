# EVOLVE-BLOCK-START
"""Best fit guided by the empirical item-size distribution (residual fillability)."""
import numpy as np

# Online histogram of item sizes seen so far (1..100), used to value residuals.
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Rank bins: prefer exact fits, then bins whose residual is a plausible next item.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _total

    # Update empirical distribution with the current item (state persists per stream).
    _hist[item] += 1.0
    _total += 1.0

    residual = bins - item  # >= 0 for all shown bins

    # Probability that a future item exactly (or nearly) fits the residual.
    # p[r] = mass of sizes in [r-1, r] roughly; gives a fillability value per residual.
    probs = _hist / _total

    # Build a value table: for each possible residual r, value = chance next item leaves
    # a small residual there, i.e. sum of p[s] for s in a band around r.
    # r=0 is perfect (exact fill) and gets the top value.
    lo = np.maximum(residual - 1, 0)
    hi = residual + 1
    # cumulative mass in [lo, hi]; handle r=0 exactly as 1.0
    csum = np.concatenate(([0.0], np.cumsum(probs)))
    lo_c = csum[np.clip(lo, 0, 101)]
    hi_c = csum[np.clip(hi, 0, 100)]
    fillvalue = hi_c - lo_c

    # Prefer small residual strongly (best fit) AND high fillability.
    # Exact fill (residual 0) dominates.
    score = -residual.astype(np.float64) * 0.15 + fillvalue * 100.0
    exact = (residual == 0)
    score = np.where(exact, 1e6, score)

    return score
# EVOLVE-BLOCK-END
