# EVOLVE-BLOCK-START
"""Hybrid best-fit: pack tightly, but nudge toward bins that end up fuller."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item            # remaining capacity after placing the item
    # Base best-fit: prefer smallest resulting residual.
    score = -resid.astype(np.float64)
    # Small bonus when a bin becomes nearly full: final residual <= 10.
    score += 0.5 * (resid <= 10)
    return score
# EVOLVE-BLOCK-END
