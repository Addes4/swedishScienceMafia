# EVOLVE-BLOCK-START
"""Best fit with a guard against stranding tiny unusable residuals."""
import numpy as np

# Items come from a Weibull-shaped distribution with mean ~40, sizes 1..100.
# The smallest items are relatively rare and small, so a bin left with a tiny
# residual is effectively wasted. Best fit maximizes utilization, but among
# near-tight candidates we prefer the one whose leftover is still usable.

_MIN_USABLE = 5.0   # residuals below this are ~unusable for future items
_MIN_USABLE2 = _MIN_USABLE * _MIN_USABLE


def priority(item, bins):
    # Post-placement residual for each bin.
    resid = bins - item  # >= 0 because bins are only those that fit

    # Base score: prefer smallest residual (best fit), scaled.
    score = -resid.astype(np.float64)

    # Penalize residuals that are too small to be useful later: if a bin ends
    # with a tiny leftover it is likely stranded, so prefer leaving >= _MIN_USABLE
    # when the alternative isn't much worse.
    tiny = resid < _MIN_USABLE
    # Strong but not total: keep best-fit ordering dominant, use penalty to
    # break near-ties toward more usable leftovers.
    score -= tiny * (0.5 * (_MIN_USABLE - resid))

    return score
# EVOLVE-BLOCK-END
