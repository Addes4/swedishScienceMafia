# EVOLVE-BLOCK-START
"""Worst-fit: place each item into the feasible bin with the largest remaining capacity.

Worst-fit spreads items out, which can reduce the number of stranded tiny residuals
that best-fit creates; unused bins (remaining capacity 100) are naturally the loosest,
so the rule also defers opening partially filled bins in a different way than best-fit.
"""
import numpy as np


def priority(item, bins):
    """Rank bins by worst-fit: larger remaining capacity scores higher.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    return bins.astype(np.float64)
# EVOLVE-BLOCK-END

