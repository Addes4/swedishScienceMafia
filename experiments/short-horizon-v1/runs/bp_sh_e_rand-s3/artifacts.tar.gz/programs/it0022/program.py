# EVOLVE-BLOCK-START
"""Best fit with an adaptive usability threshold on residual capacity.

Items arrive online. Pure best fit leaves tiny residuals that future items cannot use.
We estimate a typical item size from the running stream and demote bins whose
post-placement residual is below that size (unusable), unless no better bin exists.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0, "sumsq": 0.0}


def priority(item, bins):
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["sumsq"] += float(item) * item

    n = st["n"]
    mean = st["sum"] / n
    var = max(st["sumsq"] / n - mean * mean, 0.0)
    std = var ** 0.5

    # Typical small item size: items that could still fill a gap.
    # Use a fraction of the running mean, floored to a sane minimum.
    thr = max(5.0, 0.5 * mean - 0.25 * std)

    residual = bins - item  # remaining capacity after placing the item

    # Base: best fit (tightest residual = smallest residual). Higher score better.
    base = -residual.astype(np.float64)

    # Penalize residuals that are non-zero but too small to host a typical item.
    tiny = (residual < thr) & (residual > 0)
    # Only apply penalty when at least one usable (non-tiny or zero) option exists.
    if tiny.any() and (~tiny).any():
        base = base - np.where(tiny, 1e6, 0.0)

    return base
# EVOLVE-BLOCK-END
