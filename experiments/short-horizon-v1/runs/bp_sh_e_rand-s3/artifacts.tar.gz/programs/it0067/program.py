# EVOLVE-BLOCK-START
"""Best fit with a stateful bonus for leaving reusable residuals."""
import numpy as np

_SIZES = np.zeros(101, dtype=np.float64)  # histogram of observed item sizes
_TOTAL = 0.0


def _update(item):
    global _TOTAL
    _SIZES[item] += 1.0
    _TOTAL += 1.0


def priority(item, bins):
    """Rank bins by best fit, giving a bonus for reusable leftover gaps.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    _update(item)

    residual = bins - item  # >= 0 for all shown bins
    score = -residual.astype(np.float64)

    # Tiny nonzero residuals are likely stranded capacity; mild penalty so that a
    # slightly looser bin is preferred when available. Exact fills stay unpenalized.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny.astype(np.float64) * 1.5

    # Stateful bonus: reward residuals that match item sizes seen before in the
    # stream, since such gaps can plausibly be refilled exactly later.
    if _TOTAL > 0:
        freq = _SIZES / _TOTAL
        r = residual
        valid = (r > 0) & (r <= 100)
        matched = np.zeros(r.shape, dtype=np.float64)
        idx = np.clip(r, 0, 100).astype(np.int64)
        matched[valid] = freq[idx[valid]] / (freq.max() + 1e-12)
        score += matched * 1.0

    return score
# EVOLVE-BLOCK-END
