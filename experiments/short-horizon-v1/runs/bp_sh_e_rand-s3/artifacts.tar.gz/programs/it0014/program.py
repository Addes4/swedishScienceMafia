# EVOLVE-BLOCK-START
"""Best fit with a mild load-balancing tie-break to preserve empty bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary term is best-fit: smaller post-placement residual is better.
    Secondary term mildly prefers already-used bins (lower remaining capacity)
    so that empty/near-empty bins stay reserved for large future items.
    """
    residual = bins - item
    # Primary: best fit (prefer small residual). Scale so it dominates.
    # Secondary: prefer fuller bins (smaller bins value) among close residuals.
    return -residual.astype(np.float64) * 1000.0 - bins.astype(np.float64)
# EVOLVE-BLOCK-END
