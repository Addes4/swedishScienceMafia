# EVOLVE-BLOCK-START
"""Best fit with an adaptive penalty for leaving unusable tiny residuals."""
import numpy as np

_state = {"sum": 0, "count": 0}


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small to be reusable.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _state
    residual = bins - item  # >= 0 for all shown bins

    # Running estimate of the mean item size seen so far.
    _state["sum"] += item
    _state["count"] += 1
    mean_item = _state["sum"] / _state["count"]

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize tiny nonzero residuals: capacity that is likely stranded because no
    # future item (which is on average `mean_item` large) will fit into it. Exact
    # fills (residual 0) are ideal and must not be penalized.
    tiny = (residual > 0) & (residual < mean_item * 0.25)
    score -= tiny.astype(np.float64) * (mean_item * 0.1)

    return score
# EVOLVE-BLOCK-END
