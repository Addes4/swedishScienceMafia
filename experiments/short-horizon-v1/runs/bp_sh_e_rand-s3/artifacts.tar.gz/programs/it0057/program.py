# EVOLVE-BLOCK-START
"""Best fit with exact-fill priority and a load-based tie-break."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit; prefer exact fills, break ties by fullest bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary: smaller residual is better (best fit).
    score = -residual.astype(np.float64)

    # Exact fill is strictly best: give it a decisive bonus.
    exact = residual == 0
    score += exact.astype(np.float64) * 1000.0

    # Tie-break among equal residuals: prefer the bin that is already more loaded
    # (smaller remaining capacity before placement), i.e. the larger item size.
    score -= bins.astype(np.float64) * 1e-3

    return score
# EVOLVE-BLOCK-END
