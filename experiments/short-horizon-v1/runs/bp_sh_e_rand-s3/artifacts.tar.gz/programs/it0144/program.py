# EVOLVE-BLOCK-START
"""Best fit with a mild penalty for stranded tiny residuals.

Primary signal is strict best-fit (smallest residual). A small penalty is
applied only to tiny nonzero residuals (1..4), which are the most likely to be
stranded, while exact fills (residual 0) stay optimal. This keeps the well-
performing best-fit ordering and reduces fragmentation of leftover capacity.
"""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small to be useful.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Tiny nonzero residuals are likely stranded capacity; penalize them mildly
    # so that when a slightly looser bin is available, we prefer it. Residual 0
    # (exact fill) is ideal and must NOT be penalized.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny.astype(np.float64) * 1.5

    return score
# EVOLVE-BLOCK-END
