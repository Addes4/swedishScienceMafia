# EVOLVE-BLOCK-START
"""Best fit with an adaptive guard against stranding tiny residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, avoiding residual gaps smaller than the smallest item seen.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary: best fit (smallest residual).
    score = -residual.astype(np.float64)

    # Avoid leaving a nonzero gap too small to ever hold another item:
    # penalize small gaps relative to the smallest item size seen so far.
    # Exact fills (residual 0) stay optimal.
    mask = (residual > 0) & (residual < item)
    score -= mask.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
