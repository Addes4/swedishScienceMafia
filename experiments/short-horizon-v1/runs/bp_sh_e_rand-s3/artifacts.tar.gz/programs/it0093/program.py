# EVOLVE-BLOCK-START
"""Best fit with a size-aware residual-utility tie-break."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit; break near-ties toward reusable residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins
    score = -residual.astype(np.float64)

    # Penalize stranded tiny nonzero residuals lightly, but prefer residuals
    # that are "reusable" (at least a typical small item).
    tiny = (residual > 0) & (residual < 4)
    score -= tiny.astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
