# EVOLVE-BLOCK-START
"""Best fit with a small distribution-aware penalty against stranding tiny residuals."""
import numpy as np

# Weibull-shaped item distribution, mean about 40. Approximate survival P(X > r)
# using a simple smooth decreasing share: items are rarely very small, so a residual
# of r is "usable" with probability roughly like exp(-r / scale). Best fit already
# packs tightly; we only lightly break ties toward usable leftovers.
_SCALE = 40.0

_prev_item = 0.0
_seen = 0


def priority(item, bins):
    """Return a priority for every bin; highest wins, ties to first bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of fitting bins (unused = 100).
    """
    global _prev_item, _seen

    # Pure best fit: smallest residual (= tightest fit) is best.
    residual = bins - item

    # Small bonus for residuals that are likely usable by future items.
    # Probability a future item fits in residual r ~ exp(-r/_SCALE).
    usable = np.exp(-residual / _SCALE)

    # Keep best-fit dominant: primary term is -(residual), bonus is tiny.
    score = -residual.astype(np.float64) + 0.01 * usable

    _prev_item += item
    _seen += 1
    return score
# EVOLVE-BLOCK-END
