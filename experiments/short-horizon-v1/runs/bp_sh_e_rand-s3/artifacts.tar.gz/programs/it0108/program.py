# EVOLVE-BLOCK-START
"""Best fit with an adaptive penalty for stranding small residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals too small to be reused.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Adaptive stranding penalty: residuals below the running mean item size are
    # likely to be stranded (no future item will fit). Penalize them smoothly by
    # how far below the threshold they are, scaled so best fit stays dominant.
    mean = max(_state["sum"] / _state["n"], 1.0) if _state["n"] > 0 else 40.0
    threshold = 0.5 * mean

    small = (residual > 0) & (residual < threshold)
    # Penalty grows as residual shrinks toward 0, bounded to keep best-fit dominant.
    pen = np.where(small, (threshold - residual) / threshold, 0.0)
    score -= pen

    # Track running mean item size (bounded contribution).
    _state["sum"] += item
    _state["n"] += 1

    return score


_state = {"sum": 0, "n": 0}
# EVOLVE-BLOCK-END
