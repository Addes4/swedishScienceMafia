# EVOLVE-BLOCK-START
"""Best fit with a small penalization of near-useless tiny residuals.

The item goes to the bin whose remaining capacity is smallest but still >= item,
i.e. the tightest fit.  When residuals are essentially tied, prefer the residual
that is a bit larger (less likely to be stranded forever) by adding a fractional
tie-break term proportional to the residual.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item, >= 0
    # Primary term: strongly prefer small residual (best fit).
    # Secondary term: among near-equal residuals prefer slightly larger residual
    # to avoid stranding tiny unusable gaps.  Scaled so it never overrides best fit.
    return -residual + residual / 256.0
# EVOLVE-BLOCK-END
