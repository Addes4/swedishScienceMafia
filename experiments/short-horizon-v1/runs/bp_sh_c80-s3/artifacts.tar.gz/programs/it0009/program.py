# EVOLVE-BLOCK-START
"""Best fit, tie-broken by preferring residuals that are common item sizes."""
import numpy as np


def priority(item, bins):
    """Rank bins: tight fit first, but prefer residual equal to a likely future item."""
    residual = bins - item
    # Base: tightly fitting bins score higher (smaller residual).
    base = -residual.astype(np.float64)
    # Bonus for residual exactly matching the current item gets no special merit;
    # instead slightly reward residuals in the typical item-size band (5..45) and
    # penalize tiny slivers (< 5) that are hard to fill later.
    small = residual < 5
    medium = (residual >= 5) & (residual <= 45)
    adjust = np.zeros(residual.shape, dtype=np.float64)
    adjust[medium] += 0.25
    adjust[small] -= 0.5
    return base + adjust
# EVOLVE-BLOCK-END
