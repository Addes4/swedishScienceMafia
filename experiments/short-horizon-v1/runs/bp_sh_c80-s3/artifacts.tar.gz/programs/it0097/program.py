# EVOLVE-BLOCK-START
"""Best fit with a small consolidation bonus: primary key is tightest residual,
secondary key prefers bins that are already more loaded (smaller pre-capacity),
which reduces the number of partially-filled bins left behind."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Primary: smallest residual (tightest fit). Secondary: prefer fuller bins
    # (smaller pre-placement capacity) to consolidate load and limit fragmentation.
    return -residual - 0.001 * bins
# EVOLVE-BLOCK-END
