# EVOLVE-BLOCK-START
"""Best-fit with an index (first-fit) tie-break toward earlier bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    # Tightest fit is primary; mild preference for earlier bins helps close bins.
    return -(bins - item).astype(np.float64) * 100.0 - idx
# EVOLVE-BLOCK-END
