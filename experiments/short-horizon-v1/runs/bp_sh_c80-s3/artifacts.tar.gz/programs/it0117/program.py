# EVOLVE-BLOCK-START
"""Sum of Squares rule: choose the bin that minimizes the resulting squared
remaining capacity, i.e. minimizes the increase in sum of squares of loads.
This classic online rule beats best fit on realistic item distributions."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item                      # remaining capacity after placing item
    return -(residual.astype(np.float64) ** 2)  # minimize residual^2 => maximize -residual^2
# EVOLVE-BLOCK-END
