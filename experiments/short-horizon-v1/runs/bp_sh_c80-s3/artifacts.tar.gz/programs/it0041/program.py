# EVOLVE-BLOCK-START
"""Stateful size-class-aware best fit.

Idea: residuals (remaining capacities) are only useful if they equal some item size
that will actually arrive.  Online we estimate the item-size distribution from the
past items in the stream and prefer the bin whose post-placement residual is most
likely to be exactly filled by a future item; among equally likely residuals we fall
back to best fit (tightest residual).
"""
import numpy as np


class _State:
    def __init__(self):
        # histogram of observed item sizes 1..100 (index 0 unused)
        self.hist = np.zeros(101, dtype=np.float64)
        self.total = 0.0


_STATE = _State()


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    st = _STATE

    # Update online histogram with the arriving item.
    st.hist[item] += 1.0
    st.total += 1.0

    # Residual each candidate bin would have after placing the item.
    residual = bins - item  # >= 0 for all shown bins

    # Score for a residual r: how attractive it is to leave capacity r unused.
    # We want r to be a size that frequently arrives (so it can be reused later).
    # hist_prob[r] = fraction of past items of exactly size r.
    prob = st.hist / st.total  # length 101

    # Map residuals to their "future fillability" probability.
    prob_score = prob[np.clip(residual, 0, 100)]

    # Best fit tie-break: prefer the smallest residual (tightest fit).
    # Scale so that probability dominates but ties are broken by tightness.
    # prob differences are >= 1/total ~ 1/n; use a small tightness term.
    tightness = -residual.astype(np.float64) * 1e-6

    return prob_score + tightness
# EVOLVE-BLOCK-END

