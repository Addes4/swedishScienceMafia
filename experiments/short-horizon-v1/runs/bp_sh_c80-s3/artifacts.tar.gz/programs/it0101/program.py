# EVOLVE-BLOCK-START
"""Best fit with a convex penalty that favors very tight residuals."""
import numpy as np


def priority(item, bins):
    """Return a score for every bin; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    residual = bins - item
    # Prefer the tightest fit (smallest residual).  Apply an extra convex penalty so
    # that residuals well above zero are penalized more than proportionally, pushing
    # items into nearly-full bins and leaving fresh bins open only when necessary.
    penalty = np.maximum(0.0, residual.astype(np.float64) - 30.0)
    return -residual.astype(np.float64) - 0.5 * penalty
# EVOLVE-BLOCK-END
