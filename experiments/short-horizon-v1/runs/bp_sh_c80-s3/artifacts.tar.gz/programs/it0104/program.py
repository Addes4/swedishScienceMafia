# EVOLVE-BLOCK-START
"""Best-fit with a small bonus for residuals that are likely to be reused.

The item distribution is Weibull-shaped with mean about 40, so residuals close to
common item sizes are more likely to be filled by a future item.  We keep the
tightest fit as the dominant criterion and add a tiny bonus based on a discrete
density estimate of the item-size distribution.
"""
import numpy as np

# Discrete weight for each possible residual/leftover size 0..100, approximating
# the probability an item of that size arrives.  Built once from a Weibull(2, ~45)
# style shape with mean near 40, rounded to integer sizes.
_SIZES = np.arange(0, 101)
_SHAPE = 2.0
_SCALE = 45.0
_raw = (_SIZES / _SCALE) ** (_SHAPE - 1.0) * np.exp(-(_SIZES / _SCALE) ** _SHAPE)
_raw[0] = 0.0
_DENSITY = _raw / _raw.sum()

# Bonus is deliberately tiny so that tightest-fit ordering is preserved except
# among essentially equal residuals.
_BONUS = 0.5 * _DENSITY


def priority(item, bins):
    """Score bins: primary is tightest fit (smallest residual), secondary rewards
    residuals whose size is a likely future item size."""
    residual = bins - item
    return -residual.astype(np.float64) + _BONUS[np.clip(residual, 0, 100)]
# EVOLVE-BLOCK-END
