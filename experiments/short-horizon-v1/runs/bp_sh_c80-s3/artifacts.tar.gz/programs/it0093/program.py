# EVOLVE-BLOCK-START
"""Best fit, but break near-ties toward residuals that a typical future item can use."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item
    # Primary: tightest fit (smallest post-placement residual).
    # Bonus: residuals that are usable by a typical future item (0 or >= mean ~40).
    usable = (resid == 0) | (resid >= 40)
    return -resid + 0.01 * usable
# EVOLVE-BLOCK-END

