# EVOLVE-BLOCK-START
"""Best fit with harmonic-style protection against unfillable slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Best fit picks the bin with the smallest post-placement residual.  Tiny residuals
    (smaller than the arriving item but far from zero) tend to be wasted slivers.  We
    demote bins whose resulting residual falls into the "bad sliver" zone, unless the
    residual is essentially zero (a perfect fit is always good).
    """
    residual = bins - item
    # Base: smaller residual is better (best fit).
    score = -residual.astype(np.float64)

    # A residual that is nonzero but smaller than the current item is a likely wasted
    # sliver.  Subtract a penalty that grows as the residual sits right below a
    # "useful" size.  Perfect fits (residual == 0) are exempt.
    sliver = (residual > 0) & (residual < item)
    # Penalize slivers proportionally to how small they are relative to the item,
    # but only mildly so best-fit still dominates in most cases.
    penalty = sliver.astype(np.float64) * (item - residual) * 0.5
    score -= penalty

    return score
# EVOLVE-BLOCK-END
