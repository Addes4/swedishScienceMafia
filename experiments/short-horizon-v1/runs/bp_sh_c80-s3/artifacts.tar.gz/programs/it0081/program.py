# EVOLVE-BLOCK-START
"""Modified best-fit: prefer tight fits but mildly damp unusably small residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    r = bins - item                      # residual after placing (>= 0, since item fits)
    # Base: strongly prefer smaller residual (best fit).
    score = -r.astype(np.float64)
    # Mild damping: small residuals (0,1,2...) are "wasted" since few future items fit,
    # so add a small bonus for residuals that can still accept typical items.
    damp = np.where(r < 3, r * 0.5, 0.0)
    return score + damp
# EVOLVE-BLOCK-END
