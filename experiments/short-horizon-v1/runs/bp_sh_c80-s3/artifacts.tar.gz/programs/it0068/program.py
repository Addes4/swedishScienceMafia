# EVOLVE-BLOCK-START
"""Best-fit with a small bias against opening unused (fresh) bins on ties."""
import numpy as np


def priority(item, bins):
    """Priority per bin; highest wins, first on ties.

    Primarily best-fit (tightest resulting residual). A tiny penalty is applied
    to placements that consume a fresh, empty bin (residual == 100 - item),
    so that existing equally-tight bins are preferred, reducing unnecessary
    bin openings.
    """
    residual = bins - item
    # Penalize consuming a fresh empty bin slightly so existing bins win ties
    # when their residual is equally tight.
    fresh = (bins == 100)
    return -residual.astype(np.float64) - 1e-3 * fresh
# EVOLVE-BLOCK-END
