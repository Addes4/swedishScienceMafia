# EVOLVE-BLOCK-START
"""Best-fit variant: minimize the squared residual after placement."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    return -(remaining.astype(np.float64) ** 2)
# EVOLVE-BLOCK-END
