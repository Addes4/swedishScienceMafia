# EVOLVE-BLOCK-START
"""Size-aware hybrid: worst-fit for large items, best-fit for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item >= 50:
        # Worst fit: put large items into the emptiest fitting bin so they are
        # not stranded in bins that are almost full.
        return bins.astype(np.float64)
    # Best fit: tightest residual for small items.
    return -(bins - item).astype(np.float64)
# EVOLVE-BLOCK-END

