# EVOLVE-BLOCK-START
"""Stateful sum-of-squares / best-fit hybrid bin-choice rule."""
import numpy as np


def priority(item, bins):
    # Best fit: prefer the bin that leaves the smallest nonnegative residual.
    residual = bins - item  # always >= 0 since only fitting bins are shown
    # Sum-of-squares potential: placing here changes residual^2 by
    #   (r - item)^2 - r^2 = item^2 - 2*item*r
    # Minimizing that gain is equivalent to maximizing r, i.e. worst fit.
    # Pure best fit minimizes r. A common strong online rule mixes the two:
    # favor tight fits but penalize leaving a residual that is a poor match
    # for typical future items. We approximate with best fit plus a tiny
    # preference for residuals near a small multiple of the item size.
    q = residual.astype(np.float64)
    # Distance of residual to the nearest nonnegative multiple of item size.
    m = np.round(q / item) * item
    frac_pen = np.abs(q - m)
    score = -q.astype(np.float64) - 1e-3 * frac_pen
    return score
# EVOLVE-BLOCK-END
