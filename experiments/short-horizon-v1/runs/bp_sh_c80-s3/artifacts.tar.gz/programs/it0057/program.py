# EVOLVE-BLOCK-START
"""Best fit, but avoid leaving useless tiny gaps in bins."""
import numpy as np


class _State:
    def __init__(self):
        self.min_seen = 100.0
        self.n = 0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    # online estimate of the smallest item size seen so far
    if item < _state.min_seen:
        _state.min_seen = float(item)
    _state.n += 1

    residual = bins - item

    # A gap strictly between 0 and the typical smallest item is wasted space.
    # Penalise leaving such a gap; reward exact fits slightly more.
    min_gap = _state.min_seen
    if _state.n < 3:
        min_gap = 1.0

    tiny = (residual > 0) & (residual < min_gap)
    # base: tightest fit (largest residual is worst -> score = -residual)
    score = -residual.astype(np.float64)
    # small extra bonus for exact fit
    score += np.where(residual == 0, 0.5, 0.0)
    # subtract a penalty for tiny useless gaps
    score -= np.where(tiny, min_gap, 0.0)
    return score
# EVOLVE-BLOCK-END

