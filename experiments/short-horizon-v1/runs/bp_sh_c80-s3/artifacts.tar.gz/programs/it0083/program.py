# EVOLVE-BLOCK-START
"""Tuned best-fit: prefer filling existing bins before opening a new one."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit (prefer smallest residual).
    score = -residual.astype(np.float64)
    # Small bonus for already-used bins (residual < 100) to discourage opening new bins.
    used = bins < 100
    score += 0.5 * used
    return score
# EVOLVE-BLOCK-END
