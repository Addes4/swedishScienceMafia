# EVOLVE-BLOCK-START
"""Best fit with a mild preference against consuming fresh bins on small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Core: best fit -> prefer the smallest residual that still fits the item.
    # Score = -(residual after placing). Higher score = tighter fit.
    residual = bins - item

    # For relatively small items, discourage using a completely empty bin,
    # since empty bins may be better spent on a future large item.
    # The effect is tiny so best-fit still dominates among already-used bins.
    if item <= 30:
        # nudge empty bins (residual 100 before placement) down a touch
        penalty = np.where(bins >= 100, 0.5, 0.0)
        return -residual - penalty

    return -residual
# EVOLVE-BLOCK-END

