# EVOLVE-BLOCK-START
"""Harmonic-style bin packing: class-based bin choice beats pure best-fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Harmonic-style classes: for k = 1, 2, 3, ... define threshold 100/k.
    # Items in (100/(k+1), 100/k] are class k. Bins are also bucketed by
    # remaining capacity; an item of class k prefers a bin whose residual
    # falls in the same class, then the tightest such fit.
    # Precompute class thresholds for the item.
    n = bins.size
    # Compute the class index of the item: smallest k with 100/k >= item.
    # i.e. k = ceil(100/item), bounded below by 1.
    k = (100 + item - 1) // item  # ceil(100/item)
    # Target residual range for bins to receive this item: bins with
    # residual in (100/(k+1), 100/k] fit the item and are preferred (same class).
    if k == 1:
        # Large item (>50): prefer tightest fit (best-fit), as only big bins fit.
        post = bins - item  # residual after placement
        # Prefer leaving residual close to 0.
        return -post
    # For class k >= 2, prefer bins whose residual is in the same class
    # (i.e. residual <= 100/k and residual > 100/(k+1)), tightest first.
    upper = 100.0 / k          # residual upper bound of class k
    lower = 100.0 / (k + 1)    # residual lower bound of class k
    # Score: bins whose post-placement residual lands in class k get a big bonus;
    # among those prefer tighter (smaller post residual).
    post = bins - item
    # In-class bonus: post residual in [lower, upper) means bin was roughly in class k.
    in_class = (post >= lower) & (post < upper)
    # Also give a milder bonus to leaving small residual (consolidation).
    score = np.where(in_class, 1e6, 0.0) - post
    return score
# EVOLVE-BLOCK-END

