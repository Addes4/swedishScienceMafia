# EVOLVE-BLOCK-START
"""Best fit with an online-learned gap-reuse tie-break.

Primary: tightest fit (smallest residual) so we never waste capacity.
Secondary: among near-tied residuals, prefer residuals that have historically
been exactly filled by arriving items, so leftover gaps get reused.
"""
import numpy as np

_STATE = {"counts": None, "seen": 0}


def priority(item, bins):
    counts = _STATE["counts"]
    if counts is None:
        counts = np.zeros(101, dtype=np.float64)
        _STATE["counts"] = counts
    seen = _STATE["seen"]

    # Residual after placing item in each bin.
    residual = bins - item  # bins already only contains bins where item fits

    if seen > 0:
        # Empirical probability that a future item exactly equals a given size.
        probs = (counts + 1.0) / (counts.sum() + 101.0)
        # Value of leaving residual r: chance a future item hits it exactly.
        # Only residuals that could be filled matter; scale mildly.
        gap_value = probs[np.clip(residual, 0, 100)]
    else:
        gap_value = np.zeros_like(residual, dtype=np.float64)

    # Primary: tightest fit. Secondary: gap that is likely reusable.
    return -(residual.astype(np.float64)) + 0.3 * gap_value
# EVOLVE-BLOCK-END
