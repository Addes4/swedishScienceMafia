# EVOLVE-BLOCK-START
"""Size-aware hybrid: big items use best fit, small items fill the fullest usable bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item
    if item * 2 >= 100:
        # Large item: best fit — leave the smallest residual (tightest fit).
        return -residual
    else:
        # Small item: prefer the fullest bin that still fits (smallest pre-placement
        # remaining capacity), keeping larger/empty bins open for big items.
        return -bins
# EVOLVE-BLOCK-END
