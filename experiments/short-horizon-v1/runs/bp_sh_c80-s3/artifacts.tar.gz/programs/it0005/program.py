# EVOLVE-BLOCK-START
"""Best fit with a micro-preference for already-used bins over fresh bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual_after = bins - item
    # Prefer the tightest fit (smallest residual after placement).
    score = -residual_after.astype(np.float64)
    # Micro-bias: slightly disfavor completely fresh bins (capacity 100) so that
    # existing partial bins are consolidated and fresh capacity is saved.
    fresh = (bins == 100)
    score -= 1e-3 * fresh
    return score
# EVOLVE-BLOCK-END
