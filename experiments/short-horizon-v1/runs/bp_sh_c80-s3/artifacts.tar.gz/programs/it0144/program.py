# EVOLVE-BLOCK-START
"""Harmonic-style bin choice: group residuals into geometric classes and pack tightly
within the smallest feasible class."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Class boundaries: roughly geometric over residual capacities 1..100.
    # A bin belongs to the smallest class (largest level) whose residual >= item.
    # We reward tight packing inside a class using the residual, and give a bonus
    # for classes whose residual upper bound is close to the item.
    residual = bins
    # Score: prefer tightest fits (small residual - item), but weight by an
    # inverse-capacity term so that near-full bins are strongly favored.
    slack = residual - item
    # Best-fit baseline plus mild preference for lower residuals overall.
    score = -slack.astype(np.float64)
    # Consolidation bonus: strongly prefer bins that end up quite full.
    score += -0.15 * residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
