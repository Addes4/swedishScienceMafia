# EVOLVE-BLOCK-START
"""Best fit with a mild target-residual bias based on an online mean estimate."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    residual = bins - item  # remaining capacity after placing the item

    # Base: pure best fit -> prefer smallest residual (tightest fit).
    score = -residual.astype(np.float64)

    # Mild bonus when the residual lands near the typical item size (good for packing).
    target = mean
    score -= 0.05 * np.abs(residual.astype(np.float64) - target)

    return score
# EVOLVE-BLOCK-END

