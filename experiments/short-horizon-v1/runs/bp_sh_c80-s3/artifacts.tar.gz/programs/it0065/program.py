# EVOLVE-BLOCK-START
"""Best fit with a harmonic reservation bonus based on the modal item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Base: best fit -> tightest residual (smaller residual => higher score).
    residual = bins - item
    score = -residual.astype(np.float64)

    # Track a histogram of past item sizes to find the modal (most common) size.
    hist = priority.hist
    hist[item] += 1
    tot = priority.total
    priority.total = tot + 1

    # Modal size so far (fallback to current item).
    modal = int(np.argmax(hist)) if priority.total > 0 and hist.max() > 0 else item
    if modal <= 0:
        modal = item

    # Give a small bonus when the resulting residual is a useful multiple of the
    # modal size (so recurring same-size items can keep filling bins evenly).
    if modal > 0:
        useful = residual > 0
        # residual is (close to) a multiple of modal -> good gap to leave
        mult = residual % modal
        good = useful & (mult == 0)
        # also reward residual == 0 slightly (perfectly full bin)
        perfect = residual == 0
        score = score + 0.5 * good.astype(np.float64) + 0.25 * perfect.astype(np.float64)

    return score


priority.hist = np.zeros(101, dtype=np.int64)
priority.total = 0
# EVOLVE-BLOCK-END

