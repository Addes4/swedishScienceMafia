# EVOLVE-BLOCK-START
"""Best-fit with a mild stateful preference for residuals matching common item sizes."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "count": 0.0}


def priority(item, bins):
    """Best-fit with a small bonus for residuals that match frequent item sizes."""
    state = _state
    hist = state["hist"]
    cnt = state["count"]

    residual = bins - item

    if cnt > 0:
        # probability-ish weight that residual can be exactly filled later
        prob = hist / cnt
        # bonus scales with probability and residual size (larger residuals more valuable to keep fillable)
        bonus = prob[residual.clip(0, 100)] * (residual + 1.0)
    else:
        bonus = np.zeros_like(residual, dtype=np.float64)

    # primary: smaller residual (best fit). bonus only breaks near-ties via small coefficient.
    score = -(residual.astype(np.float64)) + 0.02 * bonus

    # update history with the arriving item
    hist[item] += 1.0
    state["count"] = cnt + 1.0

    return score
# EVOLVE-BLOCK-END

