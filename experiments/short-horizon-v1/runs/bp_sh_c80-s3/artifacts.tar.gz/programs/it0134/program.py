# EVOLVE-BLOCK-START
"""Best-fit with a small penalty for opening fresh (empty) bins.

Items arrive online. Classic best-fit (choose the bin leaving the least residual)
is near-optimal for this size distribution, but early in the stream it can waste
a pristine full-capacity bin on a small item. We add a tiny, item-size-dependent
penalty to bins that are currently empty (capacity exactly 100) so that, when an
existing partially-filled bin fits comparably well, the item is placed there
instead. The penalty is small enough that when the item genuinely fits best in an
empty bin, best-fit still wins.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: minimize resulting residual = (bins - item), so negative residual.
    score = -(bins - item).astype(np.float64)

    # Small penalty for placing into a currently-empty bin (residual exactly 100).
    # Scale the penalty with item size so large items, which need full bins anyway,
    # are barely affected, while small items strongly prefer already-opened bins.
    empty_mask = (bins == 100)
    score[empty_mask] -= 1e-3 * item

    return score
# EVOLVE-BLOCK-END

