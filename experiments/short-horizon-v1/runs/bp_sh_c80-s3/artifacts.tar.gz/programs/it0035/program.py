# EVOLVE-BLOCK-START
"""Best-fit with residual-consolidation bonus.

Plain best fit (smallest residual >= item) is the strongest simple online rule
here.  The main source of waste is creating tiny residual slivers that no
future item can fill.  We keep best-fit as the dominant criterion, but when
several bins are (nearly) equally tight, prefer the placement whose resulting
residual equals some *other* existing bin's residual, so that two slivers
become one fillable slot.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary: best fit -> prefer small residual.  Use a large weight so that a
    # tighter bin always beats a looser one unless residual is identical.
    score = -residual.astype(np.float64) * 1000.0

    # Secondary (tie-break only, since residual differences dominate): reward
    # residuals that equal another bin's current residual (potential to pair up
    # into a full bin later).
    # Count how many bins currently hold each residual value.
    vals, counts = np.unique(bins, return_counts=True)
    present = dict(zip(vals.tolist(), counts.tolist()))

    for i in range(residual.size):
        r = int(residual[i])
        if r == 0:
            # Exact fill is ideal: small extra nudge (still dominated by best
            # fit ordering unless residuals tie).
            score[i] += 1.0
        elif r in present and present[r] > 0:
            score[i] += 0.5

    return score
# EVOLVE-BLOCK-END
