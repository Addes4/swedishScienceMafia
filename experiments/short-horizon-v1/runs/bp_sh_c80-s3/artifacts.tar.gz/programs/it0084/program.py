# EVOLVE-BLOCK-START
"""Modified best fit: favor tight fits but avoid creating tiny useless residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: strongly prefer tightest fit (classic best fit).
    score = -residual.astype(np.float64)
    # Mild penalty for creating very small residuals that can rarely be
    # filled again, which wastes almost a whole bin's worth of space.
    small = residual < item
    score[small] -= 0.5 * (item - residual[small])
    return score
# EVOLVE-BLOCK-END

