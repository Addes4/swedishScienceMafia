# EVOLVE-BLOCK-START
"""Best-fit with a stateful bonus for historically reusable leftover capacities."""
import numpy as np


def priority(item, bins):
    """Rank bins: tightest fit, plus a small bonus for leftovers that recur."""
    # Base: best-fit tightness (higher = tighter fit).
    res = bins - item
    score = -res.astype(np.float64)

    # State: frequency of item sizes seen so far (used to reward reusable leftovers).
    hist = priority.hist
    total = hist.sum()
    if total >= 16:
        # Fraction of past items of each size; a leftover equal to a common
        # size is likely to be exactly filled later.
        freqs = hist / total
        # Residuals that can still be filled must be in [1, 100].
        valid = (res >= 1) & (res <= 100)
        idx = np.clip(res, 0, 100)
        bonus = freqs[idx]
        score = score + 2.0 * bonus * valid

    return score


priority.hist = np.zeros(101, dtype=np.float64)


def _observe(item):
    priority.hist[item] += 1.0
# EVOLVE-BLOCK-END

