# EVOLVE-BLOCK-START
"""Best fit with a stateful future-fill-probability tie-break.

Pure best-fit minimizes the leftover residual. But a residual of, say, 7 may be hard to
fill later, while a residual of 30 may be fillable by many common item sizes. We keep an
online histogram of item sizes seen so far (petri-dish counts) and score a placement by
the negative estimated probability that the resulting residual gets exactly filled by a
future item. Among placements with similar fit quality we prefer fillable residuals.
"""
import numpy as np

# module-level online item-size statistics (per-stream state)
_counts = np.ones(101, dtype=np.float64)  # Laplace smoothing over sizes 1..100
_total = 100.0


def _fill_prob(res):
    """Estimated probability that a future item exactly equals `res`."""
    if res <= 0:
        return 1.0  # perfectly full: nothing to fill, treat as best
    if res > 100:
        return 0.0
    return _counts[res] / _total


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _counts, _total

    # update online histogram with the arriving item
    _counts[item] += 1.0
    _total += 1.0

    residuals = bins - item  # post-placement residual (>= 0 since all shown bins fit)

    # primary objective: tight fit (small residual) -> use -residual
    tight = -residuals.astype(np.float64)

    # secondary objective: prefer residuals likely to be exactly filled later.
    # vectorized fill probability
    r = residuals
    fill = np.zeros_like(tight)
    valid = r > 0
    if np.any(valid):
        rr = r[valid]
        fill[valid] = _counts[rr] / _total
    fill[~valid] = 1.0  # residual 0 -> perfect, best fill prob

    # combine: tight fit dominates, fillability resolves near-ties.
    # scale fill into a small tie-break band (less than 1 unit of residual).
    return tight + 0.5 * fill
# EVOLVE-BLOCK-END
