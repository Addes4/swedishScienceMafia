# EVOLVE-BLOCK-START
"""Best fit with a mild residual-shaping bonus."""
import numpy as np

MEAN = 40.0


def priority(item, bins):
    residual = bins - item
    # base: best fit (smaller residual -> higher score)
    score = -residual.astype(np.float64)
    # bonus: encourage residuals that can still hold a typical (mean) item,
    # penalize tiny slivers (>=1 but < min useful) and residuals just below mean
    bonuses = np.where(
        residual == 0, 3.0,
        np.where(residual >= 30, 0.5, np.where(residual >= 10, 0.0, -0.5))
    )
    return score + bonuses
# EVOLVE-BLOCK-END
