# EVOLVE-BLOCK-START
"""Best-fit with an online-learned tie-break on the resulting residual.

Primary rule: best fit (smallest residual r = bins - item).
Tie-break: among bins whose residual is within a small window of the best,
add a bonus for residuals that have historically been "absorbed" soon after
being created, so leftover gaps that are actually reusable get preferred.
State is updated every call from the actual residual created and the arriving
item size, so it adapts to the Weibull(mean~40) distribution without seeing
the future directly.
"""
import numpy as np

# residual value (0..100) -> smoothed count of how often a bin with that
# residual was subsequently filled by an arriving item (reuse success).
_REUSE = np.zeros(101, dtype=np.float64)
# how often each residual value was ever created (for normalization)
_CREATED = np.zeros(101, dtype=np.float64)
# last residual created per bin is not tracked (no bin ids); instead we
# track aggregate: on each call, before choosing, credit any current bin
# whose remaining capacity matches a value we care about only via histogram.

_ALPHA = 0.02          # weight of the learned tie-break
_WINDOW = 4            # residual window treated as "near best"
_DECAY = 0.999         # slow decay to stay adaptive


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    global _REUSE, _CREATED

    bins = np.asarray(bins)
    res = bins - item                       # residual after placing
    best = res.min()

    # reusable-residual score: fraction of the time that residual value,
    # once created, was soon used by another item.
    denom = _CREATED + 1.0
    reuse_score = _REUSE / denom            # in [0,1]

    near = res <= (best + _WINDOW)
    pri = -res.astype(np.float64)           # primary: best fit
    # small bonus only on near-best-fit bins, toward reusable residuals
    pri = pri + _ALPHA * reuse_score[res] * near

    # --- learn from this placement ---
    idx = int(np.argmax(pri))               # bin chosen (first max, matches harness)
    chosen_res = int(res[idx])
    # credit reuse: this arriving item absorbed the pre-placement capacity of
    # the chosen bin, i.e. that previous residual was successfully reused.
    prev_res = int(bins[idx])               # remaining capacity before placement
    if 0 <= prev_res <= 100:
        _REUSE[prev_res] += 1.0
    if 0 <= chosen_res <= 100:
        _CREATED[chosen_res] += 1.0
    _REUSE *= _DECAY
    _CREATED *= _DECAY

    return pri
# EVOLVE-BLOCK-END

