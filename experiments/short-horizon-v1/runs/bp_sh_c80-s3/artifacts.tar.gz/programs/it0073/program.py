# EVOLVE-BLOCK-START
"""Best-fit, but avoid leaving tiny dead residuals by preferring second-best in that case."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    n = residual.shape[0]
    if n == 0:
        return residual.astype(np.float64)

    order = np.argsort(residual, kind="stable")
    # Build descending priorities in residual order (tightest gets highest) -> best fit.
    pri = np.empty(n, dtype=np.float64)
    pri[order] = -np.arange(n, dtype=np.float64)

    # If the tightest residual is a tiny "dead zone", boost the second-tightest instead.
    if n >= 2:
        best_res = residual[order[0]]
        if 0 < best_res < 15:
            pri[order[1]] = 1.0
    return pri
# EVOLVE-BLOCK-END
