# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and unfillable-sliver avoidance."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.int64), "n": 0}

# Residuals (1..RMAX-1) that the item distribution almost never fills.
# Computed from a rough Weibull(mean~40) sized model: small residuals are
# rarely exactly matched. We use an empirical-frequency heuristic instead of
# hardcoding, but keep a fallback range.
_RMAX = 100


def _fillable(item, bins):
    # exact match: a bin whose residual equals the item exactly leaves 0.
    return bins == item


def priority(item, bins):
    """Score bins for the arriving item; highest score wins (first on ties).

    Primary: tightest fit (best fit). Enhancement: prefer a bin whose
    residual exactly equals the item (perfect fill) - since best-fit already
    picks the minimum residual, this only matters when min residual > item,
    i.e. we rank by smallness but break near-ties by exact-fill potential.
    Secondary: avoid leaving a tiny unfillable sliver when a slightly larger
    residual is (empirically) much more likely to be exactly refilled.
    """
    hist = _state["hist"]
    n = _state["n"]
    # update histogram with the observed item (state persists within a stream)
    item_i = int(item)
    if 1 <= item_i <= 100:
        hist[item_i] += 1
        _state["n"] = n + 1
    n = _state["n"]

    resid = bins - item  # resulting residual if placed here; >= 0 guaranteed

    # Base priority: smaller residual is better (best fit).
    score = -resid.astype(np.float64)

    # Boost bins that achieve an exact fill (residual == 0).
    score[resid == 0] += 1e6

    # Among bins with very small residuals, penalize leaving tiny slivers
    # (1..3) that are hard to fill, by nudging them down slightly relative
    # to bins leaving 0.
    if n > 0:
        total = float(n)
        # empirical fillability of a residual value r = prob some observed
        # size equals r (rough proxy using the histogram).
        freq = hist / total
        # for residuals in 1..20, add a small bonus proportional to how
        # often a future item of exactly that residual size tends to appear.
        small = (resid >= 1) & (resid <= 20)
        if small.any():
            score[small] += 0.5 * freq[resid[small].astype(np.int64)]

    return score
# EVOLVE-BLOCK-END
