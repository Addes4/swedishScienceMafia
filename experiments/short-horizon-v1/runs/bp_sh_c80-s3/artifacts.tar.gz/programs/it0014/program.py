# EVOLVE-BLOCK-START
"""Best fit with a small learned tie-break that favors re-usable residuals."""
import numpy as np

# Running histogram of observed item sizes (1..100), shared across calls within a stream.
_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Score bins: primarily best fit (smallest residual), tie-broken by fillability.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _counts, _total

    # Update online histogram with the arriving item (state persists within a stream).
    if 1 <= item <= 100:
        _counts[item] += 1.0
        _total += 1.0

    residuals = bins - item  # remaining capacity after placing the item

    # Base score: best fit -> smaller residual is much better.
    score = -residuals.astype(np.float64)

    # Learned tie-break: among bins with (nearly) equal residual, prefer residuals that
    # historical item sizes can still fill reasonably well (typical reusable leftovers).
    if _total >= 8:
        p = _counts / _total  # P(future item == s)
        # Probability that some future item fits exactly into a residual r: sum_{s<=r} p[s]
        # (scaled by items remaining is unknown, so just a monotone fillability weight).
        cum = np.cumsum(p)  # cum[r] = P(item <= r)
        usable = cum[np.clip(residuals, 0, 100)]
        # Small bounded bonus so it only breaks near-ties, not override best fit.
        score = score + 0.25 * usable

    return score
# EVOLVE-BLOCK-END
