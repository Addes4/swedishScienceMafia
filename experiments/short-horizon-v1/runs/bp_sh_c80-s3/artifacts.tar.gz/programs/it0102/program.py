# EVOLVE-BLOCK-START
"""Best fit with a mild residual-reusability tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary criterion: tightest fit (smallest residual after placement).
    Secondary, tiny tie-break: prefer residuals that leave a reusable gap (favor
    residuals near 0 and near common mid sizes), which slightly improves packing
    without overriding the dominant tightest-fit behavior.
    """
    residual = bins - item
    # Tiny tie-break: mildly prefer residuals that are small but still 'reusable'.
    # residual==0 is best; residuals around typical item sizes are also useful.
    # Use a smooth small bonus so it never overturns a strictly tighter fit.
    bonus = -0.001 * residual
    return -(residual) + bonus
# EVOLVE-BLOCK-END
