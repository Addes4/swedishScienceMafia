# EVOLVE-BLOCK-START
"""Best-fit variant that avoids stranding tiny unusable residuals."""
import numpy as np

_state = {"min_item": 101}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    m = _state["min_item"]
    if item < m:
        m = item
        _state["min_item"] = m

    residual = bins - item

    # Useful residual threshold: a residual below the smallest item seen so far
    # can never hold another item, so it is pure waste. Prefer residuals that
    # are at least this large, but otherwise fall back to ordinary best fit.
    useful = residual >= m

    # Score: bins leaving a "useful" residual rank above bins that don't;
    # within each group, tighter fit (smaller residual) is better.
    drive = np.where(useful, 1000.0 - residual, -residual)
    return drive
# EVOLVE-BLOCK-END
