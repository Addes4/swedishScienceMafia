# EVOLVE-BLOCK-START
"""Best fit with unusable-gap awareness learned online."""
import numpy as np


def priority(item, bins):
    """Rank bins: best fit, but penalize leaving a residual gap too small to be filled.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Track the smallest item size seen so far (online, no future knowledge).
    global _min_seen
    try:
        _min_seen
    except NameError:
        _min_seen = 100

    if item < _min_seen:
        _min_seen = item

    # Smallest size we have ever seen; any residual below it may never be fillable,
    # but item sizes are integers so residual < _min_seen is potentially dead space.
    dead = _min_seen - 1

    residual = bins - item  # remaining capacity after placing item here

    # Base score: leave the smallest possible residual (best fit).
    score = -residual.astype(np.float64)

    # Penalty for stranding dead space (residual > 0 but < dead threshold).
    is_dead = (residual > 0) & (residual <= dead)
    score[is_dead] -= 0.5

    return score
# EVOLVE-BLOCK-END
