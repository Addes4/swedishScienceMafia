# EVOLVE-BLOCK-START
"""Best fit with an exact-empty tie-break bonus.

Pure best fit (tightest residual) is strong but occasionally leaves slivers.
A cheap, robust improvement: when an item exactly exhausts a bin (residual after
placement is 0) that's strictly better than other placements, because it removes
a bin from the pool for all future items.  Encode this as a small bonus so it
wins ties/close calls, while otherwise remaining best fit.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item          # remaining capacity after placement
    # Base: prefer tightest fit -> smallest residual is best.
    score = -residual.astype(np.float64)
    # Bonus for perfectly filling a bin (residual == 0).
    score[residual == 0] += 0.5
    return score
# EVOLVE-BLOCK-END
