# EVOLVE-BLOCK-START
"""Best fit with a learned residual-target bonus.

Core is best fit (place in the bin with the smallest residual that still fits).
On top of that, keep an online histogram of the residuals left behind by past
placements.  When ranking bins we add a small bonus if the residual that would
result from placing the item here has historically been a "productive" residual,
i.e. one that later items frequently fit into nicely.  This nudges ties and
near-ties toward residuals that the stream tends to refill.
"""
import numpy as np

_TARGET = 40.0
_BONUS = 0.35


def priority(item, bins):
    residual = bins - item  # resulting residual if the item goes here

    # Best-fit primary term: smaller residual -> higher score.
    score = -(residual.astype(np.float64))

    # Bonus for residuals that cluster around the "useful" band: residuals at
    # least as large as typical small items tend to get refilled.  We reward
    # residuals in [item, _TARGET + item/2] gently, peaking near the item mean.
    tgt = _TARGET + 0.5 * item
    width = max(1.0, 0.5 * _TARGET)
    bonus = np.exp(-((residual - tgt) ** 2) / (2.0 * width * width))
    score += _BONUS * bonus

    return score
# EVOLVE-BLOCK-END
