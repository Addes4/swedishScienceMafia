# EVOLVE-BLOCK-START
"""Modified best fit: pack tightly, but avoid creating unusable slivers.

Items arrive one at a time. Pure best fit packs each item into the bin with the
smallest residual after placement, which is strong on average but occasionally
strands a few units of capacity that no future item can use. This rule keeps the
best-fit ordering as the primary key, but nudges it: it tracks a running estimate
of the typical item size and, when the tightest fit would leave a residual smaller
than that typical size, it prefers a slightly larger residual so the leftover
space stays reusable.
"""
import numpy as np


class _State:
    def __init__(self):
        self.total = 0.0
        self.count = 0


_state = _State()


def priority(item, bins):
    """Score each bin; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    # Update the running mean of observed item sizes.
    _state.total += item
    _state.count += 1
    mean_item = _state.total / _state.count

    residual = bins - item  # remaining capacity after placing the item here

    # Primary key: tightest fit (smallest residual). Best fit = -residual.
    score = -residual.astype(np.float64)

    # Small reward for leaving a residual that at least one more typical item could fit,
    # which keeps the leftover space from becoming dead slivers.
    reusable = (residual >= mean_item).astype(np.float64)
    score += 0.5 * reusable

    # Punish residuals that are small but nonzero: almost certainly unusable space.
    sliver = ((residual > 0) & (residual < mean_item)).astype(np.float64)
    score -= 0.25 * sliver

    return score
# EVOLVE-BLOCK-END
