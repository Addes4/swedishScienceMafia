# EVOLVE-BLOCK-START
"""Best fit with a small-item empty-bin penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base score: prefer tightest fit (smallest residual).
    score = -residual.astype(np.float64)
    # Slightly penalize using an empty (fully unused) bin for small items,
    # preferring to consolidate into already-open bins.
    if item <= 40:
        score -= (bins == 100) * 0.5
    return score
# EVOLVE-BLOCK-END
