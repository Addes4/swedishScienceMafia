# EVOLVE-BLOCK-START
"""Best fit with a small preference against opening fresh bins for small/medium items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Core rule is best-fit (smallest residual after placement). We add a small penalty to
    completely empty bins (residual 100) when the item is not large, so that small and
    medium items fill existing residuals first and empty bins stay available for large items.
    """
    residual = bins - item  # smaller is tighter fit
    score = -residual.astype(np.float64)
    # Penalize fresh empty bins for non-large items.
    if item < 75:
        score = np.where(bins == 100, score - 3.0, score)
    return score
# EVOLVE-BLOCK-END
