# EVOLVE-BLOCK-START
"""Residual-target fit: balance tight fills against leaving fillable residuals."""
import numpy as np

_MEAN = 40.0  # approx mean item size (Weibull-shaped distribution)


def priority(item, bins):
    """Score each bin; item goes to the highest score (first on ties).

    Primary signal is best-fit (small post-placement residual is good), but we
    also reward residuals close to the typical item size so future items can
    nearly fill them. Unused bins (residual 100) get a mild penalty for small
    items to preserve them for large ones.
    """
    r = bins - item  # post-placement residual (>= 0)

    # Best-fit component: strongly prefer small residuals (near-exact fill).
    best_fit = -r.astype(np.float64)

    # Target component: reward residuals near the mean so they can be filled.
    # Only meaningful for residuals a normal item could fill.
    target = -np.abs(r.astype(np.float64) - _MEAN)

    # Combine: best-fit dominates ties, target breaks near-equal fits.
    score = best_fit + 0.15 * target

    # If the residual equals zero (perfect fill), give it a big bonus.
    score += np.where(r == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

