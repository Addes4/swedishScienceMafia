# EVOLVE-BLOCK-START
"""Hybrid best-fit: preserve room for large items while packing small ones tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    if item >= 50:
        # Large items: pure best fit to avoid stranding big items in near-full bins.
        return -residual.astype(np.float64)

    # Small items: best fit, but add a mild preference for bins that end up
    # moderately full (residual near a target) so larger empty bins stay free.
    target = 25.0
    bonus = -np.abs(residual - target)
    return -residual.astype(np.float64) + 0.02 * bonus
# EVOLVE-BLOCK-END
