# EVOLVE-BLOCK-START
"""Best-fit augmented with residual-matching against the observed item-size distribution."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    """Rank bins: strong best-fit, plus a bonus for residuals matching common item sizes."""
    hist = _state["hist"]
    n = _state["n"]

    # Update observed item-size histogram.
    hist[item] += 1.0
    _state["n"] = n + 1

    residual = bins - item  # remaining capacity after placing item

    # Best-fit component: prefer small residual (tight fit).
    bf = -residual.astype(np.float64)

    if n >= 20:
        # Normalized probability of an item matching each resulting residual.
        probs = hist / hist.sum()
        size_match = probs[np.clip(residual, 0, 100)]
        # Weight: moderate, so best-fit remains the primary driver.
        bonus = 12.0 * size_match
    else:
        bonus = 0.0

    return bf + bonus
# EVOLVE-BLOCK-END
