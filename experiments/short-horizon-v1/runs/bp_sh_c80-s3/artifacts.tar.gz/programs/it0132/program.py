# EVOLVE-BLOCK-START
"""Best-fit with conserved empty bins for future large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: best fit -> smaller resulting residual (bins - item) is better.
    residual = bins - item
    score = -residual.astype(np.float64)

    # Penalize using a perfectly pristine (capacity 100) bin so empty bins are
    # conserved for future large items, unless the item is itself large.
    empty = bins == 100
    if item < 60:
        # Discourage opening a fresh bin with medium/small items.
        score = score - empty * (60.0 - item) * 0.5

    return score
# EVOLVE-BLOCK-END
