# EVOLVE-BLOCK-START
"""Stateful best-fit: prefer tight fits, but break near-ties toward residuals that
past item sizes suggest are likely to be filled exactly later."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)   # smoothed counts of observed item sizes
_TOTAL = 0.0


def _reset():
    global _HIST, _TOTAL
    _HIST = np.zeros(101, dtype=np.float64)
    _TOTAL = 0.0


def priority(item, bins):
    global _HIST, _TOTAL

    if _TOTAL == 0.0 and not np.any(_HIST):
        pass

    # record the arriving item (used on subsequent calls only)
    _HIST[item] += 1.0
    _TOTAL += 1.0

    bins = np.asarray(bins)
    residual = bins - item          # >= 0 by construction
    fit_gap = bins - item           # larger gap = less tight

    # estimated probability that a random future item equals a given residual size
    # (residual 0 means the bin is full -> perfect)
    prob = (_HIST + 0.5) / (_TOTAL + 50.0)   # Laplace-smoothed per-size frequency

    # fill score: how likely is this residual to be exactly matched later?
    # residual 0 -> bin fully used, best; residual 100 -> fresh bin, neutral
    fill_score = np.empty_like(residual, dtype=np.float64)
    idx = np.clip(residual, 0, 100).astype(np.int64)
    fill_score = prob[idx]
    fill_score[residual == 0] = 1.0          # a full bin is ideal

    # primary: best fit (smallest residual). secondary: prefer more fillable residuals.
    # best-fit is the dominant term; fillability only breaks near ties.
    return -(fit_gap) + 0.75 * fill_score
