# EVOLVE-BLOCK-START
"""Best fit with a mild exact-fit reservation on ties among tightest fits."""
import numpy as np

_state = {"min_item": 100.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    # track smallest item seen so far (safe lower bound on future items)
    if item < _state["min_item"]:
        _state["min_item"] = float(item)

    n = _state["n"]
    _state["n"] = n + 1

    residual = bins - item  # >= 0 for all shown bins

    # Primary: best fit (tightest residual = smallest residual).
    score = -residual.astype(np.float64)

    # Secondary (only matters on ties): among equal residuals, prefer the bin whose
    # residual is not a value that a future item is likely to exactly need.
    # Small residuals that are below the smallest item seen so far are dead weight,
    # so give them a tiny bonus to be consumed now.
    min_item = _state["min_item"]
    dead = (residual < min_item) & (residual > 0)
    score = score + 1e-3 * dead.astype(np.float64)

    # Exact fills (residual 0) are always good; nudge them very slightly.
    score = score + 1e-6 * (residual == 0).astype(np.float64)

    return score
# EVOLVE-BLOCK-END
