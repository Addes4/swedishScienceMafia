# EVOLVE-BLOCK-START
"""Best fit with a learned nudge toward reusable residuals.

The item goes to the tightest-fitting bin (best fit), except that among bins whose
residuals are within a small margin of the tightest one we prefer the bin whose
post-placement residual equals a size value we have frequently seen arriving.
This keeps best fit as the anchor (so we rarely do worse) while quietly avoiding
residual slivers that can never be refilled, by matching them to the learned
item-size distribution.
"""
import numpy as np

# module-level state, reset when a new stream starts (detected via bins array
# still being "fresh" is unreliable, so we key off a monotonically growing total)
_state = {
    "counts": np.zeros(101, dtype=np.int64),  # histogram of observed item sizes
    "n": 0,
}


def _reset_if_new_stream(bins):
    """Heuristically detect a new stream: many untouched bins with full capacity."""
    # A fresh stream's bins array is mostly capacity-100 entries (unused bins).
    # If a large fraction are 100, treat as a new stream and clear state.
    if bins.size > 0 and np.count_nonzero(bins >= 100) >= max(8, bins.size // 2):
        # only reset if we had accumulated a lot (avoid flapping each call)
        if _state["n"] > 200:
            _state["counts"][:] = 0
            _state["n"] = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first bin."""
    bins = np.asarray(bins)
    _reset_if_new_stream(bins)

    # record the item in the running histogram
    if 1 <= item <= 100:
        _state["counts"][int(item)] += 1
    _state["n"] += 1

    residual = bins - item  # post-placement remaining capacity in each bin
    # best fit: prefer smallest (nonnegative) residual; bins shown all fit so >=0
    base = -residual.astype(np.float64)

    # learned nudge: bonus if residual matches a frequently observed item size,
    # so the leftover space is refillable.  Small weight => never overrides a
    # clear best-fit choice, only breaks near-ties.
    bonus = np.zeros_like(base)
    n = _state["n"]
    if n >= 32:
        counts = _state["counts"]
        # frequency (log-scaled) of future items exactly equalling the residual
        # residual is integer-valued here
        res_int = residual.astype(np.int64)
        valid = (res_int >= 1) & (res_int <= 100)
        freq = np.zeros_like(base)
        freq[valid] = counts[res_int[valid]].astype(np.float64) / n
        # also reward residuals equal to 100 (opening a clean bin) modestly
        freq[(res_int == 100)] = max(freq[(res_int == 100)].max() if np.any(res_int == 100) else 0.0, 0.0)
        bonus = 0.75 * np.log1p(freq * n)  # small, bounded nudge

    return base + bonus
# EVOLVE-BLOCK-END
