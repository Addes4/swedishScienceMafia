# EVOLVE-BLOCK-START
"""Best-fit with a tie-break that favors filling already-fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # primary: tightest fit (smallest residual)
    # secondary: break near-ties by preferring the fuller bin (smaller current capacity)
    return -(residual) * 1000.0 - bins
# EVOLVE-BLOCK-END

