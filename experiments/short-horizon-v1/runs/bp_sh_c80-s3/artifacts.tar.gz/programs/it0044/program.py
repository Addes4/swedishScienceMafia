# EVOLVE-BLOCK-START
"""Best fit with empty-bin reservation for large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing
    score = -residual.astype(np.float64)  # best fit: smaller residual -> higher score

    # Reserve completely empty bins for reasonably large items.
    # If the item is small relative to the typical item size, penalize using a fresh bin.
    empty = bins == 100
    if item < 40:
        score = score - empty * 50.0
    elif item < 60:
        score = score - empty * 5.0

    return score
# EVOLVE-BLOCK-END
