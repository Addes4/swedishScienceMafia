# EVOLVE-BLOCK-START
"""Best fit augmented with an online estimate of the item distribution.

The rule still picks the tightest fit, but when several bins give residuals of
similar quality it prefers the residual that is most likely to be reused by a
future item.  The distribution of item sizes is learned online with a simple
frequency table and converted into a reuse-value for each candidate residual.
"""
import numpy as np

_CAP = 100.0

# online histogram of observed item sizes (index = size, 1..100)
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0


def _residual_value(r):
    """Estimated usefulness of leaving residual r in a bin."""
    ri = int(r)
    if ri <= 0:
        return -1e9
    # probability that some future item exactly fits this residual
    exact = _hist[ri]
    # probability that a future item fits at all (non-empty residual is good)
    fits = _hist[1:ri + 1].sum() if ri >= 1 else 0.0
    total = _hist.sum() + 1e-9
    p_exact = exact / total
    p_fit = fits / total
    # prefer small residuals that can still be filled, but not hopeless slivers
    return p_fit + 2.0 * p_exact


def priority(item, bins):
    global _n
    # update online distribution estimate
    _hist[int(item)] += 1.0
    _n += 1.0

    resid = bins.astype(np.float64) - float(item)
    # tightest fit dominates the ordering
    tight = -resid
    # additive, much smaller preference for reusable residuals
    if _n < 5:
        return tight
    vals = np.empty(len(resid), dtype=np.float64)
    for i in range(len(resid)):
        vals[i] = tight[i] + 0.5 * _residual_value(resid[i])
    return vals
# EVOLVE-BLOCK-END
