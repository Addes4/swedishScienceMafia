# EVOLVE-BLOCK-START
"""First fit: place the item in the first (lowest-index) bin it fits in.

Bins with remaining capacity >= item are shown; among those, the lowest-index
bin has full remaining capacity 100 only if unused, but in general early bins
hold earlier items. Ranking by smallest remaining capacity with earliest-index
tie-breaking approximates First-Fit while respecting that the harness picks the
highest score (first on ties).
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Smallest remaining capacity first; numpy argmax picks the first max on ties,
    # so equal residuals favor the lower bin index -> First-Fit behavior.
    return -bins.astype(np.float64)
# EVOLVE-BLOCK-END
