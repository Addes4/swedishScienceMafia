# EVOLVE-BLOCK-START
"""Adaptive best-fit that reserves empty bins for large future items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (ties: first bin).

    Base rule is best-fit (tightest fitting bin).  We add a stateful penalty for
    consuming a pristine (capacity 100) bin with a small item, so that a few empty
    bins are held in reserve for the large items that this Weibull-shaped stream
    still tends to produce.
    """
    remaining = bins.astype(np.float64)

    # Base best-fit score: the tighter the bin the higher the score.
    base = -(remaining - item)

    # Penalize wasting a completely empty (unused) bin on a small item.
    penalty = np.where((remaining >= 100), (60.0 - item) * 0.5, 0.0)

    return base - penalty
# EVOLVE-BLOCK-END
