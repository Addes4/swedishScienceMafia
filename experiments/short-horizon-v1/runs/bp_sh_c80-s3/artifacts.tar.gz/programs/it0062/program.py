# EVOLVE-BLOCK-START
"""Best fit with a tie-break that pairs identical residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: best fit (tightest residual after placement = smallest bins - item).
    residual = bins - item
    score = -residual.astype(np.float64)
    # Tiny tie-break: prefer placements whose residual exactly equals the item size,
    # which lets stacks of identical items keep combining into the same bins.
    tie = (residual == item).astype(np.float64)
    return score + 0.5 * tie
# EVOLVE-BLOCK-END

