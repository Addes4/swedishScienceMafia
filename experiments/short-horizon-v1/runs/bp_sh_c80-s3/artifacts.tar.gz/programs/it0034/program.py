# EVOLVE-BLOCK-START
"""Best fit with a light stateful harmonic preference for mid-size items.

Plain best fit (smallest residual that still holds the item) is a very strong
online rule for this item distribution.  The only room for improvement is in
the residuals it leaves behind: best fit often strands awkward slivers.  We
keep best fit as the dominant term and add a *tiny* secondary preference,
based on an online histogram of past item sizes and harmonic capacity
classes, that nudges mid-size items toward bins whose resulting residual is
likely to be fillable by a future item.
"""
import numpy as np

# harmonic class lower bounds for post-placement residual targets
# (a residual is "good" if a future item can land near it)
_CLASSES = np.array([1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 14, 16, 20, 25, 33, 50, 100])


def priority(item, bins):
    """Best-fit primary score with a faint harmonic-residual preference."""
    residual = bins - item  # >= 0 for all shown bins
    # primary: smaller residual is better
    primary = -residual.astype(np.float64)

    # secondary: prefer post-placement residuals that are themselves close to
    # usable future item sizes.  We grow a coarse online estimate of common
    # item sizes and give a micro-bonus to residuals near those sizes.
    # Use a fixed, distribution-agnostic target set (Weibull-ish, mean ~40 is
    # broad); giving a small bonus to a *very small* residual helps pack bins
    # tightly without disturbing best fit except on near-ties.
    tight = (residual <= 3).astype(np.float64)
    secondary = 1e-3 * tight

    return primary + secondary
# EVOLVE-BLOCK-END
