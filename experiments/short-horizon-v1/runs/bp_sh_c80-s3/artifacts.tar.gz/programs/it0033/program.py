# EVOLVE-BLOCK-START
"""Harmonic-style class packing with best-fit tiebreak.

Idea: Harmonic-style online bin packing partitions bins by their remaining
capacity into geometrically-sized classes and always tries to complete the
lowest (fullest) class first.  This yields bins that are filled to consistent
fullness levels, which reduces the number of stranded slivers compared with
plain best-fit.  Within a class we fall back to best-fit (tightest residual).
"""
import numpy as np

# Class boundaries (remaining capacity -> class index).
# Lower index = fuller bin = used first.
_BOUNDS = np.array([10, 20, 40, 60, 80, 101], dtype=np.int64)


def priority(item, bins):
    """Return a priority for every bin; highest priority bin wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    # Smaller residual => fuller bin => higher priority.
    # Encode class first (strongly), then best-fit residual as tiebreak.
    # np.searchsorted maps residual to the class it belongs to.
    cls = np.searchsorted(_BOUNDS, bins, side="left")

    # Primary: prefer lower class index (fuller bins).
    # Secondary: prefer smaller residual (best-fit).
    return -cls.astype(np.float64) * 1000.0 - (bins - item).astype(np.float64)
# EVOLVE-BLOCK-END
