# EVOLVE-BLOCK-START
"""Best fit with a learned size-histogram tie-break on near-ties."""
import numpy as np

_SIZE = 101
_hist = np.zeros(_SIZE, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _total
    # Update the empirical item-size histogram with a mild decay for adaptivity.
    _hist[item] += 1.0
    _total += 1.0
    if _total > 1e6:
        _hist *= 0.5
        _total *= 0.5

    # Normalized frequency (a prior over which residual sizes are reusable).
    freq = _hist / max(_total, 1.0)

    residual = bins - item
    # Primary: best fit (smallest residual => largest score).
    score = -residual.astype(np.float64)

    # Tie-break: bonus if the residual equals a commonly-seen item size
    # (likely to be filled later), and mild bonus if the pre-placement
    # remaining capacity is itself a frequent item size.
    resid_bonus = freq[np.clip(residual, 0, _SIZE - 1)]
    cap_bonus = freq[np.clip(bins, 0, _SIZE - 1)]

    # Keep primary ordering dominant: only break near-ties.
    return score + 0.4 * resid_bonus + 0.1 * cap_bonus
# EVOLVE-BLOCK-END
