# EVOLVE-BLOCK-START
"""Best fit with a small residual-aware tie-break to avoid useless slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Base: best fit -> prefer the smallest residual (fullest bin that fits).
    score = -residual.astype(np.float64)

    # Anti-sliver nudge: a residual of 1..3 is nearly unusable, so slightly demote
    # placements that leave such a tiny leftover, preferring a slightly larger residual
    # among near-tight fits.  Kept small so it only affects close calls.
    penalty = np.where((residual >= 1) & (residual <= 3), (4 - residual) * 0.05, 0.0)

    return score - penalty
# EVOLVE-BLOCK-END
