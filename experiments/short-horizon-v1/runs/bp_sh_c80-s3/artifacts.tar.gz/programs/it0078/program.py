# EVOLVE-BLOCK-START
"""Best-fit with a small preference for reusing already-open (partially filled) bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer tightly fitting bins (smaller residual -> higher score).
    score = -residual.astype(np.float64)
    # Small bonus for reusing already-open (partially filled) bins.
    used = bins < 100
    score += used * 0.5
    return score
# EVOLVE-BLOCK-END

