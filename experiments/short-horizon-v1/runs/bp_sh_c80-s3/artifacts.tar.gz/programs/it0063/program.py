# EVOLVE-BLOCK-START
"""Best fit with a learned tie-break that favors residuals matching common past items."""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.int64), "n": 0}


def priority(item, bins):
    """Best-fit primary; ties broken toward residuals that a frequent past item size would fill."""
    counts = _state["counts"]
    counts[item] += 1
    _state["n"] += 1

    resid = bins - item  # resulting residual capacity (>=0 because item fits)

    # Tiny secondary score: how often a past item size equals this residual.
    # counts[r] is large for common item sizes; residual r being a common item size
    # means the gap is likely to be exactly filled soon.
    match = counts[resid]  # shape (len(bins),), residual 0..100 valid index

    # Primary: tighter fit (smaller residual) is better -> larger score.
    # Scale residual by a large factor so match only breaks near-ties.
    return -resid.astype(np.float64) * 1000.0 + match
# EVOLVE-BLOCK-END

