# EVOLVE-BLOCK-START
"""Distribution-aware best fit: prefer bins whose post-placement residual
matches a size that actually tends to appear in the item stream.

Classic best fit minimizes the residual, but a small residual that no future
item can fill wastes the bin just as much as a large one.  We keep an online
histogram of the item sizes we have seen, turn it into an empirical
probability mass over residuals 1..100, and among fitting bins prefer the one
that, after placing the item, leaves a residual that is likely to be filled
exactly by a later item.  This packs complementary items together and raises
the achieved packing efficiency over pure best fit.
"""
import numpy as np

# Empirical counts of item sizes seen in this stream (index 0 unused).
_COUNTS = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of all fitting bins.
    """
    global _TOTAL
    # Update the running histogram with the arriving item (it is a real item).
    _COUNTS[item] += 1.0
    _TOTAL += 1.0

    # Empirical probability that a future item has size exactly r (Laplace-ish
    # smoothing so unseen sizes are not impossible forever).
    probs = (_COUNTS + 0.5) / (_TOTAL + 50.5)

    # Post-placement residual for every candidate bin.
    residual = bins - item  # >= 0, since only fitting bins are shown

    # Score = probability that some future item can exactly fill this residual.
    # A zero residual is a perfectly packed bin -> full reward.
    # Otherwise reward the likelihood that residual itself is an item size.
    score = np.where(residual == 0, 1.0, probs[np.clip(residual, 0, 100)])

    # Secondary tie-breaker: among equally likely residuals, prefer the
    # fuller bin (classic best-fit tightness) to avoid scatter.
    score = score * 1e6 - residual
    return score
# EVOLVE-BLOCK-END
