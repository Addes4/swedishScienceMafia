# EVOLVE-BLOCK-START
"""Best-fit with a learned residual-utility tie-break.

Put the item in the tightest bin (classic best-fit).  This is already very strong.
We add only a *tiny* secondary term that rewards placements whose leftover space is
likely to be filled later, estimated online from the histogram of item sizes already
seen.  The secondary term is deliberately small so it can only break near-ties and
cannot override genuine best-fit decisions.
"""
import numpy as np

# --- module state (per stream, reset by harness on import/reload per stream) ---
_hist = np.zeros(101, dtype=np.float64)   # counts of observed item sizes 1..100
_total = 1.0                              # total items observed (>=1 to avoid /0)


def priority(item, bins):
    global _total
    res = bins - item                      # remaining capacity after placing (>=0)

    # ---------------------------------------------------------------
    # Primary term: best-fit -> prefer the smallest residual.
    # ---------------------------------------------------------------
    score = -res.astype(np.float64)

    # ---------------------------------------------------------------
    # Secondary term (small): does the residual look useful?
    # We estimate the probability that *some* future item exactly
    # equals this residual (from the observed histogram), and also
    # mildly reward residuals that are "common" sizes overall.
    # ---------------------------------------------------------------
    # normalize histogram lazily
    p = _hist / _total
    # utility of residual r: probability mass at exactly r plus a small
    # reward for r being a multiple of a frequent size (helps pairing).
    util = p[np.clip(res, 0, 100)]

    # small weight so best-fit still dominates
    score += 0.05 * util

    # ---------------------------------------------------------------
    # Update history with the just-seen item *after* scoring.
    # ---------------------------------------------------------------
    _hist[item] += 1.0
    _total += 1.0
    # gentle decay to stay adaptive to the distribution
    if _total > 5000:
        _hist *= 0.5
        _total *= 0.5

    return score
# EVOLVE-BLOCK-END

