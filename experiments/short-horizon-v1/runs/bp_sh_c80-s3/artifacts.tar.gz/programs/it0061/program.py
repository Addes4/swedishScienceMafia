# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with residual-class awareness.

Items arrive one at a time. We keep a lightweight online estimate of the
item-size distribution and use it to nudge best-fit away from placements
that leave a residual capacity unlikely to be reused by future items.
"""
import numpy as np

_state = {
    "count": 0,
    "size_sum": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    # --- update online item statistics ---
    _state["count"] += 1
    _state["size_sum"] += item
    _state["hist"][item] += 1.0
    n = _state["count"]
    mean = _state["size_sum"] / n

    # Typical item size (used to judge whether a residual gap is useful).
    # Blend the running mean with a mild prior to stabilize early on.
    typical = (mean * n + 40.0 * 4.0) / (n + 4.0)
    typical = max(1.0, min(100.0, typical))

    residual = bins - item  # remaining capacity after placing here

    # Base: best-fit -> strongly prefer small residual.
    score = -residual.astype(np.float64)

    # Exact fill gets a clear bonus.
    score += np.where(residual == 0, 1e6, 0.0)

    # Penalize residuals that are small but nonzero and smaller than the
    # typical item, since they are hard to reuse (leftover waste).
    small = (residual > 0) & (residual < typical)
    score -= np.where(small, (typical - residual), 0.0) * 0.5

    # Mildly favor residuals that are close to a multiple of the typical
    # item size (good packing potential).
    frac = residual - typical * np.floor(residual / typical + 1e-9)
    good_mult = residual % max(1.0, round(typical)) == 0
    score += np.where(good_mult, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
