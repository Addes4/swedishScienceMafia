# EVOLVE-BLOCK-START
"""Best fit with a penalty for producing unusable residual gaps."""
import numpy as np


def priority(item, bins):
    """Rank bins: tightest fit, but penalize residuals too small to ever be refilled."""
    # tightness: prefer smaller resulting residual (closer fit). best fit is -(bins-item).
    residual = bins - item

    # A residual r is "wasted" if r>0 but no future item can plausibly fill it,
    # i.e. r is smaller than the smallest item size seen so far. Since we cannot
    # know that exactly, use a soft penalty for tiny positive residuals.
    # penalty grows as residual -> 1..small, and is zero once residual is comfortable.
    # Use a fixed small threshold: residuals below ~20 are hard to fill exactly but
    # leaving exactly 0 is best. So just push toward exact fit:
    penalty = (residual > 0).astype(np.float64) * np.minimum(residual, 20.0)

    # base: tight best fit
    score = -residual.astype(np.float64) - 0.0 * penalty

    # Slight nudge toward exact residual==0 (perfect fill) already handled by -residual,
    # but reward exact fills strongly.
    score += 5.0 * (residual == 0).astype(np.float64)
    return score
# EVOLVE-BLOCK-END
