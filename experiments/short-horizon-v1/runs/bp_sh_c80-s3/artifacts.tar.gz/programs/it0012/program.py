# EVOLVE-BLOCK-START
"""Best fit with an online size-histogram tie-break among near-optimal bins."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "count": 0}


def priority(item, bins):
    """Score bins by tightest fit, breaking near-ties using observed item sizes.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update the running histogram of observed items.
    _state["hist"][item] += 1.0
    _state["count"] += 1

    residual = bins.astype(np.float64) - float(item)

    # Primary: best fit (smallest residual gets the highest score).
    base = -residual

    hist = _state["hist"]
    count = _state["count"]

    if count >= 20:
        # Probability a random future item fits exactly into a residual of size r.
        cum = np.cumsum(hist) / count
        # For each bin, estimate the chance its residual will be reused well:
        # weight residuals near common remaining item sizes a bit more.
        r_int = np.clip(residual.astype(np.int64), 0, 100)
        reuse = hist[r_int] / count  # freq of items exactly matching residual
        # Tiny bonus so near-perfect fits that are also common sizes are favored,
        # without overriding the primary best-fit ordering.
        return base + 0.001 * reuse
    return base
# EVOLVE-BLOCK-END
