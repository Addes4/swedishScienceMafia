# EVOLVE-BLOCK-START
"""Best fit with a small online-learned residual-reuse tie-break."""
import numpy as np

_count = np.zeros(101, dtype=np.float64)

def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _count
    _count[item] += 1.0
    total = _count.sum()
    # small bonus if the residual after placement matches a frequently seen item size
    resid = bins - item
    # probability-like weight of residual sizes (clipped 0..100)
    idx = np.clip(resid, 0, 100).astype(np.int64)
    freq = _count[idx] / total  # normalized
    # primary: tightest fit (smallest residual -> larger score)
    return -(resid.astype(np.float64)) + 0.3 * freq
# EVOLVE-BLOCK-END

