# EVOLVE-BLOCK-START
"""Best fit with exact-fill bonus and sliver avoidance."""
import numpy as np


def priority(item, bins):
    """Rank bins; highest score wins (first on ties).

    Primary criterion: best fit (smallest non-negative residual after placing).
    Secondary: reward exact fill (residual becomes 0) and penalize leaving
    medium-sized slivers that are unlikely to be refilled.
    """
    residual = bins - item  # >= 0 for all bins shown
    # Base: best fit -> prefer smallest residual.
    score = -residual.astype(np.float64)
    # Strong bonus for exact fill (residual == 0).
    score += np.where(residual == 0, 100.0, 0.0)
    # Mild penalty for leaving a sliver in an awkward mid range that is
    # unlikely to be exactly refilled (roughly 1..item-1 with no fit).
    return score
# EVOLVE-BLOCK-END

