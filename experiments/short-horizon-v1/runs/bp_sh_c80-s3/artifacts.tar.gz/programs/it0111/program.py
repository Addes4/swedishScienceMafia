# EVOLVE-BLOCK-START
"""Best fit with a small bias against leaving tiny unusable residuals."""
import numpy as np

_state = {"sizes": None, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item
    # Base: prefer the tightest fit.
    score = -residual.astype(np.float64)

    # Small nudge: among bins whose residual is very small (< ~5), prefer the slightly
    # larger residual so we don't strand 1..4 unit gaps that rarely receive an item.
    tiny = (residual >= 0) & (residual < 5)
    score += tiny * residual * 0.5

    return score
# EVOLVE-BLOCK-END

