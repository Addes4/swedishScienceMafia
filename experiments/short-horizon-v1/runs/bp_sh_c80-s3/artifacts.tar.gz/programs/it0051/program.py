# EVOLVE-BLOCK-START
"""Best fit with a bonus for leaving a frequently-occurring residual.

The item distribution is fixed and Weibull-shaped.  A leftover residual r in a bin is
useful only if future items of size ~r can fill it.  So instead of blindly minimizing
the residual (pure best fit), give a small bonus to a bin whose post-placement residual
matches a common item size seen so far in the stream.  This nudges the packer toward
creating residuals that are likely to be exactly filled later, without sacrificing the
strong tight-fit behaviour of best fit for large items.
"""
import numpy as np

_STATE = {"counts": None, "total": 0}


def _get_counts():
    c = _STATE["counts"]
    if c is None:
        c = np.zeros(101, dtype=np.float64)
        _STATE["counts"] = c
    return c


def priority(item, bins):
    """Rank bins by (tightness, expected fillability of the residual)."""
    counts = _get_counts()

    # update online histogram (used only as a prior for "common" sizes)
    if 1 <= item <= 100:
        counts[item] += 1.0
    _STATE["total"] += 1

    resid = bins - item  # remaining capacity after placing the item, >= 0

    # base score: best fit -> most negative for smallest residual (most negative = highest priority)
    score = -resid.astype(np.float64)

    # fraction of past items that exactly equal the resulting residual
    total = _STATE["total"]
    freq = counts / total

    # bonus for residuals that are common item sizes (likely to be exactly filled later)
    # (weight kept small so best-fit dominates; this only breaks near-ties)
    bonus = np.zeros(resid.shape, dtype=np.float64)
    valid = (resid >= 1) & (resid <= 100)
    if valid.any():
        idx = resid[valid].astype(np.int64)
        bonus[valid] = freq[idx]

    # also mildly reward residuals that are themselves near the mean item size,
    # since those bins stay "open" for a typical next item
    mean_size = (np.arange(101) * counts).sum() / total if total > 0 else 40.0
    near_mean = -np.abs(resid - mean_size) / 100.0

    return score + 0.5 * bonus + 0.05 * near_mean
# EVOLVE-BLOCK-END
