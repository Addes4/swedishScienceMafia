# EVOLVE-BLOCK-START
"""Best-fit with a small learned dead-zone avoidance tie-break."""
import numpy as np

_state = {"count": None, "hist": None}


def _ensure(item):
    if _state["hist"] is None:
        _state["hist"] = np.zeros(101, dtype=np.float64)
        _state["count"] = 0


def priority(item, bins):
    _ensure(item)
    hist = _state["hist"]
    hist[item] += 1.0
    _state["count"] += 1
    n = _state["count"]

    # Estimate probability that a random future item fits in a residual r.
    # P(size <= r) from the online histogram.
    if n >= 10:
        cdf = np.cumsum(hist) / n
    else:
        cdf = None

    residual = bins - item  # >= 0 since bins only contains fitting bins
    # Base: best fit -> highest score for smallest residual.
    score = -residual.astype(np.float64)

    if cdf is not None:
        # Residual r will be a candidate leftover; probability that some future
        # item exactly/small enough fills it. Small residuals in a dead zone
        # (below the smallest commonly seen item) are nearly wasted. Give a
        # tiny bonus to residuals that are more likely usable, but keep the
        # dominant best-fit ordering.
        r = residual.astype(np.int64)
        prob = cdf[np.clip(r, 0, 100)]
        score += 0.05 * prob

    return score
# EVOLVE-BLOCK-END
