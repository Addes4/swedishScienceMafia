# EVOLVE-BLOCK-START
"""Best fit with tie-break toward the emptier bin.

Primary rule: pick the bin minimizing the resulting residual (classic best fit).
Tie-break (equal residual, i.e. equal remaining capacity): prefer the bin with the
larger current remaining capacity, i.e. the more-loaded... no, the emptier bin.
This keeps slightly more headroom in partially filled bins so that medium/large
arrivals have more fitting options later.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Highest score wins. Rank by smallest residual first (best fit),
    # then by largest original remaining capacity (emptier bin) as a tie-break.
    return -residual * 1000.0 + bins
# EVOLVE-BLOCK-END

