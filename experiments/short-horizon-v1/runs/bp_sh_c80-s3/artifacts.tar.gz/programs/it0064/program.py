# EVOLVE-BLOCK-START
"""Best-fit with a histogram-based secondary key on the resulting residual.

Primary: tightest fit (smallest residual after placement).
Secondary (only for bins whose residual is within a small tolerance of the best):
prefer the residual that matches a frequently observed item size, so that
same-sized items tend to reuse the same bin and fragmentation shrinks.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Score every fitting bin; the item goes to the highest score (first on ties)."""
    global _TOTAL
    res = bins - item  # residual capacity after placing the item

    # Best (smallest) residual among the shown bins.
    best = res.min()

    # Secondary key from the running item-size histogram: residuals that equal a
    # common item size are attractive because a future item can fill them exactly.
    # Normalize by total so the bonus is on a comparable scale to residual gaps.
    if _TOTAL > 0:
        freq = _HIST / _TOTAL
    else:
        freq = _HIST

    # Look up frequency of the residual size (0..100); out-of-range -> 0.
    idx = np.clip(res, 0, 100)
    fit_bonus = freq[idx]

    # Within a tolerance of the tightest fit, let the frequency bonus decide.
    tol = 1.0
    near = (res <= best + tol)

    # Base: prefer tighter fits. Blend in a bounded bonus for common residuals.
    score = -res.astype(np.float64) + 2.0 * fit_bonus * near

    # Record the item AFTER scoring (no future information used).
    _HIST[item] += 1.0
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END
