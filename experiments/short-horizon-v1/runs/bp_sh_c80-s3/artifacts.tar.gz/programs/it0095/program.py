# EVOLVE-BLOCK-START
"""Best fit with a shallow residual-quality tie-break.

Primary key: tightest residual (best fit). Among bins within a small tolerance
of the best residual, prefer the one whose resulting residual is the largest
but still small enough to remain a plausible full-fit target for a typical
Weibull item. This avoids creating unusable tiny gaps in nearly full bins.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Tolerance: treat near-best residuals as ties. Use a few units so that
    # slight differences don't override the residual-quality preference.
    tol = 3.0
    # Quality term: reward residuals in a "useful" band (roughly 10..50),
    # penalize very small nonzero residuals (fragmentation) and huge ones.
    r = residual.astype(np.float64)
    # penalty grows for tiny positive residuals (unusable gaps)
    tiny = np.where((r > 0) & (r < 10), (10.0 - r), 0.0)
    # reward moderate residuals up to ~50, saturating
    useful = np.clip(np.minimum(r, 50.0), 0.0, 50.0)
    # primary: negative residual (tightest fit), scaled large
    score = -1e6 * r + 1.0 * useful - 2.0 * tiny
    return score
# EVOLVE-BLOCK-END
