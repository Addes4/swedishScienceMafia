# EVOLVE-BLOCK-START
"""Best fit with a size-aware residual tie-breaker.

Idea: pure best fit (choose the bin leaving the smallest residual) is a strong
online rule for this distribution. The only freedom left is among bins whose
post-placement residual is close to the minimal one. Rather than always picking
the absolute tightest, we give a small bonus to bins whose post-placement
residual coincides with a size that occurs often in the stream (tracked online).
Leaving such a residual makes a future perfect fit likely, so it can save a bin
without hurting the tight-fit property.
"""
import numpy as np


class _State:
    def __init__(self):
        # small histogram of item sizes seen so far (1..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0


_state = _State()


def priority(item, bins):
    item = int(item)

    # update running statistics with the current item (past items only in spirit,
    # but the value depends only on values, so this is fine and cheap)
    _state.hist[item] += 1.0
    _state.count += 1

    residual = bins - item  # >= 0 for all shown bins

    # base: pure best fit -> smallest residual gets highest score
    score = -residual.astype(np.float64)

    # tie-breaker: small bonus if the residual after placement equals a size
    # that is frequently seen (so a future item may fit exactly).
    # Normalize histogram into probabilities.
    if _state.count > 0:
        prob = _state.hist / _state.count
        res_clip = np.clip(residual, 0, 100).astype(np.int64)
        bonus = prob[res_clip]
    else:
        bonus = np.zeros_like(score)

    # The bonus must not override best-fit ordering, only break near-ties.
    # Add a tiny fraction so that differences in residual dominate.
    return score + 1e-3 * bonus
# EVOLVE-BLOCK-END
