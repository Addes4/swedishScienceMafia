# EVOLVE-BLOCK-START
"""Adaptive best fit: aim for post-placement residual near a size-dependent target."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    r = bins - item  # post-placement residual
    # Target residual: for large items we want tight (0); for small items we
    # prefer leaving a moderate residual so bins stay useful for medium items.
    target = max(0.0, (50.0 - item) * 0.5)
    score = -np.abs(r - target)
    return score
# EVOLVE-BLOCK-END

