# EVOLVE-BLOCK-START
"""Best fit with an online residual-complement bonus.

We keep best-fit as the dominant term (tightest fit), but add a small bonus when the
residual left after placement is close to a common item size seen so far. That helps
create residuals that future items can fill, reducing unusable slack.
"""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update online histogram of item sizes.
    hist = _state["hist"]
    _state["n"] += 1.0
    hist[item] += 1.0

    resid = bins - item  # post-placement residual (>= 0)

    # Best fit: prefer smallest residual -> negative residual as base score.
    base = -resid.astype(np.float64)

    # Fraction of past items whose size is <= residual (helps fill residuals).
    n = _state["n"]
    cum = np.cumsum(hist) / n  # cum[s] = P(size <= s)

    # Bonus if residual matches a common item size region: use prob mass near residual.
    # prob that a future item fits exactly-ish in this residual.
    fit_prob = cum[np.clip(resid, 0, 100).astype(np.int64)]

    # Weight: keep base dominant; small additive nudge toward fillable residuals.
    return base + 2.0 * fit_prob
# EVOLVE-BLOCK-END

