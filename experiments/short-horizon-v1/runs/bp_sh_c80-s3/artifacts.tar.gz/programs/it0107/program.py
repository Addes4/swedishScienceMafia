# EVOLVE-BLOCK-START
"""Best fit with a small, bounded consolidation tie-break.

Primary rule: tightest fit (smallest residual after placement).
Secondary rule (only among near-tightest fits): prefer residuals that are
"usable" (>= 1) over residuals of 0, so a perfect fill is taken when available,
otherwise leave the largest reusable gap among the tight band.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Primary: tightest fit -> larger score for smaller residual.
    score = -residual.astype(np.float64)
    # Very small secondary nudge: a small residual that is at least 1 (usable)
    # is slightly preferred over a 0 residual of a different bin, and among
    # equal tightness we prefer the larger (more usable) gap.
    # residual == 0 is best primary already; only nudge non-zero residuals.
    score += 1e-3 * (residual > 0)
    return score
# EVOLVE-BLOCK-END

