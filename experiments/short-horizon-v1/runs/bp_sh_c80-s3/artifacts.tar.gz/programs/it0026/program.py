# EVOLVE-BLOCK-START
"""Best fit with sliver-avoiding tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: prefer tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Slivers that the (mean ~40) distribution rarely fills exactly are bad.
    # Give a small penalty to residuals in the awkward mid range so that,
    # among near-tied best fits, we avoid parking items next to unfillable gaps.
    bad = (residual >= 5) & (residual <= 19)
    score[bad] -= 0.5

    # Very small residuals (0,1,2,3,4) are nearly sealed off and good; tiny bonus.
    tiny = (residual >= 0) & (residual <= 4)
    score[tiny] += 0.25

    return score
# EVOLVE-BLOCK-END

