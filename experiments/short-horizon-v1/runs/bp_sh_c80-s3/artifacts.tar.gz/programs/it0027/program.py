# EVOLVE-BLOCK-START
"""Best fit with exact-fill bonus and sliver avoidance.

Pure best fit (tightest residual) is near optimal but leaves awkward
slivers.  Two cheap fixes that are robust across distributions:

* strongly prefer a bin that the item fills exactly (residual == item),
  which removes a bin for free;
* among the remaining bins, use best fit but nudge away from leaving a
  residual smaller than the smallest item seen so far (an unfillable
  sliver), since such a residual wastes the bin.

An online running minimum item size is kept, so the rule adapts to the
observed distribution without seeing the future.
"""
import numpy as np


_min_item = 101  # running minimum item size observed


def priority(item, bins):
    global _min_item
    if item < _min_item:
        _min_item = item

    residual = bins - item              # remaining capacity after placing
    score = -residual.astype(np.float64)  # best fit: tighter is better

    # Reward exact fills so the bin is closed completely.
    score += 1000.0 * (residual == 0)

    # Penalize leaving a sliver smaller than the smallest item seen so far
    # (cannot be reused by any future item, so it is pure waste).
    sliver = (residual > 0) & (residual < _min_item)
    score -= 100.0 * sliver

    return score
# EVOLVE-BLOCK-END

