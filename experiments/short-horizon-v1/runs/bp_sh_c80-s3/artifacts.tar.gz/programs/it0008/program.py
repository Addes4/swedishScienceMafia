# EVOLVE-BLOCK-START
"""Half-mean-residual fit: prefer leaving a residual near half the mean item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer residuals around 20 (half the mean item size ~40), so bins stay
    # fillable by one or two typical items rather than becoming slivers or
    # staying overly empty.
    return -np.abs(residual - 20)
# EVOLVE-BLOCK-END

