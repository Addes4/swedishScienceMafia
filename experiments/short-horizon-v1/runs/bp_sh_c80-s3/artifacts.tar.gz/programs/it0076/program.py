# EVOLVE-BLOCK-START
"""Best fit with a dead-zone guard: never leave a residual smaller than the
smallest item seen so far (a safe estimate of the minimum future item size)."""
import numpy as np

_state = {"min_item": 101}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item
    m = _state["min_item"]

    residual = bins - item  # >= 0 since bins only contains fitting bins

    safe = residual >= m
    if safe.any():
        return -np.where(safe, residual, residual + 1000000)
    return -residual
# EVOLVE-BLOCK-END

