# EVOLVE-BLOCK-START
"""Best fit for large items; mean-residual target for small items."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    residual = bins - item  # post-placement remaining capacity

    if item >= mean:
        # Large items: pure best fit (tightest residual).
        return -residual.astype(np.float64)

    # Small items: prefer a residual near the mean so leftover bins remain
    # fillable by typical future items; tie-break toward tightest fit.
    target = mean
    score = -np.abs(residual - target).astype(np.float64)
    score = score - 0.001 * residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
