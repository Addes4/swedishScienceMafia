# EVOLVE-BLOCK-START
"""Best fit with a residual-aware tie-break.

Primary rule: put the item in the bin with the smallest resulting residual
(best fit). Ties (equal residual) are broken toward bins that leave a larger
remaining capacity *before* placement, i.e. we avoid piling tiny residuals onto
already-nearly-full bins. This spreads near-full bins and keeps room for the
medium/large Weibull items, which pure first-bin tie-breaking does not.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary key: tightest fit (largest score for smallest residual).
    # Secondary key: among equal residuals, prefer bins with larger pre-item capacity
    # (i.e. keep small residuals out of already-tight bins).
    return -(residual * 1024.0) + bins
# EVOLVE-BLOCK-END
