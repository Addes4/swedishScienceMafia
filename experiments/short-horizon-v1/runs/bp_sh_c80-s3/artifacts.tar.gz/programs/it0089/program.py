# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a size-dependent slack tolerance.

Items come from a Weibull-shaped distribution (mean ~40). Large items are hard
to place later, so we pack them as tightly as possible (pure best fit). Small
items are flexible, so we treat placements whose leftover residual is within a
tolerance of the tightest leftover as equally good, and among those prefer the
largest residual, keeping big gaps available for future large items.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for the bins we are shown
    r = residual.astype(np.float64)

    # Tolerance grows as items get smaller: small items may accept looser fits.
    # tol = 0 for big items (strict best fit), larger for small items.
    # item ~ 40 typical; scale so tol is small relative to item for mid sizes.
    tol = 0.25 * (60.0 - item)
    if tol < 0.0:
        tol = 0.0

    rmin = r.min()
    near = r <= (rmin + tol)          # placements considered equally tight
    if near.all():
        # No discrimination by tightness: prefer the largest residual
        # (open/fill bins that keep big gaps available).
        return r
    # Among the near-optimal-tightness bins, prefer the largest residual;
    # push non-near bins far below.
    score = np.where(near, r, rmin - 1e6)
    return score
# EVOLVE-BLOCK-END
