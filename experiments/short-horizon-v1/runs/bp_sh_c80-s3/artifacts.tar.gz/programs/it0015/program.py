# EVOLVE-BLOCK-START
"""Best fit with a small tolerance band that avoids hopeless slivers.

Pure best fit packs tightly, but it can repeatedly stuff items into bins leaving
tiny residual slivers that no future item (mean ~40) can ever fill.  We keep
best-fit as the dominant criterion, but when two bins' post-placement residuals
are within a small tolerance, we prefer the *larger* residual, since that bin is
slightly more likely to still be refillable.
"""
import numpy as np


def priority(item, bins):
    """Score each bin; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of fitting bins, in bin order.
    """
    residual = bins - item  # >= 0 because bins only contains fitting bins
    # Primary key: smaller residual is better.  Secondary key: within a small
    # tolerance band of the best residual, prefer larger residuals.
    band = 2.0
    # Negate residual so larger score = tighter fit; add a tiny reward for
    # residual being larger inside the band without overriding the primary order.
    return -residual + band * (residual / (residual + band + 1.0))
# EVOLVE-BLOCK-END
