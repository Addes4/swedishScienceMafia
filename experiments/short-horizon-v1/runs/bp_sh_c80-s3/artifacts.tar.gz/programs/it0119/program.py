# EVOLVE-BLOCK-START
"""Hybrid: prefer perfect fits and residuals that can host a same-size item later."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    # Primary: prefer a perfect fit (residual 0).
    perfect = (residual == 0)
    # Secondary: prefer residuals that can accommodate another item of this size,
    # i.e. residual >= item, to keep "reusable" holes; among those prefer tightest.
    reusable = (residual >= item)
    # Score: huge bonus for perfect fill; then prefer reusable holes (tightest first);
    # otherwise best fit (tightest residual).
    score = -residual.astype(np.float64)
    score += 1e6 * perfect.astype(np.float64)
    score += 1e3 * reusable.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
