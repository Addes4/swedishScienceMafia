# EVOLVE-BLOCK-START
"""Online bin choice: best fit, with a tie-break that exploits existing residuals.

Pure best fit (tightest residual) is a strong default for the Weibull item stream.
We keep it as the primary signal, but among bins that are *near* best fit
(residual within a small window of the minimum), we break the tie by preferring
a bin whose pre-placement remaining capacity equals a value that appears as an
available capacity of another bin. Placing the item there can "complete" a
residual (residual -> 0) or align two bins, which keeps the packing compact
without overriding genuine best-fit decisions. The window is tiny, so ties are
the only thing affected and behavior stays close to the strong baseline.
"""
import numpy as np

_WINDOW = 1  # only residuals within this many units of the best are reconsidered


def priority(item, bins):
    """Rank bins: primary = best fit (min residual); tie-break = completion bonus."""
    residual = bins - item
    best = residual.min()
    # Base score: smaller residual => higher score.
    score = -residual.astype(np.float64)

    # Indices within the tiny near-tie window.
    near = residual <= (best + _WINDOW)

    if near.any() and near.sum() < len(bins):
        # Available capacities of all bins (pre-placement), as a set for lookup.
        available = np.unique(bins)
        # A bin is attractive if its pre-placement capacity is a "clean" value:
        # either it exactly equals the item (residual 0), or the resulting
        # residual matches some other bin's current remaining capacity, meaning
        # a future item could exactly fill one of them.
        resid_vals = residual[near]
        avail_set = set(available.tolist())
        bonus = np.zeros(len(bins), dtype=np.float64)
        # Prefer residuals that are themselves available capacities elsewhere
        # (complementary sizes) or zero.
        for idx in np.nonzero(near)[0]:
            r = int(residual[idx])
            if r == 0:
                bonus[idx] = 0.5
            elif r in avail_set:
                bonus[idx] = 0.25
        score = score + bonus

    return score
# EVOLVE-BLOCK-END

