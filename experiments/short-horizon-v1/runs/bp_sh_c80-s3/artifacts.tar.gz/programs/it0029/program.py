# EVOLVE-BLOCK-START
"""Best fit with a smooth sliver-avoidance secondary tie-break.

Primary: tightest fit (smallest residual after placing).
Secondary: when the post-placement residual r is tiny (a likely-unfillable
sliver), gently prefer a slightly larger residual so the leftover can still
host small items; this is a smooth term, not a hard bonus.
"""
import numpy as np


def priority(item, bins):
    # smaller post-placement residual => higher priority
    post = bins - item
    # primary best-fit score: prefer smallest post (larger negative post)
    score = -post.astype(np.float64)
    # Smooth penalty for leaving a very small sliver (r in [1, 8]) since such
    # leftovers are rarely reusable; push those toward slightly larger r.
    r = post.astype(np.float64)
    sliver = (r >= 1) & (r <= 8)
    # penalty magnitude 0.5: smaller than a full unit gap so exact-fit (r==0)
    # still wins, but among near-ties the less-slivery bin is preferred.
    score = score - 0.5 * sliver
    return score
# EVOLVE-BLOCK-END
