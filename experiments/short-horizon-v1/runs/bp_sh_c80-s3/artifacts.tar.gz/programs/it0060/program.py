# EVOLVE-BLOCK-START
"""Modified best fit: tightest residual, with a mild tie-break toward earlier bins
so that identical items tend to cluster into the same bin rather than scattering."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since only fitting bins are shown
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    # Base: prefer the tightest fit (smallest residual).
    score = -residual.astype(np.float64)
    # Mild tie-break toward earlier bins: within a small tolerance of the best residual,
    # the earliest bin wins, encouraging equal-size items to cluster.
    tol = 1.0
    best = score.max()
    near = score >= (best - tol)
    # Add a tiny index penalty so among near-ties the lowest index is preferred.
    return score - 1e-6 * idx * near
# EVOLVE-BLOCK-END
