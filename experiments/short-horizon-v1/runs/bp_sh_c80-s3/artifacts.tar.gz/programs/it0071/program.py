# EVOLVE-BLOCK-START
"""Baseline best-fit plus a tiny dead-zone penalty on unusable residuals."""
import numpy as np


def priority(item, bins):
    """Highest score goes to the bin the item fits most tightly.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    residual = bins - item
    # Best fit: prefer smallest residual (largest -residual).
    score = -residual.astype(np.float64)
    # Tiny penalty for residuals that are too small to ever be reusable.
    # Only 1..2 leftover space is essentially dead weight; mildly steer away.
    dead = (residual > 0) & (residual <= 2)
    score -= 0.01 * dead
    return score
# EVOLVE-BLOCK-END
