# EVOLVE-BLOCK-START
"""Best fit with online statistics to avoid stranding tiny unusable gaps."""
import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "min": 101,
}


def priority(item, bins):
    """Rank bins: prefer tight fits, but avoid creating unusably small residuals for small items."""
    s = _state
    s["n"] += 1
    s["sum"] += item
    if item < s["min"]:
        s["min"] = item

    residual = bins - item  # post-placement remaining capacity

    # Best fit: minimize residual. Ties/close calls adjusted to avoid tiny stranded gaps
    # when placing a relatively small item, by nudging residual that is below the smallest
    # observed item size slightly downward in score (so it's less preferred) unless it is exact.
    minsz = s["min"] if s["min"] <= 100 else 1

    base = -residual.astype(np.float64)

    # Penalty for residuals in (0, minsz): those gaps likely can never be filled.
    # Only meaningful when the resulting residual is nonzero but too small.
    gap = (residual > 0) & (residual < minsz)
    base = base - gap * 0.5

    return base
# EVOLVE-BLOCK-END
