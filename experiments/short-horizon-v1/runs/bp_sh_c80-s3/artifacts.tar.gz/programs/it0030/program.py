# EVOLVE-BLOCK-START
"""Best fit with a tiny large-item sliver-avoidance nudging."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Primary: best fit (prefer small residual >= 0).
    # Secondary, only for relatively large items, avoid landing on medium slivers:
    # residual in [1, item-1] is hard to refill later, so penalize those mildly
    # while leaving exact fills (residual 0) and large residuals unaffected.
    score = -residual.astype(np.float64)
    if item >= 50:
        sliver = (residual > 0) & (residual < item)
        score -= 0.5 * sliver
    return score
# EVOLVE-BLOCK-END
