# EVOLVE-BLOCK-START
"""Best fit with a stateful "residual matches a seen item size" bonus."""
import numpy as np


class State:
    def __init__(self):
        # Counts of item sizes seen so far (1..100).
        self.counts = np.zeros(101, dtype=np.int64)
        self.total = 0


_state = State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = _state
    s.counts[item] += 1
    s.total += 1

    residual = bins - item  # capacity left after placing the item here

    # Base: best fit tightness (smaller residual = better, so negative).
    score = -(residual).astype(np.float64)

    # Small bonus when the residual exactly matches a size we've already seen
    # (a future item could fill it perfectly).  Strongly favor residual 0.
    seen_bonus = np.where(residual >= 0, s.counts[np.clip(residual, 0, 100)], 0)
    seen_bonus = seen_bonus / (s.total + 1.0)
    score += 0.25 * seen_bonus

    # Extra bonus for a perfect fill.
    score += 0.5 * (residual == 0)

    return score
# EVOLVE-BLOCK-END
