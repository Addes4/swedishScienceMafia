# EVOLVE-BLOCK-START
"""Best fit with online exact-fill scoring of the resulting residual."""
import numpy as np

# Online histogram of past item sizes (integer 1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0

# candidates residual -> accumulated "exact fill potential"
def priority(item, bins):
    global _COUNT
    # update online histogram with current item (only helps future decisions)
    _HIST[item] += 1.0
    _COUNT += 1.0

    residual = bins - item  # remaining capacity after placing item here

    # base: prefer tightest fit -> smaller residual better -> higher score
    base = -residual.astype(np.float64)

    # estimate probability that a future item exactly fills a residual r:
    # weight sizes near r. Use histogram mass in a small window around r.
    # Avoid heavy compute: only adjust near-ties via a mild bonus.
    if _COUNT >= 20.0:
        # build a normalized probability-ish vector over residuals present
        prob = _HIST / _COUNT  # P(next size == s)
        # For each bin, compute chance the residual r gets exactly filled:
        # sum over s of P(s) but we only need s==r; use a neighborhood to be robust
        # Compute via lookup for unique residuals.
        uniq = np.unique(residual)
        bonus_map = {}
        for r in uniq:
            if r <= 0:
                bonus_map[r] = 0.0
                continue
            lo = max(1, int(r) - 3)
            hi = min(100, int(r) + 3)
            bonus_map[r] = float(prob[lo:hi + 1].sum())
        bonus = np.array([bonus_map[r] for r in residual], dtype=np.float64)
        # small weight so it only breaks near-ties, keeping best-fit dominant
        return base + 2.0 * bonus
    return base
# EVOLVE-BLOCK-END
