# EVOLVE-BLOCK-START
"""Best-fit augmented with online histogram-based residual matching."""
import numpy as np


# module-level state, reset per stream via fresh import in the harness
_HIST = np.zeros(101, dtype=np.float64)   # counts of observed item sizes
_TOTAL = 0.0


def priority(item, bins):
    global _TOTAL
    # update histogram with the arriving item
    _HIST[item] += 1.0
    _TOTAL += 1.0

    residual = bins - item            # post-placement residual (>= 0 guaranteed)
    # best fit: minimize residual
    best = residual.min()

    # near-tie window: allow residuals up to best + small slack
    slack = max(1, item // 8)
    tie_mask = residual <= best + slack

    if tie_mask.sum() <= 1 or _TOTAL < 10:
        return -(residual.astype(np.float64))

    # score tied bins by how likely their residual can be exactly refilled
    # using a smoothed histogram (avoid zero counts).
    h = _HIST + 0.5
    h = h / h.sum()
    # fillability of a residual value r: probability some observed size == r,
    # weighted a bit by the chance a size <= r could pair down further.
    scores = residual.astype(np.float64)

    # for tied bins, compute histogram weight at their residual
    res_tied = residual[tie_mask]
    fill_weight = h[np.clip(res_tied, 0, 100)]

    out = np.full(residual.shape, -1e9, dtype=np.float64)
    # default: best fit
    out[:] = -(residual.astype(np.float64))
    # within the tie set, rank by fill weight first, then tightness
    # encode: primary = fill weight, secondary = -residual (tightness)
    combined = fill_weight * 1000.0 - res_tied.astype(np.float64)
    out[tie_mask] = combined
    return out
# EVOLVE-BLOCK-END

