# EVOLVE-BLOCK-START
"""Best fit with a small learned-residual tie-breaker."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary key: best fit (most negative residual after placement = tightest).
    residual = bins - item

    # Track how often each residual size has been observed as an item size so far.
    # We keep it simple and bounded: a small count table over 1..100.
    global _counts
    try:
        counts = _counts
    except NameError:
        counts = np.zeros(101, dtype=np.float64)
        _counts = counts

    # Frequency bonus: prefer residuals that are common item sizes (likely fillable later).
    # Normalize to [0, ~0.5] so it only breaks near-ties in best-fit.
    freq = counts[bins]  # bins values are within 1..100 here (residuals are >=0)
    total = counts.sum()
    if total > 0:
        bonus = 0.499 * (freq / total)
    else:
        bonus = np.zeros_like(freq)

    score = -residual.astype(np.float64) + bonus

    # Update the learned distribution with the current item.
    counts[item] += 1.0

    return score
# EVOLVE-BLOCK-END
