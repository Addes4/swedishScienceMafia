# EVOLVE-BLOCK-START
"""Best fit with a residual-reusability bias based on observed item sizes."""
import numpy as np

_state = {"counts": None, "n": 0}


def priority(item, bins):
    if _state["counts"] is None:
        _state["counts"] = np.zeros(101, dtype=np.float64)
    counts = _state["counts"]
    _state["n"] += 1
    n = _state["n"]

    # residual after placing item in each bin
    resid = bins - item

    # primary: tightest fit (smallest residual)
    score = -resid.astype(np.float64)

    # bias toward residuals that are reusable: estimate probability a future
    # item has size <= r for the residual r, using observed item-size history.
    if n > 20:
        total = counts.sum()
        if total > 0:
            cdf = np.cumsum(counts) / total  # cdf[s] = P(item <= s)
            # value of leaving residual r: chance some future item fits well
            r = resid
            valid = r >= 0
            reuse = np.zeros_like(resid, dtype=np.float64)
            rr = np.clip(r, 0, 100)
            reuse[valid] = cdf[rr[valid]]
            # small bonus, doesn't dominate tightest-fit
            score = score + 0.5 * reuse

    # record item
    counts[item] += 1.0
    return score
# EVOLVE-BLOCK-END
