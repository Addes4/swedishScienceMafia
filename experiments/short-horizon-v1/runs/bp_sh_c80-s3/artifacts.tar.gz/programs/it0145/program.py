# EVOLVE-BLOCK-START
"""Adaptive best-fit: prefer leaving a residual near the running mean item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Simple target: small residual for tight fit, but scale gently so we
    # don't ignore tighter fits. Pure best-fit corresponds to minimizing residual;
    # here we slightly favor residuals consistent with the item size itself,
    # which tends to reduce fragmentation for the Weibull-shaped distribution.
    target = float(item) * 0.5

    # Score: primary tightness (smaller residual better), secondary closeness to target.
    return -(residual - target) ** 2 * 1e-3 - residual
# EVOLVE-BLOCK-END
