# EVOLVE-BLOCK-START
"""Best fit with a stateful reservation for large future items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    state = priority.state
    if state is None:
        state = {"max_seen": item}
        priority.state = state
    if item > state["max_seen"]:
        state["max_seen"] = item

    max_seen = state["max_seen"]
    residual = bins - item  # post-placement remaining capacity

    # Base: prefer tightest fit (smallest residual).
    score = -(residual.astype(np.float64))

    # Small penalty when the placement would leave a residual smaller than the
    # largest item seen so far, i.e. the bin becomes unable to accept a big item
    # later. This softly redirects away from "closing off" bins too tightly.
    penalty = np.where(residual < max_seen, 0.5, 0.0)
    score -= penalty

    return score


priority.state = None
# EVOLVE-BLOCK-END

