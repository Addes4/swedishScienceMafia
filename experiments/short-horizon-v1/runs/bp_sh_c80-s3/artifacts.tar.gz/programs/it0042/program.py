# EVOLVE-BLOCK-START
"""Best fit with a small tie tolerance favoring emptier bins among near-equal residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placement (>= 0 for fit bins)
    # Primary: best fit = smallest residual after placement.
    # Secondary tie-break within a small tolerance: prefer bin with larger current
    # remaining capacity (less packed), to keep tight bins tight for future fits.
    tol = 1.0
    min_res = residual.min()
    near = residual <= min_res + tol
    # score: high for near-best-fit, then higher current capacity wins ties
    return -(residual.astype(np.float64)) + 0.001 * bins * near
# EVOLVE-BLOCK-END

