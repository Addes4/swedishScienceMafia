# EVOLVE-BLOCK-START
"""Best fit with a clean-close bonus: prefer tight fits, strongly prefer leaving zero waste."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: tightest fit (smallest resulting residual gets highest score).
    score = -residual.astype(np.float64)
    # Bonus for perfectly filling a bin (residual 0), and mild bonus for very small residuals.
    score += (residual == 0) * 1000.0
    score += (residual <= 4) * 1.5
    return score
# EVOLVE-BLOCK-END
