# EVOLVE-BLOCK-START
"""Modified best fit: prefer tight fits, but avoid stranding tiny unusable gaps."""
import numpy as np


class _State:
    def __init__(self):
        # online estimate of the smallest "common" item size (running min-ish)
        self.min_seen = 101

    def update(self, item):
        if item < self.min_seen:
            self.min_seen = item


_STATE = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    _STATE.update(item)
    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item  # >= 0 guaranteed

    # Cutoff: residuals strictly below this are "tiny unusable gaps" we try to avoid.
    # Use the smallest item seen so far, but at least 1 (avoid forbidding exact fits).
    gap = max(1, _STATE.min_seen - 1)

    # Base priority: best fit (smaller residual -> higher score).
    score = -residual.astype(np.float64) * 1000.0

    # Penalize tiny residuals that would strand an unusable gap
    # (unless residual == 0, which is a perfect fill and always good).
    tiny = (residual > 0) & (residual < gap)
    score[tiny] -= 1.0

    return score
# EVOLVE-BLOCK-END
