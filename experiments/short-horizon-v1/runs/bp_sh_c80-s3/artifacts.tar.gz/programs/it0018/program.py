# EVOLVE-BLOCK-START
"""Almost best fit: take tightest fit unless it creates a likely-unusable sliver."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Tiebreak-free base: strongly prefer the smallest residual (best fit).
    base = -residual.astype(np.float64)

    # Dislike leaving a residual in a hard-to-refill gap (small slivers).
    # Items are Weibull-shaped with mean ~40, so tiny residuals (say 5..19)
    # are seldom exactly matched later; nudge those bins down.
    gap_penalty = ((residual >= 5) & (residual <= 19)).astype(np.float64)

    return base - 0.3 * gap_penalty
# EVOLVE-BLOCK-END

