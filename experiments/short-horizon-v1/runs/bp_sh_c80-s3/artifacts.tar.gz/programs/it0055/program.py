# EVOLVE-BLOCK-START
"""Best fit with residual-consolidating tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: prefer tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Secondary: among equal residuals, prefer residuals that already occur
    # elsewhere in the bin array (consolidates fragment sizes), and avoid
    # stranding tiny unusable gaps.
    b = np.asarray(bins)
    counts = np.bincount(b, minlength=101)
    # bonus for merging with an existing residual; small bonus so it only
    # breaks near-ties in the primary best-fit ordering.
    resid_ok = (residual >= 0) & (residual <= 100)
    existing = np.zeros(len(bins))
    existing[resid_ok] = counts[residual[resid_ok]]
    # penalize creating a brand-new very small gap
    tiny = (residual > 0) & (residual < 5) & (existing == 0)
    score = score + 1e-3 * existing - 2e-3 * tiny
    return score
# EVOLVE-BLOCK-END
