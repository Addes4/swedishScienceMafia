# EVOLVE-BLOCK-START
"""Best fit with a light complement-match bonus based on online item statistics."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "counts": None}


def priority(item, bins):
    """Rank bins: tightly fit (best-fit) with a bonus for residuals fillable by typical items."""
    # Update online size statistics
    _state["n"] += 1
    _state["sum"] += item
    counts = _state["counts"]
    if counts is None:
        counts = np.zeros(101, dtype=np.float64)
        _state["counts"] = counts
    counts[item] += 1.0

    residual = bins - item  # post-placement remaining capacity, >= 0

    # Pure best-fit base score: smaller residual is better
    base = -residual.astype(np.float64)

    # Complement bonus: reward residuals that equal a common past item size,
    # since such a residual can likely be filled exactly by a future item.
    n = _state["n"]
    if n >= 30:
        freq = counts / counts.sum()
        # probability mass at the residual value (capped to [0,100])
        r_int = np.clip(residual, 0, 100).astype(np.int64)
        comp = freq[r_int]
        # small weight so it only breaks near-ties in the best-fit
        return base + 2.0 * comp

    return base
# EVOLVE-BLOCK-END
