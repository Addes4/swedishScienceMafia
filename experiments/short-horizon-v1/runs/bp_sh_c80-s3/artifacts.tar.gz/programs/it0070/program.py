# EVOLVE-BLOCK-START
"""Best fit with a dead-zone penalty driven by the online item-size histogram.

Pure best-fit keeps residuals as tight as possible, but on a Weibull(mean~40)
stream it frequently creates tiny leftover gaps that no future item can fill,
wasting capacity.  We keep a histogram of item sizes seen so far and:
  * strongly reward residual == 0,
  * penalize residuals smaller than the smallest item likely to appear,
  * otherwise still prefer the tightest fit.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    global _COUNT
    # update online histogram (shifted estimate of future item sizes)
    _HIST[item] += 1.0
    _COUNT += 1.0

    residual = bins - item

    # smallest size we still expect to see reasonably often
    # use an empirical quantile of seen items as a "usability floor"
    if _COUNT >= 8:
        cdf = np.cumsum(_HIST) / _COUNT
        # size below which cumulative mass reaches ~5%
        lo = int(np.searchsorted(cdf, 0.05)) + 1
        if lo < 1:
            lo = 1
    else:
        lo = 1

    # primary term: prefer tightest residual (best fit)
    score = -residual.astype(np.float64)

    # exact-fill bonus (perfect packing)
    score += np.where(residual == 0, 1e3, 0.0)

    # dead-zone penalty: residual in [1, lo) is likely unusable space,
    # so nudge away from it (do not override tight-fit ordering by much).
    dead = (residual > 0) & (residual < lo)
    score = score - np.where(dead, 0.5, 0.0)

    # tiny preference for residuals that match common past item sizes
    if _COUNT >= 8:
        common = _HIST / _COUNT
        match = np.where((residual > 0) & (residual <= 100), common[np.clip(residual, 0, 100)], 0.0)
        score = score + 0.25 * match

    return score
# EVOLVE-BLOCK-END
