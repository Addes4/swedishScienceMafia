# EVOLVE-BLOCK-START
"""Best fit with a dead-zone penalty on tiny unusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: best fit (smallest residual).  Small bonus for exactly filling the bin.
    score = -(residual.astype(np.float64))

    # Penalize residuals in the "dead zone" 1..9: too little room for common items,
    # yet the bin is no longer empty, so it fragments the packing.
    dead = (residual >= 1) & (residual <= 9)
    score -= dead.astype(np.float64) * 2.0

    # Slight preference for exactly-full bins (residual 0) beyond best fit.
    score += (residual == 0).astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
