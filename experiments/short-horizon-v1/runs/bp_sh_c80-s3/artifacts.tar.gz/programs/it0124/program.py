# EVOLVE-BLOCK-START
"""Harmonic-inspired bin choice blended with best fit."""
import numpy as np


def priority(item, bins):
    """Score each bin: favor residual near an ideal leftover for this item's class.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of bins the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Ideal leftover: for a given item size, the "sweet spot" residual is often
    # either near 0 (tight pack) or near 100 (open a nearly fresh bin for large items).
    # Blend so medium items prefer tight packing, large items prefer fresh-ish bins.
    # Best-fit score: prefer minimal residual (tight packing).
    bf = -residual.astype(np.float64)

    # Harmonic preference: reward residuals that are a multiple of the item size
    # (allows future exact-fill packing) scaled modestly.
    ideal = item
    harm = -np.abs((residual + item * 0.5) % item - item * 0.5).astype(np.float64)

    return bf + 0.01 * harm
# EVOLVE-BLOCK-END
