# EVOLVE-BLOCK-START
"""Best fit with a small preference against opening fresh bins on ties."""
import numpy as np


def priority(item, bins):
    """Priority: best fit first; on ties prefer already-used bins over empty ones.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual).
    score = -residual.astype(np.float64)
    # Secondary, tiny: prefer bins that are not completely empty (residual < 100).
    score += np.where(bins < 100, 1e-6, 0.0)
    return score
# EVOLVE-BLOCK-END

