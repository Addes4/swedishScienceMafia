# EVOLVE-BLOCK-START
"""Stateful hybrid: best-fit anchored by empirical residual fillability.

Pure best fit is near optimal here, but it can leave awkward slivers.  We keep
best fit as the dominant term and use a small online estimate of the item-size
distribution to nudge near-ties toward residuals that the stream has shown to be
reliably fillable by a single future item.

np is available; we keep the required signature and return scores per bin.
"""
import numpy as np

# state kept across calls within a stream
_hist = np.zeros(101, dtype=np.float64)   # counts of observed item sizes
_seen = 0.0
_res_fill = np.zeros(101, dtype=np.float64)  # smoothed fillability of residual r


def priority(item, bins):
    global _hist, _seen, _res_fill

    # update the empirical item-size histogram lazily (exclude unused bins)
    # we count the arriving item itself
    _hist[item] += 1.0
    _seen += 1.0

    # --- estimate how likely a residual r is to be exactly fillable ---
    # p(r) ~ sum_k P(item == r) + small weight for pairwise exact fill of r.
    # we only need a cheap, monotone-ish signal; use a short local window.
    h = _hist
    tot = max(_seen, 1.0)
    # smoothed single-item exact-fill probability
    single = np.zeros(101, dtype=np.float64)
    single[1:101] = h[1:101] / tot
    # light smoothing so unseen but plausible sizes still count
    k = np.array([0.2, 0.5, 1.0, 0.5, 0.2])
    sm = np.convolve(single, k / k.sum(), mode='same')
    _res_fill = sm  # keep for potential reuse

    # --- main choice: best fit, with near-tie nudge by residual fillability ---
    # residual that best fit would produce is (bins - item); best fit minimizes it.
    resid = bins - item
    # fillability of the resulting residual, scaled by item size
    fill = sm[resid]

    # primary term: prefer tight fits (negative residual small in magnitude)
    # we want a score where highest wins, so use -(resid) strongly plus fill bonus.
    tight = -(resid.astype(np.float64))

    # bonus only meaningful when two options have close residuals; scale bonus
    # so it can never overturn a genuinely better (smaller) fit by much.
    bonus = fill * (item / 100.0)

    return tight + bonus
# EVOLVE-BLOCK-END
