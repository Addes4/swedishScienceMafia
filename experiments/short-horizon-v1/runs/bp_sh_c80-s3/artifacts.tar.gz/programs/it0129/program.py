# EVOLVE-BLOCK-START
"""Best fit with stateful residual-matching bonus.

Plain best fit (put item in the tightest fitting bin) is a strong baseline.
The residual left after a placement is wasted whenever no future item exactly
matches it.  Online, we can only guess which residuals are "likely": sizes are
integers drawn from a fixed distribution, so small residuals (near 0) are the
most valuable to hit exactly.  We therefore still prefer tight fits, but add a
bonus when the resulting residual is small enough that a future item could
plausibly land on it exactly, nudging the packer toward residuals near 0 rather
than near 100.
"""
import numpy as np

# state kept across calls in a stream
_state = {"n": 0}


def priority(item, bins):
    """Rank bins: best fit, with a bonus for producing a small exact-fill residual."""
    _state["n"] += 1

    remainder = bins - item  # residual after putting the item here

    # base: best fit (tightest remaining capacity => smallest residual)
    score = -remainder.astype(np.float64)

    # bonus: reward residuals near 0 (exact fills are never wasted)
    # small residual -> extra reward; scale modestly so tightness still dominates
    score += 2.0 * np.exp(-remainder / 8.0)

    return score
# EVOLVE-BLOCK-END

