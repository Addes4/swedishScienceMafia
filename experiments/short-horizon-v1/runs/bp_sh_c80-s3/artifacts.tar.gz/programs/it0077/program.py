# EVOLVE-BLOCK-START
"""Best-fit with a light, statistically-grounded tie-break on residuals."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Core is best-fit (tightest residual). As a soft tie-break among near-ties, we slightly
    prefer residuals that are NOT hot spots for future perfect fits, estimated from an
    online histogram of item sizes observed so far.
    """
    hist = _state["hist"]
    n = _state["n"]

    residual = bins - item  # >= 0 for all shown bins

    # Update the online size distribution AFTER computing (so current item isn't used to
    # decide its own placement via a peek at itself, though it's fine either way).
    hist[item] += 1.0
    _state["n"] = n + 1.0

    # Best-fit primary score: higher for smaller residual.
    score = -residual.astype(np.float64)

    # Soft tie-break: penalize residuals that are very likely to be filled exactly by a
    # frequent upcoming item size (reserving them is valuable). Use a small weight so it
    # only matters among near-equal residuals.
    if n >= 20.0:
        # probability mass of future items equal to each possible residual value
        probs = hist / _state["n"]
        r = residual.astype(np.int64)
        # probability that some future item exactly equals r (per-item density)
        hot = probs[np.clip(r, 0, 100)]
        # Penalize tight residuals that are also hot spots, but weakly.
        score = score - 0.0005 * hot

    return score
# EVOLVE-BLOCK-END

