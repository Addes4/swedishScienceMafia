# EVOLVE-BLOCK-START
"""Stateful rule: best-fit tightness biased by an adaptive residual target.

Pure best-fit tends to create bins with tiny awkward residuals.  We track the
running mean of item sizes seen so far and, among the fitting bins, slightly
prefer the bin whose residual after placement lands near a multiple of that
mean (i.e. a residual that future items can actually fill).  The tightness
term dominates so behaviour stays close to best-fit, which is empirically the
strongest simple online rule here.
"""
import numpy as np


class _State:
    total = 0.0
    count = 0


_state = _State()


def priority(item, bins):
    """Return a priority per bin; item goes to the highest (first on ties)."""
    _state.total += item
    _state.count += 1
    avg = _state.total / _state.count

    residual = bins - item            # leftover after placing the item here
    # Tightness: prefer small residual (best-fit).  Negative of residual.
    tight = -residual.astype(np.float64)

    # Anti-fragmentation: reward residuals that are near a usable multiple of
    # the running average item size (so future items can fill the gap).  The
    # nearer residual is to k*avg, the smaller the remainder penalty.
    if avg >= 1.0:
        rem = np.mod(residual, avg)
        gap = np.minimum(rem, avg - rem)          # distance to nearest multiple
        frag = -gap                                # prefer small gap
    else:
        frag = np.zeros_like(tight)

    # Tightness is primary; fragmentation only nudges near-ties.
    return tight + 0.15 * frag
# EVOLVE-BLOCK-END
