# EVOLVE-BLOCK-START
"""Best fit with an online residual-refillability tie-break.

We keep best-fit (smallest residual) as the dominant term, but among bins whose
residual is within a small window of the best residual we prefer the one whose
resulting residual has historically been the one most often exactly filled by a
later item. This keeps the near-optimal best-fit behavior while nudging ties
toward residuals that experience shows are reusable.
"""
import numpy as np


class _State:
    def __init__(self):
        # fill_score[r] = decayed count of times a bin ended with residual r
        # and was later exactly filled (residual reached 0 right after a placement).
        self.fill_score = np.zeros(101, dtype=np.float64)
        self.prev_residual = None  # residual of last chosen bin before this item

    def observe(self, item, residual_before):
        # If a bin that had residual_before is now exactly filled by `item`,
        # credit residual_before.
        if residual_before is not None and residual_before == item:
            self.fill_score[residual_before] += 1.0


_state = _State()


def priority(item, bins):
    bins = np.asarray(bins)
    resid = bins - item  # post-placement residual for each bin

    st = _state
    # Credit the previous choice if this item exactly fills the bin we used.
    st.observe(item, st.prev_residual)

    # Dominant term: prefer smallest non-negative residual (best fit).
    # Small non-negative residuals rank best.
    best = resid.min()

    # Tie-break window: residuals within a tiny slack of best.
    slack = 1
    within = resid <= best + slack

    # Refillability bonus for the resulting residual, scaled very small so it
    # can only ever change the ordering among near-tied candidates.
    bonus = st.fill_score[np.clip(resid, 0, 100)]

    score = -resid.astype(np.float64) + 1e-3 * bonus * within

    # Record which residual we are about to leave, to credit on the next call.
    # We don't know the harness's final pick order for ties, so use argmax.
    choice = int(np.argmax(score))
    st.prev_residual = int(resid[choice])

    return score
# EVOLVE-BLOCK-END
