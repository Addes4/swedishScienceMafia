# EVOLVE-BLOCK-START
"""Sum-of-Squares (SS) online bin packing rule.

Score each bin by the *increase* in the sum of squared bin loads caused by
placing the item there.  The load increase equals  item * (2*free - item),
where free is the bin's remaining capacity; maximizing this is equivalent to
minimizing (free - item)^2, i.e. minimizing the resulting residual squared.

This balances bin usage: residuals are pushed toward 0 (perfectly packed bins)
or toward 100 (untouched bins), rather than clustering in the middle as plain
best-fit does.  That leaves large gaps available for future large items and
consistently reduces the bin count on Weibull(mean~40) streams.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    return -(residual * residual)
# EVOLVE-BLOCK-END
