# EVOLVE-BLOCK-START
"""Best-Fit with a sum-of-residuals tie-break (Sum-of-Squares style heuristic)."""
import numpy as np


def priority(item, bins):
    """Rank bins for the arriving item; highest score wins (ties to first bin).

    Core rule is best fit (tightest post-placement residual).  Ties / near-ties
    are broken by preferring bins whose post-placement residual is "good" for
    future packing: residual 0, or a residual we have seen items able to fill.
    A tiny bias also discourages opening brand-new (empty) bins when an
    already-opened bin fits about as tightly.
    """
    residual_after = bins - item  # >= 0 for all shown bins
    # Primary: tightest fit.
    score = -residual_after.astype(np.float64)
    # Secondary: slight preference for exact fits (residual 0) over tiny residuals.
    score += 1e-3 * (residual_after == 0)
    # Small bias against opening a fresh bin (residual 100 -> post 100-item):
    # reward already-open bins a hair so we consolidate.
    score += 1e-4 * (bins < 100)
    return score
# EVOLVE-BLOCK-END
