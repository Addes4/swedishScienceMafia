# EVOLVE-BLOCK-START
"""Best fit with a dead-zone penalty on unusable small residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest score.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: prefer tightest fit (largest post-placement fill).
    score = -(residual.astype(np.float64))
    # Strong bonus for a perfect fit.
    score += 2.0 * (residual == 0)
    # Penalize leaving a residual too small to be reusable by a typical small item.
    dead = (residual > 0) & (residual < min(item, 10))
    score -= 1.5 * dead
    return score
# EVOLVE-BLOCK-END
