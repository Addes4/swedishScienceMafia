# EVOLVE-BLOCK-START
"""Residual-class bin choice: protect against unusable tiny leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0, since only fitting bins are shown

    # Class scoring: exact fits are best; otherwise prefer residuals that are at
    # least as large as the current item (still reusable) and as tight as possible.
    exact = (residual == 0)
    reusable = residual >= item

    score = -residual.astype(np.float64)
    # Big bonus for exact fits.
    score = score + exact * 1000.0
    # Bonus for leaving a reusable gap, scaled to break ties sensibly.
    score = score + reusable * 200.0

    return score
# EVOLVE-BLOCK-END
