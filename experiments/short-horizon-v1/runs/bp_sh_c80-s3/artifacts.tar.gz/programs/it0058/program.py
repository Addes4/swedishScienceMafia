# EVOLVE-BLOCK-START
"""Best fit with an online exact-fill bonus for promising residual gaps."""
import numpy as np


class _State:
    def __init__(self):
        # running counts of item sizes seen so far (sizes 1..100)
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def observe(self, item):
        self.counts[item] += 1.0
        self.total += 1.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties).

    Best fit on the residual after placement, plus a small bonus when the
    resulting residual capacity is a size that has been common among past
    items (so the bin is likely to be exactly filled later).
    """
    _state.observe(item)

    residual = bins - item  # >= 0 for all shown bins

    # Estimate the frequency of each residual size among past items.
    if _state.total > 0:
        freq = _state.counts / _state.total
    else:
        freq = _state.counts

    # Base: best fit (tighter residual is better).
    score = -residual.astype(np.float64)

    # Bonus for residuals that correspond to likely future item sizes.
    # Use the residual itself as the index into the frequency table.
    bonus = np.zeros_like(score)
    mask = (residual >= 1) & (residual <= 100)
    if mask.any():
        bonus[mask] = freq[residual[mask].astype(np.int64)]

    # Scale the bonus to be a mild tie-breaker, not a dominant term.
    score = score + 0.5 * bonus

    return score
# EVOLVE-BLOCK-END

