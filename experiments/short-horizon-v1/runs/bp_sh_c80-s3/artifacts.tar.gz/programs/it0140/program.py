# EVOLVE-BLOCK-START
"""Harmonic-style bin choice: prefer the smallest-fit bin within the item's size class.

Items ~ Weibull(mean 40), capacity 100. Pure best-fit can leave awkward fragments.
A harmonic approach groups items by size class and fills bins mostly with items of
one class, reducing fragmentation. We approximate that here with a piecewise-linear
priority that emphasizes tightness (best-fit) but adds a mild preference to keep
bins grouped by their current fill level, biasing toward bins whose residual is
close to the item size (perfect-ish fit) and penalizing near-empty large bins
slightly so they stay open for large future items.
"""
import numpy as np


def priority(item, bins):
    # Base: tightest fit (best-fit) -> prefer smallest remaining capacity >= item.
    tight = -(bins - item)

    # Residual after placement.
    resid = bins - item

    # Harmonic-ish grouping: encourage residuals that are "round" relative to
    # the item size, i.e. multiples of the item size (bins filled by equal items),
    # which consolidates similar items and reduces leftover waste.
    # bonus when resid is a small near-multiple of item (little leftover).
    if item > 0:
        mult = resid / item
        # closeness to nearest integer multiple
        frac = np.abs(mult - np.round(mult))
        mult_bonus = 2.0 * (1.0 - frac)  # peaks when resid == k*item
    else:
        mult_bonus = np.zeros_like(resid, dtype=float)

    # Mild penalty for using plenty of large empty bins only when a good tight
    # fit (=small resid) exists elsewhere; scale by how empty the bin is.
    empty_pen = -(bins == 100).astype(float) * 0.5

    return tight + 0.05 * mult_bonus + empty_pen
# EVOLVE-BLOCK-END
