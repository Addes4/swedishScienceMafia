# EVOLVE-BLOCK-START
"""Best-fit variant that favors closing bins: prefer residual below a running mean item size."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.total = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # update running mean of item sizes (only for items that actually appear)
    _state.n += 1
    _state.total += item
    mean = _state.total / _state.n

    residual = bins - item  # remaining capacity after placing the item

    # base: best fit (smallest residual first)
    score = residual.astype(np.float64)

    # bonus for closing a bin: residual well below the mean item size means this bin
    # will likely be hard to fill further, so finishing it off is good.
    # We negate because lower score = preferred in best fit; highest score wins.
    # Convert: higher score should mean better. Prefer small residual, so use negative.
    score = -score

    # extra bonus when the post-placement residual is small (bin nearly closed)
    close_bonus = np.where(residual < mean, mean - residual, 0.0)
    score = score + 0.5 * close_bonus

    return score
# EVOLVE-BLOCK-END
