# EVOLVE-BLOCK-START
"""Best fit with a gap-matching bonus keyed to the online estimate of the item mean."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Online estimate of the running mean item size (used to guess useful residual gaps).
    s = _state
    s["n"] += 1
    s["sum"] += item
    mean = s["sum"] / s["n"]

    residual = bins - item  # remaining capacity after placing the item

    # Primary: prefer the tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Secondary: nudge toward bins whose residual is close to the running mean item size,
    # i.e. the leftover gap is likely to be filled by a future average-sized item.
    score -= 0.02 * np.abs(residual - mean)

    return score
# EVOLVE-BLOCK-END
