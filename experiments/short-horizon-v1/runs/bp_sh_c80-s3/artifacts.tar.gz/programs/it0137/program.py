# EVOLVE-BLOCK-START
"""Best fit with a small penalty for leaving a bin nearly-but-not-completely full.

Standard best-fit tends to create many bins with tiny leftovers that are hard to fill
exactly.  Here we keep best-fit's tightness ordering but lightly penalize placements that
result in a very small (but nonzero) residual, so those near-full bins are less attractive
and get consolidated better in the long run.  The effect is a mild "close the bin" bias.
"""
import numpy as np

# Residuals at or below this are considered "nearly full"; we mildly avoid creating them
# because they are hard to fill exactly later.
_SMALL = 3


def priority(item, bins):
    """Return a priority for every bin; highest goes first (ties to lowest index)."""
    residual = bins - item
    # Base: best fit -> most negative residual (i.e. tightest) gets the highest score.
    score = -residual.astype(np.float64)
    # Penalize creating a tiny leftover that is unlikely to be filled exactly later.
    tiny = (residual > 0) & (residual <= _SMALL)
    score = score - 0.5 * tiny
    return score
# EVOLVE-BLOCK-END
