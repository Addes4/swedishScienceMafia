# EVOLVE-BLOCK-START
"""Online best-fit augmented with a learned "residual matching" score.

The idea: pure best-fit minimizes the immediate residual, but a residual that can be
exactly filled by a future item is more valuable than a slightly smaller residual that
will always be wasted.  We keep a histogram of item sizes seen so far in the stream and
score each candidate residual r by the observed frequency of items of size exactly r
(future items are i.i.d. from the same distribution).  Ties fall back to best-fit.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Restrict to bins the item actually fits in.
    residual = bins - item  # >= 0 for fitting bins (harness guarantees fits)

    # --- learned item-size histogram (state across calls within a stream) ---
    hist = getattr(priority, "hist", None)
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        priority.hist = hist
        priority.total = 0.0

    total = priority.total
    # Score: prefer residual r that tends to be exactly fillable by a future item.
    # Use Laplace-smoothed frequency estimate, but weight by 1 (relative, not absolute),
    # and add a tiny decreasing term in r so best-fit breaks matching ties.
    match_score = (hist[residual] + 0.0) / (total + 1.0) if total > 0 else np.zeros_like(residual, dtype=np.float64)

    # Primary: matching score (higher better).  Secondary: best-fit (smaller residual better).
    # Combine additively with a small weight on -residual so best-fit dominates when
    # matching scores are equal (matching scores are quantized by integer residual).
    score = match_score * 1000.0 - residual * 1e-3

    # Record this item AFTER scoring (it is not a "future" item relative to itself).
    hist[item] += 1.0
    priority.total = total + 1.0

    return score
# EVOLVE-BLOCK-END
