# EVOLVE-BLOCK-START
"""Almost-Worst-Fit: prefer residuals in [item/2, item]; otherwise best fit.

This is the classic online bin-packing improvement over Best Fit.  Placing an
arriving item into a bin whose remaining capacity lies in [item/2, item] (the
*tight-enough* window) keeps residuals in a range that future items of similar
size can still fill, avoiding stranding useful mid-size gaps.  When no bin has
a residual in that window we fall back to best fit (smallest sufficient
residual), which handles the tail cases well.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (all sufficient), bin order.
    """
    residual = bins - item  # remaining capacity after placing item in that bin

    # Best fit score: smaller residual => higher score.
    score = -(residual.astype(np.float64))

    # Bonus for residuals in the "tight-enough" window [ceil(item/2), item-1].
    # Residuals in this window are hard to fill exactly but not useless slivers;
    # nudging the choice here lets future items pack them well.
    lo = (item + 1) // 2
    hi = item - 1
    in_window = (residual >= lo) & (residual <= hi)
    score[in_window] += 1000.0

    return score
# EVOLVE-BLOCK-END
