# EVOLVE-BLOCK-START
"""Best fit with residual-reuse tie-breaking."""
import numpy as np

# common item sizes cluster near the mean (~40); favor residuals that can be
# filled exactly by a future item of a typical size.
_TARGET = 40.0


def priority(item, bins):
    """Rank bins: tightest residual first, then residual-reuse and load bonuses."""
    residual = bins - item  # remaining capacity after placing the item

    # primary signal: smaller residual is better (best fit)
    score = -residual.astype(np.float64)

    # bonus if the resulting residual exactly matches a typical future item,
    # so that gap can be filled perfectly later
    close = np.abs(residual - _TARGET)
    score += 2.0 / (close + 1.0)

    # bonus for reducing overall fragmentation: prefer older/fuller bins
    # (smaller current remaining capacity), keeps empty bins free
    score += 0.5 / (bins.astype(np.float64) + 1.0)

    return score
# EVOLVE-BLOCK-END
