# EVOLVE-BLOCK-START
"""Best fit with a conservative reusability tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Conservative tie-break: among near-equal fits, prefer a bin that stays
    # reusable (residual >= item) so we avoid creating unusable slivers.
    reusable = (residual >= item).astype(np.float64)
    return -residual + 1e-3 * reusable
# EVOLVE-BLOCK-END
