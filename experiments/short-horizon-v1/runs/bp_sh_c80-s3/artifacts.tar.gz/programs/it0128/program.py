# EVOLVE-BLOCK-START
"""Hybrid best-fit with a reserved empty-bin bonus for large items."""
import numpy as np


def priority(item, bins):
    fit = bins - item                # residual after placing (>=0 since item fits)
    # Best-fit tightness: prefer the smallest resulting residual.
    score = -fit.astype(np.float64)
    # Bonus for placing a large item into a fresh empty bin (capacity 100),
    # reserving empties helps absorb the large tail of the Weibull.
    is_empty = bins == 100
    if item >= 60:
        score += is_empty * (item - 60) * 1.0
    return score
# EVOLVE-BLOCK-END
