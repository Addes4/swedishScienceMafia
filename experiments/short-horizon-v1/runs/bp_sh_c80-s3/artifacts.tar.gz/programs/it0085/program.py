# EVOLVE-BLOCK-START
"""Best fit with a learned residual-value correction.

Pure best fit minimizes the leftover residual. Online, some residuals are more
"reusable" than others: if a residual happens to equal a size that frequently
appears in the stream, that leftover gap is likely to be filled later, so it is
less wasteful than its raw magnitude suggests. We keep a running histogram of
arriving item sizes and subtract a small bonus proportional to the probability
that the leftover residual will be matched by a future item.
"""
import numpy as np

# Running histogram of item sizes over the whole stream (index 1..100).
_size_count = np.zeros(101, dtype=np.float64)
_total = 0.0


def _freq(sizes):
    """Probability that an integer size appears as an item (array over sizes)."""
    if _total < 50.0:
        return np.zeros_like(sizes, dtype=np.float64)
    f = _size_count[sizes] / _total
    return f


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    global _total
    # update histogram with the incoming item
    _size_count[item] += 1.0
    _total += 1.0

    bins = np.asarray(bins)
    residual = bins - item  # leftover capacity after placing the item (>= 0)

    # Base: best fit -> tighter residual is better.
    score = -residual.astype(np.float64)

    # Bonus: residuals that equal a commonly seen item size are valuable.
    # Cap the index used for lookup so it stays in range.
    idx = np.clip(residual, 0, 100).astype(np.int64)
    freq = _freq(idx)
    score = score + 2.0 * freq

    return score
# EVOLVE-BLOCK-END
