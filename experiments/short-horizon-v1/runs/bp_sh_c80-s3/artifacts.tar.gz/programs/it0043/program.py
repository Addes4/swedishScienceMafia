# EVOLVE-BLOCK-START
"""Best fit with a residual-targeting bonus based on a running mean item size.

The idea: pure best fit tends to leave many tiny unusable slivers. By mildly
biasing toward bins whose post-placement residual is close to the running mean
item size (so it can be filled exactly by a typical future item), while keeping
the strong best-fit preference for tight fits, we reduce wasted sliver capacity.
State is a single running sum/count so it is O(1) and distribution-agnostic.
"""
import numpy as np

# module-level state (reset not required; harness starts fresh per stream)
_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    # update running mean of item sizes
    _state["sum"] += item
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]

    # post-placement residual for each bin
    r = (bins - item).astype(np.float64)

    # Best-fit core: prefer smallest residual (most tightly packed).
    # Add a mild bonus when residual is close to the running mean
    # (so a typical future item could fill it exactly).
    # A small weight keeps the rule dominated by best-fit.
    deviation = np.abs(r - mean)
    score = -r - 0.15 * deviation
    return score
# EVOLVE-BLOCK-END
