# EVOLVE-BLOCK-START
"""Best-fit with a small stateful nudge toward reusable residuals."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    residual = bins - item  # >= 0 since bins only contains fitting bins

    # Dominant term: prefer tightest fit (small residual).
    score = -residual.astype(np.float64)

    # Small nudge: among near-tight residuals, mildly favor ones that leave a
    # reusable leftover (close to the running mean item size) rather than a
    # tiny dead void. Kept small so it only breaks near-ties.
    # Only meaningful when residual is not huge.
    reuse = -np.abs(residual - mean_item) / 100.0
    score = score + 0.05 * reuse

    return score
# EVOLVE-BLOCK-END
