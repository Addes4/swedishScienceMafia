# EVOLVE-BLOCK-START
"""Best fit with an adaptive consolidation bonus that preserves empty bins."""
import numpy as np


def priority(item, bins):
    """Rank bins: primarily tightest fit, with a bonus that consolidates load.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item                      # resulting residual if placed here
    # Best-fit quality: smaller residual is better.
    base = -resid.astype(np.float64)
    # Consolidation bonus: reward bins that end up well-filled (small residual),
    # slight extra push for finishing a bin off (residual near 0) and a mild
    # penalty for using a still-empty bin.
    finish = -np.abs(resid).astype(np.float64) / 100.0
    fresh_penalty = np.where(bins == 100, 1.0, 0.0)
    return base + 0.4 * finish - 0.6 * fresh_penalty
# EVOLVE-BLOCK-END
