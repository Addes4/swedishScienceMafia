# EVOLVE-BLOCK-START
"""Best fit plus residual-matching bonus.

Primary rule: best fit (minimize resulting residual). Tie-break / secondary signal:
prefer a bin whose resulting residual equals the remaining capacity of some other bin,
so that a later item of that exact size can fill it perfectly. This exploits the fact
that Weibull(mean 40) streams contain many repeated item sizes.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item

    # Best fit: smallest nonnegative residual is best -> score = -residual.
    score = -residual.astype(np.float64)

    # Bonus: does this resulting residual match some other bin's current capacity?
    # (Then a future item of size `residual` can exactly fill that other bin.)
    caps = bins  # current remaining capacities
    # For each candidate residual r, check if r appears among caps (excluding itself).
    # Use sorting of caps to query membership quickly.
    if caps.size > 1:
        order = np.argsort(caps, kind="stable")
        sorted_caps = caps[order]
        idx = np.searchsorted(sorted_caps, residual, side="left")
        clipped = np.clip(idx, 0, sorted_caps.size - 1)
        hit = sorted_caps[clipped] == residual
        # avoid matching the same bin against itself when it is the only occurrence
        score[hit] += 1.0

    return score
# EVOLVE-BLOCK-END
