# EVOLVE-BLOCK-START
"""Best fit with a penalty for creating unusable slivers.

Items are packed into the tightest-fitting bin (classic Best Fit).  On top of that, we
discount a bin slightly when the residual it would leave behind is so small that no future
item is likely to fill it, which would waste that space.  Conversely we give a tiny bonus
when the residual matches the typical item size band, making it reusable.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Base: prefer tight fits (small residual) -> larger score.
    score = -residual.astype(np.float64)

    # Penalize leaving a sliver too small to be useful (wasted space).
    # A residual of 1..4 is almost never filled; scale the penalty by how dead it is.
    dead = (residual >= 0) & (residual < 5)
    score[dead] -= 3.0 * (5 - residual[dead])

    # Small bonus if the residual lands in the typical item-size band (~40),
    # so the leftover can plausibly be filled by a single future item.
    band = (residual >= 30) & (residual <= 45)
    score[band] += 0.5

    return score
# EVOLVE-BLOCK-END
