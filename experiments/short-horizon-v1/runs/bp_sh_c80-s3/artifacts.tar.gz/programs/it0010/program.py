# EVOLVE-BLOCK-START
"""Best fit augmented by an online estimate of the item-size distribution.

The rule learns the empirical distribution of item sizes seen so far in the stream.
For each fitting bin it computes the post-placement residual r = cap - item, and scores
the bin by how likely that residual is to be exactly consumable by a future item:
a residual that matches (or nearly matches) a frequently seen item size is good,
a residual that is a rare/awkward sliver is bad. Tight fits (r near 0) are treated as
consumed (excellent), and the tie-break favors fuller bins as in best fit.
"""
import numpy as np

# module-level state, reset per stream by the harness importing fresh state
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    global _hist, _total

    # update online histogram of observed item sizes (Laplace-smoothed)
    if 1 <= item <= 100:
        _hist[item] += 1.0
        _total += 1.0

    # probability mass function estimate over item sizes
    pmf = (_hist + 1.0)
    pmf = pmf / pmf.sum()

    # post-placement residual for every bin
    resid = bins - item  # >= 0 since only fitting bins are shown

    # cumulative distribution: chance a future item is <= r
    cum = np.cumsum(pmf)  # cum[k] = P(size <= k)

    # score: prefer residuals that are exactly fillable by common sizes.
    # exact-match mass reward
    idx = np.clip(resid, 0, 100).astype(np.int64)
    exact = pmf[idx]

    # near-match reward: probability mass within [r-2, r]
    lo = np.clip(idx - 2, 0, 100)
    near = cum[idx] - cum[np.maximum(lo - 1, 0)]

    # full bins (residual 0) are perfectly consumed
    full = 1.0 / (1.0 + resid.astype(np.float64))

    # combine: tight fit is good, but a residual that can be consumed later is also good.
    score = full * 3.0 + exact * 2.0 + near * 1.0

    # small tie-break toward tighter fits so behavior degrades gracefully to best fit
    score = score - resid.astype(np.float64) * 1e-6

    return score
# EVOLVE-BLOCK-END
