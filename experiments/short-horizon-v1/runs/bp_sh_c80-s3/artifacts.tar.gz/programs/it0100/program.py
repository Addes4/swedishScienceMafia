# EVOLVE-BLOCK-START
"""Adaptive best-fit: prefer tightest fit, with a bonus for residuals that match
common small future item sizes, and a mild preference for consolidating into
already-started (fuller) bins."""
import numpy as np

_STATE = {"min_seen": 100}


def priority(item, bins):
    # Track the smallest item seen so far (small items are the hardest to place
    # later, so leaving a residual exactly equal to a small item is valuable).
    if item < _STATE["min_seen"]:
        _STATE["min_seen"] = item

    resid = bins - item  # remaining capacity after placement (>= 0)

    # Primary: tightest fit (largest -resid -> smallest resid).
    score = -resid.astype(np.float64)

    # Bonus: residual exactly 0 (a perfectly filled bin).
    score += np.where(resid == 0, 1000.0, 0.0)

    # Bonus: residual equals the smallest item seen so far, so a future copy of
    # that small item can complete this bin exactly.
    small = _STATE["min_seen"]
    score += np.where(resid == small, 5.0, 0.0)

    # Mild consolidation bonus: prefer fuller bins (smaller current remaining).
    score += (100.0 - bins) * 1e-6

    return score
# EVOLVE-BLOCK-END
