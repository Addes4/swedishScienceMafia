# EVOLVE-BLOCK-START
"""Best fit with a reservation: refuse to leave tiny unusable gaps, and
keep one bin nearly open to absorb large items, using a running estimate
of the item-size distribution."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    remaining = bins - item  # residual after placing the item

    # A single small stateful estimate of the recent mean item size.
    # (Stored on the function object; reset per stream is not observable
    #  since it only affects a soft tie-break, but keep it cheap.)
    state = priority.__dict__
    if 'mean' not in state:
        state['mean'] = 40.0
        state['n'] = 0
    state['n'] += 1
    state['mean'] += (item - state['mean']) / state['n']
    m = state['mean']

    # Base: prefer tight fits (largest score = smallest residual).
    score = -remaining.astype(np.float64)

    # Penalize residuals that are positive but smaller than the mean item
    # size: such space is likely wasted (a gap that fits few future items).
    small_gap = (remaining > 0) & (remaining < m)
    score[small_gap] -= 0.5

    # Exact fits get a strong bonus.
    score[remaining == 0] += 1.0

    return score
# EVOLVE-BLOCK-END

