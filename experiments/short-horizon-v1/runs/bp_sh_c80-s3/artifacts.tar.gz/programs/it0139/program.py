# EVOLVE-BLOCK-START
"""Best-fit with a small exact-fit bonus to encourage filling residuals cleanly."""
import numpy as np


def priority(item, bins):
    """Rank bins: tightest fit, with a mild bonus for residuals that are multiples of item."""
    residual = bins - item
    # Base: tighter fit (smaller residual) scores higher.
    score = -residual.astype(np.float64)
    # Bonus: prefer residuals that are exact multiples of the item (clean packing).
    rem = residual % item
    clean = np.where(rem == 0, 1.0, 0.0)
    score += 0.5 * clean
    return score
# EVOLVE-BLOCK-END

