# EVOLVE-BLOCK-START
"""Best fit, but reserve empty bins for large items by penalizing them for small items."""
import numpy as np


def priority(item, bins):
    """Best-fit core; strongly discourage small items from opening a fresh bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    rem = np.asarray(bins, dtype=np.float64)
    # best fit: prefer the smallest residual that still holds the item
    score = -(rem - item)
    # reserve empty bins for large items
    if item < 40:
        fresh = (rem >= 100).astype(np.float64)
        # the smaller the item, the more we avoid a fresh bin
        score -= fresh * (200.0 * (40 - item) / 40.0 + 50.0)
    return score
# EVOLVE-BLOCK-END
