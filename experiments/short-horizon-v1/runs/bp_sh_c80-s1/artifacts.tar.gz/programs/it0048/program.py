# EVOLVE-BLOCK-START
"""Best fit, but always take an exact fit first (Match-style)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Dominant term: best-fit (smallest residual first).
    # Exact fits (residual 0) get a tiny extra boost so they are chosen over any other
    # bin with the same best-fit residual ordering; among exact fits ties go to first bin.
    return -(residual) + (residual == 0) * 1e-9
# EVOLVE-BLOCK-END

