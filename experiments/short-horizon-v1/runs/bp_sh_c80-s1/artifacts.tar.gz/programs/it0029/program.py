# EVOLVE-BLOCK-START
"""Expected-utility bin choice.

Instead of always filling the tightest gap (best fit), score each bin by how
"useful" its post-placement residual is for the stream we have observed so far.
A residual is useful if many likely future item sizes can still fit into it.
Best-fit tightness is kept as a secondary term so packing stays compact.
"""
import numpy as np

# Online histogram of observed item sizes (1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    global _HIST, _COUNT

    # Record the item we just saw.
    _HIST[item] += 1.0
    _COUNT += 1.0

    # Learned probability distribution over item sizes.
    probs = _HIST / _COUNT

    # Residual after placing this item into each shown bin.
    residual = bins - item

    # For each candidate residual, estimate how many future items it can still
    # absorb: sum over item sizes s <= residual of P(s).  This is a rough
    # "usefulness" of leaving that residual.
    # Build cumulative distribution to evaluate quickly.
    cdf = np.cumsum(probs)  # cdf[s] = P(size <= s)

    # residual values are integers >= 0 (only bins the item fits are shown).
    res_clipped = np.clip(residual, 0, 100).astype(np.int64)
    usefulness = cdf[res_clipped]

    # Primary: prefer useful residuals (more future items can fit).
    # Secondary: prefer tighter fit (smaller residual) to keep packing compact.
    # Scale secondary small so it only breaks near-ties in usefulness.
    return usefulness - 1e-4 * residual
# EVOLVE-BLOCK-END
