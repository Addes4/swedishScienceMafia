# EVOLVE-BLOCK-START
"""Best fit augmented with a mild "larger residual" bonus and exact-fit reward."""
import numpy as np


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Primary term is best fit (smallest post-placement residual).  Since the item
    distribution has mean ~40, larger residuals tend to remain refillable by a
    single future item, so we add a small monotone bonus in the residual and a
    strong reward for exact fits (residual 0).
    """
    residual = bins - item  # >= 0 for all shown bins
    r = residual.astype(np.float64)

    # Best fit: prefer the smallest residual.
    base = -r

    # Mild preference for larger residuals (easier to reuse).
    reuse_bonus = 0.15 * r

    # Strong reward for exact fits (no wasted space).
    exact_bonus = np.where(r == 0.0, 1e6, 0.0)

    return base + reuse_bonus + exact_bonus
# EVOLVE-BLOCK-END
