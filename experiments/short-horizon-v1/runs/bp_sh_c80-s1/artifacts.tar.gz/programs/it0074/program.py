# EVOLVE-BLOCK-START
"""Best fit with a small, deterministic diversion: mostly tightest fit, occasionally second best."""
import numpy as np


def priority(item, bins):
    """Score bins: primary tightness (smaller residual preferred), with a tiny hash-based jitter."""
    residual = bins - item
    # Prefer tight fits: smaller residual => higher score.
    # Add a small deterministic jitter (based on bin index) to occasionally prefer a near-optimal bin.
    n = bins.shape[0]
    idx = np.arange(n)
    # cheap deterministic pseudo-random in [0, 1)
    h = (idx * 1103515245 + 12345) & 2147483647
    jitter = (h % 1000) / 1000.0  # 0..0.999
    # jitter magnitude small enough to only affect near-ties, but breaks ties/preferences
    return -(residual.astype(np.float64)) + 0.4 * jitter
# EVOLVE-BLOCK-END
