# EVOLVE-BLOCK-START
"""Best fit, with a histogram-driven residual shaping for large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # remaining capacity after placing item here

    # Strict best fit: smallest residual wins.
    score = -residual.astype(np.float64)

    # For relatively large items, nudge toward leaving a residual that matches
    # a commonly occurring item size, which future items can fill tightly.
    if item >= 30:
        # Small epsilon shaping; does not override a strictly tighter fit.
        # Prefer residuals that are "nice" sizes (powers-of-two-ish common gaps).
        target = 20.0
        score += -0.001 * np.abs(residual.astype(np.float64) - target)

    return score
# EVOLVE-BLOCK-END
