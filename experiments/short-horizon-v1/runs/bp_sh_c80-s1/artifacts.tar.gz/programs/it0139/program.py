# EVOLVE-BLOCK-START
"""Best fit with a bounded complement-reuse bonus from a robust online pmf."""
import numpy as np


# Online histogram of item sizes seen so far (updated once per call).
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_RECOMPUTE_EVERY = 25
_CACHED_PROB = np.zeros(101, dtype=np.float64)


def _refresh_prob():
    global _CACHED_PROB
    if _TOTAL <= 0:
        _CACHED_PROB = np.zeros(101, dtype=np.float64)
        return
    p = _HIST / _TOTAL
    # Laplace-style smoothing so unseen sizes aren't treated as impossible.
    p = (p + 1.0 / 101.0) / 2.0
    _CACHED_PROB = p


def priority(item, bins):
    """Best fit plus a bounded bonus for residuals likely to be refilled.

    Base term is best fit (smallest post-placement residual), which dominates.
    We add a small bounded bonus when the residual size is one the online pmf
    says is common, since such a gap is likely to be exactly refilled soon.
    """
    global _TOTAL, _RECOMPUTE_EVERY

    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0:
        _refresh_prob()

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    prob = _CACHED_PROB[residual]
    # Bounded bonus: at most ~2 capacity units, so exact fits still dominate.
    bonus = 2.0 * prob

    return base + bonus
# EVOLVE-BLOCK-END
