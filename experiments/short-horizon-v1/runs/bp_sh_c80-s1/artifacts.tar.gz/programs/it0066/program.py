# EVOLVE-BLOCK-START
"""Best fit with a learned residual-reuse bonus from the running item histogram."""
import numpy as np

# Per-stream state: histogram of observed item sizes (1..100).
_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary rule is best fit (minimize resulting residual).  A small, self-normalizing bonus
    rewards placements whose resulting residual is a size that has appeared often in the
    stream, so leftovers are more likely to be reused by a future item.
    """
    global _total
    _counts[item] += 1.0
    _total += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Probability that a future item has size exactly r (smoothed).
    probs = _counts / _total  # length 101, index = size

    # Reuse bonus: probability of exactly filling residual r next.
    reuse = probs[np.clip(residual, 0, 100)]

    # Slight preference for residuals that are common sizes, scaled conservatively.
    score = -residual + 0.6 * reuse

    return score
# EVOLVE-BLOCK-END
