# EVOLVE-BLOCK-START
"""Best fit with a tiny nudge favoring larger residuals to reduce stranding."""
import numpy as np


def priority(item, bins):
    """Rank fitting bins: best fit dominant, small bonus for larger residual.

    Pure best fit (smallest residual) is the strongest known simple online rule.
    When residuals are nearly tied, placing into the larger residual leaves more
    room for future items, slightly reducing the chance of stranding small gaps.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Best-fit term dominates: larger (less negative) for smaller residual.
    base = -residual.astype(np.float64)
    # Tiny tie-breaking nudge toward larger residuals (opposes best fit only weakly).
    nudge = 0.001 * residual.astype(np.float64)
    return base + nudge
# EVOLVE-BLOCK-END

