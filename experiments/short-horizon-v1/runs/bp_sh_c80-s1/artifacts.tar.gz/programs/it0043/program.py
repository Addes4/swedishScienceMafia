# EVOLVE-BLOCK-START
"""Worst-fit: put the item in the emptiest bin, but take an exact fit if one exists."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Prefer an exact fit (residual 0) above everything else; otherwise worst-fit:
    # the emptiest bin (largest remaining capacity) which keeps bins roomy.
    exact = (bins == item)
    return np.where(exact, 1e9, bins.astype(float))
# EVOLVE-BLOCK-END

