# EVOLVE-BLOCK-START
"""Best fit with residual-alignment tie-break based on item size."""
import numpy as np


def priority(item, bins):
    """Rank bins: primary best-fit on residual, tie-break by residual alignment.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    residual = bins - item
    # Strict best-fit: smaller residual is better.
    base = -residual.astype(np.float64)
    # Bonus when the residual is an exact multiple of the item size, meaning the
    # remaining gap can be filled exactly by repeated copies of this item.
    mult = np.where(item > 0, residual % item == 0, False)
    bonus = mult.astype(np.float64) * 0.5
    return base + bonus
# EVOLVE-BLOCK-END

