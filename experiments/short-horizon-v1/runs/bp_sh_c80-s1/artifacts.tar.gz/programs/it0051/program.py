# EVOLVE-BLOCK-START
"""Best fit, but route large items to roomier bins to avoid locking big fragments."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # <= 0 always (bins only contains bins the item fits in)
    if item >= 60:
        # For large items, prefer the roomiest bin so we don't leave a large
        # fragment that only another large item could fill.
        return bins.astype(float)
    # Otherwise best fit: smallest residual (most negative), i.e. tightest fit.
    return residual.astype(float)
# EVOLVE-BLOCK-END

