# EVOLVE-BLOCK-START
"""Best fit with a mild bias toward leaving smaller bins and perfect fills."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: prefer smallest post-placement residual (best fit).
    # Secondary: prefer perfectly filled bins (residual == 0).
    return -residual.astype(np.float64) * 1000.0 - (residual == 0).astype(np.float64)
# EVOLVE-BLOCK-END

