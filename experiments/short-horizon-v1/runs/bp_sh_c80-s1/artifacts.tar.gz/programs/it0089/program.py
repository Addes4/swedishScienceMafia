# EVOLVE-BLOCK-START
"""Best fit, but avoid stranding residuals that no typical future item can use."""
import numpy as np


# Online statistics of item sizes seen so far (updated once per call).
_HIST = np.zeros(101, dtype=np.float64)   # counts for sizes 1..100
_TOTAL = 0.0
_RECOMPUTE_EVERY = 50
_CACHED_CDF = np.zeros(101, dtype=np.float64)   # P(item <= r) for r = 0..100


def _refresh_cdf():
    global _CACHED_CDF
    if _TOTAL <= 0:
        _CACHED_CDF = np.zeros(101, dtype=np.float64)
        return
    p = _HIST / _TOTAL
    _CACHED_CDF = np.cumsum(p)


def priority(item, bins):
    """Rank bins by smallest post-placement residual, penalizing residuals that
    are too small to be reused by a typical future item (structurally stranded)."""
    global _TOTAL

    # Record this item.
    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0:
        _refresh_cdf()

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # P(item <= residual): how likely a future item fits in the leftover gap.
    fillable = _CACHED_CDF[residual]

    # Penalize residuals that are small relative to the item distribution:
    # a residual below the typical item size will almost always be stranded.
    # Reward residuals that can still accommodate a plausible next item.
    penalty = 25.0 * (1.0 - fillable)

    return base - penalty
# EVOLVE-BLOCK-END

