# EVOLVE-BLOCK-START
"""Best fit with a soft empirical tie-break on the residual."""
import numpy as np


def priority(item, bins):
    """Best-fit, with tiny data-driven tie-break among almost-equal residuals."""
    residual = bins - item

    # Running empirical histogram of item sizes seen so far (module-level state).
    hist = priority.hist
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        priority.hist = hist
        priority.count = 0.0

    # Best fit: smaller residual is better.
    score = -residual.astype(np.float64)

    # Tiny bonus if the residual matches a size we have seen (smoothed histogram).
    # This only breaks near-ties; the -residual term dominates.
    if priority.count > 0:
        w = np.zeros(101, dtype=np.float64)
        w[:101] = hist
        # Smooth to allow slight neighborhood matching.
        w = w + 0.5 * np.concatenate(([0.0], w[:-1]))
        w = w / w.max()
        r = np.clip(residual, 0, 100).astype(np.int64)
        score = score + 1e-3 * w[r]

    # Update histogram with the current item.
    hist[item] += 1.0
    priority.count += 1.0

    return score


priority.hist = None
priority.count = 0.0
# EVOLVE-BLOCK-END
