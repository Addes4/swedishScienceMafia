# EVOLVE-BLOCK-START
"""Pure best fit: place each item into the bin that leaves the smallest residual."""
import numpy as np


def priority(item, bins):
    """Score every fitting bin; highest score wins (first on ties).

    Best fit minimizes the post-placement residual, which packs tightly and
    avoids creating hard-to-fill gaps.
    """
    residual = bins - item  # >= 0 for all shown bins
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
