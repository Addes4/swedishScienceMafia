# EVOLVE-BLOCK-START
"""Best-fit with frequency-aware perfect matching for online bin packing."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties).

    Strategy: strict best-fit is the basis.  We add a small bonus for bins that
    would be left with a residual equal to a frequently observed small item
    size, and a big bonus for a perfect fit (residual zero).  The bonus is
    small enough that it never overrides a strictly tighter fit except among
    near-ties, but it biases ambiguous choices toward gaps that future small
    items are likely to fill.
    """
    hist = _state["hist"]
    n = _state["n"]

    resid = bins - item  # remaining capacity after placing the item (>= 0)

    # Base: prefer tighter fits (smaller residual).  Negate so higher is better.
    best = -(resid.astype(np.float64))

    # Frequency-weighted bonus: reward residuals that are common item sizes.
    # Only apply once we have a little history so early decisions stay pure.
    if n >= 20:
        freq = hist / n
        # Bonus proportional to probability that a future item equals residual.
        # Cap residual index to 100.
        idx = np.clip(resid, 0, 100)
        bonus = freq[idx]
        # Perfect fit (residual 0) gets the strongest data-independent reward.
        bonus = np.where(resid == 0, 1.0, bonus)
        # Keep bonus strictly smaller than one unit of residual difference so
        # best-fit ordering is preserved up to exact/tiny ties.
        best = best + 0.9 * bonus

    # Record the item for the running histogram.
    hist[item] += 1.0
    _state["n"] = n + 1

    return best
# EVOLVE-BLOCK-END
