# EVOLVE-BLOCK-START
"""Best fit with an online, CDF-based penalty for stranding improbable residuals."""
import numpy as np


# Online histogram of item sizes seen so far (updated once per call).
_HIST = np.zeros(101, dtype=np.float64)   # counts for sizes 1..100
_TOTAL = 0.0
_RECOMPUTE_EVERY = 25
_CACHED_PROB = np.zeros(101, dtype=np.float64)
_CACHED_CDF = np.zeros(101, dtype=np.float64)
_MEAN_ITEM = 40.0


def _refresh_prob():
    global _CACHED_PROB, _CACHED_CDF, _MEAN_ITEM
    if _TOTAL <= 0:
        _CACHED_PROB = np.zeros(101, dtype=np.float64)
        _CACHED_CDF = np.zeros(101, dtype=np.float64)
        return
    p = _HIST / _TOTAL
    _CACHED_PROB = p
    _CACHED_CDF = np.cumsum(p)
    # Running mean of observed item sizes (index 0 unused/zero weight).
    idx = np.arange(101, dtype=np.float64)
    _MEAN_ITEM = float((p * idx).sum())


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Base is best fit (smallest post-placement residual).  We add a penalty when the
    residual r is a size that the empirical item distribution rarely revisits,
    measured by the empirical pmf at r relative to a baseline, normalized and capped
    so that an exact fill always dominates.
    """
    global _TOTAL

    # Record this item (post-decision, but item is given before we rank).
    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0:
        _refresh_prob()

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    prob = _CACHED_PROB[residual]

    # Baseline expected chance a residual of this size gets exactly refilled.
    # Use a smoothed floor so early calls behave sanely.
    denom = max(1.0, _TOTAL)
    baseline = 1.0 / denom

    # Ratio of observed reuse probability to baseline; >1 means likely refillable.
    ratio = prob / baseline

    # Cap the penalty so that a residual of 0 (exact fill) keeps a strong advantage:
    # residual 0 -> prob high, penalty ~0; stranded small residuals -> capped penalty.
    penalty = np.minimum(ratio, 3.0)
    scale = 0.5 * _MEAN_ITEM  # adaptive, ~20 for mean-40 distribution

    # Small residuals that are unlikely to be refilled are the true waste; gently
    # down-weight the penalty for larger residuals which still fit many items.
    size_factor = np.clip(residual, 0.0, 1.0)

    return base - scale * (1.0 - penalty / 3.0) * (1.0 - 0.5 * size_factor)
# EVOLVE-BLOCK-END
