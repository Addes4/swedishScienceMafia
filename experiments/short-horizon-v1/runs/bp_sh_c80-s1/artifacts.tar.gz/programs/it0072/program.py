# EVOLVE-BLOCK-START
"""Best fit with a fractional near-tie tie-break on current fill."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize residual (best fit). Add a small fractional term that
    # prefers bins that are already more full (smaller current remaining capacity)
    # among near-tied residuals, which tends to consolidate packing.
    return -residual - 0.001 * (100 - residual)
# EVOLVE-BLOCK-END

