# EVOLVE-BLOCK-START
"""Best fit with a small consolidation tie-break toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: strictly tightest fit (most negative residual first).
    # Secondary: among near-equal residuals, prefer the fuller (smaller remaining) bin,
    # which consolidates leftovers and tends to reduce fragmentation.
    return -(residual.astype(np.float64) * 1.0) - 1e-6 * bins.astype(np.float64)
# EVOLVE-BLOCK-END

