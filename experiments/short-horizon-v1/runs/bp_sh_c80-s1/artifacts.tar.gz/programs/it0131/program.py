# EVOLVE-BLOCK-START
"""Best fit with a mild, recency-weighted reuse bonus for the resulting residual."""
import numpy as np


# Recency-weighted online histogram of item sizes (decayed once per call).
_HIST = np.zeros(101, dtype=np.float64)
_DECAY = 0.99
_STEP = 0.0


def priority(item, bins):
    """Rank fitting bins: dominant best-fit, small bonus when residual is reusable.

    The bonus rewards a residual that matches a size we expect future items to have
    (recency-weighted frequency), since such gaps are more likely to be consumed.
    """
    global _HIST, _STEP

    # Decay history and record current item (a likely future complement signal).
    _HIST *= _DECAY
    _HIST[item] += 1.0
    _STEP += 1.0

    residual = bins - item  # >= 0
    base = -residual.astype(np.float64)  # best fit (smallest residual first)

    total = _HIST.sum()
    if total > 0:
        prob = _HIST / total
    else:
        prob = _HIST

    # Bonus: residual size is a commonly seen item size (likely reusable).
    bonus = 40.0 * prob[residual]

    return base + bonus
# EVOLVE-BLOCK-END
