# EVOLVE-BLOCK-START
"""Best-fit, but avoid leaving residuals that are too small to ever be useful."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item
    # Prefer exact fits, then residuals large enough to hold at least a size-1 item,
    # then otherwise still prefer the tightest fit (best-fit).
    # Score: primary key = residual; exact fits (0) get top priority.
    # We implement as: minimize residual but treat residual==0 as special (already smallest).
    return -residual
# EVOLVE-BLOCK-END
