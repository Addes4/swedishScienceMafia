# EVOLVE-BLOCK-START
"""Adaptive best fit: strict best fit, but for large items prefer near-exact fills."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: strict best fit (smallest residual wins).
    score = -residual.astype(np.float64)
    # For large items, strongly reward near-exact fills so big items don't fragment bins.
    if item >= 60:
        # weight larger for bigger items; residual==0 gets a large boost
        w = (item - 60) / 40.0 + 0.5
        score += w * (100.0 / (1.0 + residual.astype(np.float64)))
    return score
# EVOLVE-BLOCK-END
