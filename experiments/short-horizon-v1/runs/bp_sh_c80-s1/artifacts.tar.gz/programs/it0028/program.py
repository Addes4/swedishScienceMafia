# EVOLVE-BLOCK-START
"""Best fit with a tiny learned tie-break toward reusable residuals."""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary: best fit (smallest post-placement residual).
    Tie-break: prefer residuals that are multiples of common item sizes seen so far,
    so the leftover gap is more likely to be exactly fillable later.
    """
    counts = _state["counts"]
    counts[item] += 1.0
    _state["n"] += 1.0

    residual = bins - item  # post-placement remaining capacity (>=0 for fitting bins)

    # Tiny bonus for residuals that are "nice" (multiples of 1..? learned sizes).
    # Build a small weight vector for residual values 0..100.
    n = _state["n"]
    if n < 8:
        return -residual.astype(np.float64)

    # Learned probability over item sizes; residual r is "reusable" if some
    # common size divides/equals it. Use a soft score = sum p[s] for s | r.
    p = counts / n
    reuse = np.zeros(101, dtype=np.float64)
    for r in range(101):
        # probability mass of observed sizes that exactly equal r or divide r
        acc = p[r]
        s = 2
        while s * s <= r:
            if r % s == 0:
                acc += p[s] + p[r // s]
            s += 1
        if r > 0 and s * s == r:
            acc += p[s]
        reuse[r] = acc

    # Clip residual into valid index range
    ri = np.clip(residual, 0, 100).astype(np.int64)
    bonus = reuse[ri]

    # Best fit dominates; bonus is a tiny tie/near-tie breaker.
    return -residual.astype(np.float64) + 0.01 * bonus
# EVOLVE-BLOCK-END
