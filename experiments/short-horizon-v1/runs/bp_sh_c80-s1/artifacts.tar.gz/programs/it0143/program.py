# EVOLVE-BLOCK-START
"""Best fit with a tiny, deterministic tie-break bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Pure best fit (smallest post-placement residual) dominates.  A small bonus
    rewards residuals exactly equal to the current item's size, since equal-size
    items recur and will exactly fill such gaps.
    """
    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Small bonus when residual == item (likely to be filled by a same-size item).
    bonus = 1.0 * (residual == item)

    return base + bonus
# EVOLVE-BLOCK-END

