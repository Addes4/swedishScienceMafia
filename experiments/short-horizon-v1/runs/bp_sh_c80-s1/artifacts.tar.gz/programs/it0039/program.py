# EVOLVE-BLOCK-START
"""Best fit with fragment-averse tie-breaking using online item statistics."""
import numpy as np


class _Stats:
    def __init__(self):
        self.max_small = 0
        self.seen = 0

    def update(self, item):
        self.seen += 1
        if item < 40:
            if item > self.max_small:
                self.max_small = item


_stats = _Stats()


def priority(item, bins):
    """Best fit, with tie-breaking that avoids leaving tiny unusable fragments."""
    _stats.update(int(item))
    resid = bins - item
    # Primary: minimize post-placement residual (best fit).
    # Secondary: strongly penalize residuals that are positive but smaller than
    # the largest common small item (a likely unusable fragment), and reward 0.
    frag_floor = _stats.max_small
    # small bonus/penalty applied at a scale below 1 so it only breaks near-ties
    penalty = np.zeros(resid.shape, dtype=np.float64)
    pos = resid > 0
    if frag_floor > 0:
        tiny = pos & (resid < frag_floor)
        penalty[tiny] = 0.75
    # feasible residuals (>= frag_floor) get slight preference over tiny ones
    ok = pos & (resid >= frag_floor)
    penalty[ok] = 0.25
    # exact fits best
    penalty[resid == 0] = 0.0
    return -(resid.astype(np.float64) + penalty)
# EVOLVE-BLOCK-END

