# EVOLVE-BLOCK-START
"""Online best fit biased by the estimated chance of exactly closing a bin."""
import numpy as np

SIZE = 101
_hist = np.zeros(SIZE, dtype=np.float64)
_total = 0.0


def _record(item):
    global _total
    _hist[item] += 1.0
    _total += 1.0


def priority(item, bins):
    """Rank bins: prefer the residual most likely to be exactly filled next.

    We keep an online histogram of seen item sizes.  For a candidate bin the
    post-placement residual r is scored by P(next item == r) plus a small
    best-fit tie-break, so residuals that match frequent sizes are favoured.
    """
    _record(item)

    residual = bins - item  # >= 0 for every bin shown
    # Probability that a future item exactly equals this residual
    # (Laplace-smoothed frequency of residual among seen sizes).
    freq = _hist[residual] if residual.size else np.zeros_like(residual, dtype=np.float64)
    prob = (freq + 1.0) / (_total + SIZE)

    # Primary: likelihood of exactly closing the bin; secondary: best fit.
    score = 1000.0 * prob - residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
