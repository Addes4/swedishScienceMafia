# EVOLVE-BLOCK-START
"""Best fit with a mild preference for leaving reusable residuals.

Pure best fit minimizes the post-placement residual. On a Weibull-shaped
distribution with mean ~40 many items are mid-sized, so a bin whose residual
is close to a typical future item size stays reusable. We therefore score
bins primarily by tightness (small residual = good), but give a small bonus
when the residual lands near the expected item size, breaking the pure
best-fit choices toward more reusable leftovers.
"""
import numpy as np

# Expected value of the item-size distribution (mean ~ 40).
_TARGET = 40.0


def priority(item, bins):
    residual = bins - item                 # remaining capacity after placement
    # Primary: prefer tight fits (small residual).
    tight = -residual.astype(np.float64)
    # Secondary: small bonus for residuals near the typical item size.
    reusable = -np.abs(residual - _TARGET)
    return tight + 0.01 * reusable
# EVOLVE-BLOCK-END
