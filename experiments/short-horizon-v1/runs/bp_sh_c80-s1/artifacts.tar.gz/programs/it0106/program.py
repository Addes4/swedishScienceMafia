# EVOLVE-BLOCK-START
"""Best fit: place the item in the bin leaving the smallest residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Best fit: prefer the bin whose remaining capacity after placement is smallest.
    Exact fits (residual 0) get the highest score automatically.  Ties are broken
    toward the earlier bin index by the harness.
    """
    residual = bins - item  # >= 0 for all shown bins
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
