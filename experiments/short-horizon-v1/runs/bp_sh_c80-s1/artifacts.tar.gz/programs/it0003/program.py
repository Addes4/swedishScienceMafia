# EVOLVE-BLOCK-START
"""Best fit with a learned-residual bonus.

Pure best fit minimizes immediate waste: place the item into the bin with the
smallest remaining capacity that still fits.  On Weibull-shaped sizes (mean
~40) this leaves many bins with small, hard-to-fill residuals.

We add a light hindsight term: we keep a running histogram of the observed item
sizes and score each candidate bin by how well its post-placement residual
matches the sizes that actually tend to arrive.  A residual that is a common
item size (or a good fit for a common size) is more valuable than one that is
awkward, so we break near-ties in favour of bins whose leftover is "useful".

The best-fit term dominates so we never lose the tightness of the classic rule;
the histogram term only refines among comparable fits.
"""
import numpy as np

SIZES = 100

# module-level state, reset lazily per stream via item count drift
_state = {"counts": None, "total": 0}
_hist = np.zeros(SIZES + 1, dtype=np.float64)
_seen = 0


def _maybe_reset():
    """Heuristically detect a fresh stream: unused-bin signals aside, streams
    restart the module.  We reset only when no calls have happened yet, which
    the harness guarantees by importing/initialising fresh per stream is not
    available -- so we keep a simple decay instead of a hard reset."""
    global _seen
    # slow decay keeps adaptation to the current stream while limiting drift
    if _seen and _seen % 2000 == 0:
        _hist *= 0.5


def priority(item, bins):
    global _seen
    _maybe_reset()

    # update empirical size distribution (with Laplace-ish smoothing)
    _hist[item] += 1.0
    _seen += 1

    total = _hist.sum()
    if total > 0:
        probs = (_hist + 0.5) / (total + 0.5 * (SIZES + 1))
    else:
        probs = np.full(SIZES + 1, 1.0 / (SIZES + 1))

    # expected "quality" of a residual r: probability that some future item
    # exactly or loosely matches it.  We reward the mass of item sizes <= r
    # that would leave a small residual, plus exact-fit mass.
    # Build a value table indexed by residual for speed.
    residual = bins - item  # remaining capacity after placing the item
    caps = np.clip(residual, 0, SIZES).astype(np.int64)
    idx = caps  # 0..100

    # cumulative mass of sizes <= r, weighted toward tight fits
    cum = np.cumsum(probs)  # cum[r] = P(size <= r)

    # value of residual r: high if it equals a likely size (exact fit later)
    exact = probs[idx]
    # loose-fit value: room for a near-full future item, penalise huge slack
    loose = cum[idx] * (1.0 - idx / (SIZES + 1.0))

    value = 3.0 * exact + loose

    # dominant best-fit term: tighter fit (smaller residual) is better
    score = -(bins - item) + 1e-3 * value
    return score
# EVOLVE-BLOCK-END
