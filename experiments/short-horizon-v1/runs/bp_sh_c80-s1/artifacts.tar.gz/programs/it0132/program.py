# EVOLVE-BLOCK-START
"""Best fit, with tie-breaking that favors residuals likely to be reused."""
import numpy as np


# Online histogram of item sizes seen so far (updated once per call).
_HIST = np.zeros(101, dtype=np.float64)   # counts for sizes 1..100


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Base is best fit (smallest post-placement residual).  Among comparable residuals
    we give a small bonus when the residual equals a frequently seen item size, since
    such a gap is likely to be filled exactly by a future item and thus reused.
    """
    # Record this item so the histogram reflects the stream.
    _HIST[item] += 1.0
    total = _HIST.sum()

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Empirical probability that a future item exactly fills this residual.
    prob = _HIST[residual] / total

    # Small stable bonus: up to ~2 units, enough to break near-ties in residual
    # but not to override a genuinely tighter fit (residual diff >= 1).
    bonus = 1.8 * prob

    return base + bonus
# EVOLVE-BLOCK-END
