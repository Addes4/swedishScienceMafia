# EVOLVE-BLOCK-START
"""Best fit with a harmonic-fit adjustment: prefer tightness, but penalize residuals
that waste a bin (too small to be useful, yet nonzero)."""
import numpy as np

# Precompute a lookup: for a post-placement residual r in 0..100, a "quality" score.
# Exact fit (r==0) is best; tiny nonzero residuals are worst (wasted space);
# larger residuals are increasingly useful (can still hold typical items).
_R = np.arange(101, dtype=np.float64)
# quality: 0 at r=0 handled separately; for r>0 a concave increasing reward,
# strongly penalizing small residuals.
_QUALITY = np.where(_R == 0, 0.0, np.log1p(_R) - 2.0 / (_R + 1.0))


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest score.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all bins shown
    q = _QUALITY[residual]
    # Primary: strong preference for exact fits.
    exact = (residual == 0).astype(np.float64)
    # Secondary: prefer tighter fits (best-fit signal).
    tight = -residual.astype(np.float64)
    return exact * 12.0 + q * 1.0 + tight * 0.02
# EVOLVE-BLOCK-END
