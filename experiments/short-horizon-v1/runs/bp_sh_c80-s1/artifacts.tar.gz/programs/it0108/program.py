# EVOLVE-BLOCK-START
"""Best fit with a smooth prior bonus for reusable residuals.

Item sizes are Weibull-shaped with mean about 40 and capacity 100, so bins
typically hold 2-3 items.  Best fit alone occasionally strands a tiny residual
that no future item can fill.  We keep best fit as the primary ordering and add
a smooth, fixed-shape bonus that favors residuals lying in the bulk of the item
distribution (near a typical item size), where reuse is most likely.
"""
import numpy as np

# Precompute a smooth reusability prior over residuals 0..100 from a typical
# Weibull-ish item profile: peak near the mean (~40), near-exact fills valuable,
# very small residuals (below a few) mostly unusable.
_R = np.arange(0, 101, dtype=np.float64)
_MU = 40.0
_SIGMA = 22.0
_BULK = np.exp(-0.5 * ((_R - _MU) / _SIGMA) ** 2)
# Small residuals (< ~8) are hard to fill exactly; down-weight them.
_SMALL = 1.0 - np.exp(-_R / 6.0)
_PRIOR = _BULK * _SMALL


def priority(item, bins):
    """Rank fitting bins: primary best fit, secondary reusable-residual bonus."""
    residual = bins - item  # >= 0 for all shown bins

    base = -residual.astype(np.float64)          # best fit
    exact = (residual == 0).astype(np.float64)   # exact fills dominate
    bonus = _PRIOR[residual]                     # smooth reusability prior

    return base + 40.0 * exact + 6.0 * bonus
# EVOLVE-BLOCK-END
