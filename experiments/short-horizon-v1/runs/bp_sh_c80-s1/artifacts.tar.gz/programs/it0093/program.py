# EVOLVE-BLOCK-START
"""Best fit with a mild quadratic correction favoring larger residuals (ASUM-like)."""
import numpy as np


def priority(item, bins):
    """Rank bins: strongly prefer small residuals (best fit), but mildly favor
    leaving bins with more free room, which reduces stranding of tiny residuals.

    score = -residual - c * residual^2
    Ties break toward smaller residual (first bin). Exact fills (residual 0)
    always win.
    """
    residual = (bins - item).astype(np.float64)  # >= 0
    return -residual - 0.02 * residual * residual
# EVOLVE-BLOCK-END
