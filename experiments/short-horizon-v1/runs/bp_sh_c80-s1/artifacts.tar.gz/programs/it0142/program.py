# EVOLVE-BLOCK-START
"""Best fit with a deterministic exact-fit / equal-size-residual tie-break."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer exact fill, then residual equal to the item size, then best fit.

    - residual 0 (perfect fill) is always best.
    - residual == item means a bin likely to be filled by the next same-sized item.
    - otherwise prefer the smallest residual (classic best fit).
    """
    residual = bins - item  # >= 0 for all shown bins

    score = -residual.astype(np.float64)

    # Bonus for a residual that equals the current item size (commonly recurring).
    score += 25.0 * (residual == item)

    # Exact fills get a large bonus so they always win.
    score += 1000.0 * (residual == 0)

    return score
# EVOLVE-BLOCK-END
