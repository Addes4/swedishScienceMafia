# EVOLVE-BLOCK-START
"""Best fit with a smooth, empirically-scaled tie-breaker on the residual."""
import numpy as np


# Online histogram of item sizes seen so far.
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Rank bins: primarily best fit (smallest residual), with a mild empirical tie-break.

    Pure best fit minimizes the immediate residual.  We add a small bonus when the
    residual matches a size the stream has actually produced often, since such gaps
    are the ones most likely to be closed later; the bonus is scaled small so it only
    reshuffles near-ties rather than overriding clearly tighter fits.
    """
    global _TOTAL

    # Update empirical distribution with the current item.
    _HIST[item] += 1.0
    _TOTAL += 1.0

    residual = bins - item  # >= 0
    base = -residual.astype(np.float64)

    # Mild empirical bonus: how often have we seen an item of exactly this residual?
    prob = _HIST[residual] / _TOTAL

    # Scale small: at most ~1 unit of score, enough for near-ties only.
    bonus = 2.0 * prob

    return base + bonus
# EVOLVE-BLOCK-END
