# EVOLVE-BLOCK-START
"""Best fit with a stable guard against stranding tiny residuals."""
import numpy as np


_MIN_ITEM = 100.0  # running minimum item size seen so far


def priority(item, bins):
    """Score bins: prefer tightest fit (smallest residual), but slightly avoid
    creating residuals smaller than the smallest item we've seen, which are
    likely to be stranded forever.

    Score = -residual + bonus for residuals that are >= smallest seen item
    (i.e. gaps that some real item could still fill).  Best-fit remains dominant.
    """
    global _MIN_ITEM
    if item < _MIN_ITEM:
        _MIN_ITEM = item
    m = _MIN_ITEM

    residual = bins - item  # non-negative for all shown bins
    rf = residual.astype(np.float64)

    # Base: strongest preference for smallest residual (best fit).
    score = -rf

    # Penalty only when residual is positive but below the smallest item we
    # believe can still appear: such a gap cannot be exactly filled and is
    # likely stranded. Small enough not to override clear best-fit ordering,
    # but enough to break near-ties toward reusable gaps.
    tiny = (rf > 0.0) & (rf < m)
    score = score - 1.5 * tiny.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
