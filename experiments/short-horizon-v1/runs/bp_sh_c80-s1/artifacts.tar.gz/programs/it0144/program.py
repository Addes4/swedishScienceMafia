# EVOLVE-BLOCK-START
"""Best fit with a smooth grading that favors residuals slightly larger than the item."""
import numpy as np


# Online exponential moving average of recent item sizes (state per stream).
_EMA = 0.0
_ALPHA = 0.05


def priority(item, bins):
    """Score bins by best fit, with a smooth preference for residuals near the item size.

    Pure best fit minimizes the immediate residual.  We modulate it slightly so that,
    among residuals, ones comfortably larger than the current item (but not huge) are
    preferred, which tends to accumulate like-sized items together and leave small
    usable gaps rather than many tiny unusable ones.  The modulation is bounded so
    exact fits and clearly-better fits still win.
    """
    global _EMA
    _EMA += _ALPHA * (item - _EMA) if _EMA > 0 else (item - _EMA)
    ref = _EMA if _EMA > 0 else float(item)

    residual = bins - item  # >= 0 for all shown bins
    res = residual.astype(np.float64)

    # Base: best fit.
    base = -res

    # Smooth grading: prefer residual moderately above item, penalize tiny residuals
    # that are hard to reuse and huge ones that waste space.
    # target residual ~ item (a match is reusable); small bounded swing.
    target = float(item)
    # normalized deviation, bounded
    dev = (res - target) / 100.0
    grade = -3.0 * dev * dev

    return base + grade
# EVOLVE-BLOCK-END

