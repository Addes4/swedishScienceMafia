# EVOLVE-BLOCK-START
"""Best fit with saturation damping: prefer tight fits but avoid over-filling.

Items are ~Weibull with mean 40. Pure best fit tends to consolidate large items,
leaving many tiny unusable residuals and forcing new bins for medium items.
Scoring by a damped residual (raising residual capacity to a power <1) keeps
tight fits preferred but spreads packing slightly, improving bin reuse.
"""
import numpy as np


def priority(item, bins):
    r = bins - item  # post-placement residual, >= 0
    # Exact fits get a strong bonus.
    score = np.where(r == 0, 1e6, 0.0)
    # Damped residual: smaller residual -> higher score; damping softens the
    # extreme preference for near-zero residuals that wastes bins.
    score = score + (100.0 - np.power(r.astype(np.float64), 0.85))
    return score
# EVOLVE-BLOCK-END

