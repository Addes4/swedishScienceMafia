# EVOLVE-BLOCK-START
"""Ratio-aware best fit for Weibull-shaped items."""
import numpy as np


def priority(item, bins):
    """Rank bins by a fill-ratio criterion.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer tightly-fitting bins (small residual), but use the fill ratio after the
    # placement to encourage packing into already-used bins and reserving empties.
    # Post-placement fill fraction: (100 - residual) / 100.
    fill = (100.0 - residual) / 100.0
    # Primary: minimize residual; secondary: maximize fill ratio.
    return -residual + 0.5 * fill
# EVOLVE-BLOCK-END
