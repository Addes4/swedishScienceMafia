# EVOLVE-BLOCK-START
"""Residual-targeting rule: aim to leave residuals that future items can still fill."""
import numpy as np

# Target post-placement residual: close to a common Weibull-ish item size,
# so the leftover bin is likely to be reusable by a future item.
_TARGET = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer bins whose post-placement residual is near _TARGET (reusable),
    # but never worse than best-fit when residuals are already very small.
    return -np.abs(residual - _TARGET) - 0.02 * residual
# EVOLVE-BLOCK-END
