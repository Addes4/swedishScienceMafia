# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly.

Small tie-break: among equal residual bins, prefer the one that is already more
loaded (smaller remaining capacity before placement), which reduces the number of
partially-filled bins retained for future items.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize resulting residual (best fit).
    # Secondary: prefer bins that are already fuller (smaller current capacity).
    return -residual * 1e6 - (100.0 - bins)
# EVOLVE-BLOCK-END
