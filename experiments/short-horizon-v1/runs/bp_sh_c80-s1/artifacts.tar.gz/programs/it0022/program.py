# EVOLVE-BLOCK-START
"""Best fit with a soft bonus for residuals matching common observed item sizes."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Score each bin: primary = best fit (smallest residual), secondary = small
    bonus when the residual equals a frequently observed item size."""
    global _total
    _counts[item] += 1.0
    _total += 1.0

    resid = bins - item  # >= 0 for all shown bins
    # Base: tighter fit is better -> larger score for smaller residual.
    score = -resid.astype(np.float64)

    # Soft bonus: residual values that are common past item sizes are desirable.
    freq = _counts / _total  # in (0,1]
    # freq indexed by residual, clipped to [0,100]
    r = np.clip(resid, 0, 100).astype(np.int64)
    score += 0.05 * freq[r]

    return score
# EVOLVE-BLOCK-END
