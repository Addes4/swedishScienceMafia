# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus: minimize residual, strongly prefer residual 0."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of bins the item fits in.
    """
    residual = bins - item
    # Primary: tightest fit. Exact fills get a large bonus so they always win.
    score = -residual.astype(np.float64)
    score += 1e6 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
