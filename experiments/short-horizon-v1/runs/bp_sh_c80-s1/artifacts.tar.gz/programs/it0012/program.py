# EVOLVE-BLOCK-START
"""Best fit with a tiny capacity-aware tie-break toward already-reduced bins."""
import numpy as np


def priority(item, bins):
    """Score bins by post-placement residual (best fit), tie-break by smaller residual bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smallest residual first (best fit). Tiny epsilon: among equal residuals,
    # prefer the bin that currently has less remaining capacity (already-reduced bins),
    # which keeps large fresh bins available for the many large items.
    return -residual - 1e-6 * bins
# EVOLVE-BLOCK-END

