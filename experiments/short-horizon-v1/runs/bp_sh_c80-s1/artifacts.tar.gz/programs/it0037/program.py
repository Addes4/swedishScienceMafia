# EVOLVE-BLOCK-START
"""Best fit with a usability-aware preference for non-fragmenting residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown

    # Best-fit default: prefer the smallest residual (largest score).
    score = -residual.astype(np.float64)

    # Bonus: exact fills should always win.
    score += (residual == 0) * 1000.0

    # Bonus: residuals that can still fit a typical item (>= threshold) are "usable"
    # and should be preferred over tiny fragments, as long as they are not too big.
    usable = (residual >= 25) & (residual < 100)
    score += usable * 1.0

    return score
# EVOLVE-BLOCK-END
