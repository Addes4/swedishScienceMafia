# EVOLVE-BLOCK-START
"""Best-fit with a mild worst-fit pull: prefer tight fits, but slightly favour bins
that are already partly filled so residuals consolidate into reusable bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item            # leftover capacity after placing the item
    # Primary: smaller residual is better. Secondary: a small pull toward bins that are
    # less full (larger residual), which avoids stranding many tiny residuals.
    alpha = 0.05
    return -residual.astype(np.float64) + alpha * residual.astype(np.float64)
# EVOLVE-BLOCK-END

