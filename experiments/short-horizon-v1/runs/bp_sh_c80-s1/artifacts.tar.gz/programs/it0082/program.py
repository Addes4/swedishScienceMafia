# EVOLVE-BLOCK-START
"""Mostly best fit, with rare diversion to bin whose residual matches a common future item."""
import numpy as np


def _hash(x):
    # deterministic 32-bit hash of a nonnegative int
    x = (x ^ 61) ^ (x >> 16)
    x = (x + (x << 3)) & 0xFFFFFFFF
    x = x ^ (x >> 4)
    x = (x * 0x27D4EB2F) & 0xFFFFFFFF
    x = x ^ (x >> 15)
    return x


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing item

    # Base: best fit (prefer smallest residual).
    score = -residual.astype(np.float64)

    # With small probability, break out of strict best fit by slightly favoring
    # bins whose residual lands in a "sweet spot" where a future item commonly
    # fits exactly (helps reuse otherwise-stranded residuals).
    h = _hash(int(item) * 2654435761 + int(bins.shape[0]))
    if (h & 0xFF) < 26:  # ~10% of items
        # sweet spot: residual in [16, 48]
        sweet = (residual >= 16) & (residual <= 48)
        score += sweet.astype(np.float64) * 6.0
        # mild extra for leaving a larger residual (reusable bin) only when sweet
        score += np.where(sweet, residual.astype(np.float64) * 0.08, 0.0)

    return score
# EVOLVE-BLOCK-END
