# EVOLVE-BLOCK-START
"""Best fit with an online estimate of the chance a residual can be filled."""
import numpy as np


# Online histogram of item sizes seen so far.
_HIST = np.zeros(101, dtype=np.float64)   # counts for sizes 1..100
_TOTAL = 0.0
_RECOMPUTE_EVERY = 25
_CACHED_PROB = np.zeros(101, dtype=np.float64)


def _refresh_prob():
    global _CACHED_PROB
    if _TOTAL <= 0:
        _CACHED_PROB = np.zeros(101, dtype=np.float64)
        return
    _CACHED_PROB = _HIST / _TOTAL


def priority(item, bins):
    """Rank bins by best fit, with a bonus for residuals likely to be reused.

    Exact fits are strongly favored.  Among other bins we still prefer the
    smallest post-placement residual (best fit), but we add a small bonus when
    the residual is a size that has been observed often, since such a gap is
    more likely to be exactly filled by a future item.
    """
    global _TOTAL

    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0:
        _refresh_prob()

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    prob = _CACHED_PROB[residual]

    # Small bonus proportional to how likely the residual is to be fillable.
    # Optionally treat exact fits (residual 0) as maximally reusable.
    bonus = 20.0 * prob
    bonus = np.where(residual == 0, 20.0, bonus)

    return base + bonus
# EVOLVE-BLOCK-END

