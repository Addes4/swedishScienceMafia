# EVOLVE-BLOCK-START
"""Best fit with a small bonus for larger residuals to avoid tiny stranded gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Base is best fit (smallest post-placement residual), so tight fits dominate.
    We add a small bonus proportional to the residual so that when tight fits are
    comparable, we prefer leaving a larger (more reusable) gap rather than a tiny
    one that is likely to be stranded forever.
    """
    residual = (bins - item).astype(np.float64)  # >= 0 for all shown bins

    # Best-fit term dominates; residual bonus is a mild tie-breaker.
    score = -residual + 0.02 * residual
    return score
# EVOLVE-BLOCK-END
