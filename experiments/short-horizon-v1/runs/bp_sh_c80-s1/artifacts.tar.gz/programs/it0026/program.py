# EVOLVE-BLOCK-START
"""First fit: place the item in the lowest-index bin it fits in.

For Weibull-shaped sizes (mean ~40) consolidating early bins can reduce the
number of bins compared to best fit, which fragments capacity by always
filling the tightest residual.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = bins.shape[0]
    # Prefer the earliest bin (first fit): higher priority for lower index.
    return -np.arange(n, dtype=np.float64)
# EVOLVE-BLOCK-END

