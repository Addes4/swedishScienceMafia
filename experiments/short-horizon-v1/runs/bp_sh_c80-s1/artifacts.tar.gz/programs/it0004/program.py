# EVOLVE-BLOCK-START
"""Best fit with a mild worst-fit tie-break on near-perfect matches."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tight fits, but among near-equal leftovers prefer fuller bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item  # >= 0 for all shown bins
    # Best fit: smaller leftover is better -> negative leftover.
    score = -leftover.astype(np.float64)
    # Mild tie-break: among bins with similar leftover, prefer the one with larger
    # remaining capacity so that the resulting residual stays more flexible.
    score += 0.02 * bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
