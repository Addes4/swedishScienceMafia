# EVOLVE-BLOCK-START
"""Best fit with a fill-biased tie-break among near-equal residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    best = residual.min()
    # Bins close to the tightest fit: within a small tolerance window.
    near = residual <= (best + 1)
    # Among those, prefer the emptier bin (larger pre-placement capacity),
    # so tight gaps stay usable and residual space is consolidated.
    score = np.where(near, bins.astype(np.float64), -1e9 - residual.astype(np.float64))
    return score
# EVOLVE-BLOCK-END

