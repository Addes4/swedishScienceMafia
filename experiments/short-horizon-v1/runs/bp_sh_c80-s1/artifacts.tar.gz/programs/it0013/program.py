# EVOLVE-BLOCK-START
"""Worst-fit among bins that leave enough room to keep flexibility."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer bins whose residual is at least the item size (keeps a usable gap),
    # otherwise fall back to best fit (smallest residual).
    target = item
    has_room = residual >= target
    # Give bins with room a large positive score ordered by largest residual (worst fit),
    # and bins without room a negative score ordered by smallest residual (best fit).
    score = np.where(has_room, residual.astype(np.float64), -1e6 - residual.astype(np.float64))
    return score
# EVOLVE-BLOCK-END

