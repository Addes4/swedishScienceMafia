# EVOLVE-BLOCK-START
"""Best fit with a mild preference for fuller bins, using a quadratic residual penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Prefer bins where the leftover after placing is small (best fit), but
    # add a tiny extra penalty proportional to how empty the bin currently is.
    # This nudges choices toward already-loaded bins among near-ties.
    residual = bins - item
    return -(residual) - 0.01 * bins
# EVOLVE-BLOCK-END
