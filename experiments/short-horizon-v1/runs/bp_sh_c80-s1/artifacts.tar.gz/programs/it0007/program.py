# EVOLVE-BLOCK-START
"""Online bin packing via expected-waste minimization.

For each arriving item, estimate, using the empirical distribution of item sizes seen so
far in this stream, the expected wasted space that would result from placing the item into
each candidate bin.  Choose the bin minimizing that expected waste.  A best-fit term is
used as a prior/fallback so behaviour is robust early in the stream.
"""
import numpy as np

# state kept across calls within a stream
_hist = np.zeros(101, dtype=np.float64)   # count of seen item sizes (index 1..100)
_total = 0.0                              # number of seen items
_prior = None                             # smoothed prior over sizes 1..100


def _get_prior():
    """A gentle Weibull-ish prior (mean ~40) used before enough data accumulates."""
    global _prior
    if _prior is None:
        x = np.arange(1, 101, dtype=np.float64)
        k, lam = 1.6, 45.0
        dens = (k / lam) * (x / lam) ** (k - 1.0) * np.exp(-((x / lam) ** k))
        dens = dens + 1e-6
        _prior = dens / dens.sum()
    return _prior


def priority(item, bins):
    global _total
    # update empirical distribution with the current item
    _hist[item] += 1.0
    _total += 1.0

    # mixing weight for empirical vs prior
    w = _total / (_total + 30.0)
    emp = _hist[1:101] / max(_total, 1.0)
    probs = w * emp + (1.0 - w) * _get_prior()

    sizes = np.arange(1, 101, dtype=np.float64)
    pm = probs  # probability mass for each future size 1..100

    residual = bins - item  # remaining capacity after placing the item (>=0)

    # Expected waste if this bin is chosen and then we stop choosing it until a future
    # item fits exactly or we give up: model as expected residual mismatch.
    # For each possible future item size s (prob p_s), it fits if s <= residual.
    # If it fits, remaining residual becomes residual - s (waste if s == residual -> 0).
    # We approximate future waste by the expected value of (residual - s) given s <= residual
    # plus the event that no fitting future item appears before the stream churns.
    #
    # Practical proxy: prefer small residuals, but reward residuals that are exactly
    # matchable by likely sizes.
    fit_mask = sizes[None, :] <= residual[:, None]  # (nbins, 100)

    # probability that a random future item fits this bin
    fit_prob = (fit_mask * pm[None, :]).sum(axis=1)

    # expected leftover after placing one fitting future item (smaller is better)
    with np.errstate(divide="ignore", invalid="ignore"):
        exp_left = (fit_mask * (residual[:, None] - sizes[None, :]) * pm[None, :]).sum(axis=1)
        exp_left = np.where(fit_prob > 0, exp_left / np.maximum(fit_prob, 1e-12), residual)

    # expected waste: leftover that will likely never be filled -> approximate by
    # chance of no future match times residual (a bin left open) plus leftover.
    no_match = 1.0 - fit_prob
    exp_waste = no_match * residual + exp_left * fit_prob

    # combine with a light best-fit prior to stabilize early behaviour
    best_fit = residual.astype(np.float64)
    score = -(exp_waste + 0.25 * best_fit)
    return score
# EVOLVE-BLOCK-END
