# EVOLVE-BLOCK-START
"""Best fit with an online penalty for stranding improbable small residuals."""
import numpy as np


# Online histogram of item sizes seen so far (updated once per call).
_HIST = np.zeros(101, dtype=np.float64)   # counts for sizes 1..100
_TOTAL = 0.0
_RECOMPUTE_EVERY = 50
_CACHED_PROB = np.zeros(101, dtype=np.float64)
_CACHED_CDF = np.zeros(101, dtype=np.float64)


def _refresh_prob():
    global _CACHED_PROB, _CACHED_CDF
    if _TOTAL <= 0:
        _CACHED_PROB = np.zeros(101, dtype=np.float64)
        _CACHED_CDF = np.zeros(101, dtype=np.float64)
        return
    p = _HIST / _TOTAL
    _CACHED_PROB = p
    c = np.cumsum(p)
    c[c > 1.0] = 1.0
    _CACHED_CDF = c


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Base is best fit (smallest post-placement residual).  We add a penalty when
    the residual is hard to reuse: low exact-match probability, tempered by how
    much probability mass of smaller items could still fit in the residual.
    """
    global _TOTAL, _RECOMPUTE_EVERY

    # Record this item (post-decision, but item is given before we rank).
    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0:
        _refresh_prob()

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Probability that some future item exactly fills the residual.
    prob = _CACHED_PROB[residual]
    # Probability that some future item is small enough to fit in the residual.
    cdf = _CACHED_CDF[residual]

    # Penalize residuals unlikely to be reused, but soften for those that can
    # still absorb some small item.
    reuse = 0.7 * prob + 0.3 * cdf
    penalty = 70.0 * (1.0 - reuse)

    return base - penalty
# EVOLVE-BLOCK-END
