# EVOLVE-BLOCK-START
"""Best fit with a mild occupancy bias.

Classic best-fit minimizes the residual after placement, which for integer sizes
is optimal-ish; here we keep that as the dominant term but add a tiny bonus for
bins that are already more occupied (higher used fraction).  When two residuals
are close, packing further into a fuller bin consolidates space in the mostly
empty bins, which tends to help on Weibull(mean~40)/capacity-100 streams.
"""
import numpy as np


def priority(item, bins):
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item           # capacity left if placed here
    used_frac = (100.0 - bins) / 100.0
    # Dominant: smaller residual is better.  Tie-break: prefer fuller bins.
    return -residual + 1e-3 * used_frac
# EVOLVE-BLOCK-END
