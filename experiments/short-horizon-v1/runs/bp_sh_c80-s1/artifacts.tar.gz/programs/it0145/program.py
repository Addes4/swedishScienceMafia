# EVOLVE-BLOCK-START
"""Best fit with an online "usable residual" adjustment."""
import numpy as np


# Online decaying histogram of recently seen item sizes (halved occasionally).
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_CALLS = 0
_DECAY_EVERY = 500
_DECAY = 0.5


def _decay():
    global _HIST, _TOTAL
    _HIST *= _DECAY
    _TOTAL *= _DECAY


def priority(item, bins):
    """Highest score wins; ties go to first bin.

    Base: best fit (smallest post-placement residual), dominant term.
    Bonus: prefer residuals that are exact fills (0) or well-matched to
    common recent item sizes so the leftover space stays reusable.
    """
    global _TOTAL, _CALLS

    _HIST[item] += 1.0
    _TOTAL += 1.0
    _CALLS += 1
    if _CALLS % _DECAY_EVERY == 0:
        _decay()

    residual = bins - item  # >= 0
    base = -residual.astype(np.float64)

    # Empirical (decayed) probability of each residual size being a future item.
    if _TOTAL > 0:
        prob = _HIST[residual] / _TOTAL
    else:
        prob = np.zeros_like(base)

    # Strong bonus for exact fill (residual 0) and for residuals that are
    # commonly producible as a future item.
    exact = (residual == 0).astype(np.float64)
    bonus = 200.0 * exact + 40.0 * prob

    return base + bonus
# EVOLVE-BLOCK-END
