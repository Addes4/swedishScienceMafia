# EVOLVE-BLOCK-START
"""Best fit with a strong exact-fit bonus and a smooth Weibull-based reuse prior."""
import numpy as np

# Fixed, smooth prior: item sizes ~ Weibull(k~2, lambda~45), mean ~40, support 1..100.
_SIZES = np.arange(0, 101, dtype=np.float64)
_K = 2.0
_LAM = 45.0
# Weibull pdf evaluated at integer sizes (proportional weights).
_pdf = (_K / _LAM) * (_SIZES / _LAM) ** (_K - 1.0) * np.exp(-(_SIZES / _LAM) ** _K)
_pdf[0] = 0.0
_TOTAL_P = _pdf.sum()
_W = _pdf / _TOTAL_P if _TOTAL_P > 0 else _pdf  # normalized pmf-like weight


def priority(item, bins):
    """Score each fitting bin; highest wins (first on ties).

    Best fit (smallest residual) is primary. A large bonus rewards residuals equal
    to a typical future item size, and an extra bonus rewards near-exact small fills
    so that bins get closed out rather than left partially stranded.
    """
    residual = bins - item  # >= 0
    base = -residual.astype(np.float64)

    # Smooth probability that a future item exactly matches this residual size.
    prob = _W[residual]

    # Bonus for reusability of the leftover gap (peaks near typical item sizes).
    reuse_bonus = 200.0 * prob

    # Extra bonus for exact/near-exact fills to close small gaps.
    exact_bonus = np.where(residual == 0, 400.0, 0.0)

    return base + reuse_bonus + exact_bonus
# EVOLVE-BLOCK-END
