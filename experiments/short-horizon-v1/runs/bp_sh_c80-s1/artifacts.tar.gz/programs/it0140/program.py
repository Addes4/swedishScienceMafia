# EVOLVE-BLOCK-START
"""Best fit with a deterministic residual-matching tie-break."""
import numpy as np


def priority(item, bins):
    """Rank bins: smallest post-placement residual wins (best fit).

    Near-ties (residuals within a small window) are broken by preferring the bin
    that leaves a residual equal to the current item size, which a future item of
    the same size can exactly fill.  This is a purely deterministic, stateless
    refinement of best fit, avoiding the noisy online-histogram penalty.
    """
    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Prefer residuals that match the current item's own size (exact refill likely).
    match = (residual == item).astype(np.float64)

    # Small bounded bonus so it only breaks close best-fit choices.
    return base + 0.5 * match
# EVOLVE-BLOCK-END
