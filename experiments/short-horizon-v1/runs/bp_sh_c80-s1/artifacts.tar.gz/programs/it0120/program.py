# EVOLVE-BLOCK-START
"""Best fit with exact-fit reward and large-residual tie-breaking."""
import numpy as np


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Primary term is best fit (smallest post-placement residual).  We add a strong
    bonus for an exact fit (residual 0) and a tiny monotone bonus for larger
    residuals, since a larger residual is more likely to be reused by a future item.
    """
    residual = bins - item  # >= 0 for all shown bins
    residual = residual.astype(np.float64)

    base = -residual

    # Strong reward for filling a bin exactly.
    exact = (residual == 0).astype(np.float64) * 100.0

    # Tiny monotone nudge: prefer leaving a larger gap (more reusable).
    nudge = 0.001 * residual

    return base + exact + nudge
# EVOLVE-BLOCK-END
