# EVOLVE-BLOCK-START
"""Harmonic best-fit: reward small post-placement residual superlinearly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Concave, superlinear reward for small residuals; exact fit (residual 0) dominates.
    return 1000.0 / (residual + 1.0)
# EVOLVE-BLOCK-END
