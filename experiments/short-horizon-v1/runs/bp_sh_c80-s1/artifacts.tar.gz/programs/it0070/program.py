# EVOLVE-BLOCK-START
"""Thresholded best-fit/worst-fit hybrid for online bin packing.

Small items (size < 50) prefer the emptiest bin (worst fit) so they cluster
together and keep bins with little free room available.  Large items (size
>= 50) prefer the fullest fitting bin (best fit) since only one or two can
share a bin.  This reserves roomy bins for the large arrivals.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item >= 50:
        # Best fit: choose the fullest bin that still fits the item.
        return -(bins - item)
    # Worst fit: choose the emptiest bin (largest remaining capacity).
    return bins.astype(float)
# EVOLVE-BLOCK-END
