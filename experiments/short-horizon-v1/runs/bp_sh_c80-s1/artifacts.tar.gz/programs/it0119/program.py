# EVOLVE-BLOCK-START
"""Best fit with a fixed smooth complement-reuse bonus."""
import numpy as np


# Fixed smooth prior over item sizes 1..100, Weibull-shaped, mean ~40.
_SIZES = np.arange(101, dtype=np.float64)
# Approximate Weibull(k=2, lambda=45) pmf, normalized over 1..100.
_prior = (2.0 / 45.0) * (_SIZES / 45.0) * np.exp(-(_SIZES / 45.0) ** 2)
_prior[0] = 0.0
_prior /= _prior.sum()
# Map size -> probability, with a floor to avoid zero.
_PROB = _prior.copy()


def priority(item, bins):
    """Highest score wins. Base is best fit; small bonus for reusable residuals.

    Best fit minimizes the leftover gap (residual).  Additionally, a residual that
    equals a plausible future item size is more likely to be exactly filled later,
    so we add a modest bonus proportional to that probability.
    """
    residual = bins - item            # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Bonus for residuals that look like fillable complements.
    bonus = 20.0 * _PROB[residual]
    # Strong bonus for exact fits (residual 0) to lock them in.
    base = np.where(residual == 0, base + 1000.0, base)

    return base + bonus
# EVOLVE-BLOCK-END

