# EVOLVE-BLOCK-START
"""Best fit with an exact-fit bonus and a mild large-residual preference."""
import numpy as np


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Primary term is best fit (smallest post-placement residual).  We add:
      * a large bonus for an exact fit (residual 0),
      * a small preference for larger residuals, which tend to leave room for
        future items and reduce stranding of tiny unusable gaps.
    """
    residual = bins - item  # >= 0 for all shown bins

    score = -residual.astype(np.float64)

    # Small bonus for larger residuals (mild worst-fit tie-break).
    score += 0.05 * residual.astype(np.float64)

    # Strong bonus for exact fits.
    score += 1000.0 * (residual == 0)

    return score
# EVOLVE-BLOCK-END
