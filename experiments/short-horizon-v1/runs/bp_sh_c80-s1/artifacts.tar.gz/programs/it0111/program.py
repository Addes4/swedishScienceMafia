# EVOLVE-BLOCK-START
"""Best fit with a smooth fixed prior rewarding reusable residuals."""
import numpy as np


# Weibull-shaped item sizes, mean ~40. Build a smooth fixed pmf over sizes 1..100.
_SIZES = np.arange(101, dtype=np.float64)
_SHAPE = 2.0
_SCALE = 45.0  # tuned so mean ~40
_raw = np.exp(-((_SIZES / _SCALE) ** _SHAPE))
_raw[0] = 0.0
_PMF = _raw / _raw.sum()

# Probability that a residual r can be exactly filled by a single item.
_SINGLE = _PMF.copy()

# Probability that a residual r can be exactly filled by the sum of two items.
_TWO = np.zeros(101, dtype=np.float64)
for i in range(1, 101):
    pi = _PMF[i]
    if pi <= 0:
        continue
    # j from 1 to min(100, 100-i) so that i+j <= 100 (residual can appear)
    for j in range(1, 101 - i + 1):
        _TWO[i + j] += pi * _PMF[j]

# Combined "reusability" score for each possible residual (0..100).
_REUSE = _SINGLE + 0.5 * _TWO


def priority(item, bins):
    """Best-fit primary; small bonus for residuals likely to be exactly refilled."""
    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Bonus for residuals that can be cleanly reused by one or two future items.
    bonus = _REUSE[residual]

    # Scale so the bonus only breaks near-ties between comparable residuals.
    return base + 8.0 * bonus
# EVOLVE-BLOCK-END
