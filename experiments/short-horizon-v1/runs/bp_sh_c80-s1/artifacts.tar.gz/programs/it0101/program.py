# EVOLVE-BLOCK-START
"""Best fit modulated by how reusable the leftover capacity is."""
import numpy as np


# Online histogram of item sizes seen so far (updated once per call).
_HIST = np.zeros(101, dtype=np.float64)   # counts for sizes 1..100
_TOTAL = 0.0
_RECOMPUTE_EVERY = 40
_CACHED_PROB = np.zeros(101, dtype=np.float64)


def _refresh_prob():
    global _CACHED_PROB
    if _TOTAL <= 0:
        _CACHED_PROB = np.zeros(101, dtype=np.float64)
        return
    _CACHED_PROB = _HIST / _TOTAL


def priority(item, bins):
    """Highest score wins (first on ties).

    Primary term favors small post-placement residual (best fit).  A bonus is
    added when the residual is a size the stream actually produces, so leftover
    room that a future item is likely to fill exactly is preferred.
    """
    global _TOTAL

    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0:
        _refresh_prob()

    residual = (bins - item).astype(np.float64)
    base = -residual

    # Empirical chance a future item exactly fills this residual.
    prob = _CACHED_PROB[np.clip(bins - item, 0, 100).astype(np.int64)]

    # Bonus for reusability, capped so it largely refines rather than overturns
    # the best-fit ordering between clearly different residuals.
    bonus = 25.0 * prob

    # Extra strong preference for exact fits (residual 0).
    exact = 40.0 * (residual == 0.0)

    return base + bonus + exact
# EVOLVE-BLOCK-END
