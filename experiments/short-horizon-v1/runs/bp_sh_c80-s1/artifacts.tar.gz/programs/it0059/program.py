# EVOLVE-BLOCK-START
"""Best fit with a small mean-residual tie-break, which keeps bins reusable."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit -> smaller residual is better.
    # Secondary (small): prefer a residual near the item mean so the leftover
    # space is likely to be reusable by a future item, not a dead fragment.
    score = -residual.astype(np.float64) - 0.02 * np.abs(residual - 40.0)
    return score
# EVOLVE-BLOCK-END

