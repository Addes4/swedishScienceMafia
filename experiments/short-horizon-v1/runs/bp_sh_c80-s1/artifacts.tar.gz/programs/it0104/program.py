# EVOLVE-BLOCK-START
"""Best fit with a smoothed, fast-converging reuse bonus for post-placement residuals."""
import numpy as np


# Online histogram of item sizes seen so far (updated once per call).
_HIST = np.zeros(101, dtype=np.float64)   # counts for sizes 1..100
_TOTAL = 0.0

# Fixed prior over item sizes (Weibull-shaped, mean ~40). This keeps the estimate
# stable early in a stream before the empirical histogram has converged.
_PRIOR = np.exp(-((np.arange(101, dtype=np.float64) / 40.0) ** 1.5))
_PRIOR[0] = 0.0
_PRIOR /= _PRIOR.sum()

# Blending weight for the prior (pseudo-count scale).
_PRIOR_STRENGTH = 200.0

_CACHED_PROB = _PRIOR.copy()
_RECOMPUTE_EVERY = 25


def _refresh_prob():
    global _CACHED_PROB
    if _TOTAL <= 0:
        _CACHED_PROB = _PRIOR.copy()
        return
    # Blend empirical counts with the fixed prior.
    blended = _HIST + _PRIOR_STRENGTH * _PRIOR
    _CACHED_PROB = blended / blended.sum()


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Primary is best fit (smallest post-placement residual).  We add a bonus when the
    residual r is a size the smoothed item distribution is likely to produce again,
    since such a gap is more likely to be reused by a future item.
    """
    global _TOTAL

    # Record this item before ranking (item is given).
    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0:
        _refresh_prob()

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Probability that some future item exactly fills the residual.
    prob = _CACHED_PROB[residual]

    # Bonus for residuals that are likely reusable. Scale modestly so it shapes
    # close best-fit decisions without overturning clear ones.
    bonus = 25.0 * prob

    return base + bonus
# EVOLVE-BLOCK-END
