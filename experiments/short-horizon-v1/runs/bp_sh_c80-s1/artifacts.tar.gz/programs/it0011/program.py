# EVOLVE-BLOCK-START
"""Histogram-based expected-fill best fit."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Rank bins by how well the residual after placement matches future items.

    Maintains a running histogram of seen item sizes and scores each bin by the
    expected number of additional items required to fill the residual, i.e. the
    future "cost" of leaving that residual. Smaller expected cost is better.
    """
    global _hist, _count

    n = bins.shape[0]

    # Update running histogram with the arriving item.
    _hist[item] += 1.0
    _count += 1.0

    # Empirical item-size distribution (normalized).
    dist = _hist / _count
    sizes = np.arange(101, dtype=np.float64)

    # Expected number of future items needed to consume `r` remaining capacity.
    # e[r] = 1 + sum_s dist[s] * e[r-s]  (approx; a small DP).
    # We precompute lazily up to 100 each call.
    E = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        acc = 0.0
        s = sizes[1:r + 1]
        # expected future fills: 1 + weighted E of remaining
        acc = 1.0 + float(np.dot(dist[1:r + 1], E[(r - sizes[1:r + 1]).astype(np.int64)]))
        E[r] = acc

    residual = bins - item  # >= 0 since bins only include fitting bins
    residual = np.clip(residual, 0, 100).astype(np.int64)

    # Score: prefer smaller expected future fill count (higher score).
    return -E[residual]
# EVOLVE-BLOCK-END
