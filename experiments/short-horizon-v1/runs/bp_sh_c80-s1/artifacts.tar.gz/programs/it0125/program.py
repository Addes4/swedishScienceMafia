# EVOLVE-BLOCK-START
"""Best fit with a smooth analytic prior over reusable residuals."""
import numpy as np


def priority(item, bins):
    """Rank fitting bins; highest score wins (first on ties).

    Core idea: prefer the bin whose leftover is an exact fit (residual 0), since
    that wastes nothing.  Otherwise, avoid stranding a tiny leftover (hard to
    ever fill) and mildly prefer leftovers that are themselves near a typical
    item size, so they remain reusable.  Weibull(shape~1.5, scale~45) is a fixed
    smooth stand-in for the item distribution, so no noisy online state is used.
    """
    residual = (bins - item).astype(np.float64)

    # Penalty for stranding a small unusable gap.  Bigger residuals are more
    # likely to be refilled later, so reward them on a gentle concave scale.
    small_pen = np.where(residual < 15.0,
                         4.0 * (15.0 - residual),
                         0.0)

    # Mild bonus proportional to residual, capped, so we do not always chase
    # huge gaps but do favor fuller, more reusable leftovers over tiny ones.
    size_bonus = np.minimum(residual, 60.0) * 0.30

    # Reward residuals close to a typical item size (likely refillable).
    typical = np.exp(-0.5 * ((residual - 42.0) / 22.0) ** 2) * 6.0

    # Strong reward for exact fits.
    exact = np.where(residual < 0.5, 40.0, 0.0)

    return size_bonus + typical + exact - small_pen
# EVOLVE-BLOCK-END

