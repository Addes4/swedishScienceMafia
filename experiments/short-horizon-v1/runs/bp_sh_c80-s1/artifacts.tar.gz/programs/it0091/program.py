# EVOLVE-BLOCK-START
"""Best fit blended with a reusable-residual score.

Maintains an online histogram of item sizes.  For each fitting bin we compute
the post-placement residual and score it by:
  - a strong bonus for exact/near-exact fills (residual is a common item size),
  - plus a bonus for residuals large enough to accept a typical item,
  - minus a penalty for residuals that are too small to be refilled.
The combination is nonlinear so it can overturn close best-fit choices.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_RECOMPUTE_EVERY = 25
_CDF = np.zeros(101, dtype=np.float64)   # P(size <= r)
_PMF = np.zeros(101, dtype=np.float64)   # P(size == r)
_MEAN = 40.0


def _refresh():
    global _CDF, _PMF, _MEAN
    if _TOTAL <= 0:
        _CDF = np.zeros(101, dtype=np.float64)
        _PMF = np.zeros(101, dtype=np.float64)
        return
    pmf = _HIST / _TOTAL
    _PMF = pmf
    _CDF = np.cumsum(pmf)
    sizes = np.arange(101, dtype=np.float64)
    _MEAN = float(np.dot(pmf, sizes)) or 40.0


def priority(item, bins):
    global _TOTAL
    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0:
        _refresh()

    residual = bins.astype(np.int64) - item
    # residual >= 0 for all fitting bins

    r = residual.astype(np.float64)

    # Exact / near-exact fill bonus: prob a future item equals the residual.
    exact = _PMF[residual]

    # Reuse potential: probability some future item is <= residual (so gap fillable).
    # Convert to a bonus bounded in [0,1].
    fill_p = _CDF[residual]

    # Penalty for very small residuals that can rarely be filled.
    # (1 - fill_p) is high when residual is tiny.
    strand = 1.0 - fill_p

    # Reward small residuals (best fit) but modulated by reusability.
    # Normalize residual to [0,1] by capacity 100.
    base = -r / 100.0

    # Strong bonus for exact fits; moderate bonus for reusable gaps.
    score = base + 1.5 * exact + 0.35 * fill_p - 0.6 * strand

    return score
# EVOLVE-BLOCK-END
