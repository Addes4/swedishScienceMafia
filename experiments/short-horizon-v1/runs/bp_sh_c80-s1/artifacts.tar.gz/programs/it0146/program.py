# EVOLVE-BLOCK-START
"""Best fit with a stranding penalty based on the smallest recently seen item."""
import numpy as np


# Online estimate of the smallest item size seen recently (items are i.i.d.).
_MIN_SEEN = 100.0
_ALPHA = 0.02  # decay so the estimate tracks the distribution's lower tail


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Base is best fit (smallest post-placement residual).  We add a penalty on the
    residual r to discourage creating gaps too small to be filled by any typical
    future item, and to encourage draining bins before opening fresh ones.
    """
    global _MIN_SEEN

    # Update the running estimate of a typical minimum item size.
    if item < _MIN_SEEN:
        _MIN_SEEN = float(item)
    else:
        _MIN_SEEN = (1.0 - _ALPHA) * _MIN_SEEN + _ALPHA * float(item)

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # residual == 0 is a perfect fill: no penalty.
    # residual >= item: the gap could still hold a same-sized item: mild penalty for
    #   remaining wasted space, but this same "wasted space" term is what drains
    #   partially-full bins, so keep it gentle and monotone.
    # residual in (0, min_seen): likely stranded forever: strong penalty.
    min_seen = max(_MIN_SEEN, 1.0)
    too_small = np.clip((min_seen - residual) / min_seen, 0.0, 1.0)

    # Small residual (but not zero) is also slightly bad: it means the bin can hold
    # only very small items from now on.
    residual_pen = residual / 100.0

    penalty = 25.0 * too_small + 3.0 * residual_pen * (residual > 0.0)

    return base - penalty
# EVOLVE-BLOCK-END
