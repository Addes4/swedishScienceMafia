# EVOLVE-BLOCK-START
"""Residual-aware best fit: keep bin leftovers reusable.

Items arrive online. Pure best-fit minimizes the immediate leftover, but a leftover
just below the typical item size is wasted space that no future item can use. Here we
prefer, among fitting bins, the tightest fit whose post-placement residual is either 0
(perfect fill) or large enough to plausibly host more items. If every tight fit leaves
an awkward fragment, we instead put the item in the emptiest fitting bin so the
remaining free space stays contiguous and reusable.
"""
import numpy as np

# Threshold above which a leftover is considered reusable. The item distribution is
# Weibull-shaped with mean ~40, so a decent fraction of items are <= ~45; leaving at
# least this much space keeps a bin open for more items.
_REUSE = 50


def priority(item, bins):
    """Score each candidate bin; highest score wins (first on ties).

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (all bins the item fits).
    """
    residual = bins - item  # post-placement leftover for each bin

    # Perfect fills are always best: give them top priority.
    perfect = (residual == 0)

    # "Good" bins leave a leftover that is either 0 or >= _REUSE (reusable space).
    good = (residual == 0) | (residual >= _REUSE)

    # Primary: prefer good bins. Secondary within good bins: tightest fit (smallest
    # residual) so we consume space efficiently. Within non-good bins, we invert the
    # preference and use the emptiest bin (largest residual) to avoid piling up small
    # unusable fragments -- the item goes to a bin with the most contiguous free space.
    score = np.where(good, -residual, residual)

    # Encode the good/perfect preference as a large offset on the chosen ordering.
    score = score + np.where(good, 1_000.0, 0.0) + np.where(perfect, 1_000_000.0, 0.0)
    return score
# EVOLVE-BLOCK-END

