# EVOLVE-BLOCK-START
"""Harmonic-flavored best fit: prefer tight fits but reward residuals that stay usable."""
import numpy as np


def priority(item, bins):
    """Score each bin; item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin (unused -> 100),
          in bin order.
    """
    rem_after = bins - item  # residual capacity if placed here (>= 0)

    # Dominant term: smaller residual is better (best-fit). We use a concave
    # transform so that exact fits (residual 0) are hugely favoured, and small
    # residuals are strongly but smoothly preferred over larger ones.
    score = -np.sqrt(rem_after.astype(np.float64) + 1.0)

    # Bonus: a residual of exactly 0 is the ideal (perfect fill).
    score += 1000.0 * (rem_after == 0)

    return score
# EVOLVE-BLOCK-END
