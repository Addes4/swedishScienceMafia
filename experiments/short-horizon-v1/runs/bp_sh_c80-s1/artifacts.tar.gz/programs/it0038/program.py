# EVOLVE-BLOCK-START
"""Best fit with a reusable-residual tie-break.

Primary score is the (negated) post-placement residual, so the
tightest-fitting bin wins (classic best fit). A small secondary term
rewards bins whose remaining capacity after placement can still hold a
typical item from the distribution (mean ~40), discouraging leftovers
that can no longer be used. The bonus is small enough never to override
a genuinely tighter fit by a meaningful margin.
"""
import numpy as np


def priority(item, bins):
    bins = np.asarray(bins)
    residual = bins - item  # >= 0 for all shown bins
    # Primary: tightest fit (smallest residual wins -> larger score).
    primary = -residual.astype(np.float64)
    # Secondary: reward residuals that can still fit a typical item.
    typical = 40.0
    reusable = np.minimum(residual, 1) * 0.0  # placeholder, see below
    # Count how many typical items the residual can still hold (0,1,2,...).
    count = np.floor_divide(residual, int(typical)).astype(np.float64)
    # Small bonus: more reusable capacity is slightly better.
    bonus = 0.05 * count
    # Extra tiny bonus for exactly filling a bin.
    perfect = (residual == 0).astype(np.float64) * 0.05
    return primary + bonus + perfect
# EVOLVE-BLOCK-END

