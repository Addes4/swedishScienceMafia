# EVOLVE-BLOCK-START
"""Best fit with a light bonus for residuals matching common recent item sizes."""
import numpy as np

# Online counts of item sizes seen so far (updated once per call).
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_EVERY = 25
_CACHED_PROB = np.zeros(101, dtype=np.float64)


def _refresh():
    global _CACHED_PROB
    if _TOTAL > 0:
        _CACHED_PROB = _HIST / _TOTAL


def priority(item, bins):
    """Rank bins: best fit (smallest residual) plus a bonus when the residual
    is a size that has appeared often recently (so a future exact fill is likely).
    """
    global _TOTAL
    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _EVERY == 0:
        _refresh()

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Bonus proportional to how likely the residual size is to arrive next.
    bonus = 40.0 * _CACHED_PROB[residual]

    # Strong boost for exact fits so they always win.
    exact = (residual == 0).astype(np.float64)

    return base + bonus + 1e6 * exact
# EVOLVE-BLOCK-END
