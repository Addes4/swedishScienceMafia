# EVOLVE-BLOCK-START
"""Best fit with a smooth residual-magnitude penalty."""
import numpy as np


def priority(item, bins):
    """Score bins by post-placement residual; prefer small, non-stranding residuals."""
    residual = bins - item  # >= 0 for all shown bins
    # Strongly prefer smallest residual (classic best fit),
    # with a slight extra preference for residuals that keep room for a typical item.
    base = -residual.astype(np.float64)
    # Mild concave bonus for larger residual bins so they aren't all killed,
    # while exact/small residuals still dominate.
    bonus = 3.0 * np.sqrt(residual.astype(np.float64))
    return base + bonus
# EVOLVE-BLOCK-END
