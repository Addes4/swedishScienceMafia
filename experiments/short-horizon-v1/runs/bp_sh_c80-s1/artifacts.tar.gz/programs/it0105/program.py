# EVOLVE-BLOCK-START
"""Best fit with exact-fit bonus and a guard against stranding unusable tiny gaps."""
import numpy as np


# Online stats: smallest item size seen so far (drives the minimum usable residual).
_MIN_SEEN = 101  # sentinel larger than any item


def priority(item, bins):
    """Rank bins by best fit, but protect against stranding unusable residuals.

    Primary: smallest post-placement residual (best fit).
    Bonus:   exact fit (residual 0) is strongly preferred.
    Penalty: a residual smaller than the smallest item seen so far is almost surely
             dead weight, so penalize heavily; it only fires when no better option
             with a usable residual exists.
    """
    global _MIN_SEEN
    if item < _MIN_SEEN:
        _MIN_SEEN = item

    residual = bins - item  # >= 0 for all shown bins
    resid = residual.astype(np.float64)

    # Best fit primary, with an exact-fit bonus.
    base = -resid
    exact_bonus = np.where(residual == 0, 1000.0, 0.0)

    # Penalize residuals strictly below the smallest item seen (unusable gaps).
    min_usable = float(_MIN_SEEN)
    dead = np.where((resid > 0.0) & (resid < min_usable), 1.0, 0.0)
    penalty = 500.0 * dead

    return base + exact_bonus - penalty
# EVOLVE-BLOCK-END

