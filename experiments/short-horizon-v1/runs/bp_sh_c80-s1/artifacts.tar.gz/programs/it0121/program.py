# EVOLVE-BLOCK-START
"""Pure best fit: place each item into the bin with the smallest residual capacity."""
import numpy as np


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Best fit: a bin with residual r after placing the item gets score -r, so the
    smallest residual (tightest fit) is chosen.  No state, no noise.
    """
    residual = bins - item  # >= 0 for all shown bins
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
