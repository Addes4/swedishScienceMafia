# EVOLVE-BLOCK-START
"""Best fit with dust-avoidance: avoid leaving residuals too small to ever be reused."""
import numpy as np


_MIN_ITEM = 1


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _MIN_ITEM

    # Update running estimate of the smallest item seen (conservative floor).
    if item < _MIN_ITEM:
        _MIN_ITEM = item

    residual = bins - item  # post-placement remaining capacity (>= 0 for fitting bins)

    # Best-fit ordering: smaller residual -> better (higher score).
    score = -residual.astype(np.float64)

    # Penalize residuals that are positive but too small to hold any future item,
    # i.e. "dust" that is permanently wasted. Avoid creating such dust if we can.
    min_size = _MIN_ITEM if _MIN_ITEM > 0 else 1
    dust = (residual > 0) & (residual < min_size)
    score[dust] -= 1e6

    return score
# EVOLVE-BLOCK-END
