# EVOLVE-BLOCK-START
"""Best-fit variant that avoids leaving unusable residual fragments."""
import numpy as np


def priority(item, bins):
    """Rank bins so the item goes to the best bin (highest score, first wins).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 for all shown bins

    # A "usable" residual is 0 (perfect fill) or large enough to hold a typical item.
    # We use a conservative threshold: residuals below the item's own size tend to be
    # wasted gaps, so we prefer the fullest bin that leaves a usable residual.
    usable = (residual == 0) | (residual >= item)

    # Among usable-residual bins prefer the fullest (smallest residual, but tie-broken
    # toward exact fits); among the rest fall back to tightest fit.
    # Primary key: usable first. Secondary: smallest residual.
    score = np.where(usable, 1_000_000, 0) - residual
    return score
# EVOLVE-BLOCK-END
