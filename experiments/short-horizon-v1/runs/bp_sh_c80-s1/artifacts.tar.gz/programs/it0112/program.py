# EVOLVE-BLOCK-START
"""Best fit with a smooth parametric prior rewarding residuals that look like items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Primary term is best fit (smallest post-placement residual), so exact fills
    dominate.  A smooth prior bonus rewards residuals near a typical item size
    (~40), since those gaps are most likely to be exactly filled later, while
    a mild penalty discourages leaving awkward large residuals.
    """
    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Smooth reward for residuals that resemble a plausible item size.
    # Peak around 40 (distribution mean), Gaussian-like, bounded to [0, 1].
    r = residual.astype(np.float64)
    fit_bonus = np.exp(-((r - 40.0) / 35.0) ** 2)

    # Small bonus for near-exact fits (residual close to 0) is already handled
    # by the dominant base term, so keep this modest.
    return base + 3.0 * fit_bonus
# EVOLVE-BLOCK-END
