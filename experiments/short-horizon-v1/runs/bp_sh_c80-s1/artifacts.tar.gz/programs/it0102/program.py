# EVOLVE-BLOCK-START
"""Convex-potential bin choice: prefer exact fits, then small squared residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Exact fits are strongly preferred (residual 0).  Otherwise we minimize the
    convex potential residual**2, which corresponds to a sum-of-squares style
    rule: keeping a single bin's residual as large as possible (i.e. not making
    awkward medium residuals) tends to preserve future packing flexibility and
    is known to be competitive for Weibull-like item distributions.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Exact fit gets a decisive bonus.
    exact_bonus = np.where(residual == 0, 1e6, 0.0)

    # Convex potential: smaller residual^2 is better (higher score => negate).
    potential = residual.astype(np.float64) ** 2

    # Best fit (smallest positive residual) as a fine tie-break.
    return exact_bonus - potential - 1e-3 * residual
# EVOLVE-BLOCK-END

