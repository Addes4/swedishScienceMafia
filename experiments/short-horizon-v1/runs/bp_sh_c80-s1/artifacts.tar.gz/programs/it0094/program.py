# EVOLVE-BLOCK-START
"""Best fit with a bounded' reusability' tie-break favoring residuals that are
likely to be exactly filled by a future item."""
import numpy as np


_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_RECOMPUTE_EVERY = 32
_CACHED_PROB = np.zeros(101, dtype=np.float64)


def _refresh_prob():
    global _CACHED_PROB
    if _TOTAL <= 0:
        _CACHED_PROB = np.zeros(101, dtype=np.float64)
        return
    _CACHED_PROB = _HIST / _TOTAL


def priority(item, bins):
    global _TOTAL

    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0:
        _refresh_prob()

    residual = bins - item  # >= 0

    # Primary: best fit (smallest residual).
    base = -residual.astype(np.float64)

    # Secondary: reward residuals that the empirical item pmf is likely to fill,
    # scaled strictly below 1 so it can only break exact residual ties, never
    # overturn a strictly smaller residual.
    prob = _CACHED_PROB[residual]
    bonus = np.minimum(prob, 0.99)

    return base + bonus
# EVOLVE-BLOCK-END
