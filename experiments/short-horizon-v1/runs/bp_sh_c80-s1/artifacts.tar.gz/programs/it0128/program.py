# EVOLVE-BLOCK-START
"""Best fit with a small continuous tie-breaker toward refillable residuals."""
import numpy as np

# Analytic prior over item sizes (index 1..100), approximating the Weibull-shaped
# distribution (mean ~40).  Used only as a gentle tie-breaker, never to overturn
# a genuine best-fit (smaller residual) decision.
_TABLE = np.zeros(101, dtype=np.float64)
for _s in range(1, 101):
    _x = _s / 100.0
    # Rough Weibull(k=2, lambda~45) density on 0..100, plus flat tail mass.
    _k, _lam = 2.0, 45.0
    _d = (_k / _lam) * (_x * 100.0 / _lam) ** (_k - 1.0) * np.exp(-(_x * 100.0 / _lam) ** _k)
    _TABLE[_s] = _d + 0.002
_TABLE[0] = 0.0
_TABLE /= _TABLE.sum()


def priority(item, bins):
    """Highest score wins; ties go to the first bin.

    Primary term: best fit (smallest residual).  Secondary term: a tiny bonus
    proportional to the analytic probability that the residual will be exactly
    filled by some future item -- resolves near-ties toward more reusable gaps
    without changing the ordering of clearly different residuals.
    """
    residual = bins - item  # >= 0
    # Strongly prefer smaller residual; scale keeps best-fit strictly dominant.
    base = -1000.0 * residual.astype(np.float64)
    # Gentle tie-breaker: probability mass of an exact fill at the residual size.
    bonus = 1000.0 * _TABLE[residual]
    return base + bonus
# EVOLVE-BLOCK-END
