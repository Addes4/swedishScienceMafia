# EVOLVE-BLOCK-START
"""Worst-fit: place each item into the emptiest fitting bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Worst-fit sends the item to the bin with the most remaining capacity.
    For a Weibull-shaped size distribution (many small items, few large ones),
    this keeps many bins partially open, letting smalls coalesce and reserving
    nearly-empty bins so large items are less likely to be stranded.
    """
    return bins.astype(np.float64)
# EVOLVE-BLOCK-END
