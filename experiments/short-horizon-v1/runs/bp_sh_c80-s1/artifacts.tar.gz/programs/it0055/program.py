# EVOLVE-BLOCK-START
"""Best fit with a running-mean-aware residual tie-break."""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["sum"] += item
    _state["count"] += 1
    mean = _state["sum"] / _state["count"]

    # Primary: best fit (smallest remaining capacity after placement => most negative residual).
    residual = bins - item

    # Tie-break: for near-equal post-placement residuals, prefer the residual closest to
    # the running mean item size, so the leftover space stays usable by future items.
    # Exact fits (residual 0) get a strong bonus since they waste nothing.
    exact = (residual == 0)
    closeness = -np.abs(residual - mean)

    # Best fit dominates; closeness only breaks ties among equal residuals.
    # Scale closeness so it never overtakes a one-unit residual difference:
    # residual differences are integers, so a bonus in (-0.5, 0.5) is safe.
    bonus = 0.4 * np.tanh(closeness / 20.0)

    score = -residual.astype(np.float64) + bonus
    score[exact] += 1.0  # strongly prefer exact fits
    return score
# EVOLVE-BLOCK-END
