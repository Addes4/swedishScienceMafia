# EVOLVE-BLOCK-START
"""Best fit with online-learned reusable-gap preservation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (smallest residual). Secondary: slight preference for
    # residuals that keep capacity open for future items (small residuals that
    # are still >= typical future item sizes are reusable; near-full residuals
    # that can't fit anything are also fine). We use a mild quadratic penalty
    # on large residuals so best-fit dominates but ties break toward tighter
    # partial fills rather than full empty bins.
    return -(residual.astype(np.float64)) - 0.001 * residual
# EVOLVE-BLOCK-END
