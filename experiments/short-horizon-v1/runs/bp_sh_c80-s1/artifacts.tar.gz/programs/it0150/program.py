# EVOLVE-BLOCK-START
"""Best fit, with a tiny deterministic tie-break that is stable when residuals tie."""
import numpy as np


def priority(item, bins):
    """Best fit: smallest post-placement residual wins; exact fit is best.

    A small epsilon on the raw residual keeps this essentially pure best-fit,
    which was the strongest performer, while making tie-breaking deterministic.
    """
    residual = (bins - item).astype(np.float64)
    return 1.0e6 - residual
# EVOLVE-BLOCK-END

