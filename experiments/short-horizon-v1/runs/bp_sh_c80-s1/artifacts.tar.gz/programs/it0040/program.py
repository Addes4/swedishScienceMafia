# EVOLVE-BLOCK-START
"""Best fit with reuse-aware tie-breaking.

Primary rule: put the item in the bin it fits most tightly (minimize residual).
Tie-break: among the tightest options, prefer residuals that stay "reusable":
  - residual 0 (perfect fill) is best,
  - a residual >= item size means the leftover can hold another like-sized item.
Otherwise keep the first (best-fit) bin so the strong baseline is preserved.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all shown bins
    # Dominant term: prefer smaller residual (tighter fit). Scale large so ties
    # are decided only within residual neighborhoods.
    primary = -residual.astype(np.float64)

    # Small reuse bonus: perfect fit (residual 0) or residual that can still hold
    # another item of the same size.
    bonus = np.zeros_like(primary)
    bonus[residual == 0] += 0.5
    bonus[residual >= item] += 0.25

    return primary + bonus
# EVOLVE-BLOCK-END
