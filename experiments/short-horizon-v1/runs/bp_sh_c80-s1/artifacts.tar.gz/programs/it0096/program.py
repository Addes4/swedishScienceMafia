# EVOLVE-BLOCK-START
"""Plain best fit with a fixed, distribution-informed tie-break on residuals."""
import numpy as np


def priority(item, bins):
    """Rank fitting bins by smallest residual; ties broken by reuse potential.

    Primary term: best fit (prefer the smallest post-placement residual).
    Tiny secondary term: among bins whose residual is close, favor residuals that
    can still exactly accept a typical future item, without using any noisy
    online histogram. This shaping is fixed and distribution-agnostic.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary: strongest preference for the smallest residual.
    base = -residual.astype(np.float64)

    # Fixed, bounded secondary shaping: favor residuals that are exactly 0
    # (perfect fill) and residual values that are "round enough" to be likely
    # future item sizes. Keep amplitude tiny so it only breaks near-ties.
    r = residual.astype(np.float64)
    # Encourage exact fill strongly but bounded.
    exact = np.where(r == 0.0, 1.0, 0.0)
    # A mild concave bonus: smaller residuals preferred, but not linearly only.
    mild = -0.02 * r

    return base + 0.5 * exact + mild
# EVOLVE-BLOCK-END
