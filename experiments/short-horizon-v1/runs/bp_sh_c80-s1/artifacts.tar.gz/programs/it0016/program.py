# EVOLVE-BLOCK-START
"""Best-fit with a histogram-aware tie-break for near-tight residuals."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running histogram of past item sizes.
    try:
        sz = int(item)
        if 1 <= sz <= 100:
            _state.hist[sz] += 1.0
            _state.count += 1.0
    except Exception:
        pass

    # Post-placement residual.
    resid = (bins - item).astype(np.float64)  # >= 0 for fitting bins

    # Base score: strict best fit -> smallest residual gets highest score.
    base = -resid

    # Histogram-aware refinement: reward residuals that are close to a common
    # incoming item size (so the leftover gap can be filled later).
    if _state.count > 0:
        total = _state.count + 1.0
        # Probability mass of sizes strictly smaller/equal to each residual.
        # We want residual to match a likely item size; weight by empirical prob.
        max_res = int(resid.max()) if resid.size else 0
        if max_res > 100:
            max_res = 100
        # A residual r is "good" if there's high probability of an item exactly == r
        # OR r is a small residual (fully packed-ish). Combine smoothly.
        size_prob = _state.hist / total  # index by size, [0..100]
        # For each bin, look up prob of an item equal to its residual (clamped).
        r_int = np.clip(resid.astype(np.int64), 0, 100)
        match = size_prob[r_int]
        # Small epsilon so it only breaks near-ties, not clear best-fit wins.
        refine = 1e-3 * match
    else:
        refine = 0.0

    # For very large items, prioritize minimizing residual waste directly (still best-fit).
    # Combine: primary is best-fit; refinement breaks near-ties.
    return base + refine
# EVOLVE-BLOCK-END
