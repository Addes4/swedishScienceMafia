# EVOLVE-BLOCK-START
"""Best fit with a perfect-fill tie bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # strict best fit: smallest residual is best
    score = -residual.astype(np.float64)
    # small bonus for a perfect fill (residual == 0)
    score += (residual == 0) * 0.5
    return score
# EVOLVE-BLOCK-END

