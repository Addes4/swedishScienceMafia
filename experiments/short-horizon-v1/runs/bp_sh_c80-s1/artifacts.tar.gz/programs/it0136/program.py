# EVOLVE-BLOCK-START
"""Best fit with a mild self-similarity bonus for leaving a residual equal to item size."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer smallest residual (best fit), with a bonus for
    residuals equal or close to the current item size, which is the most
    likely size to arrive next and exactly refill the gap."""
    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Bonus: residual equal to item size -> next same-size item fills exactly.
    # Mild so best-fit dominance is preserved but near-ties flip here.
    bonus = np.where(residual == item, 1.0, 0.0)

    return base + bonus
# EVOLVE-BLOCK-END
