# EVOLVE-BLOCK-START
"""Best fit with an online-learned gap-size preference.

Pure best fit leaves the tightest residual. For a Weibull-shaped stream
(mean ~40) many residuals are large enough to still accept small items, but
a residual just barely able to take a common small size is more useful than
one that is a bit tighter yet cannot. We learn a running histogram of item
sizes and mildly prefer residuals that can accept common sizes, while keeping
best fit as the dominant criterion.
"""
import numpy as np

# Histogram of observed item sizes (index 0..100).  Persistent per-process;
# it carries over calls within a stream, which is allowed.
_SIZE_COUNT = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority per fitting bin; highest wins (first on ties)."""
    global _TOTAL
    _SIZE_COUNT[item] += 1.0
    _TOTAL += 1.0

    residual = bins - item  # >= 0 for all shown bins

    # Dominant criterion: smallest residual (best fit). Scale to a fine unit.
    score = -residual.astype(np.float64) * 1000.0

    # Secondary: mild bonus if this residual can still fit a commonly seen
    # size (so the gap is not wasted). Prefer smaller such sizes slightly.
    if _TOTAL > 0:
        # Probability mass for sizes s <= residual, weighted toward small s.
        cum = np.cumsum(_SIZE_COUNT[:101]) / _TOTAL  # cum[s] = P(size<=s)
        fit_mass = cum[np.clip(residual, 0, 100)]
        score += fit_mass
    else:
        score += 0.0

    return score
# EVOLVE-BLOCK-END
