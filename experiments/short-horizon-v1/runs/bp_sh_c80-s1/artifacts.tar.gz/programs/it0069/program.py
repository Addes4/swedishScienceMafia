# EVOLVE-BLOCK-START
"""Best fit with an adaptive residual-reusability tie-break.

Primary rule: put the item in the bin it fits most tightly (minimize resulting
residual).  Among placements that leave a similar residual, gently prefer a
residual that looks like a "typical" future item size, so bins stay reusable.
The typical size is estimated online from past items (mean of observed sizes),
so the rule never sees the future.  The bonus is tiny so it only breaks near-ties.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    # Resulting residual after placing the item in each shown bin.
    residual = bins - item

    # ---- online estimate of a "typical" item size (state kept between calls) ----
    state = priority.state
    if state is None:
        state = priority.state = {"n": 0, "mean": 40.0}
    state["n"] += 1
    n = state["n"]
    # running mean, updated with the item we just saw (used for FUTURE items only)
    mean = state["mean"]
    target = mean

    # ---- primary: best fit, i.e. smallest residual ----
    score = -residual.astype(np.float64)

    # ---- tiny adaptive bonus for residuals close to a typical item size ----
    # (residual near `target` => the leftover bin is likely to be reusable)
    diff = np.abs(residual - target).astype(np.float64)
    bonus = -0.25 * diff  # weak, magnitudes < ~25, only breaks near-ties

    prio = score + bonus

    # update the running mean for the next call
    mean = mean + (item - mean) / n
    state["mean"] = mean

    return prio
# EVOLVE-BLOCK-END

priority.state = None
