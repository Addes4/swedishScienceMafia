# EVOLVE-BLOCK-START
"""Best fit with a mild exact-complement bonus tied to the current item size."""
import numpy as np


def priority(item, bins):
    """Rank bins: best fit dominant, with a mild bonus when residual equals item.

    The item goes where the post-placement residual is smallest (best fit).
    We add a small bonus when the residual equals the current item size, since
    the item distribution is unimodal with mean ~40, so a residual equal to a
    recently seen item size is somewhat more likely to be filled later.  The
    bonus is tiny so it only breaks near-ties and never overrides best fit by
    more than one unit of residual.
    """
    residual = bins - item  # >= 0
    score = -residual.astype(np.float64)

    # Mild exact-complement bonus: residual == item means two such items fill
    # the bin exactly.  Kept small (< 1) so a one-unit-smaller residual still
    # wins overall.
    score += 0.4 * (residual == item)

    return score
# EVOLVE-BLOCK-END
