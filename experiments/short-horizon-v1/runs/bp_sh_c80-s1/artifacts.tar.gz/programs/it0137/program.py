# EVOLVE-BLOCK-START
"""Best fit with a decayed online complement-reuse bonus for tie-breaking."""
import numpy as np


# Decaying histogram of recent item sizes (1..100). Updated once per call.
_RECENT = np.zeros(101, dtype=np.float64)
_DECAY = 0.97


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Dominant term is best fit (smallest post-placement residual).  A small bonus
    rewards residuals that exactly match a commonly and recently seen item size,
    since such a gap is likely to be filled exactly by a future item.
    """
    global _RECENT

    # Decay and record this item.
    _RECENT *= _DECAY
    _RECENT[item] += 1.0

    residual = bins - item  # >= 0 for all shown bins
    base = -100.0 * residual.astype(np.float64)

    # Bounded reuse bonus: how much recent mass matches the residual exactly.
    mass = _RECENT[residual]
    # Squash so the bonus stays well below the 100-per-unit best-fit granularity,
    # i.e. it can only affect bins whose residuals differ by 0.
    bonus = np.log1p(mass)

    return base + bonus
# EVOLVE-BLOCK-END

