# EVOLVE-BLOCK-START
"""Best fit with a deterministic penalty for stranding unusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Base is best fit (smallest post-placement residual).  We add a fixed bonus
    for exact fills and a penalty when the residual is too small to accept a
    typical future item, which prevents stranding tiny gaps.  The rule is fully
    deterministic, so it does not depend on noisy online estimates.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Best fit: prefer the smallest residual.
    score = -residual.astype(np.float64)

    # Strong preference for exact fills (residual 0): always a free bin saved.
    score += 2000.0 * (residual == 0)

    # Penalize residuals that are too small to accept a typical future item
    # (mean item size ~40).  Small unusable gaps tend to be stranded forever.
    small = residual < 20
    score -= 50.0 * small

    return score
# EVOLVE-BLOCK-END

