# EVOLVE-BLOCK-START
"""Worst fit: put the item in the emptiest bin it fits in."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    return bins - item
# EVOLVE-BLOCK-END

