# EVOLVE-BLOCK-START
"""Best fit with a smooth EWMA-based penalty for stranding improbable residuals."""
import numpy as np


# Exponentially weighted moving average of the item-size distribution (sizes 1..100).
# Updated incrementally on every call so it reflects *recent* items, not a stale
# 50-item snapshot.  Initialized to a flat prior.
_ALPHA = 0.05
_PMF = np.full(101, 1.0 / 100.0, dtype=np.float64)
_PMF[0] = 0.0


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Base is best fit (smallest post-placement residual).  We add a penalty when the
    residual r is a size the (recent) item distribution almost never produces, since
    such a gap is likely to be stranded forever.
    """
    global _PMF

    # Update the EWMA with the newly arrived item (item given before ranking).
    _PMF *= (1.0 - _ALPHA)
    _PMF[item] += _ALPHA
    # Keep normalized (drift is negligible but renormalize defensively).
    s = _PMF.sum()
    if s > 0:
        _PMF /= s

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Probability that a future item exactly fills the residual.
    prob = _PMF[residual]

    # Penalize residuals unlikely to be reused by a future item.
    penalty = 60.0 * (1.0 - prob)

    return base - penalty
# EVOLVE-BLOCK-END
