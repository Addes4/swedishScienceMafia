# EVOLVE-BLOCK-START
"""Harmonic-class bin choice: match item size class with residual size class."""
import numpy as np


def priority(item, bins):
    """Score bins by harmonic-class fit.

    Items are grouped into size classes based on the harmonic partition of
    capacity (100).  For an item in class j, we prefer bins whose remaining
    capacity is just large enough to hold an item of class j, i.e. match the
    residual to the same class boundary.  This is the classic Harmonic(2)
    style rule adapted to be lookahead-free and per-item.
    """
    b = bins.astype(np.float64)
    it = float(item)

    # Class boundaries as fractions of capacity 1/k. Item of size s belongs
    # to the largest k with 1/k < s/100 <= 1/(k-1); small items fall to k up to K.
    K = 6
    cap = 100.0

    # Determine item's class k: smallest integer k>=2 with item > cap/k,
    # clamped to [2, K+1].  Higher k = smaller item.
    size_frac = it / cap
    k_item = K + 1
    for k in range(2, K + 1):
        if size_frac > 1.0 / k:
            k_item = k
            break

    # For the item's class, we want the residual to be as close as possible to
    # the upper boundary of a "just enough" bin for this class.  Class k items
    # fit comfortably in bins with residual >= item; among those, prefer the
    # bin whose residual belongs to the same or a coarser class so the
    # remaining space is reusable by the next item of that class.
    # Concretely: aim for residual r in the interval (cap/(k_item+1), cap/k_item].
    # If item is tiny (k_item == K+1) just use best fit.
    if k_item > K:
        return -(b - it)

    lo = cap / (k_item + 1)
    hi = cap / k_item

    # residual after placing the item
    r = b - it

    # distance to the desired interval (0 if inside)
    dist = np.where(r < lo, lo - r, np.where(r > hi, r - hi, 0.0))

    # primary: minimize distance into the target interval; secondary: best fit
    return -dist * 1000.0 - r
# EVOLVE-BLOCK-END
