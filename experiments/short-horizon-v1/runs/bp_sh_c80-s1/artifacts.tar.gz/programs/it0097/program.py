# EVOLVE-BLOCK-START
"""Best fit with a fixed offline-informed bonus for reusable residuals."""
import numpy as np


# Fixed estimate of the item size distribution (Weibull-shaped, mean ~40),
# used only to shape tie-breaks. Built once, never reads future items.
_SIZES = np.arange(1, 101, dtype=np.float64)
# A smooth, unimodal weighting centered near the mean (~40), wide enough to
# cover most of the mass but never dominating the best-fit ordering.
_CENTER = 40.0
_WIDTH = 22.0
_WEIGHT = np.exp(-0.5 * ((_SIZES - _CENTER) / _WIDTH) ** 2)


def priority(item, bins):
    """Rank bins; highest score wins (first on ties).

    Primary: best fit (smallest post-placement residual), giving a large bonus
    to an exact fill.  Secondary: mildly favor residuals that are themselves
    likely future item sizes (reusable gaps), using a fixed smooth weight so the
    best-fit ordering is only broken for near-ties.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Base best-fit score: smaller residual is better.
    base = -residual.astype(np.float64)

    # Exact fill: strongly preferred (guaranteed no future reuse needed).
    exact_bonus = np.where(residual == 0, 1e6, 0.0)

    # Reusability bonus: a residual matching a common item size can be filled
    # precisely later.  This is at most 1.0, so it only breaks near-ties.
    reuse_bonus = _WEIGHT[residual]

    return base + exact_bonus + reuse_bonus
# EVOLVE-BLOCK-END
