# EVOLVE-BLOCK-START
"""Best fit with an online penalty for stranding improbable small residuals,
where the penalty is based on the empirical chance that a residual can still
be used (survival probability)."""
import numpy as np


# Online histogram of item sizes seen so far (updated once per call).
_HIST = np.zeros(101, dtype=np.float64)   # counts for sizes 1..100
_TOTAL = 0.0
_RECOMPUTE_EVERY = 25
_CACHED_PROB = np.zeros(101, dtype=np.float64)   # pmf of item sizes
_CACHED_SURV = np.ones(101, dtype=np.float64)    # P(future item <= r)


def _refresh_prob():
    global _CACHED_PROB, _CACHED_SURV
    if _TOTAL <= 0:
        _CACHED_PROB = np.zeros(101, dtype=np.float64)
        _CACHED_SURV = np.ones(101, dtype=np.float64)
        return
    p = _HIST / _TOTAL
    _CACHED_PROB = p
    # Survival: probability a random future item is <= r.
    cdf = np.cumsum(p)
    _CACHED_SURV = np.empty(101, dtype=np.float64)
    _CACHED_SURV[0] = 0.0
    _CACHED_SURV[1:] = cdf[:100]


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Base is best fit (smallest post-placement residual).  We add a penalty when the
    residual r is small enough that a future item is unlikely to fit into it
    (low survival probability), which strongly correlates with that space being
    stranded.
    """
    global _TOTAL

    # Record this item (the item is already given before we rank).
    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0:
        _refresh_prob()

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Probability that a future item fits into the residual.
    surv = _CACHED_SURV[residual]

    # Penalize residuals that are unlikely to be fillable.
    penalty = 40.0 * (1.0 - surv)

    # Extra bonus for exact fit so it is never overturned.
    exact = (residual == 0).astype(np.float64)

    return base - penalty + 1000.0 * exact
# EVOLVE-BLOCK-END
