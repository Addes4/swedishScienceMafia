# EVOLVE-BLOCK-START
"""Best-fit with a predicted-next-item residual refinement.

Items are drawn i.i.d. from a fixed Weibull-shaped distribution with mean ~40.
Pure best-fit leaves residuals of arbitrary magnitude; many of those residuals
are too small to be useful (a future item rarely fits) or awkward. We keep
best-fit as the dominant term (minimize the residual after placement) but
break near-ties in favor of residuals that are close to a "typical" future
item size, estimated online from the stream so far. This nudges the packing
toward leftovers that a future item can actually use.
"""
import numpy as np

_CAP = 100.0
# Prior mean of the item distribution (mean ~40); updated online.
_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    global _mean, _count

    # Online estimate of the mean item size (simple exponential-ish update).
    _count += 1
    _mean += (item - _mean) / min(_count, 200)

    residual = bins - item                     # remaining capacity after placing
    # Dominant term: prefer small residual (best fit).
    base = -residual.astype(np.float64)

    # Refinement: reward residuals near a typical future item size so the
    # bin can be closed out cleanly; penalize tiny useless residuals.
    target = _mean
    # Closeness to target, scaled; small weight so it only breaks near-ties.
    closeness = -np.abs(residual - target) / (target + 1e-9)
    # Extra nudge: avoid leaving residuals smaller than a plausible item.
    tiny_penalty = -np.where(residual < 8.0, (8.0 - residual) / 8.0, 0.0)

    return base + 0.5 * closeness + 0.25 * tiny_penalty
# EVOLVE-BLOCK-END
