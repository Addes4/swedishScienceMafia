# EVOLVE-BLOCK-START
"""Best fit with a harmonic tie-break on the resulting residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item  # resulting residual after placing item here, >= 0
    # Primary: minimize residual (best fit). Encode as large negative slope so it dominates.
    # Secondary (tie-break only within equal residual): prefer residuals that are "small but
    # not too small" is subtle, but equal-residual bins are essentially identical for pure
    # best-fit, so add a tiny harmonic preference favoring larger remaining bins (fuller use
    # of leftover is binary here) -- keep it strictly as an epsilon tie-break.
    harm = 1.0 / (resid.astype(np.float64) + 1.0)  # larger for smaller residual, monotone
    return -resid.astype(np.float64) - 1e-9 * harm
# EVOLVE-BLOCK-END
