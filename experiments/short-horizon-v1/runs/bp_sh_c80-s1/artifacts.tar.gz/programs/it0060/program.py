# EVOLVE-BLOCK-START
"""Harmonic-style bin packing: rank bins by the harmonic weight of the resulting residual.

The classic Harmonic / harmonic-fit family of online algorithms partitions items by size
class so that bins tend to be filled with items of similar size. We mimic its spirit at the
single-item level: placing the item into a bin changes that bin's remaining capacity from R
to r = R - item. We score the placement by the *marginal* harmonic potential

    phi(r) = sum_{k>=1} 1/(k (k+1)) ... approximated simply as 1/(r+1)

so that fuller bins (small residual) are strongly preferred, but the preference is smooth
rather than the rigid "smallest residual wins" of best fit. Because the item only fits in
bins with R >= item, we restrict to those (given), and the resulting priority is a strictly
decreasing function of r, so for a fixed item size it is a monotone reordering of best fit.

To actually differ from best fit and reduce fragmentation, we additionally give a bonus to
placements whose residual matches a "size class" boundary (multiples of the item): a residual
equal to a whole multiple of the arriving item is likely to be filled by a future copy of the
same size class, mimicking harmonic bin packing.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Smooth harmonic-like preference for fuller bins: 1/(residual+1) is larger for small
    # residuals, so best-fit remains the dominant ordering.
    base = 1.0 / (residual + 1.0)

    # Harmonic-style bonus: residuals that are whole multiples of the item (or leave room for
    # several more copies of this size class) are worth keeping, since future same-class items
    # can fill them exactly. This tilts choices away from creating unusable odd residuals.
    # Avoid division by zero: item >= 1.
    multiple_gap = residual - (residual // item) * item  # residual mod item, in [0, item-1]
    # Smaller gap => residual is close to a multiple of item => better reuse. Normalize to [0,1].
    reuse_bonus = (item - 1 - multiple_gap) / item

    return base + 1e-3 * reuse_bonus
# EVOLVE-BLOCK-END
