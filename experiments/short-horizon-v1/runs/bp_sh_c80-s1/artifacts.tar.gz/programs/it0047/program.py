# EVOLVE-BLOCK-START
"""Best-fit with a residual-quality shaping term.

Pure best-fit (place into the fullest bin the item fits) is a strong online rule,
but it greedily creates tiny leftover capacities that can never be reused.  Here
we keep tightness as the dominant term but reward post-placement residuals that
are still large enough to accept a typical future item, staying close to
best-fit yet slightly reducing fragmentation.
"""
import numpy as np


def priority(item, bins):
    """Rank bins: dominant best-fit term plus a mild residual-quality bonus.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacities of bins the item fits in, in bin order.
    """
    residual = bins - item          # capacity left after placing the item here
    # Dominant term: smaller residual (fuller bin) is better -> larger score.
    score = -residual.astype(np.float64)
    # Mild bonus when the leftover can still hold a typical item (mean ~40).
    # This nudges us away from leftovers in the 1..39 dead zone toward
    # leftovers >= 40, without overriding best-fit on clearly better fits.
    score += np.where((residual >= 40) & (residual < 60), 0.5, 0.0)
    return score
# EVOLVE-BLOCK-END
