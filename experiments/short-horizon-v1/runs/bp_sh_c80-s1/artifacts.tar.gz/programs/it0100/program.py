# EVOLVE-BLOCK-START
"""Exact-fit bonus with a convex (sum-of-squares) tie-break on the placed bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Primary: strongly prefer an exact fit (residual 0).
    Secondary: minimize the resulting squared remaining capacity of this bin,
    which is the change in a convex potential sum(c^2) and favors consolidating
    small residuals rather than stranding usable space.
    """
    residual = bins.astype(np.float64) - float(item)

    # Exact fits get a large bonus so they are always chosen.
    exact = (residual <= 0.0).astype(np.float64)

    # Convex potential of the new residual: prefer smaller residual^2,
    # i.e. subtract residual^2 from the score.
    score = exact * 1e6 - residual * residual

    return score
# EVOLVE-BLOCK-END
