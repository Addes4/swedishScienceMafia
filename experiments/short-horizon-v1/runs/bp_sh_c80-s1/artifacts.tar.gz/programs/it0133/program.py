# EVOLVE-BLOCK-START
"""Best fit with a decaying online histogram used to reward reusable residuals."""
import numpy as np


# Decaying histogram of recent item sizes (1..100).
_HIST = np.zeros(101, dtype=np.float64)
_DECAY = 0.98
_TOTAL = 0.0


def priority(item, bins):
    """Best fit plus a small bonus for residuals likely to be filled soon.

    The bonus favors residuals that exactly match a frequently seen item size
    (so a future item is likely to fill this gap exactly), while best fit
    (smallest residual) remains the dominant term.
    """
    global _TOTAL

    # Decay the histogram and record this item.
    _HIST *= _DECAY
    _TOTAL = _TOTAL * _DECAY + 1.0
    _HIST[item] += 1.0

    residual = bins.astype(np.float64) - float(item)

    # Best fit: prefer small residual.
    score = -residual

    # Bonus for residuals that are a likely future item size.
    # Normalized so it can break near-ties but not overwhelm best fit.
    prob = _HIST[residual] / _TOTAL
    # Residual 0 means exact fit; treat separately and strongly.
    score = np.where(residual == 0.0, 1000.0, score + 8.0 * prob)

    return score
# EVOLVE-BLOCK-END
