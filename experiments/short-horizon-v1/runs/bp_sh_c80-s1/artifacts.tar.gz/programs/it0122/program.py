# EVOLVE-BLOCK-START
"""Best fit with a stable prior-based bonus for reusable residual gaps."""
import numpy as np

# Fixed Weibull-shaped prior over item sizes (mean ~40), evaluated at integer sizes 1..100.
# Shape k and scale lam chosen so the mean is ~40.
_K = 1.9
_LAM = 45.0
_SIZES = np.arange(0, 101, dtype=np.float64)
# Weibull pdf (unnormalized over 1..100), zero at size 0.
_pdf = np.zeros(101, dtype=np.float64)
_s = _SIZES[1:]
_pdf[1:] = (_K / _LAM) * (_s / _LAM) ** (_K - 1.0) * np.exp(-(_s / _LAM) ** _K)
_pdf /= _pdf.sum()
_CDF = np.cumsum(_pdf)


def priority(item, bins):
    """Rank bins: best fit dominates, plus a bonus when the residual is a likely
    future item size (so the leftover gap is more likely to be refilled)."""
    residual = bins - item  # >= 0
    base = -residual.astype(np.float64)

    # Probability a future item exactly fills the residual (fixed prior).
    p_exact = _pdf[residual]

    # Penalize unlikely-to-be-reused residuals; scale modest so best fit stays dominant.
    return base + 80.0 * p_exact
# EVOLVE-BLOCK-END
