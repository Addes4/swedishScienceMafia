# EVOLVE-BLOCK-START
"""Best fit with a strong exact-fit bonus and a mild large-residual preference."""
import numpy as np


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Primary rule: best fit (smallest post-placement residual).  We add a large
    bonus when the residual is exactly 0 (item perfectly fills the bin), since
    that wastes nothing.  We also give a mild bonus to larger residuals, which
    tend to be more useful (bigger free space) than tiny unusable gaps.
    """
    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Strong bonus for an exact fit.
    exact_bonus = np.where(residual == 0, 1000.0, 0.0)

    # Mild preference for larger residuals (more reusable free space).
    large_bonus = 0.01 * residual.astype(np.float64)

    return base + exact_bonus + large_bonus
# EVOLVE-BLOCK-END

