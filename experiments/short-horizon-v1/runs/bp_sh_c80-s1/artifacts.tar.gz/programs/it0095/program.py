# EVOLVE-BLOCK-START
"""Power-of-capacity online rule (favor bins that reduce a convex potential most)."""
import numpy as np


def priority(item, bins):
    """Score bins by potential reduction: (cap^p - residual^p) / item.

    Placing the item into bin with remaining capacity `c` changes the residual
    from c to c-item.  Minimizing a convex potential sum f(residual) is a well
    known near-optimal online heuristic for random item sizes (related to
    Harmonic / sum-of-squares bin packing).  We use a gentle power p=1.5 and
    add a small exact-fill bonus.
    """
    cap = bins.astype(np.float64)
    residual = cap - float(item)

    p = 1.5
    # Reduction in potential when the item is placed here.
    # Higher score = better.
    score = np.power(cap, p) - np.power(residual, p)

    # Strong preference for exact fits.
    score += 500.0 * (residual == 0.0)

    return score
# EVOLVE-BLOCK-END
