# EVOLVE-BLOCK-START
"""Best fit with an online penalty for residuals that can never be refilled."""
import numpy as np


# Online histogram of item sizes seen so far (updated once per call).
_HIST = np.zeros(101, dtype=np.float64)   # counts for sizes 1..100
_TOTAL = 0.0
_RECOMPUTE_EVERY = 25
_CACHED_CDF = np.zeros(101, dtype=np.float64)  # P(item <= r) for r = 0..100


def _refresh_cdf():
    global _CACHED_CDF
    if _TOTAL <= 0:
        _CACHED_CDF = np.zeros(101, dtype=np.float64)
        return
    p = _HIST / _TOTAL
    # cumulative: CDF[r] = P(item <= r)
    _CACHED_CDF = np.cumsum(p)


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Base is best fit (smallest post-placement residual).  We add a penalty when the
    residual r is so small that the empirical item distribution almost never
    produces an item that fits in it, since such a gap is likely stranded forever.
    """
    global _TOTAL

    # Record this item (item is known before we rank).
    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0:
        _refresh_cdf()

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Probability that some future item fits in the residual (item <= residual).
    fillable = _CACHED_CDF[residual]

    # Penalize residuals that are very unlikely to ever be refilled.
    # Scale kept modest so exact/near-exact fills still dominate.
    penalty = 50.0 * (1.0 - fillable)

    return base - penalty
# EVOLVE-BLOCK-END
