# EVOLVE-BLOCK-START
"""Best fit with an analytic penalty for stranding improbable small residuals."""
import numpy as np

# Fixed prior over item sizes 1..100, approximating the Weibull-shaped stream
# (mean ~40).  We only need a smooth plausibility curve, not the exact pmf.
_SIZES = np.arange(1, 101, dtype=np.float64)
# Weibull-ish density with shape k=2, scale chosen so mean ~ 40.
_K = 2.0
_LAM = 40.0 / 0.8862269254527580  # Gamma(1+1/k)
_RAW = (_K / _LAM) * (_SIZES / _LAM) ** (_K - 1.0) * np.exp(-(_SIZES / _LAM) ** _K)
_PRIOR = np.zeros(101, dtype=np.float64)
_PRIOR[1:] = _RAW
_PRIOR[1:] /= _PRIOR[1:].sum()

# Feasibility of a residual of size r: probability that some single future item
# exactly equals r (so the bin can be closed).  Larger residuals are easier to
# eventually fill, small ones (1..3) are almost certainly stranded.
_FEAS = np.cumsum(_PRIOR)  # monotone in r: cumulative chance of filling <= r


def priority(item, bins):
    residual = bins - item
    base = -residual.astype(np.float64)

    # Penalize tiny unusable residuals much more than large ones.
    # _FEAS[r] ~ probability a random item is <= r; small r -> tiny value.
    feas = _FEAS[residual]

    # Strong hook for exact fits (residual 0) already implied by base, but make
    # near-full bins clearly favored over empty ones with awkward gaps.
    penalty = 200.0 * (1.0 - feas)

    return base - penalty
# EVOLVE-BLOCK-END
