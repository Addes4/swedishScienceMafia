# EVOLVE-BLOCK-START
"""Best fit with a mild penalty for leaving large residual gaps.

Items are Weibull-shaped (mean ~40). Pure best fit already does well, but it
sometimes leaves awkward residuals (e.g. a bin with 60 free) that never get
reused cleanly. We keep best-fit's preference for small residuals but add a
penalty on residuals beyond a threshold so that, among comparable fits, the
rule avoids creating heavily fragmented near-empty gaps.
"""
import numpy as np


def priority(item, bins):
    r = bins - item                # post-placement residual, >= 0
    T = 40.0                       # threshold near the mean item size
    w = 0.25                       # mild extra penalty past the threshold
    penalty = np.maximum(0.0, r - T)
    return -r - w * penalty
# EVOLVE-BLOCK-END

