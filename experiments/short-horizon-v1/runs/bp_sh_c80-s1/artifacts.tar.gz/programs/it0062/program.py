# EVOLVE-BLOCK-START
"""Best fit with a mild penalty against creating useless small residues."""
import numpy as np


def priority(item, bins):
    """Rank bins; item goes to the highest score (first on ties).

    Primary: best fit (smallest resulting residual).
    Secondary: break near-ties by penalizing residues that are small but nonzero
    and rewarding exact fits / residues likely reusable by an average item.
    """
    residual = bins - item
    # Best fit dominates; scale so the secondary term only matters near-ties.
    score = -residual.astype(np.float64)
    # Reward exact fits slightly.
    score += 1e-2 * (residual == 0)
    # Mildly penalize tiny nonzero residues (slivers) — less reusable than larger ones.
    small = (residual > 0) & (residual <= 2)
    score -= 1e-3 * small
    return score
# EVOLVE-BLOCK-END
