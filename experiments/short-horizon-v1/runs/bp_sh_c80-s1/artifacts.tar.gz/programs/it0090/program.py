# EVOLVE-BLOCK-START
"""Best fit with a bounded reuse-potential tie-break from online item statistics."""
import numpy as np


# Online histogram of item sizes seen so far (updated once per call).
_HIST = np.zeros(101, dtype=np.float64)   # counts for sizes 1..100
_TOTAL = 0.0
_RECOMPUTE_EVERY = 25
_CACHED_PROB = np.zeros(101, dtype=np.float64)
_CACHED_MEAN = 40.0


def _refresh_prob():
    global _CACHED_PROB, _CACHED_MEAN
    if _TOTAL <= 0:
        _CACHED_PROB = np.zeros(101, dtype=np.float64)
        _CACHED_MEAN = 40.0
        return
    p = _HIST / _TOTAL
    _CACHED_PROB = p
    s = np.arange(101, dtype=np.float64)
    _CACHED_MEAN = float(np.dot(p, s))


def priority(item, bins):
    """Rank bins: best fit first, with a small bounded bonus for reusable residuals."""
    global _TOTAL

    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0:
        _refresh_prob()

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Reuse potential: a residual equal to a likely future item size is good.
    # Use empirical pmf, smoothed with a tiny prior so unseen sizes aren't zeroed.
    prob = _CACHED_PROB[residual]
    # Bonus bounded to < 1 so it only breaks near-ties (residual differences of 1).
    bonus = prob / (prob + 0.02)

    # Extra nudge: avoid leaving residuals smaller than a typical item when
    # alternatives with larger, fillable residuals are available.
    mean = _CACHED_MEAN
    small_pen = 0.0
    if mean > 1.0:
        # cumulative chance the residual is at least a plausible small item
        fill_ok = np.clip(residual / mean, 0.0, 1.0)
        small_pen = 0.3 * (1.0 - fill_ok)

    return base + 0.9 * bonus - small_pen
# EVOLVE-BLOCK-END

