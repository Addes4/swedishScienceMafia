# EVOLVE-BLOCK-START
"""Best-fit with a bias toward residuals matching the typical item size."""
import numpy as np


def priority(item, bins):
    """Higher score wins; ties go to the first bin.

    We use best fit: leftover = bins - item, smaller is better.
    But a residual equal to a common item size is far more usable than an
    arbitrarily small residual, so we add a bonus when the residual is close
    to the running mean of item sizes seen so far (a proxy for likely next items).
    """
    leftover = bins - item  # remaining capacity after placing the item

    # Running statistics kept on the function object.
    s = getattr(priority, "_sum", 0) + item
    n = getattr(priority, "_n", 0) + 1
    priority._sum = s
    priority._n = n
    mean = s / n if n else 40.0

    # Base best-fit score: tighter fit => higher score.
    score = -leftover.astype(np.float64)

    # Bonus for residuals close to the typical item size (usable residuals).
    # Bounded so it only breaks near-ties in favor of usable residuals.
    diff = np.abs(leftover - mean)
    score += 2.0 / (1.0 + diff)

    return score
# EVOLVE-BLOCK-END
