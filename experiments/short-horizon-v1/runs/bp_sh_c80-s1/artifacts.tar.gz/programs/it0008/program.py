# EVOLVE-BLOCK-START
"""Empirical best-fit: prefer bins whose leftover after placement matches a likely future item."""
import numpy as np


class _State:
    """Running histogram of item sizes seen so far in the current stream."""
    def __init__(self):
        self.count = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def observe(self, item):
        self.count[item] += 1.0
        self.total += 1.0


_state = _State()


def priority(item, bins):
    """Rank bins; highest score wins (ties go to the first bin).

    item: integer size 1..100.
    bins: numpy int64 array of remaining capacities of fitting bins, in bin order.
    """
    # Update stats lazily (item being placed now is not yet observed).
    hist = _state.count
    total = _state.total

    if total >= 20:
        probs = hist / total
    else:
        # Uniform fallback early on.
        probs = np.full(101, 1.0 / 100.0)
        probs[0] = 0.0

    residual = bins - item  # >= 0 for all shown bins

    # Probability that a future item exactly matches this residual (or is small enough
    # to keep the bin usable). We want to leave residuals that are likely to be filled.
    # Score combines best-fit tightness with the chance of completing the bin.
    idx = np.clip(residual, 0, 100).astype(np.int64)
    exact = probs[idx]
    # small residual can always be topped off by some small item
    small_cdf = np.cumsum(probs)

    score = exact * 1000.0 + (1.0 - small_cdf[idx]) * 0.0 - residual * 1e-3

    _state.observe(item)
    return score
# EVOLVE-BLOCK-END
