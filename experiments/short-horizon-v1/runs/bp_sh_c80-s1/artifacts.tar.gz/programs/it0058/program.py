# EVOLVE-BLOCK-START
"""Sub-harmonic residual potential: prefer placements that keep residuals near-fillable."""
import numpy as np


def priority(item, bins):
    """Score bins by a soft-harmonic residual potential.

    For each bin with remaining capacity R, placing the item leaves residual
    r = R - item.  The classic harmonic lower-bound potential counts, for each
    residual, how many items of size <= that residual remain useful.  Using a
    smooth weight 1/(r+1) over all residuals (plus 1/(R+1) for the original
    residual) rewards placements whose resulting residual pattern keeps many
    small gaps available for future items, rather than only minimizing the
    immediate waste as pure best-fit does.
    """
    R = bins.astype(np.float64)
    r = R - float(item)

    before = 1.0 / (R + 1.0)
    after = 1.0 / (r + 1.0)

    # Maximize the increase in soft-harmonic residual potential, but weight
    # the immediate-waste (best-fit) component so it stays dominant and only
    # steers among near-equally-good fits.
    return (before - after) - 1e-6 * r
# EVOLVE-BLOCK-END

