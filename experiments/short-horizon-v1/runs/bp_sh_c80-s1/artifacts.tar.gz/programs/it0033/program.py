# EVOLVE-BLOCK-START
"""Residual-reuse best fit: prefer leftovers that can still hold the item again."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best-fit residual is the base criterion (smaller residual is better).
    score = -residual.astype(np.float64)

    # Bonus for exact fills (residual 0): always ideal.
    score += (residual == 0) * 50.0

    # Bonus for bins whose leftover can still hold another copy of this item:
    # this keeps capacity in "reusable multiples" rather than leaving dead fragments.
    score += (residual >= item) * 5.0

    return score
# EVOLVE-BLOCK-END
