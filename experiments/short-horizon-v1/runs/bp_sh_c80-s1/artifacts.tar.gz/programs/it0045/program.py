# EVOLVE-BLOCK-START
"""Best fit with a learned tie-break: prefer residuals that are likely to be
exactly refillable by a future item (estimated from the empirical item histogram).
"""
import numpy as np


class _State:
    def __init__(self):
        # histogram of item sizes seen (1..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.n = 0


_state = _State()


def priority(item, bins):
    st = _state
    # update empirical histogram with the current item
    if 1 <= item <= 100:
        st.hist[item] += 1.0
        st.n += 1.0

    residual = bins - item  # capacity left after placing item in each bin

    # base: best-fit -> smaller residual better
    score = -residual.astype(np.float64)

    # tie-break: reward residuals that are exactly an item size we've seen often,
    # or 0 (perfect fill). This keeps near-tie choices from wasting a bin.
    if st.n > 0:
        weights = st.hist[residual] if False else None
        # residual may be 1..100 after placement; gather frequencies safely
        r = np.clip(residual, 0, 100)
        freq = st.hist[r]  # frequency that a past item had this residual size
        # normalize by total to keep it small vs base term
        bonus = freq / st.n
        # exact fits get a small extra nudge
        bonus = bonus + np.where(residual == 0, 1.0, 0.0) / st.n
        score = score + 0.5 * bonus

    return score
# EVOLVE-BLOCK-END
