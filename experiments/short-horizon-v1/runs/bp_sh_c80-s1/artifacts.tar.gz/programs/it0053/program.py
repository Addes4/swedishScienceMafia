# EVOLVE-BLOCK-START
"""Match-then-best-fit with a distribution-aware residual tie-break.

Primary: reward exact fits (post-placement residual 0) heavily.
Secondary: best-fit (minimize post-placement residual).
Tie-break: among nearly equal residuals, prefer residuals close to the
distribution's typical item size (mean ~40), which are more likely to be
exactly fillable by a future item, reducing unusable slivers.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)
    residual = bins - item

    # Primary: strong preference for exact fits.
    exact = (residual == 0).astype(np.float64)

    # Best-fit closeness: negative residual (smaller residual -> higher score).
    tightness = -residual.astype(np.float64)

    # Tie-break: reward residuals near the typical item size (~40).
    # Larger reward the closer the residual is to ~40.
    typical = 40.0
    near_typical = 1.0 / (1.0 + np.abs(residual.astype(np.float64) - typical))

    return exact * 1e6 + tightness + 0.5 * near_typical
# EVOLVE-BLOCK-END
