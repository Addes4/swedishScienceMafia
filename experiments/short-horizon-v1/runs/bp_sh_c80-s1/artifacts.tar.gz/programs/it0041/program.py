# EVOLVE-BLOCK-START
"""Best fit, with a bonus for leaving a usable residual.

The item goes into the bin it fits most tightly (minimal post-placement residual).
Ties/close calls are broken by preferring bins whose residual after placement is
either 0 (a perfect fill) or still large enough to hold a typical future item,
so bins don't get fragmented into unusable little gaps.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    residual = bins - item

    # Running estimate of a "typical" item size from the items seen so far.
    # Kept on the function object so it persists across calls in a stream.
    total = getattr(priority, "_total", 0) + item
    count = getattr(priority, "_count", 0) + 1
    priority._total = total
    priority._count = count
    mean_item = total / count

    # Dominant term: prefer tight fits (small residual).
    score = -residual.astype(np.float64)

    # Bonus: exact fill is ideal; a residual that can still host a typical
    # future item keeps the bin useful and avoids tiny wasted fragments.
    usable = residual >= mean_item
    exact = residual == 0
    score += 0.5 * usable
    score += 0.5 * exact
    return score
# EVOLVE-BLOCK-END
