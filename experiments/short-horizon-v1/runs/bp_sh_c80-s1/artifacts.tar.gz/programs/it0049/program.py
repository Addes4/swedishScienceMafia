# EVOLVE-BLOCK-START
"""Best fit with a small bonus for bins that already hold more items.

The dominant term is best-fit (minimize post-placement residual). A tiny
additive bonus rewards bins that have already received more items, which
breaks near-ties toward concentrating load and reduces fragmentation.
Bin identity is tracked via the remaining-capacity value at first sight
plus a stateful counter keyed by bin index within the current call stream.
"""
import numpy as np

# Module-level state, reset per stream by the harness recreating the module is
# not guaranteed, so we reset when we detect a fresh stream (all bins == 100).
_load = {}
_prev_n = 0


def priority(item, bins):
    global _load, _prev_n

    n = len(bins)
    # Detect a fresh stream: bin count changed or we see the initial state.
    if n != _prev_n:
        _load = {}

    # Best-fit base: higher score = smaller residual after placement.
    residual = bins - item  # >= 0 for all shown bins
    score = -residual.astype(np.float64)

    # Small bonus for bins already holding more items (concentrate load).
    # _load maps bin index -> number of items placed there this stream.
    # Bin index corresponds to position in the stream's bin array.
    counts = np.empty(n, dtype=np.float64)
    for i in range(n):
        counts[i] = _load.get(i, 0)

    # Normalize bonus so it only breaks near-ties, never overrides tightness.
    # residual differences are integers >= 1, so use bonus < 1.
    max_count = counts.max() if n > 0 else 0.0
    if max_count > 0:
        score = score + 0.5 * (counts / (max_count + 1.0))

    # Update load counters for the chosen bin (argmax with first-tie rule).
    chosen = int(np.argmax(score))
    _load[chosen] = _load.get(chosen, 0) + 1
    _prev_n = n

    return score
# EVOLVE-BLOCK-END
