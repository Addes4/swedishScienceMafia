# EVOLVE-BLOCK-START
"""Best fit with a small residual-utility tie-break toward fillable residual sizes."""
import numpy as np

# Approximate probability weights that a future item equals a given size (1..100).
# Weibull-shaped distribution with mean ~40. Build a smooth concave mass over sizes.
_sizes = np.arange(1, 101, dtype=np.float64)
_k = 1.8
_lam = 40.0 / 0.8862  # scale so mean ~40 for k=1.8 (Gamma(1+1/k))
_w = (_k / _lam) * (_sizes / _lam) ** (_k - 1.0) * np.exp(-(_sizes / _lam) ** _k)
_w = _w / _w.sum()

# Cumulative probability that an item has size <= s, for s = 0..100
_cdf = np.zeros(101, dtype=np.float64)
_cdf[1:] = np.cumsum(_w)


def priority(item, bins):
    """Score each bin: strongly prefer exact fit, otherwise best-fit with a residual bonus."""
    residual = bins - item  # >= 0 by construction
    # Lower residual is better; negate so higher score wins.
    base = -residual.astype(np.float64)

    # Bonus if the residual can be exactly filled by a plausible future item.
    r = residual.astype(np.int64)
    r_clipped = np.clip(r, 0, 100)
    # Probability that some future item exactly matches this residual size.
    fill_p = _w[np.clip(r_clipped - 1, 0, 99)] if False else _w[r_clipped - 1]
    # r_clipped is 0..100; index r_clipped-1 for r>=1; for r==0 use 0 contribution
    fill_p = np.where(r_clipped >= 1, _w[np.clip(r_clipped - 1, 0, 99)], 0.0)

    # Small weight so best-fit stays dominant; exact fits already dominate via base.
    return base + 0.5 * fill_p
# EVOLVE-BLOCK-END
