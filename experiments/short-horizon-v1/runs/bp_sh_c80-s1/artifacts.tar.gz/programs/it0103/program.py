# EVOLVE-BLOCK-START
"""Best fit with a smoothed empirical reuse bonus for the residual."""
import numpy as np


# Online histogram of item sizes seen so far (updated once per call).
_HIST = np.zeros(101, dtype=np.float64)   # counts for sizes 1..100
_TOTAL = 0.0
_RECOMPUTE_EVERY = 32
_CACHED_PROB = np.zeros(101, dtype=np.float64)


def _refresh_prob():
    global _CACHED_PROB
    if _TOTAL <= 0:
        _CACHED_PROB = np.zeros(101, dtype=np.float64)
        return
    # Smoothed pmf: add a small uniform prior so unseen sizes still get credit.
    p = (_HIST + 0.25) / (_TOTAL + 25.0)
    _CACHED_PROB = p


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Primary rule is best fit: prefer the smallest non-negative residual.
    Secondary: add a small bonus proportional to the smoothed empirical
    probability that this exact residual will be filled by a future item,
    so that common residual sizes are preferred over rare ones.
    """
    global _TOTAL, _CACHED_PROB

    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0 or _TOTAL <= 1.0:
        _refresh_prob()

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    prob = _CACHED_PROB[residual]

    # Small reuse bonus: cannot override best-fit for distinct residuals by more
    # than a fraction of one unit, since prob is at most ~1.
    return base + 0.5 * prob
# EVOLVE-BLOCK-END
