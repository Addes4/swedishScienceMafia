# EVOLVE-BLOCK-START
"""Best fit with an online bonus for residuals that are likely reusable item sizes."""
import numpy as np


# Online histogram of item sizes seen so far (updated once per call).
_HIST = np.zeros(101, dtype=np.float64)   # counts for sizes 1..100
_TOTAL = 0.0
_RECOMPUTE_EVERY = 50
_CACHED_PROB = np.zeros(101, dtype=np.float64)


def _refresh_prob():
    global _CACHED_PROB
    if _TOTAL <= 0:
        _CACHED_PROB = np.zeros(101, dtype=np.float64)
        return
    _CACHED_PROB = _HIST / _TOTAL


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Primary key is best fit (smallest post-placement residual), scaled large enough
    to dominate.  We then add a bonus proportional to the empirical probability that
    the residual size will be produced exactly by a future item (reuse likelihood),
    so that among comparable residuals we prefer ones that are common item sizes.
    """
    global _TOTAL, _RECOMPUTE_EVERY

    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0:
        _refresh_prob()

    residual = bins - item  # >= 0 for all shown bins

    # Best fit dominates; scale large relative to the reuse bonus (<= ~1).
    base = -1000.0 * residual.astype(np.float64)

    # Bonus: probability this residual is exactly matched by a future item.
    prob = _CACHED_PROB[residual]

    return base + 5.0 * prob
# EVOLVE-BLOCK-END
