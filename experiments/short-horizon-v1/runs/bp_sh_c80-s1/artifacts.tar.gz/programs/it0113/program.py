# EVOLVE-BLOCK-START
"""Best fit with an online sliding-window estimate of future fill probability."""
import numpy as np


# Sliding-window (exponentially decayed) online histogram of item sizes 1..100.
_W = np.zeros(101, dtype=np.float64)   # decayed counts
_TOTAL = 0.0
_DECAY = 0.97                          # forget factor: effective window ~ 1/(1-DECAY)
_CACHED_PROB = np.zeros(101, dtype=np.float64)


def _refresh_prob():
    global _CACHED_PROB
    if _TOTAL <= 0:
        _CACHED_PROB = np.zeros(101, dtype=np.float64)
        return
    _CACHED_PROB = _W / _TOTAL


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Primary term is best fit (smallest non-negative residual).  We add a bonus when
    the residual is a size that future items plausibly produce (so the gap gets
    filled instead of stranded), and a large bonus for an exact fit (residual 0).
    """
    global _TOTAL

    # Decay the window and record this item.
    _W *= _DECAY
    _TOTAL *= _DECAY
    _W[item] += 1.0
    _TOTAL += 1.0
    _refresh_prob()

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    prob = _CACHED_PROB[residual]

    # Bonus: exact fit is ideal; otherwise reward residuals likely to be refilled.
    bonus = 60.0 * prob
    exact = np.where(residual == 0, 5.0, 0.0)

    return base + bonus + exact
# EVOLVE-BLOCK-END
