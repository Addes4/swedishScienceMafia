# EVOLVE-BLOCK-START
"""Best fit: put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Strict best fit: minimize residual. Perfect fills (residual 0) get a slight edge.
    return -residual - 1e-3 * (residual == 0)
# EVOLVE-BLOCK-END

