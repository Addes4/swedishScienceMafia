# EVOLVE-BLOCK-START
"""Best fit with a smooth parametric exact-fill bonus (Weibull-like prior)."""
import numpy as np

# Smooth prior over item sizes 1..100, roughly Weibull-shaped with mean ~40.
_SIZES = np.arange(101, dtype=np.float64)
_SHAPE = 1.6
_SCALE = 45.0
_PRIOR = (_SHAPE / _SCALE) * (_SIZES / _SCALE) ** (_SHAPE - 1.0) * np.exp(
    -(_SIZES / _SCALE) ** _SHAPE
)
_PRIOR[0] = 0.0
_M = _PRIOR.max()
if _M > 0:
    _PRIOR = _PRIOR / _M


def priority(item, bins):
    """Rank bins: best fit primary, strong bonus for likely-fillable residuals."""
    residual = (bins - item).astype(np.float64)  # >= 0 for all shown bins
    base = -residual
    # Bonus when the residual matches a typical item size (fillable by one future item).
    bonus = 40.0 * _PRIOR[residual.astype(np.int64)]
    return base + bonus
# EVOLVE-BLOCK-END
