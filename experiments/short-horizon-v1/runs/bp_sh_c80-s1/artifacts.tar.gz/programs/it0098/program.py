# EVOLVE-BLOCK-START
"""Best fit with a learned bonus when the residual is a common future item size."""
import numpy as np


# Online histogram of item sizes seen so far (updated once per call).
_HIST = np.zeros(101, dtype=np.float64)   # counts for sizes 1..100
_TOTAL = 0.0
_RECOMPUTE_EVERY = 25
_CACHED_PROB = np.zeros(101, dtype=np.float64)


def _refresh_prob():
    global _CACHED_PROB
    if _TOTAL <= 0:
        _CACHED_PROB = np.zeros(101, dtype=np.float64)
        return
    _CACHED_PROB = _HIST / _TOTAL


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Primary: best fit (smallest post-placement residual).  Secondary: a bonus
    proportional to how likely the residual size is to show up again as an item,
    so we prefer leaving gaps that can actually be filled later.
    """
    global _TOTAL

    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0:
        _refresh_prob()

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Exact fit is essentially always good.
    exact = (residual == 0).astype(np.float64)

    # Bonus only matters as a tie-break among close residuals, so keep it small.
    prob = _CACHED_PROB[residual]
    bonus = 30.0 * prob

    return base + bonus + 1000.0 * exact
# EVOLVE-BLOCK-END
