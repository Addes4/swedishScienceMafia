# EVOLVE-BLOCK-START
"""Hybrid best-fit: prefer exact fills and avoid leaving unusable fragments.

Default is strict best-fit (minimize post-placement residual). But it is better to
avoid stranding a residual that no future item can use, if another fitting bin would
leave the item's characteristic size or a near-perfect fill.
"""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest score."""
    if item < _state["min_item"]:
        _state["min_item"] = item
    smallest = _state["min_item"]

    residual = bins - item  # all >= 0 since only fitting bins are shown

    # primary: tightest fit (smallest residual) -> highest score
    score = -residual.astype(np.float64)

    # exact fill (residual 0) is always best
    exact = residual == 0
    score[exact] += 1000.0

    # we prefer leaving a residual that is "usable": either 0 or >= smallest observed item
    unusable = (residual > 0) & (residual < smallest)
    usable = ~unusable

    # bins leaving usable residuals get a mild bonus over unusable ones
    score[usable] += 2.0

    return score
# EVOLVE-BLOCK-END
