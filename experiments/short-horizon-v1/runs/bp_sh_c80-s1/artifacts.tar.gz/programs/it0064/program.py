# EVOLVE-BLOCK-START
"""Best fit with a tiny distribution-aware tie-break on equal residuals."""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.m2 = 0.0

    def update(self, x):
        self.n += 1
        d = x - self.mean
        self.mean += d / self.n
        self.m2 += d * (x - self.mean)


_STATS = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _STATS.update(item)

    residual = bins - item  # >= 0 for all shown bins

    # Primary: minimize residual (best fit). Convert to a maximizing score.
    # Secondary (only matters on exact residual ties): prefer residual near 0,
    # then prefer residual at/above the running mean (more likely reusable).
    # Both are made much smaller than 1 so they cannot override best fit.
    if _STATS.n > 3 and _STATS.mean > 0:
        thr = _STATS.mean
    else:
        thr = 40.0

    # small binary-ish bonus for reusable leftovers (>= thr), tiny bonus for exact zero
    big = np.where(residual == 0, 1.0, np.where(residual >= thr, 0.5, 0.0))
    # fine tie-break: prefer leftover just at/above thr, else smaller residual
    fine = np.where(residual >= thr, -(residual - thr) * 1e-3, -residual * 1e-3)

    return -residual + 1e-2 * big + fine
# EVOLVE-BLOCK-END

