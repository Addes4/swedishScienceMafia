# EVOLVE-BLOCK-START
"""Best fit, with a smooth nudge away from stranding tiny residuals.

Items are i.i.d. from a fixed Weibull-shaped distribution with mean about 40.
Empirical-histogram penalties tried previously were too noisy to beat plain
best fit.  Instead we use a deterministic, smooth function of the residual:

  * primary term: strongly prefer small post-placement residual (best fit),
  * secondary term: mildly prefer residuals that are large enough to still
    accept a typical future item, so tiny gaps (which are effectively stranded
    forever) are avoided.

The two terms are combined at a fixed scale so the nudge can break near-ties
between comparable residuals but never overturn a clearly better fit.
"""
import numpy as np


def priority(item, bins):
    residual = (bins - item).astype(np.float64)   # >= 0 for all shown bins

    # Primary: best fit (smallest residual wins).
    score = -residual

    # Secondary: tiny residuals are likely stranded; residual near/above the
    # typical item size is more reusable.  Use a smooth saturating bonus so it
    # only acts as a tie-break and never dominates the best-fit term.
    # mean item size ~ 40, so use a soft reference of 40.
    reuse = residual / (residual + 40.0)          # in [0, 1), increasing
    score = score + 0.05 * reuse

    return score
# EVOLVE-BLOCK-END
