# EVOLVE-BLOCK-START
"""First-fit style placement: fill partially-used bins before opening fresh ones.

Best fit tends to produce many small stranded residuals.  A known-robust online
alternative is First Fit: use the earliest bin that still fits.  Since the bins
array is ordered by bin index, "earliest fitting bin" corresponds to the first
entry.  Among bins we prefer those with larger remaining capacity still able to
hold the item (i.e., the least-loaded fitting bin), which keeps small residuals
from accumulating and preserves roomy bins for large future items.
"""
import numpy as np


def priority(item, bins):
    """Score every fitting bin; highest wins (first on ties).

    Primary: prefer bins whose residual after placement is large enough to still
    be useful, i.e. avoid creating tiny stranded residuals.  We do this by
    ranking on the post-placement residual directly, but with a strong cap that
    discourages residuals below the item size (they can't hold this item again)
    only mildly, and by preserving the natural bin order via tiny tie-break.
    """
    residual = bins - item  # >= 0

    # Value of leaving `residual` behind.  Residuals >= item are more valuable
    # (can hold another item of this size); tiny residuals are weakly penalized.
    r = residual.astype(np.float64)

    # Concave value: grows fast near 0 then saturates, so we prefer leaving a
    # moderate residual over an exact fill only when it keeps the bin flexible.
    value = np.log1p(r) / np.log1p(100.0)

    # Mild bonus for residuals that can still fit the current item (reusable).
    value += 0.05 * (residual >= item)

    return value
# EVOLVE-BLOCK-END
