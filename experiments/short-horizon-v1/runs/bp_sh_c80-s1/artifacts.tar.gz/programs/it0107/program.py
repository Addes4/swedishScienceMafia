# EVOLVE-BLOCK-START
"""Best fit with a smoothed online look-ahead bonus for refillable residuals."""
import numpy as np


# Online histogram of item sizes seen so far (updated once per call).
_HIST = np.zeros(101, dtype=np.float64)   # counts for sizes 1..100
_TOTAL = 0.0
_RECOMPUTE_EVERY = 25
_CACHED_PROB = np.zeros(101, dtype=np.float64)


def _refresh_prob():
    global _CACHED_PROB
    if _TOTAL <= 0:
        _CACHED_PROB = np.zeros(101, dtype=np.float64)
        return
    # Laplace-style smoothing so unseen sizes still get a small nonzero chance.
    counts = _HIST[1:].copy()
    smoothed = counts + 0.5
    total = smoothed.sum()
    p = smoothed / total
    _CACHED_PROB = np.zeros(101, dtype=np.float64)
    _CACHED_PROB[1:] = p


def priority(item, bins):
    """Score each fitting bin: strongly prefer small residuals, mildly reward
    residuals that are likely to be exactly filled later.
    """
    global _TOTAL

    # Record this item first so the distribution reflects the current stream.
    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0:
        _refresh_prob()

    residual = bins - item  # >= 0 for all shown bins

    # Best fit primary: negative residual dominates (exact fit best).
    base = -residual.astype(np.float64)

    # Look-ahead bonus: residuals that future items are likely to fit exactly.
    prob = _CACHED_PROB[residual]

    # Small weight so it only breaks near-ties, never overrides best fit.
    bonus = 4.0 * prob

    return base + bonus
# EVOLVE-BLOCK-END
