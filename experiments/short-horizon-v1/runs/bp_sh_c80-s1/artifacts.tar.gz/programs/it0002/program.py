# EVOLVE-BLOCK-START
"""Best fit with a tie-break preference toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item
    # Primary: best fit (smallest remaining capacity after placement).
    # Secondary: prefer fuller bins (smaller pre-placement remaining capacity) to
    # concentrate load and avoid fragmenting free space.
    return -rem.astype(np.float64) - 1e-3 * bins.astype(np.float64)
# EVOLVE-BLOCK-END
