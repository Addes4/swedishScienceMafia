# EVOLVE-BLOCK-START
"""Best fit with a small first-fit tiebreak toward earlier bins."""
import numpy as np


def priority(item, bins):
    """Rank bins: tightest fit first, then earlier (lower-index) bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smallest post-placement residual (best fit).
    # Secondary: earlier bins have slightly larger score so they win ties.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    return -residual.astype(np.float64) - idx * 1e-6
# EVOLVE-BLOCK-END
