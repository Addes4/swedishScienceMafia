# EVOLVE-BLOCK-START
"""Best fit with online histogram-aware residual preference."""
import numpy as np


class _State:
    def __init__(self):
        # counts of item sizes seen so far (1..100); index 0 unused
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def observe(self, item):
        self.counts[item] += 1.0
        self.total += 1.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state.observe(item)

    residual = bins - item  # >= 0 for all provided bins

    # Best fit: smaller residual is better.
    score = -residual.astype(np.float64)

    # Bonus if the post-placement residual matches a common future item size.
    # Frequency of each residual size among past items (tunable weight).
    counts = _state.counts
    total = _state.total
    if total > 0:
        freq = counts / total
        # Look up frequency for each residual (clip to valid range).
        r = residual
        valid = (r >= 1) & (r <= 100)
        bonus = np.zeros_like(score)
        if np.any(valid):
            bonus[valid] = freq[r[valid]]
        score += 0.01 * bonus

    return score
# EVOLVE-BLOCK-END

