# EVOLVE-BLOCK-START
"""Best fit with a mild preference for residuals that match likely future items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit (smaller residual -> higher score).
    score = -residual.astype(np.float64)
    # Mild bonus for residuals near the typical item size (~40), so that leftover
    # space stays usable by a likely future item rather than being wasted.
    score += 0.5 * np.exp(-((residual - 40.0) ** 2) / (2.0 * 15.0 * 15.0))
    return score
# EVOLVE-BLOCK-END
