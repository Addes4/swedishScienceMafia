# EVOLVE-BLOCK-START
"""Best fit with explicit perfect-fit preference and fuller-bin tie-breaking."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # smaller residual == tighter fit
    # Primary: prefer smaller residual. Perfect fit (residual 0) should dominate,
    # so scale it strongly; then tighter fits next; then prefer fuller bins.
    score = -residual.astype(np.float64)
    # Emphasize exact perfect fits.
    score += (residual == 0).astype(np.float64) * 1e6
    return score
# EVOLVE-BLOCK-END
