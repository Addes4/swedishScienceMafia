# EVOLVE-BLOCK-START
"""Best fit with a mild randomized tie-break to reduce systematic fragmentation."""
import numpy as np

_rng = np.random.default_rng(12345)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual = bins - item
    # Deterministic best fit: -residual (smaller residual -> higher score).
    base = -residual.astype(np.float64)
    # Small noise, proportional to a fraction of one unit of residual gap, so that
    # near-ties can go either way but clear best fits still dominate.
    noise = _rng.random(bins.shape[0]) * 0.5
    return base + noise
# EVOLVE-BLOCK-END
