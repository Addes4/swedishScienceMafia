# EVOLVE-BLOCK-START
"""Best fit with a smoothed, bounded bonus for residuals likely to be reused."""
import numpy as np


# Online histogram of item sizes seen so far (updated once per call).
_HIST = np.zeros(101, dtype=np.float64)   # counts for sizes 1..100
_TOTAL = 0.0
_RECOMPUTE_EVERY = 25
_CACHED_PROB = np.zeros(101, dtype=np.float64)


def _refresh_prob():
    global _CACHED_PROB
    if _TOTAL <= 0:
        _CACHED_PROB = np.zeros(101, dtype=np.float64)
        return
    p = _HIST / _TOTAL
    # Laplace-style smoothing toward a broad prior so it stays stable early on.
    _CACHED_PROB = p


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Dominant term is best fit (smallest post-placement residual).  We add a small,
    bounded bonus when the residual equals a size the stream has recently produced
    often, since that gap is likely to be filled by a future item instead of stranded.
    """
    global _TOTAL

    # Record this item (given before ranking).
    _HIST[item] += 1.0
    _TOTAL += 1.0
    if int(_TOTAL) % _RECOMPUTE_EVERY == 0:
        _refresh_prob()

    residual = (bins - item).astype(np.float64)  # >= 0 for all shown bins

    # Best-fit base: prefer the smallest residual.
    base = -residual

    # Probability the residual size arrives as a future item.
    prob = _CACHED_PROB[residual.astype(np.int64)]

    # Small bounded bonus so best-fit stays dominant; only breaks near-ties.
    bonus = 2.0 * prob

    return base + bonus
# EVOLVE-BLOCK-END
