# EVOLVE-BLOCK-START
"""Best fit with an EWMA-learned penalty for stranding common residuals."""
import numpy as np


# Online exponentially-weighted estimate of the item-size pmf (updated per call).
_PMF = np.zeros(101, dtype=np.float64)
_ALPHA = 0.02
_PRIOR = 1.0 / 100.0  # uniform prior mass over sizes 1..100


def priority(item, bins):
    """Return a priority for every fitting bin; highest score wins (first on ties).

    Base is best fit (smallest post-placement residual).  We add a reward when the
    residual r is a size the stream frequently produces, since such a gap is
    likely to be reused by a future item instead of being stranded.
    """
    # Update EWMA pmf toward a one-hot of the current item size.
    _PMF *= (1.0 - _ALPHA)
    _PMF[item] += _ALPHA

    residual = bins - item  # >= 0 for all shown bins
    base = -residual.astype(np.float64)

    # Estimated probability that some future item exactly fills the residual.
    prob = _PMF[residual]

    # Reward reusable residuals; scale so it can break close best-fit ties but
    # never dominates an exact fit or a meaningfully smaller residual.
    reward = 40.0 * prob

    return base + reward
# EVOLVE-BLOCK-END
