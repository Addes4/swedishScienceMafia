# EVOLVE-BLOCK-START
"""Harmonic-style bin choice: minimize increase in sum of squared residuals,
which favors tightly fitting bins while penalizing scattering into roomy bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    r = bins.astype(np.float64)
    new_r = r - item
    # increase in sum of squared residuals
    delta = new_r * new_r - r * r
    return -delta
# EVOLVE-BLOCK-END

