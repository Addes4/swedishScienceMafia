# EVOLVE-BLOCK-START
"""Best-fit with tightness emphasis and conditional empty-bin promotion."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    rem_f = rem.astype(np.float64)

    # Primary criterion: best fit (prefer smallest leftover), with a mild
    # super-linear emphasis on tight fits to encourage exact-fitting.
    score = -(rem_f + 0.02 * rem_f * rem_f)

    is_empty = bins == 100

    # Wasteful-gap penalty: a used bin leaving a residual larger than the item
    # is a poor fit and blocks future mid-size items.
    wasteful = (rem > item) & (~is_empty)
    score += wasteful.astype(np.float64) * (item + 1)

    # Empty-bin promotion, but only for large items and only when no used bin
    # already offers a reasonably tight fit (leftover <= half the item).
    if item >= 60:
        used_rem = rem[~is_empty]
        tight_exists = used_rem.size > 0 and used_rem.min() <= item * 0.5
        if not tight_exists:
            scale = (item - 60.0) / 40.0  # 0 at 60, up to 1.0 at 100
            score += scale * (item + 1) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
