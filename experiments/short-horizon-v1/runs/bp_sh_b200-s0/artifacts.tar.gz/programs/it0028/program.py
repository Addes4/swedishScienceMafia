# EVOLVE-BLOCK-START
"""Hybrid: best-fit for good fits, but prefer a fresh bin when the fit is wasteful."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # If placing into a used bin would leave a large remainder (a wasteful gap that is
    # hard to fill later), promote unused bins (remaining capacity == 100).
    is_empty = bins == 100
    # Penalize non-empty bins whose resulting gap is "awkward" (big leftover).
    # Scale the penalty so it only overrides when the leftover is large.
    awkward = np.clip(rem - item, 0, None)  # leftover exceeding the item size
    score -= awkward.astype(np.float64) * (~is_empty)

    # Extra: strongly discourage creating a gap bigger than a "typical" item (mean ~40),
    # since such gaps are hard to refill; this makes fresh bins win in wasteful cases.
    big_gap = np.clip(rem - 40, 0, None)
    score -= big_gap.astype(np.float64) * 2.0 * (~is_empty)
    return score
# EVOLVE-BLOCK-END

