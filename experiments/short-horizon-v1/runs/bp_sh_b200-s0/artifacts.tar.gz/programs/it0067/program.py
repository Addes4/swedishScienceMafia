# EVOLVE-BLOCK-START
"""Best fit with a small bonus for reusing partially-filled bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Small bonus for reusing a non-empty bin, to consolidate items and avoid
    # opening fresh bins unnecessarily. Empty bins (remaining == 100) get none.
    is_empty = bins == 100
    score += 0.5 * (~is_empty)
    return score
# EVOLVE-BLOCK-END

