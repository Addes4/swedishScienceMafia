# EVOLVE-BLOCK-START
"""Best-fit primary with smooth, self-tuning empty-bin promotion and consolidation:
prefer used bins whose residual is close to a typical future item (best fit),
but allow opening a fresh bin when the arriving item is large relative to the
running mean, since such items rarely fit well into existing gaps."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover after placing item
    score = -rem.astype(np.float64)  # primary: best fit (small leftover)

    is_empty = bins == 100

    # Penalize leaving a gap larger than the item itself in a used bin:
    # such a gap is often too big to be reusable and indicates a poor fit.
    wasteful = (rem > item) & (~is_empty)
    score += wasteful.astype(np.float64) * (item + 1.0)

    # Smooth empty-bin promotion: the larger the item relative to the running
    # mean, the more it deserves a fresh bin (existing gaps rarely suit it).
    rel = item / max(mean_item, 1.0)
    if rel > 1.0:
        bonus = (rel - 1.0) * (item + 1.0) * is_empty.astype(np.float64)
        score += bonus

    # Consolidation nudge for typical/small items: prefer a used bin whose
    # residual is still useful (>= half mean) over opening a fresh bin.
    if rel <= 1.0:
        useful_used = (rem >= 0.5 * mean_item) & (rem <= item) & (~is_empty)
        score += 0.5 * (item + 1.0) * useful_used.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

