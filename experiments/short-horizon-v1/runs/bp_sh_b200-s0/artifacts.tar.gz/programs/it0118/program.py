# EVOLVE-BLOCK-START
"""Best-fit primary, with item-size-scaled empty-bin promotion for large items
and a stateful consolidation nudge for typical-size items."""
import numpy as np

# Per-stream running statistics (reset when a fresh stream starts).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running statistics.
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item

    rem_f = rem.astype(np.float64)
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem_f

    is_empty = bins == 100

    # Absolute wasteful-gap test: a used bin leaving a residual larger than the
    # item itself is a poor fit.
    wasteful = (rem > item) & (~is_empty)
    score += wasteful.astype(np.float64) * (item + 1.0)

    # Item-size-scaled empty-bin promotion: reserve a fresh bin mainly for
    # large items, while letting smaller items consolidate into used bins.
    scale = (item - 50.0) / 50.0  # <=0 for items up to 50, up to 1.0 at 100
    if scale > 0:
        bonus = scale * (item + 1.0) * is_empty.astype(np.float64)
        score += bonus
    else:
        # Consolidation nudge: for typical/small items, prefer a used bin whose
        # residual stays useful (>= the running mean item size, so it can still
        # seat a future typical item) over opening a fresh bin.
        useful_used = (rem >= mean_item) & (rem <= item) & (~is_empty)
        score += 0.5 * (item + 1.0) * useful_used.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

