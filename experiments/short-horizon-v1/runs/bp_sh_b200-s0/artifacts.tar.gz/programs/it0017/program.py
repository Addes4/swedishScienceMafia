# EVOLVE-BLOCK-START
"""Hybrid: best-fit with a small bonus for leftovers matching common item sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Small bonus for leftovers near the item size: a gap about the size of a typical
    # item is more likely to be filled by an upcoming item, at little cost to best-fit.
    bonus = -np.abs(rem - item).astype(np.float64) * 0.05
    score += bonus
    return score
# EVOLVE-BLOCK-END

