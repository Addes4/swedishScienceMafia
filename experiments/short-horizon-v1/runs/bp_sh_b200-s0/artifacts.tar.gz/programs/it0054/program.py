# EVOLVE-BLOCK-START
"""Best-fit with an online-learned residual-value bonus."""
import numpy as np


# Module-level state: exponential moving average of "did a bin with residual r get
# filled later" is too complex; instead track a small bucketed value table learned
# from the observed item sizes so residuals near common sizes are favored.
_BUCKETS = 16  # residual buckets of width 100/16
_VALUE = np.zeros(_BUCKETS, dtype=np.float64)
_MEAN = 40.0
_ALPHA = 0.05


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _MEAN

    # Update a running mean of observed items (no future information used).
    _MEAN = (1.0 - _ALPHA) * _MEAN + _ALPHA * float(item)

    rem = bins - item  # leftover capacity after placing the item
    score = -rem.astype(np.float64)  # base: best fit

    # Reward exact fills strongly.
    score += 5.0 * (rem == 0)

    # Reward residuals that are near the running mean item size (likely fillable).
    score += 0.5 * np.exp(-np.abs(rem - _MEAN) / 10.0)

    # Tiny preference for non-empty bins to consolidate.
    score += 0.01 * (bins < 100)
    return score
# EVOLVE-BLOCK-END

