# EVOLVE-BLOCK-START
"""Best-fit primary, with a light stateful empty-bin nudge for large items and
a perfect-fill reward for used bins, keeping the robust best-fit ordering."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item
    score = -rem.astype(np.float64)  # best fit dominant

    is_empty = bins == 100

    # Reward used bins that would be filled exactly (perfect fill is always good).
    perfect = (rem == 0) & (~is_empty)
    score += perfect.astype(np.float64) * (item + 1)

    # Mild empty-bin nudges, scaled by item size relative to the running mean.
    # For items at or above the mean, opening a fresh bin is often worth it
    # (avoids fragments too small to reuse); for small items, prefer packing.
    if item >= mean_item:
        # Promote empty bins mildly, proportional to how large the item is.
        bonus = (item / 100.0) * (item + 1) * is_empty.astype(np.float64)
        score += 0.6 * bonus
    else:
        # For small items, discourage an empty bin just slightly less than a
        # poor used bin, keeping consolidation but not forcing it.
        score -= 0.3 * (item + 1) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

