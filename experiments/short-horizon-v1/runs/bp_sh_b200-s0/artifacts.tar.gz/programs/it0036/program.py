# EVOLVE-BLOCK-START
"""Hybrid: best-fit for good fits, but prefer a fresh bin when the best fit is wasteful."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Best-fit leftover among used (non-empty) bins.
    FLT_MAX = np.float64(1e18)
    used_rem = np.where(is_empty, FLT_MAX, rem)
    best_used_rem = used_rem.min() if used_rem.size else FLT_MAX

    # If even the best used-bin placement wastes a lot (leftover >= item size),
    # promote a fresh bin instead.
    if best_used_rem < FLT_MAX and best_used_rem >= item:
        score += float(best_used_rem) * is_empty

    return score
# EVOLVE-BLOCK-END


