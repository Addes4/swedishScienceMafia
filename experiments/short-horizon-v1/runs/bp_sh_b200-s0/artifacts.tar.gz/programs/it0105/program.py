# EVOLVE-BLOCK-START
"""Best-fit primary, with residual-aware empty-bin promotion."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100
    used = ~is_empty

    # For each used bin, judge how awkward the residual would be: a residual
    # that is large relative to the item is hard to fill later (wasteful).
    # We promote an empty bin proportionally to the best (smallest) such
    # awkward residual among used bins, so large items that cannot be packed
    # tightly prefer a fresh bin, while items that fit snugly consolidate.
    if used.any():
        used_rem = rem[used]
        best_used_rem = used_rem.min()
        # Only care if even the best used placement leaves a big residual.
        # Ramp: 0 when best_used_rem <= item (snug), up to 1 when >= 2*item.
        excess = (best_used_rem - item) / float(item)
        awkwardness = min(max(excess, 0.0), 1.0)
    else:
        awkwardness = 1.0

    # Empty-bin promotion, gated by the awkwardness of the best used fit and
    # scaled by item size (large items benefit most from a fresh bin).
    size_scale = max(0.0, (item - 30.0) / 70.0)
    bonus = awkwardness * size_scale * (item + 1.0)
    score += bonus * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
