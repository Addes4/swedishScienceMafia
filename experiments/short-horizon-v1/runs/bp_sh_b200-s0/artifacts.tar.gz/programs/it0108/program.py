# EVOLVE-BLOCK-START
"""Best-fit with a fillability-aware tie-break and empty-bin promotion for large items."""
import numpy as np

# Typical item size for the stream distribution (Weibull-shaped, mean ~40).
_MEAN_ITEM = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # leftover capacity after placing the item

    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem

    is_empty = bins == 100

    # Fillability tie-break: among similar fits, prefer a leftover that is itself
    # close to a typical future item size (so it can be filled later), rather than
    # a tiny gap that is hard to fill. Small bonus, only matters near-ties.
    fillable = np.exp(-((rem - _MEAN_ITEM) ** 2) / (2.0 * (0.6 * _MEAN_ITEM) ** 2))
    score += 0.35 * fillable

    # Wasteful-gap penalty: a used bin whose leftover exceeds the item is a poor
    # fit (the residual is large but the placement is still "large-gap").
    wasteful = (rem > item) & (~is_empty)
    score -= wasteful.astype(np.float64) * (item + 1)

    # Item-size-scaled empty-bin promotion: strongly reserve a fresh bin for large
    # items (hard to place later), while letting medium items consolidate into
    # used bins. Ramp starts around the distribution mean.
    scale = (item - 40.0) / 60.0  # <=0 up to 40, -> ~1.0 at 100
    if scale > 0:
        score += scale * (item + 1) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
