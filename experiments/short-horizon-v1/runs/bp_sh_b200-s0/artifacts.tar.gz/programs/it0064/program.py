# EVOLVE-BLOCK-START
"""Best fit with a bonus for residuals that are likely to be filled by a future item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Track a running estimate of the typical item size (EMA), stored on the function.
    state = priority.__dict__
    mean = state.get("mean", 40.0)
    mean = 0.98 * mean + 0.02 * item
    state["mean"] = mean

    # Reward residuals near the expected next item size (likely to be filled soon),
    # and strongly reward exact fills.
    target = mean
    closeness = np.exp(-((rem - target) / max(target, 1.0)) ** 2)
    score += 3.0 * closeness

    exact = rem == 0
    score += 10.0 * exact

    return score
# EVOLVE-BLOCK-END
