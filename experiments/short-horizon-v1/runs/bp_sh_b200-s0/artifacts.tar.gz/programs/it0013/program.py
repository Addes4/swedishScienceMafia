# EVOLVE-BLOCK-START
"""Best-fit with a small preference for opening fresh bins on near-ties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Small bonus toward unused bins (remaining capacity == 100) to avoid
    # fragmenting used bins on near-ties; magnitude kept tiny so best-fit dominates.
    is_empty = bins == 100
    score += is_empty.astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END
