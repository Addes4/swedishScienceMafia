# EVOLVE-BLOCK-START
"""Best fit with a proportional empty-bin bonus to avoid wasteful small leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    score = -rem.astype(np.float64)  # base: best fit (smallest leftover)

    # Empty bins: add a modest bonus proportional to the item size so that opening a
    # fresh bin is preferred only when all used bins would leave a relatively large gap.
    is_empty = bins == 100
    score += is_empty.astype(np.float64) * (0.25 * item)
    return score
# EVOLVE-BLOCK-END

