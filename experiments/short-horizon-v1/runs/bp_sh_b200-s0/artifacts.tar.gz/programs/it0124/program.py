# EVOLVE-BLOCK-START
"""Best-fit primary, with a wasteful-gap penalty and a single unified
empty-bin term: promote empties only for large items, penalize them for
item sizes below the running mean to encourage consolidation."""
import numpy as np

# Per-stream running statistics (soft, adapts across the stream).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = (bins == 100).astype(np.float64)

    # Absolute wasteful-gap penalty: leaving a residual larger than the item
    # itself in a used bin is a poor fit.
    wasteful = (rem > item) & (bins != 100)
    score += wasteful.astype(np.float64) * (item + 1)

    # Unified empty-bin term: for items at/above the running mean, promote
    # opening a fresh bin (they are large relative to the stream); for smaller
    # items, penalize empties to encourage consolidation into used bins.
    scale = (item - mean_item) / 50.0  # positive for large, negative for small
    score += scale * (item + 1) * is_empty

    return score
# EVOLVE-BLOCK-END

