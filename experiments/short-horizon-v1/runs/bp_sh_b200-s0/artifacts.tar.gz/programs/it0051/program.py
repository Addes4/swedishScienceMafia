# EVOLVE-BLOCK-START
"""Best-fit with exact-fill reward and a mild fresh-bin penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Strong reward for exact fills (leftover 0) -- perfect packing.
    score += (rem == 0).astype(np.float64) * 1.5

    # Mild penalty for opening a fresh bin (remaining capacity == 100) unless
    # the best used-bin fit is wasteful. This encourages consolidation.
    is_empty = (bins == 100)
    score -= is_empty.astype(np.float64) * 0.25 * (rem > item)
    return score
# EVOLVE-BLOCK-END

