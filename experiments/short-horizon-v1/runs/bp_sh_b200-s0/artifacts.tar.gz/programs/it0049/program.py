# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware residual-matching bonus.

Base rule: best fit (prefer smallest leftover after placing the item).
Refinement: bins whose leftover after placement is an item size that the
stream keeps producing are slightly cheaper to "close" later, so give them a
small bonus.  The histogram of past item sizes is tracked with an
exponentially weighted counter so the rule adapts to the (unknown) item
distribution without seeing the future.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Lazily build / refresh the exponentially weighted item histogram (sizes 1..100).
    hist = priority.hist
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        priority.hist = hist
    # decay then record the current item (weight by count for decayed mass)
    hist *= priority.decay
    hist[item] += 1.0

    rem = bins - item  # leftover capacity after placing the item

    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Residual-matching bonus: leftover capacities that match a frequently seen
    # item size are easy to fill later, so promote them slightly.
    # Normalize the histogram into a per-size "fillability" weight.
    h = hist[1:101]
    total = h.sum()
    if total > 0:
        fill = h / total  # probability-ish weight per leftover size 0..99
    else:
        fill = None

    if fill is not None:
        # rem ranges 0..99 (used bins) or up to 100 (empty bins).
        clipped = np.clip(rem, 0, 99).astype(np.int64)
        bonus = fill[clipped]
        score += bonus * priority.bonus_scale

    return score


priority.hist = None
priority.decay = 0.995
priority.bonus_scale = 6.0
# EVOLVE-BLOCK-END

