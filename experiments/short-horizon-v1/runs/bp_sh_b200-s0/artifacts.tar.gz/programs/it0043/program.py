# EVOLVE-BLOCK-START
"""Best-fit, but open a fresh bin when every used-bin fit wastes over half the item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    score = -rem.astype(np.float64)  # best fit: prefer smallest leftover

    is_empty = bins == 100
    # Best (smallest) leftover achievable in a used bin.
    used_rem = np.where(is_empty, np.iinfo(np.int64).max, rem)
    best_used = used_rem.min()
    # If the best used-bin fit would waste more than half the item, promote a fresh bin.
    threshold = item * 0.5
    if best_used > threshold:
        score += is_empty.astype(np.float64) * (best_used + 1.0)
    return score
# EVOLVE-BLOCK-END

