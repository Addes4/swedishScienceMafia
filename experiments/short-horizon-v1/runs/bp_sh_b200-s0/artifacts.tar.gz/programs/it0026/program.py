# EVOLVE-BLOCK-START
"""Best-fit with a small, distribution-aware preference for leaving useful gaps."""
import numpy as np

_state = {"sum": 0.0, "n": 0}
_TARGET = None


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _TARGET
    # Online running mean of item sizes -> estimate of a "typical useful leftover".
    _state["sum"] += item
    _state["n"] += 1
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item
    rem_f = rem.astype(np.float64)

    # Dominant term: best fit (prefer smallest leftover). This is standard BF.
    score = -rem_f

    # Secondary term: reward leftovers close to the typical item size (mean), since a gap
    # of about one mean-sized item is fillable later, while very small gaps below the
    # smallest common item are wasted. Keep this strictly smaller than the best-fit
    # spacing (1.0 per unit) so it only breaks near-ties.
    target = mean_item
    score -= np.abs(rem_f - target) * 0.05

    return score
# EVOLVE-BLOCK-END
