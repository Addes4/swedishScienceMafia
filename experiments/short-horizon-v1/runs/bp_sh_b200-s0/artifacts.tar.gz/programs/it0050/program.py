# EVOLVE-BLOCK-START
"""Best-fit with exact-fill bonus and consolidation tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Strong bonus for perfect fills.
    score += (rem == 0) * 1000.0

    # Mild preference to consolidate into already-used bins (avoid opening fresh ones).
    score += (bins != 100) * 0.5

    return score
# EVOLVE-BLOCK-END

