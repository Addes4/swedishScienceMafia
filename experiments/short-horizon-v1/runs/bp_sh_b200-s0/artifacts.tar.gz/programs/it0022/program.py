# EVOLVE-BLOCK-START
"""Hybrid: best-fit with a strong reward for completing a bin (leftover 0)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    rem = rem.astype(np.float64)

    # Base: best fit (prefer smallest leftover).
    score = -rem

    # Strong bonus for a perfect completion (leftover exactly 0): the bin is full and
    # removed from future consideration, effectively gaining a fresh bin.
    score += 200.0 * (rem == 0)

    # Mild bonus for nearly-full bins: leftover small relative to item size is easier
    # to fill later with a single small item, so reward it slightly.
    score -= np.clip(rem - item, 0, None)  # penalize awkward large gaps

    return score
# EVOLVE-BLOCK-END
