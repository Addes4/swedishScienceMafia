# EVOLVE-BLOCK-START
"""Best-fit primary, with a residual-quality gate for empty-bin promotion."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Absolute wasteful-gap test: a used bin whose residual exceeds the item
    # itself is a poor fit.
    wasteful = (rem > item) & (~is_empty)
    score += wasteful.astype(np.float64) * (item + 1)

    # Empty-bin promotion: prefer a fresh bin exactly when placing the item in
    # a used bin would leave a small, hard-to-fill residual. The closer the
    # best used residual is to zero, the more worthwhile reserving a new bin.
    # Use a Gaussian bump centered slightly above zero.
    used = ~is_empty
    if used.any():
        best_used_rem = rem[used].min()
        # 0..1 ramp: 1 when residual ~0 (awkward), 0 when residual >= item.
        if best_used_rem < item:
            urgency = np.exp(-(best_used_rem / max(item * 0.3, 1.0)) ** 2)
        else:
            urgency = 0.0
        score += urgency * (item + 1) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
