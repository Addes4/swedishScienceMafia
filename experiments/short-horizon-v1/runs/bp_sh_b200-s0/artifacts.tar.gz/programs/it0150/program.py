# EVOLVE-BLOCK-START
"""Best-fit with a graded close-the-bin bonus for tiny post-placement residuals."""
import numpy as np

# Per-stream running statistics (reset when a fresh stream starts).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Graded close-the-bin bonus: strongly reward used bins whose post-placement
    # residual is small, since sealing a bin prevents further openings. The
    # bonus grows as the residual shrinks toward zero.
    used = ~is_empty
    small_res = (rem <= 0.25 * item) & used
    score += small_res.astype(np.float64) * (item + 1)

    # Mild empty-bin promotion for genuinely large items so they don't get
    # crammed into a partially-used bin and orphan the residual.
    scale = (item - mean_item) / 100.0
    if scale > 0:
        score += scale * (item + 1) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
