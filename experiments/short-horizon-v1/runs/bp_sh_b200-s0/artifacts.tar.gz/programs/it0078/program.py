# EVOLVE-BLOCK-START
"""Fuller-bin-first: place into the fullest bin that fits, tie-break by best fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Prefer the fullest bin (smallest pre-placement remaining capacity).
    # Tie-break by best fit (smallest residual).
    return -(bins.astype(np.float64) * 2.0 + rem.astype(np.float64) * 0.001)
# EVOLVE-BLOCK-END
