# EVOLVE-BLOCK-START
"""Harmonic-style packing rule for online bin packing."""

import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Harmonic bin-choice rule: classify the arriving item by its harmonic size class
    # (largest power of 2 <= item) and prefer the bin whose leftover best matches the
    # upper boundary of that class. This groups items into size classes so that
    # similarly-sized items tend to share bins.
    sb = 1
    while sb * 2 <= item:
        sb *= 2
    # top of the item's class: value just below 2*sb (capped at capacity)
    top = min(2 * sb, 100)

    # For used bins, reward staying close to the class top (target leftover), i.e. we want
    # the leftover after placement to be small relative to the class boundary. Best fit is
    # naturally captured: prefer the smallest leftover among used bins.
    used = bins < 100
    is_empty = ~used

    # Primary term: best fit for used bins (smallest leftover).
    score = -rem.astype(np.float64)

    # Fresh-bin promotion only when the best used-bin fit would leave a leftover that is
    # still at least the class-top scale (a strong indicator the fit is wasteful).
    if np.any(used):
        best_used_rem = int(np.min(rem[used]))
        if best_used_rem >= top:
            score[is_empty] += float(best_used_rem - top + 1)
    return score
# EVOLVE-BLOCK-END
