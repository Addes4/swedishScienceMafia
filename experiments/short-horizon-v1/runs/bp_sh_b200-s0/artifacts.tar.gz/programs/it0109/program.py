# EVOLVE-BLOCK-START
"""Best-fit with residual-aware empty-bin reservation.

Primary term is pure best-fit (smallest leftover). On top of it we add:
  * a "wasteful gap" penalty for used bins that would leave a residual
    strictly larger than the arriving item (a gap future items may not fill);
  * a residual-aware empty-bin bonus: a fresh bin is promoted only when the
    best used-bin residual would be large relative to the item, scaled by the
    item size so that large items (hard to place later) reserve a new bin while
    medium items keep consolidating. The bonus is capped so best-fit ordering
    among used bins is never disturbed.
"""
import numpy as np


def priority(item, bins):
    rem = bins - item                    # leftover after placing the item
    score = -rem.astype(np.float64)      # primary: best fit

    is_empty = bins == 100

    # Wasteful-gap penalty: a used bin leaving a residual bigger than the item
    # itself is a poor fit (the gap is unlikely to be filled later).
    wasteful = (rem > item) & (~is_empty)
    score += wasteful.astype(np.float64) * (item + 1)

    # Residual-aware empty-bin promotion.
    used = ~is_empty
    if used.any():
        best_used_res = rem[used].min()          # leftover in the best used bin
    else:
        best_used_res = 0

    # How large is that leftover relative to the item? 0 => perfect-ish, 1 => >= item.
    rel = best_used_res / float(item) if item > 0 else 0.0
    # Promotion strength: only when consolidation would leave a notable gap,
    # ramped by item size (large items benefit from a fresh bin).
    size_gate = min(max((item - 40.0) / 60.0, 0.0), 1.0)  # 0 at <=40, 1 at 100
    gap_gate = min(max((rel - 0.25) / 0.75, 0.0), 1.0)    # 0 if small gap, 1 if big
    bonus = size_gate * gap_gate * (item + 1)

    score += bonus * is_empty.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
