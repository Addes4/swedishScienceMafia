# EVOLVE-BLOCK-START
"""Best-fit with a decisive exact-fit bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Decisive bonus for an exact fit: residual 0 means a perfectly packed bin.
    # Make it larger than any possible residual difference so exact fits always win,
    # but keep it additive on top of best-fit for everything else.
    score += (rem == 0).astype(np.float64) * 101.0
    return score
# EVOLVE-BLOCK-END
