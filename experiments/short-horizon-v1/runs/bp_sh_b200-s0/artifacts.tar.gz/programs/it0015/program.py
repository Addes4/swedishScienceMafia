# EVOLVE-BLOCK-START
"""Almost-worst-fit: prefer the largest leftover, but avoid useless slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover after placing the item
    # Worst fit: prefer the largest leftover, which keeps bins balanced and
    # preserves many medium-sized gaps for future items.
    score = rem.astype(np.float64)
    return score
# EVOLVE-BLOCK-END

