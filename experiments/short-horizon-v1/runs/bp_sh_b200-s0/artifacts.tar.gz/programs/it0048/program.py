# EVOLVE-BLOCK-START
"""Best-fit with a threshold that opens a fresh bin only when consolidation is wasteful."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"] if _state["n"] > 0 else 40.0

    rem = bins - item  # leftover after placing
    score = -rem.astype(np.float64)

    is_empty = bins == 100
    if is_empty.any() and (~is_empty).any():
        best_used_rem = int(rem[~is_empty].min())
        # If best used-bin placement leaves a residual too large to be filled
        # well by a typical future item, prefer a fresh bin.
        if best_used_rem > mean_item:
            score += is_empty.astype(np.float64) * (best_used_rem - mean_item + 1.0)

    return score
# EVOLVE-BLOCK-END
