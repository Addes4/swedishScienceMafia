# EVOLVE-BLOCK-START
"""Best-fit with a tuned empty-bin avoidance penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Primary: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Penalize opening a fresh (unused) bin when a used bin provides a reasonably
    # tight fit. The penalty grows with the best used-bin residual, so it activates
    # only when consolidation would leave a wasteful gap.
    is_empty = bins == 100
    # Best (smallest) residual achievable in a used bin; if none, use a large value.
    used = ~is_empty
    if np.any(used):
        best_used_rem = np.min(rem[used])
    else:
        best_used_rem = 100
    # Penalty on empty bins: proportional to how much worse the used-bin fit is
    # relative to the item itself.
    penalty = np.clip(best_used_rem - item, 0, None) * 0.5
    score -= is_empty.astype(np.float64) * penalty
    return score
# EVOLVE-BLOCK-END
