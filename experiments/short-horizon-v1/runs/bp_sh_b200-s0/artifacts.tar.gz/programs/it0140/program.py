# EVOLVE-BLOCK-START
"""Best-fit primary, with item-size-proportional empty-bin reluctance and a
symmetric reusable-residual bonus. State is a soft running mean of item sizes."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Empty-bin reluctance: reserving a fresh bin is only worth it for items that
    # are large relative to the running mean. Penalty grows with item size so the
    # best-fit ordering among used bins is untouched (all used bins share it).
    empty_pen = 0.5 * item * is_empty.astype(np.float64)
    score -= empty_pen

    # Symmetric bonus: reward leaving a residual that is a decent size relative
    # to the running mean (likely reusable by a future item), but only for used
    # bins so empty bins aren't double-favored.
    reusable = ((rem >= 0.5 * mean_item) & (rem <= item) & (~is_empty)).astype(np.float64)
    score += 0.5 * reusable

    return score
# EVOLVE-BLOCK-END
