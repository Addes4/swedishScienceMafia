# EVOLVE-BLOCK-START
"""Best-fit primary, with residual-quality scoring: prefer used bins that either
close (tiny leftover) or leave a residual matching a typical future item, and
discourage opening fresh bins except for large items."""
import numpy as np

# Per-stream running statistics (reset softly across the stream).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = (bins - item).astype(np.float64)  # leftover capacity after placing item
    is_empty = bins == 100

    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem

    # Residual-quality bonus for used bins: a residual that either closes the bin
    # (<= mean_item, likely unusable later) or matches a typical future item
    # (usable later) is good packing. Reward small residuals, scaled by item size.
    used = ~is_empty
    # closer to zero leftover is better; also reward residuals near a typical item size
    quality = np.exp(-(rem / (mean_item + 1.0)))  # peaks at rem=0, decays
    match = np.exp(-((rem - mean_item) ** 2) / (2.0 * (mean_item + 1.0) ** 2))
    score += (item + 1) * (0.6 * quality + 0.2 * match) * used

    # Empty-bin penalty scaled by item size: reserving a fresh bin is only worth
    # it for large items; small items should consolidate into used bins.
    empty_penalty = ((50.0 - item) / 50.0)
    score += (item + 1) * empty_penalty * is_empty

    return score
# EVOLVE-BLOCK-END

