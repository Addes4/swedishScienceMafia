# EVOLVE-BLOCK-START
"""Best-fit primary with data-driven gap-fillability bonus for consolidation."""
import numpy as np

# Running histogram of item sizes, shared across calls within a stream.
# Indexed 0..100; index 0 unused.
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_DECAY = 0.999

# Cache of "fillability" weights derived from the histogram: for a residual r,
# how likely are future items to fit exactly into it (small leftover after fill).
def _update_hist(item):
    global _HIST, _TOTAL
    _HIST *= _DECAY
    _HIST[item] += 1.0
    _TOTAL = _TOTAL * _DECAY + 1.0


def _fillability_weight(rem_arr):
    """For each residual value, score how 'fillable' it is by future items.

    A residual r is good if some typical future item s can be placed leaving
    a small leftover (r - s) that is itself likely fillable, i.e. near 0 or
    matching another common size. We approximate by the probability mass that
    a future item is <= r and close to r (leaving small slack)."""
    # Probability mass of items exactly equal to some size s <= r such that
    # r - s is small. We compute best (largest) mass over s in [max(1,r-BAND), r].
    BAND = 8
    w = np.zeros_like(rem_arr, dtype=np.float64)
    denom = _TOTAL if _TOTAL > 1e-9 else 1.0
    # Use the histogram as a distribution over item sizes.
    # Cumulative mass function so we can query ranges quickly.
    # For each rem, find items s in [r-BAND, r].
    for i in range(rem_arr.shape[0]):
        r = int(rem_arr[i])
        if r <= 0:
            w[i] = -1e6  # dead bin, strongly avoid
            continue
        lo = r - BAND
        if lo < 1:
            lo = 1
        if r > 100:
            r_clip = 100
        else:
            r_clip = r
        # mass of items in [lo, r_clip]; also add small mass for any item <= r
        if lo <= r_clip:
            m = _HIST[lo:r_clip + 1].sum() / denom
        else:
            m = 0.0
        # bonus also if r itself matches a common size (can be filled exactly)
        if 1 <= r_clip <= 100:
            exact = _HIST[r_clip] / denom
        else:
            exact = 0.0
        w[i] = m + 0.5 * exact
    return w


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _HIST, _TOTAL
    if item <= 0:
        item = 1
    if item > 100:
        item = 100

    # Update the running histogram BEFORE scoring (so the current item informs
    # the notion of typical sizes, though it also biases toward itself).
    _update_hist(item)

    rem = bins - item  # leftover after placing the item

    # Primary criterion: best fit, prefer smallest leftover.
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Secondary criterion: prefer leftovers that are likely fillable by future
    # (typical) items. Weight is on the leftover value of used bins.
    fill = _fillability_weight(rem)
    score += fill

    # Empty bins are not (yet) gaps: keep their leftover as "full capacity" and
    # give a mild preference so that very large items that would leave an
    # unfillable small gap in used bins prefer a fresh bin.
    # Small promotion, scaled by item size, only when the best used fit is poor.
    scale = (item - 50.0) / 50.0  # 0 for <=50 up to 1.0 at 100
    if scale > 0:
        # Apply promotion only on empty bins.
        score += (scale * 0.8) * is_empty.astype(np.float64)

    # Strongly avoid filling a used bin so tightly that a tiny (hard to fill)
    # leftover remains early in the stream when larger items are still likely.
    # This is naturally handled by the fillability weight being low for tiny
    # residuals, so no extra term is needed.

    return score
# EVOLVE-BLOCK-END
