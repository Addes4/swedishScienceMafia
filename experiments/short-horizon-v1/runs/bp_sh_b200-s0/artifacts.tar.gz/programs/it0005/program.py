# EVOLVE-BLOCK-START
"""Best-fit with a usable-gap guard: avoid leaving tiny unusable remainders.

The rule prefers the tightest fit (smallest leftover) as long as that leftover is
large enough to be filled by a typical future item.  If the tightest fit would
leave a remainder smaller than a small item, opening a fresh bin is preferred,
since that small gap is effectively wasted capacity.
"""
import numpy as np

# Online estimate of a small item size (the kind of item that can fill a sliver).
_min_seen = 100


def priority(item, bins):
    global _min_seen
    if item < _min_seen:
        _min_seen = item

    rem = bins - item  # leftover capacity after placing the item
    is_empty = bins == 100

    # Best fit: prefer the smallest leftover.
    score = -rem.astype(np.float64)

    # Guard: a used bin whose resulting remainder is too small to be reused
    # (smaller than the smallest item seen so far) is nearly as bad as a fresh
    # bin, since the sliver can never be filled.  Demote such bins below fresh
    # bins, but only when the used bin's current fill is small (i.e. it is not
    # close to full, so the sliver is true waste rather than an acceptable end).
    min_item = _min_seen if _min_seen > 0 else 1
    tiny_gap = (~is_empty) & (rem < min_item) & (bins > item + rem + item)
    # Demote: add a large negative offset for tiny-gap used bins.
    score -= tiny_gap.astype(np.float64) * 1e6

    return score
# EVOLVE-BLOCK-END


