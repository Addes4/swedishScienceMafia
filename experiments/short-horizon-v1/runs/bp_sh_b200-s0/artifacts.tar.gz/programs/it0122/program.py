# EVOLVE-BLOCK-START
"""Best-fit primary, with item-size-scaled empty-bin promotion for large items
and a stateful gap-alignment consolidation nudge for typical-size items."""
import numpy as np

# Per-stream running statistics (reset softly via a running mean).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item

    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100
    used = ~is_empty

    # Absolute wasteful-gap test: a used bin that would leave a residual larger
    # than the item itself is a poor fit.
    wasteful = (rem > item) & used
    score += wasteful.astype(np.float64) * (item + 1)

    # Item-size-scaled empty-bin promotion: reserve a fresh bin mainly for
    # large items, while letting smaller items consolidate into used bins.
    scale = (item - 50.0) / 50.0  # <=0 for items up to 50, up to 1.0 at 100
    if scale > 0:
        bonus = scale * (item + 1) * is_empty.astype(np.float64)
        score += bonus

    # Gap-alignment nudge for typical-size items: among used bins, mildly favor
    # the one whose leftover after placement is closest to the running mean item
    # size, i.e. the leftover most likely to be reusable by a future item.
    if scale <= 0 and mean_item > 0:
        target = mean_item
        gap_pen = np.abs(rem - target).astype(np.float64)
        align = used.astype(np.float64)
        # Small weight so best-fit stays dominant; only breaks near-ties.
        weight = 0.15 * (item + 1)
        score -= weight * gap_pen * align

    return score
# EVOLVE-BLOCK-END

