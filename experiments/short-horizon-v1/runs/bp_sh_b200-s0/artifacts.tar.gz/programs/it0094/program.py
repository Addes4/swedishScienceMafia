# EVOLVE-BLOCK-START
"""Best-fit with a data-driven residual-quality bonus estimated from past items."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    hist = _state["hist"]
    n = _state["n"]

    rem = bins - item  # leftover capacity after placing the item
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Estimate the probability that a bin with residual r can still receive
    # some future item favorably: use the running size histogram.
    if n > 0:
        probs = hist / n
        # For each possible residual r, quality ~ probability mass of items
        # that fit into r and leave a small gap (i.e. r - s is small relative).
        # Approximate with a vectorized lookup over unique residuals.
        quality = np.zeros(101, dtype=np.float64)
        sizes = np.arange(1, 101)
        for r in range(0, 101):
            if r <= 0:
                quality[r] = 0.0
                continue
            # items that fit: s <= r
            mask = sizes <= r
            if not np.any(mask):
                quality[r] = 0.0
                continue
            s = sizes[mask]
            gap = r - s  # leftover after placing such an item
            p = probs[mask]
            # reward residuals that are "well fillable": weight by probability
            # of an item that leaves a small residual
            w = 1.0 / (1.0 + gap.astype(np.float64))
            quality[r] = float(np.sum(p * w))
        q = quality[rem.clip(0, 100)]
    else:
        q = np.zeros_like(score)

    # Add a modest residual-quality bonus (scale chosen to sit below the
    # best-fit spacing of 1, so best-fit still dominates).
    score += 0.5 * q

    # Keep the item-size-scaled empty-bin promotion for large items.
    scale = (item - 50.0) / 50.0
    if scale > 0:
        score += scale * (item + 1) * is_empty.astype(np.float64)

    # Update histogram with this item (state for future calls in the stream).
    hist[item] += 1.0
    _state["n"] = n + 1.0

    return score
# EVOLVE-BLOCK-END
