# EVOLVE-BLOCK-START
"""Best-fit primary, with conservative empty-bin promotion only for large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Absolute wasteful-gap test: a used bin that would leave a residual larger
    # than the item itself is a poor fit; penalize it.
    wasteful = (rem > item) & (~is_empty)
    score += wasteful.astype(np.float64) * (item + 1)

    # Conservative empty-bin promotion: only strongly reserve a fresh bin for
    # large items, where leaving a small awkward gap is most costly. Use a
    # sharper threshold (only items above ~65 get a real bonus) but scale the
    # bonus with item size so very large items reserve aggressively.
    if item > 65:
        scale = (item - 65.0) / 35.0  # 0 at 65, up to 1.0 at 100
        bonus = scale * (item + 1) * is_empty.astype(np.float64)
        score += bonus

    return score
# EVOLVE-BLOCK-END


