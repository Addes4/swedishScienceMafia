# EVOLVE-BLOCK-START
"""Best-fit, but prefer a fresh bin when the best fit would waste too much space."""
import numpy as np


class _State:
    total = 0.0
    count = 0


def priority(item, bins):
    st = _State
    # Online mean of item sizes seen so far.
    if st.count > 0:
        mean = st.total / st.count
    else:
        mean = 40.0
    st.total += item
    st.count += 1

    rem = bins - item  # leftover after placing the item
    score = -rem.astype(np.float64)  # best fit base

    best_rem = rem.min()
    is_empty = bins == 100

    # If even the best fit leaves a large awkward gap, prefer a fresh bin.
    # Threshold grows with the observed mean item size.
    if best_rem > mean:
        score += is_empty.astype(np.float64) * (best_rem - mean)

    return score
# EVOLVE-BLOCK-END
