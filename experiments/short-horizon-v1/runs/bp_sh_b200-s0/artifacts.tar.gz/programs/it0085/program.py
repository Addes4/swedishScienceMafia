# EVOLVE-BLOCK-START
"""Best-fit with a gentle penalty for residuals that strand a typical-sized gap."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # leftover capacity after placing the item

    # Primary: best fit (prefer smallest non-negative leftover).
    score = -rem

    # Gentle penalty for residuals that are larger than the item but still too small to
    # comfortably hold a typical item: such a gap is likely to be stranded waste.
    # Keep it small so it only breaks near-ties rather than overriding best-fit.
    stranded = np.clip(rem, 0, None)
    # Penalize gaps below a typical item size (~40) but larger than the item itself.
    penalty = np.where((stranded > item) & (stranded < 40.0), stranded, 0.0)
    score -= penalty * 0.05

    return score
# EVOLVE-BLOCK-END
