# EVOLVE-BLOCK-START
"""Best-fit primary, with item-size-scaled empty-bin promotion for large items,
a stateful consolidation nudge for typical-size items, and an adaptive
wasteful-gap penalty that strengthens for small items."""
import numpy as np

# Per-stream running statistics (reset when a fresh stream starts).
_state = {"n": 0, "sum": 0.0, "last_size": -1}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Absolute wasteful-gap test: a used bin that would leave a residual larger
    # than the item itself is a poor fit.  Strengthen this for items that are
    # small relative to the running mean, so small items consolidate more.
    smallness = max(0.0, (mean_item - item) / max(mean_item, 1.0))
    waste_strength = 1.0 + 2.0 * smallness
    wasteful = (rem > item) & (~is_empty)
    score += wasteful.astype(np.float64) * (item + 1) * waste_strength

    # Item-size-scaled empty-bin promotion: reserve a fresh bin mainly for
    # large items, while letting smaller items consolidate into used bins.
    scale = (item - 50.0) / 50.0  # <=0 for items up to 50, up to 1.0 at 100
    if scale > 0:
        bonus = scale * (item + 1) * is_empty.astype(np.float64)
        score += bonus

    # Consolidation nudge: for typical-size items, prefer a used bin whose
    # residual stays useful (>= half the running mean item size) over opening a
    # fresh bin, cutting needless bin openings without harming large items.
    if scale <= 0:
        half_mean = 0.5 * mean_item
        useful_used = (rem >= half_mean) & (rem <= item) & (~is_empty)
        score += 0.5 * (item + 1) * useful_used.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
