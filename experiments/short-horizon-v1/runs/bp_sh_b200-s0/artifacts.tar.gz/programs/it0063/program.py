# EVOLVE-BLOCK-START
"""Best-fit with a soft fill-target bonus based on the running mean item size."""
import numpy as np

_state = {"mean": 40.0, "n": 0}


def priority(item, bins):
    """Score bins: prefer tight fits, but reward residuals that a typical item can fill."""
    # Update running estimate of item size (exponential moving average).
    n = _state["n"]
    if n == 0:
        _state["mean"] = float(item)
    else:
        alpha = 0.02
        _state["mean"] = (1.0 - alpha) * _state["mean"] + alpha * float(item)
    _state["n"] = n + 1

    mu = _state["mean"]
    rem = (bins - item).astype(np.float64)  # residual after placing the item

    # Base: best fit (prefer smallest residual).
    score = -rem

    is_empty = bins == 100

    # Reward used bins whose residual is close to the typical item size mu
    # (a future item of typical size can then consume it well).
    closeness = -np.abs(rem - mu) / max(mu, 1.0)
    score += 0.5 * closeness * (~is_empty)

    # Mildly penalize leaving a tiny, useless nonzero gap in a used bin.
    tiny = np.clip(1.0 - rem / max(mu, 1.0), 0.0, 1.0) * (rem > 0)
    score -= 0.3 * tiny * (~is_empty)

    # Only promote unused bins when the best used residual is large relative to mu.
    score += 0.2 * is_empty * (rem >= 0)

    return score
# EVOLVE-BLOCK-END
