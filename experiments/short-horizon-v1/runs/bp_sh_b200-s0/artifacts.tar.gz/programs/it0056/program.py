# EVOLVE-BLOCK-START
"""Best-fit with a smooth, scale-aware preference against wasteful fresh-bin gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Empty bins have rem = 100 - item. Penalize choosing an empty bin by an amount
    # that grows with the size of the gap it would create, so we only open a fresh
    # bin when the resulting leftover is small (i.e. the item nearly fills it) and
    # otherwise consolidate into used bins.
    is_empty = bins == 100
    empty_gap = np.where(is_empty, rem, 0).astype(np.float64)
    score -= empty_gap * 0.5

    return score
# EVOLVE-BLOCK-END


