# EVOLVE-BLOCK-START
"""Best-fit with an online-mean tie-break: prefer the tightest fit, breaking near-ties
in favor of bins whose leftover best matches the typical (mean) item size."""
import numpy as np

_mean = [40.0]
_n = [0]


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties go to the first bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Online estimate of the mean item size (initialize at 40).
    _n[0] += 1
    m = _mean[0]
    _mean[0] = m + (item - m) / _n[0]
    mu = _mean[0]

    rem = bins - item  # leftover capacity after placing the item
    # Dominant term: best fit = smallest leftover.
    score = -rem.astype(np.float64)

    # Tiny tie-break: mildly favor bins whose leftover is closest to the typical item
    # size, so that well-set-up bins are preferred over exact-order ties.
    # Scale so it never overrides a real leftover difference (leftovers are integers,
    # so 1 unit of leftover dominates any tie-break below 1).
    closeness = -np.abs(rem.astype(np.float64) - mu)
    score += closeness * 1e-3

    return score
# EVOLVE-BLOCK-END
