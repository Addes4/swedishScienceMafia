# EVOLVE-BLOCK-START
"""Best-fit, but avoid leaving large unusable gaps by preferring a fresh bin.

Items have mean ~40 on a 100 capacity. Best-fit alone packs tightly but can create
hard-to-fill gaps. We use best-fit (smallest leftover) as the primary rule, but when
the tightest existing bin would still leave a leftover larger than THRESH, we instead
prefer an unused bin, since such a gap is unlikely to be filled by a future item.
"""
import numpy as np

# A leftover bigger than this after best-fit is considered a wasteful gap.
# ~ mean item size of the Weibull-shaped distribution (mean ~40), so gaps up to
# roughly one item are fine; larger gaps waste potential.
THRESH = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    rem = bins - item  # leftover capacity after placing the item
    is_empty = bins == 100

    # Primary: best fit -> prefer smallest leftover.
    score = -rem.astype(np.float64)

    # Override: if the best existing (non-empty) fit leaves a leftover larger than
    # THRESH, it's a wasteful gap; strongly prefer opening a fresh bin instead.
    # Largest possible leftover among non-empty bins:
    non_empty_rem = np.where(is_empty, -np.inf, rem)
    if np.max(non_empty_rem) > THRESH:
        # Boost empty bins above all used bins.
        score += is_empty.astype(np.float64) * 1e6

    return score
# EVOLVE-BLOCK-END
