# EVOLVE-BLOCK-START
"""Best-fit with a mild convex penalty on large leftover gaps (anti-fragmentation)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Dominant term: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Mild convex penalty on the resulting gap: discourages leaving large awkward
    # leftovers that are hard to fill later. Kept small so it only breaks near-ties.
    score -= 0.01 * (rem.astype(np.float64) ** 2)

    return score
# EVOLVE-BLOCK-END
