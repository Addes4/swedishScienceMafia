# EVOLVE-BLOCK-START
"""Best-fit primary, with a smooth item-size-gated empty-bin promotion."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Absolute wasteful-gap test: a used bin whose residual would exceed the item
    # itself is a poor fit — prefer a fresh bin in that case.
    wasteful = (rem > item) & (~is_empty)
    score += wasteful.astype(np.float64) * (item + 1)

    # Smooth item-size-gated empty-bin promotion.  Only reserve a fresh bin for
    # large items (which are hard to place later); mid-size items should
    # consolidate into tightly-fitting used bins.  A logistic ramp centered near
    # 55 keeps medium items consolidating while strongly reserving for big ones.
    scale = 1.0 / (1.0 + np.exp(-(item - 55.0) / 8.0))
    bonus = scale * (item + 1) * is_empty.astype(np.float64)
    score += bonus

    return score
# EVOLVE-BLOCK-END
