# EVOLVE-BLOCK-START
"""Best-fit primary, with a smooth item-size-scaled empty-bin promotion."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    rem = bins - item  # leftover capacity after placing the item
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Absolute wasteful-gap test: a used bin that would leave a residual
    # larger than the item itself is a poor fit.
    wasteful = (rem > item) & (~is_empty)
    score += wasteful.astype(np.float64) * (item + 1)

    # Smooth item-size-scaled empty-bin promotion.
    # Map item size to a bonus via a logistic ramp centered near item=45,
    # so large items strongly reserve a fresh bin while small/medium items
    # consolidate into used bins. Bonus stays within (item+1).
    scale = 1.0 / (1.0 + np.exp(-(item - 45.0) / 8.0))  # ~0.02 at 10, ~0.5 at 45, ~0.98 at 90
    bonus = scale * (item + 1) * is_empty.astype(np.float64)
    score += bonus

    return score
# EVOLVE-BLOCK-END
