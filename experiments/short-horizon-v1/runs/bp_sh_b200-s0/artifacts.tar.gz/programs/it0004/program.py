# EVOLVE-BLOCK-START
"""Best-fit with a mean-item-scaled waste penalty favoring fresh bins for awkward gaps."""
import numpy as np


class _State:
    total = 0
    count = 0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Online estimate of the mean item size (starts near the known mean ~40).
    _state.total += item
    _state.count += 1
    mean = _state.total / _state.count
    # Half the mean item size is a reasonable "usable leftover" threshold.
    thresh = 0.5 * mean

    rem = bins - item  # leftover capacity after placing the item
    is_empty = bins == 100

    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Penalize used bins leaving an awkward (large) gap that is likely hard to
    # fill later, scaled to typical item size. Empty bins get no penalty and so
    # win when every existing gap is too wasteful.
    awkward = np.clip(rem - thresh, 0.0, None)
    score -= awkward.astype(np.float64) * (~is_empty)
    return score
# EVOLVE-BLOCK-END

