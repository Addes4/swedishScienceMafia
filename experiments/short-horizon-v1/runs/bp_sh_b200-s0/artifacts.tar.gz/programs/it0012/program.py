# EVOLVE-BLOCK-START
"""Online-aware best fit: prefer fuller bins, but reward gaps that match upcoming item sizes."""
import numpy as np

# Per-stream state: histogram of observed item sizes (1..100).
_HIST = np.zeros(101, dtype=np.float64)
_N = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _HIST, _N

    # Update online estimate of the item-size distribution.
    _HIST[item] += 1.0
    _N += 1.0

    total = _N
    cdf = np.cumsum(_HIST) / total  # cdf[s] = P(size <= s)

    rem = bins - item  # leftover after placing item

    # Best-fit base: prefer smallest leftover.
    score = -rem.astype(np.float64)

    # Fresh-bin bonus: less useful if many unused bins already exist, but helps
    # avoid wasting a used bin's remaining space when the leftover is small/hard to fill.
    is_empty = bins == 100

    # For a used bin, reward leftovers that are "reasonable" item sizes:
    # probability that a future item fits in the leftover and leaves it small.
    # Use tail mass: P(next item <= rem) is a natural fillability measure.
    rem_clipped = np.clip(rem, 0, 100).astype(np.int64)
    fill_prob = cdf[rem_clipped]  # P(size <= leftover)
    # Scale so this acts as a mild tie-breaker versus raw best-fit magnitude.
    score += fill_prob * 100.0 * (~is_empty)

    # Slight preference for used bins overall (avoid opening new bins too eagerly).
    score += is_empty * (-2.0)

    return score
# EVOLVE-BLOCK-END

