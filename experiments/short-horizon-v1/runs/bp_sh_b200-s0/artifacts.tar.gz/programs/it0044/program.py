# EVOLVE-BLOCK-START
"""Best-fit with a smooth fresh-bin bonus when the fit would waste capacity."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # leftover after placing the item
    # Base: best fit (prefer smallest leftover).
    score = -rem

    # A fresh bin (remaining capacity 100) is attractive when the tightest used-bin fit
    # would still leave a large remainder (a wasteful, hard-to-fill gap).
    is_empty = bins == 100
    used = ~is_empty
    if np.any(used):
        best_rem = rem[used].min()
        # Waste fraction of the item: how much slack relative to the item size.
        frac = best_rem / float(item) if item > 0 else 0.0
        # Sigmoid centered where waste ~ item size (frac=1); scales fresh-bin bonus.
        bonus = 1.0 / (1.0 + np.exp(-2.0 * (frac - 1.0))) * float(item)
        score = score + is_empty * bonus
    return score
# EVOLVE-BLOCK-END
