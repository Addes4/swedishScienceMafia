# EVOLVE-BLOCK-START
"""Best-fit with an online item-size histogram: avoid leaving gaps that later items can't fill."""
import numpy as np

SIZE = 101


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Per-stream state stored on the function object.
    hist = getattr(priority, "hist", None)
    if hist is None:
        hist = np.zeros(SIZE, dtype=np.float64)
        priority.hist = hist
        priority.count = 0.0

    rem = bins - item  # leftover capacity after placing the item
    is_empty = bins == 100

    score = -rem.astype(np.float64)

    # Estimate of how likely a leftover remainder r is to be exactly fillable:
    # proportion of past items that fit within r. Small leftovers get penalized
    # more strongly so a fresh bin is preferred over an unusable tiny gap.
    count = priority.count
    if count > 0:
        # cumulative probability that a past item size <= r, for r = 0..100
        total = hist.sum()
        if total > 0:
            cdf = np.cumsum(hist) / total  # cdf[r] = P(item <= r)
        else:
            cdf = np.zeros(SIZE)
    else:
        cdf = np.zeros(SIZE)

    rem_i = rem.astype(np.int64)
    np.clip(rem_i, 0, SIZE - 1, out=rem_i)
    # Penalize non-empty bins whose leftover is poorly fillable (low cdf),
    # scaled gently so it only overrides best-fit for genuinely bad gaps.
    fill_score = cdf[rem_i]
    score += 6.0 * fill_score * (~is_empty)

    # Update histogram with the current item.
    hist[item] += 1.0
    priority.count = count + 1.0

    return score
# EVOLVE-BLOCK-END
