# EVOLVE-BLOCK-START
"""Best-fit dominant, but refuse to open a wasteful gap: if the best fitting used bin would
leave a leftover at least as large as a typical future item, prefer a fresh bin instead."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Track running mean of past item sizes (this item not yet included).
    n = _state["n"]
    mean = _state["sum"] / n if n > 0 else 40.0
    _state["n"] = n + 1
    _state["sum"] += item

    rem = (bins - item).astype(np.float64)  # leftover after placing
    # Base: best fit (prefer smallest leftover).
    score = -rem

    is_empty = bins == 100
    # A non-empty placement is considered wasteful if its leftover is at least a typical
    # future item size (that leftover likely cannot be filled cheaply).
    wasteful = (rem >= mean) & (~is_empty)
    # Large enough to reliably beat any used bin by a fresh bin's score (-100 + 0).
    score -= wasteful.astype(np.float64) * 1000.0
    return score
# EVOLVE-BLOCK-END
