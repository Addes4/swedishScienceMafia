# EVOLVE-BLOCK-START
"""Best fit with deterministic tie-breaking toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Prefer the tightest fit; break ties by lower remaining capacity (fuller bin).
    return -(bins - item) * 101 - bins
# EVOLVE-BLOCK-END

