# EVOLVE-BLOCK-START
"""Best-fit primary, with a relative wasteful-gap penalty and a soft empty-bin reservation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Relative wasteful-gap test: a used bin leaving a residual larger than a
    # fraction of the item is a poor fit and gets penalized.
    wasteful = (rem > 0.5 * item) & (~is_empty)
    score -= wasteful.astype(np.float64) * (item + 1)

    # Soft empty-bin reservation: always slightly prefer a used bin, more so for
    # small items (which are easy to place later) than for large ones.
    empty_pen = ((60.0 - item) / 60.0)
    if empty_pen > 0:
        score -= empty_pen * (item + 1) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
