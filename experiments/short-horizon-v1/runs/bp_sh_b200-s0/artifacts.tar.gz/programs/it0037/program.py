# EVOLVE-BLOCK-START
"""Best-fit with a consolidation bonus for near-exact fills."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item, >= 0

    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Consolidation bonus: strongly reward near-exact fills of used bins so that
    # already-partly-filled bins get closed out rather than left with awkward gaps.
    is_empty = bins == 100
    # Bonus grows as leftover shrinks; capped so it only matters for tight fits.
    tight = np.where(is_empty, 0.0, np.maximum(0.0, item - rem))
    score += tight.astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
