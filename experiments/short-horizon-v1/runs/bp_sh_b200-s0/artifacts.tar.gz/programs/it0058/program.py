# EVOLVE-BLOCK-START
"""Hybrid: best-fit for good fits, but penalize large post-placement leftovers quadratically."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Penalize non-empty bins whose resulting gap is awkward (large leftover),
    # with a superlinear term so big wastes are strongly discouraged.
    is_empty = bins == 100
    awkward = np.clip(rem - item, 0, None).astype(np.float64)  # leftover exceeding item size
    score -= (awkward + 0.01 * awkward * awkward) * (~is_empty)
    return score
# EVOLVE-BLOCK-END
