# EVOLVE-BLOCK-START
"""Best-fit with a strong exact-fit (complement) bonus and size-aware empty-bin reluctance.

Rationale: the objective rewards closing bins. Best-fit already minimizes residual, but ties
and near-ties are common. We (1) reward used bins whose new residual is exactly 0 (perfect
complement), (2) give a graded bonus to used bins whose residual is small relative to the item
(so the bin becomes hard to reuse usefully -> likely closed), and (3) apply a size-scaled
penalty to opening a fresh bin, only worth it for large items in this Weibull(mean~40) stream.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    # Running mean item size, used to scale the empty-bin reluctance.
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item                      # residual after placing item
    is_empty = bins == 100
    is_used = ~is_empty

    # Primary: best fit (smallest residual).
    score = -rem.astype(np.float64)

    # (1) Perfect-complement bonus: closing a used bin exactly.
    perfect = is_used & (rem == 0)
    score += perfect.astype(np.float64) * (item + 1)

    # (2) Graded bonus for small residuals on used bins: residual <= item means the bin's
    # leftover is at most one more such item; scale bonus inversely with residual.
    small = is_used & (rem > 0) & (rem <= item)
    score += small.astype(np.float64) * (item + 1) / (rem.astype(np.float64) + 1.0)

    # (3) Size-scaled empty-bin penalty: reserving a fresh bin is only justified for large
    # items; smaller items should consolidate into used bins.
    scale = (item - mean_item) / max(mean_item, 1.0)   # >0 for large items
    empty_pen = np.where(is_empty, np.maximum(-scale, 0.0) * (item + 1), 0.0)
    score += empty_pen

    return score
# EVOLVE-BLOCK-END

