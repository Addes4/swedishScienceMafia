# EVOLVE-BLOCK-START
"""Best-fit for used bins, with a fresh bin preferred only on clearly wasteful fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Best fit: prefer the smallest leftover. Larger score = better.
    score = -rem.astype(np.float64)

    is_empty = bins == 100
    # Best fit over used bins only (ignore empties) to judge if the fit is wasteful.
    used = ~is_empty
    if used.any():
        best_used_rem = rem[used].min()
        if best_used_rem >= item:
            # The tightest available used-bin fit still leaves at least a whole item's
            # worth of slack -> wasteful; drop that used bin below the fresh bins.
            score -= (used & (rem == best_used_rem)) * (item + 1)

    return score
# EVOLVE-BLOCK-END
