# EVOLVE-BLOCK-START
"""Hybrid: best-fit primary, with a tie-break toward fillable leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Base: best fit (prefer smallest leftover). Dominant term.
    score = -rem.astype(np.float64)

    # Tie-break: reward leftovers that are close to a typical future item size (~40 mean),
    # so the resulting gap is likely fillable by a single upcoming item.
    target = 40.0
    leftover_bonus = -np.abs(rem - target).astype(np.float64)

    # Only break near-ties: scale tiny relative to the 1-unit best-fit granularity.
    score += 1e-3 * leftover_bonus
    return score
# EVOLVE-BLOCK-END
