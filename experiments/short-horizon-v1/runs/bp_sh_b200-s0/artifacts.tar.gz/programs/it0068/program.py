# EVOLVE-BLOCK-START
"""Best fit with exact-fit bonus and consolidation tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # leftover capacity after placing the item

    # Primary: best fit -> prefer smallest leftover.
    score = -rem

    # Strong bonus for an exact fit (leftover 0): no wasted space at all.
    score += (rem == 0) * 1000.0

    # Tiny consolidation tie-break: among near-equal residuals, prefer bins that are
    # already fuller (smaller leftover means the bin is closer to sealed).
    # Using a minuscule weight keeps the primary best-fit ordering intact.
    score -= rem * 1e-3

    return score
# EVOLVE-BLOCK-END
