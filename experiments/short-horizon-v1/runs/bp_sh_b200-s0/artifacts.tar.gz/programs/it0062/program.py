# EVOLVE-BLOCK-START
"""Best-fit with a small penalty for leaving tiny unusable gaps in used bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100
    # A tiny nonzero residual is often impossible to fill later (wasted capacity),
    # so slightly demote used bins that would leave such a gap.
    tiny_gap = (~is_empty) & (rem > 0) & (rem < (item // 2))
    score -= tiny_gap.astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END
