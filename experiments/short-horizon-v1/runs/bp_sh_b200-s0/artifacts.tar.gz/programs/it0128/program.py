# EVOLVE-BLOCK-START
"""Best-fit primary, with a strong exact-fit bonus and a size-scaled empty-bin
penalty that discourages fragmenting used bins for larger items."""
import numpy as np

# Per-stream running statistics (reset when a fresh stream starts).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item
    f = rem.astype(np.float64)

    # Primary criterion: best fit (prefer smallest leftover).
    score = -f

    is_empty = bins == 100

    # Strong bonus when a used bin would become exactly full: such perfect
    # placements are almost always optimal and reduce fragmentation.
    perfect = (rem == 0) & (~is_empty)
    score += perfect.astype(np.float64) * 50.0

    # Empty-bin penalty: opening a fresh bin leaves a residual of (100 - item),
    # which is wasteful relative to reusing an existing gap. Penalize it mildly,
    # scaling up with item size so larger items (which need more contiguous room
    # and would fragment a used bin badly) are more inclined to use fresh bins.
    scale = item / 100.0
    score -= scale * 15.0 * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
