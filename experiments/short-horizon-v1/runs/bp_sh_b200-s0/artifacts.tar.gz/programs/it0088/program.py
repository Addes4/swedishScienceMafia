# EVOLVE-BLOCK-START
"""Best-fit with an adaptive penalty for residuals that strand an unfillable gap."""
import numpy as np


def priority(item, bins):
    rem = bins - item  # leftover capacity after placing the item
    score = -rem.astype(np.float64)  # best fit: prefer smallest leftover

    # Recent item-size statistics (state kept across calls within a stream).
    hist = getattr(priority, "_hist", None)
    if hist is None:
        hist = []
        priority._hist = hist
    if hist:
        med = float(np.median(hist))
    else:
        med = 40.0
    hist.append(item)
    if len(hist) > 200:
        hist.pop(0)

    is_empty = bins == 100
    # A residual that is too small to hold a typical future item (but nonzero) is a
    # stranded, useless gap: penalize it.  An exact fit (rem==0) is ideal.
    stranded = (rem > 0) & (rem < med)
    score -= stranded.astype(np.float64) * med
    return score
# EVOLVE-BLOCK-END
