# EVOLVE-BLOCK-START
"""Best-fit primary, with a bonus for closing a used bin (residual smaller than
the typical item) and item-size-scaled reluctance to open fresh bins."""
import numpy as np

# Per-stream running statistics (reset when a fresh stream starts).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100
    used = ~is_empty

    # Closing bonus: if a used bin's residual is smaller than the typical item,
    # it is effectively closed (unlikely to be usefully refilled), so prefer it.
    closed = used & (rem < mean_item)
    score += closed.astype(np.float64) * (item + 1)

    # Wasteful-gap penalty: leaving a residual far larger than the item on a used
    # bin wastes space better spent elsewhere.
    wasteful = used & (rem > item)
    score -= wasteful.astype(np.float64) * (item + 1)

    # Item-size-scaled reluctance to open a fresh bin: only clearly large items
    # justify reserving a new bin.
    scale = (item - mean_item) / 100.0
    if scale > 0:
        score -= scale * (item + 1) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

