# EVOLVE-BLOCK-START
"""Best-fit with a convex leftover penalty that super-linearly discourages waste."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item (>= 0)

    # Base best-fit: prefer smallest leftover.
    score = -rem.astype(np.float64)

    # Convex penalty on leftover: strongly discourage leaving large gaps, which are
    # harder to fill later. This makes the rule behave like best-fit but sharper.
    score -= (rem.astype(np.float64) ** 2) / 100.0

    # Slight bonus for leaving a leftover that equals a "completing" residue of zero,
    # i.e. exact fills should dominate.
    score += (rem == 0).astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
