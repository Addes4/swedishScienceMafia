# EVOLVE-BLOCK-START
"""Best-fit with an online-tracked "small item" reward for fillable residuals."""
import numpy as np

_state = {"min_item": 101}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item < _state["min_item"]:
        _state["min_item"] = item
    m = _state["min_item"]

    rem = bins - item  # leftover capacity after placement

    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Reward used bins whose residual is nonzero but small enough that a future
    # small item (>= observed minimum) can still fill it: this discourages leaving
    # "dead" gaps and encourages packing tight.
    is_empty = bins == 100
    small_res = (rem > 0) & (rem < m) & (~is_empty)
    score += small_res.astype(np.float64) * 0.5 * float(m)
    return score
# EVOLVE-BLOCK-END
