# EVOLVE-BLOCK-START
"""Best-fit primary, with a residual-quality test for empty-bin promotion:
a fresh bin is preferred when the best used-bin placement would leave a
residual that is hard to fill later (residual below a typical item size)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # A used bin whose resulting residual is below a typical future item size
    # (~mean 40) leaves a gap that is likely to be wasted. Penalize that.
    # Convert to float w to avoid sign issues with the negative-rem ordering.
    used_residual_penalty = (rem < 40) & (~is_empty)
    score -= used_residual_penalty.astype(np.float64) * (item + 1)

    # Promote a fresh bin modestly for larger items.
    scale = (item - 50.0) / 50.0  # <=0 for items up to 50, up to 1.0 at 100
    if scale > 0:
        score += scale * (item + 1) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

