# EVOLVE-BLOCK-START
"""Hybrid: best-fit for good fits, but convexly penalize wasteful fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    rem_f = rem.astype(np.float64)

    # Base: best fit (prefer smallest leftover).
    score = -rem_f

    is_empty = bins == 100
    # Convex penalty on leftovers that exceed the item size: a wasteful gap that
    # grows worse than linearly, so it is reliably beaten by opening a fresh bin.
    excess = np.clip(rem_f - item, 0.0, None)
    score -= (excess * excess) / max(float(item), 1.0) * (~is_empty)
    return score
# EVOLVE-BLOCK-END
