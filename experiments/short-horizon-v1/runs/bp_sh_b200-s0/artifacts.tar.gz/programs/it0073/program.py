# EVOLVE-BLOCK-START
"""Best-fit with a fractional tie-break that favors filling already-fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # leftover capacity after placing the item
    # Primary: best fit -> smallest leftover.
    score = -rem
    # Tie-break (sub-integer, cannot change best-fit ordering): reward placing into a
    # bin that is already more full (smaller remaining), so near-equal residuals tend to
    # consolidate into packed bins; exact fits (rem == 0) are naturally the fullest.
    score -= (bins.astype(np.float64)) * 1e-3
    return score
# EVOLVE-BLOCK-END
