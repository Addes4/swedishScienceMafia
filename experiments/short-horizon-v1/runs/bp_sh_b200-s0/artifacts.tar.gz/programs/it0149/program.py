# EVOLVE-BLOCK-START
"""Best-fit primary, with a "harvestable residual" bonus.

The dominant failure mode of plain best-fit is leaving residuals too small to
hold another typical item, forcing a fresh bin soon after.  We therefore reward
used bins whose residual after placement can still accept a mean-sized item,
while keeping best-fit as the primary ordering and reserving fresh bins mainly
for large items.
"""
import numpy as np

# Per-stream running statistics (reset when a fresh stream starts).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item
    is_empty = bins == 100

    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Reward used bins whose residual can still hold a typical future item:
    # such residuals are "harvestable" and reduce future bin openings.
    harvestable = (rem >= mean_item) & (~is_empty)
    score += 0.75 * (item + 1) * harvestable.astype(np.float64)

    # Empty-bin promotion for large items: only genuinely large items (above
    # the running mean) are worth opening a fresh bin for.
    large = item > mean_item
    if large:
        score += (item + 1) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
