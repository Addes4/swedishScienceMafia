# EVOLVE-BLOCK-START
"""Distribution-aware best-fit: prefer bins whose leftover matches a likely future item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Maintain an exponentially-weighted empirical histogram of item sizes seen so far
    # (state persists only within a stream; reset happens automatically on shape check).
    hist = getattr(priority, "hist", None)
    if hist is None or hist.shape[0] != 101:
        hist = np.zeros(101, dtype=np.float64)
        priority.hist = hist
        priority.count = 0.0

    priority.hist *= 0.98
    priority.hist[item] += 1.0
    priority.count += 1.0

    h = priority.hist
    total = h.sum()
    if total <= 0:
        match = np.zeros(101, dtype=np.float64)
    else:
        match = h / total  # probability that a future item equals each size 0..100

    rem_f = rem.astype(np.float64)
    # Base: best fit (prefer smallest leftover).
    score = -rem_f.copy()

    # Bonus: reward leftovers that are likely to be filled exactly by a future item.
    valid = rem >= 0
    idx = np.clip(rem, 0, 100)
    prob = np.where(valid, match[idx], 0.0)
    score += prob * 25.0

    # Strong reward for perfect fills.
    score += (rem == 0).astype(np.float64) * 5.0
    return score
# EVOLVE-BLOCK-END
