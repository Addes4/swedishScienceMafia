# EVOLVE-BLOCK-START
"""Best-fit primary, with a stateful consolidation bonus that keeps residual gaps
large enough to stay useful, plus a gentle empty-bin reserve for large items."""
import numpy as np

# Per-stream running statistics (reset implicitly; a stream starts fresh state).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item                      # leftover capacity after placing the item
    score = -rem.astype(np.float64)        # primary: best fit (smallest leftover)

    is_empty = bins == 100

    # Consolidation bonus: for a used bin, reward a placement that leaves a
    # residual able to still hold a typical future item (>= half the mean),
    # so we prefer packing into used bins over opening fresh ones.
    half_mean = 0.5 * mean_item
    useful_used = (rem >= half_mean) & (~is_empty)
    score += 0.5 * (item + 1) * useful_used.astype(np.float64)

    # Open a fresh bin only for genuinely large items, scaled by size.
    scale = (item - 50.0) / 50.0
    if scale > 0:
        score += scale * (item + 1) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

