# EVOLVE-BLOCK-START
"""Best-fit dominant, with a suboptimality penalty to avoid awkward medium gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # leftover capacity after placing the item
    # Base: best fit (prefer smallest leftover).
    best_rem = rem.min()
    score = -rem

    # Suboptimality penalty: mildly discourage leftover gaps that are large relative to
    # the best available fit, so an almost-complete bin isn't spoiled by a medium gap.
    excess = rem - best_rem
    score -= 0.05 * excess

    # Bonus for near-exact completion of a used bin.
    is_empty = bins == 100
    score += (rem == 0) * (~is_empty) * 1e-3
    return score
# EVOLVE-BLOCK-END


