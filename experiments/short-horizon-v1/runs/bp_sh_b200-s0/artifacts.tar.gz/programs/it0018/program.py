# EVOLVE-BLOCK-START
"""Best-fit with a gap-waste penalty calibrated to the item distribution."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # leftover after placing the item

    # Base: best fit (prefer smallest leftover).
    score = -rem

    # Penalize leaving a gap that exceeds the current item's size (hard to fill later,
    # since few future items will be that large). Penalty grows with the excess.
    excess = np.clip(rem - item, 0.0, None)
    score -= 0.5 * excess

    # Small constant penalty for opening a fresh bin so a reasonable non-empty fit wins
    # over an empty bin, but a terrible non-empty fit still loses to a fresh bin.
    is_empty = bins == 100
    score -= 0.5 * is_empty

    return score
# EVOLVE-BLOCK-END

