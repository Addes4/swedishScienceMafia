# EVOLVE-BLOCK-START
"""Residual-target best fit: prefer small leftover, mildly reward leftovers that match a
typical future item so gaps stay fillable, and prefer exact fits strongly."""
import numpy as np


def priority(item, bins):
    rem = (bins - item).astype(np.float64)  # leftover after placing item
    is_empty = (bins == 100)

    # Base: best fit (prefer smallest leftover).
    score = -rem

    # Strong bonus for exact fit.
    score += 50.0 * (rem == 0)

    # Slight preference for reusing used bins over opening new ones when fits are comparable.
    score += 0.01 * (~is_empty)

    return score
# EVOLVE-BLOCK-END
