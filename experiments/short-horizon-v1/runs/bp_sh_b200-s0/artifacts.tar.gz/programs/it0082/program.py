# EVOLVE-BLOCK-START
"""Best-fit with an adaptive-dead-gap penalty based on the smallest item seen."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update the smallest item seen so far in this stream.
    if item < _state["min_item"]:
        _state["min_item"] = item
    min_seen = _state["min_item"]

    rem = bins - item  # leftover capacity after placing the item
    rem_f = rem.astype(np.float64)

    # Base: best fit (prefer smallest leftover).
    score = -rem_f

    # A residual gap that is smaller than the smallest item seen so far can never
    # be filled again -> it's a dead gap. Penalize such non-empty placements
    # (but keep exact fit, residual 0, as the best option).
    is_empty = bins == 100
    dead_gap = (rem > 0) & (rem < min_seen) & (~is_empty)
    score -= dead_gap.astype(np.float64) * 100.0

    return score
# EVOLVE-BLOCK-END
