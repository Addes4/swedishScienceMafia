# EVOLVE-BLOCK-START
"""Best-fit with a squared-residual penalty that discourages wasteful gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Prefer smallest leftover (best fit).
    score = -rem.astype(np.float64)

    # Penalize awkward large leftovers on used bins: a remainder much larger than the
    # item tends to be wasted because future mean items (~40) can still fit but small
    # fragments accumulate. Use a quadratic penalty so tight fits dominate.
    is_empty = bins == 100
    awkward = np.clip(rem - item, 0, None)  # leftover exceeding the item size
    score -= (awkward.astype(np.float64) ** 2) / 100.0 * (~is_empty)
    return score
# EVOLVE-BLOCK-END

