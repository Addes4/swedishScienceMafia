# EVOLVE-BLOCK-START
"""Best-fit primary, with a stateful "reusable residual" nudge that prefers a
used bin whose leftover most resembles a typical next item, plus a mild
empty-bin penalty for small/medium items to reduce needless bin openings."""
import numpy as np

# Per-stream running statistics (reset per stream by the harness's fresh import).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running statistics.
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Mild empty-bin penalty for small/medium items: discourage opening a fresh
    # bin when a used one is a reasonable fit, but never outweigh best-fit.
    scale = (item - 60.0) / 40.0  # <=0 for items up to 60, up to 1.0 at 100
    empty_pen = 0.3 * (1.0 - max(scale, 0.0)) * (item + 1) * is_empty.astype(np.float64)
    score -= empty_pen

    # Reusable-residual nudge: among used bins, mildly favor leftovers closest
    # to a typical future item size (the running mean), aiding consolidation.
    used = ~is_empty
    gap_diff = np.abs(rem - mean_item) / (mean_item + 1.0)
    score -= 0.4 * (item + 1) * np.where(used, gap_diff, 0.0)

    return score
# EVOLVE-BLOCK-END

