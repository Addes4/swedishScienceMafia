# EVOLVE-BLOCK-START
"""Pure best-fit: place the item so the chosen bin's leftover capacity is smallest.

Ties are broken toward the bin with the larger remaining capacity (the fresher bin),
which mildly discourages fragmenting already-crowded bins.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Tiny tie-breaker: prefer the bin with more remaining capacity (fresher bin),
    # scaled so it never overrides the primary best-fit ordering.
    score += bins.astype(np.float64) * 1e-3

    return score
# EVOLVE-BLOCK-END

