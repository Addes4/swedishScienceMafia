# EVOLVE-BLOCK-START
"""Best fit: place the item so the smallest leftover capacity remains."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Best fit: prefer the smallest leftover (most tightly packed placement).
    return -rem.astype(np.float64)
# EVOLVE-BLOCK-END
