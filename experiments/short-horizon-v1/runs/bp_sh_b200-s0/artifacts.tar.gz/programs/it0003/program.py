# EVOLVE-BLOCK-START
"""Online bin choice: best-fit with an online estimate of how fillable the leftover is."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    score = -rem.astype(np.float64)

    is_empty = bins == 100
    # Penalize used bins whose resulting leftover is a "wasteful" gap that is likely to be
    # hard to fill later.  Only override best-fit when the gap is large relative to the item.
    awkward = np.clip(rem - item, 0, None)
    score -= awkward.astype(np.float64) * (~is_empty)
    return score
# EVOLVE-BLOCK-END
