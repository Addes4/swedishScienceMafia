# EVOLVE-BLOCK-START
"""Best-fit with a learned penalty for unfillable residual gaps."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    rem = bins - item  # leftover after placing the item (>= 0 for bins shown)

    # Track the smallest item seen so far in this stream (per-module state).
    if item < _state["min_item"]:
        _state["min_item"] = item
    min_item = _state["min_item"]

    score = -rem.astype(np.float64)

    # A residual gap strictly smaller than the minimum item size can never be filled
    # by any future item, so it is effectively lost capacity: penalize it.
    dead = (rem > 0) & (rem < min_item)
    score -= dead.astype(np.float64) * (min_item - rem)

    return score
# EVOLVE-BLOCK-END
