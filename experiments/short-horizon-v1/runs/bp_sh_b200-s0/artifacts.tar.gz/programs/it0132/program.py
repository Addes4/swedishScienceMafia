# EVOLVE-BLOCK-START
"""Best-fit primary, with mean-adaptive empty-bin promotion for large items and
a tie-break that prefers used bins over fresh ones for typical items."""
import numpy as np

# Per-stream running statistics (reset implicitly; adapts across the stream).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item          # leftover capacity after placing the item
    is_empty = bins == 100

    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Tie-break: for equal residual, prefer a used bin over a fresh one so we
    # don't open new bins needlessly.  A small constant per non-empty bin does
    # this without disturbing the best-fit ordering (residuals are integers).
    score += (~is_empty).astype(np.float64) * 0.25

    # Mean-adaptive empty-bin promotion: reserve a fresh bin mainly for items
    # larger than the running mean, while letting typical/small items
    # consolidate into used bins.
    big = item > mean_item
    if big:
        bonus = (item - mean_item) / 100.0 * (item + 1)
        score += bonus * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
