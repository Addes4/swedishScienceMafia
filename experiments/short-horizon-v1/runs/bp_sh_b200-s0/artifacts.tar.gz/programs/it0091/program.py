# EVOLVE-BLOCK-START
"""Best-fit primary, with empty-bin promotion for wasteful fits and a modest gap-match nudge."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    remf = rem.astype(np.float64)

    # Primary criterion: best fit (prefer smallest leftover).
    score = -remf

    # Mild nudge: reward residuals close to the distribution's typical item size (~40),
    # so gaps stay fillable by future items rather than being stranded as small waste.
    target = 40.0
    score -= 0.05 * np.abs(remf - target)

    # Promote an unused bin only when placing into a used bin would leave a residual
    # larger than the item itself (a genuinely wasteful gap hard to fill later).
    is_empty = bins == 100
    wasteful = (rem > item) & (~is_empty)
    score += wasteful.astype(np.float64) * (item + 1)
    return score
# EVOLVE-BLOCK-END

