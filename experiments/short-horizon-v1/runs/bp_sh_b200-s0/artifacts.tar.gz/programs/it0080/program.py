# EVOLVE-BLOCK-START
"""Best-fit that avoids leaving dead gaps too small to be filled later."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Base score: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Strongly prefer exact fits (residual 0): a perfectly closed bin is never wasted.
    score += (rem == 0).astype(np.float64) * 200.0

    # Discourage leaving tiny residuals (1..9) that are hard to fill later, but only
    # for used bins; a small residual in a fresh bin is fine.
    is_empty = bins == 100
    tiny = (rem > 0) & (rem < 10) & (~is_empty)
    score -= tiny.astype(np.float64) * (10.0 - rem.astype(np.float64))

    return score
# EVOLVE-BLOCK-END
