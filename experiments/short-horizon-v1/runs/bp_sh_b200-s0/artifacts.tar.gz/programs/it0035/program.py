# EVOLVE-BLOCK-START
"""Best-fit dominant, with a fresh-bin preference only for severely wasteful fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # A used bin whose leftover still exceeds half the item means the placement is
    # quite wasteful (a poor partner for a future item of similar size); make a fresh
    # bin competitive only in that case. Fresh bins have rem = 100 - item.
    wasteful = rem > (item // 2)
    score -= (wasteful & (~is_empty)).astype(np.float64) * item
    return score
# EVOLVE-BLOCK-END
