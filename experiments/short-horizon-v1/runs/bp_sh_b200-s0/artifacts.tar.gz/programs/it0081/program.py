# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus and empty-bin fallback for wasteful gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    score = -rem.astype(np.float64)

    # Strong bonus for an exact fit (residual 0): closing a bin is always good.
    score += (rem == 0) * 1e6

    # Empty-bin fallback: if placing into a used bin would leave a residual at least as
    # large as the item (a wasteful gap), promote empty bins (remaining capacity == 100).
    is_empty = bins == 100
    best_used_rem = item  # sentinel: worst-case best fit
    used = ~is_empty
    if np.any(used):
        best_used_rem = int(np.min(rem[used]))
    if best_used_rem >= item and np.any(is_empty):
        score += is_empty * 1e5

    return score
# EVOLVE-BLOCK-END
