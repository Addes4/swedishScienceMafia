# EVOLVE-BLOCK-START
"""Best-fit with a capped bonus for leftovers that match a typical item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Base: best fit -> prefer smallest leftover.
    score = -rem.astype(np.float64)

    # Reward leftovers that look like a typical item could fit exactly afterwards
    # (small gap that is still usable), but cap the reward so it is only a tie-breaker
    # among comparably tight fits, never enough to prefer opening a wasteful bin.
    # A leftover of ~0 (perfect fill) is ideal; leftover smaller than a plausible
    # minimum item (~1) is unusable, so slightly penalize it.
    target = 20.0  # rough typical small-item scale for this distribution
    usable = np.minimum(rem, target)
    # closeness to a "usable small gap"
    bonus = usable.astype(np.float64) / target  # 0 at full, up to 1 at target
    score += 0.5 * bonus

    # Small tie-break: prefer already-used bins (avoid wasting fresh bins unnecessarily).
    is_empty = bins == 100
    score -= 0.01 * is_empty
    return score
# EVOLVE-BLOCK-END

