# EVOLVE-BLOCK-START
"""Best-fit with principled exact-fill promotion and mean-adaptive reuse nudge."""
import numpy as np

# Per-stream running statistics (reset when a fresh stream starts).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item

    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Strong promotion of exact fills on used bins: a zero residual frees a bin
    # for the future at no cost, so it should dominate all other considerations.
    exact_fill = (rem == 0) & (~is_empty)
    score += exact_fill.astype(np.float64) * 1e6

    # For items at or below the running mean, mildly prefer used bins whose
    # post-placement residual stays near the mean item size: such gaps are the
    # most likely to be filled by a future item, reducing fragmentation.
    if item <= mean_item:
        gap = np.abs(rem - mean_item)
        reusable = (~is_empty) & (rem > 0)
        score += np.where(reusable, -0.5 * gap, 0.0)

    # For items above the running mean, moderately penalize opening a fresh bin
    # so that large items still try to complete existing bins first.
    if item > mean_item:
        score -= 0.25 * (item + 1) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

