# EVOLVE-BLOCK-START
"""Best-fit primary, with adaptive thresholds derived from the running mean
item size: promote empty bins for above-average items and penalize bins whose
post-placement residual wastes more than a typical item."""
import numpy as np

# Per-stream running statistics (reset implicitly by adapting over the stream).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Wasteful-gap penalty, scaled by the running mean: a used bin that would
    # leave a residual much larger than a typical item is a poor fit.
    wasteful = (rem > mean_item) & (~is_empty)
    score += wasteful.astype(np.float64) * (item + 1)

    # Empty-bin promotion only for items above the running mean (large relative
    # to the stream); smaller items consolidate into used bins.
    if item > mean_item:
        scale = (item - mean_item) / max(mean_item, 1.0)
        score += scale * (item + 1) * is_empty.astype(np.float64)
    else:
        # Consolidation nudge: prefer a used bin whose residual stays useful.
        useful_used = (rem >= 0.5 * mean_item) & (rem <= item) & (~is_empty)
        score += 0.5 * (item + 1) * useful_used.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

