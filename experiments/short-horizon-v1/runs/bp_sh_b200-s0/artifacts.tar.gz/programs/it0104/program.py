# EVOLVE-BLOCK-START
"""Best-fit primary, with item-size-scaled empty-bin promotion for large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Absolute wasteful-gap test: a used bin that would leave a residual larger
    # than the item itself is a poor fit.
    wasteful = (rem > item) & (~is_empty)
    score += wasteful.astype(np.float64) * (item + 1)

    # Item-size-scaled empty-bin promotion: reserve a fresh bin for large items
    # (which are hard to place later), while letting smaller items consolidate
    # into used bins. The bonus ramps up smoothly with item size, starting
    # around the distribution mean so mid-size items also benefit.
    scale = (item - 40.0) / 60.0  # <=0 for items up to 40, up to 1.0 at 100
    if scale > 0:
        bonus = scale * (item + 1) * is_empty.astype(np.float64)
        score += bonus

    return score
# EVOLVE-BLOCK-END

