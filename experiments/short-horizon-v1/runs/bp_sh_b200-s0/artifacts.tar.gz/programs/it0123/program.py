# EVOLVE-BLOCK-START
"""Best-fit with perfect-fill bonus and size-gated empty-bin promotion."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover after placing the item
    # Primary: best fit (smallest non-negative leftover in a used bin).
    score = -rem.astype(np.float64)

    is_empty = bins == 100
    is_used = ~is_empty

    # Reward perfect fills on used bins slightly.
    perfect = (rem == 0) & is_used
    score += perfect.astype(np.float64) * 0.5

    # Penalize wasteful gaps on used bins (better to leave a fresh bin alone).
    wasteful = (rem > item) & is_used
    score -= wasteful.astype(np.float64) * (0.25 * item + 1.0)

    # Empty-bin promotion only for items larger than the running mean (large
    # items are hard to fit later, so a fresh bin is worthwhile).
    scale = (item - mean_item) / 50.0
    if scale > 0:
        score += scale * (item + 1) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
