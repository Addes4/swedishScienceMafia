# EVOLVE-BLOCK-START
"""Best-fit primary, with waste-triggered empty-bin promotion scaled by fill level."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    score = -rem.astype(np.float64)  # primary: best fit

    is_empty = bins == 100

    # A used bin leaving a residual larger than the item itself is a wasteful gap:
    # hard to fill later, so penalize it, pushing toward tighter used bins.
    wasteful = (rem > item) & (~is_empty)
    score += wasteful.astype(np.float64) * (item + 1)

    # Empty-bin promotion only for large items, and stronger when there are already
    # many used bins (so consolidation is less valuable than a clean fresh bin).
    n_used = int(np.count_nonzero(~is_empty))
    n_total = bins.shape[0]
    occupancy = n_used / n_total if n_total > 0 else 0.0

    scale = (item - 50.0) / 50.0  # <=0 for items up to 50, up to 1.0 at 100
    if scale > 0:
        # Ramp the promotion up as occupancy grows (i.e. fewer spare empty bins).
        w = occupancy ** 2
        bonus = scale * (item + 1) * (0.5 + 1.5 * w) * is_empty.astype(np.float64)
        score += bonus

    return score
# EVOLVE-BLOCK-END

