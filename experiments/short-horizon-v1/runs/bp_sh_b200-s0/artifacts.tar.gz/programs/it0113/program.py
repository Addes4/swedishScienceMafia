# EVOLVE-BLOCK-START
"""Best-fit primary with size-relative waste penalty and fit-gated empty-bin reservation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    fitem = float(item)

    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Relative wasteful-gap penalty: a used bin whose leftover exceeds a fraction
    # of the item leaves a gap that is hard to fill later. Scale the penalty by
    # how far the leftover exceeds that fraction.
    threshold = 0.4 * fitem
    used = ~is_empty
    excess = rem.astype(np.float64) - threshold
    excess = np.where(used & (excess > 0.0), excess, 0.0)
    score -= excess

    # Empty-bin handling: a fresh bin is wasteful only if a used bin already
    # offers a reasonably tight fit. Reserve fresh bins softly for large items
    # that have no tight used-bin option.
    any_tight = bool(np.any(used & (rem <= threshold)))
    if not any_tight:
        # No tight used-bin fit exists; softly reserve fresh bins for large items.
        scale = max(0.0, (fitem - 40.0) / 60.0)
        if scale > 0.0:
            score += scale * (fitem + 1.0) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
