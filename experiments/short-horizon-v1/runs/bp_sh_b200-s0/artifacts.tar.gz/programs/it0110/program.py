# EVOLVE-BLOCK-START
"""Best-fit primary with wasteful-gap penalty and large-item empty-bin promotion."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Penalize used bins that would leave a residual larger than the item
    # (a genuinely wasteful gap that is hard to fill later).
    wasteful = (rem > item) & (~is_empty)
    score += wasteful.astype(np.float64) * (item + 1)

    # Promote empty bins only for large items, where future placement is hardest.
    # Ramp starts at 60 and reaches full strength near 100.
    if item >= 60:
        scale = (item - 60.0) / 40.0  # 0 at 60, 1 at 100
        score += scale * (item + 1) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
