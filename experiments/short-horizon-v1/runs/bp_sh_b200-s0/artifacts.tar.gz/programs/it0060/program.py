# EVOLVE-BLOCK-START
"""Relative best-fit: normalize leftovers by bin capacity and lightly reward good fills."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Base: best fit -> smallest relative leftover preferred.
    score = -rem.astype(np.float64) / 100.0

    # Light reward for near-perfect fills (residual small relative to the item),
    # a scale-free way to encourage closing bins tightly.
    fill = item.astype(np.float64) / (bins.astype(np.float64) + 1e-9)
    score += 0.25 * fill
    return score
# EVOLVE-BLOCK-END


