# EVOLVE-BLOCK-START
"""Best-fit with an online-estimated penalty for hard-to-fill leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover after placing the item
    score = -rem.astype(np.float64)

    is_empty = bins == 100
    # Penalize non-empty bins whose resulting gap is likely to be wasted.
    # A gap is wasteful if no typical future item can fill it well.
    # Use a simple scaling: gaps that are very large (close to capacity)
    # after placing into a used bin are undesirable relative to opening fresh.
    awkward = np.clip(rem - item, 0, None)
    score -= awkward.astype(np.float64) * (~is_empty)
    return score
# EVOLVE-BLOCK-END
