# EVOLVE-BLOCK-START
"""Best-fit primary, with perfect-fill preference and size-aware empty-bin use."""
import numpy as np

# Per-stream running statistics (reset when a fresh stream starts).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100
    perfect = rem == 0

    # Strongly prefer a perfect fill of an existing bin.
    score += perfect.astype(np.float64) * (item + 1.0)

    # Empty-bin promotion only for large items (relative to running mean),
    # so small items consolidate into used bins.
    scale = (item - mean_item) / 100.0
    if scale > 0:
        score += scale * (item + 1.0) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

