# EVOLVE-BLOCK-START
"""Best-fit toward a target residual, keeping bins reusable.

The idea: placing an item into a used bin leaves a residual. We prefer the bin
whose residual is smallest but still close to a useful target (about half a
typical future item), so we both pack tightly and leave room that a future item
can actually use. A fresh bin is only chosen when no used bin leaves a usable
residual.
"""
import numpy as np

# Per-stream running statistics (reset implicitly at the start of a new stream
# by the harness creating a fresh module instance per stream).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest
    (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item                 # leftover capacity after placing the item
    is_empty = bins == 100

    # Target residual: about half a typical item stays useful for the future.
    target = max(1.0, 0.5 * mean_item)

    score = np.zeros(bins.shape, dtype=np.float64)

    # Used bins: reward small residuals, and reward residuals near the target
    # (keeps remaining space usable rather than leaving unfillable slivers).
    used = ~is_empty
    rem_f = rem.astype(np.float64)
    score += used.astype(np.float64) * (-rem_f)
    score += used.astype(np.float64) * (-np.abs(rem_f - target) * 0.3)

    # A used bin that leaves a residual larger than a whole typical item is
    # wasteful: penalize it so we don't strand large gaps.
    wasteful = used & (rem_f > mean_item)
    score -= wasteful.astype(np.float64) * (given := (item + 1))

    # Fresh bins: slightly discouraged, but strongly promoted for large items
    # that would otherwise rarely fit once a bin is partially used.
    empty_pen = 0.2 * (item + 1)
    large_bonus = max(0.0, (item - 60.0) / 40.0) * (item + 1)
    score += is_empty.astype(np.float64) * (large_bonus - empty_pen)

    return score
# EVOLVE-BLOCK-END
