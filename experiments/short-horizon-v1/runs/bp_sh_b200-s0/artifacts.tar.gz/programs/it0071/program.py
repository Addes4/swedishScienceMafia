# EVOLVE-BLOCK-START
"""Adaptive best-fit / worst-fit driven by an online estimate of the item distribution."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Track exponential moving averages of item size and squared size for the std estimate.
    if not hasattr(priority, "count"):
        priority.count = 0
        priority.mean = float(item)
        priority.m2 = float(item) * float(item)
    else:
        priority.count += 1
        a = 0.02
        priority.mean += a * (item - priority.mean)
        priority.m2 += a * (float(item) * float(item) - priority.m2)

    mean = priority.mean if priority.count else float(item)
    var = priority.m2 - mean * mean
    std = (var if var > 0 else 1.0) ** 0.5

    # How "large" is the item relative to the typical item (> 0 means larger than mean).
    z = (item - mean) / std

    if z > 0.5:
        # Large item: prefer bins that keep a large residual (worst-fit / most-empty),
        # so a big item doesn't strand small awkward gaps.
        score = rem.astype(np.float64)
    else:
        # Small/medium item: best-fit to consolidate gaps.
        score = -rem.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
