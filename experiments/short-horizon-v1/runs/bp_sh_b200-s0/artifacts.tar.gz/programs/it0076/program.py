# EVOLVE-BLOCK-START
"""Best-fit, but avoid packing into a used bin when it would leave a huge gap."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    rem = (bins - item).astype(np.float64)  # leftover capacity after placing the item
    # Base: best fit (prefer smallest leftover).
    score = -rem

    # Deprioritize non-empty bins whose resulting gap is large (>= item size), i.e. wasting
    # space that a fresh bin could use better. Empty bins get no such penalty.
    is_empty = bins == 100
    wasteful = (rem >= item) & (~is_empty)
    score -= wasteful.astype(np.float64) * (item.astype(np.float64) + 1.0)
    return score
# EVOLVE-BLOCK-END
