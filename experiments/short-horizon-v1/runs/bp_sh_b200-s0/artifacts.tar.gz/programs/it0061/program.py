# EVOLVE-BLOCK-START
"""Best-fit with an item-scaled empty-bin bonus."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer smallest leftover, but promote empties when the fit is poor."""
    rem = bins - item
    score = -rem.astype(np.float64)

    # Bonus for unused bins: choose an empty bin only when the best used-bin
    # leftover exceeds ~a fraction of the item size (scale-free threshold).
    is_empty = bins == 100
    bonus = float(item) * 0.5
    score += is_empty.astype(np.float64) * bonus
    return score
# EVOLVE-BLOCK-END
