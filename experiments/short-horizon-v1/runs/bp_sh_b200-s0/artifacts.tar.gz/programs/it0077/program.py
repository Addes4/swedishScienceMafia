# EVOLVE-BLOCK-START
"""Best-fit (smallest residual), with a fine tie-break toward the fullest bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Primary: best fit (prefer smallest residual). Scale up to keep integers exact.
    score = -rem.astype(np.float64) * 1000.0
    # Fine tie-break: among equal residuals, prefer the fullest bin (smallest `bins`).
    score -= bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
