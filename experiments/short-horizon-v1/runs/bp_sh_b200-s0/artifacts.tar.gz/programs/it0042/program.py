# EVOLVE-BLOCK-START
"""Best-fit with a perfect-fill bonus and a guarded fresh-bin preference."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # leftover after placing the item
    score = -rem  # base: best fit (smallest leftover)

    # Strongly reward perfect fills (leftover exactly 0).
    score += (rem == 0) * 1e6

    # Prefer a fresh bin when even the best used-bin fit wastes more than
    # 60% of the item's size (gap hard to fill later).
    used = bins < 100
    if used.any():
        best_rem = rem[used].min()
        if best_rem > 0.6 * item:
            score += (bins == 100) * 0.5

    return score
# EVOLVE-BLOCK-END
