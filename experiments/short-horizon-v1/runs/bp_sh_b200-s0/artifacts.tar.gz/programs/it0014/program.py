# EVOLVE-BLOCK-START
"""Best-fit, mildly preferring bins whose resulting leftover is a likely future item size."""
import numpy as np

_state = {"n": 0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes into the highest (first on ties)."""
    hist = _state["hist"]
    n = _state["n"]

    rem = bins - item  # leftover capacity after placing

    # Base: best fit -> prefer smallest leftover.
    score = -rem.astype(np.float64)

    if n >= 30:
        # Probability mass (relative) of future items fitting into a leftover of size rem.
        # For leftover r, future items of size <= r can fill it; but we prefer leftovers that
        # can be filled *well* (close to full). Use cumulative mass up to min(r,100).
        cdf = np.cumsum(hist) / n  # cdf[s] ~ P(item <= s)
        p_fill = cdf[np.clip(rem, 0, 100).astype(np.int64)]
        score += 3.0 * p_fill  # reward leftovers that are fillable by typical items

    # Record the item.
    hist[item] += 1.0
    _state["n"] = n + 1

    return score
# EVOLVE-BLOCK-END
