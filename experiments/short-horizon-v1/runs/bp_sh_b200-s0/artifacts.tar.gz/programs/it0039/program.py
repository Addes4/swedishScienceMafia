# EVOLVE-BLOCK-START
"""Hybrid best-fit with a quadratic penalty on wasteful leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    # Best fit: prefer smallest leftover.
    score = -rem.astype(np.float64)

    # Quadratic penalty on the leftover (relative to the item size): strongly rewards
    # near-exact wraps and mildly discourages medium-waste placements.
    score -= (rem.astype(np.float64) ** 2) / max(item, 1)

    return score
# EVOLVE-BLOCK-END
