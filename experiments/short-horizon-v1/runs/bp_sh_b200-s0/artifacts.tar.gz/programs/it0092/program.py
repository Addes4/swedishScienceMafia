# EVOLVE-BLOCK-START
"""Best-fit primary, with a smooth small-residual bonus and a mild empty-bin safeguard."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    remf = rem.astype(np.float64)

    # Primary criterion: best fit (prefer smallest post-placement residual).
    score = -remf

    # Mild bonus for tight residuals: packing into an already-nearly-full bin keeps
    # fragmentation low, so give a small edge to residuals in the "small item" band.
    score += np.where((rem >= 0) & (rem <= 20), 0.5 * (20.0 - remf) / 20.0, 0.0)

    # Promote an unused bin only when the best used bin would leave a genuinely
    # wasteful gap (residual larger than the item itself, and non-trivial).
    is_empty = bins == 100
    wasteful = (rem > item) & (~is_empty)
    score += wasteful.astype(np.float64) * (0.5 * item)
    return score
# EVOLVE-BLOCK-END


