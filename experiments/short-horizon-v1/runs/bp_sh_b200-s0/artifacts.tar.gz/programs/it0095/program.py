# EVOLVE-BLOCK-START
"""Best-fit primary, with a smooth future-fit empty-bin promotion."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item                      # leftover capacity after placing the item
    is_empty = bins == 100

    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # A used bin whose residual would exceed the item being placed is a poor
    # target: the gap is larger than what we just put in and likely to linger.
    # Penalize it by exactly one tier so it ranks behind an equal-residual
    # tight fit but still ahead of much worse best-fit choices handled below.
    wasteful = (rem > item) & (~is_empty)
    score -= wasteful.astype(np.float64) * (item + 1)

    # Smooth empty-bin promotion: only promote a fresh bin when the current
    # item is large AND the best used placement would leave an awkward residual.
    # scale ramps 0 -> 1 as item grows from half-capacity to full capacity.
    scale = (item - 50.0) / 50.0
    if scale > 0 and not np.any(is_empty & False):  # scale>0 branch only
        # residual that the best used bin would leave (ignoring empties)
        used = ~is_empty
        if np.any(used):
            best_used_rem = np.min(rem[used])
        else:
            best_used_rem = 101
        # how awkward that residual is: 1 if it can't fit a small item (~10),
        # tapering off as it grows toward a comfortable fill range.
        awkward = (45.0 - best_used_rem) / 45.0
        awkward = min(max(awkward, 0.0), 1.0)
        bonus = scale * awkward * (item + 1)
        score += bonus * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
