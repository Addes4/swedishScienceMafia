# EVOLVE-BLOCK-START
"""Best-fit with a residual-shaping correction tuned to the item distribution.

Score used bins primarily by best-fit (smallest leftover after placement), but shape
the preference so that near-perfect fills and leftovers that will still accommodate a
typical future item are favored over "dead" midrange leftovers that no future item of
the distribution can fill. Empty bins get a small baseline that only wins when the
best used-bin fill would leave a residual that cannot host a typical item.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of all bins the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover after placing this item
    is_empty = bins == 100

    # Dominant term: best fit -> prefer smallest leftover.
    score = -rem.astype(np.float64)

    # Residual shaping: ideal leftovers are small (near 0) or large enough to host a
    # typical future item (~40). Penalize the "dead zone" leftover that is too big to
    # be a tight wrap but too small to fit a typical item.
    typical = 40.0
    # distance of leftover from the nearest desirable anchor: 0 or typical.
    d0 = rem.astype(np.float64)
    dT = np.abs(rem.astype(np.float64) - typical)
    deadness = np.minimum(d0, dT)  # 0 when leftover ~0 or ~typical, larger in between
    # Only penalize non-empty bins; empty bins are governed by the fresh-bin baseline.
    penalty = deadness * (~is_empty)

    # Fresh-bin baseline: unused bins start slightly above a perfect-fill used bin so
    # that opening a new bin is preferred over a wasteful midrange placement.
    fresh = is_empty.astype(np.float64) * (typical * 0.5)

    score = score - penalty + fresh
    return score
# EVOLVE-BLOCK-END
