# EVOLVE-BLOCK-START
"""Best-fit with a normalized fill preference to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item                       # leftover after placement
    # Dominant term: best fit (smallest leftover).
    score = -rem.astype(np.float64)
    # Secondary term: prefer bins that are already relatively full, i.e. small current
    # remaining capacity. This consolidates load and reduces scattered slack.
    # Normalize by 100 so the term is a mild tie-breaker, not a dominating one.
    score -= 0.05 * (bins.astype(np.float64) - item * 0.0) / 100.0 * item
    return score
# EVOLVE-BLOCK-END
