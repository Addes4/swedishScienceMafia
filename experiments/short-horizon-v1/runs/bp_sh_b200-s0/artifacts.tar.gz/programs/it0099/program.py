# EVOLVE-BLOCK-START
"""Best-fit primary, with data-driven empty-bin promotion for awkward residuals."""
import numpy as np

# Running statistics of recently seen items (updated in `priority`).
_state = {
    "n": 0.0,          # effective count (decays)
    "mean": 40.0,      # decayed mean item size
    "small_frac": 0.25,  # decayed fraction of "small" items (<= mean/2)
    "decay": 0.99,
}


def _update(item):
    s = _state
    m = s["mean"]
    small = 1.0 if item <= m * 0.5 else 0.0
    s["n"] = s["n"] * s["decay"] + 1.0
    s["mean"] = m * s["decay"] + item * (1.0 - s["decay"])
    s["small_frac"] = (
        s["small_frac"] * s["decay"] + small * (1.0 - s["decay"])
    )


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _update(item)

    rem = bins - item  # leftover capacity after placing the item
    score = -rem.astype(np.float64)  # primary: best fit

    is_empty = bins == 100

    mean = _state["mean"]
    # A used bin whose leftover falls in the "small item" range is actually a
    # fine gap to leave (small items are common); one whose leftover is above
    # that but still awkward is a poor fit. Reward fillable residuals.
    small_thresh = mean * 0.5

    fillable = (rem >= 0) & (rem <= small_thresh) & (~is_empty)
    score += fillable.astype(np.float64) * (item + 1) * 0.5

    # Promote an empty bin when placing here would leave an awkward residual:
    # the leftover is too big to be a small-item gap yet smaller than a typical
    # item (a residual that few future items can use well).
    awkward = (rem > small_thresh) & (rem < mean) & (~is_empty)
    scale = (item - 40.0) / 60.0
    if scale > 0:
        score += awkward.astype(np.float64) * (item + 1) * scale
        score += scale * (item + 1) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

