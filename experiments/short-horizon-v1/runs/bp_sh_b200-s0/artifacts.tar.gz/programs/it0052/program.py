# EVOLVE-BLOCK-START
"""Best fit with a residual-compatibility bonus based on the running item distribution.

Idea: placing an item into a bin leaves a residual r. A bin is "good" not only when r is
small (best fit) but also when r is a value that the item distribution is likely to fill
well later. We keep best-fit as the base and add a small bonus when the residual is close
to a typical future item size (tracked online via a running mean and std of past items).
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    state = priority.__dict__
    # Online running stats (Welford-ish, simple cumulative mean/var).
    n = state.get("n", 0) + 1
    mean = state.get("mean", 0.0)
    m2 = state.get("m2", 0.0)
    delta = item - mean
    mean += delta / n
    m2 += delta * (item - mean)
    state["n"] = n
    state["mean"] = mean
    state["m2"] = m2

    rem = bins - item  # leftover capacity after placing the item
    rem_f = rem.astype(np.float64)

    # Base: best fit (prefer smallest leftover).
    score = -rem_f

    # Residual-compatibility bonus: reward residuals close to a typical item size.
    if n >= 5:
        var = m2 / n
        std = np.sqrt(var) if var > 1e-9 else 1.0
        mu = mean
        # Gaussian-shaped reward centered at the running mean item size.
        z = (rem_f - mu) / std
        reward = np.exp(-0.5 * z * z)
        score += 0.5 * reward

    return score
# EVOLVE-BLOCK-END
