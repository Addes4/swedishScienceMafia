# EVOLVE-BLOCK-START
"""Best-fit with a gentle guard against unusable small residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of bins the item fits in.
    """
    rem = (bins - item).astype(np.float64)  # leftover capacity after placing the item
    # Primary: best fit (prefer smallest leftover).
    score = -rem

    # Guard: if the leftover is a small non-zero gap that is hard to fill later
    # (smaller than a typical item), slightly discourage it relative to other bins,
    # but never enough to override a strictly better fit by more than 1 unit.
    # A tiny dead-zone penalty keeps residuals from accumulating as unusable crumbs.
    dead = (rem > 0) & (rem < 10)
    score -= dead.astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
