# EVOLVE-BLOCK-START
"""Best-fit-flavored harmony rule: prefer the used bin whose leftover after
placing the item is closest to the running mean item size (a reusable gap),
with a small empty-bin penalty so fresh bins are only opened when no used bin
offers a reasonable residual."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = (bins - item).astype(np.float64)  # leftover after placing the item
    is_empty = bins == 100

    # Target residual: a gap large enough to hold a typical future item, which
    # keeps the bin maximally reusable rather than wasting capacity.
    target = mean_item

    # Distance from the ideal leftover, but scaled by item size so that large
    # items still prefer the tightest fit (their residuals matter more).
    dist = np.abs(rem - target)
    score = -dist

    # Soft penalty on opening a fresh bin: only worth it if it clearly beats
    # the best used bin.  Scale mildly with item size.
    score -= is_empty.astype(np.float64) * (0.25 * target + 1.0)

    return score
# EVOLVE-BLOCK-END

