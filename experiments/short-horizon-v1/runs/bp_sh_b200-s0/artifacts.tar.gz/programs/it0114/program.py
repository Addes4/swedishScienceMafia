# EVOLVE-BLOCK-START
"""Best-fit with size-aware wasteful-gap penalty and conditional empty-bin promotion."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # leftover after placing the item
    # Primary: best fit (prefer smallest leftover).
    score = -rem

    is_empty = bins == 100

    # Wasteful-gap penalty: leaving a residual larger than the item itself in a
    # used bin is poor, since the item could have gone into a tighter bin.
    wasteful = (rem > item) & (~is_empty)
    score -= wasteful.astype(np.float64) * (item + 1.0)

    # Conditional empty-bin promotion: promote fresh bins only for large items and
    # only when no used bin already offers a reasonably tight fit.
    tight_used = (~is_empty) & (rem <= item / 2.0)
    has_tight = bool(tight_used.any())
    large = item >= 55
    if large and not has_tight:
        scale = (item - 55.0) / 45.0  # up to 1.0 at 100
        score += scale * (item + 1.0) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
