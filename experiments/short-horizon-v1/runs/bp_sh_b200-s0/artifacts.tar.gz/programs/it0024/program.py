# EVOLVE-BLOCK-START
"""Best-fit base with a fresh-bin preference whose threshold scales with the item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    rem = bins - item  # leftover capacity after placing the item
    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # If placing into a used bin leaves a large remainder, promote unused bins.
    # The threshold scales with item size: large items deserve roomier leftovers
    # because the distribution is heavy-tailed (mean ~40), so a big gap left by a
    # big item is likely to be filled by another big-ish item.
    is_empty = bins == 100
    # Penalize used bins whose leftover exceeds a fraction of the item size.
    excess = np.clip(rem - 0.6 * item, 0, None)
    score -= excess.astype(np.float64) * (~is_empty)
    return score
# EVOLVE-BLOCK-END
