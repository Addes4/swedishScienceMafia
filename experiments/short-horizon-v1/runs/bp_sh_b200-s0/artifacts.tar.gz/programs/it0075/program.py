# EVOLVE-BLOCK-START
"""Best fit with a smooth fullness bonus to close near-full bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # leftover after placing, >= 0 for fitting bins
    # Primary: best fit -> smallest residual.
    score = -rem
    # Secondary: reward closing bins tightly (prefer smaller residual more strongly for
    # residuals below the item size, where the gap is hard to reuse).
    score -= 0.05 * np.clip(item - rem, 0, None)
    return score
# EVOLVE-BLOCK-END
