# EVOLVE-BLOCK-START
"""Best-fit primary, with item-size-scaled empty-bin promotion for large items
and a stateful consolidation nudge for typical-size items. Thresholds adapt to
the running mean item size."""
import numpy as np

# Per-stream running statistics (reset when a fresh stream starts).
_state = {"n": 0, "sum": 0.0, "last_size": -1}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running statistics with a soft running mean.
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Wasteful-gap test relative to the running mean: a used bin that would leave
    # a residual larger than the mean item size is a poor fit.
    wasteful = (rem > mean_item) & (~is_empty)
    score += wasteful.astype(np.float64) * (mean_item + 1)

    # Item-size-scaled empty-bin promotion: reserve a fresh bin mainly for
    # items above the running mean, scaling up as the item grows.
    scale = (item - mean_item) / max(mean_item, 1.0)
    if scale > 0:
        bonus = min(scale, 1.0) * (item + 1) * is_empty.astype(np.float64)
        score += bonus

    # Consolidation nudge: for typical-size items, prefer a used bin whose
    # residual stays useful (>= half the running mean item size) over opening a
    # fresh bin, cutting needless bin openings without harming large items.
    if scale <= 0:
        half_mean = 0.5 * mean_item
        useful_used = (rem >= half_mean) & (rem <= item) & (~is_empty)
        score += 0.5 * (item + 1) * useful_used.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
