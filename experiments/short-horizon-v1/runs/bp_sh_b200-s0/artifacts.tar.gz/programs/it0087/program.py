# EVOLVE-BLOCK-START
"""Best-fit with a wasteful-gap safeguard: prefer empty bins only when the best used
bin would leave a residual larger than the item itself."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item                 # residual after placing the item
    is_empty = bins == 100

    # Primary: best fit -> smaller residual is better.
    score = -rem.astype(np.float64)

    # Safeguard: opening a fresh bin is only better than a used bin when the used bin
    # would leave a wasteful gap (residual >= item size, i.e. the placed item is small
    # relative to what remains, fragmenting the bin). Penalize empty bins in that case.
    wasteful = rem >= item
    # Non-empty bins that are wasteful get pushed below empty bins.
    score -= wasteful.astype(np.float64) * (~is_empty) * 1e6

    return score
# EVOLVE-BLOCK-END
