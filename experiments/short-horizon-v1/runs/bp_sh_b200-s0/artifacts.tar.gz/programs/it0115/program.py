# EVOLVE-BLOCK-START
"""Best-fit with a size-relative consolidation bonus and gated empty-bin promotion."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.float64)  # leftover capacity after placing the item
    is_empty = bins == 100

    # Primary term: best fit (prefer smallest leftover).
    score = -rem

    # Consolidation bonus: reward used bins where the leftover relative to the
    # item is small, i.e. the item fills the bin tightly (good future packing).
    ratio = rem / float(item)
    score -= 2.0 * ratio * (~is_empty)

    # Empty-bin promotion: only for large items, where leaving a used bin with a
    # large residual is more costly than consuming a fresh bin.
    scale = (item - 55.0) / 45.0
    if scale > 0.0:
        score += scale * (item + 1.0) * is_empty.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
