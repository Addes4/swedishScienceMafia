# EVOLVE-BLOCK-START
"""Best-fit that avoids creating tiny, hard-to-fill leftover gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = (bins - item).astype(np.int64)  # leftover capacity after placing the item

    # Threshold: a leftover below this is an "awkward" gap that is hard to fill later.
    # Items have mean ~40, so a gap smaller than ~10 is usually wasted.
    T = 10

    is_empty = bins == 100

    # Base score: best-fit (prefer smallest leftover) -> -rem.
    score = -rem.astype(np.float64)

    # Exact fit (rem == 0) is always best: give a strong bonus.
    score += (rem == 0).astype(np.float64) * 1000.0

    # For non-empty bins, penalize awkward small-but-nonzero gaps (0 < rem < T).
    # This makes us prefer a used bin with a larger usable leftover over one that
    # would be left with an unusable sliver.
    awkward = (rem > 0) & (rem < T) & (~is_empty)
    score -= awkward.astype(np.float64) * 500.0

    return score
# EVOLVE-BLOCK-END
