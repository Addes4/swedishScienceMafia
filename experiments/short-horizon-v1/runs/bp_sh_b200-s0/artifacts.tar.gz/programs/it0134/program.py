# EVOLVE-BLOCK-START
"""Best-fit primary, with a near-perfect-fill bonus for used bins and a
mean-relative penalty for opening fresh bins."""
import numpy as np

# Per-stream running statistics.
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties)."""
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    rem = bins - item  # leftover capacity after placing the item
    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Near-perfect-fill bonus: if placing the item nearly fills a used bin
    # (residual small relative to capacity), strongly prefer it since it
    # effectively retires a bin at low cost.
    nearly_full = (~is_empty) & (rem <= 0.05 * 100)
    score += nearly_full.astype(np.float64) * 100.0

    # Empty-bin penalty: opening a fresh bin wastes the chance to consolidate.
    # Scale with how large the item is relative to the running mean, so big
    # items are allowed to open fresh bins while small/typical ones consolidate.
    excess = item - mean_item
    if excess > 0:
        score -= (excess / max(mean_item, 1.0)) * is_empty.astype(np.float64) * 60.0

    return score
# EVOLVE-BLOCK-END

