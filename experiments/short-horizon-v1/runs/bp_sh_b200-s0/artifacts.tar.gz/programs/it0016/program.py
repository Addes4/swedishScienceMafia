# EVOLVE-BLOCK-START
"""Best-fit with a tiny online completability bonus for near-ties."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "count": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    hist = st["hist"]
    count = st["count"]

    rem = bins - item  # leftover capacity after placing
    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    if count > 0:
        # Probability that a future item exactly fills the leftover `rem`.
        # Normalized histogram over past items; only reward exact fills.
        probs = hist / count
        # rem is 0..100 integer since bins and item are ints
        idx = np.clip(rem, 0, 100).astype(np.int64)
        bonus = probs[idx]
        # Fresh bins (remaining==100) won't be exactly filled by a single item often;
        # the bonus naturally captures whether leftover matches common item sizes.
        score += bonus * 2.0

    # Update online histogram after scoring (state for next calls).
    if 1 <= item <= 100:
        hist[item] += 1.0
        st["count"] = count + 1.0

    return score
# EVOLVE-BLOCK-END
