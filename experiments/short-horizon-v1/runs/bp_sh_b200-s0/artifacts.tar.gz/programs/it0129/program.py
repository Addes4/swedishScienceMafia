# EVOLVE-BLOCK-START
"""Best-fit primary, with a strong near-perfect-fill bonus.

Pure best-fit (smallest residual after placement) is already a strong online
rule for this distribution.  The only addition is a bonus for used bins whose
residual after placement becomes very small (essentially an exact or near-exact
fill), which is the one case where deviating from plain best-fit is clearly
beneficial: it locks in a well-packed bin and avoids wasting a tight gap.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Primary criterion: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Near-perfect-fill bonus: when a used bin would be left with a residual
    # much smaller than the item itself, strongly prefer it so the tight gap is
    # consumed rather than stranded.  This rewards placing large items into
    # nearly-full bins instead of opening a fresh bin.
    near_perfect = (~is_empty) & (rem * 4 <= item)
    score += near_perfect.astype(np.float64) * (item + 1.0)

    return score
# EVOLVE-BLOCK-END
