# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware residual-fillability score.

The arriving item must be placed immediately.  Best fit (smallest leftover) is the
strongest single heuristic for online bin packing, but it ignores whether the
leftover gap is likely to be fillable later.  We keep best-fit as the dominant
term and add a modest bonus for gaps that the running empirical item distribution
is likely to fill (either exactly or by a near match), while mildly preferring to
consolidate into used bins rather than opening fresh ones.
"""
import numpy as np

# Module state: exponentially weighted histogram of item sizes seen so far.
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_ALPHA = 0.02   # EWMA decay for the histogram


def _fillability(res):
    """Estimate, from the running item histogram, the chance a residual gets filled.

    Returns a value in [0, 1] that is high when the residual is close to a
    commonly seen item size (so it can be completed), and decays with distance.
    """
    if res <= 0:
        return 1.0
    if _TOTAL <= 0:
        return 0.0
    # Distribution over item sizes (normalized).
    probs = _HIST / _TOTAL
    # Reward residuals that equal a frequent item size; smooth with a small
    # tolerance kernel so near matches also get credit.
    lo = max(1, res - 2)
    hi = min(100, res + 2)
    return float(probs[lo:hi + 1].sum())


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _TOTAL

    rem = (bins - item).astype(np.float64)
    # Update running empirical distribution with this arriving item.
    _HIST[item] += 1.0
    _TOTAL += 1.0
    if _TOTAL > 1.0 / _ALPHA:
        _HIST *= (1.0 - _ALPHA)
        _TOTAL *= (1.0 - _ALPHA)

    # Base: best fit (prefer smallest non-negative leftover).
    score = -rem

    is_empty = (bins == 100)
    probs = _HIST / _TOTAL if _TOTAL > 0 else np.zeros(101)

    # Distribution-awareness: reward used bins whose post-placement residual is
    # likely to be completed by a future item (dense in the histogram).
    for i in range(bins.shape[0]):
        r = rem[i]
        if r > 0:
            lo = int(max(1, r - 2))
            hi = int(min(100, r + 2))
            score[i] += 5.0 * float(probs[lo:hi + 1].sum())

    # Mildly prefer consolidating into used bins over opening fresh ones.
    score -= 0.5 * is_empty
    return score
# EVOLVE-BLOCK-END
