# EVOLVE-BLOCK-START
"""Best-fit with an online "good pairing" bonus based on the running item mean."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Online estimate of the mean item size from past items (starts near the known mean ~40).
    n = _state["n"]
    mean = (_state["sum"] / n) if n > 0 else 40.0
    _state["sum"] += item
    _state["n"] = n + 1

    # Bonus when the leftover closely matches a likely future item (perfect pairing).
    # Small weight so it only breaks near-ties in favor of well-paired leftovers.
    bonus = np.exp(-((rem - mean) ** 2) / (2.0 * (mean * 0.5) ** 2))
    score += 0.5 * bonus.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
