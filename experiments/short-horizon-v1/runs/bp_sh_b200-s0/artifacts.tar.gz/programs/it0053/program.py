# EVOLVE-BLOCK-START
"""Best-fit with an empty-bin hysteresis driven by the running item scale.

item: integer size of the arriving item, 1..100.
bins: numpy int64 array with remaining capacity of every bin the item fits in,
      including unused bins (remaining capacity 100), in bin order.
"""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    # Update running mean item size (state persists within a stream).
    _state["sum"] += item
    _state["n"] += 1
    mean_item = _state["sum"] / _state["n"]

    rem = (bins - item).astype(np.float64)  # leftover after placing
    is_empty = bins == 100

    # Base: best fit -> smallest leftover is best.
    score = -rem

    # Hysteresis: only open a fresh bin when the best used-bin leftover is so
    # large that it is unlikely to be filled well by future items. The threshold
    # scales with the running mean item size.
    # Reward empty bins when every used bin leaves a big residual; otherwise
    # mildly penalize opening a new bin to encourage consolidation.
    # Find the smallest leftover achievable among used bins.
    if np.any(~is_empty):
        best_used_rem = rem[~is_empty].min()
    else:
        best_used_rem = np.inf

    threshold = 0.5 * mean_item
    if best_used_rem > threshold:
        # A used bin would leave a wasteful gap: promote empty bins.
        score += is_empty.astype(np.float64) * mean_item
    else:
        # Consolidate: prefer used bins slightly over empty bins.
        score -= is_empty.astype(np.float64) * (0.01 * mean_item)

    return score
# EVOLVE-BLOCK-END
