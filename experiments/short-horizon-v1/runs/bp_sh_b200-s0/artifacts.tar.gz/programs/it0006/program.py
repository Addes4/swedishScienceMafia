# EVOLVE-BLOCK-START
"""Distribution-aware best-fit: penalize leftovers unlikely to be filled by future items."""
import numpy as np

_SAMPLES = np.arange(1, 101)
_STATE = {"hist": np.zeros(101, dtype=np.float64), "n": 0}


def _probs():
    n = _STATE["n"]
    hist = _STATE["hist"]
    if n < 30:
        return None
    p = hist / n
    return p


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update online item-size histogram.
    _STATE["hist"][item] += 1.0
    _STATE["n"] += 1

    rem = bins - item  # leftover after placing the item
    is_empty = bins == 100

    # Base best-fit: prefer smallest leftover.
    score = -rem.astype(np.float64)

    p = _probs()
    if p is not None:
        # For each leftover value r, estimate "usefulness": the probability a future item
        # can be packed to leave an even smaller remainder (i.e., how fillable this gap is).
        # We approximate fillability by the mass of item sizes <= r, and reward leftovers
        # that match a common item size (high chance of exact/near fill).
        cum = np.cumsum(p)  # cum[s] = P(item <= s), 1-indexed by size s
        # fill mass for leftover r (clamped to [0,100]); r in [0,100]
        rc = np.clip(rem, 0, 100).astype(np.int64)
        fill = np.where(rc > 0, cum[np.clip(rc - 1, 0, 100)], 0.0)
        # Reward high fill probability for non-empty bins (a usable gap).
        score += fill * (~is_empty) * 5.0

    return score
# EVOLVE-BLOCK-END
