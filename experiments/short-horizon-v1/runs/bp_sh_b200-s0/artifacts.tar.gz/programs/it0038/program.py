# EVOLVE-BLOCK-START
"""Subharmonic best-fit: best fit for used bins, with mild rewards for near-exact wraps
and a fresh-bin nudge only when the best used-bin fit is clearly wasteful."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Reward near-exact wraps: leftover close to 0 is valuable (bin likely full).
    # Continuous bonus peaked at rem == 0, decaying with leftover size relative to item.
    wrap = np.exp(-rem.astype(np.float64) / max(item, 1.0))
    score += wrap * (~is_empty)

    # Mild fresh-bin nudge only when even the best fit is wasteful:
    # leftover larger than the item itself suggests a hard-to-fill gap.
    wasteful = (rem > item)
    score += wasteful.astype(np.float64) * is_empty * 0.5

    return score
# EVOLVE-BLOCK-END

