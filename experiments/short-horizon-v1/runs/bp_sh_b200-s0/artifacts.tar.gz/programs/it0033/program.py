# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware bonus for likely-completing leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # Base: best fit (prefer smallest leftover).
    score = -rem.astype(np.float64)

    # Distribution-aware bonus: a non-empty bin whose leftover is close to a typical
    # future item size is likely to be exactly completed by a single later item, which
    # is a "free" packing gain. We track a running mean of past item sizes.
    global _prev
    try:
        mean = _prev[0]
        cnt = _prev[1]
    except NameError:
        mean = 40.0
        cnt = 0
    # Update running mean (this item excluded from its own decision).
    new_mean = (mean * cnt + item) / (cnt + 1.0)
    _prev = (new_mean, cnt + 1)

    is_empty = bins == 100
    # Reward when leftover is near the running mean (a likely future item size).
    match = np.exp(-((rem - mean) ** 2) / (2.0 * (0.5 * mean + 1.0) ** 2))
    score += 8.0 * match * (~is_empty)

    return score
# EVOLVE-BLOCK-END
