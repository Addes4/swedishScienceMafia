# EVOLVE-BLOCK-START
"""Best-fit primary, with an item-size-scaled reluctance to open fresh bins.

Grounded intuition: best-fit (smallest leftover after placement) minimizes waste
per placement, which is near-optimal for this item distribution. The main
failure mode of pure best-fit is opening a fresh bin for a small item when a
used bin could absorb it -- and the reverse: cramming a large item into a used
bin leaving a tiny, unusable residual. Both are captured by a single penalty on
choosing an empty (remaining capacity 100) bin that grows with item size:
  - small items strongly prefer used bins (consolidation),
  - large items freely open fresh bins (avoid crippling a bin with a big item).
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placement (>= 0 since item fits)
    # Primary criterion: best fit (prefer smallest leftover). Higher is better.
    score = -rem.astype(np.float64)

    is_empty = bins == 100

    # Reluctance to open a fresh bin, scaled by item size: small items should
    # consolidate into used bins; large items may reasonably claim a new bin.
    # At item=0 penalty is ~0 (freely use anything); at item=100 it fully offsets
    # best-fit so a fresh bin is comparable to any used bin.
    empty_penalty = (item / 100.0) * (item + 1) * is_empty.astype(np.float64)
    score -= empty_penalty

    return score
# EVOLVE-BLOCK-END
