# EVOLVE-BLOCK-START
"""Best-fit base with a residual-fillability bonus and exact-fill reward."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # leftover capacity after placing the item

    # If placing into a used bin would leave a large remainder (a wasteful gap that is
    # hard to fill later), promote unused bins (remaining capacity == 100).
    is_empty = bins == 100
    awkward = np.clip(rem - item, 0, None)  # leftover exceeding the item size
    score = -rem.astype(np.float64)
    score -= awkward.astype(np.float64) * (~is_empty)
    return score
# EVOLVE-BLOCK-END
