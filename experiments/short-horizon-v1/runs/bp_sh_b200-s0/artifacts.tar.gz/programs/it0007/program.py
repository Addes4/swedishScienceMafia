# EVOLVE-BLOCK-START
"""Expected-residual-waste bin choice using an online item-size distribution."""
import numpy as np

# Online histogram of observed item sizes (1..100), kept as module state.
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin; highest wins (ties go to first bin).

    item: integer size 1..100.
    bins: remaining capacities (int64) of bins the item fits in, in bin order.
    """
    global _hist, _count

    # Update the online item-size distribution safely.
    if 1 <= item <= 100:
        _hist[item] += 1.0
    _count += 1.0

    rem = bins - item  # leftover after placing the item
    rem_f = rem.astype(np.float64)

    # Base preference: best fit (smallest leftover).
    score = -rem_f

    # Build a usable-item-size profile: probability of each future item size.
    total = _hist.sum()
    if total > 0:
        p = _hist / total
    else:
        p = np.zeros(101, dtype=np.float64)
        p[1:101] = 1.0 / 100.0

    sizes = np.arange(101, dtype=np.float64)
    full_sizes = sizes[1:101]
    weights = p[1:101]

    # For each candidate leftover r, estimate how well future items fill it.
    # Good leftover: it can hold a typical item with little wasted space.
    # We compute, for each possible r, the best expected fill ratio.
    # remainders r (0..100). We only care about r = rem for each bin.
    # For a leftover r, expected best fill = max over future items s<=r of s,
    # weighted by their probabilities where defined; also strongly reward r that
    # is itself near a common item size.
    # Compute a penalty vector indexed by leftover 0..100.
    penalty = np.zeros(101, dtype=np.float64)
    for r in range(101):
        if r == 0:
            penalty[r] = 0.0
            continue
        # probability weight of usable items s (1<=s<=r)
        usable = weights[:r] if r >= 1 else np.array([])
        if usable.size > 0:
            # expected wasted fraction if we fill r with the largest typical item
            s = full_sizes[:r]
            wsum = usable.sum()
            if wsum > 0:
                # expected leftover after best single fill attempt
                # approximate fill efficiency: how much of r a random fitting item uses
                eff = float(np.sum(usable * s) / wsum) / r
            else:
                eff = 0.0
        else:
            eff = 0.0
        # Penalize low efficiency (hard-to-fill gaps). Scale down so best-fit
        # remains the dominant term; only large wasteful gaps get demoted.
        penalty[r] = (1.0 - eff) * r

    is_empty = bins == 100
    # Apply penalty only to used bins; unused bins stay attractive when gaps waste space.
    score -= penalty[np.clip(rem, 0, 100)] * (~is_empty)
    return score
# EVOLVE-BLOCK-END
