# EVOLVE-BLOCK-START
"""Best-fit with empirical completion-aware tie-breaking.

Take an exact perfect fit when available. Otherwise use best-fit (smallest
positive residual) as the dominant rule, which is robust and packs tightly.
Among residuals that are close in size (within a small band), prefer the one
whose exact value is most likely to be fillable by one or two future items,
estimated online from a Weibull-shaped prior blended with the observed item
histogram. This keeps tight packing while avoiding leaving small gaps that
can never be completed.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior

_DECAY = 0.999  # mild recency weighting

_min_item = 100.0  # smallest item observed so far in this stream


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _hist, _min_item

    residual = bins - item
    residual_f = residual.astype(np.float64)

    # Strongly prefer an exact perfect fit.
    perfect = (residual == 0)

    h = _hist / _hist.sum()
    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual.
    exact = h[r_idx]

    # Probability a pair of future items sums exactly to this residual.
    conv2 = np.convolve(h[1:], h[1:])  # conv2[k] for sum k+2
    pair = np.zeros(101, dtype=np.float64)
    k = min(101, conv2.size)
    pair[2:2 + k] = conv2[:101 - 2]

    # Completion probability (one or two items) for the residual.
    completion = exact + pair[r_idx]

    # Primary: best-fit. Smaller positive residual dominates.
    # Use a coarse band so that only residuals within the band compete on
    # completion probability.
    score = -residual_f

    # Within a band of the tightest fit, completion probability can nudge.
    # Compute the minimum positive residual among fitting bins.
    pos = residual > 0
    if np.any(pos):
        min_pos = float(residual[pos].min())
        band = (residual_f <= min_pos + 3.0) & pos
        score = score + band * (5.0 * completion)

    # Exact fits get a large bonus.
    score = score + perfect * 1e9

    # Soft stranding pressure: residuals below the smallest observed item
    # cannot ever be filled; discourage them but never override best-fit.
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual_f < min_obs)
    score -= unusable * 2.0

    # Update histogram.
    _hist *= _DECAY
    _hist[item] += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score
# EVOLVE-BLOCK-END
