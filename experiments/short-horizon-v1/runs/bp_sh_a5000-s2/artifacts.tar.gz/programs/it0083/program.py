# EVOLVE-BLOCK-START
"""Best fit with a stranding-aware penalty.

The classic best-fit rule (place the item in the bin with the smallest
remaining capacity that still fits, i.e. the smallest positive residual)
is the strongest simple online rule for this distribution. The only
modification is a penalty for placements that would leave a residual
smaller than any item observed so far in the stream, since such gaps can
never be filled again and are permanently wasted capacity.
"""
import numpy as np

_min_item = 100.0  # smallest item size observed so far in this stream


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _min_item

    residual = bins - item

    # Primary: prefer the smallest positive residual (best fit).
    # residual == 0 (perfect fit) is smallest, so it wins automatically.
    score = -residual.astype(np.float64)

    # Penalize residuals that can never be filled again: below the smallest
    # item observed so far these fragments are permanently stranded, and the
    # penalty grows the further below that minimum we fall.
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (20.0 + 8.0 * deficit)

    # Update the smallest observed item size for future calls.
    if item < _min_item:
        _min_item = float(item)

    return score
# EVOLVE-BLOCK-END
