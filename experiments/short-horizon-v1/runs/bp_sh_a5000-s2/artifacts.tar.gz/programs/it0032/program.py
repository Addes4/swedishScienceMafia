# EVOLVE-BLOCK-START
"""Best fit with empirical residual-closure tie-break."""
import numpy as np

# Empirical item-size histogram over sizes 1..100, shared across calls within a stream.
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0
# Decay for old observations (forget past items gradually).
_DECAY = 0.999


def _closure_prob(res):
    """Estimated probability that some future item exactly matches residual `res`."""
    if res <= 0:
        return 0.0
    if res > 100:
        return 0.0
    if _total <= 0:
        return 1.0 / 100.0
    p = _hist[res] / _total
    # small floor to keep ordering stable
    return p + 1e-9


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties to first bin."""
    global _total
    # Update the empirical distribution with the current item (past items only matter,
    # but incorporating it is fine since it is not future information).
    _hist *= _DECAY
    _total *= _DECAY
    _hist[item] += 1.0
    _total += 1.0

    bins = np.asarray(bins)
    residuals = bins - item

    # Primary: best fit (smallest non-negative residual => largest -residual).
    # Secondary: residual closure probability, scaled to act only as a tie-break.
    primary = -residuals.astype(np.float64)

    if _total > 1.0:
        probs = np.array([_closure_prob(int(r)) for r in residuals], dtype=np.float64)
    else:
        probs = np.zeros_like(primary)

    # Scale secondary to be strictly smaller than the smallest primary gap (which is 1).
    secondary = probs / (probs.max() + 1.0) * 0.5

    return primary + secondary
# EVOLVE-BLOCK-END
