# EVOLVE-BLOCK-START
"""Windowed-completion best fit.

Strongly prefer exact perfect fits. Otherwise rank bins by how likely the
resulting residual is to be consumed by a few future items, estimated online
from a histogram of previously-seen item sizes (with a Weibull-shaped prior).
The key difference from the previous version is that completion probability is
evaluated over a small window around the residual (so near-misses count and the
signal is far less sparse/noisy), while a mild best-fit tie-break keeps packing
tight and a soft stranding penalty avoids permanently unusable fragments.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical histogram over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior
_seen = 0.0

_min_item = 100.0  # smallest item size observed so far in this stream

_DECAY = 0.999  # mild recency weighting to adapt within a stream

# Window (in capacity units) over which completion counts are accumulated.
_WIN = 2


def _windowed(prob, r_idx):
    """Sum completion probability over residuals within +/-_WIN of each bin's residual."""
    acc = np.zeros_like(prob)
    for d in range(-_WIN, _WIN + 1):
        acc += prob[np.clip(r_idx + d, 0, 100)]
    return acc / (2.0 * _WIN + 1.0)


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties)."""
    global _hist, _seen, _min_item

    residual = bins - item
    perfect = residual == 0

    h = _hist / _hist.sum()
    p = h

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual (windowed).
    exact = _windowed(p, r_idx)

    # Self-convolution: sums of two items.
    conv2 = np.convolve(_hist[1:], _hist[1:])
    total2 = _hist.sum() * _hist.sum()
    pair = np.zeros(101, dtype=np.float64)
    k = min(101, conv2.size)
    pair[2:2 + k] = conv2[:101 - 2] / total2
    pair = _windowed(pair, r_idx)

    # Self-convolution of conv2: sums of three items.
    conv3 = np.convolve(conv2, _hist[1:])
    total3 = _hist.sum() * _hist.sum() * _hist.sum()
    triple = np.zeros(101, dtype=np.float64)
    k = min(101, conv3.size)
    triple[3:3 + k] = conv3[:101 - 3] / total3
    triple = _windowed(triple, r_idx)

    mean_size = float(np.dot(np.arange(101), h))

    # Combined usefulness: exact single > exact pair > exact triple.
    usefulness = (
        5000.0 * exact
        + 1200.0 * pair
        + 400.0 * triple
    )

    # Bonus for residuals close to the typical item size.
    usefulness += 50.0 * np.exp(-np.abs(residual - mean_size) / 10.0)

    # Mild best-fit tie-break.
    score = usefulness - residual.astype(np.float64) * 0.01

    # Soft stranding penalty: residuals below the smallest observed item can
    # never be filled again.
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (20.0 + 8.0 * deficit)

    # Update histogram for future items, with mild decay.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score + perfect * 1e9
# EVOLVE-BLOCK-END

