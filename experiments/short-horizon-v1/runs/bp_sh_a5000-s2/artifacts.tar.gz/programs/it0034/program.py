# EVOLVE-BLOCK-START
"""Best fit with a guarded worst-fit escape for fragment-prone placements.

Items arrive online; go in the fitting bin with the highest score (ties -> lowest index).
Primary rule: best fit (smallest post-placement residual). But best fit tends to leave many
bins with tiny unusable fragments (residual 1..small). When placing the item into the best-fit
bin would create such a fragment, instead prefer the bin that leaves the *largest* residual
(i.e. worst fit), which wastes less usable space against the remaining mass of the item
distribution. Otherwise, standard best fit.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item          # remaining capacity after placing the item here
    # Standard best fit score: smaller residual is better.
    score = -residual.astype(np.float64)

    # Identify fragment-prone placements: residual is positive but small.
    # A fragment of size f is "unusable" if no typical future item can fit exactly enough;
    # empirically fragments below ~item size are hard to reclaim. Use a small threshold.
    frag = (residual > 0) & (residual < item)

    # For those, flip preference to worst fit: larger residual is better.
    # Map residual -> +residual for fragment bins, keeping them comparable to -residual others.
    # Use a coarser two-tier ordering: non-fragment bins always beat fragment bins,
    # among fragment bins larger residual wins.
    score = np.where(frag, residual.astype(np.float64) - 1000.0, score)
    return score
# EVOLVE-BLOCK-END
