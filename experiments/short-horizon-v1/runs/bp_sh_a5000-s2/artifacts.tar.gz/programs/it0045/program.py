# EVOLVE-BLOCK-START
"""Best fit for large items; distribution-aware residual valuation for small items.

We keep an online histogram of observed item sizes. For a placement, the leftover
residual r is valued by the probability that the residual can still absorb a future
item (i.e., P(next item <= r)) weighted so that near-full bins are preferred. Tiny
residuals that almost no future item can use are penalized; a perfect fit is rewarded.
"""
import numpy as np

# empirical item-size counts (1..100), shared across calls within a stream
_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def _reset():
    global _counts, _total
    _counts = np.zeros(101, dtype=np.float64)
    _total = 0.0


def priority(item, bins):
    global _counts, _total

    # update the empirical distribution with the current item
    if 1 <= item <= 100:
        _counts[item] += 1.0
        _total += 1.0

    residual = (bins - item).astype(np.float64)

    if item > 22:
        # Large items: best fit.
        return -residual

    # Estimate, from observed items so far, the probability that a future item
    # fits into a residual of size r. Fall back to a smooth estimate early on.
    if _total >= 5:
        cdf = np.cumsum(_counts) / _total  # cdf[r] = P(size <= r)
        # fraction of future items that fit in residual r
        fit_prob = cdf[np.clip(residual.astype(np.int64), 0, 100)]
    else:
        # generic Weibull-ish mean ~40 prior: P(size <= r)
        fit_prob = 1.0 - np.exp(-(np.clip(residual, 0, None) / 42.0) ** 1.4)

    perfect = residual == 0

    # Value of a placement: prefer bins that are nearly full (low residual) but
    # not so full that the leftover is nearly unusable. Use a blend of the
    # best-fit signal and the fit probability of the leftover.
    score = -residual + 60.0 * fit_prob + perfect * 100000.0
    return score
# EVOLVE-BLOCK-END

