# EVOLVE-BLOCK-START
"""Best fit with a residue-quality tie-break.

Primary rule: best fit (tightest fit), i.e. smallest post-placement residual.
Tie-break: among bins whose residual is equal (or near-equal), prefer residuals that are
likely to be exactly closed by a single future item, i.e. residual 0 (already full) or a
residual close to the distribution's typical item size (~40). This nudges the packing away
from accumulating awkward tiny fragments without disturbing the strong best-fit behavior.
"""
import numpy as np


def priority(item, bins):
    """Return a priority per bin; item goes to the bin with the highest score."""
    resid = bins - item  # post-placement residual, >= 0

    # Base score: strongly prefer the tightest fit.
    score = -resid.astype(np.float64)

    # Tie-break bonus: residuals that are likely to be exactly closed later.
    # Peak at resid == 0 (completed bin) and around the typical item size (~40).
    zero_bonus = np.where(resid == 0, 1.0, 0.0)
    mid_bonus = np.exp(-((resid - 40.0) ** 2) / (2.0 * (18.0 ** 2)))
    score = score + 0.4 * zero_bonus + 0.5 * mid_bonus

    return score
# EVOLVE-BLOCK-END
