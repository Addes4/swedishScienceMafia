# EVOLVE-BLOCK-START
"""Hybrid: best fit for larger items, guarded best-fit for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    if item <= 20:
        # Small items: strongly prefer perfect fits.
        perfect = residual == 0
        # Among placements leaving a non-tiny residual, best fit (smallest residual).
        useful = residual >= 25
        # Score: base reward for smaller residual among useful, plus a bonus for
        # being useful, plus a large bonus for a perfect fit.
        # We want highest score -> best bin. So:
        #   perfect: huge
        #   useful: 1000 - residual (smaller residual better)
        #   else:   -1000 - residual (worst-fit among useless, larger residual better)
        score = np.where(
            perfect, 1e6,
            np.where(useful, 1000.0 - residual.astype(np.float64),
                     -1000.0 - residual.astype(np.float64))
        )
        return score
    # Larger items: classic best fit.
    return -residual
# EVOLVE-BLOCK-END
