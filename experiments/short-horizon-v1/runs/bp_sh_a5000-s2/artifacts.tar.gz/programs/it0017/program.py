# EVOLVE-BLOCK-START
"""Best fit with a complementary-fit tie-break for small items.

The base rule is best fit: place the item where the leftover space after
placement is smallest.  Best fit is hard to beat for this distribution, so
instead of replacing it we *refine* it: we keep an online estimate of the
typical item size seen so far, and when the arriving item is small compared
to that typical size we prefer a bin whose post-placement residual could
still comfortably hold another typical item.  For large items we stay with
pure best fit.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.total = 0.0

    def update(self, item):
        self.n += 1
        self.total += item

    def mean(self):
        if self.n == 0:
            return 40.0
        return self.total / self.n


_state = _State()


def priority(item, bins):
    """Return a score per bin; the item goes to the highest (first on ties)."""
    bins = np.asarray(bins, dtype=np.float64)

    # Base score: best fit -> smallest residual after placement wins.
    residual = bins - item
    base = -residual

    mean = _state.mean()
    _state.update(item)

    # "Small" relative to the running mean: give a gentle bonus to bins
    # whose post-placement residual is large enough to accept a typical
    # upcoming item, i.e. avoid stranding a bin just under a typical size.
    if item < 0.75 * mean:
        # bonus positive when residual >= mean (bin still useful), small
        # negative gradient otherwise; scaled so it only breaks near-ties.
        bonus = 0.02 * (residual - mean)
    else:
        bonus = 0.0

    return base + bonus
# EVOLVE-BLOCK-END
