# EVOLVE-BLOCK-START
"""Best fit with a small preference for already-used bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: minimize leftover capacity after placing the item.
    score = -(bins - item).astype(np.float64)
    # Tiny bonus for non-empty bins so tight fits into used bins win over opening new ones.
    score += np.where(bins < 100, 0.25, 0.0)
    return score
# EVOLVE-BLOCK-END
