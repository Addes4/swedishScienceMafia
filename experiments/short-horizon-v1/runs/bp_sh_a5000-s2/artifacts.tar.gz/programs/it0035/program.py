# EVOLVE-BLOCK-START
"""Hybrid: best fit normally, worst-fit for small items to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item <= 12:
        # Small items: place into the fullest bin that still fits (minimize residual),
        # i.e. best fit again but with a strong preference to consolidate fragments
        # by preferring bins with small residual after placement but not too small.
        residual = bins - item
        return -np.abs(residual - 15)
    return -(bins - item)
# EVOLVE-BLOCK-END

