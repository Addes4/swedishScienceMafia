# EVOLVE-BLOCK-START
"""Future-fillability best fit.

Prefer exact perfect fits. Otherwise score a placement by the probability
that the resulting residual can be exactly consumed by one or two future
items, using a smoothed online estimate of the item-size distribution.
Ties broken mildly toward smaller residuals.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior
_seen = 0.0

_min_item = 100.0  # smallest item size observed so far in this stream

_DECAY = 0.999  # mild recency weighting to adapt within a stream

# Precomputed smoothing kernel (over residual distance).
_kdist = np.arange(-2, 3, dtype=np.float64)
_ksmooth = np.exp(-0.5 * (_kdist / 1.0) ** 2)
_ksmooth /= _ksmooth.sum()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen, _min_item

    residual = bins - item

    # Strongly prefer an exact perfect fit.
    perfect = residual == 0

    # Current estimate of the item-size distribution over 1..100 (normalized).
    h = _hist / _hist.sum()

    # Smoothed single-item density over 0..100.
    dens = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_ksmooth):
        shift = k - 2
        src = np.clip(np.arange(101) + shift, 0, 100)
        dens += w * h[src]

    # Pair distribution: probability a pair of future items sums to k (k in 2..100).
    # Use the normalized distribution so probabilities are on a proper scale.
    hh = h[1:]  # sizes 1..100
    conv2 = np.convolve(hh, hh)  # conv2[j] = P(sum = j+2), j from 0
    pair = np.zeros(101, dtype=np.float64)
    take = min(99, conv2.size)
    pair[2:2 + take] = conv2[:take]

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    exact = dens[r_idx]
    pairp = pair[r_idx]

    # Combined future-fillability: a residual likely to be closed by one item
    # (or a pair) is good; this keeps bins from stranding awkward leftovers.
    usefulness = 5000.0 * exact + 1200.0 * pairp

    # Small bonus: residuals close to a common item size pair nicely.
    mean_size = float(np.dot(np.arange(101), h))
    usefulness += 30.0 * np.exp(-np.abs(residual - mean_size) / 12.0)

    # Mild best-fit tie-break: prefer smaller residuals.
    score = usefulness - residual.astype(np.float64) * 0.02

    # Penalize residuals that can never be filled again (below smallest seen).
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (20.0 + 8.0 * deficit)

    # Update histogram for future items, with mild decay for recency.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
