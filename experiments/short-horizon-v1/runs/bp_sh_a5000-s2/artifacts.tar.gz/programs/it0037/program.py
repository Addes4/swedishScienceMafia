# EVOLVE-BLOCK-START
"""Best fit with a penalty for leaving an unusably-small residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item
    # Base: best fit -> smaller residual is better.
    score = -residual.astype(np.float64)
    # Penalize leaving a tiny, mostly-unusable residual. A residual in 1..12
    # is unlikely to be exactly filled and tends to waste capacity, whereas a
    # somewhat larger residual (e.g. 15..40) can still hold a typical small item.
    tiny = (residual >= 1) & (residual <= 12)
    score[tiny] -= 15.0
    return score
# EVOLVE-BLOCK-END
