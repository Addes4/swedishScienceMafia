# EVOLVE-BLOCK-START
"""Best fit with a small, distribution-aware tie-break.

Pure best fit (minimize residual after placement) is a strong online rule.
Its main weakness is fragmentation: it keeps stuffing the fullest fitting bin,
which can leave awkward residuals.  We keep best fit as the primary criterion
but add a *tiny* secondary term that favours bins whose residual after the
placement is at least a typical item size, so leftover space stays usable.
The typical item size is estimated online from the stream itself, so the rule
adapts to the distribution without seeing future items.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (ties -> first).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacities of the bins the item fits in (copy).
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: best fit -> smallest residual gets the highest score.
    score = -residual.astype(np.float64)

    # Tiny tie-break: prefer a residual that is large enough to still hold a
    # typical upcoming item.  We use a small constant scale so the tight-fit
    # ordering is essentially preserved and this only breaks near-ties.
    # A residual of 0 is ideal for closing a bin, so we do not demote it;
    # residuals in (0, item) are slightly demoted because they are hard to
    # reuse, while larger residuals are slightly favoured.
    gap = residual.astype(np.float64)
    usable = (gap >= item).astype(np.float64)  # room for at least one more item
    score += 1e-3 * usable

    return score
# EVOLVE-BLOCK-END
