# EVOLVE-BLOCK-START
"""Hybrid: best fit normally, but dump small items into the fullest fitting bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item <= 15:
        # Pack small items into the fullest bin that still fits them,
        # consolidating tiny fragments instead of hunting tight fits.
        return -bins
    return -(bins - item)
# EVOLVE-BLOCK-END
