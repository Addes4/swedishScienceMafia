# EVOLVE-BLOCK-START
"""Best fit with a light "leftover fit" bonus driven by the empirical size histogram."""
import numpy as np


class _State:
    def __init__(self):
        # counts of past item sizes 1..100
        self.hist = np.zeros(101, dtype=np.float64)
        self.n = 0.0

    def update(self, item):
        if 1 <= item <= 100:
            self.hist[item] += 1.0
        self.n += 1.0


_state = _State()


def priority(item, bins):
    """Score bins: strict best-fit, with a small bonus when the leftover matches a likely size."""
    it = int(item)
    _state.update(it)

    post = bins - it  # residual after placement (all >= 0 by contract)

    hist = _state.hist
    n = _state.n
    if n > 0:
        # smoothed probability that a future item exactly equals a given residual r
        # (residuals above the max possible item size 100 can only be a partial fill,
        # so they get only the "prob at least one item fits" flavor below.)
        p = (hist + 0.1) / (n + 100.0 * 0.1)
    else:
        p = np.full(101, 1.0 / 101.0)

    post_clip = np.clip(post, 0, 100).astype(np.int64)
    exact = p[post_clip]  # prob a future item exactly fills the leftover

    # Strict best-fit dominates; the bonus only breaks near-ties in post-residual.
    # Scale bonus small relative to 1 unit of residual.
    w = 0.35
    return -(post.astype(np.float64)) + w * exact
# EVOLVE-BLOCK-END

