# EVOLVE-BLOCK-START
"""Empirical-residual best fit with pair-completion awareness.

Strongly prefer exact perfect fits. Otherwise, among bins the item fits,
score a placement by how likely its resulting residual is to be fully
consumed by future items, estimated online from a histogram of
previously-seen item sizes:
  - probability a single future item exactly equals the residual,
  - probability a pair of future items sums exactly to the residual
    (via a self-convolution of the histogram).
Gaps that can be exactly completed are kept usable instead of being
fragmented, while still packing tightly via a mild best-fit tie-break.
"""
import numpy as np

# Empirical distribution over item sizes 1..100, updated online.
_hist = np.ones(101, dtype=np.float64)  # Laplace smoothing
_seen = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen

    residual = bins - item

    # Strongly prefer an exact perfect fit.
    perfect = residual == 0

    # Current estimate of the item-size distribution.
    h = _hist / _hist.sum()
    p = _hist / _seen if _seen > 0 else h

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual.
    exact = p[r_idx]

    # Probability a pair of future items sums exactly to this residual.
    # Self-convolution of the 1..100 histogram.
    conv = np.convolve(_hist[1:], _hist[1:])  # conv[k] for sum k+2 (k = 0..198)
    total = _hist.sum() * _hist.sum()
    pair = np.zeros(101, dtype=np.float64)
    for s in range(0, 101):
        if s - 2 >= 0 and s - 2 < conv.size:
            pair[s] = conv[s - 2] / total

    # Small local-neighborhood bonus for near-matches (+/- 1).
    nearby = np.zeros_like(exact)
    for d in (-1, 0, 1):
        nearby += p[np.clip(r_idx + d, 0, 100)]
    nearby /= 3.0

    # Combined usefulness: exact single > exact pair > near-match.
    usefulness = 5000.0 * exact + 1200.0 * pair[r_idx] + 200.0 * nearby

    # Mild best-fit tie-break.
    score = usefulness - residual.astype(np.float64) * 0.01

    # Never leave a useless tiny fragment unless it's a perfect fit.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny * 10.0

    # Update histogram for future items.
    _hist[item] += 1.0
    _seen += 1.0

    return score + perfect * 1e9
# EVOLVE-BLOCK-END

