# EVOLVE-BLOCK-START
"""Best-fit with light completion awareness.

Core rule: Best Fit -- put the item into the bin with the smallest
remaining capacity that still fits (minimizes wasted space and avoids
opening new bins). Exact fits are the extreme case of this and are
preferred automatically.

On top of best-fit we add a modest bonus for residuals that can be
exactly completed by a single future item or a pair, estimated online
from a histogram of seen sizes (with a Weibull-shaped prior). A soft
penalty discourages leaving residuals smaller than the smallest item
seen so far, which tend to become permanent waste.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior
_seen = 0.0

_min_item = 100.0  # smallest item size observed so far in this stream

_DECAY = 0.999  # mild recency weighting to adapt within a stream


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen, _min_item

    residual = bins - item
    res_f = residual.astype(np.float64)

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Distribution estimate.
    h = _hist / _hist.sum()

    # Probability a single future item exactly equals this residual.
    exact = h[r_idx]

    # Self-convolution: sums of two items.
    conv2 = np.convolve(_hist[1:], _hist[1:])
    total2 = _hist.sum() * _hist.sum()
    pair = np.zeros(101, dtype=np.float64)
    k = min(101, conv2.size)
    pair[2:2 + k] = conv2[:101 - 2] / total2

    # Core: best fit. Smaller residual strongly preferred.
    score = -res_f

    # Modest completion bonuses keep fragmentation down.
    score += 120.0 * exact
    score += 40.0 * pair[r_idx]

    # Soft penalty for residuals below the smallest observed item: permanently
    # stranded fragments.
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - res_f, 0.0, None)
    score -= unusable * (5.0 + 2.0 * deficit)

    # Update histogram for future items, with mild decay for recency.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score
# EVOLVE-BLOCK-END
