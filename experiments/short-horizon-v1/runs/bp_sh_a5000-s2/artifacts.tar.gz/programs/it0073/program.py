# EVOLVE-BLOCK-START
"""Best-fit with single-item completion awareness.

Primary signal: tightest fit (smallest residual) via a strong best-fit term.
Secondary: prefer residuals that are a likely future item size (so the gap
can be exactly completed by one incoming item), estimated online from a
histogram of seen sizes with a Weibull-shaped prior for early stability.
Exact perfect fits are always taken first.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0

_hist = 1.0 + _prior_scale * _prior

_DECAY = 0.999


def priority(item, bins):
    global _hist

    residual = bins - item
    perfect = residual == 0

    total = _hist.sum()
    p = _hist / total

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual.
    exact = p[r_idx]

    # Strong best-fit term: prefer the smallest residual (tightest packing).
    score = -residual.astype(np.float64)

    # Reward residuals that can be exactly completed by one future item.
    score += 300.0 * exact

    # Avoid leaving useless tiny fragments unless they are perfect fits.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny * 50.0

    # Update histogram for future items, with mild decay.
    _hist *= _DECAY
    _hist[item] += 1.0

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
