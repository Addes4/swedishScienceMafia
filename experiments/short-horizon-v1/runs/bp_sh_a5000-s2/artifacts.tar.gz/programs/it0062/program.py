# EVOLVE-BLOCK-START
"""Empirical-residual best fit with multi-item completion awareness.

Strongly prefer exact perfect fits. Otherwise, among bins the item fits,
score a placement by how likely its resulting residual is to be fully
consumed by future items, estimated online from a histogram of
previously-seen item sizes:
  - probability a single future item exactly equals the residual,
  - probability a pair of future items sums exactly to the residual
    (via a self-convolution of the histogram),
  - probability a triple of future items sums exactly to the residual,
combined into a single normalized completability estimate.
Gaps that can be exactly completed are kept usable instead of being
fragmented, while still packing tightly via a mild best-fit tie-break.
"""
import numpy as np

# Empirical distribution over item sizes 1..100, updated online.
_hist = np.ones(101, dtype=np.float64)  # Laplace smoothing
_seen = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen

    residual = bins - item

    # Strongly prefer an exact perfect fit.
    perfect = residual == 0

    # Current estimate of the item-size distribution.
    hist = _hist[1:]                      # sizes 1..100
    tot = hist.sum()
    h = hist / tot

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual.
    exact = h[r_idx - 1]

    # Self-convolution of the 1..100 histogram: sums of two items.
    conv2 = np.convolve(hist, hist)      # conv2[k] for sum k+2, k in 0..198
    total2 = tot * tot
    pair = np.zeros(101, dtype=np.float64)
    lo2 = max(0, 2 - 2)
    for s in range(1, 101):
        idx = s - 2
        if 0 <= idx < conv2.size:
            pair[s] = conv2[idx] / total2

    # Self-convolution of conv2: sums of three items (clipped to 0..100 range).
    conv3 = np.convolve(conv2, hist)     # conv3[k] for sum k+3
    total3 = tot * tot * tot
    triple = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        idx = s - 3
        if 0 <= idx < conv3.size:
            triple[s] = conv3[idx] / total3

    # Normalize into a single "completability" estimate: probability the
    # residual can be exactly filled by 1, 2 or 3 future items.
    completability = exact + pair[r_idx] + triple[r_idx]

    # Small local-neighborhood bonus for near-matches (+/- 1).
    nearby = np.zeros_like(exact)
    for d in (-1, 0, 1):
        nearby += h[np.clip(r_idx - 1 + d, 0, 99)]

    nearby /= 3.0

    # Mean item size, for a mild "leave a typical-sized gap" bonus.
    mean_size = float(np.dot(np.arange(1, 101), h))

    # Combined usefulness: normalized completability dominates, near-match
    # and typical-size gap give mild smoothing.
    usefulness = (
        6000.0 * completability
        + 200.0 * nearby
    )

    # Mild bonus for residuals close to the typical item size.
    usefulness += 50.0 * np.exp(-np.abs(residual - mean_size) / 10.0)

    # Mild best-fit tie-break.
    score = usefulness - residual.astype(np.float64) * 0.01

    # Never leave a useless tiny fragment unless it's a perfect fit.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny * 10.0

    # Update histogram for future items.
    _hist[item] += 1.0
    _seen += 1.0

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
