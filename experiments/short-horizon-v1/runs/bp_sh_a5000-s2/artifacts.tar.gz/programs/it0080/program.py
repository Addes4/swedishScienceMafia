# EVOLVE-BLOCK-START
"""Empirical-residual best fit with online-learned completion rate.

Signals used to rank bins:
  - exact perfect fit (dominant),
  - a *learned* per-residual fill rate: fraction of times a bin showing
    residual r was later exactly consumed by an arriving item. This
    directly corrects whatever the item distribution actually is, rather
    than relying on a parametric prior.
  - empirical probability of single/pair/triple complement,
  - unusability penalty below the smallest observed item.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0

_hist = 1.0 + _prior_scale * _prior
_seen = 0.0
_min_item = 100.0
_DECAY = 0.999

# Online learned fill-rate: how often a bin with residual r was exactly
# consumed by the *next* item we placed anywhere.
_fill_ok = np.zeros(101, dtype=np.float64)   # successes
_fill_tot = np.zeros(101, dtype=np.float64)  # exposures
_fill_prior = 0.02
_last_item = None


def priority(item, bins):
    global _hist, _seen, _min_item, _last_item

    residual = bins - item
    perfect = residual == 0

    h = _hist / _hist.sum()
    p = h

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Empirical single-item complement probability.
    exact = p[r_idx]

    # Self-convolution for pairs.
    conv2 = np.convolve(_hist[1:], _hist[1:])
    total2 = _hist.sum() * _hist.sum()
    pair = np.zeros(101, dtype=np.float64)
    k = min(101, conv2.size)
    pair[2:2 + k] = conv2[:101 - 2] / total2

    # Self-convolution for triples.
    conv3 = np.convolve(conv2, _hist[1:])
    total3 = _hist.sum() * _hist.sum() * _hist.sum()
    triple = np.zeros(101, dtype=np.float64)
    k = min(101, conv3.size)
    triple[3:3 + k] = conv3[:101 - 3] / total3

    # Learned empirical fill rate per residual, smoothed by the prior.
    fill_rate = (_fill_ok + _fill_prior * 5.0) / (_fill_tot + 5.0)

    mean_size = float(np.dot(np.arange(101), h))

    usefulness = (
        5000.0 * exact
        + 1500.0 * fill_rate[r_idx]
        + 1200.0 * pair[r_idx]
        + 400.0 * triple[r_idx]
    )

    usefulness += 50.0 * np.exp(-np.abs(residual - mean_size) / 10.0)

    score = usefulness - residual.astype(np.float64) * 0.01

    # Penalize permanently stranded fragments below smallest observed item.
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (20.0 + 8.0 * deficit)

    # --- Update state ---
    # Reward the previously shown residuals that equal this arriving item.
    if _last_item is not None:
        _fill_ok[_last_item] += 1.0
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)

    # Record exposure for the current residuals (bins we could fill).
    for r in np.unique(r_idx[residual > 0]):
        _fill_tot[r] += 1.0

    _last_item = item

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
