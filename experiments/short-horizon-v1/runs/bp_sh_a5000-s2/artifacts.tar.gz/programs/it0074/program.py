# EVOLVE-BLOCK-START
"""Best-fit with empirical single-item completability.

Core idea: prefer an exact perfect fit; otherwise among feasible bins,
prefer the placement whose resulting residual is most likely to be
exactly consumed by a future item (estimated online from a histogram of
previously-seen item sizes, with a Weibull-shaped prior for stability),
and break remaining ties by best fit (smallest residual). This keeps gaps
reusable rather than fragmenting them, while still packing tightly.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior
_seen = 0.0

_DECAY = 0.999  # mild recency weighting to adapt within a stream


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen

    residual = bins - item

    # Strongly prefer an exact perfect fit.
    perfect = residual == 0

    # Current estimate of the item-size distribution (normalized).
    h = _hist / _hist.sum()

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual.
    exact = h[r_idx]

    # Local neighborhood of the residual: a gap is also quite useful if a
    # future item leaves a small, easily-filled leftover.
    nearby = np.zeros_like(exact)
    for d in (-1, 0, 1):
        nearby += h[np.clip(r_idx + d, 0, 100)]
    nearby /= 3.0

    mean_size = float(np.dot(np.arange(101), h))

    # Combined usefulness: exact single-item completion dominates, with a
    # small neighborhood bonus and a bias toward residuals near the typical
    # item size (those tend to get consumed next).
    usefulness = (
        1000.0 * exact
        + 100.0 * nearby
        + 50.0 * np.exp(-np.abs(residual - mean_size) / 10.0)
    )

    # Strong best-fit tie-break: among similarly useful gaps, take the
    # tightest one to avoid scattering waste.
    score = usefulness - residual.astype(np.float64) * 0.05

    # Never leave a useless tiny fragment unless it's a perfect fit.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny * 10.0

    # Update histogram for future items, with mild decay for recency.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
