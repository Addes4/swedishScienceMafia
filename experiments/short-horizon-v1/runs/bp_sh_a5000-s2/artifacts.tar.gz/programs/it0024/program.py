# EVOLVE-BLOCK-START
"""Best-fit with a small penalty for leaving a tiny unusable residual.

Pure best fit greedily closes gaps, often creating 1-3 unit residuals that can never
be filled again (item sizes are >=1 but the distribution makes tiny items rare), wasting
bins. We keep best-fit as the primary driver but add a lightness penalty when the
post-placement residual falls in a small "orphan gap" zone, so slightly looser bins are
preferred and the small gap remains available to be filled by a small future item.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item

    # Primary objective: smaller residual is better (tightest fit).
    base = -residual.astype(np.float64)

    # Penalize tiny orphan residuals (1..3). Such a sliver can almost never be filled
    # because items of size 1..3 are rare in a Weibull(mean~40) stream, so the bin is
    # effectively lost. Shifting the choice to a slightly looser bin keeps flexibility.
    sliver = np.clip(3.0 - residual, 0.0, 3.0)  # positive only when residual in [0,3)
    # Avoid the exact-zero case too: closing a bin is fine (residual 0), so weight the
    # strictly-positive tiny residuals more than 0.
    tiny = np.where(residual == 0, 0.0, sliver)

    return base - 0.5 * tiny
# EVOLVE-BLOCK-END
