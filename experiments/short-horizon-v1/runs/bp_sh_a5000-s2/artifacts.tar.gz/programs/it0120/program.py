# EVOLVE-BLOCK-START
"""Empirical-residual best fit with completion-aware future-fillability."""
import numpy as np

_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0

_hist = 1.0 + _prior_scale * _prior
_seen = 0.0
_min_item = 100.0

_DECAY = 0.999

_kdist = np.arange(-2, 3, dtype=np.float64)
_ksmooth = np.exp(-0.5 * (_kdist / 1.0) ** 2)
_ksmooth /= _ksmooth.sum()


def priority(item, bins):
    global _hist, _seen, _min_item

    residual = bins - item
    perfect = residual == 0

    h = _hist / _hist.sum()
    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    dens = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_ksmooth):
        shift = k - 2
        src = np.clip(np.arange(101) + shift, 0, 100)
        dens += w * h[src]

    exact = dens[r_idx]

    conv2 = np.convolve(_hist[1:], _hist[1:])
    total2 = _hist.sum() * _hist.sum()
    pair = np.zeros(101, dtype=np.float64)
    k = min(101, conv2.size)
    pair[2:2 + k] = conv2[:101 - 2] / total2

    mean_size = float(np.dot(np.arange(101), h))

    usefulness = (
        5000.0 * exact
        + 1000.0 * pair[r_idx]
    )

    usefulness += 40.0 * np.exp(-np.abs(residual - mean_size) / 10.0)

    cur_dens = float(dens[item]) if 0 <= item <= 100 else 0.0
    usefulness += 300.0 * cur_dens * np.exp(-np.abs(residual - item) / 6.0)

    # Stranding penalty: residuals that cannot be exactly completed by a
    # single or a pair of future items are wasteful; penalize gradually.
    completable = np.clip(exact * 50.0 + pair[r_idx] * 40.0, 0.0, 1.0)
    stranding = (1.0 - completable) * (residual > 0)
    usefulness -= 30.0 * stranding

    score = usefulness - residual.astype(np.float64) * 0.02

    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (20.0 + 8.0 * deficit)

    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
