# EVOLVE-BLOCK-START
"""Best-fit augmented: prefer residuals that match observed future item sizes."""
import numpy as np

_seen = []


def priority(item, bins):
    """Score bins; item goes to highest score (first on ties)."""
    # Record history (bounded to keep memory/time reasonable).
    _seen.append(int(item))
    if len(_seen) > 4096:
        del _seen[:2048]

    # Post-placement residual for each candidate bin.
    # bins holds remaining capacities of bins this item fits in.
    residual = bins - item  # >= 0 guaranteed for shown bins

    # Empirical distribution: how often did a past item equal exactly r?
    # We precompute counts lazily (cheap since len <= 4096).
    arr = np.asarray(_seen, dtype=np.int64)
    # count occurrences via bincount over sizes 1..100
    cnt = np.bincount(arr, minlength=101)  # cnt[s] = #items of size s

    n = cnt.sum()
    # probability that a residual r can be exactly closed by a single future item
    # = P(next item == r), estimated empirically.
    # Map each residual to its count.
    r = residual.astype(np.int64)
    r_clip = np.clip(r, 0, 100)
    match_prob = cnt[r_clip] / n if n > 0 else r * 0.0

    # Small residuals (like 0) are perfect closures for item==r.
    exact_bonus = np.where((r >= 1) & (r <= 100), match_prob, 0.0)

    # Primary criterion: best-fit (tightest residual -> most negative residual).
    # Normalize tightly so the secondary bonus acts only as a tie-break.
    base = -residual.astype(np.float64)
    return base + 0.5 * exact_bonus
# EVOLVE-BLOCK-END
