# EVOLVE-BLOCK-START
"""Energy (sum-of-squares) ranking with a strong perfect-fit bonus.

For every arriving item we rank bins by the residual they would leave.
A perfect fit is always best.  Otherwise we prefer the placement that minimizes
the sum of squares of the remaining capacities (classic "energy" objective used
in harmonic / sum-of-squares bin packing), which naturally prefers leaving very
full bins alone or producing large usable gaps instead of slivers.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    perfect = residual == 0
    # Energy: placing into a bin with residual r removes (bins^2 - r^2) from the
    # total sum of squares; maximizing bins^2 - r^2 is equivalent to minimizing
    # r among non-perfect placements.  To bias toward *usable* residuals rather
    # than slivers, we add a small bonus for residuals that are still large
    # enough to accept the mean-sized future item.
    score = bins.astype(np.float64) ** 2 - residual.astype(np.float64) ** 2
    usable = residual >= 25
    return -residual.astype(np.float64) - usable * 0.001 * residual.astype(np.float64) \
           + perfect * 100000.0 + bins.astype(np.float64) * 0.0
# EVOLVE-BLOCK-END
