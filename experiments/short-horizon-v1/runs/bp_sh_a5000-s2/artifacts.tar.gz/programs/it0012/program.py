# EVOLVE-BLOCK-START
"""Best-fit with a residual-usability bias derived from the observed item mean."""
import numpy as np


class _State:
    n = 0
    s = 0.0


_state = _State()


def priority(item, bins):
    """Score bins: strongly prefer tight fit, but slightly penalize residuals that
    are too small to hold a typical (mean-sized) future item, which helps reduce
    the awkward leftover fragments pure best-fit creates."""
    _state.n += 1
    _state.s += item
    mean = _state.s / _state.n

    residual = bins - item  # remaining capacity after placing the item here

    # Primary: best fit (smaller residual preferred) -> higher score.
    score = -residual.astype(np.float64)

    # Fraction of a typical item that this bin could still hold afterwards.
    frac = residual / mean
    # Bonus that grows as the residual becomes usable for a typical item,
    # saturating once a full typical item fits. Small magnitude: a tie-breaker
    # that nudges decisions within best-fit's near-tie plateau.
    bonus = 0.5 * (1.0 - np.exp(-np.maximum(frac, 0.0)))

    return score + bonus
# EVOLVE-BLOCK-END

