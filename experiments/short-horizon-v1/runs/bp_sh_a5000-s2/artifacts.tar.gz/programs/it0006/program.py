# EVOLVE-BLOCK-START
"""Best fit with a small residual-utility bonus: primary term picks the tightest fit,
secondary term slightly prefers residuals that are a good size for typical small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for bins the item fits in (all shown bins)
    # Primary: prefer smallest residual (best fit).
    # Secondary: among near-equal residuals, slightly prefer residuals near 20
    # (a common size for future items), so leftover space stays packable.
    # Keep the bonus small relative to 1 unit of residual so best-fit dominates.
    bonus = -np.abs(residual - 20) * 1e-3
    return -residual.astype(np.float64) + bonus
# EVOLVE-BLOCK-END
