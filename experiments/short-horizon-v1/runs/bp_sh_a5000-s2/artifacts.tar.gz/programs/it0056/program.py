# EVOLVE-BLOCK-START
"""Length-aware best fit: perfect fits first, best fit among bins keeping a usable residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Strongly prefer an exact perfect fit.
    perfect = residual == 0
    # Base: classic best fit -> smaller residual scores higher.
    score = -residual.astype(np.float64)
    # For small items, penalize leaving a residual that is too small to be
    # useful for future items (tiny fragments), unless it is a perfect fit.
    if item <= 25:
        tiny = (residual > 0) & (residual < item)
        score -= tiny * 50.0
    # Additionally, mildly discourage leaving large empty bins for small items,
    # so small items consume the fuller bins rather than opening fresh ones.
    if item <= 25:
        score -= 0.02 * residual * (residual > 0)
    return score + perfect * 100000.0
# EVOLVE-BLOCK-END
