# EVOLVE-BLOCK-START
"""Best fit with a leftover-reusability bonus estimated from past items."""
import numpy as np


class _State:
    def __init__(self):
        # decaying histogram of past item sizes (1..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.total = 0.0
        self.decay = 0.995

    def observe(self, item):
        self.hist *= self.decay
        self.total *= self.decay
        self.hist[item] += 1.0
        self.total += 1.0

    def prob(self, size):
        if size < 1 or size > 100 or self.total <= 0:
            return 0.0
        return self.hist[size] / self.total


_state = _State()


def priority(item, bins):
    """Rank bins: prefer tight fit, rewarded when the leftover is a likely future size."""
    _state.observe(item)
    residual = bins - item  # >= 0 for all shown bins

    # Probability that a future item exactly uses up the leftover.
    probs = np.array([_state.prob(int(r)) for r in residual], dtype=np.float64)

    # Primary: minimize residual (best fit). Secondary: leave reusable leftovers.
    # Weight chosen small so best-fit ordering among clearly different residuals wins.
    return -residual.astype(np.float64) + 0.6 * probs
# EVOLVE-BLOCK-END
