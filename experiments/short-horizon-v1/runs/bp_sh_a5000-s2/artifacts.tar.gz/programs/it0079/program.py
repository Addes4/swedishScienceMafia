# EVOLVE-BLOCK-START
"""Best-fit with completability-aware unusable-fragment avoidance.

Strongly prefer exact perfect fits. Otherwise use classic best fit: put the
item in the fullest bin it fits in (smallest positive residual), which keeps
bins dense and minimizes the number of stranded small gaps. To avoid leaving
fragments that can never be filled, penalize residuals smaller than the
smallest item size seen so far, and use the empirical item-size histogram
only as a mild bonus when a residual equals a common future item size.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior
_seen = 0.0

_min_item = 100.0  # smallest item size observed so far in this stream

_DECAY = 0.999  # mild recency weighting to adapt within a stream


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen, _min_item

    residual = bins - item
    perfect = residual == 0

    # Current estimate of the item-size distribution.
    p = _hist / _hist.sum()
    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual.
    exact = p[r_idx]

    # Classic best fit: prefer the smallest positive residual (fullest bin).
    # We build the score so that among usable residuals this dominates, then
    # rewards residuals that are likely to be exactly completed.
    res_f = residual.astype(np.float64)

    # Base: strong best-fit term (smaller residual -> higher score).
    score = -res_f * 100.0

    # Reward residuals equal to a likely future item size (completable by one item).
    score += 60.0 * exact

    # Penalize residuals that can never be filled again (below smallest item seen).
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (500.0 + 50.0 * deficit)

    # Update histogram for future items, with mild decay for recency.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
