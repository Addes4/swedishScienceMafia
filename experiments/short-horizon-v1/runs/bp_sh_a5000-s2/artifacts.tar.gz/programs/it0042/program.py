# EVOLVE-BLOCK-START
"""Best-fit with a light randomized two-choice refinement.

Pure best fit is a strong online rule, but greedy ties and near-ties can lock in
fragmentation. We instead form the best-fit candidate and a second-best candidate
(distinguished by post-placement residual), and occasionally prefer the second
candidate using a deterministic pseudo-random sequence seeded by arrival order.
State (an item counter) is kept between calls within a stream.
"""
import numpy as np

_CAP = 100


def _priority_array(bins):
    # Best fit: largest item <= residual -> post-placement residual r = bins - item,
    # we want the bin with the smallest non-negative residual.
    return -(bins)


def priority(item, bins):
    # bump a persistent counter if not present
    n = getattr(priority, "_n", 0)
    priority._n = n + 1

    residual = bins - item  # >= 0 for all shown bins (they all fit)

    # primary best-fit ranking
    order = np.lexsort((np.arange(residual.shape[0]), residual))
    best = order[0]
    scores = np.zeros(residual.shape[0], dtype=np.float64)

    if residual.shape[0] == 1:
        scores[best] = 1.0
        return scores

    second = order[1]

    # Deterministic pseudo-random bit from the item counter.
    # xorshift-ish on the counter for good mixing.
    x = (n * 1103515245 + 12345) & 0x7FFFFFFF
    x ^= (x >> 13)
    x = (x * 1103515245 + 12345) & 0x7FFFFFFF
    flip = (x >> 8) & 1

    # Choose the second candidate occasionally; otherwise best fit.
    # Slightly biased toward best fit to preserve its quality.
    if flip and (residual[second] - residual[best]) <= 5:
        chosen = second
    else:
        chosen = best

    scores[chosen] = 1.0
    return scores
# EVOLVE-BLOCK-END
