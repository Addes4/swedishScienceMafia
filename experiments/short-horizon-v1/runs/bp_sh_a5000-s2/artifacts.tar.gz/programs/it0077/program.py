# EVOLVE-BLOCK-START
"""Best fit with a smoothed residual-completability table.

Strongly prefer exact perfect fits. Otherwise, score a placement by how
likely its resulting residual is later reusable, using a smoothed estimate
of the chance that the residual equals a future item or is exactly summed
by a small group of future items. A dominant best-fit term keeps packs tight,
and gaps below the smallest observed item are penalized as stranded.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior
_seen = 0.0

_min_item = 100.0  # smallest item size observed so far in this stream

_DECAY = 0.999  # mild recency weighting to adapt within a stream


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen, _min_item

    residual = bins - item

    # Strongly prefer an exact perfect fit.
    perfect = residual == 0

    # Current estimate of the item-size distribution.
    p = _hist / _hist.sum()

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual.
    exact = p[r_idx]

    # Smoothed completion table: exact (0 items leftover) probability for a
    # residual r, combining single match, two-item sum, three-item sum.
    conv2 = np.convolve(_hist[1:], _hist[1:])
    total2 = _hist.sum() * _hist.sum()
    pair = np.zeros(101, dtype=np.float64)
    k = min(101, conv2.size)
    pair[2:2 + k] = conv2[:101 - 2] / total2

    conv3 = np.convolve(conv2, _hist[1:])
    total3 = _hist.sum() * _hist.sum() * _hist.sum()
    triple = np.zeros(101, dtype=np.float64)
    k = min(101, conv3.size)
    triple[3:3 + k] = conv3[:101 - 3] / total3

    # Combined completability of a residual.
    completable = exact + 0.5 * pair[r_idx] + 0.2 * triple[r_idx]

    # Main objective: tightest fit (best fit), plus a modest completability
    # bonus so that reusable gaps are favored over dead ones.
    score = -residual.astype(np.float64) + 40.0 * completable

    # Penalize residuals that can never be filled again: below the smallest
    # item observed so far these fragments are permanently stranded, and the
    # penalty grows the further below that minimum we fall.
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (30.0 + 8.0 * deficit)

    # Update histogram for future items, with mild decay for recency.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score + perfect * 1e9
# EVOLVE-BLOCK-END

