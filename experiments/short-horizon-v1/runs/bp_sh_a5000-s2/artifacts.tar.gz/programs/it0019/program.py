# EVOLVE-BLOCK-START
"""Best fit with a sliver-avoidance correction.

Pure best fit tends to carve bins down to tiny residuals that can never accept
another item, which is fine, but it also sometimes chooses among candidate bins
in a way that creates many near-useless slivers while leaving better medium
bins untouched.  We keep best fit as the primary criterion but add a bounded
penalty for creating a post-placement residual that is very small (below a
sliver threshold), so that, when there is a near-tie, we favour placements that
leave a residual large enough to matter.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest."""
    post = bins - item                     # remaining capacity after placing
    # Primary: prefer the tightest fit (smallest post-placement residual).
    score = -post.astype(np.float64)
    # Secondary: penalise creating a tiny sliver that can likely never be reused.
    # Small items can still use slivers, so scale the penalty by the item size:
    # we only worry about slivers when the arriving item is itself large enough
    # that a sliver would be hard to fill with whatever is left.
    sliver = 8.0
    penalty = np.where(post < sliver, (sliver - post) * 0.01, 0.0)
    return score - penalty
# EVOLVE-BLOCK-END
