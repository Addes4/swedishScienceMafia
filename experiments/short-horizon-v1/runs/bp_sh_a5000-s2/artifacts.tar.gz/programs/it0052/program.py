# EVOLVE-BLOCK-START
"""Best-fit bin choice with a strong perfect-fit preference."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best fit: smallest residual is best -> highest priority.
    # Perfect fit (residual == 0) gets a huge bonus to guarantee it's chosen.
    perfect = residual == 0
    return -residual.astype(np.float64) + perfect * 1e6
# EVOLVE-BLOCK-END
