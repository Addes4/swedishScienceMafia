# EVOLVE-BLOCK-START
"""Harmonic-style bin packing: match item size class to a target residual class."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Choose the size class k and the target residual interval (lo, hi] for that class.
    # Classes are based on fractions 1/k of capacity 100.
    if item > 50:
        # Big items: any bin that fits; prefer the fullest (least residual) -> best fit.
        return -(bins - item)

    # For smaller items, prefer bins whose residual lands in a specific target window.
    # k is the smallest integer with item > 100/(k+1), i.e. item in (100/(k+1), 100/k].
    k = int(100 // item)  # approx floor(100/item); item in (100/(k+1), 100/k]
    # target residual window: (100/k, 100/(k-1)] to leave room for class-(k-1) items.
    if k <= 1:
        hi = 100.0
        lo = 50.0
    else:
        hi = 100.0 / k
        lo = 100.0 / (k + 1)

    residual = bins - item  # residual after placing the item
    # Prefer residuals within [lo, hi]; among those use best fit (smallest residual).
    # Outside the window, penalize by distance so they are only chosen when necessary.
    # Score: higher is better.
    in_window = (residual >= lo) & (residual <= hi)
    # distance to window (0 if inside)
    dist = np.maximum(0.0, np.maximum(lo - residual, residual - hi))
    # primary: prefer in-window; secondary: smaller distance; tertiary: best fit
    # Use large bonus for in-window and small weight on residual to break ties tightly.
    score = -dist * 1000.0 - residual * 0.001
    # ensure in-window strongly beats out-of-window handled by dist scaling vs residual.
    score = np.where(in_window, -residual * 0.001 + 1000000.0, score)
    return score
# EVOLVE-BLOCK-END
