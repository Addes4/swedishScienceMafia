# EVOLVE-BLOCK-START
"""Best fit with exact-completability tie-breaking.

Primary rule: best fit (smallest resulting residual), with a strong
preference for exact perfect fits. Tie-breaking/completion signal: the
(smoothed) empirical probability that the residual can be exactly filled
by one future item or by a pair of future items, computed from a
normalized online histogram of item sizes.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 40.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior
_seen = 0.0

_DECAY = 0.999  # mild recency weighting to adapt within a stream

# Precomputed smoothing kernel (over residual distance).
_kdist = np.arange(-2, 3, dtype=np.float64)
_ksmooth = np.exp(-0.5 * (_kdist / 1.0) ** 2)
_ksmooth /= _ksmooth.sum()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen

    residual = bins - item

    # Strongly prefer an exact perfect fit.
    perfect = residual == 0

    # Current estimate of the item-size distribution over 1..100.
    h = _hist / _hist.sum()

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Smoothed density at the residual (robustness to sampling gaps).
    dens = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_ksmooth):
        shift = k - 2
        src = np.clip(np.arange(101) + shift, 0, 100)
        dens += w * h[src]

    # Probability a single future item exactly equals this residual.
    exact = dens[r_idx]

    # Pair-completion probability via normalized self-convolution of h over 1..100.
    p = h[1:]  # distribution over sizes 1..100, sums to ~1
    conv2 = np.convolve(p, p)  # conv2[s-2] = P(two items sum to s)
    pair = np.zeros(101, dtype=np.float64)
    upto = min(101, conv2.size + 2)
    pair[2:upto] = conv2[:upto - 2]

    # Completion usefulness: single fit dominates, pair is a mild bonus.
    usefulness = 30.0 * exact + 6.0 * pair[r_idx]

    # Primary rule: best fit (smallest residual) plus completion usefulness.
    score = -residual.astype(np.float64) + usefulness

    # Update histogram for future items, with mild decay for recency.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
