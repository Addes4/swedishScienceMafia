# EVOLVE-BLOCK-START
"""Hybrid: best fit for larger items, consolidation rule for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    if item <= 20:
        # Small items: prefer perfect fits; otherwise choose the fullest bin that
        # still leaves a residual large enough to be reusable, to avoid both tiny
        # fragments and over-spreading.
        perfect = residual == 0
        useful = residual >= 15
        # Base: smaller residual (fuller bin) is better, so use -residual.
        return -residual.astype(np.float64) + perfect * 100000.0 - useful * 1000.0
    # Larger items: classic best fit.
    return -residual
# EVOLVE-BLOCK-END
