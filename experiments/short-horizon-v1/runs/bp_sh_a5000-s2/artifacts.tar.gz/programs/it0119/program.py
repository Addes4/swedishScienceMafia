# EVOLVE-BLOCK-START
"""Residual completability scoring with empirical item-size distribution.

Prefer exact fits strongly. Otherwise score each bin by the estimated
probability that its residual can be exactly filled by a future item
(single) or by a pair of future items (convolution), using an online
histogram of observed sizes. Keep a mild best-fit tie-break and a
stranding penalty for residuals below the smallest item seen.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior

_min_item = 100.0  # smallest item size observed so far in this stream

# Smoothing kernel over residual distance for the single-item density.
_kdist = np.arange(-2, 3, dtype=np.float64)
_ksmooth = np.exp(-0.5 * (_kdist / 1.0) ** 2)
_ksmooth /= _ksmooth.sum()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _min_item

    residual = bins - item
    perfect = residual == 0

    total = _hist.sum()
    h = _hist / total

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Smoothed single-item density at the residual.
    dens = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_ksmooth):
        shift = k - 2
        src = np.clip(np.arange(101) + shift, 0, 100)
        dens += w * h[src]

    exact = dens[r_idx]

    # Pair-completion probability via self-convolution of the histogram.
    conv2 = np.convolve(_hist[1:], _hist[1:])  # conv2[k] corresponds to sum k+2
    total2 = total * total
    pair = np.zeros(101, dtype=np.float64)
    k = min(101, conv2.size)
    pair[2:2 + k] = conv2[:101 - 2] / total2

    # Completable residuals are strongly preferred; exact single fill best.
    usefulness = 5000.0 * exact + 1500.0 * pair[r_idx]

    # Mild best-fit tie-break: prefer smaller residuals.
    score = usefulness - residual.astype(np.float64) * 0.02

    # Penalize residuals that can never be filled again (below smallest seen).
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (15.0 + 6.0 * deficit)

    # Update histogram for future items.
    _hist[item] += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score + perfect * 1e9
# EVOLVE-BLOCK-END

