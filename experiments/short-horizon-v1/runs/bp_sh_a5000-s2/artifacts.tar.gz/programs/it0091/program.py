# EVOLVE-BLOCK-START
"""Best-fit with exact-completion awareness.

Primary rule: exact perfect fit if available; otherwise classic best-fit
(smallest positive residual), which is strong on Weibull-shaped sizes.
A modest correction prefers residuals that the empirical item histogram
says are likely to be exactly hit by a single future item, helping to
keep completable gaps alive rather than dropping into permanently
stranded fragments. A stranding penalty discourages residuals below the
smallest observed item.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

_hist = 1.0 + _prior_scale * _prior
_seen = 0.0

_min_item = 100.0  # smallest item size observed so far in this stream

_DECAY = 0.999  # mild recency weighting


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen, _min_item

    residual = bins - item
    perfect = residual == 0

    p = _hist / _hist.sum()

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual.
    exact = p[r_idx]

    # Base: classic best fit -> smaller positive residual is better.
    # Scale so completion correction can act as a near-tie break.
    score = -residual.astype(np.float64)

    # Bonus for exact completability: a gap that a future item can fill
    # exactly is worth keeping usable.
    score += 8.0 * exact

    # Prefer exact perfect fits overwhelmingly.
    score += perfect * 1e9

    # Penalize residuals that are permanently stranded below the smallest
    # item observed so far.
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (10.0 + 4.0 * deficit)

    # Update histogram for future items.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score
# EVOLVE-BLOCK-END


