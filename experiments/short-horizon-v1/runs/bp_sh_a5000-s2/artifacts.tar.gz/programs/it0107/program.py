# EVOLVE-BLOCK-START
"""Best-fit with exact-fit preference and future-fillability via min-item awareness.

Strongly prefer exact perfect fits. Otherwise use a best-fit style rule: prefer
the bin whose resulting residual is small (tight) yet still fillable by future
items, penalizing residuals that fall below the smallest item size seen so far.
A smoothed online estimate of the item-size distribution provides a mild
future-fillability signal to break ties among tight fits.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior
_seen = 0.0

_min_item = 100.0  # smallest item size observed so far in this stream

_DECAY = 0.999  # mild recency weighting to adapt within a stream


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen, _min_item

    residual = bins - item

    # Strongly prefer an exact perfect fit.
    perfect = residual == 0

    # Current estimate of the item-size distribution over 1..100.
    h = _hist / _hist.sum()

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual.
    exact = h[r_idx]

    mean_size = float(np.dot(np.arange(101), h))

    # Future usefulness estimate: exact single-item match plus mild taste for
    # residuals near the typical item size.
    usefulness = 3000.0 * exact
    usefulness += 40.0 * np.exp(-np.abs(residual - mean_size) / 12.0)

    # Best-fit tie-break: prefer tighter (smaller) residuals.
    score = usefulness - residual.astype(np.float64) * 0.5

    # Penalize residuals that can never be filled again (below smallest seen).
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (20.0 + 8.0 * deficit)

    # Update histogram for future items, with mild decay for recency.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
