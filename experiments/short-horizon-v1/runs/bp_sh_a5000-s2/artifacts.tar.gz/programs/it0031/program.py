# EVOLVE-BLOCK-START
"""Best fit with a slight preference for less-full bins (fragment consolidation)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # penalize bins that are already quite full (small residual) slightly,
    # so ties in residual get broken toward less-full bins, reducing many
    # bins left with tiny unusable fragments.
    full_penalty = (100 - residual) / 100.0
    return -residual - 0.02 * full_penalty
# EVOLVE-BLOCK-END
