# EVOLVE-BLOCK-START
"""Best-fit with a small empirical "closability" tie-break."""
import numpy as np

_state = {"sizes": np.zeros(101, dtype=np.int64), "count": 0}


def _closability(r, p):
    """Probability that residual r can be matched exactly by a future item,
    estimated from the empirical distribution p (index = size)."""
    if r <= 0:
        return 0.0
    if r > 100:
        return 0.0
    return float(p[r])


def priority(item, bins):
    # record observed item sizes
    _state["sizes"][item] += 1
    _state["count"] += 1
    p = _state["sizes"] / _state["count"]

    residual = bins - item
    # primary: pure best-fit (tightest post-placement residual), scaled strongly
    # secondary: encourage residuals that are empirically closable later
    clos = np.array([_closability(int(r), p) for r in residual])
    return -residual * (1.0 + 0.05) + clos * 0.5
# EVOLVE-BLOCK-END

