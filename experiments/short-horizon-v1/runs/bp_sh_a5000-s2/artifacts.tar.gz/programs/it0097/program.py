# EVOLVE-BLOCK-START
"""Exact-fit best fit with light empirical completion awareness.

Strongly prefer exact perfect fits. Otherwise, among bins the item fits,
score a placement by a blend of:
  - probability a single future item exactly equals the residual,
  - a small near-match bonus (+/- 1),
  - a mild best-fit preference (fuller bins first),
and penalize residuals that fall below the smallest item seen so far
(permanently stranded capacity). The pairwise/triple convolution signals
are dropped because prior smoothing keeps them noisy and they added more
variance than signal.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior
_seen = 0.0

_min_item = 100.0  # smallest item size observed so far in this stream

_DECAY = 0.999  # mild recency weighting to adapt within a stream


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen, _min_item

    residual = bins - item

    # Strongly prefer an exact perfect fit.
    perfect = residual == 0

    # Current estimate of the item-size distribution.
    p = _hist / _hist.sum()

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual.
    exact = p[r_idx]

    # Small local-neighborhood bonus for near-matches (+/- 1).
    nearby = np.zeros_like(exact)
    for d in (-1, 0, 1):
        nearby += p[np.clip(r_idx + d, 0, 100)]
    nearby /= 3.0

    # Combined usefulness: exact single match dominates, near-match is a mild signal.
    usefulness = 4000.0 * exact + 150.0 * nearby

    # Prefer fuller bins (smaller residual) as a tie-break among non-perfect fits.
    score = usefulness - 2.0 * residual.astype(np.float64)

    # Penalize residuals that can never be filled again: below the smallest
    # item observed so far these fragments are permanently stranded.
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    score -= unusable * 30.0

    # Update histogram for future items, with mild decay for recency.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
