# EVOLVE-BLOCK-START
"""Best fit with a mild convexity push toward fully closing bins."""
import numpy as np


def priority(item, bins):
    """Rank bins by post-placement residual, favoring tighter fits.

    score = -(residual) - alpha * (residual == 0 ? 0 : residual**2 / 100)
    A mild convex penalty on positive residuals discourages leaving tiny
    unusable gaps while still strongly preferring the tightest fit.
    """
    residual = bins - item
    # residual >= 0 for all bins shown (item fits)
    # Mild convex penalty: larger residuals slightly more discouraged,
    # but exact fit (residual == 0) gets the best score.
    penalty = np.where(residual > 0, (residual * residual) / 200.0, 0.0)
    return -(residual.astype(np.float64)) - penalty
# EVOLVE-BLOCK-END
