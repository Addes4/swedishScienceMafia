# EVOLVE-BLOCK-START
"""Best fit with residual-quality shaping based on the item distribution."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item in each bin

    # Weibull-shaped distribution with mean ~40: most items are small-to-medium.
    # A good residual is one that can still be usefully filled by future items.
    # Small residuals (< ~20) are hard to fill well and risk becoming waste, but a
    # very tight fit (near 0) is fine. Mid residuals are fine too since small items
    # abound. The main danger is residuals in a "dead zone" that neither close the
    # bin nor leave room for a typical item.
    #
    # Score: prefer small residuals (best fit), but give a mild bonus for residuals
    # that are themselves close to 0 (perfectly full) since those close bins cleanly.
    score = -residual.astype(np.float64)
    # Extra reward for leaving the bin essentially full (residual very small).
    score += 0.05 * np.exp(-residual / 5.0)
    return score
# EVOLVE-BLOCK-END

