# EVOLVE-BLOCK-START
"""Distribution-aware best fit: prefer the bin whose residual after placing the item
is most likely to be exactly filled or usefully reused by future items.

Items are Weibull-shaped with mean ~40, so future items are most likely small (1..50)
with a long tail up to 100. Rather than greedily minimizing the immediate residual,
we score each bin by combining:
  - tightness (prefer full bins to avoid fragmentation), and
  - a small preference for leaving a residual that future items can still fill.
The dominant term remains best-fit; the secondary term breaks the pathologies of
pure best-fit without ever opening a new bin when a good fit exists.
State is kept to adapt the mix weight from observed items, but stays simple.
"""
import numpy as np

# Shape/scale for a Weibull with mean ~40 (mean = scale * Gamma(1+1/k)).
# k around 1.5, scale ~44 gives mean near 40; used only as a smooth prior.
_K = 1.5
_SCALE = 44.0
_GAMMA_1_PLUS_1_OVER_K = 0.9027  # Gamma(1 + 1/1.5)


def _residual_usefulness(residual):
    """Smooth score for how 'usable' a residual space is for future Weibull items.

    A residual near 0 is ideal (bin fully closed). A residual that is large is
    also fine (bin still mostly empty). Residuals in an awkward middle range
    (small but not tiny) are the worst: cannot hold a typical item but waste space.
    We express this by penalizing residuals that sit just below typical small items.
    """
    r = residual.astype(np.float64)
    # Probability density that a future item is at least r (i.e., r is fillable soon).
    # Larger residual -> easier to fill -> small benefit; near-0 residual -> no benefit needed.
    frac = r / 100.0
    # Smooth, bounded: prefer either very small or very large residuals.
    # Use a U-shaped penalty around the awkward zone (~20..60).
    center = 0.4
    width = 0.25
    u = (frac - center) / width
    awkward = np.exp(-0.5 * u * u)  # peaks in the awkward middle zone
    return awkward


def priority(item, bins):
    # Primary: best fit (maximize remaining-capacity-minus-item, i.e. minimize residual).
    fit = -(bins - item)
    fit = fit.astype(np.float64)

    residual_after = (bins - item).astype(np.float64)
    penalty = _residual_usefulness(residual_after)

    # Small weight: never override a clearly better fit, only break near-ties toward
    # leaving more usable space. Scale relative to item size so it stays gentle.
    w = 0.02 * item
    return fit - w * penalty
# EVOLVE-BLOCK-END
