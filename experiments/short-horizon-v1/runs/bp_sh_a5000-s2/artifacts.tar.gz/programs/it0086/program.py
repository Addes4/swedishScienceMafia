# EVOLVE-BLOCK-START
"""Empirical best-fit with expected-waste scoring.

Core idea: choose the bin that minimizes expected permanently wasted
capacity. Perfect fits are best. Otherwise we score a residual by how
likely it can still be productively consumed by future items, estimated
from the online empirical item-size histogram (with a Weibull prior).

For a residual r, the capacity is "at risk" if the future items that
would fill it do not arrive. We estimate, from the histogram of item
sizes seen so far, the probability mass of items that can still fit in
a gap of size r, and reward residuals that match common item sizes (or
common pairwise sums), while penalizing fragments smaller than the
smallest item likely to appear.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior
_seen = 0.0

_DECAY = 0.999  # mild recency weighting to adapt within a stream

# CDF-based helpers recomputed lazily each call (cheap for 101-length arrays).
_idx = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen

    residual = bins - item
    perfect = residual == 0

    h = _hist / _hist.sum()
    p = h

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual.
    exact = p[r_idx]

    # Pairwise sums self-convolution: probability two items sum to residual.
    conv2 = np.convolve(_hist[1:], _hist[1:])
    total2 = _hist.sum() * _hist.sum()
    pair = np.zeros(101, dtype=np.float64)
    k = min(101, conv2.size)
    pair[2:2 + k] = conv2[:101 - 2] / total2

    # Expected amount of capacity consumed productively in a gap of size r:
    # a value near 1 means the residual is very "reachable"; near 0 means
    # it is a stranded fragment.
    # Expected minimum item size that could still fit is approximated by
    # the mass of items <= r.
    cdf = np.cumsum(h)  # cdf[s] = P(item <= s)
    reachable_mass = cdf[r_idx]  # probability some item fits in the gap

    # Productive-capacity estimate: expected fraction of the residual that
    # future items can still fill, weighted toward exact matches.
    usefulness = (
        3000.0 * exact
        + 900.0 * pair[r_idx]
        + 120.0 * reachable_mass
    )

    # Penalize wasted capacity: a residual that is unlikely to be filled
    # exactly leaves capacity stranded; scale by the residual magnitude.
    waste = (residual.astype(np.float64)) * (1.0 - exact - pair[r_idx])
    usefulness -= 6.0 * np.clip(waste, 0.0, None)

    # Mild best-fit tie-break so tight bins are preferred.
    score = usefulness - residual.astype(np.float64) * 0.01

    # Update histogram for future items, with mild decay for recency.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
