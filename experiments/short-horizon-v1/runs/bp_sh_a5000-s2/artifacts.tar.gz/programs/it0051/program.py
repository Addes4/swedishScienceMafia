# EVOLVE-BLOCK-START
"""Best fit with an explicit perfect-fit bonus and a mild anti-fragmentation term."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Perfect fit always wins.
    perfect = residual == 0
    # Classic best fit: prefer the smallest resulting residual (tightest placement).
    # Small positive tie-breaker rewards residuals that remain useful for future items.
    return -residual.astype(np.float64) + perfect * 100000.0
# EVOLVE-BLOCK-END
