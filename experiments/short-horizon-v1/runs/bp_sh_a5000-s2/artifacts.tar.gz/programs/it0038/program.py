# EVOLVE-BLOCK-START
"""Best fit with exact-fit prioritisation and residual-strand penalty.

Best fit minimises post-placement residual. Empirically the only reliable
gain over plain best fit in online packing of medium-sized items is to
strongly prefer *exact* fits (residual 0) and otherwise minimise residual,
while mildly penalising residuals that are too small to ever hold the
smallest plausible future item. Since future items are >=1, every residual
is usable, so the penalty is kept negligible and the rule reduces to best fit
with a firm exact-fit bonus.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Primary ranking by residual (best fit); exact fits get a strong bonus
    # so that among equal-residual bins an exact one always wins.
    score = -residual.astype(np.float64)
    score += 1000.0 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
