# EVOLVE-BLOCK-START
"""Best fit variant: prefer tightest fit, but penalize leaving very small residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer small residuals (tight fit), but add a mild penalty for residuals that are
    # positive but very small, since those leave fragmented, hard-to-reuse space.
    penalty = np.where((residual > 0) & (residual < 10), 2.0, 0.0)
    return -residual - penalty
# EVOLVE-BLOCK-END
