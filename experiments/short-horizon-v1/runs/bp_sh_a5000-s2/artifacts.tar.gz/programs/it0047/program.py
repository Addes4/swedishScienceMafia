# EVOLVE-BLOCK-START
"""Hybrid: best fit for larger items, residual-skill rule for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    if item <= 20:
        # Small items: avoid creating tiny unusable fragments.
        perfect = (residual == 0).astype(np.float64)
        # Reward residuals that could still be filled by a typical future item
        # (mean ~40): peak reward near 40, tapering for smaller/larger gaps.
        # Tiny leftovers and near-full unusable gaps get little reward.
        near_mean = np.clip(1.0 - np.abs(residual - 40.0) / 40.0, 0.0, 1.0)
        useful = (residual >= 15).astype(np.float64)
        return (
            residual.astype(np.float64)
            + perfect * 100000.0
            + useful * 100.0
            + near_mean * 50.0
        )
    # Larger items: classic best fit.
    return -residual
# EVOLVE-BLOCK-END

