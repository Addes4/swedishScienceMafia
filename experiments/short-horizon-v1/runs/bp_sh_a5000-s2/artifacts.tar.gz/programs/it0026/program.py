# EVOLVE-BLOCK-START
"""Best-fit with a small-item residual-balancing correction.

Best fit alone is a strong online rule. The main loss versus optimal comes from
bins that end up with a small, hard-to-fill residual. For small items we can
cheaply "clean up" such bins: among the bins that fit, prefer the placement that
leaves residuals close to zero or close to the typical future item size, rather
than always the tightest fit. Large items keep pure best fit, which is near
optimal for them.
"""
import numpy as np


def priority(item, bins):
    """Score every bin; item goes to the highest (first on ties)."""
    resid = bins - item  # post-placement remaining capacity, all >= 0

    # Pure best fit: most negative residual (tightest) is best.
    score = -resid.astype(np.float64)

    # For small items, nudge toward residuals that are easy to close later:
    # residuals near 0 (nearly full bins) are good, and residuals near a
    # typical item size (~40) are good, while awkward mid-values are penalized.
    if item <= 25:
        r = resid.astype(np.float64)
        # want r close to 0 or close to 40 -> use cosine-like bump
        near_full = np.exp(-(r / 8.0) ** 2)
        near_typ = np.exp(-((r - 40.0) / 12.0) ** 2)
        bonus = 3.0 * (near_full + near_typ)
        score = score * 0.5 + bonus

    return score
# EVOLVE-BLOCK-END
