# EVOLVE-BLOCK-START
"""Best fit with a margin tie-breaker to avoid closing nearly-full bins early."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    post = bins - item            # residual after placement (smaller is better)
    # primary criterion: tightest fit (negated residual), scale up so integer residuals dominate
    score = -post.astype(np.float64) * 1000.0
    # tie-breaker: prefer larger pre-placement residual (avoid closing near-full bins
    # when multiple bins give the same post-placement residual)
    frac = item / 100.0
    score += bins.astype(np.float64) * frac
    return score
# EVOLVE-BLOCK-END
