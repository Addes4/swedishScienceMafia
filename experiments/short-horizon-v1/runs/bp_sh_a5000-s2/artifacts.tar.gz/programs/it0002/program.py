# EVOLVE-BLOCK-START
"""Best fit with a small preference to avoid opening fresh bins too eagerly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item
    # Base: best fit (smaller residual is better).
    score = -rem.astype(np.float64)
    # Penalize unused bins slightly so we prefer to fill existing partially-used bins.
    score -= 0.5 * (bins == 100)
    return score
# EVOLVE-BLOCK-END
