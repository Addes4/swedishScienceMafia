# EVOLVE-BLOCK-START
"""Empirical best fit with sharp single-item completion awareness.

Strongly prefer exact perfect fits. Otherwise, among bins the item fits,
score a placement by how likely its residual is to be exactly consumed by
a single future item, estimated online from a histogram of previously-seen
item sizes (with a Weibull-shaped prior for stability). This keeps gaps that
can be exactly completed usable instead of fragmenting them, while a mild
best-fit tie-break still packs tightly.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior
_seen = 0.0

_min_item = 100.0  # smallest item size observed so far in this stream

_DECAY = 0.999  # mild recency weighting to adapt within a stream


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen, _min_item

    residual = bins - item

    # Strongly prefer an exact perfect fit.
    perfect = residual == 0

    # Current estimate of the item-size distribution over sizes 0..100.
    p = _hist / _hist.sum()

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual.
    exact = p[r_idx]

    # Small local-neighborhood density around the residual, to value residuals
    # that sit in a high-probability region of the size distribution.
    nearby = np.zeros_like(exact)
    for d in (-1, 0, 1):
        nearby += p[np.clip(r_idx + d, 0, 100)]
    nearby /= 3.0

    mean_size = float(np.dot(np.arange(101), p))

    # Combined usefulness: exact single completion dominates; near-match and
    # region-density provide softer secondary signals.
    usefulness = 5000.0 * exact + 800.0 * nearby

    # Mild bonus for residuals close to the typical item size.
    usefulness += 50.0 * np.exp(-np.abs(residual - mean_size) / 10.0)

    # Mild best-fit tie-break.
    score = usefulness - residual.astype(np.float64) * 0.01

    # Penalize residuals that can never be filled again: below the smallest
    # item observed so far these fragments are permanently stranded, and the
    # penalty grows the further below that minimum we fall.
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (20.0 + 8.0 * deficit)

    # Update histogram for future items, with mild decay for recency.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
