# EVOLVE-BLOCK-START
"""Empirical best-fit with future-fillability using a learned/updated item histogram.

The scoring blends:
  - a very strong exact perfect-fit bonus,
  - the probability the residual can be exactly consumed by 1 or 2 future
    items, estimated from an online histogram of item sizes,
  - a mild best-fit (smaller residual) tie-break,
  - a stranding penalty for residuals below the smallest size seen so far.
"""
import numpy as np

# Nonparametric-ish prior over sizes 1..100 approximating a Weibull(shape~2)
# with mean ~40 (using scale ~45 gives mean ~40). We build it by discretizing
# a finer grid so the shape is accurate.
_fine = np.linspace(0.0, 100.0, 4001)
_fw = (_fine[1:] / 45.0) * np.exp(-(_fine[1:] / 45.0) ** 2.0)  # shape=2
_bin_id = np.clip(np.ceil(_fine[1:]).astype(np.int64), 1, 100)
_w = np.zeros(101, dtype=np.float64)
np.add.at(_w, _bin_id, _fw)
_w[1:] /= _w[1:].sum()
_prior = _w.copy()

_prior_pseudo = 6.0  # small pseudo-count so observed data dominates fast

# Online empirical counts over sizes 1..100 (index i => size i).
_hist = np.zeros(101, dtype=np.float64)
_hist[1:] = _prior_pseudo * _prior[1:]

_min_item = 100.0  # smallest item size seen this stream

_DECAY = 0.9995  # very mild recency weighting

# Smoothing kernel applied at lookup only.
_k = np.arange(-2, 3, dtype=np.float64)
_ksm = np.exp(-0.5 * (_k / 1.0) ** 2)
_ksm /= _ksm.sum()


def priority(item, bins):
    """Return a score per bin; highest score wins (ties -> first bin)."""
    global _hist, _min_item

    residual = bins - item
    perfect = residual == 0

    total = _hist.sum()
    h = _hist / total

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Smoothed density at the residual.
    dens = np.zeros(101, dtype=np.float64)
    for kk in range(5):
        shift = kk - 2
        src = np.clip(np.arange(101) + shift, 0, 100)
        dens += _ksm[kk] * h[src]

    # Single-item exact completion probability.
    exact1 = dens[r_idx]

    # Pair-completion: probability that two future items sum to the residual.
    # Normalized properly using the (mass) histogram.
    conv2 = np.convolve(h[1:], h[1:])  # conv2[k] -> sum k+2
    pair = np.zeros(101, dtype=np.float64)
    m = min(101, conv2.size)
    pair[2:2 + m] = conv2[:101 - 2]
    pair_prob = pair[r_idx]

    usefulness = 4000.0 * exact1 + 1500.0 * pair_prob

    # Reward residuals equal to a common small item size (sharply completable).
    small_mass = float(h[1:21].sum())
    usefulness += 800.0 * small_mass * np.exp(-np.abs(residual - 15.0) / 8.0)

    # Mild best-fit tie-break.
    score = usefulness - residual.astype(np.float64) * 0.03

    # Stranding penalty: residuals between 1 and the smallest seen can never
    # be filled again.
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (25.0 + 10.0 * deficit)

    # Update histogram.
    _hist *= _DECAY
    _hist[item] += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
