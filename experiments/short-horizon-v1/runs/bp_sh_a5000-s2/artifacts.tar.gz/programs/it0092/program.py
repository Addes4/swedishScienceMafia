# EVOLVE-BLOCK-START
"""Empirical-residual best fit with multi-item completion awareness.

Strongly prefer exact perfect fits. Otherwise, among bins the item fits,
score a placement by how likely its resulting residual is to be fully
consumed by future items, estimated online from a histogram of
previously-seen item sizes (with a Weibull-shaped prior for stability).
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + 20.0 * _prior
_seen = 0.0

_min_item = 100.0  # smallest item size observed so far in this stream

_DECAY = 0.9995  # mild recency weighting to adapt within a stream


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen, _min_item

    residual = bins - item

    # Strongly prefer an exact perfect fit.
    perfect = residual == 0

    # Current estimate of the item-size distribution.
    total = _hist.sum()
    p = _hist / total

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual.
    exact = p[r_idx]

    # Self-convolution of the 1..100 histogram: sums of two items.
    conv2 = np.convolve(_hist[1:], _hist[1:])  # conv2[k] for sum k+2
    total2 = total * total
    pair = np.zeros(101, dtype=np.float64)
    k = min(101, conv2.size)
    pair[2:2 + k] = conv2[:max(0, 101 - 2)] / total2

    # Self-convolution of conv2: sums of three items (clipped to 0..100 range).
    conv3 = np.convolve(conv2, _hist[1:])  # conv3[k] for sum k+3
    total3 = total * total * total
    triple = np.zeros(101, dtype=np.float64)
    k = min(101, conv3.size)
    triple[3:3 + k] = conv3[:max(0, 101 - 3)] / total3

    mean_size = float(np.dot(np.arange(101), p))

    # Combined usefulness: exact single > exact pair > exact triple.
    usefulness = (
        6000.0 * exact
        + 1500.0 * pair[r_idx]
        + 300.0 * triple[r_idx]
    )

    # Mild bonus for residuals close to the typical item size.
    usefulness += 40.0 * np.exp(-np.abs(residual - mean_size) / 10.0)

    # Mild best-fit tie-break.
    score = usefulness - residual.astype(np.float64) * 0.01

    # Penalize residuals that can never be filled again: below the smallest
    # item observed so far these fragments are permanently stranded, and the
    # penalty grows the further below that minimum we fall.
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (25.0 + 8.0 * deficit)

    # Update histogram for future items, with mild decay for recency.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score + perfect * 1e9
# EVOLVE-BLOCK-END

