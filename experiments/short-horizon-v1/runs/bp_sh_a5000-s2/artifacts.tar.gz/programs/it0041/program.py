# EVOLVE-BLOCK-START
"""Best fit with a mild fullness bias to consolidate into already-used bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    post = bins - item  # residual after placing the item
    # Primary: best fit (smaller residual better) -> rank by -post.
    # Secondary: mild fullness bias, reward bins that are already more used
    # (i.e. have smaller current remaining capacity) so that new/empty bins
    # are slightly discouraged, consolidating the stream into fewer bins.
    fullness = (100 - bins) / 100.0
    return -(post) + 0.5 * fullness
# EVOLVE-BLOCK-END
