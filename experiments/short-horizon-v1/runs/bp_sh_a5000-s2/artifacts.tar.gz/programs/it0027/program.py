# EVOLVE-BLOCK-START
"""Best fit plus an empirical residual-closure tie-break.

The main term is classic best fit: prefer the smallest post-placement residual.
Because ties/near-ties are common in an integer stream, I add a small secondary
term based on state learned online: how often a bin whose post-placement
residual equals r has historically been subsequently filled exactly (residual
"closed" by a later item).  This nudges the choice toward residuals that the
stream actually tends to close.
"""
import numpy as np


class _State:
    __slots__ = ("obs", "n", "counts", "closed", "seen", "last_res")

    def __init__(self):
        # empirical tally of item sizes seen (for distribution awareness)
        self.obs = np.zeros(101, dtype=np.float64)
        self.counts = np.zeros(101, dtype=np.float64)   # times residual r observed
        self.closed = np.zeros(101, dtype=np.float64)   # times residual r later closed
        self.seen = 0
        self.last_res = -1           # residual left by our previous placement
        self.n = 0


_state = _State()


def priority(item, bins):
    st = _state

    # ---- update closure statistics from the previous decision ----
    if st.last_res >= 0:
        r = st.last_res
        st.closed[r] += 1.0 if item == r else 0.0
    st.counts[0] = 0.0  # residual 0 can't be "closed" further

    # record observed item for the empirical prior
    if 1 <= item <= 100:
        st.obs[item] += 1.0
    st.n += 1

    # ---- empirical closure probability per residual value ----
    c = st.counts
    cl = st.closed
    with np.errstate(invalid="ignore", divide="ignore"):
        pmf = np.where(c > 0.0, cl / np.maximum(c, 1.0), 0.0)
    pmf[0] = 0.0

    # ---- main best-fit term + secondary closure-probability nudge ----
    res = bins - item                       # post-placement residual, >= 0
    # dominant: smaller residual is better -> large negative score
    score = -res.astype(np.float64)

    # secondary: reward residuals the past says get closed exactly
    p = pmf[res]
    # scale the nudge well below the unit gap between residuals
    score += 0.4 * p * (1.0 / (1.0 + res))

    # remember the residual we are about to create (best-score bin)
    best = int(np.argmax(score))
    st.last_res = int(res[best])

    return score
# EVOLVE-BLOCK-END
