# EVOLVE-BLOCK-START
"""Best fit with a residual-reuse guard tuned to the item distribution.

Items are Weibull-shaped with mean about 40.  Pure best-fit is strong, but it
sometimes closes a bin leaving a small residual that no future item is likely
to fill.  We keep best-fit as the primary key (tightest fit) but, among bins
whose residual after placement is "small", we nudge the score toward residuals
that are either zero or close to a typical future item size, so fragments stay
reusable.
"""
import numpy as np

# A coarse histogram over plausible future item sizes (1..100), favoring the
# mean-40 Weibull shape without depending on noisy per-stream statistics.
_SIZES = np.arange(1, 101, dtype=np.float64)
_SHAPE = 1.4
_SCALE = 40.0 / 0.9114  # 0.9114 ~ Gamma(1 + 1/1.4)
_LIK = (1.0 - np.exp(-((_SIZES / _SCALE) ** _SHAPE)))
_LIK = _LIK / _LIK.sum()


def priority(item, bins):
    resid = bins - item  # post-placement remaining capacity, all >= 0
    # Primary: best fit (most negative residual is best).
    primary = -resid.astype(np.float64)
    # Guard: for small residuals, reward residuals that are near 0 or that are
    # themselves likely item sizes; penalize tiny-but-nonzero fragments.
    r = resid.astype(np.int64)
    guard = np.zeros(bins.shape, dtype=np.float64)
    small = r <= 12
    # plausibility that this residual can be closed by one future item
    plaus = _LIK[np.clip(r - 1, 0, 99)]
    guard[small] = plaus[small] - 0.02 * r[small]
    # residual 0 is ideal (bin exactly full)
    guard[r == 0] = 1.0
    return primary + 0.5 * guard
# EVOLVE-BLOCK-END
