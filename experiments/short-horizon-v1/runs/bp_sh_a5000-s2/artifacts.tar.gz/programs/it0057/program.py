# EVOLVE-BLOCK-START
"""Length-aware best fit with a fragment guard for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Always take an exact perfect fit.
    score = np.zeros(len(bins), dtype=np.float64)
    perfect = residual == 0
    score += perfect * 100000.0

    # Base best-fit: smaller residual is better.
    score += -residual.astype(np.float64)

    # For small items, avoid carving out slivers too small to be useful later.
    # Only penalize non-perfect placements that leave a very small residual.
    if item <= 30:
        tiny = (residual > 0) & (residual < 0.5 * item)
        score -= tiny * 25.0

    return score
# EVOLVE-BLOCK-END
