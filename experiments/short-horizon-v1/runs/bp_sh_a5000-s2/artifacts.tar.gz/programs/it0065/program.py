# EVOLVE-BLOCK-START
"""Empirical-residual best fit with multi-item completion awareness.

Strongly prefer exact perfect fits. Otherwise score each feasible bin by an
online estimate of how likely its residual is to be fully consumed by future
items, using a smoothed histogram of previously-seen item sizes:
  - probability a single future item exactly equals the residual,
  - probability a pair of future items sums exactly to the residual,
  - probability a triple of future items sums exactly to the residual.
Completable gaps are kept usable instead of being fragmented, while a mild
best-fit tie-break keeps packing tight.
"""
import numpy as np

# Empirical distribution over item sizes 1..100, updated online.
_hist = np.ones(101, dtype=np.float64)  # Laplace smoothing
_seen = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen

    residual = bins - item

    # Strongly prefer an exact perfect fit.
    perfect = residual == 0

    # Current estimate of the item-size distribution.
    h = _hist / _hist.sum()
    p = _hist / _seen if _seen > 0 else h

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual.
    exact = p[r_idx]

    # Self-convolution of the 1..100 histogram: sums of two items.
    conv2 = np.convolve(_hist[1:], _hist[1:])  # conv2[k] for sum k+2
    total2 = _hist.sum() * _hist.sum()
    pair = np.zeros(101, dtype=np.float64)
    for s in range(0, 101):
        if 0 <= s - 2 < conv2.size:
            pair[s] = conv2[s - 2] / total2

    # Self-convolution of conv2: sums of three items (clipped to 0..100 range).
    conv3 = np.convolve(conv2, _hist[1:])  # conv3[k] for sum k+3
    total3 = _hist.sum() * _hist.sum() * _hist.sum()
    triple = np.zeros(101, dtype=np.float64)
    for s in range(0, 101):
        if 0 <= s - 3 < conv3.size:
            triple[s] = conv3[s - 3] / total3

    # Small local-neighborhood bonus for near-matches (+/- 1).
    nearby = np.zeros_like(exact)
    for d in (-1, 0, 1):
        nearby += p[np.clip(r_idx + d, 0, 100)]
    nearby /= 3.0

    # Mean item size, for a mild "leave a typical-sized gap" bonus.
    mean_size = float(np.dot(np.arange(101), h)) if _seen > 0 else 40.0

    # Combined usefulness: exact single > exact pair > exact triple > near-match.
    usefulness = (
        6000.0 * exact
        + 1500.0 * pair[r_idx]
        + 450.0 * triple[r_idx]
        + 150.0 * nearby
    )

    # Mild bonus for residuals close to the typical item size.
    usefulness += 60.0 * np.exp(-np.abs(residual - mean_size) / 12.0)

    # Smooth penalty for leaving a tiny fragment (fades out by residual ~8).
    usefulness -= 8.0 * np.exp(-residual / 4.0)

    # Mild best-fit tie-break.
    score = usefulness - residual.astype(np.float64) * 0.01

    # Update histogram for future items.
    _hist[item] += 1.0
    _seen += 1.0

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
