# EVOLVE-BLOCK-START
"""Empirical-residual best fit.

Strongly prefer exact perfect fits. Otherwise, among bins the item fits,
score a placement by how likely its resulting residual is to be matched
exactly (or nearly) by a future item, estimated from an online histogram
of previously-seen item sizes. This keeps gaps usable instead of
fragmenting them into slivers, while still packing tightly.
"""
import numpy as np

# Empirical distribution over item sizes 1..100, updated online.
_hist = np.ones(101, dtype=np.float64)  # Laplace smoothing
_seen = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen

    residual = bins - item

    # Strongly prefer an exact perfect fit.
    perfect = residual == 0

    # Update the online histogram with the current item (use current knowledge
    # then incorporate this item for future calls).
    p = _hist / _seen if _seen > 0 else _hist / _hist.sum()

    # For each possible residual r (0..100), usefulness = probability that a
    # future item exactly equals r, plus a small bonus for being close to a
    # likely item size (so near-perfect-but-not-exact gaps still count).
    r_idx = np.clip(residual, 0, 100).astype(np.int64)
    exact = p[r_idx]

    # A small local-neighborhood bonus: average probability of residuals
    # within +/- 2 of r (treating a slightly mis-sized gap as still usable).
    nearby = np.zeros_like(exact)
    for d in (-2, -1, 0, 1, 2):
        idx = np.clip(r_idx + d, 0, 100)
        nearby += p[idx]
    nearby /= 5.0

    # Base tie-breaker: prefer smaller residual (classic best fit) but weight
    # the usefulness estimate much more heavily.
    score = nearby * 1000.0 + exact * 5000.0 - residual.astype(np.float64) * 0.01

    # Never leave a useless tiny fragment unless it's a perfect fit.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny * 10.0

    # Update histogram for future items.
    _hist[item] += 1.0
    _seen += 1.0

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
