# EVOLVE-BLOCK-START
"""Best fit with exact-fit preference and smoothed single-item completability.

Strongly prefer exact perfect fits. Otherwise, among bins the item fits,
score a placement by the empirical likelihood that the resulting residual
is a plausible future item size (smoothed over its immediate neighbors),
estimated online from a histogram of previously-seen item sizes with a
Weibull-shaped prior for stability, plus a mild best-fit tie-break.
This keeps gaps that a single future item can likely finish instead of
fragmenting them, while packing tightly.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior
_seen = 0.0

_DECAY = 0.999  # mild recency weighting to adapt within a stream


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen

    residual = bins - item

    # Strongly prefer an exact perfect fit.
    perfect = residual == 0

    # Current estimate of the item-size distribution.
    p = _hist / _hist.sum()

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Smoothed probability the residual is exactly a plausible future item size.
    # Average the empirical probability of the residual and its immediate neighbors
    # to reduce variance from sparse histogram buckets.
    completable = (
        p[np.clip(r_idx - 1, 0, 100)]
        + p[r_idx]
        + p[np.clip(r_idx + 1, 0, 100)]
    ) / 3.0

    mean_size = float(np.dot(np.arange(101), p))

    # Main usefulness: how likely a single future item can finish the gap.
    usefulness = 3000.0 * completable

    # Mild bonus for residuals close to the typical item size.
    usefulness += 50.0 * np.exp(-np.abs(residual - mean_size) / 10.0)

    # Mild best-fit tie-break: slightly prefer the tightest fitting bin.
    score = usefulness - residual.astype(np.float64) * 0.01

    # Never leave a useless tiny fragment unless it's a perfect fit.
    tiny = (residual > 0) & (residual < 5)
    score -= tiny * 10.0

    # Update histogram for future items, with mild decay for recency.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
