# EVOLVE-BLOCK-START
"""Best fit with a smooth residual reward that discourages wasteful tiny gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: prefer tighter fits (smaller residual). Encode as negative residual.
    # Secondary: reward residuals that are neither wasteful tiny gaps nor huge open space.
    # A small gap (< 15) often can't be reused meaningfully; penalize it slightly by
    # effectively pushing its rank above (worse than) a residual just large enough to hold
    # common small items, while still keeping near-best-fit ordering.
    base = -residual.astype(np.float64)
    # Smooth bump: give a small bonus when residual is in a "usable" band.
    # Peak around residual ~ 20, decaying for very small and very large residuals.
    usable = np.exp(-((residual - 20.0) ** 2) / (2.0 * 18.0 ** 2))
    # Penalty for tiny unusable gaps.
    tiny = np.exp(-(residual.astype(np.float64) ** 2) / (2.0 * 6.0 ** 2))
    return base + 0.5 * usable - 0.5 * tiny
# EVOLVE-BLOCK-END
