# EVOLVE-BLOCK-START
"""Best fit with a mild occupancy bonus to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer the bin whose remaining capacity after placing the item is smallest.
    remaining = bins - item
    # Mild bonus for fuller bins (lower remaining capacity) to discourage opening new bins
    # and reduce fragmentation, while keeping tight fits dominant.
    return -remaining - 0.001 * bins
# EVOLVE-BLOCK-END
