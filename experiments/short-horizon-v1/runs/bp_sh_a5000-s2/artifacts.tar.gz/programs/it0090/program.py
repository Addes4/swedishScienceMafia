# EVOLVE-BLOCK-START
"""Empirical-residual best fit with multi-item completion awareness.

Strongly prefer exact perfect fits. Otherwise, among bins the item fits,
score a placement by how likely its resulting residual is to be fully
consumed by future items, estimated online from a histogram of
previously-seen item sizes (with a Weibull-shaped prior for stability):
  - probability a single future item exactly equals the residual,
  - probability a pair of future items sums exactly to the residual,
  - probability a triple of future items sums exactly to the residual.
Gaps that can be exactly completed are kept usable instead of being
fragmented, while still packing tightly via a mild best-fit tie-break.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior
_seen = 0.0

_min_item = 100.0  # smallest item size observed so far in this stream

_DECAY = 0.999  # mild recency weighting to adapt within a stream


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen, _min_item

    residual = bins - item

    # Strongly prefer an exact perfect fit.
    perfect = residual == 0

    # Current estimate of the item-size distribution.
    h = _hist / _hist.sum()
    p = _hist / _hist.sum()

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual.
    exact = p[r_idx]

    # Self-convolution of the 1..100 histogram: sums of two items.
    conv2 = np.convolve(_hist[1:], _hist[1:])  # conv2[k] for sum k+2
    total2 = _hist.sum() * _hist.sum()
    pair = np.zeros(101, dtype=np.float64)
    k = min(101, conv2.size)
    pair[2:2 + k] = conv2[:101 - 2] / total2

    # Self-convolution of conv2: sums of three items (clipped to 0..100 range).
    conv3 = np.convolve(conv2, _hist[1:])  # conv3[k] for sum k+3
    total3 = _hist.sum() * _hist.sum() * _hist.sum()
    triple = np.zeros(101, dtype=np.float64)
    k = min(101, conv3.size)
    triple[3:3 + k] = conv3[:101 - 3] / total3

    # Small local-neighborhood bonus for near-matches (+/- 1).
    nearby = np.zeros_like(exact)
    for d in (-1, 0, 1):
        nearby += p[np.clip(r_idx + d, 0, 100)]

    nearby /= 3.0

    mean_size = float(np.dot(np.arange(101), h))

    # Combined usefulness: exact single > exact pair > exact triple > near-match.
    usefulness = (
        5000.0 * exact
        + 1200.0 * pair[r_idx]
        + 400.0 * triple[r_idx]
        + 200.0 * nearby
    )

    # Mild bonus for residuals close to the typical item size.
    usefulness += 50.0 * np.exp(-np.abs(residual - mean_size) / 10.0)

    # Mild best-fit tie-break.
    score = usefulness - residual.astype(np.float64) * 0.01

    # Penalize residuals that can never be filled again: below the smallest
    # item observed so far these fragments are permanently stranded, and the
    # penalty grows the further below that minimum we fall.  Use a larger,
    # steeper penalty to more strongly avoid creating stranded slivers.
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (60.0 + 20.0 * deficit)

    # Update histogram for future items, with mild decay for recency.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
