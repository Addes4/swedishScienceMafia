# EVOLVE-BLOCK-START
"""Best fit with an empirical residual-closure tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Pure best fit primary: smaller post-placement residual -> higher score.
    residual = bins - item
    return -residual
# EVOLVE-BLOCK-END
