# EVOLVE-BLOCK-START
"""Best fit with an age-aware tie-break on post-placement residual ties.

The primary ranking stays exact best fit: the bin whose remaining capacity after
placing the item is smallest wins.  Ties are broken by age: among equally tight
bins we prefer the one that has gone longest without receiving an item, which
gently consolidates older open bins instead of spreading tiny residuals across
many stale bins that may never be revisited.
"""
import numpy as np

# per-stream recency counter, reset lazily when the stream restarts
_last = {}
_tick = [0]


def priority(item, bins):
    """Return a score per bin; highest score wins (first on ties)."""
    _tick[0] += 1
    n = bins.shape[0]
    # identify which bins these are by identity of the array copy is not stable,
    # so instead treat index positions and let the harness rebuild state each stream.
    # We key age by index within the current bins array.
    key = id(bins)
    state = _last.get("state")
    if state is None or state.shape[0] != n:
        state = np.zeros(n, dtype=np.int64)
        _last["state"] = state

    # residual after placing
    residual = bins - item
    # primary: smaller residual => better (negate)
    score = -residual.astype(np.float64)
    # tie-break: older bins (smaller last-insert tick) get a tiny boost
    # scale small enough not to disturb strict residual ordering
    score += (state / max(_tick[0], 1)) * 0.25

    # record insertion time for the chosen bin (argmax) after scoring
    chosen = int(np.argmax(score))
    state[chosen] = _tick[0]
    return score
# EVOLVE-BLOCK-END
