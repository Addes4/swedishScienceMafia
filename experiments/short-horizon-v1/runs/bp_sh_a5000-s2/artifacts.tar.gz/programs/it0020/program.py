# EVOLVE-BLOCK-START
"""Best fit with residue-avoidance: prefer tight fits, but avoid leaving tiny unusable gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for bins shown

    # Base: tighter fit is better (negative residual).
    score = -residual.astype(np.float64)

    # Penalize small-but-nonzero residuals: a leftover of r (1..item-1) that is too small
    # to hold a typical item tends to waste a bin; prefer residuals of 0 (perfect fill)
    # or residuals large enough to be reusable.
    reusable = 40.0  # mean item size
    # penalty is large for small nonzero residuals, tapering to 0 near `reusable`
    pen = np.where(
        (residual > 0) & (residual < reusable),
        (reusable - residual) / reusable,
        0.0,
    )
    score -= pen

    return score
# EVOLVE-BLOCK-END
