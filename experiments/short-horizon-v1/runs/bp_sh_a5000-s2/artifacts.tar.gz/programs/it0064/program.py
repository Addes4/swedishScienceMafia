# EVOLVE-BLOCK-START
"""Best fit with learned residual utility.

Among bins the item fits, we prefer placements that leave a small residual
(best-fit) but penalize leaving a residual smaller than a likely future item
size, since such tiny gaps cannot be reused. The utility of a residual is
estimated online from a histogram of previously-seen item sizes.
"""
import numpy as np

# Empirical distribution over item sizes 1..100, updated online.
_hist = np.ones(101, dtype=np.float64)  # Laplace smoothing
_seen = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen

    residual = bins - item
    residual_f = residual.astype(np.float64)
    perfect = residual == 0

    # Empirical item-size distribution.
    p = _hist / _hist.sum()

    # Probability a future item exactly equals this residual.
    r_idx = np.clip(residual, 0, 100).astype(np.int64)
    exact = p[r_idx]

    # Probability a single future item is small enough to reuse the gap.
    # We approximate "reusable" as the probability a typical small item fits.
    reusable = np.array([
        float(p[1:max(1, int(r)) + 1].sum()) if r > 0 else 0.0
        for r in np.clip(residual, 0, 100)
    ])

    # Best-fit core: prefer small residual (tight packing).
    score = -residual_f * 1.0

    # Strong bonus if a future item can exactly fill the gap.
    score += 2000.0 * exact

    # Penalize tiny gaps that likely cannot be reused.
    tiny_penalty = np.where((residual > 0) & (residual < 3), 50.0, 0.0)
    score -= tiny_penalty

    # Reward residuals that are plausibly reusable by a small future item.
    score += 100.0 * reusable

    # Update histogram for future items.
    _hist[item] += 1.0
    _seen += 1.0

    # Hard priority for perfect fits.
    return score + perfect * 1e9
# EVOLVE-BLOCK-END
