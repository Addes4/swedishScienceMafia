# EVOLVE-BLOCK-START
"""Adaptive best-fit with an online residual-completion table.

Rule:
  1. Always take an exact perfect fit if one exists.
  2. Otherwise, primary signal is best-fit (smallest positive residual).
  3. Tie-break by an online learned "completion rate" per residual: the
     fraction of past items whose size exactly matched a previously-observed
     residual, tracked via a decaying table, so the rule adapts to the stream.
  4. Penalize residuals that are permanently unfillable (below the smallest
     item observed so far).
"""
import numpy as np

# Parametric prior over sizes 1..100 for smoothing the empirical histogram.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0

_hist = 1.0 + _prior_scale * _prior
_seen = 0.0
_min_item = 100.0

# Online completion table: how often a residual r was exactly consumed by the
# next arriving item. Smoothed with a small prior.
_fill = np.zeros(101, dtype=np.float64)
_fill_denom = np.zeros(101, dtype=np.float64)
_prev_residuals = None  # residuals present when last item arrived (mask)

_DECAY = 0.999


def priority(item, bins):
    global _hist, _seen, _min_item, _fill, _fill_denom, _prev_residuals

    residual = bins - item
    perfect = residual == 0

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Empirical size distribution.
    total = _hist.sum()
    p = _hist / total

    # Completion signal from the online learned table (smoothed).
    comp_prob = (_fill + 1.0) / (_fill_denom + 25.0)

    # Probability the exact residual can be filled by a single future item.
    exact = p[r_idx]

    # Nearest-present residual complement: residual that equals item size is great.
    completion = comp_prob[r_idx]

    # Exact fits dominate.
    if np.any(perfect):
        # Among perfect fits just return high score for first; harness picks first.
        score = np.where(perfect, 1e9, 0.0)
        _update(item, residual)
        return score

    # Primary: best fit (smallest positive residual). Encode as negative residual
    # scaled so completion signals can break near-ties.
    usable = residual > 0
    bestfit = -residual.astype(np.float64) * 10.0

    score = bestfit
    score += 300.0 * exact
    score += 200.0 * completion

    # Penalize permanently unfillable fragments.
    min_obs = max(1.0, _min_item)
    unusable = usable & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (500.0 + 20.0 * deficit)

    _update(item, residual)
    return score + perfect * 1e9


def _update(item, residual):
    global _hist, _seen, _min_item, _fill, _fill_denom, _prev_residuals

    # Update completion table: for each unique positive residual that existed
    # before this item, if item == that residual it was a successful fill.
    pos = np.unique(residual[residual > 0])
    if pos.size:
        _fill_denom[pos] *= _DECAY
        _fill_denom[pos] += 1.0
        if item in pos:
            _fill[item] *= _DECAY
            _fill[item] += 1.0

    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)
# EVOLVE-BLOCK-END
