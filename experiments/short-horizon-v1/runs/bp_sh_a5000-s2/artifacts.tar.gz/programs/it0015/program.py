# EVOLVE-BLOCK-START
"""Best fit with a small penalty for leaving unusable residuals.

Pure best fit minimizes the post-placement residual, but it often leaves a residual
so small that no future item can use it (wasted space), or closes a bin awkwardly.
We keep best-fit as the dominant criterion but subtract a small penalty when the
resulting residual is far from the typical item size seen so far: a good residual is
one that could fit (or nearly finish) a future item of typical size.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # >= 0 since bins shown only if item fits

    # Running estimate of typical item size (start at 40, the stated mean).
    s = priority.state
    s["n"] += 1
    s["sum"] += item
    mean = s["sum"] / s["n"]

    # Penalize residuals that are "wasted": too small to ever help again.
    # A residual r is wasteful if 0 < r < typical_min; approximate typical_min
    # by a fraction of the mean, and also penalize leaving room just below mean.
    # Keep the penalty small so best-fit dominates on near-ties.
    small = mean * 0.5
    # penalty increases as residual shrinks below `small`, and is capped.
    pen = np.where(residual < small, (small - residual) / (small + 1.0), 0.0)

    return -residual - 0.15 * pen


priority.state = {"n": 0, "sum": 0.0}
# EVOLVE-BLOCK-END

