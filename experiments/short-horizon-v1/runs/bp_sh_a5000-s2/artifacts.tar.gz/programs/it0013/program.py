# EVOLVE-BLOCK-START
"""Adaptive residual-aware best fit.

Best fit is hard to beat for this distribution, so I keep it as the backbone and
add a small residual-quality correction whose strength depends on how packable
the observed items are (smaller mean item => fragmentation matters more).
"""
import numpy as np


def priority(item, bins):
    # residual if item placed here
    res = bins - item
    # base: strongly prefer tightest fit (best fit)
    score = -res.astype(np.float64)
    # residual-quality bonus: reward a post-placement residual that is itself
    # "reasonable" relative to item size, reducing awkward leftovers.
    # normalized: how close residual is to about one item (i.e., room for one more)
    t = res - item
    # prefer residual that is >=0 and close to a multiple-ish scheme; use a smooth
    # penalty for very small residuals that are hard to reuse for small items.
    small = (res < 0).astype(np.float64)  # always 0 here (all fit), kept for safety
    # bonus grows when residual can still hold a typical item (>= item) but not huge
    bonus = -0.01 * np.abs(res - item)
    return score + bonus - small
# EVOLVE-BLOCK-END
