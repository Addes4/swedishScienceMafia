# EVOLVE-BLOCK-START
"""Best-fit with strong perfect-fit preference and mild completion awareness.

Primary rule: exact perfect fit wins. Otherwise, best-fit (smallest residual).
A smoothed online item-size histogram provides small tie-breakers that nudge
toward residuals likely to be exactly consumable by future items, plus a
soft stranding penalty for residuals below the smallest observed item size.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior
_seen = 0.0

_min_item = 100.0  # smallest item size observed so far in this stream

_DECAY = 0.999  # mild recency weighting to adapt within a stream

# Precomputed smoothing kernel (over residual distance).
_kdist = np.arange(-2, 3, dtype=np.float64)
_ksmooth = np.exp(-0.5 * (_kdist / 1.0) ** 2)
_ksmooth /= _ksmooth.sum()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen, _min_item

    residual = bins - item

    # Strongly prefer an exact perfect fit.
    perfect = residual == 0

    # Current estimate of the item-size distribution over 1..100.
    h = _hist / _hist.sum()

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Smoothed density at the residual (robustness to small sampling gaps).
    dens = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_ksmooth):
        shift = k - 2
        src = np.clip(np.arange(101) + shift, 0, 100)
        dens += w * h[src]

    # Probability a single future item exactly equals this residual.
    exact = dens[r_idx]

    # Primary secondary criterion: best-fit (smaller residual is better).
    # Scale it strongly so it dominates the noisy usefulness terms.
    score = -1.0 * residual.astype(np.float64)

    # Small tie-breakers: prefer residuals likely to be consumable exactly.
    score += 20.0 * exact

    # Penalize residuals that can never be filled again (below smallest seen).
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (0.5 + 0.1 * deficit)

    # Update histogram for future items, with mild decay for recency.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score + perfect * 1e9
# EVOLVE-BLOCK-END

