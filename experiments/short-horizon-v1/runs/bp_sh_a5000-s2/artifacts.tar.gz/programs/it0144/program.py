# EVOLVE-BLOCK-START
"""Best fit with a scaled exact-completion bonus.

Rank primarily by best fit (smallest residual), but give a genuine, properly
scaled bonus when the residual is very likely to be exactly consumed by one
future item or by a pair of future items, using an online empirical estimate
of the item-size distribution.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior
_seen = 0.0
_min_item = 100.0  # smallest item size observed so far in this stream


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen, _min_item

    residual = bins - item
    perfect = residual == 0

    # Normalized empirical distribution over 1..100.
    h = _hist / _hist.sum()

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Probability a single future item exactly equals this residual.
    single = h[r_idx]

    # Pair-completion probability via normalized self-convolution.
    conv2 = np.convolve(h[1:], h[1:])  # conv2[k] corresponds to sum k+2
    pair = np.zeros(101, dtype=np.float64)
    k = min(101, conv2.size)
    pair[2:2 + k] = conv2[:101 - 2]

    # Scaled completion signal (kept well below the best-fit ordering so it
    # only breaks near-ties).
    usefulness = 0.06 * single + 0.02 * pair[r_idx]

    # Best-fit tie-break: prefer smaller residuals.
    score = usefulness - residual.astype(np.float64) * 0.002

    # Penalize residuals that can never be filled again (below smallest seen).
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (0.05 + 0.01 * deficit)

    # Update histogram for future items.
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
