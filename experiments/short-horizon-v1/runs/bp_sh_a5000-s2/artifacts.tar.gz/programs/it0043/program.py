# EVOLVE-BLOCK-START
"""Hybrid: best fit for larger items, worst fit for tiny items to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    if item <= 18:
        # Small items: avoid leaving tiny unusable fragments.
        # Perfect fits are still ideal; otherwise prefer worst fit (largest remaining
        # capacity), which keeps small gaps consolidated rather than splitting them.
        perfect = residual == 0
        # Score: huge bonus for exact fill, else larger residual -> larger score.
        return residual.astype(np.float64) + perfect * 1000.0
    # Larger items: classic best fit.
    return -residual
# EVOLVE-BLOCK-END

