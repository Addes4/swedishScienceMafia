# EVOLVE-BLOCK-START
"""Best fit with a near-tie reorder that avoids hard-to-fill residuals."""
import numpy as np

_TYPICAL = 40.0  # mean item size ~40


def priority(item, bins):
    """Return a priority per bin; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)

    # Primary: prefer tighter fits. Score is higher for smaller residual.
    # We quantise the residual into a small number of "tie bands" so that
    # near-equal fits are treated as ties and can be reordered below.
    band = np.floor(residual / 5.0)          # width-5 bands
    primary = -band                          # smaller band -> higher score

    # Secondary within a band: prefer a residual that is unlikely to be
    # stranded, i.e. far from being just under a multiple of the mean item
    # size. Concretely, residuals close to 0 are best; residual near the
    # typical size is fine; residual just below the typical size is bad
    # because no single future item fits exactly.
    frac = np.mod(residual, _TYPICAL)
    # penalty grows as frac approaches _TYPICAL from below
    secondary = -(frac / _TYPICAL)           # prefer small frac (tight-ish)

    # Tertiary: deterministic index tie-break (earlier bin first).
    n = residual.shape[0]
    tertiary = -np.arange(n) * 1e-12

    return primary * 1e6 + secondary * 1e3 + tertiary
# EVOLVE-BLOCK-END
