# EVOLVE-BLOCK-START
"""Empirical best fit with exact-completion preference.

Strongly prefer exact perfect fits (residual 0). Among the rest, prefer
the placement whose residual is most likely to be exactly filled by a
single future item (using an online histogram estimate of the item-size
distribution), and break remaining ties toward the smallest residual.
"""
import numpy as np

# Parametric prior: Weibull-ish shape with mean ~40, over sizes 1..100.
_sizes = np.arange(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
_w_prior = (_sizes[1:] / _scale) ** (_shape - 1.0) * np.exp(-(_sizes[1:] / _scale) ** _shape)
_w_prior = _w_prior / _w_prior.sum()
_prior = np.zeros(101, dtype=np.float64)
_prior[1:] = _w_prior
_prior_scale = 30.0  # weight of prior relative to observed counts

# Empirical distribution over item sizes 1..100, updated online.
_hist = 1.0 + _prior_scale * _prior
_seen = 0.0

_min_item = 100.0  # smallest item size observed so far in this stream

_DECAY = 0.999  # mild recency weighting to adapt within a stream


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen, _min_item

    residual = bins - item

    # Strongly prefer an exact perfect fit.
    perfect = residual == 0

    # Current estimate of the item-size distribution over 1..100.
    h = _hist / _hist.sum()

    r_idx = np.clip(residual, 0, 100).astype(np.int64)

    # Normalized probability a single future item exactly equals the residual.
    exact = h[r_idx]

    # Primary usefulness: likely to be exactly completed by one future item.
    usefulness = 4.0 * exact

    # Mild best-fit tie-break: prefer smaller residuals.
    score = usefulness - residual.astype(np.float64) * 0.05

    # Penalize residuals that can never be filled again (below smallest seen).
    min_obs = max(1.0, _min_item)
    unusable = (residual > 0) & (residual < min_obs)
    deficit = np.clip(min_obs - residual, 0.0, None)
    score -= unusable * (20.0 + 8.0 * deficit)

    # Update histogram for future items, with mild decay for recency.
    _hist *= _DECAY
    _hist[item] += 1.0
    _seen += 1.0
    if item < _min_item:
        _min_item = float(item)

    return score + perfect * 1e9
# EVOLVE-BLOCK-END
