# EVOLVE-BLOCK-START
"""Hybrid: best fit for larger items, anti-fragmentation rule for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    if item <= 20:
        # Small items: avoid creating tiny unusable fragments.
        # Perfect fits first.
        perfect = residual == 0
        # Reward residuals that are either zero or large enough to still be
        # useful for future items; penalize tiny leftovers.
        # map residual -> score: larger residual is better, but add a big bonus
        # for residuals >= floor so tiny fragments are avoided.
        useful = residual >= 15
        return residual.astype(np.float64) + perfect * 100000.0 + useful * 100.0
    # Larger items: classic best fit.
    return -residual
# EVOLVE-BLOCK-END
