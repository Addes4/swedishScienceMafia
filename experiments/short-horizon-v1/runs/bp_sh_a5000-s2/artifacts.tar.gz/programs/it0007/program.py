# EVOLVE-BLOCK-START
"""Best fit with a worst-fit slack band.

Best fit is strong when residuals differ meaningfully, but when several bins have
nearly the same remaining capacity it tends to keep hammering the fullest one,
which leaves a fragmented tail of tiny residuals.  Here we quantize the residual
and prefer larger remaining capacity within the same fit "bucket", so nearly
equivalent fits are spread out (worst-fit style) while genuinely tighter fits
still win.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (100), in bin order.
    """
    residual = bins - item          # >= 0 for every bin we are shown

    # Fit "bucket": residuals within this band are treated as equivalent, so we
    # are free to choose the emptiest bin in the band (worst fit there) instead
    # of repeatedly filling the tightest one.  Scale a little with item size so
    # small items do not fragment large open bins unnecessarily.
    band = 2 + (item // 20)
    bucket = residual // band

    # Primary key: finer bucket first (tighter fit preferred at coarse level),
    # tie-broken inside the bucket by larger remaining capacity (worst fit).
    return -bucket * 1000.0 + bins
# EVOLVE-BLOCK-END
