# EVOLVE-BLOCK-START
"""Hybrid: best fit for larger items, residual-near-mean rule for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    if item <= 20:
        # Small items: prefer a perfect fit; otherwise keep the leftover close to
        # a typical future item size (~40) so the gap remains usable.
        perfect = residual == 0
        # closeness of residual to ~40; smaller distance is better.
        dist = np.abs(residual.astype(np.float64) - 40.0)
        return perfect * 100000.0 - dist
    # Larger items: classic best fit.
    return -residual
# EVOLVE-BLOCK-END

