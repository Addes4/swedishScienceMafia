# EVOLVE-BLOCK-START
"""Best fit with online residual-matching secondary term.

Pure best fit is strong for this distribution. To reduce slivers, we add a
small, always-on secondary bonus for bins whose post-placement residual matches
a value recently seen in the item stream. Such residuals are more likely to be
filled exactly by a future item, improving packing efficiency without the
noise of a periodic diversion.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_DECAY = 0.99
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    # Update online histogram of past item sizes (decayed).
    _HIST *= _DECAY
    _HIST[item] += 1.0

    # Base: best-fit priority (tighter residual -> higher score).
    resid = bins - item  # remaining after placement (>= 0)
    better_fit = -resid

    # Secondary: residual-matching bonus. Higher when the post-placement
    # residual is an integer value recently seen as an item size.
    ri = np.clip(np.rint(resid).astype(np.int64), 0, 100)
    match = _HIST[ri]
    # Normalize gently so it never dominates best-fit.
    bonus = 0.02 * match

    # Exact-fit strongly preferred.
    exact = (resid == 0).astype(np.float64) * 0.5

    return better_fit + bonus + exact
# EVOLVE-BLOCK-END
