# EVOLVE-BLOCK-START
"""Best fit with soft preservation of a "typical item" gap.

Pure best fit is the strongest simple baseline here, but it aggressively
closes bins and can leave many unusable slivers.  This rule keeps best fit
as the dominant ordering (tighter post-placement residual always wins when
residuals are small), yet adds a smooth, monotone preference among looser
residuals for bins whose leftover equals a typical future item size.  A
stateful running estimate of the mean item size drives the target, so the
rule adapts to the fixed but unknown item distribution without seeing the
future.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}
_MIN_SEEN = 8  # fallback target before enough items are observed


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1
    _state["sum"] += item

    mean = _state["sum"] / (n + 1)
    if mean < 1.0:
        mean = _MIN_SEEN

    resid = bins - item  # remaining capacity after placing (>= 0 by contract)

    # Primary: best fit -> smaller residual is better.
    primary = -resid

    # Secondary: among larger residuals, gently prefer one close to a typical
    # future item size, so the leftover can host a whole future item.
    dist = np.abs(resid - mean)
    # Soft bonus, bounded and always smaller than one unit of residual so it
    # cannot reorder bins whose residuals differ by >= 1.
    bonus = 0.5 / (1.0 + dist)

    return primary + bonus
# EVOLVE-BLOCK-END

