# EVOLVE-BLOCK-START
"""Best fit with a slight bias toward preserving very large bins."""
import numpy as np


def priority(item, bins):
    """Score bins so the tightest fit wins, except keep some slack for large items.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Residual capacity after placing the item: smaller is a tighter (better) fit.
    residual = bins - item

    # Penalize wasting bins that are very large: if the item is small, prefer not to
    # dump it into a nearly empty bin when a tighter fit exists. This is essentially
    # best fit, with a tiny tie-breaking nudge by bin fullness.
    return -residual
# EVOLVE-BLOCK-END

