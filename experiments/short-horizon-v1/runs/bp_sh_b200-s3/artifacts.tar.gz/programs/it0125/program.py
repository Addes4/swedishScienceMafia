# EVOLVE-BLOCK-START
"""Best fit with a smooth residual-matching tie-break.

Pure best fit is strong but leaves slivers. This rule keeps best-fit as the
dominant term and adds an always-on, cheap secondary term that prefers a
post-placement residual close to the current item's own size (so that two
similar items pair up) plus a mild preference for residuals near the running
mean. No periodic diversion, so behaviour stays near-proven-good.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    st = _state
    n = st["n"]
    st["n"] = n + 1
    st["sum"] += item
    mean = st["sum"] / (n + 1) if n >= 10 else _MEAN

    resid = bins - item  # remaining after placing (>= 0 for shown bins)

    # Dominant: best-fit (tighter residual -> higher score).
    score = -(resid.astype(np.float64))

    # Secondary: prefer residuals close to the current item (pairing) or to
    # the running mean (plausible future item). Small weight keeps best-fit
    # dominant while breaking near-ties toward less fragmenting residuals.
    target = 0.5 * item + 0.5 * mean
    score -= 1e-3 * np.abs(resid - target)

    return score
# EVOLVE-BLOCK-END
