# EVOLVE-BLOCK-START
"""Best fit with a smooth, always-on residual-quality tie-breaker.

Pure best fit is strong for this distribution. We keep post-placement
residual minimisation as the dominant term, and add a small always-on
bonus for residuals that are themselves plausible future item sizes
(near the typical small-item scale, ~mean/2 to mean). The bonus is scaled
small enough that it only breaks near-ties, avoiding the fragility of the
previous periodic diversion.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0
# Typical "useful" residual targets: residuals that can still hold a
# common small item rather than leaving an unusable tiny sliver.
_LOW = 18.0
_HIGH = 42.0
_W = 0.03  # small weight; only nudges near-ties


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Dominant: best fit (tighter residual -> higher score).
    score = -resid.astype(np.float64)

    # Small always-on bonus for residuals in the useful band (can still
    # accept a typical future item) rather than unusable slivers.
    in_band = (resid >= _LOW) & (resid <= _HIGH)
    score += _W * in_band

    return score
# EVOLVE-BLOCK-END
