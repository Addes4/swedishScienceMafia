# EVOLVE-BLOCK-START
"""Best fit with a light, always-on residual-affinity tie-break.

Pure best fit is the strongest simple online rule for this distribution, but
it can leave awkward slivers. We keep best-fit as the dominant term and add a
small, bounded bonus when the post-placement residual is close to a size that
tends to appear again soon (tracked via a coarse running histogram of items).
The bonus is scaled well below the best-fit gap (floor of residual) so it only
breaks near-ties, never overriding best fit.
"""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    hist = _state["hist"]
    hist[item] += 1.0
    _state["n"] += 1

    # Dominant term: best fit (tighter post-placement residual -> higher score).
    resid = bins - item  # remaining after placing, >= 0 for shown bins
    base = -resid

    # Light affinity term: prefer residuals that are plausible future item sizes.
    # Normalize histogram into a coarse probability over residual values.
    total = hist.sum()
    if total > 0:
        # residual is integer-valued; weight by observed frequency at that size,
        # plus small smoothing so all residuals get non-negative affinity.
        aff = hist[np.clip(resid, 0, 100).astype(np.int64)] / total
    else:
        aff = np.zeros_like(resid)

    # Bonus magnitude < 1 so it only breaks ties within the same integer residual.
    return base + 0.9 * aff
# EVOLVE-BLOCK-END
