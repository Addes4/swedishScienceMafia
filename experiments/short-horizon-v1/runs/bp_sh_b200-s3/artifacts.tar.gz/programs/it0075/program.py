# EVOLVE-BLOCK-START
"""Best fit with distribution-aware tie-breaking.

Best fit is a strong online packing rule for Weibull-shaped sizes (mean ~40).
Pure best fit tends to leave residuals that are too small to be reused. We keep
best-fit as the primary criterion and break near-ties using a bonus that prefers
post-placement residuals which are still large enough to hold items commonly seen
so far in the stream. The bonus is learned online from observed item sizes.
"""
import numpy as np

_state = {"counts": None, "n": 0}
_MAXSIZE = 101


def _get_counts():
    c = _state["counts"]
    if c is None:
        c = np.zeros(_MAXSIZE, dtype=np.float64)
        _state["counts"] = c
    return c


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    counts = _get_counts()
    counts[item] += 1.0
    _state["n"] += 1

    resid = bins - item  # remaining capacity after placing item (>=0)

    # Primary: best fit -> prefer smallest post-placement residual.
    # Encode as negative residual so higher = tighter fit.
    score = -resid.astype(np.float64)

    # Secondary: small bonus preferring residuals that can still hold a
    # commonly-seen item, i.e. penalize leaving a tiny unusable sliver.
    # Weight scales with total observed items (grows confidence over time).
    total = counts.sum()
    if total > 0:
        # fraction of past items with size <= residual
        csum = np.cumsum(counts)  # csum[s] = # items with size <= s
        idx = np.clip(resid, 0, _MAXSIZE - 1)
        frac_fit = csum[idx] / total  # fraction of items that would fit resid
        # Mild, bounded bonus; scale small enough to only matter for near-ties.
        score += 0.5 * frac_fit

    return score
# EVOLVE-BLOCK-END
