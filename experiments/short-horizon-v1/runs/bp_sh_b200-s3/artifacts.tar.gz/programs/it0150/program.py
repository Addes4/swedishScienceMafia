# EVOLVE-BLOCK-START
"""Smoothed best fit with modular-consolidation alignment.

Pure best fit leaves many small slivers for this Weibull-shaped distribution.
We keep best-fit as the dominant rule, but add a small always-on bonus that
rewards residuals close to a multiple of the mean item size (~40). This nudges
placement toward consolidating leftovers into fuller slots without the brittle
periodic trigger of earlier versions, spreading consolidation evenly.
"""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    # Dominant term: best fit (tighter residual -> higher score).
    better_fit = -(bins - item)

    # Smooth bonus: reward residuals near a multiple of the mean item size.
    resid = bins - item  # remaining after placing (>= 0)
    m = np.round(resid / _MEAN)
    align = -np.abs(resid - m * _MEAN)

    return better_fit + 0.15 * align
# EVOLVE-BLOCK-END

