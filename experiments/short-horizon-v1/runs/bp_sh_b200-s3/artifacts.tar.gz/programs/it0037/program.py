# EVOLVE-BLOCK-START
"""Best fit with residual-gap-aware tie-breaking.

Strict best fit is a strong baseline for this distribution. The main room for
improvement is how we break (near-)ties: among bins that leave a similar
residual, it is better to complete a bin to exactly full when possible, and
otherwise to prefer the bin whose post-placement residual keeps it as useful
as possible. All secondary terms are scaled strictly below one residual unit
so the best-fit primary never gets overridden.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    residual = bins - item  # post-placement free space, >= 0 for fitting bins

    # Primary: best fit -> smaller residual is better.
    score = -residual.astype(np.float64)

    # Secondary tie-break, scaled well below 1 residual unit so it only
    # resolves near-ties among bins with essentially equal residual.
    # 1) strongly prefer exact perfect fills (residual == 0).
    perfect = (residual == 0).astype(np.float64)
    # 2) among the rest, prefer fuller bins (larger pre-placement fullness),
    #    i.e. residual close to the item's "natural" leftover: use fullness
    #    fraction as a smooth tie-break.
    fullness = (bins.astype(np.float64)) / 100.0

    score += 0.5 * perfect + 0.01 * fullness

    return score
# EVOLVE-BLOCK-END

