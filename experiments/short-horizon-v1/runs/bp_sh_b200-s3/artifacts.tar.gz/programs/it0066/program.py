# EVOLVE-BLOCK-START
"""Modulo-consolidating best fit.

For every item we score each fitting bin by how close its post-placement
residual is to a multiple of the mean item size (~40).  Placing items so the
leftover is a "multiple of a typical item" keeps bins usable for future
mean-sized items and avoids scattering tiny slivers, which is the dominant
source of wasted space for this Weibull-shaped distribution.  Best-fit is
used as a soft tie-breaker so we still favour tight packing.
"""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placing (>= 0)

    # Distance of residual to the nearest multiple of the mean item size.
    m = np.round(resid / _MEAN)
    dist = np.abs(resid - m * _MEAN)

    # Primary: preder residuals close to a multiple of the mean (consolidation).
    score = -dist

    # Secondary tie-breaker: among equally-good targets prefer tighter fit
    # (smaller residual), i.e. best fit, weighted small enough not to
    # override the modulo preference.
    score = score - 0.01 * resid

    return score
# EVOLVE-BLOCK-END


