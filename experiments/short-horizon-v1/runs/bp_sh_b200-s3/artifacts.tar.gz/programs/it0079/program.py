# EVOLVE-BLOCK-START
"""Best fit with distribution-aware tie-break.

Pure best fit is strong for Weibull-shaped sizes, but there are ties and
near-ties where the choice matters. We keep best-fit as the primary key and
break near-ties by an estimate of future waste: for a candidate post-placement
residual r, compute the expected loss = E[max(0, next_item - r)] using a
running histogram of observed item sizes. Choosing the residual with the
smallest expected loss keeps bins usable and reduces slivers.
"""
import numpy as np

_state = {"hist": np.ones(101, dtype=np.float64), "n": 0}
_MAXSIZE = 100


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    hist = _state["hist"]
    _state["n"] += 1

    # Update observed item histogram (Laplace-smoothed, starts uniform-ish).
    if 1 <= item <= _MAXSIZE:
        hist[item] += 1.0

    total = hist.sum()
    sizes = np.arange(_MAXSIZE + 1, dtype=np.float64)
    probs = hist / total

    resid = bins - item  # remaining capacity after placement (>= 0)

    # Primary key: best fit (smaller residual is better).
    # Secondary key: expected future waste given residual r:
    #   waste(r) = sum_s p(s) * max(0, s - r)
    # Precompute cumulative distribution to vectorize.
    # E[max(0, s - r)] = sum_{s > r} p(s) * (s - r)
    cdf = np.cumsum(probs)          # cdf[r] = P(s <= r)
    tail_mean = np.cumsum(probs * sizes)[::-1][::-1]  # sum_{s>=t} p(s)*s indexed by t
    # sum_{s>r} p(s)*s = total_sizes_tail(r+1)
    tail_sizes = np.zeros(_MAXSIZE + 2, dtype=np.float64)
    tail_sizes[:-1] = np.cumsum((probs * sizes)[::-1])[::-1]
    tail_prob = np.zeros(_MAXSIZE + 2, dtype=np.float64)
    tail_prob[:-1] = np.cumsum(probs[::-1])[::-1]

    r_idx = np.clip(resid.astype(np.int64), 0, _MAXSIZE)
    rp = r_idx + 1
    # expected waste for residual r_idx
    sw = tail_sizes[rp]
    pw = tail_prob[rp]
    waste = sw - r_idx * pw

    # Combine: best-fit dominates, small weight on waste tie-break.
    # Scale residual so primary term is much larger than waste differences.
    return -resid * 1000.0 - waste
# EVOLVE-BLOCK-END
