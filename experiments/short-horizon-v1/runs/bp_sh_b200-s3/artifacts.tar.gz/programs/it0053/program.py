# EVOLVE-BLOCK-START
"""Best fit with a smooth "reusable residual" tie-breaker.

Pure best fit is the strong baseline, but it can create tiny unusable
slivers. We keep the tightest-residual ordering as the primary key, and add
a small continuous bonus that gently prefers placements whose post-placement
residual stays close to a typical future item size, keeping leftover space
useful without overriding best-fit.
"""
import numpy as np

_state = {"n": 0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Track a running estimate of the mean item size to keep the target adaptive.
    m = _state["mean"]
    m = m + (item - m) / (n + 1.0)
    _state["mean"] = m

    residual = bins - item  # remaining space after placing the item

    # Primary: tightest fit (smaller residual) -> higher score.
    score = -residual.astype(np.float64)

    # Secondary: gently favor residuals that are close to a typical item size,
    # so leftover space stays reusable rather than becoming a sliver.
    # target ~ a bit less than the mean, well below capacity.
    target = 0.8 * m
    # smooth penalty for deviation from target, scaled small vs. the 1-unit
    # granularity of residual so best-fit remains dominant.
    dev = (residual - target) / 100.0
    score = score - 0.15 * dev * dev

    return score
# EVOLVE-BLOCK-END
