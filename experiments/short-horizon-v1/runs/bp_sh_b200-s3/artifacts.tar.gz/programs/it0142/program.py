# EVOLVE-BLOCK-START
"""Best fit with adaptive sliver-avoiding consolidation.

Pure best fit leaves many small slivers for this Weibull-shaped distribution.
The main loss comes from placements that leave a residual too small to host a
typical future item. When the best-fit choice would produce such a wasteful
sliver, we instead pick the bin whose resulting residual is the smallest one
that is still useful (>= a modest threshold), consolidating leftovers.

The rule is smooth and item-size aware, avoiding noisy periodic bursts.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Base: best-fit priority (tighter residual -> higher score).
    better_fit = -(bins - item)
    resid = bins - item  # remaining after placing (>= 0)

    # A residual below this threshold is likely unusable by the next items.
    threshold = 0.5 * _MEAN  # ~20

    # If the best-fit residual would be a wasteful sliver, prefer the bin
    # whose residual is the smallest still-useful value (closest to threshold
    # from above), consolidating near-empty space.
    best_fit_idx = int(np.argmax(better_fit))
    best_fit_resid = resid[best_fit_idx]

    if item < 60 and best_fit_resid < threshold:
        # Prefer residuals at or just above the threshold; among those take
        # the tightest (smallest) usable residual to maximize fill.
        above = resid >= threshold
        if np.any(above):
            # Score: high for residuals just above threshold, penalize larger.
            score = np.where(above, -np.abs(resid - threshold), -1e6)
            return score * 100.0 + better_fit

    return better_fit
# EVOLVE-BLOCK-END
