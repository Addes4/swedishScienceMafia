# EVOLVE-BLOCK-START
"""Best fit with a small, targeted diversification only when it matters.

Pure best-fit is very strong here. The plateau it hits is largely due to
occasionally packing an item into a bin and leaving a tiny unusable sliver
while a slightly larger residual elsewhere could still hold a future
mean-sized item. We therefore keep best-fit scoring but, when the chosen
residual is extremely small (a "wasted sliver"), slightly prefer a less-full
bin among those that are still a reasonably tight fit.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    residual = bins - item          # >= 0 for all shown bins
    score = -residual.astype(np.float64)

    # Identify the tightest fit and its residual.
    best = residual.min()

    # Only intervene when best-fit would create a wasteful tiny sliver.
    if best < 5:
        # Prefer, among the reasonably tight bins, the one leaving more room
        # for a future mean-sized (~40) item, i.e. larger residual, but cap the
        # reward so we never drift far from best-fit.
        boost = np.minimum(residual, 40).astype(np.float64)
        score = score + 0.15 * boost

    return score
# EVOLVE-BLOCK-END
