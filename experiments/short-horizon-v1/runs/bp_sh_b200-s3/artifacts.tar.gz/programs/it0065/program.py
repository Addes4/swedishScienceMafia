# EVOLVE-BLOCK-START
"""Best fit with a sliver-avoiding residual shaping.

Pure best fit packs tightly but creates many unusable slivers. We score bins
by their post-placement residual, but prefer residuals that are either nearly
full (small residual) or that can still hold a typical (mean-sized) item.
This is a stateless shaping of the best-fit rule and needs no periodic hack.
"""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placing (>= 0)

    # Base: best fit (tighter residual -> higher score).
    score = -resid.astype(np.float64)

    # Bonus for residuals that are close to a multiple of the mean item size,
    # so leftover space stays usable instead of becoming a wasted sliver.
    m = np.round(resid / _MEAN)
    dist = np.abs(resid - m * _MEAN)
    score += 0.15 * (1.0 - dist / (_MEAN * 0.5))

    return score
# EVOLVE-BLOCK-END
