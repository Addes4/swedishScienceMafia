# EVOLVE-BLOCK-START
"""Best-fit with bounded worst-fit tie-break.

Pure best fit (smallest post-placement residual) packs tightly but often
creates tiny slivers. Here we find the tightest fit, then among all bins
whose residual is within a small tolerance of that tightest fit, choose the
one with the LARGEST residual. This keeps tight packing while leaving more
usable space in the chosen bin, reducing fragmentation.
"""
import numpy as np

_state = {"n": 0}
_TOL = 3.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placement (>= 0 shown)
    min_resid = resid.min()
    # Among near-tightest bins, prefer the largest residual (worst fit).
    # Method: score = residual, but only bins within tolerance are eligible;
    # ineligible bins get a large negative score.
    eligible = resid <= (min_resid + _TOL)
    scores = np.where(eligible, resid, -1e6)
    return scores
# EVOLVE-BLOCK-END
