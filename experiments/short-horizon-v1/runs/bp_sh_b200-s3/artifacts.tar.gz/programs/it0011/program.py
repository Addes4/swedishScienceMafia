# EVOLVE-BLOCK-START
"""Best fit with a soft, deterministic perturbation for tie/near-tie breaking.

Pure best fit is a strong baseline for this distribution but can sit on a
plateau. Instead of occasionally jumping to the least-full bin (which is too
disruptive), we add a tiny deterministic jitter to the best-fit ordering so
that near-ties are sometimes resolved toward slightly larger residuals. This
keeps best-fit's core behavior while gently diversifying placements.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Best-fit priority: tighter fit (smaller residual) -> higher score.
    residual = bins - item
    score = -residual.astype(np.float64)

    # Tiny deterministic jitter that scales with residual magnitude, so
    # near-ties may favor slightly larger residuals without changing the
    # dominant best-fit ordering.
    k = np.arange(bins.shape[0], dtype=np.float64)
    jitter = ((k * 2654435761.0 + n * 40503.0) % 1000.0) / 1000.0 - 0.5
    score = score + 0.2 * jitter * (1.0 + residual / 100.0)

    return score
# EVOLVE-BLOCK-END
