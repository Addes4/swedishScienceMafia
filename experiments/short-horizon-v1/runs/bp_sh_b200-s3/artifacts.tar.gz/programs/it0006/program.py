# EVOLVE-BLOCK-START
"""Follow-up-aware rule: prefer residuals close to the item mean (~40)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    target = 40.0
    # Prefer residuals near the target so remaining space stays usable;
    # small residuals (tight fits) get penalized.
    return -(residual - target) ** 2
# EVOLVE-BLOCK-END

