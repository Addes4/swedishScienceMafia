# EVOLVE-BLOCK-START
"""Best fit with fullness-aware tie-breaking.

Pure best-fit ranks bins by post-placement residual. Ties (equal residual)
are common and are currently broken by bin index. Instead, among tied bins we
prefer the one with the smallest current remaining capacity (the fullest bin),
so nearly-full bins get closed out and larger open gaps are preserved for
future items.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item          # remaining after placing (>= 0 shown)
    # Dominant term: smaller residual -> higher score (best fit).
    primary = -resid
    # Tiny tie-break: smaller current capacity -> higher score.
    tiebreak = -bins * 1e-6
    return primary + tiebreak
# EVOLVE-BLOCK-END
