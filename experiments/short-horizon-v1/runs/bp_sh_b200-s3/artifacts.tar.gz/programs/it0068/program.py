# EVOLVE-BLOCK-START
"""Best fit with sliver-avoidance penalty.

Pure best fit packs tightly but tends to leave tiny residuals that can no
longer hold a typical (~mean-sized) item. We keep best-fit as the primary
signal but subtract a penalty whenever the post-placement residual is
smaller than the mean item size, so among similarly tight bins we prefer
one whose leftover can still accommodate a typical item. This consolidates
fragmentation without waiting for a periodic trigger.
"""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placing (>= 0)

    # Primary: best-fit (tighter residual -> higher score).
    better_fit = -resid

    # Penalty for residuals that are too small to hold a mean-sized item.
    sliver = np.maximum(_MEAN - resid, 0.0)

    return better_fit - 0.15 * sliver
# EVOLVE-BLOCK-END

