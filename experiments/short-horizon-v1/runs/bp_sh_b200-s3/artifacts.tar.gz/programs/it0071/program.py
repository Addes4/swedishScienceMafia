# EVOLVE-BLOCK-START
"""Best-fit variant favoring residuals that remain useful.

For a Weibull-shaped item distribution with mean ~40, pure best-fit creates
many small unusable slivers. Instead of always minimizing the post-placement
residual, we prefer the bin that leaves the *smallest* residual, unless that
residual is a small sliver below the typical minimum item size; in that case
we prefer the bin whose residual is closest to (but not exceeding) a full
typical item slot, keeping bins usable for future items.
"""
import numpy as np

_MEAN = 40.0
_MIN = 8.0  # approximate small-item cutoff for this distribution


def priority(item, bins):
    resid = bins - item  # remaining after placement, all >= 0

    # Primary: best-fit (smaller residual is better).
    better_fit = -resid.astype(np.float64)

    # Penalize residuals that are small slivers (below the typical min item),
    # since those bins are effectively dead; prefer residuals just above _MIN.
    sliver = np.clip(_MIN - resid, 0.0, None)

    return better_fit - 0.5 * sliver
# EVOLVE-BLOCK-END


