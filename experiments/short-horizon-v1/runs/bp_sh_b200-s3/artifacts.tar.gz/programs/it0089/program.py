# EVOLVE-BLOCK-START
"""Best-fit with a small worst-fit tilt to avoid sliver creation.

Pure best fit greedily closes the tightest bin, but for a broad Weibull-like
item distribution this frequently leaves small unusable slivers in many bins.
We keep best-fit as the dominant rule (smaller post-placement residual ranks
higher) but add a small tilt toward bins that retain more room, so among
near-equal fits the bin leaving slightly more capacity is chosen. This spreads
items just enough to reduce sliver-driven bin growth without fully wasting
space as pure worst-fit would.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placing (all >= 0)
    # Dominant term: best fit (prefer smaller residual).
    # Secondary term: small tilt toward larger residual to avoid slivers.
    return -resid + 0.05 * resid
# EVOLVE-BLOCK-END


