# EVOLVE-BLOCK-START
"""Best fit with a bounded consolidation tie-break.

Pure best fit is a strong baseline for this distribution. It leaves many
small slivers, however. Here we keep best-fit as the primary criterion but
add a small bonus that favors residuals close to a multiple of the mean item
size, applied only within a narrow window around the tightest fit so that we
never sacrifice a genuinely better fit just to consolidate.
"""
import numpy as np

_MEAN = 40.0
_WINDOW = 6.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placing (>= 0 as shown)

    # Primary: best fit, tighter residual gets a higher score. Scale so the
    # consolidation bonus can never overturn a real fit difference beyond the
    # window.
    best = resid.min()
    better_fit = -resid

    # Consolidation bonus: prefer residuals near a multiple of the mean item
    # size, but only for bins whose residual is within _WINDOW of the best.
    near = resid <= best + _WINDOW
    m = np.round(resid / _MEAN)
    dist = np.abs(resid - m * _MEAN)
    bonus = np.where(near, -dist * 0.02, 0.0)

    return better_fit + bonus
# EVOLVE-BLOCK-END


