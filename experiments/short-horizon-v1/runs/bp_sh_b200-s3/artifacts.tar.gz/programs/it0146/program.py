# EVOLVE-BLOCK-START
"""Sliver-aware best fit with mean-modulo consolidation.

Best fit is the default and dominates: tighter residual -> higher score. To
avoid creating tiny unusable slivers, small items get a soft bonus for leaving
a residual near a multiple of the running mean item size, which consolidates
fragments into fuller slots. The bonus is scaled by item smallness so mid and
large items behave like pure best fit.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}
_MEAN0 = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    s = _state
    s["sum"] += item
    s["n"] += 1
    mean = s["sum"] / s["n"]

    better_fit = -(bins - item)

    # Only smaller items tend to form slivers; give them a consolidation bonus.
    if item <= mean:
        resid = bins - item  # remaining after placing (>= 0)
        m = np.round(resid / mean)
        dist = np.abs(resid - m * mean)
        # Weight: stronger for small items relative to the running mean.
        w = 1.0 - item / mean
        return better_fit - w * dist

    return better_fit
# EVOLVE-BLOCK-END

