# EVOLVE-BLOCK-START
"""Best fit with a tie-break that prefers the fullest bin.

Classic Best Fit: choose the bin whose residual after placement is smallest.
When several bins yield the same residual, the harness breaks ties by bin
index, which is arbitrary. Instead we prefer, among equal residuals, the bin
that was fuller before placement (smaller remaining capacity), concentrating
load into already-used bins and leaving emptier bins untouched for later large
items. This is a purely local, deterministic rule with no fragile state.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    residual = bins - item          # remaining capacity after placing (>= 0)
    # Primary: smaller residual is better -> use negative residual.
    # Tie-break: among equal residuals prefer the bin with smaller current
    # remaining capacity (fuller bin).  bins is int64; scale the tie-break so
    # it never overrides the primary ordering.
    return -(residual * 1000 + bins)
# EVOLVE-BLOCK-END


