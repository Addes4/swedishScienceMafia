# EVOLVE-BLOCK-START
"""Best fit with a tiny secondary preference for residuals that remain useful."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for bins the item fits in
    # Primary: tightest fit (smallest residual).
    # Secondary: tiny bonus for residuals that are not in the "awkward" small range,
    # which slightly reduces fragmentation without disturbing best-fit ordering much.
    r = residual.astype(np.float64)
    bonus = 1e-3 * (r / 100.0)
    return -r + bonus
# EVOLVE-BLOCK-END
