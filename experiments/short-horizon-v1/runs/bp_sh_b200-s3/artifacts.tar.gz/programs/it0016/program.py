# EVOLVE-BLOCK-START
"""Best fit with a small penalty for leaving an unusable residual.

Pure best fit tends to create many bins with tiny leftover residuals that no
future item can fit into, wasting capacity. Here we keep best fit as the
primary rule but slightly penalize placements that leave a "dead" residual
(larger than zero but smaller than a typical small item), encouraging bins
that end up either nicely full or still usable.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    residual = bins - item  # remaining capacity after placing the item

    # Base: best fit (prefer smallest residual). Larger score = better.
    score = -residual.astype(np.float64)

    # Penalize residuals in the "dead zone": >0 but too small to fit a
    # typical small item (~10). Such placements waste the bin's remaining room.
    dead = (residual > 0) & (residual < 10)
    score = score - 5.0 * dead.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
