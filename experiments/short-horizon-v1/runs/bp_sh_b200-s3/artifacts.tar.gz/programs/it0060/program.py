# EVOLVE-BLOCK-START
"""Best fit with sliver-aware modulo-consolidation diversion.

Pure best fit leaves many small slivers for this distribution. Rather than a
periodic diversion that fires regardless of context, we detect the cases that
actually create unusable slivers: placements whose resulting residual is
positive but smaller than a typical item (~40). In those cases we instead
prefer the bin whose residual after placement is closest to a multiple of the
mean item size, which keeps leftovers packable. Otherwise we use best fit.
"""
import numpy as np

_STATE = {"n": 0}
_MEAN = 40.0
_MEAN_INT = 40


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    _STATE["n"] += 1

    # Best-fit priority: tighter residual -> higher score.
    best_fit = -(bins - item)

    # Best-fit residual for the chosen bin would be bins_min - item.
    # We can detect whether best fit's residual is a sliver by looking at the
    # smallest residual among eligible bins.
    residual = bins - item
    min_resid = int(residual.min())

    # A "sliver" is a positive leftover too small for a typical item.
    is_sliver = 0 < min_resid < _MEAN_INT

    if is_sliver:
        # Prefer residual close to a multiple of the mean item size.
        m = np.round(residual / _MEAN)
        dist = np.abs(residual - m * _MEAN)
        # Slight tie-break toward tighter fits via tiny best-fit component.
        return -dist - 1e-3 * residual

    return best_fit
# EVOLVE-BLOCK-END
