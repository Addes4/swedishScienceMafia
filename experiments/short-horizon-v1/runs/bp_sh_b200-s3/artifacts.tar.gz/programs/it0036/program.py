# EVOLVE-BLOCK-START
"""Best fit with occasional randomized diversification toward least-full bins.

Pure best fit gets stuck on a plateau for this distribution. A small,
adaptive amount of randomized exploration can help avoid the worst
fragmentation patterns without abandoning the strong best-fit baseline.
"""
import numpy as np

_state = {"rng": np.random.RandomState(12345)}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    rng = _state["rng"]

    # Best-fit priority: tighter fit (smaller residual) -> higher score.
    score = -(bins - item)

    # With a small probability, prefer the least-full fitting bin instead,
    # to diversify placement decisions and escape fragmentation plateaus.
    if rng.rand() < 0.04:
        score = score + 1000.0 * (bins / 100.0)

    return score
# EVOLVE-BLOCK-END

