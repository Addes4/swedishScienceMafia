# EVOLVE-BLOCK-START
"""Best fit with a targeted diversion for tiny items.

Pure best fit is a strong baseline for this distribution, but placing very
small items into nearly-full bins seals off residual gaps that could still
hold future medium/large items. For those tiny items only, periodically
prefer a less-full bin instead, preserving tight fits for everything else.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Best-fit priority: tighter fit (smaller residual) -> higher score.
    score = -(bins - item)

    # Only for small items, and only occasionally, divert to a less-full bin
    # so we do not waste near-full bins on tiny items.
    if item <= 12 and (n % 7 == 3):
        score = score + 1000.0 * (bins / 100.0)

    return score
# EVOLVE-BLOCK-END
