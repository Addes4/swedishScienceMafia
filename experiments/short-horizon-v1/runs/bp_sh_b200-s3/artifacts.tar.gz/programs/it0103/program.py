# EVOLVE-BLOCK-START
"""Best fit with stateful residual-matching bonus.

Pure best fit ignores that a residual equal to a common item size can later
be filled exactly. We keep best-fit as the dominant term and add a small
bonus when the post-placement residual matches a frequently-seen past item
size. State is a fixed-size histogram (sizes 1..100); no dynamic indexing.
"""
import numpy as np

_state = {"n": 0, "hist": np.zeros(101, dtype=np.float64)}
_DECAY = 0.99
_W = 3.0  # weight of the residual-matching bonus relative to best-fit


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    hist = _state["hist"]
    # Decay old counts so the histogram tracks the recent stream.
    hist *= _DECAY
    # Record the arriving item.
    hist[int(item)] += 1.0
    _state["n"] += 1

    # Dominant term: best fit (smaller post-placement residual is better).
    resid = bins - item  # remaining after placing, >= 0 for shown bins
    better_fit = -resid

    # Bonus: reward residuals that are common past item sizes (fillable later).
    idx = np.clip(resid.astype(np.int64), 0, 100)
    match = hist[idx]

    return better_fit + _W * match
# EVOLVE-BLOCK-END
