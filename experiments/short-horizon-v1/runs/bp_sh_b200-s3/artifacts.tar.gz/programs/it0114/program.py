# EVOLVE-BLOCK-START
"""Best fit with a soft residual-reusability bonus.

Pure best fit is a strong baseline for this distribution, but it tends to
create many tiny slivers that no future item can use.  We keep best-fit as
the dominant term and add a small, bounded secondary bonus that prefers
post-placement residuals which are close to a canonical reusable size: the
running mean item size (~40).  The bonus is always on (no fragile periodic
diversion), stays strictly below one unit of residual so it only acts as a
tie-break among equally good fits, and is cheap to compute.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}
_MEAN0 = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    s = _state
    n = s["n"]
    s["n"] = n + 1
    s["sum"] += item
    mean = s["sum"] / (n + 1)

    # Dominant term: best fit (tighter residual -> higher score).
    resid = bins - item  # remaining after placing this item (>= 0)
    fit = -resid.astype(np.float64)

    # Soft secondary bonus: prefer residuals close to a reusable canonical
    # size (running mean), so gaps stay usable by future items.  Bounded in
    # [-0.5, 0] so it only breaks ties between equal-residual bins.
    m = np.round(resid / mean)
    dist = np.abs(resid - m * mean)
    bonus = -0.5 * (dist / mean)

    return fit + bonus
# EVOLVE-BLOCK-END
