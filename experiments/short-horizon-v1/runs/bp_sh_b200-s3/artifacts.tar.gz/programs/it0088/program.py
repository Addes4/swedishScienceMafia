# EVOLVE-BLOCK-START
"""Best fit with a deterministic, stateless parity tie-break.

Pure best fit already scores ~0.945. Empirically, its main loss comes from
leaving many mid-sized slivers that no later item can fill exactly. Tie
situations in best fit (same post-placement residual) are common because
residuals are integers; the index order then decides, which is arbitrary and
correlated across streams. We keep best fit as the primary rule but break
near-ties by a deterministic function of the bin's remaining capacity and the
item size, so that equal-residual bins are distinguished in a way that spreads
placements across different residual classes rather than always picking the
earliest bin.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Primary: best fit -> smaller residual is better.
    score = -resid.astype(np.float64)

    # Secondary, well below the primary gap of 1: among equal residual bins,
    # prefer those whose pre-placement residual (bins) mod item is larger,
    # which tends to select bins whose leftover aligns less trivially with
    # common item sizes and thus reduces fragmentation of mid-size slivers.
    mod = bins % max(item, 1)
    score += 1e-3 * mod.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

