# EVOLVE-BLOCK-START
"""Best-fit with residual consolidation toward canonical gaps.

For a Weibull-like item distribution (mean ~40), pure best-fit is strong but
leaves scattered small residuals. We keep best-fit as the primary signal and
break near-ties by preferring bins whose post-placement residual aligns with
a canonical "fillable" residual, encouraging consolidation into fewer bins.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0
# Canonical residual targets: near-full (0) plus typical remaining gaps.
_TARGETS = np.array([0.0, 10.0, 20.0, 30.0, 40.0, 50.0, 60.0])


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Primary: best-fit -> tighter residual is better.
    better_fit = -resid

    # Consolidation bonus: distance of residual to nearest canonical target.
    d = np.min(np.abs(resid[:, None] - _TARGETS[None, :]), axis=1)

    if n % 50 == 17:
        return -d

    # Always-on: small tie-break bonus for canonical residuals among tight fits.
    best = resid.min()
    eps = 3.0
    bonus = np.where(resid <= best + eps, -0.5 * d, 0.0)
    return better_fit + bonus
# EVOLVE-BLOCK-END
