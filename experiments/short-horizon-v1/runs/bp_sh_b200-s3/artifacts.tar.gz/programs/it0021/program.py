# EVOLVE-BLOCK-START
"""Consolidating best fit.

Strict best-fit on this distribution leaves many bins with tiny residuals that
can never be used again.  Among placements whose post-placement residual is
essentially the same (a near-tie), we instead prefer the bin that is already
fuller: putting the item where it packs most tightly leaves the emptier bins
untouched, so their large free space remains available for future mean-sized
(~40) items.  This consolidates free space and reduces the number of wasted,
nearly-empty bins.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    # Post-placement residual: smaller is a tighter fit (primary criterion).
    residual = bins - item

    # Near-tie tolerance: residuals within this window are treated as equally
    # good fits, so we can break ties by consolidation instead of by a few
    # wasted units of residual.
    tol = 3.0

    best = residual.min()
    near = residual <= (best + tol)

    # For near-ties, prefer the bin that is already fuller (smaller remaining
    # capacity before placement = larger consumed), i.e. keep the emptiest
    # bins free for future items.
    consolidate = -(bins.astype(float))

    score = np.where(near, 1000.0 + consolidate, -residual)
    return score
# EVOLVE-BLOCK-END
