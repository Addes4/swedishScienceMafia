# EVOLVE-BLOCK-START
"""Best fit with a tiny fullness tie-break.

Pure best fit minimizes the residual left after placement, which is a strong
baseline for this distribution. As a deterministic tie-break among bins with
(nearly) equal residual, prefer bins that are already fuller, since packing
into an already-used bin slightly reduces fragmentation risk. The bonus is
scaled strictly below the smallest unit residual difference so it never
overrides the primary best-fit ordering.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Best-fit primary: tighter fit (smaller residual) -> higher score.
    residual = bins - item
    score = -residual.astype(np.float64)

    # Tiny tie-break: prefer fuller bins (smaller pre-placement remaining
    # capacity), scaled below 1 unit so it only breaks near-exact ties.
    score += (100.0 - bins.astype(np.float64)) * 1e-3

    return score
# EVOLVE-BLOCK-END
