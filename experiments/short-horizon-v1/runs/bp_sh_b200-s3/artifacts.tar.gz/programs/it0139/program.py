# EVOLVE-BLOCK-START
"""Best fit with adaptive sliver-filling diversion.

Pure best fit leaves many small slivers. On some steps we divert to the bin
whose residual after placement is smallest among bins that leave a usable
gap, tightening nearly-full bins. Best-fit stays dominant otherwise.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Base: best-fit priority (tighter residual -> higher score).
    better_fit = -(bins - item)

    # Divert mainly when small items are arriving (these create slivers),
    # using a fractional phase to spread consolidation evenly.
    if item < 60 and (n % 3 == 0):
        resid = bins - item  # remaining after placing (>= 0)
        # Prefer the smallest non-negative residual: tightly fills bins.
        return -resid * 100.0 + better_fit

    return better_fit
# EVOLVE-BLOCK-END
