# EVOLVE-BLOCK-START
"""Best fit with tiny closing/fresh-bin tie-break.

Pure best fit is the strong baseline for this distribution. We add a very
small epsilon-weighted secondary term that, strictly among near-equal fits,
prefers bins that either close to near-zero residual or start fresh near
capacity, which tends to reduce slivers without disturbing the primary
best-fit ordering.
"""
import numpy as np

_MEAN = 40.0
_EPS = 1e-3


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining after placing (>= 0 shown)

    # Primary: best fit (tighter residual -> higher score).
    best = -resid.astype(np.float64)

    # Secondary: prefer bins that close (residual ~ 0) or start fresh (~100).
    # Scaled by _EPS so it only breaks near-ties.
    to_zero = -np.abs(resid - 0.0)
    to_full = -np.abs(resid - 100.0)
    sec = np.maximum(to_zero, to_full) / 100.0

    return best + _EPS * sec
# EVOLVE-BLOCK-END
