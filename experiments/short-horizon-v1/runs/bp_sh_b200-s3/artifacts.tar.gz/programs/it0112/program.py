# EVOLVE-BLOCK-START
"""Best fit with a fullness tie-break.

Pure best fit minimizes the post-placement residual, which is a very strong
rule for this distribution.  Ties (equal residual) are common and the default
bin-index tie-break is arbitrary.  We break ties toward the bin that is
currently fullest (smallest remaining capacity before placement), which tends
to close out nearly-full bins and keep larger open gaps available for future
items.  A tiny epsilon keeps best-fit dominant while resolving ties.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item                      # residual after placing (>= 0)
    # Dominant term: prefer smallest residual (best fit).
    # Secondary epsilon: among equal residuals, prefer smallest current capacity.
    return -resid.astype(np.float64) - 1e-3 * bins
# EVOLVE-BLOCK-END

