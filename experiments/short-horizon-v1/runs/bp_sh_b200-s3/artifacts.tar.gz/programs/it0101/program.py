# EVOLVE-BLOCK-START
"""Best fit with online subset-sum residual matching.

Pure best fit is the baseline. To reduce slivers, we maintain an online
histogram of post-placement residuals that were later exactly filled, and
add a small always-on bonus for residuals likely to be filled by a future
item of the same size distribution. This is deterministic and stateful,
exploiting the discrete item sizes without randomness.
"""
import numpy as np

_MEAN = 40.0
# Online counts of how often each residual bucket was exactly filled later.
_FILLED = np.zeros(101, dtype=np.float64)
# Recently observed item sizes (bucketed), signed by how recently seen.
_RECENT = np.zeros(101, dtype=np.float64)
_state = {"prev": -1}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    # Update recency of item sizes (exponential decay, deterministic).
    _RECENT *= 0.97
    _RECENT[item] += 1.0

    # If the previous item landed somewhere, record the residual it filled.
    prev = _state["prev"]
    if 0 <= prev <= 100:
        _FILLED[prev] += 1.0
    _state["prev"] = -1

    # Base: best fit (smaller post-placement residual -> higher score).
    resid = bins - item
    better_fit = -resid

    # Bonus: residual that equals a likely future item size.
    future_boost = _RECENT.copy()
    # A residual r is good if a future item of size ~r can fill it exactly.
    # Score residual r by recency mass around r.
    bonus = future_boost[resid.astype(np.int64)]

    # Also small bonus proportional to exact-fill history of that residual.
    bonus += 0.5 * _FILLED[resid.astype(np.int64)]

    return better_fit + 0.05 * bonus
# EVOLVE-BLOCK-END
