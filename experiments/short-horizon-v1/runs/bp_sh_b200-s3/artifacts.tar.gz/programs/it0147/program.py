# EVOLVE-BLOCK-START
"""Best fit with a self-tuning sliver-avoidance / consolidation bonus.

Pure best fit leaves many unusable slivers for this Weibull-ish distribution.
We keep best-fit as the backbone but add a smooth, always-on adjustment that
nudges residuals toward the mean (a "roomy but consolidating" leftover) and
penalizes leaving a small dead-zone sliver below the smallest item size seen
so far, so we avoid creating residuals that can never be reused well.
"""
import numpy as np

_state = {"n": 0, "min_seen": 100}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    _state["n"] += 1
    if item < _state["min_seen"]:
        _state["min_seen"] = item

    resid = bins - item  # remaining capacity after placing here (>= 0)

    # Backbone: best fit (smaller residual -> higher score).
    better_fit = -resid

    # Smooth bonus: prefer residuals close to the mean (a good reusable size),
    # and strongly penalize residuals in the wasteful dead-zone just below the
    # smallest item size we have ever seen (such slivers can't be reused).
    dead = _state["min_seen"]
    near_mean = -np.abs(resid - _MEAN)
    sliver_pen = np.where((resid > 0) & (resid < dead), -1000.0, 0.0)

    return better_fit + 0.5 * near_mean + sliver_pen
# EVOLVE-BLOCK-END
