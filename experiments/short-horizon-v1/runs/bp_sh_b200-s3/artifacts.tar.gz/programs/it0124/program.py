# EVOLVE-BLOCK-START
"""Best fit with sparse modulo-consolidation diversion.

Pure best fit is very strong for this Weibull-shaped distribution. Its main
weakness is leaving slivers. We keep best-fit as the default and, on a sparse
schedule, divert to the bin whose post-placement residual is closest to a
multiple of a typical item size, which consolidates leftovers. We restrict
the diversion to small items so that big items never destabilize the packing.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Base: best-fit priority (tighter residual -> higher score).
    better_fit = -(bins - item)

    # Sparse diversion, only for small items, to consolidate slivers.
    if item <= 30 and n % 37 == 17:
        resid = bins - item  # remaining after placing (>= 0 shown)
        # Distance of residual to nearest multiple of _MEAN.
        m = np.round(resid / _MEAN)
        dist = np.abs(resid - m * _MEAN)
        # Prefer residual close to a multiple of _MEAN, with best-fit as a
        # gentle tie-breaker so behavior stays near pure best fit.
        return -dist - 1e-3 * (bins - item)

    return better_fit
# EVOLVE-BLOCK-END
