# EVOLVE-BLOCK-START
"""Best fit with sliver-triggered perfect-fill diversion.

Pure best fit leaves many wasteful slivers for this distribution. Instead of a
blind periodic diversion, we only divert when the best-fit choice would leave a
"dead-zone" residual just below the mean item size (a sliver too small to be
usefully filled later). On those steps we pick the bin giving the closest to a
perfect fill (residual nearest zero), consolidating fragments into tight bins.
Best-fit stays dominant otherwise.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Base: best-fit priority (tighter residual -> higher score).
    better_fit = -(bins - item)

    # Only consider diversion for smaller items (where slivers form).
    if item < 60:
        resid = bins - item  # remaining after placing (>= 0)
        # The best-fit bin's resulting residual (smallest non-negative resid).
        best_resid = np.min(resid)
        # Trigger only if best-fit leaves a wasteful sliver just below the mean:
        # too small to fit another typical item, but too large to be "tight".
        dead_lo, dead_hi = 8.0, _MEAN
        if dead_lo <= best_resid <= dead_hi:
            # Divert: prefer near-perfect fills (residual closest to zero).
            return -resid.astype(np.float64) * 100.0 + better_fit

    return better_fit
# EVOLVE-BLOCK-END

