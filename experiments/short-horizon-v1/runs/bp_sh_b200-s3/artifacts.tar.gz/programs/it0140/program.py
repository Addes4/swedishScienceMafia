# EVOLVE-BLOCK-START
"""Best fit with sliver-avoiding diversion.

Pure best fit tends to leave bins with small unusable residuals (slivers) for
this Weibull-shaped distribution (mean ~40). On a fraction of steps we divert
to a score that penalizes creating a residual which is too small to be useful
but nonzero, and mildly rewards residuals near the mean item size so leftovers
stay packable. Best-fit dominates otherwise.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Base: best-fit priority (tighter residual -> higher score).
    better_fit = -(bins - item)

    # Divert on a sparse, evenly-spread set of steps, mainly for smaller
    # items (these are what create slivers when packed into tight bins).
    if item < 60 and (n % 3 == 0):
        resid = bins - item  # remaining after placing (>= 0)

        # Penalize tiny nonzero residuals (wasted slivers).
        sliver = np.where((resid > 0) & (resid < 15), 1.0, 0.0)

        # Reward residuals near the mean item size (packable leftovers).
        reward = -np.abs(resid - _MEAN) / _MEAN

        return -sliver * 50.0 + reward * 10.0 + better_fit

    return better_fit
# EVOLVE-BLOCK-END
