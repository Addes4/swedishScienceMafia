# EVOLVE-BLOCK-START
"""Best fit with occasional worst-fit diversion.

Pure best fit is a very strong online rule for Weibull-shaped items with
mean ~40. However it tends to leave a long tail of tiny slivers. On a small,
deterministic fraction of arrivals we instead pick the emptiest fitting bin
(worst-fit), which lets later small items fill gaps and can reduce the total
number of bins. Best-fit stays the baseline for the majority of items.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    if n % 11 == 5:
        # Worst-fit: prefer the emptiest fitting bin (largest residual).
        return bins

    # Best-fit: prefer the tightest fitting residual.
    return -(bins - item)
# EVOLVE-BLOCK-END

