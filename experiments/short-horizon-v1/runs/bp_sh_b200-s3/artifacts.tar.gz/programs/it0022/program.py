# EVOLVE-BLOCK-START
"""Best fit biased toward leaving a usable (fillable) residual.

Items are Weibull-shaped with mean ~40. Best fit alone leaves many bins with
tiny residuals that no future item can fill. We keep best-fit as the dominant
term but nudge the choice toward bins whose post-placement residual is a
"characteristic" size, i.e. one that a future item can actually use.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    _state["n"] += 1

    residual = bins - item  # >= 0 for all shown bins

    # Primary: best fit (smaller residual -> higher score).
    score = -residual.astype(np.float64)

    # Secondary nudge: prefer residuals that leave a fillable bin.
    # A residual near a typical item size (mean ~40) can still be filled;
    # a near-zero residual wastes the bin.
    usable = -((residual - 40.0) ** 2) / 2000.0
    score = score + usable

    return score
# EVOLVE-BLOCK-END

