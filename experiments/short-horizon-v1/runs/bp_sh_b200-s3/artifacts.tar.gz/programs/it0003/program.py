# EVOLVE-BLOCK-START
"""Best fit with a mild penalty for leaving a nearly-unusable residual.

Items are Weibull-shaped (mean ~40) with a tail of small items. Pure best fit can
leave tiny residuals in bins that no future small item will fit into, wasting
capacity. We keep best-fit's tightness preference but add a small bonus for
residuals that remain large enough to host a plausible future item, so ties and
near-ties are broken toward bins whose leftover space stays useful.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since these bins fit the item

    # Core: best fit prefers the smallest residual (tightest fit).
    score = -residual.astype(np.float64)

    # Mild nudge: reward residuals big enough to hold a plausible future small item.
    # Residuals of 0 are fine (perfect fit). We only tilt comparisons when the
    # leftover is very small but nonzero, favoring a slightly less tight bin whose
    # leftover stays usable. Scale small so it barely perturbs genuine tightness gaps.
    tiny = (residual > 0) & (residual < 10)  # leftover too small to matter yet wasted
    score = score - 0.5 * tiny

    return score
# EVOLVE-BLOCK-END
