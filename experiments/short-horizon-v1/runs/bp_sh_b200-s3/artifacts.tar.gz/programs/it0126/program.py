# EVOLVE-BLOCK-START
"""Best fit with a robust residual-shaping tie-break for small items.

Pure best fit is strong for this Weibull-ish distribution, but it tends to
isolate tiny slivers that later small items can't fill efficiently.  We keep
best-fit dominant (it decides among the "big" residuals) and add a small
always-on bonus for post-placement residuals that coincide with the most
common small item sizes.  This gently consolidates slivers into usable
residuals without the fragile periodic diversion that hurt earlier.
"""
import numpy as np

_TARGETS = np.array([1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0, 13.0], dtype=float)


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    post = bins - item                       # residual after placing (>= 0)
    # Base: best-fit (smaller residual -> higher score).
    score = -post.astype(float)

    # Always-on gentle reward for residuals matching common small item sizes.
    d = np.abs(post[:, None] - _TARGETS[None, :]).min(axis=1)
    score += 0.5 * (d <= 0.5)                # tiny bonus, near-ties only

    return score
# EVOLVE-BLOCK-END


