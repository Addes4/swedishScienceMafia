# EVOLVE-BLOCK-START
"""Best-fit with a subset-sum-aware secondary term.

For Weibull-shaped item sizes (mean ~40), pure best fit creates many
slivers. A useful signal is whether the residual left after placing an item
matches a value likely to be needed later. We keep best-fit as the primary
rank (small residual preferred) but add a small always-on bonus when the
post-placement residual is close to zero or close to a "useful" size learned
from the running stream. This gently consolidates leftovers without ever
overriding a genuinely better tight fit.
"""
import numpy as np

_state = {"n": 0, "seen": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    seen = _state["seen"]
    seen[item] += 1.0
    _state["n"] += 1

    resid = bins - item  # remaining capacity after placing (>= 0)

    # Primary: best fit -> tighter residual is better.
    score = -resid.astype(np.float64)

    # Secondary: small bonus if residual is 0 or close to a useful size.
    # "Useful" means close to 0 (fully packed) or close to values that
    # frequently appear as residuals of a good packing, approximated by
    # the running distribution of item sizes.
    total = seen.sum()
    # bonus for residual near zero
    bonus = np.where(resid <= 2, 1.0, 0.0)
    # bonus for residual roughly matching a common item size
    if total > 20:
        w = seen / total
        # closeness of residual to any common item size (weighted)
        r = resid
        closeness = w[r] * 1.0  # weight of exact residual size
        bonus = bonus + 0.5 * closeness

    return score + 0.05 * bonus
# EVOLVE-BLOCK-END
