# EVOLVE-BLOCK-START
"""Best fit with a small exact-fill bonus.

Pure best-fit (smallest post-placement residual) is a strong online rule for
this distribution. Adding a modest always-on bonus for residuals near zero
encourages exact fills (which are common with integer sizes) and slightly
reduces slivers, without the tuning fragility of periodic diversions.
"""
import numpy as np

_EXACT_BONUS = 200.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placing (>= 0 shown)
    # Best fit: tighter residual -> higher score.
    score = -resid.astype(np.float64)
    # Small bonus for near-exact fills.
    score += _EXACT_BONUS / (resid + 1.0)
    return score
# EVOLVE-BLOCK-END
