# EVOLVE-BLOCK-START
"""Best fit with a smooth residual-usefulness tie-break.

Core: put the item in the tightest fitting bin (best fit), which is a strong
online rule for this stream. To hedge against wasting bins on small residuals
and to keep medium bins usable, add a small, bounded reward for residuals that
are at least a typical future item size.
"""
import numpy as np


def priority(item, bins):
    """Return a priority per bin; highest score wins (ties to first bin).

    item: integer size of the arriving item, 1..100.
    bins: remaining capacities of feasible bins (numpy int64).
    """
    b = bins.astype(np.float64)
    residual = b - item  # capacity left after placing the item here (>= 0)

    # Primary: best fit -> smaller residual is better.
    # Use a small smoothing so ties are broken by the tie-break term.
    fit = -residual

    # Tie-break reward: mildly favor residuals that can still accept a
    # typical (mean ~40) future item, capped so it never overrides the fit.
    reward = np.minimum(residual, 40.0) / 40.0  # in [0, 1]

    return fit + 1e-3 * reward
# EVOLVE-BLOCK-END
