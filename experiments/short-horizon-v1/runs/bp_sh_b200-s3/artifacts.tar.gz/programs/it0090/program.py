# EVOLVE-BLOCK-START
"""Best-fit with online residual-match tie-break.

Pure best fit is strong, but it leaves residuals that future items cannot
fill well. We keep best-fit as the primary order but, when several bins are
nearly equally good fits, prefer the bin whose post-placement residual is
close to a commonly observed item size (so a future item can close it) or
close to zero. The histogram of past items is maintained online.
"""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0}
_DECAY = 0.999
_EPS = 1e-3


def priority(item, bins):
    hist = _state["hist"]
    n = _state["n"]
    _state["n"] = n + 1

    # Record the item we just saw.
    hist *= _DECAY
    hist[item] += 1.0

    resid = bins - item  # remaining capacity after placing (>= 0 shown)

    # Primary: best fit -> smaller residual gets higher score.
    best = -resid.astype(np.float64)

    # Secondary: reward residuals near 0 or near a common item size.
    # For each bin, look up how often a future item of size == resid occurs.
    # Also reward residuals close to any frequent item size.
    idx = np.clip(resid, 0, 100).astype(np.int64)
    close_score = hist[idx]  # exact-size demand
    # nearby sizes (residual +/- a few units) also help close the bin
    for d in (1, 2, 3, 4, 5):
        lo = np.clip(idx - d, 0, 100)
        hi = np.clip(idx + d, 0, 100)
        close_score += 0.5 * (hist[lo] + hist[hi])
    # Closing bonus: residual near zero is very valuable.
    close_score += 0.5 * hist[0] * np.exp(-resid / 2.0)

    total = hist.sum() + 1e-9
    return best + _EPS * (close_score / total)
# EVOLVE-BLOCK-END
