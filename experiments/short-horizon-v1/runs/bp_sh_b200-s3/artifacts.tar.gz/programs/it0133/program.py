# EVOLVE-BLOCK-START
"""Best fit with a smooth, always-on consolidation tie-breaker.

Pure best-fit leaves many slivers for this Weibull-shaped distribution. The
secondary term prefers bins whose residual after placement is close to a
small positive "usable" value (a multiple of a typical small item), which
keeps residuals refillable and reduces fragmentation, while best-fit remains
dominant because the tie-break is scaled by 1/100 and applied continuously.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    _state["n"] += 1

    # Base: best-fit priority (tighter residual -> higher score).
    resid = bins - item  # remaining capacity after placing (>= 0)
    better_fit = -resid

    # Smooth consolidation: prefer residuals close to a multiple of _MEAN,
    # scaled so it only refines, never overrides, best-fit ordering by fit.
    m = np.round(resid / _MEAN)
    dist = np.abs(resid - m * _MEAN)

    return better_fit - dist * (resid <= _MEAN) * 0.5
# EVOLVE-BLOCK-END
