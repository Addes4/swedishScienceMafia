# EVOLVE-BLOCK-START
"""Waste-aware best fit: prefer tight fits but avoid leaving residuals that are hard to reuse."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tighter fit (smaller residual) is better -> negative residual.
    # Secondary: among similar residuals, prefer residuals that are easy to fill later.
    # Target residual ~40 (mean item). Reward residuals near 40, and also reward
    # very large residuals (still plenty of room), penalize tiny residuals.
    target = 40.0
    # Smooth penalty for being far from target, but saturating for large residual.
    near = np.minimum(residual, 100.0).astype(np.float64)
    # Value of a residual: how many typical items it can still absorb.
    usefulness = 1.0 - np.abs(near - target) / 60.0
    # Emphasize tightness first; usefulness is only a small tie-breaker.
    return -residual.astype(np.float64) * 0.85 + usefulness
# EVOLVE-BLOCK-END

