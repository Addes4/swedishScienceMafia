# EVOLVE-BLOCK-START
"""Best fit with a soft, always-on residual-matching bonus.

Pure best fit leaves slivers for this Weibull-ish distribution (mean ~40).
We keep best fit as the dominant signal but add a small, bounded bonus that
prefers post-placement residuals close to a set of "recyclable" residual
targets: the running mean item size and a few fractions of it. The bonus is
scaled small so it only breaks near-ties, preserving best-fit stability while
gently steering leftovers into slots likely to be filled later.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1
    _state["sum"] += item
    mean = _state["sum"] / (n + 1)

    # Base: best-fit priority (tighter residual -> higher score).
    better_fit = -(bins - item)

    resid = bins - item  # remaining after placing (>= 0 shown)
    # Targets: the running mean, and a few multiples that commonly re-fit.
    t = mean
    d = np.abs(resid - t)
    d = np.minimum(d, np.abs(resid - 2.0 * t))
    d = np.minimum(d, np.abs(resid - 3.0 * t))

    # Small bounded bonus; only breaks near-ties in best fit.
    return better_fit - 0.02 * d
# EVOLVE-BLOCK-END
