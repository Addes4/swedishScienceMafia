# EVOLVE-BLOCK-START
"""Best fit with a small exact-fill bonus.

Pure best fit (choosing the bin with the smallest remaining capacity after
placing the item) is a very strong online rule for this distribution.  We keep
it as the primary ranking and only add a tiny tie-breaking bonus that prefers a
residual of exactly zero, which exploits the fact that item sizes are integers
drawn from a fixed distribution and exact fills do occur.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placing item
    # Primary: smaller residual is better (best fit).
    score = -resid.astype(np.float64)
    # Tiny bonus for an exact fill; does not disturb best-fit ordering.
    score += 1e-6 * (resid == 0)
    return score
# EVOLVE-BLOCK-END
