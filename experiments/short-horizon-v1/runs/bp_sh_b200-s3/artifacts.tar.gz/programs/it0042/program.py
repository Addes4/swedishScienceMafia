# EVOLVE-BLOCK-START
"""Best fit with a rare, size-aware worst-fit diversion.

Pure best fit is a very strong baseline for this distribution. The only
change is that, on a small deterministic fraction of arrivals, we instead
pick the least-full fitting bin. The choice of *when* to diversify depends
only on the current item size and a step counter, so it is reproducible and
does not tune to any particular stream.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Best-fit priority: tighter fit (smaller residual) -> higher score.
    score = -(bins - item)

    # Rare, deterministic worst-fit diversion keyed on item size and step.
    if ((item * 7 + n * 13) % 50) == 0:
        score = score + 1000.0 * (bins / 100.0)

    return score
# EVOLVE-BLOCK-END
