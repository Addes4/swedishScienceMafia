# EVOLVE-BLOCK-START
"""Best fit with a soft "useful residual" bonus.

Pure best fit is strong, but it can leave residuals too small to hold future
items. Since item sizes are integer, mean ~40, a residual is more valuable if
it is still large enough to accommodate a typical future item. We keep
best-fit as the primary order and add a smooth, sub-unit bonus for bins whose
residual is at least the running mean item size, which breaks near-ties
toward more reusable leftovers without disturbing clear best-fit choices.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1
    _state["sum"] += item
    mean = _state["sum"] / (n + 1)

    # Primary: best fit, tighter residual -> higher score.
    score = -(bins - item).astype(np.float64)

    # Secondary (sub-unit): reward residuals still useful for a typical item.
    # Smoothly saturates so it only perturbs near-ties.
    usefulness = np.minimum(bins / max(mean, 1.0), 1.0)
    score = score + 0.5 * usefulness

    return score
# EVOLVE-BLOCK-END

