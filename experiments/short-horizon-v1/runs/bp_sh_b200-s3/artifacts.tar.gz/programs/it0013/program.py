# EVOLVE-BLOCK-START
"""Best fit with a gentle future-fill preference.

Pure best fit is strong for this distribution but occasionally creates
residuals too small to accept typical future items (~40).  We keep the
best-fit ordering as the dominant signal, and add a small bonus to bins
whose post-placement residual is closer to the item mean, so that nearly
tied choices break toward more reusable residual capacity.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    n = _state["n"]
    _state["n"] = n + 1

    # Best-fit priority: tighter fit (smaller residual) -> higher score.
    residual = bins - item
    score = -residual.astype(np.float64)

    # Small bonus for residuals that can still hold a typical item (~40),
    # with a mild preference near the mean.
    target = 40.0
    bonus = -np.abs(residual - target) * 0.05

    score = score + bonus

    # Rare diversification toward least-full bins.
    if n % 50 == 17:
        score = score + 1000.0 * (bins / 100.0)

    return score
# EVOLVE-BLOCK-END

