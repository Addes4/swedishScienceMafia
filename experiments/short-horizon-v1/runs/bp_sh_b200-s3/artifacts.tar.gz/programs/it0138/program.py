# EVOLVE-BLOCK-START
"""Soft best-fit with smooth sliver-consolidation bias.

Pure best fit leaves tiny residues ("slivers") for this distribution. We keep
best-fit dominant but add a continuous, always-on bias that rewards bins whose
post-placement residual is close to a multiple of the mean item size (~40).
The strength of this bias grows as the arriving item gets smaller, since small
items are the ones that leave unusable slivers; large items are packed by pure
best fit. This avoids the bursty, noise-prone periodic diversion.
"""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity if item placed here (>= 0)

    # Base: best-fit priority (tighter residual -> higher score).
    better_fit = -resid.astype(np.float64)

    # Consolidation target: residual close to a multiple of the mean.
    m = np.round(resid / _MEAN)
    dist_to_multiple = np.abs(resid - m * _MEAN)

    # Bias strength: stronger for smaller items (which create slivers).
    # item ~ 1  -> weight ~ 1.5 ; item ~ 60 -> weight ~ 0.0
    w = max(0.0, (60.0 - item)) / 40.0
    return better_fit - w * dist_to_multiple
# EVOLVE-BLOCK-END
