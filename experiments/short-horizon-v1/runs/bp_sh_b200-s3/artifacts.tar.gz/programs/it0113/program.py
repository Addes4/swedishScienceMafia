# EVOLVE-BLOCK-START
"""Adaptive best-fit with sliver avoidance for small items.

Best fit is retained as the dominant rule (it performs well on this
distribution). The one structural weakness of best fit here is that small
items create tiny unusable slivers. So for small items we instead prefer the
bin whose post-placement residual is at least the running mean item size
(keeping gaps usable), falling back to best fit when no such bin exists.
For large items we keep pure best fit, which packs them tightly.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1
    _state["sum"] += item
    mean = _state["sum"] / (n + 1)

    # Base: best-fit priority (tighter residual -> higher score).
    better_fit = -(bins - item).astype(np.float64)

    # Only intervene for small items, where slivers are the problem.
    if item < mean * 0.6:
        resid = (bins - item).astype(np.float64)
        # Prefer residuals that stay at/above the mean (usable gap),
        # softly scoring how much usable room remains beyond best-fit.
        usable = resid >= mean
        score = better_fit + usable * 1e-3
        return score

    return better_fit
# EVOLVE-BLOCK-END
