# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break.

Pure best fit (minimize post-placement residual) is a strong online baseline.
The one clear failure mode is leaving a residual that exactly equals a common
item size, which then forces that item to open a fresh bin.  We keep best fit
as the dominant term but add a smooth penalty for residuals that coincide with
frequently occurring item sizes.
"""
import numpy as np

_state = {"n": 0}

# Residuals equal to these sizes are the most likely to be hit by the next
# item (distribution is Weibull-shaped with mean ~40, most mass in 20..60).
_HOT = np.array([20.0, 30.0, 40.0, 50.0, 60.0])


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    residual = bins - item  # >= 0 for fitting bins

    # Primary: tighter fit is better (negated residual).
    score = -residual.astype(np.float64)

    # Secondary: penalize leaving a residual that matches a common item size,
    # since such a residual is likely to be consumed by the very next item
    # (we would rather leave an awkward residual that the next item can't use).
    # Use a smooth bump around each hot value.
    pen = np.zeros_like(score)
    for h in _HOT:
        pen += np.exp(-((residual - h) ** 2) / (2.0 * 8.0 ** 2))

    # Small weight so this only breaks near-ties, never overrides fit quality.
    score -= 0.75 * pen

    return score
# EVOLVE-BLOCK-END
