# EVOLVE-BLOCK-START
"""Best fit with periodic sliver-avoiding diversion.

Pure best fit packs tightly but creates many unusable slivers (residuals
smaller than a typical arriving item). Periodically we instead choose the
bin whose post-placement residual avoids such slivers: we prefer the
smallest residual that is either ~0 or at least a threshold, penalizing
the in-between "wasted" residuals. Between diversions we keep best fit.
A slowly varying trigger phase avoids aliasing with the item stream.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0
_THRESH = 12.0  # residuals below this (and >0) are considered wasted slivers


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    better_fit = -(bins - item)

    # Trigger slightly irregularly to avoid phase-locking with the stream.
    if (n % 50) == 17 or (n % 97) == 41:
        resid = bins - item  # remaining capacity after placement

        # Wasted sliver penalty: nonzero residual below threshold.
        waste = (resid > 0) & (resid < _THRESH)
        # Base score: tighter fit is better, but a wasted sliver is penalized.
        # Use a soft penalty via scaling down rather than hard exclusion.
        score = -resid.astype(np.float64)
        score[waste] -= _THRESH  # push wasted slivers well below non-wasted
        return score

    return better_fit
# EVOLVE-BLOCK-END
