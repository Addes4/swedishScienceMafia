# EVOLVE-BLOCK-START
"""Best fit with residual-usability bonus.

Pure best fit is a strong baseline for this distribution, but it often leaves
small residual slivers that can never hold another item. We keep best-fit as
the dominant criterion and add a bounded secondary bonus that rewards
post-placement residuals which are either nearly full (close to 0) or large
enough to still accept a typical item (~mean size). This nudges packings away
from permanently unusable slivers without sacrificing the good fit choices.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    _state["n"] += 1

    resid = bins - item  # remaining capacity after placing (>= 0 shown)

    # Dominant term: best-fit (smaller residual -> higher score).
    base = -resid

    # Secondary usability bonus, kept strictly smaller than 1 so it only
    # breaks ties among bins whose residuals differ by less than one unit.
    # Reward residuals near 0 (nearly full) or >= mean (can hold a typical item).
    usability = np.where(
        (resid <= 2) | (resid >= _MEAN),
        0.5,
        0.0,
    )

    return base + usability
# EVOLVE-BLOCK-END
