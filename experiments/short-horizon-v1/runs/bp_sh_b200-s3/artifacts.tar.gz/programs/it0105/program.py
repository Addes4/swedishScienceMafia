# EVOLVE-BLOCK-START
"""Best fit with fullest-bin tie-breaking.

Pure best fit leaves many small slivers and resolves ties by bin index, which
can waste near-full bins. Keeping best-fit as the dominant ranking, we break
ties among bins with equal post-placement residual by preferring the bin with
the smallest remaining capacity before placement (the fullest bin). This tends
to consolidate items into bins that are already loaded and keeps large open
gaps available for future large items.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Dominant term: best-fit (tighter post-placement residual is better).
    better_fit = -(bins - item)

    # Tie-break: among equal residuals, prefer the fullest bin (smallest
    # remaining capacity before placement). Scale by a tiny factor so it only
    # affects exact ties in the dominant term.
    tiebreak = -(bins.astype(np.float64)) * 1e-6

    return better_fit.astype(np.float64) + tiebreak
# EVOLVE-BLOCK-END

