# EVOLVE-BLOCK-START
"""Best fit with score-based diversion to avoid wasted slivers.

Pure best fit leaves many slivers too small to hold a typical (mean-sized)
item. On a periodic trigger, if the best-fit bin would leave such a wasted
sliver and another bin offers a post-placement residual large enough to fit a
mean-sized item at only slightly worse fit, we divert there.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    resid = bins - item  # remaining capacity after placing (all >= 0)

    # Base: best fit (tighter residual -> higher score).
    better_fit = -resid

    if (n + 3) % 20 == 0:
        # Post-placement residual of the best-fit bin.
        best_idx = int(np.argmin(resid))
        best_resid = resid[best_idx]
        # A "wasted sliver": positive but too small for a mean-sized item.
        if 0 < best_resid < _MEAN:
            # Bonus for bins whose residual can still fit a mean-sized item.
            bonus = (resid >= _MEAN).astype(np.float64)
            return better_fit + 0.5 * bonus

    return better_fit
# EVOLVE-BLOCK-END
