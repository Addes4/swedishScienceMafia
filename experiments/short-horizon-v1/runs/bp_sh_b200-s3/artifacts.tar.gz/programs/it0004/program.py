# EVOLVE-BLOCK-START
"""Hybrid: best fit when a tight fit exists, else least-full (reserve big bins)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for every shown bin
    # A "tight fit" leaves little residual. Prefer best fit among those.
    # If no bin is tight enough, spread the load: prefer bins with more free space
    # so that large future items still have room.
    threshold = max(5, item // 4)
    tie_break = -bins.astype(np.float64) * 1e-6
    tight = residual <= threshold
    if tight.any():
        score = -residual.astype(np.float64)
        score = np.where(tight, score, -1e9)
    else:
        # fall back: least-full bin (largest remaining capacity)
        score = bins.astype(np.float64)
    return score + tie_break
# EVOLVE-BLOCK-END

