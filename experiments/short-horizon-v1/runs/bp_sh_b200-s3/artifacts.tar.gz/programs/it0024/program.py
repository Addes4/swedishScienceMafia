# EVOLVE-BLOCK-START
"""Best fit with an adaptive anti-fragmentation penalty.

Items arrive online from a fixed Weibull-like distribution (mean ~40).
Pure best-fit minimizes immediate wasted space but tends to create tiny
unusable residuals that can never be filled, inflating the bin count.

Here we keep best-fit as the primary rule, but track the empirical
distribution of item sizes seen so far.  A bin whose post-placement
residual would fall in a "dead zone" -- a residual smaller than most
future items, so it is unlikely to ever be used again -- is penalized.
Bins are ranked by best-fit (smaller residual wins), adjusted by this
penalty, so that near-tie decisions avoid locking away small fragments.
"""
import numpy as np

_state = {"n": 0, "hist": None, "seen": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Running item-size histogram (1..100), for a cheap empirical CDF.
    hist = _state["hist"]
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        _state["hist"] = hist
    if 1 <= item <= 100:
        hist[item] += 1.0
    _state["seen"] += 1

    residual = bins - item  # post-placement free space

    # Best-fit priority: tighter fit -> higher score.
    score = -residual.astype(np.float64)

    # Anti-fragmentation penalty: residuals that are small but nonzero
    # tend to become permanently unusable.  Estimate the fraction of
    # future items that could still fit into a residual r as
    # P(item <= r); a small value means the residual is "dead".
    seen = _state["seen"]
    if seen >= 20:
        # cumulative counts: how many past items are <= r
        cum = np.cumsum(hist)  # cum[r] = count of items with size <= r
        r_clip = np.clip(residual, 0, 100).astype(np.int64)
        frac = cum[r_clip] / seen  # in [0,1]
        # Penalize dead residuals (small frac) but leave full/empty alone.
        # Scale grows modestly so it only breaks near-ties.
        penalty = np.where((residual > 0) & (residual < 60),
                           6.0 * (1.0 - frac), 0.0)
        score = score - penalty

    return score
# EVOLVE-BLOCK-END

