# EVOLVE-BLOCK-START
"""Best fit with a mild residual-quality shaping.

Pure best fit is a strong baseline for this distribution but plateaus due
to fragmentation: it creates bins whose remaining residual is too small to
be useful for future mean-sized (~40) items. We keep best fit as the
dominant term, but add a small, smooth bonus for bins whose residual after
placement is close to the item distribution's mean, which gently avoids
creating unusable slivers without abandoning the tight-fit preference.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    residual = bins - item  # remaining capacity after placing the item

    # Primary term: best fit -> tighter fit (smaller residual) scores higher.
    score = -(residual).astype(np.float64)

    # Secondary term: mildly prefer residuals near the mean item size (~40),
    # so we avoid leaving tiny unusable slivers. Kept small so it only breaks
    # near-ties rather than overriding best fit.
    shaped = -np.abs(residual - 40.0)
    score = score + 0.05 * shaped

    return score
# EVOLVE-BLOCK-END
