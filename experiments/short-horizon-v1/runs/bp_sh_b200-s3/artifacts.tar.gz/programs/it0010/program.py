# EVOLVE-BLOCK-START
"""Best fit with occasional diversification toward less-full bins.

Pure best fit gets stuck on a plateau for this distribution. A small,
deterministic amount of exploration can help avoid the worst fragmentation
patterns without abandoning the strong best-fit baseline.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Best-fit priority: tighter fit (smaller residual) -> higher score.
    score = -(bins - item)

    # With a small periodic probability, prefer the least-full bin instead,
    # to diversify placement decisions.
    if n % 50 == 17:
        # bins are remaining capacities; larger means more free -> boost those.
        score = score + 1000.0 * (bins / 100.0)

    return score
# EVOLVE-BLOCK-END
