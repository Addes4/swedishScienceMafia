# EVOLVE-BLOCK-START
"""Best fit with a continuous, always-on sliver-aware tie-break.

Pure best fit (tighter residual -> higher priority) is near-optimal for the
Weibull-like item stream.  Fully closing a bin (residual 0) is always good, so
we add a tiny, smoothly decaying bonus for residuals near zero.  The bonus is
scaled by a small epsilon so it only resolves near-ties and never overrides the
primary best-fit ordering by any meaningful margin.
"""
import numpy as np

_EPS = 1e-3


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # residual after placement (>= 0 for shown bins)

    # Primary: best fit -- smaller residual is better.
    score = -resid.astype(np.float64)

    # Secondary: tiny bonus for residuals close to 0 (a filled/closed bin),
    # decaying smoothly so it only matters among near-ties.
    score += _EPS * (1.0 / (1.0 + resid))

    return score
# EVOLVE-BLOCK-END
