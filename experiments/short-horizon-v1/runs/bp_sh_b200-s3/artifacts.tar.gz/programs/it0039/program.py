# EVOLVE-BLOCK-START
"""Best fit with a hist-based residual-usability tie-break.

Pure best fit is strong here. The main waste comes from leaving small
residuals that future items can never exactly fill. Since item sizes are
drawn from a fixed distribution, residuals that equal common item sizes are
more likely to be fillable later. We keep best-fit as the primary rule and
only add a tiny sub-unit bonus (never overriding the 1-unit residual gap)
for bins whose post-placement residual is a frequently-seen item size.
"""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    hist = _state["hist"]
    hist[item] += 1.0
    _state["n"] += 1

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: smaller residual -> higher score.
    score = -residual.astype(np.float64)

    # Sub-unit bonus: reward residuals that match common past item sizes,
    # since those residuals are more likely to be exactly fillable later.
    # Scale strictly below 1 so best-fit dominance is preserved.
    freq = hist[residual]
    total = _state["n"]
    bonus = 0.5 * (freq / total) if total > 0 else 0.0
    # residual==0 is already the best fit; give exact-fill a bit extra is
    # redundant, so apply bonus only to positive residuals.
    score = score + np.where(residual > 0, bonus, 0.0)

    return score
# EVOLVE-BLOCK-END
