# EVOLVE-BLOCK-START
"""Best fit, with diversification for small items.

Pure best fit is strong for this distribution, but tiny items placed by
strict best-fit tend to pile into already-full-ish bins and waste residual
capacity. For the smallest items we instead prefer the least-full fitting
bin, which packs small items as filler and leaves tight fits available for
larger items.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Best-fit priority: tighter fit (smaller residual) -> higher score.
    score = -(bins - item)

    # For very small items, prefer the most-free bin instead: larger
    # remaining capacity gets a boost.
    if item <= 15:
        score = score + 1000.0 * (bins / 100.0)

    return score
# EVOLVE-BLOCK-END

