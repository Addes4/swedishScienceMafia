# EVOLVE-BLOCK-START
"""Best fit with residual-matching to frequent past item sizes.

Pure best fit is strong but leaves many gaps whose size matches no common
item, so those gaps never get filled. We keep best-fit as the dominant term
and add a small, bounded secondary bonus when the post-placement residual
equals a size that has appeared frequently in the stream. This lets leftover
gaps line up with items likely to arrive, improving packing density, without
ever overriding the primary best-fit ranking.
"""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0}
_DECAY = 0.999  # forget old statistics slowly
_BONUS = 1e-3   # small enough to never overturn a genuine best-fit gap


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    hist = _state["hist"]

    # Best-fit primary term: tighter post-placement residual -> higher score.
    better_fit = -(bins - item).astype(np.float64)

    # Residual after placing the item for each shown bin.
    resid = (bins - item).astype(np.float64)

    # Bonus proportional to how often this residual has appeared as an item
    # size before (clamped integer index keeps indexing safe).
    idx = np.clip(resid.astype(np.int64), 0, 100)
    bonus = _BONUS * hist[idx]

    # Update the histogram with the current item (decay old counts a bit).
    hist *= _DECAY
    hist[item] += 1.0
    _state["n"] += 1

    return better_fit + bonus
# EVOLVE-BLOCK-END
