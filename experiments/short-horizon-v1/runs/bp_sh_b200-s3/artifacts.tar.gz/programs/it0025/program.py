# EVOLVE-BLOCK-START
"""Best fit, with consolidation for loose placements.

Most placements should use best fit (minimize residual). But when even the
best fit leaves a large residual, the item is "wasted" filling a bin only
partially; in that case we prefer to place it in the bin that is already
fullest (smallest pre-placement remaining capacity) so that fragmented space
gets consolidated rather than spread across many bins.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Post-placement residual for each candidate bin.
    residual = bins - item

    # Best fit: smaller residual -> higher score.
    score = -residual.astype(np.float64)

    # If the best fit still wastes a lot (residual larger than a typical
    # item), consolidate instead: reward bins that are already fuller.
    best_res = residual.min()
    if best_res > 30:
        # bins = remaining capacity; smaller remaining -> fuller bin.
        fullness = (100.0 - bins.astype(np.float64)) / 100.0
        score = score + 5.0 * fullness

    return score
# EVOLVE-BLOCK-END

