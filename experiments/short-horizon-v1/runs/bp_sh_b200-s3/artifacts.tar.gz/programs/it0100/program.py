# EVOLVE-BLOCK-START
"""Best fit with item-conditional modulo-consolidation diversion.

Pure best fit leaves many small slivers for this Weibull-shaped stream. Large
items are the ones that leave awkward residuals, so when a large item arrives
we divert to the bin whose residual after placement is closest to a multiple
of the mean item size (~40), consolidating leftovers. Otherwise we use plain
best fit, which is the strong baseline.
"""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    if item >= 60:
        resid = bins - item  # remaining after placing (>= 0 for shown bins)
        m = np.round(resid / _MEAN)
        dist = np.abs(resid - m * _MEAN)
        return -dist

    # Base: best-fit priority (tighter residual -> higher score).
    return -(bins - item)
# EVOLVE-BLOCK-END

