# EVOLVE-BLOCK-START
"""Best fit with a "useful residual" fallback.

Pure best-fit is a strong online rule for Weibull-shaped items, but it tends
to fragment bins into tiny unusable slivers. This rule keeps best-fit as the
default, but when the tightest fit would leave a residual smaller than a
typical future item, it prefers the bin whose post-placement residual is
closest to (but not below) that typical size, preserving usable free space.
"""
import numpy as np

_state = {"n": 0}

# Roughly the mean item size for the Weibull distribution described.
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    _state["n"] += 1

    residual = bins - item  # post-placement free space for each candidate bin

    # Default: best fit -> tighter fit (smaller residual) scores higher.
    score = -residual

    # For bins where the fit is very tight (leaves a small, hard-to-use gap),
    # bias the ranking toward residuals near the typical item size so future
    # items can still use the space.
    tight = residual < _MEAN
    # Distance from the ideal "one more typical item" leftover.
    bias = -np.abs(residual - _MEAN)
    score = np.where(tight, bias, score)

    return score
# EVOLVE-BLOCK-END
