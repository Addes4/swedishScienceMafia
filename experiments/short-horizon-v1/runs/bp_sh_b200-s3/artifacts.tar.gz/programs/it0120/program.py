# EVOLVE-BLOCK-START
"""Pure best fit with a deterministic tie-break.

Rank bins by the residual left after placing the item (smaller is better).
This is the classic best-fit rule, which is strong for this item
distribution. A tiny secondary term breaks exact ties in favour of the
bin that is currently the fullest (smallest remaining capacity), so that
nearly complete bins get closed first without disturbing the primary
best-fit ordering.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placing (>= 0 for fitting bins)
    # Primary: best fit (smallest residual). Secondary: prefer fuller bins.
    return -(resid + 1e-6 * bins)
# EVOLVE-BLOCK-END

