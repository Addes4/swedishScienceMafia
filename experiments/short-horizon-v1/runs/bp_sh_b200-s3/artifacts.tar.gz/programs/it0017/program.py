# EVOLVE-BLOCK-START
"""Best fit with squared-residual scoring plus light diversification.

Pure linear best fit (minimize post residual) leaves many nearly-empty bins.
Scoring by the squared residual instead rewards placing items into bins that
are already substantially used, consolidating free space and reducing the
number of bins. A small periodic least-full diversion keeps diversity.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # bins are remaining capacities; post-placement residual = bins - item.
    residual = bins - item

    # Squared-residual best fit: prefer tighter fits, with extra reward for
    # filling bins that are already well-used (small resulting residual has a
    # disproportionately high score).
    score = -(residual * residual).astype(np.float64)

    # Periodic diversification: sometimes prefer the least-full bin.
    if n % 50 == 17:
        score = score + 1e6 * (bins / 100.0)

    return score
# EVOLVE-BLOCK-END

