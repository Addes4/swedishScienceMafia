# EVOLVE-BLOCK-START
"""Best fit with harmonic-style residual preference.

Best fit is strong for this distribution but leaves many medium slivers.
We keep best-fit as the primary ranking and add a smooth secondary term that
prefers post-placement residuals close to a set of canonical reusable gap
sizes (small tight fits first, then ~40, then ~60), which helps medium gaps
be reused by the next similar item. The term is small enough not to override
best-fit's ordering among clearly different residuals.
"""
import numpy as np

_state = {"n": 0}
_GAPS = np.array([0.0, 20.0, 40.0, 60.0, 80.0])


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item

    # Primary: best-fit (tighter residual -> higher score).
    # Scale so it dominates; residuals range 0..100.
    primary = -(resid.astype(np.float64))

    # Secondary: smooth bonus for residuals near a canonical reusable gap.
    d = np.abs(resid[:, None] - _GAPS[None, :])
    mind = d.min(axis=1)
    bonus = -mind * 0.05

    return primary + bonus
# EVOLVE-BLOCK-END
