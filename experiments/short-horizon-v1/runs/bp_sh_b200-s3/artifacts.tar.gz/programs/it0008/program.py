# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware waste penalty.

Pure best fit (minimizing the post-placement residual) is a strong online rule.
We refine it by scoring each bin not just by the raw residual, but by combining
tightness with a mild preference for residuals that remain useful for the
Weibull item distribution (mean ~40), while strongly discouraging leaving a
small, hard-to-fill residual.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # remaining capacity after placing the item here

    # Core best-fit signal: smaller residual is better (negated).
    tightness = -residual.astype(np.float64)

    # Distribution-aware term: reward residuals that stay useful.  The Weibull
    # item distribution has mean ~40, so a residual near 40 can still host a
    # typical future item; very small residuals (< ~mean/2) are mostly wasted.
    # Use a smooth bump centered at the item mean, scaled small so it only
    # breaks near-ties of the best-fit signal.
    mean = 40.0
    usefulness = -((residual - mean) ** 2) / (2.0 * mean * mean)

    return tightness + 0.5 * usefulness
# EVOLVE-BLOCK-END

