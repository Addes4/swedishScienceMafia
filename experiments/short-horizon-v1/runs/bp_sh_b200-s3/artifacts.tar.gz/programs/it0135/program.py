# EVOLVE-BLOCK-START
"""Best fit with an adaptive, size-aware consolidation rule.

Pure best fit is the dominant rule. To reduce slivers we add a smooth,
always-on secondary term that gently prefers bins whose post-placement
residual equals a "usable gap" (a multiple of the mean item size roughly, or
zero). The weight is small so best-fit stays dominant, and the term is scaled
smoothly so it does not behave like a noisy periodic diversion.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    _state["n"] += 1
    _state["sum"] += item

    # Base: best-fit priority (tighter residual -> higher score).
    better_fit = -(bins - item)

    resid = bins - item  # remaining after placing (>= 0)

    # Prefer residuals that are usable gaps: close to zero or close to a
    # multiple of the mean item size. Weight scaled to bin capacity so it
    # acts only as a gentle tie-breaker among near-equal fits.
    m = np.round(resid / _MEAN)
    dist = np.abs(resid - m * _MEAN)
    # dist is small when resid is a usable gap; convert to a small bonus.
    gap_bonus = (20.0 - dist) / 20.0  # roughly in [-something, 1]

    # Only let the bonus matter when the fit itself is reasonably tight,
    # so we never pile items into an already-bad bin.
    slack = 30.0
    weight = np.clip((slack - (bins - item)) / slack, 0.0, 1.0)

    return better_fit + 0.5 * weight * gap_bonus
# EVOLVE-BLOCK-END
