# EVOLVE-BLOCK-START
"""Sum-of-Squares-style best fit.

Rank bins by the (sublinearly scaled) residual after placement: a tighter fit
is strongly preferred, but among comparable residuals a fuller bin wins,
which reduces fragmentation on heavy-tailed item distributions.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = (bins - item).astype(np.float64) / 100.0  # post-placement residual fraction
    # Primary: prefer tight fits (small residual -> high score).
    # Secondary: Sublinear penalty on residual so the Sum-of-Squares ordering
    # dominates while near-ties are broken toward fuller bins.
    score = -(resid ** 0.5) - 0.15 * resid
    return score
# EVOLVE-BLOCK-END
