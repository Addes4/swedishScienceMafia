# EVOLVE-BLOCK-START
"""Best fit with a worst-fit tie-break inside a near-tie window.

Pure best fit minimizes immediate waste but tends to create many bins with a
single small residual that no future item can fill, inflating bin count for
heavy-tailed (Weibull, mean ~40) streams.  We keep best fit as the primary
criterion via a coarse bucket on the post-placement residual, then within each
bucket prefer a larger residual so we leave more room and reduce unfillable
slivers.
"""
import numpy as np

_BUCKET = 3.0  # width of the near-tie window in capacity units


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placing (>= 0 shown)

    # Primary: coarse best-fit bucket (smaller residual -> higher bucket).
    bucket = -np.floor(resid / _BUCKET)
    # Secondary: within the bucket, prefer a larger residual (less sliver risk).
    return bucket * 1000.0 + resid
# EVOLVE-BLOCK-END
