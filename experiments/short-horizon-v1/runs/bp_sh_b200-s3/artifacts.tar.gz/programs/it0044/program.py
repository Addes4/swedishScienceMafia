# EVOLVE-BLOCK-START
"""Best fit, with small items diverted toward emptier bins.

Pure best fit is near-optimal for medium/large items, but placing very small
items into tight residuals can fragment capacity. For small items we instead
prefer the least-full bin, leaving tight residuals intact for future matches.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    if item <= 20:
        # Prefer the least-full bin (largest remaining capacity) for small items.
        return bins.astype(np.float64)
    # Otherwise best-fit: tighter fit (smaller residual) -> higher score.
    return -(bins - item)
# EVOLVE-BLOCK-END

