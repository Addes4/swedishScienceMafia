# EVOLVE-BLOCK-START
"""Best fit with a sliver-avoidance secondary preference.

Pure best fit fills each bin as tightly as possible, but this frequently
leaves tiny unusable slivers that can never hold another item from the
distribution (mean ~40). We keep best-fit's primary ordering but add a small
bonus for choices whose post-placement residual is at least a typical item
size, so leftover space stays usable for future items. The bonus is small
enough that it only breaks near-ties in the tightest fit.
"""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placing the item

    # Primary: best fit (smaller residual -> larger score).
    score = -resid.astype(np.float64)

    # Secondary: reward leaving at least a typical item's worth of room,
    # so the leftover does not become a permanently unusable sliver.
    usable = (resid >= _MEAN).astype(np.float64)
    score += 0.5 * usable

    return score
# EVOLVE-BLOCK-END
