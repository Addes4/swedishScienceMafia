# EVOLVE-BLOCK-START
"""Distribution-aware best fit.

Primary rule: best fit (tightest post-placement residual).  Ties and
near-ties are broken by an always-on bonus based on a running histogram of
item sizes: residuals that equal (or nearly equal) an observed item size are
more likely to be filled exactly by a future item, so we prefer them.  This
is deterministic, always on, and degrades gracefully to pure best fit.
"""
import numpy as np

_state = {"n": 0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    hist = _state["hist"]
    n = _state["n"]
    _state["n"] = n + 1

    # Primary: best fit (smaller residual -> higher score).
    resid = bins - item
    score = -(resid.astype(np.float64))

    # Secondary: bonus if residual equals a frequently-seen item size.
    # Use only currently-available residuals to index the histogram.
    # Small bonus so it only breaks near-ties.
    h = hist[resid]
    score += 0.001 * h

    # Record this item for future bonus lookups.
    hist[item] += 1.0

    return score
# EVOLVE-BLOCK-END
