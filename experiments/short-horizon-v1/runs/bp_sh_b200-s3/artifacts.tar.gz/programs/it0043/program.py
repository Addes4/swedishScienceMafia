# EVOLVE-BLOCK-START
"""Best fit with a residual-utility shaping term.

Pure best fit minimizes residual at each step, but it happily leaves tiny,
unusable slivers that fragment bins. Since item sizes are integers with mean
~40, small residuals below a cutoff are rarely reusable, while moderate and
large residuals can still absorb future items. We shape the priority as the
tightest fit plus a smooth utility term that mildly penalizes leaving a tiny
residual, without disturbing the decisive preference for the smallest residual.

The shaping is sub-unit scaled so it can never override the primary best-fit
ordering (which differs by at least 1 between distinct bins), only acting as a
tie-breaker among bins with identical residual.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    residual = bins - item  # >= 0 for all shown bins

    # Primary: tightest fit (smallest residual) -> highest score.
    score = -residual.astype(np.float64)

    # Tie-breaker: among equal residuals, avoid tiny unusable slivers slightly.
    # Favor residuals near 0 (perfect fill) and residuals large enough to be
    # reusable; mildly de-prioritize small positive residuals.
    r = residual.astype(np.float64)
    # Utility in (0,1): peaks at r==0, dips for tiny positive slivers.
    # 0.5 for perfect fill, decreasing then flattening for larger residuals.
    util = 0.5 / (1.0 + 0.02 * r * r) + 0.5 * (1.0 - np.exp(-r / 20.0))
    score = score + 0.5 * util

    return score
# EVOLVE-BLOCK-END

