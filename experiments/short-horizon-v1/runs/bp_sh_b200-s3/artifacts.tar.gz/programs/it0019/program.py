# EVOLVE-BLOCK-START
"""Two-tier best fit: primary on tight fit, secondary on useful residual.

Pure best fit is strong for this distribution but leaves a plateau where many
bins sit with tiny unusable residuals. We keep best fit as the primary
criterion, but when several bins are near-tied in fit, we prefer the one whose
post-placement residual is closest to a useful target (around 20), which
matches the half-mean item size and tends to consolidate space into bins that
can still absorb future items.
"""
import numpy as np

_state = {"n": 0}

# Target residual after placement: half the distribution mean (~40).
_TARGET = 20.0
# Tolerance for "near-tie" in fit residual.
_TOL = 2


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    residual = bins - item

    # Primary: best fit (smaller residual is better).
    # Scale large enough that it dominates the secondary term.
    primary = -residual.astype(np.float64) * 1000.0

    # Secondary: prefer residuals near the useful target.
    secondary = -np.abs(residual.astype(np.float64) - _TARGET)

    # Blend: primary dominates except when residuals are near-tied.
    score = primary + secondary

    return score
# EVOLVE-BLOCK-END
