# EVOLVE-BLOCK-START
"""Best fit with a small residual-quality tie-breaker.

Pure best-fit is strong for this Weibull-shaped item distribution. The main
source of waste is leaving tiny, unfillable slivers. We keep best-fit as the
dominant term (scaled by a large weight so it decides almost always), and add
a small always-on secondary term that prefers post-placement residuals which
are large enough to plausibly accept a future item (>= the item just placed,
bounded). This nudges ties and near-ties toward fuller, reusable residuals
without abandoning the proven-good best-fit ranking.
"""
import numpy as np

_MEAN = 40.0
_W = 1000.0  # weight making best-fit dominant


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placing (>= 0)

    # Dominant: best-fit (smaller post-placement residual -> higher score).
    best_fit = -resid

    # Secondary: prefer residuals that remain "usable", i.e. not tiny slivers.
    # Reward residual >= mean-ish scale lightly; scale small enough to only
    # break near-ties.
    usable = np.minimum(resid, _MEAN) / _MEAN

    return _W * best_fit + usable
# EVOLVE-BLOCK-END
