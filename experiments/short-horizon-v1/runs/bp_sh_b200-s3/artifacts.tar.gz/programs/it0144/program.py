# EVOLVE-BLOCK-START
"""Best fit with sliver-avoidance diversion.

Pure best fit is the strong default. The known weakness for this distribution
is that best fit tends to leave small unusable slivers. We keep best fit except
when the arriving item is small (slivers are created mainly by small items) AND
placing it best-fit would leave a residual in a wasteful "dead zone" just below
the mean item size. In that case we divert to the bin whose resulting residual
is the largest value not exceeding the mean, which packs fragments together.
"""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    better_fit = -(bins - item)

    # Only small items create slivers.
    if item < 35:
        resid = bins - item  # remaining after placing (>= 0)
        # Best-fit residual (the bin best-fit would pick).
        best_resid = np.min(resid)
        # Dead zone: residual just below the mean is wasteful.
        if best_resid < _MEAN:
            # Among bins whose residual does not exceed the mean, prefer the
            # fullest one (largest residual <= mean) to consolidate.
            ok = resid <= _MEAN
            if np.any(ok):
                # score: higher for larger residual within [0, mean]; best-fit
                # naturally acts as a tiebreak for the rest.
                divert = np.where(ok, resid, -1e9)
                return divert * 1000.0 + better_fit

    return better_fit
# EVOLVE-BLOCK-END
