# EVOLVE-BLOCK-START
"""Best fit with a fractional-fullness tie-break.

Classic best fit minimizes the residual after placing the item. Ties (and
near-ties) are broken by preferring the bin that is already more full, which
encourages consolidation and avoids spreading items thinly across many bins.
The tie-break is scaled far below the 1-unit residual gap so best-fit remains
the dominant criterion.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    # Best-fit primary criterion: smaller residual -> higher score.
    residual = bins - item
    score = -residual.astype(np.float64)

    # Tie-break: prefer bins that are already more occupied (smaller remaining
    # capacity before placing). After the item, residual is bins-item, so a
    # fuller bin had smaller bins. Add a tiny bonus proportional to fullness.
    score += 1e-3 * (100.0 - bins) / 100.0

    return score
# EVOLVE-BLOCK-END
