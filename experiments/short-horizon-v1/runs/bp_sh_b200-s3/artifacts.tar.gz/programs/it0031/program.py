# EVOLVE-BLOCK-START
"""Best fit with a strong bonus for perfect fills.

Pure best fit already performs well for this distribution. The main remaining
loss is leaving a bin with a small but nonzero residual that no future item can
fill. Strongly rewarding exact fills (residual 0 after placement) captures the
biggest wins without sacrificing the best-fit baseline.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    residual = bins - item  # remaining capacity after placing item (>= 0 for fitting bins)

    # Primary: best fit (smaller residual is better).
    score = -residual.astype(np.float64)

    # Strong bonus for perfect fills (residual exactly 0).
    score += 1000.0 * (residual == 0)

    # Tiny tie-break: among equal residuals, slightly prefer fuller bins
    # (smaller current remaining capacity) to consolidate used bins.
    score -= 1e-6 * bins

    return score
# EVOLVE-BLOCK-END

