# EVOLVE-BLOCK-START
"""Blended best-fit with continuous consolidation for small residuals.

Best fit (smallest post-placement residual) is the dominant term, but for
bins whose residual is small we add a bonus that prefers residuals close to a
multiple of the mean item size (~40). Small residuals are where fragmentation
costs the most, so influencing bin choice there helps consolidate leftovers
without disturbing the good decisions best fit already makes for large gaps.
"""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placing this item (>= 0)

    # Dominant term: best fit (smaller residual -> higher score).
    score = -resid.astype(np.float64)

    # Consolidation bonus: for small residuals, prefer those near a multiple
    # of the mean item size, so leftovers are more likely to be filled later.
    small = resid <= _MEAN
    if np.any(small):
        m = np.round(resid / _MEAN)
        dist = np.abs(resid - m * _MEAN)
        bonus = (_MEAN - dist) * 0.5  # in roughly [0, _MEAN/2]
        score = np.where(small, score + bonus, score)

    return score
# EVOLVE-BLOCK-END
