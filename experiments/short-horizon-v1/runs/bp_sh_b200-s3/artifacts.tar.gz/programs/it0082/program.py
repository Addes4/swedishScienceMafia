# EVOLVE-BLOCK-START
"""Best fit with empirical residual-utility tie-break.

Best fit is a strong baseline for this distribution.  We keep best fit as the
dominant ordering and add a strictly secondary, small-magnitude term that
prefers leaving a residual which is likely to be fillable by a future item,
based on a running histogram of observed item sizes.  The secondary term is
scaled to be smaller than one unit of fit difference so it can only break ties
among near-equal residuals.
"""
import numpy as np

_state = {"n": 0, "hist": np.zeros(101)}

_ALPHA = 0.35  # secondary term weight, kept below 0.5 (one fit unit)


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    hist = _state["hist"]
    n = _state["n"] + 1
    _state["n"] = n
    if 1 <= item <= 100:
        hist[item] += 1.0

    # Primary: best fit (tighter residual after placement -> higher score).
    better_fit = -(bins - item)

    # Secondary: prefer residuals likely to be usable by a future item.
    resid = bins - item
    # Probability mass of items that can still fit in the residual.
    # Cumulative histogram: total mass of observed sizes <= resid.
    cum = np.cumsum(hist)
    total = cum[100]
    if total <= 0:
        return better_fit
    usable = cum[np.clip(resid, 0, 100).astype(np.int64)] / total

    return better_fit + _ALPHA * usable
# EVOLVE-BLOCK-END
