# EVOLVE-BLOCK-START
"""Best fit with a smooth, always-on "usable residual" bonus.

Pure best fit packs tightly but often strands small slivers. This rule keeps
best-fit as the primary criterion (via the negative post-placement residual)
and adds a smooth bonus that rewards residuals which are either nearly full
(small sliver) or large enough to still accommodate a typical item (~mean).
The bonus is scale-free and continuous, avoiding the brittleness of a single
periodic trigger.
"""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placement (>= 0)

    # Primary: best-fit (smaller residual -> higher score).
    best_fit = -resid.astype(np.float64)

    # Secondary: smooth bonus for residuals near 0 (almost full) or near mean.
    # Gaussian-like bumps, both scaled small so they only break near-ties.
    a = np.exp(-(resid / 10.0) ** 2)          # reward near-empty residual
    b = np.exp(-((resid - _MEAN) / 15.0) ** 2)  # reward ~mean residual
    bonus = 8.0 * a + 5.0 * b

    return best_fit + bonus
# EVOLVE-BLOCK-END
