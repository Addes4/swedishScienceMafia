# EVOLVE-BLOCK-START
"""Best fit with a mild conservation bias toward partially-filled bins.

The item distribution is Weibull-shaped with mean ~40 on capacity 100, so
items often fit into leftover gaps. Pure best-fit tends to break fresh bins
when residual gaps are useless, fragmenting capacity. We keep best-fit as the
primary criterion but add a small tie-break term that prefers bins already
moderately filled over nearly-empty bins, preserving large empty bins for
large items while still filling tight gaps first.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Primary: best fit -> smaller post-placement residual scores higher.
    score = -(bins - item)

    # Secondary: mild preference for bins that already hold some load
    # (smaller remaining capacity), scaled to be a tie-breaker only.
    # This consolidates load and reserves near-empty bins for large items.
    score = score - 0.05 * bins

    return score
# EVOLVE-BLOCK-END
