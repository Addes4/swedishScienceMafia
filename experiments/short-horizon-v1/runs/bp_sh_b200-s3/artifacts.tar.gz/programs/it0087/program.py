# EVOLVE-BLOCK-START
"""Best fit with a history-driven "perfect-fit" tie-break.

Best fit is the strongest simple online rule for this item distribution. To
squeeze a little more, we keep best fit as the dominant objective but break
near-ties using a running histogram of observed item sizes: among bins whose
residual-after-placement is nearly identical, prefer the one whose residual is
a size that has actually been seen, making the bin easier to close exactly
later. The perturbation is tiny so it only affects near-ties.
"""
import numpy as np

_state = {"n": 0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    hist = _state["hist"]

    # Base: best-fit priority (tighter residual -> higher score).
    resid = bins - item  # remaining capacity after placing (>= 0)
    better_fit = -resid.astype(np.float64)

    # Bonus if this residual is a commonly seen item size (easy to close).
    # Normalize histogram to a small weight.
    total = hist.sum()
    if total > 0:
        freq = hist / total
        # residuals are within 0..100
        r = resid.astype(np.int64)
        np.clip(r, 0, 100, out=r)
        bonus = freq[r]
    else:
        bonus = 0.0

    _state["n"] += 1

    # Tiny weight: only breaks near-ties, preserves best-fit ordering.
    return better_fit + 0.01 * bonus
