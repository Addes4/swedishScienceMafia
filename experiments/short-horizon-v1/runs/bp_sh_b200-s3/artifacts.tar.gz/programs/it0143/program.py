# EVOLVE-BLOCK-START
"""Best fit with dead-zone consolidation tracking the observed item floor.

Best fit tends to leave small slivers just below the smallest item size, which
become permanently unusable. We track the minimum item size seen so far (a
proxy for the smallest future item) and give a strong bonus to placements whose
resulting residual is 0 or at least that floor, while penalizing residuals that
fall in the unusable dead zone (0, floor). This consolidates waste without
relying on a noisy modulo-of-mean target.
"""
import numpy as np

_state = {"min_item": None}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    m = _state["min_item"]
    if m is None or item < m:
        m = item
        _state["min_item"] = m

    resid = bins - item  # remaining after placing (>= 0)

    # Base: best fit (tighter residual -> higher score).
    better_fit = -resid.astype(np.float64)

    # Dead zone: residual in [1, m-1] is hard to ever reuse.
    floor = float(max(m - 1, 1))
    # Penalize residuals strictly inside (0, m); reward perfectly tight (0)
    # and residuals >= floor equally (both are reusable).
    in_dead_zone = (resid > 0) & (resid < m)
    penal = np.where(in_dead_zone, 1.0, 0.0)

    return better_fit - penal * 50.0
# EVOLVE-BLOCK-END

