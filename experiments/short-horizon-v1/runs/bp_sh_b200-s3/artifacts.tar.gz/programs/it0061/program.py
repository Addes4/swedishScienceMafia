# EVOLVE-BLOCK-START
"""Best fit with periodic reserve-slot consolidation diversion.

Pure best fit leaves many small slivers for this distribution. Occasionally
we divert to the bin whose residual after placement is closest to the mean
item size (~40), which reserves room for one more typical item and reduces
fragmentation, while keeping best-fit as the baseline.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    better_fit = -(bins - item)

    if n % 25 == 13:
        resid = bins - item
        return -np.abs(resid - _MEAN)

    return better_fit
# EVOLVE-BLOCK-END
