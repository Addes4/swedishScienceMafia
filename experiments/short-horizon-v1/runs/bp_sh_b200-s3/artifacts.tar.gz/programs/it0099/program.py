# EVOLVE-BLOCK-START
"""Best fit with a fillable-sliver tie-break.

Pure Best Fit (smallest post-placement residual) is known to be a strong online
rule for this distribution. Its main weakness is creating tiny slivers that no
future item can fill. We keep Best Fit as the base but, when several bins leave
a very small residual (below the smallest item observed so far), we prefer the
one whose residual is closest to that smallest item size, so the leftover is
still likely to be filled by a future item instead of being wasted.
"""
import numpy as np

_state = {"min_item": 101.0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    if item < _state["min_item"]:
        _state["min_item"] = float(item)

    resid = bins - item  # remaining capacity after placing (>= 0 shown)

    # Base: Best Fit -> smaller post-placement residual gets higher score.
    better_fit = -resid.astype(np.float64)

    # Identify the very tight bins: residual below the smallest possible item.
    threshold = max(_state["min_item"], 1.0)
    tight = resid < threshold

    if np.any(tight):
        # Among tight bins, prefer residual closest to the smallest item size,
        # which gives the best chance of being exactly filled later.
        score = better_fit.copy()
        target = _state["min_item"]
        # Shift the tight bins' scores so the one nearest `target` wins, while
        # still staying above the loose bins.
        bonus = np.zeros_like(better_fit)
        idx = np.where(tight)[0]
        bonus[idx] = -np.abs(resid[idx] - target) / (100.0 + target)
        return score + bonus

    return better_fit
# EVOLVE-BLOCK-END
