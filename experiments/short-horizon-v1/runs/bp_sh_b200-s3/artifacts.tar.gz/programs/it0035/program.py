# EVOLVE-BLOCK-START
"""Best fit with a reusable-gap awareness tie-break.

Strict best fit is a strong online rule for this distribution, but it can
create small unusable leftover gaps. We keep best fit as the primary
criterion and use a stateful tie-break: among bins whose residual is close
to the best, prefer one whose resulting residual equals a commonly seen item
size (so the gap is likely to be reusable later). The tie-break is scaled
well below 1 residual unit so it never overrides best fit.
"""
import numpy as np

_state = {"n": 0, "seen": np.zeros(101, dtype=np.int64)}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    seen = _state["seen"]
    # Record the current item, but decide placement using only past items.
    if item < 101:
        seen[item] += 1

    # Best-fit priority: tighter fit (smaller residual) -> higher score.
    residual = bins - item
    score = -residual.astype(np.float64)

    # Reward residuals that match a frequently seen item size, so the
    # leftover gap is likely reusable. Scale below 1 residual unit.
    idx = np.clip(residual, 0, 100)
    freq = seen[idx].astype(np.float64)
    maxfreq = freq.max() if freq.size else 0.0
    if maxfreq > 0:
        score = score + 0.5 * (freq / maxfreq)

    return score
# EVOLVE-BLOCK-END

