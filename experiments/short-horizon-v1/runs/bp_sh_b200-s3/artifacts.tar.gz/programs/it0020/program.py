# EVOLVE-BLOCK-START
"""Best fit with a tolerance-based tie-break toward larger residuals.

Strict best fit minimizes the post-placement residual. On this Weibull-like
distribution that occasionally creates tiny residuals that no future item can
fill. Among bins that fit "almost as well" as the best one (residual within a
small tolerance of the minimum), preferring the bin that leaves a larger
residual gives more usable slack, which tends to reduce long-run fragmentation
without abandoning the strong best-fit baseline.
"""
import numpy as np

_state = {"n": 0}

# Residual tolerance: bins leaving a residual within this many units of the
# best residual are treated as near-ties and ranked by larger residual.
_TOL = 3.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    residual = bins - item
    best = residual.min()

    # Primary: tighter fit is better. Bins within tolerance of the best fit
    # get a bonus proportional to how much more residual they leave, so that
    # near-ties resolve toward the roomier bin (less fragmentation risk).
    score = -residual
    near = residual <= best + _TOL
    score = score + np.where(near, 1e-3 * residual, 0.0)

    return score
# EVOLVE-BLOCK-END

