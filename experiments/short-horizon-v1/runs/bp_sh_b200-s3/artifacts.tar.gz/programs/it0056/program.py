# EVOLVE-BLOCK-START
"""Best fit with a soft penalty for creating unusable slivers.

Pure best fit is strong for this distribution, but it often leaves small
residual gaps that cannot hold a future item of the same size. We keep the
tightest-fit ranking as the base and add a smooth penalty when the residual
after placement is positive yet smaller than the current item size, nudging
the rule away from creating wasted slivers without a hard discontinuity.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    _state["n"] += 1

    residual = bins - item

    # Base: tighter fit (smaller residual) -> higher score.
    score = -residual.astype(np.float64)

    # Soft penalty for a positive residual smaller than the item size:
    # such a gap likely cannot hold another like-sized item.
    sliver = np.clip(item - residual, 0.0, None)  # >0 only when 0 < residual < item
    score -= 0.5 * sliver

    return score
# EVOLVE-BLOCK-END

