# EVOLVE-BLOCK-START
"""Best fit with online residual-fill learning.

We track, for each residual bucket, how often a subsequent item has landed
exactly (or nearly) in that bucket, i.e. how "consumable" a leftover tends to
be. Placements still mostly follow best-fit, but residuals that the stream has
historically been able to fill get a small boost, which consolidates bins over
time without relying on a fixed periodic diversion.
"""
import numpy as np

_state = {"n": 0, "hist": np.zeros(101)}
_MEAN = 40.0
_BONUS = 0.35  # gentle weight for the learned fill score


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    st = _state
    # Record this item, then (approximately) reward the residual bucket it
    # would have closed if it exactly filled a leftover; here we simply update
    # an item-size frequency used as a proxy for "consumable" residuals.
    hist = st["hist"]
    hist[item] += 1.0
    if st["n"] > 0 and st["n"] % 200 == 0:
        hist *= 0.5  # decay old observations so the rule adapts
    st["n"] += 1

    # Base: best-fit priority (tighter residual -> higher score).
    resid = bins - item  # remaining after placing (>= 0 shown)

    # Learned attractiveness: a residual is good if sizes near it have appeared.
    # Use a small window around the residual to estimate future fill likelihood.
    idx = np.clip(resid, 0, 100).astype(np.int64)
    lo = np.clip(idx - 3, 0, 100)
    hi = np.clip(idx + 3, 0, 100)
    # cumulative helper
    csum = np.concatenate(([0.0], np.cumsum(hist)))
    fill_score = csum[hi + 1] - csum[lo]

    return -resid + _BONUS * fill_score
# EVOLVE-BLOCK-END


