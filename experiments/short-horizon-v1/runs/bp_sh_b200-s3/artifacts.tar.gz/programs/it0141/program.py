# EVOLVE-BLOCK-START
"""Best fit with sliver-targeted diversion.

Pure best fit is strong for this Weibull-shaped distribution, but it tends to
leave "slivers" (residuals just below the mean item size ~40) that later items
cannot use efficiently. This rule detects when the best-fit choice would create
exactly such a sliver and, in that case, diverts to the bin whose residual is
closest to the mean (so leftovers stay usable by the typical next item). All
other steps use plain best fit.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0
_SLIVER_LO = 22.0   # below this residual is too small to be reliably useful
_SLIVER_HI = 38.0   # residuals in [LO, HI) are the wasteful sliver zone


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    better_fit = -(bins - item)

    # Only consider diversion for mid-size items, where slivers tend to form.
    if 30 <= item <= 55:
        resid = bins - item  # remaining after placing (>= 0)
        # The best-fit bin is the one with smallest residual.
        idx = int(np.argmin(resid))
        bf_resid = resid[idx]
        if _SLIVER_LO <= bf_resid < _SLIVER_HI:
            # Best fit would create a sliver: prefer residual closest to mean.
            dist = np.abs(resid - _MEAN)
            return -dist * 100.0 + better_fit

    return better_fit
# EVOLVE-BLOCK-END
