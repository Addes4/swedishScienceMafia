# EVOLVE-BLOCK-START
"""Best-fit with size-dependent tightness weighting.

Pure best fit is near-optimal for medium/large items but tends to leave
awkward small residuals when filling gaps with small items. We keep the
best-fit backbone (prefer smallest residual bins - item) and add a
size-dependent tilt: for large items we strongly prefer the tightest fit,
while for small items we mildly prefer bins where the residual remains
large, so that future medium items can still land cleanly.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    residual = bins - item  # >= 0 for all shown bins

    # Base: best fit -> smaller residual is better.
    score = -residual.astype(np.float64)

    # Size-dependent tilt. For small items, mild preference for bins that
    # stay relatively full-agnostic (larger residual) to avoid fragmenting
    # near-full bins with tiny gaps. For large items this term vanishes.
    # w in [0, 1]; peaks for the smallest items, ~0 for large items.
    w = max(0.0, (60.0 - item) / 60.0)
    score = score + w * (residual.astype(np.float64) / 100.0)

    return score
# EVOLVE-BLOCK-END
