# EVOLVE-BLOCK-START
"""Best fit with periodic mean-residual diversion.

Pure best fit leaves many small slivers for this distribution. Occasionally
we divert to the bin whose residual after placement is closest to the running
mean item size (~40), which tends to leave reusable gaps, while keeping
best-fit as the baseline for most items.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Online mean of item sizes (skip the very first few for stability).
    s = _state["sum"] + item
    _state["sum"] = s
    if n + 1 >= 5:
        _state["mean"] = s / (n + 1)
    target = _state["mean"]

    # Base: best-fit priority (tighter residual -> higher score).
    better_fit = -(bins - item)

    if n % 7 == 3:
        resid = bins - item  # remaining after placing (>= 0 shown)
        # Prefer residual close to the running mean item size.
        return -np.abs(resid - target)

    return better_fit
# EVOLVE-BLOCK-END
