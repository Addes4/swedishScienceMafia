# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break.

Pure best fit is a strong baseline for this distribution. The one systematic
weakness is that it sometimes leaves a mid-sized residual ("sliver") that no
future item of typical size can use. We keep best fit as the dominant ranking
but give a big bonus to placements that either fill the bin exactly or leave a
residual at least as large as a typical item, so that usable gaps are preferred
over unusable slivers whenever both options are available.
"""
import numpy as np

_state = {"n": 0}

_TYPICAL = 40.0  # mean item size


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    residual = bins - item  # >= 0 for all shown bins

    # Base: best fit -> tighter fit (smaller residual) scores higher.
    score = -residual

    # Bonus: residual is exactly 0 (perfect fill) or big enough to hold a
    # typical future item. Mid-sized unusable slivers get no bonus.
    usable = (residual == 0) | (residual >= _TYPICAL)
    score = score + 50.0 * usable.astype(np.float64)

    # Among usable placements, prefer the tightest fit (tie-break already
    # handled by the base score), and among sliver placements also keep the
    # tightest fit. No periodic diversion: it hurt the baseline.
    return score
# EVOLVE-BLOCK-END
