# EVOLVE-BLOCK-START
"""Best fit with sliver-avoidance tie-break.

Primary criterion: best fit (smallest post-placement residual) so we keep the
strong packing behaviour of best fit. Tie-break: among bins whose residuals are
within a small window of the best residual, prefer one whose residual is close
to a multiple of the mean item size (~40), which keeps usable slots open and
reduces the accumulation of tiny slivers.
"""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placing (>= 0 where shown)

    # Best fit: smaller residual is better.
    best = resid.min()

    # Bins that are essentially tied with the best fit.
    window = 3.0
    near = np.abs(resid - best) <= window

    # Among near-best, prefer residual close to a multiple of the mean item size.
    m = np.round(resid / _MEAN)
    dist = np.abs(resid - m * _MEAN)

    # Score: high for near-best bins, with a bonus for good modulo residual.
    score = -(resid - best) - 0.01 * np.where(near, dist, 0.0)
    return score
# EVOLVE-BLOCK-END
