# EVOLVE-BLOCK-START
"""Best fit plus distribution-aware residual matching.

Best fit is the dominant term. As a small secondary term we reward bins whose
post-placement residual closely matches a frequently observed item size, so
leftover gaps stay reusable by future items instead of becoming dead slivers.
A fixed online histogram (updated from past items) gives the target sizes.
"""
import numpy as np

_state = {"hist": np.zeros(101), "n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    hist = _state["hist"]
    n = _state["n"]
    _state["n"] = n + 1

    # Update histogram with the current item (this item itself is fair game:
    # it has already arrived, no future info).
    hist[item] += 1.0

    # Base: best fit (tighter residual -> higher score).
    resid = bins - item  # remaining capacity after placement

    # Distribution-aware bonus: how likely is this residual to be usable?
    # Probability that a future item of some size s fits exactly-ish into resid.
    # Score = sum_s P(s) * kernel(resid - s), using the observed histogram.
    # Vectorized over bins via the cumulative-histogram lookup.
    # Weight of an item size s (normalized).
    total = hist.sum()
    if total <= 0.0:
        return -resid.astype(np.float64)

    # For each bin, residual r: reward closeness to any seen size.
    # Compute per-bin reward with a small tolerance window.
    r = resid.astype(np.int64)
    r_clip = np.clip(r, 0, 100)
    # Bonus from exact match and one-off neighbors, weighted by frequency.
    bonus = hist[r_clip]
    if total > 1.0:
        left = np.clip(r_clip - 1, 0, 100)
        right = np.clip(r_clip + 1, 0, 100)
        bonus = bonus + 0.5 * (hist[left] + hist[right])
    bonus = bonus / total

    # Best fit is dominant; bonus is a small tie-breaker below it.
    return -resid.astype(np.float64) + 0.5 * bonus
# EVOLVE-BLOCK-END
