# EVOLVE-BLOCK-START
"""Best fit with selective adaptive consolidation diversion.

Best fit dominates to keep bins tight, but periodically we divert to a bin
whose post-placement residual is close to a common item size (a multiple of the
mean ~40), which keeps leftovers usable instead of leaving tiny slivers. The
diversion is limited to small items (where slivers form) and spread evenly with
a fractional phase so it doesn't fire in bursts.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Base: best-fit priority (tighter residual -> higher score).
    better_fit = -(bins - item)

    # Divert mainly when small items are arriving (these create slivers),
    # spread consolidation evenly using a fractional phase.
    if item < 55 and ((3 * n) % 7 == 0):
        resid = bins - item  # remaining after placing (>= 0)
        m = np.round(resid / _MEAN)
        dist = np.abs(resid - m * _MEAN)
        # Prefer residuals near a usable item-size multiple, but still
        # favour the tighter fit among equally good candidates.
        return -dist * 1000.0 + better_fit

    return better_fit
# EVOLVE-BLOCK-END

