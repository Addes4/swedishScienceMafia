# EVOLVE-BLOCK-START
"""Best fit with tie-broken residual usability.

Pure best fit (rank by tightest residual) is near-optimal for this
Weibull-shaped size distribution (mean ~40). The only freedom that helps is
how to break ties among bins with nearly equal residuals: we prefer residuals
that avoid leaving permanently unusable slivers, but the effect must not
overturn a genuinely tighter fit. We implement this as a lexicographic rule:
primary key is the residual after placement (smaller is better), and the
tie-break rewards residuals that can still fit at least one small item.
"""
import numpy as np

_MIN_ITEM = 1


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placing the item

    # Primary: best fit (tighter residual is better). Scale so that any
    # difference of 1 in residual dominates the tie-break below.
    primary = -resid

    # Secondary: mildly prefer residuals that are not tiny slivers, i.e. that
    # can still accept at least one more small item. This only matters among
    # bins with the same residual, so it never overturns best fit.
    usable = (resid >= _MIN_ITEM).astype(np.float64)

    return primary + 0.5 * usable
# EVOLVE-BLOCK-END
