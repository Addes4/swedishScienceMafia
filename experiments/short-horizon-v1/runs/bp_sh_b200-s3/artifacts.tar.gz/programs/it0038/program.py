# EVOLVE-BLOCK-START
"""Strict best fit with a penalty for leaving small unusable residuals.

The item distribution is Weibull-shaped with mean ~40, so residuals below
roughly 10 are rarely reusable. Best fit minimizes residual but may create
many tiny, unusable leftovers. This rule strongly prefers perfect fills and
penalizes residuals in the small-unusable zone, while otherwise behaving like
best fit.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    resid = bins - item  # post-placement remaining capacity, >= 0

    # Base: strict best fit (smaller residual -> higher score).
    score = -resid.astype(np.float64)

    # Penalize tiny unusable residuals (1..10): these almost never get reused
    # for items with mean ~40, so they waste capacity. Perfect fills (0) are
    # strongly preferred.
    small = (resid >= 1) & (resid <= 10)
    score = score - 5.0 * small.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
