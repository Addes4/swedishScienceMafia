# EVOLVE-BLOCK-START
"""Best fit with a residual-utility bonus driven by recent item sizes.

Pure best fit is strong but leaves residuals that no future item can use.
Since item sizes are integers from a fixed distribution, we track a small
running histogram of recent item sizes and give a modest bonus to bins whose
residual after placement equals a size that has been seen often recently.
The best-fit ordering stays primary, so this only breaks near-ties.
"""
import numpy as np

_state = {"n": 0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    st = _state
    st["hist"] *= 0.9  # decay so recent items dominate
    hist = st["hist"]
    # Best-fit primary key: tighter fit (smaller residual) -> higher score.
    residual = bins - item
    score = -residual.astype(np.float64)

    # Modest bonus when the leftover capacity matches a recently common item
    # size, so the bin can likely be filled exactly later.
    # Use frequency at that residual index, scaled below the unit gap of the
    # best-fit ordering so it only breaks ties.
    freq = hist[np.clip(bins - item, 0, 100).astype(np.int64)]
    score += 0.5 * freq

    st["hist"][item] += 1.0
    st["n"] += 1
    return score
# EVOLVE-BLOCK-END

