# EVOLVE-BLOCK-START
"""Best fit with a light aging bonus toward stale, less-full bins.

Pure best fit tends to keep many bins partially open, which fragments the
capacity. A small continuous bonus for bins that have not been used recently
encourages filling them up (or draining them) without the disruptive periodic
worst-fit diversion.
"""
import numpy as np

_state = {"n": 0, "last": {}}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1
    last = _state["last"]

    # Best-fit priority: tighter fit (smaller residual) -> higher score.
    score = -(bins - item).astype(np.float64)

    # Aging bonus: bins not touched for a while (and not completely full of
    # free space relative to others) get a slight preference to consolidate.
    # Only apply to bins that are clearly less-full than a tight fit would be.
    # Use a small coefficient so best-fit still dominates.
    if len(last) and bins.size:
        # approximate age: stream position minus last-touch for known bins,
        # default to a moderate age for unseen bins.
        ages = np.empty(bins.size, dtype=np.float64)
        for i in range(bins.size):
            ages[i] = n - last.get(i, n)
        # Only reward less-full bins (large remaining capacity) that are stale.
        # Normalize age into [0,1]-ish with a soft saturating curve.
        stale = ages / (ages + 30.0)
        # Slight bonus, scaled down, proportional to remaining free space.
        score = score + 3.0 * stale * (bins / 100.0)

    # Record which bin index the item is likely to go to (best score, first tie).
    best = int(np.argmax(score))
    last[best] = n

    return score
# EVOLVE-BLOCK-END

