# EVOLVE-BLOCK-START
"""Best fit with an always-on near-tie consolidating tie-break.

Pure best fit is strong for this distribution, but occasionally several bins
offer nearly the same residual.  In that near-tie window we prefer the bin
whose post-placement residual is large enough to still accept a typical item
(~40), reducing the number of permanent slivers.  The window is narrow so the
primary best-fit ordering is preserved almost everywhere.
"""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining after placing (>= 0 shown)
    min_resid = resid.min()

    if resid.size == 1:
        return resid.astype(np.float64)

    # Primary: best fit -> smaller residual scores higher.
    # Secondary: within a small window above the best residual, prefer
    # residuals that can still hold a typical item.  Implemented as a
    # continuous bonus that decays with distance from the best residual,
    # so it only acts among near-equivalent fits.
    window = 6.0
    near = np.clip((min_resid + window - resid) / window, 0.0, 1.0)
    usable = np.clip(resid / _MEAN, 0.0, 1.0)

    score = -resid + 3.0 * near * usable
    return score
# EVOLVE-BLOCK-END
