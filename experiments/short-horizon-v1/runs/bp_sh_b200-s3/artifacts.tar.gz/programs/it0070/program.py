# EVOLVE-BLOCK-START
"""Best-fit with a smooth sliver-avoidance tie-break.

Pure best-fit packs tightly but can leave many small unusable slivers.
We keep best-fit as the dominant criterion, then add a small bonus for
residuals that lie in "usable" regions: very close to full (residual near 0)
or large enough to still accept a future typical item. Residuals trapped in
the band just below the mean item size are penalized. The bonus is small
enough that it only breaks near-ties, so best-fit behavior dominates.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    resid = bins - item  # capacity left after placing (>= 0 for shown bins)

    # Dominant term: best-fit (tighter residual -> higher score).
    better_fit = -resid

    # Secondary term: discourage slivers. Residuals in (0, _MEAN) are
    # penalized proportionally to how far below _MEAN they sit; residual 0
    # (exactly full) and residuals >= _MEAN get no penalty.
    sliver = np.clip(1.0 - resid / _MEAN, 0.0, 1.0)
    # Zero out the penalty exactly at residual 0 (perfect fill is ideal).
    sliver = np.where(resid == 0, 0.0, sliver)

    return better_fit - 0.5 * sliver
# EVOLVE-BLOCK-END

