# EVOLVE-BLOCK-START
"""Best fit with adaptive residual coalescing.

Pure best fit is strong on this distribution but plateaus due to
fragmentation. We keep strict best-fit as the primary signal and only
intervene in two cheap, deterministic ways:

1. If the best fit is loose (minimum residual is large), the item is
   "wasting" its placement opportunity, so prefer the fullest bin that
   still fits (consolidation).
2. Otherwise, break near-ties by nudging residuals toward the running
   mean item size, so leftover gaps stay large enough to be reusable.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1
    _state["sum"] += item
    mean_item = _state["sum"] / (n + 1)

    resid = bins - item  # remaining capacity after placing item here

    # Primary: best fit -> smaller residual is better.
    score = -resid.astype(np.float64)

    # Tie-break nudge: prefer residuals near a typical item size so remaining
    # gaps stay usable. Scaled tiny so it only affects near-ties.
    score -= 0.01 * np.abs(resid - mean_item)

    # Diversification: if the tightest fit is still loose (large residual),
    # prefer the fullest bin that still fits, to consolidate space.
    if resid.min() > 0.5 * mean_item:
        score -= 0.001 * bins.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
