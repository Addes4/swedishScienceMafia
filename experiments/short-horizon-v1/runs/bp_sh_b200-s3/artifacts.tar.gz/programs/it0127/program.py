# EVOLVE-BLOCK-START
"""Best fit with a smooth "harmonic residual" tie-breaker.

Pure best fit is strong, but it frequently leaves tiny slivers (residuals of
1..3) that can never be filled by this Weibull-shaped distribution. We keep
best-fit dominant and add a small always-on bonus for post-placement residuals
that are themselves plausible future item sizes, so bins consolidate into
residuals that future items can actually fit into.
"""
import numpy as np

_STATE = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    _STATE["n"] += 1

    # Dominant term: best fit (tighter residual -> higher score).
    resid = bins - item

    # Smooth bonus: prefer residuals that are achievable item sizes (>=1),
    # softly penalising tiny unfillable slivers (resid 1..3 are wasteful).
    # Small weight keeps best-fit dominant so behavior stays near proven-good.
    small = np.where(resid < 4, -0.5, 0.0)

    return -(resid.astype(np.float64)) + small
# EVOLVE-BLOCK-END
