# EVOLVE-BLOCK-START
"""Best fit with tuned modulo-consolidation diversion.

Pure best fit leaves many small slivers for this distribution. On occasional
steps we divert to the bin whose residual after placement is closest to a
multiple of the mean item size (~40), which packs leftovers into fuller slots
and reduces overall fragmentation. Best-fit stays as the dominant baseline.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Base: best-fit priority (tighter residual -> higher score).
    better_fit = -(bins - item)

    if n % 3 == 1:
        resid = bins - item  # remaining after placing (>= 0)
        # Distance of residual to nearest multiple of the mean item size.
        m = np.round(resid / _MEAN)
        dist = np.abs(resid - m * _MEAN)
        # Prefer residual close to a multiple of _MEAN; tie-break tighter fit.
        return -dist * 1000.0 + better_fit

    return better_fit
# EVOLVE-BLOCK-END

