# EVOLVE-BLOCK-START
"""Best fit with a learned-residual tie-break.

Pure best fit is a strong online rule for this distribution. To squeeze out
extra gains we break near-ties using an online histogram of past item sizes:
when several bins fit almost equally tightly, prefer the one whose residual
after placement is a size that has been seen often before, since such a
residual is likely to be filled exactly by a future item, avoiding waste.
"""
import numpy as np

_state = {"n": 0, "hist": None}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Base: best-fit priority (tighter residual -> higher score).
    resid = bins - item
    better_fit = -resid

    # Update online histogram of item sizes (1..100).
    hist = _state["hist"]
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        _state["hist"] = hist
    hist[item] += 1.0

    # Only bother with the tie-break once we have some history.
    if n < 30:
        return better_fit

    # Frequency prior over residuals (residuals are 0..99).
    freq = hist[:100].copy()
    total = freq.sum()
    if total <= 0:
        return better_fit
    freq /= total

    # Score: closeness to best fit dominates; small bonus if the residual is
    # itself a commonly seen item size (so it can likely be filled exactly),
    # and a big bonus for residual exactly 0 (perfect fill).
    bonus = freq[resid.astype(np.int64)]
    bonus = bonus + 10.0 * (resid == 0)

    # Scale the bonus to only matter in near-ties (typical freq ~ 1/40 = 0.025).
    return better_fit + 0.15 * bonus
# EVOLVE-BLOCK-END
