# EVOLVE-BLOCK-START
"""Best fit with a concave residual utility.

Pure best fit minimizes the post-placement residual (r = bins - item), which
tends to create many bins with tiny leftover gaps that can never be filled by
the coarse item sizes of this distribution. Instead, reward exact fits
strongly and otherwise use a concave, gradual utility on the residual so that
leaving an unusable sliver is only mildly preferred over leaving a still-useful
amount of free space.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    r = bins - item  # post-placement residual (>= 0 for fitting bins)

    # Strong bonus for exact fills.
    score = (r == 0).astype(np.float64) * 1000.0

    # Concave utility on the residual: encourage leaving a reasonable gap
    # rather than a useless sliver, while still mildly preferring tighter fits.
    score += np.sqrt(r.astype(np.float64))

    return score
# EVOLVE-BLOCK-END

