# EVOLVE-BLOCK-START
"""Adaptive best-fit / worst-fit hybrid.

For this Weibull-shaped distribution (mean ~40), pure best-fit occasionally
creates many nearly-full bins that can never be closed. Placing *large* items
(>= half capacity) into the emptiest fitting bin tends to consolidate the
big items cleanly, while small items are still handled with best-fit to fill
slivers tightly.
"""
import numpy as np

_state = {"n": 0}
_LARGE = 50


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    _state["n"] += 1

    if item >= _LARGE:
        # Worst-fit: prefer the emptiest bin (largest remaining capacity).
        return bins.astype(np.float64)

    # Best-fit: prefer the tightest residual (smallest remaining capacity).
    return -(bins - item).astype(np.float64)
# EVOLVE-BLOCK-END
