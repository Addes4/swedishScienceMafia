# EVOLVE-BLOCK-START
"""Best fit with empty-bin preference among ties.

Pure best fit (tightest residual) is the strongest simple rule for this
Weibull-shaped distribution.  Earlier periodic modulo diversions produced
noise and slightly hurt the score, so we drop them entirely.  To squeeze a
little more, among near-ties (within a tiny epsilon of the tightest fit) we
prefer the bin with the largest post-placement residual, keeping emptier bins
available for larger future items and reducing tiny unfillable slivers.
"""
import numpy as np

_EPS = 1e-9


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item
    tightest = resid.min()
    # Slight preference for larger residual only among (near-)tightest fits.
    return -(resid) + _EPS * (resid - tightest)
# EVOLVE-BLOCK-END
