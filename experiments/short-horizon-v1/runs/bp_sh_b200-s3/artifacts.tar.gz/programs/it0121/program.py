# EVOLVE-BLOCK-START
"""Best fit with deferred bin opening.

Pure best fit is the dominant rule, but it occasionally opens a fresh unused
bin while a partially-filled bin could still fit the item.  By strongly
penalising placement into a completely empty (remaining == 100) bin, we keep
bins available for later items and tend to reduce the total bin count.
"""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    # Base: best-fit priority (tighter residual -> higher score).
    better_fit = -(bins - item)

    # Penalise opening a brand-new (still empty) bin, unless we must.
    empty = bins == 100
    # If any non-empty bin fits, forbid empty ones entirely; otherwise just
    # mildly prefer non-empty bins so best-fit still decides among the rest.
    if np.any(~empty):
        better_fit = np.where(empty, -np.inf, better_fit)

    return better_fit
# EVOLVE-BLOCK-END
