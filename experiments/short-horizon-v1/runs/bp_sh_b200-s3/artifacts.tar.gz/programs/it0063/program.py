# EVOLVE-BLOCK-START
"""Best fit with a soft, periodic modulo-consolidation nudge.

Pure best fit leaves many small slivers for this distribution. Periodically
we nudge the ranking toward the bin whose residual after placement is closest
to a multiple of the mean item size (~40). Unlike a hard override, the nudge
is blended with best-fit so that genuinely tight fits still win out; this
avoids the regressions seen when the diversion was forced.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Base: best-fit priority (tighter residual -> higher score).
    better_fit = -(bins - item)

    if n % 40 == 17:
        resid = bins - item  # remaining after placing (>= 0 shown)
        # Distance of residual to nearest multiple of the mean item size.
        m = np.round(resid / _MEAN)
        dist = np.abs(resid - m * _MEAN)
        # Prefer residual close to a multiple of _MEAN.
        modulo_score = -dist
        # Blend: small perturbation only, keep best-fit dominant.
        # Normalize modulo score roughly to the scale of fit scores.
        return better_fit * 1.0 + modulo_score * 0.5

    return better_fit
# EVOLVE-BLOCK-END


