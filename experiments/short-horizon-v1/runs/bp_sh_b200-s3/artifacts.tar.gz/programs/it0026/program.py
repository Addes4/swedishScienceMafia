# EVOLVE-BLOCK-START
"""Best fit with a small residual-value shaping bonus.

Pure best fit is a very strong baseline for this distribution. The only
change here is a tiny secondary term that prefers leaving a residual that
is comfortably larger than the current item (i.e. avoids creating exactly
tight "dead-zone" gaps), scaled small enough that it only breaks near-ties.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    # Primary criterion: best fit -> minimize post-placement residual.
    residual = bins - item
    score = -residual.astype(np.float64)

    # Tiny secondary term: among nearly-equal fits, mildly prefer bins whose
    # residual is larger (more room left for a future item). Scaled so it
    # cannot override the primary best-fit ordering.
    score += residual.astype(np.float64) / 1000.0

    return score
# EVOLVE-BLOCK-END
