# EVOLVE-BLOCK-START
"""Best fit with a perfect-fill preference and fuller-bin tie-break.

Pure best fit is a strong online baseline. The only refinement that reliably
helps here is to break residual ties in favour of exact fills and, failing
that, the fullest bin (smaller residual), so that near-perfect fits are
consolidated instead of spread across many nearly-empty bins.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    residual = bins - item

    # Primary: best fit (smaller residual -> higher score).
    score = -residual.astype(np.float64)

    # Secondary: prefer exact fills, then fuller bins. Scaled strictly below
    # one residual unit so it only breaks ties / near-ties.
    score += np.where(residual == 0, -0.5, 0.0)
    score += (-residual.astype(np.float64)) * 1e-6

    return score
# EVOLVE-BLOCK-END
