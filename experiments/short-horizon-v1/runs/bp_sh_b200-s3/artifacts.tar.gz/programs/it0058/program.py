# EVOLVE-BLOCK-START
"""Best fit with a periodic light Gaussian perturbation.

Pure best fit packs tightly but can lock into a deterministic plateau on this
Weibull-shaped item distribution. Occasionally adding a small amount of random
noise to the best-fit scores breaks ties/fragmentation patterns in a way that
boosting the least-full bin does not, while leaving best-fit behavior dominant.
"""
import numpy as np

_state = {"n": 0}
_rng = np.random.default_rng(12345)


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Best-fit priority: tighter fit (smaller residual) -> higher score.
    score = -(bins - item).astype(np.float64)

    # Occasionally add a small Gaussian jitter to all bins to escape the
    # deterministic best-fit plateau without abandoning tight packing.
    if n % 7 == 3:
        score = score + _rng.normal(0.0, 3.0, size=score.shape)

    return score
# EVOLVE-BLOCK-END
