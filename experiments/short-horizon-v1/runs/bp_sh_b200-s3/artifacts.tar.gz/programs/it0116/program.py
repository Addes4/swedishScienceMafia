# EVOLVE-BLOCK-START
"""Distribution-aware best fit.

Primary term: best fit (smaller post-placement residual is better).
Secondary term (always on, bounded below the primary tie tolerance):
prefer a post-placement residual that is itself a likely future item size,
estimated from a running histogram of observed item sizes. This converts
fragmentation-causing slivers into reusable gaps without disturbing the
established best-fit behavior on clear-cut choices.
"""
import numpy as np

_MEAN = 40.0
_HIST = np.zeros(101, dtype=np.float64)  # observed item size counts
_TOTAL = 0.0
_STATE = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    global _TOTAL

    n = _STATE["n"]
    _STATE["n"] = n + 1

    resid = bins - item  # remaining after placement (>= 0 for shown bins)

    # Primary: best fit. Negate residual so smaller residual scores higher.
    primary = -resid.astype(np.float64)

    # Estimate probability that a future item equals residual size r.
    # Use Laplace-smoothed histogram over [1,100]; zeros stay ~0.
    if _TOTAL > 0:
        prob = (_HIST[resid] + 1.0) / (_TOTAL + 101.0)
    else:
        # Cold start: bell around the mean.
        prob = np.exp(-0.5 * ((resid - _MEAN) / 20.0) ** 2) / 40.0

    # Secondary term scaled strictly below one unit of primary difference.
    # Residuals are integers, so primary differences are >=1; using <0.5
    # guarantees the primary dominates and this only refines near-ties.
    secondary = 0.49 * prob

    # Update histogram with the current item (after scoring).
    _HIST[item] += 1.0
    _TOTAL += 1.0

    return primary + secondary
# EVOLVE-BLOCK-END
