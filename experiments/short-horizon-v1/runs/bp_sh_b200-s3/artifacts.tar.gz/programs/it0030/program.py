# EVOLVE-BLOCK-START
"""Best fit with a periodic exact-fit completion bonus.

Pure best fit is the strong baseline for this distribution. The main
remaining waste comes from bins that end up with a residual no future item
can fill. Encouraging placements that exactly close a bin (residual equals
the item) consolidates space, so we give such exact fits an overwhelming
bonus, and otherwise stay purely best-fit.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Best-fit priority: tighter fit (smaller residual) -> higher score.
    score = -(bins - item)

    # Overwhelming bonus for bins this item would close exactly, so that
    # perfect fits are always taken over merely tight fits.
    exact = 10000.0 * (bins == item)
    score = score + exact

    return score
# EVOLVE-BLOCK-END
