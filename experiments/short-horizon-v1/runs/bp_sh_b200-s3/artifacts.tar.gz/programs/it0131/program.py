# EVOLVE-BLOCK-START
"""Best fit with an always-on concave penalty on post-placement residual.

Pure best fit already wins for this distribution; the win here comes from a
smooth, deterministic refinement. Instead of a noisy periodic diversion we
score each bin by a concave function of its post-placement residual, so the
rule still strongly prefers the tightest fit (residual near 0), but among
relatively loose fits it differentiates by how close the leftover is to a
"useful" size. Residuals left in [1, 2] are effectively unfillable slivers
and are penalized slightly harder than a plain linear residual would imply,
which encourages placements that don't create tiny waste.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining capacity after placing item (>= 0)

    # Best-fit base: smaller residual -> higher priority.
    # Apply a smooth concave slight penalty for creating tiny slivers.
    # sqrt compresses large residuals and makes near-zero residuals dominate
    # without ever overturning the ordering for very tight fits.
    score = -resid - 0.5 / (resid + 1.0)

    return score
# EVOLVE-BLOCK-END
