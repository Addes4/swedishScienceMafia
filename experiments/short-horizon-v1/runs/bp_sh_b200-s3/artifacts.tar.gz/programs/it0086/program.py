# EVOLVE-BLOCK-START
"""Best fit with periodic first-fit (fullest-bin) consolidation.

Pure best fit is a strong online rule for this distribution, but it can leave
bins with medium residuals that no single item will ever fill. Periodically
diverting to the fullest bin that still fits the item (first-fit) consolidates
small residuals into fuller bins and reduces the total bin count. The diversion
is deterministic in call index so behavior is reproducible.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Periodic diversion: choose the fullest bin that still fits (first fit).
    if n % 40 == 13:
        # bins holds remaining capacity; smaller residual = fuller bin.
        # Highest score should go to the smallest residual.
        return -bins

    # Base: best fit (tighter residual after placing -> higher score).
    return -(bins - item)
# EVOLVE-BLOCK-END
