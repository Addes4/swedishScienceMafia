# EVOLVE-BLOCK-START
"""Best fit with periodic modulo-consolidation diversion.

Pure best fit leaves many small slivers for this distribution. Occasionally
we divert to the bin whose residual after placement is closest to a multiple
of the mean item size (~40), which packs leftovers into fuller slots and
reduces overall fragmentation, while keeping best-fit as the baseline.
"""
import numpy as np

_state = {"n": 0}
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Base: best-fit priority (tighter residual -> higher score).
    better_fit = -(bins - item)

    if n % 50 == 17:
        resid = bins - item  # remaining after placing (>= 0 shown)
        # Distance of residual to nearest multiple of the mean item size.
        m = np.round(resid / _MEAN)
        dist = np.abs(resid - m * _MEAN)
        # Prefer residual close to a multiple of _MEAN.
        return -dist

    return better_fit
# EVOLVE-BLOCK-END

