# EVOLVE-BLOCK-START
"""Best fit with subset-sum-aware residual preference.

The item distribution has mean about 40 and items are integers, so certain
residuals (multiples and complement-ish values of typical item sizes) are much
more likely to be exactly filled by future items.  Pure best fit ignores this
and can leave a bin with a residual that no future item can ever close.

This rule keeps best fit as the baseline but, among bins with a small residual
after placement, prefers the residual closest to a "useful" value set derived
from the distribution (0, and values near 100 - k*mean).  When the best fit is
already good (residual below a threshold), we stay with pure best fit so we
never regress on the common case.
"""
import numpy as np

_state = {"n": 0}

# Residuals that are likely to be exactly fillable by future items.
_USEFUL = np.array([0.0, 12.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0, 80.0, 90.0])


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    residual = bins - item  # remaining capacity if we place here

    # Baseline: best fit (smaller residual -> higher score).
    score = -residual.astype(np.float64)

    # Only consider diversification when no bin gives an exact/near-exact fit.
    best = residual.min()
    if best > 3:
        # Distance from each residual to the nearest "useful" value.
        d = np.abs(residual[:, None] - _USEFUL[None, :]).min(axis=1)
        # Add a bounded bonus: prefer residuals likely to be fillable later.
        score = score + 0.5 * (1.0 / (1.0 + d))

    return score
# EVOLVE-BLOCK-END
