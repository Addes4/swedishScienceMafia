# EVOLVE-BLOCK-START
"""Best fit with a small residual-match bonus.

Pure best fit is the strongest simple online rule for this distribution, but
it tends to leave slivers. We keep best-fit (smallest post-placement residual)
as the dominant term, and add a tiny bonus for bins whose residual after
placement equals a value recently seen as an item size, since such residuals
are likely to be filled exactly by a future item. The bonus is small enough
not to override genuine fit differences.
"""
import numpy as np

_state = {"n": 0, "counts": {}}
_MEAN = 40.0
_HIST_LEN = 64  # window of recent item sizes considered "likely next"


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Base: best-fit priority (tighter residual -> higher score).
    resid = bins - item  # remaining after placing (>= 0 for shown bins)
    better_fit = -resid

    # Update a small recency-weighted histogram of item sizes.
    counts = _state["counts"]
    counts[item] = counts.get(item, 0) + 1
    if n > _HIST_LEN:
        # decay occasionally so the window stays recent
        if n % _HIST_LEN == 0:
            for k in list(counts.keys()):
                counts[k] = counts[k] * 0.5
                if counts[k] < 0.5:
                    del counts[k]

    # Bonus: residual close to a commonly seen item size (likely future fit).
    # Only apply to small residuals where exact refill is plausible.
    bonus = np.zeros_like(resid, dtype=float)
    if counts:
        # Consider the most frequent few item sizes.
        common = sorted(counts.items(), key=lambda kv: -kv[1])[:8]
        for sz, c in common:
            w = min(c, 8.0) / 8.0
            bonus += w * np.maximum(0.0, 1.0 - np.abs(resid - sz))

    return better_fit + 0.10 * bonus
# EVOLVE-BLOCK-END
