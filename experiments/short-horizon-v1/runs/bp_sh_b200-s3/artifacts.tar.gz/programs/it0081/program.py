# EVOLVE-BLOCK-START
"""Best fit with online sliver-avoidance tie-breaking.

Pure best fit is strong for Weibull-like items (mean ~40). Its main weakness
is creating tiny unusable residuals ("slivers") that can never be refilled.
We keep best fit as the primary criterion, but within a small window of
near-tie residuals we prefer the bin whose post-placement residual is either
almost empty (near 0, i.e. nearly perfectly filled) or large enough to still
accept a typical future item. The "typical size" is tracked online from the
running mean of observed items, so the rule adapts to the stream.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}

# Residual within this many units of the tightest fit is considered a tie.
_WINDOW = 3.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["sum"] += item
    _state["n"] = n + 1
    mean = _state["sum"] / (n + 1)

    resid = bins - item                 # residual after placing item (>= 0)
    tight = np.min(resid)               # best-fit residual (smallest)

    # Best-fit primary score: tighter (smaller resid) is better.
    score = -resid.astype(np.float64)

    # Sliver-avoidance secondary term, applied only to near-tie bins so it
    # cannot override a genuinely better fit.
    near = resid <= tight + _WINDOW
    if np.any(near):
        # Prefer residuals that are either near 0 (great fill) or >= mean
        # (still usable by a typical future item). Penalize the middle band,
        # which tends to be a permanent sliver.
        good = (resid <= 1.0) | (resid >= mean - 1.0)
        bonus = np.where(good, 0.5, 0.0)
        score = score + np.where(near, bonus, 0.0)

    return score
# EVOLVE-BLOCK-END
