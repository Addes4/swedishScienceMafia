# EVOLVE-BLOCK-START
"""Best fit with a soft mean-residual tie-break.

Pure best fit is hard to beat, but for a Weibull item distribution many bins
end with tiny slivers just below the typical item size. We keep best-fit as the
dominant ranking, but among bins whose post-placement residual is already small
(within one item's worth of the best), we softly prefer residuals close to the
running empirical mean, which packs leftovers into gaps likely to be reused by
future items.
"""
import numpy as np

_state = {"s": 0.0, "n": 0}
_MEAN0 = 40.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1

    # Running mean of observed item sizes (used for the residual target).
    s = _state["s"] + item
    _state["s"] = s
    mean = s / (n + 1) if n > 0 else _MEAN0

    resid = bins - item  # remaining capacity after placement (>= 0)

    # Dominant term: best fit (smaller residual better).
    best = resid.min()

    # Among residuals close to the best, softly prefer near the running mean.
    # Only consider bins within a modest window above the best residual.
    win = mean  # allow residuals up to one mean above the best
    close = resid <= (best + win)

    # Score: base is -resid; add a small bonus for closeness to mean for the
    # "close" bins. Smaller deviation from mean -> higher score.
    dev = np.abs(resid - mean)
    # Normalize bonus into a small range so it never overrides best-fit order.
    bonus = np.where(close, (win - dev) * 1e-3, 0.0)
    return -resid + bonus
# EVOLVE-BLOCK-END
