# EVOLVE-BLOCK-START
"""Best fit with a deterministic fuller-bin tie-break.

Pure best fit (smallest residual after placement) is a strong online rule for
this item distribution. The only ambiguity is ties / near-ties in residual:
strict index order can scatter items across bins that fit equally well. Here
we keep residual minimization as the dominant criterion and add a tiny bonus
proportional to how full the bin already is, so near-ties resolve toward the
fuller bin. This consolidates items into already-used bins and tends to reduce
the total number of bins opened.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    # Dominant term: smaller post-placement residual -> much higher score.
    residual = bins - item
    # Tie-break: prefer bins that are already fuller (smaller remaining
    # capacity before placement). Add as a tiny monotone bonus.
    fullness = 100.0 - bins
    return -(residual.astype(np.float64)) + 1e-3 * fullness.astype(np.float64)
# EVOLVE-BLOCK-END

