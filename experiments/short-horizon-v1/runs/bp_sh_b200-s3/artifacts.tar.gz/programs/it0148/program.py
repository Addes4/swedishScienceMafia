# EVOLVE-BLOCK-START
"""Best fit with a dead-zone guard.

Pure best fit packs tightly but happily creates tiny residuals that later items
cannot use (slivers). Here we keep best fit as the fallback, but when the
arriving item is small enough that slivers are a real risk, we restrict the
choice to bins whose post-placement residual is either near-zero (a perfect
fill) or at least a small dead-zone threshold, so we don't churn small unusable
leftovers. If no bin qualifies we fall back to plain best fit.
"""
import numpy as np

_state = {"n": 0, "min_item": 100.0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    n = _state["n"]
    _state["n"] = n + 1
    if item < _state["min_item"]:
        _state["min_item"] = float(item)

    # Base: best-fit priority (tighter residual -> higher score).
    better_fit = -(bins - item)

    # Only small items tend to leave unusable slivers.
    if item <= 40:
        resid = bins - item  # remaining after placing (>= 0)
        deadzone = max(5.0, 0.15 * _state["min_item"])
        # Accept perfect fills and residuals above the dead zone.
        ok = (resid <= 2) | (resid >= deadzone)
        # Bad residuals (just inside the dead zone) are pushed far down,
        # while ordering among accepted bins still follows best fit.
        penalty = np.where(ok, 0.0, 1000.0)
        return better_fit - penalty

    return better_fit
# EVOLVE-BLOCK-END
