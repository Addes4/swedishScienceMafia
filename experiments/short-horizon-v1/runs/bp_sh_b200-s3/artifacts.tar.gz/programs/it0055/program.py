# EVOLVE-BLOCK-START
"""Best fit with a residual-usability guard.

Pure best fit is a strong baseline but tends to leave medium residuals that
no future item can use. Add a tiny, sharply-thresholded bonus only when the
resulting residual is >= the current item size (so the gap can hold another
item), leaving pure best-fit behavior for tight/perfect fits.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    _state["n"] += 1

    residual = bins - item  # remaining space after placing item

    # Base: tighter fit (smaller residual) -> higher score.
    score = -residual.astype(np.float64)

    # Small bonus only if the leftover can still hold another item like this one.
    usable = residual >= item
    score += 0.5 * usable

    return score
# EVOLVE-BLOCK-END
