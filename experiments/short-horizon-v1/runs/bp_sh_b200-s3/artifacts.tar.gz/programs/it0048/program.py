# EVOLVE-BLOCK-START
"""Best-fit with a threshold: don't leave a residual that can't hold a typical item.

Pure best-fit on this Weibull-shaped distribution (mean ~40) frequently leaves
tiny residuals that are useless for future items. Instead of the arbitrary
periodic diversification, we rank bins by tightest residual but heavily prefer
bins whose residual is at least a fraction of the mean item size, so leftovers
stay reusable. This is state-free and deterministic.
"""
import numpy as np

MEAN_ITEM = 40.0
# Residuals at least this large are considered "reusable".
GOOD_RESIDUAL = 0.5 * MEAN_ITEM


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    # Base: best fit (smaller residual -> higher score).
    score = -(bins - item)

    # Bonus for bins that keep a reusable residual after placement.
    # residuals in `bins` are remaining capacities (>= item for fitting bins).
    healthy = bins >= (item + GOOD_RESIDUAL)
    score = score + 5.0 * healthy.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

