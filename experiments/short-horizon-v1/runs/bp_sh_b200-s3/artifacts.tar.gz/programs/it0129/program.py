# EVOLVE-BLOCK-START
"""Best fit with an always-on "fillability" tie-breaker.

Pure best fit is strong, but it sometimes leaves tiny residuals (slivers)
that later items can rarely fill, wasting capacity. We keep best-fit as the
dominant term and add a small, smooth secondary penalty that discourages
post-placement residuals that are implausibly small (below the bulk of the
item distribution), while mildly preferring residuals near common item sizes
so leftover space stays usable.
"""
import numpy as np

_MEAN = 40.0
_STD = 20.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    resid = bins - item  # remaining after placing (>= 0 for shown bins)

    # Dominant term: best-fit (tighter post-placement residual is better).
    best_fit = -resid

    # Secondary: penalize residuals that are small relative to the typical
    # item size, since such slivers are unlikely to be refilled usefully.
    # A smooth penalty growing as residual shrinks below ~mean item size.
    sliver = np.maximum(0.0, (_MEAN * 0.5) - resid)  # 0 for resid >= 20
    sliver_pen = -0.35 * sliver

    return best_fit + sliver_pen
# EVOLVE-BLOCK-END

