# EVOLVE-BLOCK-START
"""Best fit with an exact-completion bonus from an empirical item-size histogram."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    hist = _state["hist"]
    hist[int(item)] += 1.0
    _state["n"] += 1

    # Base: strict best fit (smallest residual).
    resid = bins - item
    score = -(resid.astype(np.float64))

    # Exact-completion bonus: reward leaving a residual equal to a size we
    # have observed often, so a future item can complete the bin exactly.
    if _state["n"] >= 30:
        w = hist / _state["n"]
        # Weight for residual r = freq of items of size r.
        bonus = w[np.clip(resid, 0, 100).astype(np.int64)]
        score += 40.0 * bonus

    return score
# EVOLVE-BLOCK-END
