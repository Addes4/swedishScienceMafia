# EVOLVE-BLOCK-START
"""Best fit, with a robust bonus when the leftover equals a common item size."""
import numpy as np

_state = {"sizes": [], "count": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    st = _state
    it = int(item)
    st["sizes"].append(it)
    st["count"][it] += 1.0
    st["n"] += 1

    # Decay old observations so the histogram tracks the current distribution.
    if st["n"] % 500 == 0:
        st["count"] *= 0.5

    n = st["n"]
    if n >= 20:
        cnt = st["count"]
        total = cnt.sum()
        freq = cnt / total  # empirical probability of each size
    else:
        freq = None

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Dominant term: tightest fit = smallest residual.
    score = -resid.astype(np.float64)

    # Robust tie-break: reward residuals that are themselves likely item sizes,
    # so the leftover can be consumed by a future item.
    if freq is not None:
        r = resid
        valid = (r >= 1) & (r <= 100)
        idx = np.clip(r, 0, 100).astype(np.int64)
        bonus = freq[idx]
        score += np.where(valid, 8.0 * bonus, 0.0)

    # Penalize opening a fresh bin when a partial one can take the item.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
