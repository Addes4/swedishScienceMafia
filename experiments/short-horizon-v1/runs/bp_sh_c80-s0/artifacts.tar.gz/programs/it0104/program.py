# EVOLVE-BLOCK-START
"""Best fit with a decisive completion bonus, otherwise strict tightest fit."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Base: prefer tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Decisive bonus for perfect completion (residual exactly zero).
    score += np.where(resid == 0, 1000.0, 0.0)

    # Strong preference not to open a fresh bin when a valid partial fill exists.
    empty = bins == 100
    score -= np.where(empty, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END
