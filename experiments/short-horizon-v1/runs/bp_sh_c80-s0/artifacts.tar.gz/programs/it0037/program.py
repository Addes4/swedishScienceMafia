# EVOLVE-BLOCK-START
"""Best fit with a bonus for residuals that are integer multiples of the item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: strongly prefer the smallest residual (best fit).
    score = -residual.astype(np.float64)
    # Small bonus when the residual is a multiple of the item size,
    # encouraging several equal-size items to share a bin snugly.
    if item > 0:
        mult = (residual % item) == 0
        score += 0.25 * mult
    return score
# EVOLVE-BLOCK-END

