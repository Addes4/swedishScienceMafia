# EVOLVE-BLOCK-START
"""Best-fit with a mild, low-variance reuse bonus for residuals near a typical item."""
import numpy as np

_state = {"n": 0, "mean": 40.0}


def priority(item, bins):
    # Running mean of item sizes (simple, low variance).
    n = _state["n"]
    mean = _state["mean"]
    mean = (mean * n + float(item)) / (n + 1)
    _state["n"] = n + 1
    _state["mean"] = mean

    resid = bins - item  # remaining capacity after placing (shown bins all fit)

    # Base: prefer the tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Mild reuse bonus: a residual close to a typical item size can be refilled later.
    band = mean
    # Small bonus, scaled so it only slightly biases among near-equal fits.
    score -= np.abs(resid - band) * 0.02

    # Slight preference to not open a fresh bin when a valid partial fill exists.
    empty = bins == 100
    score -= np.where(empty, 0.1, 0.0)

    return score
# EVOLVE-BLOCK-END

