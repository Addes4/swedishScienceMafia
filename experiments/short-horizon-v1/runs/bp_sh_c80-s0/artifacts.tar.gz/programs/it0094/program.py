# EVOLVE-BLOCK-START
"""Best fit with a lightweight learned reusability prior on the residual."""
import numpy as np

_state = {"sizes": [], "mn": 1}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 4000:
        del sizes[:2000]

    if len(sizes) >= 30:
        arr = np.array(sizes, dtype=np.float64)
        mu = float(arr.mean())
        mn = float(arr.min())
    else:
        mu = 40.0
        mn = 1.0

    _state["mn"] = mn

    resid = (bins - item).astype(np.float64)  # >= 0 for the bins shown

    # Base: tightest fit (smallest residual).
    score = -resid

    # Strong penalty for leaving a residual too small to hold a typical item.
    # mn is the smallest item seen so far; a residual below it is likely dead.
    dead = (resid > 0) & (resid < mn)
    score -= np.where(dead, 4.0, 0.0)

    # Mild bonus when residual is close to the typical item size: such a
    # leftover is likely to be consumed exactly by a future item.
    diff = np.abs(resid - mu)
    score += np.where(diff < 0.15 * mu, 3.0, 0.0)
    score += np.where(diff < 0.35 * mu, 1.0, 0.0)

    # Avoid opening a fresh bin while a partial bin can absorb the item.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
