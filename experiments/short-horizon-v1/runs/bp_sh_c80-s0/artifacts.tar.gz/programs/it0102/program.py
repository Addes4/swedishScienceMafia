# EVOLVE-BLOCK-START
"""Pure best fit: place item in the fullest bin it fits into."""
import numpy as np


def priority(item, bins):
    # Prefer the bin with the smallest remaining capacity that still fits
    # the item, i.e. the tightest residual after placement.
    return -(bins.astype(np.float64))
# EVOLVE-BLOCK-END

