# EVOLVE-BLOCK-START
"""Sum-of-Squares bin packing heuristic."""
import numpy as np


def priority(item, bins):
    # bins = remaining capacity before placement
    before = bins.astype(np.float64)
    after = before - float(item)
    # Minimize after^2 - before^2  -> largest reduction of squared free space.
    score = before * before - after * after
    return score
# EVOLVE-BLOCK-END
