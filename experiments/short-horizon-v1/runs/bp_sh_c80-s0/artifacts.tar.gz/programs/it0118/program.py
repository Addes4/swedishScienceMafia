# EVOLVE-BLOCK-START
"""Adaptive best-fit: tightest residual dominates; exact-completion bonus for
residuals matching commonly observed item sizes; strong anti-empty-bin penalty."""
import numpy as np

_state = {"sizes": [], "hist": np.zeros(101, dtype=np.float64)}

# Refresh histogram every this many observations to keep it cheap.
_REFRESH = 32


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    n = len(sizes)
    if n > 2000:
        del sizes[:1000]
        n = len(sizes)

    hist = _state["hist"]
    # Periodically rebuild a normalized histogram of observed item sizes.
    if n >= 16 and (n % _REFRESH == 0 or hist.sum() == 0.0):
        arr = np.array(sizes, dtype=np.int64)
        h = np.bincount(arr, minlength=101).astype(np.float64)
        hist[:] = h / h.sum()

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Dominant term: prefer the tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Bonus: residual exactly matches a size we commonly see -> a future item
    # can complete this bin exactly. Use log to compress frequency weighting.
    if hist.sum() > 0.0:
        freq = hist[resid]
        score += 4.0 * np.log1p(freq * 100.0)

    # Decisive anti-empty-bin penalty: don't open a fresh bin until we must.
    empty = bins == 100
    score -= np.where(empty, 3.0, 0.0)

    return score
# EVOLVE-BLOCK-END
