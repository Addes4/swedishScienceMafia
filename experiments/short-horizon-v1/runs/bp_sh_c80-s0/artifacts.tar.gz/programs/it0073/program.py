# EVOLVE-BLOCK-START
"""Best fit toward a target residual of roughly one more typical item."""
import numpy as np


class _State:
    samples = None


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = _State
    if s.samples is None:
        s.samples = []
    # running estimate of typical item size (median-ish), cheap online update
    s.samples.append(item)
    if len(s.samples) > 256:
        # keep it bounded
        s.samples = s.samples[-128:]
    target = float(np.median(s.samples))

    residual = bins - item  # remaining capacity after placing the item
    # We want to land near `target` residual: bins that end up around one more
    # typical item are most useful. Penalize distance from target.
    # But never allow tiny unusable slivers to look good: distance dominates.
    score = -np.abs(residual - target)
    return score
# EVOLVE-BLOCK-END
