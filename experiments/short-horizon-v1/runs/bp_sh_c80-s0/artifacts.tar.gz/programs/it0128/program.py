# EVOLVE-BLOCK-START
"""Best fit with a deterministic reward for residuals that are plausible item sizes."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    # Estimate the typical item size from observed history.
    if len(sizes) >= 20:
        arr = np.array(sizes, dtype=np.float64)
        mu = arr.mean()
        sd = arr.std()
    else:
        mu = 40.0
        sd = 20.0

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Base: prefer tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Deterministic secondary term: a residual that is itself a plausible item size
    # will very likely be consumed exactly by a future item, so reward it.  Scale by
    # how close the residual is to the mean, weighted by the observed spread.
    one_sd = sd if sd > 1.0 else 10.0
    closeness = np.exp(-((resid - mu) ** 2) / (2.0 * one_sd * one_sd))
    score += 2.0 * closeness

    # Strong preference not to open a fresh bin when a valid partial fill exists.
    empty = bins == 100
    score -= np.where(empty, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END

