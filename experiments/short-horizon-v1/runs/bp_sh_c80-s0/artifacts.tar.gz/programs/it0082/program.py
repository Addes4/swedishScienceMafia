# EVOLVE-BLOCK-START
"""Best-fit with a sliver-avoidance penalty.

Pure best fit picks the tightest fit, which often leaves tiny unusable residuals.
We add a small penalty for residuals that are too small to hold a typical item,
pushing those placements toward bins whose leftover remains usable.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # post-placement remaining capacity, >= 0

    # A leftover below this threshold is a "sliver": too small to hold a typical
    # item (mean ~40), so it tends to be wasted. Penalize such placements.
    sliver = np.minimum(residual, 20).astype(np.float64)

    # Base: prefer tightest fit. Penalty: avoid creating slivers.
    return -residual.astype(np.float64) - sliver
# EVOLVE-BLOCK-END

