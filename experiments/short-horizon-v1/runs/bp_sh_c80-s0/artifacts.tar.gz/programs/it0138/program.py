# EVOLVE-BLOCK-START
"""Pure Best-Fit: minimize the residual left behind."""
import numpy as np


def priority(item, bins):
    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Dominant: tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Tiny tie-break: slightly discourage opening a fresh (empty) bin.
    empty = bins == 100
    score -= np.where(empty, 1e-6, 0.0)

    return score
# EVOLVE-BLOCK-END

