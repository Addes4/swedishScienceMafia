# EVOLVE-BLOCK-START
"""Best fit with a subtle earlier-bin tie-break to avoid opening new bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, ties to first bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer the bin with the smallest residual capacity after placement.
    residual = bins - item
    n = bins.shape[0]
    # Break near-ties (within a couple units) toward earlier bins to discourage
    # opening/using later bins when a nearly-as-tight early bin exists.
    order = np.arange(n, dtype=np.float64)
    return -(residual.astype(np.float64) + 0.001 * order)
# EVOLVE-BLOCK-END

