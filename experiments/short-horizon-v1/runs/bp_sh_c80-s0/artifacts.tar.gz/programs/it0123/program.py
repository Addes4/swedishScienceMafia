# EVOLVE-BLOCK-START
"""Best fit with a small penalty on tiny residuals that can never be filled."""
import numpy as np

_state = {"sizes": [], "small": 0}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    # Track the smallest item seen so far (an empty residual below this is dead space).
    if len(sizes) >= 5:
        small = int(min(sizes[-1000:]))
    else:
        small = 1
    if small < 1:
        small = 1

    resid = bins - item  # remaining capacity after placing

    # Base: prefer the tightest fit (smallest residual), classic best-fit.
    score = -(resid.astype(np.float64))

    # Penalize residuals that are positive but below the smallest item we expect
    # to ever see again; such bins are effectively dead (unusable) space.
    dead = (resid > 0) & (resid < small)
    score -= np.where(dead, 2.0, 0.0)

    # Prefer not to open a fresh bin unless it is the tightest available fit.
    empty = bins == 100
    score -= np.where(empty, 0.001, 0.0)

    return score
# EVOLVE-BLOCK-END
