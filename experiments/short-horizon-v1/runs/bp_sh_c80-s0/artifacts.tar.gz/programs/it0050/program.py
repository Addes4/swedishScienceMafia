# EVOLVE-BLOCK-START
"""Best fit with a harmonic-style tie-break toward a target residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary criterion: best fit (smallest resulting residual).
    Tie/near-tie break: prefer the residual closest to a harmonic target of 50,
    which helps keep leftover pockets usable for future items.
    """
    residual = bins - item
    # Primary: best fit -> higher priority for smaller residual.
    # We encode lexicographic preference by a large negative slope on residual
    # plus a small bonus shaping toward the target residual.
    target = 50.0
    return -(residual.astype(np.float64)) - 1e-3 * np.abs(residual.astype(np.float64) - target)
# EVOLVE-BLOCK-END
