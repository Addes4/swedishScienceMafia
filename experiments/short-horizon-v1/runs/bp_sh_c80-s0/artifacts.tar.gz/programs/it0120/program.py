# EVOLVE-BLOCK-START
"""Best fit with deterministic harmonic-class tie breaking.

The dominant term is strict best-fit (smallest residual).  Ties are broken by a
deterministic harmonic weight derived from the arriving item size, favouring
bins whose residual falls in a class that is likely to be exactly refilled by
later items of similar size.  No stream state is used, making the rule stable
across every instance.
"""
import numpy as np


def priority(item, bins):
    item = int(item)
    resid = bins - item  # remaining capacity after placing (>= 0)

    # Dominant term: strict best fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Deterministic harmonic weight class of the item size.
    # Larger items -> coarser class; small items -> finer classes.
    if item <= 0:
        w = 1.0
    else:
        w = 1.0 / (1.0 + np.floor(100.0 / item))

    # Reward residuals that are a near multiple of the item size: such leftovers
    # can be completed exactly by a later item of the same size, reducing
    # fragmentation without any noisy estimation.
    if item > 0 and item <= 100:
        rem = np.mod(resid, item)
        exact = (rem == 0) & (resid >= 0)
        close = (~exact) & (np.minimum(rem, item - rem) <= max(1, item // 4))
        score += np.where(exact, 3.0 + w, 0.0)
        score += np.where(close, 0.5 + w, 0.0)

    # Perfect fill is always best: strong, deterministic bonus.
    score += np.where(resid == 0, 5.0, 0.0)

    # Avoid opening a fresh bin when a valid partial fill is available.
    score -= np.where(bins == 100, 1.0, 0.0)

    # Mild penalty for unusable slivers (too small to hold a reasonable item).
    sliver = (resid > 0) & (resid < max(1, item // 4))
    score -= np.where(sliver, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END

