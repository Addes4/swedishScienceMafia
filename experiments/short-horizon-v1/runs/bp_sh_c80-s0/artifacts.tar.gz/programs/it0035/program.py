# EVOLVE-BLOCK-START
"""Best fit with a mild look-ahead: rank by post-placement residual, but nudge
toward bins whose leftover is a usable size for a typical future item."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Score every bin; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacities of bins the item fits, in bin order.
    """
    s = _state["sum"] + item
    n = _state["n"] + 1
    _state["sum"] = s
    _state["n"] = n
    mean = s / n

    residual = bins - item            # leftover after placing here
    # base: prefer tightest fit (smallest residual)
    # nudge: among sizes that are still "useful", residual near typical item
    #        size is good; an exactly-0 residual is always best.
    target = mean
    # distance of residual from target, but exact fits dominate
    d = np.abs(residual - target)
    # exact fit gets a big bonus so we never pass it up
    bonus = np.where(residual == 0, 1000.0, 0.0)
    return -d + bonus
# EVOLVE-BLOCK-END
