# EVOLVE-BLOCK-START
"""Best fit with a strong, principled preference for exact fits and small residuals."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 4000:
        del sizes[:2000]

    # Estimate minimum observed item size to identify unusable slivers.
    if len(sizes) >= 30:
        arr = np.array(sizes, dtype=np.float64)
        smin = float(arr.min())
    else:
        smin = 1.0

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Base: tightest fit (smallest residual) is the strongest known rule.
    score = -(resid.astype(np.float64))

    # Exact fit: residual 0 is strictly dominant, make it win decisively.
    score += np.where(resid == 0, 50.0, 0.0)

    # Small bonus when the leftover happens to be a usable size (>= smallest seen item),
    # this nudges ties toward residuals that can still accept a future item.
    reusable = resid >= smin
    score += np.where(reusable, 0.5, 0.0)

    # Strongly discourage opening a fresh bin when any used bin is shown.
    empty = bins == 100
    score -= np.where(empty, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
