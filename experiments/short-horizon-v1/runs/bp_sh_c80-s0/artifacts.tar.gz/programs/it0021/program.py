# EVOLVE-BLOCK-START
"""Best fit with a small tie-break that prefers residuals that future items can fill.

Primary: minimize the post-placement residual (classic best fit).
Tie-break: among bins with the same residual, prefer the one whose residual is
NOT a tiny value that no typical future item (< ~10) can fill well, by nudging
the score slightly. This keeps best-fit behaviour intact (no regression) while
occasionally avoiding stranding 1..3 units of capacity.
"""
import numpy as np

# Residuals in this set are considered "bad" (hard to fill later) - tiny slivers.
_BAD = np.zeros(101, dtype=np.float64)
for _r in (1, 2, 3):
    _BAD[_r] = 1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    residual = bins - item
    # Primary: smallest residual (most negative => best fit).
    # Secondary (tiny epsilon): penalize stranded tiny residuals slightly less
    # than "good" residuals? No - we want to *discourage* tiny residuals, so add
    # a small positive penalty to their score for larger residuals? Careful:
    # higher score = better. best-fit wants small residual => score = -residual.
    # To discourage bad residuals, subtract a tiny penalty from their score.
    score = -residual.astype(np.float64)
    bad = _BAD[np.clip(residual, 0, 100)]
    # Only apply the epsilon so it never overrides a 1-unit residual difference.
    return score - 1e-6 * bad
# EVOLVE-BLOCK-END

