# EVOLVE-BLOCK-START
"""Best-fit with a target-residual bias learned online from past items."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin it fits in.
    """
    n = _state["n"]
    if n == 0:
        target = 40.0
    else:
        target = _state["sum"] / n

    _state["sum"] += item
    _state["n"] = n + 1

    residual = bins - item  # >= 0 since all shown bins fit the item

    # Prefer exact-ish fits; otherwise bias the leftover toward the running mean.
    # Score: larger is better.
    # Primary term: how close the leftover residual is to a desired leftover.
    # Desired leftover: prefer 0 if an exact fit is possible near target; else target.
    # We use a smooth score: minimize |residual - desired| where desired blends 0 and target.
    desired = np.minimum(target, residual.max() if residual.size else 0.0)
    # Strong preference to keep residual small (best fit), but pull toward `desired`
    score = -np.abs(residual - desired) - 0.5 * residual
    return score
# EVOLVE-BLOCK-END
