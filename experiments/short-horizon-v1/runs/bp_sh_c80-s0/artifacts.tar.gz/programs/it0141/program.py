# EVOLVE-BLOCK-START
"""Best fit with an exact-complement pairing bonus for consolidation."""
import numpy as np


def priority(item, bins):
    resid = bins - item  # remaining capacity after placing (>=0 for shown bins)

    # Base: tightest fit (smallest resulting residual).
    score = -(resid.astype(np.float64))

    # Strong bonus when the resulting residual exactly matches another open
    # bin's current residual: such two partials can be completed later.
    # Also reward when residual matches a currently open bin's capacity minus
    # zero to encourage pairing identical gaps.
    rset = set(int(r) for r in bins)
    matches = np.array([1.0 if int(r) in rset else 0.0 for r in resid],
                       dtype=np.float64)
    score += 3.0 * matches

    # Mild preference not to open a fresh bin.
    empty = bins == 100
    score -= np.where(empty, 0.25, 0.0)

    return score
# EVOLVE-BLOCK-END
