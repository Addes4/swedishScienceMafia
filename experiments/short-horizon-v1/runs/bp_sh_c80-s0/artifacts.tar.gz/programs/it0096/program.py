# EVOLVE-BLOCK-START
"""Best fit with a pairing bonus for residuals that match the item size."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    # Estimate the typical item size band from observed history.
    if len(sizes) >= 20:
        arr = np.array(sizes, dtype=np.float64)
        mu = arr.mean()
        sd = arr.std()
    else:
        mu = 40.0
        sd = 20.0

    tmp = int(mu)
    if tmp < 1:
        tmp = 1
    if tmp > 100:
        tmp = 100
    band = tmp
    tol = int(0.25 * band) + 1

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Base: prefer tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Bonus if residual is a "useful" leftover near the typical size band.
    useful = (resid >= 0) & (resid <= 100)
    near_band = useful & (np.abs(resid - band) <= tol)
    score += np.where(near_band, 6.0, 0.0)

    reusable = useful & (resid >= band - tol) & (resid <= 100)
    score += np.where(reusable, 1.0, 0.0)

    sliver = useful & (resid > 0) & (resid < max(1, band - tol))
    score -= np.where(sliver, 1.0, 0.0)

    # Pairing bonus: residual close to the current item size means the leftover
    # can be filled by another item of similar size, matching optimal pairing.
    pair = useful & (np.abs(resid - item) <= max(1, int(0.15 * item)))
    score += np.where(pair, 4.0, 0.0)

    # Mildly prefer residuals that match an exact recent item size.
    if len(sizes) >= 40:
        uniq = set(sizes[-500:])
        exact = np.array([1.0 if int(r) in uniq else 0.0 for r in resid], dtype=np.float64)
        score += 0.5 * exact

    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
