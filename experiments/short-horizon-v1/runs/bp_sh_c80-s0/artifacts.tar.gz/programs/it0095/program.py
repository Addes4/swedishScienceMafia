# EVOLVE-BLOCK-START
"""Best fit with a smooth, learned residual-utility bonus.

Items have mean ~40, capacity 100.  The classic insight (dual bin packing /
harmonic) is that after placing an item the leftover capacity should itself be
a good "target" for future items.  Instead of hard bands we use a smooth,
concave utility of the residual: residuals near a typical item size are the most
reusable (they can be filled exactly by one item), while tiny slivers and
near-full bins are less valuable.
"""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    if len(sizes) >= 20:
        arr = np.array(sizes, dtype=np.float64)
        mu = float(arr.mean())
        sd = float(arr.std())
    else:
        mu = 40.0
        sd = 20.0

    if mu < 1.0:
        mu = 1.0
    if mu > 100.0:
        mu = 100.0
    if sd < 1.0:
        sd = 1.0

    resid = bins.astype(np.float64) - float(item)  # >= 0 for shown bins

    # Smooth residual utility: a Gaussian bump centered at the typical item
    # size.  Leftovers close to a whole item are the most reusable; leftovers
    # far from that (slivers or near-full remainders) are worth less.
    util = np.exp(-0.5 * ((resid - mu) / sd) ** 2)

    # Base: prefer the tightest fit (smallest residual) -> best fit.
    score = -resid + 4.0 * util

    # Avoid opening a fresh bin when a valid partial fill already exists.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
