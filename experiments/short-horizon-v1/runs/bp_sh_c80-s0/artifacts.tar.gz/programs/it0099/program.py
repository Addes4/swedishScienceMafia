# EVOLVE-BLOCK-START
"""Best fit with a matching-residual completion bonus."""
import numpy as np

_state = {"sizes": [], "counts": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    sizes = _state["sizes"]
    counts = _state["counts"]
    sizes.append(int(item))
    counts[int(item)] += 1.0
    if len(sizes) > 3000:
        # decay counts to keep them representative
        counts *= 0.5
        del sizes[:1500]

    # Smoothed empirical distribution over item sizes 1..100.
    # Estimate probability a future item has a given size.
    if counts.sum() >= 30:
        w = counts.copy()
        # light smoothing
        w = w + np.concatenate(([0.0], w[:-1])) * 0.5 + np.concatenate((w[1:], [0.0])) * 0.5
        p = w / w.sum()
    else:
        p = np.zeros(101, dtype=np.float64)
        # default: broad uniform-ish prior around mean 40
        for s in range(1, 101):
            p[s] = np.exp(-0.5 * ((s - 40.0) / 20.0) ** 2) + 1e-3
        p /= p.sum()

    sizes_axis = np.arange(101, dtype=np.float64)

    resid = bins - item  # remaining capacity after placing this item

    # Base: prefer tightest fit (smallest residual).
    score = -(resid.astype(np.float64)) * 1.0

    # Completion bonus: prob that some future single item exactly fills the residual.
    # residual r can be filled by an item of size r.
    r_clip = np.clip(resid, 0, 100).astype(np.int64)
    fill_prob = p[r_clip]
    score += fill_prob * 30.0

    # Also reward residuals near a common item size (within +-2), smooth match.
    # Expected value of being able to pair this residual with a future item.
    match_val = np.zeros_like(resid, dtype=np.float64)
    for d in (-2, -1, 1, 2):
        idx = np.clip(r_clip + d, 0, 100)
        match_val += p[idx] * (0.5 ** abs(d))
    score += match_val * 8.0

    # Penalize leaving a tiny sliver (< smallest likely useful item) that wastes space.
    # Estimate a small threshold from distribution: 10th percentile of observed sizes.
    if counts.sum() >= 30:
        cum = np.cumsum(p)
        small = int(np.searchsorted(cum, 0.10)) 
        small = max(1, min(20, small))
    else:
        small = 8
    sliver = (resid > 0) & (resid < small)
    score -= np.where(sliver, 3.0, 0.0)

    # Mild preference not to open a fresh bin.
    empty = bins == 100
    score -= np.where(empty, 0.3, 0.0)

    return score
# EVOLVE-BLOCK-END

