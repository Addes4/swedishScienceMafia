# EVOLVE-BLOCK-START
"""Best fit with a strong preference against opening fresh bins."""
import numpy as np


def priority(item, bins):
    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Base: prefer tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Strongly avoid opening a fresh bin when any valid partial fill exists.
    empty = bins == 100
    score -= np.where(empty, 5.0, 0.0)

    return score
# EVOLVE-BLOCK-END

