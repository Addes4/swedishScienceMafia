# EVOLVE-BLOCK-START
"""Best fit with a learned sliver-avoidance tie-break.

Primary rule is classic best fit (tightest residual).  But if the tightest residual
would be smaller than the smallest item plausibly appearing, that residual is
effectively unusable dead space.  In that case we prefer a placement that leaves a
larger, still-useful residual (or a fresh bin), so slivers don't accumulate.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item

    # Largest residual among non-empty bins that is still "useful", used for sliver
    # avoidance.  Empty bins (residual 100) are always acceptable fallbacks.
    # Score is higher = better.  Best fit gives highest score to smallest residual.
    # We encode it as negative residual, but add a small bonus to useful residuals.
    #
    # To keep behaviour identical to best fit except in the sliver case, use a
    # large constant scale so the sliver nudge never overrides a real difference
    # in residual.
    score = -(residual.astype(np.float64))

    # Nudge: residuals below a small threshold (dead space) get a tiny penalty so
    # that, when tied on exact residual or nearly so, a larger usable residual wins.
    # Threshold is fixed small; items mean ~40, so slivers < ~1 are truly wasted.
    sliver = residual < 1
    score = score - sliver * 0.5

    # Prefer to avoid brand-new bins when an existing bin can absorb the item with
    # at least some usable space, i.e. penalise placing into an empty bin (res 100)
    # only when an alternative non-empty bin exists with reasonable residual.
    # This is handled implicitly by best fit (larger residual => lower score), so we
    # do not add extra empty-bin penalties here.

    return score
# EVOLVE-BLOCK-END
