# EVOLVE-BLOCK-START
"""Best-fit with a harmonic residual target: prefer tight fits, but when several bins
are close, choose the one whose leftover best matches a reusable pocket size."""
import numpy as np

_state = {"n": 0, "mean": 40.0}

def priority(item, bins):
    # Online mean estimate of item sizes (used only to modulate tie-breaks mildly).
    s = _state
    s["n"] += 1
    a = 1.0 / min(s["n"], 200.0)
    s["mean"] = (1.0 - a) * s["mean"] + a * float(item)
    m = s["mean"]

    resid = bins - item  # resulting residual if placed here (all bins fit)

    # Best-fit base: smaller residual is better, so use negative residual.
    base = -resid.astype(np.float64)

    # Mild harmonic bonus: reward residuals that form a reusable pocket
    # (close to the running mean, or near zero for a perfectly filled bin),
    # penalize tiny slivers that waste capacity.
    target = m
    pocket = -np.abs(resid - target)
    full = -np.where(resid < 3, 0.0, 1e9)

    # Keep best-fit dominant; break near-ties toward reusable/full residuals.
    return base * 1000.0 + pocket * 0.5 + full * 0.25
# EVOLVE-BLOCK-END
