# EVOLVE-BLOCK-START
"""Best fit with deterministic pseudo-random jitter to break near-ties."""
import numpy as np


def priority(item, bins):
    """Return a priority per bin; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in, in bin order.
    """
    post = bins.astype(np.int64) - item          # residual after placement
    idx = np.arange(bins.shape[0], dtype=np.int64)
    # deterministic jitter in [0, 1) from a simple integer hash of (item, index)
    h = (idx * 2654435761 + item * 40503 + 12345) & 0xFFFFFFFF
    jit = (h % 1000) / 1000.0
    # primary: smallest residual; jitter only perturbs by < 1 unit
    return -(post.astype(np.float64) + jit)
# EVOLVE-BLOCK-END
