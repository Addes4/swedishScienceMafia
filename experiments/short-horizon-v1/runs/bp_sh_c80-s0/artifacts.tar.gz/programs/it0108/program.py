# EVOLVE-BLOCK-START
"""Best fit with a light nudge toward residuals that recent items can complete."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    # Estimate a typical item size and spread from observed history.
    if len(sizes) >= 20:
        arr = np.array(sizes, dtype=np.float64)
        mu = arr.mean()
        sd = arr.std()
    else:
        mu = 40.0
        sd = 20.0

    band = int(mu)
    if band < 1:
        band = 1
    if band > 100:
        band = 100
    tol = int(0.25 * band) + 1

    resid = bins - item  # residual after placing (>= 0 for shown bins)

    # Base: strict tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    useful = resid >= 0

    # Bonus when the residual could be completed by a single typical item.
    near_band = useful & (np.abs(resid - band) <= tol)
    score += np.where(near_band, 6.0, 0.0)

    # Secondary: residual big enough to hold at least one typical item.
    reusable = useful & (resid >= band - tol)
    score += np.where(reusable, 1.0, 0.0)

    # Penalty for leaving slivers too small to be useful.
    sliver = useful & (resid > 0) & (resid < max(1, band - tol))
    score -= np.where(sliver, 1.0, 0.0)

    # Light preference against opening a fresh bin when partial fills exist.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END

