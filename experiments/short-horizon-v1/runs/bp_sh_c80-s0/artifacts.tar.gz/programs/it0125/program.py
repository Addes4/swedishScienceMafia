# EVOLVE-BLOCK-START
"""Harmonic/class-based online bin packing with tight-fit tie-breaks."""
import numpy as np

_CAP = 100.0
# Harmonic class boundaries relative to capacity: 1/2, 1/3, 1/4, ...
_BOUNDS = np.array([1.0 / k for k in range(1, 12)], dtype=np.float64)  # 1, 1/2, 1/3, ...


def _class_of(frac):
    # frac in (0,1]; return harmonic class index (smaller index = larger item)
    # class k: (1/(k+1), 1/k]
    # find largest k such that frac <= 1/k
    for k in range(1, 12):
        if frac > 1.0 / (k + 1):
            return k
    return 11


def priority(item, bins):
    item = float(item)
    resid = bins.astype(np.float64) - item  # >= 0 for shown bins

    f_item = item / _CAP  # item fraction of capacity
    k_item = _class_of(f_item)

    # Harmonic-style target: pack items of the same class together so that
    # a bin holding class-k items rejects items of the same class once it
    # would overflow, keeping residuals "compatible".  We score by how close
    # the post-placement residual is to a multiple of the class's item size,
    # which maximizes future exact fits.
    # Use the class's nominal item size.
    nominal = _CAP / k_item

    # Distance from residual being an integer multiple of the item's nominal
    # class size (i.e., the bin is "clean" for future same-class items).
    m = np.round(resid / nominal)
    m = np.maximum(m, 0.0)
    clean_dist = np.abs(resid - m * nominal)

    score = -clean_dist  # prefer clean residuals

    # Strong reward for exact fill (residual zero => bin closed optimally).
    score += np.where(resid < 1e-9, 5.0, 0.0)

    # Secondary: best-fit (tightest residual) as tie-break, small weight.
    score -= 0.01 * resid

    # Discourage opening fresh bins.
    empty = bins == 100
    score -= np.where(empty, 0.2, 0.0)

    return score
# EVOLVE-BLOCK-END
