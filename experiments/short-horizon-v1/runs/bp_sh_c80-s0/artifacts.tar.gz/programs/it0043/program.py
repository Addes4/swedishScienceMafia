# EVOLVE-BLOCK-START
"""Best fit with a small-gap-repair tie-break toward typical item sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities (including unused bins at 100).
    """
    residual = bins - item  # post-placement remaining capacity, >= 0

    # Primary: best fit -> smallest residual.
    min_res = residual.min()

    # Among bins nearly as tight as the best, prefer residuals near the mean
    # item size (~40) so the leftover gap can accept a future typical item.
    window = max(1, item // 16)  # small tolerance window
    close = residual <= (min_res + window)

    target = 40.0
    closeness = -np.abs(residual - target)

    # Score: tightly-fitting bins get a strong base; within the window the
    # closeness to the typical item size decides.
    score = -residual.astype(float)
    score = np.where(close, -min_res + (closeness - closeness.min()) * 1e-3, score)
    return score
# EVOLVE-BLOCK-END
