# EVOLVE-BLOCK-START
"""Best fit with a consolidation tie-break.

The item goes into the bin it fits most tightly (smallest residual). When several
bins give the same residual, prefer the bin that already holds more (smaller
remaining capacity), which consolidates slivers instead of scattering them.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual -> highest score).
    # Tie-break: prefer the more-loaded bin (smaller current capacity) by a
    # sub-unit epsilon so it only matters when residuals are equal.
    return -residual.astype(np.float64) - 1e-3 * bins.astype(np.float64)
# EVOLVE-BLOCK-END
