# EVOLVE-BLOCK-START
"""Best-fit augmented with a look-ahead residual target learned online.

The item goes into the bin whose post-placement residual is closest to a "good"
residual value: 0 (perfect fit) is always excellent, but so is the residual that
matches a size commonly seen in the stream.  We learn a histogram of arriving
sizes and accumulate, for each candidate residual, an estimate of how likely a
future item is to exactly fill it (a "fill value").  We score bins by combining
the tightness of fit with this fill-value estimate.
"""
import numpy as np

# Running statistics kept across calls within a stream.
_HIST = np.zeros(101, dtype=np.float64)   # count of observed sizes 1..100
_TOTAL = 0.0

# Precompute a static prior over sizes so we aren't blind at the start.
# Rough shape of the Weibull-like distribution (mean ~40): weight tails.
_PRIOR = np.zeros(101, dtype=np.float64)
for _s in range(1, 101):
    # A cheap unimodal prior peaking around 40; monotonically shaped.
    _PRIOR[_s] = np.exp(-(((_s - 40.0) / 22.0) ** 2))
_PRIOR[0] = 0.0


def _fill_score(residual):
    """Estimate desirability of leaving `residual` empty in a bin.

    A residual is good if it is small (perfect/near fits) OR if it equals a
    size that the stream commonly produces (so a future item can exactly fill it).
    """
    r = int(round(residual))
    if r < 0:
        return -1e9
    if r == 0:
        return 1e6
    if r > 100:
        # A whole empty bin: worst (it starts a new bin for a small item).
        return -1.0
    # Probability mass on this exact residual from observed sizes + prior.
    mass = (_HIST[r] + 0.5 * _PRIOR[r] * 5.0) / (_TOTAL + 5.0 * _PRIOR.sum() + 1.0)
    # Tightness term: prefer small residuals when fill mass is comparable.
    tight = 1.0 / (1.0 + r)
    return mass + 1e-3 * tight


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities the item fits in, in order.
    """
    global _TOTAL
    # Record the arriving item for future residual-target estimation.
    it = int(item)
    if 1 <= it <= 100:
        _HIST[it] += 1.0
    _TOTAL += 1.0

    b = np.asarray(bins)
    residual = b - it  # >= 0 for every bin shown (item fits by construction)

    # Clamp residuals > 100 (empty bins) so they aren't treated as fillable sizes.
    scores = np.empty(residual.shape, dtype=np.float64)
    for i in range(residual.shape[0]):
        scores[i] = _fill_score(residual[i])
    return scores
# EVOLVE-BLOCK-END
