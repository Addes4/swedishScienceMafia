# EVOLVE-BLOCK-START
"""Best-fit with size-class niche targeting.

Classic online packing theory (Harmonic / Modified-Harmonic / Advanced-Harmonic) shows that
pure best-fit wastes space because it always leaves the smallest possible residual, which is
often too small to be useful and destroys a nearly-full bin's ability to take one more item.
Instead we partition item sizes into a handful of classes and give each class a small set of
"target residual" values (niches).  For an arriving item we compute the post-placement residual
for every bin and prefer a bin whose residual lands near one of the target residuals for the
item's class; if none is close we fall back to best-fit.
"""
import numpy as np


# For each class we list the residuals we *want* to leave behind.  The idea: an item of size s
# belongs to class c; we prefer leaving a leftovers value L such that L + s (or L + some multiple)
# neatly fills a bin later.  Values chosen to match the Weibull-ish size distribution.
_TARGETS = (
    # class lower bounds (size >= lb) -> tuple of preferred post-placement residuals
    (1,  (0, 40, 50, 60, 70, 80, 90)),     # tiny items: fill exactly or leave big chunks
    (20, (0, 45, 55, 65, 75, 85)),          # small items: leave a big-item worth gap
    (33, (0, 34, 40, 50, 60, 67)),          # medium items
    (50, (0, 25, 30, 40, 50)),              # large items: pair with medium leftovers
    (67, (0, 10, 20, 33)),                  # very large: fit into a big gap
    (85, (0, 10, 15)),                      # near-full bins only
    (100, (0,)),                            # full-size items: only exact fits matter
)


def _targets_for(item):
    best = _TARGETS[0][1]
    for lb, t in _TARGETS:
        if item >= lb:
            best = t
        else:
            break
    return best


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # post-placement remaining capacity (>= 0 by construction)

    targets = _targets_for(item)
    # best-fit distance: prefer small residuals
    bf = -np.abs(residual).astype(np.float64)

    # niche distance: how far the residual is from any preferred target for this class
    # (0 distance -> perfect)
    dist = None
    for t in targets:
        d = np.abs(residual - t)
        dist = d if dist is None else np.minimum(dist, d)

    # Score: strongly favour bins whose residual hits a target, then best-fit.
    score = -dist.astype(np.float64) * 2.0 + bf * 1e-3
    return score
# EVOLVE-BLOCK-END
