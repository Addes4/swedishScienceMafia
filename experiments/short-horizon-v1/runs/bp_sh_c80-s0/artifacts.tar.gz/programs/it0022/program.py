# EVOLVE-BLOCK-START
"""Best fit with a near-exact fill preference."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Standard best fit: maximize -residual (i.e. minimize residual).
    # Small boost for near-exact fits so that residuals in [0, k) dominate.
    k = 5
    near = residual < k
    return -residual.astype(np.float64) + near.astype(np.float64) * 1e-3
# EVOLVE-BLOCK-END
