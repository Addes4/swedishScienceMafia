# EVOLVE-BLOCK-START
"""Strict best fit with a residual-diversity tie-break."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Dominant term: strict tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Tie-break: among near-equal residuals, prefer a residual value that is
    # currently uncommon among the bins, so leftovers stay varied and more
    # likely to match a future item exactly.
    vals, counts = np.unique(resid, return_counts=True)
    inv = dict(zip(vals.tolist(), counts.tolist()))
    rarity = np.array([1.0 / inv.get(int(r), 1) for r in resid], dtype=np.float64)
    score += 1e-3 * rarity

    return score
# EVOLVE-BLOCK-END

