# EVOLVE-BLOCK-START
"""Harmonic-style bin choice: prefer fills that leave a class-useful residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Post-placement residual for every bin.
    res = bins - item

    # Reward tight fits, but give a bonus when the leftover residual is itself
    # a "good" capacity: large enough that it can still hold a typical item,
    # or exactly zero (perfectly packed).
    # scaled residual (smaller leftover -> higher base score)
    base = -res.astype(np.float64)

    # bonus for leaving a residual that can still hold an average item (>= ~40)
    # and bonus for exact fits (res == 0)
    mid_bonus = np.where((res >= 40), 1.0, 0.0)
    exact_bonus = np.where(res == 0, 2.0, 0.0)
    # penalize tiny unusable slivers (0 < res < 10)
    sliver_penalty = np.where((res > 0) & (res < 10), -1.0, 0.0)

    return base + mid_bonus + exact_bonus + sliver_penalty
# EVOLVE-BLOCK-END

