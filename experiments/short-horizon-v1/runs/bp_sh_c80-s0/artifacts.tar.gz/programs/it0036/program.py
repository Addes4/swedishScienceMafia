# EVOLVE-BLOCK-START
"""Best-fit with exact-fill preference."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best fit: minimize residual after placement (tightest fit).
    score = -residual
    # Slight bonus for exact fills (residual 0) to strongly prefer perfect packing.
    score = score + (residual == 0).astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END
