# EVOLVE-BLOCK-START
"""Best fit in relative terms: prefer the bin whose leftover fraction is smallest,
but strongly prefer non-empty bins over fresh ones unless the fit is poor."""
import numpy as np


def priority(item, bins):
    residual = bins - item                     # leftover after placement (>=0 for fitting bins)
    frac = residual / 100.0                    # leftover as fraction of capacity
    # prefer tight (small leftover fraction); small constant bias to used bins
    used_bonus = np.where(bins < 100, 0.02, 0.0)
    return -frac + used_bonus
# EVOLVE-BLOCK-END

