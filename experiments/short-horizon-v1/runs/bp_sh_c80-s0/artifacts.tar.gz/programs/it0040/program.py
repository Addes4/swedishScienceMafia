# EVOLVE-BLOCK-START
"""Best fit, but nudge mid-size items toward residuals that match common item sizes."""
import numpy as np


def priority(item, bins):
    residual = bins - item  # post-placement residual (>=0 since only fitting bins are shown)
    base = -residual.astype(np.float64)

    # Track a running estimate of typical item sizes to build "nice" target residuals.
    # We use a tiny fixed set of plausible target residuals derived from item size.
    targets = (item, 2 * item, (item + 1) // 2, 100 - item)

    score = base.copy()
    # Favor leaving a residual equal to a common item size (good future fits) without
    # sacrificing the tightest fit by much: only among bins within 1 of the minimum residual.
    if residual.size:
        best = residual.min()
        near = residual <= best + 1
        for t in targets:
            if t <= 0:
                continue
            # prefer bins whose resulting residual equals t and are near-optimal
            m = near & (residual == t)
            if m.any():
                score += m.astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END
