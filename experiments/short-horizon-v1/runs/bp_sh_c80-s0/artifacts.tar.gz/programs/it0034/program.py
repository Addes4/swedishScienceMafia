# EVOLVE-BLOCK-START
"""Best fit with a class-aware exact-fit preference for small items."""
import numpy as np


_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Exact-fit preference for small items when a perfectly fitting bin exists.
    n = _state["n"]
    mean = (_state["sum"] / n) if n > 0 else 40.0
    _state["n"] = n + 1
    _state["sum"] += item

    if item <= mean * 0.5:
        zero = residual == 0
        if zero.any():
            score = -residual.astype(np.float64)
            score += zero.astype(np.float64) * 1000.0
            return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
