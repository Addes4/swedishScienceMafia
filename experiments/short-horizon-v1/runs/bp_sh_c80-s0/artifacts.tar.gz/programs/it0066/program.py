# EVOLVE-BLOCK-START
"""Best fit with an age tie-break: prefer the older bin among near-equal fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    idx = np.arange(bins.shape[0])
    # Primary: best fit -> smallest resulting residual (bins - item).
    residual = bins - item
    # Secondary: among near-equal residuals (within 1), prefer older bins (lower index).
    # Use a small epsilon keyed on residual so near-ties get broken by age, while
    # clearly better fits still win.
    return -(residual.astype(np.float64) * 2.0 + idx * 0.001)
# EVOLVE-BLOCK-END
