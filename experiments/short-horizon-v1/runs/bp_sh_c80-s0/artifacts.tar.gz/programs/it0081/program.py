# EVOLVE-BLOCK-START
"""Best-fit with a small nudge toward filling bins near capacity."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer the tightest fit, breaking ties toward fuller bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Remaining capacity after placing the item: bins - item.
    residual = bins - item
    # Pure best-fit: smallest residual first (most tightly packed).
    # Add a tiny nudge so that among near-equal residuals, the bin that ends up
    # closest to full (smaller residual) is preferred -- identical to best-fit,
    # but expressed as a combined score for numerical stability.
    return -(residual * 1000.0)
# EVOLVE-BLOCK-END
