# EVOLVE-BLOCK-START
"""Best fit with a small, online-statistics tie-break toward reusable residuals."""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    s = _state
    s["count"] += 1
    # Running mean of item sizes (used only as a weak bias).
    if s["count"] == 1:
        s["sum"] = float(item)
        mean = float(item)
    else:
        s["sum"] += float(item)
        mean = s["sum"] / s["count"]

    residual = bins - item  # remaining capacity after placing

    # Primary: best fit (smaller residual is better).
    base = -residual.astype(np.float64)

    # Weak bonus: residuals close to a typical item size (mean) are more reusable
    # than slivers, so nudge toward them without overriding best fit.
    # Only meaningful for non-trivial residuals.
    bonus = -0.05 * np.abs(residual - mean).astype(np.float64)

    return base + bonus
# EVOLVE-BLOCK-END
