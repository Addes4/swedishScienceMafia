# EVOLVE-BLOCK-START
"""Best fit with a deterministic exact-completion bonus from a size histogram."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "count": 0}


def priority(item, bins):
    hist = _state["hist"]
    hist[item] += 1.0
    _state["count"] += 1
    if _state["count"] > 4000:
        hist *= 0.5
        _state["count"] = 2000

    resid = bins.astype(np.float64) - item

    # Base: tightest fit dominates.
    score = -resid * 1000.0

    # Bonus when the residual equals a size we've actually seen often:
    # a future item of that exact size would fill the bin perfectly.
    valid = resid >= 0
    ri = np.clip(resid.astype(np.int64), 0, 100)
    seen = hist[ri] * valid
    score += seen * 50.0

    # Bonus for exact zero residual (perfect fill right now).
    score += np.where(resid == 0, 500.0, 0.0)

    # Penalty for leaving a sliver that nothing can use.
    score -= np.where(valid & (resid > 0) & (resid < 10), 200.0, 0.0)

    # Strong preference against opening a fresh empty bin.
    score -= np.where(bins == 100, 500.0, 0.0)

    return score
# EVOLVE-BLOCK-END
