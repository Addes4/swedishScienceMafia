# EVOLVE-BLOCK-START
"""Best fit with residual fragmentation tie-breaking."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    # Typical item size from observed history.
    if len(sizes) >= 30:
        arr = np.array(sizes, dtype=np.float64)
        mu = float(arr.mean())
    else:
        mu = 40.0
    if mu < 1.0:
        mu = 1.0
    if mu > 100.0:
        mu = 100.0

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)
    resid_f = resid.astype(np.float64)

    # Base: tightest fit (smallest residual) dominates.
    score = -resid_f

    # Tie-break: prefer residuals that a typical item can exactly fill or
    # that leave a reusable chunk near a multiple of the typical size.
    # Fractional part of resid/mu close to 0 or 1 means well-aligned packing.
    frac = (resid_f / mu) % 1.0
    align = np.minimum(frac, 1.0 - frac)  # 0 = perfect multiple
    score -= 0.02 * align

    # Discourage leaving slivers too small for any meaningful item.
    sliver = (resid_f > 0) & (resid_f < 1.0)
    score -= np.where(sliver, 0.5, 0.0)

    # Strong preference not to open a fresh (empty) bin.
    empty = bins == 100
    score -= np.where(empty, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
