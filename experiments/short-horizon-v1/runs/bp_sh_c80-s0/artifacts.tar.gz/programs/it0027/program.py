# EVOLVE-BLOCK-START
"""Best-fit with a stateful snugness guard tuned to the running item mean."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = _state
    s["n"] += 1
    s["sum"] += item
    mean = s["sum"] / s["n"]

    residual = bins - item  # >= 0 for every shown bin

    # Prefer leaving a residual that matches a typical future item well, but
    # always strongly prefer tighter fits (smaller residual).  Bigger items get
    # the classic best-fit behavior; small items are steered toward bins that
    # end up nearly full yet not exactly full.
    target = mean * 0.5
    penalty = np.abs(residual - target) * (mean / (item + 1e-9))
    return -(residual * 1e6 + penalty)
# EVOLVE-BLOCK-END
