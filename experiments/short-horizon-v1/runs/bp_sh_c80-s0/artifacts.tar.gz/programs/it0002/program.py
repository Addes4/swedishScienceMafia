# EVOLVE-BLOCK-START
"""Hybrid best-fit with residual targeting.

Idea: pure best-fit (smallest leftover) is a strong baseline for online bin packing, but it
tends to fragment capacity with medium/large items. Here we score each bin by how close the
leftover capacity (bins - item) is to a target residual that depends on the item size: small
items favor leaving bins near-full so future large items still find fits, while larger items
favor leaving a residual big enough to host typical mid-size items from the distribution.
This keeps the packing tight without over-gluing large items into the same bins.
"""
import numpy as np


def priority(item, bins):
    leftover = bins - item  # >= 0 for all shown bins

    # Target residual after placement. For the Weibull-ish distribution (mean ~40),
    # a residual near ~30-40 tends to accept future mid-size items well.
    # Small items: keep bins as full as possible (target ~0).
    # Large items: leave a usable hole (target ~40).
    target = 40.0 * (item / 100.0)

    # Prefer bins whose resulting leftover is close to target.
    closeness = -(leftover - target) ** 2

    # Tiebreak by smallest leftover (classic best-fit behavior).
    return closeness - 0.01 * leftover
# EVOLVE-BLOCK-END

