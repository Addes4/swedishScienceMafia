# EVOLVE-BLOCK-START
"""Best fit with a residual-quality adjustment.

Best-fit (tightest remaining capacity that still fits) is strong for the bulk of
the Weibull-distributed items, but it often leaves tiny unusable residuals.
This rule keeps the best-fit ordering as the primary signal and adds a mild
correction based on the residual left after placement: residuals that are
either nearly zero (no waste) or comfortably large (still useful) are mildly
rewarded, while residuals in the awkward middle are slightly penalized.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities of all bins the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Primary signal: best-fit (smaller residual is better).
    best_fit = -residual.astype(np.float64)

    # Residual-quality adjustment.
    # Reward very small residuals (little waste) and residuals large enough
    # to still fit a typical future item; mildly penalize the awkward middle.
    r = residual.astype(np.float64)

    # Sharply reward near-zero leftovers.
    tight_bonus = 1.0 / (1.0 + r)

    # Reward leftovers that are still useful for a mean-sized item.
    useful = np.minimum(r, 40.0) / 40.0

    return best_fit + 0.5 * tight_bonus + 0.2 * useful
# EVOLVE-BLOCK-END

