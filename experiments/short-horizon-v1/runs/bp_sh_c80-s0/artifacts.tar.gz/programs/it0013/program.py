# EVOLVE-BLOCK-START
"""Best fit with a penalty for leaving a residual that is small and rarely usable."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins.astype(np.float64) - float(item)
    # Best-fit core: tighter residual is better.
    score = -residual
    # Penalize leaving a residual of exactly 1: only a size-1 item could fill it,
    # which is very unlikely under the Weibull distribution, so it's essentially wasted.
    score -= 0.5 * (residual == 1.0)
    return score
# EVOLVE-BLOCK-END

