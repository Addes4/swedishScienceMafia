# EVOLVE-BLOCK-START
"""Best fit with a reusable-residual tie-break driven by an item-size histogram."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0
_decay = 0.999


def priority(item, bins):
    global _count
    it = int(item)
    _hist[it] += 1.0
    _count += 1
    if _count > 4000:
        _hist *= _decay
        _count = int(_count * _decay) + 1

    resid = bins - it  # >= 0 for shown bins

    # Dominant term: tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Secondary: reward residuals that are themselves common item sizes,
    # making the leftover likely reusable by a future item.
    total = _hist.sum()
    if total > 0:
        freq = _hist / total
    else:
        freq = _hist
    # Only consider residuals in the plausible item range.
    idx = np.clip(resid, 0, 100).astype(np.int64)
    reuse = freq[idx]
    score += 2.0 * reuse

    # Mild penalty for opening a fresh empty bin.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
