# EVOLVE-BLOCK-START
"""Distribution-aware best fit.

Items are drawn from a fixed Weibull-shaped distribution with mean about 40.
Pure best-fit minimizes the post-placement residual, which tends to leave many
tiny unusable gaps.  Instead we score each bin by how "useful" the residual
it would leave behind is, given the known item distribution: a residual that
matches a typical item size can still be filled, whereas a middling residual
is comparatively wasteful.  We combine this with the classic best-fit term so
that tight packing is still strongly preferred.
"""
import numpy as np

# Target residual sizes derived from the item distribution (mean ~40).
# We slightly favor leaving residuals close to typical item sizes so future
# items can consume them.
_TARGETS = np.array([40.0, 20.0, 60.0, 80.0, 100.0])


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # >= 0 because these bins fit the item

    # Best-fit term: prefer the smallest residual (most tightly packed).
    tight = -residual

    # Distribution-aware term: the closer a residual is to a typical future
    # item size, the more likely it can be filled later, so it is preferred.
    dist = np.abs(residual[:, None] - _TARGETS[None, :]).min(axis=1)

    return tight - 0.5 * dist
# EVOLVE-BLOCK-END
