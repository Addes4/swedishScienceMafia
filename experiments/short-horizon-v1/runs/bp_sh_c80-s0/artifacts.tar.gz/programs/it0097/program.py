# EVOLVE-BLOCK-START
"""Best fit biased toward residuals that a future item can exactly fill."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 3000:
        del sizes[:1500]

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Base: best-fit tightness (smallest residual first).
    score = -(resid.astype(np.float64))

    if len(sizes) < 30:
        empty = bins == 100
        score -= np.where(empty, 0.5, 0.0)
        return score

    arr = np.array(sizes, dtype=np.float64)
    mu = arr.mean()
    sd = arr.std()
    if sd < 1.0:
        sd = 1.0

    # Smoothed empirical density: probability a future item lands near size r.
    # Gaussian kernel with bandwidth = sd gives P(~r) without binning noise.
    rs = resid
    z = (rs - mu) / sd
    dens = np.exp(-0.5 * z * z)  # unnormalized kernel density proxy

    # Reward residuals that a typical future item can exactly fill.
    # Normalize magnitude to ~1.
    score += 8.0 * dens

    # Reward residuals that can hold at least one typical item (reusable leftover).
    useful = (resid >= max(1.0, mu - 0.5 * sd)) & (resid <= 100)
    score += np.where(useful, 1.5, 0.0)

    # Penalize slivers too small to hold a likely future item.
    sliver = (resid > 0) & (resid < max(1.0, mu - sd))
    score -= np.where(sliver, 3.0, 0.0)

    # Mild preference against opening a fresh bin.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
