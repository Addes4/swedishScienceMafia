# EVOLVE-BLOCK-START
"""Best fit that avoids leaving unusable slivers and rewards reusable residuals."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 4000:
        del sizes[:2000]

    # Estimate distribution characteristics from observed history.
    if len(sizes) >= 30:
        arr = np.array(sizes, dtype=np.float64)
        mu = float(arr.mean())
        sd = float(arr.std())
        # smallest meaningful item: use a low percentile-ish estimate
        small = float(np.percentile(arr, 10))
    else:
        mu = 40.0
        sd = 20.0
        small = 15.0

    if small < 1.0:
        small = 1.0

    resid = (bins - item).astype(np.float64)  # >= 0 for shown bins

    # Primary: tightest fit (smallest residual).
    score = -resid

    # Penalty for leaving a sliver too small to hold a typical small item.
    sliver = (resid > 0) & (resid < small)
    score -= np.where(sliver, 2.0, 0.0)

    # Bonus for leaving a residual that itself matches a typical item size,
    # which is likely to be exactly refillable later.
    near = np.abs(resid - mu) <= 0.25 * mu + 2.0
    score += np.where(near, 1.5, 0.0)

    # Bonus for near-exact fill of a partial bin (leaving zero-ish residual).
    exact = (resid == 0)
    score += np.where(exact, 3.0, 0.0)

    # Mild preference against opening fresh bins.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END

