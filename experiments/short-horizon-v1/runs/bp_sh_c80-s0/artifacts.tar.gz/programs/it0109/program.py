# EVOLVE-BLOCK-START
"""Best fit with a histogram-based exact-completion bonus.

Base rule: smallest residual wins (best fit).  On top of that we reward
leaving a residual equal to a common observed item size, because a future
item of that size will complete the bin exactly.  The empirical histogram
is smoothed and concentrated on residuals that matter.
"""
import numpy as np

_state = {"sizes": []}

# Residual values we care about (1..100).  Index 0 unused.
_HIST_LEN = 101


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    resid = (bins - item).astype(np.int64)

    # Base: strict best fit (smallest residual, i.e. tightest fit).
    score = -(resid.astype(np.float64))

    # Histogram-based completion bonus.
    if len(sizes) >= 30:
        arr = np.array(sizes, dtype=np.float64)
        counts = np.bincount(arr.astype(np.int64), minlength=_HIST_LEN)[:_HIST_LEN]
        # Smooth a little so we generalize to unseen sizes.
        k = np.array([1.0, 2.0, 3.0, 2.0, 1.0])
        k = k / k.sum()
        sm = np.convolve(counts, k, mode="same")
        weight = sm / (sm.sum() + 1e-9)  # prob mass per size
        # Bonus for leaving residual equal to a likely future item size.
        # Scale so it dominates small residual differences but not structure.
        w = np.where(resid > 0, weight[np.clip(resid, 0, 100)], 0.0)
        score += 40.0 * w
        # Extra: residual that is itself very common gets a bit more.
        top = weight[np.clip(resid, 0, 100)]
        score += 20.0 * np.where(resid > 0, top, 0.0)

    # Light preference against opening a fresh empty bin.
    empty = bins == 100
    score -= np.where(empty, 0.05, 0.0)

    return score
# EVOLVE-BLOCK-END
