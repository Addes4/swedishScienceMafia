# EVOLVE-BLOCK-START
"""Best fit, with a mild learned penalty for leaving unusably tiny residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item
    # Mild penalty when the residual is a tiny sliver that likely no item will use.
    # Threshold is small and fixed so normal best-fit decisions are unchanged.
    sliver = (resid >= 0) & (resid <= 1)
    return -(resid) - 0.05 * sliver
# EVOLVE-BLOCK-END
