# EVOLVE-BLOCK-START
"""Best fit with a mild penalty for stranding sub-minimum slivers."""
import numpy as np

_state = {"min_item": 101}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item < _state["min_item"]:
        _state["min_item"] = item
    m = _state["min_item"]

    residual = bins - item

    # Primary: tightest fit (lower residual -> higher score).
    score = -residual.astype(np.float64)

    # Penalize placements that leave a residual too small to hold the smallest
    # item seen so far, i.e. a potentially unusable sliver.
    sliver = (residual < m) & (residual > 0)
    score -= sliver * 0.5

    # Strongly prefer filling an exactly-full bin.
    score += (residual == 0) * 1e-9

    return score
# EVOLVE-BLOCK-END
