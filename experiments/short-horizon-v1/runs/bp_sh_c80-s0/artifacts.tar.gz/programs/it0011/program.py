# EVOLVE-BLOCK-START
"""Size-aware best-fit hybrid.

For larger items (where wasting capacity is costly), use exact best-fit: put the item
in the bin it fits most tightly. For smaller items (where best-fit tends to leave many
tiny, unusable residuals), instead prefer the fullest bin whose residual after placing
the item is comfortably large (still at least the item size), so future small items can
reuse that gap.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    if item >= 50:
        # Large items: exact best-fit (tightest residual).
        return -residual.astype(np.float64)

    # Small/medium items: prefer fuller bins (small current residual) but avoid
    # leaving a tiny unusable gap. Reward residuals that are still >= item,
    # penalize residuals that are small but nonzero.
    score = -bins.astype(np.float64)

    # Penalty for leaving a residual in (0, item): it can't hold another item of this size.
    tiny = (residual > 0) & (residual < item)
    score -= tiny.astype(np.float64) * 1e6

    return score
# EVOLVE-BLOCK-END
