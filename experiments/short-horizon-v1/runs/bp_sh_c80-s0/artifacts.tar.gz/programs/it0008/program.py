# EVOLVE-BLOCK-START
"""Best fit with a sealing bonus and worst-fit avoidance for large items."""
import numpy as np


def priority(item, bins):
    """Rank bins: tightest fit for large items; reward sealing small residuals otherwise.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (tightest fit first => smallest residual highest score)
    score = -residual.astype(np.float64)

    # Sealing bonus: if placing this item leaves a tiny residual, that bin is
    # effectively full; strongly prefer it so we don't strand small scraps.
    # Applies mainly for smaller items where sealing is often possible.
    if item <= 50:
        # residuals in [0, ~item/4] get a bonus that grows as residual shrinks
        seal = np.maximum(0.0, (item * 0.25) - residual)
        score += 2.0 * seal

    return score
# EVOLVE-BLOCK-END
