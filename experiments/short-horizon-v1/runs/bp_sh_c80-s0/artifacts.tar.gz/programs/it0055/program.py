# EVOLVE-BLOCK-START
"""Best fit with a residual-quality bonus.

Pure best-fit minimizes the residual. But a bin left with a tiny sliver residual
(1..few) is effectively wasted, while a residual close to a typical item size is
reusable. We keep best-fit as the backbone but add a small bonus for residuals
that are "good": near zero (fully packed) or close to an online estimate of the
typical arriving item size.
"""
import numpy as np


class _State:
    def __init__(self):
        self.mean = 40.0
        self.n = 0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    # Online estimate of the item-size distribution mean (starts at 40).
    _state.n += 1
    a = min(0.02, 1.0 / _state.n) if _state.n > 1 else 1.0
    _state.mean = (1.0 - a) * _state.mean + a * item
    m = _state.mean
    if m < 1.0:
        m = 1.0

    residual = bins - item  # resulting remaining capacity, >= 0

    # Backbone: strongly prefer small residuals (best fit). Scale down so the
    # bonus below can break near-ties without overriding big differences.
    base = -residual.astype(np.float64)

    # Reusability bonus: reward residuals that are ~0 (full) or ~= typical size.
    r = residual.astype(np.float64)
    # Distance to nearest of {0, m}: small is good.
    d0 = r
    d1 = np.abs(r - m)
    near = np.minimum(d0, d1)
    bonus = np.exp(-(near / m) ** 2)

    # Keep bonus bounded and small relative to the integer backbone.
    return base + 0.5 * bonus
# EVOLVE-BLOCK-END
