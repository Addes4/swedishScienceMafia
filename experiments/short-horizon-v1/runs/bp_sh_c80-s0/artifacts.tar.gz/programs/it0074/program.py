# EVOLVE-BLOCK-START
"""Best-fit with a minimum-useful-residual guard.

For an arriving item, prefer bins whose resulting leftover can still hold at least one
more item of the same size (residual_after >= item); among those choose the tightest
(smallest residual_after). If no bin leaves such a residual, fall back to pure best-fit.
"""
import numpy as np


def priority(item, bins):
    residual_after = bins - item
    # Prefer residuals that can still fit another item of this size, tightest first.
    guarded = np.where(residual_after >= item, -residual_after, -1_000_000)
    # If any guarded bin exists, use those; otherwise fall back to plain best-fit.
    if np.any(residual_after >= item):
        return guarded
    return -residual_after
# EVOLVE-BLOCK-END
