# EVOLVE-BLOCK-START
"""Targeted residual: prefer leftovers close to a size-dependent target."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Target leftover after placing the item.  For small items a small nonzero
    # leftover is fine (many will pack together); for larger items aim tighter.
    target = min(12.0, 0.25 * item)
    residual = bins - item
    return -np.abs(residual - target)
# EVOLVE-BLOCK-END

