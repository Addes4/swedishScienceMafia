# EVOLVE-BLOCK-START
"""Best fit with an empirical residual-usability bonus."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 3000:
        del sizes[:1500]

    resid = bins - item  # remaining capacity after placing (>= 0)

    # Base: best fit (smallest residual).
    score = -(resid.astype(np.float64))

    if len(sizes) >= 30:
        arr = np.array(sizes, dtype=np.float64)
        mu = arr.mean()
        sd = arr.std()
    else:
        mu = 40.0
        sd = 20.0

    if sd < 1.0:
        sd = 1.0

    # Probability that a future item is <= residual (rough normal approx via CDF).
    # Use scipy-free logistic approximation to normal CDF.
    z = (resid - mu) / (sd * 1.7)
    cdf = 1.0 / (1.0 + np.exp(-z))  # ~P(next item <= resid), larger residual -> higher

    # Bonus for residuals that are likely reusable (can hold another typical item),
    # but not so large that we waste space; peak around the mean.
    usable = (resid > 0)
    bonus = np.where(usable, cdf * 4.0, 0.0)

    # Penalty for leaving a residual in the "dead zone": positive but below the
    # smallest typical item (~ mu - 1.2 sd), unlikely to be reused.
    dead = usable & (resid < max(1.0, mu - 1.2 * sd))
    bonus -= np.where(dead, 2.0, 0.0)

    score += bonus

    # Slight preference not to open a fresh bin when partial bins exist.
    empty = bins == 100
    score -= np.where(empty, 0.3, 0.0)

    return score
# EVOLVE-BLOCK-END
