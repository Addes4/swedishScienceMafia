# EVOLVE-BLOCK-START
"""Best-fit with a penalty for creating unusably small residuals.

Online bin packing where items arrive one at a time. Pure best-fit is very strong
for this Weibull-shaped distribution (mean ~40), so we keep it as the primary rule
but discourage placements that would leave a tiny, likely-unusable sliver of
capacity. The threshold adapts to the observed item stream.
"""
import numpy as np


class _State:
    def __init__(self):
        # Running 20th-percentile-ish estimate of item sizes (small items).
        self.q = 15.0     # initial guess for a "small-ish" item size
        self.n = 0

    def update(self, item):
        self.n += 1
        # Exponentially weighted update toward the observed percentile behavior.
        # If the item is small, push the threshold down; if large, up slowly.
        if item < self.q:
            self.q += 0.02 * (item - self.q)
        else:
            self.q += 0.002 * (item - self.q)
        # Keep it in a sane range.
        if self.q < 3.0:
            self.q = 3.0
        if self.q > 40.0:
            self.q = 40.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of fitting bins, in bin order.
    """
    _state.update(item)
    bins = np.asarray(bins)

    residual = bins - item  # post-placement remaining capacity (>= 0)

    # Best-fit base score: tighter (smaller residual) is better.
    score = -residual.astype(np.float64)

    # Penalize residuals that are too small to hold even a small item.
    thr = _state.q
    tiny = residual < thr
    score = score - np.where(tiny, 30.0, 0.0)

    return score
# EVOLVE-BLOCK-END
