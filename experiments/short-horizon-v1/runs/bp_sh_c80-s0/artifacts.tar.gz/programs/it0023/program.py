# EVOLVE-BLOCK-START
"""Best fit with a small distribution-aware tie-break on the post-placement residual."""
import numpy as np

_MEAN = 40.0
_K = 2.0            # Weibull shape parameter for a mean-40 Weibull
_LAMBDA = _MEAN / 0.886226925452758   # Gamma(1 + 1/K)

# Build an approximate PMF over item sizes 1..100 from a Weibull(K, lambda).
_x = np.arange(1, 101, dtype=float)
_cdf = 1.0 - np.exp(-(_x / _LAMBDA) ** _K)
_pmf = np.empty(101, dtype=float)
_pmf[0] = 0.0
_pmf[1:] = np.diff(_cdf)
_pmf = np.clip(_pmf, 1e-9, None)
_pmf /= _pmf.sum()

# "Fillability" of a post-placement residual: how likely a future item exactly fits.
# We use P(item <= residual) as a mild, monotone value, plus a bonus for residuals
# that are themselves the most probable item size (so they can be exactly filled).
_cum = np.cumsum(_pmf)


def priority(item, bins):
    """Best fit (minimize residual), tie-broken by distribution-aware fillability."""
    residual = bins - item              # >= 0 for all shown bins
    # primary: tightest fit -> smallest residual
    # secondary (small weight): prefer residuals that are most "useful" for the future
    r = np.clip(residual, 0, 100)
    # usefulness = cumulative probability a future item fits (favors larger residuals a bit),
    # moderated by how probable an exact fill is (a bump near typical item sizes).
    useful = _cum[r] - 0.5 * _pmf[r]
    # combine: tightest fit dominates, usefulness only breaks near-ties
    return -residual + 1e-3 * useful
# EVOLVE-BLOCK-END

