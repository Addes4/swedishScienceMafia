# EVOLVE-BLOCK-START
"""Best-Fit: choose the bin that leaves the smallest residual after placement."""
import numpy as np


def priority(item, bins):
    # Remaining capacity after placing the item (bins shown already fit the item).
    resid = bins - item

    # Prefer the tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Mild, constant penalty for empty bins to break exact ties toward open bins.
    empty = bins == 100
    score -= np.where(empty, 1e-3, 0.0)

    return score
# EVOLVE-BLOCK-END
