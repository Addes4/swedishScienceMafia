# EVOLVE-BLOCK-START
"""Harmonic-style bin choice: classify items and prefer class-consistent bins."""
import numpy as np

# Harmonic thresholds (classic Online Harmonic): 1/2, 1/3, 1/4, 1/5, ... of capacity 100.
_THRESH = [50, 34, 25, 20, 17, 14, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]


def _bucket(item):
    """Return the harmonic bucket index for an item size."""
    for i, t in enumerate(_THRESH):
        if item >= t:
            return i
    return len(_THRESH)


def priority(item, bins):
    """Rank bins: prefer tight fit, but favor class-consistent residuals.

    item: integer size of arriving item, 1..100.
    bins: remaining capacities of bins the item fits in, in bin order.
    """
    b = _bucket(item)
    # residual after placement
    residual = bins - item

    # Class-consistent target residual: the item itself is the best match,
    # so a residual that is small (tight fit) is ideal. We blend:
    # primary: smallest residual (best fit), but break near-ties toward
    # residuals that are themselves likely to form a full harmonic class.
    score = -residual.astype(np.float64)

    # Bonus for residuals that are "round" harmonic values (reusable slot).
    # Residual r is a good target if r == 100 - k*item for some small k,
    # i.e. the bin would be filled by exact copies of this item class.
    # We approximate with: residual close to 0 or close to a harmonic step.
    bonus = np.zeros_like(score)
    for t in _THRESH[1:]:
        # residual being near t means a future item of size ~ (100-t)+... reuse
        bonus = np.maximum(bonus, -np.abs(residual - t).astype(np.float64) * 0.01)
    score += bonus

    return score
# EVOLVE-BLOCK-END
