# EVOLVE-BLOCK-START
"""Best fit, plus a strong bonus for residuals matching a common future item size."""
import numpy as np

_state = {"sizes": [], "hist": None, "dirty": 0}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))

    # Build a smoothed empirical histogram of item sizes (for likely future items).
    dirty = _state["dirty"] + 1
    _state["dirty"] = dirty
    if _state["hist"] is None or dirty >= 50:
        _state["dirty"] = 0
        if len(sizes) >= 20:
            arr = np.array(sizes, dtype=np.int64)
            counts = np.bincount(arr, minlength=101)
            # smooth a bit
            kernel = np.array([0.25, 0.5, 0.25])
            sm = np.convolve(counts.astype(np.float64), kernel, mode="same")
            _state["hist"] = sm
        else:
            _state["hist"] = None

    resid = (bins - item).astype(np.float64)

    # Base: tightest fit (smallest non-negative residual).
    score = -resid

    hist = _state["hist"]
    if hist is not None:
        # Likely future item sizes (where histogram mass is high).
        # A residual r can be completed by a future item of size r.
        n = hist.sum()
        if n > 0:
            prob = hist / n
            # For each bin, look up the probability that a future item equals the residual.
            r_idx = np.clip(resid.astype(np.int64), 0, 100)
            match = prob[r_idx]
            # Strong bonus: residual matches a common future item size.
            score += 40.0 * match
            # Small bonus if residual is at least a plausible item size.
            score += 2.0 * (prob[r_idx] > 0.0)

    # Light preference against opening a fresh bin.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
