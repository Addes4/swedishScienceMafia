# EVOLVE-BLOCK-START
"""Best fit with a lookahead-free residual-reuse tie-break.

Core rule is still best fit (tightest residual).  On top of that, we keep a
short history of the item sizes that have been seen in this stream and, when
choosing among bins, prefer the bin whose residual after placing the item can
still be used by the most of those typical sizes.  This discourages leaving
residuals that only a large item could fill, without looking at the future.
"""
import numpy as np

_HISTORY = []
_MAX_HISTORY = 64


def priority(item, bins):
    # Update the recent-size history (small items dominate the packing remnants).
    _HISTORY.append(int(item))
    if len(_HISTORY) > _MAX_HISTORY:
        del _HISTORY[0]

    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item

    # Base: best fit -> smallest residual gets the highest score.
    score = -residual.astype(np.float64)

    # Tie-break: among (near-)equal best-fit residuals, prefer the one that the
    # typical recent item sizes can still fill, i.e. avoid orphaning gaps.
    if len(_HISTORY) > 0:
        hist = np.asarray(_HISTORY, dtype=np.int64)
        # For each bin, count how many recent item sizes would fit in the
        # residual left behind.  Use a fine tie-break so the best fit order is
        # preserved but slightly broken toward reusable residuals.
        fits = (residual[:, None] >= hist[None, :]).sum(axis=1)
        score = score + 1e-3 * fits.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
