# EVOLVE-BLOCK-START
"""Best fit, plus a targeted bonus for residuals completable by one common item."""
import numpy as np

_state = {"sizes": [], "hist": np.zeros(101, dtype=np.float64), "count": 0}


def priority(item, bins):
    st = _state
    it = int(item)
    st["sizes"].append(it)
    if st["count"] < 100000:
        st["hist"][it] += 1.0
        st["count"] += 1
    if len(st["sizes"]) > 4000:
        del st["sizes"][:2000]

    # Smoothed empirical probability that a future item completes residual r:
    # we need an item of size 100 - residual.
    if st["count"] >= 50:
        h = st["hist"]
        # light smoothing so unseen sizes still carry some weight
        smooth = h + 0.5
        total = smooth.sum()
        p = smooth / total
    else:
        p = None

    resid = bins - it  # remaining capacity after placing (>=0 for shown bins)
    score = -resid.astype(np.float64)  # tightest fit base

    if p is not None:
        need = 100 - resid  # size of a single future item that would complete the bin
        valid = (need >= 1) & (need <= 100)
        completion_prob = np.where(valid, p[np.clip(need, 0, 100)], 0.0)
        # Reward residuals that a single common item can complete exactly.
        score += 30.0 * completion_prob

    # Light preference not to open a fresh unused bin.
    score -= np.where(bins == 100, 0.2, 0.0)

    return score
# EVOLVE-BLOCK-END
