# EVOLVE-BLOCK-START
"""Best-fit with a reusable-gap preference, tuned for Weibull-shaped items."""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    _state["sum"] += float(item)
    _state["count"] += 1

    # Estimate the mean item size from observed history (cheap running mean).
    if _state["count"] >= 1:
        mu = _state["sum"] / _state["count"]
    else:
        mu = 40.0
    if mu < 1.0:
        mu = 1.0
    if mu > 100.0:
        mu = 100.0

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)
    score = -resid.astype(np.float64)  # tightest fit dominates

    # Reward residuals that can still hold a typical item: reusable gap.
    reusable = (resid >= mu - 1.0) & (resid <= 100)
    score += np.where(reusable, 2.0, 0.0)

    # Penalize leaving slivers too small to be useful.
    sliver = (resid > 0) & (resid < mu - 1.0)
    score -= np.where(sliver, 0.5, 0.0)

    # Mildly discourage opening a fresh bin over reusing an open one.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
