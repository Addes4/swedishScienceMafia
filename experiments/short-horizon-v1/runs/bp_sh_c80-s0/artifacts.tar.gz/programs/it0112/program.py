# EVOLVE-BLOCK-START
"""Best fit with a smooth, distribution-scaled reusable-residual bonus."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    # Estimate the typical item size distribution from observed history.
    if len(sizes) >= 20:
        arr = np.array(sizes, dtype=np.float64)
        mu = arr.mean()
        sd = arr.std()
        if sd < 1.0:
            sd = 1.0
    else:
        mu = 40.0
        sd = 20.0

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)
    r = resid.astype(np.float64)

    # Base: prefer tightest fit (smallest residual).
    score = -r

    # Smooth bonus for residuals near the typical item size: such a leftover
    # can likely be filled by a future item, so it is "useful" rather than waste.
    # Gaussian centered at mu, scaled by sd, only for positive residuals.
    gauss = np.exp(-0.5 * ((r - mu) / sd) ** 2)
    useful = r > 0
    score += np.where(useful, 3.0 * gauss, 0.0)

    # Strong preference not to open a fresh bin when a valid partial fill exists.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END

