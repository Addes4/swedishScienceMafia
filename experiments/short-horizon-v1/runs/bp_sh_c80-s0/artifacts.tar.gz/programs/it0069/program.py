# EVOLVE-BLOCK-START
"""Harmonic-style best fit: bucket items by size and target a matching residual range."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Harmonic-style size buckets: each bucket has an ideal residual range so that
    # bins are packed to a consistent fill level and small slivers are avoided.
    if item > 50:
        # Large items: use nearly-full bins (tight fit), avoid wasting fresh bins.
        ideal_lo, ideal_hi = 0, 12
    elif item > 33:
        ideal_lo, ideal_hi = 0, 20
    elif item > 20:
        ideal_lo, ideal_hi = 0, 30
    elif item > 10:
        ideal_lo, ideal_hi = 0, 45
    else:
        ideal_lo, ideal_hi = 0, 60

    # Score: prefer residuals inside [ideal_lo, ideal_hi], then the smallest residual.
    in_range = (residual >= ideal_lo) & (residual <= ideal_hi)
    # Primary: reward being in range (1), then tighter fit (smaller residual).
    return in_range.astype(np.float64) * 1000.0 - residual
# EVOLVE-BLOCK-END

