# EVOLVE-BLOCK-START
"""Best-fit with a guard against creating tiny unusable residuals.

Core idea: plain best-fit is strong, but it frequently leaves residuals that are
smaller than typical future items, wasting capacity. So among all bins that fit,
we prefer those whose post-placement residual is either exactly 0 or at least a
threshold (`MIN_USEFUL`). When several qualify we pick the tightest fit (largest
remaining capacity that still leaves a usable residual is worse, so we want the
smallest remaining capacity >= item + MIN_USEFUL, i.e. best-fit subject to the
guard). If no bin leaves a usable residual, fall back to plain best-fit.

`MIN_USEFUL` is set to the rounded mean of the item distribution (~40), so that
the residual can still accommodate a typical item later.
"""
import numpy as np

# Typical item size from the (Weibull-shaped, mean ~40) distribution.
MIN_USEFUL = 40


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins

    # "Good" placements: perfect fit, or leave a residual that can still hold a typical item.
    good = (residual == 0) | (residual >= MIN_USEFUL)

    # Base score: best-fit = prefer smallest residual (most filled bin).
    score = -residual.astype(np.float64)

    # Add a large bonus so that, whenever any good bin exists, good bins dominate.
    score += good.astype(np.float64) * 1e6

    return score
# EVOLVE-BLOCK-END
