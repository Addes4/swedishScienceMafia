# EVOLVE-BLOCK-START
"""Score bins by the expected future packing value of the residual they leave behind.

For each candidate bin we know the residual `r` that would remain after placing the
current item.  We estimate, from the observed item-size distribution, how many
future items on average can be packed into a bin of capacity `r` (a simple
expected-fill / value estimate).  We prefer the placement that leaves the highest
expected future value while keeping the immediate waste small.
"""
import numpy as np

_state = {"sizes": []}


def _expected_value(caps, probs, sizes):
    """Approximate expected number of items packable in a bin of each capacity.

    Uses a small forward recursion: for each capacity c (0..100) the value is the
    best expected additional items obtainable, estimated by trying every possible
    next item size weighted by its probability.
    """
    # value[c] = expected number of items that can still be packed into a bin
    # with remaining capacity c, given item-size distribution.
    value = np.zeros(101, dtype=np.float64)
    if len(sizes) == 0:
        return value
    ss = np.array(sizes, dtype=np.float64)
    pp = np.array(probs, dtype=np.float64)
    # sort by size
    order = np.argsort(ss)
    ss = ss[order]
    pp = pp[order]
    # iterative value iteration (few sweeps is enough for a coarse estimate)
    for _ in range(3):
        new = np.zeros(101, dtype=np.float64)
        for c in range(1, 101):
            # options: stop (0), or place one item of size s <= c
            best = 0.0
            # consider only item sizes that fit
            mask = ss <= c
            if np.any(mask):
                # expected value if we place the smallest-fitting item greedily
                # and then have c-s capacity
                sub_s = ss[mask]
                sub_p = pp[mask]
                # placing one item gains 1 plus value of residual
                gains = 1.0 + value[(c - sub_s).astype(np.int64)]
                expected = float(np.dot(sub_p, gains))
                norm = float(sub_p.sum())
                if norm > 0:
                    expected /= norm
                # we may also choose to stop and not place; take max with a
                # conservative fraction of the expected value
                best = max(0.0, expected)
            new[c] = best
        value = new
    return value


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 3000:
        del sizes[:1500]

    resid = bins - item  # residual after placing (>=0 for shown bins)

    # Empirical item-size distribution (smoothed).
    if len(sizes) >= 30:
        hist = np.zeros(101, dtype=np.float64)
        for s in sizes:
            if 1 <= s <= 100:
                hist[s] += 1.0
        # mild smoothing
        hist += 0.5
        probs = hist / hist.sum()
        size_list = [s for s in range(1, 101) if hist[s] > 0]
        prob_list = [probs[s] for s in size_list]
    else:
        size_list = list(range(1, 101))
        prob_list = [1.0 / 100.0] * 100

    value = _expected_value(resid, prob_list, size_list)

    # value[c] for c = residual
    cap = np.clip(resid.astype(np.int64), 0, 100)
    future_val = value[cap]

    # Primary: maximize expected future value of the leftover.
    score = future_val.astype(np.float64).copy()

    # Secondary: prefer tightest fit (smallest residual) to avoid fragmentation.
    score -= 0.01 * resid.astype(np.float64)

    # Strongly discourage opening a fresh empty bin.
    empty = bins == 100
    score -= np.where(empty, 0.05, 0.0)

    return score
# EVOLVE-BLOCK-END
