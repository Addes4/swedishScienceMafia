# EVOLVE-BLOCK-START
"""Best fit with a sum-of-squares style residual score and no-empty penalty."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    # Estimate the typical item size from observed history.
    if len(sizes) >= 20:
        arr = np.array(sizes, dtype=np.float64)
        mu = arr.mean()
    else:
        mu = 40.0
    if mu < 1.0:
        mu = 1.0
    if mu > 100.0:
        mu = 100.0

    resid = (bins - item).astype(np.float64)  # >= 0 for shown bins

    # Dominant: tightest fit (best fit base).
    score = -resid

    # Secondary: reward residuals that can hold a typical item but are not a
    # wasteful near-full leftover. Prefer resid near mu (reusable) and penalize
    # slivers smaller than mu, which tend to become unusable.
    score += np.where(resid >= mu, 0.35, 0.0)
    score -= np.where((resid > 0) & (resid < mu), 0.35, 0.0)

    # Exact completion bonus: placing item consumes bin perfectly.
    score += np.where(bins == item, 1.0, 0.0)

    # Strong preference not to open a fresh bin when a partial fill exists.
    score -= np.where(bins == 100, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
