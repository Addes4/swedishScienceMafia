# EVOLVE-BLOCK-START
"""Best fit with a small-residual guard.

Place the item in the bin it fits most tightly (smallest resulting residual).
To avoid leaving useless slivers, add a tiny tie-influencing bonus for
residuals that are not too small, while keeping best-fit dominance.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, first on ties.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Primary term: tightest fit (most negative residual = best).
    score = -residual.astype(np.float64)
    # Tiny bonus so that a residual that is too small to be reusable (a sliver
    # below the smallest possible item, i.e. 0) is very slightly penalized.
    # This only affects ties/近-ties and preserves best-fit otherwise.
    score -= 0.001 * (residual == 0)
    return score
# EVOLVE-BLOCK-END

