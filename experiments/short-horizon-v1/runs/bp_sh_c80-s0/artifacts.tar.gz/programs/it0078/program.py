# EVOLVE-BLOCK-START
"""Best fit, with a secondary preference that reduces sliver creation.

Primary key: smallest residual after placement (classic best fit).
Tie key (exact ties only): prefer the bin that had the LARGER remaining
capacity before placement, so we fill down from fuller-capacity bins in a
consistent way and keep the tightest residual deterministic.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, first on ties."""
    residual_after = bins - item  # what remains if the item goes here
    # Highest score -> smallest residual_after. On equal residual_after,
    # prefer larger pre-placement capacity via a tiny secondary term.
    return -residual_after.astype(np.float64) + 1e-9 * bins
# EVOLVE-BLOCK-END
