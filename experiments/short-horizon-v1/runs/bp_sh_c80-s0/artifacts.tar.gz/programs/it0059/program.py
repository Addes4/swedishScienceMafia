# EVOLVE-BLOCK-START
"""Best fit with learned reusable-residual tie-break.

The core decision is best fit (minimize resulting residual). Ties (and near-ties
within a tiny window) are broken by preferring a residual that matches a typical
item size seen so far, estimated via an online histogram of item sizes. This
keeps tight packing but nudges slivers toward reusable pockets.
"""
import numpy as np

# Online histogram of item sizes (1..100) over the current stream.
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def _reset():
    global _hist, _count
    _hist = np.zeros(101, dtype=np.float64)
    _count = 0.0


def priority(item, bins):
    global _hist, _count

    # Detect a fresh stream (bins array patterns repeat across streams but
    # state must reset). We reset heuristically when the item distribution
    # counter grows large, but harness resets module state per stream anyway.
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # resulting remaining capacity

    # Reusable-size value: weight a residual r by how often sizes <= r exist,
    # i.e. the probability mass of item sizes at or below r.
    if _count > 0.0:
        cum = np.cumsum(_hist) / _count
    else:
        cum = np.ones(101, dtype=np.float64)

    # Score: primary = best fit (smaller residual better, so negative).
    # Secondary = prefer residual whose value has a decent chance of being
    # filled by a future item: value cdf around that residual.
    clip = np.clip(residual, 0, 100).astype(np.int64)
    reuse = cum[clip]

    # Strongly weight best-fit dominance; tie region is tiny (sub-unit).
    return -(residual) + 0.001 * reuse
# EVOLVE-BLOCK-END
