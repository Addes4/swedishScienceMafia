# EVOLVE-BLOCK-START
"""Best fit, with a pairing-aware preference for complementing existing bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    used = 100 - bins  # amount already in each bin
    residual = bins - item  # leftover after placing
    # Base: best fit (smaller residual is better).
    score = -residual.astype(np.float64)
    # Among bins that already have content, mildly prefer a post-placement residual
    # close to a typical item size (~40), which is more likely to be fillable later.
    nonempty = used > 0
    target = 40.0
    pair_bonus = 1.5 * (1.0 - np.abs(residual - target) / 100.0)
    score = np.where(nonempty, score + pair_bonus, score)
    return score
