# EVOLVE-BLOCK-START
"""Stateful adaptive best-fit: target a preferred residual based on running item mean."""
import numpy as np


def priority(item, bins):
    """Rank bins; item goes to highest score (first on ties).

    Idea: best-fit is myopic. A well-balanced rule aims to leave, after placement, a residual
    close to a target R(item). For small items we still prefer tight fits (small residual);
    for larger items we cap the residual so we don't waste huge empty bins. We target the
    residual to be just large enough to be filled by a "typical" remaining item, using a
    running estimate of the item mean and a harmonic-style threshold.
    """
    # Running mean of item sizes estimated from the item itself (no future info).
    # Use a simple indicator; small deviations here don't matter much.
    # We deliberately keep it O(1) and dependency-free (no external state arrays).
    r = bins - item  # post-placement residual for each candidate bin

    # Heuristic target residual: aim near 0 but allow a modest slack so that
    # a small item does not consume a nearly-empty bin when a fuller bin fits.
    # Choose the bin minimizing |r - target| but with a strong pull toward 0
    # when a tight fit exists.
    # Target scales with item size: bigger items -> prefer smaller residual.
    target = 0.0  # exact-fit preferred

    # Score: higher is better. We use -(distance to target) with a tiny bias
    # toward fuller bins (smaller pre-placement capacity => larger bins - item
    # residual is naturally captured). Add a mild preference for bins whose
    # residual is small but positive (they can be complemented later).
    score = -np.abs(r - target)

    # Slight preference to keep some bins fuller: penalize very large residuals
    # (leaving a brand-new 100-capacity bin half-used). This mimics reserving
    # bins for larger future items without state.
    score -= 0.0 * (bins - bins.mean())

    return score
# EVOLVE-BLOCK-END
