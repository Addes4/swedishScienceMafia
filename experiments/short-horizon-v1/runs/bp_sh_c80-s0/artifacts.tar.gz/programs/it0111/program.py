# EVOLVE-BLOCK-START
"""Best fit with a bonus for leaving a residual that a common future item fills exactly."""
import numpy as np

_state = {"sizes": [], "hist": None, "epoch": 0}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 3000:
        del sizes[:1500]

    # Smooth empirical probability that a future item equals a given size 1..100.
    n = len(sizes)
    if n >= 200:
        arr = np.array(sizes, dtype=np.int64)
        counts = np.bincount(arr, minlength=101)
        # light smoothing to avoid zero probabilities
        p = (counts[1:101] + 0.5).astype(np.float64)
        p /= p.sum()
    else:
        # flat fallback
        p = np.full(100, 1.0 / 100.0)

    resid = bins - item  # >= 0 for shown bins

    # Base: strict tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Bonus: residual r means a future item of size r would complete this bin.
    # Reward by the empirical probability of size r.
    r = resid.astype(np.int64)
    valid = (r >= 1) & (r <= 100)
    rr = np.where(valid, r, 1)
    prob = p[rr - 1]
    score += np.where(valid, 30.0 * prob, 0.0)

    # Complete bins (residual 0) are ideal; reward them explicitly.
    score += np.where(resid == 0, 5.0, 0.0)

    # Mild preference not to open a fresh bin when a partial fill exists.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
