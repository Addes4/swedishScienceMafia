# EVOLVE-BLOCK-START
"""Stateful best-fit that avoids tiny unusable slivers using an online threshold."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.m2 = 0.0
        self.counts = np.zeros(101, dtype=np.float64)


_S = _State()


def priority(item, bins):
    # Online statistics of arriving items.
    _S.n += 1
    d = item - _S.mean
    _S.mean += d / _S.n
    _S.m2 += d * (item - _S.mean)
    _S.counts[item] += 1.0

    n = _S.n
    if n < 20:
        return -(bins - item)

    # Estimate a small "sliver" threshold: roughly the ~10th percentile of item sizes,
    # approximated cheaply via mean and std of the observed distribution.
    var = _S.m2 / n
    std = np.sqrt(var) if var > 0 else 1.0
    # Weibull-ish: mean ~ 40, so a lower quantile is around mean - std.
    thresh = max(1.0, _S.mean - 0.8 * std)

    item_i = int(item)
    # Count how many entirely unused bins exist (remaining capacity 100).
    unused = int(np.count_nonzero(bins == 100))

    best_fit_residual = -(bins - item)  # = item - bins ; higher (less negative) is tighter fit
    # Actual resulting residual:
    residual = bins - item

    # Best-fit choice index (smallest residual >= 0).
    bf_idx = int(np.argmax(best_fit_residual))

    if unused > 0 and residual[bf_idx] < thresh:
        # Prefer starting a fresh bin rather than creating a tiny sliver,
        # but only when many bins remain so we don't waste capacity needlessly.
        full_bins = bins.size - unused
        if full_bins > 0 and unused >= 1:
            fresh = np.where(bins == 100)[0]
            scores = np.full(bins.shape, -1e9)
            scores[fresh[0]] = 0.0
            return scores

    return best_fit_residual
# EVOLVE-BLOCK-END

