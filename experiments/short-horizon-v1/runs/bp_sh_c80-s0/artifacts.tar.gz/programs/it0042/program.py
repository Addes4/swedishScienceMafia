# EVOLVE-BLOCK-START
"""Best fit with a tie-break toward the fuller bin (leaves room for large future items)."""
import numpy as np


def priority(item, bins):
    """Score each bin; highest wins, ties to the first bin.

    Primary: minimize post-placement residual (best fit).
    Secondary: on equal residual, prefer the larger remaining capacity (fuller bin),
    keeping the emptier bins free to absorb future large items.
    """
    residual = bins - item
    return -residual.astype(np.float64) - 1e-6 * bins
# EVOLVE-BLOCK-END
