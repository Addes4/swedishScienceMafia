# EVOLVE-BLOCK-START
"""Best fit with reusable-residual tie-break driven by observed size histogram."""
import numpy as np

_state = {"sizes": [], "hist": np.zeros(101, dtype=np.float64), "count": 0}


def priority(item, bins):
    st = _state
    st["sizes"].append(int(item))
    st["hist"][int(item)] += 1.0
    st["count"] += 1
    if len(st["sizes"]) > 4000:
        del st["sizes"][:2000]

    item = int(item)
    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Base: tightest fit (smallest residual). Dominant term.
    score = -(resid.astype(np.float64)) * 4.0

    # Secondary: reward residuals that are themselves plausible item sizes,
    # so the leftover can likely be filled exactly later.
    if st["count"] >= 20:
        prob = st["hist"] / st["count"]
        # probability mass within +-2 of the residual value
        r = np.clip(resid, 0, 100).astype(np.int64)
        reus = prob[r]
        # also include neighbours to be tolerant of jitter
        for d in (1, 2):
            lo = np.clip(r - d, 0, 100)
            hi = np.clip(r + d, 0, 100)
            reus += prob[lo] + prob[hi]
        score += reus * 8.0
    else:
        # fallback: prefer residuals near typical band ~40
        score -= np.abs(resid - 40).astype(np.float64) * 0.05

    # Prefer not to open a fresh bin while partial bins can hold the item.
    empty = bins == 100
    score -= np.where(empty, 3.0, 0.0)

    # Penalize tiny slivers that are hard to reuse.
    sliver = (resid > 0) & (resid < 5)
    score -= np.where(sliver, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END

