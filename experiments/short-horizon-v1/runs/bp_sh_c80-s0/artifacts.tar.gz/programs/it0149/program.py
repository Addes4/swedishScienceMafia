# EVOLVE-BLOCK-START
"""Best-Fit with a pairing bonus: prefer residuals that can host a similar item."""
import numpy as np


def priority(item, bins):
    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Base: prefer tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Bonus when the leftover exactly equals this item's size: such a bin can
    # later absorb a similar item and become perfectly full, improving packing.
    score += np.where(resid == item, 1.0, 0.0)

    # Tiny penalty for opening a fresh bin, only to break exact ties.
    empty = bins == 100
    score -= np.where(empty, 0.1, 0.0)

    return score
# EVOLVE-BLOCK-END
