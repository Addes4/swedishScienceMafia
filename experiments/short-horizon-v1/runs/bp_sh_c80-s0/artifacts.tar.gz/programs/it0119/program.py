# EVOLVE-BLOCK-START
"""Best fit with a reusable-residual bonus and exact-fit reward."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    # Estimate the typical item size from observed history.
    if len(sizes) >= 20:
        arr = np.array(sizes, dtype=np.float64)
        mu = float(arr.mean())
    else:
        mu = 40.0
    if mu < 1.0:
        mu = 1.0
    if mu > 100.0:
        mu = 100.0

    resid = bins - item  # remaining capacity after placing

    # Base: strict best-fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Reward exact fits strongly: the bin closes perfectly.
    exact = resid == 0
    score += np.where(exact, 50.0, 0.0)

    # Reward residuals that can hold at least one typical future item,
    # i.e. reusable space rather than a sliver.
    reusable = (resid >= mu)
    score += np.where(reusable, 2.0, 0.0)

    # Penalize useless slivers (non-zero, too small for a typical item).
    sliver = (resid > 0) & (resid < mu)
    score -= np.where(sliver, 2.0, 0.0)

    # Mild preference against opening a fresh bin.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
