# EVOLVE-BLOCK-START
"""Class-based (harmonic) bin choice with best-fit tie-breaking."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 4000:
        del sizes[:2000]

    resid = np.maximum(bins - item, 0)

    # Harmonic thresholds: class k covers items in (100/(k+1), 100/k].
    # A residual r is "useful" if it can still host a full class-k item,
    # i.e. r lies in [100/(k+1), 100/k] for some k, and is not a sliver.
    # Build an approximate set of useful residual landmarks from the
    # standard harmonic decomposition (k = 1..8 covers most of the range).
    landmarks = []
    for k in range(1, 12):
        lo = 100.0 / (k + 1)
        hi = 100.0 / k
        if hi <= 0:
            continue
        # represent the class by its midpoint size
        landmarks.append(0.5 * (lo + hi))
    lm = np.array(landmarks, dtype=np.float64)

    # Base: best fit (prefer tightest residual).
    score = -resid.astype(np.float64)

    # Bonus: residual is close to a class-landmark (reusable by a class).
    if lm.size:
        # distance from residual to nearest landmark
        d = np.abs(resid[:, None] - lm[None, :]).min(axis=1)
        score -= 0.02 * d

    # Slight preference to fill partial bins over opening empty ones.
    empty = bins == 100
    score -= np.where(empty, 0.05, 0.0)

    # Penalize leaving slivers too small for the smallest useful class.
    sliver = (resid > 0) & (resid < 100.0 / 12.0)
    score -= np.where(sliver, 0.1, 0.0)

    return score
# EVOLVE-BLOCK-END
