# EVOLVE-BLOCK-START
"""Best-Fit with a complement bonus: preferentially create residuals that are
likely to be exactly filled by another item (~mean 40, but broad), so partial
bins get paired up instead of accumulating slivers."""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    _state["n"] += 1

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Base: tightest fit (smallest residual) is the classic Best-Fit.
    score = -(resid.astype(np.float64))

    # Bonus for leaving a residual that a typical item (~40) can exactly close:
    # prefer residuals close to the mean item size so a later item 40-ish fills it.
    # Use a smooth, fixed kernel (low variance) rather than per-stream estimates.
    d = np.abs(resid - 40.0)
    score += 3.0 * np.exp(-(d * d) / (2.0 * 12.0 * 12.0))

    # Strong bonus for residuals that are common small item sizes (likely to pair).
    exact = (resid == 0) | (resid == 10) | (resid == 20) | (resid == 30) | \
            (resid == 40) | (resid == 50) | (resid == 60) | (resid == 70)
    score += np.where(exact, 1.5, 0.0)

    # Penalize leaving a residual smaller than the smallest useful item slivers.
    score -= np.where((resid > 0) & (resid < 20), 0.5, 0.0)

    # Tiny preference to avoid opening a fresh bin on near-ties.
    score -= np.where(bins == 100, 0.2, 0.0)

    return score
# EVOLVE-BLOCK-END
