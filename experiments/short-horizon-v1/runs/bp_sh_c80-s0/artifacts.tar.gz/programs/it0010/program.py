# EVOLVE-BLOCK-START
"""Size-aware hybrid packing rule.

Large items (>= 50): pure best-fit (tightest residual) is near optimal.
Smaller items: best-fit leaves many tiny unusable residuals. Prefer bins
whose residual after placement is either near zero (perfect fill) or large
enough to still be useful, penalizing the narrow band of small wasted gaps.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    resid = bins - item  # remaining capacity after placing the item, >= 0

    if item >= 50:
        # Best fit: smallest residual wins.
        return -resid.astype(np.float64)

    # For smaller items, reward tight fits (small residual) strongly, but
    # add a mild bonus for residuals that are still large enough to be useful
    # for future items, to avoid stranding tiny gaps.
    r = resid.astype(np.float64)
    # Reward near-zero residuals (efficient fill).
    tight_bonus = np.exp(-r / 6.0)
    # Mildly reward large residuals (still reusable) over small wasted gaps.
    reuse_bonus = 0.15 * np.minimum(r, 40.0) / 40.0
    return -r + 8.0 * tight_bonus + reuse_bonus
# EVOLVE-BLOCK-END
