# EVOLVE-BLOCK-START
"""Best fit biased so that the residual left behind is likely reusable."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 4000:
        del sizes[:2000]

    if len(sizes) >= 50:
        arr = np.array(sizes, dtype=np.float64)
        mu = arr.mean()
        sd = arr.std()
    else:
        mu = 40.0
        sd = 20.0

    tmp = int(mu)
    if tmp < 1:
        tmp = 1
    if tmp > 100:
        tmp = 100
    band = tmp
    tol = int(0.25 * band) + 1

    resid = bins - item

    # Primary: prefer tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    useful = (resid >= 0) & (resid <= 100)

    # Bonus if residual is a "useful" leftover close to a typical item size.
    near_band = useful & (np.abs(resid - band) <= tol)
    score += np.where(near_band, 6.0, 0.0)

    reusable = useful & (resid >= band - tol) & (resid <= 100)
    score += np.where(reusable, 1.0, 0.0)

    sliver = useful & (resid > 0) & (resid < max(1, band - tol))
    score -= np.where(sliver, 1.0, 0.0)

    # Bonus when the residual exactly matches a frequently observed item size,
    # so a future item can fill it perfectly (good tie-breaker among tight fits).
    if len(sizes) >= 200:
        freq = np.bincount(np.array(sizes, dtype=np.int64), minlength=101)
        total = freq.sum()
        # probability-ish weight of residual being an exact future item size
        pr = freq[np.clip(resid, 0, 100)].astype(np.float64) / total
        score += np.where(useful, 4.0 * pr * 100.0, 0.0)

    # Strong preference not to open a fresh bin when a valid partial fill exists.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END

