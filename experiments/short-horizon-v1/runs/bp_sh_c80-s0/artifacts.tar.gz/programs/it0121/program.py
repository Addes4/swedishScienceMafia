# EVOLVE-BLOCK-START
"""Best fit with a deterministic exact-fit tie-break toward reusable residuals."""
import numpy as np

_state = {"seen": np.zeros(101, dtype=np.int64)}


def priority(item, bins):
    seen = _state["seen"]
    seen[int(item)] += 1

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Base: prefer tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Strong deterministic bonus when the residual is a perfect fit for some
    # item size that we have actually observed (so a future item can close it).
    observed = seen[1:101] > 0  # index 0 unused, sizes 1..100
    exact = (resid >= 1) & (resid <= 100)
    # residual equals an observed size?
    idx = np.clip(resid, 0, 100)
    exact_ok = exact & observed[idx]
    score += np.where(exact_ok, 8.0, 0.0)

    # Prefer leaving a residual of 0 (perfect fill) most of all.
    score += np.where(resid == 0, 100.0, 0.0)

    # Decisive penalty for opening a fresh bin while partial bins are available.
    empty = bins == 100
    score -= np.where(empty, 50.0, 0.0)

    return score
# EVOLVE-BLOCK-END

