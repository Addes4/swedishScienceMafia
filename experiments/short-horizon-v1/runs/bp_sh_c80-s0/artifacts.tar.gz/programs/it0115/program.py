# EVOLVE-BLOCK-START
"""Best fit with a sharp reusable-leftover criterion driven by the observed distribution."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    # Estimate a typical item size from observed history.
    if len(sizes) >= 30:
        arr = np.array(sizes, dtype=np.float64)
        mu = arr.mean()
    else:
        mu = 40.0

    typ = int(mu)
    if typ < 1:
        typ = 1
    if typ > 100:
        typ = 100

    resid = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Base: tightest fit (smallest residual).
    score = -resid

    # Reward perfect fills decisively: an exact complement is ideal.
    perfect = resid == 0
    score += np.where(perfect, 3.0, 0.0)

    # Penalize unusable slivers: leftover is positive but too small for a typical item.
    sliver = (resid > 0) & (resid < typ)
    score -= np.where(sliver, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END

