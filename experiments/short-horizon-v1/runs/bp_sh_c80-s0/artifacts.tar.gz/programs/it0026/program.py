# EVOLVE-BLOCK-START
"""Best fit with a strict exact-fit preference and deterministic residual ordering.

Primary rule is classic best fit: place the item in the bin that leaves the smallest
positive residual (tightest fit). We add an epsilon-scaled secondary term so that the
ranking is a clean lexicographic order on (residual_after, residual_before), which
strictly prefers exact fits and otherwise reproduces best fit exactly (no ties left to
chance), avoiding any accidental interior ordering that could hurt.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)
    residual_after = bins - item
    # Smaller residual_after -> higher priority.
    # Tiny secondary term: among equal residuals, prefer the bin that was already fuller
    # (smaller residual_before) so tight bins are used first; strictly lexicographic.
    eps = 1.0 / (4.0 * 100.0 + 4.0)
    return -(residual_after.astype(np.float64) + eps * bins.astype(np.float64))
# EVOLVE-BLOCK-END
