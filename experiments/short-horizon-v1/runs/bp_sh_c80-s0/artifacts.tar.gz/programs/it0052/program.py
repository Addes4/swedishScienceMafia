# EVOLVE-BLOCK-START
"""Best fit, gently biased toward leaving reusable residual pockets.

Plain best fit minimizes the leftover residual, but it frequently leaves
tiny slivers that no future item can use.  We keep best fit as the dominant
term and add a small bounded bonus for residuals close to the typical item
size, so that (marginal) choices prefer a pocket that can still hold a
typical item.  The item mean/spread are estimated online with an EMA.
"""
import numpy as np

_m = 40.0      # running estimate of the item mean
_v = 300.0     # running estimate of the item variance
_n = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _m, _v, _n
    _n += 1
    k = min(_n, 100)
    d = item - _m
    _m += d / k
    _v += (d * d - _v) / k

    sig = _v ** 0.5
    if sig < 5.0:
        sig = 5.0

    r = bins - item                      # residual after placing the item here
    bonus = np.exp(-(((r - _m) / sig) ** 2))   # peaks when residual ~ typical item size
    return -r + 0.3 * bonus
# EVOLVE-BLOCK-END
