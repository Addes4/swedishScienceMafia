# EVOLVE-BLOCK-START
"""Hybrid rule: best-fit primary, with a light harmonic-style nudge.

Items are IID from a Weibull-shaped distribution with mean ~40 on capacity 100.
Pure best-fit is strong, but the harmonic family often gains a little by
deliberately creating residuals equal to common item sizes so the leftovers can
be packed later.  We keep best-fit as the primary ordering and use a small
residual "niche table" only to break close calls.
"""
import numpy as np

# Niche residuals that tend to be reusable by future items.  Derived from the
# item distribution: common item sizes cluster ~20-60 and small items fill gaps.
_NICHES = np.array([0, 8, 12, 16, 20, 25, 30, 34, 40, 45, 50, 55, 60, 66, 75], dtype=np.int64)

# Map a residual to its distance from the nearest niche (0 = perfect niche).
def _niche_dist(res):
    return np.abs(res[:, None] - _NICHES[None, :]).min(axis=1)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in, in bin order.
    """
    residual = bins - item                      # residual after placing here

    # Primary: best fit (smaller residual is better).
    primary = -residual.astype(np.float64)

    # Secondary: how close the residual is to a reusable "niche" size.
    niche = -_niche_dist(residual).astype(np.float64)

    # Combine: best-fit dominates, niche only breaks near-ties.
    # Scale primary so that a one-unit residual difference outweighs the
    # niche term, but ties in residual are resolved by niche, then bin order.
    score = primary * 4.0 + niche
    return score
# EVOLVE-BLOCK-END
