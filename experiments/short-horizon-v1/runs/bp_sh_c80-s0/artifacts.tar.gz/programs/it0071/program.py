# EVOLVE-BLOCK-START
"""Best-fit with a threshold: prefer best-fit unless it would strand a tiny residual."""
import numpy as np


def priority(item, bins):
    """Rank bins; highest score wins (first on ties).

    Primary rule: best fit (smallest residual after placement).
    But placements leaving a residual strictly below a running estimate of the
    smallest item size are penalized slightly, nudging items toward bins that
    leave reusable space or toward fresh bins.
    """
    residual = bins - item

    # Penalize micro-slivers slightly; residual >= 0 guaranteed by caller.
    # A residual of 0 (exact fit) is fine, so exclude it from the penalty.
    penalty = np.where((residual > 0) & (residual < 12), 0.5, 0.0)

    return -residual.astype(np.float64) - penalty
# EVOLVE-BLOCK-END

