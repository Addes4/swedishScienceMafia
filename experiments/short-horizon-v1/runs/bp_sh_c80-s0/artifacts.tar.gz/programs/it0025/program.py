# EVOLVE-BLOCK-START
"""Best fit with a fullness tie-break to avoid wasting exact-fit bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smaller residual is better (tightest fit).
    # Secondary: among equal residuals, prefer the fuller bin (smaller original capacity),
    # which keeps near-empty bins available for larger items.
    return -residual * 200.0 - (100 - bins)
# EVOLVE-BLOCK-END

