# EVOLVE-BLOCK-START
"""Best fit with reusable-residual bonus based on observed size histogram."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.int64), "n": 0}


def priority(item, bins):
    hist = _state["hist"]
    hist[item] += 1
    _state["n"] += 1

    resid = bins - item  # remaining capacity after placing (>=0 for shown bins)
    score = -(resid.astype(np.float64))

    n = _state["n"]
    if n >= 30:
        # Probability mass of observed item sizes -> chance a residual can be refilled.
        probs = hist / float(n)
        # Expected number of future items fitting residual r is ~ stream_remaining * P(size<=r).
        cum = np.cumsum(probs)  # cum[r] = P(item <= r)
        # Reward residuals that can hold a typical amount; weight by fill chance.
        reuse = cum[np.clip(resid, 0, 100)]
        score += 4.0 * reuse
        # Reward exact fills strongly (residual 0 leaves nothing wasted).
        score += np.where(resid == 0, 3.0, 0.0)
        # Penalize leaving a sliver that can hold almost nothing.
        score -= np.where((resid > 0) & (resid < 8), 1.5, 0.0)
    else:
        score += np.where(resid == 0, 3.0, 0.0)

    # Mild preference for already-open partial bins over fresh bins.
    score -= np.where(bins == 100, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
