# EVOLVE-BLOCK-START
"""Best fit, but avoid leaving residuals smaller than the current item's size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary: tightest fit (smallest residual). But if that residual would be smaller than
    `item` itself (a sliver that cannot hold another item of this size), instead prefer
    bins that leave a residual >= item, maximizing residual among those (i.e. keep the
    bin open for another same-sized item). Falls back to plain best-fit otherwise.
    """
    residual = bins - item  # capacity left after placing the item
    fits_more = residual >= item  # can still hold another item of this size
    if np.any(fits_more):
        # Among bins that stay useful, pick the tightest that still fits another item.
        # residual is in [item, ...]; smaller residual = tighter = better.
        score = np.where(fits_more, -residual, -1e18 - residual)
        return score
    # No bin can hold another same-sized item afterwards: pure best-fit.
    return -residual
# EVOLVE-BLOCK-END
