# EVOLVE-BLOCK-START
"""Best fit with a mild anti-new-bin nudge for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit -> maximize -(residual)
    score = -residual.astype(np.float64)
    # For small items, gently prefer fuller bins so we don't scatter tiny items
    # into fresh bins; the penalty is < 1 so it never overrides the residual order
    # among bins whose residuals differ by at least 1.
    if item <= 40:
        score -= (bins.astype(np.float64) / 200.0)
    return score
# EVOLVE-BLOCK-END
