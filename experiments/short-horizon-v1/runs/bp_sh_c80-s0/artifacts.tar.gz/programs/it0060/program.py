# EVOLVE-BLOCK-START
"""Best fit, with a guarded anti-sliver preference for fresh bins."""
import numpy as np


class _State:
    def __init__(self):
        self.min_item = 100


_STATE = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item < _STATE.min_item:
        _STATE.min_item = item
    # Best fit: smaller residual is better.
    residual = bins - item
    score = -residual.astype(np.float64)
    # Guarded anti-sliver: if best-fit would leave a residual below the smallest
    # item we've seen so far (i.e. a truly unusable sliver), give a tiny nudge
    # toward empty bins so the sliver is avoided. Kept small so best-fit still
    # dominates unless the residual is genuinely wasted space.
    thr = _STATE.min_item
    if thr > 1:
        unusable = residual < thr
        if unusable.any():
            # Prefer larger remaining capacity (fresh bins) among unusable results.
            score = score + np.where(unusable, bins * 1e-3, 0.0)
    return score
# EVOLVE-BLOCK-END
