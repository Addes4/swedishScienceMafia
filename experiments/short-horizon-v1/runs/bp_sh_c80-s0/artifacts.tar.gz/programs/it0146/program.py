# EVOLVE-BLOCK-START
"""Pure best-fit: place the item into the bin that leaves the smallest residual,
with a tiny constant penalty for empty bins so ties prefer already-open bins."""
import numpy as np


def priority(item, bins):
    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Tighter fit preferred: smaller residual => higher score.
    score = -(resid.astype(np.float64))

    # Break exact ties toward already-open partial bins over fresh empty bins.
    empty = bins == 100
    score -= np.where(empty, 1e-6, 0.0)

    return score
# EVOLVE-BLOCK-END

