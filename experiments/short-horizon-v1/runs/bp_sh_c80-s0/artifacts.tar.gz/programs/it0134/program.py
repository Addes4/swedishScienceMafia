# EVOLVE-BLOCK-START
"""Best fit with a reusable-residual tie-break from an observed size histogram."""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    it = int(item)
    counts = _state["counts"]
    # Decay so recent items matter more, keeping the histogram adaptive.
    counts *= 0.995
    counts[it] += 1.0
    _state["n"] += 1

    resid = bins - it  # >= 0 for shown bins

    # Dominant term: tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Secondary: bonus if the leftover equals a common item size (likely reused).
    # Build a size-weight lookup over possible residuals 0..100.
    w = counts  # weight per exact residual value
    if _state["n"] > 0:
        maxw = w.max()
        if maxw > 0:
            bonus = w * (3.0 / maxw)  # 0..3
        else:
            bonus = w
    else:
        bonus = w

    # Apply bonus indexed by integer residual (clip out-of-range to 0).
    r = resid.astype(np.int64)
    valid = (r >= 0) & (r <= 100)
    add = np.where(valid, bonus[np.clip(r, 0, 100)], 0.0)
    score += add

    # Penalty for leaving a sliver (residual that no item can fit well).
    sliver = (r > 0) & (r < 5)
    score -= np.where(sliver, 1.0, 0.0)

    # Strong preference against opening a fresh bin.
    empty = bins == 100
    score -= np.where(empty, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END

