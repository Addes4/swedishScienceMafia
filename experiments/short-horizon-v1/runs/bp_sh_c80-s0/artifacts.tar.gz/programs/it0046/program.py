# EVOLVE-BLOCK-START
"""Best fit with a stateful sliver-consolidation rule.

The dominant rule is best fit: place the item in the bin leaving the smallest
non-negative residual. Pure best fit is strong here, but it can create many
tiny residuals that no future item can fit. We add a light stateful correction:
if best fit would leave a residual below a learned "dead" threshold (smaller
than most arriving items), we instead pick the bin whose residual (after the
item) lands in the most useful range, i.e. as close as possible to a typical
item size, so the leftover space stays reusable.
"""
import numpy as np

# --- module state (per stream, reset by re-import / fresh module) ---
_state = {
    "n": 0,
    "sum": 0.0,
    "sumsq": 0.0,
    "counts": None,  # histogram of item sizes 1..100
    "dead": 15,      # residual smaller than this is treated as wasted
    "typical": 40.0, # typical item size (starts at distribution mean)
    "warmup": 40,    # items before we trust the estimate
}


def _update(item):
    s = _state
    s["n"] += 1
    x = float(item)
    s["sum"] += x
    s["sumsq"] += x * x
    if s["counts"] is None:
        s["counts"] = np.zeros(101, dtype=np.float64)
    s["counts"][item] += 1.0
    n = s["n"]
    if n >= s["warmup"]:
        mean = s["sum"] / n
        var = max(s["sumsq"] / n - mean * mean, 0.0)
        sd = var ** 0.5
        # "dead" residual: a bit below the 20th percentile-ish scale.
        s["dead"] = max(6.0, min(25.0, 0.35 * mean - 0.25 * sd))
        s["typical"] = min(100.0, max(20.0, mean))


def priority(item, bins):
    """Rank bins for the arriving item; highest score wins (first on ties)."""
    _update(item)
    s = _state
    resid = bins - item            # residual after placing item
    # best-fit ranking: smaller residual is better
    base = -resid.astype(np.float64)

    dead = s["dead"]
    if item <= dead:
        # tiny item: adding it rarely creates a new dead residual, but can
        # consume a near-dead bin. Best fit is fine; keep it.
        return base

    best_resid = int(resid.min())
    if best_resid < dead:
        # best fit would create/consume a sliver. Among all bins, prefer the
        # residual closest to a typical item size (keeps leftovers usable),
        # while still ranking strictly by that target.
        target = s["typical"]
        return -np.abs(resid.astype(np.float64) - target)
    return base
# EVOLVE-BLOCK-END
