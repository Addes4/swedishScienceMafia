# EVOLVE-BLOCK-START
"""Best fit with a sliver penalty: avoid leaving tiny unusable residual space."""
import numpy as np

_state = {"min_seen": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item < _state["min_seen"]:
        _state["min_seen"] = item
    tau = _state["min_seen"]
    if tau < 1:
        tau = 1

    residual = bins - item
    # Primary: best fit -> smallest residual (most negative score is best fit if we negate).
    score = -residual.astype(np.float64)
    # Penalize slivers: residuals in (0, tau) are hard to reuse.
    sliver = (residual > 0) & (residual < tau)
    score = score - 0.5 * sliver
    return score
# EVOLVE-BLOCK-END
