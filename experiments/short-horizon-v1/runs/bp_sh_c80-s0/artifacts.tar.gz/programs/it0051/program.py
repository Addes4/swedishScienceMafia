# EVOLVE-BLOCK-START
"""Best fit with a mild preference for making bins exactly full.

Best fit (highest priority = smallest resulting residual) is a strong
online rule for this item distribution.  A small extra bonus for placing
the item so that a bin becomes exactly full encourages consolidating
slivers into completed bins instead of leaving many partial bins behind.
"""
import numpy as np


def priority(item, bins):
    """Score each bin: higher is better; item goes to the highest score.

    Base score is negative resulting residual (best fit).  Bins that become
    exactly full receive a small additive bonus, and bins left with a
    residual smaller than the smallest observed item size (effectively
    unusable) get a small penalty relative to leaving a reusable residual.
    """
    residual = bins - item
    score = -residual.astype(np.float64)
    # Prefer exactly full bins.
    score += 1e-3 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
