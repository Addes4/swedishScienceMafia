# EVOLVE-BLOCK-START
"""Harmonic-style best fit: tightest residual wins, with tie-breaks that
prefer exact completion and class-consistent residuals."""
import numpy as np


def priority(item, bins):
    item = float(item)
    resid = bins.astype(np.float64) - item  # remaining capacity after placing

    # Base: strict tightest fit (smallest residual). Dominant term.
    score = -resid

    # Exact completion: placing this item fills the bin perfectly.
    score += np.where(resid == 0.0, 1000.0, 0.0)

    # Harmonic class tie-break: prefer residuals that fall in the same size
    # class as the item, so leftover space tends to fit future similar items.
    cls = np.floor(np.log(100.0 / np.maximum(item, 1.0)) / np.log(2.0))
    r = np.maximum(resid, 1e-9)
    resid_cls = np.floor(np.log(100.0 / r) / np.log(2.0))
    same_cls = (resid > 0) & (resid_cls == cls)
    score += np.where(same_cls, 0.5, 0.0)

    # Avoid opening a fresh empty bin unless it is clearly the best.
    empty = bins == 100
    score -= np.where(empty, 0.25, 0.0)

    return score
# EVOLVE-BLOCK-END

