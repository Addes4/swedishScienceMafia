# EVOLVE-BLOCK-START
"""Near-pure best fit with a light, robust tie-break toward reusable residuals."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Dominant term: tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Small deterministic tie-break: reward residuals that match a common
    # observed item size (so the leftover can likely be filled exactly later).
    if len(sizes) >= 40:
        arr = np.array(sizes, dtype=np.float64)
        mu = arr.mean()
        sd = arr.std()
        if sd < 1e-9:
            sd = 1.0
    else:
        mu = 40.0
        sd = 20.0

    # Rewards residuals near a typical size, weighted by a narrow Gaussian.
    z = (resid - mu) / (sd + 1e-9)
    near = np.exp(-0.5 * z * z)
    score += 0.3 * near

    # Mild anti-empty: avoid opening fresh bins when not needed.
    score -= np.where(bins == 100, 0.05, 0.0)

    return score
# EVOLVE-BLOCK-END

