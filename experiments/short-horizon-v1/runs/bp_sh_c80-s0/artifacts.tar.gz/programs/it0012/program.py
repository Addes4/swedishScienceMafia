# EVOLVE-BLOCK-START
"""Best fit with a mild residual-reuse bonus for common future item sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best-fit primary term (tightest residual is best -> least negative).
    score = -residual.astype(np.float64)
    # Small bonus when residual is either near zero (perfectly packed) or a
    # "useful" size that common small items (~half the mean, ~20-40) can fill,
    # so we don't strand tiny unusable gaps.
    useful = (residual >= 20) & (residual <= 40)
    score += 0.05 * useful
    score += 0.10 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
