# EVOLVE-BLOCK-START
"""Best-fit with a size-aware bias that keeps large-capacity bins available for big items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item
    # Base: best fit (smallest leftover after packing).
    score = -leftover.astype(np.float64)

    # For small items, nudge toward fuller bins so empty/high-capacity bins stay open.
    if item <= 40:
        score -= leftover * (0.35 * (1.0 - item / 40.0))

    # For large items, strongly reward near-exact fits.
    if item >= 60:
        exact = np.where(leftover == 0, 1.0, 0.0)
        score += exact * 50.0

    return score
# EVOLVE-BLOCK-END
