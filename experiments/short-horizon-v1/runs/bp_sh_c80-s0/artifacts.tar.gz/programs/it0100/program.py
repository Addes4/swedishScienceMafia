# EVOLVE-BLOCK-START
"""Best fit with a small bonus for residual = 100 minus a common item size."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 3000:
        del sizes[:1500]

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Base: prefer tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Build a smoothed histogram of observed item sizes to estimate which
    # future item sizes are likely. Bonus when residual == 100 - s for a
    # frequent size s, meaning a future item of size s would complete the bin.
    if len(sizes) >= 30:
        hist = np.zeros(101, dtype=np.float64)
        arr = np.array(sizes, dtype=np.int64)
        for s in arr:
            if 1 <= s <= 100:
                hist[s] += 1.0
        if hist.sum() > 0:
            hist /= hist.sum()
            # smooth with a small triangular kernel
            ker = np.array([1.0, 2.0, 3.0, 2.0, 1.0])
            ker /= ker.sum()
            hist = np.convolve(hist, ker, mode="same")
            # weight of residual r is hist at s = 100 - r
            idx = np.clip(100 - resid, 0, 100).astype(np.int64)
            w = hist[idx]
            # scale bonus relative to typical histogram mass
            score += 8.0 * w * hist.max() / (hist.max() + 1e-9) * (w / (w.max() + 1e-12))
    return score
# EVOLVE-BLOCK-END

