# EVOLVE-BLOCK-START
"""Hybrid: best fit normally, but for small items prefer leaving a bin with room for a
typical future item (mean ~40), avoiding premature closure of bins near full."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placement

    # Default: best fit (smallest residual wins).
    score = -residual.astype(np.float64)

    if item <= 15:
        # For small items, if some already-opened bin would still leave at least a
        # typical item's worth of room, prefer the roomiest such bin (keeps future
        # large fits possible), instead of closing bins tightly.
        roomy = residual >= 40
        if np.any(roomy):
            # Give roomy bins a bonus that dominates the best-fit ordering.
            score = np.where(roomy, -residual + 1000.0, -residual)

    return score
# EVOLVE-BLOCK-END

