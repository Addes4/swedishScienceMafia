# EVOLVE-BLOCK-START
"""Best fit, with a mild penalty for leaving tiny unusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit (tighter residual => higher priority).
    score = -residual.astype(np.float64)
    # Penalize small positive residuals that are hard to reuse later.
    # Tiny residuals (1..15) are nearly wasted space under the Weibull item mix.
    hard = (residual > 0) & (residual < 16)
    score = score - 2.0 * hard
    return score
# EVOLVE-BLOCK-END
