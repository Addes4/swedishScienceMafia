# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware residual cost.

Items are ~40 on average (Weibull shaped, 1..100). Pure best-fit minimizes the
leftover residual r = bins - item. That is near-optimal online, but it can leave
tiny residuals (1..5) that almost no future item can use, while a slightly larger
residual would still be usably filled later. We therefore keep best-fit ordering
but score bins by a cost that is monotone increasing in the residual (so tighter
fits still win overall) yet concave: small residuals are penalised relatively more
than large ones, gently pushing ties toward residuals that are either ~0 or big
enough for a typical item.

The cost is built only from `item` and `bins` (no state), is finite everywhere,
and preserves the first-bin tie-break because it is a strictly monotone function
of the residual with tiny distribution-aware shaping.
"""
import numpy as np


# Typical item size of the distribution (mean about 40).
_TYP = 40.0


def _cost(residual):
    """Cost of leaving `residual` capacity in the chosen bin.

    residual >= 0 (the bin fits the item). Lower cost is better.
    Base term is the residual itself (best fit). A concave shaping term rewards
    residuals that a typical future item (~_TYP) could still fill while mildly
    discouraging unusable tiny crumbs.
    """
    r = residual
    # Usable fraction: how much of a typical item this residual could hold.
    frac = np.minimum(r, _TYP) / _TYP          # in [0, 1]
    # Reward usable residuals a little (subtract), penalise near-zero crumbs a
    # little (their frac is ~0), keeping the overall order monotone in r.
    shaping = 0.5 * (frac - frac * frac)        # max 0.125 at frac=0.5, 0 at ends
    return r - shaping


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (capacity 100), in bin order.
    """
    residual = bins.astype(np.float64) - float(item)
    return -_cost(residual)
# EVOLVE-BLOCK-END

