# EVOLVE-BLOCK-START
"""Best fit with a decisive penalty for opening a fresh bin."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Base: prefer tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Decisive preference not to open a fresh bin when a valid partial fill exists.
    empty = bins == 100
    score -= np.where(empty, 50.0, 0.0)

    return score
# EVOLVE-BLOCK-END

