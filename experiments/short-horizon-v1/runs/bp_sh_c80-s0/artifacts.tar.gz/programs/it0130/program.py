# EVOLVE-BLOCK-START
"""Tightest-fit with a strong anti-empty-bins bias."""
import numpy as np


def priority(item, bins):
    resid = bins - item  # remaining capacity after placing (>=0 for shown bins)

    # Dominant: tightest fit (smallest residual after placement).
    score = -(resid.astype(np.float64))

    # Strongly prefer not to open a fresh (empty) bin when a partial bin fits.
    empty = bins == 100
    score -= np.where(empty, 100.0, 0.0)

    return score
# EVOLVE-BLOCK-END
