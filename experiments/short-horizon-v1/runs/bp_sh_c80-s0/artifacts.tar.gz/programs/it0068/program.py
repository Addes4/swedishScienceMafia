# EVOLVE-BLOCK-START
"""Harmonic-style capped best fit bin packing.

For each arriving item we compute a harmonic "ideal residual" target based on the
item's size class, then choose the bin whose post-placement residual is closest to
that target.  This generalises best-fit (which targets residual 0) by allowing
larger target residuals for larger items, which reduces the number of stranded
slivers and improves packing efficiency on Weibull-shaped size distributions.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    # Harmonic-style target residual.  Best-fit is recovered when item is small.
    # For a size-100 bin, an item of size s ideally leaves residual ~ f(s).
    # Use a piecewise target that grows with item size but stays well below 1
    # full bin, favouring placement that doesn't create useless slivers.
    if item <= 0:
        target = 0.0
    elif item <= 20:
        target = 0.0
    elif item <= 33:
        target = item * 0.25          # ~5..8
    elif item <= 50:
        target = item * 0.60          # ~20..30
    elif item <= 66:
        target = item * 0.90          # ~45..59
    else:
        target = 0.0                  # big items: pure best-fit

    residual = bins - item
    # Negative residuals can't occur (harness only shows fitting bins), but guard.
    valid = residual >= 0
    # Distance to target; smaller is better, so negate for priority.
    score = -np.abs(residual - target)
    # Never prefer an invalid placement.
    score = np.where(valid, score, -1e18)
    return score
# EVOLVE-BLOCK-END
