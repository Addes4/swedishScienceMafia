# EVOLVE-BLOCK-START
"""Best-fit with a conservative load-balancing tweak for mid-sized items."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Online mean estimate of item sizes.
    _state.n += 1
    a = 1.0 / min(_state.n, 200)
    _state.mean += a * (item - _state.mean)
    mu = _state.mean

    residual = bins - item  # >= 0 for bins shown (item fits)

    # Best-fit base score: smaller residual -> higher score.
    base = -residual.astype(np.float64)

    # For mid-sized items (near the mean), blend in a mild larger-residual
    # preference to avoid leaving tiny unusable slivers.
    lo = 0.55 * mu
    hi = 1.45 * mu
    if lo <= item <= hi and len(bins) > 0:
        # Prefer larger residual slightly (break ties toward more room).
        base = base + 0.02 * residual.astype(np.float64)

    return base
# EVOLVE-BLOCK-END
