# EVOLVE-BLOCK-START
"""Best fit with a bounded pairing bonus over the current bin configuration."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    if len(sizes) >= 30:
        arr = np.array(sizes, dtype=np.float64)
        mu = arr.mean()
        sd = arr.std()
        if sd < 1.0:
            sd = 1.0
    else:
        mu = 40.0
        sd = 20.0

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Dominant: tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Pairing bonus: reward a residual that is "likely completable", i.e. within
    # one typical item of zero (so it can be closed by a single future item),
    # scaled by how typical that closing item size is.
    r = resid.astype(np.float64)
    closing = r  # future item that would exactly fill the bin is of size r
    z = (closing - mu) / sd
    typical = np.exp(-0.5 * z * z)  # Gaussian plausibility of closing item
    # Only consider non-empty, valid residuals.
    valid = resid > 0
    score += np.where(valid, 3.0 * typical, 0.0)

    # Anti-empty: avoid opening fresh bins when a partial bin can hold the item.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END

