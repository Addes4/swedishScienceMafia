# EVOLVE-BLOCK-START
"""Best fit with a learned residual-quality tie-breaker.

Primary ordering is still tightest fit (smallest post-placement residual),
since that is near-optimal for this stream. The remaining loss comes from
how ties / near-ties are broken, so we add a learned goodness value for the
residual left behind: residuals that are large enough to be reused by a
typical future item are favored, tiny slivers and huge wasted residuals are
penalized.
"""
import numpy as np

_state = {"sizes": [], "q": None}


def _quality_table(sizes):
    """Build an array quality[r] = estimated usefulness of leaving residual r.

    quality[r] is the probability that a random future item fits in r,
    minus a small penalty for wasting capacity (large unusable residual).
    """
    q = np.zeros(101, dtype=np.float64)
    if len(sizes) >= 50:
        arr = np.array(sizes, dtype=np.float64)
        # Empirical CDF of item sizes.
        s_sorted = np.sort(arr)
        n = len(s_sorted)
        for r in range(101):
            # fraction of past items <= r
            q[r] = np.searchsorted(s_sorted, r, side="right") / n
        mu = arr.mean()
    else:
        mu = 40.0
        for r in range(101):
            # crude fallback: near-exponential fit ~ P(item<=r)
            q[r] = 1.0 - np.exp(-r / max(mu, 1e-6))
    # Penalize leaving residuals too small to reuse (slivers) and wasting
    # capacity when the residual is large but under one full bin.
    for r in range(101):
        if r == 0:
            q[r] = 1.0  # perfect fill, best possible
        else:
            # mild preference for not wasting lots of space
            q[r] -= 0.002 * (r / 100.0)
    return q


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 3000:
        del sizes[:1500]

    if _state["q"] is None or len(sizes) % 25 == 0:
        _state["q"] = _quality_table(sizes)
    q = _state["q"]

    resid = bins - item  # >= 0 for shown bins (they all fit)
    resid_clip = np.clip(resid, 0, 100)
    rq = q[resid_clip.astype(np.int64)]

    # Primary: tightest fit (smallest residual). Secondary: quality of residual.
    score = -(resid.astype(np.float64)) + 8.0 * rq

    # Discourage opening fresh bins when a valid partial bin exists.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
