# EVOLVE-BLOCK-START
"""Best fit with a deterministic exact-fill / typical-size residual bonus."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    # Estimate a typical item size from observed history (median is robust).
    if len(sizes) >= 20:
        arr = np.array(sizes, dtype=np.float64)
        typical = float(np.median(arr))
    else:
        typical = 40.0
    if typical < 1.0:
        typical = 1.0
    if typical > 100.0:
        typical = 100.0

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Base: strict best fit -> smallest residual dominates.
    score = -(resid.astype(np.float64))

    # Deterministic bonuses on the resulting residual.
    perfect = resid == 0
    score += np.where(perfect, 3.0, 0.0)

    # Bonus when leftover can exactly fit one typical item (likely reusable).
    near_typ = np.abs(resid - typical) <= 1.0
    score += np.where(near_typ, 0.6, 0.0)

    # Mild penalty for tiny unusable slivers (wasted space).
    sliver = (resid > 0) & (resid < typical)
    score -= np.where(sliver, 0.2, 0.0)

    # Discourage opening a fresh bin when partial fills exist.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
