# EVOLVE-BLOCK-START
"""Pair complementary residuals: reward leaving a residual that matches another bin's residual,
so two partial bins can later be combined to fill exactly."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    item = int(item)
    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Base: prefer tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Reward residuals that are themselves plausible item sizes (likely filled later).
    if len(sizes) >= 20:
        arr = np.array(sizes, dtype=np.float64)
        mu = arr.mean()
    else:
        mu = 40.0
    band = int(mu)
    if band < 1:
        band = 1
    if band > 100:
        band = 100
    tol = int(0.25 * band) + 1

    near_band = (resid >= 0) & (np.abs(resid - band) <= tol)
    score += np.where(near_band, 5.0, 0.0)

    # Perfect completion bonus: if residual is 0, that's the best outcome.
    score += np.where(resid == 0, 8.0, 0.0)

    # Complementary pairing: reward residuals that equal the residual of another
    # currently-visible partial bin (their sum can exactly fill a bin later).
    # Compute residuals of bins under the *current* state (before placement) that
    # are not the tightest fit, using the pre-placement residual distribution.
    pre = bins.astype(np.int64)
    # For each candidate residual r, count how many other bins currently have
    # remaining capacity exactly (100 - r) OR whose capacity equals r + item.
    # Cheap: build a small set of existing remaining capacities.
    existing = np.unique(pre)
    # A residual r pairs well if some other bin has capacity (100 - r) so item + that = 100.
    comp = 100 - resid
    pair = np.isin(comp, existing)
    score += np.where((resid > 0) & pair, 3.0, 0.0)

    # Penalize slivers too small for anything meaningful.
    sliver = (resid > 0) & (resid < max(1, band - tol))
    score -= np.where(sliver, 1.0, 0.0)

    # Strong preference not to open a fresh bin when a valid partial fill exists.
    empty = bins == 100
    score -= np.where(empty, 0.6, 0.0)

    return score
# EVOLVE-BLOCK-END

