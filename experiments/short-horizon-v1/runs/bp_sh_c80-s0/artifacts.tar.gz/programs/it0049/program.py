# EVOLVE-BLOCK-START
"""Best fit with sliver avoidance: prefer fully-full bins, then reusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary idea: among bins the item fits in, we want to avoid creating unusable slivers.
    Rank placements by residual = bins - item:
      1. exact fill (residual == 0) is best,
      2. otherwise residuals >= item (large enough to accept another typical-sized item) are
         good; smaller residuals are penalized,
      3. among the same class, tighter fit (smaller residual) wins, with ties to lower index.
    """
    residual = bins - item

    # Class 0: perfect fill. Class 1: reusable residual (>= item). Class 2: sliver.
    is_full = (residual == 0)
    is_reusable = residual >= item

    # Lower class value = better. Encode as large negative offsets.
    cls = np.where(is_full, 0, np.where(is_reusable, 1, 2))

    # Within class, prefer smaller residual (tighter fit).
    # Use combined key: class dominates, residual breaks ties.
    # 1000 is safely larger than any residual (<=99).
    score = -(cls * 1000 + residual)
    return score
# EVOLVE-BLOCK-END
