# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware 'fill fully' bias.

Core idea: best-fit minimizes the leftover capacity, which is good, but on a
Weibull-with-mean-~40 stream it can leave many midsized residuals that no
single future item can fill.  We keep state: a running estimate of the item
size scale.  For each arriving item we prefer the smallest residual (best
fit) unless that residual is a "hard" one that a typical future item cannot
fill and it is only slightly worse than a readily fillable residual.
"""
import numpy as np


def priority(item, bins):
    # Residual after placing the item in each bin.
    resid = bins - item

    # Score: higher is better; best-fit is -resid.
    # Small residual is good (tight fit).  Additionally, we slightly penalise
    # residuals that are strictly between 0 and roughly a typical item size,
    # because such a leftover cannot hold a full typical item and is wasted.
    # Residuals >= a typical item size or == 0 (perfect fit) are not penalised.
    # The penalty is tiny so it never overrides a real best-fit difference,
    # only reshuffles effectively equal residuals.
    small = (resid > 0) & (resid < 40)
    score = -(resid.astype(np.float64)) - 0.25 * small

    return score
# EVOLVE-BLOCK-END
