# EVOLVE-BLOCK-START
"""Best fit plus an exact-completion lookahead: strongly prefer residuals that a
likely future item can fill exactly, otherwise fall back to tightest fit."""
import numpy as np

_state = {"sizes": [], "hist": None}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    # Empirical distribution of item sizes (smoothed histogram over 1..100).
    if len(sizes) >= 50:
        arr = np.array(sizes, dtype=np.int64)
        arr = np.clip(arr, 1, 100)
        hist = np.bincount(arr, minlength=101).astype(np.float64)
        # Smooth with a small triangular kernel so nearby sizes get credit.
        kern = np.array([1.0, 2.0, 3.0, 2.0, 1.0])
        kern /= kern.sum()
        hist = np.convolve(hist, kern, mode="same")
        total = hist.sum()
        if total > 0:
            hist /= total
        _state["hist"] = hist
        prob = hist
    else:
        prob = None

    resid = bins - item  # >= 0 for shown bins

    # Base score: tightest fit (smallest residual).
    score = -(resid.astype(np.float64))

    # Strong preference: residual exactly matches a likely future item size,
    # so that future item can complete this bin with no waste.
    if prob is not None:
        useful = (resid >= 1) & (resid <= 100)
        match = np.where(useful, prob[np.clip(resid, 0, 100)], 0.0)
        score += 40.0 * match

    # Avoid opening a fresh bin when a partial fill exists.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
