# EVOLVE-BLOCK-START
"""Pure best-fit: smallest residual after placement wins; just avoid opening new bins on ties."""
import numpy as np

EMPTY_CAP = 100
EMPTY_PENALTY = 1e-6  # tiny: only breaks exact-tie cases toward already-open bins


def priority(item, bins):
    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)
    score = -(resid.astype(np.float64))
    # Prefer not to open a fresh bin when an exact tie exists.
    score -= np.where(bins == EMPTY_CAP, EMPTY_PENALTY, 0.0)
    return score
# EVOLVE-BLOCK-END
