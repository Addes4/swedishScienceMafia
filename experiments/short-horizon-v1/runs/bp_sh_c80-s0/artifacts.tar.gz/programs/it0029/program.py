# EVOLVE-BLOCK-START
"""Stateful best-fit toward the running-mean residual.

Classic best fit minimizes the leftover after placement, which is greedy w.r.t.
the current item only.  Since items are i.i.d. from a fixed Weibull-like
distribution (mean ~40), we instead prefer the bin whose leftover after
placement is closest to the running mean item size seen so far.  That way the
gaps we create are, on average, exactly fillable by a typical future item,
which improves packing efficiency over the stream.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    s = _state
    # Update running statistics with the current item.
    s["n"] += 1
    s["sum"] += float(item)
    mean = s["sum"] / s["n"]

    residual = bins - item  # leftover in each candidate bin after placement
    # Prefer residuals close to the running mean item size.
    return -np.abs(residual - mean)
# EVOLVE-BLOCK-END
