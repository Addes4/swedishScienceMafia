# EVOLVE-BLOCK-START
"""Best fit with sliver-avoiding tie-break.

Place the item in the bin it fits most tightly (best fit), but when several
bins are essentially tied on the residual they leave, prefer the one whose
residual is not an unusable sliver. The "usable" threshold is learned online
from the stream itself: we keep an exponential moving average of item sizes
and treat a residual below a small fraction of it as likely waste.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Base score: best fit (smaller residual is better).
    score = -residual.astype(np.float64)

    # We prefer residuals that are not tiny slivers. Estimate a typical small
    # item size online as a light EMA, seeded at half of the current item.
    state = priority.state
    if state is None:
        state = float(item)
    else:
        state = 0.9 * state + 0.1 * float(item)
    priority.state = state

    # A residual below this is likely unusable waste; nudge the score down so
    # among near-tied bins we favor ones that leave a usable remainder.
    sliver = 0.5 * state
    sliver_penalty = (residual < sliver).astype(np.float64)
    # Small weight: only breaks ties, never overrides a clearly better fit.
    score -= 1e-6 * sliver_penalty

    return score


priority.state = None
# EVOLVE-BLOCK-END

