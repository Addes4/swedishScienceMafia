# EVOLVE-BLOCK-START
"""Best fit with a light penalty for leaving a residual that is too small to be useful."""
import numpy as np

_TARGET = 40.0  # rough mean item size


def priority(item, bins):
    residual = bins - item
    # Best-fit base: prefer smallest nonnegative residual.
    # Penalty: discourage leaving a residual in (0, item) that's below a useful
    # fraction of the mean item size -- such slivers tend to be wasted.
    # A residual >= item can hold another item of this size, which is good.
    sliver = (residual > 0) & (residual < item)
    penalty = sliver * (item - residual) / _TARGET
    return -residual - penalty
# EVOLVE-BLOCK-END

