# EVOLVE-BLOCK-START
"""Best-fit with a histogram-driven reusable-residual tie-break."""
import numpy as np

_state = {"sizes": [], "hist": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    hist = _state["hist"]
    n = _state["n"]
    # Update running histogram of observed item sizes.
    it = int(item)
    if 1 <= it <= 100:
        hist[it] += 1.0
    n += 1
    _state["n"] = n

    # Decay the histogram very slowly so it tracks the stationary distribution.
    if n % 1000 == 0:
        hist *= 0.5

    # Tightest-fit base: prefer smallest residual (best fit).
    resid = bins - item
    score = -(resid.astype(np.float64))

    # Secondary tie-break: reward residuals that are plausible future item sizes.
    # Normalize the histogram to a smooth "reusability" weight.
    if n >= 30:
        total = hist.sum()
        w = hist / total if total > 0 else hist
        # smooth with neighbors to reduce noise on rare sizes
        sw = w.copy()
        sw[1:100] += w[0:99] + w[2:101]
        sw /= sw.max() if sw.max() > 0 else 1.0
    else:
        # uniform-ish prior early on
        sw = np.full(101, 0.1, dtype=np.float64)
        sw[0] = 0.0

    # Clip residuals into a lookup range; only valid residuals can be scored.
    idx = np.clip(resid, 0, 100).astype(np.int64)
    reuse = np.where((resid >= 0) & (resid <= 100), sw[idx], 0.0)
    score += 0.9 * reuse

    # Penalize residuals too small to hold almost anything (dead space).
    tiny = (resid >= 0) & (resid <= 10)
    score -= np.where(tiny, 0.6, 0.0)

    # Strong preference not to open a fresh bin when a partial one can fit.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
