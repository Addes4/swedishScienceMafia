# EVOLVE-BLOCK-START
"""Hybrid: avoid wasting near-perfect fits on small items, else best-fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    Strategy: pure best-fit is myopic; leaving a residual near 0 forces a new bin soon.
    Instead, we prefer the fullest bin whose post-placement residual is at least a
    small threshold, so that a bin near-exactly full is not consumed by a tiny item.
    """
    resid = bins - item
    # threshold: avoid filling bins down to residuals that waste future items,
    # but keep it modest so we don't abandon tight packing.
    thr = max(5, item // 8)
    score = np.where(resid >= thr, -resid, -1e9 - resid)
    return score
# EVOLVE-BLOCK-END
