# EVOLVE-BLOCK-START
"""Worst-fit among bins leaving a reusable residual; best-fit otherwise."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 2000:
        del sizes[:1000]

    # Estimate the typical item size from observed history.
    if len(sizes) >= 20:
        arr = np.array(sizes, dtype=np.float64)
        mu = arr.mean()
    else:
        mu = 40.0

    typical = mu
    if typical < 1.0:
        typical = 1.0
    if typical > 100.0:
        typical = 100.0

    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)
    resid_f = resid.astype(np.float64)

    # A residual is "reusable" if it can still hold a typical item after this placement.
    reusable = resid_f >= typical

    # Among reusable bins, prefer to leave the *largest* residual (least fragmentation,
    # keeps bins flexible for the many small future items). Otherwise tightest fit.
    score = np.where(reusable, resid_f, -resid_f)

    # Mild preference not to open a fresh bin when a reusable partial fill exists.
    empty = bins == 100
    score -= np.where(empty & reusable.any(), 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END

