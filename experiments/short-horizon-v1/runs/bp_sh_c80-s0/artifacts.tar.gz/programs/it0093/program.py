# EVOLVE-BLOCK-START
"""Best fit with a learned residual-value tiebreak and empty-bin penalty.

The rule is essentially best fit: place the item so the leftover space is as
small as possible.  Ties are broken with a small learned preference for
leftovers that (a) are tiny (unlikely to be usable again) or (b) exactly match
a frequently seen recent item size (likely to be filled by a future item).
Opening a brand-new bin is mildly discouraged when any partial bin fits.
"""
import numpy as np

_state = {"sizes": [], "counts": None}


def priority(item, bins):
    sizes = _state["sizes"]
    sizes.append(int(item))
    if len(sizes) > 5000:
        del sizes[:2500]

    n = len(sizes)
    if n >= 50:
        counts = _state["counts"]
        if counts is None or n % 100 == 1:
            counts = np.bincount(np.array(sizes, dtype=np.int64), minlength=101)
            _state["counts"] = counts
        freq = counts.astype(np.float64)
        total = freq.sum()
        if total > 0:
            freq = freq / total
        else:
            freq = None
    else:
        freq = None

    resid = bins - item  # remaining capacity after placing, >= 0 for shown bins

    # Primary: best fit (smallest residual).
    score = -(resid.astype(np.float64))

    if freq is not None:
        # Bonus if this residual exactly matches a commonly seen item size.
        ridx = resid.astype(np.int64)
        ridx = np.clip(ridx, 0, 100)
        match = freq[ridx]
        score += 3.0 * match

    # Small preference for very tight / near-perfect fills.
    score += np.where((resid >= 0) & (resid <= 2), 0.5, 0.0)

    # Discourage opening a fresh bin if any partial bin fits.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
