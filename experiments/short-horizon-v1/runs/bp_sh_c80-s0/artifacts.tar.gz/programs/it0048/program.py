# EVOLVE-BLOCK-START
"""Best fit with a stateful harmonic tie-break toward a reusable residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _ema, _n

    # Stateful estimate of typical item size (EMA of recent items).
    try:
        _ema
    except NameError:
        _ema = float(item)
        _n = 0
    _n += 1
    _ema += (item - _ema) * (2.0 / (min(_n, 50) + 1.0))
    target = _ema

    residual = bins - item  # resulting remaining capacity
    best = residual.min()

    # Primary: best fit (smallest resulting residual). Near-ties within a small
    # window are broken toward a reusable target residual.
    window = 4
    close = residual <= best + window
    # For close bins, reward being near the target residual.
    tie_score = -np.abs(residual - target)
    score = np.where(close, tie_score, -residual.astype(np.float64))
    # Ensure strict separation: close bins always outrank non-close bins.
    score = score - close * 0.0
    # Order mainly by closeness to best fit, then by tie_score.
    big = np.where(close, tie_score, -1e9 - residual.astype(np.float64))
    return big
# EVOLVE-BLOCK-END
