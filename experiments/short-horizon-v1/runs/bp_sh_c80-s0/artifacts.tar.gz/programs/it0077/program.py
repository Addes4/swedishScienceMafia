# EVOLVE-BLOCK-START
"""Best-fit with a tiny secondary bonus for residuals that pair well."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    Primary order is tightest fit (best-fit). As a tie-break within the same
    residual we prefer a residual that is close to an exact multiple of the
    item size, which tends to leave usable space for later similar items.
    """
    residual = (bins - item).astype(np.float64)
    # Tiny secondary term: reward residuals of the form k*item (k>=1) slightly.
    rem = np.mod(bins, item).astype(np.float64)
    # smaller rem => near exact multiple; scale below 1.0 so it never overrides best-fit
    bonus = -rem * (1.0 / (item + 1.0))
    return -residual + bonus
# EVOLVE-BLOCK-END
