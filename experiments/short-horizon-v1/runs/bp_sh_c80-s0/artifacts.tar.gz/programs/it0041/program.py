# EVOLVE-BLOCK-START
"""Best fit with periodic worst-fit probing to escape packing traps."""
import numpy as np

_state = {"count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["count"] += 1
    residuals = bins - item  # smaller = tighter fit
    # Occasionally prefer the emptiest bin (worst fit) to open fresh room.
    if _state["count"] % 17 == 0:
        return bins.astype(np.float64)
    return -residuals.astype(np.float64)
# EVOLVE-BLOCK-END
