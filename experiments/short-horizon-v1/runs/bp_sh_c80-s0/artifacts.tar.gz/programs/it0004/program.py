# EVOLVE-BLOCK-START
"""Hybrid best-fit / fill-aware rule for online bin packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit score: prefer bins whose remaining capacity is closest to the item size.
    bf = -(bins - item)

    if item >= 34:
        return bf

    # For small items, mildly prefer bins that are already well filled (tight fit),
    # but discourage leaving tiny unusable slivers (fragmentation).
    residual = bins - item  # leftover after placing
    # Penalize residuals that are small but nonzero (hard to reuse), reward exact fits.
    frag = np.where((residual > 0) & (residual < item), -1.0, 0.0)
    return bf + frag
# EVOLVE-BLOCK-END

