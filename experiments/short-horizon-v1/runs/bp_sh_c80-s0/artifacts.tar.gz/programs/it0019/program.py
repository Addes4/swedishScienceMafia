# EVOLVE-BLOCK-START
"""Best fit with a small-item residual guard."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    # Core: prefer the tightest fit (smallest resulting residual).
    residual = bins - item

    # For genuinely small items, avoid dropping them into bins whose residual after
    # placement becomes too small to be useful later, unless no better option exists.
    # This keeps best-fit's strength on medium/large items unchanged.
    if item <= 20:
        # Prefer bins whose post-placement residual is at least the item size
        # (i.e. leaves room for another similarly small item), else fall back to best fit.
        usable = residual >= item
        # Primary key: usable first, then smallest usable residual (tight but recyclable).
        # Non-usable bins get a strictly worse key.
        score = np.where(usable, -residual, -1000.0 + residual)
        return score

    return -residual
# EVOLVE-BLOCK-END

