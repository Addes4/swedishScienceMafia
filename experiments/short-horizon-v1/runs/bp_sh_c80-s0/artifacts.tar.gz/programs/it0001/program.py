# EVOLVE-BLOCK-START
"""Hybrid: best-fit for large items, worst-fit for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties).

    Small items are packed using worst-fit (fill fullest bins first) to
    preserve tightly-fitting bins for larger items, while larger items
    use best-fit (tightest remaining capacity)."""
    if item <= 40:
        # Worst fit: prefer bin with smallest remaining capacity (fullest bin)
        return -bins
    else:
        # Best fit: prefer bin with smallest remaining capacity >= item
        return -(bins - item)
# EVOLVE-BLOCK-END

