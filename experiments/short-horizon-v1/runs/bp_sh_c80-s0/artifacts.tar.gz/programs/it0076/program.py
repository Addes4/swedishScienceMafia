# EVOLVE-BLOCK-START
"""Best-fit with a sliver guard: avoid creating unusably small residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best-fit ranking: smaller residual after placement is better.
    score = -residual.astype(np.float64)

    # Guard: discourage creating residuals that are too small to be useful.
    # A residual below a small fraction of the item size is likely a stranded sliver.
    # Keep the penalty mild so it only affects near-ties.
    threshold = item  # want leftover big enough for another item of similar size
    small = residual < threshold
    score[small] -= 0.5

    return score
# EVOLVE-BLOCK-END
