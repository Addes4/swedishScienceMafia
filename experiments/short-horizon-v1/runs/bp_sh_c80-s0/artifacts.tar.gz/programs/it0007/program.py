# EVOLVE-BLOCK-START
"""Best fit with a mild penalty on extremely tight residuals for mid/large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Best fit: smaller residual is better.
    score = -residual.astype(np.float64)
    # Mild penalty for residuals that are very tight (0 or 1) for mid/large items,
    # so we don't waste near-perfect fits on items that could fit elsewhere,
    # while still preferring tighter fits overall.
    if item >= 30:
        tight = residual <= 1
        score -= tight * 0.5
    return score
# EVOLVE-BLOCK-END

