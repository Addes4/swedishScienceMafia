# EVOLVE-BLOCK-START
"""Strict best fit: place each item in the bin with the smallest remaining
capacity that still fits. This is the classic near-optimal online rule and
avoids the ad-hoc bonuses that misfired on the Weibull item distribution."""
import numpy as np

_state = {}


def priority(item, bins):
    resid = bins.astype(np.int64) - int(item)
    # Higher score for tighter fits; bins shown already fit the item.
    return -(resid.astype(np.float64))
# EVOLVE-BLOCK-END

