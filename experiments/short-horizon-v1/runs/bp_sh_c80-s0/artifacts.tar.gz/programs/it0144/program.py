# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus and fresh-bin penalty."""
import numpy as np


def priority(item, bins):
    resid = bins - item  # remaining capacity after placing (>= 0 for shown bins)

    # Base: prefer tightest fit (smallest residual after placement).
    score = -(resid.astype(np.float64))

    # Strong bonus for an exact (near-exact) fill.
    score += np.where(resid <= 1, 3.0, 0.0)

    # Small bonus for leaving a large, still-recyclable residual.
    score += np.where(resid >= 60, 0.5, 0.0)

    # Penalize leaving tiny slivers that are unlikely to be reused.
    sliver = (resid > 1) & (resid < 15)
    score -= np.where(sliver, 0.5, 0.0)

    # Mild preference not to open a fresh bin when a partial fill exists.
    empty = bins == 100
    score -= np.where(empty, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END

