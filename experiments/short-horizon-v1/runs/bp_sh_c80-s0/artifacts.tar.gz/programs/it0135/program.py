# EVOLVE-BLOCK-START
"""Best fit with an exact-fill (complement) bonus."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.int64), "count": 0}


def priority(item, bins):
    hist = _state["hist"]
    item = int(item)
    hist[item] += 1
    _state["count"] += 1

    n = _state["count"]

    resid = bins - item  # >= 0 for shown bins

    score = -resid.astype(np.float64)

    # Bonus when the residual left behind is itself a plausible item size:
    # it can likely be filled exactly later, avoiding waste.
    # Use observed histogram once we have enough data, else a smooth prior.
    if n >= 30:
        w = hist.astype(np.float64)
        w /= w.sum()
        # residual size likelihood
        p = w[np.clip(resid, 0, 100)]
    else:
        # smooth prior around typical sizes
        p = np.exp(-((resid - 40.0) ** 2) / (2.0 * 20.0 ** 2))

    score += 3.0 * p

    # Complement bonus: if this residual matches another open bin's residual,
    # the two leftover spaces could combine (cheap pairing signal).
    # Count how many open bins share each residual value.
    resid_clip = np.clip(resid, 0, 100)
    # bins that are non-empty reference (remaining capacity of others)
    other = bins  # current remaining of bins shown
    # number of bins whose remaining capacity equals our new residual
    # (build a small lookup over possible capacities)
    cap = other.astype(np.int64)
    counts = np.bincount(cap, minlength=101)
    # subtract self-count possibility roughly
    pair = counts[resid_clip]
    score += 0.5 * (pair > 1)

    # Strong but modest anti-empty: avoid opening fresh bins needlessly.
    empty = bins == 100
    score -= np.where(empty, 0.6, 0.0)

    return score
# EVOLVE-BLOCK-END

