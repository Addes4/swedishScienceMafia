# EVOLVE-BLOCK-START
"""Best fit with a sliver-avoidance refinement.

Plain best-fit minimises the residual after placement. The problem is that it often
leaves tiny residuals (slivers) that no future item can use, e.g. residual 3 when items
are ~40. This rule instead scores bins so that:

  * a placement that closes a bin completely (residual 0) is best,
  * otherwise a placement that leaves a residual of at least ``min_item`` (a reusable
    residual that can hold at least the smallest item seen so far) is preferred over one
    that leaves an unusable sliver,
  * ties are broken by ordinary best-fit (smaller residual).

It is stateful only to remember the smallest item seen in the stream, a cheap proxy for
the lower tail of the Weibull distribution, which controls what counts as a sliver.
"""
import numpy as np


_MIN_ITEM = 100


def priority(item, bins):
    global _MIN_ITEM
    if item < _MIN_ITEM:
        _MIN_ITEM = item
    residual = bins - item            # remaining capacity after placing the item
    # 0 residual (bin exactly full) -> best; sliver (0 < residual < min_item) -> worst.
    sliver = (residual > 0) & (residual < _MIN_ITEM)
    score = -residual.astype(np.float64)
    score[sliver] -= 1e6              # strongly discourage unusable slivers
    return score
# EVOLVE-BLOCK-END
