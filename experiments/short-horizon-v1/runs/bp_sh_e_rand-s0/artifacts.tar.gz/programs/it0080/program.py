# EVOLVE-BLOCK-START
"""Best fit with a smooth residual-utility bonus."""
import numpy as np


def priority(item, bins):
    """Rank bins by tightest fit plus a smooth reward for a reusable residual.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 remaining capacities of bins the item fits in (bin order).
    """
    remaining = (bins - item).astype(np.float64)  # post-placement residual
    best_fit = -remaining  # tightest fit first

    # Smooth utility of the residual: exact fill is great; otherwise a residual
    # that is large enough to hold a typical item (mean ~40) is more reusable than
    # a small unusable leftover. Use a logistic ramp rather than a hard cutoff.
    util = 1.0 / (1.0 + np.exp(-(remaining - 20.0) / 6.0))
    exact = (remaining == 0).astype(np.float64)

    return best_fit + 3.0 * util + 2.0 * exact
# EVOLVE-BLOCK-END
