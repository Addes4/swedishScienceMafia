# EVOLVE-BLOCK-START
"""Harmonic-flavored best fit: prefer residuals just below class thresholds."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # >= 0 guaranteed by the harness

    # Harmonic-style weighting: a bin whose post-placement residual r lies in
    # (1/(k+1), 1/k] * C  is "worth" about k units of future packing potential.
    # We prefer smaller residuals (higher weight), matching best-fit, but the
    # reciprocals make residuals just below a class boundary much more valuable,
    # driving items to fill bins and keep leftovers reusable.
    residual = remaining.astype(np.float64)

    # floor weight: larger for smaller residual. Use 100/(r+1) as a smooth
    # harmonic-like weight that peaks at r=0 (exact fill) and decays.
    weight = 100.0 / (residual + 1.0)

    # Feasibility: recomputed robustly (in case item does not fit any bin).
    feasible = remaining >= 0

    return np.where(feasible, weight, -1e9)
# EVOLVE-BLOCK-END

