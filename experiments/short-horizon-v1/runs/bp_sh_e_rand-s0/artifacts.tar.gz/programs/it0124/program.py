# EVOLVE-BLOCK-START
"""Harmonic-class best fit: rank by the harmonic class of the resulting residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # residual capacity after placing the item

    # Base: best fit (prefer tightest residual, i.e. smallest remaining).
    score = -remaining.astype(np.float64)

    # Harmonic-style brake: residuals in an intermediate band are the "wasteful"
    # ones -- too big to be negligible, too small to hold a typical item next.
    # Strongly discourage stranding capacity in the lower half of the item size,
    # where a future item of similar size will not fit.
    # Penalize residuals r with 0 < r < item (can't fit another same-size item)
    # but especially those near the lower end (awkward slivers).
    low = (remaining > 0) & (remaining < item)
    # Penalty proportional to how "awkward" the residual is: max near r ~ item/2.
    frac = np.where(low, remaining.astype(np.float64) / max(item, 1), 0.0)
    # Prefer residuals that are either ~0 (perfectly tight) or large enough to
    # keep a full item; the trough is around half the item size.
    awkward = np.where(low, 1.0 - np.abs(2.0 * frac - 1.0), 0.0)
    score -= 1.5 * awkward

    # Mild reward for residuals that can still hold a reasonably sized future item
    # (>= item), reinforcing the "leave usable gaps" behavior.
    usable = remaining >= item
    score += np.where(usable, 0.25, 0.0)

    return score
# EVOLVE-BLOCK-END

