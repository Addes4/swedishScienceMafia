# EVOLVE-BLOCK-START
"""Best fit with a residual-harmonic waste penalty shaped by observed items."""
import numpy as np


class _Stats:
    """Cheap online tracker of observed item sizes."""

    def __init__(self):
        self.n = 0
        self.total = 0.0
        # quantile sketch via fixed sample of recent/histogram-free approach
        self.samples = []  # bounded reservoir
        self.next_pow = 1

    def add(self, x):
        self.n += 1
        self.total += x
        # simple bounded reservoir
        if len(self.samples) < 512:
            self.samples.append(x)
        else:
            if x > 0 and (x * 2654435761) % 512 == 0:
                pass
            # keep most recent-ish small set deterministic
            self.samples[self.n % 512] = x

    def low_quantile(self):
        """Approx 25th percentile of item sizes (threshold for 'too small to reuse')."""
        if self.n < 8:
            return 20.0
        s = np.sort(np.asarray(self.samples, dtype=np.float64))
        return float(s[int(0.25 * (len(s) - 1))])


_state = {}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    key = id(bins)  # not stable; instead use global single-stream state
    st = _state.get("st")
    if st is None:
        st = _Stats()
        _state["st"] = st

    # Update stats with the arriving item (called once per item).
    st.add(item)

    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit

    # Threshold: residuals below the bulk of item sizes are hard to reuse.
    thr = st.low_quantile()
    if thr < 1.0:
        thr = 1.0

    # Penalize residual in (0, thr): capacity too small for a typical future item.
    small = (remaining > 0) & (remaining < thr)
    waste = np.where(small, thr - remaining, 0.0)
    return best_fit - 2.0 * waste
# EVOLVE-BLOCK-END

