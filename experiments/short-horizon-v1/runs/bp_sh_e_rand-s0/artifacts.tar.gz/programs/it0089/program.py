# EVOLVE-BLOCK-START
"""Best fit with a strong exact-fill bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    # Base: best fit (highest score => smallest post-placement residual).
    score = -remaining.astype(np.float64)
    # Strongly reward exact fills so we complete bins whenever possible.
    score += np.where(remaining == 0, 1000.0, 0.0)
    return score
# EVOLVE-BLOCK-END
