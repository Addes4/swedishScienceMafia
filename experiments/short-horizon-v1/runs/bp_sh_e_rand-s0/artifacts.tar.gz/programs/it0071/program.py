# EVOLVE-BLOCK-START
"""Best fit with a soft, distribution-aware residual penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit

    # Smooth penalty: strongly discourage leaving residuals in the "dead zone"
    # (0, ~20) where few future items fit, using a smooth falloff rather than a
    # hard threshold. This keeps the gradient information that pure best-fit has
    # but reorders near-ties toward more reusable bins.
    r = remaining.astype(np.float64)
    # dead_zone peak near residual 10, width ~10; vanishes for r >= 25.
    dead = np.exp(-((r - 10.0) ** 2) / (2.0 * 8.0 * 8.0))
    dead = np.where(r > 0, dead, 0.0)
    return best_fit - 3.0 * dead
# EVOLVE-BLOCK-END
