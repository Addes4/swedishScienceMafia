# EVOLVE-BLOCK-START
"""Best-fit with a learned residual-usability tie-break."""
import numpy as np


class _State:
    n = 0
    total = 0.0


_s = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running mean of observed item sizes.
    _s.n += 1
    _s.total += item
    mean = _s.total / _s.n

    remaining = bins - item
    # Dominant term: best fit (prefer the fullest bin that still fits).
    best_fit = -remaining.astype(np.float64)

    # Tie-break: reward residuals that are 0 (perfect) or near the typical
    # future item size, since those leave the most reusable leftover capacity.
    # Small weight so it only breaks near-ties in best-fit.
    target_dist = np.minimum(np.abs(remaining - mean), np.abs(remaining))
    return best_fit - 0.05 * target_dist.astype(np.float64)
# EVOLVE-BLOCK-END
