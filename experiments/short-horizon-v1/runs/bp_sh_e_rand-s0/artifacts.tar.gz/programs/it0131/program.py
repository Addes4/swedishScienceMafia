# EVOLVE-BLOCK-START
"""Best fit with a smooth, scale-aware penalty on unusably small leftovers."""
import numpy as np

# Running state (per stream) to estimate the typical item size.
_state = {
    "n": 0,
    "sum": 0.0,
    "mean": 40.0,
}


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties).

    Core idea: best fit (tightest remaining capacity), but with a smooth
    penalty for leaving a small, hard-to-reuse residual.  The penalty
    threshold is scaled to the running mean item size rather than a fixed
    constant, so it adapts to the actual distribution.
    """
    # Update running mean item size.
    _state["n"] += 1
    _state["sum"] += item
    mean_size = _state["sum"] / _state["n"]
    # Use a threshold relative to the typical item size.
    thresh = max(1.0, 0.5 * mean_size)

    remaining = bins - item  # >= 0 for all bins shown
    best_fit = -remaining.astype(np.float64)

    # Smooth penalty: residuals in (0, thresh) are increasingly wasteful.
    # A residual of 0 (perfect fit) is ideal, so do NOT penalize it.
    small = (remaining > 0) & (remaining < thresh)
    frac = np.where(small, (remaining.astype(np.float64) / thresh), 0.0)
    # Penalize by how "wasted" the leftover is; weight tuned to stay close
    # to pure best fit while breaking ties toward fuller bins.
    penalty = 3.0 * frac * (1.0 - frac) + 1.0 * small * frac

    return best_fit - penalty
# EVOLVE-BLOCK-END
