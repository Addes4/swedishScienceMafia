# EVOLVE-BLOCK-START
"""Best fit with a small learned bonus for leaving reusable residual capacity."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_WEIGHT = 0.6


def priority(item, bins):
    global _TOTAL
    # update running histogram of arriving item sizes
    if 1 <= item <= 100:
        _HIST[item] += 1.0
    _TOTAL += 1.0
    freq = _HIST / _TOTAL if _TOTAL > 0 else _HIST

    residual = bins - item  # remaining capacity after placing item
    # Probability mass of item sizes that can still fit in the residual.
    # Precompute cumulative tail probabilities for each possible residual.
    # tail[r] = P(next item size <= r)
    cdf = np.cumsum(freq)
    # residuals range 0..99; clip to avoid out-of-range
    r = np.clip(residual, 0, 100)
    reusable = cdf[r]

    # primary term: tighter fit => higher score (smaller residual)
    # bias term: reward reusable residuals
    return -(residual.astype(np.float64)) + _WEIGHT * reusable
# EVOLVE-BLOCK-END
