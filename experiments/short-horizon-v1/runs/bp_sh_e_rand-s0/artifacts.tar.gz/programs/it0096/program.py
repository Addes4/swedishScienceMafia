# EVOLVE-BLOCK-START
"""Best-fit with residual-utility ranking: tighten fits, avoid stranding tiny leftovers."""
import numpy as np


def priority(item, bins):
    """Score every fitting bin; higher score wins, ties go to the earliest bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item

    # Base: prefer the tightest fit (smallest post-placement residual).
    score = -remaining.astype(np.float64)

    # Strong bonus for a perfect fill: closes a bin with zero waste.
    score += 60.0 * (remaining == 0)

    # Discourage stranding tiny unusable leftovers, but graduated so that the
    # smallest positive residuals are penalized most and larger ones fade out.
    tiny = (remaining > 0) & (remaining <= 30)
    penalty = np.where(tiny, 30.0 - remaining, 0.0)
    score -= penalty

    # Mild preference for leaving a comfortably reusable residual (spreads
    # items away from marginal fits without overriding true tightness).
    score += 3.0 * np.minimum(remaining, 100)

    return score
# EVOLVE-BLOCK-END
