# EVOLVE-BLOCK-START
"""Best fit with a learned residual-band bonus (harmonic-flavored)."""
import numpy as np

# Weibull-shaped item distribution (mean ~40): size classes worth keeping alive.
# Boundaries chosen so residual bands match commonly seen item sizes.
_BOUNDS = np.array([0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100], dtype=np.float64)
# Prior utility per residual band: higher = more likely reusable by a future item.
_BAND_UTIL = np.array([0.0, 0.9, 0.9, 0.8, 0.6, 0.4, 0.3, 0.2, 0.1, 0.05], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; highest wins, ties to first bin."""
    remaining = bins - item
    # Primary: best fit (smaller residual is better).
    score = -remaining.astype(np.float64)
    # Secondary: reward residuals that land in a reusable band.
    idx = np.searchsorted(_BOUNDS, remaining, side="right") - 1
    idx = np.clip(idx, 0, len(_BAND_UTIL) - 1)
    band_bonus = np.where(remaining > 0, _BAND_UTIL[idx], 0.0)
    # Scale so band bonus refines rather than overrides best-fit ordering.
    return score + 0.9 * band_bonus
# EVOLVE-BLOCK-END

