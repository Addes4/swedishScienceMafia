# EVOLVE-BLOCK-START
"""Best fit with dead-space-aware penalty: avoid tiny unusable leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining  # higher is tighter fit

    # Dead space: residual that is positive but too small to likely ever be reused.
    # Treat residuals in [1, 19] as progressively worse toward 0, but scale the
    # penalty so that a residual of 19 is essentially neutral vs. best fit.
    r = remaining.astype(np.float64)
    small = (r > 0) & (r <= 19)
    penalty = np.where(small, (20.0 - r), 0.0)
    return best_fit.astype(np.float64) - 0.6 * penalty
# EVOLVE-BLOCK-END

