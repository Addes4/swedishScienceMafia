# EVOLVE-BLOCK-START
"""Best fit with a minimal, size-relative sliver penalty to avoid unusable leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining  # higher is tighter fit; dominant term

    # Only lightly penalize residuals that are almost certainly unusable,
    # keeping best fit dominant so tight packing is preserved.
    sliver = (remaining > 0) & (remaining <= 2)
    # also penalize residuals smaller than a fraction of the current item
    frac = max(1, item // 8)
    sliver |= (remaining > 0) & (remaining < frac)

    return best_fit.astype(np.float64) - 0.5 * sliver
# EVOLVE-BLOCK-END
