# EVOLVE-BLOCK-START
"""Best fit with a principled, size-relative residual-reuse correction."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # post-placement residual (>= 0 since item fits)

    # Dominant term: best fit -> prefer the smallest residual.
    best_fit = -remaining

    # Secondary term: among near-equal residuals, mildly prefer residuals that are
    # still "reusable".  A residual that is a usable fraction of typical item sizes
    # is valuable; very small slivers are waste.  We use a smooth, size-relative
    # measure so the correction never overrides the tight-fit ordering.
    # reward grows with residual up to ~item size, then saturates.
    scale = float(item) + 1.0
    reuse = remaining / (remaining + scale)  # in [0, 1), monotone increasing

    # Small weight so best-fit stays dominant on any integer residual difference.
    return best_fit.astype(np.float64) + 0.25 * reuse
# EVOLVE-BLOCK-END

