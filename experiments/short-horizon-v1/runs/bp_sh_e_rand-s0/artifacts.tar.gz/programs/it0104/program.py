# EVOLVE-BLOCK-START
"""Best fit with an exponential penalty on unusable residuals.

The base ranking is best fit: the bin with the smallest remaining capacity that
still fits the item is preferred, because that concentrates packing.  Pure best
fit, however, often leaves tiny residuals (1..k) that no later item can use.
We subtract a smooth penalty that grows as the post-placement residual shrinks
towards zero, so sliver-creating placements are discouraged without overpowering
the best-fit ordering for larger residuals.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (ties: first).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in
          bin order, including empty bins (remaining capacity 100).
    """
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)

    # Exponential penalty that is meaningful only for very small residuals.
    # residual = 0  -> slight bonus (exact fit closes the bin perfectly).
    # residual 1..  -> penalty, decaying as residual grows.
    residual = remaining.astype(np.float64)
    # scale tied to typical residual scale; smaller items -> finer resolution.
    scale = 4.0
    pen = np.where(residual > 0, -np.exp(-residual / scale), 0.0)
    # exact fits get a bonus rather than a penalty
    exact = np.where(residual == 0, 1.0, 0.0)

    return best_fit + pen + exact
# EVOLVE-BLOCK-END
