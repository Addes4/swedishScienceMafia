# EVOLVE-BLOCK-START
"""Harmonic-style bin choice: prefer bins whose residual lands in the harmonic
class matching the item, using Best Fit as the intra-class ranking."""
import numpy as np

# precomputed harmonic thresholds for item sizes 1..100
# class k covers items with size in (1/(k+1), 1/k] * 100
_BOUNDS = np.array([100, 50, 34, 25, 20, 17, 15, 13, 12, 11,
                    10, 10, 9, 9, 8, 8, 8, 7, 7, 7,
                    7, 6, 6, 6, 6, 6, 5, 5, 5, 5], dtype=np.int64)


def _harmonic_class(size):
    """Return the harmonic class index for an item size (int)."""
    # class k is the smallest k such that size* (k+1) > 100  (i.e. size > 100/(k+1))
    k = 0
    while k < 29 and size * (k + 1) <= 100:
        k += 1
    return k


def priority(item, bins):
    """Rank bins: favorite the bin whose post-placement residual sits in the
    harmonic class matching the item's own harmonic class, then best fit."""
    remaining = (bins - item).astype(np.float64)

    # harmonic class of the arriving item
    k = _harmonic_class(int(item))
    # target residual band for class k: residuals in the same harmonic band
    # roughly [100/(k+2), 100/(k+1)] but we want residual to be fillable by a
    # subsequent item of this class, so favor small residuals that still match.
    # Compute per-bin harmonic class of the residual.
    res_int = np.maximum(bins - item, 0)

    # class of residual r: smallest j with r*(j+1) > 100
    cls = np.zeros_like(res_int)
    valid = res_int > 0
    tmp = res_int.copy()
    j = np.zeros_like(res_int)
    # vectorized harmonic class for residuals 0..100
    # class j covers (100/(j+1), 100/j]; use lookup
    lut = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        jj = 0
        while jj < 29 and r * (jj + 1) <= 100:
            jj += 1
        lut[r] = jj
    cls = lut[res_int]

    # best fit base (dominant): higher is tighter
    best_fit = -remaining

    # harmonic bonus: strongly prefer residuals classified in the SAME class as
    # the item, since such a residual is exactly the size class that future
    # items of this class will fit snugly.
    same_class = (cls == k) & valid
    bonus = np.where(same_class, 1.0, 0.0)

    # exact fit extra nudge
    exact = (remaining == 0)
    bonus = bonus + np.where(exact, 2.0, 0.0)

    return best_fit + 8.0 * bonus
# EVOLVE-BLOCK-END

