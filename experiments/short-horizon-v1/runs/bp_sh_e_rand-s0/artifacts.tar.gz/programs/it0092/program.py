# EVOLVE-BLOCK-START
"""Best fit with a fullness (age proxy) tie-breaker."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    # Primary signal: best fit (tightest remaining capacity wins).
    best_fit = -remaining.astype(np.float64)
    # Secondary signal: prefer already-fuller bins (age proxy) to concentrate packing.
    # Normalize fullness so it acts as a small tie-breaker, not overriding best fit.
    fullness = (100 - bins).astype(np.float64) / 100.0
    return best_fit + 0.5 * fullness
# EVOLVE-BLOCK-END

