# EVOLVE-BLOCK-START
"""Best fit with a smooth residual-utility penalty favoring reusable leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = (bins - item).astype(np.int64)
    # Base: best fit (prefer tightest fit).
    best_fit = -remaining.astype(np.float64)
    # Smooth penalty on small non-zero residuals: a residual of r wastes r capacity
    # until a future item fills it. Penalize monotonically more as r shrinks toward 0,
    # with peak penalty at r=1 and decaying for larger (more reusable) residuals.
    # exact fit (r==0) is best; use a piecewise linear/smooth shaping on r in [1,100].
    r = remaining
    # penalty 0 at r==0, rising as r->0 from above, tapering for large r
    # shape: pen(r) = (100 - r) / 100 for r>=1 scaled, giving strong push away from slivers
    pen = np.where(r > 0, (100.0 - r) / 100.0, 0.0)
    # emphasize the sliver region (r small) more strongly
    sliver = np.where((r > 0) & (r <= 10), (11.0 - r) / 10.0, 0.0)
    return best_fit - 3.0 * pen - 5.0 * sliver
# EVOLVE-BLOCK-END
