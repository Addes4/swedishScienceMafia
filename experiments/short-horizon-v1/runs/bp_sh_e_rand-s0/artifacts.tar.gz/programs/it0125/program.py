# EVOLVE-BLOCK-START
"""Harmonic-class best fit for online bin packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; item goes to highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities of fitting bins (bin order).
    """
    remaining = bins - item
    # Primary: best fit (tighter leftover is better).
    score = -remaining.astype(np.float64)
    # Penalize residuals that strand capacity too small for a reasonably
    # packable follow-up item, scaled by how small the sliver is.
    # A residual r is penalized most when it is tiny relative to the item size.
    sliver = np.where((remaining > 0) & (remaining < 0.5 * item), remaining, 0)
    score -= 3.0 * sliver
    return score
# EVOLVE-BLOCK-END
