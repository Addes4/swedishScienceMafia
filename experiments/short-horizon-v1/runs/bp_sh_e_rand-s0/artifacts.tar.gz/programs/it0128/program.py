# EVOLVE-BLOCK-START
"""Best fit with an item-scaled sliver penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining  # higher is tighter fit (smaller residual)
    # A leftover residual is "waste" if it is too small to hold another item of a
    # size comparable to the current one.  Scale the threshold with the item size,
    # with a small absolute floor, so plain best fit still dominates otherwise.
    threshold = max(2.0, 0.3 * item)
    waste = np.where((remaining > 0) & (remaining <= threshold), remaining, 0)
    return best_fit.astype(np.float64) - 2.0 * waste
# EVOLVE-BLOCK-END

