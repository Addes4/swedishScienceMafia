# EVOLVE-BLOCK-START
"""Harmonic-boundary best fit: guide residuals to reusable harmonic capacity classes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    remaining = (bins - item).astype(np.float64)

    # Base: tightest fit (best fit).
    score = -remaining

    # Reward residuals that sit exactly at or just above a harmonic boundary
    # 100/k, since a bin holding a residual R can absorb items up to R, and
    # residuals equal to 100/k correspond to the classic Harmonic class size.
    # We add small bonuses for residuals near 100/k for k = 1..12.
    r = np.maximum(remaining, 0.0)
    bonus = np.zeros_like(r)
    for k in range(1, 13):
        target = 100.0 / k
        # reward residuals just at/above target (so target-size items fit)
        near = np.exp(-np.abs(r - target) / 3.0)
        bonus = np.maximum(bonus, near)
    score = score + 1.5 * bonus

    # Penalize unusable tiny residuals (cannot fit a small future item well).
    tiny = np.where((remaining > 0) & (remaining <= 4), 1.0, 0.0)
    score = score - 1.0 * tiny

    return score
# EVOLVE-BLOCK-END
