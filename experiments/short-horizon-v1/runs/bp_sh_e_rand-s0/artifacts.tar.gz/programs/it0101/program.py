# EVOLVE-BLOCK-START
"""Best fit with a mild sliver penalty and an exact-fill bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit

    # Mild penalty for residuals that are too small to be usefully refilled.
    # Threshold scales with the item size so larger items tolerate larger slivers less.
    threshold = max(1, item // 4)
    sliver = np.where((remaining > 0) & (remaining <= threshold), remaining, 0)

    # Small bonus for exact fills to encourage closing bins cleanly.
    exact = np.where(remaining == 0, 1.0, 0.0)

    return best_fit - 1.5 * sliver.astype(np.float64) + 0.5 * exact
# EVOLVE-BLOCK-END
