# EVOLVE-BLOCK-START
"""Best fit with a smooth, graduated residual penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # post-placement residual, 0..99
    # Base: best fit -> tighter fits (smaller residual) preferred.
    best_fit = -remaining.astype(np.float64)
    # Graduated penalty for tiny residuals that are hard to reuse.
    # Smooth ramp: large penalty for residual 1, tapering to zero by ~20.
    small = np.clip(remaining, 0, None)
    tiny_penalty = np.where(small <= 20, (21.0 - small) ** 2, 0.0)
    # Mild bonus for large reusable residuals (close to a typical item ~40).
    reusable = np.where((small >= 35) & (small <= 60), 1.0, 0.0)
    return best_fit - 0.6 * tiny_penalty + 1.5 * reusable
# EVOLVE-BLOCK-END

