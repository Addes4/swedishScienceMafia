# EVOLVE-BLOCK-START
"""Best fit with a reusability bonus for residuals equal to the item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # post-placement residual, >= 0
    # Base: best fit (smaller residual is better).
    score = -remaining.astype(np.float64)
    # Bonus: residual exactly equals item size -> bin can later be filled perfectly
    # by a same-sized item, keeping space reusable.
    score += np.where(remaining == item, 5.0, 0.0)
    # Mild bonus: exact fill.
    score += np.where(remaining == 0, 2.0, 0.0)
    return score
# EVOLVE-BLOCK-END

