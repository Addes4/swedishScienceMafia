# EVOLVE-BLOCK-START
"""Harmonic-flavored best fit: concentrate items into the fullest fitting bin,
while mildly preferring bins whose leftover can still absorb same-class items."""
import numpy as np


def _harmonic_class(x):
    """Map a positive size to a harmonic-style class index (bigger x -> bigger class)."""
    # Classes based on 1/k thresholds: class k covers sizes in (100/(k+1), 100/k].
    # Smaller items -> finer classes; encode as a continuous monotone score.
    return 100.0 / x


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # post-placement residual, all >= 0

    # Dominant term: best fit (tighter residual preferred).
    best_fit = -remaining.astype(np.float64)

    # Secondary term: mild reward for residuals that can still absorb items of the
    # same harmonic class as the current item (residual close to or larger than item),
    # discouraging bins sealed with unusable slivers slightly below `item`.
    # Normalized, tiny weight so it never overrides the best-fit core.
    reusable = np.minimum(remaining, item).astype(np.float64) / 100.0
    return best_fit + 0.05 * reusable
# EVOLVE-BLOCK-END

