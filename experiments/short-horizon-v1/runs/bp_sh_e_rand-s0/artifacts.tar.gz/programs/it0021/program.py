# EVOLVE-BLOCK-START
"""Best fit with a smooth residual-quality tie-break.

Base ranking is best fit (fill the fullest bin that fits).  On top of that we add
a bounded, scale-invariant tie-break that slightly prefers placements leaving a
residual which is likely reusable: either essentially empty (a closed bin) or an
exact multiple/size-class boundary.  The tie-break is small enough that best fit
still dominates, but breaks near-ties toward bins that keep space reusable.
"""
import numpy as np

_CAP = 100.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    remaining = (bins - item).astype(np.float64)

    # Dominant signal: best fit (higher priority for tighter fit / fuller bin).
    best_fit = -remaining

    # Smooth residual-quality bonus, scale-invariant.
    # Fully filled bins (residual 0) are ideal: strongly preferred.
    # Otherwise reward residuals that sit at classic harmonic size-class
    # boundaries (fractions of capacity), which are reusable for future items.
    closed = (remaining <= 0).astype(np.float64)
    resid_frac = np.clip(remaining, 0.0, _CAP) / _CAP
    # Reward proximity to 0 and to harmonic boundaries 1/2, 1/3, 1/4, 1/5.
    bonus = 3.0 * closed
    for k in (2, 3, 4, 5):
        boundary = 1.0 / k
        prox = np.maximum(0.0, 1.0 - np.abs(resid_frac - boundary) * k)
        bonus = np.maximum(bonus, 1.5 * prox)
    # Reward residual exactly 0 via the closed term already; small positive
    # residual that fits no plausible item contributes nothing (left unpenalized
    # so pure best-fit ordering is preserved for those cases).

    return best_fit + bonus
# EVOLVE-BLOCK-END
