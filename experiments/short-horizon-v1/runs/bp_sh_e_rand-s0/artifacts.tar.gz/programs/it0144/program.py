# EVOLVE-BLOCK-START
"""Best-fit core with a smoothed small-residual waste penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit

    # Smoothed waste penalty: residuals from 0 up to ~19 are penalized with a
    # linear ramp (strongest at 0), rather than a hard cutoff. This avoids the
    # discontinuity at the threshold and gently discourages leaving capacity
    # too small to be reliably reused.
    threshold = 19.0
    ramp = np.clip((threshold - remaining) / threshold, 0.0, 1.0)
    # Only penalize positive residuals that fit (remaining >= 0); remaining<0
    # never appears since bins given all fit the item.
    penalty = np.where(remaining > 0, ramp, 0.0)
    return best_fit - 2.0 * penalty
# EVOLVE-BLOCK-END
