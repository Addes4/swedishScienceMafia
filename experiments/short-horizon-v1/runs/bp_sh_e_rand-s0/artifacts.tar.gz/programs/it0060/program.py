# EVOLVE-BLOCK-START
"""Adaptive best fit: concentrate items into the fullest fitting bin, penalizing
residuals too small to be reusable based on the observed item-size distribution."""
import numpy as np

# Module-level state, reset per stream by the harness.
_SIZE_STATS = {"count": 0, "size_counts": None}


def _reset_if_needed():
    if _SIZE_STATS["size_counts"] is None:
        _SIZE_STATS["size_counts"] = np.zeros(101, dtype=np.int64)
        _SIZE_STATS["count"] = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    _reset_if_needed()
    sc = _SIZE_STATS["size_counts"]
    sc[item] += 1
    _SIZE_STATS["count"] += 1
    n = _SIZE_STATS["count"]

    # Estimate the typical reusable residual: the (high) quantile of observed item
    # sizes. Small residuals below the common smallest items are essentially waste.
    # Use a smoothed estimate over observed sizes.
    if n >= 8:
        sizes = np.arange(1, 101)
        cdf = np.cumsum(sc[1:]) / n
        # A residual is "reusable" if it can hold a reasonably common item.
        # Use the 60th-percentile size as the threshold for usability.
        idx = np.searchsorted(cdf, 0.60)
        threshold = float(sizes[min(idx, 99)])
    else:
        threshold = 20.0

    remaining = (bins - item).astype(np.float64)
    best_fit = -remaining

    # Penalize residuals that are positive but below the usability threshold:
    # such leftover capacity is hard to ever use again.
    waste = np.where((remaining > 0) & (remaining < threshold), remaining, 0.0)

    # Slightly stronger, quadratic tightness term so very tight fits dominate.
    tight = np.where(remaining >= 0, -(remaining ** 2) * 0.01, 0.0)

    return best_fit - 2.0 * waste + tight
# EVOLVE-BLOCK-END
