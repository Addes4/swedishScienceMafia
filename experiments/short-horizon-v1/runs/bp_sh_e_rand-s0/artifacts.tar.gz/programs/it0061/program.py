# EVOLVE-BLOCK-START
"""Adaptive best-fit / reserving-reusable-space rule."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, but more strongly avoid creating residuals that
    cannot fit a typical future item (based on a running estimate of item size)."""
    # Running estimate of typical item size, stored on the function object.
    state = priority.__dict__
    if "count" not in state:
        state["count"] = 0
        state["sum"] = 0.0
    state["count"] += 1
    state["sum"] += float(item)
    mean = state["sum"] / state["count"]

    remaining = bins - item

    # Bins that fit and leave a residual big enough to still accept a typical item
    # are preferred (keeps capacity usable). Among those, prefer tighter fit.
    usable = remaining >= mean
    # Score: bin with usable residual gets a large bonus, then tightest fit wins.
    return usable.astype(np.float64) * 1e6 - remaining.astype(np.float64)
# EVOLVE-BLOCK-END
