# EVOLVE-BLOCK-START
"""Best fit with a learned penalty for unusable residuals."""
import numpy as np

_min_item = 0
_seen = 0


def priority(item, bins):
    """Rank bins: tightest fit first, penalizing residuals below the smallest seen item."""
    global _min_item, _seen
    if item < _min_item or _seen < 20:
        if _seen < 20 or item < _min_item:
            _min_item = item if _seen == 0 else min(_min_item, item)
    _seen += 1

    remaining = bins - item
    best_fit = -remaining.astype(np.float64)

    # Only residuals strictly smaller than the smallest item seen so far are truly
    # stranded (no future item can fill them). Penalize them mildly and linearly,
    # so the penalty only breaks near-ties rather than overriding fit tightness.
    m = _min_item if _min_item > 0 else 1
    unusable = np.clip(m - remaining, 0, None)
    return best_fit - 0.5 * unusable
# EVOLVE-BLOCK-END
