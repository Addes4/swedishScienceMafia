# EVOLVE-BLOCK-START
"""Best fit with a residual-reusability bonus: prefer tight fits, gently favor
leaving a leftover that matches a typical item size (reusable slot)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit

    # Base waste penalty: discourage tiny unusable leftovers.
    waste = np.where((remaining > 0) & (remaining <= 19), remaining, 0)
    score = best_fit - 2.0 * waste

    # Mild bonus when the residual is a plausible reusable slot size: a common
    # item size near the distribution's body (mean ~40, mass roughly 10..70).
    # This encourages leftovers that a future item can fit snugly.
    reusable = (remaining >= 10) & (remaining <= 60)
    score += np.where(reusable, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
