# EVOLVE-BLOCK-START
"""Best-fit core with a density/concentration reward to avoid opening fresh bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins.astype(np.float64)
    residual = rem - item

    # Best-fit core: tighter fit is better (smaller residual -> higher score).
    best_fit = -residual

    # Concentration reward: prefer bins that are already partly used, so we do not
    # spread items across fresh (capacity 100) bins. A fresh bin has rem == 100; the
    # more a bin is already filled, the larger this reward.
    used_frac = (100.0 - rem) / 100.0

    # Reuse reward for residuals that are too small to be "waste" is handled implicitly
    # by best_fit; keep the rule mostly best-fit and let concentration break ties.
    return best_fit + 0.5 * used_frac
# EVOLVE-BLOCK-END
