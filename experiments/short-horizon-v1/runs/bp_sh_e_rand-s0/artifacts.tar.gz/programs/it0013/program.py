# EVOLVE-BLOCK-START
"""Harmonic-flavored best fit with a learned residual-reusability tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit as the dominant ranking: higher means tighter fit.
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)

    # Penalize leaving small leftover residuals (hard-to-reuse capacity),
    # which concentrates packing into fewer, tighter bins.
    waste = np.where((remaining > 0) & (remaining <= 19), remaining, 0)
    score = best_fit - 2.0 * waste

    # Mild bonus when the post-placement residual matches a common observed item
    # size, so leftover space is likely to be reusable by a future item.
    hist = priority.hist
    if hist is not None:
        # residual is a valid index 0..100; weight by how often that size appears.
        res = np.clip(remaining, 0, 100).astype(np.int64)
        freq = hist[res] / priority.total if priority.total > 0 else 0.0
        score = score + 0.5 * freq

    # Update running histogram of item sizes.
    priority.hist[item] += 1
    priority.total += 1

    return score


priority.hist = np.zeros(101, dtype=np.float64)
priority.total = 0
# EVOLVE-BLOCK-END
