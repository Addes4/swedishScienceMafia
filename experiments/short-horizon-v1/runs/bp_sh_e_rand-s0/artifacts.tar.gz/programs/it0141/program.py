# EVOLVE-BLOCK-START
"""Best fit with tie-breaking toward residuals most likely reusable."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item.astype(np.int64)
    # Dominant term: best fit -- smaller residual is better.
    best_fit = -remaining.astype(np.float64)
    # Secondary term: among close fits, prefer the bin with a larger residual so we
    # don't create unusably tiny slivers; this is a mild tie-break that only matters
    # when best-fit differences are small.
    return best_fit + 0.01 * remaining
# EVOLVE-BLOCK-END

