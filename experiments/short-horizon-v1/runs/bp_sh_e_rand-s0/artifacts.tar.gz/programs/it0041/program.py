# EVOLVE-BLOCK-START
"""Best fit: place each item into the fullest bin that can still hold it."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer the bin that becomes fullest, i.e. smallest residual capacity.
    remaining = bins - item
    return (-remaining).astype(np.float64)
# EVOLVE-BLOCK-END

