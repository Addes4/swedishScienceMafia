# EVOLVE-BLOCK-START
"""Pure best fit: place the item into the fullest bin that still fits it."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    # Dominant term: best fit = smallest remaining capacity after placement
    # (equivalently maximize remaining capacity negated).
    best_fit = -remaining.astype(np.float64)
    # Infinitesimal tie-break: prefer a larger residual (slightly more reusable)
    # without ever overriding the dominant best-fit ordering.
    tie_break = remaining.astype(np.float64) * 1e-6
    return best_fit + tie_break
# EVOLVE-BLOCK-END
