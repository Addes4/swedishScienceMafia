# EVOLVE-BLOCK-START
"""Best fit with Harmonic class-boundary bias."""
import numpy as np


def priority(item, bins):
    remaining = bins - item  # residual after placing item here

    # Base: best fit (tighter post-placement bin is better).
    score = (-remaining).astype(np.float64)

    # Bonus for leaving residuals near harmonic class boundaries 100/k,
    # since those bins can efficiently absorb future items of matching size.
    # Boundaries: 100, 50, 34, 25, 20, 17, 15.
    for k in (2, 3, 4, 5, 6):
        target = 100.0 / k
        score -= 0.5 * np.exp(-((remaining - target) ** 2) / (2.0 * (3.0 ** 2)))

    # Penalize tiny nonzero residuals (1..6) that waste capacity, but don't
    # penalize exact fill (remaining == 0) which is ideal.
    waste = np.where((remaining > 0) & (remaining <= 6), remaining, 0)
    score -= 1.0 * waste

    return score
# EVOLVE-BLOCK-END
