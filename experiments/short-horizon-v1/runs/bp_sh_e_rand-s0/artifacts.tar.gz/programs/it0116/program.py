# EVOLVE-BLOCK-START
"""Best fit with an item-scaled residual-utility penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining  # higher is tighter fit
    # Penalize residuals that are too small to hold another item of similar size,
    # scaled by the current item size (more robust than a fixed threshold).
    threshold = max(1, item // 4)
    tiny = (remaining > 0) & (remaining < threshold)
    return best_fit.astype(np.float64) - 1.5 * tiny * remaining
# EVOLVE-BLOCK-END
