# EVOLVE-BLOCK-START
"""Best-fit with an exact-complement (residual == item) preference."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # post-placement residual, >= 0 for all shown bins
    # Primary: smallest post-placement residual (classic best fit).
    score = -remaining.astype(np.float64)
    # Secondary: strongly prefer a bin whose residual exactly equals the item size,
    # since a future item of this size can then fill it perfectly.
    score += np.where(remaining == item, 1.0, 0.0)
    return score
# EVOLVE-BLOCK-END
