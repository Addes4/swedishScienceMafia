# EVOLVE-BLOCK-START
"""Harmonic-flavored best fit: concentrate items into the fullest fitting bin."""
import numpy as np

# Module-level state (reset per stream by the harness importing fresh).
_min_item = 100.0
_count = 0


def priority(item, bins):
    """Rank bins; highest score wins, ties to first bin.

    Base is best fit (smallest post-placement residual). We add a soft penalty
    for leaving a residual that is too small to hold any item we've seen so far,
    which reduces stranded capacity without overriding the best-fit ranking.
    """
    global _min_item, _count
    _count += 1
    if item < _min_item:
        _min_item = float(item)

    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher = tighter fit

    # A residual is "dead space" only if it cannot hold the smallest item seen.
    # Penalize it, but with a weight below 1 so it never overturns a real gain
    # in tightness of more than one unit.
    dead = (remaining > 0) & (remaining < _min_item)
    return best_fit - 0.5 * dead.astype(np.float64)
# EVOLVE-BLOCK-END
