# EVOLVE-BLOCK-START
"""Best fit with a tight waste penalty for truly unusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit
    # Penalize only genuinely hard-to-reuse residuals (too small for typical items).
    waste = np.where((remaining > 0) & (remaining <= 5), remaining.astype(np.float64), 0.0)
    # Small bonus for exact fill.
    exact = np.where(remaining == 0, 1.0, 0.0)
    return best_fit - 3.0 * waste + exact
# EVOLVE-BLOCK-END

