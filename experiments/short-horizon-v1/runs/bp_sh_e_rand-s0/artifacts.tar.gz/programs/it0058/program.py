# EVOLVE-BLOCK-START
"""Best fit with a learned, distribution-aware residual-usage bonus."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.total = 0.0
        self.min_seen = 100


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    s = _state
    s.n += 1
    s.total += item
    if item < s.min_seen:
        s.min_seen = item

    mean = s.total / s.n if s.n > 0 else 40.0
    # Expected number of future average-sized items the residual can still hold.
    remaining = bins - item
    # Best fit: smaller residual -> higher score.
    best_fit = -remaining.astype(np.float64)

    # Bonus for residuals that can still hold at least one more typical item
    # (avoids sealing off usable medium residuals into useless slivers).
    usable = np.minimum(remaining / max(mean, 1.0), 2.0)
    # Small residuals below the smallest item seen are effectively dead space.
    dead = (remaining > 0) & (remaining < s.min_seen)
    return best_fit + 0.5 * usable - 5.0 * dead
# EVOLVE-BLOCK-END
