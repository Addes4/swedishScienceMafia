# EVOLVE-BLOCK-START
"""Best-fit with online-learned penalty on unusably small residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    remaining = bins - item
    # Track a rough scale of item sizes seen so far.
    _priority.mean_size = 0.98 * getattr(_priority, "mean_size", 40.0) + 0.02 * item
    resid = remaining.astype(np.float64)
    # Penalize residuals that are too small to be reliably reusable.
    thresh = 0.5 * _priority.mean_size
    penalty = np.where((resid > 0) & (resid < thresh), thresh - resid, 0.0)
    return -resid - 1.5 * penalty
# EVOLVE-BLOCK-END

