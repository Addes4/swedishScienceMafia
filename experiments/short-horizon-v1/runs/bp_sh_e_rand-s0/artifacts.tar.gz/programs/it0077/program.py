# EVOLVE-BLOCK-START
"""Best fit with a flat waste penalty and a consolidation tie-breaker."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit

    # Flat penalty for tiny unusable leftovers (the proven base shaping).
    waste = np.where((remaining > 0) & (remaining <= 19), remaining, 0)
    score = best_fit - 2.0 * waste

    # Consolidation tie-breaker: mildly reward a residual that matches another
    # currently-open bin's remaining capacity, so leftovers stay reusable.
    caps = np.unique(bins)
    rem_set = set(caps.tolist())
    match = np.fromiter((1.0 if r in rem_set else 0.0 for r in remaining.tolist()),
                        dtype=np.float64, count=remaining.shape[0])
    score = score + 0.5 * match

    return score
# EVOLVE-BLOCK-END
