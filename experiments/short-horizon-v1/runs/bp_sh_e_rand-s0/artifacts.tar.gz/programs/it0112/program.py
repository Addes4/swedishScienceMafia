# EVOLVE-BLOCK-START
"""Best fit refined by a residual-utility penalty: avoid leaving crumbs."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # >= 0 for all bins shown
    best_fit = -remaining  # higher is tighter fit

    # Penalize hard-to-reuse tiny leftovers; the penalty grows as the residual shrinks.
    # Residuals of 0 (exact fit) are ideal, so exempt them.
    small = (remaining > 0) & (remaining <= 19)
    waste_pen = np.where(small, (20 - remaining), 0)
    return best_fit.astype(np.float64) - 2.0 * waste_pen
# EVOLVE-BLOCK-END

