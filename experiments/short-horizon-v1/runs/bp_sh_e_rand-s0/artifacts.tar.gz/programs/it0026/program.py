# EVOLVE-BLOCK-START
"""Best-fit with a distribution-calibrated penalty on tiny dead-space residuals."""
import numpy as np


class _State:
    def __init__(self):
        self.done = 0
        self.sum_sq = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities (item fits everywhere shown).
    """
    # Track a robustness statistic of past items (incremental sum of squares via mean tracking).
    s = _state
    s.done += 1
    s.sum_sq += float(item) * float(item)
    # RMS of past items as a scale estimate for "typical item size".
    rms = (s.sum_sq / s.done) ** 0.5 if s.done > 0 else 40.0
    # Typical small-item scale; floor to keep it stable early in a stream.
    scale = max(8.0, 0.35 * rms)

    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # tighter fit -> higher

    # Penalize tiny positive residuals (dead space) smoothly; zero residual is ideal.
    small = np.maximum(0.0, 1.0 - remaining.astype(np.float64) / scale)
    tiny_penalty = np.where(remaining > 0, small * remaining.astype(np.float64), 0.0)

    return best_fit - 1.5 * tiny_penalty
# EVOLVE-BLOCK-END

