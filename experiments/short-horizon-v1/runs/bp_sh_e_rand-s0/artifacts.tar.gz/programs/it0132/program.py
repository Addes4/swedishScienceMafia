# EVOLVE-BLOCK-START
"""Harmonic-relative best fit: prefer tight fits whose residual matches the item's scale."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # post-placement residual, may be 0 (bin becomes exactly full)

    # Base: tightest fit first (smallest residual).
    best_fit = -remaining.astype(np.float64)

    # Harmonic-relative bonus: a residual is "good" when it is small relative to the
    # current item scale, so leftover space is a small fraction of a typical future item.
    # Score residuals that fall below a fraction of the item size as near-perfect.
    scale = float(item) if item > 0 else 1.0
    frac = remaining.astype(np.float64) / scale  # residual in units of current item
    # Reward fractional residuals in [0, 1): these leftovers are smaller than the incoming
    # item, meaning the bin was packed efficiently without leaving a large reusable hole.
    small = np.where((frac < 1.0) & (remaining >= 0), 1.0 - frac, 0.0)

    return best_fit + 3.0 * small
# EVOLVE-BLOCK-END

