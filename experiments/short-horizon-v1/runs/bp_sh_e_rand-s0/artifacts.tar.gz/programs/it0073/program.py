# EVOLVE-BLOCK-START
"""Best fit with a bonus for residuals that match common future item sizes."""
import numpy as np


class _State:
    def __init__(self):
        # histogram over item sizes 1..100 (index 0 unused)
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0

    def observe(self, item):
        self.hist[item] += 1.0
        self.count += 1.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state

    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit (smaller residual)

    # Probability mass of past items at each residual value (smoothed count of "reusable slots").
    if st.count > 0.0:
        probs = st.hist / st.count  # normalized frequency of each item size
    else:
        probs = st.hist  # all zero before first observation

    # For each bin, look up the frequency of the post-placement residual (clipped to range).
    resid = np.clip(remaining, 0, 100).astype(np.int64)
    slot_bonus = probs[resid]  # how often a future item exactly equals this residual

    # Base best-fit plus a modest bonus for residuals equal to common item sizes.
    score = best_fit + 30.0 * slot_bonus

    # Record the arriving item after scoring (it is a past item for future calls).
    st.observe(item)

    return score
# EVOLVE-BLOCK-END
