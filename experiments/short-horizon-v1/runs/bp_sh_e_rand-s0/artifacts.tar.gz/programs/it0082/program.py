# EVOLVE-BLOCK-START
"""Best fit with a harmonic-class consolidation bonus.

The classic best-fit rule (place the item in the fullest bin that still fits) is a
strong online rule for this distribution. Pure best-fit, however, wastes capacity:
it happily leaves a residual that is too small to hold any future item. The Harmonic
family of online algorithms avoids this by grouping bins into capacity classes and
only allowing items of a matching size band into a class.

We keep best-fit as the dominant ranking and add a light harmonic-class bonus: after
placing the item, we look at the residual r. If r sits just below a harmonic threshold
100/k (i.e. placing the item there moves the bin into a clean capacity class), we give
a small bonus, encouraging items to consolidate into bins that will remain useful.
"""
import numpy as np

# harmonic class boundaries: residual r is "good" when it is close to 100/k
_K = np.array([2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 16, 20, 25, 34], dtype=np.float64)
_THRESH = 100.0 / _K  # descending thresholds


def priority(item, bins):
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher = tighter fit

    # Harmonic-class bonus: reward residuals that land near a class threshold 100/k,
    # and mildly penalize tiny non-zero residuals that are hard to reuse.
    bonus = np.zeros_like(best_fit)

    # exact fill is always good
    bonus += np.where(remaining == 0, 1.0, 0.0)

    # proximity to a harmonic threshold (only meaningful for positive residuals)
    pos = remaining > 0
    if np.any(pos):
        r = remaining[pos].astype(np.float64)
        # distance to the nearest threshold
        d = np.min(np.abs(r[:, None] - _THRESH[None, :]), axis=1)
        # small bonus when very close to a class boundary (say within 2 units)
        bonus[pos] += np.where(d <= 2.0, 0.6, 0.0)

    # penalize leaving a tiny unusable residual (1..4)
    bonus -= np.where((remaining > 0) & (remaining <= 4), 0.3, 0.0)

    return best_fit + bonus
# EVOLVE-BLOCK-END

