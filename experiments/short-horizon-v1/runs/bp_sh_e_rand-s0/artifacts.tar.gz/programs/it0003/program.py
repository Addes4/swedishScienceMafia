# EVOLVE-BLOCK-START
"""Best-fit with waste-avoiding redirection.

Idea: classic best fit tends to leave many small residuals spread across bins when
a small item lands in a nearly-empty bin at the end. We restrict the choice to bins
that stay "reasonably full" after placing the item (residual below a threshold),
and among those pick the tightest fit. If no such bin exists, we fall back to
pure best fit (tightest residual overall), which keeps the single-bin case exact.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item (all >= 0)
    # Threshold: don't create residual larger than this when a fuller option exists.
    # Scale with item size so small items still allow reasonably tight placements.
    threshold = max(10.0, 0.5 * item)
    good = residual <= threshold
    # Score: tightest fit (lower residual -> higher score) among "good" bins.
    # Bad bins get a large penalty so any good bin outranks them.
    score = -residual.astype(np.float64)
    penalty = residual.max() + 1.0
    score = np.where(good, score, score - penalty)
    return score
# EVOLVE-BLOCK-END
