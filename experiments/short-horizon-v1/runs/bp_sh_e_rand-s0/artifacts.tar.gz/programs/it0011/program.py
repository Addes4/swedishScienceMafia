# EVOLVE-BLOCK-START
"""Best-fit with a learned residual-reusability bonus.

Items are packed via classical best fit (tighter bin first). On top of that we keep a
running histogram of seen item sizes and add a small bonus whenever the residual left in a
bin is a size that future items are likely to need (i.e. a frequent observed size), so the
leftover capacity is more likely to be reusable rather than stranded.
"""
import numpy as np


class _State:
    def __init__(self):
        # running histogram of item sizes 1..100
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    remaining = bins - item
    # Dominant term: best fit (prefer tighter bins).
    score = -remaining.astype(np.float64)

    # Update the running histogram with the current item (ignored for ranking this call).
    _state.hist[item] += 1.0
    _state.count += 1.0

    # Residual-reusability bonus: a residual that is a common observed size is valuable.
    if _state.count > 0:
        freq = _state.hist / _state.count
        # normalized frequency in [0,1]; weight kept small so best-fit stays dominant
        bonus = np.where(remaining > 0, freq[np.clip(remaining, 0, 100)], 0.0)
        score = score + 0.5 * bonus

    return score
# EVOLVE-BLOCK-END
