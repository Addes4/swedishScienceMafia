# EVOLVE-BLOCK-START
"""Best-fit with a fragmentation-aware tie-breaker for online bin packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    # Dominant term: best fit (tightest fit = smallest residual).
    best_fit = -remaining.astype(np.float64)
    # Tiny tie-breaker: among equally good fits, prefer the bin that keeps the most
    # free capacity in absolute terms is wrong; instead prefer the tighter residual,
    # so use a secondary penalty proportional to the residual to break near-ties
    # toward the fullest remaining bin without overriding distinct best fits.
    tie_break = -0.001 * remaining.astype(np.float64)
    return best_fit + tie_break
# EVOLVE-BLOCK-END

