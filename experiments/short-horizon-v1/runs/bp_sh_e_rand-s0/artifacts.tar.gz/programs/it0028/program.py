# EVOLVE-BLOCK-START
"""Harmonic-flavored best fit: concentrate items into the fullest fitting bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # residual after placing the item
    best_fit = -remaining     # higher is tighter fit

    # Harmonic-class tie-break: prefer residuals that leave a small leftover
    # (< ~1/2 of the largest class threshold) since those are easier to fill.
    waste = np.where((remaining > 0) & (remaining <= 19), remaining, 0)
    score = best_fit.astype(np.float64) - 2.0 * waste

    # Slight extra reward for exactly filling a bin (zero residual).
    score = score + 0.5 * (remaining == 0)

    return score
# EVOLVE-BLOCK-END

