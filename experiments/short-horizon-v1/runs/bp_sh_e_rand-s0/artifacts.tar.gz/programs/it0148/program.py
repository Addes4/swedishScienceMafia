# EVOLVE-BLOCK-START
"""Best fit with flexibility tie-break for online bin packing."""
import numpy as np


def priority(item, bins):
    """Rank bins for the arriving item; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin (bin order).
    """
    remaining = bins.astype(np.float64) - item  # post-placement residual
    # Dominant term: prefer the tightest fit (smallest residual).
    score = -remaining
    # Secondary: among candidates, keep flexibility by favoring emptier bins
    # (larger pre-placement capacity) — a tiny nudge that only matters on ties/near-ties.
    score += 1e-3 * bins.astype(np.float64)
    # Small bonus for near-exact fits, which reduce wasted slivers.
    score += np.where(remaining == 0, 1e-2, 0.0)
    return score
# EVOLVE-BLOCK-END
