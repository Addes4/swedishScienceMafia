# EVOLVE-BLOCK-START
"""Adaptive best fit: concentrate packing, penalize unusable residuals sized from the
running item distribution rather than a fixed threshold."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Track a running estimate of the item-size scale (mean) across the stream.
    state = priority.state
    if state is None:
        state = {"n": 0.0, "mean": 40.0}
        priority.state = state
    n = state["n"]
    state["mean"] = (state["mean"] * n + item) / (n + 1.0)
    state["n"] = n + 1.0

    # A residual that cannot hold even a small item (say ~0.4 * running mean) is waste.
    thr = max(4.0, 0.4 * state["mean"])

    remaining = bins - item
    best_fit = -remaining.astype(np.float64)          # tighter fit is better
    # Penalize residuals in (0, thr): capacity too small to be easily reused.
    waste = np.where((remaining > 0) & (remaining <= thr), remaining, 0.0)
    # Mild bonus for fuller bins (concentration) to reduce bin count.
    fullness = (100.0 - bins) / 100.0
    return best_fit - 2.0 * waste + 0.5 * fullness


priority.state = None
# EVOLVE-BLOCK-END
