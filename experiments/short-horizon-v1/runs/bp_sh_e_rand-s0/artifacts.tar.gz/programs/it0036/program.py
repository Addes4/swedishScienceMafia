# EVOLVE-BLOCK-START
"""Best fit biased by a live estimate of future-item usefulness of each residual."""
import numpy as np


# Empirical size histogram, shared across calls within a stream (reset via lazy init).
_HIST = None
_TOTAL = 0
_SIZE = 101


def _accumulate(item):
    global _HIST, _TOTAL
    if _HIST is None:
        _HIST = np.zeros(_SIZE, dtype=np.float64)
        _TOTAL = 0
    _HIST[item] += 1.0
    _TOTAL += 1


def priority(item, bins):
    """Rank bins; item goes to highest score (first on ties).

    item: integer size, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in
          (includes unused bins with remaining 100), in bin order.
    """
    _accumulate(item)

    remaining = bins - item  # residual after placing here, >= 0

    # Base: best fit (smaller residual = better).
    score = -remaining.astype(np.float64)

    # Estimate, for each residual r, the fraction of future items that could fit
    # in a bin with that residual.  Small residuals with no matching items are
    # pure waste.
    if _TOTAL >= 8 and _HIST is not None:
        # Cumulative mass of item sizes <= r, i.e. prob a future item fits.
        cum = np.cumsum(_HIST) / _TOTAL  # cum[k] = P(size <= k)
        # For each bin residual r, look up P(future item fits) = cum[r] (r<=100).
        r_clip = np.clip(remaining, 0, 100).astype(np.int64)
        fits_prob = cum[r_clip]
        # Reward residuals that can still absorb likely items; penalize dead space.
        # dead space: small residual unlikely to ever be filled.
        dead = (1.0 - fits_prob)
        # Weight: prefer concentrating (best fit already does) but avoid pure waste.
        score = score + 6.0 * fits_prob - 3.0 * dead * (remaining > 0)
        # extra nudge: zero residual is ideal (perfectly filled bin)
        score = np.where(remaining == 0, score + 12.0, score)
    else:
        # Fallback early in stream: mild waste penalty like before.
        waste = np.where((remaining > 0) & (remaining <= 19), remaining, 0)
        score = score - 2.0 * waste

    return score
# EVOLVE-BLOCK-END
