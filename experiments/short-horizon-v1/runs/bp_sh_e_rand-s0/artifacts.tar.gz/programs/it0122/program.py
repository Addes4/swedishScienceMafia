# EVOLVE-BLOCK-START
"""Best fit with a learned, distribution-shaped residual penalty.

The core ranking is best fit (minimize resulting residual).  Any fixed penalty
on "wasted" residuals tends to plateau.  Instead we learn, online, the typical
item sizes seen so far and penalize a residual r proportionally to how likely
it is that *no* typical future item can reuse it well -- i.e. residuals that are
small relative to the observed size distribution are stranded capacity.
"""
import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.small_hist = np.zeros(101, dtype=np.float64)  # counts of items by size 1..100

    def observe(self, item):
        self.count += 1
        self.total += item
        self.small_hist[item] += 1.0


_state = _State()


def priority(item, bins):
    st = _state
    st.observe(item)

    remaining = (bins - item).astype(np.float64)  # post-placement residual, >= 0

    # Best-fit core: tighter fit (smaller residual, but >0 preferred over ==0
    # only mildly) => higher score.  Use negative residual.
    best_fit = -remaining

    # Learned scale: fraction of observed items that are <= a given residual.
    n = max(st.count, 1)
    cum = np.cumsum(st.small_hist) / n  # cum[r] = P(item <= r)

    # A residual r is "waste" if few future items fit into it.  If r==0 that is
    # actually a perfectly closed bin -> reward it, not penalize.
    # stranded[r] ~ probability that a random future item does NOT fit (size > r).
    stranded = 1.0 - cum  # P(item > r), r in 0..100

    # Penalty grows with stranded probability but vanishes for r==0 (perfectly
    # full bin) and for large r (easily reusable).
    r_int = np.clip(remaining.astype(np.int64), 0, 100)
    pen = np.where(remaining > 0, stranded[r_int], 0.0)

    return best_fit - 8.0 * pen
# EVOLVE-BLOCK-END
