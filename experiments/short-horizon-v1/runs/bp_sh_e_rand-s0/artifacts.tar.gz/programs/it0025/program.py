# EVOLVE-BLOCK-START
"""Harmonic-style best fit: rank by tightest harmonic class, tie-break best fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, first on ties.

    Harmonic bin-packing idea: an item of size s is "class-j" where
    1/(j+1) < s/100 <= 1/j. Bins whose residual falls in (100/(j+1), 100/j]
    are the tight targets for that class. We bias ranking toward those bins
    while keeping best-fit as the tie-break / fallback.
    """
    res = bins.astype(np.float64) - float(item)

    # Determine harmonic class j of the item: smallest j>=1 with item >= 100/j.
    # i.e. j = ceil(100 / item), clamped.
    if item <= 0:
        j = 0
    else:
        j = (100 + item - 1) // item  # ceil(100/item)

    # Window boundaries for the class: (100/(j+1), 100/j].
    lo = 100.0 / (j + 1)
    hi = 100.0 / j

    # Bins whose post-placement residual lies in the tight class window get a bonus.
    in_window = (res > lo) & (res <= hi + 1e-9)

    # Base: best fit (tighter residual = higher score).
    score = -res
    # Strong bonus for landing in the harmonic window so class targets dominate.
    score = score + 1e4 * in_window.astype(np.float64)
    # Slight bonus for exact fills (residual 0) as well.
    score = score + 1e4 * (res == 0)

    return score
# EVOLVE-BLOCK-END
