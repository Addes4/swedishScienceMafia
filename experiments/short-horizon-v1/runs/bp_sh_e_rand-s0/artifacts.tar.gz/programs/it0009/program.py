# EVOLVE-BLOCK-START
"""Best fit with a residual-waste penalty to avoid leaving tiny unusable gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Base ranking: best fit (tightest residual gets the highest score).
    remaining = bins - item
    best_fit = -remaining  # higher is tighter fit

    # Penalize leaving a small residual that is hard to reuse, since future items
    # have mean size ~40 and rarely fit into tiny leftovers. Residuals below half
    # the mean item size are treated as wasted capacity.
    waste = np.where((remaining > 0) & (remaining <= 20), remaining, 0)
    return best_fit.astype(np.float64) - 2.0 * waste
# EVOLVE-BLOCK-END
