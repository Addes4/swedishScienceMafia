# EVOLVE-BLOCK-START
"""Harmonic-flavored best fit with a fragment-aware residual penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item

    # Dominant term: prefer the tightest fit (smallest post-placement residual).
    best_fit = -remaining.astype(np.float64)

    # Value residual relative to the item: a residual much smaller than the item is
    # likely wasted capacity, penalize it; a healthy residual that could fit another
    # typical item is mildly rewarded.
    small = (remaining > 0) & (remaining * 2 < item)
    waste = np.where(small, remaining.astype(np.float64), 0.0)

    return best_fit - 1.0 * waste
# EVOLVE-BLOCK-END
