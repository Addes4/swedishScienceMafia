# EVOLVE-BLOCK-START
"""Best fit with a learned small-residual waste penalty."""
import numpy as np

_state = {"lo": None}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Track a running low estimate of item sizes to know which small residuals are
    # effectively unusable (can't hold a typical future item).
    lo = _state.get("lo")
    if lo is None:
        lo = item
    else:
        # Exponentially weighted low quantile estimate.
        if item < lo:
            lo = 0.7 * lo + 0.3 * item
        else:
            lo = 0.999 * lo + 0.001 * item
    _state["lo"] = lo

    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit

    # Penalize residuals too small to plausibly hold a future item; use a threshold
    # based on the learned lower scale of item sizes (with a small absolute floor).
    threshold = max(2.0, 0.5 * lo)
    waste = np.where((remaining > 0) & (remaining < threshold), remaining, 0)
    return best_fit - 2.0 * waste
# EVOLVE-BLOCK-END

