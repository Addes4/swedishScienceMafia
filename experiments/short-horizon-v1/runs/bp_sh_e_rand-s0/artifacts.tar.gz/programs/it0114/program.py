# EVOLVE-BLOCK-START
"""Adaptive Best-Fit: concentrate items, penalize residuals too small to reuse."""
import numpy as np


def priority(item, bins):
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)
    # Penalize small residuals smoothly: residuals below a reuse threshold are waste.
    # Threshold tied to item size (residuals under the item block same-or-larger items).
    thr = max(8.0, 0.5 * item)
    # Only penalize residuals that are > 0 (still some room) but small.
    small = np.clip(thr - remaining, 0, None)
    small = np.where(remaining > 0, small, 0.0)
    return best_fit - 2.0 * small
# EVOLVE-BLOCK-END

