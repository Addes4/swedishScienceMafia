# EVOLVE-BLOCK-START
"""Best fit with a learned residual-reuse bonus.

Items are i.i.d. from a fixed (Weibull-shaped, mean ~40) distribution.  Pure best
fit tends to leave tiny residuals that can never be reused.  We keep best fit as
the dominant term but add a small bonus for a post-placement residual that is
likely to be filled *tightly* by some future item, using a running histogram of
the item sizes seen so far in this stream.  A residual r is good if the most
likely next item fits into it with little waste, i.e. r is close to a common
item size (or a small integer multiple of one).
"""
import numpy as np

# 101 possible item sizes (1..100); index 0 unused.
_HIST = np.zeros(101, dtype=np.float64)
_N = 0.0


def priority(item, bins):
    global _HIST, _N

    # Update the running item-size histogram (state persists within a stream).
    _HIST[item] += 1.0
    _N += 1.0

    remaining = bins - item          # capacity left after placing the item (>=0)

    # --- dominant term: tightest fit (Best Fit) ---------------------------
    best_fit = -remaining.astype(np.float64)

    # --- small bonus: residual r is reusable by a likely future item ------
    # Expected leftover if we drop the best-fitting future item into residual r.
    # For each r we want the smallest expected waste over the next item.
    # Build a reusable-value lookup lazily: for each candidate residual compute
    # min over item sizes s<=r of (r - s) weighted toward likely sizes.
    # Cheap approximation: reward residuals close to a currently common size.
    if _N > 5:
        probs = _HIST / _N
        # common sizes (prob above small threshold), weighted by probability
        sizes = np.nonzero(probs * 100.0 >= 1.0)[0]  # sizes >= ~1% frequency
        pw = probs[sizes]
    else:
        sizes = None

    n = remaining.shape[0]
    bonus = np.zeros(n, dtype=np.float64)
    if sizes is not None and sizes.size:
        # For each bin, find the smallest leftover (r - s) over common sizes s<=r.
        # reward = probability mass of sizes that fit tightly.
        r = remaining
        # matrix too big (n up to ~5000, sizes up to ~100): loop over sizes.
        # For each common size s, bins with r>=s and small (r-s) get reward.
        for s, p in zip(sizes, pw):
            fits = r >= s
            gap = r - s
            # tightness weight: 1 when exact, decaying for larger gaps
            w = np.where(fits, p * np.exp(-gap / 8.0), 0.0)
            bonus = np.maximum(bonus, w)

    return best_fit + 6.0 * bonus
# EVOLVE-BLOCK-END
