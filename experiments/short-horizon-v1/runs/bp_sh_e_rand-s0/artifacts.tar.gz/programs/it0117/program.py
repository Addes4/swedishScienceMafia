# EVOLVE-BLOCK-START
"""Best fit with an item-scaled penalty on hard-to-reuse small residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining  # higher is tighter fit

    # Residuals that are strictly smaller than the arriving item cannot hold a
    # same-sized item again and tend to be stranded; penalize them, scaled by
    # how small they are relative to the item.
    # Residuals just above the item are mildly good (still reusable).
    r = remaining.astype(np.float64)
    it = float(item)

    # Penalty for tiny leftovers: strongest near 0, fading out at the item size.
    small_pen = np.where((r > 0) & (r < it), (it - r) / it, 0.0)

    # Mild reward for residuals in [item, 2*item) relative to the fit tightness.
    reuse_bonus = np.where((r >= it) & (r < 2.0 * it) & (bins == 100), 0.0, 0.0)

    return (best_fit - 2.0 * small_pen + reuse_bonus).astype(np.float64)
# EVOLVE-BLOCK-END

