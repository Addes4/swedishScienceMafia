# EVOLVE-BLOCK-START
"""Best fit with a learned residual-reusability bonus.

Core idea: classic best-fit (prefer the fullest fitting bin) minimizes wasted
capacity on average. But placing an item always leaves a residual; a residual is
"good" only if future items can actually use it. We learn a running histogram of
the item-size distribution seen so far and reward bins whose post-placement
residual matches a size class that future items are likely to demand. This keeps
the concentration power of best-fit while avoiding residuals in size ranges that
future items will rarely fit into.
"""
import numpy as np

# Running histogram of observed item sizes (1..100). Persists across calls
# within a stream; a fresh module import resets it.
_SIZE_HIST = np.zeros(101, dtype=np.float64)
_N_OBS = 0
_MAX_RESIDUAL = 100


def priority(item, bins):
    """Rank bins for the arriving item; highest score wins (first on ties)."""
    global _N_OBS

    # Update learned distribution of item sizes.
    if 1 <= item <= 100:
        _SIZE_HIST[item] += 1.0
    _N_OBS += 1

    remaining = bins - item
    # Best-fit core: higher (less negative) for tighter fits.
    best_fit = -remaining.astype(np.float64)

    # Probability mass for each residual value: how likely a future item is to
    # exactly (or nearly) fit into the leftover capacity. Use the histogram of
    # item sizes seen so far as a proxy for the future distribution.
    # Normalize to a probability vector.
    total = _SIZE_HIST.sum()
    if total > 0:
        probs = _SIZE_HIST / total
    else:
        probs = np.ones(101) / 101.0

    # For a residual r (0..100), usable capacity that fits at least one more
    # item is captured by the cumulative mass of sizes <= r. Bins whose
    # residual still admits many possible future item sizes are preferred.
    cum = np.cumsum(probs)  # cum[r] = P(future size <= r)
    cum = np.clip(cum, 0.0, 1.0)

    clipped = np.clip(remaining, 0, _MAX_RESIDUAL)
    reusability = cum[clipped]  # in [0, 1]

    # Residual == 0 (perfect fill) is best; residual that still fits likely
    # future items is good; residual too small to fit a probable item is waste.
    return best_fit + reusability
# EVOLVE-BLOCK-END
