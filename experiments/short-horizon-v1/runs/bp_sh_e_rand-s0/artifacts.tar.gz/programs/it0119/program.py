# EVOLVE-BLOCK-START
"""Best fit with an online-adaptive penalty for stranding small residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins: best fit first, penalizing residuals too small to reuse well.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)

    # Track observed item sizes online to estimate the distribution's low end.
    state = priority.__dict__
    n = state.get("n", 0)
    s = state.get("s", 0.0)
    n += 1
    s += item
    state["n"] = n
    state["s"] = s
    mean = s / n

    # Threshold below which leftover capacity is hard to reuse: a fraction of mean.
    thresh = 0.45 * mean

    # Penalize residuals smaller than the threshold, scaled smoothly, but only
    # for bins that would still hold leftover unusable space.
    resid = remaining.astype(np.float64)
    pen = np.where((resid > 0) & (resid < thresh), thresh - resid, 0.0)

    return best_fit - 1.8 * pen
# EVOLVE-BLOCK-END
