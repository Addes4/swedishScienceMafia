# EVOLVE-BLOCK-START
"""Harmonic-flavored best fit: concentrate items into the fullest fitting bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Post-placement remaining capacity.
    remaining = (bins - item).astype(np.float64)

    # Harmonic-style value: 1/(r+1) rewards tight fits but is concave, so it does not
    # over-penalize leaving a moderately large residual in a nearly-new bin.
    hv = 1.0 / (remaining + 1.0)

    # Best-fit term (dominant): tighter fit => higher score.
    best_fit = -remaining

    # Blend: harmonic value provides a gentle tie-break toward full bins.
    return best_fit + 0.5 * hv
# EVOLVE-BLOCK-END
