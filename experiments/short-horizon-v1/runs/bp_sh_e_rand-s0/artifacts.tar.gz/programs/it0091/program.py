# EVOLVE-BLOCK-START
"""Best fit with a graduated small-residual waste penalty and exact-fit bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item            # residual after placing the item
    best_fit = -remaining.astype(np.float64)   # higher is a tighter fit

    # A near-zero residual is nearly pure waste: the bin can no longer hold
    # most items, yet contributes nothing useful. Graduated penalty that is
    # strongest for the smallest non-zero residuals.
    waste = np.where(remaining > 0, np.maximum(0.0, 20.0 - remaining), 0.0)

    # Exact fill closes a bin perfectly.
    exact = (remaining == 0).astype(np.float64)

    return best_fit - 2.0 * waste + 50.0 * exact
# EVOLVE-BLOCK-END
