# EVOLVE-BLOCK-START
"""Best fit with a sharp sliver penalty for stranded tiny residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit core: prefer the bin that is tightest after placing the item.
    remaining = bins - item
    best_fit = -remaining  # higher is tighter fit

    # Sharpen around tiny residuals: a leftover of a few units is nearly unusable,
    # so penalize it strongly. The penalty decays quickly and is gone well before
    # the residual reaches a typical item size, leaving the best-fit ordering intact.
    r = remaining.astype(np.float64)
    # Strong, smooth penalty on stranded slivers (r small but > 0).
    sliver = np.where(r > 0, 1.0 / (r + 1.0), 0.0)
    # Overfull/perfect placements (r == 0) should be best; no penalty there.
    sliver = np.where(r == 0, 0.0, sliver)
    return best_fit.astype(np.float64) - 3.0 * sliver
# EVOLVE-BLOCK-END
