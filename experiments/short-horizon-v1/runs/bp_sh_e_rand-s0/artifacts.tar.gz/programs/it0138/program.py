# EVOLVE-BLOCK-START
"""Best-fit core with an item-scaled penalty on unusably small residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit

    # A residual is wasted capacity if it is too small to hold a likely future item.
    # Small items are common (Weibull-shaped), and typical small items are a few units.
    # Scale the "waste" threshold mildly with the item so larger items leave slightly
    # larger acceptable residuals; cap so we never reward opening wastefully empty bins.
    threshold = 6.0 + 0.25 * item
    threshold = min(threshold, 25.0)
    # Smooth penalty that peaks for tiny residuals and fades to zero at the threshold.
    waste = np.clip(threshold - remaining, 0.0, None)
    waste = np.where(remaining < threshold, waste, 0.0)

    return best_fit - 1.5 * waste
# EVOLVE-BLOCK-END
