# EVOLVE-BLOCK-START
"""Harmonic-flavored best fit: concentrate items into the fullest fitting bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    r = remaining.astype(np.float64)

    # Base: best fit (fuller bin after placement -> higher score).
    score = -r

    # Waste penalty: convex pressure that grows sharply as residual gets small,
    # making tiny leftovers unattractive. Unused bins (residual == 100) untouched.
    waste = np.where((r > 0) & (r <= 19), (20.0 - r), 0.0)
    score = score - 0.35 * waste * waste

    # Slight bonus for perfectly filling the bin.
    score = score + np.where(r == 0, 5.0, 0.0)

    return score
# EVOLVE-BLOCK-END
