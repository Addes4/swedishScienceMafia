# EVOLVE-BLOCK-START
"""Best fit with an adaptive dead-zone penalty on unreusable residuals."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Running estimate of the mean item size (used only to shape the penalty scale).
    _state.n += 1
    _state.mean += (item - _state.mean) / _state.n

    remaining = bins - item
    # Dominant term: best fit => prefer smallest post-placement residual.
    score = -remaining.astype(np.float64)

    # Dead zone: residuals that are small in absolute terms but still positive are
    # hard to reuse later, so slightly penalize them.  Scale the zone with the
    # running mean so it adapts to the distribution rather than a fixed 19.
    zone = max(4.0, 0.45 * _state.mean)
    dead = (remaining > 0) & (remaining <= zone)
    score -= np.where(dead, 1.0 + 0.05 * remaining, 0.0)

    return score
# EVOLVE-BLOCK-END

