# EVOLVE-BLOCK-START
"""Best-fit with item-scaled residual shaping: concentrate packing but avoid unusable leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = (bins - item).astype(np.float64)
    best_fit = -remaining  # tighter fit -> higher score

    # Residuals that are too small to hold another item of similar size are near-waste.
    # Scale threshold to the current item: a leftover under half the item size is unlikely
    # to be reusable by comparable future items, so penalize it (softly), strongest when
    # the leftover is near zero.
    small = item * 0.5
    # Smooth penalty that increases as residual shrinks below `small`, zero otherwise.
    frac = np.clip(1.0 - remaining / small, 0.0, 1.0)
    penalty = 2.0 * frac * frac

    # Mild reward for residuals that can still fit a typical small item (>= 10), helping
    # reuse capacity without hurting the concentration bias.
    reward = np.where(remaining >= 10.0, 0.25, 0.0)

    return best_fit - penalty + reward
# EVOLVE-BLOCK-END
