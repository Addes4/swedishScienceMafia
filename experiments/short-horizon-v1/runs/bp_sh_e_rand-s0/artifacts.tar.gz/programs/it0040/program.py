# EVOLVE-BLOCK-START
"""Best fit with a data-driven lower bound on useful residual capacity."""
import numpy as np

_state = {"min_seen": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Track the smallest item size seen so far as an estimate of the smallest
    # residual that a future item can still usefully fill.
    if item < _state["min_seen"]:
        _state["min_seen"] = item
    min_useful = _state["min_seen"]

    remaining = bins - item
    # Base ranking: tighter fit (smaller residual) is better.
    score = -remaining.astype(np.float64)

    # A positive residual below `min_useful` is dead space: no future item can
    # ever fill it. Strongly push such placements to the back.
    stranded = (remaining > 0) & (remaining < min_useful)
    score -= np.where(stranded, 1000.0, 0.0)

    # Among acceptable bins, prefer the one leaving the smallest usable residual,
    # which is already captured by `-remaining`; break residual ties by index (natural).
    return score
# EVOLVE-BLOCK-END
