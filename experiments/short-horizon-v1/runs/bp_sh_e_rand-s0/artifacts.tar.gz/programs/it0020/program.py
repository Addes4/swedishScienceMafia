# EVOLVE-BLOCK-START
"""Best fit with adaptive dead-space avoidance based on observed item sizes."""
import numpy as np

_state = {"min_item": 101.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Track the smallest item seen so far (running minimum) as a proxy for the
    # smallest future item we should keep space for.
    if item < _state["min_item"]:
        _state["min_item"] = float(item)
    min_item = _state["min_item"]

    remaining = bins - item
    # Pure best fit is the dominant signal.
    best_fit = -remaining.astype(np.float64)

    # True dead space: a nonzero residual strictly smaller than the smallest item
    # we have ever seen cannot be reused by any future item of that size or larger.
    dead = (remaining > 0) & (remaining < min_item)
    # Small, bounded penalty so it only breaks near-ties in favor of bins whose
    # leftover can still be filled.
    return best_fit - 0.5 * dead.astype(np.float64)
# EVOLVE-BLOCK-END
