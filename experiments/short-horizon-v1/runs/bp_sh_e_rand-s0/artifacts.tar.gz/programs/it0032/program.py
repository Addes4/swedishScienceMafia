# EVOLVE-BLOCK-START
"""Best fit with a learned dead-space penalty: keep residuals reusable."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # post-placement residual, >= 0

    # Best fit: prefer the tightest residual overall.
    score = -remaining.astype(np.float64)

    # Penalize tiny positive residuals that are hard to reuse (dead space).
    # A residual of 0 is ideal (no penalty); small positives are penalized
    # proportionally to how small they are, up to a modest threshold.
    small = (remaining > 0) & (remaining <= 10)
    if small.any():
        score = score - (11.0 - remaining[small]) * (small,)
    return score
# EVOLVE-BLOCK-END
