# EVOLVE-BLOCK-START
"""Best fit augmented with an online residual-reusability bonus."""
import numpy as np

# Online item-size histogram shared across calls within a stream.
# Reset handled by module-level state keyed on nothing: harness starts fresh per stream,
# but to be safe we detect stream restarts via a cap on counts.
_SIZE = 101
_hist = np.zeros(_SIZE, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Base rule is best fit (tightest feasible residual). We add a small bonus when the
    post-placement residual is a size that appears often in the observed stream, since
    that leftover capacity is likely to be reusable by a future item.
    """
    global _hist, _total

    # Update histogram with the arriving item (probability mass of what we've seen).
    _hist[item] += 1.0
    _total += 1.0

    remaining = (bins - item).astype(np.float64)  # residual after placement, >= 0 for fitting bins

    # Best fit base: tighter residual is better.
    base = -(remaining)

    # Reusability bonus: probability mass near each residual (smoothed over +/- 1 size).
    if _total > 0:
        prob = _hist / _total
        # For each residual r, look at probability that a future item is close to r.
        prob_l = np.where(remaining >= 1, prob[np.clip((remaining - 1).astype(np.int64), 0, _SIZE - 1)], 0.0)
        prob_c = np.where(remaining >= 1, prob[np.clip((remaining).astype(np.int64), 0, _SIZE - 1)], 0.0)
        prob_r = np.where(remaining >= 2, prob[np.clip((remaining + 1).astype(np.int64), 0, _SIZE - 1)], 0.0)
        reuse = 0.5 * prob_l + prob_c + 0.5 * prob_r
        # Exact-zero residual is pure perfection for best fit; no bonus needed there but keep it.
        bonus = 20.0 * reuse
    else:
        bonus = 0.0

    # Penalize leaving tiny unusable residues slightly (mild, secondary to reuse bonus).
    waste = np.where((remaining > 0) & (remaining <= 9), 1.0, 0.0)

    return base + bonus - 0.5 * waste
# EVOLVE-BLOCK-END
