# EVOLVE-BLOCK-START
"""Harmonic-style class rule with best-fit fallback.

The classic Harmonic algorithm partitions items into size classes and, for each class,
tries to fill a bin using items of that class only. Online, the natural equivalent is:
for the arriving item, prefer the fullest bin whose post-placement residual is small
enough that only items of the same (or a compatible) class can still fit. This
concentrates packing and keeps residuals usable, while a best-fit fallback guarantees
we always pick a sensible bin when no class-preferred candidate exists.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first tie).

    item: integer size 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    remaining = bins - item  # residual if placed here
    n = remaining.shape[0]

    # Size-class boundaries (as residual thresholds). For an item of size s,
    # the residual that "just fits one more item of similar class" is around
    # the class upper bound. C <= 100/2 = 50: item <= 50; then 1/3, 1/4, ...
    # Build class upper bounds for the item.
    # Find smallest k>=2 with item <= 100/k -> class ceiling = 100/k.
    # We use this to decide which residuals are "still usable" for same-class items.
    if item > 50:
        # Big item: fill bins using big items; prefer fullest (smallest residual below 50).
        target = 50
    else:
        # class k such that 100/(k+1) < item <= 100/k
        k = int(np.ceil(100.0 / item)) if item > 0 else 100
        if k < 2:
            k = 2
        target = 100.0 / k

    # Primary: prefer bins whose residual is in [0, target): these can still host
    # same-class items. Among those, tightest fit (smallest nonneg residual).
    # Secondary fallback: best fit overall.
    residual_f = remaining.astype(np.float64)

    # Score: strongly reward class-preferred bins (residual in [0, target)),
    # with tighter residual better. Otherwise fall back to best-fit ordering,
    # placed much lower.
    in_class = (residual_f >= 0) & (residual_f < target)
    # Large offset distinguishes class-preferred from fallback.
    OFFSET = 1e6
    score = np.where(in_class, OFFSET - residual_f, -residual_f)
    # Note residual_f >= 0 guaranteed since bins only include fitting bins.
    return score.astype(np.float64)
# EVOLVE-BLOCK-END

