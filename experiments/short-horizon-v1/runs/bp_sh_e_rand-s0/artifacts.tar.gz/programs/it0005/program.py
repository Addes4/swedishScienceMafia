# EVOLVE-BLOCK-START
"""Best fit with distribution-aware tie-breaking on residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary rule: best fit (smallest residual after placement).
    Tie-break: prefer residuals that match a common observed item size, so leftover
    space stays usable by future items.
    """
    residual = bins - item

    # Best fit: tighter fit (smaller residual) scores higher.
    score = -residual.astype(np.float64)

    # Distribution-aware tie-break: reward residuals that equal a frequently seen size.
    freq = _state['freq']
    if freq is not None:
        n = len(freq)
        r = residual
        # Only consider residuals within recorded range and non-negative.
        mask = (r >= 0) & (r < n)
        bonus = np.zeros_like(score)
        if np.any(mask):
            counts = freq[r[mask]]
            bonus[mask] = counts.astype(np.float64)
        # Small weight so it never overrides the actual tightness ordering.
        score += bonus * 1e-3

    _state['freq'][item] += 1
    _state['count'] += 1
    return score


_state = {'freq': None, 'count': 0}


def _init_state():
    _state['freq'] = np.zeros(101, dtype=np.int64)
    _state['count'] = 0
