# EVOLVE-BLOCK-START
"""Harmonic-class best fit: classify items by size and best-fit within harmonic class."""
import numpy as np

# Harmonic class boundaries for capacity C=100.  Items with size in
# (C/(j+1), C/j] belong to class j and are packed with capacity scaled so that
# up to j items of that class can share one bin.  We approximate with a
# real-valued "class residual target": prefer bins whose post-placement
# residual is compatible with the item's class.
_C = 100.0


def _class_of(item):
    # return j such that C/(j+1) < item <= C/j  (j >= 1)
    j = int(np.floor(_C / item))
    if j < 1:
        j = 1
    # clamp classes to a reasonable number
    if j > 10:
        j = 10
    return j


def priority(item, bins):
    """Rank bins for a harmonic-class best-fit placement.

    item: integer size 1..100.
    bins: remaining capacities of fitting bins (numpy int64).
    """
    remaining = bins - item

    # 1) Strong exact-fit reward.
    exact = np.where(remaining == 0, 1.0, 0.0)

    # 2) Best-fit term: prefer the tightest residual.
    best_fit = -remaining.astype(np.float64)

    # 3) Harmonic-class target: for class j the ideal residual after placing
    #    a class-j item is approximately a multiple of the class size, i.e.
    #    derived from capacity C/j.  Reward residuals close to a boundary
    #    C/j (which can hold another full class item) and punish residuals
    #    that are just below a boundary (unusable slivers).
    j = _class_of(item)
    class_size = _C / j  # typical space a j-items bin should have left after use
    # distance of residual to nearest "usable" multiple of the item size
    # (a residual that can still hold at least one more item of this size).
    usable = np.where(remaining >= item, remaining % item, item)  # remainder after filling
    # falling just short of the next multiple wastes capacity: distance to next multiple
    gap_to_next = np.where(remaining >= item,
                           (item - (remaining % item)) % item,
                           item - remaining)
    # small penalties only; use scaled units
    class_bonus = np.where(remaining >= item, 1.0, 0.0)

    score = (best_fit
             + 50.0 * exact
             + 1.5 * class_bonus
             - 0.5 * gap_to_next)
    return score
# EVOLVE-BLOCK-END

