# EVOLVE-BLOCK-START
"""Best fit with an asymmetric residual-shaping penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit

    # Asymmetric residual shaping:
    #  - residual 0 (exact fill): small reward, keep these bins closed-ish but ranked high
    #  - tiny residual 1..9: heavily discouraged (essentially unusable capacity)
    #  - small-medium residual 10..24: mildly discouraged (narrow slot)
    tiny = np.where((remaining >= 1) & (remaining <= 9), remaining, 0)
    small = np.where((remaining >= 10) & (remaining <= 24), remaining, 0)
    exact = np.where(remaining == 0, 1.0, 0.0)

    return best_fit - 3.0 * tiny - 1.0 * small + 0.5 * exact
# EVOLVE-BLOCK-END
