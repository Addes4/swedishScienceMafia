# EVOLVE-BLOCK-START
"""Harmonic-flavored best fit with an online residual-match bonus."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0
_LAST_STREAM_LEN = 0


def _update(item):
    global _COUNT, _HIST
    _HIST[item] += 1.0
    _COUNT += 1


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Detect a fresh stream (bins reset to all-100 resets state heuristically when
    # too many unused bins appear relative to our count).
    n_in = len(bins)
    n_unused = int(np.sum(bins == 100))
    if n_unused > n_in - 1 and n_in != _LAST_STREAM_LEN:
        # heuristic reset: first call of a new stream
        _HIST[:] = 0.0
        _COUNT = 0
    _update(item)
    global _LAST_STREAM_LEN
    _LAST_STREAM_LEN = n_in

    remaining = bins - item
    best_fit = -remaining  # higher is tighter fit

    # Penalize tiny residuals that are hard to reuse.
    waste = np.where((remaining > 0) & (remaining <= 19), remaining, 0)

    # Residual-match bonus: reward residuals that equal a commonly seen item size.
    if _COUNT >= 20:
        p = _HIST / _COUNT
    else:
        p = np.zeros(101, dtype=np.float64)

    def p_at(r):
        return np.where((r >= 1) & (r <= 100), p[np.clip(r, 0, 100)], 0.0)

    residual_prob = p_at(remaining)
    # bonus scaled: reuse probability times residual size (bigger exact slots more useful)
    bonus = 3.0 * residual_prob * remaining

    return best_fit.astype(np.float64) - 2.0 * waste + bonus
# EVOLVE-BLOCK-END

