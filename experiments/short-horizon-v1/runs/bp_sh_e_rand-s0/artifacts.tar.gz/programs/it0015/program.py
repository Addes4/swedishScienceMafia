# EVOLVE-BLOCK-START
"""Harmonic best-fit: prefer placing an item into the fullest bin in which it
occupies a large fraction of the remaining space (harmonic-class intuition),
with best-fit as a tiebreak so leftover gaps stay small and reusable."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacities of bins the item fits in (in bin order).
    """
    remaining = bins - item  # residual after placing the item (>= 0 for shown bins)

    # Harmonic-style class score: for a fixed item, bins whose current remaining
    # capacity is between item and 2*item are the "tight" class where the item
    # consumes a large fraction of the residual. Reward filling such bins.
    # fraction saved = item / bins (how much of the patched bin we used).
    frac = item / bins.astype(np.float64)

    # Best-fit term: tighter residual is better.
    best_fit = -remaining.astype(np.float64)

    # Waste penalty: small nonzero residuals are hard to reuse.
    waste = np.where((remaining > 0) & (remaining <= 19), remaining, 0).astype(np.float64)

    # Combine: harmonic fraction dominant, best-fit as a strong tiebreak,
    # small penalty for leaving tiny unusable gaps.
    return 100.0 * frac + best_fit - 2.0 * waste
# EVOLVE-BLOCK-END

