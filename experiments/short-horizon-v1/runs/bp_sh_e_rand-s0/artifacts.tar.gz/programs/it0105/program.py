# EVOLVE-BLOCK-START
"""Best-fit with an online Sum-of-Squares residual tie-breaker.

Pure best fit (place each item in the fullest bin that still fits) is an
extremely strong online rule for this Weibull-ish item distribution.  The only
thing that can be improved is how we handle near-ties: among bins that give a
similar fit, we want the one whose leftover capacity is *reusable* (close to a
typical future item size) rather than a dead sliver.

We therefore use best-fit as the dominant term and add a small, bounded
tie-breaker based on the post-placement residual, bucketed into coarse
(power-of-two-ish) classes so that residuals that can plausibly hold a future
item are preferred over tiny unusable gaps.
"""
import numpy as np


def priority(item, bins):
    remaining = bins - item                      # residual after placing item

    # Dominant term: pure best fit (higher score == tighter fit).  Scale by a
    # large constant so the tie-breaker can never override a strictly better fit.
    score = -remaining.astype(np.float64) * 1000.0

    # Tie-breaker: prefer residuals that are large enough to be reusable.
    # Bucket the residual into power-of-two classes; small dead slivers get a
    # mild penalty, healthy leftovers get a mild bonus.
    r = remaining.astype(np.float64)
    # Exact fits are ideal.
    score += np.where(r == 0, 5.0, 0.0)
    # Tiny unusable slivers (1..3) are mildly penalized.
    score -= np.where((r >= 1) & (r <= 3), 3.0, 0.0)
    # Residuals big enough to hold a typical future item (>= 20) get a tiny
    # bonus so we do not strand large gaps in nearly empty bins.
    score += np.where(r >= 20, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
