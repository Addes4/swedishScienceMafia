# EVOLVE-BLOCK-START
"""Best fit with a value-aware penalty for stranding reusable residual capacity."""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    """Rank bins: primary term is best fit (smallest post-placement residual),
    secondary term penalizes residuals that are too small to be reused well."""
    _state["sum"] += item
    _state["count"] += 1
    mean_item = _state["sum"] / _state["count"]

    remaining = bins - item
    # Primary: best fit. Higher score = tighter fit (smaller residual).
    score = -remaining.astype(np.float64)

    # Penalize residuals that are stranded: too small to hold a typical item.
    # Threshold scales with the observed mean item size.
    threshold = 0.5 * mean_item
    stranded = np.where((remaining > 0) & (remaining < threshold), remaining, 0.0)
    score -= 1.5 * stranded

    return score
# EVOLVE-BLOCK-END
