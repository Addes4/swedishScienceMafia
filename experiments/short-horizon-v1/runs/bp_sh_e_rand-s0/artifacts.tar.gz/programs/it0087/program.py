# EVOLVE-BLOCK-START
"""Best fit with a smooth residual-usability bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = (bins - item).astype(np.float64)

    # Tighter fit is better: prefer bins with small post-placement residual.
    tight = -remaining

    # Usable-leftover bonus: a residual is more useful when it is large enough to
    # hold a typical item. Use a smooth, saturating (sqrt) reward so that very
    # large residuals are mildly preferred but exact fills are not over-penalized.
    usable = np.sqrt(np.maximum(remaining, 0.0))

    # Exact-fill bonus: completing a bin is almost always ideal.
    exact = np.where(remaining == 0, 1.0, 0.0)

    return tight + 2.0 * usable + 5.0 * exact
# EVOLVE-BLOCK-END
