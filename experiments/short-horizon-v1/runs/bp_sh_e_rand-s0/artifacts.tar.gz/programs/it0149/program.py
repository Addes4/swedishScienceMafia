# EVOLVE-BLOCK-START
"""Best fit with a strong bonus for (near) exact fits: concentrate packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit

    # Strong reward for near-exact fits (small residual), scaled so exact fits dominate.
    # residual r >= 0; give a bonus that is large when r is tiny, fading by ~item size.
    r = remaining.astype(np.float64)
    bonus = 100.0 / (1.0 + r)  # large for r=0 (~100), smaller as r grows

    # Mild penalty for tiny-but-nonzero unusable slivers relative to near-full bins.
    waste = np.where((r > 0) & (r <= 19), r, 0)

    return best_fit + bonus - 0.5 * waste
# EVOLVE-BLOCK-END
