# EVOLVE-BLOCK-START
"""Best fit with harmonic exact-fit bonus for online bin packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item                      # post-placement residual
    best_fit = -remaining.astype(np.float64)     # tightest fit dominant
    # Harmonic-style bonus: strongly favour near-exact fills (residual small but positive),
    # so bins get driven to (or near) exactly full.
    h = np.where(remaining > 0, 1.0 / (remaining + 1.0), 0.0) * item
    # Mild penalty for leaving an unusable tiny sliver of leftover capacity.
    waste = np.where((remaining > 0) & (remaining <= 19), remaining, 0).astype(np.float64)
    return best_fit + 1.5 * h - 1.0 * waste
# EVOLVE-BLOCK-END

