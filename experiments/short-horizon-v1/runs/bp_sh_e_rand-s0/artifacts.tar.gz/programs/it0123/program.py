# EVOLVE-BLOCK-START
"""Best fit with a smooth, distribution-free penalty on stranded sliver residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins; highest score gets the item (first on ties).

    item: integer size 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    remaining = (bins - item).astype(np.float64)
    # Primary: best fit (tightest residual).
    best_fit = -remaining
    # Penalize slivers: residuals that are positive but too small to be useful
    # for almost any future item. Penalty is smooth and strongest near 0,
    # fading out by the item size, so it is scale-free without learned params.
    pos = remaining > 0
    frac = np.where(pos, remaining / float(item), 1.0)
    # 1/(frac+eps) style: large when residual << item, ~0 when residual >= item.
    sliver = np.where(pos, 1.0 / (frac + 0.5) - 1.0 / 1.5, 0.0)
    return best_fit - 1.0 * sliver
# EVOLVE-BLOCK-END
