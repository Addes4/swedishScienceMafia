# EVOLVE-BLOCK-START
"""Adaptive harmonic waste-aware best fit."""
import numpy as np


class _State:
    def __init__(self):
        # Recent item sizes, kept to estimate the low end of the item distribution.
        self.recent = []


_state = _State()


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals that strand reusable capacity.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Track a small window of past item sizes to adapt the "waste" threshold.
    _state.recent.append(item)
    if len(_state.recent) > 200:
        _state.recent.pop(0)

    if len(_state.recent) >= 20:
        # Low quantile of past items ~ smallest item likely to arrive next.
        small = float(np.percentile(_state.recent, 15))
    else:
        small = 20.0
    small = max(1.0, min(small, 100.0))

    remaining = bins - item
    best_fit = -remaining  # higher is tighter fit

    # Penalize squeezing out a residual smaller than a typical small item: that
    # stranded capacity is unlikely to ever be reused, whereas a residual that can
    # still hold a small item keeps its value.
    waste = np.where((remaining > 0) & (remaining < small), remaining, 0)
    return best_fit.astype(np.float64) - 2.0 * waste
# EVOLVE-BLOCK-END
