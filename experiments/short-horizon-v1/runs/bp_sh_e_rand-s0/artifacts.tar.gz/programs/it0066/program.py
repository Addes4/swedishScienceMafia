# EVOLVE-BLOCK-START
"""Hybrid best/worst fit: large items spread out, small items concentrate."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # capacity left after placement
    # Best fit: higher score when remaining is small -> -remaining.
    # Worst fit: higher score when remaining is large -> +remaining.
    # Blend: for large items (item >= 50) worst fit is stronger; for small items
    # best fit concentrates nicely. Use a weight that leans to worst fit for big items.
    w = (item - 50.0) / 50.0        # -1 for tiny items, +1 for item == 100
    w = np.clip(w, -1.0, 1.0)
    # scale so both terms have similar magnitude
    score = -remaining + w * remaining * 2.0
    # Penalize unusable tiny residuals (hard to reuse) mildly.
    waste = np.where((remaining > 0) & (remaining <= 19), remaining, 0)
    return score.astype(np.float64) - 2.0 * waste
# EVOLVE-BLOCK-END
