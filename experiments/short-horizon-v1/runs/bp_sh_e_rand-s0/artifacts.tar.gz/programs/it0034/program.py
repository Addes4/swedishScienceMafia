# EVOLVE-BLOCK-START
"""Best fit with dead-space-aware secondary ranking."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # residual capacity after hypothetical placement

    # Primary: tightest fit (smallest residual) is best.
    # Secondary: among residuals, prefer 0 (exact fill), then residuals >= 20
    # (generally reusable), and least prefer tiny unusable residuals (1..19).
    # Encode as a single score: primary term dominates the secondary tie-break.
    primary = -remaining.astype(np.float64)

    exact = (remaining == 0)
    reusable = (remaining >= 20)
    # dead space: 1..19 residuals
    secondary = np.where(exact, 1.0, np.where(reusable, 0.5, 0.0))

    return primary + 0.01 * secondary
# EVOLVE-BLOCK-END
