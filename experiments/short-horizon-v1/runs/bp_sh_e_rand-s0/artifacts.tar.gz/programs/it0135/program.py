# EVOLVE-BLOCK-START
"""Best fit with an exponential near-exact-fill bonus, concentrating packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # >= 0 for all shown bins
    # Best fit core: tighter fit (smaller residual) is better.
    best_fit = -remaining.astype(np.float64)
    # Extra reward when the residual is very small: near-exact fills are best,
    # and this reward grows steeply as the residual shrinks toward 0.
    # Scale factor keeps the bonus bounded relative to the best-fit ordering.
    bonus = 10.0 * np.exp(-remaining.astype(np.float64) / 5.0)
    return best_fit + bonus
# EVOLVE-BLOCK-END

