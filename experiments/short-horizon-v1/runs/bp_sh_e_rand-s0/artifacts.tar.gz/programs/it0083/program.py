# EVOLVE-BLOCK-START
"""Distribution-aware best fit: concentrate items, avoid leaving unusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit as the base ranking: prefer the tightest placement.
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)

    # Reward exact completion: a bin filled perfectly is ideal (no waste at all).
    exact = np.where(remaining == 0, 1.0, 0.0)

    # Penalize residuals that are too small to be reused by a typical item.
    # A leftover below the smallest typical item can never be filled again -> pure waste.
    # Use a smooth ramp up to a modest threshold.
    small = np.where((remaining > 0) & (remaining < 10), remaining / 10.0, 0.0)

    return best_fit + 3.0 * exact - 2.0 * small
# EVOLVE-BLOCK-END
