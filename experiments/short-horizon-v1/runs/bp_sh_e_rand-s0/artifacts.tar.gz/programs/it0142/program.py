# EVOLVE-BLOCK-START
"""Best fit with a small aperture: prefer tightest fit, ignore residual that is too small to matter."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # >= 0 for all shown bins

    # Dominant term: classic best fit, higher score for tighter fit.
    best_fit = -remaining.astype(np.float64)

    # Aperture: residuals below this are effectively "filled" -- any such bin is
    # equally desirable, so flatten the ranking there instead of over-rewarding
    # near-zero residuals while penalizing slightly-larger ones.
    aperture = 2.0
    filled = remaining <= aperture
    # Give all "filled" bins a strong common bonus so they win over loose bins,
    # but do not further differentiate among them.
    best_fit = best_fit + np.where(filled, aperture * 2.0, 0.0)

    return best_fit
# EVOLVE-BLOCK-END
