# EVOLVE-BLOCK-START
"""Best-fit with a light, data-driven guard against unusable tiny leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit core: smaller post-placement residual is better (higher score).
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)

    # Light, data-driven nudge: strongly discourage residuals that are so small they
    # can almost never hold another item. The floor adapts to observed item sizes via
    # state kept on the function, but only slightly perturbs the best-fit ordering.
    state = priority.state
    n = state.get("n", 0)
    small = state.get("small", 10)  # running estimate of a small typical item size
    # Update running estimate of small item sizes (cheap, no history buffering).
    if item < small:
        small = item
    state["small"] = small
    state["n"] = n + 1

    floor = max(1, min(small - 1, item - 1)) if item > 1 else 0
    waste = np.where((remaining > 0) & (remaining <= floor), remaining, 0).astype(np.float64)
    return best_fit - 0.75 * waste


priority.state = {"n": 0, "small": 100}
# EVOLVE-BLOCK-END

