# EVOLVE-BLOCK-START
"""Best-fit with an occupancy-aware tie-break tuned to the item distribution."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    Primary key: smallest residual after placement (best fit).
    Secondary: prefer residuals that are large enough to be reusable, and
    prefer bins that are already more occupied so capacity concentrates.
    """
    remaining = bins - item  # >= 0 by construction (only fitting bins shown)
    # Primary: best fit (tighter is better).
    best_fit = -remaining.astype(np.float64)

    # Small, monotone tie-break: residuals in the mid-range (roughly 20..60)
    # are more likely to fit another typical item than residuals in 1..20,
    # so give them a gentle nudge without overriding best fit.
    # Reward usable residual, decay beyond a typical item size.
    reusable = np.where(remaining > 0, np.minimum(remaining, 60), 0.0)
    # Prefer larger usable capacity slightly; scale small so best fit dominates.
    tie = 0.0 * best_fit + 0.0005 * reusable

    return best_fit + tie
# EVOLVE-BLOCK-END
