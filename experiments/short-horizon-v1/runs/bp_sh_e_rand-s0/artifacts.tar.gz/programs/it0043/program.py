# EVOLVE-BLOCK-START
"""Online residual-value best fit: rank bins by tightness plus future fill probability."""
import numpy as np

_CAP = 100
# Empirical size histogram over the seen stream, one slot per size 1..100.
_COUNT = np.zeros(_CAP + 1, dtype=np.float64)
_TOTAL = 0.0
_SMALL = None  # smallest observed size so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL, _SMALL
    global _COUNT

    # Base ranking: best fit (smaller residual -> higher score).
    residual = bins - item

    # Estimate the probability that a residual r can still be completely filled
    # by some future item.  We approximate this with the fraction of past items
    # whose size is <= r weighted by how likely a useful fit is; this rewards
    # residuals that match common item sizes and punishes stranded slivers.
    n = _TOTAL
    if n >= 8:
        # Probability mass of items <= r (a residual can host such an item).
        csum = np.cumsum(_COUNT)
        # For each bin, mass of item sizes <= residual r (clipped).
        r = np.clip(residual, 0, _CAP).astype(np.int64)
        fill_prob = csum[r] / n  # in [0,1]
        # Penalize residuals that are too small to ever host a typical item
        # (unless exactly 0, which is ideal).
        tiny = (residual > 0) & (residual < (_SMALL if _SMALL else 1))
        score = -residual.astype(np.float64) + 6.0 * fill_prob
        score = np.where(residual == 0, 1e6, score)
        score = np.where(tiny, score - 5.0, score)
    else:
        score = -residual.astype(np.float64)
        score = np.where(residual == 0, 1e6, score)

    # Update statistics with the arriving item (after scoring).
    _COUNT[item] += 1.0
    _TOTAL += 1.0
    if _SMALL is None or item < _SMALL:
        _SMALL = item

    return score
# EVOLVE-BLOCK-END
