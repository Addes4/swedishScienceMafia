# EVOLVE-BLOCK-START
"""Harmonic-style bin choice: put the item in the fullest bin of the tightest
capacity class, i.e. prefer bins whose remaining capacity is closest above the
item but from a coarse class bucketing (graduates small/medium/large items into
matched slots rather than always the single fullest bin)."""
import numpy as np


def priority(item, bins):
    """Return a score per bin; highest score wins (ties -> first bin).

    item: integer size 1..100.
    bins: remaining capacities (int64), all >= item, in fixed bin order.
    """
    remaining = bins.astype(np.float64)
    residual = remaining - item  # leftover after placing

    # --- Primary signal: best fit (tightest residual). ---
    # Higher score for smaller residual => -residual.
    score = -residual

    # --- Harmonic-style class correction. ---
    # The classic Harmonic scheme assigns items to capacity classes by size.
    # Here we mirror that by favoring placements whose *pre-placement* capacity
    # sits in the same coarse class as the item, so medium items don't waste
    # large bins and small items top off near-full bins.
    # Class boundaries at item size / (k+1) style: a bin is "matching" if its
    # capacity is roughly item * (1 + 1/m) for small integer m.
    for m in (1, 2, 3, 4, 6, 9):
        target = item + item / m  # capacity that leaves a clean residual item/m
        match = np.abs(remaining - target) <= item / (m + 1) / 2
        score = np.where(match, score + 1.0 / m, score)

    # Keep the small-residual waste penalty from before (true dead space).
    waste = np.where((residual > 0) & (residual <= 19), residual, 0.0)
    return (score - 2.0 * waste).astype(np.float64)
# EVOLVE-BLOCK-END
