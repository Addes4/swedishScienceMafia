# EVOLVE-BLOCK-START
"""Best fit with a mild fullness bonus to concentrate items into existing bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Dominant term: best fit (smaller post-placement residual -> higher score).
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)
    # Mild bonus for fuller bins (smaller current remaining capacity) to concentrate
    # packing into existing bins rather than opening fresh ones.
    fullness = (100.0 - bins.astype(np.float64)) / 100.0
    return best_fit + 0.05 * fullness
# EVOLVE-BLOCK-END

