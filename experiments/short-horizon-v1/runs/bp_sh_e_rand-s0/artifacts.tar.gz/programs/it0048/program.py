# EVOLVE-BLOCK-START
"""Best-fit with a learned residual-usefulness bias, adapted online."""
import numpy as np


# Online state shared across calls within a stream.
_STATE = {"min_seen": 100, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update learned statistics about the arriving item sizes.
    if item < _STATE["min_seen"]:
        _STATE["min_seen"] = item
    _STATE["count"] += 1

    remaining = bins - item  # post-placement residual for each bin

    # Base: classic best fit (smallest residual => highest score).
    score = -remaining.astype(np.float64)

    # Bonus for exact fill (residual == 0): perfectly packed bin.
    score += np.where(remaining == 0, 1.0, 0.0)

    # Mild penalty for residuals that are too small to ever be reused
    # (smaller than the smallest item seen so far). This only breaks near-ties.
    min_seen = _STATE["min_seen"]
    small = (remaining > 0) & (remaining < min_seen)
    score -= 0.5 * small

    return score
# EVOLVE-BLOCK-END
