# EVOLVE-BLOCK-START
"""Best fit with a distribution-adaptive waste penalty.

The base ranking is best fit (minimize the post-placement residual).  We add a penalty
for residuals that are likely to be unusable for future items.  Instead of a fixed
threshold, we learn the observed item-size distribution online and penalize a residual
proportionally to the probability that a future item is strictly larger than it
(i.e. cannot fit in the leftover), which adapts automatically to the stream.
"""
import numpy as np

# Module-level state (reset implicitly by starting fresh per stream is not guaranteed,
# so keep it robust: a global histogram accumulated over calls).
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, ties to first."""
    global _TOTAL
    # Update observed histogram with the arriving item.
    _HIST[item] += 1.0
    _TOTAL += 1.0

    remaining = (bins - item).astype(np.float64)

    # Best fit: tighter post-placement residual is better.
    score = -remaining

    # Probability that a random future item is strictly larger than each residual.
    # Only meaningful for residuals in 0..100; accumulate tail mass.
    if _TOTAL > 0.0:
        cum = np.cumsum(_HIST)  # cum[s] = P(size <= s)
        total = _TOTAL
        # clamp residuals to valid range
        r = np.clip(remaining, 0, 100).astype(np.int64)
        # P(size > r) = 1 - P(size <= r)
        p_too_big = 1.0 - cum[r] / total
        # Penalize the expected wasted space: residual * chance it can't be used?
        # Simpler and effective: penalize unusable residuals by their tail probability,
        # scaled to combine with best fit. Weight chosen small to keep best-fit dominant.
        score = score - 25.0 * p_too_big

    return score
# EVOLVE-BLOCK-END
