# EVOLVE-BLOCK-START
"""Best fit with a smooth concave penalty on small residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit
    # Smoothly penalize leaving a small residual: a concave (sqrt) shaping makes
    # tiny leftovers costlier than the linear best-fit term, steering the packer
    # away from fragmenting capacity without a hard threshold.
    r = np.maximum(remaining, 0).astype(np.float64)
    return best_fit - 1.5 * np.sqrt(r)
# EVOLVE-BLOCK-END
