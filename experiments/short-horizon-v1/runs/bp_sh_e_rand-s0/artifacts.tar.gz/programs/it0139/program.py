# EVOLVE-BLOCK-START
"""Best fit with a residual-value penalty learned from the arriving item stream."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Track a running mean of observed item sizes to scale the "unusable scrap" term.
    _state["sum"] += item
    _state["n"] += 1
    mean_item = _state["sum"] / _state["n"]

    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit

    # A post-placement residual r is "scrap" if it is small relative to a typical item:
    # it likely cannot hold a future item, so that capacity is wasted. Penalize it
    # smoothly up to ~half the mean item size, saturating after that.
    scale = max(1.0, 0.5 * mean_item)
    scrap = np.clip(1.0 - remaining / scale, 0.0, 1.0)
    scrap = np.where(remaining > 0, scrap, 0.0)  # exact fill is ideal, not scrap
    return best_fit - 2.0 * scrap
# EVOLVE-BLOCK-END

