# EVOLVE-BLOCK-START
"""Best fit with a strong bonus for perfectly filling a bin (zero residual)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    remaining = bins - item
    # Primary: best fit (tighter is better). Higher score = smaller residual.
    score = -remaining.astype(np.float64)
    # Strong bonus when the item exactly fills the bin: residual 0, no dead space.
    score += np.where(remaining == 0, 1000.0, 0.0)
    return score
# EVOLVE-BLOCK-END
