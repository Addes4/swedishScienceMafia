# EVOLVE-BLOCK-START
"""Best fit with residual-zero bonus and fuller-bin tie-break."""
import numpy as np


def priority(item, bins):
    """Score bins: prefer exact fit, then smallest residual, then fullest bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # >= 0 since only bins that fit are shown
    score = residual.astype(np.float64)
    # Perfect fit (residual 0) should strongly beat everything else.
    score = np.where(residual == 0, -1.0, score)
    # Tie-break toward fuller bins (smaller remaining capacity first already does
    # this since residual = cap - item; add tiny term to break equal residuals
    # in favor of more-full bins, i.e. smaller cap).
    score = score + 1e-6 * bins
    return -score
# EVOLVE-BLOCK-END
