# EVOLVE-BLOCK-START
"""Best fit with a smooth scale-free residual quality tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # leftover after placing (>=0 since bins only hold fitting ones)

    # Primary signal: best fit (tightest), scaled so it dominates the tie-break.
    best_fit = -remaining.astype(np.float64)

    # Tie-break operates only relative to the item's own size, so it's scale-free.
    # r = fraction of the item size that remains.
    frac = remaining.astype(np.float64) / float(item)

    # Dipping penalty: a very small leftover (relative to item) is dead space.
    # A mild peak reward around residuals on the order of a small item (~item/4)
    # which future small items can still exploit; unused bins (frac ~ 100/item)
    # get no special treatment beyond being far from the dip.
    dip = np.exp(-((frac - 0.0) ** 2) / (2.0 * 0.03 ** 2))
    peak = np.exp(-((frac - 0.25) ** 2) / (2.0 * 0.15 ** 2))

    tie = -0.6 * dip + 0.1 * peak
    return best_fit + tie
# EVOLVE-BLOCK-END

