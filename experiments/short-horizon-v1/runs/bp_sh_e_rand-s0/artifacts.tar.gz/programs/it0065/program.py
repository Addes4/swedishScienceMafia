# EVOLVE-BLOCK-START
"""Best fit with an online-learned penalty for unusable leftover capacity."""
import numpy as np

# Module-level state (reset implicitly per stream since lower bound harness creates
# fresh state via re-instantiation isn't guaranteed, so keep it light and robust).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    """Score bins by best-fit tightness minus expected useless leftover capacity."""
    global _HIST, _COUNT

    # Update running histogram with the current item (we only know past + current).
    _HIST[item] += 1.0
    _COUNT += 1.0

    remaining = bins.astype(np.int64) - item  # >= 0 for bins shown

    # Best-fit base: tighter fit => higher score (negative residual).
    best_fit = -remaining.astype(np.float64)

    # Probability mass of item sizes that cannot fit in a residual of size r.
    # For residual r, mass of future items > r is "wasted" capacity.
    if _COUNT > 0:
        probs = _HIST / _COUNT  # prob. of each size 1..100
        # cumulative mass strictly greater than each r
        tail = np.cumsum(probs[::-1])[::-1]  # tail[s] = P(size >= s)
        # P(size > r) = tail[r+1]
        r_clipped = np.clip(remaining, 0, 99)
        unusable = tail[r_clipped + 1]
    else:
        unusable = np.zeros_like(remaining, dtype=np.float64)

    # Penalize expected wasted capacity; scale modestly so best-fit dominates.
    return best_fit - 100.0 * unusable
# EVOLVE-BLOCK-END
