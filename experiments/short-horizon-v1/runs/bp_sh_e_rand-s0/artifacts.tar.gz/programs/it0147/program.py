# EVOLVE-BLOCK-START
"""Best fit with a small usable-leftover bonus to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = (bins - item).astype(np.float64)
    # Dominant best-fit term: tighter fit (smaller residual) is better.
    score = -remaining
    # Mild bonus for residuals that are still usefully large (can hold a small item),
    # which discourages creating tiny unusable slivers.
    score += 0.05 * np.minimum(remaining, 20.0)
    return score
# EVOLVE-BLOCK-END
