# EVOLVE-BLOCK-START
"""Best fit with online-learned residual usability and an exact-fill bonus."""
import numpy as np


class _State:
    def __init__(self):
        # Histogram of item sizes seen so far (indices 1..100).
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update online estimate of the item-size distribution.
    _state.counts[item] += 1.0
    _state.total += 1.0

    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit

    # Estimate, for each candidate residual r, the probability that some future item fits
    # in a bin with residual r: P(item <= r). This makes leftovers "usable" if they can
    # hold typical future items, and worthless if they are too small.
    if _state.total >= 5:
        cdf = np.cumsum(_state.counts) / _state.total  # cdf[r] = P(item <= r), 0..100
        r_clip = np.clip(remaining, 0, 100)
        usability = cdf[r_clip]
    else:
        usability = (remaining > 0).astype(np.float64)

    # Exact fill (residual 0) is a free bin — strongly reward it.
    exact = (remaining == 0).astype(np.float64)

    return best_fit + 50.0 * usability + 1000.0 * exact
# EVOLVE-BLOCK-END
