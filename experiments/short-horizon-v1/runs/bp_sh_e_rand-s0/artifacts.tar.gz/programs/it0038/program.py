# EVOLVE-BLOCK-START
"""Best fit with a strong exact-fill bonus and normalized tightness tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties)."""
    remaining = bins - item  # post-placement residual, >= 0 for bins we see
    # Primary driver: tightest fit (smallest residual -> largest -remaining).
    best_fit = -remaining.astype(np.float64)
    # Strong bonus when the bin becomes exactly full (residual 0).
    exact = (remaining == 0).astype(np.float64)
    # Normalized tightness: prefer bins with higher post-placement occupancy ratio.
    occupancy = (100.0 - remaining) / 100.0
    return best_fit + 1000.0 * exact + 0.5 * occupancy
# EVOLVE-BLOCK-END
