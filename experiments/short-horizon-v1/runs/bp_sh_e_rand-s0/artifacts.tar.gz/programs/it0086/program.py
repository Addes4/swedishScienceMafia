# EVOLVE-BLOCK-START
"""Scale-aware best fit using an online estimate of the item-size distribution.

The item goes to the bin whose post-placement residual is most likely to still be
usable by a future item, with a strong bonus for exactly filling a bin.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)   # histogram of observed item sizes (index 1..100)
_COUNT = 0.0


def priority(item, bins):
    global _HIST, _COUNT

    # Update the online histogram of item sizes.
    if 1 <= item <= 100:
        _HIST[item] += 1.0
    _COUNT += 1.0

    # Empirical CDF of item sizes: prob mass at sizes <= x.
    total = _HIST.sum()
    if total > 0:
        pdf = _HIST / total
    else:
        pdf = None

    # Fraction of future items that are <= residual, i.e. the residual is usable.
    remaining = bins - item

    # Cumulative usability: sum of pdf over sizes <= residual.
    if pdf is not None:
        cdf = np.cumsum(pdf)  # cdf[s] = P(size <= s)
        usable = cdf[np.clip(remaining, 0, 100).astype(np.int64)]
    else:
        # Fallback: uniform-ish prior; usable if residual >= 1.
        usable = np.clip(remaining, 0, 1).astype(np.float64)

    # Base: tightest fit (best fit).
    best_fit = -remaining.astype(np.float64)

    # Reward usable residuals, plus a strong exact-fill bonus.
    exact = (remaining == 0).astype(np.float64)

    return 10.0 * usable + best_fit + 50.0 * exact
# EVOLVE-BLOCK-END
