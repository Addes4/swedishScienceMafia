# EVOLVE-BLOCK-START
"""Best fit with a strong but bounded exact-fill bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of bins the item fits in,
          including unused bins (remaining 100), in bin order.
    """
    remaining = bins - item
    # Base: tighter fit is better (smallest residual).
    score = -remaining.astype(np.float64)
    # Strong bounded bonus for exact fill; keeps exact fills dominant over near fills.
    score += np.where(remaining == 0, 3.0, 0.0)
    return score
# EVOLVE-BLOCK-END

