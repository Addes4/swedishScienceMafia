# EVOLVE-BLOCK-START
"""Best fit with a reusable-residual reward and a strong tiny-residual penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit

    # Penalize leaving a tiny residual (unusable capacity); reward residuals that
    # can still plausibly hold a typical item (mean ~40, so favor mid-size slots).
    tiny = np.where((remaining > 0) & (remaining <= 12), remaining, 0)
    # Mild reward for residuals close to a typical item size (~40).
    dist_to_40 = np.abs(remaining - 40.0)
    reward = np.where(remaining >= 25, 4.0 - 0.1 * dist_to_40, 0.0)

    return best_fit - 2.0 * tiny + reward
# EVOLVE-BLOCK-END
