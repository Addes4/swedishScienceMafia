# EVOLVE-BLOCK-START
"""Best fit with a self-fill bonus: tighten packing and favor refillable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # post-placement residual, >= 0 for all shown bins
    # Base: best fit -> smallest residual first (higher score = tighter).
    score = -remaining.astype(np.float64)
    # Bonus: a residual exactly equal to the item size can be filled perfectly by
    # one more identical item, so prefer such bins to reduce future waste.
    score += 30.0 * (remaining == item)
    # Mild bonus for exact fills (residual 0) as an almost-complete bin.
    score += 5.0 * (remaining == 0)
    return score
# EVOLVE-BLOCK-END

