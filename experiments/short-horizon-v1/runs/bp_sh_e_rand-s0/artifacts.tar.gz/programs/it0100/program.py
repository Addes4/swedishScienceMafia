# EVOLVE-BLOCK-START
"""Best fit refined with a graded, size-aware waste penalty for tiny residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit

    # Graded penalty for leaving a small, hard-to-reuse residual.
    # Residuals that are tiny relative to typical items are the worst waste.
    tiny = np.clip(20.0 - remaining, 0.0, None)
    tiny = np.where(remaining > 0, tiny, 0.0)

    # Mild bonus for a reusable residual (at least half the current item).
    reusable = np.where(remaining * 2 >= item, 1.0, 0.0)

    return best_fit - 2.0 * tiny + 1.0 * reusable
# EVOLVE-BLOCK-END

