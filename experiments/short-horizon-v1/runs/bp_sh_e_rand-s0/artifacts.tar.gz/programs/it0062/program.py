# EVOLVE-BLOCK-START
"""Best fit with an online-learned residual-usability penalty.

Rank by smallest post-placement residual (best fit), but penalize leaving a
residual that future items are unlikely to fit into.  The penalty uses an
empirical histogram of item sizes seen so far in this stream, estimating the
fraction of upcoming items larger than the residual.  This captures "wasted"
capacity without a fixed threshold.
"""
import numpy as np

# Histogram of observed item sizes (1..100), persists across calls in a stream.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    global _COUNT
    # Update the empirical size distribution with the current item.
    _HIST[item] += 1.0
    _COUNT += 1.0

    remaining = bins - item  # post-placement residual (<= 0 means it doesn't fit)

    # Best fit: higher score for smaller residual.
    best_fit = -remaining.astype(np.float64)

    # Probability that a future item is larger than the residual, using
    # the empirical CDF of seen sizes.  For each bin compute the mass of
    # sizes that would NOT fit in the residual (i.e. size > residual).
    if _COUNT > 0:
        # cumulative counts: cdf[s] = P(size <= s)
        cdf = np.cumsum(_HIST) / _COUNT
        # For residual r (integer >= 0), unusable mass = 1 - P(size <= r)
        r = np.clip(remaining, 0, 100)
        unusable = 1.0 - cdf[r]
    else:
        unusable = np.zeros_like(remaining, dtype=np.float64)

    return best_fit - 2.0 * unusable
# EVOLVE-BLOCK-END
