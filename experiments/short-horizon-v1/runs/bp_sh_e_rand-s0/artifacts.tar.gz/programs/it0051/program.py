# EVOLVE-BLOCK-START
"""Best fit with reusability value: tighten residual, favor fillable leftovers."""
import numpy as np

_STATE = {
    "hist": np.zeros(101, dtype=np.float64),
    "count": 0.0,
}


def priority(item, bins):
    """Rank bins by smallest post-placement residual, plus a learned value for
    residuals that future items can reuse (exact fill or common item size)."""
    hist = _STATE["hist"]
    n = _STATE["count"]

    if n > 0:
        p = hist / n
    else:
        p = np.full(101, 1.0 / 100.0)
        p[0] = 0.0

    # Probability a future item matches each residual exactly (reuse value).
    reuse = p  # p[r] = P(next item size == r)

    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher = tighter

    # Value of residual: chance it can be exactly consumed by a future item.
    # r=0 means exactly full now, which is best of all.
    val = np.where(remaining >= 0, reuse[np.clip(remaining, 0, 100)], 0.0)

    score = best_fit + 25.0 * val

    # Update histogram with this item (state evolves within a stream).
    hist[item] += 1.0
    _STATE["count"] = n + 1.0

    return score
# EVOLVE-BLOCK-END
