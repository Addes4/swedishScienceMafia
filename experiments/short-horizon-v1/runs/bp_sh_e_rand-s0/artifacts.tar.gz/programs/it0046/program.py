# EVOLVE-BLOCK-START
"""Best fit with a learned tie-break that avoids stranding unusable residual capacity."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = (bins - item).astype(np.float64)
    # Primary signal: smallest post-placement residual (tightest fit).
    best_fit = -remaining

    # Small bonus if the residual is large enough to still hold an average future item
    # (reusable capacity), avoiding stranded tiny slivers.
    reusable = np.where(remaining >= 25.0, 1.0, 0.0)

    return best_fit + 0.5 * reusable
# EVOLVE-BLOCK-END

