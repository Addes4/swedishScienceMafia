# EVOLVE-BLOCK-START
"""Best fit with a residual-utility penalty shaped by the arriving item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # residual capacity after placing the item (>= 0)
    best_fit = -remaining.astype(np.float64)  # tighter fit is better

    # Penalize residuals that are too small to be useful for a future item of
    # comparable size. Rescaled by the current item size so the penalty adapts
    # to the item distribution instead of a fixed cutoff.
    thr = item  # residual below a same-sized item is hard to reuse
    small = (remaining > 0) & (remaining < thr)
    frac = np.where(small, (thr - remaining) / thr, 0.0)
    return best_fit - 2.0 * frac
# EVOLVE-BLOCK-END

