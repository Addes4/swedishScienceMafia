# EVOLVE-BLOCK-START
"""Harmonic-flavored best fit: concentrate items into the fullest fitting bin,
with a concave bonus favoring leftovers that match typical item sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    # Best-fit base: higher (tight) is better.
    best_fit = -remaining.astype(np.float64)
    # Two-sided residual shaping on the normalized leftover (fraction of capacity).
    r = remaining.astype(np.float64) / 100.0
    # Penalize stranded slivers (residual below ~typical-small item) and
    # reward mid-range leftovers that can still host a future item well.
    sliver = np.where((remaining > 0) & (remaining <= 19), (20.0 - remaining) / 20.0, 0.0)
    # Concave bonus: peak around residual ~0.4 (near mean item), tapering at extremes.
    mid = np.where(remaining > 0, np.sqrt(np.maximum(r, 0.0)) * (1.0 - r), 0.0)
    return best_fit - 2.0 * sliver + 3.0 * mid
# EVOLVE-BLOCK-END

