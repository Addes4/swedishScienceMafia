# EVOLVE-BLOCK-START
"""Best fit with a scale-aware penalty on unusably small leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit

    # Penalize residuals too small to be profitably reused. Threshold scales with
    # the distribution: keep a running estimate of the mean item size and treat
    # residuals below ~1/3 of that mean as waste.
    state = priority.__dict__
    total = state.get("total", 0) + item
    count = state.get("count", 0) + 1
    state["total"] = total
    state["count"] = count
    mean_item = total / count
    thresh = max(2.0, mean_item / 3.0)

    waste = np.where((remaining > 0) & (remaining <= thresh), remaining, 0.0)
    return best_fit - 1.5 * waste
# EVOLVE-BLOCK-END
