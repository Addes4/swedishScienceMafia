# EVOLVE-BLOCK-START
"""Best fit with a graded waste penalty and a data-driven reusable-residual bonus."""
import numpy as np


class _State:
    def __init__(self):
        # Online histogram of item sizes seen so far (1..100).
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = (bins - item).astype(np.float64)  # >= 0 for all bins shown

    # Best-fit base: tighter fit scores higher.
    best_fit = -remaining

    # Graded waste penalty: harder penalty as the leftover gets smaller and thus
    # less likely to be reusable (a near-zero residual is nearly pure waste).
    small = np.clip(20.0 - remaining, 0.0, 20.0)  # 0..20
    waste = -0.5 * small

    # Data-driven reusable-residual bonus: reward residuals close to item sizes
    # that actually appear in the stream, so gaps we leave can be filled later.
    counts = _state.counts
    if _state.total >= 1.0:
        p = counts / _state.total  # probability each exact size shows up
        # Score residual r by the chance that some item of size ~r can fit it.
        # Use a soft window around each residual.
        r = remaining
        bonus = np.zeros_like(r)
        sizes = np.nonzero(p)[0]
        for s in sizes:
            ps = p[s]
            bonus += ps * np.exp(-0.5 * ((r - s) / 5.0) ** 2)
        reusable = 3.0 * bonus
    else:
        reusable = np.zeros_like(remaining)

    # Strong exact-fill bonus (leaving zero residual is ideal).
    exact = np.where(remaining == 0, 4.0, 0.0)

    score = best_fit + waste + reusable + exact

    # Update online histogram after scoring.
    _state.counts[item] += 1.0
    _state.total += 1.0

    return score
# EVOLVE-BLOCK-END
