# EVOLVE-BLOCK-START
"""Best-fit with a sliver penalty relative to the arriving item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order,
          including unused bins (remaining capacity 100).
    """
    remaining = bins - item  # residual capacity after placing the item (>= 0)

    # Dominant term: best fit (tightest residual is best).
    best_fit = -remaining.astype(np.float64)

    # Penalize residuals that are unusable slivers: leftover strictly smaller than the
    # arriving item is likely too small to be reused well later, so mildly avoid it.
    sliver = (remaining > 0) & (remaining < item)
    penalty = np.where(sliver, (item - remaining).astype(np.float64) / item, 0.0)

    # Mild bonus for exact fits (fully packed bin, no waste at all).
    exact = (remaining == 0).astype(np.float64)

    return best_fit - penalty + 0.5 * exact
# EVOLVE-BLOCK-END

