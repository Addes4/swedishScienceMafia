# EVOLVE-BLOCK-START
"""Best fit with an adaptive residual-value penalty: concentrate items into the fullest
fitting bin while avoiding post-placement residuals too small to be reused."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["sum"] += item
    st["n"] += 1
    mean_item = st["sum"] / st["n"]

    remaining = bins - item  # >= 0 for all bins shown

    # Dominant term: best fit (tightest residual gets highest score).
    best_fit = -remaining.astype(np.float64)

    # Residuals too small to plausibly hold a future item are waste. Estimate the
    # typical small item as a fraction of the running mean (mean ~40, so ~0.15*mean).
    small = max(1.0, 0.15 * mean_item)

    # Penalize residuals in (0, small): they are effectively dead capacity now.
    # Exact fills (remaining == 0) are ideal and must NOT be penalized.
    dead = (remaining > 0) & (remaining < small)
    waste = np.where(dead, (small - remaining) / small, 0.0)

    return best_fit - 3.0 * waste
# EVOLVE-BLOCK-END
