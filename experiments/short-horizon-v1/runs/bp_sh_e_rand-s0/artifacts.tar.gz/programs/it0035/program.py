# EVOLVE-BLOCK-START
"""Best fit with a strong bonus for perfect fills."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    # Primary signal: tighter fit (smaller residual) is better.
    score = -remaining.astype(np.float64)
    # Strongly reward exact fills: choosing them directly avoids starting a new bin.
    score += np.where(remaining == 0, 1000.0, 0.0)
    return score
# EVOLVE-BLOCK-END

