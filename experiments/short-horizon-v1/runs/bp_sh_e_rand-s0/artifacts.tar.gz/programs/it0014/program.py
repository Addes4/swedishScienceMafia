# EVOLVE-BLOCK-START
"""Harmonic best-fit with residual-packability bonus.

Best fit alone leaves hard-to-reuse tiny gaps. Optimal online packing tends to
leave residuals that are themselves common item sizes, so future items can fill
them. We keep best fit dominant but add a bonus when the post-placement residual
is close to a frequently seen item size (learned from a running histogram).
"""
import numpy as np


def priority(item, bins):
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher is tighter fit

    # Maintain a running histogram of seen item sizes (module-level state).
    hist = priority.hist
    hist[item] += 1
    total = priority.total
    priority.total = total + 1

    # Bonus for residuals that are likely reusable: residual close to a
    # frequently-seen item size. Use the top frequency sizes as targets.
    # Cost-based: penalize residual based on how "useful" it is as a leftover.
    bonus = np.zeros_like(remaining, dtype=np.float64)
    if total > 20:
        counts = hist
        # normalize frequencies
        freq = counts / float(total)
        # for each bin, look at how frequently the residual value is observed
        # we only care about residuals in [1, 100]
        idx = np.clip(remaining, 0, 100)
        f = freq[idx]
        bonus = f * 100.0  # scale so max bonus ~ a few capacity units

    return best_fit + 0.6 * bonus


priority.hist = np.zeros(101, dtype=np.float64)
priority.total = 0
# EVOLVE-BLOCK-END
