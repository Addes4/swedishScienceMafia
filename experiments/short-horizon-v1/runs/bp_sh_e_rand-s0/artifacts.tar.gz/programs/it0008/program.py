# EVOLVE-BLOCK-START
"""Harmonic best fit: prefer tightest fit, scaled by harmonic reward on small residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # >= 0 for bins shown
    # Base best-fit: tighter fit -> higher score.
    score = -remaining.astype(np.float64)
    # Harmonic-scale: strongly reward leaving a very small residual (bin nearly full),
    # making best-fit more aggressive about concentrating into nearly-full bins.
    tight = (remaining > 0) & (remaining <= 10)
    score += np.where(tight, 10.0 / (remaining + 1.0), 0.0)
    return score
# EVOLVE-BLOCK-END
