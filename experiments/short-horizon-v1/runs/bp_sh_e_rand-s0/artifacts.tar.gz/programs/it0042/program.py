# EVOLVE-BLOCK-START
"""Harmonic-flavored best fit: concentrate items into the fullest fitting bin,
but use capacity classes so small residuals are reserved for small items."""
import numpy as np

# Class boundaries: bins with remaining capacity in [b_{k}, b_{k+1}) belong to class k.
# Harmonic(M) style geometrically spaced boundaries over capacity 0..100.
_BOUNDS = np.array([0, 1, 2, 3, 4, 5, 6, 8, 10, 13, 16, 20, 25, 32, 40, 50, 60, 75, 100, 101], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Class index of the current remaining capacity: larger class = emptier bin.
    cls = np.searchsorted(_BOUNDS, bins, side='right') - 1
    # Prefer the tightest class (smallest remaining class) that still fits, i.e.
    # use up small-residual bins for small items instead of large ones.
    score = -cls.astype(np.float64)
    # Within a class, prefer the fullest bin (smallest post-placement residual) to
    # concentrate packing and avoid fragmenting capacity.
    score += (100.0 - bins) * 1e-3
    return score
# EVOLVE-BLOCK-END
