# EVOLVE-BLOCK-START
"""Best fit with harmonic-class consolidation bonuses (discrete, bounded)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = (bins - item).astype(np.int64)
    # Base: best fit -- tighter post-placement residual ranks higher.
    score = -remaining.astype(np.float64)
    # Exact-fill is always excellent.
    score += np.where(remaining == 0, 3.0, 0.0)
    # Harmonic-style classes: strongly reward residuals that exactly hit a class
    # boundary, i.e. capacities that are reusable "slots" for future items.
    # Boundaries 100//k for k=2..: 50,33,25,20,16,14,12,11,10,...
    for k in (2, 3, 4, 5, 6, 7, 8, 9, 10):
        b = 100 // k
        score += np.where(remaining == b, 1.0 / k, 0.0)
    # Mildly penalize tiny unusable residuals (can't hold the smallest common items),
    # but bounded so it never overrides the best-fit ordering.
    score -= np.where((remaining > 0) & (remaining < 8), 0.05, 0.0)
    return score
# EVOLVE-BLOCK-END
