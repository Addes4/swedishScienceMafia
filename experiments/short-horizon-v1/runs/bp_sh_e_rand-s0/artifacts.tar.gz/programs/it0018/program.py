# EVOLVE-BLOCK-START
"""Best fit with adaptive residual targeting from a running item-size histogram."""
import numpy as np


class _State:
    def __init__(self):
        # Histogram of item sizes seen so far (1..100), plus running count.
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 1.0
        self.min_seen = 100.0

    def update(self, item):
        self.hist[item] += 1.0
        self.count += 1.0
        if item < self.min_seen:
            self.min_seen = item

    def modal_residual(self):
        # Most common item size seen (mass-based; ignores the trivial min bin).
        h = self.hist[1:].copy()
        if h.sum() <= 0:
            return 20.0
        return float(np.argmax(h)) + 1.0

    def small_threshold(self):
        # A residual smaller than this can rarely fit any future item -> dead space.
        h = self.hist[1:]
        total = h.sum()
        if total < 5:
            return float(self.min_seen)
        cum = np.cumsum(h)
        # smallest item size covering at least 5% of observed mass (roughly).
        idx = int(np.searchsorted(cum, 0.05 * total))
        return float(idx + 1)


_state = _State()


def priority(item, bins):
    """Rank bins: best-fit dominant, plus a bonus for a reusable residual."""
    _state.update(item)
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)

    modal = _state.modal_residual()
    small = _state.small_threshold()

    # Dead-space penalty: residual too small to fit a typical small future item.
    dead = np.where((remaining > 0) & (remaining < small), remaining,
                    np.where(remaining == 0, 0.0, 0.0))
    # Bonus: residual close to the most common item size (highly reusable).
    target = float(modal)
    close = np.where((remaining > 0) & (np.abs(remaining - target) <= 1),
                     1.0, 0.0)

    return best_fit - 1.5 * dead + 0.75 * close
# EVOLVE-BLOCK-END

