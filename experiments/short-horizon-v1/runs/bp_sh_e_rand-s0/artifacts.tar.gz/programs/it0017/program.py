# EVOLVE-BLOCK-START
"""Best fit with a dynamic, distribution-adaptive small-residual (waste) penalty."""
import numpy as np


class _State:
    def __init__(self):
        # Histogram of item sizes seen so far (index 1..100).
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0

    def threshold(self):
        """Return a size below which a residual is likely unusable (rare-to-use)."""
        if self.count < 20:
            return 19.0
        # Fraction of observed items that are at or below a given size.
        cdf = np.cumsum(self.hist)
        cdf /= cdf[-1]
        # Smallest size such that at least 25% of items are <= it: leftovers
        # below this are hard to reuse.
        idx = np.searchsorted(cdf, 0.25)
        return float(idx)


_state = _State()


def priority(item, bins):
    """Rank bins for the arriving item; highest score wins (first on ties)."""
    _state.hist[item] += 1.0
    _state.count += 1.0

    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # higher => tighter fit

    thr = _state.threshold()
    waste = np.where((remaining > 0) & (remaining <= thr), remaining, 0.0)
    return best_fit - 2.0 * waste
# EVOLVE-BLOCK-END
