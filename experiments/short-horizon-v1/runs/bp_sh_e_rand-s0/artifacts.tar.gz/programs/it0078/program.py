# EVOLVE-BLOCK-START
"""Best fit with a smooth, distribution-aware residual reward.

Base ranking is best fit (prefer the bin that ends up tightest). On top of that
we add a small bonus when the post-placement residual is a "reusable" size --
one that matches (or nearly matches) the sizes of items we've been observing.
Items are Weibull-shaped; tracking an online histogram lets the rule adapt the
notion of reusable leftover without seeing the future.
"""
import numpy as np

# Fixed resolution histogram over item sizes 1..100.
_cfg = {"hist": np.zeros(101, dtype=np.float64), "count": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    hist = _cfg["hist"]
    count = _cfg["count"]

    remaining = bins - item
    best_fit = -remaining.astype(np.float64)  # tighter fit => higher score

    if count > 5.0:
        # Smoothed density over residuals 0..100. We treat residual 0 as a perfect
        # fill (always good) and otherwise reward residuals that commonly occur as
        # an item size, since such a leftover slot can be filled exactly.
        dens = hist / count
        # Tiny smoothing to make the reward robust across nearby sizes.
        smooth = dens.copy()
        smooth[1:100] += 0.5 * (dens[0:99] + dens[2:101])
        # reward for reusable residual (exact-ish match to an item size)
        idx = np.clip(remaining, 0, 100)
        reuse_bonus = smooth[idx]
        # exact fill is unambiguously good
        reuse_bonus = reuse_bonus + np.where(remaining == 0, dens.sum() * 0.0, 0.0)
        scale = 60.0  # keep the bonus small relative to best-fit
        score = best_fit + scale * reuse_bonus
    else:
        score = best_fit

    # Update online histogram with this item (decay keeps it adaptive).
    _cfg["hist"] *= 0.999
    hist[item] += 1.0
    _cfg["count"] = count * 0.999 + 1.0

    return score
# EVOLVE-BLOCK-END
