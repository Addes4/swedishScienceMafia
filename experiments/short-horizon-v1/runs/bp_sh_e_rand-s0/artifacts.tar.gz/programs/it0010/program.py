# EVOLVE-BLOCK-START
"""Best fit with distribution-adaptive waste penalty."""
import numpy as np

# Per-stream state
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def _reset():
    global _hist, _count
    _hist = np.zeros(101, dtype=np.float64)
    _count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count

    # Update running histogram of item sizes seen so far in this stream.
    item = int(item)
    _hist[item] += 1.0
    _count += 1.0

    # Estimate recent distribution (recency-weighted decay toward uniform is avoided;
    # simple cumulative histogram is robust for long streams).
    total = _count
    # Compute the median (50th percentile) of observed item sizes.
    cum = np.cumsum(_hist)
    median_size = np.searchsorted(cum, 0.5 * total)  # integer size
    # Waste threshold: residuals smaller than the median observed item are hard to reuse.
    thresh = max(1.0, float(median_size))

    remaining = bins - item
    best_fit = -remaining  # higher is tighter fit

    # Penalize residues that are too small to fit a typical future item.
    waste = np.where((remaining > 0) & (remaining < thresh), remaining, 0)
    return best_fit.astype(np.float64) - 1.5 * waste
# EVOLVE-BLOCK-END

