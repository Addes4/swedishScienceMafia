# EVOLVE-BLOCK-START
"""Harmonic-class matching on top of best fit."""
import numpy as np


def priority(item, bins):
    """Rank bins: best fit, with a strong bonus for a residual in the item's size class.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)

    # Harmonic size class: bins whose leftover is close to the item's own size
    # (within the harmonic window) can be completed by a same-class item.
    # Window shrinks with item size to mirror harmonic partitioning.
    lo = max(1, item // 2 + 1)
    hi = item
    bonus = np.where((remaining >= lo) & (remaining <= hi), 3.0 * item, 0.0)

    return best_fit + bonus
# EVOLVE-BLOCK-END

