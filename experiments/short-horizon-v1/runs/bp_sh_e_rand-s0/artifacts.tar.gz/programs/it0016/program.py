# EVOLVE-BLOCK-START
"""Harmonic-flavored best fit: concentrate items into the fullest fitting bin,
with a light bonus for leaving a class-boundary residual (reusable space)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    best_fit = -remaining  # higher is tighter fit

    # Penalize leaving small leftover residuals (hard-to-reuse capacity).
    waste = np.where((remaining > 0) & (remaining <= 19), remaining, 0)
    score = best_fit.astype(np.float64) - 2.0 * waste

    # Light bonus when the post-placement residual sits on a Harmonic size-class
    # boundary (just below 50, 33, 25, ... of capacity), where leftover space is
    # most reusable by future small items.
    residual = remaining.astype(np.float64)
    boundary_bonus = np.zeros_like(residual)
    for k in (2, 3, 4, 5, 8):
        b = 100.0 / k
        boundary_bonus += np.where(
            (residual <= b) & (residual >= b - k), 1.0, 0.0
        )
    return score + 0.6 * boundary_bonus
# EVOLVE-BLOCK-END

