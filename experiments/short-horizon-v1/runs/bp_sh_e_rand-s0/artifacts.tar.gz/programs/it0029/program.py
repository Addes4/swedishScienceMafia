# EVOLVE-BLOCK-START
"""Harmonic-style bin ranking: class-aware tight packing with best-fit fallback."""
import numpy as np


def priority(item, bins):
    """Return a priority per bin; highest score wins (first on ties).

    item: integer size 1..100.
    bins: numpy int64 remaining capacities of every fitting bin, in bin order.

    Strategy (Harmonic flavored):
    - Classify the arriving item into a size class using thresholds 1/k boundaries
      scaled by capacity 100.
    - Prefer the fullest bin whose post-placement residual is below the class's
      "small-item" bound, so remaining space stays usable by similar-size items.
    - Fall back to pure best fit otherwise.
    """
    capacity = 100.0
    s = float(item)

    # Size class of the arriving item using classic 1/(k+1) style boundaries.
    # classes: (50,100], (33,50], (25,33], (20,25], (16,20], (0,16]
    if s > 50.0:
        cls_bound = 50.0          # large item: keep residual usable for >=~item/2? be tight
    elif s > 33.0:
        cls_bound = 33.0
    elif s > 25.0:
        cls_bound = 25.0
    elif s > 20.0:
        cls_bound = 20.0
    elif s > 16.0:
        cls_bound = 16.0
    else:
        cls_bound = 16.0

    remaining = bins - item
    # Exact fill gets top priority.
    exact = (remaining == 0).astype(np.float64)

    # Compatibility: residual below class bound is "good" (keeps space for a peer item).
    small_resid = ((remaining > 0) & (remaining < cls_bound)).astype(np.float64)

    best_fit = -remaining.astype(np.float64)  # fullest bin (tightest) largest score

    # Layered score: exact fill >> compatible-small-residual >> full best fit.
    return exact * 1e6 + small_resid * 1e3 + best_fit
# EVOLVE-BLOCK-END
