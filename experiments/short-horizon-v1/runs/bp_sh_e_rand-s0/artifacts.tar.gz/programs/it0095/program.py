# EVOLVE-BLOCK-START
"""Best-fit with a small-residual waste penalty and exact-fill bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    # Base: best fit -- higher score means tighter fit.
    score = (-remaining).astype(np.float64)
    # Strong bonus for exact fills.
    score += np.where(remaining == 0, 1000.0, 0.0)
    # Penalize leaving a small, hard-to-reuse residual (wasteful stranded capacity).
    waste = np.where((remaining > 0) & (remaining <= 25), remaining, 0)
    score -= 3.0 * waste
    return score
# EVOLVE-BLOCK-END

