# EVOLVE-BLOCK-START
"""Best fit with online-learned minimum-item-size awareness."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    state = priority.state
    if state is None:
        state = {"min_item": item}
        priority.state = state
    else:
        if item < state["min_item"]:
            state["min_item"] = item

    remaining = bins - item  # post-placement residual, >= 0 for all shown bins

    residual = remaining.astype(np.float64)
    # Best fit: smallest residual is best (most tightly packed).
    score = -residual

    # Mild bonus for exact fill.
    score += np.where(remaining == 0, 0.5, 0.0)

    # Penalize residuals too small to ever be reused (below smallest seen item).
    min_item = state["min_item"]
    too_small = (remaining > 0) & (remaining < min_item)
    score -= too_small * (0.25 * (min_item - remaining))

    return score


priority.state = None
# EVOLVE-BLOCK-END
