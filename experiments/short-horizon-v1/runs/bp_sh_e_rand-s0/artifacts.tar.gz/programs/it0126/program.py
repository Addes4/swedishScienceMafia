# EVOLVE-BLOCK-START
"""Best fit with an adaptive penalty on truly stranded residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit as the base ranking: prefer the bin that ends up fullest.
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)

    # Estimate a low-quantile item size from past items to decide what counts as
    # a stranded (hard-to-reuse) residual.  Default to a conservative small value.
    hist = getattr(priority, "_hist", None)
    if hist is None:
        hist = []
        priority._hist = hist
    q = 5
    if len(hist) >= 20:
        q = int(np.percentile(hist, 10))
        if q < 1:
            q = 1
    hist.append(int(item))

    # Penalize only the tiniest residuals (below the learned low quantile),
    # so we avoid stranding unusable slivers, without the blunt fixed cutoff.
    waste = np.where((remaining > 0) & (remaining < q), remaining, 0)
    return best_fit - 2.0 * waste.astype(np.float64)
# EVOLVE-BLOCK-END

