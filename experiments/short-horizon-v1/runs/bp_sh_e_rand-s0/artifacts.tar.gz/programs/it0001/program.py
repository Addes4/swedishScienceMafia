# EVOLVE-BLOCK-START
"""Hybrid: best-fit with a mild preference toward fuller bins to reduce waste."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual).
    # Secondary: slightly prefer fuller bins (smaller remaining capacity),
    # scaled so it never overrides the tightest-fit ordering.
    return -residual * 1000.0 - bins
# EVOLVE-BLOCK-END
