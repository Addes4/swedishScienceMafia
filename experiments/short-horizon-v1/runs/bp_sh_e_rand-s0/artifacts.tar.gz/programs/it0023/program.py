# EVOLVE-BLOCK-START
"""Best fit with a smooth residual-usefulness tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, first on ties.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of bins the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary signal: best fit (prefer the fullest bin that still fits the item).
    remaining = bins - item

    # Secondary signal: reward residuals that are "useful" (large enough to
    # plausibly hold a future item), while best-fit stays dominant.
    # Concave (sqrt-like) reward so moderate residuals aren't over-rewarded.
    useful = np.sqrt(np.maximum(remaining, 0))

    # Keep unused bins (remaining capacity 100) as a fallback but don't let
    # them dominate; best-fit already makes them low priority via -remaining.
    return (-remaining).astype(np.float64) + 0.5 * useful
# EVOLVE-BLOCK-END
