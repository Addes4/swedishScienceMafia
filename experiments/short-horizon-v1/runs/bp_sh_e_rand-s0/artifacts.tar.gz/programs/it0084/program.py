# EVOLVE-BLOCK-START
"""Scale-aware best fit: prefer tight fits, but avoid leaving unusable slivers.

Items arrive online.  Best fit alone packs tightly but often leaves small
residuals that no future item can fill.  We therefore score each candidate bin
by how tight the fit is, while giving a bonus to bins that end exactly full or
leave a residual large enough to still hold a "typical" item.
"""
import numpy as np

# Running estimate of the item distribution, kept per-process.  It is reset
# implicitly whenever a stream starts because the harness imports a fresh
# module per stream (state only ever needs to be approximate anyway).
_seen = 0
_sum = 0.0

# Coarse size bands used to test whether a residual is "reusable".  These are
# fixed and broad so they generalize across streams rather than overfitting.
_BANDS = (10, 20, 25, 34, 40, 50, 60, 67, 75, 85, 100)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins.

    item: integer item size, 1..100.
    bins: numpy int64 remaining capacities of the fitting bins, in bin order.
    """
    global _seen, _sum
    _seen += 1
    _sum += item
    mean_item = _sum / _seen

    remaining = bins - item  # post-placement residual, >= 0 by construction

    # Base signal: best fit -- tighter fit (smaller residual) scores higher.
    score = -remaining.astype(np.float64)

    # Exact fill is always excellent: finishing a bin costs nothing extra and
    # cannot create waste.
    score += np.where(remaining == 0, 6.0, 0.0)

    # A residual is "reusable" if it could plausibly hold future items.  Use a
    # threshold tied to the running mean item size, snapped to a band so the
    # rule stays smooth and not instance-specific.
    thr = min(max(mean_item * 0.75, 15.0), 45.0)

    # Reward residuals that are large enough to be reused; mildly reward
    # residuals near a band boundary, which tend to stay useful.
    reusable = np.where(remaining >= thr, 1.0, 0.0)
    score += 3.0 * reusable

    # Penalize unusable slivers (positive but below the reuse threshold).
    sliver = np.where((remaining > 0) & (remaining < thr), 1.0, 0.0)
    score -= 2.0 * sliver

    return score
# EVOLVE-BLOCK-END
