# EVOLVE-BLOCK-START
"""Best fit with a "dominant residual" bonus: leave a residual equal to the item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    # Base: best fit (tighter post-placement residual is better).
    score = -remaining.astype(np.float64)
    # Bonus when the leftover exactly equals the item size: a same-size item
    # would then fill this bin completely, which is very efficient.
    score += 3.0 * (remaining == item)
    return score
# EVOLVE-BLOCK-END

