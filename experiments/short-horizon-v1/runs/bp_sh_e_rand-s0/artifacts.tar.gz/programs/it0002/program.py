# EVOLVE-BLOCK-START
"""Best-fit with a light preference for keeping bins open (fuller bins)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best fit: prefer the smallest residual.
    score = -residual.astype(np.float64)
    # Small bonus for placing into bins that are already relatively full
    # (small remaining capacity), to consolidate load and reduce fragmentation.
    score += 0.05 * (100 - bins)
    return score
# EVOLVE-BLOCK-END
