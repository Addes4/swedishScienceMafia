# EVOLVE-BLOCK-START
"""Best fit with a mild residue-utility adjustment to avoid unusable leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    # Primary signal: best fit (tighter leftover preferred).
    best_fit = -remaining.astype(np.float64)
    # Small residual (but not zero) is dead space: penalize it mildly.
    # Zero residual is perfect; residuals >= ~small-item size are reusable.
    tiny = np.where((remaining > 0) & (remaining <= 9), remaining.astype(np.float64), 0.0)
    return best_fit - 1.5 * tiny
# EVOLVE-BLOCK-END

