# EVOLVE-BLOCK-START
"""Best fit with an online-learned residual-usability tie-breaker."""
import numpy as np


def priority(item, bins):
    """Rank bins: tight fit, but prefer residuals that can still fit future items."""
    # Best fit base: tightest residual (smallest remaining) ranks highest.
    remaining = bins - item
    best_fit = -remaining.astype(np.float64)

    # Online empirical CDF of item sizes seen so far. We keep a histogram over
    # sizes 1..100 so we can estimate P(future item fits in a given residual).
    counts = priority.counts
    total = priority.total

    if total == 0:
        # No history yet: pure best fit with an exact-fill nudge.
        return best_fit

    # Survival function: fraction of seen items with size <= r, for each residual.
    cdf = np.cumsum(counts) / total  # cdf[r-1] = P(item <= r)

    # Cap residuals at 100 (unused bins have residual up to 100 - item).
    r = np.clip(remaining, 0, 100)
    # For residual 0, no future item fits; for r>0, P(fit) ~ cdf[r-1].
    p_fit = np.where(r >= 1, cdf[np.maximum(r - 1, 0)], 0.0)

    # Strongly favor tight fits; break ties/uncertainty by residual usability so
    # we avoid stranding small unusable leftovers.
    return best_fit + 5.0 * p_fit


# State container for online statistics (per stream, reset by the harness).
priority.counts = np.zeros(101, dtype=np.float64)
priority.total = 0.0
# EVOLVE-BLOCK-END
