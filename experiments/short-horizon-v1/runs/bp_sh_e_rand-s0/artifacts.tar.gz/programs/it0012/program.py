# EVOLVE-BLOCK-START
"""Best-fit with active-bin concentration when residual stays small."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item
    # Pure best fit as the dominant ranking.
    best_fit = (100 - remaining).astype(np.float64)  # higher = tighter fit
    # Bonus: strongly prefer the fullest bin that still fits, but only when placing
    # this item leaves a small residual (<= 20), since that residual is likely to be
    # filled by a future small item. This concentrates packing without creating waste.
    small_residual = (remaining >= 0) & (remaining <= 20)
    active_bonus = np.where(small_residual, 100.0, 0.0)
    return best_fit + active_bonus
# EVOLVE-BLOCK-END

