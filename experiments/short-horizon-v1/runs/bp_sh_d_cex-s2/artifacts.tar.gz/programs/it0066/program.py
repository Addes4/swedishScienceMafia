# EVOLVE-BLOCK-START
"""Best-fit with residual quantization: avoid stranding sub-item-size slivers."""
import numpy as np

_MEAN = 40.0
_SLIVER = 20.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # post-placement remaining capacity, all >= 0

    # Base: prefer tightest fit (smallest residual) -> strongest single signal.
    # Adjustment: penalize residuals that are positive but smaller than a typical
    # item (~20-40), since those slivers are hard to reuse. Slightly prefer
    # residuals near 0 or near a multiple of the mean item size (reusable slack).
    sliver_pen = np.where((residual > 0) & (residual < _SLIVER), 1.0, 0.0)
    # distance to nearest multiple of mean, normalized
    k = np.round(residual / _MEAN)
    near_mult = np.abs(residual - k * _MEAN) / _MEAN

    score = -residual.astype(float) - 8.0 * sliver_pen - 1.5 * near_mult
    return score
# EVOLVE-BLOCK-END
