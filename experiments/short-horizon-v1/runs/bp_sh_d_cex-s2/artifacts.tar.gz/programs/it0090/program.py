# EVOLVE-BLOCK-START
"""Best fit with an online "residual reuse" bonus.

Pure best fit puts the item in the bin with the smallest residual capacity after
placement. That is already strong, but it can strand tiny unusable gaps. Here we
keep best fit as the dominant term and add a small bonus when the residual after
placement is exactly 0, or exactly matches a size that has been seen frequently
in the stream (so the gap can likely be filled later).

State (histogram of item sizes, exponential decayed) is updated once per call,
before scoring, using only past items -- no lookahead.
"""
import numpy as np

# Exponential decay factor for the online size histogram.
_DECAY = 0.999
# Bonus magnitude for a "reusable" residual (kept well below 1 so best-fit
# ordering is essentially preserved on non-degenerate instances).
_BONUS = 0.30

# Module state: decayed counts of observed item sizes (index = size 1..100).
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    global _hist

    # Update the (decayed) histogram of item sizes with the current item.
    _hist *= _DECAY
    _hist[item] += 1.0

    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item

    # Dominant term: best fit (smaller residual -> higher score).
    score = -residual.astype(np.float64)

    # Reuse bonus: reward residuals that are exactly 0, or that exactly match a
    # frequently seen item size (so the leftover gap is likely to be filled).
    # Normalize histogram weights into [0, 1].
    total = _hist.sum()
    if total > 0.0:
        h = _hist / total
    else:
        h = _hist

    # Frequency of the residual size, for residuals in the valid 0..100 range.
    in_range = (residual >= 0) & (residual <= 100)
    freq = np.zeros_like(residual, dtype=np.float64)
    if np.any(in_range):
        freq[in_range] = h[residual[in_range]]

    # Normalize the frequency term to roughly [0, 1] using a reference scale:
    # a residual seen with ~1/100 of mass is "common".
    score += _BONUS * (freq / 0.01).clip(0.0, 1.0)

    # Exact fill gets a decisive (but still bounded) nudge.
    score += _BONUS * (residual == 0)

    return score
# EVOLVE-BLOCK-END
