# EVOLVE-BLOCK-START
"""Best fit with a tiny near-tie preference for larger residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    rmin = residual.min()
    # Near-ties within 1 unit of the minimum: prefer the larger residual among them,
    # so we delay creating exactly-zero-residual (fully packed) bins.
    priority = np.where(residual <= rmin + 1, residual.astype(np.float64), -1e9 - residual)
    return priority
# EVOLVE-BLOCK-END
