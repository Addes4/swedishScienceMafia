# EVOLVE-BLOCK-START
"""Harmonic-style rule: bucket post-placement residuals by harmonic class,
then best-fits within the tightest admissible class."""
import numpy as np

# Harmonic class boundaries. Residuals r (post-placement) are bucketed into
# geometrically widening intervals so that near-full bins are preferred, but
# among roughly equivalent residuals we still take the tightest fit.
_CUTS = np.array([0, 15, 30, 45, 60, 80, 101], dtype=np.int64)
_NCLASS = len(_CUTS) - 1


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # residual after placing item (>= 0 for fitting bins)
    # Class index: smaller residual -> smaller class index.
    cls = np.searchsorted(_CUTS, residual, side='right') - 1
    cls = np.clip(cls, 0, _NCLASS - 1)
    # Prefer the smallest class, and within a class the smallest residual.
    return -cls * 1000 - residual
# EVOLVE-BLOCK-END
