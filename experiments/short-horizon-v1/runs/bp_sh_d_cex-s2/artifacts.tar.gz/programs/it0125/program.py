# EVOLVE-BLOCK-START
"""Harmonic-flavored best fit tuned for Weibull(mean~40) item sizes."""
import numpy as np


def priority(item, bins):
    residual = bins - item  # post-placement residual, >= 0 guaranteed by harness
    if item >= 50:
        # Big item: tightest fit is optimal-ish.
        return -residual.astype(np.float64)

    # Smaller item: prefer placing it where it still leaves room for a future
    # big item (residual >= 50), choosing the tightest such residual.
    # If no bin qualifies, fall back to plain best fit.
    big_room = residual >= 50
    score = np.where(
        big_room,
        -residual.astype(np.float64),      # tight fit among qualifying bins
        -1e6 - residual.astype(np.float64),  # strongly discourage others
    )
    return score
# EVOLVE-BLOCK-END
