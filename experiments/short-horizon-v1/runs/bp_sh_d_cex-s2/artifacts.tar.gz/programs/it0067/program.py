# EVOLVE-BLOCK-START
"""Best fit with a mild residual-reusability tie-break (stateful)."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Rank bins; the item goes to the highest score (first on ties).

    Historically best-fit alone matched the best known result. We keep best-fit as the
    primary signal (smallest post-placement residual), but break near-ties using a
    stateful estimate of the mean item size so that we avoid stranding residuals just
    below a typical item size, which wastes capacity in long streams.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]
    # Typical item size, used as the minimum reusable residual we like to keep.
    tau = max(1.0, mean)

    residual = bins - item  # post-placement residual (>= 0 for all shown bins)

    # Primary: best fit -> smaller residual is better.
    # Secondary: prefer residuals that are exactly 0 or at least tau (reusable),
    # penalize residuals strictly inside (0, tau) which tend to be stranded.
    stranded = (residual > 0) & (residual < tau)
    penalty = stranded.astype(np.float64) * (tau - residual)

    return -residual.astype(np.float64) - penalty
# EVOLVE-BLOCK-END
