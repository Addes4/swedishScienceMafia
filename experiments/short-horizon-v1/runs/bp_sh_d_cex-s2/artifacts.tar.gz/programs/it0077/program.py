# EVOLVE-BLOCK-START
"""Almost-worst-fit: spread items across bins while avoiding tiny residual gaps."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["sum"] += item
    _state["n"] += 1
    mean_item = _state["sum"] / _state["n"]

    residual = bins - item  # capacity left after placing the item

    # Prefer bins that leave a residual large enough to be useful, but otherwise
    # favor keeping bins open (large remaining capacity) to spread the load.
    # Bins that would leave a very small residual are penalized.
    threshold = max(1.0, 0.5 * mean_item)
    usable = (residual >= threshold).astype(np.float64)

    # Primary: large remaining capacity (worst-fit) among "usable" placements.
    # Score: remaining capacity, plus a big bonus when residual is usable,
    # and a mild preference for larger residual.
    score = bins.astype(np.float64) + usable * 1000.0
    return score
# EVOLVE-BLOCK-END
