# EVOLVE-BLOCK-START
"""Best-fit with a near-exact-fit preference to seal dense bins earlier."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since bins only contains fitting bins

    # Small threshold: gaps this small are unlikely to be useful again,
    # so prefer to place items where the leftover is very small.
    small = 4
    # Strongly prefer bins that would be left with a tiny residual.
    near = residual <= small

    # Base score: best-fit (smaller residual is better).
    score = -residual.astype(np.float64)

    # Boost near-exact fits so they get sealed off before the gap is wasted.
    score[near] += 1000.0 - residual[near].astype(np.float64)

    return score
# EVOLVE-BLOCK-END
