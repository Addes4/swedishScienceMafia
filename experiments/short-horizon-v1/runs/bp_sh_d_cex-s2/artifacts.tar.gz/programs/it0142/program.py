# EVOLVE-BLOCK-START
"""Best-fit with a small-residual rejection band driven by running item statistics."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    post = bins - item  # remaining capacity after placing the item

    # Score: smaller post-placement residual is better (best fit).
    # But reject residuals that are too small to usefully accept a future item:
    # if a bin would be left with a tiny residual, prefer a slightly larger one.
    score = -post.astype(np.float64)

    # A residual below this is "wasted" (unlikely to accept a typical item).
    # Use a fixed small threshold based on the min item size (1), padded a bit.
    wasted = post < 1
    score[wasted] -= 1000.0

    return score
# EVOLVE-BLOCK-END
