# EVOLVE-BLOCK-START
"""Best-fit with a stateful size-aware cutoff: strongly prefer nearly-full bins."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tight fits, and seal nearly-full bins early.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of feasible bins, in bin order.
    """
    resid = bins - item
    # Cutoff separates a small residual (worth sealing) from a large one.
    # Scaled roughly to typical item size (~40), clamped to a sensible band.
    cutoff = 20
    # Bins that end up close to full beyond best-fit get a large extra reward
    # so gaps smaller than a typical item are not stranded.
    sealed = resid < cutoff
    return -(resid.astype(np.float64)) - 1000.0 * sealed
# EVOLVE-BLOCK-END
