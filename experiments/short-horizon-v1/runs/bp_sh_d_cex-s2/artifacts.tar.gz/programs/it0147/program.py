# EVOLVE-BLOCK-START
"""Best-fit backbone with a distribution-aware residual scoring for gap filling."""
import numpy as np


def priority(item, bins):
    """Prioritize bins by best fit, with a bonus for residuals likely to be exactly filled.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Exact fill is always best: residual zero.
    residual = bins - item

    # Score: primary is small residual (best-fit). Bonus rewards residuals that are
    # likely to be filled exactly by one future item. We estimate that probability with
    # a smooth unimodal density peaked near a fixed typical size (mean ~40), which is
    # robust across instances of the Weibull-shaped distribution.
    # Fields:
    #   - best fit term: -residual
    #   - gap-fill term: density-like score peaking around residual ~ 40
    mu = 40.0
    sigma = 22.0
    fill = np.exp(-((residual - mu) ** 2) / (2.0 * sigma * sigma))

    # Strong preference for exact fills.
    exact = (residual == 0).astype(np.float64) * 1000.0

    # Small weight on fill so it only breaks near-ties in best-fit.
    return -residual.astype(np.float64) + 8.0 * fill + exact
# EVOLVE-BLOCK-END
