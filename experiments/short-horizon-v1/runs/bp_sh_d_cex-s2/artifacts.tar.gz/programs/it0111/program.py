# EVOLVE-BLOCK-START
"""Best fit with a guard against stranding small unusable gaps."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tight fits that don't leave a tiny unusable residual."""
    residual = bins - item  # remaining capacity after placing the item
    # Bins that fit exactly (residual 0) are ideal; slightly larger residuals
    # waste space. Penalize residuals in the "stranded gap" zone (1..item-1)
    # because those gaps typically can't fit any later item of similar size,
    # but do so only mildly so best-fit ordering is preserved for larger gaps.
    gap_penalty = np.where(
        (residual > 0) & (residual < item),
        residual.astype(np.float64) * 0.02,
        0.0,
    )
    score = -(residual.astype(np.float64) + gap_penalty)
    # Tie-break: earlier bins win by default (harness uses first max).
    return score
# EVOLVE-BLOCK-END
