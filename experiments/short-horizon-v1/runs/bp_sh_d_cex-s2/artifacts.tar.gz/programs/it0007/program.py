# EVOLVE-BLOCK-START
"""Best fit with a small-sliver avoidance rescue.

Pure best fit is strong on average but occasionally creates tiny residuals
(1..few units) that can never hold another item, wasting capacity on long
streams.  This rule keeps exact best fit as the default and only diverts when
the tightest fit would leave a residual that is both small and unlikely to be
reusable, and when another bin leaving a residual near the running mean item
size is available at only slightly worse tightness.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    n = _state["n"] + 1
    _state["n"] = n
    _state["sum"] += item
    mean = _state["sum"] / n

    residual = bins - item  # capacity left after placing item here
    # Primary score: tighter fit (smaller residual) is better.
    score = -residual.astype(np.float64)

    # Rescue: penalize residuals that are small, non-zero slivers smaller than
    # a fraction of the mean item size, since they are typically unusable.
    thr = max(1.0, 0.15 * mean)
    tiny = (residual > 0) & (residual < thr)
    # Mild penalty scaled by how tiny the sliver is.
    score -= tiny * (thr - residual) * 0.5

    # Also mildly penalize very large residuals (wasteful full bins) so the
    # remaining items get a chance to fit better later.
    big = residual > 75.0
    score -= big * (residual - 75.0) * 0.02

    # Nudge toward residuals near the mean (likely reusable) among similar fits
    score -= 0.03 * np.abs(residual - mean)

    return score
# EVOLVE-BLOCK-END
