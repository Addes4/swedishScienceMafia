# EVOLVE-BLOCK-START
"""Best fit with a fill-fraction bonus to reduce stranded small gaps.

Idea: pure best fit leaves many bins with a small residual that future large
items cannot use.  By modestly preferring fuller bins (higher fill fraction),
we consolidate small items into already-full bins and keep emptier bins
available for the large items, which reduces the number of bins on
Weibull-shaped streams (mean ~40).
"""
import numpy as np


def priority(item, bins):
    residual = bins - item            # post-placement residual, >= 0
    fill = bins.astype(np.float64)    # pre-placement remaining capacity
    # Prefer smaller residual (best fit) but add a tiny reward for fuller bins.
    # reward ~ -residual scaled, bonus pushes toward fuller bins without
    # overriding best-fit ordering by much.
    return -residual - 0.05 * (100.0 - fill)
# EVOLVE-BLOCK-END

