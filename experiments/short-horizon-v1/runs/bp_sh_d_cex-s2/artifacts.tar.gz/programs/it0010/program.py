# EVOLVE-BLOCK-START
"""Best-fit with residual sweet-spot tie-break.

Primary rule: tightest fit (minimize residual after placement), but among bins whose
residual is within a small tolerance of the minimum, prefer the bin whose post-placement
residual is closest to a target value near the mean item size. This avoids collapsing
many bins to zero residual slivers in a way that still packs tightly.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for every bin shown
    # Primary: tightest fit -> smaller residual scores higher.
    primary = -residual.astype(np.float64)
    # Small bounded tie-break: prefer residuals near a sweet spot (scaled by item size).
    target = 0.5 * item + 15.0
    tie = -np.abs(residual.astype(np.float64) - target) / 100.0
    return primary + 1e-3 * tie
# EVOLVE-BLOCK-END
