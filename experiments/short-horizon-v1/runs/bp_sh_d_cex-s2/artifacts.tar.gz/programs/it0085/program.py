# EVOLVE-BLOCK-START
"""Best fit with a mild preference against stranding tiny residuals.

The classic best-fit rule sends the item to the bin with the smallest post-placement
residual.  That is usually near-optimal, but it can strand many tiny unusable gaps
(e.g. residual 1..3) while a slightly looser bin would keep a reusable gap.

We keep pure ordering by residual, but add a tiny monotone bonus for larger residuals
inside a small window around the minimum.  Bins with residual equal to the minimum keep
priority; bins with residuals a little larger but still small enough to be "reusable"
get a marginal boost so they are chosen instead when the tightest one would strand an
essentially unusable sliver.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # post-placement remaining capacity, >= 0 for fitting bins

    # Pure best fit base score: larger residual -> lower priority.
    score = -residual.astype(np.float64)

    # A tiny windowed bonus for residuals that are "reusable" (>= item/2 roughly),
    # but only when they are within a small distance of the tightest fit, so we do
    # not disturb the global best-fit behaviour in most cases.
    rmin = residual.min()
    thresh = rmin + max(1.0, 0.5 * item)
    reusable = (residual >= max(1.0, 0.5 * item)) & (residual <= thresh)
    score += reusable.astype(np.float64) * 1e-3

    return score
# EVOLVE-BLOCK-END
