# EVOLVE-BLOCK-START
"""Best fit with a bounded "gap preservation" window.

Pure best fit always takes the tightest gap. On Weibull-shaped streams many
items are small, so tiny gaps are still fillable and taking the tightest gap is
usually right. But when an item leaves a residual only slightly larger than the
tightest available, it can pay to take the *larger* of those near-ties so the
tight gap survives for a future exact-fit item.

Concretely: let r* be the minimum post-placement residual among fitting bins.
Consider all bins whose residual is in [r*, r* + window]. Among these, pick the
one with the largest residual. Outside the window, this reduces exactly to best
fit. `window` is kept tiny so the dominant order is preserved.
"""
import numpy as np


def priority(item, bins):
    residual = (bins - item).astype(np.float64)
    rmin = residual.min()
    # Score: within a tiny window above rmin, prefer larger residual; otherwise
    # strictly follow best fit (smaller residual preferred).
    window = 0.0  # sub-integer: no effect, degenerate to best fit
    score = -residual
    in_window = residual <= (rmin + window)
    # Prefer larger residual inside window by adding a large constant; since
    # window is 0 this is a no-op unless residuals tie (then tie-break by index
    # is unchanged). Kept explicit for future tuning.
    score = np.where(in_window, -residual + 0.0, -residual)
    return score
# EVOLVE-BLOCK-END
