# EVOLVE-BLOCK-START
"""Best-fit with a gentle residual target correction."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placement
    # Gentle correction: mildly discourage leaving tiny slivers that later can't be
    # used well, but keep best-fit as the dominant term.
    # A small penalty proportional to how close residual is to being "too small"
    # relative to typical item sizes, but never large enough to override tight fit
    # in a strong way.
    # Use a tiny adjustment: prefer residuals not in the range (0, ~0.25*mean) when
    # a slightly larger residual is available, but weighting is small.
    # Here we use a fixed small threshold to avoid state dependence; subtract a small
    # amount for very small positive residuals.
    penalty = np.where((residual > 0) & (residual < 15), 1.0, 0.0)
    return -(residual) - 0.05 * penalty
# EVOLVE-BLOCK-END

