# EVOLVE-BLOCK-START
"""Fullest-fit: put the item in the bin that is fullest but still fits it.

Equivalent to always choosing the smallest remaining capacity that is >= item,
which drives bins toward being completely filled before a new bin is opened.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Prefer the bin with the smallest remaining capacity (fullest bin).
    return -bins
# EVOLVE-BLOCK-END
