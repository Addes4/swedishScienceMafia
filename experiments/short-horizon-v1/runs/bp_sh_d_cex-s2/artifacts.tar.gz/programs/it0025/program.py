# EVOLVE-BLOCK-START
"""Best fit with a small-residual penalty.

Primary key: smallest post-placement residual (classic best fit).
Tie-break within a small window: prefer residuals that are either 0 (perfect fill)
or >= ~11 (large enough to hold a typical small item), penalizing residuals in the
"dead zone" (1..10) that are unlikely to be usable by future items.
"""
import numpy as np

_DEAD = 10  # residuals 1.._DEAD are considered hard to reuse


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, bin order.
    """
    resid = bins - item  # >= 0 guaranteed by the harness

    # Base: prefer tightest fit (largest negative residual).
    score = -resid.astype(np.float64)

    # Penalize placements whose leftover lands in the unusable dead zone,
    # but only relative to better leftovers, so primary ordering stays intact.
    dead = (resid > 0) & (resid <= _DEAD)
    score -= dead.astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
