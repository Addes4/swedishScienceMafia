# EVOLVE-BLOCK-START
"""Best-fit with a bias against opening fresh bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # what's left after placing the item

    # Best-fit primary key: smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize using a completely empty bin (capacity 100) so we consolidate
    # into already-opened bins whenever a reasonable fit exists.
    empty = (bins >= 100)
    if empty.any() and (~empty).any():
        # If some opened bin exists, subtract a penalty from empty-bin scores.
        score = score - empty * 50.0

    return score
# EVOLVE-BLOCK-END
