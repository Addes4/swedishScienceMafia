# EVOLVE-BLOCK-START
"""Best fit with a "keep-it-usable" tie-break.

Prefer the tightest fit, but avoid stranding tiny unusable residuals when an
equally good (or nearly equally good) fit exists that keeps room for at least
one more item of the current item's size.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of bins the item fits in.
    """
    residual = bins - item  # remaining capacity after placing the item

    # A residual is "good" if it is exactly 0 (perfect fill) or can still hold
    # at least one more item of this item's size.
    good = (residual == 0) | (residual >= item)

    # Primary key: prefer tight fits (small residual). Secondary key: prefer
    # good residuals over stranded small ones.
    return -residual.astype(np.float64) - 0.001 * (~good)
# EVOLVE-BLOCK-END
