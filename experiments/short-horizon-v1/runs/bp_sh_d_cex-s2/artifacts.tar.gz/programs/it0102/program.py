# EVOLVE-BLOCK-START
"""Adaptive residual-target rule for online bin packing.

We keep best-fit as the backbone but bias toward leaving a residual close to a
representative recent item size, so that stranded tiny gaps (the classic failure of
best-fit) are avoided: a residual of e.g. 37 can still accept a future item of size
~37, whereas a residual of 2 cannot.
"""
import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.mean = 40.0
        self.samples = []


_state = _State()


def _update(item):
    s = _state
    s.count += 1
    s.mean += (item - s.mean) / s.count
    if len(s.samples) < 512:
        s.samples.append(item)
    else:
        # reservoir-ish: occasionally drop an old sample
        if s.count % 8 == 0:
            s.samples[(s.count // 8) % 512] = item


def _target():
    s = _state
    if len(s.samples) >= 16:
        a = np.asarray(s.samples, dtype=np.float64)
        # representative future item size: a moderate quantile of recent sizes
        q = np.quantile(a, 0.55)
        if q < 1.0:
            q = 1.0
        return q
    return 40.0


def priority(item, bins):
    _update(item)

    residual = bins - item
    target = _target()

    # Best-fit backbone: strongly prefer the smallest residual.
    score = -residual.astype(np.float64)

    # Extra credit when the residual is close to a typical future item size,
    # which is where a later item can still fit and close the bin.
    d = np.abs(residual - target)
    bonus = 1.0 / (1.0 + d)  # in (0, 1]
    score += 0.75 * bonus

    return score
# EVOLVE-BLOCK-END
