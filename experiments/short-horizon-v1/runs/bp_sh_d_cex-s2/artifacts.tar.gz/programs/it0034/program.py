# EVOLVE-BLOCK-START
"""Best fit with a residual-consolidation epsilon tie-break.

The primary key is the post-placement residual (bins - item): smaller is better,
which is the classic best-fit rule and already very strong (0.9727). The only
freedom left is tie-breaking. Two bins can only tie when they have equal
remaining capacity, in which case any choice is equivalent for the current item,
but the *bin index* order determines which we pick. To nudge the packing toward
consolidation we add a sub-epsilon term that prefers the bin with the smaller
index-independent remaining capacity; since ties already imply equal capacity
this is a no-op numerically, so instead we use a genuinely useful secondary
signal: among bins with (nearly) equal post-placement residual, prefer the one
whose *pre-placement* remaining capacity was larger, i.e. the bin we are filling
more fully relative to its own state -- this consolidates load and reduces
proliferation of partially-filled bins.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Primary: tightest fit (smallest residual) -> most negative is best.
    primary = -residual
    # Secondary: prefer bins that were already closer to full before the item
    # (smaller `bins`), so equal-residual ties consolidate rather than spread.
    secondary = -bins.astype(np.float64) * 1e-6
    return primary.astype(np.float64) + secondary
# EVOLVE-BLOCK-END
