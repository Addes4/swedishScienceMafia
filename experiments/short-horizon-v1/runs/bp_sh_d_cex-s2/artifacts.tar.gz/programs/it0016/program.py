# EVOLVE-BLOCK-START
"""Best fit with a small-residual tie-break that keeps future-friendly residuals."""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.int64), "n": 0}


def priority(item, bins):
    """Rank bins; item goes to the highest score (first wins ties).

    Primary: best fit (minimize post-placement residual = bins - item).
    Tie-break: among bins with (near-)equal residual, prefer one whose residual is
    a "useful" size (one that matches a frequently seen item size), so the leftover
    bin can later be filled exactly, while avoiding tiny 1..3 gaps.
    """
    counts = _state["counts"]
    n = _state["n"]
    counts[item] += 1
    _state["n"] = n + 1

    residual = bins - item  # >= 0 since bins only contains fitting bins

    # Best fit primary key: smaller residual is better.
    score = -residual.astype(np.float64)

    # Build a usefulness bonus for each possible residual, from the observed
    # frequencies of item sizes. Scale so it only breaks (near-)ties.
    # bonus[r] = frequency of item size r (normalized), with a penalty for
    # very small gaps (1..3) that tend to be wasted.
    freq = counts / max(n + 1, 1)
    bonus_table = freq.astype(np.float64).copy()  # index by residual 0..100

    # discourage tiny unusable gaps
    tiny_pen = 0.0
    for r in (1, 2, 3):
        bonus_table[r] -= 0.4 * freq.max() if freq.max() > 0 else 0.0

    # recompute tiny_pen unused variable removal
    res_clipped = np.clip(residual, 0, 100)
    tie_bonus = bonus_table[res_clipped]

    # tie_bonus is at most ~1; scale so it can reorder within 1 unit of residual
    score = score + 0.5 * tie_bonus
    return score
# EVOLVE-BLOCK-END
