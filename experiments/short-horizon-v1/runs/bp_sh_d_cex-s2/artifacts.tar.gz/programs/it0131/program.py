# EVOLVE-BLOCK-START
"""Best fit with a running-mean-aware tweak: prefer residuals near a typical future item."""
import numpy as np


class _State:
    n = 0
    total = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state.n += 1
    _state.total += item
    mean = _state.total / _state.n

    residual = bins - item  # >= 0 for all bins shown

    # Best-fit base: prefer smallest residual.
    # Add a small bonus when the residual is close to the running mean item size,
    # so bins end up able to host a typical future item rather than a sliver.
    # Bonus magnitude stays small so it only breaks near-ties.
    closeness = np.abs(residual - mean)
    return -residual - 0.001 * closeness
# EVOLVE-BLOCK-END
