# EVOLVE-BLOCK-START
"""Best fit with a residual-aware convex cost tuned online."""
import numpy as np


class _State:
    n = 0
    s = 0.0
    s2 = 0.0


_state = _State()


def priority(item, bins):
    st = _state
    st.n += 1
    st.s += item
    st.s2 += item * item

    b = bins.astype(np.float64)
    r = b - item  # residual after placing the item

    # Running statistics of item size.
    mean = st.s / st.n
    var = max(st.s2 / st.n - mean * mean, 0.0)
    std = var ** 0.5

    # Target residual: we'd like to leave room for a typical item, but not waste space.
    # A convex penalty on residual below ~mean/(1+std/mean) discourages unusable slivers,
    # while still preferring tighter fits above that.
    if mean <= 0:
        return -r

    # Scale: prefer residuals near a "usable" magnitude u = mean, penalize small ones.
    u = mean
    # Convex in the sliver region (r < u): cost grows as r decreases.
    # Above u: mildly prefer smaller r (tightness).
    # Combine into a monotone-ish score: score = tightness - penalty(small r).
    tight = -r

    # Penalty for residuals that are too small to be useful (< ~0.5*mean).
    thr = 0.5 * u
    pen = np.where(r < thr, (thr - r) ** 2 / (u * u + 1e-9), 0.0)

    return tight - pen
# EVOLVE-BLOCK-END
