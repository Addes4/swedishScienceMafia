# EVOLVE-BLOCK-START
"""Best fit with a harmonic-residual bias learned from the stream."""
import numpy as np


class _State:
    def __init__(self):
        # empirical histogram of item sizes (1..100), Laplace-smoothed
        self.hist = np.ones(101, dtype=np.float64)
        self.n = 0

    def observe(self, item):
        self.hist[item] += 1.0
        self.n += 1


_state = _State()


def priority(item, bins):
    """Best fit, with a small bias toward residuals that match common item sizes."""
    _state.observe(item)

    residual = bins - item  # remaining capacity after placing item

    # Best-fit core: prefer smaller residual (tight fit).
    score = -residual.astype(np.float64)

    # Frequency-based bias: reward residual of 0 or residuals equal to a likely
    # future item size, so that leftover space can be filled exactly later.
    total = _state.hist.sum()
    freq = _state.hist / total  # probability mass per size

    # Map residual (0..100) to its histogram frequency; residual 0 gets a strong bonus.
    r = residual.astype(np.int64)
    valid = (r >= 0) & (r <= 100)
    f = np.zeros_like(score)
    f[valid] = freq[r[valid]]

    # Weight: keep best-fit dominant, add a modest bonus for reusable residuals.
    score += 2.0 * f
    # Explicitly favor exactly-full bins.
    score += (residual == 0).astype(np.float64) * 1.0

    return score
# EVOLVE-BLOCK-END
