# EVOLVE-BLOCK-START
"""Best fit with a mild penalty for opening brand-new bins on exact ties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary term is best fit: minimize the residual capacity (bins - item).
    A tiny secondary term discourages placing an item into a completely unused bin
    (remaining capacity 100) when some already-used bin is an equally tight fit,
    which avoids wasting a fresh bin's capacity on a perfect-fit accident.
    """
    residual = bins - item
    # Dominant best-fit ordering.
    score = -residual.astype(np.float64)
    # Tiny nudge: an unused bin (capacity 100) is slightly less attractive on exact ties.
    score -= 1e-3 * (bins == 100)
    return score
# EVOLVE-BLOCK-END
