# EVOLVE-BLOCK-START
"""Best-fit with a stateful "open bin" reservation.

The default ranking is classic best-fit (place into the fitting bin that leaves the
smallest residual capacity).  On top of that we keep one *open* bin index: while the
current item still fits in the open bin and does not overfill it to the point that
the resulting residual is too small to be useful (compared against a running EMA of
item sizes), we strongly prefer the open bin.  This consolidates fill and reduces
fragmentation; when the open bin is exhausted we simply best-fit as usual.

State is per-stream (the harness starts a fresh module for each stream).
"""
import numpy as np

_EMA = None
_ALPHA = 0.02
_OPEN = None


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties go to first."""
    global _EMA, _OPEN

    if _EMA is None:
        _EMA = float(item)
    else:
        _EMA = (1.0 - _ALPHA) * _EMA + _ALPHA * float(item)

    n = bins.shape[0]
    residual = bins - item

    # Base: best-fit ordering.
    score = -(residual.astype(np.float64))

    # Consolidation: strongly prefer the currently open bin when it is still
    # comfortably usable (leaves at least ~one average item's worth of space).
    usable = residual >= max(1.0, 0.5 * _EMA)
    if _OPEN is not None and 0 <= _OPEN < n and usable[_OPEN]:
        score[_OPEN] += 2.0
    else:
        # choose a new open bin: tightest best-fit that remains usable
        cand = np.where(usable)[0]
        if cand.size:
            _OPEN = int(cand[np.argmin(residual[cand])])
        else:
            _OPEN = int(np.argmin(residual)) if n else None

    return score
# EVOLVE-BLOCK-END
