# EVOLVE-BLOCK-START
"""Complementary best fit: tight packing with a small bonus for reusable leftovers."""
import numpy as np


def priority(item, bins):
    """Rank bins: minimize residual (best fit), lightly prefer reusable leftovers.

    Residual after placing the item is r = bins - item. Best fit minimizes r.
    We add a small penalty when r is a "sliver" (too small to be useful) and a
    small reward when r is near a typical item size, so leftover space stays
    reusable. Best fit remains dominant.
    """
    residual = bins - item

    # Typical item size around 40 (distribution mean). Reusable leftovers
    # are those at least a small threshold; prefer residuals near the mean.
    mean = 40.0
    # Penalize tiny slivers and reward residuals close to a typical item size.
    # Scale kept small relative to residual (which ranges 0..100) so that
    # best-fit ordering is preserved unless residuals are nearly equal.
    sliver = residual < 5  # e.g. 1..4 leftover is usually wasted
    near_mean = -np.abs(residual - mean)

    score = -residual.astype(np.float64)
    score += 0.5 * near_mean / mean          # gentle nudge toward reusable
    score -= 1000.0 * sliver.astype(np.float64)  # avoid unusable slivers

    return score
# EVOLVE-BLOCK-END
