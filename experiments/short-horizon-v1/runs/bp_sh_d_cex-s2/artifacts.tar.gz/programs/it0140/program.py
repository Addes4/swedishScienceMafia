# EVOLVE-BLOCK-START
"""Hybrid rule: best-fit with a future-completion bonus derived from an online
size-frequency table of the observed item stream."""
import numpy as np

# Running histogram of observed item sizes (1..100). Index 0 unused.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _COUNT

    # score each bin
    # post-placement residual
    r = bins - item  # elementwise; all bins shown already fit the item

    # completion bonus: how likely is residual r to be exactly a future item size?
    if _COUNT > 0:
        freq = _HIST / _COUNT
    else:
        freq = np.zeros(101, dtype=np.float64)

    # probability mass that residual r will be exactly matched later
    idx = np.clip(r, 0, 100).astype(np.int64)
    p_match = freq[idx]

    # exact fill is best; then high match probability; then tightest fit
    bonus = 3.0 * p_match + 1000.0 * (idx == 0)

    score = bonus - 0.01 * r

    # update statistics with the current item
    _HIST[item] += 1.0
    _COUNT += 1.0

    return score
# EVOLVE-BLOCK-END
