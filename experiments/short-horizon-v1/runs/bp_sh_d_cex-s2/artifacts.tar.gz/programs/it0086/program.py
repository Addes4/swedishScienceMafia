# EVOLVE-BLOCK-START
"""Best fit with consolidation tie-break: among the tightest-fitting bins,
prefer the bin that was already the fullest (smallest remaining capacity),
to keep gaps concentrated and reusable."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    min_res = int(residual.min())
    # Tolerance: treat near-ties as ties, but keep it small so tight fits still win.
    tol = 1
    near_best = residual <= (min_res + tol)
    # Primary: tightest fit (higher score = smaller residual).
    # Tie-break among near-best: prefer the fuller bin (smaller remaining capacity),
    # which consolidates small gaps instead of spreading them.
    score = -residual.astype(np.float64) * 1000.0 + (-bins.astype(np.float64)) * near_best * 0.0
    # Add consolidation term only within the near-best set.
    score = score - near_best.astype(np.float64) * (bins.astype(np.float64)) * 0.001
    return score
# EVOLVE-BLOCK-END

