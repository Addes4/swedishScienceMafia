# EVOLVE-BLOCK-START
"""Best fit with sliver avoidance: avoid leaving tiny unusable residuals."""
import numpy as np


def priority(item, bins):
    """Score each bin; highest wins.

    Dominant term is best-fit (smallest residual). When the best residual is
    below a threshold (a sliver), tilt toward bins whose residual is larger
    and thus more reusable, without abandoning tight packing entirely.
    """
    residual = bins - item  # remaining capacity after placing item
    # Base: best fit is the smallest residual -> large negative residual is bad.
    base = -residual.astype(np.float64)

    best = residual.min()
    if best < 12:
        # Encourage leaving a usable residual instead of a sliver.
        # Bin with residual >= 12 gets a bonus roughly proportional to how
        # close it is to a mid-size slot, but never overrides near-exact fits.
        target = 40.0  # typical item size
        bonus = np.where(residual >= 12,
                         1.0 / (1.0 + np.abs(residual - target)),
                         0.0)
        # bound the bonus so it only tilts among sliver-producing candidates
        base = base + 0.5 * bonus
    return base
# EVOLVE-BLOCK-END
