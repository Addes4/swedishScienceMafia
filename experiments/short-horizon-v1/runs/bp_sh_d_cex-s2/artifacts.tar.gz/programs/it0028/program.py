# EVOLVE-BLOCK-START
"""Best fit with an online-distribution tie-break that avoids unusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary key is best-fit (smallest post-placement residual). Among near-ties we add a
    small bonus when the resulting residual is close to a typical future item size, and a
    mild penalty when it is a tiny unusable sliver.
    """
    residual = bins - item

    # Base: best fit (smaller residual -> higher score).
    score = -residual.astype(np.float64)

    # Near-tie window: within a few units of the tightest fit.
    best = residual.min()
    near = (residual <= best + 3)

    # Typical item size from the Weibull-shaped distribution (mean ~40); a residual near
    # this value is likely to be fillable soon, whereas very small residuals are wasted.
    typical = 40.0
    near_bonus = np.where(
        near,
        -0.5 * np.abs(residual - typical) / typical,  # prefer residual near typical
        0.0,
    )
    # Mild penalty for creating a near-empty (likely unusable) bin.
    waste_penalty = np.where(near & (residual < 8), -0.3, 0.0)

    score = score + near_bonus + waste_penalty
    return score
# EVOLVE-BLOCK-END
