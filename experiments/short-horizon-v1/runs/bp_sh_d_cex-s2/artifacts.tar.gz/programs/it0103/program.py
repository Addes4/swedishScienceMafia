# EVOLVE-BLOCK-START
"""Best-fit with a tiny convex penalty on small residuals (near-SS spreading)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    res = bins - item
    # Primary: prefer smallest residual (best fit). Add a very small convex bonus that
    # slightly prefers larger residuals, mimicking the Sum-of-Squares spreading rule
    # without overriding the dominant best-fit ordering.
    return -res + (res.astype(np.float64) ** 2) * 1e-4
# EVOLVE-BLOCK-END
