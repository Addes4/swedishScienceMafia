# EVOLVE-BLOCK-START
"""Best fit with a slight preference for already-full bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item          # post-placement residual (>= 0 for fitting bins)
    fill = 100 - bins               # current fill level
    # Primary: tightest fit (smallest residual). Secondary: prefer fuller bins.
    # Scale the fill bonus so it can break ties among nearby residuals but never
    # overrides a clearly tighter fit.
    return -residual + 0.01 * fill
# EVOLVE-BLOCK-END
