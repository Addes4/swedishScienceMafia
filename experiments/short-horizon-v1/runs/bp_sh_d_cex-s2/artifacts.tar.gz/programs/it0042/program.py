# EVOLVE-BLOCK-START
"""Best fit, with a rare anti-fragmentation nudge.

Primary rule: best fit (smallest residual after placing the item).
Secondary rule: if the tightest placement would leave a tiny, hard-to-reuse
leftover (<= 2), and some bin's residual after placement would be exactly the
item size (letting a future identical item complete it), prefer that bin.
The nudge is +1, so it overrides at most a single unit of residual and cannot
flip strong best-fit choices.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # capacity left after placing the item

    # Primary: best fit -> smaller residual is better.
    primary = -residual.astype(np.float64)

    # Anti-fragmentation nudge, applied only in the rare case that best-fit would
    # strand a tiny leftover.
    min_res = int(residual.min())
    if min_res <= 2:
        nudge = (residual == item).astype(np.float64)
        if nudge.any():
            return primary + nudge

    return primary
# EVOLVE-BLOCK-END
