# EVOLVE-BLOCK-START
"""Hybrid: best-fit for large items, worst-fit among used bins for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item > 50:
        # Large items: best fit (tightest remaining capacity).
        return -(bins - item)
    # Small items: prefer used bins (remaining < 100), worst fit among them (largest leftover),
    # so we avoid opening new bins and keep the leftover large enough for future items.
    used = bins < 100
    score = np.where(used, bins, -1000.0 - bins)
    return score
# EVOLVE-BLOCK-END
