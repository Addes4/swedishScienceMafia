# EVOLVE-BLOCK-START
"""Best fit, but prefer residuals that hit near-exact fills."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tightest fit, tuned to avoid tiny slivers for big items."""
    residual = bins - item  # >= 0 for all shown bins
    # Primary: best fit = smallest residual. For large items, prefer bins whose
    # residual is not a tiny sliver, since those cannot be reused.
    # Score: higher is better. Base best-fit contribution:
    base = -residual.astype(np.float64)
    # Add a mild bonus for residuals near a small multiple of the item size,
    # which tends to produce reusable leftovers.
    if item >= 50:
        # penalty for residuals in (0, item) that are too small to hold another
        # such item but waste space; prefer larger residuals in that case.
        sliver = (residual > 0) & (residual < item)
        base = base + sliver * (residual.astype(np.float64) * 0.5)
    return base
# EVOLVE-BLOCK-END
