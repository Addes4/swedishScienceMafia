# EVOLVE-BLOCK-START
"""Best fit with complementary packing (BFCP).

Primary rule is classic best fit (place the item in the bin it fits most tightly).
As a refinement, we maintain a running estimate of the mean item size.  Before
applying best fit we look for a bin whose remaining capacity, after the item is
placed, would leave a residual that is "usable" -- larger than a tiny sliver and
roughly the size of a typical item.  If such a bin exists, we prefer it.  This
occasionally pairs items to create reusable average-sized slots while otherwise
behaving exactly like best fit.
"""
import numpy as np

# module-level state, reset per stream because streams start fresh.
_MEAN = 40.0     # running estimate of the mean item size
_N = 0           # number of items seen
MEAN_INIT = 40.0
_USABLE_LO = 12  # residuals below this are treated as unusable slivers
_ALPHA = 0.05    # EMA smoothing for the running mean


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    global _MEAN, _N

    # update running mean of the item distribution
    _N += 1
    _MEAN += _ALPHA * (item - _MEAN)
    mean = _MEAN
    if mean < 1.0:
        mean = 1.0

    # residual after placing item into each bin
    residual = bins - item

    # best-fit score: more tightly packed (smaller residual) is better
    bf = -residual.astype(np.float64)

    # complementary target: leave a residual close to the running mean
    # widen the acceptance band a bit for robustness
    hi = mean * 1.5
    lo = _USABLE_LO
    if hi < lo + 1.0:
        hi = lo + 1.0

    # a bin is "complementary" if its residual is in [lo, hi]
    comp = (residual >= lo) & (residual <= hi)

    if comp.any():
        # prefer complementary bins; among them, still prefer best fit (smallest residual)
        score = bf + comp.astype(np.float64) * 1000.0
    else:
        score = bf

    return score
# EVOLVE-BLOCK-END

