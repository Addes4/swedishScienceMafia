# EVOLVE-BLOCK-START
"""Hybrid: best-fit for large items, residual-aware choice for small items."""
import numpy as np

SMALL = 40  # items at or below this are "small"


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item

    if item > SMALL:
        # Large items: classic best fit (smallest non-negative residual).
        return -residual.astype(np.float64)

    # Small items: prefer tight fits, but never create a tiny unusable sliver.
    # Score: reward smaller residual, but give a clear bonus to placements that
    # leave either 0 (exact fill) or a residual at least SMALL (reusable).
    exact = (residual == 0)
    reusable = (residual >= SMALL) | exact
    score = -residual.astype(np.float64)
    score = score + reusable.astype(np.float64) * (SMALL + 1.0)
    return score
# EVOLVE-BLOCK-END
