# EVOLVE-BLOCK-START
"""Hybrid best-fit: tight packing for large items, capacity leveling for small ones."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item
    # Best fit: prefer smallest residual (tightest fit).
    best_fit = -residual.astype(np.float64)

    if item >= 45:
        return best_fit

    # For smaller items, mildly prefer bins that, after placement, still have a
    # residual around the "sweet spot" ~ half the mean item size, so the bin stays
    # usable for future medium items while avoiding leaving a large untouched gap.
    sweet = 20.0
    level = -np.abs(residual.astype(np.float64) - sweet)

    # Combine: mostly best-fit behavior, nudged by the leveling term.
    return best_fit + 0.15 * level
# EVOLVE-BLOCK-END
