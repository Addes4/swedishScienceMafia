# EVOLVE-BLOCK-START
"""Best-fit with a one-step future-fill adjustment.

Pure best fit is already strong on Weibull(mean~40) streams.  The idea here is to
keep best fit as the backbone but, when several bins are almost equally tight,
prefer the one whose residual is most likely to be exactly closed by one of the
item sizes seen so far.  The empirical histogram is cheap to maintain and lets
the rule reason about "which leftover gaps tend to get filled later".
"""
import numpy as np


class _State:
    def __init__(self):
        # counts of item sizes 1..100 seen so far
        self.hist = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def update(self, item):
        self.hist[item] += 1.0
        self.total += 1.0

    def prob(self, size):
        """Smoothed probability (relative frequency) of seeing `size`."""
        if size < 1 or size > 100:
            return 0.0
        # Laplace-ish smoothing so unseen sizes are not impossible
        denom = self.total + 100.0
        return (self.hist[size] + 1.0) / denom


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    item = int(item)
    _state.update(item)

    residual = bins - item  # remaining capacity after placing the item

    # Backbone score: best fit -> smaller residual is better.
    score = -residual.astype(np.float64)

    # Probability that this bin's new residual will be exactly consumed by the
    # next item (one-step survival): p(residual) * residual (larger gaps are
    # slightly more valuable to keep open, but exact-match gaps are best).
    res_int = residual.astype(np.int64)
    valid = (res_int >= 0) & (res_int <= 100)
    p = np.zeros(res_int.shape, dtype=np.float64)
    if _state.total > 0:
        # Vectorised lookup into the histogram-smoothed distribution.
        denom = _state.total + 100.0
        rr = np.clip(res_int, 0, 100)
        p[valid] = (_state.hist[rr[valid]] + 1.0) / denom

    # Small bonus favouring residuals that are likely to be closed soon.
    score += 0.35 * p

    return score
# EVOLVE-BLOCK-END
