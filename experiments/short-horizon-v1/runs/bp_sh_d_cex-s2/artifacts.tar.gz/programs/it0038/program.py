# EVOLVE-BLOCK-START
"""Best-fit with an online residual-reusability nudge.

Primary ranking is still tightest fit (minimize post-placement residual).  Among bins
whose residual is within a small tolerance of the tightest residual we break ties by
preferring a residual that is likely to be reusable, estimated from the running
distribution of item sizes seen so far in this stream (mean and a cheap spread).
"""
import numpy as np

_state = {"n": 0, "mean": 40.0, "sumsq": 40.0 * 40.0}


def priority(item, bins):
    # --- online estimate of item size distribution (mean / std) ---
    s = _state
    s["n"] += 1
    n = s["n"]
    old_mean = s["mean"]
    s["mean"] = old_mean + (item - old_mean) / n
    s["sumsq"] += item * item
    var = max(s["sumsq"] / n - s["mean"] * s["mean"], 1.0)
    sd = var ** 0.5
    m = s["mean"]

    residual = bins - item  # >= 0 for all shown bins

    # minimum residual (tightest fit)
    rmin = residual.min()

    # residuals within a small window of the best are considered ties for the
    # secondary (reusability) criterion.
    window = max(1.0, 0.05 * sd)
    tie = residual <= (rmin + window)

    # Reusability score: prefer a residual that is a likely future item size.
    # Gaussian-shaped bonus centered at the running mean, scaled small so it only
    # affects near-ties.  Also slightly penalize residuals that are too tiny to be
    # useful (below ~ the smallest plausible item) when a bigger tie exists.
    z = (residual - m) / (sd + 1e-9)
    reuse = np.exp(-0.5 * z * z)

    # tiny-residual penalty: a leftover much smaller than the mean is hard to reuse
    tiny = np.clip((m * 0.5 - residual) / (m * 0.5 + 1e-9), 0.0, 1.0)

    # primary term dominates; secondary only matters for near-ties.
    score = -residual * 1000.0 + reuse * 1.0 - tiny * 0.5
    return score
# EVOLVE-BLOCK-END
