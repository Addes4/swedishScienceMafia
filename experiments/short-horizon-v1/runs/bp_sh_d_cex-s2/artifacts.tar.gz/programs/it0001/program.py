# EVOLVE-BLOCK-START
"""Adaptive best-fit: prefer a bin whose residual after placement is near a learned target.

Pure best fit drives residuals toward zero, fragmenting bins into slivers that can no
longer hold typical items. This rule instead keeps a modest slack (half the running mean
item size), learned online from past items, so bins stay reusable.
"""
import numpy as np


class _State:
    n = 0
    total = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = _state
    mean = s.total / s.n if s.n > 0 else 40.0
    # update running statistics with the current item (uses no future information)
    s.n += 1
    s.total += item

    target = 0.5 * mean
    residual = bins - item
    return -np.abs(residual - target)
# EVOLVE-BLOCK-END
