# EVOLVE-BLOCK-START
"""Hybrid: best-fit generally, with a residual-quality tie-break for medium items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    if item >= 34:
        # Large item: pure best fit (tightest residual).
        return -(bins - item)
    # Smaller item: best-fit, but prefer leaving a residual as close as possible to 0
    # among bins whose residual is small; otherwise standard best-fit.
    residual = bins - item
    # Score: primary term pushes toward the smallest non-negative residual,
    # but we add a mild bonus for residuals that are "reusable" (>= item sized).
    # Reusable bonus: prefer residual ~ item (so another same-size item can fill it).
    reuse = -np.abs(residual - item)
    return -(residual) * 1000.0 + reuse
# EVOLVE-BLOCK-END
