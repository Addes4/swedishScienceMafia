# EVOLVE-BLOCK-START
"""Best-fit with a stateful recent-size residual matching tie-breaker."""
import numpy as np

_state = {"recent": []}
_WINDOW = 24


def priority(item, bins):
    """Rank bins: primary tight fit, tie-break by leaving a residual equal to a recent item.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of each fitting bin, in bin order.
    """
    recent = _state["recent"]

    # Primary: tightest fit (smallest residual after placing the item)
    resid = bins - item
    primary = -resid.astype(np.float64)

    # Secondary: nudge toward residuals that match a recently seen item size,
    # making leftover space exactly fillable by a similar future item.
    if recent:
        rec = np.array(recent, dtype=np.int64)
        sec = np.zeros(len(bins), dtype=np.float64)
        for i in range(len(bins)):
            r = resid[i]
            if r > 0:
                d = np.min(np.abs(rec - r))
                sec[i] = -float(d)
            else:
                sec[i] = 0.0
        # tiny weight so it only breaks near-ties
        score = primary + 0.001 * sec
    else:
        score = primary

    # record this item size (bounded window)
    recent.append(int(item))
    if len(recent) > _WINDOW:
        del recent[0]

    return score
# EVOLVE-BLOCK-END
