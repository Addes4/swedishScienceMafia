# EVOLVE-BLOCK-START
"""Best fit with exact-fill bonus and mild anti-fragmentation tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # remaining capacity after placing the item

    # Base: prefer the tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Strong bonus for a perfect fill.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Mild preference for residuals that leave a "usable" gap:
    # avoid leaving tiny unusable slivers (1..3) unless it's an exact fill.
    small_sliver = (residual > 0) & (residual <= 3)
    score -= np.where(small_sliver, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
