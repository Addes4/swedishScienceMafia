# EVOLVE-BLOCK-START
"""Best fit with a gentle nudge toward reusable leftover gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit base: fullest fitting bin first (smallest residual).
    residual = bins - item  # >= 0 since bins are the fitting ones

    # Gentle nudge: reward residuals that are exactly 0 (perfect fill) and residual
    # gaps large enough to plausibly fit a future item. Tiny epsilon only breaks ties.
    # EMA of item sizes kept in a module-level attribute to persist across calls.
    ema = getattr(priority, "ema", 40.0)
    ema = 0.99 * ema + 0.01 * item
    priority.ema = ema

    score = -residual.astype(np.float64)
    # Small bonus for exactly-zero residual (perfectly filled bin).
    score += 1e-3 * (residual == 0)
    # Small bonus for leaving a reusable gap (>= EMA); slight edge over stranded tiny gaps.
    score += 5e-4 * (residual >= ema)
    return score
# EVOLVE-BLOCK-END

