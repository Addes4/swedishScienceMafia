# EVOLVE-BLOCK-START
"""Best fit with a small penalty for stranding residuals just below the item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: prefer the tightest fit (smallest residual).
    score = -residual.astype(np.float64)
    # Penalize residuals that are small but still leave a bin almost-full yet
    # unable to accept typical items, by nudging them toward zero residual.
    # small usable range: residuals 1..8 are often wasted; make them less attractive
    # than a slightly larger residual in 9..24 (which could accept small items).
    waste = (residual >= 1) & (residual <= 8)
    score[waste] -= 2.0
    return score
# EVOLVE-BLOCK-END
