# EVOLVE-BLOCK-START
"""Best-fit with a light anti-fragmentation preference.

Pure best-fit scores 0.9727 here.  This variant keeps best-fit as the primary
criterion but, when several bins fit the item almost equally tightly, nudges the
item toward the bin whose post-placement residual is closest to a favourable
target (roughly the mean item size), so residuals stay useful for future items
instead of collapsing into tiny slivers.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    # Online running mean of past item sizes (cheap, order-independent).
    n = _state["n"]
    s = _state["sum"]
    mean = (s / n) if n > 0 else 40.0
    _state["n"] = n + 1
    _state["sum"] = s + item

    post = bins - item          # remaining capacity after placing the item
    # Primary: best fit -> we want the smallest post-placement residual.
    # Secondary, only among near-ties (residual within a small margin of the
    # best), prefer residual close to the typical item size so the bin keeps
    # enough room for a likely future item.
    best = int(post.min())
    margin = max(1, int(0.05 * mean)) + 1
    tie = post <= best + margin

    target = max(1.0, mean * 0.9)
    close_to_target = -np.abs(post.astype(np.float64) - target)

    score = -post.astype(np.float64)
    # Small additive bonus only inside the tie band; magnitude is tiny relative
    # to the integer residual gaps outside the band so best-fit still dominates.
    score = score + tie.astype(np.float64) * 1e-3 * close_to_target
    return score
# EVOLVE-BLOCK-END
