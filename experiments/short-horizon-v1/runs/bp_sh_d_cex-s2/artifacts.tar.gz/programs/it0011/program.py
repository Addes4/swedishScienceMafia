# EVOLVE-BLOCK-START
"""Best-fit with a residual sweet-spot tie-break driven by the running mean item size."""
import numpy as np


class _State:
    n = 0
    total = 0.0


def priority(item, bins):
    # Update running mean of item sizes.
    _State.n += 1
    _State.total += item
    mean = _State.total / _State.n

    residual = bins - item  # remaining capacity after placing the item

    # Primary: prefer tightest fit (smallest residual), as in pure best-fit.
    # Tie-break within a small window: prefer a residual near the running mean,
    # which keeps leftover space usable for typical future items.
    tight = residual.min()
    window = max(1.0, 0.02 * mean)
    close = residual <= tight + window

    # Among the close bins, score = residual; but penalize tiny slivers (< a few units)
    # and encourage residuals around mean. Lower residual still favored overall.
    sliver = residual < max(1.0, 0.03 * mean)
    score = -(residual) - 0.5 * sliver.astype(float)
    # Encourage residuals near mean only among the close set.
    adj = np.where(close, -np.abs(residual - mean) * 0.05, 0.0)
    score = score + adj
    return score
# EVOLVE-BLOCK-END
