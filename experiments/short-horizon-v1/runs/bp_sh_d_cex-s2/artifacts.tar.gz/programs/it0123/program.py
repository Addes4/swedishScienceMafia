# EVOLVE-BLOCK-START
"""Best fit, but break near-ties toward the most recently used bin.

Items arrive online. Classic best fit places each item into the bin that
minimizes the residual capacity after placement. On skewed item
distributions, ties are common; resolving them toward *recently opened* bins
(higher bin index) helps fully close off older bins before opening new ones,
which tends to reduce the total number of bins used.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, first on ties.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    n = bins.shape[0]
    residual = bins - item
    # Primary term: prefer the tightest fit (smallest residual).
    # Secondary term: prefer recent (high-index) bins so older bins are
    # consolidated and closed. The index term is strictly smaller than one
    # capacity unit so it never dominates the best-fit ordering.
    idx = np.arange(n, dtype=np.float64)
    return -residual.astype(np.float64) + 1e-3 * idx / max(n, 1)
# EVOLVE-BLOCK-END
