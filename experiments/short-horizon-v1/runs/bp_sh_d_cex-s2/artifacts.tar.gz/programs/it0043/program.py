# EVOLVE-BLOCK-START
"""Best fit with a sliver-avoidance penalty.

Primary rule: best fit (smallest post-placement residual).
Correction: never create an unusable tiny residual (1..m) if an alternative exists.
"""
import numpy as np

# Running estimate of item sizes, used only for the sliver threshold.
_state = {"n": 0, "sum": 0}


def priority(item, bins):
    """Rank bins; highest score wins, ties go to the first (lowest index)."""
    s = _state
    s["n"] += 1
    s["sum"] += item
    mean = s["sum"] / s["n"]

    # Smallest worth-keeping residual.  Items are integers >= 1, but very small
    # leftovers (1..m) are rarely reusable, so avoid creating them when we can.
    m = int(mean * 0.15)
    if m < 1:
        m = 0

    residual = bins - item  # >= 0 for every bin shown

    # Base: best fit -> prefer the smallest residual (negate so bigger is better).
    score = -residual.astype(np.float64)

    if m > 0:
        # Penalize creating a sliver residual.  Penalty < 1 so it only matters
        # among bins with the same or adjacent residual, and exact fits (0)
        # remain strictly best.
        sliver = (residual >= 1) & (residual <= m)
        score -= sliver * 0.5

    return score
# EVOLVE-BLOCK-END
