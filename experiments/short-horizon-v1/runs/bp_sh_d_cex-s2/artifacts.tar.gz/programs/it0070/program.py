# EVOLVE-BLOCK-START
"""Best fit with an online, distribution-aware residual bonus.

Primary rule is ordinary best fit (smallest post-placement residual).  We add a
small, bounded bonus for residuals that are either exactly zero (a perfectly
filled bin) or large enough to hold a typical future item, where "typical" is
tracked online via an exponential moving average of seen item sizes.  This
consolidates leftover space into reusable chunks without abandoning tight fits.
"""
import numpy as np

_mean = 40.0  # running estimate of a typical item size


def priority(item, bins):
    """Return a priority per bin; item goes to the highest score (first on ties)."""
    global _mean

    # Update the running mean of item sizes (exponential moving average).
    _mean += 0.02 * (float(item) - _mean)

    residual = bins - item
    # Primary criterion: best fit -> smaller residual is better.
    score = -residual.astype(np.float64)

    # Bonus: perfectly filled bin is strongly preferred.
    score += 5.0 * (residual == 0)

    # Small bonus if the residual can still hold a typical future item,
    # i.e. the leftover is "reusable" rather than stranded sub-mean waste.
    reusable = (residual > 0) & (residual >= _mean)
    score += 0.5 * reusable

    return score
# EVOLVE-BLOCK-END
