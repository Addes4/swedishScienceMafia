# EVOLVE-BLOCK-START
"""Best fit with sum-of-squares tie-break: pack as tightly as possible, and among
near-ties prefer the bin that is fullest after placement (concentrating waste)."""
import numpy as np


def priority(item, bins):
    """Score each bin; highest score wins (first on ties).

    Primary key: minimize residual after placement (best fit).
    Tie-break (within a small tolerance): prefer the bin whose post-placement
    residual is smallest in a sum-of-squares sense, i.e. the fullest bin.
    """
    residual = bins - item  # remaining capacity after putting item here
    # Primary: tightest fit -> larger score for smaller residual.
    # Use exact residual so pure best-fit behavior dominates.
    tight = -residual.astype(np.float64)
    # Secondary, only meaningful for ties/near-ties: fuller bin is better,
    # captured by a tiny fraction of the (negative) residual itself.
    # (Equivalent to a mild preference for fuller bins among equal fits.)
    return tight + 1e-6 * (-residual.astype(np.float64))
# EVOLVE-BLOCK-END
