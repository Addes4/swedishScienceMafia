# EVOLVE-BLOCK-START
"""Best-fit with a small bonus for residuals that align with typical item sizes."""
import numpy as np

# module-level state, reset per stream by the harness creating fresh state only via call ordering
_state = {"sum": 0.0, "n": 0}

def priority(item, bins):
    _state["sum"] += item
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]

    # post-placement residual
    resid = bins - item

    # base: strongly prefer smaller residual (best fit)
    score = -resid.astype(np.float64)

    # completion bonus: exact zero residual is great
    score = np.where(resid == 0, score + 0.5, score)

    # alignment bonus: residuals near a multiple of a coarse modal estimate stay fillable
    step = max(1.0, mean / 2.0)
    k = np.round(resid / step)
    align = np.abs(resid - k * step)
    score -= 1e-3 * align

    return score
# EVOLVE-BLOCK-END
