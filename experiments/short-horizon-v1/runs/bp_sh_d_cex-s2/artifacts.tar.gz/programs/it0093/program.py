# EVOLVE-BLOCK-START
"""Best fit with a drain tie-breaker: favor tight fits, then denser bins."""
import numpy as np


def priority(item, bins):
    """Score bins; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    residual_after = bins - item
    # Dominant term: best fit (tightest residual after placement).
    # Secondary term: among close fits, prefer the bin that was already fuller
    # (smaller residual before placement), sealing off partially filled bins.
    return -residual_after - 0.25 * bins
# EVOLVE-BLOCK-END
