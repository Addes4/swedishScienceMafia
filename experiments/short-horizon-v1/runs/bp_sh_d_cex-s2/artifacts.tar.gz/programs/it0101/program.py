# EVOLVE-BLOCK-START
"""Sum-of-squares: minimize the squared post-placement residual.

Best-fit greedily packs each item into the tightest gap, which tends to leave
behind many tiny unusable gaps.  Minimizing the squared residual instead prefers
either an exact fit (residual 0) or a bin that stays relatively empty, keeping
bins in a state where future items of varied size can still fit well.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    return -(residual.astype(np.int64) ** 2)
# EVOLVE-BLOCK-END
