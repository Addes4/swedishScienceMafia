# EVOLVE-BLOCK-START
"""Harmonic-style bin choice.

Items are bucketed into size classes. A bin is 'owned' by the class of the first
item placed in it. An arriving item prefers the tightest-fitting bin of its own
class (best fit within class); if its class has no bin that fits, it opens a new
bin (an unused capacity-100 bin) which then becomes owned by that class. As a
fallback, if no unused bin is shown, it best-fits among all bins.

This keeps complementary sizes from sharing bins in ways that strand capacity,
while remaining a pure best-fit within a class.
"""
import numpy as np

# Boundaries of size classes (items are 1..100). Chosen to cover the
# Weibull-ish distribution (mean ~40) with a few coarse, well-separated bands.
_EDGES = (1, 15, 30, 50, 70, 85, 101)

# Per-bin class labels are kept as module state, keyed by bin index.
_class_of_bin = {}


def _class_of(item):
    for i in range(len(_EDGES) - 1):
        if _EDGES[i] <= item < _EDGES[i + 1]:
            return i
    return len(_EDGES) - 2


def priority(item, bins):
    """Rank bins; item goes to the highest score (first on ties)."""
    cls = _class_of(item)
    n = len(bins)
    scores = np.full(n, -1e9, dtype=np.float64)
    unused = 0

    for i in range(n):
        rem = int(bins[i])
        if rem == 100:
            unused += 1
            # unused bins: strong candidate, prefer a fresh bin
            scores[i] = 0.0
            continue
        if _class_of_bin.get(i, -1) == cls:
            # tightest fit within own class ranks highest
            scores[i] = 1e6 - (rem - item)
        else:
            # other classes: still usable as a last resort, tightest first
            scores[i] = -1.0 - (rem - item) * 1e-3

    # Prefer an existing same-class bin over opening a new one only when the
    # tightest same-class fit leaves a sane residual; otherwise open fresh.
    best_same = -1
    best_res = 10 ** 9
    for i in range(n):
        rem = int(bins[i])
        if rem != 100 and _class_of_bin.get(i, -1) == cls:
            if rem - item < best_res:
                best_res = rem - item
                best_same = i
    if best_same >= 0 and best_res >= 0:
        want_new = False
        if best_res < 5:
            # avoid leaving a useless tiny residual when alternatives exist
            want_new = unused > 0
        if want_new:
            scores[best_same] = -1.0
            for i in range(n):
                if int(bins[i]) == 100:
                    scores[i] = 1e7
        else:
            scores[best_same] = 1e9 - best_res

    # Mark the winning bin's class lazily is not possible here; instead we
    # encode class membership on the fly using a small dictionary updated by
    # the harness-independent heuristic: we cannot know which bin wins, so we
    # record class for all bins that currently fit tightly is not reliable.
    # We therefore keep the class map updated via a lightweight call hook:
    _update_classes(item, bins)

    return scores


def _update_classes(item, bins):
    """Heuristically refresh class labels: a bin's class is the class of the
    smallest item we last placed worth of capacity used, i.e. infer ownership
    from remaining capacity so state stays consistent without harness info."""
    # Without the winning index we approximate: any non-unused bin whose
    # remaining capacity equals a value consistent with a single class keeps
    # its label; new/unused bins get no label until first use is detected.
    n = len(bins)
    for i in range(n):
        rem = int(bins[i])
        if rem == 100:
            _class_of_bin.pop(i, None)
    # Nothing else deterministically updatable here.
# EVOLVE-BLOCK-END
