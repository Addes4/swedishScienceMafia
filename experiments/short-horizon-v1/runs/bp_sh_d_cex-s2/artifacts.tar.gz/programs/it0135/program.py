# EVOLVE-BLOCK-START
"""Target-residual rule: aim for a favorable post-placement leftover tracked online."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Rank bins by how close their post-placement residual is to a sweet-spot target.

    The target is an online estimate of a desirable leftover (~ half the running mean item
    size), so residuals stay useful for future items instead of becoming tiny slivers, while
    still preferring tighter fits via a tie-break toward smaller residual.
    """
    s = _state
    s["n"] += 1
    s["sum"] += item
    mean = s["sum"] / s["n"]
    target = 0.5 * mean

    resid = bins - item
    # Closeness to target, with a small preference for smaller residuals to keep best-fit flavor.
    return -np.abs(resid - target) + 1e-6 * (-resid)
# EVOLVE-BLOCK-END
