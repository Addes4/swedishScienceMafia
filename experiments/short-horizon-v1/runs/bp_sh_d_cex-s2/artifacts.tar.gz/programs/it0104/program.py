# EVOLVE-BLOCK-START
"""Best-fit with a mild harmonic-style grouping bonus.

Small items get packed preferentially into bins that will retain a residual in a
similar coarse bucket, encouraging like-sized items to share bins and reserving
fresh/empty bins for the large items that follow.
"""
import numpy as np

# coarse capacity buckets (residual after placement -> bucket id)
_BOUNDS = np.array([10, 20, 35, 50, 65, 80, 100])


def priority(item, bins):
    residual = bins - item
    # base: classic best-fit ordering (prefer smallest residual)
    score = -residual.astype(np.float64)

    # harmonic-style: for smaller items, add a small bonus when the post-placement
    # residual stays below a size-dependent cutoff (keeps bins "matched" to item size).
    if item <= 35:
        cutoff = 100 - item  # bins that, after placement, hold at most one item's worth
        near = residual < (100 - item)
        # bonus grows as residual approaches the cutoff from below: seal tight bins first
        score = score + 0.5 * np.where(near, (cutoff - residual) / max(cutoff, 1), 0.0)

    return score
# EVOLVE-BLOCK-END
