# EVOLVE-BLOCK-START
"""Best fit with an online gap-consolidation tie-break."""
import numpy as np


class _State:
    def __init__(self):
        self.mean = 40.0
        self.n = 0.0


_s = _State()


def priority(item, bins):
    """Rank bins: primary is post-placement residual (best fit), with a small bonus for
    residuals that sit near a multiple of the running typical item size (usable slots)."""
    resid = bins - item  # post-placement residual, >= 0 for shown bins

    # Update running estimate of typical item size (plain average, light smoothing).
    _s.n += 1.0
    _s.mean += (item - _s.mean) / min(_s.n, 200.0)
    typ = _s.mean
    if typ < 1.0:
        typ = 1.0

    # Primary: smaller residual is better -> use negative residual.
    score = -resid.astype(np.float64)

    # Bonus: reward residuals close to a positive multiple of `typ` (reusable slots),
    # small enough to only break near-ties without overriding tight packing.
    m = np.round(resid / typ)
    m = np.maximum(m, 0.0)
    target = m * typ
    bonus = 1.0 - np.abs(resid - target) / typ
    score += 0.02 * bonus

    return score
# EVOLVE-BLOCK-END
