# EVOLVE-BLOCK-START
"""Best fit with a soft exponential preference over residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Soft best-fit: exponentially reward smaller residuals.  The scale is set so
    # that residual differences of a few units are almost flat (near-ties get
    # broken by bin order) while larger differences still dominate.
    scale = 2.0
    return np.exp(-residual / scale)
# EVOLVE-BLOCK-END
