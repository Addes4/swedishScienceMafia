# EVOLVE-BLOCK-START
"""Best fit with an online-statistics residual-value tie-break.

Primary rule: pack tightly (largest remaining capacity that still fits -> smallest residual).
Secondary rule: when two bins give similar residual, prefer the one leaving a leftover close
to the typical item size (so it can still be reused), and slightly avoid leftovers that are
too small to ever hold a future item.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all shown bins

    # Tight fit as the dominant term: smaller residual -> higher score.
    score = -residual.astype(np.float64)

    # A small structured tie-break that never overrides a strictly better fit.
    # Leftovers: 0 (perfect) is great; very small leftovers are bad (unusable);
    # leftovers near a typical item size are good (reusable).
    # Use a mild weight so it only matters within the near-ties of the tight fits.
    r = residual.astype(np.float64)
    # bonus: perfect fill
    bonus = np.where(r == 0.0, 1.0, 0.0)
    # penalize tiny unusable leftovers (1..~8) a bit, scaled so it stays sub-unit
    tiny = (r >= 1.0) & (r <= 8.0)
    bonus -= np.where(tiny, 0.5, 0.0)

    return score + 1e-3 * bonus
# EVOLVE-BLOCK-END
