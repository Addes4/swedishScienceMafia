# EVOLVE-BLOCK-START
"""Hybrid best-fit: tightly fill bins, but avoid stranding slivers by preferring
emptier bins when the best-fit residual would be too small to be reusable."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here
    # Primary: prefer the tightest fit (smallest residual >= 0).
    # Secondary: if the residual is tiny (a stranded sliver), prefer larger current residual
    # so the sliver is created in a bin that already had room, not in a nearly full one.
    primary = -residual.astype(np.float64)
    # Penalize small residuals by nudging the score down slightly when residual < item.
    sliver_penalty = np.where(residual < item, residual.astype(np.float64) * 1e-3, 0.0)
    # Prefer larger current capacity when residuals are equal-tiny.
    secondary = bins.astype(np.float64) * 1e-6
    return primary - sliver_penalty + secondary
# EVOLVE-BLOCK-END
