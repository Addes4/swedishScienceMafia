# EVOLVE-BLOCK-START
"""Best fit plus a stateful bonus when the leftover gap matches a likely future item size."""
import numpy as np

_hist = None  # counts of recent item sizes, index 1..100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist
    if _hist is None:
        _hist = np.zeros(101, dtype=np.float64)

    # Best-fit dominant term: smaller post-placement residual -> higher priority.
    residual = bins - item
    score = -residual.astype(np.float64)

    # Stateful bonus: reward gaps that match a plausible future item size.
    # Normalize histogram to get a probability-like weight for each residual value.
    total = _hist.sum()
    if total > 0:
        freq = _hist / total
        # residual indexes into 0..100; gaps <=0 or >100 get no bonus.
        valid = (residual >= 1) & (residual <= 100)
        bonus = np.zeros_like(score)
        idx = np.where(valid)[0]
        if idx.size:
            bonus[idx] = freq[residual[idx]]
        # small weight so best-fit remains dominant
        score = score + 0.5 * bonus

    # Update histogram with the arriving item (decayed so it tracks recent distribution).
    _hist *= 0.999
    _hist[item] += 1.0

    return score
# EVOLVE-BLOCK-END

