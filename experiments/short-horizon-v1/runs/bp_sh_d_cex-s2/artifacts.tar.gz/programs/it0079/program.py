# EVOLVE-BLOCK-START
"""Best-fit with a tunable spread term and residual-reuse bonus.

The item goes to the bin maximizing:
    -(residual) + alpha * residual + beta * bonus
where residual = bins - item is the capacity left after placing the item,
alpha is a small spreading coefficient, and bonus rewards leaving a residual
that matches a common residual seen earlier in the stream.
"""
import numpy as np

_ALPHA = 0.06      # small spread toward less-full bins (worst-fit nudge)
_RESID_SET = set()  # residuals observed as post-placement left-overs
_SEEN = 0


def priority(item, bins):
    global _SEEN
    residual = bins - item  # capacity remaining after placing `item`

    # Bonus for residuals that are very common leftovers in this stream.
    if _RESID_SET:
        # vectorized membership: exact matches only, cheap
        bonus = np.fromiter((1.0 if int(r) in _RESID_SET else 0.0 for r in residual),
                            dtype=float, count=residual.shape[0])
    else:
        bonus = np.zeros(residual.shape[0], dtype=float)

    score = -(residual.astype(float)) + _ALPHA * residual.astype(float) + 0.5 * bonus

    # Update the residual set with the chosen placement's residual.
    if residual.size:
        best = int(np.argmax(score))
        r = int(residual[best])
        if r > 0 and r <= 100:
            _RESID_SET.add(r)
        _SEEN += 1
        # keep the set bounded so it stays cheap
        if len(_RESID_SET) > 80:
            _RESID_SET.clear()
            _RESID_SET.add(r)

    return score
# EVOLVE-BLOCK-END
