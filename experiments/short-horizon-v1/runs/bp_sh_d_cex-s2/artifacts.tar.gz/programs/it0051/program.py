# EVOLVE-BLOCK-START
"""Best fit with a bounded tie-break bonus toward reusable residuals."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "mean": 40.0}


def priority(item, bins):
    """Rank bins: best fit dominates; small bounded bonus for reusable leftovers.

    item: integer size 1..100.
    bins: remaining capacities of bins the item fits in (int64, includes unused=100).
    """
    # update running mean of item sizes
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    residual = bins - item  # >= 0 for all shown bins

    # bonus in [0, 1): exact fill (residual 0) gets the max; residuals near the
    # running mean get a decreasing bonus; small slivers get little.
    # distance from 0 -> 0 bonus; closeness to mean -> up to ~0.5.
    # use a smooth, bounded kernel so it never reorders distinct residuals when
    # scaled below 1.
    target = mean
    # closeness to typical future item size (in units of target)
    if target <= 0:
        target = 40.0
    d_mean = np.abs(residual - target) / target
    bonus_mean = 0.5 / (1.0 + d_mean * d_mean)

    # exact/near-exact fill bonus
    bonus_exact = 0.5 / (1.0 + (residual * residual) / 100.0)

    bonus = np.maximum(bonus_mean, bonus_exact)

    # dominant term: minimize residual (i.e. best fit). Scale large so bonus
    # cannot override a strictly smaller residual.
    return -residual * 1e6 + bonus
# EVOLVE-BLOCK-END
