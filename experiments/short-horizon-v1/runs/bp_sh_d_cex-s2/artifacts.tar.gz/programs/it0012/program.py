# EVOLVE-BLOCK-START
"""Dead-zone-aware best fit.

Best fit packs tightly, but residual slivers (1..threshold) are effectively wasted
because items that small are rare.  We keep the tightest-fit as the primary goal,
but demote candidates whose post-placement residual lands in the dead zone so that
a slightly looser (but still usable) bin is preferred instead.
"""
import numpy as np


def priority(item, bins):
    """Return a priority per bin; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits
          in (including unused bins, remaining 100), in bin order.
    """
    residual = bins - item          # >= 0 for every bin shown

    # Adaptive dead-zone threshold from observed item sizes: items below the
    # ~15th percentile are rare, so a residual smaller than that is mostly wasted.
    global _sizes
    try:
        _sizes
    except NameError:
        _sizes = []
    if len(_sizes) < 200:
        _sizes.append(item)

    if len(_sizes) >= 50:
        thr = np.percentile(np.asarray(_sizes), 15)
        thr = int(max(1, round(thr)))
    else:
        thr = 5

    # Penalty: map a dead-zone residual to just above thr so it is not chosen
    # over a real (>= thr) or perfectly-full (== 0) option, while preserving the
    # order among non-dead-zone residuals.
    dead = (residual > 0) & (residual < thr)
    eff = residual.astype(np.float64).copy()
    eff[dead] = thr + (residual[dead] - 0.5) / max(thr, 1) * 0.5

    # highest score <-> smallest effective residual
    return -eff
# EVOLVE-BLOCK-END
