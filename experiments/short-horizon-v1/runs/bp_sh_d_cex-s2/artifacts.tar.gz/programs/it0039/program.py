# EVOLVE-BLOCK-START
"""Best fit with a reusability guard on the resulting residual."""
import numpy as np


def priority(item, bins):
    """Rank bins for an arriving item; highest score wins (first on ties).

    Primary rule: best fit (smallest residual after placement). Secondary rule:
    prefer residuals that are at least the running mean item size, since those
    remain reusable; only fall back to tightest fit when no such bin exists.
    """
    # running mean item size estimate, kept on the function object
    n = getattr(priority, "n", 0) + 1
    mean = getattr(priority, "mean", 40.0)
    mean = mean + (item - mean) / n
    priority.n = n
    priority.mean = mean

    resid = bins - item  # remaining capacity after placing the item here

    # bins that leave a "reusable" residual (>= running mean item size)
    reusable = resid >= mean

    if np.any(reusable):
        # among reusable bins choose the smallest such residual (tightest reusable fit)
        score = np.where(reusable, -resid.astype(np.float64), -np.inf)
    else:
        # no reusable option: plain best fit
        score = -resid.astype(np.float64)

    # Small tie-break: prefer larger residual slightly to keep bins flexible,
    # without overriding the primary ordering.
    return score + resid.astype(np.float64) * 1e-9
# EVOLVE-BLOCK-END
