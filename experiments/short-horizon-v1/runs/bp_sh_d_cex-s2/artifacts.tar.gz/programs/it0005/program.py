# EVOLVE-BLOCK-START
"""Best fit with a light, adaptive anti-sliver tie-break."""
import numpy as np


def priority(item, bins):
    """Rank bins: primary = tightest fit; tie-break = avoid tiny slivers.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)
    residual = bins - item  # >= 0 since only fitting bins are shown

    # Tightest fit as the dominant key.
    score = -residual.astype(np.float64)

    # Light anti-sliver tie-break: penalize residuals just below the smallest
    # item size (1) up to a small threshold, i.e. leftover space likely wasted.
    # The penalty is small enough to only flip near-exact ties.
    sliver = (residual >= 1) & (residual <= 4)
    score = score - 0.01 * sliver.astype(np.float64)
    return score
# EVOLVE-BLOCK-END

