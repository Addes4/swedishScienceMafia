# EVOLVE-BLOCK-START
"""Best fit with a residual tie-break: choose the tightest fit, breaking ties
by preferring the smallest positive residual (least slack)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual). Secondary: prefer residuals that are
    # small but nonzero is handled by the same key here since residual >= 0.
    # Use a strong linear key so exact tightest fit dominates.
    return -residual
# EVOLVE-BLOCK-END

