# EVOLVE-BLOCK-START
"""Best fit with a mild anti-sliver / anti-waste adjustment."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Pure best-fit: minimize residual (i.e. maximize -(residual)).
    score = -residual.astype(np.float64)

    # Mild penalty for leaving a large residual (waste), scaled so it only breaks
    # near-ties among tight fits rather than overriding best-fit.
    score -= 0.02 * residual

    # Slightly stronger dislike of tiny non-zero residuals (slivers that are
    # effectively unusable), pushing the item into a bin where it fits exactly.
    sliver = (residual > 0) & (residual <= 2)
    score[sliver] -= 0.5

    return score
# EVOLVE-BLOCK-END
