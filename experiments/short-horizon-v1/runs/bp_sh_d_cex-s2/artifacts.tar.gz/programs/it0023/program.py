# EVOLVE-BLOCK-START
"""Adaptive best-fit / worst-fit hybrid.

Key idea: track the item size distribution online and, for each arriving item,
choose between tightest-fit (best-fit) and loosest-fit (worst-fit) based on how
much "fragmentation risk" tightest-fit would create.

For small items, tightest-fit tends to fill bins exactly and is good.
For larger items, tightest-fit can leave small unusable residuals; worst-fit may
be better by leaving larger residuals that future items can still use.
"""
import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.total = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in, in bin order.
    """
    bins = np.asarray(bins)
    residual = bins - item  # >= 0 since only fitting bins are shown

    # Update online stats (items arrive one at a time).
    _state.count += 1
    _state.total += item
    mean_item = _state.total / _state.count

    # For every placement, score = -residual (best fit), but add a bonus for
    # leaving a residual that is "useful" (larger than a small fraction of
    # typical item size), to avoid tiny unusable gaps.
    # A residual of 0 is perfect (no waste).
    tiny = max(1.0, 0.15 * mean_item)

    # Base: prefer tighter fits.
    score = -residual.astype(np.float64)

    # Penalize leaving a tiny nonzero residual (unusable gap).
    tiny_gap = (residual > 0) & (residual < tiny)
    score = score - 0.5 * tiny_gap.astype(np.float64)

    # Bonus for exactly filling a bin.
    exact = residual == 0
    score = score + 0.3 * exact.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
