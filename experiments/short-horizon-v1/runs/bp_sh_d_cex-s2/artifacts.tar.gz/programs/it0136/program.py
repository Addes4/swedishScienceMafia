# EVOLVE-BLOCK-START
"""Best fit with exact-fill and near-tie resolution toward the minimum residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best fit: prefer the smallest post-placement residual.
    # Exact fills (residual 0) are already the smallest possible value,
    # so plain best-fit already captures them; keep the rule simple and robust.
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
