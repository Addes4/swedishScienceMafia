# EVOLVE-BLOCK-START
"""Softmax (randomized) best-fit: usually tightest fit, sometimes spread out."""
import numpy as np

_RNG = np.random.default_rng(123456789)
_T = 8.0          # temperature: higher -> more exploration
_EPS = 0.15       # probability of not taking the strict argmax bin


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    base = -residual.astype(np.float64)

    # Occasional exploration: perturb priorities so a non-tightest bin can win,
    # which breaks up the greedy stranding of tiny unusable gaps.
    if _RNG.random() < _EPS:
        noise = _RNG.gumbel(size=base.shape) * _T
        return base + noise
    return base
# EVOLVE-BLOCK-END
