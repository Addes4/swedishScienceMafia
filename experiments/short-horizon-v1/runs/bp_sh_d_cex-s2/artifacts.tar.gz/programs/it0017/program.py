# EVOLVE-BLOCK-START
"""Best fit with a mild penalty for creating exact-zero residual bins.

Items arrive online; we rank bins by the residual left after placing the item.
Pure best-fit fills bins to zero residual, which is usually good but can waste
flexibility for future medium items.  Penalizing a zero residual very slightly
keeps the tight packing while retaining a bin that can still absorb something.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of bins the item fits in.
    """
    residual = bins - item
    # Base: tighter fit is better (smaller residual -> higher score).
    score = -residual.astype(np.float64)
    # Slight penalty for exactly filling a bin, to preserve future flexibility.
    score -= 1e-3 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
