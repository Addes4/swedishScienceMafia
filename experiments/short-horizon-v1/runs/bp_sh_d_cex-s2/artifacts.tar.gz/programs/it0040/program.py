# EVOLVE-BLOCK-START
"""Best fit with an online "reusable residual" tie-break.

Primary: minimize post-placement residual r = bins - item (classic best fit).
Secondary (tie-break only): among bins with equal residual, prefer the one whose
residual is closest to the running mean item size, which tends to keep a bin in a
state where the next typical item also fits tightly.
"""
import numpy as np

_mass = 0.0
_count = 0


def priority(item, bins):
    global _mass, _count
    _mass += item
    _count += 1
    mean = _mass / _count

    r = bins - item
    # Primary key: tighter fit (smaller residual) is better -> negative residual.
    # Secondary key is strictly smaller than 1 so integer residuals dominate.
    frac = np.abs(r - mean)
    # Map to (0, 1): smaller distance => closer to 1 bonus.
    bonus = 1.0 / (1.0 + frac)
    return -r + bonus
# EVOLVE-BLOCK-END
