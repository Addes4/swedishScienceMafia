# EVOLVE-BLOCK-START
"""Bounded best-fit: tightly fit, but prefer residuals that stay reusable."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "min": 101}


def priority(item, bins):
    """Rank bins by a bounded best-fit criterion over remaining capacity.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    b = bins.astype(np.float64)
    residual = b - item  # >= 0 for all bins shown

    # Online estimate of the smallest item we are likely to see again.
    s = _state
    s["n"] += 1
    s["sum"] += item
    if item < s["min"]:
        s["min"] = item
    n = s["n"]
    mean = s["sum"] / n
    # Expected minimum of a sample of the same size seen so far (rough, robust):
    # use a fraction of the running mean, floored at 1.
    tiny = max(1.0, 0.25 * mean)

    # Best-fit primary: minimize residual.  But residuals below `tiny` are
    # essentially unusable; add a mild penalty so a slightly larger residual
    # that keeps the bin fillable is preferred when the tie is close.
    penalty = np.where(residual < tiny, (tiny - residual), 0.0)
    score = -(residual + 0.5 * penalty)
    return score
# EVOLVE-BLOCK-END
