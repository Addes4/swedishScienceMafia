# EVOLVE-BLOCK-START
"""Adaptive best-fit: tightest fit, with a soft dead-zone penalty for tiny unusable residuals."""
import numpy as np

_state = {"n": 0, "s": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Running mean of observed item sizes (cheap online estimate).
    _state["n"] += 1
    _state["s"] += item
    mean = _state["s"] / _state["n"]

    resid = bins - item  # post-placement remaining capacity, >= 0

    # Primary score: prefer tightest fit (smaller residual -> higher score).
    score = -resid.astype(np.float64)

    # Dead zone: residuals strictly between 0 and a threshold slightly below the mean are
    # likely to be wasted. Push them just above the next usable residual, but only in a
    # narrow band so exact best-fit behaviour is preserved elsewhere.
    thr = 0.6 * mean
    if thr > 1.0:
        dead = (resid > 0) & (resid < thr)
        # Penalize by shifting the residual up by one, making a slightly less tight bin
        # (or a zero-residual bin) win.
        score = np.where(dead, -(resid.astype(np.float64) + 1.0), score)

    return score
# EVOLVE-BLOCK-END
