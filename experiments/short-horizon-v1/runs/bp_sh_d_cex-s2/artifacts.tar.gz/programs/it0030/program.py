# EVOLVE-BLOCK-START
"""Adaptive best-fit with residual-quality tie-breaking.

Primary rule: best fit (tightest remaining capacity).  Among bins that are
within a small tolerance of the tightest fit, prefer the bin whose
post-placement residual is close to a "good" leftover size, estimated online
from the arriving item sizes.  This keeps large items packed tightly while
avoiding leaving tiny, unusable fragments.
"""
import numpy as np

# Online state (module-level, reset implicitly by harness between streams is
# not guaranteed, but estimates converge quickly and are harmless).
_sum = 0.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)  # rounded size histogram buckets


def priority(item, bins):
    global _sum, _count, _hist

    _sum += item
    _count += 1
    _hist[item] += 1.0
    mean = _sum / _count

    # Tightest fit residual
    resid = bins - item

    # score: higher is better.  Base: prefer small residual.
    base = -resid.astype(np.float64)

    # Residual-quality term: reward residuals that are either small (close to
    # full) OR close to the running mean item size (usable leftover), and
    # penalize tiny-but-nonzero residuals that likely become waste.
    # tolerance window around best fit
    best = resid.min()
    near = resid <= (best + 2)

    # measure of "goodness" of a residual
    dist_to_mean = np.abs(resid - mean)
    # residual == 0 is best; residuals near mean are good; tiny leftovers bad.
    quality = np.where(resid == 0, 10.0,
                       np.where(np.abs(resid - mean) <= 2.0, 3.0,
                                -np.minimum(resid, 5.0) * 0.1))

    score = base + 0.35 * quality
    # only let quality matter within the near-best window
    score = np.where(near, score, base)

    return score
# EVOLVE-BLOCK-END
