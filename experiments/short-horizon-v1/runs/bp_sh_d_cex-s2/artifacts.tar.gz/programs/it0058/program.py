# EVOLVE-BLOCK-START
"""Best-fit with a bounded anti-sliver fallback.

Primary rule: best fit (leave the smallest feasible residual). However, best fit can
strand tiny slivers of capacity that no future item can use. To limit that, when the
tightest feasible placement leaves a residual below a sliver threshold, we instead pick,
among bins whose residual is still small (within a tolerance window of the best-fit
residual), the one whose residual is closest to the running mean item size -- i.e. a
residual that a typical future item could actually fill. Otherwise pure best fit wins.

State kept across calls within a stream: running count and sum of item sizes to estimate
the mean item size.
"""
import numpy as np

# Module-level state (reset per stream is handled by the harness importing fresh).
_state = {"n": 0, "sum": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority per bin; item goes to the highest (first on ties)."""
    # Update running mean estimate.
    _state["n"] += 1
    _state["sum"] += float(item)
    mean = _state["sum"] / _state["n"] if _state["n"] else 40.0

    residual = bins - item  # capacity left if the item goes here (>= 0 guaranteed)

    # Best fit: smaller residual is better.
    best = -residual.astype(np.float64)

    # Sliver threshold and tolerance window scale with the current mean item size.
    sliver = 0.5 * mean
    window = 0.5 * mean

    best_res = residual.min()
    if best_res < sliver:
        # Among bins within the tolerance window of the best residual, prefer the
        # residual nearest the typical item size (usable leftover).
        near = residual <= best_res + window
        target = mean
        # higher score = closer to target; keep best-fit as a strong base so ties
        # outside the window never overtake a strictly tighter placement.
        adj = -np.abs(residual.astype(np.float64) - target)
        best = np.where(near, best + 1e-3 * adj, best)

    return best
# EVOLVE-BLOCK-END
