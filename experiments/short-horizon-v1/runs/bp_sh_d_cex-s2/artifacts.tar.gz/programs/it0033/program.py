# EVOLVE-BLOCK-START
"""Best fit with a controlled preference against tiny unusable residuals.

Primary rule: tightest fit (minimise remaining capacity after placing the item).
Secondary, sub-dominant rule: among bins that fit, mildly penalise creating a
residual in the "waste zone" (1..3) which no future item from the Weibull-shaped
distribution (mean ~40, min 1) is likely to ever fill.  The penalty is kept tiny
so it only breaks near-ties and never overrides a genuinely tighter fit.
"""
import numpy as np

_WASTE_LO = 1
_WASTE_HI = 3
_EPS = 1e-3


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item
    # Base: prefer tightest fit (most negative residual => highest score).
    score = -residual.astype(np.float64)
    # Tiny bonus for leaving a comfortably reusable residual, tiny penalty for
    # leaving a nearly unusable one.  Bounded well below 1 so it only breaks ties.
    waste = (residual >= _WASTE_LO) & (residual <= _WASTE_HI)
    bonus = np.where(residual == 0, _EPS, 0.0)
    bonus -= np.where(waste, _EPS, 0.0)
    return score + bonus
# EVOLVE-BLOCK-END

