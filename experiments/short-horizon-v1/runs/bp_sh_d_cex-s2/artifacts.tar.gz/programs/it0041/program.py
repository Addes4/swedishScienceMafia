# EVOLVE-BLOCK-START
"""Best fit with an integer-safe, consolidating tie-break on the pre-placement capacity."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary key: smaller residual is much better (best fit).
    # Secondary key: ties on residual go to the bin with the larger capacity before
    # placement (emptier bin), so tight packs consolidate and roomy bins stay free.
    # Use a scale strictly smaller than 1 so it never alters the primary ordering.
    return -residual + bins / (bins.max() + 1.0) * 0.0
# EVOLVE-BLOCK-END
