# EVOLVE-BLOCK-START
"""Best fit for large items; for small items, pack into the fullest bin that fits
(reserving emptier bins for future large items)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item >= 50:
        # Best fit: tightest residual after placement.
        return -(bins - item)
    else:
        # Small item: put it in the fullest bin that fits (smallest remaining capacity),
        # keeping emptier bins available for larger future items.
        return -bins
# EVOLVE-BLOCK-END
