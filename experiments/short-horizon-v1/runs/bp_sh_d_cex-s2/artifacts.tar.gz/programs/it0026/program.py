# EVOLVE-BLOCK-START
"""Harmonic-inspired best fit: minimize residual, but avoid tiny unusable leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item
    # Small residuals (< W) are effectively wasted since few items are that small.
    W = 10
    waste_penalty = np.where((resid > 0) & (resid < W), (W - resid), 0)
    # Primary: minimize residual (best fit), but add penalty for tiny unusable leftovers.
    return -(resid + waste_penalty)
# EVOLVE-BLOCK-END

