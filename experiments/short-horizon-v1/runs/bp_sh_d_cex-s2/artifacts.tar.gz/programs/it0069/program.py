# EVOLVE-BLOCK-START
"""Best fit with a conservative harmonic residual tie-break.

Primary rule is still tightest fit (smallest post-placement residual).  A small
secondary term rewards residuals that are roughly multiples of the observed
typical item size, so leftover space tends to be consolidated into chunks that a
future item can actually use, while placement order remains best-fit.
"""
import numpy as np

_state = {"sum": 0.0, "n": 0, "m": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    # Online estimate of the typical item size (running mean, smoothed).
    st = _state
    st["sum"] += item
    st["n"] += 1
    mean = st["sum"] / st["n"]
    if st["n"] < 8:
        m = 40.0
    else:
        m = 0.7 * st["m"] + 0.3 * mean
    st["m"] = m

    resid = bins - item  # post-placement residual, item fits so resid >= 0

    # Primary: tightest fit (negate residual so smallest residual -> highest score).
    score = -(resid.astype(np.float64))

    # Secondary: reward residuals that are multiples of the typical item size,
    # i.e. minimal waste left over after packing whole typical items into residue.
    if m > 1.0:
        frac = resid.astype(np.float64) / m
        waste = np.abs(frac - np.round(frac))  # 0 when residue is a multiple of m
        score -= 0.05 * waste

    return score
# EVOLVE-BLOCK-END
