# EVOLVE-BLOCK-START
"""Harmonic-style bin-choice rule with size classes.

For each arriving item of size s we use a couple of residual thresholds derived
from the capacity (100).  The idea (from the classical Harmonic algorithm) is to
keep a bin's residual from dropping into a "useless" range that no future large
item can use comfortably.  Concretely:

* For items with s >= 50 we simply use best fit (tightest residual), since large
  items dominate and tight packing is good.
* For smaller items we prefer a bin whose post-placement residual is either
  zero (perfectly filled) or at least a threshold t(s), and among those we pick
  the tightest.  Bins that would leave a small-but-nonzero residual in the
  "awkward" zone are avoided, so future medium/large items still have room.
"""
import numpy as np


def priority(item, bins):
    # Post-placement residual for every candidate bin.
    resid = bins - item  # always >= 0 for the bins we are shown

    if item >= 50:
        # Best fit for large items: tightest residual (mostly-zero residuals win).
        return -resid.astype(np.float64)

    # Size-class threshold: aim to keep at least enough room for a "large" item
    # if we cannot close the bin completely.
    if item >= 34:
        thresh = 50
    elif item >= 20:
        thresh = 34
    elif item >= 10:
        thresh = 20
    else:
        thresh = 10

    score = np.empty(resid.shape, dtype=np.float64)
    zero = resid == 0
    good = resid >= thresh
    # Perfectly filled bins are best.
    score[zero] = 1e9
    # Bins that keep useful room come next, tightest first.
    score[good & ~zero] = 1e6 - resid[good & ~zero]
    # Awkward small residuals: only used as a fallback, tightest first.
    score[~zero & ~good] = -resid[~zero & ~good]
    return score
# EVOLVE-BLOCK-END
