# EVOLVE-BLOCK-START
"""Best fit with a residual-shape bonus aimed at reducing stranded gaps.

For each bin, the post-placement residual is r = bins - item (>= 0 for feasible bins).
Best fit minimizes r.  Pure best fit creates many tiny residuals that can never be
filled again.  We instead reward a bin when its residual r can still hold a
"typical" next item (about 40), and penalize residuals that are large but wasted
(better to leave a bin fully open).  This keeps a few bins open with healthy
residuals instead of fragmenting many bins into unusable slivers.
"""
import numpy as np


def priority(item, bins):
    r = bins - item  # post-placement residual, >= 0 for shown bins

    # Prefer tight packing (small r) as the base signal.
    score = -r.astype(np.float64)

    # Bonus when the residual is a "useful" size (can still fit an average item ~40),
    # proportional to how close r is to the typical item size.
    useful = r.clip(0, 40) / 40.0          # 0 for slivers, 1 near mean size
    score += 0.5 * useful

    # Slight preference for not touching completely empty bins (r == 100 - item),
    # so we concentrate fills in already-open bins.
    empty = (bins == 100)
    score -= np.where(empty, 0.25, 0.0)

    return score
# EVOLVE-BLOCK-END
