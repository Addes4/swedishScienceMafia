# EVOLVE-BLOCK-START
"""Adaptive best-fit: tightest fit, with tie-break favoring useful leftovers."""
import numpy as np

_SIZES = None
_COUNT = 0


def _init_state():
    global _SIZES, _COUNT
    if _SIZES is None:
        _SIZES = np.zeros(101, dtype=np.float64)
        _COUNT = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    Primary key is tightest fit (minimizes post-placement residual). Ties (and near-ties
    within 1 unit) are broken by preferring a residual that equals a frequently seen
    item size, so the leftover can later be filled exactly, reducing waste.
    """
    global _SIZES, _COUNT
    _init_state()

    item = int(item)
    bins = np.asarray(bins)

    # update online histogram of item sizes (exclude unused-bin marker inference)
    if 1 <= item <= 100:
        _SIZES[item] += 1.0
        _COUNT += 1

    residual = bins - item  # >= 0 for all shown bins

    # size frequencies (smoothed)
    total = _COUNT if _COUNT > 0 else 1.0
    freq = _SIZES / total
    # usefulness of a residual r: how likely a future item equals exactly r
    useful = np.zeros(101, dtype=np.float64)
    useful[:] = freq
    # small bonus for perfect fill (residual 0) and near-perfect small gaps
    useful[0] = max(useful[0], 0.5)

    r_clipped = np.clip(residual, 0, 100)
    usefulness = useful[r_clipped]

    # invert so highest score = smallest residual; add small usefulness tie-break
    return -residual + 0.25 * usefulness
# EVOLVE-BLOCK-END
