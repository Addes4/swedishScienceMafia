# EVOLVE-BLOCK-START
"""Best fit with a residual-usability penalty: keep leftover space reusable.

Among the bins an item fits in, prefer the tightest fit, but penalize placements
that leave a small non-zero residual (a stranded gap too small for a typical
item). A residual of exactly zero is always ideal. The "typical item size" is
tracked online as an exponential moving average so the rule adapts to the stream.
"""
import numpy as np

# State kept across calls within a stream.
_ema = [40.0]   # rough prior on mean item size


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update the running estimate of a typical item size.
    _ema[0] = 0.98 * _ema[0] + 0.02 * item
    typical = _ema[0]

    residual = bins - item          # remaining capacity after placing the item

    # Base: best fit -- smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize stranded gaps: a small positive residual that is unlikely to be
    # filled later. Residuals of exactly 0 (perfect fill) get no penalty.
    stranded = (residual > 0) & (residual < typical)
    score -= stranded.astype(np.float64) * (typical - residual) * 0.5

    return score
# EVOLVE-BLOCK-END
