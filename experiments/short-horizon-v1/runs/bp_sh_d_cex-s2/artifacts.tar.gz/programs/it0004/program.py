# EVOLVE-BLOCK-START
"""Best fit with a tiny residual-quality tie-break.

Primary score: tightest fit (largest negative residual).
Secondary score: among bins with nearly the same residual, prefer leaving a residual
that is likely to be useful later rather than a tiny sliver.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item

    # Primary: best fit.  residual is non-negative because bins only contains feasible bins.
    # Use a scaled residual so secondary terms cannot overturn a clearly better fit.
    primary = -residual.astype(np.float64)

    # Secondary: mild preference for residuals near a modest target (around 10-15)
    # over both very tiny slivers and very large empty gaps.  Scale small.
    target = 12.0
    secondary = -np.abs(residual.astype(np.float64) - target)

    return primary * 1000.0 + secondary
# EVOLVE-BLOCK-END
