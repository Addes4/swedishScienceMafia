# EVOLVE-BLOCK-START
"""Best fit with a mild dead-zone discouragement for tiny unusable residuals."""
import numpy as np

_state = {"sum": 0.0, "n": 0, "eps": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running mean of item sizes (state persists within a stream; harness resets per stream).
    s = _state["sum"] + item
    n = _state["n"] + 1
    _state["sum"] = s
    _state["n"] = n
    mean = s / n

    # Threshold below which a leftover capacity is considered a wasted gap.
    # Anchored to the running mean; kept small so it acts as a bounded perturbation.
    if _state["eps"] == 0.0:
        # small fraction of the mean, at most a few units
        _state["eps"] = max(1.0, min(6.0, mean * 0.12))
    eps = _state["eps"]

    residual = bins - item  # remaining capacity after placement, >= 0
    # Primary: minimize residual (best fit). Residual 0 gets a bonus so it is used promptly.
    score = -(residual.astype(np.float64))
    # Penalize tiny-but-nonzero residuals that would likely waste space.
    small = (residual > 0) & (residual < eps)
    score[small] -= 0.5
    return score
# EVOLVE-BLOCK-END
