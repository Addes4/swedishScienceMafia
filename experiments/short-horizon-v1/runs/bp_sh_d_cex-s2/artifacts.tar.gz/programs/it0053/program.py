# EVOLVE-BLOCK-START
"""Best fit for large items, mild worst-fit balancing for small items."""
import numpy as np


def priority(item, bins):
    """Rank bins: tightest fit, but for small items balance the load a bit.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in, a numpy int64 array.
    """
    # Best fit residual (smaller is better) -> negative so higher score wins.
    score = -(bins - item)

    # For small items, instead of always stuffing the tightest bin, prefer
    # bins with more room so that residual capacity stays usable for later
    # items. This spreads the "sliver" problem out and, empirically, reduces
    # the number of bins on online streams for this item distribution.
    if item <= 20:
        # Prefer larger remaining capacity, but keep it a mild nudge so the
        # dominant term is still fit quality.
        score = score * 0.05 + bins.astype(np.float64) * 0.95

    return score
# EVOLVE-BLOCK-END
