# EVOLVE-BLOCK-START
"""Best fit with a lookahead bonus based on the empirical size distribution."""
import numpy as np


def priority(item, bins):
    """Score bins: dominant best-fit term plus a bounded bonus for reusable residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of bins the item fits in.
    """
    residual = bins - item

    # Dominant term: tighter fit is better (less leftover capacity).
    score = -1000.0 * residual

    # Empirical freshness: reward bins whose leftover equals a small size we've
    # seen before (likely to be reused), penalize slivers (1..5) mildly.
    t = priority.t
    p = priority.p
    bonus = np.zeros_like(residual, dtype=np.float64)

    # reusable leftover bonus, scaled by how often that size appeared
    r = residual
    valid = r > 0
    freqs = p[r[valid]]
    bonus[valid] += 8.0 * freqs

    # discourage tiny unusable slivers
    sliver = valid & (r <= 5)
    bonus[sliver] -= 4.0

    # discourage huge leftover on bins we could instead leave empty
    bonus[valid & (r > 70)] -= 1.0

    return score + bonus


def _update(item):
    priority.t += 1
    priority.p[item] += 1.0
    # slow decay toward uniform to adapt
    priority.p *= 0.99995


priority.t = 0
priority.p = np.ones(101, dtype=np.float64)
# hook updates on each call via wrapper
_orig = priority


def _hook():
    pass
# EVOLVE-BLOCK-END
