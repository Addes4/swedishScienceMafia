# EVOLVE-BLOCK-START
"""Perturbed best fit: minimize residual, breaking near-ties toward reusable leftovers."""
import numpy as np


class _State:
    total = 0
    count = 0


def priority(item, bins):
    residual = bins - item
    best = residual.min()
    # tolerance: residuals this close to the best are treated as tied
    tol = 3
    # reusable leftover sizes: the running mean and a few typical sizes
    if _State.count > 0:
        mean = _State.total / _State.count
    else:
        mean = 40.0
    targets = (mean, item, mean + item, 2 * item, 100 - item)

    # score: primary = smaller residual, secondary = closeness to a reusable size
    # (only matters within tolerance of the minimum).
    near = (residual <= best + tol)
    dist = np.full(residual.shape, 1e9)
    for t in targets:
        d = np.abs(residual - t)
        dist = np.minimum(dist, d)

    score = -residual.astype(np.float64)
    # add a bounded bonus (<= tol*0.5) for near-best bins with reusable leftovers
    bonus = np.where(near, np.maximum(0.0, tol * 0.5 - dist * 0.1), 0.0)
    score = score + bonus

    _State.total += item
    _State.count += 1
    return score
# EVOLVE-BLOCK-END
