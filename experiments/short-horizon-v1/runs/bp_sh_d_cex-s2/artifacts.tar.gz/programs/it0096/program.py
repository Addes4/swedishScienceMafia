# EVOLVE-BLOCK-START
"""Best fit, mildly adjusted: prefer tight fits, but give a small smooth bonus to
bins whose post-placement residual is a "healthy" gap likely to be refilled."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Dominant term: smaller post-placement residual is better (best fit).
    score = -residual.astype(np.float64)
    # Small deterministic bonus for residuals that are plausible future item sizes.
    # r in [1,100]; bonus peaks around 40 (distribution mean) and is bounded small.
    r = residual.astype(np.float64)
    bonus = 0.02 * np.exp(-((r - 40.0) ** 2) / (2.0 * 20.0 ** 2))
    return score + bonus
# EVOLVE-BLOCK-END
