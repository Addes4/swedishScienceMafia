# EVOLVE-BLOCK-START
"""Best fit with a frequency-aware tie-break on the leftover residual."""
import numpy as np


def priority(item, bins):
    """Rank bins for the arriving item; highest score wins (first on ties).

    Primary key: smallest post-placement residual (classic best fit).
    Secondary: among near-tied bins, favor residuals that match commonly seen
    item sizes, which future items can fill exactly.
    """
    # Histogram of observed item sizes stored on the function object.
    hist = priority.hist

    # Record the arriving item size (before ranking) so later calls know it.
    hist[item] += 1

    residual = bins - item  # remaining capacity after placing this item

    # Frequency weight of each candidate residual: how often an item of that
    # exact size has been seen so far (reward exact-fit opportunities).
    # residual can be 0..100; only 1..100 correspond to possible item sizes.
    n = hist.size
    freq = np.zeros_like(residual)
    valid = (residual >= 1) & (residual <= 100)
    freq[valid] = hist[residual[valid]]

    # Normalize freq into [0,1) and keep it strictly secondary to residual.
    maxf = hist.max()
    if maxf > 0:
        freq_score = freq / (maxf + 1.0)
    else:
        freq_score = np.zeros_like(freq, dtype=np.float64)

    # Score: primary is -residual; secondary is +freq_score (fractional so it
    # never overrides a smaller residual by a full unit).
    return -residual.astype(np.float64) + freq_score.astype(np.float64)


# Persistent state: a histogram over item sizes 1..100 (index 0 unused).
priority.hist = np.zeros(101, dtype=np.int64)
# EVOLVE-BLOCK-END
