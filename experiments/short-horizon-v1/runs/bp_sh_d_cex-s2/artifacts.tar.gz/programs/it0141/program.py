# EVOLVE-BLOCK-START
"""Best fit with exact-fill bonus and mild residual tie-breaking."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Primary: smaller residual is better (best fit).
    score = -residual.astype(np.float64)

    # Large bonus for perfectly filling a bin.
    score += 500.0 * (residual == 0).astype(np.float64)

    # Tiny preference among near-equal residuals for values that are not
    # awkwardly small: leaving a tiny residual tends to waste space.
    score += 0.001 * (residual > 0).astype(np.float64)

    return score
# EVOLVE-BLOCK-END
