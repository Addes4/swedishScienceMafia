# EVOLVE-BLOCK-START
"""Best fit with an integer-safe tie-break on recent usage."""
import numpy as np

_state = {"last": -1}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # what would be left after placing here
    # Primary: best fit -> smaller residual is better.
    # Tie-break: avoid the most recently used bin to spread out placements.
    # residual is integer, so scaling by a small factor keeps the primary order exact.
    score = -residual.astype(np.float64)
    last = _state["last"]
    if 0 <= last < bins.shape[0] and bins[last] >= item:
        score[last] -= 0.25
    best = int(np.argmax(score))
    _state["last"] = best
    return score
# EVOLVE-BLOCK-END
