# EVOLVE-BLOCK-START
"""Best fit with a learned-distribution "leftover usefulness" tie-break.

Primary key: post-placement residual (tightest fit), exactly as best-fit.
Secondary key: among bins whose residual is nearly identical, prefer the one whose
residual is a size that the online-estimated item distribution says is likely to arrive,
so the leftover capacity can later be exactly refilled.
"""
import numpy as np


class _State:
    def __init__(self):
        # Histogram of observed item sizes (integer 1..100).
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0
        # Smoothed probability estimate over sizes.
        self.p = np.ones(101, dtype=np.float64)

    def observe(self, item):
        item = int(item)
        if 1 <= item <= 100:
            self.counts[item] += 1.0
        self.total += 1.0


_state = _State()


def priority(item, bins):
    """Rank bins: tightest fit, tie-broken by likely-refillable leftover."""
    s = _state
    s.observe(item)

    n = int(s.total)
    if n > 0:
        # Laplace-smoothed empirical distribution; blend toward uniform while data is thin.
        alpha = 1.0
        p = (s.counts + alpha) / (n + 100.0 * alpha)
        # weight how much we trust the histogram
        trust = min(1.0, n / 200.0)
        p = trust * p + (1.0 - trust) * (1.0 / 100.0)
    else:
        p = np.full(101, 1.0 / 100.0)
    s.p = p

    residual = bins - item  # post-placement remaining capacity, >= 0
    # Zero residual is the best possible leftover (bin exactly filled, no waste).
    # usefulness[r] = probability mass that residual r can be exactly filled later.
    # For r == 0 it's perfect; otherwise weight by probability of an item of size r.
    usefulness = np.zeros(residual.shape, dtype=np.float64)
    nz = residual > 0
    idx = residual[nz]
    # exact refill probability, plus a bonus for large residuals retaining flexibility
    usefulness[nz] = p[np.clip(idx, 0, 100)]
    # zero residual: maximum usefulness (no leftover to waste)
    usefulness[~nz] = 1.0

    # Primary: minimize residual (best fit). Scale so it dominates the secondary term.
    return -residual.astype(np.float64) + 0.5 * usefulness
# EVOLVE-BLOCK-END
