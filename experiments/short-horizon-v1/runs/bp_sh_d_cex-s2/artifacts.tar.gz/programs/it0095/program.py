# EVOLVE-BLOCK-START
"""Best fit with a small exact-fit bonus: prefer tight fits, strongly reward filling exactly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Dominant term: prefer smallest residual (best fit).
    score = -residual.astype(np.float64)
    # Small bonus: reward residuals that are exactly zero (perfectly sealed bins)
    # and residuals that equal the arriving item size (gaps reusable by later
    # same-sized items). Kept small so it only breaks near-ties.
    bonus = np.zeros_like(score)
    bonus += (residual == 0) * 0.5
    bonus += (residual == item) * 0.1
    return score + bonus
# EVOLVE-BLOCK-END
