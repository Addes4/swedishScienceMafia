# EVOLVE-BLOCK-START
"""Best-fit with a "leave room" bias: among bins that keep a residual of at least half
the item (so the bin stays useful for future items), pick the tightest such bin; if no
bin qualifies, fall back to plain best-fit (tightest residual)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    qualified = residual >= (item + 1) // 2
    # Large positive bonus for qualified bins, then smaller residual wins within group.
    return np.where(qualified, 1000000.0 - residual, -residual)
# EVOLVE-BLOCK-END
