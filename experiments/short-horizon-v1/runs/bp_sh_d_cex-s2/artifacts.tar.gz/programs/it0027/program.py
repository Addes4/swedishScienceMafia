# EVOLVE-BLOCK-START
"""Hybrid: best-fit for large items, worst-fit for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item > 50:
        # Large items: tightest fit (best-fit).
        return -(bins - item)
    else:
        # Small items: prefer the emptiest bin that still fits (worst-fit),
        # to avoid creating tiny unusable residuals.
        return bins
# EVOLVE-BLOCK-END

