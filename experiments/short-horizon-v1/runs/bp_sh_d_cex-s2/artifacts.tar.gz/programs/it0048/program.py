# EVOLVE-BLOCK-START
"""Hybrid: best-fit for small items, worst-fit for large items.

Best fit excels when items are small relative to bin capacity (tight packing,
few slivers). For large items, best fit tends to close bins prematurely with
unusable slivers; worst fit keeps big bins open so large items can still pair
with future small ones. Switch based on a fixed threshold tied to the mean.
"""
import numpy as np

_THRESHOLD = 40  # roughly the distribution mean


def priority(item, bins):
    if item <= _THRESHOLD:
        # Best fit: prefer the bin whose residual after placement is smallest.
        return -(bins - item)
    # Worst fit: prefer the bin with the largest remaining capacity.
    return bins.astype(np.float64)
# EVOLVE-BLOCK-END
