# EVOLVE-BLOCK-START
"""Best fit that keeps completely empty bins in reserve for larger items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: strict best fit (smaller residual => higher score).
    score = -residual.astype(np.float64)

    # Strong bonus for an exact fill.
    score += 1000.0 * (residual == 0)

    # Keep fully empty bins in reserve for items that are at least half full,
    # so that small items do not fragment fresh bins.
    if item < 50:
        score -= 500.0 * (bins == 100)

    return score
# EVOLVE-BLOCK-END
