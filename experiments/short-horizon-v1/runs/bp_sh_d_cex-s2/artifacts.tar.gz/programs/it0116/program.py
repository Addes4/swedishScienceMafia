# EVOLVE-BLOCK-START
"""Best fit, but avoid creating residuals in the 'dead zone' just below typical item sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Best fit score: smaller residual is better.
    score = -residual.astype(np.float64)
    # Penalize residuals that fall into the "dead zone": too small to fit a
    # typical large item, so the bin becomes hard to reuse.
    # Typical item mean is about 40; the dead zone is roughly (0, 40).
    dead = (residual < 40).astype(np.float64)
    score -= 0.25 * dead * (40 - residual.astype(np.float64))
    return score
# EVOLVE-BLOCK-END
