# EVOLVE-BLOCK-START
"""Best-fit backbone with a reserve behavior for small items."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Rank bins: best-fit normally, but keep some empties available for big items.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
          (unused bins have remaining capacity 100 and are included)
    """
    _state["sum"] += item
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]

    centered = -(bins - item)  # smaller residual -> higher score

    # Number of "empty" (100) bins available in this view.
    # For small items, slightly discourage using nearly-empty bins so that
    # large future items still have room; encourage tighter packing.
    small = item < mean
    if small:
        # penalize placing small items into bins that are still nearly empty
        empty_pen = -0.5 * (bins == 100)
        centered = centered + empty_pen
    return centered
# EVOLVE-BLOCK-END
