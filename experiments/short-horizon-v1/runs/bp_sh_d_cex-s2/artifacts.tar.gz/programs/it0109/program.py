# EVOLVE-BLOCK-START
"""Average-fit: keep bins at a similar fill level to reduce stranded small gaps."""
import numpy as np


def priority(item, bins):
    """Score bins by how close their post-placement fill is to a target level.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in, in bin order.
    """
    residual = bins - item          # remaining capacity after placing the item
    used = 100 - bins               # current fill
    target = 50.0                   # aim for bins filled to about half capacity
    # prefer bins whose fill after placement is near the target; break ties toward
    # tighter fit (smaller residual) so we still consolidate when far from target.
    return -(np.abs((used + item) - target)) - 1e-3 * residual
# EVOLVE-BLOCK-END

