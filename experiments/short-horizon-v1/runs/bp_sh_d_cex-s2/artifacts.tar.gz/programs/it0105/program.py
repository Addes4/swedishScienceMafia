# EVOLVE-BLOCK-START
"""Best-fit variant: prefer to fill already-open bins before opening a fresh one."""
import numpy as np


def priority(item, bins):
    """Rank bins for the arriving item; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 guaranteed for bins shown
    # Base: best-fit -> smallest post-placement residual first.
    score = -residual.astype(np.float64)
    # Extra penalty on bins that look empty (residual before placement ~ full),
    # so a partially-filled bin is favored over opening a new one.
    score -= 0.25 * (bins >= 100 - item)
    return score
# EVOLVE-BLOCK-END
