# EVOLVE-BLOCK-START
"""Best-fit with a completion bonus and harmonic residual bucketing."""
import numpy as np


def priority(item, bins):
    """Rank bins: strongly prefer exact completions, otherwise tightest fit.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 because only fitting bins are passed in

    # Strong bonus for exactly completing a bin (item fills the remaining capacity).
    completion = (residual == 0).astype(np.float64)

    return completion * 1000.0 - residual.astype(np.float64)
# EVOLVE-BLOCK-END
