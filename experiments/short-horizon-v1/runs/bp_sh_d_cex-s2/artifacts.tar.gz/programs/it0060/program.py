# EVOLVE-BLOCK-START
"""Best fit, but never open a fresh bin while a used bin still fits the item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    used = bins < 100
    score = -(bins - item).astype(np.float64)
    # Heavily penalize opening a brand-new (empty) bin while a used bin fits.
    if used.any():
        score[~used] -= 1e6
    return score
# EVOLVE-BLOCK-END
