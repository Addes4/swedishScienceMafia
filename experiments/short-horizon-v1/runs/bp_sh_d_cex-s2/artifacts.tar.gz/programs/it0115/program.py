# EVOLVE-BLOCK-START
"""Best fit with a slight fill-level tie-break toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Rank bins: primarily best fit (smallest residual), tie-broken toward fuller bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item          # remaining capacity after placement (>= 0)
    fill = 100 - bins               # current used capacity
    # Scale the tie-break small enough that it never overrides a real residual
    # difference (residuals are integers, so < 1 in magnitude is safe).
    eps = 0.4 / float(100 + item)
    scale = 1.0 + fill * eps        # fuller bins get slightly smaller effective residual
    return -residual * scale
# EVOLVE-BLOCK-END
