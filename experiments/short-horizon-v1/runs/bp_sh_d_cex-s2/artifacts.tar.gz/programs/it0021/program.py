# EVOLVE-BLOCK-START
"""Subharmonic-style packing: prefer putting an item into a bin whose post-placement
residual lands in a fixed target class, using worst-fit within that class."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    Strategy (class-based / subharmonic flavor):
      - For small items (item <= 50): prefer bins that already contain at least one
        item (remaining capacity < 100) so we consolidate into already-open bins
        instead of repeatedly touching fresh bins; among those, use worst-fit
        (largest remaining capacity that still fits) to leave the bin as open as
        possible for future mid-size items.
      - For large items (item > 50): use best-fit to pack tightly, since they are
        hard to combine anyway.
    """
    bins = np.asarray(bins)
    resid = bins - item  # post-placement residual (>= 0 for all shown bins)

    if item <= 50:
        # Prefer already-open bins (residual < 100 - item, i.e. bin not empty).
        open_bin = (bins < 100).astype(np.float64)
        # Worst-fit among open bins: larger residual -> higher score.
        score = open_bin * 1000.0 + resid
        # Never beat an open bin with a fresh one.
        return score
    else:
        # Best-fit for large items: smallest residual wins.
        return -resid
# EVOLVE-BLOCK-END
