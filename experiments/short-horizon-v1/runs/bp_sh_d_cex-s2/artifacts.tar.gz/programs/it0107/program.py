# EVOLVE-BLOCK-START
"""Leveled best fit: prefer post-placement residuals near a target gap size.

Pure best-fit packs each item into the tightest gap, which greedily leaves many
tiny unusable residuals. Instead we score bins by how close the post-placement
residual is to a target gap (roughly half the mean item size), so the packer
maintains a healthy population of medium-size gaps that future items can use.
"""
import numpy as np

# Mean item size is about 40, so a residual near 20 is a "useful" gap.
TARGET = 20.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = np.asarray(bins, dtype=np.float64) - item
    # Highest score = residual closest to TARGET; break ties by preferring
    # the tighter (smaller) residual, which degenerates to best-fit when two
    # bins are equally distant from the target.
    return -(np.abs(residual - TARGET)) - 1e-3 * residual
# EVOLVE-BLOCK-END
