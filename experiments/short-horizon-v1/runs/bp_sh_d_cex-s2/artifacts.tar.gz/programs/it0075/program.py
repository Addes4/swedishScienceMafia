# EVOLVE-BLOCK-START
"""Best fit with a stateful penalty for stranding tiny unusable residuals."""
import numpy as np

_state = {"mean": 40.0, "n": 0}


def priority(item, bins):
    """Return a score per bin; the item goes to the highest score (first on ties).

    item: integer size 1..100.
    bins: numpy int64 remaining capacities (all bins the item fits in), bin order.
    """
    # Online estimate of the typical item size (EMA, adapts to the stream).
    m = _state["mean"]
    _state["n"] += 1
    alpha = 2.0 / (_state["n"] + 2.0)
    m = (1.0 - alpha) * m + alpha * float(item)
    _state["mean"] = m
    typ = max(1.0, m)

    residual = bins - item  # >= 0 for every bin shown

    # Primary: best fit -> smaller residual is better.
    score = -residual.astype(np.float64)

    # Penalize residuals that are positive but smaller than a typical item:
    # that space is effectively stranded and cannot hold a future average item.
    stranded = (residual > 0) & (residual < typ)
    score -= stranded.astype(np.float64) * (typ - residual.astype(np.float64))

    return score
# EVOLVE-BLOCK-END
