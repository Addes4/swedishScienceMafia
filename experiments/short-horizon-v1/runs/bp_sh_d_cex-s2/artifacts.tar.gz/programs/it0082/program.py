# EVOLVE-BLOCK-START
"""Best fit with a tiny learned residual-matching nudge."""
import numpy as np

_count = {}
_seen = 0
_sizes = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _seen
    # score: smaller residual is better (best fit). Add a small bonus when the
    # post-placement residual matches a common item size (reusable gap).
    residual = bins - item
    score = -residual.astype(np.float64)

    if _seen > 0:
        p = _sizes / _seen
        # probability mass of residual being a typical size, small weight
        match = p[np.clip(residual, 0, 100)]
        score = score + 0.5 * match

    # update histogram with this item
    if 0 <= item <= 100:
        _sizes[item] += 1.0
    _seen += 1

    return score
# EVOLVE-BLOCK-END

