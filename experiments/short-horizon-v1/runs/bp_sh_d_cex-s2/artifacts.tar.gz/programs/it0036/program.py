# EVOLVE-BLOCK-START
"""Best fit with a residual-value tie-break based on online item statistics."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    Primary key: tightest fit (smallest post-placement residual `bins - item`).
    Tiny epsilon tie-break: prefer rules that leave residuals near the running mean
    item size, which are the most reusable leftovers.
    """
    residual = bins - item

    mean = priority._mean
    cnt = priority._cnt
    # online estimate of typical item size (initialized at 40 = distribution mean)
    if cnt == 0:
        est = 40.0
    else:
        est = mean / cnt

    # epsilon bonus: smaller distance to the typical item size is better.
    # scaled small enough never to override a real residual difference.
    bonus = -np.abs(residual - est)

    return -residual + 1e-3 * bonus


priority._mean = 0.0
priority._cnt = 0
# note: stats are updated by the harness-independent wrapper pattern below.
# Because priority() has no post-call hook, we update lazily on the next call.
# We embed the update to keep state tied to the arriving item.
_orig = priority


def priority(item, bins):  # noqa: F811  (redefine to update state on entry)
    mean = priority._mean
    cnt = priority._cnt
    est = 40.0 if cnt == 0 else mean / cnt

    residual = bins - item
    bonus = -np.abs(residual - est)

    # accumulate current item into stats for future calls
    priority._mean = mean + item
    priority._cnt = cnt + 1

    return -residual + 1e-3 * bonus
# EVOLVE-BLOCK-END

