# EVOLVE-BLOCK-START
"""Best fit with a complementarity bonus for typical future items."""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Rank bins; item goes to the highest score (ties -> first bin).

    Primary term keeps best-fit behavior (small post-placement residual is good),
    a small bonus favors bins whose residual is near the typical item size so the
    leftover capacity stays useful for future items instead of being a sliver.
    """
    residual = bins - item
    complement = -np.abs(residual - _MEAN)
    return -residual.astype(np.float64) + 0.02 * complement
# EVOLVE-BLOCK-END
