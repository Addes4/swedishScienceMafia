# EVOLVE-BLOCK-START
"""Best-fit augmented with a typical-item-size-aware residual preference."""
import numpy as np

# Module-level state (persists across calls within a single stream).
_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = _state
    s["sum"] += item
    s["n"] += 1
    mean = s["sum"] / s["n"]

    residual = bins - item  # remaining capacity after placing item (>= 0)

    # Primary: best fit -> residual as small as possible.
    fit = -residual.astype(np.float64)

    # Secondary: prefer residuals that are "usable", i.e. 0 or at least a typical item.
    # A residual in (0, mean) is wasted slack; penalize it mildly.
    # Residual 0 is ideal; residuals >= mean are fine.
    small = (residual > 0) & (residual < mean)
    bonus = np.where(residual == 0, 0.5, 0.0)
    bonus = np.where(small, -0.5, bonus)

    return fit + bonus
# EVOLVE-BLOCK-END

