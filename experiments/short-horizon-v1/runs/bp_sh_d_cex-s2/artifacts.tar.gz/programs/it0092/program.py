# EVOLVE-BLOCK-START
"""Harmonic-style bin packing: score bins by the harmonic class of their residual.

Best-fit tends to leave many medium-sized gaps stranded.  The Harmonic rule places an
item into the bin whose *post-placement* residual falls into the tightest harmonic
bucket, encouraging bins to be filled to a harmonic ladder (100, 50, 33, 25, ...).
We score each bin by a decreasing harmonic value of its remaining capacity, so smaller
residuals dominate, but the ladder makes bins snap towards reusable closed classes.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Harmonic ladder: bucket boundaries at capacity / k for k = 1..M
    # Score each bin by the harmonic weight of its post-placement residual.
    residual = bins - item  # >= 0 for every bin shown

    # Bucket index k such that capacity/(k+1) < residual <= capacity/k
    # residual == 0 is the tightest class (weight 1/1).
    # We compute k = floor(capacity / residual) but handle residual == 0.
    cap = 100.0
    # Avoid division by zero.
    safe = np.where(residual > 0, residual, 1.0)
    k = np.floor(cap / safe)
    k = np.where(residual > 0, k, 1.0)

    # Harmonic weight: 1/k, decreasing in k => smaller residual gives larger score.
    # Add a tiny negative term so exact fits (residual 0) are preferred over class 1.
    score = 1.0 / k
    score = np.where(residual == 0, 2.0, score)
    return score
# EVOLVE-BLOCK-END
