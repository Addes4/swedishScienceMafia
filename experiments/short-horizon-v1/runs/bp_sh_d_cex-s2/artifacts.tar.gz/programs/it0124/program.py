# EVOLVE-BLOCK-START
"""Best fit with a small-item residual-reservation tweak.

For large items we keep strict best fit (tightest residual). For small items we
prefer bins whose post-placement residual is still >= the item size, i.e. bins
that keep the door open for a same-sized companion, breaking ties by tightest fit.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    if item >= 40:
        # strict best fit for large items
        return -residual.astype(np.float64)
    # small items: prefer residuals that still fit another item of this size,
    # then tighter fits. Encode as: primary = 0 if residual >= item else 1,
    # secondary = residual (smaller is better -> negate).
    ok = (residual >= item).astype(np.float64)
    return -ok * 1000.0 - residual.astype(np.float64)
# EVOLVE-BLOCK-END
