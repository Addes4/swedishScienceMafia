# EVOLVE-BLOCK-START
"""Best fit, with a learned tie-break that prefers useful residuals.

Primary key: post-placement residual (tightest fit, classic best-fit).
Secondary key: among effectively tied placements (residual within 1 of the best),
prefer residuals that match frequently-observed item sizes, so the leftover can
later be filled exactly. The size-frequency table is learned online from the
items seen so far in the current stream.
"""
import numpy as np

# empirical histogram of item sizes seen so far (index = size 1..100)
_FREQ = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    global _COUNT
    # learn from the arriving item
    if _COUNT == 0:
        _FREQ[:] = 0.0
    _FREQ[item] += 1.0
    _COUNT += 1

    residual = bins - item            # remaining capacity after placing
    # blend of immediate best-fit and learned usefulness of the leftover
    # normalize the frequency table to [0,1]
    if _COUNT > 0:
        freq = _FREQ / _FREQ.sum()
    else:
        freq = _FREQ
    usefulness = freq[residual]       # how likely the leftover is a future item

    # best-fit dominates; usefulness only breaks near-ties.
    # residual ranges 0..100; scale so that a 1-unit residual difference
    # outweighs any usefulness difference.
    return -(residual * 1.0) + usefulness
# EVOLVE-BLOCK-END
