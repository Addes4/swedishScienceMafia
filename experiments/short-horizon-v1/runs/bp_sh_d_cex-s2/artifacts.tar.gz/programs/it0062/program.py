# EVOLVE-BLOCK-START
"""Best fit with reserved-slack: tightest fit, but avoid leaving unusable slivers."""
import numpy as np

SLIVER_MAX = 8      # residuals <= this are considered wasted slivers
RESTORE_TARGET = 40 # aim to leave a residual near the mean item size


def priority(item, bins):
    """Score each bin; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of feasible bins.
    """
    residual = bins - item           # remaining capacity after placing the item

    # Best fit: smaller residual -> higher score (good tight packing).
    base = -residual.astype(np.float64)

    # Penalize residuals that are tiny slivers (basically wasted capacity),
    # by shifting them far below any non-sliver residual.
    sliver = residual <= SLIVER_MAX
    if np.any(sliver):
        # Among non-sliver bins, rewards larger residual up to target (usable slack),
        # so we don't needlessly reopen a bin and keep reusable capacity.
        non_sliver_val = np.where(
            residual <= RESTORE_TARGET,
            residual.astype(np.float64),
            RESTORE_TARGET - (residual - RESTORE_TARGET).astype(np.float64),
        )
        # Sliver bins get a large penalty, losing to any non-sliver that leaves usable slack.
        base = np.where(sliver, base - 1000.0, non_sliver_val)

    return base
# EVOLVE-BLOCK-END
