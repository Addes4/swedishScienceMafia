# EVOLVE-BLOCK-START
"""Adaptive residual-targeting rule.

For each arriving item we choose the bin whose remaining capacity after
placing the item is closest to a target residual.  The target adapts to the
observed item sizes: for small items we aim to leave roughly one future
"average" item's worth of room plus a little slack, for large items we simply
pack as tightly as possible (best fit).
"""
import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.total = 0.0


_state = _State()


def priority(item, bins):
    s = _state
    s.count += 1
    s.total += item
    mean = s.total / s.count

    post = bins - item  # remaining capacity after placing the item here

    if item >= mean:
        # Large-ish item: best fit (smallest post residual).
        return -post.astype(float)

    # Small item: aim to leave a residual near the running mean item size,
    # but never pack beyond what keeps a future mean-sized item plausible.
    target = min(mean, 100.0)
    return -np.abs(post.astype(float) - target)
# EVOLVE-BLOCK-END
