# EVOLVE-BLOCK-START
"""Harmonic-style bin choice: bucket the post-placement residual into geometrically
growing classes and prefer the tightest fit within the smallest useful class."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since only bins that fit are shown

    # Harmonic buckets on the residual: class 0 is residual < item/2 (very tight),
    # then each subsequent class roughly doubles the residual width. Prefer the
    # smallest class (most tightly packed bin that keeps a matching gap), and
    # within a class prefer the smaller residual.
    # class = floor(log2(residual / item)) clamped; approximate via bit_length.
    r = residual.astype(np.int64)
    # avoid log of zero: shift so that small residuals fall in the tightest class
    shifted = r + 1
    cls = np.zeros_like(shifted)
    # bit_length of (shifted / item) implicitly: compare against item * 2^k
    # compute class by integer division loop-free using bit_length
    ratio = shifted // max(item, 1)
    # bit_length of ratio (0 -> 0)
    bl = np.zeros_like(ratio)
    tmp = ratio.copy()
    for k in range(1, 8):
        bl += (tmp >= (1 << k)).astype(np.int64)
    cls = bl

    # Higher score = better. Prefer smaller class strongly, then smaller residual.
    return -(cls * 1000.0 + residual)
# EVOLVE-BLOCK-END
