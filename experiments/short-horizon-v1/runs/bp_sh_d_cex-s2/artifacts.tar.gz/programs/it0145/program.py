# EVOLVE-BLOCK-START
"""Best-fit backbone with gap-consolidating tie-break for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    Backbone: best fit (smallest residual after placement).
    Small items: nudge toward residuals near a running target so gaps get consolidated.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Exponential moving average of item sizes seen so far (module-level state).
    state = priority.__dict__
    if 'mean_item' not in state:
        state['mean_item'] = float(item)
    else:
        state['mean_item'] = 0.99 * state['mean_item'] + 0.01 * float(item)
    mean_item = state['mean_item']

    # Strongly prefer exact fills.
    exact = (residual == 0).astype(np.float64)

    # For small items, reward residuals close to the running mean (consolidation),
    # but only mildly so best fit still dominates for genuine tight fits.
    if item < mean_item:
        # target residual band: near mean_item
        band = np.abs(residual - mean_item)
        # Normalize so the nudge stays small in magnitude.
        nudge = -0.5 * (band / (mean_item + 1.0))
    else:
        nudge = np.zeros_like(residual, dtype=np.float64)

    # Best-fit term dominates.
    return -residual.astype(np.float64) + 1e6 * exact + nudge
# EVOLVE-BLOCK-END
