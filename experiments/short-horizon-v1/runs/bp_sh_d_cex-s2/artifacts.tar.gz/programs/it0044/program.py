# EVOLVE-BLOCK-START
"""Best fit with a complementary-pairing refinement for sliver avoidance."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    residual = bins - item

    # Primary: best fit (smallest non-negative residual).
    # Secondary: avoid leaving tiny unusable slivers by nudging toward
    # residuals that complement the running mean item size.
    state = priority.state
    if state is None:
        state = priority.state = {"n": 0, "sum": 0.0}
    state["n"] += 1
    state["sum"] += item
    mean = state["sum"] / state["n"]

    # Target leftover after this placement ~ mean (so the bin can be filled again).
    # Penalize leftovers far from mean, but only as a fine tie-break.
    score = -(residual) - 1e-3 * np.abs(residual - mean)
    return score


priority.state = None
# EVOLVE-BLOCK-END

