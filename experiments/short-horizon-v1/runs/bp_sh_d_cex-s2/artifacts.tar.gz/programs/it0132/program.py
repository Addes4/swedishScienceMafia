# EVOLVE-BLOCK-START
"""Best fit with a mild residual-quality tie-break shaped by the item distribution."""
import numpy as np


def priority(item, bins):
    """Rank bins: primary best-fit (tightest fit), secondary reward non-sliver residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for every bin shown
    # Primary: tighter fit is better (smaller residual -> larger score).
    fit = -residual.astype(np.float64)
    # Secondary, small tie-break: a residual that can still host a mean-sized item (~40)
    # is a bit better than a tiny sliver, to reduce fragmentation.
    # Reward residuals close to 40, capped and scaled small relative to one unit of fit.
    bonus = -np.minimum(np.abs(residual - 40), 40) / 1000.0
    return fit + bonus
# EVOLVE-BLOCK-END
