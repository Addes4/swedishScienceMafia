# EVOLVE-BLOCK-START
"""Best-fit with a tiny stateful bonus for leaving a "useful" residual gap.

Pure best-fit (choose the bin minimizing post-placement residual) is a strong rule
for Weibull-shaped item sizes.  We keep that as the dominant term and add a very
small bounded bonus when the residual left behind is close to a small item size we
have actually observed in this stream.  A gap roughly the size of the smallest
future items is more likely to be filled later; huge stranded gaps hurt.

The bonus is deliberately tiny so the dominant best-fit ordering is preserved
except in near-ties, which is where the gains live.
"""
import numpy as np


class _State:
    __slots__ = ("n", "mean", "small")

    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.small = 5.0  # running estimate of a small item size


_state = _State()


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties)."""
    st = _state
    st.n += 1
    # online running mean (cheap, no history stored)
    st.mean += (item - st.mean) / st.n
    # track something like the smallest item sizes seen via a soft minimum
    if item < st.small or st.n == 1:
        st.small = float(item)
    else:
        st.small += 0.002 * (item - st.small)

    residual = bins - item  # >= 0 for all bins shown
    base = -residual.astype(np.float64)

    # Target gap: roughly the size of the smallest items we've seen, so the
    # leftover can still be filled by upcoming small arrivals.
    target = st.small if st.small > 0 else 5.0
    # small bounded bonus, magnitude < 1 so best-fit ordering is preserved
    # except when residuals are within 1 of each other.
    bonus = 1.0 / (1.0 + np.abs(residual - target))

    return base + 0.5 * bonus
# EVOLVE-BLOCK-END
