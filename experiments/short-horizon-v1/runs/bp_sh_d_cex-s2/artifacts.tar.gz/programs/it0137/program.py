# EVOLVE-BLOCK-START
"""Adaptive best fit: close bins aggressively for small items."""
import numpy as np


def priority(item, bins):
    """Score bins; highest wins. Prefer smallest residual, but strongly prefer
    bins that the item leaves too full to accept another item of its own size
    (i.e., residual < item), which keeps slivers consolidated."""
    residual = bins - item
    # base: best fit (smallest residual -> highest score)
    score = -residual.astype(np.float64)
    # bonus for bins that become unusable for another item of this size:
    # residual after placement < item means a same-sized item won't fit.
    closes = residual < item
    score += closes.astype(np.float64) * 50.0
    return score
# EVOLVE-BLOCK-END
