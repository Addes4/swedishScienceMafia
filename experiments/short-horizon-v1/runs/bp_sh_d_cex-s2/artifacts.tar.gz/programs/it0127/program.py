# EVOLVE-BLOCK-START
"""Best fit with a small tie-shaping bonus toward bins that close tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    base = -residual.astype(np.float64)
    # Tiny bonus for residuals in [0, item//2): these bins are tight enough that a
    # similar-sized item won't fit, so packing them now tends to close them sooner.
    bonus = (residual < (item // 2)).astype(np.float64) * 1e-3
    return base + bonus
# EVOLVE-BLOCK-END
