# EVOLVE-BLOCK-START
"""Best fit with a tie-break that prefers concentrating fill into fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize residual (best fit). Secondary: prefer bins already fuller
    # (larger fill = 100 - bins) among near-equal residuals, concentrating usage.
    fill = 100 - bins
    return -residual * 1000.0 + fill * 0.01
# EVOLVE-BLOCK-END

