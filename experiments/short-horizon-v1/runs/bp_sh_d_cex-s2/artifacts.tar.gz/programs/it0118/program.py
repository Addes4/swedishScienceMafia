# EVOLVE-BLOCK-START
"""Best fit with a first-fit tie-break: prefer the tightest residual; on ties, the earliest bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = bins.shape[0]
    idx = np.arange(n)
    # Primary: tightest fit => smallest post-placement residual.
    # Tie-break: prefer the earliest bin (first fit), by subtracting a tiny index term.
    return -(bins - item) + (n - idx) * 1e-6
# EVOLVE-BLOCK-END
