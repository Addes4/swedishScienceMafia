# EVOLVE-BLOCK-START
"""Best-fit refined with class-aware residual windows.

Items arrive online into 100-capacity bins. Plain best-fit is strong on
Weibull-shaped sizes, but it often leaves unusable slivers. This rule keeps
best-fit as the backbone while steering each item toward a residual window
appropriate to its size class, which reduces sliver creation without
sacrificing tight fits.
"""
import numpy as np


def priority(item, bins):
    b = np.asarray(bins)
    residual = b - item  # remaining capacity after placing this item

    # Size-class-specific preferred residual window (after placement):
    # - very large items (>2/3): prefer minimal residual (tightest fit)
    # - large items (>1/2): prefer small residual, but keep windows useful
    # - medium items (>1/3): aim to leave a residual near a "medium" slot
    # - small items: prefer tightest fit to fill gaps
    if item > 66:
        lo, hi = 0, 30
    elif item > 50:
        lo, hi = 0, 34
    elif item > 33:
        lo, hi = 0, 40
    else:
        lo, hi = 0, 100

    # Ideal residual within window: 0 (perfect fill) gets strongest bonus.
    # Use a smooth penalty that is 0 at residual==0 and grows with distance,
    # but capped by window edge.
    r = residual.astype(np.float64)

    # Base score: strictly decreasing in residual (best-fit).
    # Scale large enough that window preference only breaks near-ties.
    score = -r

    # Window bonus: strongly prefer residuals inside [lo, hi],
    # with extra preference for exact / near-exact fits.
    in_win = (r >= lo) & (r <= hi)
    bonus = np.zeros_like(r)
    # extra for very tight residual
    tight = np.clip(1.0 - r / (hi + 1.0), 0.0, 1.0)
    bonus = np.where(in_win, 0.5 + 0.5 * tight, 0.0)

    # Sliver avoidance: penalize tiny unusable leftovers slightly
    sliver = (r >= 1) & (r <= 2)
    bonus = np.where(sliver, bonus - 0.4, bonus)

    # Item must fit (harness guarantees fit, r>=0); guard against negatives
    score = score + bonus
    score = np.where(residual < 0, -1e9, score)
    return score
# EVOLVE-BLOCK-END
