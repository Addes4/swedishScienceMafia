# EVOLVE-BLOCK-START
"""Best-fit, but avoid stranding residual gaps too small to reuse."""
import numpy as np

_state = {"sum": 0.0, "n": 0, "ema": 40.0}


def priority(item, bins):
    # Update EMA of item sizes (online, per stream).
    _state["sum"] += item
    _state["n"] += 1
    n = _state["n"]
    # modest EMA with warmup using running mean
    mean = _state["sum"] / n
    alpha = 0.05
    _state["ema"] = (1 - alpha) * _state["ema"] + alpha * item if n > 1 else item
    typical = _state["ema"]
    # Threshold: a residual is "stranded" if 0 < residual < typical (can't fit a typical item)
    residual = bins - item  # remaining capacity after placing item
    score = -residual.astype(np.float64)  # base: best fit
    # Penalize stranded gaps (non-zero residual smaller than typical item)
    stranded = (residual > 0) & (residual < typical)
    score = score - stranded * 25.0  # push away from stranding small gaps
    return score
# EVOLVE-BLOCK-END
