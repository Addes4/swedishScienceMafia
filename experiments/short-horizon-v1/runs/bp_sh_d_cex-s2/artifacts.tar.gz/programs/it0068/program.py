# EVOLVE-BLOCK-START
"""Residual-quantized best fit with an online estimate of the typical item size."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (100), in bin order.
    """
    # Online estimate of the typical item size (mean), updated each call.
    state = priority.__dict__
    n = state.get("n", 0) + 1
    mean = state.get("mean", 40.0)
    state["n"] = n
    mean += (item - mean) / n
    state["mean"] = mean

    residual = bins - item                      # capacity left after placement
    # Best fit: smallest residual is best.
    score = -residual.astype(np.float64)
    # Mild pull toward residuals that are near 0 or near a multiple of the
    # typical item size, so stranded slack tends to be reusable.
    m = max(mean, 1.0)
    q = np.round(residual / m) * m
    # Only reward quantization where it does not force a clearly worse fit:
    # scale the correction small relative to the best-fit ordering.
    score += 0.35 * (-(residual - q) ** 2) / (m * m)
    return score
# EVOLVE-BLOCK-END
