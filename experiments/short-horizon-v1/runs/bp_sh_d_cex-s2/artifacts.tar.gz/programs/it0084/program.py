# EVOLVE-BLOCK-START
"""Best fit with a tiny stateful tie-break toward reusable residuals."""
import numpy as np


class _State:
    ema = 40.0
    count = 0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state
    st.count += 1
    # EMA of item sizes (fast start).
    a = 0.01 if st.count > 100 else (1.0 / st.count)
    st.ema += a * (item - st.ema)
    ema = st.ema

    rem = bins - item  # residual after placement
    # Base: best fit (smaller residual => better).
    base = -rem.astype(np.float64)

    # Tiny tie-break bonus: residual of 0 (perfect) or >= ema (reusable) is slightly preferred.
    bonus = np.zeros(rem.shape, dtype=np.float64)
    bonus[rem == 0] = 1e-3
    bonus[(rem >= ema) & (rem > 0)] = 5e-4

    return base + bonus
# EVOLVE-BLOCK-END
