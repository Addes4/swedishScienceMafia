# EVOLVE-BLOCK-START
"""Perturbed best fit: usually tightest fit, but avoid leaving tiny slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item
    # Best-fit base: smaller residual is better.
    score = -resid
    # Penalize leaving a sliver: a residual below half the item tends to be unusable.
    thresh = item // 2
    sliver = (resid >= 1) & (resid < thresh)
    score = score.astype(np.float64)
    score[sliver] -= 1e6
    return score
# EVOLVE-BLOCK-END
