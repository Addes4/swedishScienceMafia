# EVOLVE-BLOCK-START
"""Sliver-avoiding best fit.

Best fit minimizes the leftover residual, which tends to produce many small
unusable slivers.  Here we still pack tightly, but we add a mild preference
for residuals that are large enough to accept another typical item, so bins
keep being useful for longer.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # leftover capacity after placing the item here

    # Dominant term: best fit (smaller residual -> higher score).
    score = -residual.astype(np.float64)

    # Mild bonus for usable residuals: a bin whose residual is around the mean
    # item size (~40) but not a sliver stays useful for future items.  We keep
    # this strictly smaller than 1 so it only breaks ties between residuals
    # that differ by less than one unit of capacity.
    usable = np.minimum(residual, 60) / 60.0   # 0 for empty/sliver, grows to 1
    score += 0.5 * usable

    return score
# EVOLVE-BLOCK-END
