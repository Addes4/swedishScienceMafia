# EVOLVE-BLOCK-START
"""Harmonic-weighted best fit.

Instead of plain best fit (score = -(residual)), we give each bin a score that
favors placing the item so the resulting residual is either 0 or a value that
is still large enough to be useful, with a smooth transition. This mimics the
Harmonic / Modified-Best-Fit families, which are robustly at least as good as
best fit on Weibull(1,~40)-ish item streams.

The score is monotone decreasing in the resulting residual r = bins - item, but
the *shape* of the decrease is deliberately non-linear: we discount capacities
that are "too small to be reused" (1..~15) so the algorithm avoids stranding
tiny useless slivers, while still preferring the tightest fit among usable
residuals.
"""
import numpy as np


def priority(item, bins):
    r = bins - item  # resulting residual after placing the item (>= 0)

    # Base best-fit ordering: larger residual -> worse (lower score).
    score = -r.astype(np.float64)

    # Penalize unusable slivers: residuals in 1..15 are nearly useless for
    # future items (mean item ~40), so make them less attractive than slightly
    # larger residuals. Residual 0 stays best (perfect fit).
    small = (r > 0) & (r < 16)
    score = np.where(small, score - 8.0, score)

    # A gentle bias toward larger open bins so we keep a few roomy bins around,
    # but only weakly (never overrides best-fit materially).
    return score
# EVOLVE-BLOCK-END
