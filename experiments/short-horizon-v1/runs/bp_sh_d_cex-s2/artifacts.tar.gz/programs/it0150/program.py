# EVOLVE-BLOCK-START
"""Best fit with a recency tiebreak: fill the tightest bin, breaking ties toward
the most-recently-used fitting bin to reduce fragmentation across long streams."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin.
    """
    residual = bins - item  # >= 0 for all bins shown
    # Primary: tightest fit (smallest residual). Tie-break: prefer the bin that
    # was touched most recently, i.e. the one with the largest original index
    # among equal residuals, so we keep stacking into the same bins instead of
    # spreading items out and fragmenting space.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    return -(residual.astype(np.float64)) + idx * 1e-6
# EVOLVE-BLOCK-END
