# EVOLVE-BLOCK-START
"""Best fit with a mild residual-shaping term.

The classic best-fit rule (smallest remaining residual after placement) is
usually near-optimal for online bin packing.  We keep it as the dominant term
but add a tiny, bounded preference for residuals close to a target (roughly
half the mean item size), which can nudge a few placements away from leaving
very large unusable gaps in a partially filled bin.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    residual = bins - item
    # Dominant: tightest fit (best fit) -> most negative residual first.
    score = -residual.astype(np.float64)
    # Mild tie/shape term: prefer residuals near ~20 (half the mean size ~40),
    # scaled so it can only break near-ties, not override best-fit.
    target = 20.0
    score -= 0.002 * np.abs(residual - target)
    return score
# EVOLVE-BLOCK-END
