# EVOLVE-BLOCK-START
"""Best fit with a mild stateful preference for denser bins on near-ties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Dominant term: prefer tightest fit (smaller post-placement residual).
    score = -residual.astype(np.float64)

    # Stateful density nudge: after enough items, on near-ties prefer bins that
    # are already fuller (smaller remaining capacity) so they get sealed off
    # rather than leaving many mid-size reusable gaps.
    n = getattr(priority, "seen", 0)
    priority.seen = n + 1
    if n >= 2000:
        # small penalty proportional to how empty the bin still is
        score -= 1e-3 * bins.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
