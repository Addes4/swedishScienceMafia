# EVOLVE-BLOCK-START
"""Adaptive best-fit with completion bonus and mean-targeted residual preference."""
import numpy as np


def priority(item, bins):
    res = bins - item
    # Completion bonus: filling a bin exactly is always good.
    # Slight preference for residuals near the running mean/2 target among non-zero residuals.
    # Running mean estimate via simple exponential-ish accumulation stored on function.
    p = priority
    n = getattr(p, "n", 0) + 1
    s = getattr(p, "s", 0.0) + item
    p.n = n
    p.s = s
    mean = s / n

    # score: lower residual is better (best-fit), but exact fill gets extra reward.
    score = -res.astype(np.float64)
    score += np.where(res == 0, 1e6, 0.0)
    return score
# EVOLVE-BLOCK-END
