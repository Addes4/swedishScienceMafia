# EVOLVE-BLOCK-START
"""Best fit with a worst-fit tie-break to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smaller residual is better (best fit).
    # Secondary (tie-break, < 1 unit): larger current remaining capacity is better,
    # spreading slack and reducing fragmentation of tight bins.
    return -residual.astype(np.float64) + 0.5 * (bins.astype(np.float64) / 100.0)
# EVOLVE-BLOCK-END
