# EVOLVE-BLOCK-START
"""Best fit with a light, stateful nudge toward leaving a useful residual gap."""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["sum"] += item
    _state["count"] += 1
    mean_item = _state["sum"] / _state["count"]

    residual = bins - item
    # Base: best fit (most tightly fitting bin first).
    score = -residual.astype(np.float64)

    # Light nudge: if a bin's residual after placing is near the running mean item size,
    # it's a good candidate to be filled later, so give a tiny bonus.  Only bins that
    # are not already a very tight fit get this, preserving best fit for tight cases.
    target = mean_item
    closeness = -np.abs(residual - target).astype(np.float64)
    # scale the nudge to be much smaller than 1 unit so it only breaks near-ties
    score += 0.05 * closeness / max(1.0, target)
    return score
# EVOLVE-BLOCK-END
