# EVOLVE-BLOCK-START
"""Best fit with a small reserve: avoid stranding tiny unusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # post-placement residual, all >= 0 for bins shown

    # Base: best fit -> smaller residual is better.
    score = -residual.astype(np.float64)

    # Reserve: residuals below the mean item size are wasted chunklets; among those,
    # prefer the fuller (already more loaded) bin to consolidate small leftovers.
    mean = 40.0
    stranding = residual < mean
    # slight bonus for fuller bins (smaller pre-placement remaining capacity)
    score += stranding * (-0.001 * (bins - residual + item - item))
    # (bins - residual + item - item) == bins, so use bins directly above via simplification
    score = -residual.astype(np.float64) - 0.001 * stranding * bins.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
