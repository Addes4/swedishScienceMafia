# EVOLVE-BLOCK-START
"""Best-fit modified: prefer the fullest bin that still fits, but avoid leaving a
post-placement residual that is too small to hold a typical future item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Pre-placement remaining capacity: smaller means the bin is fuller.
    # We give the highest score to the fullest bin (least remaining capacity),
    # which consolidates items and avoids wasting loose bins.
    score = -bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
