# EVOLVE-BLOCK-START
"""Best fit with a Gaussian waste-avoidance term keyed to the running item distribution."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Stateful running statistics of past item sizes (module-level attributes).
    n = getattr(priority, "n", 0)
    s = getattr(priority, "s", 0.0)
    s2 = getattr(priority, "s2", 0.0)

    n += 1
    s += item
    s2 += item * item
    priority.n = n
    priority.s = s
    priority.s2 = s2

    mean = s / n
    var = max(s2 / n - mean * mean, 0.0)
    sd = var ** 0.5
    # Typical size of a future item; scale for what counts as a "usable" leftover.
    scale = max(sd, 5.0)

    r = bins - item  # post-placement residual, >= 0

    # Base: prefer the tightest fit (smallest residual).
    base = -r.astype(np.float64)

    # Penalize residuals that are positive but small relative to the item distribution:
    # they are likely unusable slivers. Gaussian-like penalty peaked at small residuals.
    # Strictly bounded by a sub-unit amplitude so it only refines near-ties/locality.
    amp = 0.5
    penalty = amp * np.exp(-(r / scale) ** 2)

    return base - penalty
# EVOLVE-BLOCK-END
