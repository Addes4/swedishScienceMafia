# EVOLVE-BLOCK-START
"""Best-fit with a usability bonus on the post-placement residual."""
import numpy as np

# Fixed coarse estimate of the item distribution: Weibull-shaped, mean ~40.
# Typical small/medium items we want to be able to still place afterwards.
_USABLE = np.array([10.0, 20.0, 30.0, 40.0, 50.0])
_USABLE_W = np.array([0.15, 0.20, 0.20, 0.25, 0.20])


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # >= 0 for all bins shown

    # Best-fit base: tighter fit (smaller residual) is better.
    score = -residual

    # Usability bonus: reward residuals that match sizes of items we might still
    # place, gently penalize residuals that would be awkward leftovers.
    bonus = np.zeros_like(residual)
    for u, w in zip(_USABLE, _USABLE_W):
        # closeness to a usable residual size
        bonus += w * np.exp(-((residual - u) ** 2) / (2.0 * 15.0 ** 2))
    # residuals of 0 are ideal (bin exactly filled); bonus them strongly
    bonus += 0.5 * (residual == 0.0)

    score = score + 2.0 * bonus
    return score
# EVOLVE-BLOCK-END
