# EVOLVE-BLOCK-START
"""Complement matching: prefer placing an item so the leftover matches a frequent item size."""
import numpy as np

_state = {"freq": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    freq = _state["freq"]
    # update online frequency estimate BEFORE scoring (current item counts)
    freq[item] += 1.0
    _state["n"] += 1.0

    # residual after placing item in each bin
    res = bins - item  # >= 0 for all shown bins

    # best-fit base: lower res is better -> score -res, scaled heavily
    base = -res.astype(np.float64) * 1000.0

    # complement bonus: how frequent is an item of size exactly == res?
    # normalize frequencies to a small bonus range
    tot = freq.sum()
    if tot > 0:
        bonus = freq[res] / tot * 500.0
    else:
        bonus = np.zeros_like(base)

    return base + bonus
# EVOLVE-BLOCK-END
