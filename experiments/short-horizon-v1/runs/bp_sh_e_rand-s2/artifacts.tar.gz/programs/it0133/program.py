# EVOLVE-BLOCK-START
"""Best fit with a fullness tie-break: minimize post-placement residual, tie-break to the fullest bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smallest post-placement residual (best fit).
    # Tie-break: prefer the bin that is already fullest (smallest remaining capacity),
    # which wastes less by avoiding splitting nearly-full bins' leftovers.
    return -residual.astype(np.float64) + 1e-3 * (100.0 - bins.astype(np.float64))
# EVOLVE-BLOCK-END
