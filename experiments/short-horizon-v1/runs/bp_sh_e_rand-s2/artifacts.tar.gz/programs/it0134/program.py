# EVOLVE-BLOCK-START
"""Best fit with an anti-sliver reorder: among bins that fit, prefer leaving no tiny
unusable residual. If the best-fit bin would leave a small residual (a sliver that no
future item can use), prefer instead the bin whose residual is closest to the item size
without being a sliver, otherwise fall back to strict best fit."""
import numpy as np


def priority(item, bins):
    """Rank bins so the item goes to the highest score.

    Primary idea: best fit (minimize post-placement residual). But creating a tiny
    sliver (residual below a usability floor) wastes capacity, so choices that would
    leave a sliver are demoted below choices that do not.
    """
    residual = bins - item  # >= 0 since bins only contains fitting bins

    # A sliver is a residual too small to be likely reused: below a small floor.
    # Items have mean ~40; a residual below ~8 is mostly dead space.
    sliver = residual < 8

    # Score: primary = best fit (smaller residual better => higher score).
    # Secondary: heavily penalize leaving a sliver, so non-sliver fits win.
    score = -residual.astype(np.float64)

    # Demote sliver-creating bins by a margin larger than any residual difference (<=100).
    score = score - 1000.0 * sliver

    return score
# EVOLVE-BLOCK-END
