# EVOLVE-BLOCK-START
"""Hybrid rule: large items use best fit (tight residual); small items consolidate
into the fullest bin that still fits them, keeping leftover space reusable."""
import numpy as np

# running statistics of the stream (state persists across calls within a stream)
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    residual = bins - item  # post-placement remaining capacity

    if item >= 50:
        # Large items: best fit -> maximize residual tightness (smallest residual).
        return -residual.astype(np.float64)

    # Small items: prefer the fullest bin that still fits AND leaves residual that
    # is not wasted. Primary key: smallest residual that is >= 0 but not too tiny;
    # we penalize residuals below a threshold so leftover stays reusable, then
    # consolidate toward fuller bins.
    target = mean  # a residual around the mean item size is reusable
    diff = residual - target
    score = -np.abs(diff)  # closest residual to a reusable target
    # break ties toward fuller bins (smaller residual)
    score = score * 1000.0 - residual
    return score
# EVOLVE-BLOCK-END
