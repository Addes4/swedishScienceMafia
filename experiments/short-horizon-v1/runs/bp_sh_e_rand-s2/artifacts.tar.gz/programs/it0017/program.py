# EVOLVE-BLOCK-START
"""Best fit with small-item sliver protection."""
import numpy as np

_SMALL = 12          # items at or below this size are "small"
_SLIVER_LO = 1       # residuals in [1, _SMALL-1] are considered potentially wasted slivers
_SLIVER_HI = _SMALL - 1


def priority(item, bins):
    """Score each bin; item goes to highest score (first on ties)."""
    residual = bins - int(item)          # remaining capacity after placing the item

    base = -residual.astype(np.float64)  # best-fit: tighter is better

    if item <= _SMALL:
        # Penalize residuals that are small non-zero slivers (likely unusable),
        # but only when a strictly better exact/looser option is available.
        is_sliver = (residual >= _SLIVER_LO) & (residual <= _SLIVER_HI)
        # Large negative bonus for slivers, strongest for residuals just below item size.
        penalty = np.where(is_sliver, -1000.0, 0.0)
        return base + penalty

    return base
# EVOLVE-BLOCK-END
