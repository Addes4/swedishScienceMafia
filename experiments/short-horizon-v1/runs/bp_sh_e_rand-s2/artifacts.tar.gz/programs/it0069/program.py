# EVOLVE-BLOCK-START
"""Best fit, with a strong exact-fit bonus and a symmetric-pair bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item          # capacity left after placing the item (>= 0)
    # Base: best fit -> smallest residual is best.
    score = -residual.astype(np.float64)
    # Strongly prefer an exact fill (residual 0).
    score += 1000.0 * (residual == 0)
    # Small bonus if the leftover equals the item size (a matching item finishes the bin).
    score += 0.5 * (residual == item)
    return score
# EVOLVE-BLOCK-END
