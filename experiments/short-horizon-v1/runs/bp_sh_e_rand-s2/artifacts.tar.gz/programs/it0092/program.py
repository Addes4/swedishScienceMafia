# EVOLVE-BLOCK-START
"""Best fit, with a mild penalty for leaving unusable slivers.

Pure best fit minimizes the leftover.  But a leftover of a few units can almost
never be filled by a future item (the smallest items are rare), so two bins each
holding a 1-3 unit sliver are worse than one bin with a somewhat larger leftover
that a later item might still fit into.  We therefore keep best-fit as the primary
criterion but subtract a small constant (0.5, well below the unit gap between
distinct residuals) for placements whose leftover is a tiny sliver.  This makes
the item go to the tightest *usable* fit and consolidates slivers onto fewer bins.
"""
import numpy as np

# leftover sizes that are effectively dead space
SLIVER = 3
PENALTY = 0.5


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # primary: tighter fit is better (smaller residual -> higher score)
    score = -residual.astype(np.float64)
    # secondary: mildly discourage placements that strand a tiny sliver
    score -= PENALTY * (residual <= SLIVER)
    return score
# EVOLVE-BLOCK-END
