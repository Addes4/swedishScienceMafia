# EVOLVE-BLOCK-START
"""Best fit with an age-aware tie-break: among bins whose post-placement residual is
close to the tightest, prefer the oldest bin (smallest index) to consolidate leftover
space and reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smaller residual is better (best fit).
    # Tie-break: prefer older bins (smaller index) to pack leftovers together,
    # implemented as a strictly sub-unit bonus so it never overrides the primary key.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    return -residual.astype(np.float64) - idx * (1.0 / (n + 1.0))
# EVOLVE-BLOCK-END
