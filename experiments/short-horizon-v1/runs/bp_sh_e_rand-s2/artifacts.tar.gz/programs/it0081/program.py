# EVOLVE-BLOCK-START
"""Best fit with a mild anti-fragmentation tie-break.

The item is usually placed into the bin it fits most tightly (best fit),
which is a strong online heuristic for bin packing.  To reduce
fragmentation we break near-ties towards bins with more remaining capacity,
so that a bin which is almost full is not filled with a tiny item when a
roomier bin can absorb it just as well.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin
          order.
    """
    residual = bins - item  # what would be left after placing the item here
    # Primary: prefer small residual (best fit).
    # Secondary: among similarly tight fits, prefer the roomier bin
    # (larger residual) to avoid crippling an almost-full bin.
    return -residual * 0.02 + bins
# EVOLVE-BLOCK-END
