# EVOLVE-BLOCK-START
"""Best fit with online size-aware tie-breaking for near-tight fits."""
import numpy as np

_state = {"n": 0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = _state["n"]
    mean = _state["mean"]
    n += 1
    mean = mean + (item - mean) / n
    _state["n"] = n
    _state["mean"] = mean

    rem = bins
    residual = rem - item  # >= 0 for all shown bins

    # Primary: tightest fit (smallest residual). Residuals within a small
    # learned window are treated as ties, then broken toward fuller bins.
    window = max(1.0, 0.15 * mean)

    tight = residual.min()
    near_tie = residual <= tight + window

    # Among near ties, prefer the bin that is already more loaded (smaller rem),
    # except always strongly prefer exact fits (residual 0).
    occupancy = 100 - rem  # higher = more loaded

    score = -(residual.astype(np.float64))
    score = score + 0.5 * np.where(near_tie, occupancy * 1e-3, 0.0)
    # exact fit dominates
    score = np.where(residual == 0, 1e6, score)

    return score
# EVOLVE-BLOCK-END
