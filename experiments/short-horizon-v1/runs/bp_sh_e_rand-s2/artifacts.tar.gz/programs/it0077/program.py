# EVOLVE-BLOCK-START
"""Hybrid best-fit / limited worst-fit for online bin packing.

Pure best-fit tends to strand medium-sized residuals.  We keep best-fit as the
primary signal but add a small preference for bins that leave a residual which
is itself a plausible future item size, and a mild worst-fit bias when the
tightest fit would leave a tiny (barely usable) residual.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Base: prefer tightest fit (small residual).
    score = -residual.astype(np.float64)

    # Residuals equal to the item are perfect for pairing -> strong bonus.
    score += 40.0 * (residual == item)

    # Very small residuals (items barely fitting) are near-wasteful; mildly
    # discourage them relative to using a fresher bin.
    score -= 8.0 * ((residual > 0) & (residual < item // 4) & (residual < 12))

    # A residual that is a common Weibull-ish size is more reusable later.
    # Favor residuals in a broad "medium" band slightly.
    medium = (residual >= 10) & (residual <= 60)
    score += 2.0 * medium

    return score
# EVOLVE-BLOCK-END
