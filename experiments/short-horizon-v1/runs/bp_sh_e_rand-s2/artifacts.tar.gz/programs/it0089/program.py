# EVOLVE-BLOCK-START
"""Best fit with a granularity-aware tie-break on the residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual). Secondary: prefer residuals that are
    # multiples of 10 (finer granularity -> more reusable by future medium items).
    score = -residual.astype(np.float64) - 0.001 * (residual % 10)
    return score
# EVOLVE-BLOCK-END

