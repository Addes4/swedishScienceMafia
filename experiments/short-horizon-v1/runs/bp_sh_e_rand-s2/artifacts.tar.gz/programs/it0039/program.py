# EVOLVE-BLOCK-START
"""Best-fit with a tie-break that avoids leaving dead slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Primary: best fit (smallest non-negative residual first -> highest score).
    # Secondary: among equal residuals, prefer the larger residual slightly so that
    # exact ties (common with integer capacities) favor bins less likely to become
    # unusable dead slivers. Ties in the primary key are rare but this is a cheap
    # deterministic perturbation that keeps best-fit as the backbone.
    return -(residual.astype(np.float64)) + 1e-6 * residual
# EVOLVE-BLOCK-END
