# EVOLVE-BLOCK-START
"""Best fit with a tiny tie-break toward residuals near the running mean item size."""
import numpy as np

_STATE = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _STATE["sum"] += item
    _STATE["n"] += 1
    mean = _STATE["sum"] / _STATE["n"]
    res = bins - item
    # Tiny epsilon: prefer residual near running mean item size (helps future fills).
    eps = 1e-3 * (1.0 / (1.0 + np.abs(res - mean)))
    return -(res) + eps
# EVOLVE-BLOCK-END
