# EVOLVE-BLOCK-START
"""Best fit with sliver avoidance.

Pure best-fit minimizes the residual after placement. It sometimes leaves a tiny
residual (a "sliver") that no future item can fit into, wasting that bin. We keep
the best-fit preference but penalize creating residuals that are likely unusable,
using a running estimate of the smaller item sizes seen so far.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best-fit score: prefer smallest residual.
    score = -residual.astype(np.float64)
    # Penalize tiny residuals that waste a bin (unusable slivers).
    # A residual of 1..3 is almost never reusable; slight penalty pushes the item
    # into a bin that leaves a more usable gap when possible.
    sliver = (residual >= 1) & (residual <= 3)
    score -= sliver.astype(np.float64) * 0.25
    return score
# EVOLVE-BLOCK-END

