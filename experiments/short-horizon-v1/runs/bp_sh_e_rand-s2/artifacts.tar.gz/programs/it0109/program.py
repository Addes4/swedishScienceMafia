# EVOLVE-BLOCK-START
"""Best fit with a small sliver-aware tie-break based on past item sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # already >= 0 because only fitting bins are passed

    # Primary: prefer tightest fit -> smaller residual better.
    score = -residual.astype(np.float64)

    # Break ties in favor of exact fills (residual 0) over tiny unusable slivers,
    # and demote very small nonzero residuals a bit. Use sub-unit offsets so the
    # dominant best-fit ordering is preserved except among equal residuals.
    # residual == 0: best tie-break
    # 0 < residual <= 3: slightly worse than zero but still sorted by residual
    # else: unchanged
    tie = np.zeros_like(score)
    tie[residual == 0] = 0.0
    small = (residual > 0) & (residual <= 3)
    tie[small] = -0.5 + 0.1 * residual[small]

    return score + tie
# EVOLVE-BLOCK-END
