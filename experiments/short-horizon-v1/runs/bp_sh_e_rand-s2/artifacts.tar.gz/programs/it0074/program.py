# EVOLVE-BLOCK-START
"""Distribution-aware best fit: large items pack tightly, small items balance residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)
    # Best-fit component: strongly prefer the tightest placement.
    tight = -residual
    if item >= 50:
        # Large items: best fit dominates; a tiny tie-break avoids stranding exact fits.
        return tight - 1e-6 * residual
    # Small items: keep best fit as main signal but reward residuals near a reusable
    # target (roughly half the mean item size) so leftovers can be paired later.
    target = 20.0
    balance = -np.abs(residual - target)
    return tight + 0.5 * balance
# EVOLVE-BLOCK-END
