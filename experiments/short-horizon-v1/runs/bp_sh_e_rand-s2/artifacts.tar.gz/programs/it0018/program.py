# EVOLVE-BLOCK-START
"""Best-fit with online size-class exact-fill preference."""
import numpy as np

_SIZE = 101
_FREQ = np.zeros(_SIZE, dtype=np.float64)
_TOTAL = 0.0
_DECAY = 0.9995


def priority(item, bins):
    """Rank bins: prefer tight best-fit, but strongly prefer residuals usable by common item sizes."""
    global _TOTAL
    # Update online size statistics
    _FREQ *= _DECAY
    _FREQ[item] += 1.0
    _TOTAL = _TOTAL * _DECAY + 1.0

    residual = bins - item  # >= 0 since bins only contains fitting bins

    # Best-fit tightness: smaller residual is better.
    score = -residual.astype(np.float64)

    # Bonus for exact fill (residual == 0)
    # Bonus when the residual after placing matches a common item size:
    # such a bin can be cleanly closed/refilled later with a similarly sized item.
    # Compute frequency weight of each bin's resulting residual.
    freq_weights = _FREQ[np.clip(residual, 0, 100)]
    # Normalize into a modest bonus so it only breaks near-ties / shifts close calls.
    bonus = freq_weights * 0.05
    # Extra bonus for exact fill.
    score += bonus
    score += (residual == 0) * 3.0

    return score
# EVOLVE-BLOCK-END
