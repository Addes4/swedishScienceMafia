# EVOLVE-BLOCK-START
"""Residual-matching best fit.

The classic rule is "best fit": put the item in the bin that leaves the least
residual.  We keep that as the primary ordering, but:

  * we keep a running histogram of the item sizes seen so far in this stream;
  * a placement that leaves an exactly-full bin (residual 0) is always preferred;
  * a placement whose residual matches a frequently-seen item size is nudged
    up a little, since that leftover is likely to be reusable soon;
  * ties (and near ties) prefer the older, lower-indexed bin so that the
    partially filled bins get consolidated rather than being left scattered.

Everything is a monotone transformation of the pure best-fit ordering plus a
small bounded bonus, so short streams keep their exact best-fit behaviour.
"""

import numpy as np

_CAP = 100
_HIST = np.zeros(_CAP + 1, dtype=np.float64)
_TOTAL = 0.0            # total items seen (as a float counter)
_SEEN = 0               # integer count of items seen


def priority(item, bins):
    """Return a priority per bin; highest score wins, ties go to first bin."""
    global _HIST, _TOTAL, _SEEN

    item = float(item)

    # --- update the running size histogram before scoring ---
    _SEEN += 1
    _HIST[int(item)] += 1.0
    _TOTAL += 1.0

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item                     # capacity left after placing

    # ---- base ordering: best fit (smallest residual is best) ----
    # negate so smaller residual => larger score; scale large enough that the
    # bonuses below only ever break near-ties.
    score = -residual * 1000.0

    # ---- exact fit is essentially always right ----
    score += (residual <= 0.0).astype(np.float64) * 500000.0

    # ---- right-size the leftover: a residual that matches a common size is
    #      valuable because a later item of that size fills the bin exactly ----
    hist_share = _HIST / _TOTAL
    idx = np.clip(residual.astype(np.int64), 0, _CAP)
    score += hist_share[idx] * 200.0

    # ---- mild age bonus: older (lower index) bins are touched first ----
    n = bins.shape[0]
    age = np.arange(n, dtype=np.float64)
    score += (1.0 - age / max(n, 1)) * 5.0

    return score
# EVOLVE-BLOCK-END
