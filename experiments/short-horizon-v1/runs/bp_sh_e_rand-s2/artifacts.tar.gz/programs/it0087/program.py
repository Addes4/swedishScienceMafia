# EVOLVE-BLOCK-START
"""Best fit with a residual-usefulness bonus from an online item histogram."""
import numpy as np


class _State:
    def __init__(self):
        # counts of past item sizes (1..100)
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def update(self, item):
        self.counts[item] += 1.0
        self.total += 1.0
        # decay so old sizes matter less (mild)
        if self.total > 4096:
            self.counts *= 0.5
            self.total *= 0.5


_state = _State()


def priority(item, bins):
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # leftover if item placed here

    # best-fit component: prefer smallest non-negative residual
    best_fit = -residual

    # residual-usefulness: how often a past item exactly equals this residual
    idx = np.clip(residual.astype(np.int64), 0, 100)
    useful = _state.counts[idx]
    # normalize by total to keep scale comparable to best_fit units
    denom = _state.total if _state.total > 0 else 1.0
    useful = useful / denom

    # weight: only meaningful for small items; large items dominated by best-fit
    w = 1.0 if item <= 45 else 0.0

    score = best_fit + w * 200.0 * useful
    _state.update(item)
    return score
# EVOLVE-BLOCK-END
