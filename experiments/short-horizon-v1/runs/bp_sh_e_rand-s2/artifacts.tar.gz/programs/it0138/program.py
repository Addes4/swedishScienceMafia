# EVOLVE-BLOCK-START
"""Best fit with a small consolidation tie-break towards fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item          # post-placement residual (>= 0 since item fits)
    load = 100.0 - bins             # how full the bin already is
    # Primary: smallest residual (best fit). Tie-break: larger load first.
    return -residual + 1e-6 * load
# EVOLVE-BLOCK-END

