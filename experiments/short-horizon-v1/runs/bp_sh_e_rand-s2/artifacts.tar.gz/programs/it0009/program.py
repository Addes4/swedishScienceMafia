# EVOLVE-BLOCK-START
"""Stateful best-fit with a bonus for leaving residuals that match frequent item sizes."""
import numpy as np

_state = {"counts": {}}


def priority(item, bins):
    counts = _state["counts"]
    counts[item] = counts.get(item, 0) + 1

    residual = bins - item  # leftover capacity after placing item, per bin

    # Best-fit core: prefer the smallest non-negative residual.
    score = -residual.astype(np.float64)

    # Bonus for exact fits, which are always good.
    score += 3.0 * (residual == 0)

    # Bonus for leaving a residual that equals a frequent item size seen so far,
    # or is 100 (a fresh empty bin usable by big items).
    if counts:
        # Build a small set of "promising" residual targets from seen sizes.
        # Weight by frequency so common sizes matter more.
        targets = list(counts.items())
        n = len(targets)
        w = np.empty(n, dtype=np.float64)
        t = np.empty(n, dtype=np.int64)
        for i, (s, c) in enumerate(targets):
            t[i] = s
            w[i] = c
        w /= w.sum()

        # residual_match[b] = total weight of seen sizes equal to residual[b]
        match = np.zeros(residual.shape[0], dtype=np.float64)
        for i in range(n):
            match += w[i] * (residual == t[i])

        # Mild bonus; keep best-fit dominance for tight packing.
        score += 0.6 * match

    return score
# EVOLVE-BLOCK-END
