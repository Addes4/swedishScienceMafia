# EVOLVE-BLOCK-START
"""Best fit with a sliver-avoiding secondary term keyed by an online size histogram.

The backbone is classic best fit: tighter residual wins.  But best fit can leave a
tiny residual that no future item can ever fill ("dead sliver"), wasting that space.
We keep a running histogram of observed item sizes and, whenever the tightest fit
would leave such a low residual, we instead prefer the best fit whose residual is a
value the stream plausibly still produces (or zero).  The change is narrow so it
rarely perturbs the well-performing best-fit ordering.
"""
import numpy as np


_STATE = {"hist": None, "count": 0}


def priority(item, bins):
    """Return a priority per bin; item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item  # >= 0 for all shown bins
    n = residual.shape[0]

    # --- update online size histogram (unbounded, keyed by the item size) ---
    hist = _STATE["hist"]
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        _STATE["hist"] = hist
    hist[item] += 1.0
    _STATE["count"] += 1

    # --- backbone: best fit = smallest residual ---
    best_res = int(residual.min())
    best_idx = int(np.argmin(residual))

    # Estimate a "useful minimum size": the smallest size seen often enough that
    # leaving room for it is worthwhile.  Use the recent-histogram support.
    seen = np.nonzero(hist[1:])[0] + 1  # sizes 1..100 with count > 0
    if seen.size > 0:
        # smallest observed size among sizes with at least 2 sightings (avoid noise)
        common = np.nonzero(hist[1:] >= 2)[0] + 1
        min_useful = int(common.min()) if common.size > 0 else int(seen.min())
    else:
        min_useful = 1

    # Sliver threshold: a residual strictly below min_useful and > 0 is likely dead.
    sliver_cap = max(min_useful - 1, 0)

    if best_res == 0 or best_res > sliver_cap:
        # No problematic sliver: pure best fit, reward tighter fits.
        return -residual.astype(np.float64)

    # --- sliver case: avoid leaving an unusable tiny residual ---
    # Prefer residuals that are plausible future fill sizes (present in the
    # histogram) or exactly zero; break ties by tightness.
    plaus = hist[np.clip(residual, 0, 100)] > 0
    exact = residual == 0
    # score: big bonus for exact fill, then plausibility, then tightness
    score = (exact.astype(np.float64) * 1e6
             + plaus.astype(np.float64) * 1e3
             - residual.astype(np.float64))
    # Ensure the best-fit bin can still win if nothing better exists.
    score[best_idx] += 1e-6
    return score
# EVOLVE-BLOCK-END
