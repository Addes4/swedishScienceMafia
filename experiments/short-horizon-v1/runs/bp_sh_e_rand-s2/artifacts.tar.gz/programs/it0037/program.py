# EVOLVE-BLOCK-START
"""Subharmonic-style scoring: reward small residuals with exponential weight."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # residual capacity after placing the item
    res = bins - item  # all >= 0 since item only shown bins it fits in

    # Subharmonic with fs = 0.5 * C, C = 100 -> exponent k ≈ 50.
    # Use float to avoid overflow in integer power; residuals are 0..100.
    r = res.astype(np.float64)
    # -(residual)^k : smaller residual -> higher (less negative) score.
    return -(r ** 50)
# EVOLVE-BLOCK-END
