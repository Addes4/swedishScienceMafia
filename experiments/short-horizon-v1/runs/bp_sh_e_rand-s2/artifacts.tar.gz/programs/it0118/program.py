# EVOLVE-BLOCK-START
"""Baseline: best fit with a floor on the ideal residual.

Put the item in the bin whose post-placement residual is closest to an "ideal"
leftover.  Any residual at or below the running mean item size is considered
perfectly reusable, so those bins tie on fit quality; the tie is broken by
preferring the bin that was already the fullest (smallest remaining capacity
before placement), which consolidates items instead of scattering them across
many lightly-loaded bins.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Running mean item size, used as the "ideal reusable residual" threshold.
    mean_est = getattr(priority, "mean_est", 40.0)
    n = getattr(priority, "n", 0)
    # Update running mean with the current item.
    n += 1
    mean_est += (item - mean_est) / n
    priority.mean_est = mean_est
    priority.n = n

    residual = bins - item          # remaining capacity after placing the item
    # Distance from the ideal residual: no penalty for residuals between 0 and
    # the mean item size (perfectly reusable), growing penalty above that.
    excess = residual - mean_est
    excess = np.where(excess > 0, excess, 0.0)

    # Tie-break: prefer the fuller bin (smaller current remaining capacity).
    fill_bonus = -1e-3 * bins.astype(np.float64)

    return -excess + fill_bonus
# EVOLVE-BLOCK-END

