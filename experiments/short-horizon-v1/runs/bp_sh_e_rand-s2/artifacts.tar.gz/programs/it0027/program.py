# EVOLVE-BLOCK-START
"""Best fit with a preference for exact fills.

Put the item in the bin it fits most tightly, but treat an exact fill (residual 0)
as strictly better than any non-exact fit. This is the classic improvement over pure
best fit: closing a bin completely avoids leaving an unusable sliver.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since only fitting bins are shown
    # Strong bonus for exact fills, then tighten by residual (smaller residual = better).
    exact = (residual == 0)
    return -residual + exact * 1000.0
# EVOLVE-BLOCK-END
