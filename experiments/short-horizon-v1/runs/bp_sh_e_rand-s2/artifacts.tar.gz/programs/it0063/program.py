# EVOLVE-BLOCK-START
"""Best fit with a small penalty for consuming a residual that matches a common item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 because bins only shows fitting bins
    # Base score: best fit (prefer smallest residual after placement).
    score = -residual.astype(np.float64)
    # Light safeguard: if placing here would destroy a residual equal to a common
    # item size, nudge the score down a touch so a near-equal alternative can win.
    # Common sizes are inferred cheaply from the item itself (a coarse proxy).
    if item <= 50:
        # small items: prefer not to leave a residual equal to a small item size,
        # since small residuals pair well with future small items.
        penalty = np.where(residual < item, 0.25, 0.0)
        score -= penalty
    else:
        # large items: avoid leaving tiny unusable residuals when avoidable.
        penalty = np.where((residual > 0) & (residual < 10), 0.25, 0.0)
        score -= penalty
    return score
# EVOLVE-BLOCK-END
