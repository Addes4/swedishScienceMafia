# EVOLVE-BLOCK-START
"""Best fit with a narrow, stateful dead-sliver avoidance.

Normally place the item in the tightest fitting bin (classic best fit).
But if best fit would leave a tiny residual sliver that is unlikely to ever
be fillable by a future item (based on the running histogram of seen items),
prefer the tightest fit whose resulting residual is at least the smallest
common item size, so the leftover space stays usable.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count

    try:
        _hist
    except NameError:
        _hist = np.zeros(101, dtype=np.int64)
        _count = 0

    # Record the item for the running histogram.
    _hist[item] += 1
    _count += 1

    residual = bins - item  # >= 0 for all shown bins

    # Tightest fit (smallest residual).
    order = np.argsort(residual, kind="stable")
    best_idx = order[0]
    best_res = residual[best_idx]

    # Smallest "common" item size: the smallest size seen at least a few times.
    if _count >= 20:
        seen = np.nonzero(_hist)[0]
        common_min = 100
        for s in seen:
            if _hist[s] >= max(3, _count // 100):
                common_min = s
                break
    else:
        common_min = 1

    # Narrow dead-sliver zone: residual small and unlikely to be filled.
    K = 6
    if 1 <= best_res <= K and common_min > best_res:
        # Find the tightest fit whose residual is at least common_min.
        mask = residual >= common_min
        if mask.any():
            cand = np.where(mask)[0]
            # tightest such (smallest residual), ties to earliest bin
            cand_res = residual[cand]
            min_res = cand_res.min()
            sub = cand[cand_res == min_res]
            new_idx = sub[0]
            scores = np.zeros(len(bins), dtype=np.float64)
            scores[new_idx] = 1.0
            return scores

    # Default: best fit (highest score = smallest residual).
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

