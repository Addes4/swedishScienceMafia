# EVOLVE-BLOCK-START
"""Best fit with sliver avoidance.

Primary idea: classic best fit (leftmost, tightest residual) is near optimal, but it
occasionally creates tiny unusable residuals.  We track the smallest item size seen so
far in the stream and treat any residual strictly below that threshold as "dead space":
such placements are strongly demoted so that a slightly larger but reusable residual is
preferred instead.  Ties are broken by the residual itself (tightest first), with a
strictly sub-unit secondary term so a plain best-fit ordering is preserved otherwise.
"""
import numpy as np

_state = {"min_item": 101}


def priority(item, bins):
    global _state
    m = _state["min_item"]
    if item < m:
        m = item
        _state["min_item"] = m

    # post-placement residual
    residual = bins - item  # >= 0 by contract

    # A residual < m can never hold any future item -> dead space.
    # Demote by a large constant; dead bins are ranked worst, ordered among
    # themselves still by tightest residual.
    dead = residual < m

    # Composite key, higher is better.
    # base: prefer small residual -> use -residual scaled by a big factor.
    # sliver penalty dominates: subtract a big constant for dead placements.
    score = -residual.astype(np.float64) * 1000.0
    score -= dead.astype(np.float64) * 200000.0
    return score
# EVOLVE-BLOCK-END
