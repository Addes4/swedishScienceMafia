# EVOLVE-BLOCK-START
"""Best fit with a strong preference for exact fills."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit (tightest residual gets highest score).
    score = -residual.astype(np.float64)
    # Strong (but bounded) bonus for exact fills.
    score += 1e6 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
