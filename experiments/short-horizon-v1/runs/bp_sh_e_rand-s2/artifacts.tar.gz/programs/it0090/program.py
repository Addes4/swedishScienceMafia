# EVOLVE-BLOCK-START
"""Best fit with complementary-residual preference using an online item histogram."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.int64), "count": 0}


def priority(item, bins):
    """Rank bins: prefer residuals that match recently-seen item sizes (complementary fill),
    otherwise fall back to best fit (tightest residual)."""
    hist = _state["hist"]

    # Best-fit residual for each bin
    resid = bins - item  # >= 0 since bins shown fit the item

    # Build a preference score.  We want to favor residuals r that equal a common
    # past item size (so that residual can be exactly filled later).  Score is
    # negative so smaller residual is better; use histogram frequency to nudge.
    # Normalize: -resid + freq_bonus.  Bonus is small relative to residual gaps
    # but large enough to break near-ties.
    freq = hist  # counts per residual value
    # bonus only meaningful for resid <= 100
    bonus = np.zeros_like(resid, dtype=np.float64)
    valid = resid <= 100
    if np.any(valid):
        bonus[valid] = freq[resid[valid]].astype(np.float64)

    score = -resid.astype(np.float64) + 0.5 * bonus

    # Update state with the arriving item
    _state["hist"][item] += 1
    _state["count"] += 1

    return score
# EVOLVE-BLOCK-END
