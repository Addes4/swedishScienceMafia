# EVOLVE-BLOCK-START
"""Bounded-waste rule: prefer bins whose post-placement residual is near a target gap."""
import numpy as np

# Target residual: leave a gap large enough to still be useful for a typical future item,
# instead of squeezing out tiny unusable slivers (pure best fit's weakness).
TARGET = 20.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    # Prefer residuals close to TARGET; break ties toward tighter packing (smaller residual).
    return -np.abs(residual - TARGET) - 1e-3 * residual
# EVOLVE-BLOCK-END
