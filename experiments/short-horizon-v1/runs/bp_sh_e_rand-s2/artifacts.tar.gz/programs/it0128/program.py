# EVOLVE-BLOCK-START
"""Best fit, with a bounded reusability tie-break."""
import numpy as np

_mean = 40.0
_n = 0
_total = 0.0


def priority(item, bins):
    global _mean, _n, _total
    # running mean of observed items (used only for a soft tie-break)
    _n += 1
    _total += item
    _mean = _total / _n

    resid = bins - item  # remaining capacity after placing the item here

    # Primary: best fit (smallest residual).  Add a small reusability bonus for
    # residuals that can still hold a typical future item, so that when two bins
    # give nearly-equal residuals we keep usable chunks rather than tiny scraps.
    target = _mean
    reusable = (resid >= target).astype(np.float64)
    # closeness of the residual to a whole multiple of the target, gently
    frac = np.abs((resid / target) - np.round(resid / target))
    return -resid + 0.001 * reusable - 0.0005 * frac
# EVOLVE-BLOCK-END
