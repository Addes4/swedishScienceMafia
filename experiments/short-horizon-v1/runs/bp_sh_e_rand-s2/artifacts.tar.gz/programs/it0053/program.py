# EVOLVE-BLOCK-START
"""Best fit with a randomized top-k tie-break among nearly-full bins."""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for shown bins
    # top-k candidates: only look at the 4 fullest bins (smallest residual)
    k = 4
    n = residual.shape[0]
    if n <= k:
        return -(residual.astype(np.float64))
    idx = np.argpartition(residual, k - 1)[:k]
    sub = residual[idx]
    order = np.argsort(sub)
    chosen = idx[order]
    vals = sub[order].astype(np.float64)
    # weight: prefer larger residual (less tight) mildly, to avoid slivers
    w = np.exp(vals / 8.0)
    w = w / w.sum()
    r = np.random.random()
    acc = 0.0
    pick = chosen[0]
    for j in range(k):
        acc += w[j]
        if r <= acc:
            pick = chosen[j]
            break
    out = np.full(n, -1e9)
    out[pick] = 0.0
    # ensure only the chosen bin is selected with a high score
    res = np.full(n, -1e9)
    res[pick] = 1.0
    # fall back to best-fit score shape but keep chosen first
    score = -residual.astype(np.float64)
    score += res  # chosen gets a big bump
    return score
# EVOLVE-BLOCK-END
