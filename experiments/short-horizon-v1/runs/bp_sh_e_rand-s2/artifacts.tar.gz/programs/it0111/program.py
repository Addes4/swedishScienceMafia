# EVOLVE-BLOCK-START
"""Best fit that discourages leaving unusable slivers."""
import numpy as np


def priority(item, bins):
    """Rank bins so the item goes into the tightest bin whose leftover is
    still large enough to be worth having (not a tiny unusable sliver).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0
    # A leftover below ~half the mean item size is unlikely to be refilled;
    # demote such bins by adding a penalty proportional to the shortfall.
    threshold = 20
    penalty = np.where(residual < threshold, (threshold - residual), 0)
    return -(residual + penalty)
# EVOLVE-BLOCK-END

