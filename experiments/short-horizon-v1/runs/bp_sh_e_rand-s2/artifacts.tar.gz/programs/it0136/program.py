# EVOLVE-BLOCK-START
"""Best fit with a load-consolidation tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # capacity left after placing the item here
    # Primary: best fit (smallest residual). Secondary (tiny weight): prefer bins
    # that are already fuller (smaller pre-placement capacity), consolidating load.
    return -(residual) - 1e-6 * bins
# EVOLVE-BLOCK-END
