# EVOLVE-BLOCK-START
"""Best-fit with residual-matching bonus using an online item-size histogram."""
import numpy as np

_counts = None


def _ensure():
    global _counts
    if _counts is None:
        _counts = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Rank bins for the arriving item.

    Primary criterion: best fit (smallest residual after placement).
    Tie-break bonus: prefer residuals that are common past item sizes, so the
    leftover can likely be exactly filled by a later item.
    """
    _ensure()
    residual = bins - item

    # Normalized frequency estimate of past item sizes (0..100).
    total = _counts.sum()
    if total > 0:
        freq = _counts / total
    else:
        freq = np.zeros(101, dtype=np.float64)

    # Probability weight that a given residual r can be exactly filled later.
    # Use the observed frequency of size == r.
    r = np.clip(residual, 0, 100)
    fill_prob = np.where(residual >= 0, freq[r], 0.0)

    # Best-fit dominates; tiny bonus rewards matchable residuals, and an extra
    # nudge favors exactly-full bins (residual 0).
    score = -residual.astype(np.float64) + 1.5 * fill_prob + (residual == 0) * 0.5

    # Update histogram after scoring (online; no future information).
    _counts[item] += 1.0
    return score
# EVOLVE-BLOCK-END
