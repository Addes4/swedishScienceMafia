# EVOLVE-BLOCK-START
"""Harmonic-style bin choice tuned to a heavy-tailed, mean-~40 item distribution.

Items arrive online. Classic best-fit (smallest residual after placement) strands usable
space when items are large and variable. Instead we partition items into size classes by
fixed thresholds and, per class, prefer the bin whose post-placement residual is closest to
a class-specific target: the class boundary that would let another same-class item fit.
This is the harmonic idea, adapted to Weibull-shaped sizes with mean ~40.
"""
import numpy as np

# Class boundaries: items <= 1/2 capacity, <= 1/3, <= 1/4, ... down to 1/8, then large.
# For an item in (1/(k+1), 1/k] * C, a good residual is around ((k+1)*item - C) mod item
# i.e. fill the bin so another item of roughly the same class still fits.
_BOUNDARIES = np.array([50, 34, 25, 20, 17, 15, 13, 12], dtype=np.int64)
# Target residual per class (best usable leftover for the next same-class item).
_TARGETS = np.array([25, 12, 8, 6, 5, 4, 3, 3], dtype=np.int64)
_LARGE_TARGET = 0


def priority(item, bins):
    """Rank bins so the chosen bin best matches the harmonic target residual."""
    # Determine item's class index.
    idx = int(np.searchsorted(_BOUNDARIES, item, side="right"))
    if idx >= len(_TARGETS):
        target = _LARGE_TARGET
    else:
        target = int(_TARGETS[idx])
        # Refine: we want the residual to be the smallest non-negative
        # (k*item - something) leftover that can still fit one more item.
        # Approximate by nearest multiple of item to (target + item) region.
        rem = bins - item
        # Prefer residuals that can accept another item (rem >= item) and are small;
        # otherwise fall back to target.
        fits_again = rem >= item
        # Score: closeness to a desired "usable but tight" residual.
        # Primary: among bins that can still fit another item, minimize residual.
        # Among bins that cannot, minimize residual toward target.
        small = (rem >= 0) & ~fits_again
        score = np.where(fits_again,
                         -(rem - item).astype(np.float64),            # smallest usable residual
                         -(np.abs(rem - target)).astype(np.float64))  # near target for closed bins
        return score
    # Large items: just best fit (smallest residual).
    return -(bins - item)
# EVOLVE-BLOCK-END

