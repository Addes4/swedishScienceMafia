# EVOLVE-BLOCK-START
"""Hybrid best-fit: tight packing for small items, gap-shaping for large items."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.total = 0.0
        self.residuals = []

    def update(self, item, residual):
        self.n += 1
        self.total += item
        self.residuals.append(residual)
        if len(self.residuals) > 512:
            # keep a sliding window cheaply
            self.residuals = self.residuals[-512:]


_STATE = _State()


def priority(item, bins):
    """Rank bins: highest score receives the item.

    item: integer size, 1..100.
    bins: numpy int64 remaining capacities the item fits in.
    """
    st = _STATE
    if st.n == 0:
        mean_item = 40.0
        median_res = 0.0
    else:
        mean_item = st.total / st.n
        arr = np.asarray(st.residuals, dtype=np.float64)
        median_res = float(np.median(arr))

    resid = bins - item  # remaining capacity after placing the item

    if item >= mean_item:
        # Large item: avoid creating a "wasteful" gap. Prefer residuals that match
        # or exceed a typical large gap (median residual), otherwise best-fit.
        # Score favors small residuals, but penalizes residuals sitting in the
        # (0, median_res) "awkward" zone that is hard to refill.
        base = -resid.astype(np.float64)
        awkward = (resid > 0) & (resid < median_res)
        penalty = awkward.astype(np.float64) * (median_res - resid) * 0.5
        score = base - penalty
    else:
        # Small item: classic best-fit, tightly pack.
        score = -resid.astype(np.float64)

    st.update(item, int(resid[np.argmax(score)]) if len(resid) else 0)
    return score
# EVOLVE-BLOCK-END
