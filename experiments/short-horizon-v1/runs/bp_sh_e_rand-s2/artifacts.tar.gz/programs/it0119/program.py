# EVOLVE-BLOCK-START
"""Concave best-fit: prefer tight fits but reward loading fuller bins via a concave residual score."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Concave transform of the residual so that several moderately tight fits are
    # comparable, discouraging pathological tiny leftovers that strand space.
    return -np.sqrt(residual + 1.0)
# EVOLVE-BLOCK-END
