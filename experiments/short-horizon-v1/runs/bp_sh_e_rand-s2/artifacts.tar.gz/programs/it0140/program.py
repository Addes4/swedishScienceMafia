# EVOLVE-BLOCK-START
"""Best fit with an adaptive "dead residual" preference.

Best fit is essentially optimal for tight packing, but it can strand tiny
unusable residuals. We keep best fit as the primary signal and only flip the
ranking when the residual is in a band where reusability is uncertain. The
band is derived from the online observed item sizes (never future items).
"""
import numpy as np

_state = {"n": 0, "sum": 0.0, "sumsq": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    # --- online update of observed item statistics (past items only) ---
    n = _state["n"] + 1
    s = _state["sum"] + float(item)
    ss = _state["sumsq"] + float(item) * float(item)
    _state["n"] = n
    _state["sum"] = s
    _state["sumsq"] = ss

    mean = s / n
    var = max(ss / n - mean * mean, 0.0)
    std = var ** 0.5
    # Typical smallest reusable item ~ a lower percentile of the distribution.
    # Use mean - std as a soft estimate of the small-item scale.
    small = max(1.0, mean - std)

    residual = bins - item  # post-placement residual, >= 0 for fitting bins

    # Primary: tightest fit (most negative residual difference is best fit).
    base = -residual.astype(np.float64)

    # Bonus: penalize residuals that are small but still "live" (in the
    # uncertain band [0, small)).  Dead residuals (~0) are great; big
    # residuals are flexible and cost little.  The worst case is leaving a
    # residual that is too small to be reused, roughly 0 < r < small.
    # Score the penalty symmetric around small/2.
    band = np.clip(residual, 0.0, small) - 0.5 * small
    penalty = (small * 0.5 - np.abs(band)) / (small + 1.0)

    return base - penalty
# EVOLVE-BLOCK-END
