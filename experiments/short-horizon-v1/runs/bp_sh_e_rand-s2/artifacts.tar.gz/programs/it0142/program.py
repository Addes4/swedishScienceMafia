# EVOLVE-BLOCK-START
"""Best fit with a small residual-quality adjustment.

Pure best-fit minimizes the immediate leftover. We add a tiny, bounded
adjustment that mildly favors residuals which are clearly "good" (0, i.e.
perfectly full) over residuals that sit in a middle range, without ever
overriding the tightness ordering on typical gaps.
"""
import numpy as np


def priority(item, bins):
    # Primary: tightest fit => smallest residual gets highest score.
    resid = bins - item
    score = -resid.astype(np.float64)

    # Tiny adjustment: reward perfect fills, reward untouched bins slightly,
    # and slightly penalize middling residuals that tend to become dead space.
    perfect = (resid == 0)
    untouched = (bins == 100) & (resid > 0)
    middling = (resid >= 1) & (resid <= 15)

    score += 1e-3 * perfect
    score += 5e-4 * untouched
    score -= 1e-4 * middling

    return score
# EVOLVE-BLOCK-END
