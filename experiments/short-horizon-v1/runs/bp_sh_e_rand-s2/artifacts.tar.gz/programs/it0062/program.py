# EVOLVE-BLOCK-START
"""Best fit with a strong bonus for exact/near-exact fits.

The item goes into the bin it fits most tightly (smallest residual after placement).
Ties in residual are broken deterministically by bin order (first wins), because the
harness takes the highest score and breaks ties toward the first bin. We add a small
bonus term that is strictly decreasing in residual so that an exact fit (residual 0)
always beats any other bin, and smaller residuals always beat larger ones, without
changing the fundamental best-fit ordering.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary key: smaller residual is better. Score = -residual.
    # Add a tiny secondary bonus that only matters for exact ties but is monotone
    # in residual so exact fits (residual 0) are never beaten.
    score = -residual.astype(np.float64)
    # Strongly reward residual 0 (exact fill) so it is always chosen when available.
    score = score + 1e-6 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
