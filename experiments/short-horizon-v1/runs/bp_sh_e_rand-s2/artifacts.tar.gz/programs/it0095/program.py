# EVOLVE-BLOCK-START
"""Best fit with a tiny residual-class tie-break bonus from an online item histogram."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Online histogram of observed item sizes (decayed so it adapts).
    hist = _state["hist"]
    hist *= 0.995
    hist[item] += 1.0
    _state["n"] = _state["n"] * 0.995 + 1.0

    total = hist.sum()
    if total > 0.0:
        prob = hist / total
    else:
        prob = hist

    # For each bin, bonus = probability that the leftover matches a plausible future item.
    idx = np.clip(residual, 0, 100)
    bonus = prob[idx]

    # Core best-fit ordering dominates; bonus only breaks near-ties.
    return -(residual) + 0.5 * bonus
# EVOLVE-BLOCK-END
