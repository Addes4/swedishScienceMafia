# EVOLVE-BLOCK-START
"""Best fit with unusable-sliver avoidance.

The item is placed to make the post-placement residual as small as possible, but
residuals that are positive yet too small to ever be refilled (smaller than the
smallest item seen so far) are slightly demoted.  A strictly sub-unit tie-break
prefers tighter current fits so that ties among equal residuals resolve sanely.
"""
import numpy as np

_SMALL = 1e-3


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    residual = bins - item
    # Base: prefer the smallest non-negative residual (best fit).
    score = -residual.astype(np.float64)

    # Demote unusable slivers: residual in (0, min_seen) cannot be refilled.
    min_seen = getattr(priority, "_min_seen", 100)
    sliver = (residual > 0) & (residual < min_seen)
    score = score - _SMALL * sliver

    # Strictly sub-unit tie-break among equal residuals: prefer the tighter
    # (already more filled) bin, i.e. smaller current remaining capacity.
    score = score - _SMALL * _SMALL * bins

    # Track the smallest item seen so far to refine the sliver definition.
    if item < min_seen:
        priority._min_seen = item
    return score
# EVOLVE-BLOCK-END

