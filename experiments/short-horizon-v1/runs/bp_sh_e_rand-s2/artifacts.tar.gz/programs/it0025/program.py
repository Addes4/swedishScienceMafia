# EVOLVE-BLOCK-START
"""Best-fit with a mild anti-sliver nudge.

The rule is strict best-fit except for one refinement: among bins whose fit is within a
small window of the tightest fit, prefer the bin whose residual-after-placement is either
zero or large enough to be useful (>= item size). Ties otherwise fall back to the tightest
fit, which keeps behavior close to best-fit and preserves performance on short streams.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (capacity 100), in bin order.
    """
    resid = bins - item  # residual after placing the item; >= 0 for shown bins

    # Strict best-fit base: smaller residual => higher priority.
    score = -resid.astype(np.float64)

    # Anti-sliver nudge: when a bin would leave a tiny unusable residual
    # (0 < resid < item), slightly demote it relative to bins that leave
    # a residual of 0 or >= item, provided the fit is nearly as tight.
    tight = resid.min()
    window = tight + max(1, item // 4)

    tiny_sliver = (resid > 0) & (resid < item) & (resid <= window)
    score = np.where(tiny_sliver, score - 0.5, score)

    return score
# EVOLVE-BLOCK-END
