# EVOLVE-BLOCK-START
"""Best fit with unusable-sliver demotion via a lexicographic integer key.

Primary: prefer smallest post-placement residual r = bins - item.
Demotion: if 0 < r < min_seen (a residual that no future item can refill),
treat that bin as worse than any other choice by shifting its key above the
max key of "usable" choices. This keeps tight-fit ordering intact among all
other bins while avoiding slivers.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    r = bins - item  # post-placement residual, >= 0 guaranteed by the harness

    # Largest residual is 100 - 1 = 99, so keys fit comfortably in int64.
    # Usable bins get key in [0, 99]; unusable slivers get keys shifted above 99.
    key = r.astype(np.int64).copy()

    # observed minimum item size; conservative default avoids demoting early on
    mn = getattr(priority, "_min_seen", 100)
    if item < mn:
        mn = item
        priority._min_seen = mn

    unusable = (r > 0) & (r < mn)
    # push slivers above every usable key (max usable key is 99)
    key += np.where(unusable, 200, 0)

    return -key  # highest score = smallest (demotion-adjusted) residual
# EVOLVE-BLOCK-END
