# EVOLVE-BLOCK-START
"""Best fit with a size-class aware target residual preference.

We keep best-fit tightness (prefer smaller residual after placing) but add a
bounded bonus for bins whose residual lands on a value that is "useful" to
leave free, based on an online estimate of the item-size distribution we have
observed so far.  Concretely we target residuals near the observed median and
lower-quartile item sizes, which are common completions for near-full bins.
The bonus is bounded so it cannot override a genuinely tighter fit by more
than a small amount.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sizes = []


_state = _State()


def priority(item, bins):
    st = _state
    st.n += 1
    st.sizes.append(item)

    residual = bins - item  # >= 0 for all bins shown (item fits)

    # Best-fit primary score.
    score = -residual.astype(np.float64)

    # Online target residuals: median and lower quartile of observed sizes.
    if st.n >= 8:
        arr = np.asarray(st.sizes, dtype=np.float64)
        q25 = np.quantile(arr, 0.25)
        med = np.quantile(arr, 0.5)
        targets = (q25, med)
    else:
        targets = (5.0, 20.0)

    # Bounded bonus: small lambda so best-fit wins unless residuals are close.
    lam = 0.35
    bonus = np.zeros_like(score)
    for t in targets:
        d = np.abs(residual - t)
        bonus += 1.0 / (1.0 + d)

    return score + lam * bonus
# EVOLVE-BLOCK-END
