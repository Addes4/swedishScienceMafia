# EVOLVE-BLOCK-START
"""Best-fit with an online bonus for residuals that historically get refilled."""
import numpy as np


class _State:
    def __init__(self):
        # candidate residual sizes we try to preserve (item complements)
        self.res_counts = np.zeros(101, dtype=np.float64)
        self.n = 0

    def observe(self, item, chosen_residual):
        # Record which residuals got filled by future items: approximate by
        # counting how often each item size appears as the complement target.
        self.n += 1
        if chosen_residual >= 1:
            # a residual r is "reachable" if some past item equals r
            self.res_counts[chosen_residual] += 1.0


_state = _State()


def priority(item, bins):
    res = bins - item  # leftover if item placed here
    # Base: best fit (tightest leftover). Smaller res -> higher score.
    base = -res.astype(np.float64)

    # Bonus for residuals equal to a size we've recently seen items of
    # (those residuals can plausibly be filled exactly by a future item).
    target = np.zeros_like(base)
    cnt = _state.res_counts
    # index-safe gather of historical counts for each residual
    r_clip = np.clip(res, 0, 100)
    target = cnt[r_clip]

    norm = _state.n + 1.0
    bonus = 0.5 * (target / norm)

    # Record this decision's residual class for the tightest bin
    best = np.argmax(base)
    _state.observe(item, int(res[best]))

    return base + bonus
# EVOLVE-BLOCK-END
