# EVOLVE-BLOCK-START
"""Best-fit with a tiny dead-zone guard against wasted slivers."""
import numpy as np

DEAD_ZONE = 10


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing item (>= 0 for fitting bins)

    # Strict best-fit preference: smaller residual is better.
    base = -residual.astype(np.float64)

    # If the very best fit would leave a tiny dead-zone sliver, look for a bin that
    # leaves either an exact fit (0) or a residual outside the dead zone, and prefer
    # the tightest among those.
    best_res = residual.min()
    if 1 <= best_res <= DEAD_ZONE:
        good = (residual == 0) | (residual > DEAD_ZONE)
        if good.any():
            # Among "good" bins pick the one with smallest residual; elsewhere push
            # them below all others so they are never chosen over a good bin.
            bonus = np.where(good, 1000.0 - residual, -1e9)
            return bonus
    return base
# EVOLVE-BLOCK-END
