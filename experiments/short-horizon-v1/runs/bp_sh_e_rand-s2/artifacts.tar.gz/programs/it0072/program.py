# EVOLVE-BLOCK-START
"""Best fit with an online histogram bonus for residuals that match common item sizes."""
import numpy as np

# online histogram of item sizes seen so far in the current stream
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    global _hist, _count

    # update histogram with the current item (state persists across the stream)
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item

    # base: best fit -> prefer the smallest residual
    score = -(residual.astype(np.float64))

    # bonus when the resulting residual matches a frequently seen item size,
    # so leftovers can be reused by future items of that size.
    freq = _hist[residual] / _count  # 0 for negative/out-of-range handled below

    # exact fit gets the strongest bonus
    exact = (residual == 0).astype(np.float64)

    score = score + 2.0 * freq + 3.0 * exact
    return score
# EVOLVE-BLOCK-END
