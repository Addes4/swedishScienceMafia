# EVOLVE-BLOCK-START
"""Best fit with a mild penalty for unusable slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Main objective: tighter fit (smaller residual) is better.
    score = -residual.astype(np.float64)
    # Mildly demote residuals that are tiny but nonzero: hard to refill later,
    # leaving wasted space. Exact zero is fine (bin is perfectly full).
    tiny = (residual > 0) & (residual < 15)
    score[tiny] -= 0.5
    return score
# EVOLVE-BLOCK-END

