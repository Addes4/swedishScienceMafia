# EVOLVE-BLOCK-START
"""Sum-of-squares style bin choice: convex reward on remaining capacity.

Best-fit ranks purely by residual (tightest fit wins). A convex transform of the
residual keeps tight fits favored but sharpens the preference near zero residual
and near full bins, which historically packs random-size items better.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    res = bins - item  # residual after placing the item
    # Convex (sum-of-squares) reward: prefers moderate/tight fits but heavily
    # rewards leaving a near-perfect fill or a nearly full bin.
    return -((1 - res / 100.0) ** 2)
# EVOLVE-BLOCK-END
