# EVOLVE-BLOCK-START
"""Best fit with an adaptive "good residual" bonus.

Idea: classic best-fit minimizes immediate wasted space, but it can leave many
small unusable slivers.  Slightly prefer bins whose residual after placing the
item is near the typical item size (~40), so that the gap can be refilled by a
future item, while never straying far from tightest fit.
"""
import numpy as np

_target = 40.0
_n = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _target, _n

    # Update a running estimate of the typical item size (mean ~40).
    _n += 1
    _target += (item - _target) / _n

    residual = bins - item  # >= 0 because only fitting bins are shown

    # Base: best fit (more negative residual = tighter fit = higher score).
    score = -(residual.astype(np.float64))

    # Bonus for residuals near the target residual (typical future item size).
    # Gaussian bump; modest weight so best-fit still dominates when residuals
    # are very small or very large.
    diff = residual.astype(np.float64) - _target
    score += 2.0 * np.exp(-(diff * diff) / (2.0 * 15.0 * 15.0))

    return score
# EVOLVE-BLOCK-END
