# EVOLVE-BLOCK-START
"""Harmonic-style bin-choice rule.

Items arrive online. Pure best-fit leaves many bins with small-but-positive
residuals that later items cannot use, wasting capacity.  Harmonic-type rules
partition the capacity axis into classes and try to keep residuals either very
small (so a bin closes soon) or belonging to a coarse class (so that many items
of similar size can share it).  We approximate this with a continuous score that,
for a candidate bin whose residual after placement would be r, rewards small r
but also rewards residuals that fall in the "large" region (close to a full bin),
penalising residuals that sit in an awkward middle band.
"""
import numpy as np


def priority(item, bins):
    # r = residual capacity left in the bin if the item is placed there.
    r = bins - item  # bins already only contains fitting bins, so r >= 0.

    # Score: strongly prefer tight fits, but slightly penalise residuals that
    # fall in a "middle" band (say 5..35 units) where future items of the given
    # distribution (~mean 40) can neither finish the bin tightly nor share it
    # usefully.  Residuals of 0 (bin exactly full) and large residuals (>= 40,
    # room for another typical item) are best.
    score = -r.astype(np.float64)

    middle = (r >= 5) & (r <= 35)
    score -= middle * 4.0  # small nudge away from stranded middling residuals

    perfect = (r == 0)
    score += perfect * 6.0  # bonus for filling a bin exactly

    return score
# EVOLVE-BLOCK-END
