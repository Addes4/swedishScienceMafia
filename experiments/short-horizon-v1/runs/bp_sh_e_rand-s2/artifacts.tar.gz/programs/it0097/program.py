# EVOLVE-BLOCK-START
"""Best-fit with a gentle bias toward leaving usable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual gets the highest score).
    score = -residual.astype(np.float64)
    # Gentle bonus: prefer leaving a residual large enough to still be usable.
    # Usable threshold ~ the typical small item size (mean ~40, min often small).
    usable = residual >= 8
    score += 0.25 * usable
    return score
# EVOLVE-BLOCK-END
