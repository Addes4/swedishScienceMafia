# EVOLVE-BLOCK-START
"""Best fit, normalized: fill the bin whose leftover is smallest relative to its current space."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer the tightest fit, measured as a fraction of the bin's current capacity,
    # so that nearly-full bins are not forced to keep absorbing items.
    return -residual / bins
# EVOLVE-BLOCK-END
