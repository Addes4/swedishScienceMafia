# EVOLVE-BLOCK-START
"""Adaptive best-fit with a class-dependent residual target (harmonic-style).

Items are bucketed into a few coarse size classes. For each class we keep a small
score table over post-placement residual buckets, updated online with a signal
that rewards residuals which historically led to good packing (residual that a
later item could fill tightly). The primary signal remains best fit; the table
only breaks near-ties toward reusable residuals for that size class.
"""
import numpy as np

# Number of residual buckets (0..100 capacity split into ~10-wide buckets).
NB = 11  # bucket index = residual // 10, clipped to 10

# State: for each item size class, weight per residual bucket.
# Classes: small (1-20), medium (21-45), large (46-70), huge (71-100)
NCLS = 4
_w = None
_seen = None
_last = None


def _cls(item):
    if item <= 20:
        return 0
    if item <= 45:
        return 1
    if item <= 70:
        return 2
    return 3


def _init_state():
    global _w, _seen, _last
    if _w is None:
        # subtle prior: prefer smaller residuals (best fit) for all classes
        _w = np.zeros((NCLS, NB), dtype=np.float64)
        for c in range(NCLS):
            # bucket idx r: lower residual => better. weight = -(idx)
            _w[c] = -np.arange(NB, dtype=np.float64)
        _seen = 0
        _last = None


def priority(item, bins):
    _init_state()
    global _w, _seen, _last

    # Update table using feedback from previous placement: if a bin's residual
    # after the previous item was in bucket b and the current item exactly fills
    # it (residual space == item), that residual was "good" -> reward bucket.
    if _last is not None:
        prev_resid, prev_cls = _last
        b = prev_resid // 10
        if b >= NB:
            b = NB - 1
        # reward buckets whose residual can now be matched by this item
        if prev_resid >= item:
            _w[prev_cls, b] += 0.05
        else:
            _w[prev_cls, b] -= 0.02

    c = _cls(item)

    resid = bins - item  # post-placement residual, >= 0 since item fits
    # primary: smaller residual better -> use negative residual (dominant term)
    score = resid.astype(np.float64) * 8.0
    # secondary: modest pull toward reusable residuals per class table
    b = resid // 10
    np.clip(b, 0, NB - 1, out=b)
    tab = _w[c][b.astype(np.int64)]
    score = score + tab
    # normalize the secondary magnitude (subtract mean to reduce scale drift)
    score = score - tab.mean()

    # Note: harness picks the bin with the HIGHEST score.
    # Smaller residual (best fit) is better, so negate.
    out = -score

    # record chosen residual (first max) for next-step feedback
    idx = int(np.argmax(out))
    _last = (int(resid[idx]), c)
    _seen += 1
    return out
# EVOLVE-BLOCK-END
