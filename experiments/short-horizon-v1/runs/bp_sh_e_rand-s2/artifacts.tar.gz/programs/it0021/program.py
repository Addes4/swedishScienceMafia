# EVOLVE-BLOCK-START
"""Best-fit with a mild anti-sliver tie-break among near-tied bins."""
import numpy as np


def priority(item, bins):
    """Rank bins: tightest fit wins; among near-equal fits, avoid tiny slivers."""
    residual = bins - item  # >= 0 since only fitting bins are shown

    # Best-fit base score: closest fit gets the highest score.
    best = residual.min()
    # Bins within 1 unit of the tightest fit are considered "near-tied".
    near = residual <= best + 1

    # Among near-tied bins, prefer useful outcomes:
    #   exact fill (residual 0) is ideal; otherwise a residual >= item is "useful".
    useful = (residual == 0) | (residual >= item)
    # Slight preference ordering: exact-fill > useful residual > other near-tie,
    # while still favoring tighter fits overall (smaller residual -> larger score).
    bonus = np.where(residual == 0, 2.0, np.where(useful, 1.0, 0.0))

    return -residual + np.where(near, bonus, 0.0)
# EVOLVE-BLOCK-END
