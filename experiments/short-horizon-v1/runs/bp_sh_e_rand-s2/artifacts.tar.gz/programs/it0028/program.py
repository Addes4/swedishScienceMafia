# EVOLVE-BLOCK-START
"""Best fit, with exact-fit preference for large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for shown bins

    if item >= 55:
        # Prefer exact fills strongly; otherwise best-fit but avoid tiny slivers.
        score = -residual.astype(np.float64)
        exact = residual == 0
        score = score + exact * 1000.0
        # mild penalty for tiny but nonzero slivers
        tiny = (residual > 0) & (residual < item)
        score = score - tiny * 0.5
        return score

    return -residual
# EVOLVE-BLOCK-END
