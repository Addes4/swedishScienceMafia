# EVOLVE-BLOCK-START
"""Best fit with a small-residual dead-zone avoider.

The Weibull-shaped stream has mean ~40 and many small items. Pure best fit often
drops a small item into a nearly full bin, producing a tiny unusable residual
(sliver). Later mid-size items then need a fresh bin. This rule prefers best fit
but, when the best-fit placement would leave a "dead-zone" residual that is too
small to hold any likely item, it tries a slightly looser bin that leaves a
usable residual instead. It never sacrifices more than necessary.
"""
import numpy as np

# A residual below this cannot fit most items usefully; treat as wasted.
DEAD_ZONE = 10


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    residual = bins - item  # what would remain after placing the item

    # Base: best fit = smallest non-negative residual is best.
    score = -residual.astype(np.float64)

    # Penalize placements that strand a very small positive residual, but only
    # when a better (less wasteful) option exists. Give a mild bonus for exact
    # fits and for residuals large enough to be useful.
    dead = (residual > 0) & (residual <= DEAD_ZONE)
    usable = residual > DEAD_ZONE
    exact = residual == 0

    # If any bin yields an exact fit, strongly prefer it.
    if exact.any():
        score = score + exact.astype(np.float64) * 1e6
    else:
        # Otherwise, prefer usable residuals over dead-zone residuals, but keep
        # best-fit ordering within each group by using large but finite offsets.
        score = score + usable.astype(np.float64) * 1e3
        # Mild extra bonus for residuals near common small item sizes (<=30),
        # which are frequent in the distribution, to encourage consolidation.
        score = score + np.where((residual >= 1) & (residual <= 30), 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
