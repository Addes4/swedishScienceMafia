# EVOLVE-BLOCK-START
"""Best fit with a penalty for creating dead slivers (residuals too small to be filled
by a typical future item). Tighter fits still win, but residuals in the "just barely
too small for common items" zone are discouraged via a small convex adjustment.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item
    # Base: best fit, tighter (smaller residual) is better -> -residual.
    score = -residual.astype(np.float64)
    # Penalize dead slivers: residuals in (0, ~3*item) that are too small to be
    # usefully refilled. Use a smooth penalty peaking around residual ~ mean_item.
    # Only small residuals matter; scale below 1 so it breaks near-ties.
    sliver = residual + 0.0
    pen = np.where((sliver > 0) & (sliver < 12), (12 - sliver) * 0.5, 0.0)
    return -(residual.astype(np.float64) + pen)
# EVOLVE-BLOCK-END

