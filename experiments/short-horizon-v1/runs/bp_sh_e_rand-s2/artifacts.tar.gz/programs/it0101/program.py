# EVOLVE-BLOCK-START
"""Best fit with unusable-sliver avoidance.

Pure best fit occasionally leaves a residual smaller than any item that can still
arrive, permanently wasting that capacity. We demote such residuals by adding a
strictly sub-unit penalty, so among bins with very close residuals the one that
leaves a "usable" leftover (>= smallest item seen) wins.
"""
import numpy as np

_MIN_SEEN = 101  # running minimum item size observed in this stream


def priority(item, bins):
    global _MIN_SEEN
    if item < _MIN_SEEN:
        _MIN_SEEN = item
    r = bins - item  # >= 0 for all shown bins
    score = -r.astype(np.float64)
    # Penalize residuals that are positive but smaller than the smallest item
    # seen so far (cannot be refilled). Strictly < 1 so it only breaks near ties.
    unusable = (r > 0) & (r < _MIN_SEEN)
    score -= unusable * 0.5
    return score
# EVOLVE-BLOCK-END
