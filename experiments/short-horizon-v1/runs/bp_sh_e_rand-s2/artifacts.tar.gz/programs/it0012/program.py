# EVOLVE-BLOCK-START
"""Hybrid: worst-fit for large items (>50), best-fit for smaller items.

Rationale: items above half capacity cannot be paired with any other item above half
capacity, so tightly packing a large item into the fullest fitting bin destroys a large
free space and forces a new bin later. Reserving the emptiest fitting bin for large items
keeps big gaps available. For small items (< half), best-fit minimizes fragmentation.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # residual capacity after placing the item

    if item > 50:
        # Large item: prefer bins with the most remaining capacity (worst-fit),
        # i.e. keep tight packing away from large items.
        return rem.astype(np.float64)

    # Small item: best-fit, tighter is better.
    return -rem.astype(np.float64)
# EVOLVE-BLOCK-END
