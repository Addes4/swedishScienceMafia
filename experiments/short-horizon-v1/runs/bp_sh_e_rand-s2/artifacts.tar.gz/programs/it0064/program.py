# EVOLVE-BLOCK-START
"""Best fit with strong bonus for near-exact fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item (>= 0)
    # Strongly prefer exact fits (residual 0), then best-fit ordering.
    return -(residual.astype(np.float64)) - 1000.0 * (residual == 0)
# EVOLVE-BLOCK-END

