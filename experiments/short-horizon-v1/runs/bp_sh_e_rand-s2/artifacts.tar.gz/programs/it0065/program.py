# EVOLVE-BLOCK-START
"""Best fit with exact-fit priority, preserving classic ordering otherwise."""
import numpy as np


def priority(item, bins):
    """Rank bins for the arriving item.

    Priority:
      1. Any bin that becomes exactly full (residual == item) gets the top score.
      2. Otherwise classic best fit: smallest residual after placement.
    """
    residual_after = bins - item
    scores = -residual_after.astype(np.float64)
    # Exact fill gets a small bonus so it strictly beats any non-exact fit.
    scores += 1e-6 * (residual_after == 0)
    return scores
# EVOLVE-BLOCK-END
