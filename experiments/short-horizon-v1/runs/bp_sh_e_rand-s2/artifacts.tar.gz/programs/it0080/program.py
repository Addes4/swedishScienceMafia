# EVOLVE-BLOCK-START
"""Best-fit with residual-value matching via an online item-size histogram.

The item goes to the bin minimizing the residual left behind (best fit), but ties
are broken toward residuals that match sizes we frequently see in the stream, so
that leftover space is more likely to be exactly reused by a future item.
"""
import numpy as np

# Online histogram of observed item sizes (1..100). Shared across calls within a
# stream; the harness resets module state between streams by re-importing.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    global _COUNT
    # Update the histogram with the arriving item (past items inform future choices).
    _COUNT += 1
    _HIST[item] += 1.0

    # Estimated probability mass of each residual size, smoothed so unseen sizes
    # still get a tiny nonzero value (avoids hard ties).
    total = _COUNT
    prob = (_HIST + 1.0) / (total + 101.0)

    # Best fit: smaller residual is better -> negative residual is primary key.
    residual = bins - item
    primary = -residual.astype(np.float64)

    # Secondary: reward residuals whose value is a commonly seen size. Larger
    # probability means "future items likely fit this exact leftover".
    secondary = prob[bins]  # for each bin, probability of seeing this residual size

    # Best fit dominates; the histogram term only breaks near-ties.
    return primary + 0.5 * secondary
# EVOLVE-BLOCK-END
