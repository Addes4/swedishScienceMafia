# EVOLVE-BLOCK-START
"""Best fit with a residual tolerance band and load-aware tiebreak."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best fit: prefer the smallest residual. Quantize residuals into a narrow
    # band so that near-perfect fits compete on equal footing, then within the
    # band prefer the fullest bin (largest residual consumption -> smallest bin
    # index among equal band, i.e. most-loaded earliest bin) by slightly
    # rewarding smaller index bins.
    band = 1
    quant = -(residual // band)
    # index-based tiny tiebreak: earlier (more-loaded since bins get filled in
    # order) bins win ties, which is what the harness already does; keep it
    # explicit by adding a negligible decreasing term in index.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    return quant.astype(np.float64) - 1e-6 * idx
# EVOLVE-BLOCK-END
