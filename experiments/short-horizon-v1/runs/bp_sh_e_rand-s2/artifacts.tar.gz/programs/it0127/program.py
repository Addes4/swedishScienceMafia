# EVOLVE-BLOCK-START
"""Best-fit with a residual-floor tie-break driven by running item statistics."""
import numpy as np


def priority(item, bins):
    """Rank bins so the item goes to the tightest fit that still leaves usable space.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    residual = bins - item
    # A small floor: residuals this size or below are treated as equally tight,
    # and among them we prefer the fullest bin (smallest pre-placement capacity).
    # Use a fixed modest floor so tiny strands are penalised uniformly.
    floor = 3
    tight = residual <= floor
    # Primary: negative residual scaled down so that all "tight" bins score equally.
    score = -np.where(tight, 0, residual)
    # Secondary: prefer fuller bins when residuals are close.
    score = score * 1024.0 - bins
    return score
# EVOLVE-BLOCK-END
