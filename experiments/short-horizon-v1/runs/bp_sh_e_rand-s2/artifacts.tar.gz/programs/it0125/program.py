# EVOLVE-BLOCK-START
"""Best fit with a reusability tie-break.

Primary ranking is best-fit (smallest post-placement residual). Ties are broken by
preferring the bin whose post-placement residual is most reusable for a future
mean-sized item, which avoids stranding tiny unusable leftovers.
"""
import numpy as np

# running mean of items seen so far (per-stream state)
_sum = 0.0
_n = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _sum, _n
    _sum += item
    _n += 1
    mean = _sum / _n

    residual = bins - item  # post-placement remaining capacity, all >= 0

    # Best fit: smaller residual -> higher score. Residuals are integers 0..99,
    # so scale by a factor larger than any tie-break could produce.
    score = -residual.astype(np.float64)

    # Tie-break: prefer residuals that are "reusable", i.e. closest to the running
    # mean item size (keeps a chunk usable for a typical future item). This only
    # perturbs bins whose residuals are within the same integer value, so it is a
    # pure tie-break that preserves the best-fit ordering.
    tie = -np.abs(residual - mean) * 1e-3
    return score + tie
# EVOLVE-BLOCK-END
