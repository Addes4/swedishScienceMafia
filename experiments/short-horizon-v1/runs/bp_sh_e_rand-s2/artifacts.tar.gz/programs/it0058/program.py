# EVOLVE-BLOCK-START
"""Best fit with sliver avoidance: prefer placements whose residual is either
0 or remains large enough to still hold a plausible future item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item
    # A residual of 0 is perfect. Otherwise, larger residuals are better since they
    # can still accept a future item; this is the classic best-fit ranking but with
    # a strict bonus for exactly filling a bin.
    score = -residual.astype(np.float64)
    score[residual == 0] += 200.0
    return score
# EVOLVE-BLOCK-END
