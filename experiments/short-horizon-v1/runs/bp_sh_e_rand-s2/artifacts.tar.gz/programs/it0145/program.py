# EVOLVE-BLOCK-START
"""Online bin-choice rule: best-fit with an online-learned dead-residual guard."""
import numpy as np


class _State:
    n = 0
    s = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Track observed items online (mean size), used to define a "useful" residual.
    _State.n += 1
    _State.s += item
    mean = _State.s / _State.n

    residual = bins - item  # remaining capacity after placing

    # A residual is "dead" if it is too small to hold a typical future item.
    # Use a modest fraction of the running mean as the threshold.
    dead = max(1, int(round(0.35 * mean)))

    # Score: strongly prefer small residuals, but treat any residual below `dead`
    # as equally good (dead space), so tight fits win without chasing 1..dead slivers.
    # Larger residuals are penalized proportionally so the fullest bin is preferred.
    eff = np.where(residual < dead, 0, residual - dead + 1)

    return -eff
# EVOLVE-BLOCK-END
