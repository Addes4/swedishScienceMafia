# EVOLVE-BLOCK-START
"""Best fit with a small density bonus: favor tight fits and already-packed bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (smallest residual after placing).
    score = -residual.astype(np.float64)
    # Tiny bonus: prefer bins that are currently fuller (smaller remaining capacity),
    # i.e., concentrate items into already-open bins to limit the number of open bins.
    score += (100.0 - bins.astype(np.float64)) * 1e-3
    return score
# EVOLVE-BLOCK-END

