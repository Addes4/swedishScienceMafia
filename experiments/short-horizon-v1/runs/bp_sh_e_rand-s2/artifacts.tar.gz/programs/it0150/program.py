# EVOLVE-BLOCK-START
"""Best fit with residual-usefulness tie-breaking driven by running mean item size."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.total = 0.0
        self.mean = 40.0

    def update(self, item):
        self.n += 1
        self.total += item
        self.mean = self.total / self.n


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state.update(item)

    residual = bins - item  # remaining capacity after placement (>= 0)
    mean = _state.mean
    # Useful residual threshold: gaps smaller than a typical item are hard to reuse.
    # Scale slightly below the mean so we only reject clearly-useless leftovers.
    thresh = mean

    exact = residual == 0
    if np.any(exact):
        # Prefer an exact fill; among exact fills pick the fullest original bin (ties -> first).
        return np.where(exact, bins, -1000000.0).astype(np.float64)

    # Among bins whose leftover is usable (>= thresh), pick the tightest fit.
    usable = residual >= thresh
    if np.any(usable):
        # Prefer smallest residual among usable; penalize unusable ones heavily.
        return np.where(usable, -residual, -1000000.0 - residual).astype(np.float64)

    # No usable residual: fall back to tightest fit (smallest residual).
    return (-residual).astype(np.float64)
# EVOLVE-BLOCK-END
