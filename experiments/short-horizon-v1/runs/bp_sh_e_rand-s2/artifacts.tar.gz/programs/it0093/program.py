# EVOLVE-BLOCK-START
"""Best-fit with a smooth tie-break favoring residuals that are multiples of the item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item
    # Hard best-fit dominates; the tiny term favors residuals that are exact multiples
    # of the item size (reachable by future copies of this item), a cheap tie-break.
    mod = np.mod(resid, item)
    bonus = np.where(mod == 0, 0.5, -mod / (item + 1.0))
    return -resid + bonus
# EVOLVE-BLOCK-END
