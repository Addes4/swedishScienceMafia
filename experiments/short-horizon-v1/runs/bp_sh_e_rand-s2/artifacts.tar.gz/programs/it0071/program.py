# EVOLVE-BLOCK-START
"""Best fit with a concave penalty on the leftover, discouraging tiny unusable gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: prefer tightest fit (best fit) -> -residual.
    # Add a small concave bonus so that, among near-equivalent fits, we slightly
    # prefer leftovers that are large enough to be reusable, and strongly prefer
    # an exact fit (residual 0).
    exact = (residual == 0).astype(np.float64)
    # sqrt-ish shaping: reward larger residuals a little (worst-fit nudge) but far
    # weaker than the best-fit term.
    return -residual.astype(np.float64) + 0.5 * exact
# EVOLVE-BLOCK-END
