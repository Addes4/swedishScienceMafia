# EVOLVE-BLOCK-START
"""Best-fit with a mild residual-quality tie-break.

Primary criterion: smallest residual capacity after placement (classic best fit).
Secondary (tiny) bonus: prefer placements whose resulting residual is either 0
(exact fill) or close to the typical item size (~40), which can be filled by a
later item; this nudges away from leaving unusable slivers without changing the
strict best-fit backbone.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity if item placed here

    # Primary: tightest fit (largest score = smallest residual).
    score = -residual.astype(np.float64)

    # Secondary: small bonus for residuals that are likely packable later.
    # Exact fill (residual 0) gets the strongest bonus.
    exact = (residual == 0).astype(np.float64)
    near_mean = (np.abs(residual - 40.0) <= 2.0).astype(np.float64)

    return score + 0.5 * exact + 0.25 * near_mean
# EVOLVE-BLOCK-END

