# EVOLVE-BLOCK-START
"""Best-fit variant that avoids leaving unfillable slivers.

The dominant inefficiency of pure best-fit on a Weibull(mean~40) stream is
that it packs tight and leaves tiny residuals (1..k) that can never be filled
by any future item.  We keep the best-fit ordering, but when the tightest fit
would leave a residual smaller than the smallest item size that can plausibly
still arrive, we instead pick the fit whose residual is the smallest one that
is still "usable" (>= observed min item size).  This is a pure re-ranking of
the bins we are shown; the harness still enforces capacity.
"""
import numpy as np

_MIN_ITEM = 1  # smallest item size ever seen (1..100); updated online


def priority(item, bins):
    global _MIN_ITEM
    # Track the smallest item we have ever observed (item >= 1).
    if item < _MIN_ITEM or _MIN_ITEM == 1:
        if item < _MIN_ITEM:
            _MIN_ITEM = item

    residual = bins - item  # leftover capacity after placing the item

    # Usable residuals are those that some future item (>= _MIN_ITEM) could fill.
    usable = residual >= _MIN_ITEM

    # Score: strongly prefer a usable residual; among usable ones pick the
    # tightest (best fit).  If no usable residual exists, fall back to pure
    # best fit (least residual), which is what we must do anyway.
    score = np.where(usable, -(residual + 0.0), -1e6 - residual)
    return score
# EVOLVE-BLOCK-END
