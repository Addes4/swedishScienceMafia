# EVOLVE-BLOCK-START
"""Best-fit with a mild consolidation tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: minimize post-placement residual (best fit).
    residual = bins - item
    # Tie-break: prefer fuller bins (smaller pre-placement remaining capacity) to
    # avoid wasting loose space. Weighted small enough to preserve best-fit order.
    return -residual.astype(np.float64) - 1e-3 * bins.astype(np.float64)
# EVOLVE-BLOCK-END

