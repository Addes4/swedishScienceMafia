# EVOLVE-BLOCK-START
"""Online bin-choice rule: best-fit with an adaptive "sliver" avoidance tie-break.

Pure best-fit (score = -(bins - item)) is strong, but it frequently leaves a small
positive residual that no future item can fill (a "sliver"), wasting capacity.
We keep the tightest-fit ordering as the primary signal, then add a *sub-unit*
bonus/penalty that depends on the post-placement residual:

  - residual == 0            -> perfectly full, small extra reward
  - residual in [lo, hi]     -> valuable: likely fillable by a future item, small reward
  - 0 < residual < lo        -> unusable sliver, small penalty

`lo` is the smallest item size observed so far (any residual below it can never be
filled again); `hi` is a soft upper bound derived from the observed mean item size.
All bonuses have magnitude < 1, so they only break near-ties and never override
the tightest-fit preference.
"""
import numpy as np

_state = {"min_item": 100, "sum_item": 0.0, "count": 0}


def priority(item, bins):
    # --- update streaming statistics of past items (item sizes are integers 1..100)
    st = _state
    if item < st["min_item"]:
        st["min_item"] = item
    st["sum_item"] += item
    st["count"] += 1

    lo = st["min_item"]                 # smallest item seen so far (>=1)
    mean_item = st["sum_item"] / st["count"]
    hi = max(lo, int(round(mean_item)))  # soft "useful residual" band upper edge

    r = bins - item                     # post-placement residual

    # Primary: tightest fit (smaller residual ranks higher).
    score = -r.astype(np.float64)

    # Sub-unit tie-break: reward useful residuals, penalize unusable slivers.
    eps = 1e-3
    exact = (r == 0)
    sliver = (r > 0) & (r < lo)
    useful = (r >= lo) & (r <= hi)

    score += eps * exact.astype(np.float64)
    score -= eps * sliver.astype(np.float64)
    score += 0.5 * eps * useful.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
