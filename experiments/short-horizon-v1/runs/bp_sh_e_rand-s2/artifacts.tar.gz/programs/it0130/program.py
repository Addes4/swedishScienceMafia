# EVOLVE-BLOCK-START
"""Harmonic-style bin choice.

Items are bucketed into size classes by fixed thresholds derived from the
capacity (capacity 100).  For an item of class k the "ideal" residual after
placement is (1/k - 1/(k+1)) * C-like fraction of capacity, i.e. we prefer to
leave a residual that exactly matches the amount needed so the bin can still
accept a future item of the *next smaller* class.  This mirrors the harmonic
packing scheme, which is known to outperform best fit on heavy-tailed /
Weibull-shaped size distributions because it keeps residuals in reusable
chunks instead of stranding them.
"""
import numpy as np

C = 100.0

# Class boundaries: class k covers items of size in (C/(k+1), C/k].
# We use a modest number of classes; harmonic packing benefits from several.
_BOUNDARIES = np.array([C / k for k in range(1, 17)], dtype=np.float64)  # 100, 50, 33.3, ...


def _class_target(item):
    """Return the ideal post-placement residual for an item of this size."""
    # Find k such that item is in class k (C/(k+1) < item <= C/k).
    # For class k the harmonic scheme aims to fill bins to a level where the
    # residual ~ C/k - item's share; a robust surrogate is to target a residual
    # equal to the smallest class boundary that is >= item (so another same-ish
    # item still fits) minus the item, bounded to [0, C].
    k = 1
    for b in _BOUNDARIES:
        if item <= b:
            break
        k += 1
    # target residual: allow one more item of the next class to fit nicely
    # next class boundary is C/(k) (larger items) -> give room for one more
    target = C / k - item
    if target < 0.0:
        target = 0.0
    return target


def priority(item, bins):
    """Return a priority for every bin: prefer residuals near the class target."""
    residual = bins.astype(np.float64) - float(item)
    target = _class_target(item)
    # Prefer post-placement residuals close to the harmonic target, and among
    # those, prefer the fuller bin (smaller residual) via a strong secondary
    # term so ties resolve toward bin index 0 as usual.
    dist = np.abs(residual - target)
    return -dist - 1e-6 * residual
# EVOLVE-BLOCK-END
