# EVOLVE-BLOCK-START
"""Best-fit variant: aim for a residual close to the running mean item size."""
import numpy as np


class _State:
    total = 0.0
    count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing this item

    # running mean item size (streaming, no future info)
    _State.total += item
    _State.count += 1
    mean_size = _State.total / _State.count

    # Exact fill is always ideal.
    exact = residual == 0

    # Otherwise we'd like the leftover to resemble a typical future item so it
    # can be filled later; measure closeness to the running mean.
    dist = np.abs(residual.astype(np.float64) - mean_size)

    # Primary key: exact fill. Secondary: closeness to mean residual on the fuller side.
    score = np.where(exact, 1e9, -dist)
    return score
# EVOLVE-BLOCK-END
