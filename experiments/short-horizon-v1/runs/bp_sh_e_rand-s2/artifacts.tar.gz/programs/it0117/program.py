# EVOLVE-BLOCK-START
"""Ripe-bin best fit: prefer tight fits, but bias toward bins that were large enough
to absorb a typical item before placement."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state
    st["n"] += 1
    st["sum"] += item
    mean = st["sum"] / st["n"]
    residual = bins - item
    # Bonus for bins whose capacity before placement was >= mean (could hold a typical item)
    # but whose residual after placement drops below mean (becomes "used up").
    ripe = (bins >= mean) & (residual < mean)
    return -(residual.astype(np.float64)) + 30.0 * ripe
# EVOLVE-BLOCK-END
