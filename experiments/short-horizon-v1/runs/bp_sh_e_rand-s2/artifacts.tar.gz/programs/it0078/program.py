# EVOLVE-BLOCK-START
"""Best fit for pairable items; reserve-friendliest fit for items that fill a bin alone.

Items > 50 can never share a bin with another positive item (2*51 > 100), so consuming a
nearly-full bin with such an item is pure waste. Route them to the bin with the largest
remaining capacity that still fits (typically a fresh bin), leaving tight residuals
available for small items. For items <= 50 (which can be paired), use best fit.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    if item > 50:
        # Prefer the emptiest bin that fits: maximize remaining capacity.
        return bins.astype(np.float64)
    # Best fit: tightest residual (smallest remaining capacity that still fits).
    return -bins.astype(np.float64)
# EVOLVE-BLOCK-END
