# EVOLVE-BLOCK-START
"""Best fit with exact-fill shortcut and new-bin aversion."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: prefer the bin with the smallest residual after placement (best fit).
    score = -residual.astype(np.float64)

    # Exact-fill shortcut: strongly prefer bins where the item exactly fills the residual.
    exact = (residual == 0)
    score[exact] += 1000.0

    # Mild aversion to opening a brand-new bin (residual stays 100 after placement),
    # unless the item is large enough that using a fresh bin is reasonable.
    if item < 100:
        fresh = (bins == 100) & (~exact)
        score[fresh] -= 0.5 * (100 - item) / 100.0

    return score
# EVOLVE-BLOCK-END
