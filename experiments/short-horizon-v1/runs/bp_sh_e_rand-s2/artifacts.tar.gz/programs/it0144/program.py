# EVOLVE-BLOCK-START
"""Online best-fit with a future-aware residual target.

Pure best-fit minimizes the immediate remainder but can strand residuals that are large
enough to matter yet too small for a typical item.  We keep best-fit when the resulting
residual is "small" (likely dead), but otherwise steer toward leaving a residual close to
the observed mean item size, which the stream is most likely to fill next.  The mean is
tracked online over items seen so far in the stream.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    # Update running mean of observed items (before scoring the current one).
    _state["n"] += 1
    _state["sum"] += float(item)
    mean = _state["sum"] / _state["n"]
    if mean < 1.0:
        mean = 1.0

    resid = bins - item           # post-placement residual (>=0 for fitting bins)
    # Tightness: best-fit favors smallest residual.  We add a gentle penalty that grows
    # with the deviation of the residual from the target mean, but only for residuals that
    # are not already "dead" small.  Dead residuals get the full tight-fit bonus.
    dead = max(1.0, mean * 0.25)  # residuals below this are effectively wasted anyway
    excess = np.maximum(resid - dead, 0.0)
    waste_pen = np.abs(excess - mean) 
    # Primary key: prefer tight fits; the penalty softly reshapes the large-residual side.
    score = -(resid + 0.35 * waste_pen)
    return score
# EVOLVE-BLOCK-END
