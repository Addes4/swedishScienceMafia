# EVOLVE-BLOCK-START
"""Best fit with an adaptive minimum-useful-residual guard."""
import numpy as np

_state = {"thr": 8.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Adaptively track a small residual threshold: roughly a fraction of recent item sizes.
    # Keep it in a sensible band so it doesn't destroy best-fit packing.
    thr = _state["thr"]
    thr = 0.85 * thr + 0.15 * (item * 0.45)
    if thr < 4.0:
        thr = 4.0
    elif thr > 20.0:
        thr = 20.0
    _state["thr"] = thr

    rem = bins - item

    # Only apply the guard for items that aren't large (large items can't be grouped anyway).
    if item <= 60:
        # Prefer residuals that are exactly zero (perfect fill) or at least the threshold.
        ok = (rem == 0) | (rem >= thr)
    else:
        ok = np.ones_like(rem, dtype=bool)

    if ok.any():
        # Among acceptable bins, choose the tightest fit (smallest residual).
        r = np.where(ok, rem, np.int64(10**9))
        return -r

    # Fallback: plain best fit.
    return -rem
# EVOLVE-BLOCK-END
