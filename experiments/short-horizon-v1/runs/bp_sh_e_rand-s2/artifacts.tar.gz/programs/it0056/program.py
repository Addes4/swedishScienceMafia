# EVOLVE-BLOCK-START
"""Harmonic-style bin choice: classify the item by size and match it to a residual class."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placement if chosen

    # Class boundaries as fractions of capacity 100 (Harmonic partitioning).
    # Item class is determined by the smallest fraction 1/k that is >= item/100.
    # We then prefer bins whose post-placement residual falls in the *next* class down
    # (i.e. residual in [100/(k+1), 100/k)), which keeps bins reserved for
    # appropriately sized items. Fall back to best-fit when no such bin exists.
    if item <= 0:
        return -residual

    # Determine k such that 100/k >= item > 100/(k+1).
    # Solve item/100 > 1/(k+1)  =>  k+1 > 100/item  =>  k >= floor(100/item) when item divides.
    k = 100 // item  # integer class index; item in (100/(k+1), 100/k]
    if k < 1:
        k = 1

    # Preferred residual window: residuals corresponding to the next size class down.
    # Lower threshold: residual that would still fit an item of the current class boundary.
    # Use residual window [ceil(100/(k+1)), floor(100/k)] roughly.
    lo = 100.0 / (k + 1)
    hi = 100.0 / k

    in_window = (residual >= lo) & (residual <= hi)

    if np.any(in_window):
        # Prefer the fullest bin (smallest residual) within the window.
        score = np.where(in_window, -residual + 1000.0, -residual)
    else:
        # Fallback: best fit.
        score = -residual

    return score
# EVOLVE-BLOCK-END
