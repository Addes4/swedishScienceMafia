# EVOLVE-BLOCK-START
"""Best-fit with a light preference for completing already-fuller bins on ties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (smallest post-placement residual).
    # Tie-break: prefer the bin that was already fuller (smaller pre-placement capacity),
    # which helps finish off bins instead of leaving them with unusable fragments.
    return -(residual * 1000.0 + bins)
# EVOLVE-BLOCK-END

