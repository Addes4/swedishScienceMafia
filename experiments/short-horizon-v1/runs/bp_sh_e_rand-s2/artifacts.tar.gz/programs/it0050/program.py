# EVOLVE-BLOCK-START
"""Best fit with a residual-balancing tie-break based on running statistics."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sum_item = 0.0
        self.absorbed = 0.0  # sum of residuals we've created
        self.res_count = 0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Update running statistics (state never sees future items).
    _state.n += 1
    _state.sum_item += item
    mean_item = _state.sum_item / _state.n if _state.n else 40.0

    # A target residual: roughly half a typical item, so bins keep
    # enough room for a medium item but don't hoard space.
    target = 0.5 * mean_item

    # Primary: best fit (smaller residual). Secondary: residual near target.
    score = -residual.astype(np.float64) - 0.01 * np.abs(residual - target)
    return score
# EVOLVE-BLOCK-END
