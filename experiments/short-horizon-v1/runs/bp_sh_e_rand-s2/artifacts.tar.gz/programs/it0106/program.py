# EVOLVE-BLOCK-START
"""Best fit with a refillability bonus and sliver avoidance."""
import numpy as np


class _State:
    def __init__(self):
        self.min_seen = 100
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0


_state = _State()


def priority(item, bins):
    """Score every bin so the item lands in the most useful place."""
    st = _state
    if item < st.min_seen:
        st.min_seen = item
    st.counts[item] += 1.0
    st.total += 1

    residual = bins - item  # >= 0 since bins only contains fitting bins

    # Base: prefer tightest fit (smallest usable residual).
    score = -residual.astype(np.float64)

    # Bonus: reward residuals that are likely refillable by future items,
    # i.e. residuals that appear as (or near) observed item sizes.
    # Use a smooth density over observed item sizes.
    w = st.counts / st.total  # empirical pmf over sizes
    # probability mass at or below the residual (a residual r can be filled
    # by any future item <= r). Use cumulative mass as refillability.
    cum = np.cumsum(w)
    refill = cum[np.clip(residual, 0, 100)]
    score += 0.4 * refill

    # Mild penalty for unusable slivers (positive residual below min item).
    sliver = (residual > 0) & (residual < st.min_seen)
    score -= 0.5 * sliver.astype(np.float64)

    # Sub-unit tie-break: prefer the fuller bin (smaller current capacity).
    score += 0.001 * (100.0 - bins.astype(np.float64) / 100.0)

    return score
# EVOLVE-BLOCK-END
