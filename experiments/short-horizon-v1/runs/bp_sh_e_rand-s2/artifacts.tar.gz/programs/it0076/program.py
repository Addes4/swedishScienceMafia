# EVOLVE-BLOCK-START
"""Best fit with an index tiebreak (prefer earlier, more-loaded bins on equal residual)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = bins.shape[0]
    residual = bins - item
    # Primary: smallest residual first (best fit). Secondary: lowest index first.
    # Encode lexicographic order into a single float: residual dominates index.
    idx = np.arange(n)
    return -residual.astype(np.float64) - idx * 1e-6
# EVOLVE-BLOCK-END
