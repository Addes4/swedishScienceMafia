# EVOLVE-BLOCK-START
"""Best fit with a microscopic preference for fuller bins on ties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    r = bins - item
    # Primary: tighter fit (smaller residual) wins. Tie-break (sub-unit, < 1):
    # slightly prefer the bin that is already fuller before placement.
    return -r.astype(np.float64) + 0.5 * (100.0 - bins.astype(np.float64)) / 100.0
# EVOLVE-BLOCK-END

