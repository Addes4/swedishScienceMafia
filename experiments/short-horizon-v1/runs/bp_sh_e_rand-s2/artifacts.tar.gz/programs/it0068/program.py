# EVOLVE-BLOCK-START
"""Best fit with a median-residual tie preference for future exact fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score.

    Base ordering is classic best-fit (smallest residual after placement wins).
    Ties within a tiny window are broken toward leaving a residual that equals
    a typical item size, which tends to be reusable by a later exact fit.
    """
    resid = bins - item  # >= 0 by construction
    # Target residual to aim for: a common item size leaves room for an exact fit.
    # Mean item size ~40, so 40 is a reasonable, distribution-free target.
    target = 40
    # Base: smaller residual => higher score.
    score = -resid.astype(np.float64)
    # Small bonus for residuals near the typical item size, but never enough to
    # overturn a genuinely tighter placement (window <= 2).
    score += 0.01 * -np.abs(resid - target)
    return score
# EVOLVE-BLOCK-END
