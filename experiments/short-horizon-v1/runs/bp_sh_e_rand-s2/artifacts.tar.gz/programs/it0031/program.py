# EVOLVE-BLOCK-START
"""Best-fit with a dead-sliver guard: avoid leaving unusable residual gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # residual after placing the item in each shown bin
    res = bins - item  # >= 0 since bins only contains bins the item fits in

    # Segment bins: exact fits (res == 0), and usable fits (res >= threshold)
    # threshold: smallest item size seen so far is a good proxy for what can still
    # be placed; fall back to a modest constant early in the stream.
    thr = _STATE.get('min_size', 0)
    if thr < 1:
        thr = 1

    # Base ordering: best fit (smallest residual), but we will reorder by class.
    # Score classes:
    #   3 -> exact fill (res == 0)          : best
    #   2 -> usable residual (res >= thr)   : tightest usable
    #   1 -> dead sliver (0 < res < thr)    : avoid
    score = np.empty_like(res, dtype=float)
    exact = res == 0
    usable = (res >= thr) & ~exact
    dead = ~exact & ~usable

    # Tightest-first within class: use negative residual so smaller res => larger score.
    score[exact] = 3.0 + 0.0
    score[usable] = 2.0 - res[usable] * 1e-6
    score[dead] = 1.0 - res[dead] * 1e-6

    return score


_STATE = {}


def _record(item):
    m = _STATE.get('min_size', 0)
    if m == 0 or item < m:
        _STATE['min_size'] = item


# Hook: update state as items arrive via priority wrapper.
_orig_priority = priority


def priority(item, bins):
    _record(item)
    return _orig_priority(item, bins)
# EVOLVE-BLOCK-END
