# EVOLVE-BLOCK-START
"""Best fit with a stateful histogram-aware secondary preference.

Primary rule remains best-fit (smallest residual after placement). However, an
exact fill (residual 0) is preferred above all else, and among placements that
are not exact fills we break near-ties in favor of residuals that are common
item sizes seen so far. This targets the classic waste pattern where best-fit
leaves an unusable sliver while a slightly larger residual could have been
filled exactly by a future item.
"""
import numpy as np

_FREQ = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    global _TOTAL
    # Update running histogram of observed items (state persists within a stream).
    _FREQ[item] += 1.0
    _TOTAL += 1.0

    residual = bins - item  # >= 0 for all shown bins
    n = residual.shape[0]

    # Frequency weight of the residual size (how likely a future item fills it).
    # Normalize so the weight is comparable to (but smaller than) residual scale.
    freq = _FREQ[residual] / _TOTAL

    exact = (residual == 0)

    # Base: best-fit -> smaller residual is better, so score = -residual.
    # Secondary: prefer residuals that are frequent item sizes (fillable later).
    # Weight kept small so ordering among distinctly different residuals is
    # unchanged except for exact fills, which get an overwhelming bonus.
    score = -residual.astype(np.float64) + 0.5 * freq
    score = np.where(exact, 1e9, score)

    # Ensure no NaN and return.
    return score
# EVOLVE-BLOCK-END
