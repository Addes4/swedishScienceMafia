# EVOLVE-BLOCK-START
"""Streaming bin choice: best fit with a smoothed penalty for wasteful residuals."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Rank bins by residual after placement, penalizing near-mean leftovers."""
    s = _state
    s["sum"] += item
    s["n"] += 1
    mean = s["sum"] / s["n"]

    residual = bins - item  # remaining capacity if item placed here

    # Gap between the leftover and a typical item size: leftovers just below the
    # mean are the most wasted (future items rarely fit), so penalize them.
    gap = mean - residual
    penalty = np.where(gap > 0, gap * gap, 0.0)

    # Slight reward for leftovers that could hold a typical future item.
    reward = np.where(residual >= mean, mean * 0.5, 0.0)

    return -residual.astype(np.float64) - 0.02 * penalty + 0.01 * reward
# EVOLVE-BLOCK-END
