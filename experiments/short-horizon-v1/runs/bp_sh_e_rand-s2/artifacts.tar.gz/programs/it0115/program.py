# EVOLVE-BLOCK-START
"""Best fit with a mild preference for residuals near a typical future item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # post-placement leftover, 0..99
    # Prefer tight fits, but favor leftovers that can still absorb a typical item.
    # A leftover near the running mean item size is reusable; near-zero is also good.
    target = 40.0
    score = -(residual) - 0.5 * np.abs(residual - target)
    return score
# EVOLVE-BLOCK-END
