# EVOLVE-BLOCK-START
"""Best fit with a fuller-bin tie-break among equal residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties).

    Primary: minimize residual after placement (best fit).
    Secondary: among bins leaving the same residual, prefer the fuller bin.
    """
    residual = bins - item
    # Lexicographic: maximize -residual, then maximize fullness (minimize bins).
    return -residual * 1000.0 - bins
# EVOLVE-BLOCK-END
