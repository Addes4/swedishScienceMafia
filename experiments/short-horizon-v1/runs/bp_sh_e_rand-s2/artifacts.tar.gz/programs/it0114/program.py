# EVOLVE-BLOCK-START
"""Best fit with a small capacity-conservation tie-breaker.

Primary key is the post-placement residual (classic best fit: tightest fit wins).
As a tie-breaker, prefer the bin that was already fuller (smaller remaining capacity
before placement) so we keep consolidating into mature bins and leave untouched
bins (capacity 100) in reserve. This is a pure online rule; it uses only the array
it is handed.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since only fitting bins are passed
    # Lexicographic: minimize residual (best fit), then minimize bins (fuller bin first).
    # Encode with tiny secondary weight; residual range is at most 100, secondary <= 100,
    # so scale secondary below 1 unit on the primary key.
    return -(residual.astype(np.float64) * 1000.0 + bins.astype(np.float64))
# EVOLVE-BLOCK-END
