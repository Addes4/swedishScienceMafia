# EVOLVE-BLOCK-START
"""Modified best fit: pick the fullest bin whose residual stays above a
size-class threshold, else fall back to plain best fit.

Items follow a Weibull-ish size distribution with mean ~40.  Small items can
fill almost any residual, so for them pure best-fit (tightest possible) is
fine.  For larger items it pays to keep bins from being driven down into a
sliver that only tiny items could ever use, so we bias the choice toward a
residual class boundary.  Thresholds are fixed (not tuned to any instance)
and derived from the 100 capacity in a Harmonic-like geometric progression.
"""
import numpy as np

# Geometric-ish capacity classes for capacity 100.  Residuals are compared
# against these; keeping a residual above the class floor avoids slivers.
_LEVELS = np.array([0, 10, 20, 33, 50, 67, 80, 90, 100], dtype=np.int64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of fitting bins, in order.
    """
    # Residual that would be left in each bin if the item were placed there.
    rem = bins - item

    # Scale so secondary terms can never cross a one-unit residual difference.
    frac = 0.1

    if item >= 34:
        # For medium/large items prefer residuals just at or above a class
        # floor: penalise how far a residual falls BELOW the next floor up,
        # which discourages creating near-empty unusable slivers.
        # Distance from the nearest class floor (0 at the floor).
        lo = np.searchsorted(_LEVELS, rem, side="right") - 1
        lo = np.clip(lo, 0, len(_LEVELS) - 1)
        floor = _LEVELS[lo]
        below = (floor + 0.0) - rem          # <=0 normally; >0 when sliver-ish
        # Main term still strongly favours tight fits.
        main = -(rem + item * 0)              # = item - bins, tightest first
        # Secondary: small preference for being at/above a class floor.
        sec = -frac * np.maximum(below, 0)
        return main + sec

    # For small items, pure best fit (tightest fit) is essentially optimal.
    return -(bins - item)
# EVOLVE-BLOCK-END
