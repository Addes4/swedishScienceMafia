# EVOLVE-BLOCK-START
"""Best-fit with a mild anti-fragmentation bias toward bins already in use."""
import numpy as np

_state = {"seen": 0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    Best fit (tightest residual after placing) is used as the base signal, but
    bins whose residual would land near the running mean item size get a small
    bonus, and completely empty bins get a small penalty once the stream is
    warmed up.  This favors consolidation without losing best-fit's tightness.
    """
    s = _state
    s["seen"] += 1
    s["mean"] = s["mean"] + (item - s["mean"]) / max(1, min(s["seen"], 200))

    residual = bins - item  # remaining capacity after placing, >= 0

    # Base: tightest fit first.
    score = -residual.astype(np.float64)

    # Small bonus when the resulting residual is close to the running mean
    # item size: that bin is then a good candidate for a future "typical" item.
    m = s["mean"]
    score += 1.5 * np.exp(-((residual - m) ** 2) / (2.0 * (0.35 * m + 1e-6) ** 2))

    # Mildly discourage using completely empty bins to avoid fragmentation,
    # but only after enough items have arrived for the mean to be meaningful.
    if s["seen"] > 20:
        score -= (bins == 100) * 0.5

    return score
# EVOLVE-BLOCK-END
