# EVOLVE-BLOCK-START
"""Best-fit with epsilon-band tie-breaking toward emptier bins."""
import numpy as np


def priority(item, bins):
    """Score every bin; highest wins, ties go to first.

    Primary: best fit (smallest residual = bins - item).
    Within an epsilon band of the best residual, prefer the emptier bin
    (larger remaining capacity) to preserve tight residuals for exact fits.
    """
    residual = bins - item
    best = residual.min()
    # bins whose residual is within a small tolerance of the best fit
    tied = (residual <= best + 1).astype(np.float64)
    # among tied bins, favor the emptier one (larger remaining capacity)
    return tied * (100.0 + bins.astype(np.float64))
# EVOLVE-BLOCK-END
