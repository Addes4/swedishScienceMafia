# EVOLVE-BLOCK-START
"""Best fit, with a rescue when best fit would create a dead sliver."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit backbone: highest score = smallest residual after placement.
    residual = bins - item

    # Rescue: if the tightest fit leaves a residual below the running estimate of the
    # smallest item size (a sliver that can likely never be filled), prefer a bin whose
    # post-placement residual is close to that typical minimal item instead.
    dead = _min_item_estimate
    if dead is not None and residual.min() < dead:
        # Prefer residuals near the expected minimal item size, keeping tightness as a
        # secondary (small) tie-break below one integer unit.
        score = -np.abs(residual - dead) + 1e-3 * (-residual)
        return score

    return -residual


_min_item_estimate = None


def _update(item):
    global _min_item_estimate
    if _min_item_estimate is None or item < _min_item_estimate:
        _min_item_estimate = item
# EVOLVE-BLOCK-END
