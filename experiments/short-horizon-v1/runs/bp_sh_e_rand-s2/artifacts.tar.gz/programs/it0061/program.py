# EVOLVE-BLOCK-START
"""Harmonic best-fit: bucket items by size and restrict bins to matching residual ranges."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sum_sq = 0.0


_S = _State()


def priority(item, bins):
    """Return a priority per bin; the item goes to the highest (first on ties)."""
    # --- update running statistics of item sizes ---
    _S.n += 1
    _S.sum_sq += float(item) * float(item)
    rms = (_S.sum_sq / _S.n) ** 0.5 if _S.n > 0 else 40.0

    # --- harmonic classification: class k roughly holds items up to 1/(k+1) of capacity ---
    # define class boundaries scaled by RMS size of the distribution
    scale = max(rms, 1.0)
    # class index 0 -> smallest items, up to ~ 1/2 capacity; class 1 -> up to ~1/3; etc.
    if item <= scale * 0.5:
        k = 0
    elif item <= scale * 0.75:
        k = 1
    elif item <= scale * 1.0:
        k = 2
    else:
        k = 3

    # Residual ranges (in terms of capacity 100) that we are willing to fill for each class.
    # For class k, aim to leave at least roughly scale/(k+2) residual so bins stay packable.
    if k == 0:
        lo, hi = 0, 25
    elif k == 1:
        lo, hi = 20, 40
    elif k == 2:
        lo, hi = 35, 60
    else:
        lo, hi = 55, 100

    # Candidate residuals after placement
    resid = bins - item
    # mask bins whose resulting residual falls in the desired (lo,hi) band
    band = (resid >= lo) & (resid <= hi)

    score = -(resid.astype(np.float64))
    # Strong bonus for being in the preferred harmonic band
    score = score + band.astype(np.float64) * 1000.0
    return score
# EVOLVE-BLOCK-END
