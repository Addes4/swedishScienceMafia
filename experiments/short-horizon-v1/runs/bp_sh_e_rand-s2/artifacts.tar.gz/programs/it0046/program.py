# EVOLVE-BLOCK-START
"""Best-fit backbone for small items, 'leave a typical-sized gap' for large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Running estimate of the typical (mean) item size, updated online.
    state = priority.__dict__
    n = state.get("n", 0)
    s = state.get("s", 0.0)
    n += 1
    s += item
    state["n"] = n
    state["s"] = s
    mean = s / n

    residual = bins - item  # remaining capacity after placing the item

    # The bin index is the primary fit signal in best-fit: choose minimal residual.
    # We encode: primary = -residual (so tighter fits win), and add a small
    # secondary term, scaled < 1, that prefers leaving a gap near the mean item size
    # for non-small items (which can still absorb a typical future item), while
    # avoiding dead slivers below ~mean.
    tight = -residual.astype(np.float64)

    if item <= mean:
        # Small item: pure best-fit is good; keep it strict.
        return tight

    # Large item: prefer a residual near the mean, penalize slivers below it.
    # Distance from mean, but treat residuals below ~mean/2 as wasted (dead sliver).
    gap = residual.astype(np.float64)
    # Bonus: residual close to mean is good. Penalty grows as residual shrinks below mean.
    # Use a smooth penalty that is < 1 so it only breaks exact-residual ties mildly.
    target = mean
    dev = np.abs(gap - target)
    good = -dev / 200.0  # small secondary preference, magnitude < 1
    return tight + good
# EVOLVE-BLOCK-END

