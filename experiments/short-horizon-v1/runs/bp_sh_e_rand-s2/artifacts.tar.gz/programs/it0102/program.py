# EVOLVE-BLOCK-START
"""Best fit with a tiny consolidation tie-break.

Primary key: smallest post-placement residual (classic best fit).
Tie-break: among equal residuals, prefer the bin that is currently more packed
(smaller remaining capacity before placement), which consolidates filled bins.
The tie-break term is strictly sub-unit so it never overrides the primary key.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # post-placement remaining capacity, >= 0 for shown bins
    # Strictly sub-unit tie-break: prefer more-packed bins (smaller current capacity).
    # bins in [item, 100]; scale so the term lies in [0, 1), never changing primary order.
    tie = (100.0 - bins) / 200.0
    return -residual.astype(np.float64) + tie
# EVOLVE-BLOCK-END
