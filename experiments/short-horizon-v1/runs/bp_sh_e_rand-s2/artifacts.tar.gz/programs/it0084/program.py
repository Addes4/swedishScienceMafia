# EVOLVE-BLOCK-START
"""Best-fit with a bonus for residuals that are likely reusable by future items."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _total
    _counts[item] += 1.0
    _total += 1.0

    bins = np.asarray(bins)
    residual = bins - item

    # Frequency estimate of residual sizes (smoothed) as an estimate of reuse usefulness.
    freq = _counts / _total

    # Base: prefer tight fits (smaller residual => larger score).
    score = -residual.astype(np.float64)

    # Small bonus if the item exactly fills the bin (residual 0 is always reusable / no waste).
    score += 2.0 * (residual == 0)

    # Bonus proportional to how often this residual size has appeared as an item size,
    # encouraging the leftover capacity to be usable by typical future items.
    safe = np.clip(residual, 0, 100).astype(np.int64)
    score += 3.0 * freq[safe]

    return score
# EVOLVE-BLOCK-END
