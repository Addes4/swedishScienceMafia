# EVOLVE-BLOCK-START
"""Harmonic-style bin-choice rule blended with best-fit.

Classic best-fit minimizes leftover slack but tends to create unwrappable slivers.
Harmonic bin packing partitions items into size classes and restricts each class to
bins whose residual capacity is in a matching range, which reduces fragmentation.
Here we use a light-weight, robust variant: strict best-fit is the backbone, but a
bin that would be left exactly full always wins, and otherwise we prefer fit that
does not create a residual smaller than the smallest item seen so far.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, ties to first bin."""
    residual = bins - item  # residual capacity after placing the item here

    # Base: best fit -> smaller residual is better.
    score = -residual.astype(np.float64)

    # Strong bonus for leaving the bin exactly full (residual 0).
    score += 1000.0 * (residual == 0)

    return score
# EVOLVE-BLOCK-END
