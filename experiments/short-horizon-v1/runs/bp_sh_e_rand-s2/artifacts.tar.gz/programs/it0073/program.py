# EVOLVE-BLOCK-START
"""Best-fit with an exact-fit/symmetric-pair tie-break and online residual matching."""
import numpy as np


def priority(item, bins):
    """Rank bins; highest score wins (first on ties).

    Base ordering is best-fit (smallest post-placement residual).  We add a
    bounded bonus for two cheap, distribution-agnostic patterns that improve
    packing on Weibull-shaped streams:
      * exact fit (residual 0)
      * symmetric pair (residual == item)
    Both are computed purely from the current call, so short streams and tie
    behaviour stay deterministic and match best-fit whenever no such bin exists.
    """
    residual = bins - item

    # Primary: best-fit ordering, expressed so larger = better.
    score = -residual.astype(np.float64)

    exact = residual == 0
    if exact.any():
        score[exact] += 0.5

    sym = residual == item
    if sym.any():
        score[sym] += 0.25

    return score
# EVOLVE-BLOCK-END
