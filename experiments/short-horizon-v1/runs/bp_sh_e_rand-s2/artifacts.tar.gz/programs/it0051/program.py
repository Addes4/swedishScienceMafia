# EVOLVE-BLOCK-START
"""Harmonic-style bin choice: classify the item, prefer bins whose residual
lies in the matching capacity class, else fall back to best-fit."""
import numpy as np


def _class_of(frac):
    # frac in (0, 1]: return k such that frac in (1/(k+1), 1/k]
    k = int(np.floor(1.0 / frac))
    if k < 1:
        k = 1
    # ensure 1/(k+1) < frac <= 1/k
    while 1.0 / (k + 1) >= frac:
        k += 1
    while 1.0 / k < frac:
        k -= 1
    return k


def priority(item, bins):
    """Return a priority per bin; item goes to highest score (first on ties)."""
    C = 100.0
    frac = item / C
    k = _class_of(frac)
    # capacity interval that makes a bin "right" for this class:
    # after placing, the residual should be <= C/(k+1) (i.e. bin falls in class k),
    # meaning pre-capacity in (item, item + C/(k+1)].
    upper_res = C / (k + 1)
    residual = bins - item  # >= 0 for qualifying bins
    # prefer bins whose residual lands in the class-k interval (0, upper_res];
    # among those, prefer tighter (smaller) residual (best-fit inside class).
    in_class = residual <= upper_res
    # score: in-class bins dominate; then smaller residual is better.
    score = np.where(in_class, 2.0 * C - residual, C - residual)
    return score
# EVOLVE-BLOCK-END
