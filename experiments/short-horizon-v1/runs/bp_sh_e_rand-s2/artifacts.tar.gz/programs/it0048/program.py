# EVOLVE-BLOCK-START
"""Best fit with a convex lost-opportunity penalty against tiny unusable slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Running estimate of a typical item size (state kept across calls).
    state = priority.__dict__
    n = state.get("n", 0)
    mean = state.get("mean", 40.0)
    mean = (mean * n + item) / (n + 1)
    state["n"] = n + 1
    state["mean"] = mean

    typical = mean
    # Penalize residuals that are too small to fit a typical future item.
    gap = np.maximum(0.0, typical - residual)
    score = -residual.astype(np.float64) - 0.05 * gap * gap
    return score
# EVOLVE-BLOCK-END
