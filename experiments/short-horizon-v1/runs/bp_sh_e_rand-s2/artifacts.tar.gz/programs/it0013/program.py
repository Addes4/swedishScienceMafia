# EVOLVE-BLOCK-START
"""Best-fit refined: strong exact-fill bonus and a fine consolidation tie-break."""
import numpy as np


def priority(item, bins):
    """Return priority per bin; item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every fitting bin (unused bins have 100), in bin order.
    """
    residual = bins - item          # remaining capacity after placing the item
    score = -residual.astype(np.float64)
    # Strong bonus for exact fills (residual == 0): perfectly packed bins.
    score += (residual == 0) * 50.0
    return score
# EVOLVE-BLOCK-END
