# EVOLVE-BLOCK-START
"""Online best-fit with a learned 'useful residual' preference.

Best-fit is strong. Its main weakness is stranding a residual that is too small
to fit any typical future item: a tight fit leaving, say, 3 units of free space
is wasted forever. We track the running mean item size online (no future
information) and:

  * if the tightest fit leaves a residual that is "small" relative to the mean
    item size (i.e. already nearly-full, likely dead-or-fine), keep best-fit;
  * otherwise prefer the bin whose post-placement residual is closest to the
    running mean item size, so leftover space stays usable.
"""
import numpy as np


def priority(item, bins):
    # Track running mean of items seen (cheap, O(1) state).
    state = priority.state
    state[0] += 1.0
    n = state[0]
    state[1] += item
    mean = state[1] / n
    if mean < 1.0:
        mean = 1.0

    residual = bins - item  # >= 0 for all shown bins

    # Tightest residual among shown bins.
    tight = residual.min()

    # If the tightest fit is already small (near-full bin), just best-fit.
    if tight <= 0.5 * mean:
        return -residual.astype(float)

    # Otherwise pick the bin whose residual is closest to the mean item size,
    # so the leftover space can still hold a typical future item.
    return -np.abs(residual - mean).astype(float)


priority.state = [0.0, 0.0]
# EVOLVE-BLOCK-END
