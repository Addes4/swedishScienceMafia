# EVOLVE-BLOCK-START
"""Best fit with a small dead-zone avoidance guard for mid-size items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residuals = bins - item  # >= 0 for all shown bins

    # Base: strict best fit -> maximize residual closeness, i.e. minimize residual.
    base = -residuals.astype(np.float64)

    # Only add the dead-zone guard for mid-size items where slivers matter most.
    if 10 < item < 90:
        K = 3
        # Best-fit residual value.
        best_res = residuals.min()

        if 1 <= best_res <= K:
            # Candidate bins that avoid a tiny sliver: residual 0 or >= item.
            usable = (residuals == 0) | (residuals >= item)
            if usable.any():
                # Among usable ones, prefer the smallest residual that is > K (or 0).
                cand = residuals[usable]
                # score: prefer exact (0) first, then smallest residual above K
                order = np.where(cand == 0, -1.0, cand.astype(np.float64))
                # lower order is better; convert to a big bonus so it beats best-fit
                best_order = order.min()
                # Build bonus only for the chosen usable bins matching best_order.
                chosen = usable & ((residuals == 0) if best_order < 0 else (residuals == int(best_order)))
                base = base + chosen * 1000.0

    return base
# EVOLVE-BLOCK-END
