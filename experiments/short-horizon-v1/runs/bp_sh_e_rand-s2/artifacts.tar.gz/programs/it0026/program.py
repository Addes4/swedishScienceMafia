# EVOLVE-BLOCK-START
"""Best-fit with a complementary-residual bonus.

Primary criterion: smallest residual after placement (best fit).
Secondary bonus: prefer residuals that can be exactly filled by a typical small
item later, and especially a residual of 0 (perfect fill).  This is a small,
state-free nudge that keeps best-fit behavior on ties while rewarding leftovers
that are likely to be reusable.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first bin."""
    residual_after = bins - item
    # Base: strict best fit -> smaller residual_after scores higher.
    score = -residual_after.astype(np.float64)
    # Bonus for a perfectly filled bin (residual 0).
    score += np.where(residual_after == 0, 1.0, 0.0)
    # Small bonus for a leftover that is itself a common small item size,
    # so it may be exactly filled by a later item.
    common = np.isin(residual_after, (1, 2, 3, 4, 5, 10, 20, 25, 40))
    score += np.where(common, 0.5, 0.0)
    return score
# EVOLVE-BLOCK-END
