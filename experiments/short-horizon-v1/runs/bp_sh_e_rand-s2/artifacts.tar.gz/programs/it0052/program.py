# EVOLVE-BLOCK-START
"""Best fit with sliver-avoidance: fill tightly, but avoid leaving dead residuals."""
import numpy as np


def priority(item, bins):
    """Score each bin; highest score wins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (item fits in all of them).
    """
    residual = bins - item
    # Avoid leaving a small positive residual that likely cannot be filled later.
    # A residual of 0 is ideal; residuals >= min_item are usable; small slivers are bad.
    min_item = getattr(priority, "_min_item", 1)
    # running estimate of the smallest item size seen so far
    if item < min_item or min_item == 1:
        # update conservatively
        new_min = item if item > 0 else min_item
        priority._min_item = max(1, min(min_item, new_min)) if min_item != 1 else item
    min_item = getattr(priority, "_min_item", 1)

    score = -residual.astype(np.float64)
    # bonus for exact fill
    score += np.where(residual == 0, 5.0, 0.0)
    # penalty for leaving an unusable sliver (0 < residual < min_item)
    sliver = (residual > 0) & (residual < min_item)
    score -= np.where(sliver, 3.0, 0.0)
    return score
# EVOLVE-BLOCK-END
