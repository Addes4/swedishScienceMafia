# EVOLVE-BLOCK-START
"""Best-fit with a small residual-window tiebreaker favoring older/lower-index bins.

Pure best-fit fills the tightest bin.  A minor variant helps long streams: when
several bins yield nearly the same tight fit (residual within a small window),
prefer the one that appeared earlier (lower bin index), which tends to be the
already-more-filled bin and consolidates packing.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = bins.shape[0]
    residual = bins - item  # remaining capacity after placing the item (>=0 since it fits)

    # Deficit from the tightest possible placement. Best-fit minimizes residual,
    # equivalently maximizes -residual.
    base = -residual.astype(np.float64)

    # Small window tiebreaker: bins within `window` of the tightest residual get a
    # bonus decaying with bin index, so older (lower-index) bins are preferred when
    # fits are essentially equally tight. Zero bonus beyond the window keeps pure
    # best-fit ordering when residuals differ meaningfully.
    window = 2.0
    tight = residual.min()
    idx = np.arange(n, dtype=np.float64)
    within = residual <= (tight + window)
    bonus = np.where(within, 1.0 / (1.0 + idx), 0.0)

    return base + bonus
# EVOLVE-BLOCK-END
