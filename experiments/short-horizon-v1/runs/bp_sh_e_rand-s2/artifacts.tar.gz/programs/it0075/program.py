# EVOLVE-BLOCK-START
"""Best fit with an index-based tiebreaker to consolidate into older, fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = bins.shape[0]
    # Primary key: tighter fit (smaller post-placement residual) is better.
    # Secondary key: lower bin index (older, more-loaded bin) is better, scaled small
    # so it only matters as a near-tiebreak but still steadily discourages opening new bins.
    idx = np.arange(n, dtype=np.float64)
    residual = bins - item
    return -residual.astype(np.float64) - 1e-3 * idx / max(n, 1)
# EVOLVE-BLOCK-END
