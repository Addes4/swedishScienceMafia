# EVOLVE-BLOCK-START
"""Hybrid rule: fill bins toward residuals that are either 'dead' (unusable)
or large enough to remain useful for a typical future item."""
import numpy as np


def priority(item, bins):
    """Rank bins: tight fits are good, but avoid leaving small unusable gaps.

    We score each bin by its post-placement residual r = bins - item.
    - r == 0 (perfect fit): best.
    - r small (dead gap that no item >= min useful size can use): also very good,
      favor the smallest such dead gap.
    - otherwise, favor residuals close to a "target" (~40, a typical item size),
      so the leftover space stays usable, with a mild best-fit tie-break.
    Bins are returned in a fixed order; ties go to the first, so we keep the
    preferred bin earliest in its class by adding a tiny index-independent bias
    via the residual value itself.
    """
    r = bins - item  # remaining capacity after placement, >= 0 for shown bins

    # "Dead" threshold: a residual below this is effectively wasted.
    dead = 20.0
    # Target residual for a still-useful leftover.
    target = 40.0

    score = np.empty(r.shape, dtype=np.float64)

    dead_mask = r < dead
    # Dead gaps: higher score for smaller residual (tight). Map to a high range.
    score[dead_mask] = 1000.0 - r[dead_mask]

    live = ~dead_mask
    # Live: prefer residual near target; smaller distance is better.
    score[live] = -np.abs(r[live] - target)

    return score
# EVOLVE-BLOCK-END
