# EVOLVE-BLOCK-START
"""Best fit with a small bonus for preserving a useful residual (>= running median item)."""
import numpy as np

_state = {"n": 0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update running estimate of a typical item size (exponential moving average).
    _state["n"] += 1
    a = 2.0 / (_state["n"] + 1.0)
    _state["mean"] = (1.0 - a) * _state["mean"] + a * item
    typical = _state["mean"]

    residual = bins - item  # remaining capacity if item placed here (nonnegative)
    # Best fit: smaller residual is better.
    score = -residual.astype(np.float64)
    # Small bonus when the resulting residual can still hold a typical future item,
    # i.e. the leftover space remains usable rather than being wasted.
    score += 0.5 * (residual >= typical)
    return score
# EVOLVE-BLOCK-END
