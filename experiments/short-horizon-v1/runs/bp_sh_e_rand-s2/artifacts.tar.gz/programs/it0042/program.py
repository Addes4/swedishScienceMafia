# EVOLVE-BLOCK-START
"""Best fit, with a tiny histogram-based tie-break toward residuals that are common item sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _HIST

    # Running histogram of item sizes seen so far (fractional counts, decayed slowly).
    try:
        _HIST
    except NameError:
        _HIST = np.zeros(101, dtype=np.float64)

    _HIST *= 0.999
    _HIST[item] += 1.0

    residual = bins - item  # >= 0

    # Primary: tightest fit (maximize -residual).
    base = -residual.astype(np.float64)

    # Secondary: small bonus (< 1) if the residual is a frequently seen item size.
    # Normalize histogram to a fraction; scale to stay strictly below 1.
    total = _HIST.sum()
    frac = _HIST / total if total > 0 else _HIST
    # residual values are 0..100; look up their frequency as a future-item hint.
    bonus = frac[np.clip(residual, 0, 100)]

    return base + 0.5 * bonus
# EVOLVE-BLOCK-END

