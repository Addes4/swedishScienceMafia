# EVOLVE-BLOCK-START
"""Best fit with residual reusability: prefer tight fits, but among residuals
compare them by how reusable they are for future items."""
import numpy as np

_state = {"count": 0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # update running estimate of typical item size
    _state["count"] += 1
    n = _state["count"]
    _state["mean"] += (item - _state["mean"]) / n
    m = _state["mean"]

    residual = bins - item  # post-placement leftover, >= 0

    # Base: strongly prefer tight fits (small residual).
    # But a residual that is too small to ever hold another item is wasted,
    # so treat residuals below a threshold as worse than a residual near the mean.
    # We invert so higher score = better.
    # Reusability weight: residuals >= some fraction of typical item are good.
    thresh = 0.5 * m

    # Penalty for tiny-but-nonzero residuals (unusable slivers)
    sliver = np.where((residual > 0) & (residual < thresh), thresh - residual, 0.0)

    score = -(residual + 0.5 * sliver)
    return score
# EVOLVE-BLOCK-END
