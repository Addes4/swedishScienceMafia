# EVOLVE-BLOCK-START
"""Best fit with unusable-residual demotion based on observed item sizes."""
import numpy as np


class _State:
    def __init__(self):
        self.min_item = 100


_STATE = _State()


def priority(item, bins):
    """Rank bins: tightest fit first, but strongly avoid leaving dead slivers.

    Primary criterion is the post-placement residual (best fit). A bin whose
    residual is below the smallest item seen so far cannot be refilled, so it is
    demoted. The demotion is a single large penalty (< 0) rather than a shift,
    so the within-class best-fit ordering is preserved exactly.
    """
    if item < _STATE.min_item:
        _STATE.min_item = item

    residual = bins - item  # >= 0 since only fitting bins are passed

    # Smallest residual we consider still "usable": the smallest item seen so far.
    # Anything below that cannot be filled again by any observed item.
    threshold = _STATE.min_item

    # Base: best fit -> prefer smallest residual.
    score = -residual.astype(np.float64)

    # Demote unusable slivers. Subtract 1000 so they always lose to usable bins,
    # while keeping internal order among slivers by residual via the base term.
    unusable = residual < threshold
    score[unusable] -= 1000.0

    return score
# EVOLVE-BLOCK-END
