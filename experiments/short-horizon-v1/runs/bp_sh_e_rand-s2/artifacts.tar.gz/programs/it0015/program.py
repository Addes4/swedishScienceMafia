# EVOLVE-BLOCK-START
"""Best-fit with a stateful exact-fill preference learned online."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base score: prefer tighter fits (smaller residual).
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

