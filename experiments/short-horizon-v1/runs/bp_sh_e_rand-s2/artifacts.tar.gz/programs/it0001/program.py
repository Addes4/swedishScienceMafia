# EVOLVE-BLOCK-START
"""Best-fit with a small bonus for exact/near-exact fill residuals.

For each bin the item fits in, compute the residual after placing the item
(bins[i] - item). Prefer the smallest residual (best fit). A mild bonus is
added when the residual is small relative to the item size, which encourages
reusing bins that leave little useful space and reduces fragmentation.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since bins only contains bins the item fits in
    # Primary: best fit (smallest residual -> highest score).
    score = -residual.astype(np.float64)
    # Mild bonus when the residual is small: leftover space that is hard to reuse
    # (smaller than a typical small item) is preferable to fill now.
    small = residual <= 5
    score[small] += 1.0
    return score
# EVOLVE-BLOCK-END

