# EVOLVE-BLOCK-START
"""Hybrid: best-fit, but for small items prefer bins whose residual is a "useful" size
(equals a frequently seen item size or the current item), reducing stranded medium residuals."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_STATE = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update online histogram of observed item sizes.
    _HIST[item] += 1.0
    _STATE["n"] += 1

    resid = bins - item  # >= 0 for bins shown (all fit)
    # Best-fit primary key: smaller residual is better.
    best_fit = -resid.astype(np.float64)

    if item <= 50 and len(bins) > 0:
        # Value of leaving a residual r is higher if r is a common item size
        # (so it can be exactly consumed later) or equals the current item.
        r = resid.astype(np.int64)
        # frequency weight of residual as a future item size
        freq = _HIST[np.clip(r, 0, 100)]
        merit = freq / (_STATE["n"] if _STATE["n"] > 0 else 1.0)
        # bonus for symmetric pairing (residual == item) and exact-ish fits
        merit = merit + (r == item) * 0.5
        merit = merit + (r == 0) * 1.0
        # Combine: best-fit dominates, merit breaks the near-ties.
        return best_fit + 2.0 * merit

    return best_fit
# EVOLVE-BLOCK-END
