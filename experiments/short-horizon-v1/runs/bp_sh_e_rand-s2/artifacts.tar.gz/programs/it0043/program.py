# EVOLVE-BLOCK-START
"""Best-fit backbone with a harmonic-shaped residual score."""
import numpy as np

_INV = 1.0 / np.arange(1, 101)  # 1/ceil-class helper via lookup


def priority(item, bins):
    """Rank bins: prefer tight fits, but shape the penalty harmonically."""
    r = bins - item  # residual after placing; >= 0 for shown bins
    # classify residual into the harmonic class ceil(100/r) (r>0), exact fill gets class 1000
    # score = -r for tiny residuals (exact-fill dominance) but harmonic for larger ones.
    # Use: score = -(r) + alpha * (harmonic class value)
    # harmonic class value: c(r) = 1/ceil(100/max(r,1))
    rr = np.where(r > 0, r, 1)
    ceil_class = np.ceil(100.0 / rr)
    ceil_class = np.where(r == 0, 1e6, ceil_class)
    # smaller class => tighter fit; map to score: exact fill huge, else prefer small class
    # flatten mid-range by adding a small term proportional to residual (so spills spread)
    score = -ceil_class * 1e3 - r
    # exact fills dominate everything else
    score = np.where(r == 0, 1e12, score)
    return score
# EVOLVE-BLOCK-END
