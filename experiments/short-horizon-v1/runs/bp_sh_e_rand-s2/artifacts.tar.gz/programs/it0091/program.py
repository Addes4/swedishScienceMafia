# EVOLVE-BLOCK-START
"""Best fit with a same-size-residual tie-break."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tightest fit, tie-break toward residual == item (refillable)."""
    residual = bins - item
    # Primary: tightest fit is best => larger residual is worse => negative residual.
    # Secondary: residual exactly equal to `item` is a slight bonus (a future
    # same-size item completes the bin), others get a tiny penalty.
    bonus = (residual == item).astype(np.float64)
    return -residual + 0.5 * bonus
# EVOLVE-BLOCK-END
