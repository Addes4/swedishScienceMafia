# EVOLVE-BLOCK-START
"""Hybrid: best-fit, but prefer bins that are not near-empty when fits are similar."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item  # post-placement residual, always >= 0 for shown bins
    # Prefer tight fits (small residual). Among bins that fit tightly (residual < item),
    # strongest preference for the smallest residual. For very large residuals (i.e. loose
    # bins) keep the tightest available as well, which is exactly best-fit.
    # Small tie-break: prefer the bin that is already most loaded (smallest pre-capacity),
    # which consolidates bins and keeps the number of open bins low.
    # Encode as: primary term dominates, secondary term is a tiny fraction.
    return -resid * 1000.0 - bins
# EVOLVE-BLOCK-END
