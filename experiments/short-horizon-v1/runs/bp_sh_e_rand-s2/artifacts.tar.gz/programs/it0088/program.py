# EVOLVE-BLOCK-START
"""Best fit with near-tie break toward larger remaining capacity."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary: minimize residual (best fit). Near-ties within 0.5 residual are broken by
    preferring the bin with the larger remaining capacity, preserving tight fits.
    """
    residual = bins - item
    # Base best-fit score: larger is better when residual is smaller.
    score = -residual
    # Add a tiny secondary preference for bins with more remaining capacity,
    # effective only when residuals are within a small band.
    score = score + 1e-4 * bins
    return score
# EVOLVE-BLOCK-END
