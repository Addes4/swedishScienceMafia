# EVOLVE-BLOCK-START
"""Best-fit with dead-space-aware tie handling.

Pure best fit already near-optimal for this distribution. The main losses come
from leaving small-but-not-tiny residuals that block placement of future small
items. We keep tightest-fit as primary, but nudge the score so that residuals
below a small threshold (dead space anyway) and residuals exactly large enough
to hold a small item are treated more favorably, avoiding stranded mid gaps.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item              # remaining capacity after placing item
    # Primary: prefer smallest residual (tightest fit).
    score = -residual.astype(np.float64)
    # Small bonus for residuals that are already "dead" (< a few units) since
    # they are unusable anyway; this discourages wasting slightly larger gaps.
    dead = residual < 5
    score += dead * 0.5
    # Mild penalty for residuals in a mid range that could be filled by a small
    # item but often end up stranded; encourage either dead or usable-large.
    mid = (residual >= 5) & (residual < 25)
    score -= mid * 0.5
    return score
# EVOLVE-BLOCK-END
