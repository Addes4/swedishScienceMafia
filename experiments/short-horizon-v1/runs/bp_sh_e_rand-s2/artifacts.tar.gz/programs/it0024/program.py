# EVOLVE-BLOCK-START
"""Best-fit with a usable-residual preference.

Normally choose the tightest-fitting bin.  But if the tightest fit would leave
a small unusable sliver (residual < item), while some other bin can take the
item leaving residual 0 or >= item (i.e. still usable by an item this big),
prefer the tightest such usable bin.  The fallback is strict best-fit, so
behaviour on short streams is unchanged.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item            # leftover if placed here (>=0 since bin fits)
    # Lower residual == tighter fit == better.  Primary key: negative residual.
    # Penalize slivers (0 < residual < item) so they rank below usable residuals.
    usable = (residual == 0) | (residual >= item)
    # score: usable bins get their tight fit value; unusable slivers get a big penalty.
    # We want highest score wins.  Best fit -> smaller residual -> higher score.
    score = -residual.astype(np.float64)
    # apply penalty to sliver residuals (strictly between 0 and item)
    score = np.where(usable, score, score - 1000.0)
    return score
# EVOLVE-BLOCK-END
