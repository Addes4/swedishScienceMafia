# EVOLVE-BLOCK-START
"""Best fit with a histogram-guided pairing bonus."""
import numpy as np

# module-level state: histogram of item sizes seen so far in the stream
_hist = np.zeros(101, dtype=np.int64)
_total = 0


def priority(item, bins):
    """Rank bins: best-fit base, plus bonus if leftover residual is a common size."""
    global _hist, _total

    # update histogram with the current item
    _hist[item] += 1
    _total += 1

    # base best-fit score: prefer smallest residual after placement
    base = -(bins - item)

    # residual after placing in each bin
    residual = bins - item

    # bonus: how common is a future item of size == residual?
    # scale by frequency so common residuals are attractive pairings.
    freq = _hist[residual]  # vectorized lookup over residuals (residual <= 100 within capacity)
    # only valid residuals in 0..100; larger residuals can't match any item
    valid = residual <= 100
    bonus = np.where(valid, freq.astype(np.float64), 0.0)

    # weight kept small so it only breaks near-ties in best-fit,
    # preserving best-fit dominance on short streams.
    return base.astype(np.float64) + 0.01 * bonus
# EVOLVE-BLOCK-END
