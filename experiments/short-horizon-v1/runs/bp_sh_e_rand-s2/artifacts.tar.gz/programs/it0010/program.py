# EVOLVE-BLOCK-START
"""Best fit with an online size-awareness finish bonus."""
import numpy as np


class _State:
    def __init__(self):
        # Histogram of observed item sizes 1..100
        self.hist = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def observe(self, item):
        self.hist[item] += 1.0
        self.total += 1.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Base: best-fit tightness (higher score = tighter fit).
    score = -residual.astype(np.float64)

    # Online size-awareness: mildly favor residuals that match a frequently
    # observed item size, so leftover gaps are fillable later.
    if _state.total > 0.0:
        # Normalized frequency per residual size (0..100).
        freq = _state.hist / _state.total
        # Residuals are 0..99 after placing a positive item.
        r = np.clip(residual, 0, 100)
        bonus = freq[r]
        # Keep the bonus small relative to best-fit's unit granularity.
        score = score + 0.5 * bonus

    _state.observe(item)
    return score
# EVOLVE-BLOCK-END
