# EVOLVE-BLOCK-START
"""Residual-reusability rule: consolidate into fuller bins while keeping leftovers useful."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.s = 0.0

    def update(self, item):
        self.n += 1
        self.s += item

    @property
    def mean(self):
        if self.n == 0:
            return 40.0
        return self.s / self.n


_STATE = _State()

# Residuals at or below this are "stranded" (too small to hold a typical item),
# so we discount them; residuals near the mean are "reusable".
_TARGET_FRAC = 1.0


def priority(item, bins):
    _STATE.update(item)
    mean = _STATE.mean
    resid = bins - item  # post-placement remaining capacity

    # Prefer a residual close to (but not above) the running mean: keeps leftover
    # space in reusable chunks. Among bins with similar residuals, prefer the
    # fuller bin (smaller residual) to consolidate. Cap the target so tiny
    # residuals are not overly rewarded.
    # Score = -(distance from target) but biased toward tighter fits via residual itself.
    target = min(mean, 60.0) * _TARGET_FRAC

    # Primary: closeness of residual to target. Secondary: prefer fuller bin (smaller residual).
    d = np.abs(resid - target)
    score = -d.astype(np.float64) - 1e-3 * resid
    return score
# EVOLVE-BLOCK-END
