# EVOLVE-BLOCK-START
"""Best fit with a small-item guard against creating tiny unusable slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Default: best fit -> prefer smallest residual after placement.
    residual = bins - item  # all >= 0 since bins only contains fitting bins
    score = -residual.astype(np.float64)

    if item <= 20:
        # Avoid leaving a tiny sliver [1, threshold) that is likely wasted.
        threshold = item  # a sliver smaller than a typical future item is wasteful
        new_res = residual
        # Mark bins that would create a bad (nonzero but tiny) sliver.
        bad = (new_res > 0) & (new_res < threshold)
        if bad.any():
            # Among all bins, prefer non-bad ones; among those, prefer fullest (smallest residual).
            # Give a large bonus to non-bad bins; tie-break still by smaller residual.
            bonus = np.where(bad, 0.0, 1000.0)
            score = bonus - new_res.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
