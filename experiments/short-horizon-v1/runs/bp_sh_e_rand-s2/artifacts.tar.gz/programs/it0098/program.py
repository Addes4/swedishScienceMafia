# EVOLVE-BLOCK-START
"""Best fit with a small penalty for unusable residual slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for bins the item fits in
    # Best fit: prefer the smallest residual.
    score = -residual.astype(np.float64)
    # Mildly penalize leaving a positive residual that is smaller than any item we've
    # ever seen (such a sliver can never be filled again -> wasted capacity).
    min_seen = priority.min_seen
    if min_seen > 1:
        sliver = (residual > 0) & (residual < min_seen)
        score -= 0.25 * sliver
    return score


priority.min_seen = 101


def _observe(item):
    if item < priority.min_seen:
        priority.min_seen = item
