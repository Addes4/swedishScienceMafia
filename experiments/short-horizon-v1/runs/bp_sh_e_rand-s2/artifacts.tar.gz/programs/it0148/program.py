# EVOLVE-BLOCK-START
"""Best-fit with a fragmentation guard against large leftovers in fresh bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 because harness only shows fitting bins

    # Fragment cost: large leftover in a bin that was not already nearly full is wasteful.
    # Penalize residuals that are neither exactly full nor large enough to host a
    # future average-sized item, scaled mildly so tight fits still dominate.
    frag = residual.astype(np.float64) * 0.0
    # A modest penalty for leaving a mid-size stranded gap (fragmentation).
    frag += np.where((residual > 0) & (residual < 40), 1.0, 0.0) * 0.5
    # Strong bonus for perfectly filling a bin.
    full_bonus = (residual == 0).astype(np.float64) * 2.0

    return -(residual.astype(np.float64)) + full_bonus - frag
# EVOLVE-BLOCK-END
