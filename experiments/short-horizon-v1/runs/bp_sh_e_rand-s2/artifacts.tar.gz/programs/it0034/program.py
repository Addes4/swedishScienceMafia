# EVOLVE-BLOCK-START
"""Best-fit with a stateful dead-sliver guard.

Primary rule: strict best-fit (place in the bin leaving the smallest nonnegative residual).
Guard: best-fit sometimes leaves a tiny residual that no future item can ever fill (a "sliver"),
wasting capacity. We track the smallest item size seen so far; if the best-fit residual is
strictly below that smallest observed item size, and some other bin fits the item while leaving a
residual of at least that smallest size (preferably 0, i.e. exactly full), we pick that bin
instead. This avoids creating permanently unusable slivers without disturbing the normal cases.
"""
import numpy as np


class _State:
    min_seen = 101  # smallest item size observed so far (101 = none yet)


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running minimum of observed item sizes.
    it = int(item)
    if it < _state.min_seen:
        _state.min_seen = it

    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - it  # remaining capacity after placing the item here

    # Best-fit: smallest residual >= 0. Score = -residual so the tightest fit wins.
    scores = -residual.astype(np.float64)

    # Dead-sliver guard. The tightest fit leaves residual_bf. If that residual is below the
    # smallest item we have ever seen, it can likely never be filled: prefer a bin whose
    # residual is 0 (exactly full) or at least min_seen, if one exists.
    min_size = _state.min_seen
    if min_size <= 100 and residual.size > 0:
        bf = int(residual.min())
        if 0 <= bf < min_size:
            # A residual >= min_size is "usable"; residual 0 is ideal (no sliver at all).
            usable = residual >= min_size
            exact = residual == 0
            if np.any(exact):
                # Strongly prefer exact fills.
                scores = np.where(exact, 1.0, -residual.astype(np.float64))
            elif np.any(usable):
                # Among usable bins, still take the tightest.
                big = np.where(usable, residual, np.iinfo(np.int64).max)
                scores = -big.astype(np.float64)
            # else: keep plain best-fit (no usable alternative exists).

    return scores
# EVOLVE-BLOCK-END
