# EVOLVE-BLOCK-START
"""Best fit with scrap-avoidance: reserve room for a typical future item."""
import numpy as np

_state = {"sum": 0, "count": 0, "resid_hist": None}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    bins = np.asarray(bins, dtype=np.int64)
    resid = bins - item

    # Learn a characteristic item size from the stream.
    st = _state
    st["sum"] += int(item)
    st["count"] += 1
    mean_item = st["sum"] / st["count"]
    typical = max(1.0, mean_item)

    # Best-fit reference: the smallest non-negative residual.
    best_fit = resid.min()

    # Primary key: prefer tightest fit, but avoid creating tiny scrap.
    # If best fit leaves a usable residual (>= typical), keep it.
    # Otherwise, prefer the smallest residual that is >= typical (usable space).
    usable = resid >= typical
    if best_fit >= typical or not usable.any():
        # Pure best fit (primary key = -resid).
        return (-resid).astype(np.float64)

    # Among bins with residual >= typical, pick the tightest such bin.
    # Score so that these beat any bin with residual < typical.
    score = np.where(usable, -resid, -1e9 - resid)
    return score.astype(np.float64)
# EVOLVE-BLOCK-END
