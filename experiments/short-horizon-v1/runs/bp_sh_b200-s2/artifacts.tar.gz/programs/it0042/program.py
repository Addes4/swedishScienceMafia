# EVOLVE-BLOCK-START
"""Best fit on a relative (scale-free) residual: put the item where the leftover
fraction of the bin's remaining capacity is smallest."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest absolute residual). Secondary: smallest
    # relative residual, so near-ties favor the bin whose hole is a smaller
    # fraction of its capacity, consolidating partially-filled bins.
    return -(residual.astype(np.float64)) - 1e-6 * (residual.astype(np.float64) / np.maximum(bins.astype(np.float64), 1.0))
# EVOLVE-BLOCK-END
