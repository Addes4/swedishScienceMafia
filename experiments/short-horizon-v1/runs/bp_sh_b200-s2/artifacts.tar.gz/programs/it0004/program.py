# EVOLVE-BLOCK-START
"""Best fit with a tiny tie-break: prefer perfect fits, then larger bins on ties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smallest residual (tightest fit). Perfect fits get a small extra boost.
    # Secondary tie-break: among equal residuals, prefer larger residual (less full),
    # which is neutral for ties but encoded as a tiny epsilon.
    return -residual.astype(np.float64) - 0.5 * (residual == 0)
# EVOLVE-BLOCK-END

