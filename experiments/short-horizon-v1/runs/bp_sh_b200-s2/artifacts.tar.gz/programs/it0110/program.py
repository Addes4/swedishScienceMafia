# EVOLVE-BLOCK-START
"""Best fit with a gentle exact-fit bonus to prefer bins that fill perfectly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best fit: smaller residual is better.
    score = -residual
    # Gentle bonus when the bin becomes exactly full, breaking flat best-fit ties
    # toward perfect packing without disturbing the primary fit ordering.
    score = score + 0.5 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
