# EVOLVE-BLOCK-START
"""Best fit, with residual ties broken toward a position likely to be refilled later.

Primary rule is classic Best Fit: pick the fitting bin with the least remaining capacity.
Best fit frequently leaves many bins with the same post-placement residual; ties are then
resolved by bin index, which is arbitrary.  We break those near-ties by preferring the bin
whose residual after placing the item is closest to a learned estimate of the typical item
size -- such a residual is likely to be exactly fillable by a future item, which helps the
final bin count.  The primary key keeps the tightness ordering intact; only placements whose
residuals are within a tiny band are affected, so behaviour is essentially best fit.
"""
import numpy as np


class _State:
    seen = 0
    total = 0.0
    ema = 40.0


_state = _State()


def priority(item, bins):
    # Update a cheap running estimate of the mean item size.
    _state.seen += 1
    _state.total += item
    # Exponential moving average, initialized near the known distribution mean.
    a = 1.0 / min(_state.seen, 50.0)
    _state.ema += a * (item - _state.ema)
    mean_est = _state.total / _state.seen if _state.seen else 40.0
    # Blend long-run mean with short-run EMA for stability.
    target = 0.5 * mean_est + 0.5 * _state.ema

    residual = bins - item  # >= 0 since bins are only fitting bins
    # Primary: least residual (best fit). Secondary: residual closest to target.
    closeness = -np.abs(residual - target)
    # Scale the secondary term small relative to the primary so it only breaks ties.
    return -(residual.astype(np.float64)) + 1e-3 * closeness
# EVOLVE-BLOCK-END

