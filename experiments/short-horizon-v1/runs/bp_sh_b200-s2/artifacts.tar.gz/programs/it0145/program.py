# EVOLVE-BLOCK-START
"""Best-fit with exact-fit dominance and tie-break towards looser bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    Rule: residual r = bins - item. Exact fits (r == 0) are strongly preferred.
    Otherwise, among bins whose residual is close to the minimum residual, prefer
    leaving more remaining capacity (looser bin) to preserve packing flexibility.
    """
    r = bins - item  # remaining capacity after placing item, >= 0
    min_r = r.min()

    # Strong bonus for exact fits; else rank by closeness to best fit but
    # break near-ties by preferring larger residual (looser bin).
    exact = (r == 0)

    # Base: prefer small residual.
    base = -r.astype(np.float64)

    # Near-best-fit band: boost looser bins within tolerance of min_r.
    # Tolerance scales with item size to allow meaningful flexibility.
    tol = max(1.0, 0.05 * item)
    near = (r <= min_r + tol)
    # Among near-best candidates, give preference to larger residual.
    tie = np.where(near, r.astype(np.float64), 0.0)

    score = base + 0.001 * tie + 1000.0 * exact.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
