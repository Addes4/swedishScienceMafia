# EVOLVE-BLOCK-START
"""Two-regime best fit: consolidate small items into already-used bins."""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item
    if item >= _MEAN:
        # Large item: pure best fit (tightest residual).
        return -resid.astype(np.float64)
    # Small item: prefer bins that become fuller, using a concave transform of residual
    # so partially-used bins are consolidated rather than scattered.
    return -np.sqrt(resid.astype(np.float64))
# EVOLVE-BLOCK-END
