# EVOLVE-BLOCK-START
"""Best fit with tie-breaking toward already-opened bins to consolidate space."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (smallest residual). Secondary: prefer bins that are
    # already partially used (residual < 100) over fresh empty bins, consolidating
    # leftover capacity instead of opening new bins.
    already_used = (bins < 100).astype(np.float64)
    return -residual + 0.5 * already_used
# EVOLVE-BLOCK-END

