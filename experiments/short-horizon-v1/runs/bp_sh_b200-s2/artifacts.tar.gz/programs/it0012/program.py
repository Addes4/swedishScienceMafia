# EVOLVE-BLOCK-START
"""Best fit with a mild reserve for typical-itemsized holes."""
import numpy as np

_MEAN = 40.0
_N = 0.0


def priority(item, bins):
    global _MEAN, _N
    # running mean of seen items (Welford-ish incremental)
    _N += 1.0
    _MEAN += (float(item) - _MEAN) / _N

    residual = bins - item  # remaining capacity after placing
    # primary: tightest fit (smallest residual)
    score = -residual.astype(np.float64)
    # tiny bonus for leaving a hole near one typical item size
    target = _MEAN
    score += 1e-3 * (1.0 - np.abs(residual - target) / 100.0)
    return score
# EVOLVE-BLOCK-END

