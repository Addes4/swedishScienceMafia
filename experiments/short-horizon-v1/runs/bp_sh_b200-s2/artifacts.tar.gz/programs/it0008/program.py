# EVOLVE-BLOCK-START
"""Best fit with a slight penalty against opening a fresh (unused) bin."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer the tightest fit, slightly avoiding unused bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    residual = bins - item  # leftover capacity after placing the item
    # Best fit: smallest residual wins. Add a tiny penalty for untouched bins so that
    # a nearly-fitting existing bin is preferred over opening a completely fresh one.
    score = -residual - 1e-6 * (bins == 100)
    return score
# EVOLVE-BLOCK-END
