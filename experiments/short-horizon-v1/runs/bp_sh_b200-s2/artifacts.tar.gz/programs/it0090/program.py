# EVOLVE-BLOCK-START
"""Best fit with a mild age/consolidation bonus to avoid opening new bins too early."""
import numpy as np

# Per-stream state: how many times each bin index has been "seen but not chosen".
_seen = {}
_counts = {}
_stream_len = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _seen, _counts, _stream_len

    n = len(bins)
    # Detect stream restart: a fresh stream begins with a single unused bin of capacity 100.
    if n == 1 and bins[0] == 100 and _stream_len != 0:
        _seen = {}
        _counts = {}
    _stream_len = n

    # Best-fit backbone: tighter residual (larger bins closer to item) is better.
    score = -(bins - item).astype(np.float64)

    # Consolidation bonus: reward bins that have been skipped over before (lingering slack),
    # so we tend to fill partially-used bins rather than open brand-new ones.
    # Only meaningful for bins that are not exactly filled.
    counts = np.empty(n, dtype=np.float64)
    total_seen = _stream_len
    for i in range(n):
        c = _counts.get(i, 0)
        counts[i] = c
        _counts[i] = c + 1

    # Normalize and scale small so it never overrides best-fit ordering distinctions.
    if total_seen > 0:
        score += 0.02 * (counts / (total_seen + 1.0))
    else:
        score += 0.0 * counts

    return score
# EVOLVE-BLOCK-END
