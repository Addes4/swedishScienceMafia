# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and residual-usability tie-break."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer exact fill, else tightest fit that leaves a large residual."""
    residual = bins - item
    # Primary: tighter fit is better (smaller residual -> higher score)
    score = -residual.astype(np.float64)
    # Strong bonus for exact fills (residual == 0)
    score += 1000.0 * (residual == 0)
    # Mild penalty for tiny non-zero residuals (1..item-1) that may be hard to reuse
    tiny = (residual > 0) & (residual < item)
    score -= 0.5 * tiny
    return score
# EVOLVE-BLOCK-END
