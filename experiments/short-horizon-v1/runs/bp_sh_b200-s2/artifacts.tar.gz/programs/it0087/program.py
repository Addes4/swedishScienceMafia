# EVOLVE-BLOCK-START
"""Two-choice hybrid: mostly best-fit, occasionally consolidate for large items."""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Score bins by best-fit, with a mild consolidation bonus for large items.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    bins = np.asarray(bins)

    # Base: best-fit -> negative residual after placement (higher is tighter).
    score = -(bins - item)

    # Mild consolidation bonus: for larger items, prefer using an already
    # partially-filled bin (lower remaining capacity) over fresher ones.
    # Scale small so exact-tight fits still dominate.
    fullness = (100 - bins).astype(np.float64)
    bonus = 0.02 * fullness * (item / 100.0)

    return score + bonus
# EVOLVE-BLOCK-END

