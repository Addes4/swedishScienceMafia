# EVOLVE-BLOCK-START
"""Best fit with exact-fit preference and a learned scrap-avoidance threshold."""
import numpy as np


class _State:
    def __init__(self):
        self.sizes = []


_state = _State()


def priority(item, bins):
    """Rank bins: exact fits first, then avoid unusable scrap, then best fit."""
    sizes = _state.sizes
    sizes.append(int(item))
    # Keep a bounded history to stay fast.
    if len(sizes) > 512:
        del sizes[:256]

    residual = bins - item  # remaining capacity after placing the item

    # Conservative threshold: small quantile of past item sizes.
    if len(sizes) >= 8:
        thr = int(np.percentile(sizes, 20))
        if thr < 1:
            thr = 1
        if thr > 100:
            thr = 100
    else:
        thr = 1

    # Key 1: exact fits (residual 0) get highest score.
    exact = (residual == 0)

    # Key 2: among non-exact, prefer residuals that keep usable space, i.e.
    # residual >= thr, and among those the tightest such fit.
    good = (~exact) & (residual >= thr)
    fallback = (~exact) & (residual < thr)

    score = np.empty(len(bins), dtype=np.float64)
    # best fit within each group: smaller residual -> higher score
    score[exact] = 3.0
    score[good] = 2.0 - residual[good] / 1000.0
    score[fallback] = 1.0 - residual[fallback] / 1000.0
    return score
# EVOLVE-BLOCK-END
