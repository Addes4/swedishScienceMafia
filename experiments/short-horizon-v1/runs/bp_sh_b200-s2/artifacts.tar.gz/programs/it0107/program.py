# EVOLVE-BLOCK-START
"""Best fit with a hard scrap-avoidance guard.

Primary rule: put the item in the bin it fits most tightly (best fit).
Tie-break / guard: strongly avoid leaving a residual that is too small to hold
any future item, since such a bin becomes permanently unusable. We do this by
adding a large bonus to bins whose post-placement residual is at least the
smallest item size seen so far (or a small default), and ranking primarily by
best fit among such "survivable" bins.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for every bin shown
    # Best fit: smaller residual is better -> larger score for smaller residual.
    fit_score = -residual.astype(np.float64)
    # A bin is "survivable" if its residual can still hold some future item.
    # Use a modest fixed threshold; items are >= 1, so residual >= 1 always
    # leaves room, but tiny scraps are wasteful in aggregate. We use a small
    # constant to avoid stranding near-useless bins.
    survivable = (residual >= 8).astype(np.float64)
    return fit_score + 2.0 * survivable
# EVOLVE-BLOCK-END
