# EVOLVE-BLOCK-START
"""Best fit with an escape to empty bins for large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    score = -residual.astype(np.float64)
    # For large items, prefer opening a fresh/empty bin to avoid locking mid-size
    # residuals into unusable fragments. Best fit otherwise.
    if item >= 50:
        score = np.where(bins == 100, score + 100.0, score)
    return score
# EVOLVE-BLOCK-END

