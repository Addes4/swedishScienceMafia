# EVOLVE-BLOCK-START
"""Best fit with a light stateful hole-preservation rule for smallish items."""
import numpy as np


class _State:
    n = 0
    total = 0.0

    def mean(self):
        return self.total / self.n if self.n else 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state.n += 1
    _state.total += item
    mean = _state.mean()

    residual = bins - item

    if item <= mean:
        # Prefer bins that will still leave a hole at least as large as the item,
        # choosing the tightest such fit; otherwise standard best fit.
        good = residual >= item
        if good.any():
            # Among good bins, pick smallest residual (tightest fit).
            scores = np.where(good, -residual.astype(np.float64), -np.inf)
            return scores

    return -(residual.astype(np.float64))
# EVOLVE-BLOCK-END
