# EVOLVE-BLOCK-START
"""Best-fit, but avoid leaving tiny unusable scraps by preferring residuals near a typical item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: prefer tight fits (small residual). Add a mild penalty for extremely
    # small nonzero residuals (unusable scraps) so we don't waste bins on them.
    score = -residual.astype(np.float64)
    scrap = (residual > 0) & (residual < 8)
    score = score - 8.0 * scrap
    return score
# EVOLVE-BLOCK-END
