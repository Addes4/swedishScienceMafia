# EVOLVE-BLOCK-START
"""Best fit with an exact-complement bonus to encourage near-perfect pairings."""
import numpy as np


def priority(item, bins):
    """Rank bins mainly by tightest fit, with a bonus for leaving residual == item.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin (bin order).
    """
    residual = bins - item  # >= 0 by construction of the harness
    # Primary key: tighter fit => higher score.
    score = -residual.astype(np.float64)
    # Secondary bonus: a residual equal to `item` can host a future twin exactly.
    score += 0.5 * (residual == item)
    return score
# EVOLVE-BLOCK-END

