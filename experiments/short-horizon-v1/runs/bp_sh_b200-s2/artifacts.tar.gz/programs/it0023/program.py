# EVOLVE-BLOCK-START
"""Best fit enhanced with a running size-frequency bonus for exact residual matches."""
import numpy as np


class _State:
    def __init__(self):
        self.freq = np.zeros(101, dtype=np.float64)  # freq[s] = count of items of size s
        self.n = 0.0

    def update(self, item):
        self.freq[item] += 1.0
        self.n += 1.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties)."""
    _state.update(item)

    residual = bins - item  # >= 0 for all shown bins
    # Base: best fit -> prefer the smallest post-placement residual (most negative score).
    score = -residual.astype(np.float64)

    # Bonus for perfect fit (leaves no hole).
    score += 60.0 * (residual == 0)

    # Bonus: leaving a residual that is a frequent item size (a reusable hole).
    # Only consider residuals in 1..100.
    valid = (residual >= 1) & (residual <= 100)
    if np.any(valid):
        freq = _state.freq
        p = freq / max(_state.n, 1.0)
        r = residual[valid]
        score[valid] += 20.0 * p[r]

    return score
# EVOLVE-BLOCK-END
