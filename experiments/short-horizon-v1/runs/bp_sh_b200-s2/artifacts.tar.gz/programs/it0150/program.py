# EVOLVE-BLOCK-START
"""Best fit with a small residual tolerance window to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Score bins: strongly prefer the tightest fit, but within a tiny window
    of the minimum residual, prefer the larger residual to spread load.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing item; >= 0
    min_res = residual.min()
    # Tolerance window: 0 for exact fits, else a small fraction of item size.
    tol = 0 if min_res == 0 else max(1, item // 20)
    within = residual <= (min_res + tol)
    # Base score: tighter fit -> higher. Tie-break (additive, small): larger residual.
    base = -residual.astype(np.float64)
    bonus = np.where(within, residual, 0).astype(np.float64) * 0.001
    return base + bonus
# EVOLVE-BLOCK-END

