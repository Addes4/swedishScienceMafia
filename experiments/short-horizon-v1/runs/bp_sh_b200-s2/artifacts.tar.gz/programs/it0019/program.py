# EVOLVE-BLOCK-START
"""Smart best-fit: best-fit, with a fallback that consolidates small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # post-placement leftover (>= 0 since bins fits)
    # Base: best-fit => smaller residual is better.
    score = -residual.astype(np.float64)

    # Small-item consolidation: if item is small, prefer bins that are already
    # partly used (residual < 100 before placement) so leftovers get reused
    # rather than opening fresh bins repeatedly.
    if item <= 30:
        was_used = bins < 100
        # Prefer used bins slightly, but still rank by tightest fit within them.
        score = score + 0.25 * was_used.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
