# EVOLVE-BLOCK-START
"""Best-fit with an unusable-hole guard.

Classic best fit chooses the bin minimizing the residual after placement. A known
weakness is that this can strand tiny holes (residual smaller than anything that
will ever arrive), which are effectively wasted. We keep best fit as the primary
criterion, but add a mild penalty for bins whose post-placement residual is very
small yet nonzero, since such a hole can only be filled by an even smaller item.
"""
import numpy as np

_SMALL = 6  # residuals in [1, _SMALL) are treated as nearly-unusable holes


def priority(item, bins):
    residual = bins - item
    # Primary: best fit (smaller residual after placement is better).
    score = -residual.astype(np.float64)
    # Penalize tiny nonzero residuals: they waste a bin slot.
    tiny = (residual >= 1) & (residual < _SMALL)
    score[tiny] -= (1.0 + (_SMALL - residual[tiny]))
    # Strongly reward exact fills.
    score[residual == 0] += 1.0
    return score
# EVOLVE-BLOCK-END
