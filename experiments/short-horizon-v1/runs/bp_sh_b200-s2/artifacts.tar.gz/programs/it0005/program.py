# EVOLVE-BLOCK-START
"""Best fit with a small bias toward bins that can still hold a large item."""
import numpy as np

# Running state across calls within a stream.
_state = {"max_seen": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    # Update a conservative running estimate of the largest item size seen.
    if item > _state["max_seen"]:
        _state["max_seen"] = item
    big = _state["max_seen"]

    residual = (bins - item).astype(np.float64)

    # Primary: tightest fit (smallest residual).
    score = -residual.astype(np.float64) * 1000.0

    # Secondary tiny bias: prefer bins whose residual can still hold a large item,
    # i.e. avoid crushing a bin so much that no large future item can fit there.
    # This is essentially free when residuals differ much (factor 1000).
    can_fit_big = (residual >= big).astype(np.float64)
    score += can_fit_big

    return score
# EVOLVE-BLOCK-END

