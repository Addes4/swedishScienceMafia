# EVOLVE-BLOCK-START
"""Best-fit with a stateful residual-aware refinement.

Pure best-fit minimizes the residual `bins - item`.  That closes bins as tightly
as possible, but frequently leaves a tiny hole that no later item can use.  We
estimate the item distribution online and, when best-fit's residual would be
smaller than a typical item, prefer the *tightest* bin whose residual is still
at least that typical size (so the hole stays usable).  Fall back to best-fit.
"""
import numpy as np

_state = {"count": 0, "mean_est": 40.0, "q_small": 40.0}


def priority(item, bins):
    st = _state
    # online estimate of a "usable" residual: track running mean of item sizes.
    st["count"] += 1
    c = st["count"]
    m = st["mean_est"]
    m = m + (item - m) / (c if c < 200 else 200.0)  # decaying mean update
    st["mean_est"] = m

    residual = bins - item  # >= 0 since bins shown all fit

    # Typical residual that should remain usable for a future item.
    target = m * 0.5

    # Best-fit ranking (highest score = smallest non-negative residual).
    best_fit = -residual.astype(np.float64)

    # Bins whose residual after placement is at least `target` keep a useful hole.
    # Among those, prefer the tightest (smallest residual) -> still best-fit-like.
    usable = residual >= target
    if usable.any():
        # Small bonus for usable bins; magnitude below 1 so it only breaks
        # near-ties toward keeping a usable hole, never overrides tightness.
        bonus = np.where(usable, 0.5, 0.0)
    else:
        bonus = np.zeros_like(residual, dtype=np.float64)

    return best_fit + bonus
# EVOLVE-BLOCK-END
