# EVOLVE-BLOCK-START
"""Best fit with a small residual target to keep holes matched to typical items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity if placed here
    # Mildly prefer leaving a residual near half a typical item, but keep the
    # dominant best-fit term so tightly-filled existing bins still win.
    return -residual.astype(np.float64) - 0.05 * np.abs(residual - 20)
# EVOLVE-BLOCK-END

