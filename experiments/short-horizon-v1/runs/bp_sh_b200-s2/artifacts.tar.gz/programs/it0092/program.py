# EVOLVE-BLOCK-START
"""Best fit with a late-stream tiny-residual guard."""
import numpy as np

_state = {"t": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["t"] += 1
    residual = bins - item  # remaining capacity after placing the item

    # Base: best fit -> highest priority for the smallest non-negative residual.
    score = -(residual.astype(np.float64))

    # Late in the stream, mildly discourage creating small unusable leftovers,
    # but never penalize an exact fill (residual == 0).
    # The penalty grows slowly with stream position and stays tiny, so it only
    # breaks near-ties in favour of tighter completions.
    if _state["t"] > 2500:
        tiny = (residual > 0) & (residual < 15)
        score -= 0.5 * tiny.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
