# EVOLVE-BLOCK-START
"""Best fit, with a small bonus for bins that are already fuller (consolidation)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item            # remaining capacity after placing the item
    used_after = 100 - residual       # how full the bin would be afterwards
    # Primary: tightest residual (best fit). Secondary (tiny): fuller bin wins.
    return -residual - 1e-3 * used_after
# EVOLVE-BLOCK-END

