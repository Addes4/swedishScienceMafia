# EVOLVE-BLOCK-START
"""Best fit with a residual-usability penalty informed by an online item histogram."""
import numpy as np


class _State:
    def __init__(self):
        # coarse histogram over item sizes 1..100
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0


_state = _State()


def priority(item, bins):
    """Rank fitting bins. Primary: best fit. Secondary: avoid wasting small residuals."""
    st = _state
    # update histogram
    st.counts[item] += 1.0
    st.total += 1.0

    # probability that a future item can fill a residual of size r (r in 1..99)
    # a residual r is "usable" if some item size in the distribution can land near it.
    # Estimate P(item <= r) mass and the chance of a near-exact fill (r - item small).
    counts = st.counts
    total = st.total
    # smoothed probabilities
    probs = (counts + 0.5) / (total + 50.5)
    cum = np.cumsum(probs)  # cum[r] = P(item <= r)

    residual = (bins - item).astype(np.float64)  # remaining capacity after placing
    fit_mask = residual >= 0

    # base: best fit (prefer smallest residual)
    score = -residual

    # Penalty for residuals that are hard to reuse:
    # If residual is in a low-probability fill zone (no likely item ~ residual and
    # residual is small), reduce slightly.  A residual r is good if there's a decent
    # chance of an item exactly r or slightly less arriving to nearly fill it.
    # near_exact[r] = P(item == r) (since residual r could be filled exactly by item r)
    near_exact = probs  # index r gives P(item==r)

    # "fraction of future items that could fill residual r": P(item <= r)
    fillable = np.zeros(101, dtype=np.float64)
    fillable[:] = cum[:101]

    # Value of a residual: wants either to be large enough to keep the bin useful
    # (many items fit) or exactly fillable. Penalize tiny residuals with low fill prob.
    r = residual.astype(np.int64)
    r = np.clip(r, 0, 100)

    # reuse_score: high when many future items can still fit (residual big) OR
    # when residual is likely to be exactly filled.
    reuse = fillable[r] + 2.0 * near_exact[r]

    # small weight so best-fit stays dominant
    score = score + 0.6 * reuse

    # apply only where fits
    score = np.where(fit_mask, score, -np.inf)
    return score
# EVOLVE-BLOCK-END
