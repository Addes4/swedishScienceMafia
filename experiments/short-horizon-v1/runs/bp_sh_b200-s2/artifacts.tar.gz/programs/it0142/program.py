# EVOLVE-BLOCK-START
"""Near-best fit with slack: among the tightest fits, prefer leaving a bit more room."""
import numpy as np

_SLACK = 4  # allow choosing a fit up to this many units looser than the tightest


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    rmin = residual.min()
    # Among near-tight fits, prefer a slightly larger residual.
    near = residual <= rmin + _SLACK
    score = np.where(near, residual.astype(np.float64), -1.0e18 - residual.astype(np.float64))
    return score
# EVOLVE-BLOCK-END
