# EVOLVE-BLOCK-START
"""Best fit that avoids opening new bins until necessary."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)
    is_empty = (bins == 100)
    # Best fit score: tighter residual is better.
    fit = -(bins - item)
    # Large penalty for empty bins so partial bins are preferred; only used when
    # no partial bin can hold the item (all fitting bins are empty).
    fit = fit - is_empty * 1000.0
    return fit
# EVOLVE-BLOCK-END

