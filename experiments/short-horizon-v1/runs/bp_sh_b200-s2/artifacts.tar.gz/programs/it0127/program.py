# EVOLVE-BLOCK-START
"""Best fit with a mild exact-fit and usable-residual preference."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: prefer exact fit (residual 0) slightly, then tighter fit.
    # Tiny bonus for exact fit so it dominates the tightest-fit ordering but nothing else.
    return -residual + (residual == 0) * 0.5
# EVOLVE-BLOCK-END
