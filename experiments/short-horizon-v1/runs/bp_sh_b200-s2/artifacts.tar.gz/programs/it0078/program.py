# EVOLVE-BLOCK-START
"""Harmonic-class best fit: prefer residuals that past items commonly complete."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins, dtype=np.int64)
    # Post-placement residual in each candidate bin.
    residual = bins - item

    # Primary: prefer the tightest fit (smallest residual) -> best fit.
    # Secondary: among near-ties, prefer residuals that are "common" completions,
    # estimated from observed item sizes via a decaying online histogram.
    hist = getattr(priority, "_hist", None)
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        priority._hist = hist
    hist[item] += 1.0
    # Decay to track the distribution while favoring recent items.
    if hist[item] > 1e-9:
        pass
    total = hist.sum()
    # Probability that a future item equals a given residual size (roughly).
    prob = hist / total if total > 0 else hist

    # Completion bonus: how likely the residual can be exactly matched soon.
    # For residual r, sum probability of items up to r that could shrink it,
    # approximating "matchability" by the probability mass at exactly r plus
    # a small neighborhood. Use relative scale so best-fit still dominates.
    safe = np.clip(residual, 0, 100)
    bonus = prob[safe]

    # Combine: strongly prefer best fit, break near-ties by completion bonus.
    score = -residual.astype(np.float64) + 2.0 * bonus
    return score
# EVOLVE-BLOCK-END
