# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and running-aware tie handling."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Primary: prefer smallest residual after placement (best fit).
    # Reward exact fills (residual 0) slightly more strongly.
    score = -residual.astype(np.float64)
    score += 0.5 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
