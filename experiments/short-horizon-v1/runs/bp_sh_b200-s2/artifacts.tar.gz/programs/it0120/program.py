# EVOLVE-BLOCK-START
"""Best fit, with tie-breaking that prefers residuals matching the typical item size.

Best fit minimizes the post-placement residual. Ties (common with integer sizes) are broken
by preferring a residual close to the running mean item size, which tends to create gaps that
future items can fill exactly. Primary key remains tightest fit so we never regress much.
"""
import numpy as np

_STATE = {"count": 0, "sum": 0.0}


def priority(item, bins):
    # update running mean of item sizes
    _STATE["count"] += 1
    _STATE["sum"] += item
    mean_item = _STATE["sum"] / _STATE["count"]

    residual = bins - item
    # primary: smaller residual better -> use -residual
    # secondary (tiny): residual closer to mean_item is better
    target = mean_item
    tie = -np.abs(residual - target) * 1e-3
    return -residual.astype(np.float64) + tie
# EVOLVE-BLOCK-END
