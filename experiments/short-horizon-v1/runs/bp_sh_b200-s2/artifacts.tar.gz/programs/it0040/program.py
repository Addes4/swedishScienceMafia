# EVOLVE-BLOCK-START
"""Best fit with a mild harmonic/fill-level preference.

Primary signal is best fit (smallest post-placement residual). A small secondary term
prefers fuller bins (smaller remaining capacity) to encourage consolidation, which
reduces the number of barely-used open bins on Weibull-shaped item streams.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item          # post-placement residual, 0 <= residual <= 99
    # Best fit primary: smaller residual -> larger score.
    primary = -np.log1p(residual)
    # Mild consolidation bonus: prefer fuller bins (smaller remaining capacity).
    secondary = -0.05 * np.log1p(bins)
    return primary + secondary
# EVOLVE-BLOCK-END
