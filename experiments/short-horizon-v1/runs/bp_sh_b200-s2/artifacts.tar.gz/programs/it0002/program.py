# EVOLVE-BLOCK-START
"""Best-fit with a residual-capacity target based on the running mean item size."""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["sum"] += item
    st["count"] += 1
    mean = st["sum"] / st["count"]

    # After placing the item, try to leave a residual close to the mean item size,
    # so the leftover space is likely usable by a future typical item.
    residual = bins - item
    # Prefer residuals at or just above the mean; penalize too-small leftovers mildly
    # and too-large (nearly empty) bins moderately.
    target = mean
    return -np.abs(residual - target) - 0.15 * np.maximum(0, residual - target)
# EVOLVE-BLOCK-END

