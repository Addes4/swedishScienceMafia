# EVOLVE-BLOCK-START
"""Spread-fit: prefer the emptiest bin the item fits in, with a mild best-fit tiebreak.

Best-fit leaves many bins with tiny unusable residuals on heavy-tailed (Weibull) item
streams. Preferring bins with more remaining capacity keeps residuals large and reusable,
which reduces the number of new bins opened. A small best-fit component retains tightness
when continuity clearly dominates.
"""
import numpy as np


def priority(item, bins):
    """Higher score = preferred bin. Item fits in all bins shown (capacity >= item)."""
    rem = bins.astype(np.float64)
    # Primary: prefer emptier bins (more remaining capacity) to preserve usable slack.
    # Secondary: among similarly empty bins, prefer the tighter (best-fit) fit.
    score = rem - 0.25 * (rem - item)
    return score
# EVOLVE-BLOCK-END

