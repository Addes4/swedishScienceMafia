# EVOLVE-BLOCK-START
"""Size-aware best fit with a mild harmonic tie-break to reduce unusable holes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit -> smallest residual after placing gets highest score.
    score = -residual.astype(np.float64)

    # For smaller items, gently prefer leaving a residual that is a multiple of the
    # item size (a reusable slot) rather than a tiny unusable hole.
    if item <= 50:
        r = residual.astype(np.float64)
        # residual modulo item, smaller is better (0 ideal). Only nudge.
        mod = np.mod(r, item)
        score -= 0.25 * mod

    return score
# EVOLVE-BLOCK-END
