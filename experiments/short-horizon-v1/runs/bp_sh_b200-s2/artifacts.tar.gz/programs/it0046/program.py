# EVOLVE-BLOCK-START
"""Best-fit on a convex potential: minimize the sum of squared remaining capacities.

Placing an item of size s into a bin with remaining capacity r changes that bin's
contribution to sum(r_i^2) from r^2 to (r-s)^2, i.e. a decrease of r^2 - (r-s)^2
= 2*s*r - s^2. We maximize this per-bin decrease, which is equivalent to preferring
the largest remaining capacity that still fits... but we instead weight it so that
tight fits are favored while still keeping bins from being fragmented.
"""
import numpy as np


def priority(item, bins):
    """Score bins by the decrease in the sum of squared remaining capacities.

    Decrease = r^2 - (r - item)^2 = item * (2*r - item), maximized over fitting bins.
    Higher score is better; ties go to the first bin.
    """
    r = bins.astype(np.float64)
    return item * (2.0 * r - item)
# EVOLVE-BLOCK-END
