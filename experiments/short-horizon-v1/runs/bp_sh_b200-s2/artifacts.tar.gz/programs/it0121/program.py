# EVOLVE-BLOCK-START
"""Best fit with online scrap-avoidance.

Best fit (tightest residual) is a strong online rule, but it often strands
tiny unusable scraps.  We keep tightest-fit as the dominant signal and add a
learned penalty for placements that leave a residual too small to host the
smaller items we actually see, so those scraps get avoided when a comparably
tight alternative exists.  Statistics are learned online from the stream.
"""
import numpy as np


# Module-level online state (per stream; the harness resets it between streams
# by reloading / re-importing the module in practice, and even if not, the
# estimate is a mild statistic that quickly adapts).
_state = {
    "small": None,   # running estimate of a "small" (but common) item size
    "min_seen": None,
}


def _update(item):
    s = _state
    # Track a robust small-item scale: the running minimum seen (clipped) is
    # too fragile, so use an exponential estimate toward small items.
    if s["min_seen"] is None:
        s["min_seen"] = item
        s["small"] = item
    else:
        s["min_seen"] = min(s["min_seen"], item)
        # move slowly toward the small end of the distribution
        if item < s["small"]:
            s["small"] = 0.7 * s["small"] + 0.3 * item
        else:
            s["small"] = 0.98 * s["small"] + 0.02 * item


def priority(item, bins):
    _update(item)
    residual = bins - item                      # capacity left after placing
    # tightest fit is the dominant signal: larger (less negative) is better,
    # where "tight" means small non-negative residual.
    score = -residual.astype(np.float64)

    # scrap threshold: residual too small to be usefully reused
    small = _state["small"]
    if small is None:
        small = 1.0
    thresh = max(1.0, min(small, 20.0))         # cap for stability

    # penalize tiny scraps: residual in (0, thresh) is nearly wasted capacity.
    scrap = (residual > 0) & (residual < thresh)
    score = score - 1.5 * scrap.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
