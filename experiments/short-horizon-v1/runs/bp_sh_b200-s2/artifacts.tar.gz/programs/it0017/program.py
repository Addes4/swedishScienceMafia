# EVOLVE-BLOCK-START
"""Residual-matching rule.

Place the arriving item in the fitting bin whose remaining capacity after
placement is closest to the item's own size.  This leaves a hole that can
exactly hold another item of the same size, exploiting the fact that item
sizes in the stream cluster (Weibull-shaped distribution).
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Score smaller (closer to `item`) residuals higher.
    return -np.abs(residual - item)
# EVOLVE-BLOCK-END

