# EVOLVE-BLOCK-START
"""Best fit with a tiny residual-target bonus to reduce wasted scraps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best-fit dominates; tiny bonus for residuals near ~40 (typical future item size),
    # while mildly penalizing tiny unusable scraps.
    target = 40
    bonus = -0.01 * (residual - target) ** 2
    return -residual + bonus
# EVOLVE-BLOCK-END
