# EVOLVE-BLOCK-START
"""Best-fit with residual tie-break biased toward more-filled bins.

Primary key: minimize the residual after placing the item (best fit).
Secondary key: among equal residuals, prefer the bin that currently has the least
remaining capacity (i.e. is more full), which consolidates load and tends to
close out near-full bins rather than leaving many partially used ones open.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Primary: smaller residual is better -> negative residual.
    # Secondary: smaller pre-placement remaining capacity (bins) is better, used
    # only to break ties. Scale it down so it never overrides the primary key.
    return -residual.astype(np.float64) - bins.astype(np.float64) * 1e-6
# EVOLVE-BLOCK-END

