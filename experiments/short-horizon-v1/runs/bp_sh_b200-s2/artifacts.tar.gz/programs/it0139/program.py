# EVOLVE-BLOCK-START
"""Best fit, but prefer a bin the item exactly fills (residual 0)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual_after = bins - item
    # Primary: tightest fit (smallest residual after placement).
    # Exact fits (residual 0) already win under this, so best-fit is preserved.
    return -(residual_after)
# EVOLVE-BLOCK-END

