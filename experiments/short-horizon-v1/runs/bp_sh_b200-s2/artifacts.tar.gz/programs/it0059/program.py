# EVOLVE-BLOCK-START
"""Learned best-fit: tie-break by how likely the residual is to be filled later."""
import numpy as np


class _State:
    def __init__(self):
        # running histogram of item sizes 1..100
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0

    def update(self, item):
        self.hist[item] += 1.0
        self.count += 1
        if self.count % 64 == 0:
            s = self.hist.sum()
            if s > 0:
                self.hist /= s


_state = _State()


def priority(item, bins):
    """Score bins: best fit primary, with a bonus if the residual is a common item size."""
    _state.update(item)
    residual = bins - item  # >= 0 for all shown bins
    # primary: best fit (smaller residual better) -> negative residual
    score = -residual.astype(np.float64)

    # secondary: how likely is this residual to be fillable by a future item?
    # use the observed frequency of item sizes <= residual, as a smooth bonus.
    # cumulative mass of items with size <= residual
    cum = np.cumsum(_state.hist[1:])  # cum[k-1] = P(size <= k)
    r = np.clip(residual, 0, 100).astype(np.int64)
    # expected usefulness: prob a future item is <= residual, weighted by closeness
    useful = cum[np.maximum(r - 1, 0)]
    # bonus scaled small so best-fit stays dominant
    score += 0.35 * useful
    return score
# EVOLVE-BLOCK-END
