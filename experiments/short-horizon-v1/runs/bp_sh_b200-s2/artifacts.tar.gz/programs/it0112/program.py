# EVOLVE-BLOCK-START
"""Sum-of-Squares rule: choose the bin that most reduces the sum of squared residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Sum-of-Squares: placing into a bin changes its residual from b to b-item.  The
    resulting sum-of-squares decreases by 2*b*item - item*item, so maximizing the
    chosen bin's remaining capacity b maximizes the reduction.  This is the classic
    online "Sum of Squares" heuristic.
    """
    # Higher score = better. 2*item*b - item^2, with b = bins.
    return 2.0 * item * bins.astype(np.float64) - float(item) * float(item)
# EVOLVE-BLOCK-END

