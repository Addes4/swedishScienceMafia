# EVOLVE-BLOCK-START
"""Best fit with a mild "keep the bin reusable" secondary term."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 by contract
    # Primary: best fit (most negative residual wins after negation).
    score = -residual.astype(np.float64)
    # Secondary: mild bonus for residuals that stay meaningfully reusable.
    # A residual around half a typical item (~20) is fine; tiny residuals are penalized.
    reuse = np.minimum(residual, 20) * 0.02
    return score + reuse
# EVOLVE-BLOCK-END

