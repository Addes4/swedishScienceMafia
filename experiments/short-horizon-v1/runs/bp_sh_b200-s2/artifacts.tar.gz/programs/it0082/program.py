# EVOLVE-BLOCK-START
"""Best fit with exact-fill dominance.

Standard best-fit places each item in the bin it fits most tightly. When some bin
would be filled exactly (post-placement residual 0), that placement is always at
least as good as any other: it wastes nothing and closes a bin. So we give such
bins a dominant score and use best-fit for the remaining candidates.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for every bin shown
    # Exact fill (residual 0) dominates; otherwise prefer tightest fit (smallest residual).
    return -(residual) + (residual == 0) * 1000.0
# EVOLVE-BLOCK-END
