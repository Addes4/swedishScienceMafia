# EVOLVE-BLOCK-START
"""Two-choice rule guided by an online estimate of item-size distribution.

The core idea: best-fit is strong, but it can leave awkward residuals that no
future item can use.  We keep best-fit as the backbone, but among the candidate
bins whose post-placement residual is "matchable" (close to a value that the
observed item distribution actually produces), we prefer the fullest bin so that
large predictable gaps get closed.  An online histogram of seen item sizes gives
a cheap, robust estimate of which residuals are useful.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0

_MATCH_MIN = 8.0
_MATCH_MAX = 92.0


def _matchability(res):
    """Return a value in [0,1]: how likely `res` is usable by a future item."""
    if res < _MATCH_MIN:
        return 0.0
    if res > 100.0:
        return 0.0
    if _TOTAL < 30.0:
        # Not enough data: treat every plausible residual as equally usable.
        return 1.0 if res <= 100.0 else 0.0
    lo = int(res - 6)
    hi = int(res + 6)
    if lo < 1:
        lo = 1
    if hi > 100:
        hi = 100
    if hi < lo:
        return 0.0
    frac = _HIST[lo:hi + 1].sum() / _TOTAL
    return float(frac)


def priority(item, bins):
    """Rank bins: best-fit backbone, refined by estimated future matchability."""
    global _TOTAL
    # Update the online histogram with the arriving item.
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _TOTAL += 1.0

    b = np.asarray(bins, dtype=np.float64)
    res = b - item  # resulting residual after placement

    # Best-fit primary term: tighter fits get higher score.
    score = -res

    # Refinement: reward residuals that the observed distribution can match,
    # and mildly prefer fuller bins to consolidate partially-used bins.
    if _TOTAL >= 30.0:
        for i in range(res.shape[0]):
            m = _matchability(res[i])
            # scale refinement to ~1 unit so it only breaks near-ties
            score[i] += 1.5 * m
            # small consolidation bonus proportional to how full the bin is
            score[i] += 0.02 * (100.0 - res[i])

    return score
# EVOLVE-BLOCK-END

