# EVOLVE-BLOCK-START
"""Hybrid: best-fit among partially-used bins; fall back to empty bins only if needed."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Penalize fully-empty bins (remaining capacity 100 before placement) so that
    # partially-used bins are consolidated first; prefer tightest fit otherwise.
    empty_penalty = (bins == 100).astype(np.float64) * 1000.0
    return -residual.astype(np.float64) - empty_penalty
# EVOLVE-BLOCK-END

