# EVOLVE-BLOCK-START
"""Best fit with a small distribution-aware tie-break nudge."""
import numpy as np

# Target residual: a typical (mean-ish) item should still fit comfortably.
_TARGET = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smaller residual is better (best fit).
    # Secondary: a tiny bonus when residual is near _TARGET so bins stay useful.
    nudge = -0.01 * np.abs(residual - _TARGET)
    return -residual.astype(np.float64) + nudge
