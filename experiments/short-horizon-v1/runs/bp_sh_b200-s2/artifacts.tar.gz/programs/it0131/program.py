# EVOLVE-BLOCK-START
"""Best fit with a narrow exact-fit band: tightest placement wins, but within a tiny
window of residuals near the best fit, prefer a residual that future items can combine into."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # remaining capacity after placing the item; smaller = tighter

    # Tiny tolerance band: residuals within 1 unit of the tightest are treated as ties,
    # then we prefer the one that leaves the least "unreachable scrap" relative to the
    # smallest typical item (about 1). Outside the band, pure best-fit ordering holds.
    best = residual.min()
    band = residual <= (best + 1)

    # Score: primary tightness, secondary small preference for residual 0 (perfect fit)
    # and for even residuals (parity can help future small-item packing) inside the band.
    score = -residual.astype(np.float64)
    score += band.astype(np.float64) * 0.25 * (residual == 0)
    score += band.astype(np.float64) * 0.10 * ((residual % 2) == 0)
    return score
# EVOLVE-BLOCK-END
