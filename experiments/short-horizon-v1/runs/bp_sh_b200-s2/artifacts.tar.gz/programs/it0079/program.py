# EVOLVE-BLOCK-START
"""Consolidating fit: avoid opening new bins; otherwise fill the fullest useful bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remaining = bins - item  # residual capacity after placing the item (>= 0)

    # Prefer any bin that is already partially used (remaining < 100) over unused bins,
    # to delay opening new bins.  Among partial bins, prefer the best (tightest) fit,
    # which keeps residuals small and matches future items well.
    is_empty = bins >= 100
    score = -remaining.astype(np.float64)
    score += is_empty * (-1000.0)
    return score
# EVOLVE-BLOCK-END
