# EVOLVE-BLOCK-START
"""Learned residual-value best fit for online bin packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # residual after placing the item

    # Best-fit base: prefer the tightest fit (smallest positive residual).
    base = -rem.astype(np.float64)

    # Exact-fit bonus: a zero residual is always ideal.
    exact = (rem == 0).astype(np.float64) * 50.0

    # Reward residuals that are themselves valid item sizes we've seen often,
    # which makes them likely to be fillable by a later item (better reuse).
    # A residual that is too large wastes space; a residual that is too small
    # or odd-sized is hard to reuse. Use a smooth window around the mean item size.
    r = rem.astype(np.float64)
    # Peak reuse value near typical item size (~40); penalize residuals far below.
    quality = np.exp(-((r - 40.0) ** 2) / (2.0 * 30.0 ** 2))
    # Discourage leaving tiny unusable slivers.
    tiny = np.where((r > 0) & (r < 10), -5.0, 0.0)

    return base + exact + 8.0 * quality + tiny
# EVOLVE-BLOCK-END
