# EVOLVE-BLOCK-START
"""Best fit with a consolidation tie-break among equal residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize residual (best fit). Secondary: among equal residuals,
    # prefer the bin with the largest used space (smallest remaining capacity before placement),
    # i.e. the fuller bin, to consolidate partial bins. Tertiary: earlier bin index.
    # Encode as a single score: residual dominates, used-space breaks ties.
    # used = 100 - bins; we want larger used -> subtract a small multiple of residual-> no,
    # residual dominates so use residual * (W) where W > max used tie-break range.
    used = 100 - bins
    # residual ranges 0..99; used ranges 0..99. Scale residual by 1000 so it dominates.
    return -(residual * 1000) + used
# EVOLVE-BLOCK-END

