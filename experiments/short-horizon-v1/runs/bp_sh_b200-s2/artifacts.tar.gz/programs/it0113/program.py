# EVOLVE-BLOCK-START
"""Best fit with adaptive worst-fit escape when residual becomes an unusable scrap."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _State
    # adaptive estimate of item size scale
    if 'st' not in priority.__dict__:
        priority.st = _State()
    st = priority.st

    st.n += 1
    st.mean += (item - st.mean) / st.n
    mean = st.mean
    if mean < 5.0:
        mean = 5.0

    residual = bins - item  # >= 0 since item fits

    # Best-fit score: tighter fit -> higher score
    bf = -residual.astype(np.float64)

    # Best-fit candidate residual
    best_idx = int(np.argmax(bf))
    best_res = residual[best_idx]

    scrap_thresh = 0.5 * mean

    # If best fit leaves an unusable scrap, prefer the bin with the most room
    if best_res < scrap_thresh:
        # Worst fit: most remaining capacity after placing
        wf = residual.astype(np.float64)
        wf_best = int(np.argmax(wf))
        wf_res = residual[wf_best]
        # Only switch if worst fit leaves a meaningfully better residual
        if wf_res >= best_res + max(1.0, scrap_thresh):
            out = np.full(len(bins), -1e18, dtype=np.float64)
            out[wf_best] = 0.0
            # keep best-fit as fallback ranking for the rest
            out = bf
            out[wf_best] = bf.max() + 1.0
            return out

    return bf
# EVOLVE-BLOCK-END
