# EVOLVE-BLOCK-START
"""Best fit with a guard against leaving permanently useless holes.

For each bin we compute the residual after placing the item.  Pure best fit picks
the smallest residual.  We refine it: a nonzero residual that is smaller than the
smallest item size seen so far can never be filled again, so it is wasted capacity.
We heavily penalize such holes, otherwise we keep best fit ordering.
"""
import numpy as np

_min_item = 101


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _min_item
    if item < _min_item:
        _min_item = item

    residual = bins - item  # >= 0 since bins only contains bins the item fits in

    # Start from best fit: smallest residual is best.
    score = -residual.astype(np.float64)

    # Penalize nonzero residuals that are strictly smaller than any future item
    # can be: those holes are unusable, effectively losing that capacity.
    dead = (residual > 0) & (residual < _min_item)
    score[dead] -= 1000.0

    return score
# EVOLVE-BLOCK-END
