# EVOLVE-BLOCK-START
"""Best fit, with an explicit bonus for perfect fits (residual zero)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best fit is primary: prefer the smallest residual.
    score = -residual.astype(np.float64)
    # Strongly reward exact fits so that a perfect fit always beats any near-perfect fit.
    score += (residual == 0).astype(np.float64) * 1000.0
    return score
# EVOLVE-BLOCK-END
