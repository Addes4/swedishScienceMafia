# EVOLVE-BLOCK-START
"""Best fit with a small tie-break toward residuals matching common item sizes."""
import numpy as np

_state = {"sizes": None}


def priority(item, bins):
    """Rank bins by tightest fit, breaking near-ties toward fillable residuals."""
    # Learn an online estimate of the item-size distribution (histogram of recent items).
    s = _state.get("sizes")
    if s is None:
        s = np.zeros(101, dtype=np.float64)
        _state["sizes"] = s
    # decay to keep it adaptive
    s *= 0.995
    s[item] += 1.0

    residual = bins - item  # remaining capacity after placing item (>=0)

    # Primary key: tightest fit (smaller residual is better).
    score = -residual.astype(np.float64)

    # Estimate a typical item size from the histogram (mean, rounded).
    total = s.sum()
    if total > 1.0:
        idx = np.arange(101)
        mean_size = float((s * idx).sum() / total)
    else:
        mean_size = float(item)

    # Small bonus: prefer residuals close to a typical future item size,
    # so the leftover can likely be filled later. Bounded well below 1.0
    # so it only breaks ties among equal/near-equal fits.
    diff = np.abs(residual - mean_size)
    bonus = 0.001 * (1.0 / (1.0 + diff))
    return score + bonus
# EVOLVE-BLOCK-END

