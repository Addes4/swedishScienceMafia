# EVOLVE-BLOCK-START
"""Best fit with a learned "residual usefulness" tie-breaker.

Items are drawn i.i.d. from a fixed (Weibull-shaped) distribution, so the
sizes we have already seen are an unbiased sample of future sizes.  After
placing the item into a bin, the leftover residual r is only usable by a
future item of size <= r.  Best fit ignores this and greedily minimises r,
which can create many tiny unusable scraps.  We therefore keep best fit as
the dominant key, but break its flat/near-flat tie region in favour of
residuals that look like a good "slot" for the empirical item distribution:
a residual that can hold a typical item, yet is not far larger than a
typical item, is the most likely to be filled exactly later.
"""
import numpy as np

# --- state kept between calls within a stream -------------------------------
_SIZES = np.zeros(101, dtype=np.float64)   # decaying histogram of item sizes
_TOTAL = 0.0                               # total decayed weight


def _observe(item):
    global _TOTAL
    # exponential forgetting so the estimate tracks the (fixed) distribution
    _SIZES *= 0.995
    _TOTAL *= 0.995
    _SIZES[item] += 1.0
    _TOTAL += 1.0


def _mean_size():
    if _TOTAL <= 0.0:
        return 40.0
    return float(np.dot(np.arange(101), _SIZES) / _TOTAL)


def _slot_value(r):
    """How likely is residual r to be filled well by a future item?

    We compute, from the empirical size distribution, the best achievable
    fill ratio of a single bin of free space r by one future item, i.e.
    max over items s <= r of s/r, with a mild preference for residuals that
    are themselves close to a commonly seen item size (so two items can
    combine cleanly).  This is a cheap, smooth proxy for future utility.
    """
    ri = int(r)
    if ri <= 0:
        return 0.0
    if _TOTAL <= 0.0:
        # cold start: no information, reward small residuals (best fit)
        return -ri
    # best single-item fill ratio among sizes <= ri
    s = np.arange(1, ri + 1)
    w = _SIZES[1:ri + 1]
    if w.sum() <= 0.0:
        return 0.0
    # probability-weighted expected fill ratio contribution
    best = float(np.max((s / ri) * w))
    # plus matching bonus: residual itself near a typical item size
    match = float(np.max(w)) / _TOTAL
    return best + 0.5 * match


def priority(item, bins):
    """Return a priority for every bin; highest (first on ties) wins."""
    _observe(item)

    residual = bins - item               # remaining capacity after placing
    # dominant term: classic best fit (prefer the tightest fit), scaled so it
    # always outranks the secondary "usefulness" signal.
    score = -residual.astype(np.float64) * 1000.0

    # secondary term only matters inside the (nearly) tied best-fit region
    if _TOTAL > 0.0:
        vals = np.array([_slot_value(r) for r in residual], dtype=np.float64)
        score = score + vals * 1.0 + (bins.astype(np.float64) == 100) * 0.0

    return score
# EVOLVE-BLOCK-END
