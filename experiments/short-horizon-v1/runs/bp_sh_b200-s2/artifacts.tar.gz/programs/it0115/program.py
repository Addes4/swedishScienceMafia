# EVOLVE-BLOCK-START
"""Hybrid: best fit plus an online "exact-complement" bonus.

Primary ordering is best fit (tightest residual after placement).  A large
bonus is added when the resulting residual equals (within a tolerance) a
size seen recently in the stream, since such a bin can be completed by a
future item of that size.
"""
import numpy as np


def _make_cache():
    cache = {}
    return cache


_cache = _make_cache()


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    residual = bins - item  # >= 0 for bins we are shown

    # Online memory of recent item sizes (small histogram + last few sizes).
    hist = _cache.get("hist")
    recent = _cache.get("recent")
    if hist is None:
        hist = np.zeros(101, dtype=np.int64)
        recent = []
        _cache["hist"] = hist
        _cache["recent"] = recent

    # Score = best fit (tightest residual) as base, plus a bonus if residual
    # matches a recently observed size.
    score = -residual.astype(np.float64)

    if recent:
        # Tolerance: allow +-1 to absorb discreteness.
        cand = np.array(recent, dtype=np.int64)
        # For each bin, does residual equal any recent size (within tol)?
        for sz in cand:
            score += np.where((residual >= sz - 1) & (residual <= sz + 1), 5.0, 0.0)

    # Record this item after scoring.
    hist[item] += 1
    recent.append(item)
    if len(recent) > 40:
        recent.pop(0)

    return score
# EVOLVE-BLOCK-END
