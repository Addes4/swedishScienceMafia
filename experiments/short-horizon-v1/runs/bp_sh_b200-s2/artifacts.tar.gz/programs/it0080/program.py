# EVOLVE-BLOCK-START
"""Best-fit with empty-bin avoidance: prefer tighter fits, but delay opening fresh bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit backbone: smaller residual after placement is better.
    score = -(bins - item)
    # Empty bins have remaining capacity exactly 100; add a penalty so partial bins are
    # preferred whenever they also fit, consolidating usage and delaying new bins.
    score -= 20.0 * (bins == 100)
    return score
# EVOLVE-BLOCK-END
