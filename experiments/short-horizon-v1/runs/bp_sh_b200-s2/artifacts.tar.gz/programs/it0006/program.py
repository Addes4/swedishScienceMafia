# EVOLVE-BLOCK-START
"""Best fit with a mild residual-target tie-break.

Pure best-fit (place the item into the fullest bin that still fits) is a very
strong online rule for small items. The only room for improvement is in the
tie-break between bins whose residual after placement is close. Here we keep
best-fit as the primary criterion and only use a secondary term among nearly
equal residuals: prefer the residual closest to the running mean item size, so
that the leftover space stays "one average item" wide and can absorb typical
arrivals exactly.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    # running mean of observed item sizes
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    residual = bins - item            # capacity left after placing the item
    # primary: tighter fit (smaller residual) is better
    # secondary (only meaningful among near-ties): residual closest to mean
    # combine with a tiny weight so it never overrides a real residual gap
    return -(residual + 1e-3 * np.abs(residual - mean))
# EVOLVE-BLOCK-END

