# EVOLVE-BLOCK-START
"""Best fit with an online histogram bonus for reusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown

    # Primary: best-fit tightness (prefer smallest residual).
    score = -residual.astype(np.float64)

    # Exact fill bonus.
    score += 8.0 * (residual == 0)

    # Bonus when residual equals 100 (bin left empty -> could've gone elsewhere) is
    # naturally penalized by best-fit; here we only reward reusable residuals.
    return score
# EVOLVE-BLOCK-END
