# EVOLVE-BLOCK-START
"""Two-regime bin choice: best fit for large items, residual-shaping for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown

    # Base: pure best fit -> prefer the smallest residual.
    score = -residual.astype(np.float64)

    mean_size = 40.0
    if item < mean_size:
        # For small items, slightly reward leaving a residual that is a "clean"
        # amount relative to the typical item size, so that partially filled bins
        # stay near item-granular boundaries instead of accumulating tiny gaps.
        scaled = residual / mean_size
        frac = scaled - np.floor(scaled)
        # distance to nearest integer multiple of mean_size; smaller is better
        dist = np.minimum(frac, 1.0 - frac)
        # small bounded bonus, never enough to override a clearly tighter fit
        score += 0.01 * (1.0 - dist)

    return score
# EVOLVE-BLOCK-END
