# EVOLVE-BLOCK-START
"""Best fit plus a light reusability tie-break keyed to recent item sizes."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_seen = 0


def priority(item, bins):
    """Rank bins by best-fit, breaking near-ties toward reusable residuals."""
    global _seen
    # decayed histogram of recent item sizes
    _counts *= 0.97
    _counts[item] += 1.0
    _seen += 1

    r = bins - item  # residual after placement

    # reuse bonus: positive when the leftover residual equals a frequent item size
    # only meaningful for positive residuals; scale is tiny relative to fit term.
    # frequency relative to total recent mass
    freq = _counts[r] if False else None
    # vectorized lookup of freq for each residual (clip invalid -> 0)
    idx = r.astype(np.int64)
    valid = (idx >= 1) & (idx <= 100)
    idx_clipped = np.where(valid, idx, 0)
    bonus = _counts[idx_clipped]
    bonus = np.where(valid, bonus, 0.0)

    # best fit is primary; bonus is a sub-unit tie-break
    return -(r.astype(np.float64)) + 0.01 * bonus
# EVOLVE-BLOCK-END
