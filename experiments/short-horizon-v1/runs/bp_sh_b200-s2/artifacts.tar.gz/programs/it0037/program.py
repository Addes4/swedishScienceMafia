# EVOLVE-BLOCK-START
"""Best fit with a strong bonus for exactly completing a bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, first on ties.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize residual (best fit). Secondary: strongly reward residual 0.
    return -residual + 1000.0 * (residual == 0)
# EVOLVE-BLOCK-END

