# EVOLVE-BLOCK-START
"""Best fit with a small penalty for leaving an unusable small residual.

Pure best fit is a strong baseline for this distribution. The main loss comes from
occasionally stranding a bin with a small residual that no future item can use. We
keep best fit as the backbone but add a mild, bounded tie-break that discourages
leaving a positive residual below a threshold we estimate from the item stream.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    residual = bins - item
    # Base: best fit -> prefer the smallest residual after placement.
    score = -residual.astype(np.float64)
    # Mild penalty for stranding a tiny positive residual (a wasted gap), which is
    # almost never reusable by a future item. This is a bounded tie-break near the
    # best-fit optimum, so it cannot dominate the tightest-fit choice.
    tiny = (residual > 0) & (residual < 8)
    score = np.where(tiny, score - 2.0, score)
    return score
# EVOLVE-BLOCK-END
