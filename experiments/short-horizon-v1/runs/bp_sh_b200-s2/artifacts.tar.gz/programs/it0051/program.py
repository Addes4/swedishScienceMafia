# EVOLVE-BLOCK-START
"""Best fit with a concave fill-level tie-breaker.

The primary ranking is best fit (smallest post-placement residual).  To break the
near-ties that pure best fit leaves open, we add a small concave bonus based on the
resulting fill fraction sqrt(fill), which rewards consolidating items into bins that
end up fuller, while keeping the tight-fit behaviour that makes best fit strong.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item                     # >= 0, smaller is tighter fit
    fill = (100 - residual) / 100.0            # resulting fill fraction in [0, 1]
    # Primary: best fit (prefer small residual).  Secondary: concave fill bonus
    # (strongly rewards higher fill, but concave so it never flips a real tie-break
    # in favour of a bin that is noticeably emptier than the best-fit one).
    return -residual + 0.5 * np.sqrt(fill)
# EVOLVE-BLOCK-END

