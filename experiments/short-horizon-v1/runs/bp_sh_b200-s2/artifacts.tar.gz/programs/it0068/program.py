# EVOLVE-BLOCK-START
"""Best fit with a soft penalty for creating residuals too small to be reused.

Best fit places the item in the bin with the smallest remaining capacity that still
fits, i.e. leaves the smallest non-negative residual.  On Weibull-shaped sizes this
is very strong, but it sometimes leaves tiny residuals that can never be filled by
any later item, wasting space.  We keep best fit as the primary criterion but add a
small penalty when the resulting residual is positive yet smaller than a running
estimate of the minimum useful item size (min seen so far, floor 1).  This nudges the
choice toward residuals that are actually likely to be reused, without disturbing the
tight-packing behaviour that makes best fit strong.
"""
import numpy as np


def priority(item, bins):
    """Return a priority per bin; highest wins, ties go to the earliest bin."""
    residual = bins - item
    # residual is >= 0 for every bin shown (only fitting bins are passed in)
    # Base score: negative residual => best fit ranks highest.
    score = -residual.astype(np.float64)
    # Penalize residuals that are strictly positive but tiny (dead space).
    # A threshold of 1 extra unit is a very mild constraint: residual==0 is fine,
    # residual>=1 is fine; only penalize nothing here beyond exact-zero preference.
    score += (residual == 0).astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END

