# EVOLVE-BLOCK-START
"""Refined best fit: prefer tightly fitting bins, small tie-break against fresh bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item
    # Primary: smallest residual (best fit).
    score = -residual.astype(np.float64)
    # Tiny tie-break: avoid using a completely empty bin (capacity 100) if an
    # equally tight non-empty option exists.
    empty_penalty = np.where(bins == 100, 1e-3, 0.0)
    return score - empty_penalty
# EVOLVE-BLOCK-END

