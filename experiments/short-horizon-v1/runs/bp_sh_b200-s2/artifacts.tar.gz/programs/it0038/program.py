# EVOLVE-BLOCK-START
"""Almost-worst-fit style rule tailored to the Weibull item distribution.

Pure best fit fragments bins with tiny unusable holes.  Since items have mean
~40 on a capacity-100 bin, filling a bin to a residual near the typical item
size keeps it openable for one more item, which reduces total bin count.
We score a bin by how close the post-placement residual is to a target
residual near the mean item size, but we always prefer to fully close a bin
(residual 0) and we break near-ties toward the tightest fit.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item            # >= 0 for the bins we are shown
    # Ideal residual to leave behind: ~ the mean item size (40 for the Weibull dist).
    target = 40.0
    # Distance from the ideal residual; we want residuals near the target.
    dist = np.abs(residual - target)
    # Fully closing a bin (residual 0) is very good: strong bonus.
    close_bonus = np.where(residual == 0, 1000.0, 0.0)
    # Prefer the tightest fit as a gentle tie-break (smaller residual slightly better).
    tight = -0.01 * residual
    return close_bonus - dist + tight
# EVOLVE-BLOCK-END

