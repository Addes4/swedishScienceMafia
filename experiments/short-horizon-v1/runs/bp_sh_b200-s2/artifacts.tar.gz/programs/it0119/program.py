# EVOLVE-BLOCK-START
"""Best fit with anti-scrap near-tie breaking.

Primary: tightest fit (smallest post-placement residual).
Near-ties (residual within a small window of the best): prefer the larger residual
so we do not manufacture tiny unusable scraps, while remaining essentially best fit.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item            # remaining capacity after placing (>=0 for shown bins)
    best = residual.min()
    # window: prefer consolidating instead of creating near-unusable scraps
    window = 1
    key = np.where(residual <= best + window, -residual, -residual - 1e6)
    return key
# EVOLVE-BLOCK-END

