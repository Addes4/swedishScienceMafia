# EVOLVE-BLOCK-START
"""Two-choice best-fit with residue-complement bonus based on an online item histogram."""
import numpy as np

# Module-level state (reset per stream by the harness importing fresh? We guard with
# an attribute so it persists within a stream and is reinitialized safely).
_STATE = {"hist": np.zeros(101, dtype=np.float64), "n": 0}


def _common_sizes():
    """Return a normalized histogram over item sizes 1..100 (smoothed)."""
    hist = _STATE["hist"]
    n = _STATE["n"]
    if n <= 0:
        return np.ones(101) / 101.0
    # Laplace smoothing
    return (hist + 1.0) / (n + 101.0)


def priority(item, bins):
    """Return a priority for every bin; highest wins, first on ties.

    Best-fit backbone, plus a bonus when the resulting residual r = remaining - item
    is itself close to a likely future item size (so the leftover is reusable).
    """
    item = int(item)
    # Update histogram with the arriving item (state persists within a stream).
    if 1 <= item <= 100:
        _STATE["hist"][item] += 1.0
        _STATE["n"] += 1

    bins = np.asarray(bins, dtype=np.int64)
    remaining = bins - item  # residual capacity after placing the item

    # Best-fit primary term: prefer smallest residual (score = -residual).
    score = -remaining.astype(np.float64)

    # Residue-complement bonus: reward residuals that equal a likely future item size,
    # i.e. wealth of the distribution at exactly that residual.
    prob = _common_sizes()  # index by size
    # Map residual (>=0) to a probability weight; cap residuals to 0..100.
    res_idx = np.clip(remaining, 0, 100)
    bonus = prob[res_idx]
    # Also reward residuals that are sums of two common items would be too noisy;
    # keep it simple and conservative.
    score = score + 3.0 * bonus

    return score
# EVOLVE-BLOCK-END
