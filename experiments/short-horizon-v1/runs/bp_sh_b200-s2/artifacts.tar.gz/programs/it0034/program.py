# EVOLVE-BLOCK-START
"""Best fit with a mild tie-break that avoids leaving unusable tiny holes."""
import numpy as np

_min_item = [100]


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item < _min_item[0]:
        _min_item[0] = item
    residual = bins - item
    # Primary: best fit (smaller residual -> higher score).
    score = -residual.astype(np.float64)
    # Secondary: within a 1-unit band (handled by tiny scale), penalize wasted holes.
    wasted = (residual < _min_item[0]) & (residual > 0)
    score -= 0.1 * wasted.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
