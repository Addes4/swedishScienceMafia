# EVOLVE-BLOCK-START
"""Best fit with tie-break toward the fullest bin (consolidate partial bins)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary criterion: best fit (smallest residual after placing the item).
    Tie-break: prefer the bin that is currently fullest (smallest remaining capacity),
    i.e. the earliest opened / most consolidated bin, but never so strongly that it
    overrides a strictly tighter fit.
    """
    residual = bins - item
    # Primary: best fit. Secondary: prefer fuller bins (smaller residual), scaled tiny.
    return -residual * 1000.0 - (bins - item)
# EVOLVE-BLOCK-END

