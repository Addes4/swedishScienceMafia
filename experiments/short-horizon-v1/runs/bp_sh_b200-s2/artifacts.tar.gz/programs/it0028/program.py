# EVOLVE-BLOCK-START
"""Best-fit plus a harmonic-style bonus for residuals matching common item sizes."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Score bins: prefer tight fits, but reward residuals that match frequent item sizes."""
    global _total
    _total += 1.0
    # decay history slightly to adapt, update histogram of observed items
    _counts *= 0.999
    i = int(item)
    if 0 <= i <= 100:
        _counts[i] += 1.0

    total = _total
    # frequency weight of a residual r (how likely some future item fits it)
    freq = _counts / total if total > 0 else _counts

    residual = bins - i  # >= 0 for bins shown

    # base: best-fit -> smaller residual is better
    base = -residual.astype(np.float64)

    # bonus: how reusable is the leftover hole? sum of frequencies of sizes <= residual
    # (a hole of residual r can host any item up to r)
    cum = np.cumsum(freq)
    reuse = cum[np.clip(residual, 0, 100)]

    # strong bonus for perfect fit (residual 0) and for leaving a usable hole
    perfect = (residual == 0).astype(np.float64)

    # weight the reuse bonus mildly so best-fit remains dominant
    return base + 15.0 * perfect + 8.0 * reuse
# EVOLVE-BLOCK-END
