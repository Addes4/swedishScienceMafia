# EVOLVE-BLOCK-START
"""Best fit with a light, learned residual-usefulness tie-break.

Primary key: tightest fit (minimize post-placement residual).
Tie-break: among (nearly) equally tight placements, prefer a residual that
matches a frequently seen item size, so the scrap is more likely to be reused.
The bonus is strictly smaller than 1 so it can only break exact residual ties.
"""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins."""
    global _total
    residual = bins - item  # >= 0 for every shown bin

    # Update a decaying histogram of seen item sizes (state persists per stream).
    _total = _total * 0.995 + 1.0
    _counts *= 0.995
    _counts[item] += 1.0
    hist = _counts / _total  # normalized, tiny values

    # Bonus in [0,1): how likely residual (or something <= residual) is a real item size.
    # Use histogram mass at the residual and just below it (a smaller item fits too).
    r = residual
    rc = np.clip(r, 0, 100).astype(np.int64)
    bonus = hist[rc]
    below = np.clip(rc - 1, 0, 100)
    bonus = np.maximum(bonus, hist[below])

    # Primary: tightest fit. Tie-break bonus < 1 so it cannot reorder distinct residuals.
    return -(residual) + 0.5 * bonus
# EVOLVE-BLOCK-END
