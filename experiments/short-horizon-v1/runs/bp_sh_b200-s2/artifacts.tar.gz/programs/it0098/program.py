# EVOLVE-BLOCK-START
"""Best fit with a mild penalty for creating tiny unusable leftovers."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, penalizing residuals that are too small to be useful.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Tiny scraps (0 < residual < 4) are hard to ever reuse; add a small penalty so that
    # among near-equal best-fit options the bin leaving a reusable residual wins.
    waste = ((residual > 0) & (residual < 4)).astype(np.float64)
    return -residual.astype(np.float64) - 0.01 * waste
# EVOLVE-BLOCK-END
