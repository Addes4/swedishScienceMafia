# EVOLVE-BLOCK-START
"""Best fit with a smooth residual-alignment tie-breaker.

Primary signal: best fit (tightest residual after placement), scaled large enough
that it dominates. Secondary signal: a small bonus when the post-placement
residual is close to a multiple of the running mean item size, which tends to
keep residuals usable by future items.
"""
import numpy as np


class _State:
    total = 0.0
    n = 0


_state = _State()


def priority(item, bins):
    # Update running mean of the item size (state persists within a stream).
    _state.total += item
    _state.n += 1
    mean = _state.total / _state.n
    if mean < 1.0:
        mean = 1.0

    residual = bins - item  # >= 0 for all shown bins

    # Primary: best fit. Large negative magnitude ensures ordering is dominated
    # by tightest residual (we return a score, item goes to highest score).
    primary = -residual.astype(np.float64)

    # Secondary: small bonus for residuals near a multiple of `mean`.
    # Distance to nearest multiple of mean, normalized to [0, 1] where 0 is a
    # perfect multiple; convert to a bonus in [0, small].
    frac = np.mod(residual.astype(np.float64), mean) / mean
    dist = np.minimum(frac, 1.0 - frac)  # 0 at multiples, 0.5 at worst
    bonus = 1e-6 * (1.0 - 2.0 * dist)

    return primary + bonus
# EVOLVE-BLOCK-END
