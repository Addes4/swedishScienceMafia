# EVOLVE-BLOCK-START
"""Best-fit with an adaptive guard against leaving too-small slivers for large items."""
import numpy as np

_sizes = []
_count = 0


def priority(item, bins):
    """Rank bins: best-fit normally, but protect reusable holes for large items."""
    global _count
    _count += 1
    if _count <= 64:
        _sizes.append(item)

    # Adaptive split between "small" and "large" items.
    if len(_sizes) >= 16:
        thr = int(np.median(_sizes) * 1.5)
    else:
        thr = 40

    resid = bins - item  # remaining capacity after placing the item

    if item <= thr:
        # Small item: pure best fit (smallest positive/zero residual).
        return -resid

    # Large item: prefer the smallest residual that is still >= a small-item
    # size (so the leftover hole stays reusable); otherwise best-fit.
    usable = resid >= max(1, thr // 3)
    score = np.where(usable, -resid, -resid - 1000.0)
    return score
# EVOLVE-BLOCK-END
