# EVOLVE-BLOCK-START
"""Best fit with exact-fit bonus and dead-space penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item
    # Base: best fit -> tightest residual gets highest score.
    score = -residual.astype(np.float64)
    # Strongly reward exact fits (residual == 0).
    score = np.where(residual == 0, score + 1000.0, score)
    # Slightly penalize placing into a used bin that leaves a tiny, likely-dead residual.
    # A residual in [1, item-1] is only useful if some item <= residual will arrive again.
    # Heuristic: penalize very small positive residuals less than a small threshold.
    small = (residual > 0) & (residual < 5)
    score = np.where(small, score - 0.5 * (5 - residual), score)
    return score
# EVOLVE-BLOCK-END
