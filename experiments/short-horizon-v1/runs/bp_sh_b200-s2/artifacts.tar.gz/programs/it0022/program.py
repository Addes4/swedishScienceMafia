# EVOLVE-BLOCK-START
"""Best fit, but avoid leaving an unusable hole: if some bin's residual after
placement would be smaller than the current item (a hole too small to hold even
another item of this size), prefer the fullest such bin; otherwise best fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Bins whose leftover hole after placing the item is smaller than the item.
    unusable = residual < item
    if unusable.any():
        score = np.where(unusable, -residual, -np.inf)
    else:
        score = -residual
    return score
# EVOLVE-BLOCK-END
