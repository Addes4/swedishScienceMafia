# EVOLVE-BLOCK-START
"""Best fit, with a tie-break that avoids stranding unusable scraps.

Primary key is best fit (tightest remaining capacity). Among placements whose
residual is essentially tied (within 1 unit of the tightest), prefer residuals
that are still large enough to accept a typical future item, so we do not create
tiny unusable fragments. The tie-break is scale-free and strictly smaller than 1
so it can never reorder genuinely different fits.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item

    # Running estimate of a "typical" item size; used only as a soft tie-break.
    state = priority.state
    state["n"] += 1
    state["sum"] += item
    mean_item = state["sum"] / state["n"] if state["n"] else 40.0

    # Smallest residual worth keeping (a floor on scraps): a fraction of the mean.
    floor = 0.5 * mean_item

    # Best-fit primary; near-tie bonus (<1) for residuals above the scrap floor.
    good = (residual >= floor).astype(np.float64)
    return -(residual) + 0.25 * good


priority.state = {"n": 0, "sum": 0.0}
# EVOLVE-BLOCK-END

