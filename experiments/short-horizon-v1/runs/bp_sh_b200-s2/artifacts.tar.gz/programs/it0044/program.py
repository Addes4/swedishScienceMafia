# EVOLVE-BLOCK-START
"""Best fit with a toppability bonus.

The core is best-fit: we mainly prefer the bin that leaves the smallest
post-placement residual.  Pure best fit occasionally creates a tiny hole
(1..few units) that no future Weibull-sized item can fill, wasting space.
To counter that we reward decisions whose residual is small *or* large
enough to still accept roughly the smallest items we tend to see, and we
mildly prefer already-open/fuller bins to consolidate.
"""
import numpy as np

_MIN_ITEM = 1


def priority(item, bins):
    # Track the smallest item observed so far in this stream (module state).
    global _MIN_ITEM
    if item < _MIN_ITEM:
        _MIN_ITEM = item

    residual = bins - item  # >= 0 for all bins we are shown

    # Primary: best fit (smaller residual -> higher score).
    score = -residual.astype(np.float64)

    # Bonus if the leftover gap is at least the smallest item seen so far,
    # i.e. the bin can still be topped off by some item.
    toppable = residual >= _MIN_ITEM
    score += 0.5 * toppable

    # Mild preference for fuller bins (smaller remaining capacity) to
    # consolidate items and avoid scattering into many open bins.
    score -= 1e-3 * bins.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

