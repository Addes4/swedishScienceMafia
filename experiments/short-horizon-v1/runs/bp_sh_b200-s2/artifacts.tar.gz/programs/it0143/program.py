# EVOLVE-BLOCK-START
"""Best-fit with residual-quantization tie-break tuned to the item distribution."""
import numpy as np

_mu = 40.0  # running estimate of mean item size


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _mu
    # update running mean
    _mu = 0.98 * _mu + 0.02 * item

    res = bins - item  # resulting residual (>=0 since bins are only those it fits in)

    # best-fit: smallest residual best
    best = -res.astype(np.float64)

    # quantization bonus: prefer residuals that are close to a multiple of mu
    # (i.e. likely to be exactly filled by a handful of typical items)
    q = np.round(res / _mu)
    quantdist = np.abs(res - q * _mu)
    # small bonus so it only breaks near-ties in best-fit
    bonus = -0.05 * quantdist

    # strong bonus for exact fill (closes a bin)
    exact = (res == 0).astype(np.float64) * 0.5

    return best + bonus + exact
# EVOLVE-BLOCK-END
