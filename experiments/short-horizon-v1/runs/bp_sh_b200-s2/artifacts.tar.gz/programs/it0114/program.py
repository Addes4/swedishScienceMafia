# EVOLVE-BLOCK-START
"""Best fit with a learned, bounded exact-pairing tie-break."""
import numpy as np

_state = {"mean": 40.0, "n": 0}


def priority(item, bins):
    """Rank bins: tightest fit first (best fit); break near-ties toward usable residuals."""
    # Online estimate of mean item size (used only for a mild tie-break).
    n = _state["n"]
    m = _state["mean"]
    _state["mean"] = (m * n + item) / (n + 1)
    _state["n"] = n + 1

    residual = bins - item            # remaining capacity after placing item
    # Primary: best fit -> smallest residual.
    # Secondary: among residuals within +1 of the best, prefer residual near the mean,
    # so the leftover bin is reusable by a typical future item.
    best = residual.min()
    close = residual <= best + 1
    target = _state["mean"]
    pen = np.abs(residual - target)
    # Large weight on tightness; tiny bounded bonus only inside the near-tie band.
    score = -residual - np.where(close, 1e-3 * pen, 0.0)
    return score
# EVOLVE-BLOCK-END
