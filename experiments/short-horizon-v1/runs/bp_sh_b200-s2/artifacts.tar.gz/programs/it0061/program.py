# EVOLVE-BLOCK-START
"""Hybrid: best-fit for small items, worst-fit for large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item <= 50:
        # best-fit: tightest bin (smallest remaining capacity that still fits)
        score = -(bins - item).astype(np.float64)
    else:
        # worst-fit: use the emptiest bin (largest remaining capacity)
        score = bins.astype(np.float64)
    # strong bonus for exact fit
    score = score + 1000.0 * (bins == item)
    return score
# EVOLVE-BLOCK-END
