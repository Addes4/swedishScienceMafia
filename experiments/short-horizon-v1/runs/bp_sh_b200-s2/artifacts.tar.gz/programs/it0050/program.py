# EVOLVE-BLOCK-START
"""Best fit with a slight preference for consolidating into already-open bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for every bin shown
    # Primary: prefer the tightest fit (smallest residual).
    # Small tie-breaker: prefer already-used bins (remaining < 100) to consolidate,
    # and among equals prefer the one that leaves the least slack fraction.
    used_bonus = (bins < 100).astype(np.float64) * 1e-3
    return -residual + used_bonus - residual / bins
# EVOLVE-BLOCK-END

