# EVOLVE-BLOCK-START
"""Best fit with a small deterministic tie-break dither to vary tie resolution."""
import numpy as np

_MOD = 1000003


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.int64)
    # Primary: tightest fit (smaller residual => higher score).
    # Secondary: deterministic dither based on item and bin index, tiny magnitude
    # so it only breaks exact residual ties.
    dither = ((idx * 2654435761 + item * 40503) % _MOD).astype(np.float64)
    return -(bins - item).astype(np.float64) + dither * 1e-9
# EVOLVE-BLOCK-END
