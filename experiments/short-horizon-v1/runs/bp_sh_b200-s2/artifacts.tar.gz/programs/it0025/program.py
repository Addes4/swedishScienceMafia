# EVOLVE-BLOCK-START
"""Best-fit, but with a penalty against opening a brand-new (empty) bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Pure best-fit: smallest post-placement residual gets the highest score.
    score = -residual.astype(np.float64)
    # Penalize opening a fresh bin (remaining capacity exactly 100) so the item
    # prefers to squeeze into an existing partially-filled bin instead.
    empty = (bins >= 100)
    if empty.any() and (~empty).any():
        score[empty] -= 50.0
    return score
# EVOLVE-BLOCK-END
