# EVOLVE-BLOCK-START
"""Best fit, but strongly prefer to use already-open (partially filled) bins
over entirely unused bins, so we don't open new bins prematurely."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)
    # Best fit: smaller residual after placement is better.
    residual = bins - item
    # Bonus for bins that are already used (remaining < 100): prefer to consolidate.
    used_bonus = np.where(bins < 100, 1.0, 0.0) * 1000.0
    return used_bonus - residual
# EVOLVE-BLOCK-END

