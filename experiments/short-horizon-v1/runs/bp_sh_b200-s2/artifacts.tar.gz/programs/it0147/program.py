# EVOLVE-BLOCK-START
"""Sum-of-squares bin packing heuristic.

Score each fitting bin by the increase in the sum of squared used-capacity it
produces when the item is placed there.  Filling a bin more tightly gives a
larger marginal gain, which strongly favors consolidating items and closing
bins, an approach known to be competitive with best-fit for skewed
(Weibull-shaped) item distributions.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Used capacity before and after placing the item.
    used_before = 100.0 - bins
    used_after = used_before + item
    # Marginal gain in sum of squares of used capacity.
    gain = used_after * used_after - used_before * used_before
    return gain
# EVOLVE-BLOCK-END
