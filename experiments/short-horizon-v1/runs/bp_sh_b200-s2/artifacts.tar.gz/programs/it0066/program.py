# EVOLVE-BLOCK-START
"""Best-fit with exact-fill bonus and residual-usability nudge."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since item fits

    # Primary: tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Exact fill bonus.
    score += (residual == 0) * 1.0

    # Mild nudge: prefer residuals that are at least the minimum useful size.
    score += 0.05 * residual.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
