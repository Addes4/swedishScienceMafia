# EVOLVE-BLOCK-START
"""Best fit with a lightly-weighted complement-residue bonus.

Primary key remains best fit (tightest residual after placement).  We add a
small secondary tie-break that prefers a resulting residual which matches a
*typical* future item size, using a fixed analytic prior for the (Weibull,
mean ~40) item distribution.  The bonus is small enough not to disturb the
best-fit ordering by more than a rounding tick, avoiding the regressions seen
when online-histogram heuristics were given real weight.
"""
import numpy as np


def priority(item, bins):
    # residual after placing the item
    r = bins - item

    # best-fit primary: prefer smallest residual
    # (negative residual magnitude -> higher score for tighter fit)
    base = -(r.astype(np.float64))

    # small complement bonus: residuals matching common item sizes are slightly
    # preferred because a future item may exactly fill them.
    # Common sizes cluster near the distribution mean (~40) and small values.
    bonus = np.zeros(r.shape, dtype=np.float64)
    # exact fill is best
    bonus += np.where(r == 0, 0.5, 0.0)
    # residual near a typical item size (~ sizes 30-50) slightly favored
    bonus += np.where((r >= 30) & (r <= 50), 0.05, 0.0)
    # residual near twice a small typical item
    bonus += np.where((r >= 60) & (r <= 70), 0.03, 0.0)

    return base + bonus
# EVOLVE-BLOCK-END
