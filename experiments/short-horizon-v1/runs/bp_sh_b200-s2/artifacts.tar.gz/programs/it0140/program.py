# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break.

Pure best fit (tightest residual) is a strong baseline. We keep that ordering as the
primary key, but when several bins yield residuals that are within a small window of
the tightest one, we prefer the bin whose *resulting* residual is close to a typical
item size, since such a gap is likely to be reusable by a future item (reducing the
number of bins needed). The window is small enough that it never overrides a clear
best-fit advantage, but breaks the frequent near-ties toward cleaner packings.
"""
import numpy as np

# Typical item-size scale for the distribution (mean about 40).
_TYPICAL = 40.0
# Window (in capacity units) within which residuals are considered "near-tied"
# with the tightest residual; only inside this window do we apply the tie-break.
_WINDOW = 6.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # size-0 residual after placing the item
    best = residual.min()

    # Primary score: prefer tightest fit (higher = better).
    score = -residual.astype(np.float64)

    # Secondary tie-break within a small window of the best residual:
    # prefer residuals close to a multiple of the typical item size (a reusable gap).
    if _WINDOW > 0:
        near = residual <= (best + _WINDOW)
        mod = np.abs(residual % _TYPICAL)
        # distance to nearest multiple of _TYPICAL (0 best), normalized
        dist = np.minimum(mod, _TYPICAL - mod) / _TYPICAL
        # small bonus, only applied inside the near-tie window
        score = score - np.where(near, dist * 0.01, 0.0)

    return score
# EVOLVE-BLOCK-END
