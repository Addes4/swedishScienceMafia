# EVOLVE-BLOCK-START
"""Best fit with a granularity-aware tie-break.

Core rule: best fit (minimize residual after placement).  Break near-ties using a
running estimate of item granularity (the smallest reasonable fill unit), so that
bins whose leftover capacity is an exact multiple of that unit are mildly preferred.
This never overrides a clearly tighter fit, so performance stays at best-fit level
while occasionally improving packing density.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    residual = bins - item  # >= 0 for all bins shown (item fits)
    # Running estimate of granularity: min seen item size, clamped to a sane range.
    g = getattr(priority, "g", None)
    if g is None:
        g = 4
    if item < g:
        g = item
    priority.g = g
    # Preference: tighter fit dominates; small tie-break rewards residuals that are
    # near-multiples of the granularity unit (reduces stranded slivers).
    r = residual.astype(np.float64)
    frac = np.abs((r / g) - np.round(r / g))
    score = -r - 0.01 * frac + 0.0 * r  # frac bonus is tiny, never overrides fit
    return score
# EVOLVE-BLOCK-END

