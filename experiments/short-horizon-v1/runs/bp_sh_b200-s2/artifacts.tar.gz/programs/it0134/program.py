# EVOLVE-BLOCK-START
"""Best fit, but nudge near-ties toward residuals that leave usable space.

Small items create scrap: placing a small item into the tightest bin can leave a
residual too small for anything but tiny items.  For those we slightly prefer
bins whose residual after placement is close to a value that later items can
actually fill nicely (roughly half the mean item size).  For larger items we
keep pure best fit, which is what makes this class of rule strong.
"""
import numpy as np

# Weibull-shaped distribution, mean ~40.  Items can fill a bin well when the
# residual is near a multiple-ish of the typical size; a residual around the
# mean is the safest "usable" target.
_MEAN = 40.0
_TARGET = 40.0


def priority(item, bins):
    resid = bins - item  # residual after placing item in each bin (>=0)
    # Best-fit primary key: tighter residual is better.
    tight = -resid.astype(np.float64)
    # Only reorder when the item is small enough that scrap is a real risk.
    if item <= 30:
        # Reward residuals near the target (usable space for one more typical
        # item) without overcoming genuine best-fit gaps much.
        scale = 1.0 / (2.0 * _TARGET * _TARGET)
        bonus = -((resid.astype(np.float64) - _TARGET) ** 2) * scale
        return tight + 0.25 * bonus
    return tight
# EVOLVE-BLOCK-END
