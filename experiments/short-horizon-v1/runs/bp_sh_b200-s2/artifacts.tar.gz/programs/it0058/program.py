# EVOLVE-BLOCK-START
"""Best fit with a mild anti-fragmentation bonus.

Pure best-fit leaves many tiny unusable residuals. We keep best-fit dominant
(closest fit wins) but add a small bonus for two useful outcomes:
  * an exact fit (residual 0), which never wastes capacity;
  * a residual large enough to still hold a typical upcoming item, so the bin
    stays reusable rather than becoming an unusable gap.
This nudges ties and near-ties toward less fragmented packings without the
aggressive balancing that hurt earlier attempts.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest wins, ties go to first bin."""
    residual = bins - item  # >= 0 for all shown bins

    # Track a running estimate of a "useful" residual: the recent typical item
    # size (mean of items seen so far), used to reward reusable leftovers.
    state = priority.state
    if state is None:
        state = {"n": 0, "sum": 0.0}
    state["n"] += 1
    state["sum"] += item
    typical = state["sum"] / state["n"]
    priority.state = state

    # Primary: smaller residual is better (best fit).
    score = -residual.astype(np.float64)

    # Mild bonuses: exact fits, and residuals big enough to stay useful.
    exact = (residual == 0)
    reusable = (residual >= typical) & ~exact
    score += 0.5 * exact.astype(np.float64)
    score += 0.25 * reusable.astype(np.float64)

    return score


priority.state = None
# EVOLVE-BLOCK-END
