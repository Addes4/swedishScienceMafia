# EVOLVE-BLOCK-START
"""Best fit with a tiny bonus for avoiding creation of tiny unusable leftovers.

Primary criterion is still best fit (place the item into the bin where it fits
most tightly, leaving the smallest residual). Ties are broken in favour of a
placement whose resulting residual is not a "scrap" that is too small to be
useful for future items. This is a conservative tweak that never disturbs a
strict best-fit ordering difference.
"""
import numpy as np

_SMALL = 12  # residuals below this are effectively unusable scraps


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    residual = bins - item
    # Best fit: smaller residual is better -> larger score.
    score = -residual.astype(np.float64)
    # Tiny, strictly-bounded bonus for avoiding tiny unusable scraps.
    # Bonus magnitude < 1 so it only ever breaks ties among equal residuals.
    penalty = (residual < _SMALL).astype(np.float64)
    return score - 0.5 * penalty
# EVOLVE-BLOCK-END
