# EVOLVE-BLOCK-START
"""Best-fit variant that prefers leaving a residual close to the current item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best-fit (smallest residual) so tight packing dominates.
    # Secondary tie-break: prefer a residual near the item size (a matched hole).
    # Encode as a single float: small residual is best, and among equal residuals
    # prefer the one closest to `item`.
    score = -(residual.astype(np.float64)) - 0.001 * np.abs(residual - item)
    return score
# EVOLVE-BLOCK-END
