# EVOLVE-BLOCK-START
"""Adaptive best-fit: avoid leaving residuals too small to reuse."""
import numpy as np


class _State:
    def __init__(self):
        self.minsize = 101  # smallest item seen so far
        self.count = 0
        self.sum = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update running statistics on observed items.
    if item < _state.minsize:
        _state.minsize = item
    _state.count += 1
    _state.sum += item

    if _state.count > 5:
        mean = _state.sum / _state.count
        # A robust small-item threshold: leftover this large or bigger is more
        # likely to be reusable soon. Use a fraction of the mean, bounded below
        # by the smallest item actually observed.
        threshold = max(_state.minsize, int(0.35 * mean))
    else:
        threshold = _state.minsize

    residual = bins - item  # >= 0 for all bins shown

    # Exact fit gets top priority.
    exact = (residual == 0).astype(np.float64)

    # Bins whose leftover stays usable get a strong (but bounded) preference,
    # within them prefer tighter fits via -residual.
    usable = (residual >= threshold).astype(np.float64)

    # Primary: exact fit. Secondary: usable leftover. Tertiary: best fit.
    return exact * 1e6 + usable * 1e3 - residual
# EVOLVE-BLOCK-END

