# EVOLVE-BLOCK-START
"""Adaptive matching best fit: prefer tight fits, and reserve residuals that match
likely future item sizes measured online from the stream itself."""
import numpy as np


class _State:
    def __init__(self):
        # histogram of recent item sizes (1..100), with mild exponential decay
        self.hist = np.zeros(101, dtype=np.float64)
        self.total = 0.0


_state = _State()


def priority(item, bins):
    """Highest score wins; ties go to earliest bin.

    Primary key: best fit (smallest residual after placing).  Secondary: a small
    bonus for bins whose resulting residual is a commonly seen item size, so we
    tend to keep (and later fill) well-fitting remainders.
    """
    st = _state

    # update running distribution estimate (decayed counts)
    st.hist *= 0.99
    st.hist[item] += 1.0
    st.total = st.total * 0.99 + 1.0

    residual = bins - item  # >= 0 since these bins fit the item

    # frequency-based bonus, in [0,1], for the residual being a likely future size
    freq = st.hist / (st.total + 1e-12)
    # normalize so typical max ~ 1
    fmax = freq.max()
    if fmax > 0:
        freq_norm = freq / fmax
    else:
        freq_norm = freq

    bonus = freq_norm[residual]

    # primary term dominates: larger residual => worse; bonus is a tiny tie-breaker
    return -(residual) + 0.05 * bonus
# EVOLVE-BLOCK-END
