# EVOLVE-BLOCK-START
"""Best fit with a size-aware residual preference that stays close to pure best fit."""
import numpy as np

_STATE = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _STATE
    st["n"] += 1
    st["sum"] += item
    mean = st["sum"] / st["n"]

    bins = np.asarray(bins, dtype=np.int64)
    # base: best fit (tightest residual)
    score = -(bins - item)

    # For small items, nudge toward leaving a residual that can hold another
    # small/mean-sized item, but only among bins that are already tighter than
    # a fresh bin, so we don't open new bins unnecessarily.
    if item < mean:
        residual = bins - item
        # prefer residual >= item (reusable hole) but keep magnitude small
        bonus = np.where(residual >= item, 1.0, 0.0)
        # slight preference for the tightest reusable option
        score = score + bonus * 0.01
    return score
# EVOLVE-BLOCK-END
