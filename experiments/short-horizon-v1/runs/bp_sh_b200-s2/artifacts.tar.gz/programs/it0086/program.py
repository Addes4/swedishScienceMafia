# EVOLVE-BLOCK-START
"""Best fit with an online complement-matching tie-break.

The backbone is classic best fit: put the item in the bin leaving the smallest
non-negative residual.  Ties (and near ties) are broken by a small bonus that
prefers leaving a residual which is close to a commonly seen item size, i.e. a
residual that a future item is likely to fill exactly.  Item sizes are estimated
online from the stream via a simple histogram / EMA, so no future information is
used and state resets per stream naturally (a fresh module import).
"""
import numpy as np

# Module-level online statistics of past item sizes.
_SIZE_HIST = np.zeros(101, dtype=np.float64)   # counts per integer size
_N_SEEN = 0
_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    global _N_SEEN, _MEAN

    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item  # residual capacity after placing the item (>=0)

    # Classic best fit: smaller residual is better.
    score = -residual.astype(np.float64)

    # Small bonus for residuals that are likely to be filled exactly by a future
    # item.  We approximate the probability that a residual r is exactly matched
    # by some size appearing in the stream using the online histogram.
    if _N_SEEN > 0:
        # Normalized frequency of each size in [1, 100].
        freq = _SIZE_HIST[:101]
        total = freq.sum()
        if total > 0:
            freq = freq / total
            # Probability mass that is <= residual, weighted toward exact match:
            # use the frequency of the residual value itself plus a small
            # preference for residuals that are multiples of the mean.
            r_clipped = np.clip(residual, 0, 100)
            exact = freq[r_clipped]  # frequency of leaving exactly r
            # Bonus is strictly smaller than 1 so it only breaks near-ties
            # (residual differences are integers >= 1).
            score += 0.5 * exact

    # Update online statistics for this item.
    _SIZE_HIST[item] += 1.0
    _N_SEEN += 1
    _MEAN += (item - _MEAN) / _N_SEEN

    return score
# EVOLVE-BLOCK-END
