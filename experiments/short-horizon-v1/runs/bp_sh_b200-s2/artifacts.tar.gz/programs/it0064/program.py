# EVOLVE-BLOCK-START
"""Learned best-fit: prefer tightest fit, with a small bonus for residuals
that the empirical item-size distribution is likely to fill next."""
import numpy as np

# Empirical item-size histogram (sizes 1..100), updated online.
_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    global _total
    # Update the empirical size distribution.
    _counts[item] += 1.0
    _total += 1.0

    # Smoothed probability that the next item has size exactly r (for residual r).
    probs = (_counts + 1.0) / (_total + 100.0)  # Laplace smoothing, index 0 unused

    # Best-fit baseline: tightest fit (smallest residual) gets highest score.
    score = -(bins - item).astype(np.float64)

    # Bonus for residuals that are commonly fittable by future items:
    # estimate P(next item <= residual) as a usable-bin score.
    cdf = np.cumsum(probs)  # cdf[r] = P(size <= r)
    residuals = bins - item
    # Clip residual into valid index range; residual 0 already best-fit-optimal.
    ridx = np.clip(residuals, 0, 100).astype(np.int64)
    usable = cdf[ridx]  # higher when larger residual, saturating at 1
    # Reward a residual that is large enough to hold a typical item, but keep
    # this weak so best-fit stays dominant.
    score = score + 0.05 * usable

    return score
# EVOLVE-BLOCK-END
