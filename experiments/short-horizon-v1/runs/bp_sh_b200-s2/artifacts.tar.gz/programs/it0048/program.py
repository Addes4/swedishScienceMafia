# EVOLVE-BLOCK-START
"""Best-fit with near-tie consolidation toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest wins, first on ties.

    Primary: best fit (smallest post-placement residual).
    Near-tie breaker: among residuals within a tiny tolerance, prefer the bin
    that is already fuller (smaller remaining capacity), consolidating holes.
    """
    residual = bins - item  # >= 0 guaranteed by harness
    # Best fit primary; tiny secondary term favors fuller (smaller bins) bins,
    # but only within units where residuals tie exactly.
    return -residual - 1e-6 * bins
# EVOLVE-BLOCK-END
