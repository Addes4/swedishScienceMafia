# EVOLVE-BLOCK-START
"""Best fit with a learned 'reusable residual' bonus.

Primary key: best fit (smallest residual after placing).
Secondary: reward residuals close to a size we expect to see again soon,
estimated online from a coarse histogram of past items.
"""
import numpy as np


class _State:
    def __init__(self):
        # coarse histogram of item sizes (bins of 5), plus EMA of mean
        self.hist = np.zeros(21, dtype=np.float64)  # sizes 0..100 -> bin = size//5
        self.count = 0.0

    def update(self, item):
        b = item // 5
        if b > 20:
            b = 20
        self.hist[b] += 1.0
        self.count += 1.0

    def size_bonus_matrix(self):
        # probability-ish mass per 5-wide size bucket, smoothed
        if self.count < 5.0:
            return None
        p = self.hist / self.count
        return p


_state = _State()


def priority(item, bins):
    # learn from current item (no future info)
    _state.update(item)

    resid = bins - item  # >= 0 since bins only contains fitting ones
    # best fit: smaller residual -> higher score
    score = -resid.astype(np.float64)

    p = _state.size_bonus_matrix()
    if p is not None:
        # bonus when residual is close to a commonly seen item size
        # map residual to nearest bucket center
        b = resid // 5
        b = np.clip(b, 0, 20)
        # probability of that bucket times a modest weight
        bonus = p[b] * 12.0
        # also reward residuals that are exactly a bucket center-ish? keep simple
        score = score + bonus

    return score
# EVOLVE-BLOCK-END

