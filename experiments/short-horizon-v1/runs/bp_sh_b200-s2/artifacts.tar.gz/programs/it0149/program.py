# EVOLVE-BLOCK-START
"""Best fit with a deterministic early-bin tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    n = residual.shape[0]
    idx = np.arange(n, dtype=np.float64)
    return -residual.astype(np.float64) - idx * 1e-6
# EVOLVE-BLOCK-END
