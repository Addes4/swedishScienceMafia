# EVOLVE-BLOCK-START
"""Best fit with a tiny complementary-residual bonus from an online size histogram."""
import numpy as np

# State kept across calls within a stream.
_state = {"started": False, "hist": None, "n": 0}

# The item distribution has mean ~40; sizes are integers 1..100.
# We keep a smoothed count of past item sizes to reward residuals that
# match a likely future item size.
_ALPHA = 0.01  # smoothing / decay so the estimate tracks the distribution
_BONUS = 0.02  # tiny relative to residual (1 unit), so best-fit dominates


def priority(item, bins):
    st = _state
    if not st["started"] or st["hist"] is None:
        st["hist"] = np.zeros(101, dtype=np.float64)
        st["started"] = True

    hist = st["hist"]

    # Normalize into a probability-like weight over residuals.
    total = hist.sum()
    if total > 0.0:
        probs = hist / total
        maxp = probs.max()
        # relative probability scaled to [0, 1]
        rel = probs / maxp if maxp > 0 else probs
        rel = rel * rel  # sharpen: emphasize common sizes
    else:
        rel = np.zeros(101, dtype=np.float64)

    # residual after placing item in each bin
    residual = bins - item  # bins contains only fitting bins, so all >= 0

    idx = np.clip(residual.astype(np.int64), 0, 100)
    bonus = _BONUS * rel[idx]

    # Best fit: prefer smaller residual. Bonus slightly increases score
    # when that residual equals a common item size (reusable leftover).
    score = -residual.astype(np.float64) + bonus

    # Update histogram with decay (EMA over observed sizes), after scoring.
    hist *= (1.0 - _ALPHA)
    hist[item] += _ALPHA
    st["n"] += 1

    return score
# EVOLVE-BLOCK-END
