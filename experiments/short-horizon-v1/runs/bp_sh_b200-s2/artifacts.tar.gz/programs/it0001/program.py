# EVOLVE-BLOCK-START
"""Best fit with a slight preference against opening fresh (unused) bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Tightest fit: smallest remaining capacity after placement.
    tightness = -(bins - item)
    # Penalize untouched bins so a partially-filled bin is preferred when close.
    penalty = np.where(bins == 100, -0.5, 0.0)
    return tightness + penalty
# EVOLVE-BLOCK-END

