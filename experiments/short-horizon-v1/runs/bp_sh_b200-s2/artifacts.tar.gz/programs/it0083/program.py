# EVOLVE-BLOCK-START
"""Two-choice best-fit: favor exact fills; otherwise avoid stranding unusably small gaps."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Rank bins: highest score wins (first on ties)."""
    s = _state
    s["sum"] += item
    s["n"] += 1
    mean = s["sum"] / s["n"]

    # minimum "typical" item size we care about keeping usable
    # roughly a small fraction of the running mean
    thresh = max(1.0, 0.35 * mean)

    residual = bins - item  # remaining capacity after placement, >= 0
    # primary: prefer tighter fit (smaller residual)
    score = -residual.astype(np.float64)

    # penalize residuals that are positive but too small to be useful
    small = (residual > 0) & (residual < thresh)
    score[small] -= 1000.0

    # strongly reward exact fills
    exact = residual == 0
    score[exact] += 5000.0

    return score
# EVOLVE-BLOCK-END
