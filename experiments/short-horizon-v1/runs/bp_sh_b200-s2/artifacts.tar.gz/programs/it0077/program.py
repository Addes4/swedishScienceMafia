# EVOLVE-BLOCK-START
"""Best-fit augmented with an online size histogram that rewards leaving residuals
that match frequently-seen item sizes (good complements -> exact fills)."""
import numpy as np


def _build_hist():
    return np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    state = priority._state
    hist = state
    total = hist.sum()

    residual = bins - item
    # Primary: best fit (smaller residual -> higher score).
    score = -residual.astype(np.float64)

    if total > 0:
        # Posterior probability that the next item equals each residual value,
        # with a small uniform smoothing so uncommon values still get some weight.
        probs = (hist[residual] + 0.5) / (total + 101 * 0.5)
        # Small bonus for leaving a residual that a future item can fill exactly.
        score += 2.0 * probs

    # Update the histogram with the current item (after scoring, so it doesn't
    # bias this decision with its own size).
    hist[item] += 1.0
    return score


priority._state = _build_hist()
# EVOLVE-BLOCK-END
