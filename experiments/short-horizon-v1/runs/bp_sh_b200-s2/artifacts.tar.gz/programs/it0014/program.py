# EVOLVE-BLOCK-START
"""Harmonic-style interval best-fit packing with a running size estimate."""
import numpy as np


def priority(item, bins):
    # Weibull-shaped sizes with mean ~40: classify item into a size class
    # whose target capacity is a power-of-two fraction of 100, then
    # best-fit within that class's residual window.
    if item <= 25:
        lo, hi = 1, 25          # small items pack tightly together
    elif item <= 50:
        lo, hi = 26, 50         # medium
    elif item <= 75:
        lo, hi = 51, 75         # large-medium
    else:
        lo, hi = 76, 100        # large

    b = bins.astype(np.float64)
    # prefer bins whose residual is in the same "band" as the item,
    # i.e. that can still hold another item of this size; within that,
    # best fit (smallest residual after placement).
    residual = b - item
    in_band = (b >= item) & (b <= hi + item - 1) & (b >= lo)
    # bonus for staying in the correct band, then best fit
    score = -residual + in_band * 1000.0
    return score
# EVOLVE-BLOCK-END
