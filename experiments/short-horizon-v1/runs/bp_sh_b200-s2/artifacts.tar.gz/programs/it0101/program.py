# EVOLVE-BLOCK-START
"""Best fit with a distribution-informed tie-break.

Primary criterion: smallest residual after placement (best fit), which is a strong
online heuristic for this distribution. Secondary (tiny) term: among bins with
nearly equal residuals, prefer residuals that are likely to be exactly fillable by
a future item — rewarding 0 heavily and residuals near the item-distribution mean
(~40) mildly. The secondary weight is kept small so best-fit ordering dominates.
"""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    r = bins - item  # residual after placing the item
    # dominant: best fit (prefer smallest residual)
    score = -r.astype(np.float64)
    # tiny bonus for residuals that are more "fillable" later
    # peak at 0 (perfect fill), gentle bump near the distribution mean
    fill_bonus = 3.0 * (r == 0)
    fill_bonus += np.exp(-((r - _MEAN) ** 2) / (2.0 * 20.0 ** 2))
    score += 1e-3 * fill_bonus
    return score
# EVOLVE-BLOCK-END
