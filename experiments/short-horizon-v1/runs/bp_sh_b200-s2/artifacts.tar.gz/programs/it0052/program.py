# EVOLVE-BLOCK-START
"""Best fit with a light deterministic perturbation toward opening fresh bins."""
import numpy as np

_state = {"min_item": 101, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["count"] += 1
    if item < _state["min_item"]:
        _state["min_item"] = item

    m = _state["min_item"]

    # Best fit: prefer the smallest residual after placement.
    scores = -(bins - item).astype(np.float64)

    # Deterministic pseudo-random perturbation: occasionally favor fresh bins (cap == 100),
    # providing the diversification that pure best-fit lacks.
    h = (item * 2654435761 + _state["count"] * 40503) & 0xFFFFFFFF
    u = (h % 1000) / 1000.0

    if u < 0.08:
        # Mild preference for emptier bins to open a new bin sometimes.
        scores += (bins == 100) * (item * 0.5)
    else:
        # Prevent leaving a tiny unusable residual when a slightly larger residual fits future items.
        resid = bins - item
        bad = (resid > 0) & (resid < m)
        scores -= bad * (m - np.where(bad, resid, 0)) * 0.5

    return scores
# EVOLVE-BLOCK-END

