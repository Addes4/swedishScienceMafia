# EVOLVE-BLOCK-START
"""Best fit with a mild stateful complement bonus.

Primary ordering is best fit (smallest resulting residual).  As a tiny
secondary term we reward residuals that match item sizes seen often so far,
using a smoothed online count of item sizes.  The bonus is kept small so it
only breaks near-ties and cannot overturn a clearly better best-fit choice.
"""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    global _total
    _counts[item] += 1.0
    _total += 1.0

    # smoothed probability of each size (Laplace-ish smoothing)
    p = (_counts + 1.0) / (_total + 101.0)

    residual = bins - item
    # tiny bonus for residuals matching a common future item size
    bonus = p[np.clip(residual, 0, 100)] * 0.5
    return -(residual) + bonus
# EVOLVE-BLOCK-END

