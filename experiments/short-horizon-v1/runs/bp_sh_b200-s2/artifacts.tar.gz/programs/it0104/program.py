# EVOLVE-BLOCK-START
"""Best fit with scrap-avoidance using smallest observed item size."""
import numpy as np

_MIN_ITEM = 5.0  # smallest item size seen so far (init conservative)


def priority(item, bins):
    """Rank bins: prefer tight fit, penalize leaving a tiny unusable leftover."""
    global _MIN_ITEM
    if item < _MIN_ITEM:
        _MIN_ITEM = float(item)
    residual = (bins - item).astype(np.float64)
    # residual below the smallest item we've seen is likely unusable scrap
    scrap = (residual > 0) & (residual < _MIN_ITEM)
    # minimize residual (best fit); strongly demote scrap-creating placements
    return -residual - 1000.0 * scrap
# EVOLVE-BLOCK-END

