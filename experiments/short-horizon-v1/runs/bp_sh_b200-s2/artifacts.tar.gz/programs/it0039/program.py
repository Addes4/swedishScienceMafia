# EVOLVE-BLOCK-START
"""Adaptive best fit that penalizes creating unusable tiny residuals."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    if item < _state["min_item"]:
        _state["min_item"] = item
    m = _state["min_item"]
    residual = bins - item
    # negative score = we want smaller residual (best fit)
    score = -residual.astype(np.float64)
    # penalize small positive residuals that are wasted holes
    wasted = (residual > 0) & (residual < m)
    score -= wasted.astype(np.float64) * (m - residual)
    return score
# EVOLVE-BLOCK-END
