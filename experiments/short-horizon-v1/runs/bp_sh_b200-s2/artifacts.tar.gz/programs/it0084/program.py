# EVOLVE-BLOCK-START
"""Best fit with a complement-matching bonus from an online item-size histogram."""
import numpy as np

# Online histogram of item sizes (EMA over a fixed grid), persists across a stream.
_SIZE_GRID = 101
_hist = np.zeros(_SIZE_GRID, dtype=np.float64)
_seen = 0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _hist, _seen

    item = int(item)
    bins = np.asarray(bins, dtype=np.int64)

    score = -np.abs(bins - item).astype(np.float64)

    # Complement bonus: if placing this item leaves a residual r, and r is a common
    # recent item size, that bin's residual is easy to fill later.
    residual = bins - item
    # map residual to grid via safe integer indexing
    idx = np.clip(residual, 0, _SIZE_GRID - 1)
    if _seen > 0:
        bonus = _hist[idx]
    else:
        bonus = np.zeros_like(score)
    # small weight so best-fit backbone dominates
    score = score + 0.05 * bonus

    # update the online histogram with this item
    if 1 <= item < _SIZE_GRID:
        if _seen == 0:
            _hist[item] = 1.0
        else:
            _hist *= 0.995
            _hist[item] += 0.005
    _seen += 1

    return score
# EVOLVE-BLOCK-END
