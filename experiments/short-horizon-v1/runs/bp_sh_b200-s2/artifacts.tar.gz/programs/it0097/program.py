# EVOLVE-BLOCK-START
"""Best-fit with a worst-fit fallback for very tight residuals.

Pure best fit is near optimal, but it can close off bins with tiny residuals
that can never be reused.  The usual remedy without lookahead is to prefer,
among bins whose resulting residual would still be "usable" (>= a typical item
size), the one leaving the largest residual, and otherwise fall back to best
fit.  This keeps good packing while avoiding tiny dead leftovers.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # A residual below ~one mean item (about 40) is essentially hard to reuse.
    usable = residual >= 40
    # Among usable placements, prefer the *largest* residual (worst fit) so that
    # the remaining space stays large and re-usable; otherwise best fit.
    # Encode: usable bins get score based on residual (worst fit), others by
    # best fit but strictly lower priority.
    score = np.where(usable, residual.astype(float), residual.astype(float) - 1000.0)
    return score
# EVOLVE-BLOCK-END

