# EVOLVE-BLOCK-START
"""Best fit with an online residual-reusability bonus."""
import numpy as np


class _State:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0


_state = _State()


def priority(item, bins):
    """Score bins by best-fit plus a small bonus for reusable residuals."""
    st = _state
    # Update empirical distribution with the current item (arrived, will be placed).
    st.counts[item] += 1.0
    st.total += 1.0

    rem = bins.astype(np.float64)
    residual = rem - item  # resulting remaining capacity, >= 0 since item fits

    # Best-fit component: tighter fit (smaller residual) is better.
    base = -residual

    # Residual reusability: probability mass of items that would fit snugly into
    # the resulting residual. Only compute over small residuals to keep it cheap.
    if st.total > 0:
        cdf = np.cumsum(st.counts) / st.total  # cdf[r] = P(item <= r)
        # For each candidate residual r, reward = P(an item fits in r) restricted to
        # residuals in [1, 100]; residuals of 0 are already rewarded by best-fit.
        r_idx = np.clip(residual.astype(np.int64), 0, 100)
        fit_prob = cdf[r_idx]
        # Penalize very large residuals slightly (they waste space); reward snug fits.
        bonus = 0.02 * fit_prob
    else:
        bonus = 0.0

    return base + bonus
# EVOLVE-BLOCK-END
