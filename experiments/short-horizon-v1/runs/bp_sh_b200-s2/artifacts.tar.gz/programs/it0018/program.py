# EVOLVE-BLOCK-START
"""Best fit with a mild anti-sliver refinement driven by a running mean."""
import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.total = 0.0

    def mean(self):
        if self.count == 0:
            return 40.0
        return self.total / self.count


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state.count += 1
    _state.total += item
    m = _state.mean()

    residual = bins - item  # >= 0 for all shown bins
    # Prefer tightest fit, but treat residuals in (0, m) as waste-prone:
    # give a bonus when the residual is 0 or >= m so we don't leave slivers.
    good = (residual == 0) | (residual >= m)
    # Primary: good bins first; secondary: tighter fit (smaller residual) is better.
    # Encode lexicographically: score = residual, with good bins shifted down by a large amount.
    score = residual.astype(np.float64)
    score = np.where(good, score - 1000.0, score)
    return -score
# EVOLVE-BLOCK-END

