# EVOLVE-BLOCK-START
"""Sum-of-squares bin packing: balance fill levels instead of greedy tight fits.

Classic result (Csirik et al.): ranking bins by the resulting sum of squared
residual capacities, with a best-fit tiebreak, tends to use fewer bins than
pure best fit on random item streams, because it avoids leaving one nearly
full bin while others stay empty.
"""
import numpy as np


def priority(item, bins):
    """Score each bin; highest score wins (first on ties).

    Primary key: minimize sum of squares of residuals after placing the item.
    Equivalent to preferring bins whose residual is large relative to others
    (a balancing effect), while best-fit breaks exact ties.
    """
    residual = bins - item  # all >= 0 since only fitting bins are shown
    # Minimizing (R_old^2 -> residual^2) change == minimizing residual^2 - bins^2.
    # bins is fixed per call, so we only need residual^2 plus a best-fit bonus.
    # Lower residual^2 -> higher score, so negate.
    score = -(residual.astype(np.float64) ** 2)
    # Small best-fit tiebreak: prefer the tighter fit.
    score += (100.0 - residual) * 1e-3
    return score
# EVOLVE-BLOCK-END
