# EVOLVE-BLOCK-START
"""Best fit with a worst-fit escape for unusable scraps."""
import numpy as np

# Below this leftover the space is essentially wasted for the Weibull-shaped
# item stream (items have mean ~40, so tiny remnants rarely get reused).
SCRAP = 10


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary key: prefer the tightest fit (most negative residual).
    score = -residual.astype(np.float64)
    # Escape: if the tightest fit would strand a scrap, penalise scrap creation
    # slightly so a roomier bin can win, reducing wasted fragments.
    score -= (residual < SCRAP) * 0.5
    return score
# EVOLVE-BLOCK-END

