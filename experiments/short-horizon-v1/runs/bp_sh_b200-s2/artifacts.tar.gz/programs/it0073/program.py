# EVOLVE-BLOCK-START
"""Best fit reinforced by an online estimate of how reusable each residual is."""
import numpy as np


class _State:
    def __init__(self):
        # histogram of item sizes seen so far (size 1..100), with Laplace smoothing
        self.hist = np.ones(101, dtype=np.float64)
        self.n = 0
        # cache: expected "reuse value" of a residual r (larger is better)
        self._waste = None

    def _reuse_table(self):
        # fraction of mass at each size, and cumulative availability not larger than r
        # For a residual r, we reward residuals that are close to a common item size,
        # penalize residuals that are large but unlikely to be filled soon.
        total = self.hist.sum()
        p = self.hist / total
        return p


_STATE = _State()


def priority(item, bins):
    st = _STATE
    st.hist[item] += 1.0
    st.n += 1

    p = st._reuse_table()

    residual = bins - item  # >= 0 for all shown bins
    # best fit: prefer smallest residual
    base = -residual.astype(np.float64)

    # Reuse value: probability mass of item sizes that would exactly fill the residual,
    # or, smoothed, a small bonus for residuals that are close to common sizes.
    # Build a cheap per-residual score via lookup for the residuals we need.
    r = residual
    # exact-fill probability
    exact = p[np.clip(r, 0, 100)]
    # nearby-fill probability (within +-2)
    near = np.zeros_like(exact)
    for d in (-2, -1, 1, 2):
        idx = np.clip(r + d, 0, 100)
        near += p[idx]
    near *= 0.25

    # Cap the influence so best-fit remains dominant.
    reuse = np.minimum(exact + near, 0.2)

    # Waste penalty is large when reuse is small.
    return base + 2.0 * reuse
# EVOLVE-BLOCK-END

