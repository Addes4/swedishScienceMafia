# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware residual preference.

Pure best-fit is near optimal, but on Weibull-shaped streams many item sizes cluster
around ~40. For an arriving item, a bin's *post-placement* residual that equals a
common item size (or 0) is easier to fill exactly later. We therefore rank bins
primarily by small post-residual (best-fit), and only perturb the ordering when the
residual is close to a frequently occurring size, giving a nudge toward residuals
that are likely to be matched by future items.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item

    # Best-fit base score: prefer smaller post-placement residual.
    best_fit = -residual.astype(np.float64)

    # Nudge: mildly reward residuals that are "fillable" by likely future items,
    # i.e. residuals close to 0 or close to typical mid-size items (~40).
    # This is a tiny perturbation so it never overrides a clear best-fit choice.
    target = 40.0
    fillable = np.where(
        residual == 0,
        1.0,
        np.exp(-((residual - target) ** 2) / (2.0 * 8.0 ** 2)),
    )

    return best_fit + 0.01 * fillable
# EVOLVE-BLOCK-END
