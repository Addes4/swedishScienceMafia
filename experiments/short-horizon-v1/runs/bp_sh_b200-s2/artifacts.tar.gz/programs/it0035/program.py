# EVOLVE-BLOCK-START
"""Best fit, with a mild preference against leaving unusable tiny residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    residual = bins - item  # remaining capacity after placing item here

    # Smallest item size seen so far, tracked in a module-level variable.
    global _min_seen
    if item < _min_seen:
        _min_seen = item
    min_seen = _min_seen

    # Usable residual: 0 (perfect) or at least min_seen (a future item could fit).
    # A residual strictly between 0 and min_seen is essentially wasted space.
    if min_seen > 1:
        wasted = (residual > 0) & (residual < min_seen)
    else:
        wasted = np.zeros(residual.shape, dtype=bool)

    # Primary: best fit (smaller residual better). Secondary: avoid wasted holes.
    score = -residual.astype(np.float64) - 1000.0 * wasted.astype(np.float64)
    return score


_min_seen = 101
# EVOLVE-BLOCK-END

