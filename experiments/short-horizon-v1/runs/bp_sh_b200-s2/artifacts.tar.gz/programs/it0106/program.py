# EVOLVE-BLOCK-START
"""Best fit with a gentle penalty for creating unusable tiny scraps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Primary: tightest fit (largest priority = smallest residual).
    score = -residual.astype(np.float64)

    # Secondary: avoid creating very small residual scraps that later items likely cannot use.
    # A scrap is penalized relative to a small "useful" scale.
    useful = 10.0
    tiny = residual < useful
    score -= 0.05 * tiny * (1.0 - residual / useful)

    return score
# EVOLVE-BLOCK-END

