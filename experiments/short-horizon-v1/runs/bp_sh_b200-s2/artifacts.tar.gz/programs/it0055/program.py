# EVOLVE-BLOCK-START
"""Hybrid: best-fit for small items, first-fit-like for large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    exact = (residual == 0).astype(np.float64)

    # For small items (< 40), prefer tightest fit (smallest residual).
    # For large items (>= 40), prefer the emptiest bin that fits (largest residual),
    # but never open a brand new bin if an already-used bin can still take it usefully.
    if item < 40:
        score = -residual.astype(np.float64)
    else:
        # Prefer bins that are not brand-new (bins < 100 remaining), choosing the emptiest among them.
        used = (bins < 100).astype(np.float64)
        score = used * 1e6 + residual.astype(np.float64)
    score = score + exact * 1e9
    return score
# EVOLVE-BLOCK-END

