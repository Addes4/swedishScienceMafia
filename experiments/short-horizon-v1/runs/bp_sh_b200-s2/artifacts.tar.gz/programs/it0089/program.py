# EVOLVE-BLOCK-START
"""Best fit with a complementary-residual bonus from an online item-size histogram."""
import numpy as np

# Online histogram/EMA of item sizes (shared across calls within a stream).
_HIST = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _HIST
    # Update EMA histogram with the arriving item.
    _HIST *= 0.999
    _HIST[item] += 1.0
    total = _HIST.sum()
    if total > 0:
        prob = _HIST / total
    else:
        prob = _HIST

    residual = bins - item  # remaining capacity after placing item into each bin

    # Base: best fit (tightest residual => highest priority).
    score = -(residual.astype(np.float64))

    # Bonus: reward residuals that are themselves likely future item sizes.
    # A residual of 0 is already rewarded by best-fit strongly; here we add
    # a small bonus proportional to the probability of the residual size,
    # scaled so it only breaks near-ties rather than overriding best-fit.
    res_idx = residual.astype(np.int64)
    valid = (res_idx >= 0) & (res_idx <= 100)
    prob_res = np.zeros_like(score)
    prob_res[valid] = prob[res_idx[valid]]

    # Bonus magnitude small relative to the 1-unit residual gap of best-fit,
    # so it only acts as a near-tie breaker among equally-tight bins.
    score += 0.5 * prob_res

    return score
# EVOLVE-BLOCK-END
