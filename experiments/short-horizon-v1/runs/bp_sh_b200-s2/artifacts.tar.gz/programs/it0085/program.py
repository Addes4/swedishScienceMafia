# EVOLVE-BLOCK-START
"""Best-fit with exact-fill bonus and mild fullest-bin tie-breaking."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Base: best fit -> smallest residual gets highest score.
    score = -residual.astype(np.float64)
    # Exact fill bonus: filling a bin completely is never harmful.
    score += np.where(residual == 0, 0.5, 0.0)
    # Mild preference toward already-fuller bins (smaller residual) is already
    # captured by -residual, which keeps fragmentation low.
    return score
# EVOLVE-BLOCK-END

