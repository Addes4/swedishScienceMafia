# EVOLVE-BLOCK-START
"""Best fit with a parity/window tie-break that nudges toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for bins shown
    # Primary: smaller residual is better.
    # Secondary (only within a 1-unit window of the tightest fit): prefer larger residual,
    # i.e. the less dangerously tight bin, to avoid creating 1-unit scrap.
    min_r = residual.min()
    near = residual <= (min_r + 1)
    # score: tight fit dominates; within the window, larger residual wins slightly.
    score = -residual.astype(np.float64) * 1000.0
    score += near.astype(np.float64) * residual.astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END

