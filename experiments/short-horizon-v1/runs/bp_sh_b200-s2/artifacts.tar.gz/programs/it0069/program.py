# EVOLVE-BLOCK-START
"""Best-fit with a fullness tie-break: minimize residual, then prefer fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item           # capacity left after placing here
    used = 100 - bins                # capacity already consumed in this bin
    # Primary: smallest residual (best fit). Secondary: prefer fuller bins
    # (smaller residual among equally-full is already primary; here used adds a
    # slight push away from opening empty bins).
    return -residual.astype(np.float64) * 1000.0 - used.astype(np.float64)
# EVOLVE-BLOCK-END

