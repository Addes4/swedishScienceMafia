# EVOLVE-BLOCK-START
"""Best fit with a tiny quantized-residual tie-breaker."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item  # resulting residual capacity (>= 0)

    # Base: pure best fit (tightest residual first).
    score = -resid.astype(np.float64)

    # Tiny tie-breaker: prefer residuals that are close to a "nice" reusable value,
    # i.e. close to multiples of ~10 (approximate granularity of the item distribution),
    # and especially prefer exact fills (residual 0).
    # The perturbation is < 1 so it never overturns the best-fit ordering for
    # residuals differing by >= 1.
    q = 10.0
    dist_to_mult = np.abs(resid % q)
    dist_to_mult = np.minimum(dist_to_mult, q - dist_to_mult)
    nice_bonus = -dist_to_mult  # 0 when exactly on a multiple, -5 at worst
    exact_bonus = np.where(resid == 0, 1.0, 0.0)

    score += 0.01 * (nice_bonus + 0.5 * exact_bonus)
    return score
# EVOLVE-BLOCK-END
