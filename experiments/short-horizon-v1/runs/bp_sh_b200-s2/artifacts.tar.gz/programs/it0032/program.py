# EVOLVE-BLOCK-START
"""Best fit with a light reuse bonus: prefer bins leaving a residual that looks
like a size we have commonly seen, so the hole stays reusable."""
import numpy as np

_SIZES = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    global _COUNT
    _COUNT += 1.0
    _SIZES[item] += 1.0

    res = bins - item  # residual after placing, >= 0

    # best-fit dominant term: smaller residual => higher score
    score = -res.astype(np.float64)

    # reuse bonus: how "common" is the residual as a future item size?
    # use a smoothed frequency of seen sizes; strongly weight common residuals.
    idx = res.astype(np.int64)
    freq = _SIZES[idx] / _COUNT
    score += 6.0 * freq

    # tiny preference to reuse a partially used bin over opening a fresh one
    score -= 1e-6 * (res == 100)

    return score
# EVOLVE-BLOCK-END
