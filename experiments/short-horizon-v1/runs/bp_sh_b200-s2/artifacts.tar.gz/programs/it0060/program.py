# EVOLVE-BLOCK-START
"""Best-fit with exact-fit bonus and mild residual penalties."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tight fits, exact fits, and avoid tiny unusable residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacities of bins the item fits in, in bin order.
    """
    residual = bins - item  # >= 0

    # Primary: best fit -> smallest residual first (largest score)
    score = -residual.astype(np.float64)

    # Bonus for an exact fit (residual == 0): finishing a bin is very good.
    score += 8.0 * (residual == 0)

    # Mild penalty for leaving a tiny residual that is hard to reuse.
    # Penalize residuals of 1..4 slightly, scaled so it does not dominate.
    tiny = (residual > 0) & (residual <= 4)
    score -= 1.5 * tiny * (5 - residual)

    # Small preference for fuller bins among otherwise-equal choices
    # (lower residual = higher score already handles this; add slight
    #  deterministic push to break ties toward smaller residual).
    score -= 1e-3 * residual

    return score
# EVOLVE-BLOCK-END

