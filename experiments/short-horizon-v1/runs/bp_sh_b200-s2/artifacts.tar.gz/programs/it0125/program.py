# EVOLVE-BLOCK-START
"""Best fit with scrap avoidance: prefer tightest fit, but avoid straying tiny residues."""
import numpy as np

_state = {"count": 0, "mean": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update a running estimate of the typical item size (mean of observed items).
    s = _state
    s["count"] += 1
    n = s["count"]
    s["mean"] += (item - s["mean"]) / n

    # Estimate a "usable" threshold: a fraction of the running mean, floored at a few units.
    thr = max(0.5 * s["mean"], 3.0)

    resid = bins - item  # remaining capacity after placing the item here

    # Bins whose residual would be a usable amount (>= thr); among those pick the tightest fit.
    usable = resid[resid >= thr]
    if usable.size > 0:
        best_usable = usable.min()
        # Score: highest for the tightest usable residual.
        score = np.where(resid >= thr, -(resid - best_usable), -1e9)
    else:
        # No usable residual available: fall back to plain best fit.
        score = -resid

    return score
# EVOLVE-BLOCK-END
