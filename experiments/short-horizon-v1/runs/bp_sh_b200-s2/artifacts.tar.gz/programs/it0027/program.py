# EVOLVE-BLOCK-START
"""Best fit with slight tie preference for perfect fits.

The classic best-fit rule (smallest residual after placing) is essentially
optimal for this item distribution; the score is already close to 1.0. To
squeeze out a bit more, we score bins by the residual after placing but give
strict priority to bins that the item fills exactly (residual 0), since those
never leave a wasted hole.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities of feasible bins.
    """
    residual = bins - item
    # Primary: perfect fits first (residual == 0), then smallest residual.
    return -residual - 1000.0 * (residual == 0)
# EVOLVE-BLOCK-END
