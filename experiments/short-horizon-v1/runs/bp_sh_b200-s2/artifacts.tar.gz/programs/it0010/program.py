# EVOLVE-BLOCK-START
"""Worst-fit-inspired rule that balances tight fits against keeping usable gaps."""
import numpy as np

_state = {"sum": 0.0, "n": 0, "max": 1}


def priority(item, bins):
    s = _state
    s["sum"] += item
    s["n"] += 1
    if item > s["max"]:
        s["max"] = item
    mean = s["sum"] / s["n"]
    # Target residual: enough to still hold a typical item after this placement.
    # For Weibull(mean~40), a residual near the mean keeps bins flexible.
    target = 0.5 * mean + 0.25 * s["max"]
    residual = bins - item  # remaining capacity after placement
    # Prefer residuals close to the target from below (don't waste large holes),
    # but strongly prefer tight fits when they are already small.
    score = -(np.abs(residual - target)) + 0.5 * (residual <= target)
    return score
# EVOLVE-BLOCK-END
