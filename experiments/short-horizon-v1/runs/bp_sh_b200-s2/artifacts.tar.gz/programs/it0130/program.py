# EVOLVE-BLOCK-START
"""Best fit with a mild superlinear reward for tight packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual). Add a tiny superlinear bonus for
    # very tight fits so that near-perfect placements win over slightly looser ones
    # when residuals are close.
    return -residual - 0.001 * np.exp(-residual / 3.0)
# EVOLVE-BLOCK-END

