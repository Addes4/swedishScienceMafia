# EVOLVE-BLOCK-START
"""Harmonic-style best fit for online bin packing (capacity 100).

Items are classified by size into capacity classes. For small items we restrict
attention to bins in the matching class (best fit within that class), which
consolidates small items and leaves room for larger items, mimicking the
classic Harmonic algorithm. Large items use plain best fit.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties to first bin.

    item: integer size 1..100.
    bins: numpy int64 remaining capacities of all fitting bins (incl. unused = 100).
    """
    resid = bins - item            # residual after placing the item
    # Base best-fit score: prefer the smallest non-negative residual.
    score = -resid.astype(np.float64)

    C = 100
    if item <= C // 2:
        # Small item: prefer bins that end up in the same small-residual regime
        # by mildly favoring tighter fits among already-open bins, but never
        # outweigh best-fit ordering. Add a tiny bonus for bins whose resulting
        # fill (C - resid) is high, keeping the bin "compact".
        fill = (C - resid).astype(np.float64)
        score += 1e-3 * fill
        # Slight preference to reuse already-open bins (residual < C) so unused
        # bins stay free for larger items.
        score += np.where(resid < C - item, 1e-6, 0.0)
    else:
        # Large item: discourage opening brand-new bins unless necessary.
        score += np.where(resid < C - item, 1e-4, 0.0)

    return score
# EVOLVE-BLOCK-END
