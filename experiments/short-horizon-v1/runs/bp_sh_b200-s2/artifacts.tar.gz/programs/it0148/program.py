# EVOLVE-BLOCK-START
"""Best-fit with a residual-quality band: prefer tight fits that don't leave unusable slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Strong preference for exact fits (perfect fill closes the bin).
    exact = (residual == 0).astype(np.float64)

    # Prefer small residuals, but only down to a floor: leaving a residual smaller than a
    # typical small item (say 10) is wasteful because it can rarely be reused, whereas a
    # residual of ~10..20 keeps the bin useful. We penalise residuals below the floor a bit
    # less than the natural best-fit so tight-but-reusable fits win.
    floor = 10.0
    # Distance above the floor for residuals >= floor.
    above = np.maximum(residual - floor, 0.0)
    # Small positive slack for residuals below the floor (still slightly rewarded).
    below = np.maximum(floor - residual, 0.0) * 0.25

    score = -(above + below) + 50.0 * exact
    return score
# EVOLVE-BLOCK-END

