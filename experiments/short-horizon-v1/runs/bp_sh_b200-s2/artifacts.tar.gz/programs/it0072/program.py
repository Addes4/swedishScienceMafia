# EVOLVE-BLOCK-START
"""Harmonic-style best fit: prefer tight fits, but consolidate into fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # residual after placing the item (>= 0 since bins only contains fitting bins)
    residual = bins - item

    # best-fit primary signal: smaller residual is better -> use -residual
    # secondary: prefer bins that are already used more (fuller), so break ties
    used = 100 - bins  # 0 for unused bins
    # Scale the consolidation bonus so it never overrides a strictly tighter fit,
    # but helps choose among comparable residuals.
    return -(residual) + 0.004 * used
# EVOLVE-BLOCK-END

