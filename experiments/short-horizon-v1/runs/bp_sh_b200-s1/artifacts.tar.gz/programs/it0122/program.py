# EVOLVE-BLOCK-START
"""Best-fit with a smooth dead-zone penalty that adapts to the online
mean item size, plus a mild preference for used bins over fresh empty ones."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: tight best-fit. Use a concave transform so that reducing
    # residual near zero is rewarded slightly more steeply.
    score = -residual.astype(np.float64) * 1.5

    # Smooth dead-zone penalty: residuals just above 0 are likely stranded.
    # Gentle linear ramp up to a moderate cap, so tight fits still win.
    dead = (residual > 0) & (residual < 20)
    score -= np.where(dead, (20.0 - residual) * 0.4, 0.0)

    # Mild bonus for unused bins so stranding slivers in used bins is
    # discouraged unless the residual is genuinely tight.
    empty = bins == 100
    score += np.where(empty, 5.0, 0.0)

    return score
# EVOLVE-BLOCK-END
