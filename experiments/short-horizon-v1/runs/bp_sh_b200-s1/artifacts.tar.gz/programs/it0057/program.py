# EVOLVE-BLOCK-START
"""Score bins with a harmonic-style reward of the post-placement residual.

For a residual r (capacity left after placing the item), rewarding 1/r would be the
classic harmonic bound; here we use a smooth, bounded variant so that near-perfect
fills dominate but we never strand a tiny unusable residual when a slightly larger
residual is available that keeps the bin reusable by typical (~40) items.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest score (first on ties)."""
    residual = bins - item  # >= 0 for all shown bins

    r = residual.astype(np.float64)

    # Primary: strongly reward tight fits (small residual). Using 1/(r+1)
    # gives the harmonic ordering while staying finite at r=0.
    score = 1.0 / (r + 1.0)

    # Secondary shaping: a residual just below a typical item (~40) is wasteful,
    # since it can't hold another typical item. Nudge the score up once the
    # residual reaches that reusable region, using a small term that can only
    # reorder near-equal fits.
    reusable = (r >= 40.0).astype(np.float64)
    score += 0.02 * reusable

    # Tertiary: among two fits with the same residual, prefer the bin that was
    # already fuller (smaller residual -> already handled), so nothing more.

    return score
# EVOLVE-BLOCK-END
