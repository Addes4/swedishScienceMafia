# EVOLVE-BLOCK-START
"""Tight best-fit with a gentle dead-zone guard.

The dominant term is best-fit (minimize post-placement residual). A small
penalty discourages leaving tiny unusable residuals, and a small bonus
prefers opening fresh bins late. No noisy histogram term.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: tight best-fit.
    score = -residual.astype(np.float64)

    # Gentle dead-zone: residuals in (0, min_item) are almost surely stranded.
    # Use a soft penalty that grows as residual shrinks toward 0 so that an
    # exact fit (residual 0, no dead-zone) is still best, but a residual of 1
    # is not strongly preferred over a residual of ~10.
    dead = (residual > 0) & (residual < 15)
    score -= np.where(dead, (15.0 - residual) * 2.0, 0.0)

    # Mild bonus for unused bins (rewards not stranding partial bins too early).
    empty = bins == 100
    score += np.where(empty, 3.0, 0.0)

    return score
# EVOLVE-BLOCK-END
