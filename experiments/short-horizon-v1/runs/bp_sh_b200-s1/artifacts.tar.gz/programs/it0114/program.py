# EVOLVE-BLOCK-START
"""Score bins to avoid stranding small unusable residuals (a 'dead zone' penalty),
while still doing tight best-fit packing."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Base: tight best-fit — prefer the smallest non-negative residual.
    score = -residual.astype(np.float64)

    # Soft dead-zone penalty: residuals in (0, 20] are unlikely to host a future
    # mid-size item, so gently discourage them. Weight grows as the residual shrinks
    # toward 0, vanishing at the threshold.
    dead = (residual > 0) & (residual <= 20)
    score -= np.where(dead, 8.0 * (20.0 - residual) / 20.0, 0.0)

    return score
# EVOLVE-BLOCK-END
