# EVOLVE-BLOCK-START
"""Score bins to avoid stranding small unusable residuals (a 'dead zone' penalty),
while still doing tight best-fit packing."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Base: prefer residual near 0 (perfect fill).
    score = -residual.astype(np.float64)

    # Dead-zone penalty: residuals in (0, 20) are bad (too small to reuse well),
    # so strongly discourage stranding a near-empty sliver.
    dead = (residual > 0) & (residual < 20)
    score -= np.where(dead, 60.0, 0.0)

    return score
# EVOLVE-BLOCK-END

