# EVOLVE-BLOCK-START
"""Best fit with a cap that protects large-residual bins from small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    if item < 40:
        # Small items: prefer tight fits, but never reward large fresh bins more than
        # already-small bins. Cap residual so we don't shatter big free space.
        capped = np.minimum(residual, 40)
        return -capped
    return -residual
# EVOLVE-BLOCK-END

