# EVOLVE-BLOCK-START
"""Best fit with a reusable-leftover bias.

Items arrive online. Pure best fit (minimize residual after placement) is a strong
baseline, but it can shatter nearly-empty bins with tiny items and leave residuals
that no typical future item (mean ~40) can use. This rule primarily minimizes the
post-placement residual, and adds a small tie-breaking bias: among bins that leave
a small waste, prefer the one whose residual-after is close to a typical item size,
so leftover space stays reusable. Exact fits and tight fits still dominate.
"""
import numpy as np

# Typical item size of the Weibull-shaped distribution (mean ~40).
_TYP = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins.astype(np.float64)
    after = rem - item  # residual left in the bin after placing the item (>= 0)

    # Primary: best fit -> smallest post-placement residual.
    # Secondary (small, bounded): prefer residual-after near a typical item size so the
    # leftover is reusable. Normalized by capacity so the bias never overrides best fit.
    # Scale by how much free space relative to a typical item, tiny weight.
    bias = -np.abs(after - _TYP) / 100.0

    return -(after / 100.0) + 0.02 * bias
# EVOLVE-BLOCK-END

