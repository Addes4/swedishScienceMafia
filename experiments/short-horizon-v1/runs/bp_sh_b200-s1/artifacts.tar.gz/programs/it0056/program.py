# EVOLVE-BLOCK-START
"""Pure Best-Fit for online bin packing.

Rank bins by the residual capacity left after placing the item, preferring the
tightest fit (smallest residual).  Ties are resolved by the harness to the first
bin.  Penalty-based and look-ahead variants consistently underperformed plain
best-fit in evaluation, so we keep the simple, robust rule.
"""
import numpy as np


def priority(item, bins):
    """Return one score per bin; item goes to highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in (incl. unused = 100).
    """
    residual = bins - item  # remaining capacity after placing the item here
    # Maximize score == minimize residual (tightest fit). Scale is irrelevant.
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

