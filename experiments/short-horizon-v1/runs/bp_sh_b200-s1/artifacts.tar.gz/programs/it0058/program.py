# EVOLVE-BLOCK-START
"""Best-fit primary term with a tiny refillability tie-break based on the
running mean of past item sizes (estimated online)."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running mean of item sizes seen so far.
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    residual = (bins - item).astype(np.float64)  # remaining capacity after placing here

    # Primary: tightest fit (most negative residual is best).
    score = -residual

    # Tiny tie-break: favor residuals large enough to host a typical future item,
    # but never enough to override the primary best-fit ordering.
    # 1.0 / (1 + |residual - mean|) is in (0, 1], peak when residual ~= mean.
    tie = 1.0 / (1.0 + np.abs(residual - mean))
    score += 0.001 * tie

    return score
# EVOLVE-BLOCK-END

