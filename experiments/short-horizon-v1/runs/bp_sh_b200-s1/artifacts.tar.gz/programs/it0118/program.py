# EVOLVE-BLOCK-START
"""Best-fit with an online-learned fillability bonus for residual sizes.

Primary ranking is tight best-fit (-residual). On top of that, we add a bonus
proportional to the probability that the leftover residual of a bin can still
be exactly/composably filled by future items, estimated online from a smoothed
histogram of observed item sizes. This discourages stranding slivers while
keeping near-perfect fills attractive.
"""
import numpy as np


# Persistent state across calls within a stream.
_state = {
    "hist": np.ones(101, dtype=np.float64),  # smoothed item-size histogram
    "n": 0.0,
}


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    # Update online item-size histogram (with a light decay toward the prior
    # so it adapts but stays stable for long streams).
    _state["n"] += 1.0
    h = _state["hist"]
    h[item] += 1.0
    # Gentle renormalization: pull histogram toward uniform to keep it smooth.
    if _state["n"] >= 200:
        h *= 0.999
        _state["n"] *= 0.999

    residual = bins - item  # capacity left after placing here

    # Primary: tightest fit (more negative residual is worse, closer to 0 better).
    score = -residual.astype(np.float64)

    # Fillability bonus: probability mass of item sizes <= residual that help
    # eventually fill the residual. Use CDF of observed sizes, weighted so that
    # a residual matching a typical item size (so remaining can be reused) is
    # preferred over a tiny useless sliver.
    hist = _state["hist"]
    # Build a lookup table for residuals 0..100: expected "reuse value".
    # Small residuals that cannot host a typical item get low value; residuals
    # equal to common item sizes get a boost.
    cum = np.cumsum(hist)  # CDF over sizes 0..100
    tot = cum[-1]
    # value[r] = chance a new item fits in a bin with residual r, scaled.
    fit_prob = cum / tot  # P(item <= r), approximate

    r = np.clip(residual, 0, 100).astype(np.int64)
    bonus = fit_prob[r]

    # Add bonus with modest weight so best-fit dominates structural choices.
    score += 3.0 * bonus

    return score
# EVOLVE-BLOCK-END

