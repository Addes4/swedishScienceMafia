# EVOLVE-BLOCK-START
"""Score bins to favor tight best-fit fits, but break near-ties so that we avoid
leaving unusable tiny residuals while keeping residuals reusable."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    score = -residual.astype(np.float64)

    # Residuals in (0, 25] are too small to reuse well (item mean ~40), so they
    # strand most of a bin's space. Penalize them so a slightly larger residual
    # that can host a future mid-size item is preferred.
    dead = (residual > 0) & (residual < 25)
    score -= np.where(dead, 30.0, 0.0)

    return score
# EVOLVE-BLOCK-END

