# EVOLVE-BLOCK-START
"""Score bins by best-fit, plus a bonus for residuals likely to be filled later.

We keep an online histogram of item sizes seen so far. For each candidate residual,
we estimate the chance that a future item exactly matches it (using a small window
around the residual), and give a bonus so bins whose leftover can be reused are
preferred over bins that strand a sliver.
"""
import numpy as np

_CAP = 101
_hist = np.zeros(_CAP, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    global _count

    # Update online item-size histogram (1..100).
    if 1 <= item <= _CAP - 1:
        _hist[item] += 1.0
        _count += 1.0

    residual = bins - item  # remaining capacity after placing here

    # Base: tight best-fit (prefer small residual).
    score = -residual.astype(np.float64) * 2.0

    if _count > 0:
        # Estimate probability that a future item lands exactly on this residual.
        # Smooth over a small window since the distribution is continuous-ish.
        weights = np.array([0.2, 0.5, 1.0, 0.5, 0.2])
        p = np.zeros(residual.shape[0], dtype=np.float64)
        for j, r in enumerate(residual):
            if r <= 0:
                continue
            lo = r - 2
            hi = r + 2
            s = 0.0
            for k in range(lo, hi + 1):
                if 1 <= k <= _CAP - 1:
                    s += weights[k - lo] * _hist[k]
            p[j] = s
        # Bonus for fillable residuals; scale to be comparable to base term.
        score += p / max(_count, 1.0) * 8.0

    return score
# EVOLVE-BLOCK-END
