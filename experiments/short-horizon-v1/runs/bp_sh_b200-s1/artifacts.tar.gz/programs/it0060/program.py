# EVOLVE-BLOCK-START
"""Best-fit with a tiny distribution-aware tie-break that avoids stranding
residuals too small to host a typical future item."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    # Update running mean of past item sizes.
    _state["sum"] += float(item)
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]

    residual = bins - item  # remaining capacity after placing the item here

    # Primary: tightest fit (smallest residual) dominates.
    score = -residual.astype(np.float64)

    # Tiny tie-break: reward residuals large enough to host a typical item.
    # Kept well below 1 in magnitude so it only resolves near-ties.
    usable = residual >= mean
    score += np.where(usable, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
