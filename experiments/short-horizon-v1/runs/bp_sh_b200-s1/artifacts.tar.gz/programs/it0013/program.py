# EVOLVE-BLOCK-START
"""Adaptive best fit: best fit for large items, consolidation first-fit for small ones."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Adaptive threshold: items at least this large are treated as "big".
    # Big items use best fit (tightest residual) so they don't waste large bins.
    # Small items use a consolidation rule: prefer the fullest bin that is not
    # nearly empty, and among those prefer lower residual variation, so tiny
    # items are packed together rather than shattering fresh bins.
    if item >= 30:
        return -(bins - item)
    # For small items: prefer a fairly full bin (small residual) so we consolidate
    # partial bins, but never pick a bin that would leave a tiny unusable residual
    # when a slightly larger residual alternative exists. Score rewards small
    # residual with a mild preference for lower-index bins via residual tie-break.
    residual = bins - item
    # Penalize residuals that are "useless": too small (< item-ish smallest) but
    # positive; reward exact fits and moderate residuals slightly.
    score = -residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
