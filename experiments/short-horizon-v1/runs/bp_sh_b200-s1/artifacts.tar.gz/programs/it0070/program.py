# EVOLVE-BLOCK-START
"""Concave best-fit with item-aware reusability shaping.

Rank bins so that the item fills tight (small residual), but avoid leaving a
tiny useless leftover.  We use a concave transform of the residual and a
smooth penalty for residuals that are too small to fit a typical next item.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary term: prefer small residual (best fit).  Use a mild concave
    # transform so large residuals are compressed and small ones dominate.
    score = -np.sqrt(residual.astype(np.float64))

    # Reusability shaping: residuals that cannot fit a typical item (mean ~40)
    # waste nearly a full bin.  Penalize residuals below a soft threshold
    # smoothly rather than with a hard cutoff.
    # Soft penalty: large when residual is tiny, fading out around 30.
    small = np.clip((30.0 - residual) / 30.0, 0.0, 1.0)
    # exclude perfect fill (residual == 0) from the penalty: that is ideal.
    small = np.where(residual <= 0, 0.0, small)
    score -= 0.15 * small * small

    return score
# EVOLVE-BLOCK-END

