# EVOLVE-BLOCK-START
"""Tight best-fit with a small tie-breaker toward reusable residuals."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item here

    # Primary: tight best-fit (smallest residual wins).
    score = -residual.astype(np.float64)

    # Very small tie-breaker: reward residuals that exactly match a common
    # future item size (so the leftover is likely reusable). Scaled well below
    # best-fit's unit steps so it only resolves ties.
    if _COUNT > 20:
        total = _HIST.sum()
        if total > 0:
            valid = residual >= 1
            idx = np.clip(np.where(valid, residual, 0), 0, 100).astype(np.int64)
            probs = _HIST[idx] / total
            probs = np.where(valid & (residual <= 100), probs, 0.0)
            score += probs * 1.0

    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
