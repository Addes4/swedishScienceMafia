# EVOLVE-BLOCK-START
"""Score bins to avoid stranding small unusable residuals (a 'dead zone' penalty),
while still doing tight best-fit packing."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Prefer residual near 0 (perfect fill), strongly.
    # Penalize the "dead zone": a small positive residual that is unlikely to fit
    # another item, since that wastes nearly a whole bin.
    score = -residual.astype(np.float64)

    # Dead-zone penalty: residuals in (0, 25] are bad (too small to reuse well),
    # so shave their score so a slightly larger residual that can host a future
    # mid-size item is preferred.
    dead = (residual > 0) & (residual < 25)
    score -= np.where(dead, 30.0, 0.0)

    return score
# EVOLVE-BLOCK-END
