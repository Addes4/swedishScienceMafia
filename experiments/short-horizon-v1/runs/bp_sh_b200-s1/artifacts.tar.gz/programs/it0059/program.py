# EVOLVE-BLOCK-START
"""Best-fit with an online fill-forward tie-break.

Primary rule: place the item into the bin that leaves the smallest non-negative
residual (classic best fit), which is the strongest known online heuristic for
this capacity.  Ties (and near-ties within a small band) are broken toward a bin
whose resulting residual is exactly 0, or else at least a running estimate of
the typical item size, so we do not strand unusable gaps.
"""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item here

    # Update an online estimate of the mean item size (used only as a mild
    # tie-break; best-fit ordering stays dominant).
    _state["sum"] += item
    _state["count"] += 1
    mean_size = _state["sum"] / _state["count"]

    # Primary: strongest preference for the tightest fit.
    score = -residual.astype(np.float64)

    # Mild tie-break: reward residuals that are exactly empty or big enough to
    # host a future typical item.  Kept tiny so it cannot reorder clearly
    # different fits.
    good = (residual == 0) | (residual >= mean_size)
    score += np.where(good, 1e-3, 0.0)

    return score
# EVOLVE-BLOCK-END
