# EVOLVE-BLOCK-START
"""Best-fit with a dead-zone penalty calibrated to observed item sizes,
plus a small bonus for residuals matching a recently seen item size."""
import numpy as np

MIN_ITEM = 90  # running estimate of the smallest item seen so far


def priority(item, bins):
    global MIN_ITEM
    if item < MIN_ITEM:
        MIN_ITEM = item

    residual = bins - item  # remaining capacity after placing here
    score = -residual.astype(np.float64)

    # Dead zone: residuals too small to ever hold another item (based on the
    # smallest item seen so far) are nearly wasted bins.
    dz = max(MIN_ITEM, 1)
    dead = (residual > 0) & (residual < dz)
    score -= np.where(dead, 30.0, 0.0)

    return score
# EVOLVE-BLOCK-END
