# EVOLVE-BLOCK-START
"""Best fit with a residual-matching bonus to reduce fragmentation."""
import numpy as np


class _State:
    def __init__(self):
        # counts of item sizes seen (index 1..100), simple exponential smoothing
        self.freq = np.zeros(101, dtype=np.float64)


_state = _State()


def priority(item, bins):
    """Rank bins: best fit, with a bonus when the leftover equals a common item size."""
    freq = _state.freq
    # update frequency estimate with current item
    freq[item] += 1.0

    residual = bins - item

    # score: primary best fit (-residual), secondary prefers residuals that
    # equal 0 or a frequent item size (more likely to be reused cleanly).
    # normalize frequency into [0,1)
    total = freq.sum()
    if total > 0:
        common = freq / total
    else:
        common = freq

    # reward small residuals that match a plausible future item, plus exact fits
    bonus = common[residual]  # zero for negative/out-of-range handled below

    # ensure no NaN and finite
    bonus = np.nan_to_num(bonus, nan=0.0, posinf=0.0, neginf=0.0)

    return -residual + 1e-3 * bonus
# EVOLVE-BLOCK-END

