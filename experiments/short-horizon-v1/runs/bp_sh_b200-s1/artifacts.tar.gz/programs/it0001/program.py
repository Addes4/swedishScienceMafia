# EVOLVE-BLOCK-START
"""Best-fit with harmonic-style residual thresholds to squeeze packing closer to optimal."""
import numpy as np

_THRESH = (10, 20, 30, 40, 50, 60, 70, 80, 90)


def priority(item, bins):
    """Rank bins: prefer tightest fit, breaking ties toward residues that leave usable space.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    resid = bins - item  # remaining capacity after placing the item

    # Base score: tighter fit (smaller resid) is better.
    score = -resid.astype(np.float64)

    # Penalize leaving a residue that is smaller than the item itself but large,
    # which tends to strand space; reward residues just above common item sizes.
    # A small monotone nudge based on harmonic-style bucket boundaries.
    r = resid.astype(np.int64)
    for t in _THRESH:
        # bins whose residue would fall just below threshold t get a slight penalty
        score -= 0.01 * ((r < t) & (r >= t - 10)).astype(np.float64)

    return score
# EVOLVE-BLOCK-END

