# EVOLVE-BLOCK-START
"""Score bins by tightest fit (smallest residual after placement), with a tiny
bonus for exact fills to close bins crisply. Ordering is otherwise plain best-fit."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: plain best-fit (prefer smallest residual).
    score = -residual.astype(np.float64)

    # Tiny bonus for exact fills only, small enough not to reorder distinct residuals.
    score += np.where(residual == 0, 1e-3, 0.0)

    return score
# EVOLVE-BLOCK-END
