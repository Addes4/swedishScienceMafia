# EVOLVE-BLOCK-START
"""Best-fit packing with a targeted "exact-fillable residual" bonus.

The primary rule is classic tight best-fit (minimize residual after placing the
item).  On top of that we give a bonus when the leftover residual exactly equals
an item size that has been seen recently, because such a residual has a real
chance of being filled exactly by a future item, which reduces the number of
bins.  Empty bins get only a tiny nudge so we don't open new bins needlessly.
"""
import numpy as np

# Module-level state: a coarse histogram of item sizes (1..100) and the
# smallest item size observed so far.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0
_MIN_SEEN = 101


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    global _HIST, _COUNT, _MIN_SEEN

    residual = bins - item  # remaining capacity after placing the item here

    # ---- Primary: tight best-fit. residual==0 is best, larger residual worse.
    score = -residual.astype(np.float64)

    # ---- Exact-fillable residual bonus ----
    # If the leftover exactly equals a size that has appeared at least a few
    # times, a future item may fill it perfectly.  Use an indicator of whether
    # the histogram has seen that residual as an item size.
    if _COUNT > 10:
        valid = (residual >= 1) & (residual <= 100)
        idx = np.where(valid, residual, 0).astype(np.int64)
        seen = np.where(valid, _HIST[idx], 0.0) > 0.0
        score += np.where(seen, 2.0, 0.0)

    # ---- Tiny bonus for unused bins (break ties toward opening fresh bins
    #      only when residuals are comparable). ----
    empty = bins == 100
    score += np.where(empty, 0.5, 0.0)

    # ---- Record this item ----
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1
        if item < _MIN_SEEN:
            _MIN_SEEN = item

    return score
# EVOLVE-BLOCK-END

