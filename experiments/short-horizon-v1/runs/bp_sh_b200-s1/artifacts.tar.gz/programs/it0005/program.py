# EVOLVE-BLOCK-START
"""Best fit with an explicit index tie-break to consolidate partial bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = bins.shape[0]
    residual = bins - item
    # Best fit: smallest resulting residual is best (negative residual -> high score).
    # Small index term breaks ties toward earlier bins (only matters on equal residuals).
    idx = np.arange(n, dtype=np.float64)
    return -residual.astype(np.float64) - idx * 1e-9
# EVOLVE-BLOCK-END

