# EVOLVE-BLOCK-START
"""Best fit with exact-fit preference and small-residual guard."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item  # >= 0 for all bins shown
    # Prefer exact fills, then tighter fits among usable residuals.
    # Treat tiny residuals (likely dead space for this distribution, mean ~40)
    # as less attractive than a moderately larger residual.
    adjusted = resid.astype(np.float64).copy()
    tiny = (resid > 0) & (resid < 10)
    adjusted[tiny] = 100.0  # push small-but-nonzero leftovers to the back
    exact = resid == 0
    adjusted[exact] = -1.0  # exact fills always win
    return -adjusted
# EVOLVE-BLOCK-END

