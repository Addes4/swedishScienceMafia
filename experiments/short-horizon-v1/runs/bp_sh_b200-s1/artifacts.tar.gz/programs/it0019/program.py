# EVOLVE-BLOCK-START
"""Best fit with a penalty that discourages shattering large-residual bins with small items."""
import numpy as np

_state = {"n": 0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # update running mean of item sizes (exponential-ish, simple running average)
    n = _state["n"]
    mean = _state["mean"]
    mean = (mean * n + item) / (n + 1)
    _state["n"] = n + 1
    _state["mean"] = mean

    residual = bins - item  # remaining capacity after placing the item

    if item >= mean:
        # Large/medium items: standard best fit (tightest fit).
        return -residual

    # Small items: prefer a tight fit, but discourage putting them into bins
    # whose residual stays large (would shatter a big empty bin).
    # Penalize residuals above the current mean item size.
    penalty = np.maximum(residual - mean, 0.0)
    return -residual - 2.0 * penalty
# EVOLVE-BLOCK-END
