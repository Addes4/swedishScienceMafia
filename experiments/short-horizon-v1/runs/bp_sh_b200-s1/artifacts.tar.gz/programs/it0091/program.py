# EVOLVE-BLOCK-START
"""Strict best-fit with a tie-break-only dead-zone penalty.

The primary score is the (negative) residual, so ordering is identical to pure
best-fit: the smallest non-negative residual wins. A tiny epsilon penalty on
dead-zone residuals acts only when two bins have residuals differing by less
than epsilon, so it can only break near-exact ties without perturbing the
best-fit decision.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: pure best-fit (prefer smallest residual).
    score = -residual.astype(np.float64)

    # Tie-break only: penalize dead-zone residuals a negligible amount so that
    # among bins with practically the same residual, we avoid the unusable
    # leftover. Epsilon is far below any integer residual gap, so the best-fit
    # ordering among distinct residuals is preserved exactly.
    dead = (residual > 0) & (residual < 25)
    score -= np.where(dead, 1e-6, 0.0)

    return score
# EVOLVE-BLOCK-END
