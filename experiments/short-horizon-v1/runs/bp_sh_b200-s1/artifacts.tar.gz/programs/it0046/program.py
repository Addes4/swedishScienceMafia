# EVOLVE-BLOCK-START
"""Best-fit core with a sharp reward for near-exact bin closure."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit: prefer small residual strongly.
    score = -residual.astype(np.float64)

    # Reward near-exact closures: residual == 0 is ideal, and a residual smaller
    # than the item (can't even host a single item of the current size again) is
    # a clean close -- reward it so it wins over leaving a mid-size residual.
    near_exact = (residual < item) & (residual >= 0)
    score += np.where(near_exact, 20.0, 0.0)

    # Extra boost for a perfect fill.
    score += np.where(residual == 0, 100.0, 0.0)

    return score
# EVOLVE-BLOCK-END

