# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware expected-reuse tie-break.

Pure best-fit strands bins with tiny unusable residuals.  Instead of a fixed dead
zone we estimate, from the items seen so far, the probability that a future item
fits into the residual a placement would leave.  A residual that is likely to be
reused (and large) is worth keeping; a residual too small for typical items is
penalized.  Best-fit remains the dominant term so tight packing is preserved.
"""
import numpy as np


def priority(item, bins):
    # --- update running sample of item sizes (capped for speed) ---
    hist = priority.hist
    hist[item] += 1
    total = hist.sum()

    residual = bins - item  # remaining capacity after placing here

    score = -residual.astype(np.float64)  # best-fit primary term

    # Empirical fraction of seen items that would fit in each residual r>=0:
    # P(fit | r) = (# items <= r) / total, via cumulative histogram.
    cum = np.cumsum(hist)              # cum[k] = # items of size <= k
    r = np.clip(residual, 0, 100)
    fit_prob = cum[r] / total          # shape matches residual

    # Expected useful residual: larger residuals that are likely fillable matter.
    # Weight by residual magnitude so a big reusable gap outranks a tiny one,
    # but only where the residual can actually host some item.
    reuse = (fit_prob * r).astype(np.float64)

    # A residual that fits nothing useful among observed items is near-dead;
    # reward reuse strongly enough to redirect away from stranded residuals.
    score += 3.0 * reuse

    return score


priority.hist = np.zeros(101, dtype=np.int64)
# EVOLVE-BLOCK-END
