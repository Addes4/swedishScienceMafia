# EVOLVE-BLOCK-START
"""Best-fit with a dead-zone aware penalty, pure Python-free numpy scoring."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    residual = bins - item  # remaining capacity after placing the item here
    score = -residual.astype(np.float64)

    dead = (residual > 0) & (residual < 25)
    score -= np.where(dead, 30.0, 0.0)

    return score
# EVOLVE-BLOCK-END
