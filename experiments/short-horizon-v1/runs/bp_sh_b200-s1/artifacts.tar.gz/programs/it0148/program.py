# EVOLVE-BLOCK-START
"""Tight best-fit packing with an online histogram bonus that strongly rewards
residuals which can likely be filled exactly (or near-exactly) by a common
future item size, kept subordinate to best-fit so it never dominates."""
import numpy as np

# Module-level state: coarse histogram of item sizes (1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Rank bins; item goes to the highest score (first on ties)."""
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing here

    # ---- Primary: tight best-fit (smaller residual is better). ----
    score = -residual.astype(np.float64)

    # ---- Reclaimability bonus: probability that this residual equals a
    #      future item size (exact-fill opportunity). Scaled below 1.0 so a
    #      one-unit residual advantage in best-fit always outweighs it. ----
    total = _HIST.sum()
    if total > 0:
        valid = (residual >= 1) & (residual <= 100)
        idx = np.clip(np.where(valid, residual, 0), 0, 100).astype(np.int64)
        probs = _HIST[idx] / total
        score += np.where(valid, probs, 0.0) * 0.9

    # ---- Record this item. ----
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END

