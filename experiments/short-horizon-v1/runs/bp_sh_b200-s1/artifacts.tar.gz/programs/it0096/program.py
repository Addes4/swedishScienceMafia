# EVOLVE-BLOCK-START
"""Best-fit ranking with a smooth residual-utility term.

Pure best-fit (minimize residual) is the strongest known online heuristic for
this distribution.  We keep that as the primary ordering and add a smooth
utility term u(residual) that rewards residuals which a future item is likely
to consume well.  Since items have mean ~40 and integer sizes, a residual of r
is "useful" if some likely item size <= r exists; residuals below the observed
minimum usable size are nearly worthless.  We model utility as the probability
that a future item exactly fits, estimated from a running histogram of item
sizes, and add it with a small weight so it only perturbs near-ties.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing item here

    # Primary: prefer the tightest fit (smallest non-negative residual).
    score = -residual.astype(np.float64)

    # Smooth dead-zone penalty: a small residual that cannot host even a small
    # future item wastes almost the whole bin, so discourage residuals in [1, 20].
    # Use a smooth quadratic ramp instead of a hard step to avoid ordering shocks.
    r = residual.astype(np.float64)
    # penalty peaks at residual ~10 and decays for larger residual
    dead = np.clip(1.0 - np.abs(r - 10.0) / 12.0, 0.0, 1.0)
    score -= 8.0 * dead

    return score
# EVOLVE-BLOCK-END
