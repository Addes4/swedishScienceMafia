# EVOLVE-BLOCK-START
"""Best-fit packing with a sharp, sparse exact-fill bonus driven by an online
histogram of item sizes."""
import numpy as np

# Module-level state: a histogram of item sizes (1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item here

    # Primary: tight best-fit (residual near 0 is best).
    score = -residual.astype(np.float64)

    # Small bonus for unused bins.
    empty = bins == 100
    score += np.where(empty, 3.0, 0.0)

    # Sharp exact-fill bonus: reward residual matching the single most common
    # recent item size, so leftover space is likely fillable in one step.
    if _COUNT > 30:
        # most common item size among seen items
        mode_size = int(np.argmax(_HIST))
        if 1 <= mode_size <= 100:
            match = residual == mode_size
            # only reward a genuine leftover (not 0 residual already best)
            score += np.where(match, 2.0, 0.0)

    # Record this item into the histogram.
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
