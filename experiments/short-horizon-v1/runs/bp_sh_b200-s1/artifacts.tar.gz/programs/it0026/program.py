# EVOLVE-BLOCK-START
"""Best fit with a mild preference for bins whose residual is a plausible item size."""
import numpy as np

LAMBDA = 0.05
REF = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    leftover = bins - item
    # Primary: minimize leftover (best fit). Secondary: among near-tied leftovers,
    # mildly prefer bins whose leftover is a plausible future item size.
    return -leftover - LAMBDA * np.minimum(leftover.astype(np.float64), REF)
# EVOLVE-BLOCK-END

