# EVOLVE-BLOCK-START
"""Best-fit with an online, size-aware reusability bonus.

Keep tight packing (small residual) as the dominant signal, but among close
candidates prefer the residual that best matches the typical upcoming item
size, so bins stay reusable instead of being stranded with useless gaps.
"""
import numpy as np

_state = {"count": 0.0, "mean": 40.0}


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    # Online update of the running mean item size (exponential-ish).
    c = _state["count"]
    m = _state["mean"]
    _state["mean"] = (m * c + item) / (c + 1.0)
    _state["count"] = c + 1.0
    avg = _state["mean"]

    residual = bins - item

    # Dominant: prefer the tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Small bounded bonus (strictly under one residual unit) for residuals
    # that can accommodate a typical upcoming item; penalize gaps far below
    # the typical size (likely stranded) until they become useful again.
    # Reward closeness of residual to avg, capped so it never overturns a
    # genuine one-unit best-fit difference.
    gap = np.abs(residual.astype(np.float64) - avg)
    bonus = 1.0 - gap / (avg + 1.0)
    np.clip(bonus, 0.0, 1.0, out=bonus)
    # Residual of 0 (perfect fill) should not be punished by this; give it max.
    bonus = np.where(residual == 0, 1.0, bonus)
    score += 0.5 * bonus

    return score
# EVOLVE-BLOCK-END
