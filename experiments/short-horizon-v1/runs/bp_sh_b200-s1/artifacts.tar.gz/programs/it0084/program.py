# EVOLVE-BLOCK-START
"""Best-fit with a smooth, capacity-scaled dead-zone correction.

Strict best-fit (tightest fitting residual) is the dominant signal, since past
attempts showed that any hard perturbation of that ordering tends to hurt.
We keep best-fit but add a *smooth* correction: residuals in the dead zone get a
penalty proportional to the wasted capacity of the bin (so bins with larger
usable residuals are preferred over nearly-full-but-unusable ones), and smaller
residuals keep a strong negative penalty so truly tight fits remain attractive.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: prefer the tightest fit.
    score = -residual.astype(np.float64)

    # Secondary (smooth): for small residuals, subtract a penalty that grows as
    # the residual shrinks toward 0, scaled by how much capacity is stranded.
    # For residual <= 0 (perfect fill) the penalty is zero.
    # The penalty is small enough that a truly tighter fit still wins against a
    # much looser fit, but reverses near-ties where a slightly larger residual is
    # far more reusable.
    small = residual > 0
    penalty = np.where(small, 12.0 / (residual + 1.0), 0.0)
    score -= penalty

    return score
# EVOLVE-BLOCK-END

