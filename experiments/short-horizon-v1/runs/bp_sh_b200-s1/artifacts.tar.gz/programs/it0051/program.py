# EVOLVE-BLOCK-START
"""Pure best-fit: minimize the residual after placement, breaking ties by
preferring the fullest bin (largest pre-placement fill)."""

import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item here
    cap = bins.astype(np.float64)

    # Primary: tightest fit (smallest residual). Secondary: fullest bin
    # (smallest pre-placement remaining capacity), so ties close the tightest
    # possible bin instead of dropping the item into a fresh one.
    score = -residual.astype(np.float64) * 1000.0 - cap
    return score
# EVOLVE-BLOCK-END
