# EVOLVE-BLOCK-START
"""Best-fit with a smooth, item-size-aware reusability tie-break.

Pure best-fit (smallest resulting residual) is the dominant term. A small bounded
bonus (strictly less than one residual unit) breaks ties among equal residuals,
favoring bins that leave a residual large enough to host a typical future item
rather than a tiny unusable leftover.
"""
import numpy as np

# Module-level state: running estimate of the item-size distribution.
_state = {"n": 0, "mean": 40.0}


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running mean of observed item sizes.
    _state["n"] += 1
    n = _state["n"]
    _state["mean"] += (item - _state["mean"]) / n
    m = _state["mean"]

    residual = bins - item  # remaining capacity after placing the item here

    # Dominant term: prefer residual near 0 (perfect fill).
    score = -residual.astype(np.float64)

    # Bounded tie-break bonus in [0, 0.9): reward residuals that are "reusable",
    # i.e. at least as large as a typical future item, and penalize tiny leftovers.
    r = residual.astype(np.float64)
    # Smooth reusability: 0 at residual 0, saturating to 1 once residual >= m.
    reus = np.clip(r / max(m, 1.0), 0.0, 1.0)
    score += 0.9 * reus

    return score
# EVOLVE-BLOCK-END

