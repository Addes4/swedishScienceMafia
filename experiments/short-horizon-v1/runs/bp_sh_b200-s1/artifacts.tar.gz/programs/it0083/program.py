# EVOLVE-BLOCK-START
"""Score bins with best-fit plus a smooth "reusability" correction.

The primary signal is best-fit (prefer the smallest non-negative residual).
A small smooth term gently prefers residuals that can still host a future item
over residuals stuck in the awkward "dead zone" just above zero.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)  # remaining capacity after placing here

    # Primary: best-fit (tightest packing). Larger residual -> lower score.
    score = -residual

    # Secondary: soft penalty for residues stranded in the unusable dead zone.
    # Residual near 0 wastes almost a whole bin; residual around 20-40 can still
    # host a typical item (mean ~40 distribution). Penalize only the small zone,
    # decaying smoothly, in a way that never overwhelms the best-fit ordering
    # except among near-identical residuals.
    dead = np.exp(-residual / 8.0)  # ~1 at residual 0, ~0.08 at 20
    score -= 6.0 * dead

    return score
# EVOLVE-BLOCK-END
