# EVOLVE-BLOCK-START
"""Score bins by expected reusability of the leftover capacity.

Items are drawn from one fixed (Weibull-shaped, mean ~40) distribution.  For a
candidate bin the placement leaves residual r = bin_capacity - item.  We prefer
the bin whose residual is *most likely to be exactly filled by some later item*,
which directly minimises the number of wasted residual fragments without needing
any future information.  Residual 0 (perfect fill) is always best; otherwise the
score is proportional to the online-estimated probability that a future item has
size == r, with a mild preference for smaller residuals to keep the packing
tight (best-fit flavour).

State kept between calls within a stream: a running histogram of observed item
sizes, used to estimate P(item == r).
"""
import numpy as np

_MAX = 101
_HIST = np.zeros(_MAX, dtype=np.float64)
_TOTAL = 0.0


def _prob(size):
    """Estimated probability that an item of exactly `size` will arrive."""
    if size <= 0 or size >= _MAX:
        return 0.0
    if _TOTAL <= 0.0:
        # No data yet: fall back to a flat prior over feasible sizes.
        return 1.0 / 100.0
    return _HIST[size] / _TOTAL


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    global _TOTAL

    # Update running histogram with the incoming item.
    if 1 <= item < _MAX:
        _HIST[item] += 1.0
        _TOTAL += 1.0

    residual = bins - item  # capacity left if placed here (>= 0 by construction)

    # Base: prefer tight fits -> negative residual scaled by a small weight so it
    # acts as a secondary signal, not dominating the reuse probability.
    score = -0.01 * residual.astype(np.float64)

    # Reuse bonus: how likely is a later item to exactly fill this residual?
    # Vectorised probability lookup over the candidate residuals.
    r = residual.astype(np.int64)
    valid = (r > 0) & (r < _MAX)
    prob = np.zeros(r.shape, dtype=np.float64)
    if valid.any():
        if _TOTAL > 0.0:
            prob[valid] = _HIST[r[valid]] / _TOTAL
        else:
            prob[valid] = 1.0 / 100.0
    score += 50.0 * prob  # reward residuals that are plausible future item sizes

    # Perfect fit is always the best outcome.
    score += np.where(r == 0, 100.0, 0.0)

    return score
# EVOLVE-BLOCK-END
