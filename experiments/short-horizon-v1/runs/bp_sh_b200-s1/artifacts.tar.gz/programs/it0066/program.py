# EVOLVE-BLOCK-START
"""Best-fit dominant ranking with a small bounded bonus for near-exact fills.

Pure best-fit (most negative residual) is the strongest known online rule here.
Broad dead-zone thresholds over-constrain it, so we keep best-fit primary and add
only a small, strictly sub-unit bonus for residuals that are exactly 0 (perfect
fill) or very close, breaking near-ties toward tighter packing without ever
overriding a genuinely better fit.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary term: strict best-fit. More negative residual => higher score.
    score = -residual.astype(np.float64)

    # Small bounded bonus strictly smaller than one unit of residual, so it can
    # only break ties among equal residuals (never override a tighter fit).
    exact = (residual == 0)
    score += np.where(exact, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
