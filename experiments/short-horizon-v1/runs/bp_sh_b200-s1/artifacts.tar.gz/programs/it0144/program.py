# EVOLVE-BLOCK-START
"""Online best-fit with a distribution-aware term: minimize residual (tight
best-fit), but gently reward residuals that the observed item-size distribution
is likely to fill exactly, using a smoothed online histogram."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity if placed here

    # Primary: tight best-fit (smaller residual preferred).
    score = -residual.astype(np.float64)

    # Distribution-aware term: estimate P(a future item exactly equals residual).
    # Use a lightly smoothed histogram so rare sizes are not zeroed out.
    if _COUNT > 20:
        total = _HIST.sum()
        if total > 0:
            probs = np.zeros(residual.shape, dtype=np.float64)
            valid = (residual >= 1) & (residual <= 100)
            idx = np.clip(np.where(valid, residual, 0).astype(np.int64), 0, 100)
            smoothed = _HIST[idx] + 0.5
            probs = np.where(valid, smoothed / (total + 0.5 * 101), 0.0)
            # gentle nudge; do not dominate best-fit's integer steps
            score += probs * 4.0

    # Mild preference for opening a fresh bin over stranding a small residual.
    score -= np.where((residual > 0) & (residual < 15), 2.0, 0.0)

    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
