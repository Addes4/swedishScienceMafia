# EVOLVE-BLOCK-START
"""Strict best-fit, with an epsilon bonus for residuals that are reusable.

The dominant term is -residual (tightest fit). A very small additive term
rewards residual capacity that can plausibly host a future item, so that when
two candidate bins have nearly identical residual the one with more room wins.
The coefficient is tiny so best-fit ordering is preserved.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: tightest fit (most negative residual = best fill).
    score = -residual.astype(np.float64)

    # Secondary (tiny): prefer residuals that are not stranded. Among residuals
    # within a small band, giving more room a gentle nudge helps future fits,
    # while the small coefficient keeps best-fit ordering essentially intact.
    score += 0.001 * residual.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

