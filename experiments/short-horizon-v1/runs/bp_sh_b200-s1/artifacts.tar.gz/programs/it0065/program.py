# EVOLVE-BLOCK-START
"""Subset-Sum style fill rule: best-fit as primary term, with a bonus for
placements whose resulting residual is fillable by a recently seen item size."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: prefer tightest fit (smallest positive residual).
    score = -residual.astype(np.float64)

    # Secondary: strongly reward a residual of exactly 0 (perfect fill),
    # and modestly reward a residual that exactly equals a recently seen item size
    # (so the bin is likely refillable exactly), which is a cheap subset-sum proxy.
    seen = priority.seen
    seen[item] += 1

    perfect = residual == 0
    score += np.where(perfect, 5.0, 0.0)

    # Bonus for residuals matching a frequently observed size, scaled below 1 unit
    # so it only breaks ties among near-equal residual gaps.
    match = np.where((residual > 0) & (residual <= 100), seen[residual.clip(0, 100)], 0)
    score += np.minimum(match, 3) * 0.3

    return score


priority.seen = np.zeros(101, dtype=np.float64)
# EVOLVE-BLOCK-END
