# EVOLVE-BLOCK-START
"""Best-fit packing with a data-driven residual-match bonus.

Primary rule: tight best-fit (prefer the smallest non-negative residual).
Secondary rule: reward residuals whose value is a common recent item size,
since such leftover space is likely to be exactly filled by a future item.
The bonus is scaled by the online-estimated probability of that item size
and is bounded so it only breaks near-ties in favor of tighter best-fit.
"""
import numpy as np

# Module-level online histogram of item sizes (1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Rank bins; the item goes to the highest score (first on ties)."""
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity if placed here
    score = -residual.astype(np.float64)  # tight best-fit primary term

    # ---- Residual-match bonus: reward residuals equal to common item sizes ----
    if _COUNT > 20:
        total = _HIST.sum()
        if total > 0:
            valid = (residual >= 1) & (residual <= 100)
            idx = np.clip(np.where(valid, residual, 0), 0, 100).astype(np.int64)
            prob = np.where(valid, _HIST[idx] / total, 0.0)
            # A perfect-fill residual (prob close to the max single-size mass)
            # can outweigh up to ~1 unit of extra residual.
            score += prob * 60.0

    # ---- Record this item ----
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
