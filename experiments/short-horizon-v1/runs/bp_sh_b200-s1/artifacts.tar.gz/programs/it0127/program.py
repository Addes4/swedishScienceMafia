# EVOLVE-BLOCK-START
"""Best-fit packing enhanced with an online item-size histogram that rewards
leaving residuals which are likely to be exactly fillable by a future item."""
import numpy as np

# Module-level state: a coarse histogram of item sizes (1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item here

    # ---- Primary: tight best-fit (residual near 0 is best). ----
    score = -residual.astype(np.float64)

    # ---- Dead-zone penalty: residuals too small to be filled by typical items. ----
    # Use the online distribution's smallest observed item size to decide what
    # counts as "unfillable", instead of a fixed 25.
    if _COUNT > 20:
        nonzero = np.nonzero(_HIST[1:101])[0] + 1
        min_item = int(nonzero[0]) if nonzero.size > 0 else 1
    else:
        min_item = 1
    dead_thresh = max(min_item, 1)
    dead = (residual > 0) & (residual < dead_thresh)
    score -= np.where(dead, 30.0, 0.0)

    # ---- Mild bonus for unused bins. ----
    empty = bins == 100
    score += np.where(empty, 5.0, 0.0)

    # ---- Distribution-aware friendliness bonus ----
    # Reward residuals that a future item could exactly fill, weighted by the
    # chance that such an item actually appears.
    if _COUNT > 20:
        total = _HIST.sum()
        if total > 0:
            valid = residual >= 1
            idx = np.where(valid, residual, 0).astype(np.int64)
            idx = np.clip(idx, 0, 100)
            probs = _HIST[idx] / total
            probs = np.where(valid & (residual <= 100), probs, 0.0)
            score += probs * 3.0

    # ---- Record this item into the histogram ----
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
