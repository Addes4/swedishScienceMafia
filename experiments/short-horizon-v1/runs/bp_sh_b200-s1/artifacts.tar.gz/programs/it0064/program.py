# EVOLVE-BLOCK-START
"""Best-fit with a reuse-aware tie-break learned from recent item sizes.

Primary term keeps classic best-fit dominance (tightest fit wins).  A secondary
term rewards residuals that exactly match item sizes seen recently in the
stream, since such residuals are the most likely to be reused again.
"""
import numpy as np

# running frequency estimate over item sizes 1..100, exponentially weighted
_FREQ = np.zeros(101, dtype=np.float64)
_DECAY = 0.999


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    global _FREQ

    # update running frequency of item sizes (decay to stay adaptive)
    _FREQ *= _DECAY
    _FREQ[item] += 1.0

    residual = (bins - item).astype(np.float64)

    # primary: tightest fit (most negative residual -> largest score)
    score = -residual

    # secondary: reward residuals that are "reusable", i.e. exactly a size we
    # expect to see again.  Weight by recent frequency, normalized small so it
    # only breaks ties among equal residual gaps.
    reuse = np.zeros_like(residual)
    pos = residual > 0
    if np.any(pos):
        r = residual[pos].astype(np.int64)
        valid = (r >= 0) & (r <= 100)
        w = np.zeros(r.shape, dtype=np.float64)
        w[valid] = _FREQ[r[valid]]
        reuse[pos] = w

    # scale strictly below 1 unit of residual to keep best-fit dominant
    score += np.minimum(reuse * 1e-3, 0.9)

    return score
# EVOLVE-BLOCK-END
