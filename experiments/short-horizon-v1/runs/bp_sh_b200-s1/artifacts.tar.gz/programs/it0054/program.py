# EVOLVE-BLOCK-START
"""Best-fit core with a tiny tie-break that discourages stranding unusable residuals.

Plain best-fit (tightest residual) is hard to beat. Earlier large penalties hurt, so
here the tight residual ordering dominates, and only near-ties (within 0.5 of the
tightest residual) are re-ordered to avoid leaving a very small stranded residual
(0 < residual < item), which is the classic bin-packing wart.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)

    # Base rule: tightest residual wins.
    score = -residual

    # Tiny tie-break: within a half-unit of the best residual, prefer bins whose
    # resulting residual is either 0 (crisp close) or large enough to host another
    # item of roughly this size. Penalize only the small positive "dead" residuals.
    dead = (residual > 0) & (residual < item)
    score -= np.where(dead, 0.25, 0.0)

    return score
# EVOLVE-BLOCK-END
