# EVOLVE-BLOCK-START
"""Best-fit packing with a light, distribution-aware residual-reuse nudge.

Primary signal is plain best-fit (smallest positive residual wins, empty bins
preferred on ties).  A small adaptive bonus rewards residuals that match
frequently-seen item sizes so leftovers tend to be exactly fillable later.
"""
import numpy as np

# Module-level state: a coarse histogram of item sizes (1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0
_MEAN = 40.0


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    global _HIST, _COUNT, _MEAN

    residual = bins - item  # remaining capacity after placing the item here

    # ---- Primary: tight best-fit (residual near 0 is best). ----
    score = -residual.astype(np.float64)

    # ---- Prefer unused bins over equally-tight used bins. ----
    empty = bins == 100
    score += np.where(empty, 4.0, 0.0)

    # ---- Light distribution-aware residual-reuse bonus. ----
    if _COUNT > 20:
        total = _HIST.sum()
        if total > 0:
            valid = (residual >= 1) & (residual <= 100)
            idx = np.where(valid, residual, 0).astype(np.int64)
            probs = _HIST[idx] / total
            probs = np.where(valid, probs, 0.0)
            # weight kept tiny so best-fit's unit steps dominate
            score += probs * (_MEAN / 40.0) * 1.5

    # ---- Record this item into the histogram ----
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1
        _MEAN += (item - _MEAN) / _COUNT

    return score
# EVOLVE-BLOCK-END
