# EVOLVE-BLOCK-START
"""Best-fit with a lightweight reusability tie-breaker.

The base ranking is classic best-fit (smallest residual wins). We only perturb
scores in a narrow band so it reshuffles genuine near-ties: exact fits are
maximally favored, and residuals sitting in the tiny dead zone just above zero
(too small to be useful for a future ~40-sized item) are slightly demoted in
favor of a residual close to the distribution's typical item size.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Base: best-fit (smallest residual is best).
    score = -residual.astype(np.float64)

    # Exact fits are strongly preferred.
    score += np.where(residual == 0, 5.0, 0.0)

    # Mild dead-zone demotion for tiny nonzero residuals, and a mild bonus for
    # residuals near a typical item size (~40) that are likely reusable later.
    tiny = (residual > 0) & (residual < 20)
    score -= np.where(tiny, 2.0, 0.0)

    near_typical = (residual >= 30) & (residual <= 55)
    score += np.where(near_typical, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
