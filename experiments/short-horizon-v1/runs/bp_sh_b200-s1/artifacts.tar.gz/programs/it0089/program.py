# EVOLVE-BLOCK-START
"""Best-fit primary, plus a lightweight online bonus for residuals that look
like plausible future item sizes (so leftovers are more likely reusable)."""
import numpy as np

# Module-level state: an online histogram over item sizes 1..100.
_COUNTS = np.ones(101, dtype=np.float64)  # Laplace smoothing
_TOTAL = 101.0


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _TOTAL

    # Update online histogram with the arriving item (before ranking).
    if 1 <= item <= 100:
        _COUNTS[item] += 1.0
        _TOTAL += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Primary signal: pure best-fit (smaller residual is better).
    score = -residual.astype(np.float64)

    # Secondary signal: small bonus for residuals that are plausible item sizes,
    # since a leftover equal to a common item size can host a future item exactly.
    r = residual.astype(np.int64)
    probs = np.zeros(r.shape, dtype=np.float64)
    valid = (r >= 1) & (r <= 100)
    if np.any(valid):
        probs[valid] = _COUNTS[r[valid]] / _TOTAL
    # Scale small enough to never overturn strict best-fit ordering.
    score += 2.0 * probs

    return score
# EVOLVE-BLOCK-END
