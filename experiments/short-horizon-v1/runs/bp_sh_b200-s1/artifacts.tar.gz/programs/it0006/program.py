# EVOLVE-BLOCK-START
"""Size-aware hybrid: first-fit for small items, best-fit for large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item
    if item <= 33:
        # Small item: prefer low-index partial bins (first fit) so that
        # nearly-full bins are finished off and total bins stay low.
        # Score by -index equivalent: prefer smaller bin index.
        n = bins.shape[0]
        idx = np.arange(n)
        # Avoid empty bins (residual 100) so small items don't open new bins.
        empty_penalty = np.where(bins >= 100, -1e6, 0)
        return -idx + empty_penalty
    else:
        # Larger item: best fit, tightest residual.
        return -residual
# EVOLVE-BLOCK-END

