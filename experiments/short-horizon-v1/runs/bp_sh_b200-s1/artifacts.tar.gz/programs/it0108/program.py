# EVOLVE-BLOCK-START
"""Best-fit with a mild, smooth preference for reusable mid-size residuals.

Base rule is tight best-fit (minimize residual). We add a small smooth bonus
for residuals that are themselves plausible item sizes (near the distribution
mean ~40), since such residuals can be filled later, while not distorting the
ordering enough to hurt tight packing.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)  # capacity left after placing here

    # Base: prefer small residual (best fit).
    score = -residual

    # Mild smooth bonus: residuals that are themselves likely item sizes (~40)
    # can be reused by a future item, so slightly favor them.
    # Gaussian-shaped bonus centered at 40, modest amplitude, nonzero only for
    # positive residuals.
    bonus = 3.0 * np.exp(-((residual - 40.0) ** 2) / (2.0 * 20.0 ** 2))
    bonus = np.where(residual > 0, bonus, 0.0)
    score += bonus

    return score
# EVOLVE-BLOCK-END
