# EVOLVE-BLOCK-START
"""Score bins to avoid stranding small unusable residuals, adapting the
"dead zone" width to the smallest item size actually observed."""
import numpy as np

_min_seen = 100


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _min_seen
    if item < _min_seen:
        _min_seen = item

    residual = bins - item  # remaining capacity after placing the item here

    # Prefer residual near 0 (perfect fill), strongly.
    score = -residual.astype(np.float64)

    # Dead-zone penalty: a positive residual too small to fit any item we have
    # actually seen so far is (near-)stranded waste, so penalize it hard.
    # Residuals at or above the smallest seen item remain reusable and are not
    # penalized. This adapts to the real item distribution rather than a guess.
    dead = (residual > 0) & (residual < _min_seen)
    score -= np.where(dead, 30.0, 0.0)

    return score
# EVOLVE-BLOCK-END

