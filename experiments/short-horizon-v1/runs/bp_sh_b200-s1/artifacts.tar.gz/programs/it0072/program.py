# EVOLVE-BLOCK-START
"""Best-fit with a smooth, bounded dead-zone penalty for tiny unusable residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)  # remaining capacity after placing here

    # Strict best-fit primary signal.
    score = -residual

    # Smooth dead-zone penalty: residuals in (0, 25] are less reusable.
    # Use a bounded, continuously-decreasing penalty so it never dwarfs the
    # best-fit ordering (kept strictly below ~1 residual unit at the boundary).
    # Penalty peaks for near-zero residuals and fades to 0 at residual == 25.
    dead = (residual > 0) & (residual < 25)
    t = np.clip(residual / 25.0, 0.0, 1.0)   # 0 at residual 0, 1 at 25
    penalty = np.where(dead, 0.9 * (1.0 - t) ** 2, 0.0)
    score -= penalty

    return score
# EVOLVE-BLOCK-END

