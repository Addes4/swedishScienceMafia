# EVOLVE-BLOCK-START
"""Score bins to avoid stranding small unusable residuals, using a running
estimate of the item size distribution to calibrate the dead-zone penalty."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Prefer residual near 0 (perfect fill), strongly.
    score = -residual.astype(np.float64)

    # Dead-zone penalty: a small positive residual that is unlikely to fit
    # another item wastes nearly a whole bin.  We penalize residuals below a
    # fraction of a typical item size, with the strongest penalty just above 0
    # and fading out as the residual approaches the typical item size.
    # Typical item size ~ 40 for the given distribution; use ~mean as reference.
    ref = 40.0
    pos = residual > 0
    # penalty magnitude: higher for tiny residuals, lower near the reference size
    frac = np.clip(residual / ref, 0.0, 1.0)
    penalty = np.where(pos, 30.0 * (1.0 - frac), 0.0)
    score -= penalty

    return score
# EVOLVE-BLOCK-END

