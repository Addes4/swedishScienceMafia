# EVOLVE-BLOCK-START
"""Best-fit packing enhanced with an online item-size histogram that rewards
leaving residuals which are likely to be exactly fillable by a future item."""
import numpy as np

# Module-level state: histogram of item sizes (1..100) and running mean.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item here

    # ---- Primary: tight best-fit (residual near 0 is best). ----
    score = -residual.astype(np.float64)

    # ---- Adaptive dead-zone penalty ----
    # Among residuals in (0, 25), penalize those that are *unlikely* to be a
    # future item size (low histogram mass), scaled by observed distribution.
    dead = (residual > 0) & (residual < 25)
    if _COUNT > 20:
        total = _HIST.sum()
        if total > 0:
            idx = np.clip(residual, 0, 100).astype(np.int64)
            mass = _HIST[idx] / total  # probability residual is an item size
            # Penalty strongest when mass is ~0, fades to 0 as mass rises.
            penalty = np.where(mass < 0.02, 30.0 * (1.0 - mass / 0.02), 0.0)
            score -= np.where(dead, penalty, 0.0)
        else:
            score -= np.where(dead, 30.0, 0.0)
    else:
        score -= np.where(dead, 30.0, 0.0)

    # ---- Mild bonus for unused bins. ----
    empty = bins == 100
    score += np.where(empty, 5.0, 0.0)

    # ---- Distribution-aware friendliness bonus ----
    if _COUNT > 20:
        total = _HIST.sum()
        if total > 0:
            valid = residual >= 1
            idx = np.clip(np.where(valid, residual, 0), 0, 100).astype(np.int64)
            probs = _HIST[idx] / total
            probs = np.where(valid & (residual <= 100), probs, 0.0)
            score += probs * 3.0

    # ---- Record this item into the histogram ----
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
