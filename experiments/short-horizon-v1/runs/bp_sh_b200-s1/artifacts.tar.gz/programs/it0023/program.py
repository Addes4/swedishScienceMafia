# EVOLVE-BLOCK-START
"""Best fit with exact-fit priority and residual tie-breaking."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    waste = bins - item
    # Exact fits get a strong bonus so they are always chosen.
    exact = (waste == 0).astype(np.float64)
    # Base: best fit (smaller waste is better).
    score = -waste.astype(np.float64)
    # Small tie-break: among equal waste prefer larger residual (leave tight leftovers
    # intact so they can combine with future matching items).
    score += 1e-3 * bins.astype(np.float64)
    # Exact-fit bonus dominates the tie-break.
    score += 1e6 * exact
    return score
# EVOLVE-BLOCK-END

