# EVOLVE-BLOCK-START
"""Online harmonic-style bin choice: keep each size class in its own tight band."""
import numpy as np


def _class_of(item):
    if item <= 20:
        return 1
    if item <= 40:
        return 2
    if item <= 60:
        return 3
    if item <= 80:
        return 4
    return 5


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins
    # Harmonic-fit thresholds: a class-c item prefers bins with small residual.
    # Residual after placement should stay in the "band" for that class so future
    # items of the same class can still fit; use the fullest bin whose post-fit
    # residual stays >= 0 and is small.
    c = _class_of(item)
    # Upper bound on residual we'd like to keep for reuse by items of this class.
    band = {1: 19, 2: 39, 3: 59, 4: 79, 5: 99}[c]

    post = rem - item  # residual after placement (>=0 for bins shown)
    # Prefer bins whose post residual is < leftover threshold for the class,
    # i.e. tightly packed but not overfilled; among those, smallest post.
    # Encode: main term = -(post) for bins with post < band, else push them
    # down with a large constant penalty.
    fits_band = post < band
    score = -(post.astype(np.float64))
    score = np.where(fits_band, score, score - 1000.0)
    return score
# EVOLVE-BLOCK-END
