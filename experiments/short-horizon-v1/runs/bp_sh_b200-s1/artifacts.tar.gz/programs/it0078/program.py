# EVOLVE-BLOCK-START
"""Best-fit packing with a narrow, distribution-aware dead-zone penalty.

Strict best-fit (smallest nonnegative residual) is the primary rule. Only
residuals that are too small to hold any plausible future item are penalized,
and the penalty is scaled by how much of the bin is effectively wasted, so we
never strand a nearly-full bin when a tighter fill is available.
"""
import numpy as np

# Online estimate of the smallest item size seen so far (persists per stream).
_MIN_SEEN = [100]
_COUNT = [0]


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item here

    # Track the smallest item size observed (proxy for the unreusable range).
    if item < _MIN_SEEN[0]:
        _MIN_SEEN[0] = item
    _COUNT[0] += 1

    # Primary: prefer the tightest fit.
    score = -residual.astype(np.float64)

    # Dead-zone: residuals below the smallest observed item size can never be
    # reused, so treat a fraction of that stranded capacity as waste.
    # Use a conservative threshold based on the smallest item seen.
    threshold = max(1, min(_MIN_SEEN[0], 12))
    dead = (residual > 0) & (residual < threshold)
    # Penalty scaled by stranded capacity, but bounded so real tight fills win.
    score -= np.where(dead, 0.5 * residual.astype(np.float64) + 5.0, 0.0)

    return score
# EVOLVE-BLOCK-END
