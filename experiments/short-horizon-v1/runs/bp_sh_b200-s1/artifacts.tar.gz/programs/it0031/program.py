# EVOLVE-BLOCK-START
"""Best fit with a mild residual-usability tie-break.

Pure best fit (minimize post-placement residual) is a solid online rule for this
distribution, so keep it as the dominant term.  Break near-ties with a small
bonus for residuals that are either ~0 (nicely closed bin) or close to a typical
future item size (so the leftover space is likely reusable).  A running mean of
seen items gives the typical size without needing to know the distribution.
"""
import numpy as np


_mean = 40.0
_count = 0


def priority(item, bins):
    """Score each bin; highest score wins (first on ties)."""
    global _mean, _count

    # Running estimate of the mean item size (starts at the known prior ~40).
    _count += 1
    _mean += (item - _mean) / _count

    post = bins - item  # residual after placing the item in each bin

    # Dominant term: prefer the tightest fit (smallest post-placement residual).
    # Residuals are integers in [0, 100], so scaling by 100 keeps it dominant.
    score = -post.astype(np.float64)

    # Mild tie-break: favor residuals near 0 or near the typical item size.
    target = _mean
    # distance to the nearer of {0, target}, normalized; smaller is better
    d0 = post.astype(np.float64)
    dt = np.abs(post.astype(np.float64) - target)
    dist = np.minimum(d0, dt)
    score += 0.4 * (1.0 - dist / 100.0)

    return score
# EVOLVE-BLOCK-END

