# EVOLVE-BLOCK-START
"""Best fit with a residual-viability preference tuned to the item distribution."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: prefer tightest fit (smallest residual).
    score = -residual.astype(np.float64)
    # Penalize residuals in the awkward "small but non-zero" zone (1..19): these
    # leave a bin that can rarely accept another item from a mean-40 distribution.
    # A residual of 0 (exact fill) and residuals >= ~40 (viable) are favored.
    awkward = (residual > 0) & (residual < 20)
    score -= 1.5 * awkward.astype(np.float64)
    # Small bonus for keeping a fully empty bin empty when item is small-ish,
    # encouraging using partially filled bins first.
    score -= 0.001 * (bins == 100).astype(np.float64)
    return score
# EVOLVE-BLOCK-END
