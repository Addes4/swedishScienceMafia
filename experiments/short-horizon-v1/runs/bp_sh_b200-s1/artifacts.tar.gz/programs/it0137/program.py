# EVOLVE-BLOCK-START
"""Pure online Best-Fit with a strong reward for exact fills.

Best-Fit (place each item into the bin with the smallest feasible residual)
is the strongest simple online rule for this distribution.  The only
refinement that reliably helps is explicitly preferring an exact fill
(residual 0) over merely small residuals, since a zero residual retires a
bin from future consideration at no waste.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: tight best-fit.  Smaller residual -> higher score.
    score = -residual.astype(np.float64)

    # Strong reward for an exact fill (residual == 0).
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
