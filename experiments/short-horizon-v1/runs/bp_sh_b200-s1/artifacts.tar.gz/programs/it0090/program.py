# EVOLVE-BLOCK-START
"""Tightest-fit packing, with a data-driven dead-zone guard.

We track the smallest item size observed so far in the stream.  Any residual
strictly below that minimum can *never* be reused (no future item is smaller),
so leaving such a residual is pure waste.  In that case we mildly prefer a
residual that is still usable.  Everywhere else we follow pure best-fit
(smallest residual wins), which the earlier experiments showed is the dominant
signal.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit primary signal: smaller residual is better.
    score = -residual.astype(np.float64)

    # Dead-zone guard driven by the smallest item seen so far.
    min_seen = _min_seen(item)
    if min_seen > 1:
        # Residuals in [0, min_seen) other than 0 cannot host any future item.
        dead = (residual > 0) & (residual < min_seen)
        score -= np.where(dead, 15.0, 0.0)

    return score


_MIN_SEEN = [100]


def _min_seen(item):
    """Update and return the smallest item size seen so far."""
    if item < _MIN_SEEN[0]:
        _MIN_SEEN[0] = item
    return _MIN_SEEN[0]
# EVOLVE-BLOCK-END
