# EVOLVE-BLOCK-START
"""Best-fit bin packing with an online-adaptive dead-zone penalty.

The core rule is tightest-fit: prefer the bin whose residual after placing the
item is smallest (perfect fill first).  The risk of pure best-fit is that it can
create tiny, unusable residuals that strand capacity.  We discourage such
residuals, but instead of a fixed threshold we adapt the threshold online to the
observed item sizes: a residual is "dead" if it is too small to hold even a
small but plausible future item.  The threshold is estimated from the running
minimum / low quantile of items seen so far, so it tightens as small items are
observed and widens when only large items have appeared.
"""
import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.min_size = 100

    def update(self, item):
        self.count += 1
        if item < self.min_size:
            self.min_size = item


_state = _State()


def priority(item, bins):
    """Rank bins; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # capacity left after placing the item here

    _state.update(item)

    # Adaptive dead zone: residuals below the smallest item seen so far can
    # never be reused, so they are strictly worse than any usable residual.
    # We also treat residuals below a small fraction of that minimum as
    # effectively dead, to avoid off-by-one stranding.
    dead_threshold = max(1, _state.min_size - 1)

    score = -residual.astype(np.float64)

    # Strong, but only strong enough to dominate residual differences among
    # dead-zone candidates; exact best-fit still wins outside the dead zone.
    dead = (residual > 0) & (residual <= dead_threshold)
    score -= np.where(dead, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
