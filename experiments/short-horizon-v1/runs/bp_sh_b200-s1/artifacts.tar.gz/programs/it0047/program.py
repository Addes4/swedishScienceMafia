# EVOLVE-BLOCK-START
"""Best-fit packing with a mild preference against opening fresh bins and a
reward for exact closures."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)

    # Core: tightest fit (best fit). Larger score = better.
    score = -residual

    # Reward exact closures so a bin that becomes exactly full is chosen.
    score += np.where(residual == 0, 1.0, 0.0)

    # Mildly discourage opening a brand-new bin (remaining capacity == 100) when a
    # used bin offers a comparable fit, since fresh bins cannot be "closed" yet.
    score -= np.where(bins == 100, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END
