# EVOLVE-BLOCK-START
"""Best-fit primary rule with a sub-unit dead-zone nudge.

The item goes to the bin whose remaining capacity after placement (residual)
is smallest -- classic best-fit, which is near-optimal for this item
distribution. To avoid the pathology where two bins have residuals differing
by exactly 1 but the larger one is in the 'dead zone' (too little left to be
reused), we add a *fractional* nudge of less than 1 so that best-fit ordering
by integer residual is never reversed, yet among residuals differing by 0 we
can break ties favourably.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: prefer the smallest residual (tightest fit). Integer residuals
    # differ by at least 1, so a sub-unit secondary term cannot invert the
    # primary ordering.
    score = -residual.astype(np.float64)

    # Secondary, strictly sub-unit: mildly favor residuals just *outside* the
    # dead zone over residuals just inside it, without changing best-fit order
    # between bins whose residuals differ by >= 1.
    dead = (residual > 0) & (residual < 15)
    score += np.where(dead, -0.25, 0.0)

    return score
# EVOLVE-BLOCK-END

