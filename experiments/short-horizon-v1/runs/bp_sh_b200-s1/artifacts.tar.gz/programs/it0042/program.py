# EVOLVE-BLOCK-START
"""Pure best-fit: pick the bin with the smallest residual (tightest fit).

Ties go to the first such bin, which is the earliest bin index. This is the
standard BFD-style online rule and needs no tuning.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here
    # Prefer residual near 0 (tightest fit). Highest score -> smallest residual.
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
