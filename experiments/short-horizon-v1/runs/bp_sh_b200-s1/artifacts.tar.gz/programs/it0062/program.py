# EVOLVE-BLOCK-START
"""Best-fit packing with a stream-learned "reuse" bonus.

Primary term: strong best-fit (prefer smallest resulting residual).
Secondary term: a small bonus when the resulting residual equals a size
recently seen in the stream, since that residual is likely to be fillable
again by an item of that size. This is learned online from past items and
uses real observed sizes rather than an arbitrary dead-zone threshold.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    state = priority.state
    residual = bins - item  # remaining capacity after placing the item here

    # Strong primary: prefer the tightest fit (smallest positive/zero residual).
    score = -residual.astype(np.float64)

    # Small bonus for residuals matching a recently observed item size,
    # so the resulting gap is likely to be filled exactly later.
    if state["count"] > 0:
        # recent window of observed item sizes
        hist = state["recent"]
        # count matches of each residual among recent sizes
        # residual range is 0..100
        match = np.zeros(residual.shape, dtype=np.float64)
        # use a lookup of recent sizes for speed
        seen = np.zeros(101, dtype=np.float64)
        for s in hist:
            seen[s] += 1.0
        valid = (residual >= 0) & (residual <= 100)
        idx = np.clip(residual, 0, 100).astype(np.int64)
        match = np.where(valid, seen[idx], 0.0)
        # bonus scaled well below the residual gap (1.0) so ordering by
        # tightest fit is preserved except for near-ties
        score += 0.5 * np.log1p(match) * 0.1

    # update state with this item
    state["count"] += 1
    state["recent"].append(int(item))
    if len(state["recent"]) > 200:
        state["recent"].pop(0)

    return score


priority.state = {"count": 0, "recent": []}
# EVOLVE-BLOCK-END
