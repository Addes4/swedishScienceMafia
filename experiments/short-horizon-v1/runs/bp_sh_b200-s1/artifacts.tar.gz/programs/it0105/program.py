# EVOLVE-BLOCK-START
"""Pure best-fit with a tiny lexicographic bias toward fuller bins on near-ties.

The dominant term is -residual (tightest fit wins). A very small secondary term
rewards bins whose current remaining capacity is smaller, so that when two bins
give nearly the same residual the item prefers the fuller bin, preserving roomy
bins for the larger future items typical of a mean-40 Weibull distribution.
This is a standard least-remaining-space refinement and avoids any hard-coded
dead zone that could distort the primary best-fit ordering.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: tightest fit (smallest residual) wins.
    score = -residual.astype(np.float64)

    # Secondary (tiny): prefer the fuller bin, so roomy bins stay available.
    score -= 1e-3 * bins.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

