# EVOLVE-BLOCK-START
"""Best-fit packing with a nonlinear tightness reward and a mild preference
to open a fresh bin rather than strand a tiny residual in a used bin."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: tight best-fit (residual near 0 is best), with a nonlinear
    # bonus that rewards near-exact fills (small squared leftover).
    r = residual.astype(np.float64)
    score = -r - 0.05 * r * r

    # Dead-zone penalty: residuals in (1, 25) are likely to be stranded.
    dead = (residual > 1) & (residual < 25)
    score -= np.where(dead, 20.0, 0.0)

    # Mild bonus for unused bins (capacity 100) so that leaving a sliver in a
    # used bin is discouraged unless the residual is genuinely tight.
    empty = bins == 100
    score += np.where(empty, 5.0, 0.0)

    return score
# EVOLVE-BLOCK-END

