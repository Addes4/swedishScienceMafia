# EVOLVE-BLOCK-START
"""Adaptive residual scoring: prefer exact fills, and avoid leaving residuals that
are awkwardly sized relative to the observed item distribution."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Base: prefer the tightest fit (best-fit).
    score = -residual.astype(np.float64)

    # Penalize the awkward middle band: a residual that is small but not usable
    # enough to hold a typical next item wastes a bin. Use a smooth penalty that
    # grows as residual decreases below the running mean item size.
    # Estimate a reference from observed items via a simple exponential signal
    # stored on the function object.
    ref = getattr(priority, "_mean", 40.0)
    priority._mean = 0.95 * ref + 0.05 * float(item)

    # Residual near zero is good; residual >= ref is fine; small positive residual
    # below ref is bad. Penalty peaks around small residuals.
    r = residual.astype(np.float64)
    band = (r > 0) & (r < ref)
    penalty = np.where(band, (ref - r), 0.0)
    # Scale down so best-fit remains dominant for large differences.
    score -= 0.5 * penalty

    return score
# EVOLVE-BLOCK-END

