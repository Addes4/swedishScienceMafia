# EVOLVE-BLOCK-START
"""Best-fit packing with a light penalty only for truly unusable tiny slivers."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Base: prefer the tightest fit (smallest residual), exact best-fit.
    score = -residual.astype(np.float64)

    # Only strongly discourage residuals that are almost never reusable
    # (a tiny nonzero sliver wastes nearly a whole bin). Keep this narrow
    # so the best-fit ordering is otherwise preserved.
    dead = (residual > 0) & (residual < 10)
    score -= np.where(dead, 40.0, 0.0)

    return score
# EVOLVE-BLOCK-END
