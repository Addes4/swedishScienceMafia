# EVOLVE-BLOCK-START
"""Score bins with best-fit plus a smooth penalty on small, hard-to-reuse residuals.

Items arrive online; average size ~40, bins hold 100. Pure best-fit (minimize residual)
is the strong baseline, but it can strand tiny unusable slivers. We add a smooth,
monotonically decreasing penalty as the post-placement residual grows from 0 toward a
reusable mid-size (~40), so a residual that can host a future typical item is preferred
over a tiny sliver, while exact fills (residual 0) are still favored.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Base: strong preference for small residual (tight best-fit).
    score = -residual.astype(np.float64)

    # Smooth dead-zone penalty. For residual r in (0, R], the penalty decays from
    # P_MAX at r=1 down to 0 at r=R. Larger residuals are progressively more likely
    # to accept a future item, so penalize small ones more.
    R = 40.0
    P_MAX = 35.0
    r = residual.astype(np.float64)
    in_zone = (r > 0) & (r <= R)
    # Linear decay from P_MAX (at r=0) to 0 (at r=R).
    frac = np.where(in_zone, 1.0 - r / R, 0.0)
    score -= P_MAX * frac

    return score
# EVOLVE-BLOCK-END
