# EVOLVE-BLOCK-START
"""Quantized best-fit with a coarse dead-zone penalty.

Rank bins primarily by best-fit, but on a coarse residual grid so that bins
with nearly-equal residuals are treated as tied. The dead-zone penalty then
only breaks those coarse ties, avoiding the ordering distortion that hurt
earlier variants.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item here

    # Coarse grid: bins whose residuals fall in the same 5-wide bucket are tied.
    bucket = residual // 5

    # Primary score: smaller bucket is better (tighter fit).
    score = -bucket.astype(np.float64)

    # Dead-zone penalty at coarse granularity: bucket 0 means residual in 1..4
    # (plus exactly 0 is also bucket 0, but a perfect fill should win).
    # Penalize the "small but unusable" residual buckets mildly.
    perfect = (residual == 0)
    small = (residual > 0) & (residual < 25)
    score -= np.where(small, 1.0, 0.0)
    # Strong reward for a perfect fill within the coarse scheme.
    score += np.where(perfect, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
