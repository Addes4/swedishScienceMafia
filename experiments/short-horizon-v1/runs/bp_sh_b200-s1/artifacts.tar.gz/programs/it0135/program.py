# EVOLVE-BLOCK-START
"""Best-fit packing augmented with an online item-size histogram.

The core rule is tight best-fit (smallest positive residual wins), which is
strong for Weibull-shaped sizes.  On top of it we add a small, correctly
scaled tie-breaker that rewards leaving a residual which a future item could
exactly fill, and lightly penalises tiny residuals that are too small to ever
be reused.
"""
import numpy as np

# Module-level state: histogram of observed item sizes (1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0
# Smallest item size observed so far (initialised conservatively).
_MIN_SIZE = 100


def priority(item, bins):
    global _HIST, _COUNT, _MIN_SIZE

    residual = bins - item  # remaining capacity if the item goes here

    # ---- Primary: tight best-fit (residual closest to 0 from above). ----
    score = -residual.astype(np.float64)

    # ---- Reclaimability bonus from the online histogram. ----
    # Reward residuals that some plausible future item could exactly fill;
    # weight it gently so it only breaks near-ties.
    total = _HIST.sum()
    if _COUNT > 20 and total > 0:
        valid = (residual >= 1) & (residual <= 100)
        idx = np.clip(np.where(valid, residual, 0), 0, 100).astype(np.int64)
        probs = _HIST[idx] / total
        probs = np.where(valid, probs, 0.0)
        score += probs * 2.0

        # ---- Penalty on residuals too small to ever match a future item. ----
        # A leftover below the smallest commonly-seen size is nearly stranded.
        tiny = (residual >= 1) & (residual < _MIN_SIZE) & (residual < 15)
        score -= np.where(tiny, 4.0, 0.0)

    # ---- Mild preference for opening unused bins only if needed. ----
    empty = bins == 100
    score += np.where(empty, 2.0, 0.0)

    # ---- Record this item. ----
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1
        if item < _MIN_SIZE:
            _MIN_SIZE = item

    return score
# EVOLVE-BLOCK-END
