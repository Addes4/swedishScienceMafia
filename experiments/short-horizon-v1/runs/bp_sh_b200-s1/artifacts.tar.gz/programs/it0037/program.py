# EVOLVE-BLOCK-START
"""Best-fit with a smooth, distribution-aware anti-stranding penalty.

Pure best-fit strands bins with small residuals that can't host anything, wasting
nearly a whole bin.  We estimate the typical item size online and penalize a
post-placement residual according to how much "reusable space" it wastes: a tiny
residual that cannot host a typical item is heavily penalized, while residuals
near 0 (perfect fit) or large enough to host typical items are rewarded.
"""
import numpy as np

# running statistics of observed item sizes (module state, reset per stream)
_state = {"n": 0, "sum": 0.0}


def _mean_item():
    n = _state["n"]
    if n <= 0:
        return 40.0
    return _state["sum"] / n


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    residual = bins - item
    res = residual.astype(np.float64)

    # update online mean estimate of item sizes
    _state["n"] += 1
    _state["sum"] += float(item)
    mu = _mean_item()

    # Base preference: best fit (smaller residual is better).
    score = -res

    # Anti-stranding penalty.  A positive residual r is "dead" if it is too small
    # to have a good chance of hosting a future typical item.  Penalize residuals
    # in (0, mu) proportionally to how stranded they are (closer to 0 => more of
    # the residual space is wasted).  Perfect fits are never penalized.
    pos = res > 0
    deadness = np.clip((mu - res) / mu, 0.0, 1.0)   # 1 at r~0, 0 at r>=mu
    score -= np.where(pos, 30.0 * deadness, 0.0)

    return score
# EVOLVE-BLOCK-END
