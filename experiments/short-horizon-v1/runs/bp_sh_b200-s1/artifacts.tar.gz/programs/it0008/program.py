# EVOLVE-BLOCK-START
"""Best fit with a mild reward for keeping usable residual space."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (small residual). Secondary: prefer slightly larger residual
    # among near-ties, scaled small enough not to override the fit ordering.
    return -residual + 0.01 * residual
# EVOLVE-BLOCK-END
