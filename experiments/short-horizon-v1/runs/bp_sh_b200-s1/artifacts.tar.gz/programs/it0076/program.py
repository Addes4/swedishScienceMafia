# EVOLVE-BLOCK-START
"""Best-fit primary ordering with an online-aware residual reuse tie-break.

Primary rule: prefer the tightest fit (smallest nonnegative residual), which is
the classic strong signal. To break near-ties without losing best-fit's benefit,
we add a small sub-unit bonus for residuals that are likely reusable, estimated
from an online histogram of recent item sizes (mean ~40, Weibull-shaped).
"""
import numpy as np

_state = {"count": 0, "sum": 0.0}


def _typical():
    """Estimate a typical upcoming item size (online mean, init to distribution mean)."""
    c = _state["count"]
    if c < 5:
        return 40.0
    return _state["sum"] / c


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    # Update online stats with the arriving item (visible now, no future peeking).
    _state["count"] += 1
    _state["sum"] += item

    residual = (bins - item).astype(np.float64)

    # Strict best-fit: smallest residual dominates (gap of >=1 between distinct
    # integer residuals, so a sub-unit bonus cannot flip a strict preference).
    score = -residual

    # Sub-unit tie-break: favor residuals that can still host a typical small/mid
    # item, avoiding stranded tiny gaps. Reuse value in [0, 1).
    typ = _typical()
    reuse = np.minimum(residual, typ) / (typ + 1.0)
    score += 0.5 * np.where(residual >= 0, reuse, 0.0)

    return score
# EVOLVE-BLOCK-END
