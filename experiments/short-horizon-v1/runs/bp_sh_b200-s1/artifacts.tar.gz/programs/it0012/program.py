# EVOLVE-BLOCK-START
"""Gap-aware best fit: prefer tight fits, but avoid shattering large usable residuals."""
import numpy as np

# Tuned constants for Weibull-shaped sizes with mean ~40 on capacity 100.
_LARGE = 55          # item treated as "large"
_USABLE = 20         # a residual this big is worth preserving for future items
_ALPHA = 1e-9        # tiny index tie-break contribution


def priority(item, bins):
    """Rank bins by gap-aware best fit; the item goes to the highest-scoring bin."""
    residual = bins - item            # remaining capacity after placing the item
    exact = (residual == 0).astype(np.float64)

    if item >= _LARGE:
        # For large items, plain best fit is hard to beat.
        return -residual.astype(np.float64)

    # For small/medium items, best fit, but strongly avoid breaking a large
    # residual (the chosen bin's current residual) into a uselessly small piece.
    current = bins.astype(np.float64)
    shattered = ((current >= _USABLE + item) & (residual < _USABLE)).astype(np.float64)
    # Also avoid consuming the last bit of a nearly-full bin leaving tiny dead space
    # unless it is an exact fill.
    tiny = ((residual > 0) & (residual < 3)).astype(np.float64) * (1.0 - exact)

    score = -residual.astype(np.float64) - 5.0 * shattered - 2.0 * tiny
    # Prefer lower-index bins on near-ties to consolidate partial bins.
    score -= _ALPHA * np.arange(bins.shape[0], dtype=np.float64)
    return score
# EVOLVE-BLOCK-END

