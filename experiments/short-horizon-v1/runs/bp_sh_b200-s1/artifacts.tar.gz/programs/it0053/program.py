# EVOLVE-BLOCK-START
"""Best-fit plus an online distribution-aware residual bonus.

The core is tightest-fit (smallest residual wins).  On top of that we keep a
running estimate of a "typical" item size seen so far in the stream.  A bin
whose residual after placement is at least that typical size can host another
average item later, so it is mildly preferred over a bin left with a smaller
(possibly stranded) residual.  The bonus is calibrated to be smaller than one
unit of residual, so it never overrides a genuinely tighter fit.
"""
import numpy as np

_STATE = {"n": 0, "sum": 0.0}


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item here

    # Running estimate of a typical (mean) item size seen so far.
    s = _STATE
    s["n"] += 1
    s["sum"] += item
    mean_item = s["sum"] / s["n"]

    # Base: tightest fit wins (smallest residual is best).
    score = -residual.astype(np.float64)

    # Mild, sub-unit bonus for residuals that can still host a typical item.
    usable = residual >= mean_item
    score += np.where(usable, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
