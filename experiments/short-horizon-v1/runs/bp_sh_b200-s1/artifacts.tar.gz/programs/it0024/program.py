# EVOLVE-BLOCK-START
"""Score bins by how well their residual matches item + a likely future partner size."""
import numpy as np

_STATE = {"hist": None, "count": 0}


def _update_hist(item, n_bins=101):
    """Maintain a coarse empirical histogram of item sizes seen so far."""
    h = _STATE["hist"]
    if h is None:
        h = np.zeros(n_bins, dtype=np.float64)
        _STATE["hist"] = h
    h[item] += 1.0
    _STATE["count"] += 1


def _mean_size():
    h = _STATE["hist"]
    if h is None or _STATE["count"] < 20:
        return 40.0
    total = h.sum()
    if total <= 0:
        return 40.0
    sizes = np.arange(len(h))
    return float((sizes * h).sum() / total)


def priority(item, bins):
    """Best-fit-like ranking that aligns residuals with common partner sizes."""
    _update_hist(item)

    mean_sz = _mean_size()
    # Expected partner size: choose complement so that item + partner ~ typical residual.
    # We want residual close to a "useful" leftover value. Use the mean size as target.
    target_residual = item + mean_sz

    residual = bins.astype(np.float64)

    # Best fit component: prefer tight fits (small residual - item).
    best_fit = -(residual - item)

    # Alignment component: prefer residuals near target_residual (a leftover that
    # matches a typical upcoming item), which keeps bins reusable.
    align = -np.abs(residual - target_residual) * 0.15

    return best_fit + align
# EVOLVE-BLOCK-END
