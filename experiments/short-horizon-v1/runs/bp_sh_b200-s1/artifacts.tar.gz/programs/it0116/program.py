# EVOLVE-BLOCK-START
"""Score bins to favor residuals that a future item can exactly fill.

Pure best-fit minimizes the immediate residual, but small slivers (just above 0)
are hard to reuse. Rather than penalizing them arbitrarily, we reward residuals
that are "fillable": close to the arriving item size or a multiple of it, since
items are drawn from a Weibull with mean ~40 and are integers. This biases
placement toward creating bins whose leftover space can later be exactly closed.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Base: prefer tight fit (small residual).
    score = -residual.astype(np.float64)

    # Bonus for residuals that look reusable: near a multiple of the item size
    # (so a future item of similar size could exactly fill it), which discourages
    # leaving odd-sized slivers.
    for m in (1, 2):
        target = m * item
        bonus = np.maximum(0.0, 6.0 - 0.5 * np.abs(residual - target))
        score += bonus

    return score
# EVOLVE-BLOCK-END

