# EVOLVE-BLOCK-START
"""Best-fit packing: place each item into the bin where it leaves the least
remaining capacity (tightest fit), which minimizes the number of open bins.
Bins are shown by remaining capacity; we simply prefer the smallest residual,
with a small bonus for using a fresh bin when fits are otherwise comparable."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: tight best-fit (smallest residual is best).
    score = -residual.astype(np.float64)

    # Small bonus for keeping freshly-unused bins available; helps avoid
    # fragmenting many partially-filled bins.
    empty = bins == 100
    score += np.where(empty, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END
