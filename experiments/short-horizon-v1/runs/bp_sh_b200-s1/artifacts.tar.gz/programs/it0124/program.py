# EVOLVE-BLOCK-START
"""Best-fit packing with a dead-zone penalty plus a graded preference for
used bins (proportional to how full they already are) over fresh empty bins."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: tight best-fit (residual near 0 is best).
    score = -residual.astype(np.float64)

    # Dead-zone penalty: residuals in (0, 25) are likely to be stranded.
    dead = (residual > 0) & (residual < 25)
    score -= np.where(dead, 30.0, 0.0)

    # Graded bonus for used bins: the fuller a bin already is, the more we
    # prefer topping it off rather than opening/using a fresh empty bin.
    # Empty bins (remaining 100) get no bonus.
    used = bins < 100
    fill_frac = (100.0 - bins.astype(np.float64)) / 100.0  # 0 for empty, ->1 for full
    score += np.where(used, 5.0 * fill_frac, 0.0)

    return score
# EVOLVE-BLOCK-END
