# EVOLVE-BLOCK-START
"""Best-fit packing with an adaptive reclaimability model.

Primary rule: tight best-fit (small residual is best).
Refinement: rewards residuals that can likely be reclaimed by a future item,
using an online histogram of item sizes, and penalizes residuals too small to
ever be reclaimed (below the smallest observed item size).
"""
import numpy as np

# Module-level state: online histogram of item sizes (1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0
_MIN_ITEM = 100


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _HIST, _COUNT, _MIN_ITEM

    residual = (bins - item).astype(np.float64)  # remaining capacity after placing here

    # ---- Primary: tight best-fit (residual near 0 is best). ----
    score = -residual

    valid = residual >= 1  # after placement there must be positive leftover to reclaim

    # ---- Penalty on residuals too small to ever be reclaimed. ----
    # Any residual below the smallest item seen so far is permanently stranded.
    unreclaimable = valid & (residual < _MIN_ITEM)
    score -= np.where(unreclaimable, 25.0, 0.0)

    # ---- Reclaimability bonus: probability the residual is an exact future item. ----
    if _COUNT > 20:
        total = _HIST.sum()
        if total > 0:
            idx = np.clip(np.where(valid, residual, 0).astype(np.int64), 0, 100)
            probs = _HIST[idx] / total
            probs = np.where(valid & (residual <= 100), probs, 0.0)
            score += probs * 4.0

    # ---- Mild bonus for using a fresh bin (keeps bins openable but not greedy). ----
    empty = bins == 100
    score += np.where(empty, 3.0, 0.0)

    # ---- Record this item into the histogram. ----
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1
        if item < _MIN_ITEM:
            _MIN_ITEM = item

    return score
# EVOLVE-BLOCK-END

