# EVOLVE-BLOCK-START
"""Worst-fit primary ranking with a sub-unit best-fit tie-break.

Best-fit tends to strand tiny unusable residuals inside many partially-filled
bins.  Ranking by largest residual first spreads items more evenly, keeping
bins open and reusable, while the tiny best-fit term (strictly smaller than 1
residual unit) only decides between bins whose residuals are effectively tied.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in order.
    """
    residual = (bins - item).astype(np.float64)

    # Primary: largest residual wins (worst fit spreads load, keeps bins open).
    score = residual

    # Sub-unit tie-break: among effectively-equal residuals prefer tighter fit.
    score -= residual / (residual.max() + 1.0)

    return score
# EVOLVE-BLOCK-END
