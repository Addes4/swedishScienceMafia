# EVOLVE-BLOCK-START
"""Best-fit core, but among bins with residual <= a tolerance, prefer the fullest
bin (largest item) to close bins crisply rather than leaving usable space."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Plain best-fit ordering: smallest residual wins.
    score = -residual.astype(np.float64)

    # Within a small tolerance window above the best achievable residual, prefer
    # the bin with the *largest* pre-placement remaining capacity (fullest bin),
    # which tends to close bins crisper than leaving slivers of space.
    best = residual.min()
    tol = max(1, item // 8)
    in_window = residual <= best + tol
    # tie-break bonus: bigger bins (less remaining) slightly favored
    score += np.where(in_window, -0.5 * residual, 0.0)

    return score
# EVOLVE-BLOCK-END

