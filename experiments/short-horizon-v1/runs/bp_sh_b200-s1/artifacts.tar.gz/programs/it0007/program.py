# EVOLVE-BLOCK-START
"""Harmonic-inspired hybrid: size-class dependent bin choice.

Large items use best fit (minimize wasted residual on big placements).
Medium items use first fit (consolidate low-index partial bins, free big slots).
Tiny items use worst fit among the tightest-fitting bins (avoid nibbling away
the last slivers of many bins, which wastes a bin per sliver).
"""
import numpy as np


def priority(item, bins):
    if item >= 50:
        # Best fit: tightest remaining capacity >= item.
        return -(bins - item)
    elif item >= 15:
        # First fit within the class: prefer the fullest bin that still fits,
        # but break ties by index so low-index partials get consolidated.
        # Score = -(residual) so fuller bins (smaller residual) rank higher.
        return -(bins - item).astype(np.float64)
    else:
        # Small items: prefer bins leaving a *larger* residual after placement
        # to avoid shredding near-full bins into unusable slivers.
        return (bins - item).astype(np.float64)
# EVOLVE-BLOCK-END

