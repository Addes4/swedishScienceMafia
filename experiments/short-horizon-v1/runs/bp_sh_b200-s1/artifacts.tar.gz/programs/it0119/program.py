# EVOLVE-BLOCK-START
"""Best-fit primary ranking, plus a bonus for residuals that match likely
future item sizes, estimated from an online recency-weighted histogram."""
import numpy as np

_CAP = 100.0


class _State:
    def __init__(self):
        # Recency-weighted counts over item sizes 1..100.
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0


_state = _State()


def priority(item, bins):
    st = _state

    # Update online recency-weighted histogram of item sizes.
    decay = 0.995
    st.counts *= decay
    st.total = st.total * decay + 1.0
    st.counts[item] += 1.0

    residual = (bins - item).astype(np.float64)

    # Primary: tightest fit (most negative residual is best).
    score = -residual

    # Bonus: how likely is this exact residual to be filled by a future item?
    # Use the recency-weighted frequency of item sizes, slightly smoothed.
    probs = (st.counts + 0.5) / (st.total + 50.0)

    # For each bin, the residual is a candidate target fill size.
    res_int = residual.astype(np.int64)
    valid = (res_int >= 0) & (res_int <= 100)
    fill_prob = np.zeros_like(residual)
    fill_prob[valid] = probs[res_int[valid]]

    # Also mildly reward larger residuals that can host common items.
    score = score + 8.0 * fill_prob

    return score
# EVOLVE-BLOCK-END

