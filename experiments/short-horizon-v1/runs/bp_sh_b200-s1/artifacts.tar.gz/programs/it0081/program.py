# EVOLVE-BLOCK-START
"""Best-fit with a learned "unreusable residual" penalty.

Strict best-fit (smallest nonnegative residual) usually wastes a whole bin when
it leaves a residual too small to host any future item.  We track the smallest
item size seen so far online and penalize residuals below that threshold, which
are effectively dead capacity, while keeping exact/tight fills winning.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item here

    # Online estimate of the smallest item size likely to arrive.
    # Recover it from module state; default to a conservative small value.
    mn = getattr(priority, "_min_item", 100)
    if item < mn:
        mn = item
        priority._min_item = mn

    score = -residual.astype(np.float64)

    # Residuals that cannot host even the smallest item we have seen are dead
    # capacity; penalize them so a slightly larger, reusable residual wins.
    dead = (residual > 0) & (residual < mn)
    score -= np.where(dead, 50.0, 0.0)

    return score
# EVOLVE-BLOCK-END
