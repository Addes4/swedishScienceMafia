# EVOLVE-BLOCK-START
"""Best-fit with a learned fill-probability tie-breaker.

Primary ranking is tight best-fit (smallest resulting residual). Because many bins
tie or nearly tie, we break ties using an online estimate of the item-size
distribution: a residual is attractive if it is likely to be exactly consumed by a
single future item (high probability mass near that residual). This costs nothing
on tight fits and helps avoid wasting residuals that no future item will fill.
"""
import numpy as np

# Module-level histogram of observed item sizes (persists across calls within a
# stream; the harness resets the module between streams by re-importing/starting
# fresh state, but to be safe we keep it keyed so it self-initializes).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0
_SEEN = 0


def _reset_if_needed():
    global _HIST, _COUNT, _SEEN
    # Heuristic: if we have never seen anything, initialize.
    if _HIST.shape[0] != 101:
        _HIST = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    global _HIST, _COUNT, _SEEN
    _reset_if_needed()

    residual = bins - item  # remaining capacity after placing the item here

    # Update histogram with the arriving item (before scoring is fine).
    _HIST[item] += 1.0
    _SEEN += 1

    # Fill probability for a residual r: probability that some future single item
    # lands exactly on r (size == r). Use a small smoothing window around r.
    sizes = np.arange(1, 101, dtype=np.float64)
    # Smoothed empirical pmf over item sizes.
    p = _HIST[1:] + 0.5  # add smoothing so no size has zero mass
    p = p / p.sum()

    # Score for each residual we might leave: closeness of residual to a typical
    # item size, weighted by that size's probability. We build a lookup by r.
    # fill_score[r] ~ probability mass concentrated near size r.
    # Use a triangular window of width 3 around each possible size.
    fill_lookup = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        lo = max(1, r - 1)
        hi = min(100, r + 1)
        fill_lookup[r] = p[lo - 1:hi].mean()

    # Primary: best-fit -> prefer smaller residual. Use a strong linear term.
    score = -residual.astype(np.float64)

    # Tie-breaker bonus: a small positive bonus for residuals that a future item
    # is likely to fill exactly (so we don't strand them), and a matching bonus
    # that keeps already-good residue usable.
    r_clip = np.clip(residual, 0, 100)
    bonus = fill_lookup[r_clip.astype(np.int64)]
    # Zero residual (perfect fit) is always best; give it a fixed strong bonus.
    score += 2.0 * bonus
    score += np.where(residual == 0, 5.0, 0.0)

    return score
# EVOLVE-BLOCK-END
