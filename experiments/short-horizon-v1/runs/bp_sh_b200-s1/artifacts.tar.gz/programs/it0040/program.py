# EVOLVE-BLOCK-START
"""Best-fit packing with a strong reward for closing bins (residual 0)
and a graduated penalty for stranded medium residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Base: prefer the smallest residual (tightest fit).
    score = -residual.astype(np.float64)

    # Strongly reward exact fills and near-exact fills: closing a bin cleanly
    # beats leaving a sliver that may never be reused.
    score += np.where(residual == 0, 200.0, 0.0)

    # Penalize residuals that are too small to reliably host another item
    # (stranded slivers). The penalty grows as the residual shrinks toward 0,
    # but never outweighs the exact-fill bonus.
    small = (residual > 0) & (residual < 20)
    score -= np.where(small, (20.0 - residual) * 1.5, 0.0)

    return score
# EVOLVE-BLOCK-END

