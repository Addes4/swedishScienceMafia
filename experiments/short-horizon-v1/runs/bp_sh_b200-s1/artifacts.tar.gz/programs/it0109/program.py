# EVOLVE-BLOCK-START
"""Best-fit with a graduated "sliver" penalty.

Ranking rule: prefer the placement whose residual after the item is smallest
(tight best fit), but strongly discourage leaving a tiny nonzero residual that
is too small to be reused.  The penalty grows as the residual shrinks toward 0,
so a perfect fit (residual 0) beats a sliver, and among slivers a slightly
larger one is preferred.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Base: pure best fit (smaller residual -> higher score).
    score = -residual.astype(np.float64)

    # Graduated sliver penalty: for small positive residuals (< SLIVER_MAX),
    # subtract an amount that grows as the residual shrinks.  A perfect fit
    # (residual 0) takes no penalty, so it still wins.
    SLIVER_MAX = 32.0
    small = (residual > 0) & (residual < SLIVER_MAX)
    # penalty ramps from ~P_MAX at residual=1 down to ~0 at residual=SLIVER_MAX
    pen = (SLIVER_MAX - residual.astype(np.float64)) / SLIVER_MAX * 26.0
    score -= np.where(small, pen, 0.0)

    return score
# EVOLVE-BLOCK-END
