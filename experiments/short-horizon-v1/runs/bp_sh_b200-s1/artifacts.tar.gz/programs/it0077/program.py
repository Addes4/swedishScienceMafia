# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware reuse bonus.

Score = strong best-fit term (prefer small residual) plus a bonus proportional to
the probability (under an online-estimated item-size histogram) that the residual
can still accommodate a future item. This replaces the arbitrary flat dead-zone
with a learned reusability value.
"""
import numpy as np


# Module-level state: empirical histogram of observed item sizes (1..100).
_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    global _total

    # Update online histogram with the arriving item.
    _counts[item] += 1.0
    _total += 1.0

    # Empirical probability that a random future item has size <= r, for each
    # possible residual r in 0..100.
    cdf = np.cumsum(_counts[:101]) / _total  # cdf[r] = P(size <= r)

    residual = bins - item  # remaining capacity after placing this item here
    r = np.clip(residual, 0, 100)

    # Strong best-fit: prefer the smallest residual (perfect fill best).
    score = -residual.astype(np.float64)

    # Reuse bonus: reward residuals that can still host a typical future item.
    # cdf[r] is the fraction of items that fit in residual r; scale it small
    # enough not to override the best-fit ordering but to break ties/steer among
    # residuals that differ by little in best-fit terms.
    score += 5.0 * cdf[r]

    return score
# EVOLVE-BLOCK-END

