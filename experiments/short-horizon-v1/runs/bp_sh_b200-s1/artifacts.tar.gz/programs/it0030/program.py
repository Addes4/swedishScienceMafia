# EVOLVE-BLOCK-START
"""Harmonic-style online bin packing with distribution-aware thresholds."""
import numpy as np

# Harmonic class boundaries (upper bounds of item sizes per class) for capacity 100.
# Classes: (0, 100/3], (100/3, 100/4], (100/4, 100/5], ... plus a final tiny class.
_BOUNDS = np.array([100.0 / k for k in range(3, 21)], dtype=np.float64)  # 33.3 .. 5.0
_CUTS = np.concatenate((_BOUNDS, [0.0]))  # descending thresholds


def _class_of(item):
    """Return index of the harmonic class for this item (0 = largest class)."""
    i = 0
    while i < len(_BOUNDS) and item <= _BOUNDS[i]:
        i += 1
    return i


def priority(item, bins):
    """Rank bins so the item lands at the bottom of its harmonic class bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (in bin order).
    """
    cls = _class_of(item)
    # For the largest class, threshold is 100. For later classes, the resid threshold
    # is the class's lower bound (== upper bound of the next larger class).
    if cls == 0:
        thresh = 100.0
    else:
        thresh = _BOUNDS[cls - 1]

    resid = bins.astype(np.float64)
    # Prefer bins whose residual is below the class threshold: they can absorb the item
    # (resid >= item) while keeping the bin full enough to stay in a useful size range.
    below = resid <= thresh
    # Sort order: bins below threshold first (score by resid descending so we fill the fullest
    # usable bin), then remaining bins by resid ascending (tightest fit as a fallback).
    score = np.where(below, resid + 1000.0, -resid)
    return score
# EVOLVE-BLOCK-END

