# EVOLVE-BLOCK-START
"""Best-fit with an online-learned reusability tie-break.

Primary signal is pure best-fit (prefer residual near 0). Among placements the
primary signal cannot separate by a meaningful margin, we prefer the residual
that is most likely to be usable by a future item, estimated from the online
histogram of sizes seen so far in this stream.
"""
import numpy as np

# Online item-size histogram (size 1..100 -> index 0..100).
_HIST = np.zeros(101, dtype=np.float64)
_SEEN = 0


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    global _HIST, _SEEN

    # Update online estimate of the item-size distribution.
    _SEEN += 1
    decay = 0.99
    if _SEEN == 1:
        _HIST[:] = 0.0
    else:
        _HIST *= decay
    _HIST[item] += 1.0

    total = _HIST.sum()
    if total > 0:
        prob = _HIST / total
    else:
        prob = _HIST  # all zeros

    residual = bins - item  # remaining capacity after placing item
    res = residual.astype(np.float64)

    # Primary: pure best-fit (prefer smallest nonneg residual).
    score = -res

    # Reusability bonus: probability that a future item fits in the residual,
    # i.e. sum of prob over sizes <= residual. Bounded to (<1) so it only
    # breaks ties the primary best-fit term leaves open.
    # Cumulative distribution over sizes 1..residual.
    cdf = np.cumsum(prob)  # cdf[k] = P(size <= k)
    # residual may exceed 100; clamp.
    r_idx = np.clip(res.astype(np.int64), 0, 100)
    fit_prob = cdf[r_idx]
    # Zero out bonus for residual 0 (perfect fill already best).
    fit_prob = np.where(res > 0, fit_prob, 0.0)

    # Scale strictly below 1 residual unit so best-fit remains dominant.
    score += 0.5 * fit_prob

    return score
# EVOLVE-BLOCK-END
