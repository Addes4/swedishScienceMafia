# EVOLVE-BLOCK-START
"""Best fit with a soft penalty against shattering large-residual bins with small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    # Base best-fit score: tightly fitting bins score higher.
    score = -residual
    if item <= 40:
        # Mildly discourage placing small items into large-residual (mostly empty) bins,
        # which would shatter them into leftovers too small to be useful.
        score = score - 0.15 * bins
    return score
# EVOLVE-BLOCK-END

