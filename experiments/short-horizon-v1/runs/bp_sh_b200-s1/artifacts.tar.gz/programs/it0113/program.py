# EVOLVE-BLOCK-START
"""Score bins to avoid stranding tiny unusable residuals (a narrow 'dead zone'
penalty), while still doing tight best-fit packing."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Base: prefer residual near 0 (perfect fill).
    score = -residual.astype(np.float64)

    # Narrow dead-zone penalty: residuals in (0, 16) are too small to be reused
    # well, so shave their score in favor of a slightly larger, reusable residual.
    dead = (residual > 0) & (residual < 16)
    score -= np.where(dead, 20.0, 0.0)

    return score
# EVOLVE-BLOCK-END

