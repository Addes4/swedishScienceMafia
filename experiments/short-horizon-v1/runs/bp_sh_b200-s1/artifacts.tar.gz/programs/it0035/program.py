# EVOLVE-BLOCK-START
"""Best-fit packing with an adaptive dead-zone penalty based on the smallest
item seen so far, so truly unusable residuals are avoided while still-do-able
small gaps are not over-penalized."""
import numpy as np

_min_item = 100  # smallest item seen so far in the current stream


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _min_item
    if item < _min_item:
        _min_item = item

    residual = bins - item  # remaining capacity after placing the item here

    # Base: prefer residual near 0 (perfect fill).
    score = -residual.astype(np.float64)

    # Hard penalty for residuals that cannot fit even the smallest item seen so far:
    # such a bin is effectively stranded.
    dead = (residual > 0) & (residual < _min_item)
    score -= np.where(dead, 50.0, 0.0)

    # Mild penalty for small residuals that can only host a small item, scaled by
    # how unlikely such a future item is; keeps medium residuals (usable by typical
    # items) preferred over marginally-larger gaps.
    small = (residual >= _min_item) & (residual < 25)
    score -= np.where(small, 20.0, 0.0)

    return score
# EVOLVE-BLOCK-END
