# EVOLVE-BLOCK-START
"""Best-fit with an expected-residual-value correction.

The core is tight best-fit (smallest post-placement residual wins).  On top of
that we estimate, from an online histogram of item sizes, the probability that a
post-placement residual can be exactly consumed by some future item, which makes
that residual "useful" rather than stranded waste.
"""
import numpy as np

# Module-level state: histogram of item sizes (1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item here

    # ---- Primary: tight best-fit (smallest residual is best). ----
    score = -residual.astype(np.float64)

    # ---- Reward residuals that are exactly fillable by a common item size ----
    # Estimated probability that a future item equals this residual.
    if _COUNT > 20:
        total = _HIST.sum()
        if total > 0:
            valid = (residual >= 1) & (residual <= 100)
            idx = np.clip(residual, 0, 100).astype(np.int64)
            probs = _HIST[idx] / total
            probs = np.where(valid, probs, 0.0)
            # gentle nudge: comparable to a fraction of one residual unit
            score += probs * 2.0

    # ---- Record this item into the histogram ----
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
