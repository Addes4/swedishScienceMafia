# EVOLVE-BLOCK-START
"""Best-fit with a mild reuse bonus based on an online item-size histogram.

The core rule is tight best-fit (prefer the smallest nonnegative residual).
To reduce stranding of near-empty bins, we add a light bonus when the residual
after placement equals a size that has actually been observed and can plausibly
be filled later, estimated with a small online histogram of arriving item sizes.
This keeps the near-best-fit ordering intact while occasionally favoring a
placement that leaves a reusable gap.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # capacity left after placing the item here
    # Base: tight best-fit (prefer small residual). Use float scoring.
    score = -residual.astype(np.float64)

    # Maintain an online histogram of observed item sizes (state across calls).
    hist = getattr(priority, "hist", None)
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        priority.hist = hist
    if 1 <= item <= 100:
        hist[item] += 1.0

    total = hist.sum()
    if total > 0:
        # Probability that a residual r can host some future item size that has
        # been seen often enough; reward residuals that are common item sizes.
        # Use a smoothed reuse weight: fraction of mass at sizes <= r.
        cum = np.cumsum(hist) / total  # cum[r] = P(next item <= r)
        # Only consider nonzero residuals; exact fills are already best via -r.
        valid = residual > 0
        r_idx = np.clip(residual, 0, 100).astype(np.int64)
        reuse = np.where(valid, cum[r_idx], 0.0)
        # Light bonus so it perturbs but does not override best-fit.
        score += 0.5 * reuse

    return score
# EVOLVE-BLOCK-END
