# EVOLVE-BLOCK-START
"""Best-fit on tight bins; spread small items to avoid shattering large empty bins."""
import numpy as np


def priority(item, bins):
    """Score bins; item goes to the bin with the highest score (first on ties).

    Strategy: the classic best-fit rule (tightest residual) is strong when a bin's
    residual is comparable to the item, but for small items it needlessly breaks up
    large-residual (mostly empty) bins, producing unusable leftovers.  So:
      * For bins with a small residual (<= threshold) we use best-fit, i.e. we
        prefer the tightest fit, which packs leftovers efficiently.
      * For bins with a large residual (> threshold) we invert the preference so
        that small items are pushed to the fullest such bin (still leaving plenty
        of room), preserving the truly empty bins for large future items.
    The threshold is scaled to the item so the rule degenerates to pure best-fit
    for large items, where best-fit is already close to optimal.
    """
    b = np.asarray(bins, dtype=np.float64)
    residual = b - item

    # Threshold on residual: below it, best-fit (tightest first).
    # Above it, we invert so larger residuals rank lower for small items.
    thresh = 0.5 * item + 20.0

    # Small residual region: normal best-fit, score = -residual.
    tight_score = -residual

    # Large residual region: reverse so that the *smallest* large residual wins,
    # i.e. we still fill the fullest large-residual bin first.  Equivalent to a
    # score that decreases with residual but with a big constant so it always
    # ranks below the tight region.
    wide_score = -residual  # same ordering; kept explicit for clarity

    # Combine: tight bins (residual <= thresh) outrank wide bins.
    score = np.where(residual <= thresh, tight_score + 1000.0, wide_score)
    return score
# EVOLVE-BLOCK-END
