# EVOLVE-BLOCK-START
"""Best-fit with a soft anti-stranding correction.

Core: prefer the smallest usable residual (best fit). Additionally, when the
best fit would leave a residual that is small relative to a running estimate of
the item size (i.e. likely to strand a nearly-full bin), shift preference toward
slightly larger residuals that can still host a typical future item.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Running estimate of the typical item size, kept as a bounded scalar
    # attribute on the function object (modules start fresh per stream via
    # harness reload, so this is safe within our constraints).
    n = getattr(priority, "_n", 0)
    mean = getattr(priority, "_mean", 40.0)
    # Update with a simple running mean (bounded state).
    mean = (mean * n + item) / (n + 1)
    priority._n = n + 1
    priority._mean = mean

    score = -residual.astype(np.float64)

    # Dead-zone penalty: residuals too small to host a typical item waste a
    # near-full bin. Penalize proportionally to how far below the running mean
    # they are, and penalize zero-residual (perfect fill) least.
    small = (residual > 0) & (residual < mean)
    penalty = np.where(small, (mean - residual) / mean, 0.0)
    score -= 30.0 * penalty

    return score
# EVOLVE-BLOCK-END
