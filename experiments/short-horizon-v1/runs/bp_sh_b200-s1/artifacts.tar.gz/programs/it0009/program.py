# EVOLVE-BLOCK-START
"""Best fit with a small exact-fill bonus to reduce dead-space leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Base: best fit -> highest priority for smallest residual.
    score = -residual.astype(np.float64)

    # Bonus for exact fills (residual == 0): these close a bin perfectly.
    score += 3.0 * (residual == 0)

    # Slight penalty for residuals that are positive but tiny (hard to use), e.g. 1..3.
    tiny = (residual > 0) & (residual <= 3)
    score -= 0.5 * tiny

    return score
# EVOLVE-BLOCK-END
