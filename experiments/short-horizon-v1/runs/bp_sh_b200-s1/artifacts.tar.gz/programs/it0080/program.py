# EVOLVE-BLOCK-START
"""Best-fit packing with a smooth, online-adaptive penalty for unusable residuals.

The main signal is tightest fit (smallest nonnegative residual -> best). On top of
that we add a penalty for residuals that are unlikely to be reusable by a future
item: bins whose leftover capacity falls in a "dead zone" waste nearly a whole bin.
The dead-zone width is calibrated online to the observed item-size distribution
(via a running mean), so the penalty adapts instead of using a hard-coded constant.
"""
import numpy as np

_STATE = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Rank bins; the item goes to the highest score (first on ties)."""
    residual = bins - item  # remaining capacity after placing the item here

    # Online estimate of the typical item size (running mean, seeded near the
    # distribution mean ~40).
    st = _STATE
    st["sum"] += float(item)
    st["n"] += 1
    mean_item = st["sum"] / st["n"]

    # Dead-zone upper bound: a residual below roughly half of a typical item is
    # unlikely to host another item, so it is close to wasted capacity.
    dead_zone = max(1.0, 0.5 * mean_item)

    score = -residual.astype(np.float64)

    # Smooth penalty: residuals in (0, dead_zone] get penalized, scaled by how
    # much of the dead zone they occupy (smaller residual => larger penalty,
    # since more capacity is effectively stranded).
    r = residual.astype(np.float64)
    in_dead = (r > 0) & (r <= dead_zone)
    score -= np.where(in_dead, (dead_zone - r + 1.0), 0.0)

    return score
# EVOLVE-BLOCK-END
