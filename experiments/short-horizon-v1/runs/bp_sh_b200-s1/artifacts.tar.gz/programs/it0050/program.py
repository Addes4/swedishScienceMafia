# EVOLVE-BLOCK-START
"""Best-fit core with a relative dead-zone: residuals too small to host
another item of the current size are discouraged, but tight fits still win."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Base: prefer tight fit (small residual).
    score = -residual.astype(np.float64)

    # Relative dead zone: a positive residual that cannot host another item of
    # the current typical size is wasteful. Penalize residuals in (0, item).
    dead = (residual > 0) & (residual < item)
    score -= np.where(dead, 0.5 * item, 0.0)

    return score
# EVOLVE-BLOCK-END
