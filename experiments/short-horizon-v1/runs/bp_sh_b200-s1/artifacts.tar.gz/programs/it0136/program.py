# EVOLVE-BLOCK-START
"""Best-fit packing with an online-histogram tie-breaker that rewards residuals
which are likely to be exactly fillable by a future item."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item here

    # ---- Primary: tight best-fit (residual near 0 is best). ----
    score = -residual.astype(np.float64)

    # ---- Distribuion-aware tie-breaker: reward residuals a future item can fill ----
    if _COUNT > 20:
        total = _HIST.sum()
        if total > 0:
            valid = residual >= 1
            idx = np.clip(np.where(valid, residual, 0), 0, 100).astype(np.int64)
            probs = _HIST[idx] / total
            probs = np.where(valid & (residual <= 100), probs, 0.0)
            # gentle nudge, well below best-fit's unit steps
            score += probs * 1.5

    # ---- Record this item into the histogram ----
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
