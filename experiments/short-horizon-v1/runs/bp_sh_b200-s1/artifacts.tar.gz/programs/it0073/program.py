# EVOLVE-BLOCK-START
"""Best-fit primary rule with a small learned "reuse" tie-break.

The item goes to the bin leaving the smallest residual (classic best fit), which is
the dominant, robust signal.  Ties (and near-ties) are broken by a strictly sub-unit
bonus that prefers residuals close to a typical future item size, so we avoid
stranding gaps that no incoming item can fill.
"""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    s = _state
    s["sum"] += item
    s["n"] += 1
    mean_item = s["sum"] / s["n"]

    residual = (bins - item).astype(np.float64)

    # Dominant term: prefer the smallest nonnegative residual (best fit).
    score = -residual

    # Sub-unit tie-break: reward residuals that match a typical next item size,
    # penalize residuals far from it. Bounded to (0, 1) so it never overrides
    # the best-fit ordering.
    gap = np.abs(residual - mean_item)
    bonus = 1.0 / (1.0 + gap)          # in (0, 1]
    score += bonus

    return score
# EVOLVE-BLOCK-END
