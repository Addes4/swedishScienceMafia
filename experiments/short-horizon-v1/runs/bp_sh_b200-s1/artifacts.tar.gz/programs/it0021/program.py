# EVOLVE-BLOCK-START
"""Best fit restricted to a residual window, preserving fresh bins for large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Tightest fit baseline: smaller residual after placing gives higher score.
    score = -(bins - item)

    # Restrict to bins whose residual is "close" to the item (within a window),
    # so small items don't shatter nearly-empty bins needed for future large items.
    # Prefer the best fit among those tight bins; fall back otherwise.
    window = item + 10
    tight = bins <= window
    score = score - np.where(tight, 0.0, 1000.0)
    return score
# EVOLVE-BLOCK-END
