# EVOLVE-BLOCK-START
"""Best-fit packing with an adaptive "fillability" nudge from an online
item-size histogram: prefer the tightest fit, breaking ties toward residuals
that a future item is likely to exactly fill."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    global _HIST, _COUNT

    residual = bins - item  # capacity left if placed here

    # Primary: tight best-fit. Larger score (closer to 0 residual) is better.
    score = -residual.astype(np.float64)

    # Secondary: gentle bonus when the leftover exactly matches a common item
    # size seen so far, i.e. it is likely reclaimable by a future item.
    if _COUNT > 50:
        total = _HIST.sum()
        if total > 0:
            valid = (residual >= 1) & (residual <= 100)
            idx = np.clip(np.where(valid, residual, 0), 0, 100).astype(np.int64)
            probs = np.where(valid, _HIST[idx] / total, 0.0)
            score += probs * 2.0

    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
