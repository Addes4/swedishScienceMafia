# EVOLVE-BLOCK-START
"""Best-fit with a strong, item-size-aware dead-zone penalty.

Pure best-fit packs tightly but strands small unusable residuals. We keep
tightest-fit as the primary objective but subtract a sizeable penalty for
placements that leave a small positive residual too thin to hold a future
item, so slightly larger residuals that can be reused are preferred.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here
    score = -residual.astype(np.float64)

    # A residual that is too small to hold another item wastes nearly a whole bin.
    # The larger the arriving item, the worse it is to strand it in a doomed bin,
    # so scale the dead-zone threshold and penalty by item size.
    threshold = max(20.0, float(item))
    dead = (residual > 0) & (residual < threshold)
    score -= np.where(dead, 45.0, 0.0)

    return score
# EVOLVE-BLOCK-END
