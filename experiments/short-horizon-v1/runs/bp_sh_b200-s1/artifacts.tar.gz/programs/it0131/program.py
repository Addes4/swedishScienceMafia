# EVOLVE-BLOCK-START
"""Best-fit packing with a gentle, adaptive tie-breaker that nudges leftovers
toward sizes a future item is likely to fill exactly, based on an online
item-size histogram.  The primary ranking is tight best-fit (smallest residual);
secondary terms only break near-ties."""
import numpy as np

# Module-level state: coarse online histogram of item sizes (1..100) and min seen.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0
_MINSEEN = 100


def priority(item, bins):
    global _HIST, _COUNT, _MINSEEN

    residual = bins - item  # remaining capacity after placing the item here

    # ---- Primary: tight best-fit (smallest residual best). ----
    score = -residual.astype(np.float64)

    # ---- Gentle tie-breaker: reward residuals that match common item sizes. ----
    if _COUNT > 20:
        total = _HIST.sum()
        if total > 0.0:
            valid = residual >= 1
            idx = np.clip(np.where(valid, residual, 0), 0, 100).astype(np.int64)
            probs = np.where(valid & (residual <= 100), _HIST[idx] / total, 0.0)
            score += probs * 1.0  # comparable to one residual unit at most

    # ---- Penalty for residuals smaller than any item we've seen (truly stranded). ----
    if _COUNT > 20 and _MINSEEN > 1:
        stranded = (residual > 0) & (residual < _MINSEEN)
        score -= np.where(stranded, 0.5, 0.0)

    # ---- Record this item ----
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1
        if item < _MINSEEN:
            _MINSEEN = item

    return score
# EVOLVE-BLOCK-END
