# EVOLVE-BLOCK-START
"""Distribution-aware best fit.

For large items, tight packing (best fit) is nearly optimal. For small items,
leaving a residual close to a typical future item size (~mean of the Weibull
distribution, ~40) keeps the bin reusable, which tends to reduce the number of
bins over a long stream.
"""
import numpy as np

TYPICAL = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    resid_after = bins - item  # >= 0 because bins only contains fitting bins

    if item >= TYPICAL:
        # Best fit: minimize leftover space.
        return -resid_after.astype(np.float64)

    # Small item: prefer bins whose leftover after placement is near TYPICAL,
    # so the remaining gap can still hold a typical future item.
    return -np.abs(resid_after.astype(np.float64) - TYPICAL)
# EVOLVE-BLOCK-END

