# EVOLVE-BLOCK-START
"""Best-fit with an item-scaled dead-zone penalty on stranded small residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: prefer the tightest fit (residual near 0).
    score = -residual.astype(np.float64)

    # Dead-zone penalty. A small positive residual wastes nearly a whole bin
    # because few future items will fit. Large items tend to be followed by
    # items drawn from the same heavy-tailed distribution, so a stranded small
    # residual is worse when the placed item was itself large. Scale the
    # threshold mildly with the item size, capped so it stays a soft nudge.
    thresh = 15.0 + 0.25 * item
    dead = (residual > 0) & (residual < thresh)
    score -= np.where(dead, 30.0, 0.0)

    return score
# EVOLVE-BLOCK-END
