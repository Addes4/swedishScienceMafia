# EVOLVE-BLOCK-START
"""Tight best-fit packing with a mild preference against opening fresh bins.

At each arrival, place the item into the fitting bin with the smallest
post-placement residual (classic Best-Fit). A small penalty is applied to
completely empty bins so that an equally-tight fit in an already-used bin is
preferred, which tends to consolidate load and avoid scattering.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: tight best-fit (residual near 0 is best).
    score = -residual.astype(np.float64)

    # Mild penalty for completely empty bins: prefer reusing existing bins
    # when the fit is comparable.
    empty = bins == 100
    score -= np.where(empty, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END
