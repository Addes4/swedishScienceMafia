# EVOLVE-BLOCK-START
"""Best-fit with a fullness tie-break: minimize residual, then prefer the fullest bin."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: prefer residual near 0 (tightest fit gives a large negative penalty).
    # Secondary: among equal residuals, prefer the bin that is already fullest
    # (smallest pre-placement remaining capacity), which tends to close bins crisply.
    score = -residual.astype(np.float64) * 1000.0 - bins.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

