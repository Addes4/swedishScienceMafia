# EVOLVE-BLOCK-START
"""Best-fit packing with an adaptive penalty for stranding a residual that is
almost certainly too small for any future item, calibrated from observed items."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Track the smallest seen item size online; residuals below this are
    # essentially guaranteed dead. Start conservatively at a moderate value.
    state = priority.state
    if state is None:
        state = {"min_seen": 100, "count": 0}
        priority.state = state

    it = int(item)
    if it < state["min_seen"]:
        state["min_seen"] = it
    state["count"] += 1

    residual = bins - it  # remaining capacity after placing the item here

    # Base: prefer small residual (tight best fit).
    score = -residual.astype(np.float64)

    # Dead-zone penalty: residuals below the smallest item seen so far cannot be
    # reused by any known item type, so heavily discourage them. Blend from a
    # mild default to the observed minimum as the stream warms up.
    ms = state["min_seen"]
    threshold = float(ms)  # residuals < threshold are effectively unusable
    dead = (residual > 0) & (residual < threshold)
    score -= np.where(dead, 30.0, 0.0)

    return score


priority.state = None
# EVOLVE-BLOCK-END
