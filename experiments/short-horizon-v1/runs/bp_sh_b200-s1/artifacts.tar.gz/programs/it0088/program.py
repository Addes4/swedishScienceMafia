# EVOLVE-BLOCK-START
"""Score bins using a smooth convex cost of the leftover capacity.

The item should preferentially go where the resulting leftover is "useful".
We model this with a piecewise-linear convex cost g(r) on residual r = bins - item:

  - r == 0: perfect fill, cost 0 (best).
  - small r: unusable leftover, but cost rises gently (not a flat cliff),
    so best-fit ordering is preserved while truly tiny scraps are mildly disliked.
  - medium r: reusable by a typical future item (~mean 40), lowest penalty slope.
  - large r: open bins, cost grows so tight fits still win, but a fresh bin
    is only slightly worse than leaving a usable residual.

score = -g(residual), highest wins; ties to the first bin.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; highest score wins, ties to first.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in,
          including unused bins (capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)

    # Piecewise-linear convex cost on the residual.
    # Slopes (per unit capacity) chosen so that:
    #  * r == 0 is best,
    #  * a tiny unusable scrap costs noticeably but not catastrophically,
    #  * a reusable residual (mid range) is the cheapest zone,
    #  * large open bins cost more, keeping best-fit dominant.
    s1 = 1.6   # slope for 0 <= r <= 8   (unusable scrap)
    s2 = 0.45  # slope for 8 <= r <= 40  (reusable zone, cheap)
    s3 = 1.2   # slope for r >= 40        (large open bin)

    c8 = s1 * 8.0                      # cost at r = 8
    c40 = c8 + s2 * (40.0 - 8.0)       # cost at r = 40

    g = np.where(
        residual <= 8.0,
        s1 * residual,
        np.where(
            residual <= 40.0,
            c8 + s2 * (residual - 8.0),
            c40 + s3 * (residual - 40.0),
        ),
    )

    return -g
# EVOLVE-BLOCK-END
