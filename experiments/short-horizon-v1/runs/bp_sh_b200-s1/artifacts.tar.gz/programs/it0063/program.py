# EVOLVE-BLOCK-START
"""Best-fit with a tiny tie-break toward leaving a reusable (large) residual."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Dominant term: prefer the tightest fit (smallest non-negative residual).
    score = -residual.astype(np.float64)

    # Tiny tie-break strictly smaller than 1 residual unit: among bins that would
    # leave the same residual, prefer the one whose residual is larger / more
    # reusable (a residual >= typical future item is better than a dead small one).
    # 100 residual max, so /200 keeps the bonus in [0, 0.5) < 1.
    score += (residual.astype(np.float64) / 200.0)

    return score
# EVOLVE-BLOCK-END

