# EVOLVE-BLOCK-START
"""Best-fit core with a size-aware fill bonus to avoid stranded residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)

    # Tight best-fit core.
    score = -residual

    # Exact fill is always great: crisp close of the bin.
    score += np.where(residual == 0, 5.0, 0.0)

    # Small bonus for residuals that are near the typical item size (mean ~40),
    # since such a bin can still host a future mid-size item tightly rather than
    # stranding an unusable sliver.
    near_typical = np.abs(residual - 40.0)
    score += np.where((residual > 0) & (near_typical <= 8.0), 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
