# EVOLVE-BLOCK-START
"""Best-fit with a smooth dead-zone penalty tuned to the item distribution."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: prefer tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Dead-zone penalty: residuals that are too small to reliably host another
    # item waste nearly a whole bin. Deepen the penalty smoothly as the residual
    # shrinks toward 0, while leaving larger (reusable) residuals essentially
    # untouched so best-fit ordering among good bins is preserved.
    r = residual.astype(np.float64)
    # Smooth bump: strongest at small positive residuals, fading out by ~25.
    pen = np.where(r > 0, 60.0 / (1.0 + r), 0.0)
    score -= pen

    return score
# EVOLVE-BLOCK-END
