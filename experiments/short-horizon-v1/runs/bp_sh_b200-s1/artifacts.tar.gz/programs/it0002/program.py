# EVOLVE-BLOCK-START
"""Best fit with a small residual-aware nudge (best-fit dominant)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item            # capacity left if we place the item here
    # Best fit: minimize residual. Add a tiny preference to avoid creating
    # very small leftovers (which tend to waste bins), i.e. penalize small residuals.
    penalty = np.where(residual < item, residual * 1e-3, 0.0)
    return -(residual) - penalty
# EVOLVE-BLOCK-END

