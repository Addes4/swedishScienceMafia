# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest score.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item
    # Prefer minimal leftover; give a tiny extra bonus to perfect fills.
    bonus = (resid == 0).astype(np.float64) * 0.5
    return bonus - resid
# EVOLVE-BLOCK-END

