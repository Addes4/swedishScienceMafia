# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware residual value term.

The dominant term is pure best-fit (minimize residual).  On top we bias the
choice toward residuals that are likely to be reusable by a future item drawn
from the same Weibull-like distribution (mean ~40): residuals around the typical
item size are valuable, residuals in a narrow low band are nearly dead.  This is
done with a smooth value function so we never break the coarse best-fit order
for residuals that differ appreciably.
"""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)  # capacity left after placing

    # Primary signal: tightest fit (prefer small residual).
    score = -residual

    # Reuse value of the residual: smooth bump centred near the distribution
    # mean (~40), so a leftover that matches a typical item is worth keeping,
    # while a tiny leftover is near-useless.
    reuse = np.exp(-((residual - 40.0) ** 2) / (2.0 * 18.0 ** 2))

    # Dead band: very small residuals are almost always wasted capacity.
    dead = np.clip((12.0 - residual) / 12.0, 0.0, 1.0)

    # Small secondary contribution; small enough not to disturb ordering among
    # clearly different residuals, large enough to break near-ties sensibly.
    score += 0.6 * reuse - 3.0 * dead

    return score
# EVOLVE-BLOCK-END
