# EVOLVE-BLOCK-START
"""Best fit with occasional first-fit to consolidate low-index bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item
    # Best fit: tightest residual. Prefer lower residual, but among bins that
    # can still hold an average item afterwards, prefer earlier bins (first fit)
    # to consolidate fragmentation toward low indices.
    score = -residual.astype(np.float64)
    # small bonus for bins whose residual is >= 40 (can still hold a big item)
    score += (residual >= 40).astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END
