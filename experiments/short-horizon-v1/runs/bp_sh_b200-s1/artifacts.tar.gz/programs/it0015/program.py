# EVOLVE-BLOCK-START
"""Best fit with a large-item reservation for small/medium items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    score = -residual.astype(np.float64)
    if item <= 35:
        # Penalize using very empty bins (residual still large) for small items,
        # reserving them for future large items.
        score -= 1000.0 * (bins >= 80)
    return score
# EVOLVE-BLOCK-END
