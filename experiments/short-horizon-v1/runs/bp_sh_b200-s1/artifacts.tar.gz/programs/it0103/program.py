# EVOLVE-BLOCK-START
"""Score bins by estimated expected stranded capacity after placing the item.

For each candidate bin with residual r (capacity left after placing), we estimate
how much of r is likely to be unusable given future item sizes. A residual that is
hard to fill (small, or just below typical item sizes) gets penalized, while tight
fits and residuals that admit a typical future item are preferred.
"""
import numpy as np

# Discretized item-size distribution (integers 1..100). We approximate the
# Weibull-shaped distribution with mean ~40 using a discretized Weibull.
_SIZE_GRID = np.arange(1, 101, dtype=np.float64)


def _build_dist():
    # Weibull with shape k=2 (Rayleigh-ish), scale chosen so mean ~40.
    # mean = scale * Gamma(1 + 1/k) = scale * Gamma(1.5) = scale * 0.8862
    # scale = 40 / 0.8862 ~= 45.13
    from math import gamma
    k = 2.0
    scale = 40.0 / gamma(1.0 + 1.0 / k)
    s = _SIZE_GRID
    # Weibull pdf
    pdf = (k / scale) * (s / scale) ** (k - 1.0) * np.exp(-(s / scale) ** k)
    # discretized probabilities on integer sizes
    p = pdf.copy()
    p /= p.sum()
    return p


_DIST = _build_dist()
_CUM = np.cumsum(_DIST)  # CDF over integer sizes (index i -> size i+1)


def _expected_strand(r):
    """Estimate expected capacity stranded in a bin with residual r (0..100).

    Model: repeatedly, a future item drawn from the distribution is placed if it
    fits. We simulate the expected leftover using a simple recursion on the
    probability that some item fits. To keep it cheap, we approximate:
      - If r == 0: strand 0.
      - Otherwise, expected strand is roughly r times the probability that a bin
        with residual r cannot be usefully reduced, i.e. no item in the
        distribution fits with high enough chance OR the residual sits just below
        common item sizes.
    """
    if r <= 0:
        return 0.0
    r = float(r)
    # Probability that a randomly drawn item fits in residual r.
    idx = int(min(r, 100)) - 1
    fit_prob = _CUM[idx] if idx >= 0 else 0.0
    # Expected usable fraction: probability-weighted chance to fill further.
    # If fit_prob is very low, almost all of r is likely stranded.
    # Use a smooth factor: strand ~ r * (1 - fit_prob)^2 captures that a
    # residual needing back-to-back unlikely small items wastes more.
    unusable = (1.0 - fit_prob) ** 2
    return r * unusable


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)

    # Base: prefer tight fits via negative residual.
    score = -residual

    # Subtract estimated expected stranded capacity so bins that would strand
    # capacity are avoided more than raw residual suggests.
    r_clip = np.maximum(residual, 0.0)
    idx = np.clip(r_clip.astype(np.int64), 1, 100) - 1
    fit_prob = _CUM[idx]
    unusable = (1.0 - fit_prob) ** 2
    score -= r_clip * unusable

    return score
# EVOLVE-BLOCK-END
