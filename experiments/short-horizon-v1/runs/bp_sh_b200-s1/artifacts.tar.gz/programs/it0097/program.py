# EVOLVE-BLOCK-START
"""Exact best-fit, with a bonus for perfectly filling a bin."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Pure best-fit: smaller residual is better.
    score = -residual.astype(np.float64)

    # Small bonus when the bin becomes exactly full (residual == 0),
    # encouraging clean completions without disturbing best-fit ordering.
    score += np.where(residual == 0, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END

