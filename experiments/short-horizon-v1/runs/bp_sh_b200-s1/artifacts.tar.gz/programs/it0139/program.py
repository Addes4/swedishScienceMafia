# EVOLVE-BLOCK-START
"""Best-fit packing enhanced with an online item-size histogram that rewards
leaving residuals which are likely to be exactly fillable by a future item."""
import numpy as np

# Module-level state: a histogram of item sizes (1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item here

    # ---- Primary: tight best-fit (residual near 0 is best). ----
    score = -residual.astype(np.float64)

    # ---- Distribution-aware perfect-fit potential ----
    # Small bonus if the residual equals a size that actually occurs as an item,
    # i.e. a future item could exactly fill the leftover.  Kept strictly below
    # 1.0 so it only breaks ties between equal residuals and never overrides
    # the primary best-fit ordering.
    if _COUNT > 20:
        total = _HIST.sum()
        if total > 0:
            valid = (residual >= 1) & (residual <= 100)
            idx = np.where(valid, residual, 0).astype(np.int64)
            j = item  # this item's own size is always a plausible candidate
            probs = _HIST[idx] / total
            probs = np.where(valid, probs, 0.0)
            score += probs * 0.5

    # ---- Record this item into the histogram ----
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
