# EVOLVE-BLOCK-START
"""Best fit with a residual-viability bonus to avoid awkward small leftovers."""
import numpy as np


def priority(item, bins):
    """Rank bins by how well the item fits, nudging away from leaving tiny residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit (prefer smallest residual after placing).
    score = -residual.astype(np.float64)
    # Small bonus for leaving a healthy residual (avoids trapping bins with awkward gaps).
    score += 0.02 * residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
