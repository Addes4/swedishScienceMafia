# EVOLVE-BLOCK-START
"""Best-fit with an online histogram-based fillability tie-break.

Base: strongly prefer the smallest nonnegative residual (best fit).
Tie-break: among similar residuals, prefer the one whose residual is most
likely to be filled by a future item, estimated from an online histogram of
observed item sizes. Exact fits get a small extra bonus.
"""
import numpy as np


# Module-level state: histogram of observed item sizes (1..100).
_SIZE = 101
_hist = np.zeros(_SIZE, dtype=np.float64)
_total = 0.0


def _reset():
    global _hist, _total
    _hist = np.zeros(_SIZE, dtype=np.float64)
    _total = 0.0


def _observe(item):
    global _hist, _total
    if 1 <= item < _SIZE:
        _hist[item] += 1.0
        _total += 1.0


def _cdf():
    """Return estimated P(item <= k) for k = 0..100."""
    if _total <= 0:
        # Fallback: assume a rough Weibull-ish mean-40 prior (uniform-ish prior).
        c = np.linspace(0.0, 1.0, _SIZE)
        return c
    cum = np.cumsum(_hist)
    cdf = np.empty(_SIZE, dtype=np.float64)
    cdf[0] = 0.0
    cdf[1:] = cum[1:] / _total
    return cdf


def priority(item, bins):
    """Rank bins; the item goes to the highest score (first on ties)."""
    _observe(item)

    residual = bins - item  # remaining space after placing here
    r = residual.astype(np.float64)

    # Base best-fit: strongly prefer small residual.
    score = -r

    cdf = _cdf()

    # Fillability of each residual: probability a future item fits into it,
    # weighted by how much it would fill (prefer residuals we can actually use).
    r_clip = np.clip(residual, 0, 100).astype(np.int64)
    # P(next item <= residual): cumulative mass up to residual size.
    p_small = cdf[r_clip]

    # A residual of 0 is a perfect fill: small bonus to strongly prefer it.
    exact = (residual == 0)
    score = score + np.where(exact, 0.25, 0.0)

    # Prefer residuals with higher chance of being reused, but only mildly so
    # it doesn't override the best-fit ordering.
    score += 0.05 * p_small

    return score
# EVOLVE-BLOCK-END
