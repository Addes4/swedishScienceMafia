# EVOLVE-BLOCK-START
"""Best-fit with an online estimate of reusable residuals.

The idea: placing an item leaves a residual r. A residual is "good" if it is
close to 0 (no waste) or close to a size that a future item is likely to take
(so the bin can be packed tightly again). We keep a cheap online histogram of
arrived item sizes and score each candidate residual by how well it matches
either an exact fit or a likely future item size, plus a small best-fit bias.
"""
import numpy as np


# Module-level state, reset implicitly per stream because a new module instance
# is used for each stream (the harness starts state fresh per stream).
_state = {"counts": None, "n": 0}

# Coarse item-size buckets (width 5) for a cheap distribution estimate.
_BUCKET = 5
_NBUCK = 100 // _BUCKET + 1  # buckets 0..20


def _update(item):
    if _state["counts"] is None:
        _state["counts"] = np.zeros(_NBUCK, dtype=np.float64)
    b = item // _BUCKET
    if 0 <= b < _NBUCK:
        _state["counts"][b] += 1.0
    _state["n"] += 1.0


def priority(item, bins):
    """Rank bins; the item goes to the highest (first on ties)."""
    _update(item)

    residual = bins - item  # remaining capacity after placing here
    score = -residual.astype(np.float64)

    # Small bonus for residuals that a typical future item could fill well.
    # Use the online histogram to find, for each residual, the probability mass
    # of item sizes that would leave a small leftover when placed in this bin.
    counts = _state["counts"]
    n = _state["n"]
    if counts is not None and n >= 8:
        # Estimate the chance that a future item of some size s fits into a
        # residual r leaving a small remainder (which keeps packing tight).
        # For each candidate residual, look up nearby item-size buckets.
        for r_idx in np.unique(residual):
            if r_idx <= 0:
                continue
            # find buckets whose size is <= residual (fit) and yields small slack
            b_max = int(min(r_idx, 100) // _BUCKET)
            if b_max <= 0:
                continue
            # weight buckets by how small the leftover would be
            bs = np.arange(b_max + 1)
            sizes = bs * _BUCKET + _BUCKET // 2
            slack = r_idx - sizes
            good = slack >= 0
            # prefer sizes that nearly fill r (small slack) - reuse value
            w = np.where(good, 1.0 / (1.0 + slack), 0.0)
            val = float(np.dot(counts[:b_max + 1], w)) / n
            score += np.where(residual == r_idx, val, 0.0)

    return score
# EVOLVE-BLOCK-END

