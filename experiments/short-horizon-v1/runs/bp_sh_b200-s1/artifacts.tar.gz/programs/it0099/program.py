# EVOLVE-BLOCK-START
"""Best-fit packing with a tie-break toward keeping flexibility.

Score is dominated by -residual (exact best-fit: prefer the tightest fit).
Ties in residual are broken by a tiny term that favors leaving the bin with
more remaining capacity, which slightly improves future options without
disturbing the near-best-fit ordering.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: best-fit (smallest residual).
    score = -residual.astype(np.float64)

    # Tiny tie-break: favor bins with more remaining capacity after placement.
    # Magnitude is < 1 so it never overrides a 1-unit difference in residual.
    score += 1e-4 * bins.astype(np.float64)

    return score
# EVOLVE-BLOCK-END

