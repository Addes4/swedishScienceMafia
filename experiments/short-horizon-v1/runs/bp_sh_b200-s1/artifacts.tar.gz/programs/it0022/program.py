# EVOLVE-BLOCK-START
"""Best fit with a residual-magnitude bias to preserve fresh bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # leftover space after placing; >= 0 for bins shown
    # Best fit: prefer smallest leftover.
    score = -residual.astype(np.float64)
    # Mild penalty for using large-residual (near-empty) bins, so fresh bins are
    # preserved for large items. Penalty ramps up with residual magnitude.
    score -= 0.05 * residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END

