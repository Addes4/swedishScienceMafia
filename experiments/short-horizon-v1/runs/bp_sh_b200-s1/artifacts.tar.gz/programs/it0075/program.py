# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware "reusability" term.

The primary signal remains tight best-fit (prefer the smallest useful residual),
but a bounded extra term rewards bins whose residual is likely to still host a
future item, estimated online from the observed item-size distribution.
"""
import numpy as np


class _State:
    def __init__(self):
        # histogram over item sizes 1..100 (index 0 unused)
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0


_S = _State()


def _fit_prob(residual, hist, count):
    """Estimated probability that a future item fits in a bin with this residual.

    Uses the empirical size distribution: P(next item <= residual).
    """
    if count <= 0:
        # prior: Weibull mean ~40; rough default -> items up to residual
        return np.clip(residual / 100.0, 0.0, 1.0)
    r = np.clip(residual.astype(np.int64), 0, 100)
    cdf = np.cumsum(hist) / count
    return cdf[r]


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing item here

    # Update online item-size histogram.
    _S.hist[item] += 1.0
    _S.count += 1.0

    # Primary: tightest fit (most negative residual = best fit).
    score = -residual.astype(np.float64)

    # Reusability bonus: strictly sub-unit so it never overrides best-fit,
    # but breaks near-ties toward residuals that can still host a future item.
    p = _fit_prob(residual, _S.hist, _S.count)
    score += 0.5 * p

    return score
# EVOLVE-BLOCK-END
