# EVOLVE-BLOCK-START
"""Adaptive best-fit: prefer tight fits, penalize residuals too small to be
reused by future items (estimated from a running lower quantile of item sizes)."""
import numpy as np

_state = {"min_seen": 100}


def priority(item, bins):
    if item < _state["min_seen"]:
        _state["min_seen"] = item

    residual = bins - item  # remaining capacity if placed here

    # Base: tightest fit (smallest residual) preferred. Unused bins (residual
    # large) are naturally deprioritized because residual is large.
    score = -residual.astype(np.float64)

    # Adaptive dead zone: residuals below the smallest item we've seen (or a
    # safe floor) can't be reused, so penalize leaving them.
    floor = max(1, min(_state["min_seen"], 40))
    dead = (residual > 0) & (residual < floor)
    score -= np.where(dead, float(floor) + 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
