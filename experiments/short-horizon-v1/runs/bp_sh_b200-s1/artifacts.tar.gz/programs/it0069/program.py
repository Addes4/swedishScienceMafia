# EVOLVE-BLOCK-START
"""Best-fit with a concave residual reward: strongly prefer small residuals
(tightest fit, least waste), while gently avoiding residuals so tiny they
will almost surely be stranded."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: tightest fit (smallest residual) is best. Using -residual keeps
    # best-fit dominance; ties broken below.
    score = -residual.astype(np.float64)

    # Small reuse nudge (strictly less than 1 residual unit): prefer leaving a
    # residual that a typical item (~40) could reuse over tiny stranded gaps.
    reuse = np.where(residual >= 25, 0.25, 0.0)
    score += reuse

    return score
# EVOLVE-BLOCK-END
