# EVOLVE-BLOCK-START
"""Best-fit with an empirical expected-residual-value tie-break.

Pure best-fit is myopic: it produces a tight residual now but often leaves a gap
too small for any future item.  We keep best-fit dominant (smaller residual is
better) but break near-ties by preferring residuals whose *expected remaining
usable capacity* is highest, estimated from the empirical distribution of the
items seen so far.

For a residual r, the capacity we expect to eventually recover from a bin is
approximated as:  P(some future item fits in r) weighted by how close r is to a
"typical packing point".  In practice a good proxy is the probability that the
residual is at least a modest item, minus the expected waste.  We compute a small
additive correction so it only matters when best-fit residuals are close.
"""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    global _state

    # Update the empirical item-size histogram (state persists within a stream).
    hist = _state["hist"]
    hist[item] += 1.0
    n = _state["n"] + 1.0
    _state["n"] = n
    probs = hist / n  # probability of each size 1..100

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit is the dominant term: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Expected value of a residual r: probability that at least one future item
    # fits (i.e. some item size <= r) plus a small reward for exact fills.
    # Cumulative probability that an item is <= x.
    cdf = np.cumsum(probs)
    r = np.clip(residual, 0, 100)
    fit_prob = cdf[r]  # P(future item fits in this residual)

    # Small correction: prefer residuals that are likely usable, and give exact
    # fills (residual 0) a tiny nudge.
    correction = 0.4 * fit_prob + np.where(residual == 0, 0.3, 0.0)

    return primary + correction
# EVOLVE-BLOCK-END
