# EVOLVE-BLOCK-START
"""Best-fit with a stateful item-size histogram guiding leftover preferences."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0

    def observe(self, item):
        self.hist[item] += 1.0
        self.count += 1.0


_state = _State()


def priority(item, bins):
    """Rank bins: primarily best-fit, secondarily prefer useful leftovers."""
    # Update histogram with past items (do not include current item to avoid
    # trivially matching itself, though including is harmless).
    _state.observe(item)

    leftover = bins - item  # >= 0 since bins shown all fit the item

    # Primary: minimize leftover (best fit). Larger leftover -> lower score.
    # Secondary: prefer leftovers that match frequently seen item sizes,
    # since such fragments are more likely to be filled exactly later.
    # Weight the secondary term small so it only breaks near-ties.
    freq = _state.hist
    # For each bin candidate, the "usefulness" of its resulting leftover:
    # use the empirical probability mass at that exact leftover value.
    lo = leftover.astype(np.int64)
    lo_clipped = np.clip(lo, 0, 100)
    useful = freq[lo_clipped] / max(_state.count, 1.0)

    # Normalize useful to a small perturbation range.
    score = -leftover.astype(np.float64) + 0.25 * useful
    return score
# EVOLVE-BLOCK-END
