# EVOLVE-BLOCK-START
"""Selective best-fit: mostly best-fit, occasionally take second-tightest.

Pure best-fit leaves small unusable fragments because it always grabs the
tightest fit, even when a marginally looser fit would keep a bin more
useful.  Because exact ties are rare on long streams, any deterministic
tie-break collapses to best-fit.  Instead we add a small fixed probability
of accepting the second-tightest fitting bin, which perturbs the packing
just enough to avoid some dead fragments while staying very close to the
strong best-fit baseline.
"""
import numpy as np

# Probability of choosing the second-tightest fit instead of the tightest.
_P_SECOND = 0.05

# Persistent RNG state (seeded per process; streams vary the sequence enough
# that this behaves as an unbiased random perturbation).
_RNG = np.random.default_rng(12345)


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties to first bin.

    Mostly best-fit (tightest fit = smallest leftover).  With small
    probability we promote the second-tightest fitting bin to the top.
    """
    leftover = bins - item  # >= 0 for all bins shown

    if leftover.size == 1:
        return -leftover

    # Rank bins by tightness: smaller leftover => higher score.
    order = np.argsort(leftover, kind="stable")  # ascending leftover
    scores = np.empty(leftover.size, dtype=np.float64)
    # Base: strong preference for tighter fits.
    scores[:] = -leftover

    if _RNG.random() < _P_SECOND:
        # Promote the second-tightest bin above the tightest one.
        scores[order[1]] = -leftover[order[1]] + 1e6

    return scores
# EVOLVE-BLOCK-END
