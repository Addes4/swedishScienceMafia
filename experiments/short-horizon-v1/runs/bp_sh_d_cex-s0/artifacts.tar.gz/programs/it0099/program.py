# EVOLVE-BLOCK-START
"""Distribution-aware best-fit: prefer tightest fit, tilt ties toward reusable residuals."""
import numpy as np

# Estimate of the item-size CDF for the fixed Weibull-shaped distribution (mean ~40).
# We approximate P(item <= x) so we can weight a residual by how likely it is to
# ever be filled by a future item: small residuals are almost certainly wasted.
# A residual r can accept a future item with probability ~ 1 - F(r) = P(item > r).
# We prefer residuals that are more likely to be reusable, while still favoring
# tight fits. The weight is small so it only breaks near-ties.
_R = np.arange(0, 101, dtype=np.float64)
# Weibull (shape ~1.5, scale ~44) cumulative distribution approximation.
_SHAPE = 1.5
_SCALE = 44.0
_CDF = 1.0 - np.exp(-(_R / _SCALE) ** _SHAPE)  # P(item <= r)
_REUSE = 1.0 - _CDF                          # P(future item can use residual r)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item (>= 0)
    residual = np.clip(residual, 0, 100)

    # Primary best-fit: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Secondary: reward residuals likely to be reusable in the future.
    reuse = _REUSE[residual]

    # Keep the secondary term small enough to only break ties among
    # comparably-tight fits (scale < 1 so integer residual differences dominate).
    return primary + 0.9 * reuse
# EVOLVE-BLOCK-END
