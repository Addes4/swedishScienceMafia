# EVOLVE-BLOCK-START
"""Best-fit with distribution-aware sliver penalty and exact-fill bonus."""
import numpy as np

_state = {"min_item": 100, "mean": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    n = _state["n"]
    mean = _state["mean"]
    # Running mean of item sizes seen so far.
    mean = (mean * n + item) / (n + 1)
    _state["n"] = n + 1
    _state["mean"] = mean
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Sliver penalty: residuals smaller than the running mean item size are unlikely
    # to be reused; penalty grows as the residual shrinks toward 0 (excluding 0).
    ref = max(mean, 1.0)
    with np.errstate(divide="ignore", invalid="ignore"):
        frac = np.where(residual > 0, residual / ref, 1.0)
    penalty = np.where((residual > 0) & (residual < ref), 1.0 - frac, 0.0)
    # Exact fills get a strong bonus (residual 0 means a perfectly closed bin).
    bonus = np.where(residual == 0, 0.75, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END
