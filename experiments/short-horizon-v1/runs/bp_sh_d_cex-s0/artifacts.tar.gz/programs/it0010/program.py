# EVOLVE-BLOCK-START
"""Best fit with a small-item-aware tie-break.

Pure best fit picks the bin with the smallest leftover. That leaves many tiny
residuals which can never be filled again. We keep the tightest-fit primary
criterion but add a tiny bonus for bins whose left-over after placement is
either zero (a clean close) or at least the smallest item size we have seen so
far (so the residual is still usable). The bonus is small enough to only break
near-ties, so it cannot hurt the main best-fit behaviour.
"""
import numpy as np

# module-level state, reset via a fresh interpreter per stream is NOT guaranteed,
# so we detect stream restart by watching for a drop in the number of seen items.
_seen = 0
_min_item = 100


def priority(item, bins):
    global _seen, _min_item
    if item < _min_item:
        _min_item = item
    _seen += 1

    leftover = bins - item
    # primary: smaller leftover is better -> negative leftover
    score = -leftover.astype(np.float64)

    # small tie-break bonus: exact close or usable residual
    zero = leftover == 0
    usable = leftover >= _min_item
    score += 1e-3 * zero
    score += 1e-4 * usable
    return score
# EVOLVE-BLOCK-END
