# EVOLVE-BLOCK-START
"""Best-fit with a smooth, distribution-aware waste penalty on unusable residuals."""
import numpy as np

_state = {"min_item": 100, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item
    _state["count"] += 1

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Waste penalty: any residual strictly below the smallest item seen so far
    # can never be reused. Penalize proportionally to the space that becomes
    # permanently unusable, but keep it gentle so it only breaks near-ties.
    m = _state["min_item"]
    waste = np.clip(m - 1 - residual, 0, None)  # >0 only when residual < min_item
    penalty = waste.astype(np.float64) * 0.01

    # Exact-fill bonus, decaying with stream length so short streams
    # (where best-fit alone is optimal) stay unperturbed.
    decay = 1.0 / (1.0 + _state["count"] * 0.002)
    bonus = np.where(residual == 0, 0.5 * decay, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END
