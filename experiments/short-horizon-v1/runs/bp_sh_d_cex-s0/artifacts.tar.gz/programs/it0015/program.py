# EVOLVE-BLOCK-START
"""Best fit with a secondary preference for emptier bins on leftover ties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item
    # Primary: minimize leftover (best fit). Secondary: among equal leftover,
    # prefer the bin that was emptier before placement (larger bins value).
    return -leftover * 1000.0 + bins
# EVOLVE-BLOCK-END
