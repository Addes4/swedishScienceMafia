# EVOLVE-BLOCK-START
"""Best-fit with a stateful refill-probability bonus for reusability."""
import numpy as np

# Histogram of item sizes seen so far (coarse), size 101.
_hist = np.zeros(101, dtype=np.float64)
_seen = 0.0


def priority(item, bins):
    """Rank bins; highest score wins, ties to the first bin."""
    global _hist, _seen

    # Update histogram with current item.
    if 1 <= item <= 100:
        _hist[item] += 1.0
    _seen += 1.0

    residual = bins - item  # leftover capacity after placing item

    # Best-fit primary term: tighter fit is better.
    primary = -residual.astype(np.float64)

    # Estimate P(a future item <= r) for each distinct residual r.
    # Using the empirical histogram of past items (with a small Laplace-ish
    # prior so rare sizes are not fully ruled out early).
    counts = _hist[1:].copy()            # sizes 1..100
    counts += 0.5                        # smoothing
    cdf = np.cumsum(counts)
    cdf /= cdf[-1]
    # prob_fits[r] = P(next item can fit into residual r) for r in 0..100
    prob_fits = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        prob_fits[r] = cdf[r - 1]

    r_clipped = np.clip(residual, 0, 100)
    reuse = prob_fits[r_clipped]
    # Residuals with no chance of reuse get no bonus.
    reuse = np.where(residual <= 0, 0.0, reuse)

    # Exact fills strongly preferred, otherwise tightest fit with reuse bonus.
    exact = np.where(residual == 0, 2.0, 0.0)

    # Scale so reuse bonus stays smaller than the unit gap in primary.
    return primary + exact + 0.6 * reuse
# EVOLVE-BLOCK-END
