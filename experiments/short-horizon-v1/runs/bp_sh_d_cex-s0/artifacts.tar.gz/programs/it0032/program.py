# EVOLVE-BLOCK-START
"""Best-fit with a stateful tie-break that avoids leaving common item sizes as residue."""
import numpy as np


def priority(item, bins):
    """Rank bins: primary = tightest fit (min leftover); tie-break by residue usefulness.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities (bins the item fits in), in bin order.
    """
    leftover = bins - item  # >= 0 for all shown bins

    best = leftover.min()
    # bins that are essentially as tight as the best fit
    tight = leftover <= best + 1

    # stateful histogram of observed item sizes (kept on the function object)
    hist = getattr(priority, "hist", None)
    if hist is None or hist.shape[0] != 101:
        hist = np.zeros(101, dtype=np.float64)
        priority.hist = hist
    # decay toward recency
    hist *= 0.995

    # estimate the most likely upcoming item sizes from the histogram
    # (avoid index 0 which is unused)
    freq = hist[1:101]

    # For each bin, how "covered" is its resulting leftover by frequent future items?
    # We prefer NOT to leave a leftover that is a very common item size, because that
    # residue is likely to be filled anyway; but we mostly want tight fits.
    res = np.zeros(bins.shape[0], dtype=np.float64)
    for i in range(bins.shape[0]):
        lf = int(leftover[i])
        cover = freq[lf - 1] if 1 <= lf <= 100 else 0.0
        res[i] = -cover  # lower cover -> higher score among near-ties

    # base: tightest fit wins strongly; among near-ties, avoid stranding common sizes
    base = -leftover.astype(np.float64) * 1e6
    # only apply the tie-break where fits are essentially equal
    tie_pen = np.where(tight, res * 1.0, 0.0)

    score = base + tie_pen

    # record this item
    if 1 <= item <= 100:
        hist[item] += 1.0

    return score
# EVOLVE-BLOCK-END

