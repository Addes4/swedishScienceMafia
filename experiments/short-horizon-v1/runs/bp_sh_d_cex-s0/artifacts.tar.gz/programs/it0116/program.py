# EVOLVE-BLOCK-START
"""Sorted-fit hybrid: exact-fill first, avoid unusable slivers, then best-fit."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Sliver penalty: residuals in [1, min_item-1) can never be reused.
    sliver_thresh = _state["min_item"]
    sliver = (residual > 0) & (residual < sliver_thresh)
    penalty = np.where(sliver, 20.0, 0.0)

    # Exact fill is always best.
    bonus = np.where(residual == 0, 1000.0, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END

