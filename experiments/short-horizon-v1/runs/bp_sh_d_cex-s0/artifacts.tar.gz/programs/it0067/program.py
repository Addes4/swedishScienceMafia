# EVOLVE-BLOCK-START
"""Hybrid best-fit: exact-fill preference for large items, else pure best-fit."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _state
    _state["n"] += 1
    _state["sum"] += item

    residual = bins - item  # remaining capacity after placing item

    # Primary: best-fit (smaller residual is better).
    primary = -residual.astype(np.float64)

    # For larger items, strongly reward exact fills and residuals big enough to
    # host another similar-sized item; discourage leaving a medium sliver.
    if item >= 40:
        exact = (residual == 0)
        roomy = (residual >= item)
        medium_sliver = (residual > 0) & (residual < item) & (residual < 40)

        adj = np.where(exact, 2.0, 0.0)
        adj += np.where(roomy, 0.25, 0.0)
        adj -= np.where(medium_sliver, 0.75, 0.0)
        return primary + adj

    return primary
# EVOLVE-BLOCK-END
