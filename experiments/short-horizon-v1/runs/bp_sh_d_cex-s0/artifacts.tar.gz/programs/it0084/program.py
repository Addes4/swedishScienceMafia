# EVOLVE-BLOCK-START
"""Best-fit dominant, with a fillability-aware tie-break that penalizes
unusable residuals relative to the typical item size."""
import numpy as np

_state = {"sum": 0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, first on ties.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    global _state
    _state["sum"] += item
    _state["count"] += 1
    mean_item = _state["sum"] / _state["count"]

    residual = bins - item  # remaining capacity after placing the item

    # Primary: best-fit (tighter fit preferred).  Keep it integer-scaled and
    # dominant so the secondary term only breaks near-ties.
    primary = -residual.astype(np.float64) * 1000.0

    # Fillability: a residual r is "usable" if some future item can land in it,
    # i.e. roughly r >= typical item size, or r == 0 (perfectly closed).
    # Strongly reward closing bins; mildly discourage tiny unusable slivers.
    usable_cut = max(1.0, mean_item * 0.5)
    sliver = (residual > 0) & (residual < usable_cut)
    penalty = np.where(sliver, 1.0, 0.0)
    exact = np.where(residual == 0, 1.0, 0.0)

    return primary - penalty + exact
# EVOLVE-BLOCK-END
