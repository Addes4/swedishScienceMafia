# EVOLVE-BLOCK-START
"""Pure best-fit: place the item in the fullest bin that still fits it."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Smaller residual (fuller bin) is better; unused bins (cap 100) are least preferred.
    return -(bins - item).astype(np.float64)
# EVOLVE-BLOCK-END

