# EVOLVE-BLOCK-START
"""Best fit with a light adaptive tie-break driven by a recent-item histogram.

Primary rule: strict best fit (minimize post-placement remaining capacity).
Tie-break: among bins with equal post-placement leftover, prefer the leftover that
recent arriving items have most often been able to "complete" (i.e., leftover values
close to recently seen item sizes), so gaps that tend to be filled are favored.
"""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)


_state = _State()


def priority(item, bins):
    """Return a priority per bin; item goes to the highest score (first on ties)."""
    it = int(item)
    leftover = bins - it  # >= 0 since bins only contains feasible capacities

    # Primary: strict best fit -> smaller leftover is better.
    # Secondary: prefer leftover values that recent items tend to fill,
    # which we proxy with a decayed histogram of recent item sizes.
    h = _state.hist
    # update histogram with the current item (decayed, recency-weighted)
    h *= 0.995
    h[it] += 1.0

    total = h.sum()
    if total > 1.0:
        density = h / total
    else:
        density = None

    lo = leftover.astype(np.int64)

    if density is None:
        return -lo.astype(np.float64)

    # A leftover gap g is "completable" if some recently frequent item size s <= g
    # can fit into it. Score completability as the cumulative density up to g.
    # Using cumulative density rewards gaps that are at least as large as common items,
    # gently pushing toward leaving usable slack instead of tiny unusable fragments.
    csum = np.concatenate(([0.0], np.cumsum(density)))
    # clamp indices to [0,100]
    idx = np.clip(lo, 0, 100)
    complete_bonus = csum[idx]

    # Combine: primary term dominates, bonus is a small nudge (scale < 1).
    return -lo.astype(np.float64) + 0.03 * complete_bonus
# EVOLVE-BLOCK-END
