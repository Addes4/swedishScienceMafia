# EVOLVE-BLOCK-START
"""Best-fit with a smooth fillability bonus estimated from a running size histogram."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item >= 1:
        _state["hist"][item] += 1.0
        _state["n"] += 1.0

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Fillability bonus: probability (empirical) that some future item exactly
    # equals this residual, so the bin can be closed perfectly.
    hist = _state["hist"]
    total = _state["n"]
    if total > 0:
        p = hist / total
    else:
        p = np.zeros(101, dtype=np.float64)

    # Residuals are in [0, 100]; clip to valid range.
    idx = np.clip(residual, 0, 100).astype(np.int64)
    fill_prob = p[idx]

    # Exact fill is special: reward strongly.
    bonus = np.where(residual == 0, 0.5, 0.0)

    # Secondary term kept small so it only breaks near-ties in best-fit.
    return primary + 2.0 * fill_prob + bonus
# EVOLVE-BLOCK-END
