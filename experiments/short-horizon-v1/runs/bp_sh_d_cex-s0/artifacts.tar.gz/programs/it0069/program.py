# EVOLVE-BLOCK-START
"""Best-fit with histogram-aware pair-completion tie-break."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _state
    # Update running item-size histogram (all integer sizes 1..100).
    _state["hist"][item] += 1.0
    _state["n"] += 1
    hist = _state["hist"]
    n = _state["n"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Secondary: pair-completion bonus. A residual r (1..100) can be exactly closed
    # by a single future item of size r; reward residuals that are likely item sizes.
    # Use a bounded bonus so it only matters near ties.
    safe_r = np.clip(residual, 0, 100).astype(np.int64)
    # probability that some future item equals exactly r (scaled by frequency)
    freq = hist[safe_r] / n if n > 0 else np.zeros_like(safe_r, dtype=np.float64)
    pair_bonus = freq * 2.0
    # exact fill always good
    pair_bonus = np.where(residual == 0, 2.0, pair_bonus)

    return primary + pair_bonus
# EVOLVE-BLOCK-END
