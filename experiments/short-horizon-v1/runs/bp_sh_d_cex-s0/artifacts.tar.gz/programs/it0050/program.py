# EVOLVE-BLOCK-START
"""Harmonic-inspired bin selection: steer items into capacity classes to reduce slivers."""
import numpy as np

# Fixed capacity thresholds (harmonic-class boundaries scaled to capacity 100).
# A small set of coarse classes; tighter fits preferred within the class window.
_BOUNDS = np.array([100, 80, 60, 45, 33, 25, 18, 13, 9, 6], dtype=np.int64)


def priority(item, bins):
    """Rank bins: prefer tight class fit, then best-fit tightness."""
    # Primary: best fit (tightest leftover) still dominates correctness/short streams.
    tight = -(bins - item)

    # Secondary nudge: for the smallest already-fitting leftovers, favor those
    # close to a class boundary multiple of the item when possible. This is a
    # mild tie-breaker that rarely disturbs pure best-fit.
    rem = bins - item
    # Prefer residuals of exactly 0 strongly (perfect fill).
    perfect = (rem == 0).astype(np.int64) * 1
    # Prefer leftovers that are a multiple of the item (can pack more same items).
    multi = ((rem > 0) & (item > 0) & (rem % item == 0)).astype(np.int64)

    return tight * 4 + perfect * 2 + multi
# EVOLVE-BLOCK-END
