# EVOLVE-BLOCK-START
"""Fractional-harmonic-style bin choice.

Items are drawn from a Weibull-like distribution (mean ~40).  Pure best-fit
tends to break the stream into many small slivers.  A classic remedy is a
"class" rule (Harmonic / Fractional-Harmonic): each item is assigned to a
capacity window based on its size, and bins are used in a way that keeps the
capacity scale of bins matched to the arriving items, so large bins are not
consumed by small items.

We keep the rule simple and robust:
  * fragment the capacity axis into a fixed geometric-ish grid of classes;
  * for the arriving item, find the smallest capacity class that can still
    hold it comfortably (class capacity >= item);
  * prefer bins whose remaining capacity lies in that class, breaking ties by
    tightest fit.
  * if no bin is in that class, fall back to pure best-fit.
"""

import numpy as np

# Fixed fraction thresholds; capacity 100.  Class k covers
# (100*f[k+1], 100*f[k]]  (f monotonically decreasing).
_FRACS = np.array(
    [1.0, 0.75, 0.55, 0.40, 0.28, 0.18, 0.10, 0.05, 0.0], dtype=np.float64
)
_CAPS = _FRACS * 100.0


def _class_of(item, caps):
    """Index of the smallest class capacity that is >= item."""
    # caps is decreasing; find first cap >= item
    idx = np.searchsorted(-caps, -item, side="left")
    if idx >= len(caps):
        idx = len(caps) - 1
    return idx


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    return _priority_impl(item, bins)


def _priority_impl(item, bins):
    item = int(item)
    b = np.asarray(bins, dtype=np.float64)

    # Class the item "belongs" to: smallest class capacity that still fits it.
    idx = int(np.searchsorted(-_CAPS, -item, side="left"))
    if idx >= len(_CAPS):
        idx = len(_CAPS) - 1
    target_cap = _CAPS[idx]
    # Lower edge of that class (next class capacity); bins below this cannot be
    # in the class at all (they are strictly smaller than the target window).
    low_edge = _CAPS[idx + 1] if idx + 1 < len(_CAPS) else 0.0

    # Bins whose remaining capacity lies within the target class window.
    in_class = (b >= low_edge) & (b <= target_cap)

    # Score: in-class bins get a big bonus, then tightest fit (smallest leftover).
    leftover = b - item
    score = -leftover  # best-fit baseline, larger is better

    if np.any(in_class):
        score = score + np.where(in_class, 1e6, 0.0)
    else:
        # No bin in the class window: prefer the smallest capacity that still
        # holds the item (best-fit fallback already encoded in `score`).
        pass

    return score
# EVOLVE-BLOCK-END
