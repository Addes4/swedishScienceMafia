# EVOLVE-BLOCK-START
"""Best-fit with a residual-desirability tie-break learned from a running item histogram."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["hist"][item] += 1.0
    st["n"] += 1.0

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Desirability of the residual: probability that a future item can exactly fill it.
    # Use the running histogram, smoothed with a small prior, and look only at the
    # exact-fill probability for small residuals (where a single next item could fit).
    hist = st["hist"]
    prior = 1.0 / (st["n"] + 10.0)
    prob = (hist + prior) / (st["n"] + 101.0 * prior)

    # Index into prob for each residual, guarding residual=0 (perfect fill) and large.
    resid_clipped = np.clip(residual, 0, 100).astype(np.int64)
    fill_prob = prob[resid_clipped]
    fill_prob = np.where(residual == 0, 1.0, fill_prob)
    fill_prob = np.where(residual >= 101, 0.0, fill_prob)

    # Small secondary term; primary remains dominant by integer spacing.
    return primary + 5.0 * fill_prob
# EVOLVE-BLOCK-END
