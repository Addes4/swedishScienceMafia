# EVOLVE-BLOCK-START
"""Best-fit with a usable-residual tie-break tuned to the item distribution."""
import numpy as np

_state = {"mean": 40.0, "n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Secondary: prefer residuals that keep the bin usable for typical future items.
    # residual == 0: perfect fill (best)
    # residual >= mean: bin can still accept a typical item
    # 0 < residual < mean: likely wasted sliver -> penalize
    r = residual.astype(np.float64)
    # normalized "usability": 0 for perfect fill, 1 for fully usable (>= mean), 
    # scaled down for slivers
    usability = np.where(
        residual == 0,
        1.0,
        np.where(residual >= mean, 0.5, 0.5 * (r / max(mean, 1.0)))
    )

    # Secondary weight must stay < 1 so it only breaks best-fit ties.
    return primary + 0.9 * usability
# EVOLVE-BLOCK-END
