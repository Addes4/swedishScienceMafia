# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware residual-waste tie-break.

Primary criterion is best-fit (tightest residual). Among bins that are close in
residual, prefer the residual that is *least likely to be wasted* — i.e. the
residual closest to a size that actually appears in the stream (or 0). This
keeps pure best-fit dominant while resolving near-ties toward reusable space.
"""
import numpy as np

_state = {"seen": 0, "mean": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    _state["seen"] += 1
    n = _state["seen"]
    _state["mean"] += (item - _state["mean"]) / n
    mean = _state["mean"] if _state["mean"] > 0 else 40.0

    residual = (bins - item).astype(np.float64)  # remaining capacity after placing

    # Primary: best-fit (tighter residual better).
    primary = -residual

    # Exact-fill bonus: residual == 0 is always ideal.
    bonus = np.where(residual == 0.0, 0.5, 0.0)

    # Tie-break: among near-ties, prefer a residual near the typical item size
    # (likely reusable) rather than a small sliver. Gaussian bump around mean.
    sigma = max(mean * 0.5, 1.0)
    reusable = np.exp(-((residual - mean) ** 2) / (2.0 * sigma * sigma))
    # Small slivers (below ~half the mean) are discouraged.
    sliver = (residual > 0) & (residual < 0.5 * mean)
    penalty = np.where(sliver, 0.3, 0.0)

    # Secondary terms are small so they only matter near ties.
    return primary + 0.2 * reusable - penalty + bonus
# EVOLVE-BLOCK-END
