# EVOLVE-BLOCK-START
"""Best fit with a bonus for near-perfect fills."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item
    # Prefer tightest fit (smallest leftover), with a slight extra push to close
    # off bins almost completely (leftover very small) so they stop attracting items.
    bonus = np.where(leftover <= 2, 1.0, 0.0)
    return -leftover + bonus
# EVOLVE-BLOCK-END
