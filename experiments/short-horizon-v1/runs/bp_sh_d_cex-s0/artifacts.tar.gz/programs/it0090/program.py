# EVOLVE-BLOCK-START
"""Best-fit with mean-scaled sliver avoidance and exact-fill bonus."""
import numpy as np

_state = {"count": 0, "sum": 0.0}


def priority(item, bins):
    """Rank bins; highest score gets the item (first on ties).

    item: integer size, 1..100.
    bins: numpy int64 array of remaining capacities of fitting bins (bin order).
    """
    st = _state
    st["count"] += 1
    st["sum"] += item
    mean_item = st["sum"] / st["count"]

    residual = bins - item  # capacity left after placing the item
    res = residual.astype(np.float64)

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -res

    # Smooth sliver penalty scaled by mean item size: residuals in (0, mean)
    # are less likely to be filled by a typical future item, so mildly
    # discourage leaving them; exact fills get a bonus.
    thresh = max(1.0, 0.5 * mean_item)
    sliver = (res > 0) & (res < thresh)
    penalty = np.where(sliver, 0.05, 0.0)
    bonus = np.where(res == 0, 0.5, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END
