# EVOLVE-BLOCK-START
"""Best fit with a leftover-quality adjustment to reduce small dead fragments."""
import numpy as np

# Histogram of observed item sizes (1..100), starts empty.
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    Core is best-fit (prefer tightest leftover), refined so that among near-ties
    we prefer leftovers that are exactly full or that are likely to be usable by
    future items, penalizing tiny dead fragments.
    """
    global _total

    item = int(item)
    leftovers = bins - item  # >= 0 for every bin shown

    # Update histogram with the item we just saw (state across the stream).
    _hist[item] += 1.0
    _total += 1.0

    # Probability that a future item can exactly land in a leftover of size L.
    # Use observed frequency if available, else a small uniform prior.
    prob = _hist / _total if _total > 0 else np.full(101, 1.0 / 101.0)

    # Base: strict best-fit -> tightly fitting bins score higher.
    score = -leftovers.astype(np.float64)

    # For each candidate leftover L (0..100), a "quality" term:
    #  - L == 0 is perfect (no waste).
    #  - a leftover that matches a common item size is reusable -> good.
    #  - a small leftover that no future item likely fits is bad.
    q = np.empty(101, dtype=np.float64)
    for L in range(101):
        if L == 0:
            q[L] = 0.0
            continue
        # reusable if a common item size fits exactly (L itself) or fits within L
        same = prob[L]                       # chance of exact fill
        usable = prob[:L + 1].sum()           # chance some item <= L can use it
        # small leftovers that almost nothing can use are penalized
        fragment_penalty = max(0.0, 6.0 - L) * (1.0 - usable) * 0.5
        q[L] = 4.0 * same + 1.5 * usable - fragment_penalty

    # Only apply the quality term among bins within a small window of the best fit,
    # so best-fit remains the dominant criterion.
    best = leftovers.min()
    near = (leftovers <= best + 2)
    score = np.where(near, score + q[leftovers], score)

    return score
# EVOLVE-BLOCK-END
