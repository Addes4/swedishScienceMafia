# EVOLVE-BLOCK-START
"""Best-fit with residual-value tie-break using an empirical item-size histogram."""
import numpy as np

_state = {"min_item": 100, "counts": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    counts = _state["counts"]

    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item

    # Empirical distribution over item sizes seen so far.
    n = _state["n"]
    if n > 0:
        probs = counts / n
    else:
        probs = None

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Secondary: probability that a future item can still fit in this residual.
    # P(fit) = sum over sizes s <= residual of probs[s].
    if probs is not None:
        cdf = np.cumsum(probs)  # cdf[r] = P(size <= r)
        usable = cdf[np.clip(residual, 0, 100)]
    else:
        usable = (residual > 0).astype(np.float64)
    usable = np.where(residual == 0, 1.0, usable)

    # Bonus for exact fill (no waste at all).
    bonus = np.where(residual == 0, 0.5, 0.0)

    # Update histogram after scoring (so current item isn't in its own decision,
    # matching the online setting).
    counts[item] += 1.0
    _state["n"] = n + 1.0

    # Scale the secondary term to be a tie-breaker, dominant only near ties.
    return primary + 0.9 * usable + bonus
# EVOLVE-BLOCK-END
