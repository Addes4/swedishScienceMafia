# EVOLVE-BLOCK-START
"""Interval-based bin choice (Harmonic/Modified-Harmonic-style) layered on best-fit.

Items are classified by size into intervals. For the arriving item of size s we pick a
"target leftover" range [lo, hi) derived from s, and strongly prefer bins whose remaining
capacity lies in that range. Within the preferred range we use best-fit (tightest fit).
If no bin has capacity in the preferred range, we fall back to plain best-fit.

This mimics interval/class-based packing: large items go into bins that will later be
filled by the small items that belong to the matching class, reducing fragmentation
compared with pure best-fit.
"""
import numpy as np


# Size classes: upper bound (inclusive) -> target leftover window lower bound.
# The window is [lo, 2*lo) i.e. the residual band assigned to this class, so a bin
# receiving an item of this class is expected to be completed by items of size ~lo.
_CLASSES = (
    (50, 34),   # big items: reserve room for one more large-ish item
    (34, 26),
    (26, 20),
    (20, 14),
    (14, 10),
    (10, 7),
    (7, 5),
    (5, 3),
    (3, 2),
    (2, 1),
)


def _target(item):
    """Return (lo, hi) leftover window for an item of this size."""
    for ub, lo in _CLASSES:
        if item <= ub:
            return lo, 2 * lo
    return 1, 2


def priority(item, bins):
    """Return a priority per bin; highest wins, first bin on ties."""
    lo, hi = _target(item)

    # remaining capacity after placing the item
    leftover = bins - item

    # In-class bins: leftover inside the target window.
    in_class = (leftover >= lo) & (leftover < hi)

    # Primary key: prefer in-class bins (1) over others (0).
    # Secondary key: tighter fit (smaller leftover) within whatever tier.
    scores = in_class.astype(np.float64) * 1000.0 - leftover.astype(np.float64)
    return scores
# EVOLVE-BLOCK-END
