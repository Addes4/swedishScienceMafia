# EVOLVE-BLOCK-START
"""Best-fit with residual-aware soft scoring using an empirical item histogram."""
import numpy as np

_state = {"min_item": 100, "hist": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item
    _state["hist"][item] += 1.0
    _state["n"] += 1.0

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Probability that some past item size can exactly fill a residual r.
    # Use histogram mass over sizes <= max residual; reward exact fills strongly.
    hist = _state["hist"]
    n = _state["n"]

    # Exact-fill probability for each residual value.
    res_clipped = np.clip(residual, 0, 100).astype(np.int64)
    exact_p = hist[res_clipped] / n  # prob a past item equals residual

    # Unusable sliver: residual below smallest item ever seen -> very likely wasted.
    sliver_thresh = _state["min_item"]
    penalty = np.where((residual > 0) & (residual < sliver_thresh), 1.0, 0.0)

    # Exact-fill bonus scaled by empirical probability (bounded, small vs primary).
    bonus = 2.0 * exact_p
    bonus = np.where(residual == 0, 0.5, bonus)

    return primary + bonus - penalty
# EVOLVE-BLOCK-END
