# EVOLVE-BLOCK-START
"""Best-fit with a robust residual-aware tie-break to avoid unusable slivers."""
import numpy as np

_state = {
    "count": 0,
    "min_item": 100,
}

# We keep best-fit as the dominant rule (strong baseline), but add a small,
# robust secondary term: prefer residuals that are likely to be exactly fillable
# by a future item.  Rather than the noisy observed minimum (which is corrupted
# by a single tiny item early in the stream), we use a conservative, smoothly
# increasing estimate of the "small unusable residual" threshold.
_state = {"count": 0, "min_item": 100}


def priority(item, bins):
    """Score each bin; highest score wins (ties -> first)."""
    st = _state
    st["count"] += 1
    if item < st["min_item"]:
        st["min_item"] = item

    residual = bins - item  # capacity left after placing the item

    # Best-fit primary: smaller residual is better.
    primary = -residual.astype(np.float64)

    # Sliver penalty: a residual > 0 that is smaller than the smallest item
    # ever seen can never be filled by a single future item.  Penalize those.
    # Use a conservative threshold so a single early tiny item doesn't ruin it.
    thresh = max(1, st["min_item"])
    sliver = (residual > 0) & (residual < thresh)
    penalty = np.where(sliver, 1.0, 0.0)

    # Exact-fill bonus.
    bonus = np.where(residual == 0, 0.5, 0.0)

    # Scale: primary is integer-valued; secondary terms only break ties and
    # nudge among near-ties.
    return primary - penalty + bonus
# EVOLVE-BLOCK-END
