# EVOLVE-BLOCK-START
"""Best-fit with a strong penalty for creating unusably small residuals."""
import numpy as np

MEAN = 40.0
_state = {"min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Dead zone: residuals between 1 and MEAN/2 are likely to become permanent waste,
    # since a typical future item (~40) will not fit. Penalize these strongly.
    # residuals of 0 (exact fill) are ideal; residuals >= MEAN/2 are reusable.
    dead = (residual > 0) & (residual < MEAN / 2.0)
    penalty = np.where(dead, MEAN, 0.0)
    bonus = np.where(residual == 0, MEAN / 2.0, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END
