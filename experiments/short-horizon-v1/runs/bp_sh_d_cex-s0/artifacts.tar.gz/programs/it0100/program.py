# EVOLVE-BLOCK-START
"""Best-fit with a learned residual-utility tie-break."""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.float64), "total": 0.0}

# Precompute reuse value for residuals 0..100 lazily from the empirical item
# distribution: value(r) ~ expected number of future items the residual can hold
# (roughly sum over item sizes s <= r of p(s) * 1), but we only use it as a small
# tie-break bonus on top of best-fit so it never dominates the tight-fit choice.
_reuse_cache = None
_cache_total = -1.0


def _reuse_values(counts, total):
    global _reuse_cache, _cache_total
    if total <= 0:
        return np.zeros(101, dtype=np.float64)
    if _reuse_cache is not None and abs(total - _cache_total) < 1e-9:
        return _reuse_cache
    p = counts / total
    # Probability that a residual r is large enough to accept a random item.
    cum = np.cumsum(p)  # cum[r] = P(item <= r)
    vals = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        vals[r] = cum[r]
    _reuse_cache = vals
    _cache_total = total
    return vals


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    _state["counts"][item] += 1.0
    _state["total"] += 1.0
    total = _state["total"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Reuse value of the resulting residual: probability the residual can accept a
    # random future item. Bounded to [0,1], used only as a near-tie breaker.
    reuse = _reuse_values(_state["counts"], total)
    reuse_term = reuse[np.clip(residual, 0, 100)]

    # Small positive bonus for exact fills (guaranteed reusable, saves future bins).
    bonus = np.where(residual == 0, 0.5, 0.0)

    # Scale primary strongly; reuse term is weak so it only affects near-ties.
    return primary + 0.25 * reuse_term + bonus
# EVOLVE-BLOCK-END
