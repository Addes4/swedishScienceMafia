# EVOLVE-BLOCK-START
"""Best-fit with exact-fill bonus and a light, distribution-aware residual-class tie-break."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "count": 0.0, "min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    hist = _state["hist"]
    hist[item] += 1.0
    _state["count"] += 1.0
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Sliver penalty: residuals in [1, min_item-1) can never be reused.
    sliver_thresh = _state["min_item"]
    sliver = (residual > 0) & (residual < sliver_thresh)
    penalty = np.where(sliver, 1.0, 0.0)
    bonus = np.where(residual == 0, 0.5, 0.0)

    # Light residual-class bonus: prefer residuals that are common item sizes,
    # since these can likely be exactly filled later. Scaled to only matter near ties.
    # Clip residuals to the histogram range (residuals > 100 are just empty-ish bins).
    valid = (residual > 0) & (residual <= 100)
    idx = np.where(valid, residual, 0).astype(np.int64)
    freq = hist[idx] / max(_state["count"], 1.0)
    class_bonus = np.where(valid, freq, 0.0)

    return primary - penalty + bonus + 0.3 * class_bonus
# EVOLVE-BLOCK-END
