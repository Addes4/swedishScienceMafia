# EVOLVE-BLOCK-START
"""Best fit with a stateful gap-completeness tie-break.

Primary rule: minimize the remaining capacity after placement (classic best fit),
which is hard to beat online. The only freedom left is what to do when two bins
end with *exactly* the same leftover. There we prefer the bin whose leftover is
most likely to be exactly fillable by a small number of future items, estimated
from the empirical item-size distribution observed so far in this stream.
"""
import numpy as np


# Module-level state, reset per stream is not possible, but a histogram of sizes
# seen so far is a safe, self-correcting online statistic (it only ever uses past
# items, which is allowed).
_SIZE = 101
_hist = np.zeros(_SIZE, dtype=np.float64)
_seen = 0.0

# How many future items to consider when judging if a leftover gap is "completable".
# We estimate P(gap is fillable by up to K items) via a coarse sum-of-sizes model.
_K = 2


def _gap_score(gap):
    """Estimate the chance a leftover `gap` can be closed by up to _K future items.

    Small gaps that match a common single item size, or that can be split into two
    common sizes, are the most valuable to preserve/aim for.
    """
    if gap <= 0:
        return 0.0
    if _seen < 50:
        # Not enough data yet: neutral.
        return 0.0
    p = _hist / _seen
    # Probability a single item exactly equals the gap.
    s1 = p[gap] if 0 < gap < _SIZE else 0.0
    # Probability two items exactly sum to the gap (coarse convolution).
    s2 = 0.0
    if _K >= 2 and gap >= 2:
        lo = 1
        hi = min(gap - 1, _SIZE - 1)
        if hi >= lo:
            idx = np.arange(lo, hi + 1)
            s2 = float(np.dot(p[idx], p[gap - idx]))
    return s1 + s2


def priority(item, bins):
    global _seen
    # Update the running item-size histogram with the current item.
    if 0 < item < _SIZE:
        _hist[item] += 1.0
        _seen += 1.0

    leftover = bins - item  # the resulting free space of each bin (>= 0)
    # Primary criterion: best fit = smallest leftover. Secondary: prefer a
    # leftover that looks completable by a few future items; tiny tie-break so
    # it never overrides the best-fit ordering.
    gap_scores = np.array([_gap_score(int(l)) for l in leftover], dtype=np.float64)
    return -leftover.astype(np.float64) + 1e-6 * gap_scores
# EVOLVE-BLOCK-END
