# EVOLVE-BLOCK-START
"""Best-fit with a mild sliver penalty keyed to a low threshold."""
import numpy as np

_state = {"count": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    _state["count"] += 1
    _state["sum"] += item

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Sliver penalty: residuals of 1..2 units can rarely be reused; discourage them.
    # Small enough threshold that mid-range residuals remain preferred by best-fit.
    sliver = (residual > 0) & (residual < 3)
    penalty = np.where(sliver, 1.0, 0.0)

    # Exact-fill bonus.
    bonus = np.where(residual == 0, 0.5, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END
