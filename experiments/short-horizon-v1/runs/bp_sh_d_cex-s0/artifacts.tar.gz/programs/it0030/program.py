# EVOLVE-BLOCK-START
"""Best-fit with a waste cap: prefer a tight fit, but fall back to a fresh (empty) bin
when the tightest available fit would leave too large a leftover, reducing fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item  # >= 0 for all shown bins
    empty = (bins == 100)

    # Primary: minimize leftover (best fit). Empty bins naturally have leftover 100 - item.
    # We boost empty bins so that, when no tight fit exists, we open a fresh bin instead of
    # dropping the item into a loosely-filled bin (which fragments capacity).
    # The boost is strongest for bins giving near-best fits, decaying with leftover size.
    score = -leftover.astype(np.float64)

    # Threshold: a fit is "tight enough" if leftover <= half the item, else opening a new
    # bin is preferable. Use a smooth boost on empties that dominates loose non-empty fits.
    tight = leftover <= item // 2
    boost = np.where(empty & ~tight, item.astype(np.float64), 0.0)
    return score + boost
# EVOLVE-BLOCK-END
