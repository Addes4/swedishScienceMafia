# EVOLVE-BLOCK-START
"""Best-fit with an adaptive, quantile-based sliver penalty."""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _state
    sizes = _state["sizes"]
    sizes.append(item)
    if len(sizes) > 500:
        del sizes[:len(sizes) - 500]

    # Adaptive sliver threshold: small item sizes seen recently.
    arr = np.asarray(sizes)
    thresh = max(2.0, float(np.percentile(arr, 5)))

    residual = bins - item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Sliver penalty: residuals too small to plausibly be reused.
    sliver = (residual > 0) & (residual < thresh)
    penalty = np.where(sliver, 50.0, 0.0)
    # Exact fill bonus.
    bonus = np.where(residual == 0, 5.0, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END
