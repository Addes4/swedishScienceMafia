# EVOLVE-BLOCK-START
"""Best-fit with a scaled sliver penalty and exact-fill bonus."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item
    residual_f = residual.astype(np.float64)

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual_f

    # Sliver penalty: residuals in (0, min_item) can never be reused.
    # Scale by residual magnitude so it competes with best-fit differences.
    sliver_thresh = _state["min_item"]
    sliver = (residual > 0) & (residual < sliver_thresh)
    # Penalize slivers roughly by how much smaller they are than the usable threshold.
    penalty = np.where(sliver, 3.0 * (sliver_thresh - residual_f), 0.0)

    # Exact fills get a strong bonus.
    bonus = np.where(residual == 0, 100.0, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END
