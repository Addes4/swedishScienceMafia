# EVOLVE-BLOCK-START
"""Best-fit with a learned 'dead sliver' avoidance using a running item-size histogram.

Primary idea: pure best-fit creates tiny leftovers that can never be used again. We keep a
running estimate of the distribution of item sizes seen so far in this stream. When the tightest
fitting bin would leave a leftover that is smaller than the smallest item size we have seen
recently (a "dead" sliver), we instead choose the tightest bin whose resulting leftover is at
least that minimum usable size. Otherwise we do plain best-fit. This is a genuine departure from
pure best-fit while staying conservative and online.
"""
import numpy as np

_state = {"min_seen": 101, "n": 0}


def priority(item, bins):
    # Update running statistics of arriving items (state persists within a stream).
    _state["n"] += 1
    if item < _state["min_seen"]:
        _state["min_seen"] = item

    leftover = bins - item  # remaining capacity if item placed here (all bins fit by contract)

    # Tightest fit (largest leftover reduction) is the smallest leftover >= 0.
    order = np.argsort(leftover, kind="stable")

    # Threshold for a "usable" leftover: at least the smallest item seen so far.
    usable = _state["min_seen"] if _state["min_seen"] <= 100 else 1

    # If the tightest fit leaves a dead sliver, try to find the tightest fit among bins whose
    # resulting leftover is either 0 (perfect) or >= usable threshold.
    best_idx = order[0]
    best_left = leftover[best_idx]
    if best_left == 0:
        winner = best_idx
    else:
        winner = None
        # Prefer a perfect fill (leftover exactly 0) if available.
        zero_mask = leftover == 0
        if np.any(zero_mask):
            winner = int(np.argmax(zero_mask))
        elif best_left < usable:
            # Look for the tightest bin whose leftover is >= usable.
            good = leftover >= usable
            if np.any(good):
                cand = np.where(good)[0]
                # tightest = smallest leftover among the good ones
                winner = int(cand[np.argmin(leftover[cand])])
            else:
                winner = best_idx
        else:
            winner = best_idx

    scores = np.zeros(len(bins), dtype=float)
    scores[winner] = 1.0
    return scores
# EVOLVE-BLOCK-END
