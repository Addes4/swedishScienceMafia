# EVOLVE-BLOCK-START
"""Best fit with a light stateful tie-break to avoid always hitting the first tied bin.

Primary rule: strict best fit -- place the item in the bin whose remaining capacity is
smallest while still fitting it (minimizes post-placement leftover). Because numpy's
argmax resolves ties by lowest index, plain best-fit always packs into the earliest tied
bin, which tends to concentrate items and leave other partially-filled bins untouched.
We add a tiny, deterministic, stateful jitter so that tied bins get rotated, spreading
placements and letting more partially-filled bins be filled before new bins are opened.
"""
import numpy as np

_state = {"tick": 0}


def priority(item, bins):
    """Return a priority per bin; the item goes to the highest (first on ties).

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    _state["tick"] += 1
    tick = _state["tick"]

    # Strict best fit: smaller post-placement leftover -> higher score.
    leftover = bins - item
    score = -leftover.astype(np.float64)

    # Tiny rotational jitter to break index-order ties.
    n = bins.shape[0]
    if n > 1:
        idx = np.arange(n, dtype=np.float64)
        jitter = ((idx + tick) % n) * 1e-9
        score = score + jitter

    return score
# EVOLVE-BLOCK-END
