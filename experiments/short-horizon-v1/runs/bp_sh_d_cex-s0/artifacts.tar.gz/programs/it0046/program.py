# EVOLVE-BLOCK-START
"""Best-fit with distribution-aware tie-breaking among near-tied bins.

Primary rule: best fit (place the item in the bin with the smallest remaining capacity
that still fits it), which is the strongest simple online rule here.

Secondary rule: when several bins are within a small window of the tightest fit, the choice
among them barely affects how many bins are consumed, but it can affect future fragmentation.
Among these near-tied candidates we prefer the one whose resulting leftover (bins - item) is
most likely to be usable by a future item, estimated from a running histogram of the item
sizes seen so far in this stream.
"""
import numpy as np

# Keep a simple per-stream histogram of observed item sizes (index 1..100).
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0
_WINDOW = 3  # capacity units within which bins are considered near-tied


def _usable_prob(leftover):
    """Approximate probability that a future item is <= leftover, using observed sizes."""
    if leftover <= 0:
        return 0.0
    if leftover >= 100:
        return 1.0
    if _TOTAL <= 0:
        # No data yet: assume roughly uniform-ish, favor being able to fit more.
        return leftover / 100.0
    return float(_HIST[1:leftover + 1].sum()) / _TOTAL


def priority(item, bins):
    global _TOTAL
    bins = np.asarray(bins)
    res = bins - item  # resulting leftover after placing the item
    min_res = res.min()

    # Record the observed item size for future lookahead.
    _HIST[item] += 1.0
    _TOTAL += 1

    # Candidates: bins whose resulting leftover is within WINDOW of the tightest fit.
    cand = np.nonzero(res <= min_res + _WINDOW)[0]

    if cand.size == 1:
        scores = np.full(bins.shape, -1e18, dtype=np.float64)
        scores[cand[0]] = 0.0
        return scores

    # Among near-tied candidates, prefer the leftover most likely to be usable in future.
    best_idx = -1
    best_key = None
    for idx in cand:
        lo = int(res[idx])
        if lo == 0:
            key = (1, 0.0)  # exact perfect fill is best
        else:
            key = (0, _usable_prob(lo))
        if best_key is None or key > best_key:
            best_key = key
            best_idx = idx

    scores = np.full(bins.shape, -1e18, dtype=np.float64)
    scores[best_idx] = 0.0
    return scores
# EVOLVE-BLOCK-END
