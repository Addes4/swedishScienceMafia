# EVOLVE-BLOCK-START
"""Best fit, with a complementary-fit refinement based on recent item sizes."""
import numpy as np


class _State:
    def __init__(self):
        # Exponential moving average of recent item sizes (small history to allow drift).
        self.mean = 40.0
        self.count = 0
        self.hist = []  # recent items for a rough distribution estimate
        self.hist_cap = 200


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state

    # Update running statistics with the arriving item (this is a past item now).
    st.count += 1
    alpha = 0.05
    st.mean = (1.0 - alpha) * st.mean + alpha * float(item)
    st.hist.append(int(item))
    if len(st.hist) > st.hist_cap:
        # Drop oldest entries occasionally to bound cost.
        del st.hist[:50]

    # Pure best fit score: tighter fit (smaller leftover after placing) is better.
    leftover = bins - item  # >= 0 for all bins shown
    score = -(leftover.astype(np.float64))

    # Complementary-fit refinement: for items not too small, add a bonus when the leftover
    # after placement is close to a typical future item size, encouraging pairings that
    # fill the bin more completely rather than leaving awkward medium residuals.
    if item >= 20 and st.count > 5:
        m = st.mean if st.mean > 1.0 else 40.0
        # Prefer leftovers that are near a typical item size (so a later item can fill them),
        # but never override a tighter fit by too much.
        closeness = -np.abs(leftover.astype(np.float64) - m) / 100.0
        # Weight is modest to avoid disturbing pure best-fit behavior on small streams.
        score = score + 0.5 * closeness

    return score
# EVOLVE-BLOCK-END
