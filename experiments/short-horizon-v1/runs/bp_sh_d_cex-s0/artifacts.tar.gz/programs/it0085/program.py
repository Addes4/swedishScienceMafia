# EVOLVE-BLOCK-START
"""Best-fit with histogram-based perfect-fill anticipation."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "count": 0}


def priority(item, bins):
    """Rank bins: best-fit dominant, with a bonus for residuals future items likely fill."""
    hist = _state["hist"]
    hist[item] += 1.0
    _state["count"] += 1
    total = _state["count"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Perfect-fill anticipation: bonus if the resulting residual is a size
    # seen recently (probability mass that a future item exactly fits).
    prob = hist / total
    bonus = prob[np.clip(residual, 0, 100)]

    # Exact fill (residual 0) always strongly preferred.
    bonus = np.where(residual == 0, 1.0, bonus)

    # Secondary terms must not override best-fit; scale small.
    return primary + 0.1 * bonus
# EVOLVE-BLOCK-END
