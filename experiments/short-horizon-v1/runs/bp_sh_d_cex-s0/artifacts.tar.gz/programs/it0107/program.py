# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware reusable-residual tie-break.

Items come from a Weibull-shaped distribution with mean ~40, so a residual is
"reusable" only if it is large enough to hold a typical small future item.
Pure best-fit minimizes waste per placement, but it can create residuals that
are too small to ever be reused (dead space).  We keep best-fit as the primary
signal but break near-ties in favour of residuals that are likely reusable.
"""
import numpy as np

_state = {"min_item": 100, "hist": None}
_BINS = 101


def _reuse_value(residual, min_item):
    """Estimate how reusable a residual is, on a 0..~1 scale.

    residual is an int array of post-placement remaining capacities (>= 0).
    A residual of 0 is a perfect fill (best).  A residual smaller than the
    smallest item observed so far can never be reused (worst among non-zero).
    Larger residuals are progressively more reusable.
    """
    r = residual.astype(np.float64)
    # Perfect fill: fully reusable / no waste.
    exact = (r == 0).astype(np.float64)
    # Fraction of the residual that a typical item can make use of.
    # Use a soft threshold at the smallest seen item size.
    denom = max(float(min_item), 1.0)
    reusable = np.clip((r - denom) / denom, -1.0, 1.0)
    return exact - np.clip(-reusable, 0.0, 1.0) * 0.5 + np.clip(reusable, 0.0, 1.0) * 0.1


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item, >= 0

    # Best-fit primary signal: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Distribution-aware tie-break: reward residuals that are reusable.
    tie = _reuse_value(residual, _state["min_item"])

    # Small weight so the tie-break only matters when residuals are near-equal.
    return primary + 0.5 * tie
# EVOLVE-BLOCK-END
