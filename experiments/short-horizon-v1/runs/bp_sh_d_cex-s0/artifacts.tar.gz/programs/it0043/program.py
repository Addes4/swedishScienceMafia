# EVOLVE-BLOCK-START
"""Best fit with perfect-fill bonus and tiny-fragment penalty."""
import numpy as np


def priority(item, bins):
    """Rank bins: reward exact fill, penalize useless tiny fragments, then tight fit."""
    resid = bins - item
    score = -resid.astype(np.float64)
    # Bonus for exactly filling a bin (residual == 0).
    score += np.where(resid == 0, 1000.0, 0.0)
    # Penalize leftovers too small to hold common tiny items (1..item_min_useful).
    # Weibull-shaped sizes: a leftover below ~5 is nearly unusable.
    small = (resid > 0) & (resid < 5)
    score -= np.where(small, 50.0, 0.0)
    return score
# EVOLVE-BLOCK-END
