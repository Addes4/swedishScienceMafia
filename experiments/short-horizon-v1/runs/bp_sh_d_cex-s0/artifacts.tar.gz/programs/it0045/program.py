# EVOLVE-BLOCK-START
"""Focused best-fit variant: minimize squared distance of leftover to a target,
which spreads fragments to keep bins flexible while staying close to tight fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item
    # Target leftover proportional to item size (half the item), so bins end up
    # with capacity likely to accept another similar item, avoiding dead slivers.
    target = item * 0.5
    return -np.abs(leftover - target)
# EVOLVE-BLOCK-END
