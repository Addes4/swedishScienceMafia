# EVOLVE-BLOCK-START
"""Best-fit with a sharper small-gap penalty to avoid unusable slivers."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Penalize tiny unusable gaps sharply; reward exact fills.
    # Small gap width is capped so the term only matters near best-fit ties.
    small_gap = (residual > 0) & (residual < 8)
    penalty = np.where(small_gap, 0.9, 0.0)
    bonus = np.where(residual == 0, 0.75, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END
