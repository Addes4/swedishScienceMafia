# EVOLVE-BLOCK-START
"""Best fit with a gentle residual-reusability tie-breaker.

The dominant criterion is classic best fit: place the item in the fitting bin with
the smallest remaining capacity, i.e. the tightest fit.  To avoid lavishing many
bins with tiny, forever-unusable slivers, among bins whose tightness is within a
very small window we add a mild preference for leftovers that are either a perfect
fill (0) or large enough to plausibly accept another item (>= a running mean).
The tie-break is scaled so it can never overcome a meaningful difference in fit.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item               # leftover capacity after placing the item
    tightness = -rem                # primary: best fit (smallest rem) is best

    # A small, bounded bonus for residuals that stay reusable.
    #   * exact fill (rem == 0) is ideal
    #   * any rem >= ~mean item size (about 40) can still take a normal item
    bonus = np.where(rem == 0, 1.0, 0.0)
    bonus += np.where(rem >= 35, 1.0, 0.0)

    # Scale so the bonus only matters when tightness values are essentially tied.
    return tightness.astype(np.float64) + 0.01 * bonus
# EVOLVE-BLOCK-END
