# EVOLVE-BLOCK-START
"""Stateful harmonic-slot best fit: rank bins by how well the leftover matches
the empirical distribution of future item sizes."""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    counts = _state["counts"]
    n = _state["n"]
    # Running (decayed) histogram of item sizes; small decay so it adapts.
    counts *= 0.999
    counts[item] += 1.0
    _state["n"] = n + 1.0

    leftover = bins - item  # post-placement remaining capacity

    # Strict best fit as the dominant term.
    score = -leftover.astype(np.float64)

    if _state["n"] > 50:
        tot = counts.sum()
        if tot > 0:
            p = counts / tot
            # For each candidate leftover L, estimate the probability that a future
            # item exactly fits, i.e. L (leaving a perfectly full bin). Reward small,
            # achievable positives and the zero leftover most; penalize unusable gaps
            # that are smaller than the minimum plausible item.
            # prob future item == L
            fit_p = np.where(leftover >= 1, p[np.clip(leftover, 0, 100)], 0.0)
            # prob future item < L (can still make progress)
            cum = np.cumsum(p)
            prog_p = np.where(leftover >= 1, cum[np.clip(leftover - 1, 0, 100)], 0.0)
            # tiny tie-breaking nudge (won't override primary integer difference)
            score = score + 1e-3 * (fit_p + 0.1 * prog_p)
    return score
# EVOLVE-BLOCK-END
