# EVOLVE-BLOCK-START
"""Stateless best-fit: choose the bin leaving the smallest residual after placement."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Best-fit: tighter fit (smaller residual) is strictly better.
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

