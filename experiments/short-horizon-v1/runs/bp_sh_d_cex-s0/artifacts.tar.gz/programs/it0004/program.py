# EVOLVE-BLOCK-START
"""Best fit with a residual-penalty: prefer tight fits, but avoid leaving leftovers
that are awkward relative to the typical item size (~40)."""
import numpy as np

# Running statistics of item sizes seen so far in this stream (reset per stream).
_state = {"n": 0, "sum": 0.0, "sumsq": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running mean/std of item sizes (cheap, no future info used).
    _state["n"] += 1
    _state["sum"] += item
    _state["sumsq"] += item * item

    n = _state["n"]
    mean = _state["sum"] / n
    var = max(_state["sumsq"] / n - mean * mean, 1.0)
    std = var ** 0.5

    # Residual capacity left in each bin after placing the item.
    left = bins - item  # all >= 0 since bins only contains fitting bins

    # Best-fit basis: tighter leftover is better (smaller 'left' => higher score).
    score = -left.astype(np.float64)

    # Penalty for leftovers that are likely to become stranded:
    # a leftover L is "awkward" if it is too big to be cheaply closed by small items
    # but too small to reliably receive a full typical item.
    # Model: probability that a future item fits in L is roughly P(item <= L).
    # We approximate the CDF with a smooth function around the running mean.
    L = left.astype(np.float64)
    # Estimated fraction of future items that would fit into the leftover.
    # Use a logistic approximation centered at the running mean.
    fit_frac = 1.0 / (1.0 + np.exp((L - mean) / std))

    # Reward leftovers that are either very small (bin nearly closed) or can hold
    # a typical item; penalize the in-between "dead zone".
    # Small leftover => good (close the bin). Moderate leftover near mean => also ok.
    dead_zone = np.exp(-((L - mean) ** 2) / (2.0 * var))
    score -= 3.0 * dead_zone * (1.0 - fit_frac)

    return score
# EVOLVE-BLOCK-END
