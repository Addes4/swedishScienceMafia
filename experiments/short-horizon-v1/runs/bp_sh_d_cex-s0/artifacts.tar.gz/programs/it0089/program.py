# EVOLVE-BLOCK-START
"""Best-fit with a mild, scaled sliver penalty and exact-fill bonus."""
import numpy as np

_state = {"min_item": 100, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item
    _state["count"] += 1

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Sliver penalty: a residual strictly below the smallest item seen so far
    # can (almost) never be reused. Penalize, but only mildly so it never
    # overrides the best-fit ordering except among near-ties.
    sliver_thresh = max(1, _state["min_item"])
    sliver = (residual > 0) & (residual < sliver_thresh)
    penalty = np.where(sliver, 0.25, 0.0)

    # Exact fills close a bin perfectly; reward them.
    bonus = np.where(residual == 0, 0.75, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END
