# EVOLVE-BLOCK-START
"""Harmonic-style bucketing combined with best-fit leftover.

Classic online bin packing results (Lee & Lee, Ramanan et al.) show that for a
Weibull-shaped item distribution with mean ~40, plain best-fit fragments badly
because it keeps creating bins with tiny leftovers that only very small items
can fill.  A harmonic-style scheme that partitions items into size classes and
maps each class to a target bin-fill band reduces that fragmentation.

The harness only lets us *rank* the bins we are handed, so we implement the
classic rule as a score: each bin gets a score based on how well its current
remaining capacity matches the preferred "band" for this item's size class,
with a best-fit (tightest leftover) term as tiebreaker / within-band ranking.
"""
import numpy as np


# Item-size classes.  Bounds are fractions of the bin capacity (100).
# The intent: big items prefer nearly-empty bins, small items prefer bins that
# are nearly full (so their tiny leftovers get consumed), and mid items prefer
# bins whose fill is in a specific band that completes them well.
def _class_of(size):
    # size in 1..100 -> class index and the preferred leftover band [lo, hi]
    if size > 50:            # too big to pair with anything meaningful
        return 0
    if size > 100 // 3:      # 34..50 : two roughly fit, prefer near-empty
        return 1
    if size > 25:            # 26..33
        return 2
    if size > 20:            # 21..25
        return 3
    if size > 100 // 6:      # 17..20
        return 4
    if size > 100 // 7:      # 15..16
        return 5
    if size > 100 // 8:      # 13..14
        return 6
    if size > 100 // 9:      # 12
        return 7
    if size > 10:            # 11
        return 8
    if size > 100 // 12:      # 9..10
        return 9
    if size > 8:
        return 10
    if size > 100 // 20:      # 6..8
        return 11
    if size > 5:
        return 12
    if size > 4:
        return 13
    if size > 3:
        return 14
    if size > 2:
        return 15
    return 16


def priority(item, bins):
    """Rank bins for an arriving item; highest score wins (first on ties)."""
    b = np.asarray(bins, dtype=np.int64)

    # Remaining capacity after placing the item here.
    leftover = b - item

    cls = _class_of(int(item))

    # Preferred resulting leftover band.  A leftover inside the band is
    # considered "ideal" for this item class; we then break ties by tightest
    # leftover (best-fit).  Outside the band we still push toward the band so
    # that bins gravitate to the right fill level for their typical fillers.
    if cls == 0:      # item > 50 : aim for near-empty bins (small leftover after)
        lo, hi = 0, 50
    elif cls == 1:    # 34..50  : finish a bin nicely (leftover near 0..50)
        lo, hi = 0, 50
    elif cls == 2:    # 26..33  : leftover 0..40 helps round out
        lo, hi = 0, 40
    elif cls == 3:    # 21..25
        lo, hi = 0, 35
    elif cls == 4:    # 17..20
        lo, hi = 0, 30
    else:
        # Smaller items: strongly prefer bins that are already fairly full so
        # that their small leftovers accumulate toward a full bin instead of
        # being spread across many nearly-empty bins.
        lo, hi = 0, max(1, 100 // (cls + 2))

    # Band membership (0/1); within band, prefer tightest leftover.
    in_band = ((leftover >= lo) & (leftover <= hi)).astype(np.float64)

    # Primary: in-band.  Secondary: closest to the "ideal" leftover, which we
    # set to the low end of the band (tightest packing inside the band).
    target = float(lo)
    dist = np.abs(leftover - target).astype(np.float64)

    # Strong preference to stay in the band, then minimize distance to target.
    return in_band * 1000.0 - dist
# EVOLVE-BLOCK-END
