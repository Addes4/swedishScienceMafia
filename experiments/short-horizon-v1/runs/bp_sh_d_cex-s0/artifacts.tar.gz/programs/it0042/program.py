# EVOLVE-BLOCK-START
"""Best fit with a small nudge to avoid tiny dead leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item
    # Base: tighter fit (smaller leftover) is better.
    base = -leftover.astype(np.float64)
    # Bonus for perfectly filled; small penalty for useless tiny fragments.
    bonus = np.where(leftover == 0, 2.0, 0.0)
    tiny = (leftover > 0) & (leftover < 8)
    penalty = np.where(tiny, 0.5, 0.0)
    return base + bonus - penalty
# EVOLVE-BLOCK-END
