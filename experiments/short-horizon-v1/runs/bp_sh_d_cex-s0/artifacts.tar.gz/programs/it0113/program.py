# EVOLVE-BLOCK-START
"""Best-fit with adaptive sliver threshold based on observed max item size."""
import numpy as np

_state = {"max_item": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item > _state["max_item"]:
        _state["max_item"] = item

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Sliver penalty: residuals below the largest item seen cannot be refilled
    # by anything as large, so they are effectively dead space. Penalize them
    # and reward exact fills slightly.
    thresh = _state["max_item"]
    sliver = (residual > 0) & (residual < thresh)
    penalty = np.where(sliver, 1.0, 0.0)
    bonus = np.where(residual == 0, 0.5, 0.0)

    # Scale: make sliver-avoidance dominate tightness so we never strand
    # a residual that is provably unusable, but keep tightest-fit as tiebreak.
    return primary * 0.01 - penalty * 100.0 + bonus * 10.0
# EVOLVE-BLOCK-END

