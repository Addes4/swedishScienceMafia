# EVOLVE-BLOCK-START
"""Gap-aware best fit: prefer exact/near fills, penalize unusable tiny leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item
    # Base: prefer the tightest fit (smallest leftover).
    score = -leftover.astype(np.float64)
    # Strong bonus for exact fills: these close a bin cleanly.
    score += 1e6 * (leftover == 0)
    # Penalize leaving a leftover in (0, small) that no future item can use well.
    # Treat leftovers < 10 as if they were effectively wasted, below a plain best-fit.
    tiny = (leftover > 0) & (leftover < 10)
    score -= 1e3 * tiny
    return score
# EVOLVE-BLOCK-END
