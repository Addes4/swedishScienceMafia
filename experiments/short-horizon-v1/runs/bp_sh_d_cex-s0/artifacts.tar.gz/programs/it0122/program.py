# EVOLVE-BLOCK-START
"""Best-fit with an empirical reusable-residual tie-break."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "count": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties)."""
    global _state

    # Update empirical item-size histogram (with mild decay to stay adaptive).
    _state["hist"] *= 0.999
    _state["hist"][item] += 1.0
    _state["count"] = _state["count"] * 0.999 + 1.0
    hist = _state["hist"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Empirical probability that a future item can fit into each candidate residual.
    # reuse_prob[r] = sum of hist[s] for s <= r  (fraction of past items fitting residual r)
    csum = np.cumsum(hist)  # csum[r] = mass of items with size <= r
    reuse_prob = csum[np.clip(residual, 0, 100)] / _state["count"]

    # Bonus for reusability, and a stronger bonus for exact fills.
    bonus = 0.4 * reuse_prob + np.where(residual == 0, 0.5, 0.0)

    # Scale primary so the small secondary terms only resolve near-ties.
    return primary + bonus
# EVOLVE-BLOCK-END
