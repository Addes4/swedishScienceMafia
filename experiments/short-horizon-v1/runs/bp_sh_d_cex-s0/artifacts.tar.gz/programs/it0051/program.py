# EVOLVE-BLOCK-START
"""Best-fit with a small residual-reuse bonus.

Primary criterion is tightest fit (best-fit). A small additive bonus is given to
bins whose leftover after placement is 0 or near the typical item size, since
such leftovers are more likely to be reused by later items, reducing wasted
slivers. The bonus is scaled well below 1 so it only breaks near-ties.
"""
import numpy as np

# running mean of item sizes (used as the "reusable leftover" target)
_state = {"n": 0, "mean": 40.0}


def priority(item, bins):
    global _state
    n = _state["n"]
    mean = _state["mean"]
    # update running mean
    n += 1
    mean += (item - mean) / n
    _state["n"] = n
    _state["mean"] = mean

    leftover = bins - item  # residual capacity after placing item

    # best-fit primary: prefer smallest leftover (negative bins-item = tightest)
    primary = -(leftover.astype(np.float64))

    # residual-reuse bonus: reward leftovers that are 0 or near the mean item size
    target = mean
    d_zero = np.abs(leftover.astype(np.float64))
    d_mean = np.abs(leftover.astype(np.float64) - target)
    bonus = 0.5 * (1.0 / (1.0 + d_zero)) + 0.5 * (1.0 / (1.0 + 0.25 * d_mean))

    return primary + bonus
# EVOLVE-BLOCK-END
