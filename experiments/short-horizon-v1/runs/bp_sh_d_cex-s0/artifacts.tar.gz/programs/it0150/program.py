# EVOLVE-BLOCK-START
"""Worst-fit placement: put each item into the emptiest bin that fits.

Best-fit tends to shred the remaining capacity of partially-full bins into
slivers too small to ever be reused, wasting bins.  Worst-fit spreads the
load so no bin is reduced below the point of usability, which is robust and
needs no fragile state.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    # Highest remaining capacity (emptiest bin that still fits) wins.
    # Empty bins (capacity 100) are preferred over partially used ones, which
    # keeps the number of touched bins low and avoids unusable slivers.
    return bins.astype(np.float64)
# EVOLVE-BLOCK-END
