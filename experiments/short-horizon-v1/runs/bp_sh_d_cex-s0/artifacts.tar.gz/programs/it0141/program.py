# EVOLVE-BLOCK-START
"""Best-fit with mode-targeted residual tie-break."""
import numpy as np

_state = {"min_item": 100, "n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Target residual: a gap near the mean item size is the most reusable.
    target = mean_item
    dist = np.abs(residual - target).astype(np.float64)

    # Bonus for exact fill (residual 0) and for residuals close to the target gap.
    exact = np.where(residual == 0, 1.0, 0.0)
    # Only reward residuals that are at least as large as the smallest item seen.
    usable = residual >= _state["min_item"]
    near_target = np.where(usable, 1.0 / (1.0 + dist), 0.0)

    # Scale so secondary terms only matter near best-fit ties.
    return primary + 0.5 * exact + 0.5 * near_target
# EVOLVE-BLOCK-END

