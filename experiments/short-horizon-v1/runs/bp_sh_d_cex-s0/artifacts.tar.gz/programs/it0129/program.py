# EVOLVE-BLOCK-START
"""Best-fit refined toward a target residual equal to the running mean item size."""
import numpy as np

_state = {"min_item": 100, "sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item < _state["min_item"]:
        _state["min_item"] = item
    _state["sum"] += item
    _state["n"] += 1
    mean_item = _state["sum"] / _state["n"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Prefer residuals close to the average future item size: such bins are likely
    # to be exactly filled soon, instead of stranding a tiny unusable sliver.
    target = mean_item
    secondary = -np.abs(residual - target) * 0.05

    # Sliver penalty: residuals in [1, min_item-1) can never be reused.
    sliver = (residual > 0) & (residual < _state["min_item"])
    penalty = np.where(sliver, 1.0, 0.0)
    bonus = np.where(residual == 0, 0.5, 0.0)

    return primary + secondary - penalty + bonus
# EVOLVE-BLOCK-END
