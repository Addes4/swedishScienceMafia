# EVOLVE-BLOCK-START
"""Best-fit with distribution-aware sliver penalty for hard-to-fill residuals."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Distribution-aware sliver penalty: a residual that is nonzero but smaller
    # than what a typical (mean-sized) item could use is likely to become a
    # permanent sliver.  Scale small so it only breaks near-ties.
    thresh = max(2.0, 0.5 * mean_item)
    sliver = (residual > 0) & (residual < thresh)
    penalty = np.where(sliver, 0.02, 0.0)
    bonus = np.where(residual == 0, 0.1, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END
