# EVOLVE-BLOCK-START
"""Online bin choice: best fit, but avoid leaving small unusable gaps.

The rule keeps a cheap running estimate of the item-size distribution and scores
each feasible bin by the post-placement remaining capacity, penalising leftovers
that are too small to be reusable (a "harmonic" style gap penalty).  Exact fills
are always preferred most strongly, then tight fits that leave a usable gap.
"""
import numpy as np

# running statistics of observed items (state kept across calls within a stream)
_state = {"n": 0, "sum": 0.0, "sum2": 0.0}


def priority(item, bins):
    """Return a priority per feasible bin; highest score wins (first on ties)."""
    # update running mean/std of item sizes
    _state["n"] += 1
    _state["sum"] += item
    _state["sum2"] += item * item
    n = _state["n"]
    mean = _state["sum"] / n
    var = max(_state["sum2"] / n - mean * mean, 0.0)
    std = var ** 0.5

    # after placing the item, leftover capacity in each bin
    after = bins - item

    # a leftover is "usable" if it can hold at least a small item; use a
    # conservative fraction of the observed mean size (never more than 20).
    threshold = max(1.0, min(20.0, 0.5 * mean - 0.5 * std)) if n > 5 else 1.0

    # base score: prefer small post-placement leftover (best fit)
    score = -after.astype(np.float64)

    # strongly reward exact / near-exact fills
    score += 1000.0 * (after == 0)

    # penalise leftovers that are positive but too small to be reusable
    unusable = (after > 0) & (after < threshold)
    score -= 500.0 * unusable

    # small bonus for leaving a well-rounded reusable gap
    score += 0.01 * after * (after >= threshold)

    return score
# EVOLVE-BLOCK-END
