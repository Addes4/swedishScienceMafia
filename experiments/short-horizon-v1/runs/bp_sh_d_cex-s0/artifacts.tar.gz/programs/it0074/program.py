# EVOLVE-BLOCK-START
"""Best-fit with residual-aware tie-break using an item-size histogram."""
import numpy as np

_state = {"min_item": 100, "hist": None, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    hist = _state["hist"]
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        _state["hist"] = hist
    hist[item] += 1.0
    _state["count"] += 1

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Sliver penalty: residuals that can never be reused (smaller than smallest item seen).
    sliver_thresh = _state["min_item"]
    sliver = (residual > 0) & (residual < sliver_thresh)
    penalty = np.where(sliver, 1.0, 0.0)

    # Exact-fill bonus.
    bonus = np.where(residual == 0, 1.0, 0.0)

    # Pair-completion bias: reward residuals that are near a plausible sum of two
    # item sizes weighted by the running histogram, so partially-filled bins can
    # still close exactly with future items.
    if _state["count"] >= 20:
        probs = hist / _state["count"]
        # distribution of sums of two independent items (size 1..100)
        sum_pmf = np.zeros(201, dtype=np.float64)
        # convolution of probs with itself (size 0..100 for each item)
        for s in range(2, 201):
            lo = max(1, s - 100)
            hi = min(100, s - 1)
            if lo <= hi:
                sum_pmf[s] = float(np.dot(probs[lo:hi + 1], probs[s - hi:s - lo + 1][::-1]))
        # map each residual to closeness to a common attainable-ish target
        # also include single-item targets and residual 100 (fresh bins handled by primary)
        single = probs.copy()
        one = probs
        pair = sum_pmf
        res_idx = np.clip(residual, 0, 200)
        pair_w = pair[res_idx] if residual.max() <= 200 else np.zeros_like(primary)
        # normalize
        denom = pair.max() if pair.max() > 0 else 1.0
        pair_w = pair_w / denom
        one_w = one[np.clip(residual, 0, 100)] / (one.max() if one.max() > 0 else 1.0)
        # prefer residuals likely to be exactly closed by one or two future items
        pair_bonus = 0.6 * (pair_w + one_w)
        pair_bonus = np.where(residual > 0, pair_bonus, 0.0)
    else:
        pair_bonus = np.zeros_like(primary)

    # Scale primary so the small secondary terms only matter near ties.
    return primary - penalty + bonus + pair_bonus
# EVOLVE-BLOCK-END
