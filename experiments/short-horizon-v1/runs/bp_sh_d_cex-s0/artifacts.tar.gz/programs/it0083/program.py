# EVOLVE-BLOCK-START
"""Best-fit primary rule with a mild bias away from closing almost-full bins prematurely."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)

    # Best-fit: prefer the tightest fit (smallest residual).
    primary = -residual

    # Exact fills are always good: boost them slightly.
    bonus = np.where(residual == 0.0, 0.5, 0.0)

    return primary + bonus
# EVOLVE-BLOCK-END
