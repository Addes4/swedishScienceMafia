# EVOLVE-BLOCK-START
"""Best-fit with a robust residual-aware tie-break: prefer exact fills, avoid unusable slivers."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Sliver penalty: residuals in [1, thresh) are likely never reusable.
    # Keep a floor so that if only tiny items have been seen, we still
    # discourage leaving very small gaps.
    thresh = max(_state["min_item"], 4)
    sliver = (residual > 0) & (residual < thresh)
    penalty = np.where(sliver, 1.0, 0.0)
    bonus = np.where(residual == 0, 0.6, 0.0)

    # Scale primary so the small secondary terms only matter near ties.
    return primary - penalty + bonus
# EVOLVE-BLOCK-END
