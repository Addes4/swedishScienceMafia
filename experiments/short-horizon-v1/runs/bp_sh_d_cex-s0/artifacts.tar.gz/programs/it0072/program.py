# EVOLVE-BLOCK-START
"""Best-fit with a small, distribution-aware residual preference.

The dominant rule is best-fit (tightest fit, smallest residual). We add a soft
tie-break that prefers residuals equal to frequent item sizes so that a bin can
later be exactly filled by a common item, improving packing efficiency.
"""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.float64), "total": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    counts = _state["counts"]
    total = _state["total"]

    # Update the running item-size histogram before scoring.
    if 1 <= item <= 100:
        counts[item] += 1.0
    _state["total"] = total + 1.0

    residual = bins - item  # capacity left after placing the item

    # Best-fit primary term: tighter fit => larger score.
    primary = -residual.astype(np.float64)

    # Soft preference: residual values that are themselves common item sizes
    # are worth a little extra, since they can be exactly closed later.
    # Normalize frequency to [0, 1].
    denom = max(_state["total"], 1.0)
    freq = counts / denom
    # frequency of the residual as an item size (residual 0 handled separately)
    res_idx = np.clip(residual, 0, 100).astype(np.int64)
    res_freq = freq[res_idx]
    bonus = res_freq * 3.0  # small relative to the primary 1-unit spacing

    # Extra bonus for exact fills.
    bonus = bonus + np.where(residual == 0, 0.25, 0.0)

    return primary + bonus
# EVOLVE-BLOCK-END
