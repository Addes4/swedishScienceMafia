# EVOLVE-BLOCK-START
"""Best-fit with an empirical 'reusable residual' bonus to avoid dead slivers."""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.float64), "total": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    counts = _state["counts"]
    counts[item] += 1.0
    total = _state["total"] + 1.0
    _state["total"] = total

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Empirical probability that a residual r is reusable: p = P(future item size <= r).
    # Compute via a cumulative sum of the running histogram (smoothed by Laplace prior).
    smoothed = counts + 1.0
    smoothed_total = total + 100.0
    cdf = np.cumsum(smoothed) / smoothed_total  # cdf[r] = P(size <= r)

    r = residual.astype(np.int64)
    r = np.clip(r, 0, 100)
    reuse_prob = cdf[r]
    # Exact fills (r == 0) are ideal; reward them fully.
    reuse_prob = np.where(residual == 0, 1.0, reuse_prob)

    # Reusable residuals preferred; keep secondary weight small so best-fit dominates.
    return primary + 0.5 * reuse_prob
# EVOLVE-BLOCK-END
