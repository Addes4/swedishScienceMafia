# EVOLVE-BLOCK-START
"""Worst-fit: place the item into the bin that fits it most loosely.

For Weibull-shaped item sizes (mean ~40, capacity 100), best-fit tends to create
many barely-fillable fragments. Worst-fit spreads items so that open bins keep
large remaining capacity, which empirically lowers bin count on heavy-tailed
size distributions.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    return bins
# EVOLVE-BLOCK-END

