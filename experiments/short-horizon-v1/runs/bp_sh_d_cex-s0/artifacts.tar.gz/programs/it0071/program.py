# EVOLVE-BLOCK-START
"""Best-fit with a residual-completability tie-break from a running item histogram.

The dominant rule stays best-fit (tightest residual). Among bins whose residual is
within a small tolerance of the tightest fit, we prefer residuals that are more
likely to be exactly closed by a small multiset of future items, estimated by a
bounded knapsack-style DP over the residual using a running item-size histogram.
This reduces the number of unusable slivers and improves pairing without hurting
the strong best-fit baseline.
"""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.float64), "n": 0.0, "cache": {}, "min_item": 100}

# --- small bounded DP: probability mass that residual r can be filled exactly ---
_MAX_R = 100
_tol = 4.0


def _fill_values(counts, n):
    """Estimate, for each residual r in 0..100, a score in [0,1] of being exactly
    closeable by future items, using the empirical size distribution."""
    if n <= 0:
        return np.zeros(_MAX_R + 1, dtype=np.float64)
    p = counts / float(n)  # probability of each size 1..100
    # dp[s] = prob that some multiset of up to K items sums to exactly s.
    # Bounded number of items keeps this cheap and stable.
    K = 3
    reach = np.zeros(_MAX_R + 1, dtype=np.float64)
    reach[0] = 1.0
    cur = reach.copy()
    for _ in range(K):
        nxt = np.zeros(_MAX_R + 1, dtype=np.float64)
        for s in range(_MAX_R + 1):
            v = cur[s]
            if v <= 0.0:
                continue
            for size in range(1, _MAX_R + 1 - s):
                pv = p[size]
                if pv > 0.0:
                    nxt[s + size] += v * pv
        # allow using fewer than K items by keeping the best-so-far mass
        cur = np.maximum(cur, nxt)
    return cur


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    counts = _state["counts"]
    n = _state["n"]
    counts[item] += 1.0
    n += 1.0
    _state["n"] = n

    # Refresh DP periodically (cheap amortized, avoids per-item cost).
    key = int(n)
    if (key % 50 == 0) or (len(_state["cache"]) == 0 and n >= 1):
        counts_now = counts.copy()
        _state["cache"] = {0: _fill_values(counts_now, n)}
    fill = _state["cache"][0]

    residual = bins - item  # remaining capacity after placing this item

    # Best-fit primary: smaller residual is better.
    primary = -residual.astype(np.float64)

    # Completion value: how likely this residual gets exactly filled later.
    rc = np.clip(residual, 0, _MAX_R)
    comp = fill[rc]

    # Among near-best-fit candidates, prefer the more completable residual.
    # Keep best-fit dominant: scale small so it only breaks ties.
    return primary + 0.5 * comp - 0.5 * np.where(residual == 0, 1.0, 0.0)
# EVOLVE-BLOCK-END
