# EVOLVE-BLOCK-START
"""Best-fit with residual-aware tie-break and a tiny index dither on exact fits."""
import numpy as np

_state = {"min_item": 100, "seen": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Sliver penalty: residuals in [1, min_item-1) can never be reused.
    sliver_thresh = _state["min_item"]
    sliver = (residual > 0) & (residual < sliver_thresh)
    penalty = np.where(sliver, 1.0, 0.0)
    bonus = np.where(residual == 0, 0.5, 0.0)

    # Tiny index-based dither so equal-residual bins don't all funnel to bin 0,
    # which can waste future packing potential. Kept far smaller than 1.0.
    n = residual.shape[0]
    idx = np.arange(n, dtype=np.float64)
    dither = idx * (1e-4 / max(1.0, float(n)))

    return primary - penalty + bonus + dither
# EVOLVE-BLOCK-END

