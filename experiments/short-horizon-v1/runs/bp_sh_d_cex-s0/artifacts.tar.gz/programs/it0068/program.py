# EVOLVE-BLOCK-START
"""Best-fit with adaptive sliver avoidance and exact-fill pairing."""
import numpy as np

_state = {"min_item": 100, "n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    _state["n"] += 1
    _state["sum"] += item
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Sliver penalty: avoid leaving residuals that are too small to be reused.
    # Use the smallest item seen so far as an estimate of the smallest reusable residual,
    # but be conservative early in the stream (before we've seen small items).
    min_seen = _state["min_item"]
    sliver_thresh = min_seen
    sliver = (residual > 0) & (residual < sliver_thresh)
    penalty = np.where(sliver, 1.0, 0.0)

    # Exact-fill bonus: strongly reward closing a bin perfectly.
    bonus = np.where(residual == 0, 0.75, 0.0)

    # Penalty for residuals that are just below the current item (hard to refill soon).
    near = (residual > 0) & (residual < item)
    near_penalty = np.where(near, 0.25, 0.0)

    return primary - penalty - near_penalty + bonus
# EVOLVE-BLOCK-END
