# EVOLVE-BLOCK-START
"""Smart best fit: minimize post-placement leftover, but mildly discount
gaps that are unlikely to ever be reused."""
import numpy as np


def priority(item, bins):
    leftover = bins - item
    # Base: prefer smallest leftover (best fit).
    score = -leftover.astype(np.float64)
    # Penalize leaving a tiny leftover that no future item (min size 1)
    # can usefully exploit beyond size 1; such fragments waste a bin's slot.
    # A leftover in [1, some small] is still usable, but a leftover that is
    # large yet poorly aligned is also bad. Mildly favor leftovers that are
    # either 0 (perfect) or comfortably large (>= 25) over awkward mid gaps.
    L = leftover.astype(np.float64)
    # bonus for perfect fill
    score += np.where(leftover == 0, 0.5, 0.0)
    # small bonus for leaving a reasonably large usable gap (>= 25)
    score += np.where(leftover >= 25, 0.15, 0.0)
    return score
# EVOLVE-BLOCK-END
