# EVOLVE-BLOCK-START
"""Best-fit with a gentle exact-fill preference (classic online bin packing heuristic)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item
    # Primary: tightest fit (best fit). Secondary: prefer exact fills slightly.
    score = -leftover.astype(np.float64)
    return score
# EVOLVE-BLOCK-END

