# EVOLVE-BLOCK-START
"""Best-fit with a smooth, mean-calibrated residual-waste penalty."""
import numpy as np

_state = {"min_item": 100, "count": 0, "sum": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    st = _state
    st["count"] += 1
    st["sum"] += item
    st["mean"] = st["sum"] / st["count"] if st["count"] else 40.0
    if item < st["min_item"]:
        st["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item
    mean = st["mean"] if st["mean"] > 0 else 40.0

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Smooth waste penalty: residuals that are small but below the typical
    # item size are hard to reuse. Penalty rises smoothly as residual moves
    # from `mean` down to 0 (excluding exact fill, which is rewarded).
    r = residual.astype(np.float64)
    # 0 at residual>=mean, grows as residual -> 0
    frac = np.clip((mean - r) / mean, 0.0, 1.0)
    waste_penalty = frac  # in [0,1], bigger for harder-to-fill residuals

    # Exact fill gets a strong reward to dominate near-ties.
    exact_bonus = np.where(residual == 0, 1.0, 0.0)

    # Primary dominates; secondary terms break near-ties.
    return primary + 1.5 * exact_bonus - 0.5 * waste_penalty
# EVOLVE-BLOCK-END
