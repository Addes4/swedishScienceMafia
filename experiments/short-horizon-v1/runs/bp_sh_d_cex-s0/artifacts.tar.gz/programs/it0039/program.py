# EVOLVE-BLOCK-START
"""Best fit with a usable-leftover preference to avoid dead fragments."""
import numpy as np


def _priority_from_stats(item, bins, typical):
    leftover = bins - item  # remaining capacity after placing the item here
    # primary key: tightest fit (smallest leftover) via negation
    # secondary: prefer leftover == 0, or leftover >= typical; penalize tiny dead fragments
    dead = (leftover > 0) & (leftover < typical)
    score = -leftover.astype(np.float64)
    # subtract a small penalty only for dead fragments so best-fit still dominates otherwise
    score = score - dead.astype(np.float64) * 0.5
    return score


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, first on ties."""
    # Maintain a running estimate of a "typical" item size via a decaying max.
    state = priority.__dict__
    if "typical" not in state:
        state["typical"] = item
        state["n"] = 0
    state["n"] += 1
    # decaying max: tracks recent large items without a full histogram
    if item > state["typical"]:
        state["typical"] = item
    else:
        state["typical"] -= (state["typical"] - item) * 0.01

    typical = int(round(state["typical"]))
    if typical < 1:
        typical = 1

    return _priority_from_stats(item, bins, typical)
# EVOLVE-BLOCK-END
