# EVOLVE-BLOCK-START
"""Worst-fit (most loaded space left) packing to reduce unusable slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Worst-fit primary: prefer the bin with the most space left after placement.
    # This tends to keep a few bins open with room for future items and avoids
    # scattering items into many nearly-full bins that leave unusable slivers.
    primary = residual.astype(np.float64)

    # Small bonus for exact fills so a perfect fit is not skipped.
    bonus = np.where(residual == 0, 0.5, 0.0)

    return primary + bonus
# EVOLVE-BLOCK-END
