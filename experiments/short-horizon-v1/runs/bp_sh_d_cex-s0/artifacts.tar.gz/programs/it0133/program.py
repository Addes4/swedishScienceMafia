# EVOLVE-BLOCK-START
"""Best-fit with a residual-usability tie-break on near-equal fits."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item

    # Dominant best-fit term: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Quantize the fit into tiers so the tie-break only matters for near-equal fits.
    # Residuals within the same small window are considered "near ties".
    window = 2.0
    tier = np.round(primary / window)

    # Within a tier, prefer the LARGER residual, because a larger residual bin
    # can still accept more future items (avoids stranding reusable space).
    # Scale small so it only breaks near-ties, never overrides a strictly better fit.
    tie = (residual.astype(np.float64)) * 1e-3

    # Exact fills (residual 0) get a tiny extra nudge.
    bonus = np.where(residual == 0, 1e-3, 0.0)

    return tier + tie + bonus
# EVOLVE-BLOCK-END

