# EVOLVE-BLOCK-START
"""Best fit with a small-item top-off preference."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item  # remaining capacity after placing the item
    # Best fit: smaller leftover is better.
    score = -leftover.astype(np.float64)

    # For small items, add a bonus that favors tighter (more-used) bins,
    # but distinguish bins that are nearly full so they get topped off
    # before fresh/unused bins are opened.
    if item <= 25:
        # Favor bins with little spare capacity after placement.
        score += 0.5 * (100.0 - leftover.astype(np.float64)) / 100.0
    elif item <= 50:
        score += 0.1 * (100.0 - leftover.astype(np.float64)) / 100.0

    return score
# EVOLVE-BLOCK-END
