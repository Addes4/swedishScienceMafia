# EVOLVE-BLOCK-START
"""Best-fit with a usability-aware tie-break to avoid tiny unusable slivers."""
import numpy as np
import math

_state = {"min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Usability threshold: residuals below this can never hold a future item.
    thresh = _state["min_item"]

    # Classify residuals:
    #   usable   : residual >= thresh (some future item could still fit)
    #   sliver   : 0 < residual < thresh (permanently unusable)
    #   exact    : residual == 0
    sliver = (residual > 0) & (residual < thresh)
    exact = residual == 0

    # Prefer usable over sliver, and slightly prefer exact fills.
    penalty = np.where(sliver, 1.0, 0.0)
    bonus = np.where(exact, 0.5, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END
