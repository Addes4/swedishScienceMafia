# EVOLVE-BLOCK-START
"""Best fit with a mild preference for near-exact fits and sensible gap use."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item
    # Primary: least leftover (best fit).  Secondary tie-breaker encoded as a small
    # bonus for bins whose remaining capacity is large (favor packing into fuller bins
    # only when leftover is equal is already guaranteed by the linear term).  The
    # tiny quadratic term slightly prefers leaving larger single gaps usable.
    return -(leftover.astype(np.float64)) - 1e-4 * (bins.astype(np.float64))
# EVOLVE-BLOCK-END

