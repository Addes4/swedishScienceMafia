# EVOLVE-BLOCK-START
"""Bounded best-fit: avoid leaving unusable slivers when a better-fit exists."""
import numpy as np

_state = {"min_item": 100, "size_sum": 0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item
    _state["size_sum"] += item
    _state["count"] += 1

    residual = bins - item  # remaining capacity after placing the item

    # Threshold below which a residual is considered a likely-unusable sliver.
    # Use a small fraction of the running mean item size, capped by min item seen.
    mean_item = _state["size_sum"] / _state["count"]
    sliver_thresh = max(1, int(mean_item * 0.25))
    if sliver_thresh > _state["min_item"] - 1:
        sliver_thresh = max(1, _state["min_item"] - 1)

    # Primary: best-fit (smaller residual better).
    primary = -residual.astype(np.float64)

    # Sliver penalty applies only when a non-sliver alternative exists that is not
    # drastically larger; represent this via a soft penalty that best-fit can overcome
    # only for very tight fits. Bounded best-fit: among residuals within a window of
    # the tightest, prefer non-slivers.
    best_res = residual.min()
    window = sliver_thresh  # allow choosing a fit up to this much looser
    in_window = residual <= (best_res + window)

    sliver = (residual > 0) & (residual < sliver_thresh)
    penalty = np.where(in_window & sliver, 2.0, 0.0)
    bonus = np.where(residual == 0, 1.0, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END
