# EVOLVE-BLOCK-START
"""Best-fit with load-balancing among sliver-producing choices."""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    _state["sum"] += item
    _state["count"] += 1
    mean_item = _state["sum"] / _state["count"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # If the tightest fit would leave a residual below the running mean item
    # (a likely-unusable sliver), prefer instead a bin whose residual is
    # closer to the mean (more reusable), while still respecting best-fit
    # for residuals that are comfortably large.  Keep the correction tiny so
    # it only breaks near-ties.
    reusable = np.minimum(residual.astype(np.float64), mean_item)
    corr = reusable * 1e-3
    bonus = np.where(residual == 0, 1e-3, 0.0)

    return primary + corr + bonus
# EVOLVE-BLOCK-END
