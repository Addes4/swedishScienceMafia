# EVOLVE-BLOCK-START
"""Best-fit with a running item-size histogram to reward reusable residuals."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    """Rank bins: tightest fit first, with a bonus for residuals reusable by future items."""
    global _COUNT
    # Update histogram with the arriving item (only past items; current item not yet placed).
    _HIST[item] += 1.0
    _COUNT += 1.0

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Reuse value: probability that a future item exactly refills the residual.
    probs = _HIST / _COUNT
    # Index residuals safely (residual in [0, 99] for fitting bins).
    reuse = probs[np.clip(residual, 0, 100)]

    # Scale so secondary term only breaks near-ties in the primary.
    return primary + 0.75 * reuse
# EVOLVE-BLOCK-END
