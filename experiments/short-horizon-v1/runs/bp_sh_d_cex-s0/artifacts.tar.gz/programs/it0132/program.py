# EVOLVE-BLOCK-START
"""Best-fit with distribution-aware residual usability tie-break."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "count": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state

    # Update empirical histogram of past items.
    hist = _state["hist"]
    hist[item] += 1.0
    _state["count"] += 1.0
    total = _state["count"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    if total > 0.0:
        # Probability that a future item of size <= s exists now, cumulatively.
        # Cum[s] = P(item <= s). We want residuals r to be reusable by some future
        # item, i.e. P(item <= r) high. Compute cum from histogram.
        cum = np.cumsum(hist) / total  # cum[s] = P(size <= s), index 0..100
        # Usability of a residual r: probability some future item fits (size <= r).
        r = np.clip(residual, 0, 100)
        usable = cum[r]
        # Ties: prefer residuals that are more likely reusable. Small weight.
        return primary + 1.5 * usable
    return primary
# EVOLVE-BLOCK-END
