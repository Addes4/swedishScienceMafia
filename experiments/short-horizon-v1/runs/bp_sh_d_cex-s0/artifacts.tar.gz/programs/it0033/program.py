# EVOLVE-BLOCK-START
"""Harmonic-style bucketed best fit.

Items are grouped into size classes. Items that fit into a "small" bin class are
packed using best-fit restricted to bins belonging to that class (identified by
their remaining capacity), while large items use the usual best-fit over all bins.
Class boundaries follow the classical Harmonic scheme (1/2, 1/3, 2/3, ...) scaled
so the algorithm avoids mixing very different item sizes in the same bin.
"""
import numpy as np


def priority(item, bins):
    # Classical harmonic class boundaries for capacity C = 100.
    C = 100
    # Higher score = better. Use best-fit as base ordering: tighter fit => higher score.
    base = -(bins - item)

    if item > C // 2:
        # Large items (> C/2): each bin holds at most one such item plus smalls.
        # Strict best-fit works well; nothing to special-case.
        return base

    # For smaller items, prefer bins whose remaining capacity is in the same
    # harmonic bracket as the item, so items of similar size share bins and
    # leftovers stay large enough to accept future same-class items.
    if item > C // 3:
        # Class 1/3 < s <= 1/2: pair with another such item when possible.
        # Prefer bins that already contain exactly one such item (leftover in
        # this same range), else best-fit.
        in_class = (bins > C // 3) & (bins <= C // 2)
        bonus = np.where(in_class, 1e6, 0.0)
        return bonus + base
    if item > C // 4:
        # Class 1/4 < s <= 1/3: group up to 3 per bin.
        in_class = (bins > C // 4) & (bins <= 2 * C // 3)
        bonus = np.where(in_class, 1e6, 0.0)
        return bonus + base

    # Small items (<= C/4): plain best-fit across all bins.
    return base
# EVOLVE-BLOCK-END
