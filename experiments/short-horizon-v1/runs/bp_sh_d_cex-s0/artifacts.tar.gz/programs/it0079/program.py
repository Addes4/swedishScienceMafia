# EVOLVE-BLOCK-START
"""Best-fit with an exponential residual reward shaped by the observed mean item size."""
import numpy as np

_state = {"min_item": 100, "n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary criterion stays best-fit (smallest post-placement residual).  Among bins with
    residuals that are close in magnitude, prefer residuals that are plausible sums of typical
    future items, so partially filled bins tend to get closed instead of leaving awkward gaps.
    """
    st = _state
    if item < st["min_item"]:
        st["min_item"] = item
    st["n"] += 1
    st["sum"] += item
    mean_item = st["sum"] / st["n"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Reward residuals that look like a whole number of average-sized future items can fill
    # exactly (residual ≈ k * mean_item), with exact fills (residual 0) getting the most pull.
    scale = mean_item if mean_item > 1.0 else 1.0
    # Distance to nearest multiple of the typical item size, normalized.
    k = residual / scale
    dist = np.abs(k - np.round(k))
    fill_reward = np.exp(-(dist * 4.0) ** 2)
    exact_bonus = np.where(residual == 0, 1.0, 0.0)

    # Scale so these secondary terms only matter among near-tied residuals.
    return primary + 0.4 * fill_reward + 0.5 * exact_bonus
# EVOLVE-BLOCK-END
