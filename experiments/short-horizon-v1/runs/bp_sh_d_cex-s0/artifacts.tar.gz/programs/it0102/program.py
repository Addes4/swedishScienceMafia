# EVOLVE-BLOCK-START
"""Scale-invariant best-fit: tighter relative fit wins, exact fills break ties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)  # remaining capacity after placing the item

    # Scale-invariant best-fit: relative residual is the primary criterion.
    primary = -(residual / item)

    # Exact fill bonus: only a tiny tie-break so it can't override a tighter relative fit.
    bonus = (residual == 0).astype(np.float64) * 1e-6

    return primary + bonus
# EVOLVE-BLOCK-END
