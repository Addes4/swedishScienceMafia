# EVOLVE-BLOCK-START
"""Best-fit with a small, mean-aware tie-break to avoid dead slivers."""
import numpy as np


class _State:
    total = 0.0
    count = 0

    def mean(self):
        return self.total / self.count if self.count else 40.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state.total += item
    _state.count += 1
    mu = _state.mean()

    leftover = bins - item  # >= 0 for all bins shown

    # Dominant: tightest fit has smallest leftover.
    base = -leftover.astype(np.float64)

    # Tie-break window: bins whose leftover is within a few units of the tightest fit.
    tight = np.min(leftover)
    window = 1.15 * mu  # scale with item size distribution
    close = (leftover - tight) <= window

    # Reward reusable leftovers: exactly 0, or near a typical item size mu.
    reuse = np.exp(-np.abs(leftover - mu) / max(mu, 1.0))
    perfect = (leftover == 0).astype(np.float64)

    adj = np.where(close, 0.5 * reuse + 0.5 * perfect, 0.0)

    return base + adj
# EVOLVE-BLOCK-END
