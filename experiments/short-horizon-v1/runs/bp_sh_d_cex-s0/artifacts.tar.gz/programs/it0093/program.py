# EVOLVE-BLOCK-START
"""Best-fit with exact-fill bonus; residual normalized by item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Exact fills get a small bonus so a perfect fill beats a merely tight fit.
    bonus = np.where(residual == 0, 0.5, 0.0)

    return primary + bonus
# EVOLVE-BLOCK-END
