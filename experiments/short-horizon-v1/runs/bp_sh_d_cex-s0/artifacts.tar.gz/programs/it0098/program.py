# EVOLVE-BLOCK-START
"""Best-fit primary with a residual-reusability tie-break tuned to the item distribution."""
import numpy as np

_state = {"n": 0, "mean": 40.0, "sizes": None}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    # Update running statistics of item sizes (cheap, bounded window).
    n = _state["n"]
    mean = _state["mean"]
    mean = mean + (item - mean) / (n + 1)
    _state["mean"] = mean
    _state["n"] = n + 1

    residual = bins - item  # remaining capacity after placing the item

    # Primary: best-fit (smaller residual is better).
    primary = -residual.astype(np.float64)

    # Secondary: penalize tiny slivers that are very unlikely to be refillable.
    # A residual r>0 is "bad" if r is small relative to the running mean item size,
    # because no future item of typical size can fit into it.
    scale = mean * 0.08
    small = np.maximum(mean * 0.5 - residual, 0.0) / (mean * 0.5 + 1e-9)
    penalty = np.where(residual > 0, small, 0.0)

    # Bonus for exact fills (residual 0) to encourage perfect packing.
    bonus = np.where(residual == 0, 0.7, 0.0)

    return primary - penalty * scale + bonus
# EVOLVE-BLOCK-END
