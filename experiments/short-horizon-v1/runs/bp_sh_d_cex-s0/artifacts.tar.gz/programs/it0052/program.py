# EVOLVE-BLOCK-START
"""Bounded best-fit: tightest fit, with adaptive tie-window favoring reusable residuals."""
import numpy as np


_state = {"n": 0, "sum": 0.0, "sumsq": 0.0}


def priority(item, bins):
    """Rank bins: primary = tightest fit; secondary within a small window = best residual."""
    s = _state
    n = s["n"]
    if n > 0:
        mean = s["sum"] / n
        var = s["sumsq"] / n - mean * mean
        std = var ** 0.5 if var > 0 else 0.0
    else:
        mean = 40.0
        std = 20.0

    s["n"] = n + 1
    s["sum"] += item
    s["sumsq"] += item * item

    # Best fit: minimize leftover. bins contains only fitting bins, so leftover >= 0.
    leftover = bins - item
    min_left = leftover.min()
    # Window scales with item-size spread, kept small to avoid straying from best-fit.
    window = max(1.0, 0.25 * std)

    within = leftover <= (min_left + window)

    # Prefer residuals close to the mean item size (reusable later), or zero (perfect fit).
    target = mean
    # Distance of leftover from target, but exact 0 is treated as ideal.
    resid_gap = np.abs(leftover - target)
    resid_gap = np.where(leftover == 0, 0.0, resid_gap + 1.0)

    score = np.where(within, -resid_gap, -1000.0 - leftover)
    return score
# EVOLVE-BLOCK-END

