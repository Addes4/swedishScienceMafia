# EVOLVE-BLOCK-START
"""Minimize the increase in squared leftover capacity (a smoothing rule).

For each candidate bin, the placement changes the leftover from b to b - item.
The increase in the sum of squares of leftover capacities is:
    (b - item)^2 - b^2 = item^2 - 2*item*b
Since item is fixed for a given call, minimizing this is equivalent to
maximizing b, i.e. worst-fit. Instead we use the classic "sum of squares"
variant over bins that still leave a small leftover: we combine best-fit
(minimize leftover) with a mild preference for the bin whose leftover after
placement is closest to a target derived from observed item sizes.

We use a simple, robust hybrid: primary key = resulting leftover (best fit),
but we slightly reward bins whose leftover matches a running estimate of
common item sizes so fragments get absorbed by future items of the same size.
"""
import numpy as np

_state = {"hist": None}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Base: best fit -> minimize resulting leftover (bins - item).
    leftover = bins - item

    # Small stateful nudge: prefer leftovers that equal a frequently-seen item size,
    # so that partially-filled bins tend to be exactly filled later.
    hist = _state["hist"]
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        _state["hist"] = hist

    # Nudge magnitude scales with the item (large items matter more) but stays small
    # so best-fit remains the dominant criterion.
    nudge = 0.01 * item

    # Prefer bins whose post-placement leftover is a "common" size (probability mass).
    # Own estimated frequency of this leftover among past items.
    scores = -leftover.astype(np.float64)

    # Reward near-perfect fills strongly (leftover 0) — best fit already does this.
    # Add the histogram-based tie-break.
    freq = hist[np.clip(leftover, 0, 100).astype(np.int64)]
    scores += nudge * (freq / (hist.sum() + 1.0))

    # Update the histogram with the current item.
    hist[item] += 1.0

    return scores
# EVOLVE-BLOCK-END
