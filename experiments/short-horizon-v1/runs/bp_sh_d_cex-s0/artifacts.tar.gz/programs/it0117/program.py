# EVOLVE-BLOCK-START
"""Best-fit with an empirical reusable-residual bonus based on a decaying size histogram."""
import numpy as np

_state = {"hist": None, "decay": 0.997, "count": 0.0}


def _update_hist(item):
    hist = _state["hist"]
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        _state["hist"] = hist
    d = _state["decay"]
    hist *= d
    hist[item] += 1.0
    _state["count"] = _state["count"] * d + 1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _update_hist(item)

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Empirical reusable-residual bonus: how likely a future item can exactly
    # consume the residual.  Use the decaying histogram as a proxy pmf.
    hist = _state["hist"]
    total = _state["count"]
    if total > 0.0:
        pmf = hist / total
    else:
        pmf = np.zeros(101, dtype=np.float64)

    # Clip residual into [0, 100]; residuals of exactly 0 get probability 1 bonus.
    r = np.clip(residual, 0, 100).astype(np.int64)
    prob = pmf[r]
    # A residual of 0 is already a perfect fill.
    prob = np.where(residual == 0, 1.0, prob)

    # Keep best-fit dominant; bonus is a small tie-break scale.
    return primary + 2.0 * prob
# EVOLVE-BLOCK-END

