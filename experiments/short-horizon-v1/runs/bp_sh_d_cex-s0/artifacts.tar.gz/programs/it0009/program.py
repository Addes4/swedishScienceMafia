# EVOLVE-BLOCK-START
"""Best fit with a complementary-leftover term learned from the running size histogram."""
import numpy as np


class _State:
    def __init__(self):
        # histogram of item sizes seen so far (index 1..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0

    def observe(self, item):
        self.hist[item] += 1.0
        self.count += 1.0

    def probs(self):
        if self.count < 1.0:
            return None
        return self.hist / self.count


_STATE = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _STATE
    # best fit: tightest remaining capacity after placement
    leftover = bins - item

    # If a bin is exactly filled, that's ideal.
    score = -leftover.astype(np.float64)

    probs = st.probs()
    if probs is not None and leftover.size:
        # Probability mass for future items that would fit into the residual gap
        # without overflowing (i.e., sizes <= leftover), weighted by closeness to
        # exactly filling: we approximate "fillability" as P(size == leftover)
        # smoothed with neighbouring sizes.
        idx = leftover
        valid = idx >= 0
        # smoothed probability of an item exactly matching the leftover
        p_exact = np.zeros_like(leftover, dtype=np.float64)
        if np.any(valid):
            li = idx[valid]
            # neighbour-smoothed mass
            m = probs[li]
            # add a small neighbourhood mass
            m = m + 0.5 * (probs[np.clip(li - 1, 1, 100)] + probs[np.clip(li + 1, 1, 100)])
            p_exact[valid] = m
        # bonus for leaving a "fillable" gap, small enough not to override best-fit
        score = score + 0.5 * p_exact

    st.observe(int(item))
    return score
# EVOLVE-BLOCK-END

