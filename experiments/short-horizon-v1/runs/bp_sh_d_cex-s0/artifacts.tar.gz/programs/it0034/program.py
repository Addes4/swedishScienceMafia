# EVOLVE-BLOCK-START
"""Shelf-aware best fit.

Primary rule: best fit (minimize leftover).
Secondary consideration: prefer a leftover that equals the amount needed to
complete some existing partial bin, so complementary fragments get paired
instead of accumulating. Falls back to best fit when no pairing is available.
"""
import numpy as np


def priority(item, bins):
    """Score each candidate bin; highest score wins (first on ties)."""
    item = int(item)
    b = np.asarray(bins, dtype=np.int64)

    # Best-fit baseline: larger score = smaller leftover.
    leftover = b - item
    score = -leftover.astype(np.float64)

    # Identify partial bins (0 < remaining < 100): their "need" is
    # (100 - remaining) = amount required to fill them exactly.
    remaining = b
    partial = (remaining > 0) & (remaining < 100)
    if np.any(partial):
        needs = 100 - remaining[partial]
        # A fit into bin with leftover L can complete a partial bin whose
        # need == L (i.e. leftover + need == 100 means we'd fill that other
        # bin exactly with a complementary amount). Prefer such leftovers.
        # Build a set of needs for quick membership test.
        need_set = np.unique(needs)
        lo = leftover
        match = np.zeros(b.shape[0], dtype=np.float64)
        # left exact completion of existing partial bins (need == leftover)
        for n in need_set:
            match += (lo == n).astype(np.float64)
        # Small bonus, must not override best-fit at the top level.
        score += 0.5 * match

    # Keep bins that are already exactly full-ish tighter; add tiny term to
    # prefer fuller bins among leftovers of the same magnitude (stability).
    score -= 1e-6 * b
    return score
# EVOLVE-BLOCK-END
