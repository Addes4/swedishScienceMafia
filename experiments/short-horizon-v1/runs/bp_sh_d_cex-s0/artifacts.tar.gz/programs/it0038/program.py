# EVOLVE-BLOCK-START
"""Harmonic-style size classification combined with best-fit leftover target.

Each arriving item is mapped to a size class (bucketed by 1/item).  Every bin gets a
score that prefers a post-placement leftover near the midpoint of the class target,
which balances tight packing (best fit) against pairing complementary fragments.
"""
import numpy as np


def _class_index(item):
    """Map item size to a class index 1..5 for Weibull-shaped sizes (mean ~40)."""
    if item <= 10:
        return 0
    if item <= 20:
        return 1
    if item <= 34:
        return 2
    if item <= 50:
        return 3
    return 4


# Target leftover (in remaining-capacity terms) per class: we want bins whose leftover
# is close to these values so that complementary items can fill them neatly.
_TARGETS = (10.0, 20.0, 34.0, 50.0, 66.0)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    b = np.asarray(bins, dtype=np.float64)
    leftover = b - float(item)

    target = _TARGETS[_class_index(item)]

    # Primary goal: resulting leftover close to the class target.
    dist = np.abs(leftover - target)

    # Secondary: among equidistant, prefer a tighter fit (smaller leftover), and
    # strongly prefer an exact fit / avoid leaving zero-waste-sensitive bins.
    # Use a small lexicographic-ish blend so ties break toward best fit.
    return -(dist * 1024.0 + leftover)
# EVOLVE-BLOCK-END

