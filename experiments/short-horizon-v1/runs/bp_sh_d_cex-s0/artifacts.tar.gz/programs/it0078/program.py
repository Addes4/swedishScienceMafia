# EVOLVE-BLOCK-START
"""Best-fit with a density-aware tie-break on residuals near multiples of the mean item."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = _state["n"]
    s = _state["sum"]
    mean = s / n if n > 0 else 40.0
    _state["n"] = n + 1
    _state["sum"] = s + item

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Density tie-break: a residual that sits near a multiple of the running mean
    # can be closed by future items with few wasted slivers.
    if mean > 0:
        # distance to nearest multiple of mean, scaled to [0,1]
        q = residual / mean
        frac = np.abs(q - np.round(q))  # 0 when residual is a near-exact multiple
        density_bonus = 0.3 * (1.0 - 2.0 * frac)
    else:
        density_bonus = np.zeros_like(primary)

    # Exact fill bonus: keeps tightest-fit behavior for perfect closures.
    bonus = np.where(residual == 0, 0.5, 0.0)

    return primary + density_bonus + bonus
# EVOLVE-BLOCK-END
