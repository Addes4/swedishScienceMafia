# EVOLVE-BLOCK-START
"""Best-fit with a smooth, distribution-aware sliver penalty.

The item sizes come from a fixed Weibull-shaped distribution with mean ~40, so a
residual smaller than a modest fraction of the mean is unlikely to ever be usable.
We penalize such residuals smoothly and reward exact fills, while keeping best-fit
(tighter residual) dominant. Statistics use the running mean item size, which is a
stable quantity even on very short streams.
"""
import numpy as np

_state = {"count": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    _state["count"] += 1
    _state["sum"] += item

    # Running mean item size; default to the distribution mean (~40) early on.
    mean_item = _state["sum"] / _state["count"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Smooth sliver penalty: residuals below a fraction of the mean item size are
    # unlikely to be reusable. Penalty grows as the residual shrinks. Exact fills
    # (residual 0) are exempt and get a small bonus.
    thresh = max(1.0, 0.5 * mean_item)
    r = residual.astype(np.float64)
    sliver_penalty = np.where((r > 0) & (r < thresh), (thresh - r) / thresh, 0.0)
    bonus = np.where(residual == 0, 0.5, 0.0)

    # Secondary terms are small relative to the unit-spaced best-fit primary so
    # they primarily break near-ties.
    return primary - 1.5 * sliver_penalty + bonus
# EVOLVE-BLOCK-END
