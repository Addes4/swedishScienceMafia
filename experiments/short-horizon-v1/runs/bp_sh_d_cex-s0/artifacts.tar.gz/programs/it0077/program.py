# EVOLVE-BLOCK-START
"""Best-fit with strong exact-fill bonus and empty-bin aversion."""
import numpy as np

_state = {"min_item": 100, "seen": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item
    _state["seen"] += 1

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Strong bonus for exact fills: closing a bin is always good.
    bonus = np.where(residual == 0, 2.0, 0.0)

    # Sliver penalty: residuals that can never be reused by the smallest item seen.
    sliver_thresh = _state["min_item"]
    sliver = (residual > 0) & (residual < sliver_thresh)
    penalty = np.where(sliver, 1.0, 0.0)

    # Penalize using brand-new empty bins slightly so we exhaust existing bins first.
    empty = bins == 100
    empty_penalty = np.where(empty, 0.25, 0.0)

    return primary - penalty + bonus - empty_penalty
# EVOLVE-BLOCK-END

