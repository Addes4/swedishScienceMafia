# EVOLVE-BLOCK-START
"""Best-fit with empirical expected-waste tie-break."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "count": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    hist = _state["hist"]
    count = _state["count"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # exact fill bonus
    bonus = np.where(residual == 0, 0.5, 0.0)

    # Empirical expected-waste: probability that an item of size s still
    # arrives and can use a bin with residual s.  Estimate using histogram.
    if count > 0:
        items_seen = hist[1:101]
        p = items_seen / count
        # P(a future item is >= r) approximated as expected tail of distribution.
        # cumulative tail probability from r upward.
        # sort-based: tail[r] = sum_{s>=r} p[s-1]
        tail = np.cumsum(p[::-1])[::-1]  # tail[i] = P(size >= i+1)
        # usable probability for residual r = P(size == r exactly) [perfect fill]
        # plus small credit for any item that fits. Here we just use "can this be
        # filled" as probability mass >= r.
        r = residual
        rc = np.clip(r, 0, 100)
        fillable = np.empty(rc.shape, dtype=np.float64)
        # tail[rc-1] gives P(size >= rc); for rc==0 it's 1.0
        idx = np.clip(rc - 1, 0, 99)
        fillable = np.where(rc == 0, 1.0, tail[idx])
        penalty = (1.0 - fillable)
    else:
        penalty = np.where((residual > 0) & (residual < item), 1.0, 0.0)

    # Update histogram after scoring (so state reflects past items only)
    hist[item] += 1.0
    _state["count"] = count + 1.0

    return primary - penalty + bonus
# EVOLVE-BLOCK-END
