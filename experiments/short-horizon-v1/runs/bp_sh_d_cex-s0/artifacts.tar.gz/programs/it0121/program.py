# EVOLVE-BLOCK-START
"""Best-fit with an empirical reusable-residual bonus for near-ties."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)  # index by item size 1..100
_count = 0.0
_alpha = 0.995  # decay so recent items matter a bit more


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    global _count
    # Update empirical distribution with the arriving item.
    _hist *= _alpha
    _count *= _alpha
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # remaining capacity after placing (>=0 since bins fit)

    # Normalized empirical probability that some past item equals a residual r.
    # We treat residual 0 as always reusable (perfect fill).
    prob = _hist / _count if _count > 0 else np.zeros(101, dtype=np.float64)

    # Best-fit primary: smaller residual strictly better.
    primary = -residual.astype(np.float64)

    # Reusable-residual bonus: probability some future item exactly fills residual.
    r = np.clip(residual, 0, 100).astype(np.int64)
    reusable = prob[r]
    exact = np.where(residual == 0, 1.0, 0.0)

    # Secondary term small enough that best-fit still dominates (residual unit = 1.0),
    # but meaningful among residuals of similar size.
    return primary + 0.5 * reusable + 0.5 * exact
# EVOLVE-BLOCK-END
