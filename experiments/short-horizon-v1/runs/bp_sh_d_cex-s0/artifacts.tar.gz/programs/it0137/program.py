# EVOLVE-BLOCK-START
"""Best-fit with a running-maximum-based waste penalty.

Most items are large (mean ~40), so a bin left with a residual smaller than the
largest item seen so far is very likely to be permanently unusable.  We keep
best-fit dominant and add a small penalty for such residuals, plus a bonus for
exact fills (residual 0).
"""
import numpy as np

_state = {"max_item": 1}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item > _state["max_item"]:
        _state["max_item"] = item

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Waste penalty: residuals in (0, max_item) are likely to be stranded,
    # because large items dominate the distribution.
    waste_thresh = _state["max_item"]
    waste = (residual > 0) & (residual < waste_thresh)
    penalty = np.where(waste, 1.0, 0.0)
    bonus = np.where(residual == 0, 0.5, 0.0)

    # Scale primary so the small secondary terms only matter near ties.
    return primary - penalty + bonus
# EVOLVE-BLOCK-END
