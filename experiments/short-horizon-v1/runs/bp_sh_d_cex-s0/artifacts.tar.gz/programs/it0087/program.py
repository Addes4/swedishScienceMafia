# EVOLVE-BLOCK-START
"""Best-fit with distribution-aware sliver avoidance.

Items have mean ~40 (Weibull-shaped). The classic Best-Fit rule (smallest positive
residual) is hard to beat in online packing, but it sometimes creates slivers of
residual 1..k that can never be filled. We keep best-fit as the dominant criterion
and only break near-ties to avoid leaving slivers that a typical future item cannot
use, favouring residuals that are either 0 (closed) or at least a plausible item size.
"""
import numpy as np

_state = {"mean": 40.0, "n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    residual = bins - item  # remaining capacity after placing the item

    # Dominant criterion: best-fit (smaller residual is better).
    primary = -residual.astype(np.float64)

    # A residual strictly between 0 and the mean item size is a likely sliver:
    # hard to fill with a typical future item. Penalize it mildly. Exact fills
    # (residual 0) get a bonus since the bin is closed perfectly.
    sliver_thresh = max(2.0, mean)
    is_sliver = (residual > 0) & (residual < sliver_thresh)
    penalty = np.where(is_sliver, 0.25, 0.0)
    bonus = np.where(residual == 0, 0.5, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END
