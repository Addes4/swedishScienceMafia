# EVOLVE-BLOCK-START
"""Best-fit with a soft, empirically learned preference for reusable residuals."""
import numpy as np

_state = {"min_item": 100, "hist": np.zeros(101, dtype=np.float64), "n": 0.0}
_WINDOW = 9  # residuals within this band are treated as near-ties


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item

    # --- Best-fit primary: tighter fit (smaller residual) is better. ---
    primary = -residual.astype(np.float64)

    # --- Empirical reusability of a residual: probability that a future item
    #     exactly fills it. Estimated from past item-size histogram. ---
    hist = _state["hist"]
    n = _state["n"]
    if n > 0:
        p = hist / n
    else:
        p = np.zeros(101, dtype=np.float64)

    # For residual r, prob a future item of size r arrives (exact fill).
    r = np.clip(residual, 0, 100)
    reuse = p[r]

    # Only let reusability break near-ties: scale it below the primary granularity.
    score = primary + 0.9 * reuse

    # Exact fill is always strongly good.
    score = score + np.where(residual == 0, 0.5, 0.0)

    # --- Update histogram (after computing, so we don't use the current item
    #     as "past" info). ---
    hist[item] += 1.0
    _state["n"] += 1.0

    return score
# EVOLVE-BLOCK-END
