# EVOLVE-BLOCK-START
"""Best-fit with a scaled, distribution-aware sliver penalty."""
import numpy as np

_state = {"min_item": 100, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item
    _state["count"] += 1

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Sliver penalty: residuals in [1, thresh) can rarely be reused.
    # thresh tracks the smallest item seen (floored at 1) so the penalty shrinks
    # as small items become known, but stays strong enough to beat best-fit.
    thresh = max(1, _state["min_item"])
    sliver = (residual > 0) & (residual < thresh)
    # Scale penalty to dominate residual differences within the sliver zone.
    penalty = np.where(sliver, 101.0 - residual, 0.0)
    bonus = np.where(residual == 0, 0.5, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END
