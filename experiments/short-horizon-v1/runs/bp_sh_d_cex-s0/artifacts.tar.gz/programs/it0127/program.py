# EVOLVE-BLOCK-START
"""Best-fit with residual-usability scoring based on observed item-size frequencies."""
import numpy as np

_state = {"min_item": 100, "hist": np.zeros(101, dtype=np.float64), "count": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    # Update empirical item-size histogram (past items + current).
    _state["hist"][item] += 1.0
    _state["count"] += 1.0
    freq = _state["hist"] / _state["count"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Reworkability: how likely is this residual to be exactly filled by a future item?
    # residual r is reusable if some observed item size equals r (frequency freq[r]).
    safe = np.clip(residual, 0, 100)
    reuse = freq[safe]  # probability mass at exact residual sizes

    # Penalize residuals that are too small to fit the smallest item seen.
    too_small = (residual > 0) & (residual < _state["min_item"])
    penalty = np.where(too_small, 1.0, 0.0)

    # Small secondary terms only matter near ties.
    return primary + reuse - penalty
# EVOLVE-BLOCK-END
