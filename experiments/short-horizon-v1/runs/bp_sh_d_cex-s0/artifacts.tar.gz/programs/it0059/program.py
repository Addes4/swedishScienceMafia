# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware residual-value tie-break."""
import numpy as np

_state = {"min_item": 100, "hist": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    # Update running item-size histogram (excluding the unused 100-capacity bins isn't needed
    # since we only count arriving items here).
    _state["hist"][item] += 1.0
    _state["n"] += 1.0
    hist = _state["hist"]
    n = _state["n"]

    residual = bins - item  # capacity left after placing this item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Estimate probability that a residual r is "useful", i.e. some future item fits in r.
    # P(useful | r) = 1 - P(all future items > r) approximated using the empirical histogram.
    # We use the fraction of observed items <= r as a reuse probability proxy.
    if n > 0:
        cum = np.cumsum(hist) / n          # cum[r] = P(item <= r)
    else:
        cum = np.zeros(101, dtype=np.float64)

    # Bins shown have residual in [0, 100-item]; clamp for lookup.
    rc = np.clip(residual, 0, 100).astype(np.int64)
    p_reuse = cum[rc]                       # in [0, 1]

    # Expected "waste": a residual with low reuse probability is more likely wasted.
    # Exact fills (residual 0) are perfectly good; small residuals with tiny reuse prob are bad.
    waste = np.where(residual == 0, 0.0, 1.0 - p_reuse)

    # "Expected wasted capacity" idea: combine tightness of fit with usefulness.
    # Secondary term bounded in [-2, 0]; primary (min residual ~0, max ~100) dominates.
    return primary - 2.0 * waste
# EVOLVE-BLOCK-END
