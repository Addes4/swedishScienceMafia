# EVOLVE-BLOCK-START
"""Best-fit with a residual-utility tie-break driven by a running item histogram."""
import numpy as np

_STATE = {"hist": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties to first bin."""
    hist = _STATE["hist"]
    # score primary: tightest fit -> maximize -(bins - item) => minimize residual
    residual = bins - item

    # utility of a leftover r: how likely some recent item fits nicely into r
    # i.e. sum over sizes s <= r of hist[s] weighted by how tightly r-s can be reused
    # simplified: utility ~ probability that a future item leaves a small residual in r
    total = _STATE["n"] if _STATE["n"] > 0 else 1.0

    # vectorized: utility[r] = sum_{s<=r} hist[s] * (something). We precompute a
    # cumulative table over possible residuals 0..99 dynamically but cheaply.
    # Cheap approximation: utility of leftover r favors r near a recent item size
    # or near 0 (perfectly usable) or near capacity-100.
    # Build small table on the fly.
    util = np.zeros(101, dtype=np.float64)
    # cumulative sum of hist up to r, gives chance an item fits in leftover r region
    csum = np.cumsum(hist[:101])
    # utility: probability that leftover is exactly reachable (r is a sum of items)
    # use csum as a soft measure of usefulness
    util[:101] = csum

    # index residuals into util, clipped to 0..100
    r = np.clip(residual, 0, 100).astype(np.int64)
    util_r = util[r]

    # primary criterion: tightest fit dominates; secondary: higher utility preferred
    # residual differences are integers; use a strong weight on tightness so that
    # differing residuals dominate, ties broken by utility.
    return -(residual) * 1000.0 + util_r


def _update(item):
    hist = _STATE["hist"]
    hist[item] += 1.0
    _STATE["n"] += 1.0


# wrap priority to update state before scoring each call
_orig_priority = priority


def priority(item, bins):  # noqa: F811
    result = _orig_priority(item, bins)
    _update(item)
    return result
# EVOLVE-BLOCK-END

