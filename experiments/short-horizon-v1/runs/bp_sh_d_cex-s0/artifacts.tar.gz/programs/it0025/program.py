# EVOLVE-BLOCK-START
"""Best fit with a stateful tie-break toward historically common leftover sizes."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item

    # Running histogram of item sizes seen so far (smoothed).
    _state.hist *= 0.995
    _state.hist[item] += 1.0

    # Primary key: minimize leftover (best fit). Secondary: prefer leftov
    # values that historically have been common item sizes (likely fillable).
    freq = _state.hist[leftover] if leftover.min() >= 0 else 0.0
    return -(leftover.astype(np.float64)) + 0.001 * _state.hist[leftover]
# EVOLVE-BLOCK-END
