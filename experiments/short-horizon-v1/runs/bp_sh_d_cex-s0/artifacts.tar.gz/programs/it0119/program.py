# EVOLVE-BLOCK-START
"""Best-fit with adaptive flexibility tie-break among near-equal residuals."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary rule: best-fit (smallest post-placement residual).
    Tie-break: among near-equal residuals (within an adaptive window), prefer the
    larger residual, since it stays usable by a wider range of future item sizes.
    """
    state = _state
    state["n"] += 1
    state["sum"] += item
    if item < state["min_item"]:
        state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item
    residual = residual.astype(np.float64)

    # Best-fit primary term (dominant). Larger (less negative) is better.
    primary = -residual

    # Adaptive window: a fraction of the running mean item size, floored at 1.
    mean = state["sum"] / state["n"]
    window = max(1.0, 0.05 * mean)

    # Normalized flexibility term: only distinct near-best residuals get bonus,
    # scaled to stay strictly below 1 so it cannot overturn the primary ordering
    # outside the window.
    flexibility = (-residual) / (window + 1.0)
    flexibility = np.clip(flexibility + 1.0, -1.0, 1.0)

    # Combine: primary dominates; flexibility only matters for tiny gaps.
    return primary + 0.5 * flexibility
# EVOLVE-BLOCK-END

