# EVOLVE-BLOCK-START
"""Best-fit dominant, with a histogram-based tie-break that prefers residuals
likely to be exactly refillable by a future item."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "count": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    hist = _state["hist"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit dominant term: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Histogram-based reuse value of each residual: probability that a future item
    # exactly matches the residual (so the bin can be filled perfectly later).
    total = _state["count"]
    clamped = np.clip(residual, 0, 100)
    reuse = hist[clamped] / total if total > 0.0 else np.zeros_like(primary, dtype=np.float64)
    # Exact fill is always good.
    reuse = np.where(residual == 0, 1.0, reuse)

    # Update state with the current item (after scoring, so it is causal).
    hist[item] += 1.0
    _state["count"] = total + 1.0

    # Small secondary term: only breaks near-ties among comparable residuals.
    return primary + 0.35 * reuse
# EVOLVE-BLOCK-END
