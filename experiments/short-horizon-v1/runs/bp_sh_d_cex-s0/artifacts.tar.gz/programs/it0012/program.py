# EVOLVE-BLOCK-START
"""Harmonic/fill-the-gap rule with strong exact-fit preference."""
import numpy as np


class _State:
    mean = 40.0
    n = 0.0

    def update(self, item):
        self.n += 1.0
        a = 1.0 / min(self.n, 200.0)
        self.mean = (1.0 - a) * self.mean + a * item


_s = _State()


def priority(item, bins):
    """Score each feasible bin; highest score wins (ties to first)."""
    _s.update(item)

    rem = np.asarray(bins, dtype=np.float64)
    leftover = rem - float(item)

    # Strong preference for closing a bin exactly.
    exact = (leftover == 0).astype(np.float64) * 1e6

    # Primary: best-fit (tightest feasible placement).
    tight = -leftover

    # Secondary: reward leftovers that are large enough to remain usable,
    # penalize tiny-but-nonzero leftovers that tend to waste space.
    # A leftover near a multiple of the typical item size is more reusable.
    m = _s.mean if _s.mean > 1.0 else 40.0
    # distance to the nearest multiple of m (0..m/2), reward closeness
    frac = np.mod(leftover, m)
    dist = np.minimum(frac, m - frac)
    reuse = -dist / m

    return exact + tight + 0.5 * reuse
# EVOLVE-BLOCK-END
