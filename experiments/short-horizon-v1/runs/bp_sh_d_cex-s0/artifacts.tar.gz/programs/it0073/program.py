# EVOLVE-BLOCK-START
"""Best-fit with a graded, adaptive sliver penalty to avoid unusable small residuals."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item
    rf = residual.astype(np.float64)

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -rf

    # Graded sliver penalty: residuals below the smallest item seen are wasted.
    # Penalty decreases linearly as residual grows toward min_item, and is 0 above.
    thresh = float(_state["min_item"])
    # normalized closeness to zero for small residuals
    small = np.where((residual > 0) & (rf < thresh),
                     (thresh - rf) / thresh, 0.0)

    # Bonus for exact fill; primary already favors it but boost slightly.
    bonus = np.where(residual == 0, 0.5, 0.0)

    # Scale primary so secondary terms only matter near ties.
    return primary - small + bonus
# EVOLVE-BLOCK-END
