# EVOLVE-BLOCK-START
"""Size-aware best fit: prefer tight fits, but steer residuals toward typical item sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # leftover capacity after placing the item

    # Primary drive: tightest fit (smallest residual is best).
    score = -residual.astype(np.float64)

    # Secondary nudge: slightly penalize residuals that are hard to reuse later.
    # Typical item ~40; residuals near 0 are great (bin closed), residuals near 40
    # are good (one more item likely fits). Penalize small-but-not-tiny gaps
    # that tend to strand space, without overriding the best-fit ordering.
    r = residual.astype(np.float64)
    # small bonus for near-exact fills
    score += 2.0 * np.exp(-((r) / 3.0) ** 2)
    # mild attraction toward a residual around 40
    score -= 0.5 * np.abs(r - 40.0) / 100.0

    return score
# EVOLVE-BLOCK-END
