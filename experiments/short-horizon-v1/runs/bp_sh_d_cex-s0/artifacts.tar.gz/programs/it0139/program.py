# EVOLVE-BLOCK-START
"""Best-fit that strongly avoids unusable slivers, with exact fills top-ranked."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary term: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Sliver penalty with a large weight so it can override best-fit:
    # a residual in (0, min_item) can never be filled by any future item.
    sliver_thresh = _state["min_item"]
    sliver = (residual > 0) & (residual < sliver_thresh)

    score = primary - np.where(sliver, 1000.0, 0.0)

    # Exact fills are always the best available choice.
    score = np.where(residual == 0, 100000.0, score)

    return score
# EVOLVE-BLOCK-END
