# EVOLVE-BLOCK-START
"""Residual/value best-fit: tight fit, but reward residuals that are likely reusable."""
import numpy as np

_state = {"counts": None, "total": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    global _state

    # Maintain a running histogram of item sizes to estimate reuse probability.
    if _state["counts"] is None:
        _state["counts"] = np.ones(101, dtype=np.float64)
        _state["total"] = 101.0
    counts = _state["counts"]
    counts[item] += 1.0
    _state["total"] += 1.0

    residual = bins - item  # remaining capacity after placement

    # Best-fit primary: tighter fit (smaller residual) preferred.
    primary = -residual.astype(np.float64)

    # Estimate probability that a residual slot can be reused by a future item.
    # Use the histogram to value residuals that match common item sizes.
    total = _state["total"]
    prob = counts / total  # probability per unit size

    # For each bin, residual r: reward if some future item of size <= r is common.
    # Approximate reuse value as the cumulative probability mass up to r.
    cum = np.cumsum(prob)  # cum[k] = P(item <= k)
    r = np.clip(residual, 0, 100).astype(np.int64)
    reuse = cum[r]

    # Combine: strong tight-fit, then tie-break by reusability of residual.
    # Scale reuse so it only matters among similarly tight fits.
    return primary + 0.9 * reuse
# EVOLVE-BLOCK-END
