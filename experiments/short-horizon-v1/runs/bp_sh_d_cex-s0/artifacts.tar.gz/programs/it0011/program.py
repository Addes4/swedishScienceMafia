# EVOLVE-BLOCK-START
"""Best fit with a complementary-residual correction.

Pure best fit greedily minimizes the leftover after placement.  That is optimal
locally but leaves many bins with a tiny, unusable residual.  Here we keep the
tightest-fit preference for small residuals but, when the residual after
placement is in a "useless" middle range, we instead reward leaving a gap that
future items can plausibly fill.  This is a lightweight, state-free tweak of
best fit that reduces the number of nearly-empty-but-unusable bins.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item  # remaining capacity after placing the item

    # Primary: tightest fit (smallest leftover is best).
    score = -leftover.astype(np.float64)

    # Secondary: strongly reward exact fills so bins get closed off cleanly.
    score += 1000.0 * (leftover == 0)

    # Tertiary: mildly discourage leaving a "useless" tiny residual (1..few),
    # which can rarely be filled by a future item, unless the bin is nearly
    # full already.  Reward residuals that a typical future item (~mean 40)
    # could likely use, but never enough to beat a tighter usable fit.
    usable = (leftover >= 25) & (leftover <= 55)
    score += 0.5 * usable

    return score
# EVOLVE-BLOCK-END
