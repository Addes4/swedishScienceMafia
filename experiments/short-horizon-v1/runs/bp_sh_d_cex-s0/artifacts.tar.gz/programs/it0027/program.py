# EVOLVE-BLOCK-START
"""Best fit with a stateful de-fragmentation preference.

Primary: minimize post-placement leftover (classic best fit) -- near-optimal for
this distribution. Tie/secondary: among bins producing the same leftover, prefer
ones whose leftover is a value that recent items commonly complete, keeping gaps
usable. The stateful term is small so it never overrides genuine best fit.
"""
import numpy as np

_state = {"hist": None, "seen": 0}


def priority(item, bins):
    lo = int(item)
    rem = bins.astype(np.int64)
    leftover = rem - lo  # >= 0 for all shown bins

    # factorized main key: exact best fit on leftover (smaller is better)
    keys = leftover.astype(np.float64)

    # stateful tie-breaker: reward leftover values seen as item sizes recently
    hist = _state["hist"]
    if hist is None or _state["seen"] % 64 == 0:
        hist = np.zeros(101, dtype=np.float64)
        _state["hist"] = hist
    h = hist / (hist.sum() + 1e-9)
    t = _state["seen"]
    # decay old counts
    hist *= 0.97

    # count current item
    if 1 <= lo <= 100:
        hist[lo] += 1.0
    _state["seen"] += 1

    # small bonus (<= ~0.5) for leftoN values with high historical density
    left_idx = np.clip(leftover, 0, 100).astype(np.int64)
    density = h[left_idx]
    keys = keys - 0.5 * density  # prefer leftover values likely to be filled

    return -keys
# EVOLVE-BLOCK-END
