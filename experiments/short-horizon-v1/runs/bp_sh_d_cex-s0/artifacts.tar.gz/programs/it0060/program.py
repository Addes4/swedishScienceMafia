# EVOLVE-BLOCK-START
"""Best-fit with sliver-aware tie-break using a running lower-quantile threshold."""
import numpy as np

_state = {"samples": [], "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _state

    # Maintain a bounded reservoir of recent item sizes to estimate a low quantile.
    _state["samples"].append(item)
    _state["count"] += 1
    if len(_state["samples"]) > 512:
        # keep it bounded
        _state["samples"] = _state["samples"][-512:]

    samples = _state["samples"]
    if len(samples) >= 8:
        # ~10th percentile as a proxy for tiny-but-plausible future items
        thr = int(np.percentile(samples, 10))
    else:
        thr = 1
    if thr < 1:
        thr = 1

    residual = bins - item  # remaining capacity after placement

    # Primary: best-fit (tighter residual is better => higher score).
    primary = -residual.astype(np.float64)

    # Secondary: penalize leaving a residual strictly smaller than the sliver threshold
    # (those bins tend to become unusable). Exact fills get a modest bonus.
    sliver = (residual > 0) & (residual < thr)
    penalty = np.where(sliver, 0.75, 0.0)
    bonus = np.where(residual == 0, 0.25, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END
