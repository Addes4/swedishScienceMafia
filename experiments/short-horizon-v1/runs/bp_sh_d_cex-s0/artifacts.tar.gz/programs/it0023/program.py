# EVOLVE-BLOCK-START
"""Best fit with a mild 'usable gap' nudge toward typical item sizes."""
import numpy as np

MEAN = 40.0

def priority(item, bins):
    leftover = bins - item  # remaining capacity after placing the item
    # Primary: strict best fit (smallest leftover). Secondary: prefer leftovers
    # close to a typical item size (so a later average item can fill this bin).
    score = -leftover.astype(np.float64)
    # small bonus for leftover near the mean item size, but never overriding best fit
    bonus = -0.001 * np.abs(leftover - MEAN)
    return score + bonus
# EVOLVE-BLOCK-END
