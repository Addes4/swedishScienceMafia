# EVOLVE-BLOCK-START
"""Best-fit dominant, with fullness tie-break to avoid stranding usable space."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item        # remaining capacity after placing the item
    used = 100 - residual         # fullness after placing the item

    min_item = _state["min_item"]

    # Best-fit primary: tighter fit (smaller residual) is better, scaled to dominate.
    primary = -residual.astype(np.float64) * 100.0

    # Exact fill is always the best possible outcome.
    exact = np.where(residual == 0, 1e6, 0.0)

    # Sliver: leftover too small to ever be reused -> strongly penalize.
    sliver = (residual > 0) & (residual < min_item)
    sliver_pen = np.where(sliver, 1e5, 0.0)

    # Fullness bonus: prefer fuller bins among comparable residuals,
    # reserving emptier bins for future (possibly larger) items.
    fullness = used.astype(np.float64)

    return primary + exact - sliver_pen + fullness
# EVOLVE-BLOCK-END

