# EVOLVE-BLOCK-START
"""Worst-fit-ish rule: prefer the fullest bin that still leaves useful slack."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item
    # Prefer bins with more remaining capacity before placement (spread the load),
    # but mildly penalize creating tiny unusable fragments.
    penalty = np.where((leftover > 0) & (leftover < 15), leftover * 0.5, 0.0)
    return bins.astype(np.float64) - penalty
# EVOLVE-BLOCK-END
