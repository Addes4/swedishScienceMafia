# EVOLVE-BLOCK-START
"""Best-fit with a data-driven residual-compatibility tie-break.

Pure best-fit is strong, but leaving a residual that is just below the typical
item size strands capacity that future items rarely fill.  We keep best-fit as
the primary term and add a small secondary bonus proportional to how close the
post-placement residual is to the recent item sizes (so the leftover room is
likely to be reused), estimated from a bounded history of past items.
"""
import numpy as np

_state = {"hist": [], "n": 0}


def priority(item, bins):
    """Return a priority per bin; highest wins, ties to the first bin."""
    global _state

    residual = bins - item  # capacity left after placing the item here

    # Primary: best-fit (smaller residual is better).
    primary = -residual.astype(np.float64)

    # Maintain a bounded history of recent item sizes to estimate the
    # distribution of residuals that are likely to be refilled.
    hist = _state["hist"]
    hist.append(int(item))
    if len(hist) > 200:
        del hist[:len(hist) - 200]
    _state["n"] += 1

    # Compatibility bonus: reward residuals that sit near a typical recent
    # item size (those bins stay usable), scaled small enough to only break
    # near-ties in the primary term.
    if _state["n"] > 20 and len(hist) >= 20:
        arr = np.asarray(hist, dtype=np.float64)
        # distance from the residual to the nearest recent item size
        # (vectorized over bins via broadcasting on a coarse check)
        res = residual.astype(np.float64)
        # approximate nearest-item distance using a small sample to bound cost
        sample = arr[:: max(1, len(arr) // 40)]
        diff = np.abs(res[:, None] - sample[None, :])
        nearest = diff.min(axis=1)
        # prefer residuals whose nearest recent item size is close
        compat = -nearest * 0.02
    else:
        compat = np.zeros_like(primary)

    return primary + compat
# EVOLVE-BLOCK-END
