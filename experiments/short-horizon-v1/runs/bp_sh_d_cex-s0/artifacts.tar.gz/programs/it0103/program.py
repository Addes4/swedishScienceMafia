# EVOLVE-BLOCK-START
"""Pure best-fit: place the item in the bin leaving the smallest residual capacity."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit: tighter fit (smaller residual) is better.
    # Exact fills (residual 0) naturally get the highest score.
    return -(bins - item).astype(np.float64)
# EVOLVE-BLOCK-END
