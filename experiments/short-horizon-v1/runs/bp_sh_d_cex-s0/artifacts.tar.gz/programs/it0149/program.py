# EVOLVE-BLOCK-START
"""Best-fit with strictly sub-unit tie-breaks (sliver penalty + exact-fill bonus)."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item < _state["min_item"]:
        _state["min_item"] = item
    min_item = _state["min_item"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # All secondary terms strictly < 1 so they only break exact ties on residual,
    # never overriding the tighter-fit choice (residuals are integers).
    # Exact fill: best possible outcome.
    bonus = np.where(residual == 0, 0.75, 0.0)
    # Sliver: residual too small to ever be reused by a future item.
    sliver = (residual > 0) & (residual < min_item)
    penalty = np.where(sliver, 0.5, 0.0)
    # Sub-unit preference for emptier bins among otherwise identical residuals.
    tiny = -1e-3 * bins.astype(np.float64)

    return primary + bonus - penalty + tiny
# EVOLVE-BLOCK-END
