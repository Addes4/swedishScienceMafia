# EVOLVE-BLOCK-START
"""Best-fit, with near-tie tie-break favoring residuals that are more "reachable"
as exact sums of likely future item sizes.

The primary term is still tightest fit (best-fit). Within a small tolerance of the
tightest residual, we prefer bins whose resulting residual is either 0 or a value
that our observed item-size histogram suggests is achievable as a sum of a few
future items -- such residuals are the ones we can later close exactly, which is
where bins actually get saved. Slivers (residuals below the smallest observed item)
are penalized because they can never be reused.
"""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _state

    counts = _state["counts"]
    counts[item] += 1.0
    _state["n"] += 1.0
    n = _state["n"]

    # Running distribution summary.
    seen = counts > 0
    sizes = np.nonzero(seen)[0]
    min_item = int(sizes[0]) if sizes.size else item
    weights = counts[sizes] / n

    residual = bins - item  # remaining capacity after placing

    # --- Primary: best-fit (tighter residual is better) ---
    primary = -residual.astype(np.float64)

    # --- Secondary: how reusable is the resulting residual? ---
    # Only meaningful for residual > 0. Score in [0, 1) via subset-sum reachability
    # using a few copies of the (weighted) common item sizes.
    cap = 100
    # dp[s] = max probability-like "reachability" mass that sum s is attainable.
    dp = np.zeros(cap + 1, dtype=np.float64)
    dp[0] = 1.0
    # Use at most a handful of items in any sum (bounded depth), weighted by frequency.
    max_depth = 4
    cur = dp.copy()
    for _ in range(max_depth):
        nxt = cur.copy()
        for s in range(cap + 1):
            if cur[s] <= 0.0:
                continue
            rem = cap - s
            if rem <= 0:
                continue
            # add one more item of size si with prob weight
            nxt[s + 1:s + rem + 1] = np.maximum(
                nxt[s + 1:s + rem + 1],
                cur[s] * weights[:rem],
            )
        cur = nxt
    reach = cur  # reach[s] ~ mass that residual s is reachable in <= max_depth items
    reach = reach / (reach.max() if reach.max() > 0 else 1.0)

    # Map each bin's residual to its reachability score.
    r = np.clip(residual, 0, cap).astype(np.int64)
    secondary = reach[r]
    secondary = np.where(residual > 0, secondary, 0.0)

    # --- Sliver penalty: residual in (0, min_item) is unusable. ---
    sliver = (residual > 0) & (residual < min_item)
    penalty = np.where(sliver, 2.0, 0.0)
    bonus = np.where(residual == 0, 1.0, 0.0)

    # Primary dominates; secondary/penalty only decide near-ties.
    return primary + 0.5 * secondary - penalty + bonus
# EVOLVE-BLOCK-END
