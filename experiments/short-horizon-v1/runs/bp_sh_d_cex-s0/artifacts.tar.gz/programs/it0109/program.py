# EVOLVE-BLOCK-START
"""Best-fit with harmonic capacity-class preference for Weibull-like sizes."""
import numpy as np

_state = {"min_item": 100}
_CLASSES = (100, 50, 34, 25, 20, 17, 15, 13, 12, 11, 10)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (ties -> first).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (only bins the item fits in).
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item
    min_item = _state["min_item"]

    residual = bins - item  # post-placement remaining capacity

    # Primary: best-fit (tighter fit -> higher score).
    score = -residual.astype(np.float64)

    # Harmonic capacity-class bonus: strongly prefer bins whose post-placement
    # residual sits just below a capacity class boundary, i.e. the bin becomes
    # nearly "locked" as a class, keeping other bins open for future items.
    r = residual
    class_score = np.zeros_like(score)
    for c in _CLASSES:
        # residual in [0, c) means the bin can no longer hold items > c
        in_class = (r < c) & (r >= 0)
        class_score += np.where(in_class, 1.0 / c, 0.0)
    score += class_score

    # Exact-fill preference.
    score += np.where(residual == 0, 0.5, 0.0)

    # Small penalty for creating unusable slivers.
    sliver = (residual > 0) & (residual < min_item)
    score -= np.where(sliver, 0.25, 0.0)

    return score
# EVOLVE-BLOCK-END
