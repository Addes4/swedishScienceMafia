# EVOLVE-BLOCK-START
"""Best-fit, with near-tie broken toward residuals closest to a typical item size."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    _state["sum"] += item
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Tie-break: prefer residuals near the running mean item size so the bin
    # stays useful for a typical future item. Scaled small so it only breaks ties.
    tie = -np.abs(residual.astype(np.float64) - mean) * 0.01

    return primary + tie
# EVOLVE-BLOCK-END
