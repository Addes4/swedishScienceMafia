# EVOLVE-BLOCK-START
"""Sum-of-squares residual ranking (classic fast online heuristic)."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # remaining capacity after placing the item

    # Sum-of-squares residual: minimize residual^2 -> maximize -residual^2.
    primary = -(residual.astype(np.float64) ** 2)

    # Extra bonus for exact fills so sliver preference is strong.
    bonus = np.where(residual == 0, 50.0, 0.0)

    return primary + bonus
# EVOLVE-BLOCK-END

