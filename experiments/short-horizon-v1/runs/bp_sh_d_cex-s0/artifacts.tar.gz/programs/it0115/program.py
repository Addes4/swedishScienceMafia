# EVOLVE-BLOCK-START
"""Best-fit with an empirical reuse-probability tie-break on the post-placement residual."""
import numpy as np

# Empirical histogram of past item sizes (bucketed coarsely for stability).
_BUCKET = 4
_NB = 100 // _BUCKET + 1
_state = {"hist": np.zeros(_NB, dtype=np.float64), "n": 0.0, "min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    hist = _state["hist"]
    n = _state["n"]

    # Update histogram with the arriving item.
    b = item // _BUCKET
    if b >= _NB:
        b = _NB - 1
    hist[b] += 1.0
    _state["n"] = n = n + 1.0

    if item < _state["min_item"]:
        _state["min_item"] = item

    # Empirical reuse-probability for a residual of size r: probability that some
    # future item fits in the sliver of capacity r.
    probs = hist / n
    pmf = np.zeros(101, dtype=np.float64)
    pmf[0] = 0.0
    for k in range(_NB):
        if probs[k] > 0.0:
            lo = k * _BUCKET
            hi = min(lo + _BUCKET - 1, 100)
            pmf[lo:hi + 1] += probs[k] / (hi - lo + 1)
    cdf = np.cumsum(pmf)  # cdf[r] = P(item <= r)

    residual = bins - item  # remaining capacity after placing the item
    r = np.clip(residual, 0, 100)

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Reuse bonus: reward residuals that future items are likely to fit into.
    reuse = cdf[r]

    # Exact fills get an extra strong nudge.
    bonus = np.where(residual == 0, 2.0, 0.0)

    return primary + 4.0 * reuse + bonus
# EVOLVE-BLOCK-END
