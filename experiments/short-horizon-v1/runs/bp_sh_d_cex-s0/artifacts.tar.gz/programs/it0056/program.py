# EVOLVE-BLOCK-START
"""Best-fit with residual-aware tie-break to avoid unusable slivers."""
import numpy as np

_state = {"count": 0, "sum": 0.0, "min_item": 100, "inv_fit": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    _state["count"] += 1
    _state["sum"] += item
    if item < _state["min_item"]:
        _state["min_item"] = item
    mean = _state["sum"] / _state["count"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # A residual that is positive but smaller than the mean item size is likely
    # to become an unusable sliver; penalize those, scaled so it never beats
    # a genuinely tighter fit.
    sliver = (residual > 0) & (residual < mean)
    penalty = np.where(sliver, 0.4, 0.0)
    # Strong bonus for exact fills, which are always good.
    bonus = np.where(residual == 0, 0.8, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END

