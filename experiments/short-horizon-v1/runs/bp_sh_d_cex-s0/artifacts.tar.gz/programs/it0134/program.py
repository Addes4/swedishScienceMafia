# EVOLVE-BLOCK-START
"""Best-fit with histogram-based residual-fill tie-break."""
import numpy as np

_state = {
    "counts": np.zeros(101, dtype=np.float64),  # counts[s] = times item size s was seen
    "n": 0.0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state

    counts = _state["counts"]
    n = _state["n"]

    # Update histogram with the current item (does not see future items).
    counts[item] += 1.0
    n += 1.0
    _state["n"] = n

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Histogram-based tie-break: prefer residuals that past items have matched
    # (so the residual bin is likely to be exactly filled by a future item).
    # Weighted by observed frequency, normalized to [0,1].
    r = np.clip(residual, 0, 100)
    freq = counts[r] / n  # empirical probability that this residual equals a future item size
    # Bonus only for nonzero residuals (exact fills already handled by best-fit).
    bonus = np.where(residual > 0, freq, 0.0)

    # Scale so the secondary term only matters near ties in the primary term.
    return primary + 0.5 * bonus
# EVOLVE-BLOCK-END
