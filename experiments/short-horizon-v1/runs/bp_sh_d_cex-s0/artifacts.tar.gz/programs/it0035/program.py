# EVOLVE-BLOCK-START
"""Best-fit for filling existing bins tightly, but prefer any partial bin over opening a new one.

The classic Best-Fit heuristic always minimizes leftover, which can leave unusable slivers.
An alternative that often does better on skewed size distributions is to only care about
whether the item *fits* into a bin that is already partly used, and only open an empty bin
when no partial bin can take it. Among partial bins we still pick the tightest fit (best fit)
to keep large gaps available for large items.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    remaining = bins.astype(np.int64)
    # Bins with capacity 100 are unused; treat them as "empty".
    is_empty = (remaining >= 100)
    leftover = remaining - item  # how much would be left after placing the item
    # Among used bins, prefer the tightest fit (smallest leftover).
    score = -leftover.astype(np.float64)
    # Push empty bins below all used bins: subtract a large constant so any used bin wins.
    score = np.where(is_empty, score - 1000.0, score)
    return score
# EVOLVE-BLOCK-END
