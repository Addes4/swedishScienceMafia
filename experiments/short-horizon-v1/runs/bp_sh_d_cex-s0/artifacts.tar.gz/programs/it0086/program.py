# EVOLVE-BLOCK-START
"""Best-fit with a residual "fillability" penalty from the item-size histogram.

The item goes to the bin with the highest score.  We keep a running histogram of
observed item sizes and use it to estimate, for each candidate residual, how
unlikely it is that some future item can still fit into the leftover space.
Residuals that no plausible future item can fill get penalized; exact fills and
residuals that match common item sizes get a bonus.
"""
import numpy as np

_CAP = 100
_state = {
    "counts": np.ones(_CAP + 1, dtype=np.float64),  # Laplace prior, index = size
    "total": float(_CAP),                            # prior pseudo-count sum
}


def priority(item, bins):
    global _state
    counts = _state["counts"]
    counts[item] += 1.0
    _state["total"] += 1.0

    residual = bins - item  # leftover capacity after placing the item
    residual = residual.astype(np.float64)

    # Best-fit primary: tighter fit is better.
    primary = -residual

    # Estimate probability mass of item sizes <= r for each distinct residual.
    total = _state["total"]
    cum = np.cumsum(counts) / total            # cum[s] = P(size <= s), s in 0..100
    # For residual r, usable future items have size <= r.  Small r => small mass.
    rm = np.clip(residual, 0, _CAP).astype(np.int64)
    usable_mass = cum[rm]

    # Exact-fill bonus: mass of the single size equal to the residual.
    exact_mass = counts[rm] / total
    exact = np.where(residual == 0, 0.0, 0.0)  # residual 0 already terminal
    exact_bonus = np.where((residual > 0) & (residual <= _CAP),
                           exact_mass, 0.0)

    # Sliver penalty: residual is positive but too small to be likely reusable.
    # Weight grows as usable_mass shrinks.
    sliver = np.where(residual > 0, (1.0 - usable_mass) ** 2, 0.0)
    # Empty/zero residual: neutral (nonexistent here since bins are fitting bins).
    sliver = np.where(residual == 0, 0.0, sliver)

    # Scale secondary terms modestly relative to primary (residuals are integers).
    return primary - 2.0 * sliver + 3.0 * exact_bonus
# EVOLVE-BLOCK-END

