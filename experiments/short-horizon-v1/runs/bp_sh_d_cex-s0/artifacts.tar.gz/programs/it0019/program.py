# EVOLVE-BLOCK-START
"""Best fit with a concave leftover utility that prefers exact/tiny gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    Primary behavior is tightest fit (smallest leftover after placement), but we
    shape the leftover through a concave function so that exact fills and tiny
    leftovers dominate, while large leftovers (unused/empty bins) are least
    preferred. This keeps the strong best-fit backbone and only softly breaks
    the ordering among near-ties.
    """
    leftover = bins - item
    # Concave, decreasing utility: smaller leftover -> higher score.
    # sqrt compresses large gaps so near-exact fits dominate cleanly.
    return -np.sqrt(leftover.astype(np.float64))
# EVOLVE-BLOCK-END

