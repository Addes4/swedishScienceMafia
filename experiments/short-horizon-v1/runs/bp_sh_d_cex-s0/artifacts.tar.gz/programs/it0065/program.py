# EVOLVE-BLOCK-START
"""Best-fit with distribution-aware residual preference to reduce premature slivers."""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.float64), "total": 0.0}
_DECAY = 0.995


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    counts = _state["counts"]
    total = _state["total"]
    counts *= _DECAY
    total *= _DECAY
    counts[item] += 1.0
    total += 1.0
    _state["total"] = total

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Probability that a residual will be exactly matched by some single future
    # item (mode-awareness). Exact matches are valuable.
    p_single = counts[residual] / (total if total > 0 else 1.0)

    # Small residuals in [1, min_reasonable) are hard to reuse; estimate a
    # threshold from the distribution's low tail (roughly the 5th percentile).
    # We use a cheap proxy: the smallest size with non-trivial mass.
    sliver_thresh = 3.0
    sliver = (residual > 0) & (residual < sliver_thresh)

    penalty = np.where(sliver, 0.3, 0.0)

    # Reward residuals that are themselves common item sizes (fillable later),
    # scaled small so best-fit remains dominant.
    reward = 0.2 * p_single

    return primary - penalty + reward
# EVOLVE-BLOCK-END
