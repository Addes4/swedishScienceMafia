# EVOLVE-BLOCK-START
"""Best fit with a light, spectrum-aware tie-break.

Primary key: minimize the post-placement remaining capacity (classic best fit).
Secondary: among bins whose post-placement leftover is (nearly) equal, prefer the
leftover that recent arriving items have historically been able to complete,
estimated online from a running histogram of item sizes observed so far.
"""
import numpy as np

# module state, reset per stream (we detect a new stream by seeing all-full bins)
_seen = None       # np.array of observed item sizes (bounded)
_hist = None       # normalized histogram over 1..100 item sizes


def _reset():
    global _seen, _hist
    _seen = np.zeros(256, dtype=np.int64)
    _hist = np.zeros(101, dtype=np.float64)


def _update(item):
    global _seen, _hist
    if _hist is None or _seen is None:
        _reset()
    _seen[item] += 1
    _hist[item] += 1.0


def _fit_prob(cap):
    """Rough estimate that some observed item equals `cap` (a leftover completion)."""
    if cap <= 0:
        return 1.0  # exact fill: already the best possible
    if cap > 100:
        return 0.0
    return _hist[cap]


def priority(item, bins):
    bins = np.asarray(bins)
    # detect fresh stream: all bins unused (remaining 100) means state should be reset
    if bins.size and np.all(bins == 100) and (_hist is None or _hist.sum() > 0):
        # could be a genuine new stream; a fresh empty stream is cheap to treat as reset
        _reset()
    _update(item)

    leftover = bins - item  # remaining capacity after this item (>=0 since bin is feasible)

    # primary: smaller leftover is better (best fit)
    # secondary: prefer leftovers that recent items can complete exactly
    comp = np.array([_fit_prob(int(l)) for l in leftover], dtype=np.float64)

    # scale the secondary term small so it never overrides the primary ordering
    score = -leftover + 1e-3 * comp
    return score
# EVOLVE-BLOCK-END
