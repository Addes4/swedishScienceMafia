# EVOLVE-BLOCK-START
"""Best-fit dominant rule with a smooth, mild sliver penalty that never overrides fit quality."""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    _state["sum"] += item
    _state["count"] += 1
    mean_item = _state["sum"] / _state["count"]

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    # Scale so residual differences of 1 always dominate the secondary term.
    primary = -residual.astype(np.float64)

    # Smooth sliver penalty: residuals well below the mean item size are likely
    # unusable. Penalty magnitude is bounded (< 0.5) so it only breaks near-ties
    # in residual, never reorders meaningfully different fits.
    thresh = max(mean_item, 1.0)
    frac = residual / thresh  # 0 near exact fill
    sliver = (residual > 0) & (frac < 1.0)
    # penalty: largest (~0.5) for the smallest positive residual, fading to 0 at thresh
    penalty = np.where(sliver, 0.5 * (1.0 - frac), 0.0)

    # Exact fill bonus, slightly larger than max sliver penalty of same residual 0.
    bonus = np.where(residual == 0, 0.6, 0.0)

    return primary - penalty + bonus
# EVOLVE-BLOCK-END

