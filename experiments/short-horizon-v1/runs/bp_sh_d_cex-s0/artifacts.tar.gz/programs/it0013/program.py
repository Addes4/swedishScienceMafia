# EVOLVE-BLOCK-START
"""Stateful best-fit with a tie-break that favors reusable leftovers."""
import numpy as np

_state = {
    "n": 0.0,
    "mean": 40.0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary rule: best fit (prefer the fullest bin the item still fits into).
    Secondary: among bins leaving similar leftovers, prefer a leftover that is
    close to a whole number of typical items, keeping residuals reusable.
    """
    # Update running mean of item sizes (exponential-ish smoothing toward truth).
    _state["n"] += 1.0
    _state["mean"] += (item - _state["mean"]) / min(_state["n"], 200.0)
    mean = _state["mean"]

    leftover = bins - item  # remaining capacity after placement, >= 0

    # Primary: best fit -> smaller leftover is better.
    score = -leftover.astype(np.float64)

    # Secondary: penalize leftovers that are neither 0 nor near a reuse-friendly
    # granularity; keep it tiny so it only breaks ties among best-fit choices.
    fr = leftover / mean
    reuse = np.minimum(fr - np.floor(fr), np.ceil(fr) - fr)  # distance to a multiple
    score -= 0.25 * reuse

    return score
# EVOLVE-BLOCK-END
