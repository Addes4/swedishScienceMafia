# EVOLVE-BLOCK-START
"""Best-fit with expected-waste penalty from a streaming item-size histogram."""
import numpy as np

# Bin capacity is fixed at 100 for this problem.
CAP = 100

# Empirical histogram of item sizes seen so far (index 1..100).
_hist = np.zeros(CAP + 1, dtype=np.float64)
_seen = 0.0

# Precompute size axis.
_sizes = np.arange(CAP + 1, dtype=np.float64)


def _expected_waste(residual_values):
    """For each residual, expected item size that can never fit = E[max(0, size - residual)].

    Using the empirical histogram of past items as the predictive distribution.
    """
    if _seen <= 0.0:
        return np.zeros_like(residual_values)
    probs = _hist / _seen  # length 101
    # For a residual r, waste = sum_s P(s) * max(0, s - r)
    # Vectorized over residuals: shape (len(res), 101)
    r = residual_values[:, None].astype(np.float64)
    excess = np.maximum(0.0, _sizes[None, :] - r)
    return excess @ probs


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _seen

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)

    # Expected future waste: prefer residuals that can absorb typical future items.
    waste = _expected_waste(residual)

    # Exact fill bonus: a perfect fit leaves a finished bin, always good.
    exact = (residual == 0).astype(np.float64)

    # Combine: best-fit dominates, then subtract waste (lower waste better),
    # then reward exact fills.
    score = primary - 0.5 * waste + 0.25 * exact

    # Update histogram with the current item (after scoring, so no peeking ahead
    # beyond the fact that this item has actually arrived).
    if 1 <= item <= CAP:
        _hist[item] += 1.0
        _seen += 1.0

    return score
# EVOLVE-BLOCK-END

