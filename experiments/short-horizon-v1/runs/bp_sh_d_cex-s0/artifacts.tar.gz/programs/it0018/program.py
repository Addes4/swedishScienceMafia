# EVOLVE-BLOCK-START
"""Best fit: put the item in the bin it fits most tightly.

Tie-breaking: among bins that give the same leftover after placement, prefer
the bin that started with the larger remaining capacity (a partial fill of a
fuller bin), which is a safe deterministic choice that never hurts the
near-optimal best-fit behaviour.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities (all bins the item fits in),
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: minimize leftover after placement  ->  -(bins - item)
    # Secondary: prefer larger pre-placement capacity -> + bins
    return -(bins - item) + bins * 1e-6
# EVOLVE-BLOCK-END
