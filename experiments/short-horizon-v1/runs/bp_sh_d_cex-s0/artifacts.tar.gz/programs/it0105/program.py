# EVOLVE-BLOCK-START
"""Pure best-fit: prefer exact fills, then the tightest remaining fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item
    # Best-fit: tighter fit (smaller residual) is better.
    # A tiny bonus for exact fills keeps the ordering identical to best-fit
    # (residual 0 is already the smallest residual) while documenting intent.
    score = -residual.astype(np.float64)
    score += (residual == 0) * 0.5
    return score
# EVOLVE-BLOCK-END
