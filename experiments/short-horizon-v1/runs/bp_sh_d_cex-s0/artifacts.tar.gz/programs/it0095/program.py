# EVOLVE-BLOCK-START
"""Pure best-fit: place the item into the bin with the smallest remaining capacity that fits it."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit: tighter fit (smaller residual after placement) is better.
    return -(bins - item).astype(np.float64)
# EVOLVE-BLOCK-END
