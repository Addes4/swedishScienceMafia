# EVOLVE-BLOCK-START
"""Fit-aware scoring: reward residuals that a future item is likely to fill well."""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _state
    _state["sum"] += item
    _state["count"] += 1
    mean = _state["sum"] / _state["count"]

    residual = (bins - item).astype(np.float64)  # remaining capacity after placement

    # Scale of typical item sizes; used to make the score scale invariant.
    scale = max(mean, 1.0)
    s = residual / scale

    # Reward small residuals (tight fit) but smooth so tiny slivers are not overvalued.
    # A Gaussian-like bump near zero plus a mild preference for exact fills.
    tight = np.exp(-(s ** 2))
    exact = np.where(residual == 0, 0.25, 0.0)

    # Penalize unusable slivers: small but nonzero residuals that a future item
    # (mean ~ mean) is unlikely to fill exactly.
    sliver = np.where((residual > 0) & (residual < scale * 0.5), 1.0, 0.0)

    return tight + exact - sliver
# EVOLVE-BLOCK-END
