# EVOLVE-BLOCK-START
"""Stateful best-fit variant that prefers residuals that can still be filled.

Items arrive one at a time. Pure best-fit minimizes the immediate residual, but often
leaves tiny unusable gaps. We instead score bins by best-fit (tightest fit) as the
primary criterion, and use the resulting residual's "usefulness" as a tie-breaker:
a residual is considered useful when it is close to a typical future item size (tracked
online as a running histogram) or when it is exactly zero.
"""
import numpy as np


class _State:
    def __init__(self):
        # histogram of observed item sizes 1..100
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0

    def observe(self, item):
        if 1 <= item <= 100:
            self.hist[item] += 1.0
        self.count += 1


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _state.observe(item)

    # Best-fit primary: prefer the tightest fit, i.e. smallest residual after placing.
    residual = bins - item  # >= 0 for all shown bins

    if _state.count < 16:
        # Not enough statistics yet: pure best fit.
        return -residual

    hist = _state.hist
    total = hist.sum()
    # probability mass concentrated on "common" sizes; we reward residuals that
    # match a frequently seen size (can be filled exactly by a future item).
    probs = hist / max(total, 1.0)

    # Build a smooth usefulness curve over residuals 0..100.
    # - residual 0 is perfect (bin exactly filled)
    # - residual equal/near a common item size is good (future exact fill)
    # - tiny residuals (1..3) that rarely match common items are slightly penalized
    max_size = 100
    useful = np.zeros(max_size + 1, dtype=np.float64)
    for r in range(0, max_size + 1):
        if r == 0:
            useful[r] = 1.0
            continue
        # nearest known sizes contribution
        lo = max(1, r - 2)
        hi = min(100, r + 2)
        mass = probs[lo:hi + 1].sum()
        useful[r] = mass
    # Scale usefulness into a secondary term (much smaller than primary spacing 1).
    secondary = 0.4 * useful[residual]

    return -(residual.astype(np.float64)) + secondary
# EVOLVE-BLOCK-END
