# EVOLVE-BLOCK-START
"""Distribution-aware best fit: keep large residuals for large items (Weibull mean ~40)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Best fit dominant term: always prefer the smallest residual.
    score = -residual.astype(np.float64)

    if item < 40:
        # Small items: add a small, strictly-bounded tie-breaker. Reward leaving
        # a residual that is either exactly zero (perfect fit) or large enough to
        # still hold a typical large item (~40), so that filler items do not
        # consume capacity that only big items could use.
        small_gap = (residual >= 1) & (residual <= 15)
        score[small_gap] -= 1.0
        perfect = residual == 0
        score[perfect] += 1.0
        usable = residual >= 40
        score[usable] += 0.5
    return score
# EVOLVE-BLOCK-END

