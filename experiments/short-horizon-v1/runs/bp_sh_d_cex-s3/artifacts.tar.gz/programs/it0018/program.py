# EVOLVE-BLOCK-START
"""Best-fit with a mild density-based tiebreak favoring residuals that match likely future item sizes."""
import numpy as np

# Cache a smooth density target over residual sizes 1..100.  Item sizes are Weibull-shaped with
# mean ~40; we use a simple bounded bell-ish shape peaked around 40 as the "likely next size".
_SIZES = np.arange(0, 101, dtype=np.float64)
# Smooth density: mixture of a peak near 40 and a broad component; low weight near extremes.
_PEAK = 40.0
_SIG = 22.0
_DENSITY = np.exp(-0.5 * ((_SIZES - _PEAK) / _SIG) ** 2)
# small items are common too; add a gentle secondary bump for tiny leftovers
_DENSITY += 0.35 * np.exp(-0.5 * ((_SIZES - 8.0) / 8.0) ** 2)
_DENSITY /= _DENSITY.max()

_W = 1.2  # weight of the secondary "residual attractiveness" term


def priority(item, bins):
    """Rank bins: best fit first, plus a tiny reward when the leftover matches likely future items.

    item: integer size 1..100.
    bins: numpy int64 array of remaining capacities (only bins the item fits in).
    """
    residual = bins - item  # always >= 0
    # Clip residual into the table domain for the density lookup.
    idx = np.clip(residual, 0, 100).astype(np.int64)
    bonus = _DENSITY[idx]
    # Primary: smallest residual (tightest fit). Secondary: attractive leftover.
    return -residual.astype(np.float64) + _W * bonus
# EVOLVE-BLOCK-END
