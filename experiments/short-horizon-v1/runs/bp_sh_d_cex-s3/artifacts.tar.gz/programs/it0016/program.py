# EVOLVE-BLOCK-START
"""Best fit with a gentle harmonic size-class pairing bonus."""
import numpy as np


def _size_class(x):
    """Map a residual size (1..100) to a coarse harmonic-ish class index."""
    if x <= 0:
        return 0
    if x <= 10:
        return 1
    if x <= 20:
        return 2
    if x <= 30:
        return 3
    if x <= 40:
        return 4
    if x <= 55:
        return 5
    if x <= 70:
        return 6
    if x <= 85:
        return 7
    return 8


def priority(item, bins):
    """Return a priority for every bin; highest wins, ties go to the first bin.

    Primary key: best fit (smallest residual after placing the item).
    Secondary: small bonus when the resulting residual lands in the same
    size class as the item, encouraging similar-sized items to share bins.
    """
    residual = bins - item
    res = residual.astype(np.float64)

    item_cls = _size_class(item)
    res_cls = np.array([_size_class(r) for r in residual])

    # bonus: prefer residual in the same class as the item (pairing), and
    # slightly prefer adjacent classes.
    same = (res_cls == item_cls).astype(np.float64)
    adj = (np.abs(res_cls - item_cls) == 1).astype(np.float64)
    bonus = 0.5 * same + 0.1 * adj

    # best-fit dominance: negative residual, plus a bounded bonus.
    return -res + bonus
# EVOLVE-BLOCK-END

