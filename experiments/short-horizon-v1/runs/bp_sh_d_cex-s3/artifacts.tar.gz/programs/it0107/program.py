# EVOLVE-BLOCK-START
"""Best-fit with a bounded stateful 'usable residual' shaping bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    # Best-fit primary: prefer the tightest fit (smallest residual after placement).
    resid = bins - item  # >= 0 for all shown bins
    score = -resid.astype(np.float64)

    # Stateful running mean of item sizes (module-level, reset per stream by harness).
    global _count, _mean
    try:
        _count
    except NameError:
        _count = 0
        _mean = 40.0

    _count += 1
    _mean += (item - _mean) / _count

    # Bounded shaping: reward residuals likely to be consumable by future typical items.
    lo = 0.4 * _mean
    hi = 1.6 * _mean
    # Gaussian-ish bump centered on the running mean, capped small vs best-fit spacing.
    bonus = 0.0
    if _count > 5:
        bonus = 1.0 - np.abs(resid.astype(np.float64) - _mean) / max(_mean, 1.0)
        bonus = np.clip(bonus, 0.0, 1.0)
        # Only meaningful when residual is in the usable band.
        bonus *= ((resid >= lo) & (resid <= hi)).astype(np.float64)
        # Scale so it can only break near-ties (residuals within ~1 unit), not override fit.
        score = score + 0.45 * bonus

    return score
# EVOLVE-BLOCK-END

