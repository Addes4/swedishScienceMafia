# EVOLVE-BLOCK-START
"""Adaptive-threshold best fit: keep large residuals for large items (Weibull mean ~40)."""
import numpy as np

# Module-level running state (reset per stream by the harness importing fresh modules).
_total = 0.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _total, _count

    # Update running mean of observed item sizes.
    _total += item
    _count += 1
    mean = _total / _count

    residual = bins - item  # remaining capacity after placing the item

    # Threshold between "large" and "small" items, tracked to the observed mean.
    # Clamp to a sane range to remain robust early in the stream.
    threshold = mean
    if threshold < 30.0:
        threshold = 30.0
    elif threshold > 50.0:
        threshold = 50.0

    if item >= threshold:
        # For large items, standard best fit (pack tightly).
        return -(residual)

    # Small item: favor bins with small residual (fill fuller bins), but nudge
    # away from creating tiny unusable residuals.
    score = -residual.astype(np.float64)
    awkward = (residual >= 1) & (residual <= 14)
    score[awkward] -= 2.0
    return score
# EVOLVE-BLOCK-END
