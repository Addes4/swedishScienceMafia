# EVOLVE-BLOCK-START
"""Best-fit with a reusable-residual bonus driven by the observed item distribution.

Items are Weibull-shaped with mean ~40. Pure best-fit packs tightly but can strand
tiny unusable residuals. We keep best-fit as the dominant term and add a small
bonus for bins whose post-placement residual is *usable*, i.e. large enough that a
typical future item can still land there, estimated online from observed sizes.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item

    # Track observed item sizes to estimate the distribution's small-item mass.
    # State kept on the function object across calls within a stream.
    hist = getattr(priority, "hist", None)
    total = getattr(priority, "total", 0)
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        priority.hist = hist
    if item <= 100:
        hist[item] += 1.0
        total += 1
        priority.total = total

    # Dominant term: best fit (prefer smallest residual).
    score = -residual.astype(np.float64)

    # Usable-residual bonus: a residual r is "usable" if there is a decent
    # probability that a future item fits in r. Estimate that probability from
    # the running histogram (fraction of observed items <= r). This favors
    # residuals that preserve packing flexibility without a hard threshold.
    if total >= 20:
        cdf = np.cumsum(hist) / total  # cdf[r] ~ P(item <= r)
        # cdf restricted to residual range; cap residual at 100.
        r_idx = np.clip(residual, 0, 100)
        usable = cdf[r_idx] * np.minimum(residual, 100) / 100.0
        score += 0.5 * usable
    else:
        # Cold start: mild fixed bonus for residuals that can fit common items.
        usable = np.minimum(residual, 100) / 100.0
        score += 0.5 * usable

    return score
# EVOLVE-BLOCK-END
