# EVOLVE-BLOCK-START
"""Rank bins by resulting residual, with exact fit and usable-gap preference."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Primary: prefer smaller residual (best fit). Exact fit (residual 0) is the extreme of this.
    # To avoid stranding tiny unusable gaps, apply a small penalty for residual of 1 (a gap
    # almost no future item can use) unless it is an exact fit.
    score = -residual.astype(np.float64)
    score = np.where((residual == 1) & (item != 100), score - 0.5, score)
    return score
# EVOLVE-BLOCK-END
