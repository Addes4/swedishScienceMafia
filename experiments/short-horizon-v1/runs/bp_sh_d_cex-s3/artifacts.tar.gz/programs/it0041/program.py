# EVOLVE-BLOCK-START
"""Winner rule: prefer bins whose residual stays usable; otherwise best fit."""
import numpy as np


def priority(item, bins):
    """Score each bin so the item goes to the most useful bin (highest, first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    residual = bins - item
    # A residual smaller than this is a "wasted shard" unlikely to accept future items
    # (Weibull mean ~40 => many items are >= 20). Prefer not to create such shards.
    floor = 20
    # Primary: bins whose residual stays above the floor are strongly preferred.
    # Secondary: among preferred bins use best fit (smallest residual); among the rest,
    # also use best fit so we still consolidate small shards.
    return -residual - (residual < floor) * 1000.0
# EVOLVE-BLOCK-END

