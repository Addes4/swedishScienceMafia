# EVOLVE-BLOCK-START
"""Best fit with residual-quality adjustment based on the empirical item distribution."""
import numpy as np


class _State:
    def __init__(self):
        # histogram of item sizes 1..100
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0

    def update(self, item):
        self.hist[item] += 1.0
        self.count += 1.0


_state = _State()


def priority(item, bins):
    """Score bins: prefer tight fit, but avoid leaving tiny unusable residuals."""
    st = _state

    # Best-fit base: smaller residual is better.
    residual = bins - item  # >= 0 since only fitting bins are shown

    # Empirical distribution: probability mass of residuals that are "usable".
    if st.count >= 20.0:
        probs = st.hist / st.count
        # Common item sizes -> residual can likely be filled exactly.
        common = probs > 0.0
    else:
        probs = None
        common = None

    score = -residual.astype(np.float64)

    if probs is not None:
        # Penalize residuals below a "shard threshold": the smallest size that
        # has meaningful probability of arriving. Roughly the 5th percentile.
        # Use a lightweight proxy: find smallest size whose cumulative mass >= 0.02.
        cum = np.cumsum(probs[1:])  # sizes 1..100
        shard_min = 1
        for s in range(1, 101):
            if cum[s - 1] >= 0.02:
                shard_min = s
                break

        r = residual
        # penalty for tiny shards
        small = r < shard_min
        score[small] -= 15.0
        # small bonus if residual is a plausible future item size (non-trivial)
        plausible = (~small) & (r >= 1) & (r <= 100)
        idx = r[plausible]
        bonus = np.zeros(idx.shape[0], dtype=np.float64)
        valid = (idx >= 1) & (idx <= 100)
        bonus[valid] = probs[idx[valid]]
        score[plausible] += 8.0 * bonus

    st.update(item)
    return score
# EVOLVE-BLOCK-END
