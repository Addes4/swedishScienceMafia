# EVOLVE-BLOCK-START
"""Best-fit with a mean-aware worst-fit preference among sub-mean residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (fits only, plus fresh bins).
    """
    residual = bins - item  # remaining capacity after placing the item

    # Bins that would end up "small" (residual below the item mean ~40) are
    # hard to reuse for typical large items; among those prefer the LARGEST
    # residual (worst-fit) so we don't leave tiny unusable slivers.
    # Bins that would end up large are fine--pack them tightly (best-fit).
    small = residual < 40
    # Score: for small-residual bins, larger residual is better.
    # For large-residual bins, smaller residual is better.
    score = np.where(small, residual, -residual)
    return score
# EVOLVE-BLOCK-END
