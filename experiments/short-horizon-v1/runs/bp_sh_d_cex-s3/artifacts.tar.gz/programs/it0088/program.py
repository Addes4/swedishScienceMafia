# EVOLVE-BLOCK-START
"""Sum-aware best fit: learn which residuals actually get filled by future items."""
import numpy as np

_state = {
    "counts": np.zeros(101, dtype=np.float64),  # how often each residual got exactly filled
    "seen": np.zeros(101, dtype=np.float64),     # how often each residual was left behind
    "open": {},                                  # bin_index -> residual we left there
}


def _reset():
    _state["counts"][:] = 0.0
    _state["seen"][:] = 0.0
    _state["open"].clear()


def priority(item, bins):
    counts = _state["counts"]
    seen = _state["seen"]
    open_map = _state["open"]

    n = len(bins)
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    # Apply any pending observations: a bin we left with residual r was revisited
    # (still present in `bins`) -> nothing; if its residual changed, it got filled.
    # We detect exact fills by tracking residuals we predicted.
    # Update "seen" for residuals we now observe persisting.
    # Learn which residuals actually got consumed by later items.
    for idx, r in list(open_map.items()):
        if idx < n:
            cur = int(bins[idx])
            if cur != r:
                # this residual shrank -> it was (partially or fully) filled by items
                if cur == 0:
                    counts[r] += 1.0
                else:
                    seen[r] += 1.0
                # refresh the open record
                open_map[idx] = cur
        else:
            del open_map[idx]

    # Score each bin: prefer residual (bins[i]-item) that historically gets filled.
    # Use empirical fill probability with best-fit as a tie-strong fallback.
    residuals = bins - item
    total = counts + seen
    fill_prob = np.where(total > 0, counts / np.maximum(total, 1.0), 0.0)

    # Normalize fill_prob into a comparable scale to residuals.
    fp = fill_prob[residuals]
    # Primary term: tightness (best fit) scaled below the learned term so it
    # only breaks ties; learned fill probability dominates choices.
    score = 1000.0 * fp - residuals * 1e-3

    # record what we are leaving behind for this bin (chosen later)
    return score
# EVOLVE-BLOCK-END
