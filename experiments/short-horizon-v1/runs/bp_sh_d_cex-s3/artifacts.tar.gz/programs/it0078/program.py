# EVOLVE-BLOCK-START
"""Best-fit with expected-future-fit tie-breaking using an online size histogram.

Policy: score a placement by the residual it leaves (best-fit).  Among placements
that leave the same residual, prefer the one whose residual is more likely to be
matched (or nearly matched) by a future item, using a running histogram of item
sizes seen so far.  This keeps best-fit's strong packing quality but breaks ties
toward residuals that a future item can actually consume, reducing wasted space.
"""
import numpy as np

# Module-level state, reset per stream by detecting "fresh" starts.
_HIST = np.zeros(101, dtype=np.float64)   # histogram of item sizes 1..100
_COUNT = 0

# Precomputed: for a given residual r, its "usefulness" score.
def _residual_value(r):
    """Higher is better.  We want residuals that future items can fill."""
    if r <= 0:
        # exact fit -> excellent (no waste)
        return 2.0
    if r < 3:
        # very small leftover, essentially waste
        return -0.5
    # expected chance a future item (from histogram) fits into this residual,
    # weighted toward filling it more completely.
    hi = min(r, 100)
    if _COUNT > 0:
        p = _HIST[1:hi + 1].sum() / _COUNT
    else:
        # fallback: assume Weibull-ish mean ~40, approximate
        p = min(1.0, (r / 100.0) * 1.3)
    # reward larger residuals that are likely to be filled
    return 0.6 * p + 0.4 * (r / 100.0)


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    global _COUNT
    bins = np.asarray(bins, dtype=np.int64)

    # Update running histogram with this item.
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    # Residual after placing the item into each bin.
    resid = bins - int(item)

    # Primary term: best-fit (smaller residual -> higher score).
    # Use a large weight so best-fit ordering dominates.
    best_fit = -resid.astype(np.float64)

    # Secondary term over the residual value.
    vals = np.array([_residual_value(int(r)) for r in resid], dtype=np.float64)

    # Combine: best-fit dominates, value breaks near-ties.
    return best_fit * 1000.0 + vals
# EVOLVE-BLOCK-END
