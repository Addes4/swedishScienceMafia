# EVOLVE-BLOCK-START
"""Stateful best-fit with residual-decomposability awareness.

The core idea: after placing the item into a bin leaving residual r, we estimate how
"fillable" r is by future items.  We keep an online histogram of item sizes observed so
far, and for each candidate residual we compute a small knapsack-style score measuring the
fraction of r that can be covered by the most common item sizes.  Residuals that are easy
to fill later are preferred, which tends to reduce wasted capacity and thus the number of
bins.  Exact fits are strongly preferred; otherwise we combine the fillability score with
best-fit tightness to break near-ties.
"""
import numpy as np

_CAP = 100

# --- module level state (reset per stream by re-import handled by harness) ---
_SIZES = np.zeros(_CAP + 1, dtype=np.float64)   # histogram of observed item sizes
_COUNT = 0

# Precompute, for each residual r, a "fillability" value in [0, 1] using a greedy
# decomposition over the currently most common sizes.  Recomputed lazily each call
# only when the histogram changes enough.
_fill_table = np.zeros(_CAP + 1, dtype=np.float64)
_table_stamp = -1

# how many distinct top sizes to consider in the decomposition
_TOP_K = 12


def _rebuild_table():
    global _fill_table, _table_stamp
    total = _SIZES.sum()
    if total <= 0:
        _fill_table = np.ones(_CAP + 1, dtype=np.float64)
        _table_stamp = _COUNT
        return
    # pick the most frequent sizes
    order = np.argsort(_SIZES)[::-1]
    common = []
    for s in order:
        if s <= 0:
            continue
        if _SIZES[s] > 0:
            common.append(int(s))
        if len(common) >= _TOP_K:
            break
    if not common:
        _fill_table = np.ones(_CAP + 1, dtype=np.float64)
        _table_stamp = _COUNT
        return

    # weights: relative frequency of each common size
    w = np.array([_SIZES[s] for s in common], dtype=np.float64)
    w = w / w.sum()

    # For each residual, greedily maximize covered capacity with common sizes,
    # using a small bounded knapsack DP (capacity <= 100).
    table = np.zeros(_CAP + 1, dtype=np.float64)
    for r in range(_CAP + 1):
        if r == 0:
            table[r] = 1.0
            continue
        # bounded knapsack: cover as much of r as possible
        dp = np.zeros(r + 1, dtype=np.int32)
        for idx, s in enumerate(common):
            if s > r:
                continue
            # unbounded-ish: allow multiple copies (limit r // s)
            maxc = r // s
            # binary splitting for efficiency
            k = 1
            while maxc > 0:
                take = min(k, maxc)
                step = take * s
                # 0/1 update on a copy
                newdp = dp.copy()
                for c in range(r, step - 1, -1):
                    if dp[c - step] + step > newdp[c]:
                        newdp[c] = dp[c - step] + step
                dp = newdp
                maxc -= take
                k <<= 1
        covered = dp[r]
        # also consider using a cheap "greedy remainder" refinement
        table[r] = covered / r
    _fill_table = table
    _table_stamp = _COUNT


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _COUNT, _table_stamp

    # update histogram with the arriving item
    _COUNT += 1
    if 1 <= item <= _CAP:
        _SIZES[item] += 1.0

    # rebuild the fillability table when histogram has moved enough
    if _table_stamp < 0 or (_COUNT % 5 == 0):
        _rebuild_table()

    bins = np.asarray(bins)

    # residual after placing into each bin
    residual = bins - item

    # best-fit tightness term: smaller residual is better (and thus higher priority)
    # normalize to ~[0,1]
    fit_term = 1.0 - (residual.astype(np.float64) / float(_CAP))

    # fillability of the resulting residual: larger is better
    fill_term = _fill_table[np.clip(residual, 0, _CAP)]

    # exact fit gets a strong bonus
    exact = (residual == 0).astype(np.float64)

    # final score: prefer fillable residuals, break near-ties with best-fit tightness
    score = 0.55 * fill_term + 0.40 * fit_term + 5.0 * exact
    return score
# EVOLVE-BLOCK-END
