# EVOLVE-BLOCK-START
"""Best-fit with a harmonic boundary bonus for the residual."""
import numpy as np

# Precompute class boundaries 100/k and a grid for distance lookup.
_KMAX = 20
_BOUNDARIES = np.array([100.0 / k for k in range(1, _KMAX + 1)])


def priority(item, bins):
    """Score bins: strongly prefer tight fits, softly prefer reusable residuals."""
    residual = bins - item               # >= 0 for bins shown
    # best-fit primary: smaller residual is better -> -residual
    score = -residual.astype(np.float64)

    # Distance of each residual to the nearest harmonic boundary.
    d = np.abs(residual[:, None] - _BOUNDARIES[None, :])
    nearest = d.min(axis=1)

    # Weak bonus (small relative to the 1.0 residual spacing) for boundary hits.
    # At most ~0.9, so best-fit still dominates except on near-ties.
    bonus = 0.9 * np.exp(-nearest / 2.0)

    return score + bonus
# EVOLVE-BLOCK-END
