# EVOLVE-BLOCK-START
"""Stateful online rule: best-fit for large items, fullest-fit consolidation for small items.

Idea: large items benefit from tight best-fit pairing (residual close to complement),
while small items should be consolidated to preserve large empty bins for future large items.
The split threshold adapts to the observed item-size distribution.
"""
import numpy as np

# Module-level state, reset per stream (harness restarts the module per stream).
_count = 0
_sum = 0.0
_thresh = 0.0


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties)."""
    global _count, _sum, _thresh

    # Update running statistics of observed items.
    _count += 1
    _sum += item
    mean = _sum / _count
    # Adaptive small-item threshold: a fraction of the running mean.
    _thresh = 0.5 * mean

    residual = bins - item  # capacity left after placing the item here (>=0)

    if item <= _thresh:
        # Small item: consolidate into the most-filled fitting bin (tightest residual)
        # so tiny residuals get used up instead of fragmenting large bins.
        # Higher priority for smaller residual.
        return -residual.astype(np.float64)

    # Large item: best-fit (tightest residual). Same as -residual.
    # Add a mild tie-breaking nudge favoring residuals able to hold another
    # near-mean item, without overriding the primary tightest-fit ordering.
    tie = np.where(residual >= mean, 1.0, 0.0)
    return -residual.astype(np.float64) + 1e-3 * tie
# EVOLVE-BLOCK-END
