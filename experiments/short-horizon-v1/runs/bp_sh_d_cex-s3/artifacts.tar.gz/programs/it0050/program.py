# EVOLVE-BLOCK-START
"""Best fit with a small tie-break toward emptier bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smallest resulting residual (tightest fit).
    # Secondary: prefer larger original residual (emptier bin) on near-ties,
    # encoded as a tiny additive term so it only breaks ties.
    return -residual.astype(np.float64) + 1e-3 * bins.astype(np.float64)
# EVOLVE-BLOCK-END
