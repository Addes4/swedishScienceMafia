# EVOLVE-BLOCK-START
"""Best fit with a capacity-preserving tie-break.

The item goes into the bin it fits most tightly (minimizing residual).  When several
bins yield the same residual, prefer the one with the largest remaining capacity,
which keeps a big bin available for future large items without disturbing the tight
packing that makes best-fit strong.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual).  Secondary: largest current capacity.
    return -residual * (bins.max() + 1) + bins
# EVOLVE-BLOCK-END
