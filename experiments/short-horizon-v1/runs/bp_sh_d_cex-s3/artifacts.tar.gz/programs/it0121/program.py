# EVOLVE-BLOCK-START
"""Adaptive best-fit with harmonic-residual correction.

Best-fit puts each item in the tightest feasible bin, which greedily minimizes
wasted space locally but can leave residuals too small to hold common large
items.  We keep best-fit as the primary criterion but break near-ties using an
online estimate of how "useful" the resulting residual is for the item
distribution seen so far: a residual r is useful if a typical arriving item
fits inside it.  This is a lightweight, stateful version of a matching-based
(Lagrange) bound and needs no future knowledge.
"""
import numpy as np

# Online statistics of item sizes seen in the current stream.
_state = {
    "n": 0,
    "sum": 0.0,
    "hist": np.zeros(101, dtype=np.float64),  # histogram of sizes 1..100
}


def _reset():
    _state["n"] = 0
    _state["sum"] = 0.0
    _state["hist"][:] = 0.0


def priority(item, bins):
    """Return a score per bin; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of feasible bins, in bin order.
    """
    # Detect the start of a new stream (new module state should begin fresh).
    # We cannot know this directly, but we reset cheaply if a full stream seems done.
    if _state["n"] >= 5000:
        _reset()

    # Update online item statistics with the current item.
    _state["n"] += 1
    _state["sum"] += item
    _state["hist"][item] += 1.0

    n = _state["n"]

    # Primary criterion: best fit (smallest residual => most negative -(bins-item)).
    primary = -(bins - item)

    # Residual after placing would be r = bins - item.
    r = bins - item  # nonneg since only feasible bins are shown

    # Estimate, from the observed distribution, the probability that a future
    # item fits inside residual r.  Use the empirical size histogram; smooth it
    # with a small uniform prior so early decisions are not too noisy.
    hist = _state["hist"]
    # cumulative count of sizes <= r
    cdf_le = np.cumsum(hist[:101])[r.astype(np.int64)]  # shape matches r
    # P(item <= r) estimated; small prior keeps values sane before data accrues.
    p_fit = (cdf_le + 1.0) / (n + 2.0)

    # Usefulness of residual: a residual is valuable if it can still hold a
    # decent fraction of typical items.  Combine fit-probability with a mild
    # preference for residuals near the observed mean size (good packing targets).
    mean = _state["sum"] / n
    # Target residual for "ideal reuse": about the mean item size.
    ideal = mean

    # Secondary score: prefer residuals close to the typical mean size, and
    # reward higher fit-probability.  Keep small relative to primary so best fit
    # dominates except for genuine near-ties.
    secondary = 0.5 * p_fit - 0.002 * np.abs(r - ideal)

    return primary + secondary
# EVOLVE-BLOCK-END
