# EVOLVE-BLOCK-START
"""Best fit with an empirical-residual tie-break.

Primary rule: best fit (smallest residual after placement).  Ties (and near-ties) are broken
by a small stateful bonus when the residual matches a frequently observed item size, so that
gaps left behind tend to be fillable by common future items.
"""
import numpy as np

_COUNT = np.zeros(101, dtype=np.float64)   # empirical counts of item sizes seen
_TOTAL = 0.0


def priority(item, bins):
    global _TOTAL
    # record the arriving item
    _COUNT[item] += 1.0
    _TOTAL += 1.0

    residual = bins - item                     # remaining capacity after placing here
    # normalize empirical frequency of each residual value to [0, 1]
    if _TOTAL > 0:
        freq = _COUNT[residual] / _TOTAL
    else:
        freq = np.zeros_like(residual, dtype=np.float64)

    # base: best fit -> the bin with the smallest residual is best
    # secondary: if two residuals are close, prefer the one that is a common item size
    return -residual.astype(np.float64) + 0.5 * freq
# EVOLVE-BLOCK-END
