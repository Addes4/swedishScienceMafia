# EVOLVE-BLOCK-START
"""Blended best fit: prefer tight fits, and let small items favor exact fills."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)  # capacity left after placing

    # Dominant term: best fit (small residual is best).
    score = -residual

    # Continuous smallness weight: 0 for large items, ->1 for tiny items.
    w = max(0.0, (50.0 - item) / 50.0)

    # Bonus for residuals that are exactly filled or leave a reusable gap.
    # Prefer residual == 0 (perfect fill) and penalize tiny unusable gaps.
    perfect = 8.0 * w
    score += perfect * (residual == 0)
    tiny = (residual >= 1) & (residual <= 10)
    score[tiny] -= (1.5 * w)

    return score
# EVOLVE-BLOCK-END

