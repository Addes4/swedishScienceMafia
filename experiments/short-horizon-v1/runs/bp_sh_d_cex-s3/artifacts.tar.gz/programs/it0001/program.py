# EVOLVE-BLOCK-START
"""Best fit with a tie-aware leftover penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacities of bins the item fits in, in bin order.
    """
    remaining = bins - item
    # Best fit: smallest remaining capacity is best (maximize -remaining).
    score = -remaining.astype(np.float64)
    # Mild penalty for leaving a small non-zero leftover that is likely unusable.
    # A leftover of 0 is perfect (no penalty); leftovers in 1..20 are discouraged
    # slightly so we avoid stranding tiny slivers, while still preferring tight fits.
    penalty = np.where((remaining > 0) & (remaining <= 20), 0.05 * remaining, 0.0)
    return score - penalty
# EVOLVE-BLOCK-END

