# EVOLVE-BLOCK-START
"""Best-fit plus a small stateful "residual is a common item size" pairing bonus."""
import numpy as np

_CAP = 100.0
# Histogram of item sizes seen so far (index 0..100 unused).
_hist = np.zeros(_CAP + 1, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    global _hist, _total

    # Empirical probability that a future item exactly equals a given size.
    if _total > 0:
        prob = _hist / _total
    else:
        prob = np.zeros(_CAP + 1, dtype=np.float64)

    # Best-fit: prefer smallest residual after placing item.
    residual = bins - item

    # Pairing bonus: if the leftover residual is a size we have seen often,
    # a future item may fill it exactly. Cap the bonus so best-fit dominates.
    idx = np.clip(residual, 0, _CAP).astype(np.int64)
    bonus = 6.0 * prob[idx]

    # Tiny preference for not leaving huge residuals (keeps best-fit ordering).
    score = -residual + bonus

    # Update histogram with the current item (state for later calls).
    _hist[item] += 1.0
    _total += 1.0

    return score
# EVOLVE-BLOCK-END
