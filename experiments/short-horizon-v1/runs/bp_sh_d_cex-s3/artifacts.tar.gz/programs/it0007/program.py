# EVOLVE-BLOCK-START
"""Size-adaptive best fit: tightest fit, with small items strongly funneled into
already well-filled bins to reduce fragmentation on the Weibull-shaped stream."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # residual capacity after placing the item
    if item <= 20:
        # Small item: strongly prefer the tightest fit (fill gaps of open bins).
        # Use a steep nonlinear penalty on residual so tiny gaps dominate.
        return -rem.astype(np.float64) * 4.0
    elif item <= 60:
        # Medium item: standard best fit.
        return -rem.astype(np.float64)
    else:
        # Large item: best fit, but nudge away from leaving a near-full bin's
        # tiny residual, which would waste space for future large items.
        score = -rem.astype(np.float64)
        small = rem <= 3
        score[small] -= 1.0
        return score
# EVOLVE-BLOCK-END
