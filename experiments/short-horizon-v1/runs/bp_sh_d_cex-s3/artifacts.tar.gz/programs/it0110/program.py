# EVOLVE-BLOCK-START
"""Residual-class best fit, distribution aware.

Pure best-fit (residual-tightest) is a strong online rule but ignores the fact that
leaving a residual equal to a common future item size wastes nothing, while leaving
an "odd" residual tends to strand capacity.  We keep best-fit as the dominant term
and add a small, bounded bonus when the residual left behind is a plausible future
item size (estimated from a running histogram), so the rule degrades gracefully
for unusual distributions.
"""
import numpy as np

# ---- module state (reset per stream; the harness calls a fresh module each stream) ----
_NBINS_HIST = 120          # histogram over sizes 1..100 (index by size)
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0


def _update_hist(item):
    global _total
    _hist[item] += 1.0
    _total += 1.0


def priority(item, bins):
    """Best-fit with a small bonus for residuals that look like future items."""
    _update_hist(item)

    # residual remaining after placing the item in each bin
    resid = bins - item  # >= 0 for all shown bins

    # posterior probability that a future item exactly equals the residual.
    # Laplace-smoothed so unseen sizes still get a tiny mass and best-fit dominates.
    denom = _total + 101.0
    # P(size == r) estimated for every candidate residual r
    probs = (_hist[resid] + 1.0) / denom

    # Best-fit primary: prefer the smallest residual (tightest fit).  Scale so that
    # a one-unit difference in residual dominates any plausible probability bonus.
    score = -resid.astype(np.float64) + 0.25 * probs
    return score
# EVOLVE-BLOCK-END
