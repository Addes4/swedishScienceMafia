# EVOLVE-BLOCK-START
"""Best fit with a fillability-aware penalty on tiny unusable residuals."""
import numpy as np


class _State:
    max_seen = 0


def priority(item, bins):
    """Rank bins: prefer tightest fit, but discourage residuals too small to be useful.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item > _State.max_seen:
        _State.max_seen = item

    residual = bins - item  # >= 0 for all shown bins
    # Base best-fit: tighter (smaller residual) is better.
    score = -residual.astype(np.float64)

    # Penalize leaving a strictly positive residual smaller than the largest item seen:
    # such a bin can never be filled again and its space is wasted.
    # Exact fills (residual 0) are not penalized.
    small = (residual > 0) & (residual < _State.max_seen)
    score[small] -= 1.0

    return score
# EVOLVE-BLOCK-END
