# EVOLVE-BLOCK-START
"""Distribution-aware best fit: keep large residuals for large items (Weibull mean ~40)."""
import numpy as np

# Running histogram of observed item sizes (1..100), shared across calls within a stream.
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0

# Precompute cumulative probability of at least one item fitting a residual of size r.
# P(fit | residual r) = fraction of observed items with size <= r.
_PROB_FIT = None


def _update_prob(item):
    """Rebuild the fit-probability lookup from the running histogram."""
    global _PROB_FIT
    # cumulative distribution of item sizes
    cdf = np.cumsum(_HIST)
    if cdf[-1] > 0:
        cdf = cdf / cdf[-1]
    _PROB_FIT = cdf


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _TOTAL
    _HIST[item] += 1.0
    _TOTAL += 1.0
    _update_prob(item)

    residual = bins - item  # remaining capacity after placing the item

    # Dominant term: best fit (prefer smallest resulting residual).
    score = -residual.astype(np.float64)

    if _TOTAL >= 1:
        # Usability of the residual we create: probability a future item fits into it.
        # Residuals of 0 are perfect; tiny residuals (e.g. 1) are near-useless.
        r = np.clip(residual, 0, 100)
        usable = _PROB_FIT[r]  # in [0,1]: higher = more likely reusable later
        # For the current item itself, a zero residual is ideal, so no penalty there.
        # Bonus rewards creating residuals that are likely to be reused, weighted small
        # so best-fit stays dominant. Avoid rewarding r==0 differently (it's just tight).
        score += 2.0 * usable
    else:
        # Fallback (should not trigger): mild nudge away from tiny residuals.
        awkward = (residual >= 1) & (residual <= 15)
        score[awkward] -= 2.0

    return score
# EVOLVE-BLOCK-END
