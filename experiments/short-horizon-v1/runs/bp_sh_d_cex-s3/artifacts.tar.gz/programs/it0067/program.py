# EVOLVE-BLOCK-START
"""Best-fit with exact-fill preference and small residual-quality tie-break."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer exact fit, otherwise best fit; break ties by residual fillability."""
    residual = bins - item  # remaining capacity after placing item

    # Primary: best fit (smallest resulting residual)
    score = -residual.astype(np.float64)

    # Strong bonus for perfect fits (residual exactly 0)
    score += (residual == 0) * 1000.0

    # Small bonus: among near-ties, reward residuals that equal a "common" size,
    # penalize tiny unusable gaps (1..4) slightly. This never overrides best-fit
    # by more than epsilon-level, only nudges equal/near-equal residuals.
    tiny = (residual >= 1) & (residual <= 4)
    score += tiny * (-0.001)

    return score
# EVOLVE-BLOCK-END
