# EVOLVE-BLOCK-START
"""Online bin packing: prefer fits whose residual is a likely future item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item  # remaining capacity after placing the item
    # Best-fit primary: strongly prefer the tightest fit (smallest residual).
    score = -resid.astype(np.float64)
    # Secondary: nudge toward residuals that match a typical future item size (~40),
    # so leftover space stays usable rather than becoming a stranded sliver.
    target = 40.0
    sigma = 22.0
    bonus = -0.08 * ((resid - target) ** 2) / (sigma * sigma)
    return score + bonus
# EVOLVE-BLOCK-END
