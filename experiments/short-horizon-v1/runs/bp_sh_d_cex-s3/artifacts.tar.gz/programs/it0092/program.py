# EVOLVE-BLOCK-START
"""Best fit with a mild consolidation tie-break.

Pure best fit leaves many tiny residuals that later items cannot fill. This rule
still prefers the tightest fit, but when several bins give the same (or nearly
the same) residual it prefers the bin that is already more full, consolidating
waste into fewer, larger gaps that future items can still use.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # leftover after placing the item
    # Primary: tighten fit (smaller residual is better).
    # Secondary (tiny): prefer fuller bins to consolidate slack, scaled so it
    # only breaks ties among equal residuals without overturning tighter fits.
    return -residual * 256.0 + (100 - bins)
# EVOLVE-BLOCK-END
