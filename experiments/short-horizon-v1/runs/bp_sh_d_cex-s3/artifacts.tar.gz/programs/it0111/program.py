# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware residual usefulness bonus."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.int64), "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary signal is best-fit (tightest residual after placement). A small bounded bonus
    rewards residuals that match common observed item sizes, so fragmented bins can be
    closed off later. Bonus is capped so best-fit never reverses on clearly different fits.
    """
    hist = _state["hist"]
    n = _state["n"]

    res = bins - item  # remaining capacity after placing item

    # Best-fit component: smaller residual better. Normalize conservatively.
    bf = -res.astype(np.float64)

    # Distribution-aware bonus: probability mass at the residual size.
    if n >= 50:
        p = hist.astype(np.float64) / n
        # bonus for residual matching a seen item size (clamped to residual range 0..100)
        r = np.clip(res, 0, 100)
        bonus = p[r] * (bins.astype(np.float64) > item)  # only for actual placements
        # cap bonus to a small fraction of the best-fit scale
        bonus = np.minimum(bonus, 2.0)
    else:
        bonus = np.zeros_like(bf)

    score = bf + bonus

    # Update histogram with current item (state for future calls)
    hist[item] += 1
    _state["n"] = n + 1

    return score
# EVOLVE-BLOCK-END
