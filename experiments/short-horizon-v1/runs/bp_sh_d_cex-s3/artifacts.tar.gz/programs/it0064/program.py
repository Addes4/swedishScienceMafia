# EVOLVE-BLOCK-START
"""Best-fit with a stateful tie-break that consumes unusable small residuals first."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        # running histogram of item sizes (sizes 1..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.min_seen = 101


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    Core: best-fit (smallest resulting residual). Ties broken toward the bin whose
    resulting residual is least likely to be usable by future items (i.e. smaller),
    so we don't strand many identical small shards.
    """
    global _state

    # update distribution state (ignored by ranking, used only to gauge shard usefulness)
    _state.n += 1
    if 1 <= item <= 100:
        _state.hist[item] += 1.0

    residual = bins - item  # resulting capacity if placed here

    # Primary: best-fit -> most negative residual (smallest remaining capacity).
    # Tiny secondary term: also prefer smaller residual on ties (dominated by primary,
    # but stays consistent and consumes small shards first).
    score = -residual.astype(np.float64)

    # Very small perturbation proportional to -residual keeps primary ordering and
    # breaks exact ties deterministically in favor of smaller residuals.
    score = score - 1e-6 * residual.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
