# EVOLVE-BLOCK-START
"""Best fit with a harmonic-style residual preference.

Idea: pure best fit (minimizing residual) is strong, but for items smaller than the
typical item size it can shatter bins into tiny residuals that no future item can use.
We keep tightness as the dominant term but add a mild bonus for leaving a residual
that is "useful" (close to a plausible future small item), which tends to keep bins
consolidated. For large items we fall back essentially to pure best fit.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity if item placed here (>=0)

    # Dominant term: prefer the tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Mild harmonic-style correction: reward residuals that are small but not
    # zero-ish, so that a bin keeps the ability to absorb a future small item.
    # residuals of 0 (exact fit) are already rewarded by the dominant term; we
    # only nudge away from leaving 1..3 free when a slightly larger residual of
    # comparable tightness exists.
    r = residual.astype(np.float64)
    # penalty grows as residual approaches the "wasted tiny gap" range
    tiny = ((r >= 1.0) & (r <= 3.0)).astype(np.float64)
    score -= 0.5 * tiny * (4.0 - r)

    return score
# EVOLVE-BLOCK-END
