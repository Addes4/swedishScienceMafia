# EVOLVE-BLOCK-START
"""Best-fit variant with Sum-of-Squares inspired residual targeting.

Items arrive online; we must rank the bins the item fits in. Pure best-fit (tightest
fit) is a strong baseline, but it can create awkward small residuals that waste space.
Here we keep best-fit as the dominant signal, but nudge the ranking so that placing an
item tends to leave "useful" residuals: either nearly perfect (0) or big enough to still
accept large future items. This is implemented cheaply with a small secondary term.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: prefer the tightest fit (best fit).
    primary = -residual.astype(np.float64)

    # Secondary: among similar fits, prefer residuals that are either very small
    # (near-perfectly filled bin) or comfortably large (still useful for big items).
    # A residual in the "dead zone" (small but not tiny) is penalized.
    # "Dead zone": 1..~30 can often not be filled well by future big items.
    dead = (residual > 0) & (residual < 30)
    secondary = np.where(dead, -0.5, 0.0)

    return primary + secondary
# EVOLVE-BLOCK-END
