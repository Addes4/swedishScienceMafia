# EVOLVE-BLOCK-START
"""Best fit with a mild anti-stranding nudge on near-ties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # remaining capacity after placing the item

    # Dominant term: best fit (smaller residual = fuller bin = higher score).
    score = -residual.astype(np.float64)

    # Mild nudge: residual of exactly 1 can never hold any future item, so it is
    # pure waste. Penalize creating it slightly. Keep the nudge small so it only
    # affects near-ties and never overrides a clearly better fit.
    stranded = residual == 1
    score[stranded] -= 0.5

    return score
# EVOLVE-BLOCK-END
