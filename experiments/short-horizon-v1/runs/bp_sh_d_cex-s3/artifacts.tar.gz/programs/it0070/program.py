# EVOLVE-BLOCK-START
"""Best-fit with a stateful histogram tie-break that avoids unusable residues."""
import numpy as np

# Running histogram of item sizes seen so far (index 1..100), plus total count.
_HIST = np.zeros(101, dtype=np.int64)
_COUNT = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _COUNT

    bins = np.asarray(bins)
    resid = bins - item  # resulting remaining capacity for each candidate bin

    # Update running histogram with the arriving item (state, current stream only).
    _HIST[item] += 1
    _COUNT += 1

    # Frequency-weighted preference for the resulting residue.
    # Perfect fit (residual 0) always desirable. Otherwise weight by how often
    # that exact size has appeared (so the gap can likely be filled exactly).
    freq = _HIST[resid] / float(_COUNT)
    bonus = np.where(resid == 0, 1.0, freq)

    # Primary key: best fit (smallest residual). Secondary: residue-fill bonus.
    # Encode so that best-fit dominates: lexicographic via large multiplier.
    return -resid * 1.0 + bonus * 0.0 - (1.0 - bonus) * 1e-3
# EVOLVE-BLOCK-END
