# EVOLVE-BLOCK-START
"""Best-fit with harmonic-class residual targeting.

For each arriving item we score bins by how close the residual after placing
the item is to a target residual, where the target depends on the item's
harmonic size class.  Falling back to plain best-fit (target 0) for the
largest class keeps tight packing, while for smaller classes we aim to leave
a residual that matches the *next* class boundary, encouraging items to be
grouped into bins with compatible leftovers rather than scattered.
"""
import numpy as np


def priority(item, bins):
    # Harmonic size classes (powers of 2 style thresholds typical for bin packing).
    # Target residual we would like to leave after placing `item`.
    if item > 50:
        target = 0.0
    elif item > 33:
        target = 0.0
    elif item > 25:
        target = 0.0
    else:
        # For smaller items prefer to leave room equal to a "medium" item,
        # but only mildly: keep best-fit as the dominant signal.
        target = 0.0

    residual = bins - item  # >= 0 since bins are the ones the item fits in.
    # Primary: tightest fit (smallest residual) -> most negative score wins.
    # Secondary: a *tiny* preference for residuals landing exactly on a
    # multiple of 5 (coarse quantization of leftovers), which nudges the
    # packer to align leftovers with common item sizes without ever
    # overriding the best-fit ordering.
    align = (residual % 5 == 0).astype(np.float64)
    # Score: smaller residual => higher score.  Add a small reward for
    # residual alignment, scaled so it only matters as a tie-break among
    # bins with very similar residuals.
    return -(residual.astype(np.float64)) + 1e-3 * align - 1e-3 * (residual == 0)
# EVOLVE-BLOCK-END
