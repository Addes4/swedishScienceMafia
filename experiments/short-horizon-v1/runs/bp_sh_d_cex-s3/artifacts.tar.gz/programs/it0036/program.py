# EVOLVE-BLOCK-START
"""Best-fit with exact-fill preference and residual-class consolidation."""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.int64), "n": 0}


def priority(item, bins):
    """Rank bins: strongly prefer exact fills, then best-fit, then common-residual fill."""
    # Update running item-size histogram
    _state["counts"][item] += 1
    _state["n"] += 1

    residual = bins - item  # >= 0 for shown bins

    # Base: best fit -> smallest residual
    score = -residual.astype(np.float64)

    # Bonus for exact fill (perfect packing)
    exact = (residual == 0)
    score[exact] += 1e6

    # Bonus for residual matching a frequently-seen item size
    counts = _state["counts"]
    freq = counts[residual]  # frequency of this residual value as an item size
    # only apply for positive residuals that are common items
    common = (residual > 0) & (freq > 0) & (freq >= max(1, _state["n"] // 200))
    score[common] += 1e3 * (freq[common].astype(np.float64) / max(1, _state["n"]))

    return score
# EVOLVE-BLOCK-END
