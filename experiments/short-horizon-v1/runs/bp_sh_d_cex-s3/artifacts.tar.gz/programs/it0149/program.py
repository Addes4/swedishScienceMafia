# EVOLVE-BLOCK-START
"""Distribution-aware best fit: keep residuals useful for the typical Weibull-sized item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item
    score = -residual.astype(np.float64)

    # For small items, avoid leaving residuals that are too small to be useful
    # for typical large items, but keep the effect bounded so best-fit dominates.
    if item < 40:
        # Graduated penalty peaking for tiny residuals, fading to zero at 25.
        gap = np.clip(25.0 - residual.astype(np.float64), 0.0, 25.0)
        score -= 0.05 * gap
    return score
# EVOLVE-BLOCK-END

