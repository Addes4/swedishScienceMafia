# EVOLVE-BLOCK-START
"""Best fit with a light future-fit preference on tie residuals."""
import numpy as np

_state = {"hist": None, "count": 0}

BINS = 101


def _hist():
    h = _state["hist"]
    if h is None:
        h = np.zeros(BINS, dtype=np.float64)
        _state["hist"] = h
    return h


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    h = _hist()
    # running histogram of past items (decayed lightly so recent items matter more)
    if _state["count"] > 0:
        h *= 0.999
    if 1 <= item <= 100:
        h[item] += 1.0
    _state["count"] += 1

    residual = bins - item  # >= 0 since bins only contains bins the item fits in

    # Primary: prefer smaller residual (best fit).
    score = -residual.astype(np.float64)

    # Small secondary bonus: a residual that matches a common recent item size is
    # slightly preferred, because it can be exactly filled next time.
    total = h.sum()
    if total > 0:
        freq = h[residual]
        score += (freq / total) * 1e-3

    return score
# EVOLVE-BLOCK-END
