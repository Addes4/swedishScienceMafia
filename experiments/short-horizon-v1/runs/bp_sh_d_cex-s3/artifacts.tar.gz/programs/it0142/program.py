# EVOLVE-BLOCK-START
"""Item-aware best fit: reward perfect fills and reusable gaps, penalize dead tiny gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)

    # For large items, standard best fit (pack as tightly as possible).
    if item >= 40:
        return -residual

    score = -residual
    # Strongly reward placements that fill the bin exactly.
    score[residual == 0] += 8.0
    # Reward leaving a gap that can still hold another item of this size.
    score[residual >= item] += 1.0
    # Penalize leaving a small gap that no similar-sized item can use.
    score[(residual >= 1) & (residual < item)] -= 1.0
    return score
# EVOLVE-BLOCK-END
