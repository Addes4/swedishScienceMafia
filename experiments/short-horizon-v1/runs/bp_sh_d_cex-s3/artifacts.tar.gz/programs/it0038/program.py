# EVOLVE-BLOCK-START
"""Best fit with a shard-consolidation nudge: prefer leaving residuals that match
small "fillable" sizes, breaking ties by tightness (best fit)."""
import numpy as np

# Residual sizes that are commonly produced by small items and thus likely fillable.
_FILLABLE = np.array([1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 15, 20], dtype=np.int64)


def priority(item, bins):
    """Priority for every fitting bin; highest score wins, ties to first bin."""
    residual = bins - item  # residual after placing; all >= 0 by construction
    # Base: best fit (smaller residual -> higher score).
    base = -residual.astype(np.float64)
    # Nudge: reward residuals that exactly match a small fillable size.
    hit = np.isin(residual, _FILLABLE).astype(np.float64)

    # Weight the nudge so it only overrides when base is nearly tied, so behavior
    # collapses to pure best-fit whenever there's a meaningfully tighter bin.
    nudge = hit * 0.5
    return base + nudge
# EVOLVE-BLOCK-END
