# EVOLVE-BLOCK-START
"""Best-fit with dominant exact-complement preference and tiny-shard penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacity of every fitting bin (incl. unused, =100), in order.
    """
    # Post-placement residual for each bin.
    residual = bins - item  # all >= 0 since these bins fit the item

    # Score: prefer smallest residual (tightest fit = best fit), but strongly
    # reward exact fills and mildly penalize creating tiny unusable shards.
    score = -residual.astype(np.float64)

    # Exact complement: residual_before == item, i.e. residual_after == 0.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Penalize leaving a small leftover that is unlikely to be reused well.
    # A leftover in 1..5 is often unusable; a leftover >= item-ish is fine.
    tiny = (residual > 0) & (residual < 10)
    score -= np.where(tiny, 5.0, 0.0)

    return score
# EVOLVE-BLOCK-END
