# EVOLVE-BLOCK-START
"""Best fit with a pairing bias toward residuals near the typical item size."""
import numpy as np


def priority(item, bins):
    """Rank bins; highest score wins (first on ties).

    Primary idea: best fit (smallest residual that still fits) is strong.
    Add a mild preference for bins whose post-placement residual is close to
    the distribution's typical item size (~40), which tends to pair items
    into well-filled bins and reduce wasted space.
    """
    residual = bins - item
    # Distance of the residual from the typical item size (~40).
    dist = np.abs(residual - 40)
    # Base: best fit (favor small residual). Weight large so it dominates ties.
    base = -residual.astype(np.float64)
    # Pairing bonus: smaller distance -> larger bonus.
    bonus = -0.5 * dist
    return base + bonus
# EVOLVE-BLOCK-END
