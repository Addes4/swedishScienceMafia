# EVOLVE-BLOCK-START
"""Hybrid: best-fit for large items, worst-fit into open bins for small items."""
import numpy as np

SMALL = 25.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    b = bins.astype(np.float64)
    if item <= SMALL:
        # Among bins that are already partially used, prefer the emptiest (largest residual)
        # so small items consolidate into shared leftovers instead of filling tight gaps.
        # Empty bins (residual 100) are treated as the least attractive.
        used = b < 100.0
        score = np.where(used, b, -1.0)
        return score
    # Best fit: minimize resulting residual.
    return -(b - item)
# EVOLVE-BLOCK-END
