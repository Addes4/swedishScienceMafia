# EVOLVE-BLOCK-START
"""Stateful best-fit that avoids tiny unusable shards and favors 'completable' residuals.

Idea: pure best-fit leaves many bins with residuals in (0, s_min) that no future item can
fill, wasting capacity. Track a running histogram of item sizes; when scoring a bin, compute
the residual that would remain after placing the item and:
  * strongly prefer exact fits (residual 0),
  * penalize residuals too small to ever be filled again (below the smallest observed size),
  * give a small bonus to residuals close to common item sizes (likely to be filled exactly).
For everything else, fall back to standard best-fit ordering so behavior is rarely worse.
"""
import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),
    "count": 0.0,
    "min_seen": 100,
}


def priority(item, bins):
    """Return one priority per bin; the item goes to the bin with the highest score."""
    st = _state
    # Update running distribution estimate.
    st["hist"][item] += 1.0
    st["count"] += 1.0
    if item < st["min_seen"]:
        st["min_seen"] = item

    n = st["count"]

    # Estimate how often each size occurs (probability of a usable item of size >= r).
    # Probability that a future item size is <= r or that some size <= r exists: we use
    # the fraction of observed items at or above each residual value.
    hist = st["hist"]
    # cumulative count of items >= r, computed for relevant r values
    # We compute, for each candidate residual r, an estimate of "chance r is fillable",
    # i.e. P(item == r) plus P(item slightly larger that leaves a small residual).
    total = n if n > 0 else 1.0

    # For each bin: resulting residual
    res = bins - item  # >= 0 since bins only contains fitting bins

    # Best-fit base: smaller residual is better (more tightly packed).
    # Use a strong linear term on -res so best-fit dominates ordering.
    score = -res.astype(np.float64)

    # Bonus for exact fill.
    score += (res == 0) * 100.0

    # Penalize unusable tiny residuals: residual >=1 but < smallest seen size can never be
    # filled by a future item (conservative: future min could be smaller, so mild penalty).
    tiny = (res > 0) & (res < st["min_seen"])
    score -= tiny * 2.0

    # Bonus for residuals that match a common item size (likely exact fill later).
    # Compute run-time frequency of each residual value among observed items.
    # freq[r] = count of items of size r observed (proxy for common sizes).
    # Scale modestly so it only breaks near-ties in the best-fit ordering.
    freq = hist[res.clip(0, 100)] / total  # includes res==0 handled above
    score += freq * 5.0

    return score
# EVOLVE-BLOCK-END
