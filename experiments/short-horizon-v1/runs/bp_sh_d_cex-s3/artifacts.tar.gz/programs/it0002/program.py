# EVOLVE-BLOCK-START
"""Best fit with a small penalty for leaving almost no residual capacity.

Items are placed by best fit: the bin whose remaining capacity after the item is smallest
(the tightest fit) wins.  However, leaving a residual of 1..3 units is nearly as bad as
leaving 0 for future packing, because only extremely small future items can use it, and such
bins become effectively dead.  We therefore add a small constant penalty to the score of
bins that would end up with a tiny residual, nudging the item into a slightly looser bin
that keeps a usable amount of free space.
"""
import numpy as np

# Residual capacities (after placing the item) that are considered too small to be useful.
_TINY = 3


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item            # remaining capacity after placing the item
    # Best fit: smaller residual -> higher score.
    score = -residual.astype(np.float64)
    # Penalize leaving a very small (but nonzero) residual.
    tiny = (residual > 0) & (residual <= _TINY)
    score -= tiny.astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END
