# EVOLVE-BLOCK-START
"""Best fit with exact-fit boost and per-bin age memory.

The item goes to the bin it fits most tightly (smallest residual). An exact fit
(residual 0) is strongly preferred because it closes a bin for free. Ties among
near-equal residuals are broken toward the bin whose current residual has been
"waiting" longest without being filled, which mildly encourages closing stale
gaps rather than opening new ones.
"""
import numpy as np

_state = {"ages": {}}


def priority(item, bins):
    # Large bonus for exact fits: residual 0 -> best possible outcome.
    residual = bins - item
    score = -(residual.astype(np.float64))

    # Exact fit boost.
    score = np.where(residual == 0, score + 1000.0, score)

    ages = _state["ages"]
    # Age bonus: bins that have been left at a residual for a while get a small
    # nudge to be filled now, helping consolidate stale gaps.
    for i in range(len(bins)):
        r = int(bins[i])
        if r == 100:
            continue
        a = ages.get(r, 0) + 1
        ages[r] = a
        if residual[i] == 0:
            ages[r] = 0
        # tiny bonus proportional to age, bounded
        score[i] += min(a, 20) * 0.01

    return score
# EVOLVE-BLOCK-END
