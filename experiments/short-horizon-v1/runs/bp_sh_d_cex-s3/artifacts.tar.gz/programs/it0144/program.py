# EVOLVE-BLOCK-START
"""Distribution-aware best fit: keep large residuals for large items (Weibull mean ~40)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # For large items, standard best fit (pack tightly).
    if item >= 35:
        return -residual.astype(np.float64)

    # Small item: favor bins with small residual (fuller bins get filled), but
    # strongly discourage creating tiny unusable residuals. The penalty is
    # graduated, largest for residual == 1, decaying to zero at residual == 15.
    score = -residual.astype(np.float64)
    awkward = (residual >= 1) & (residual <= 15)
    score[awkward] -= 2.0 * (16.0 - residual[awkward])
    return score
# EVOLVE-BLOCK-END
