# EVOLVE-BLOCK-START
"""Best fit with a tiny exact-completion bonus.

The baseline (tightest fit) is near-optimal on this distribution.  A small
stateful term encourages placing an item into a bin whose residual is exactly
the item size (a perfect completion), which cleanly closes bins without
changing the ordering in any other case.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    residual = bins - item            # leftover capacity if placed here
    # Base: strongly prefer the tightest fit (smallest residual => best fit).
    score = -residual.astype(np.float64)
    # Tiny bonus for an exact completion (residual == 0), i.e. bins - item == 0.
    score += 1e-6 * (bins == item)
    return score
# EVOLVE-BLOCK-END

