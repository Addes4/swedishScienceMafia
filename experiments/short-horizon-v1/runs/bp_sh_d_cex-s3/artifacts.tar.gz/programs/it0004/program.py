# EVOLVE-BLOCK-START
"""Best fit with least-full preference on exact fits, tiny index tie-break bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    # Primary: best fit -> smallest residual has highest score.
    score = -residual.astype(np.float64)
    # On exact fits (residual == 0), prefer the least-full (largest residual is 0, so prefer
    # the one that was least full before the item, i.e. largest bins).  Since residual==0
    # implies bins==item for all such, they're identical; instead disambiguate by index.
    # Tiny index bonus: earlier bins get a slight edge, reducing fragmentation spread.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    score = score - idx * 1e-6
    return score
# EVOLVE-BLOCK-END

