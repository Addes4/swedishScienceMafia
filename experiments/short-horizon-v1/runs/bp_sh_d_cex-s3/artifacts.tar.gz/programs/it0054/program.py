# EVOLVE-BLOCK-START
"""Best fit for large items; consolidate small items into fullest fitting bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item
    if item <= 50:
        # consolidate: prefer the fullest bin that fits (smallest residual after placing)
        return -residual
    # large items: standard best fit (tightest fit, i.e. smallest residual after placing)
    return -residual
# EVOLVE-BLOCK-END
