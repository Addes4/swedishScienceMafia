# EVOLVE-BLOCK-START
"""Best fit, with a capacity-aware tie-break: among bins that leave the same residual,
prefer the bin with the larger remaining capacity (and thus larger absolute slack)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual -> highest score).
    # Secondary (tie-break only): larger remaining capacity before placement.
    return -residual * 1024.0 + bins
# EVOLVE-BLOCK-END

