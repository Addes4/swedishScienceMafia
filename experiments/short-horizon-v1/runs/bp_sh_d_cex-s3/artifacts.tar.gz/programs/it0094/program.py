# EVOLVE-BLOCK-START
"""Best-fit augmented with a learned catalog of exactly-fillable residuals."""
import numpy as np

_good = np.zeros(101, dtype=np.float64)   # evidence that residual r is later filled exactly


def priority(item, bins):
    """Rank bins: prefer residuals that historically get matched by a future item."""
    # Learn: if this arriving item exactly equals a previously-leaving residual pattern,
    # reward the residual 'item' as fillable.
    _good[item] += 1.0

    residuals = bins - item
    bonus = _good[residuals]
    # small weight so best-fit remains dominant; bonus only breaks near-ties
    return bonus * 0.001 - residuals
# EVOLVE-BLOCK-END
