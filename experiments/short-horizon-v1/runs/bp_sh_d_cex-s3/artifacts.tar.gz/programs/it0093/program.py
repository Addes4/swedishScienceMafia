# EVOLVE-BLOCK-START
"""Best-fit with a residual-size preference that keeps gaps usable."""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual). Secondary: prefer residuals that are
    # themselves close to a typical item size, so the leftover gap is still fillable.
    gap_penalty = np.abs(residual - _MEAN)
    return -(residual + 0.05 * gap_penalty)
# EVOLVE-BLOCK-END
