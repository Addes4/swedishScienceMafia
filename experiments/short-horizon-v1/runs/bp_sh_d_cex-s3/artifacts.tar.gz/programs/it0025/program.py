# EVOLVE-BLOCK-START
"""Harmonic-class best-fit: aim post-placement residuals at 100/k boundaries."""
import numpy as np


# Target residuals at harmonic class boundaries (after placing the item).
_TARGETS = np.array([0.0, 100.0 / 6, 100.0 / 5, 100.0 / 4, 100.0 / 3,
                     100.0 / 2, 100.0], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins."""
    rem = bins.astype(np.float64)
    residual = rem - item  # >= 0 since only fitting bins are shown

    # Distance from residual to the nearest harmonic target residual.
    d = np.abs(residual[:, None] - _TARGETS[None, :]).min(axis=1)

    # Prefer small distance (close to a reusable class boundary),
    # then prefer fuller bins (smaller current remaining capacity).
    return -d - 1e-3 * rem
# EVOLVE-BLOCK-END
