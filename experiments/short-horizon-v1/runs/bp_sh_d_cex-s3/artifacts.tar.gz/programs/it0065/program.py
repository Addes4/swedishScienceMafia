# EVOLVE-BLOCK-START
"""Best fit with a stateful tie-break toward commonly fillable residuals."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_total = 0.0
_last_size = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _total, _last_size

    # Stateful histogram of past item sizes (with mild decay toward uniform).
    _counts *= 0.999
    _counts[item] += 1.0
    _total = _total * 0.999 + 1.0

    new_res = bins - item

    # Primary: best fit = smallest resulting residual.
    score = -new_res.astype(np.float64)

    # Tie-break bonus: reward resulting residuals that are common future item sizes,
    # so the leftover gap can be filled exactly later. Scale small enough to never
    # override the primary ordering (residuals are integers >= 0).
    # frequency weight in [0,1]
    freq = _counts[new_res.clip(0, 100)] / max(_total, 1.0)

    score += 0.5 * freq

    return score
# EVOLVE-BLOCK-END
