# EVOLVE-BLOCK-START
"""Best fit with a small-residual fragmentation penalty.

Items arrive online.  Pure best fit packs tightly but tends to leave tiny
residuals in many bins, which then cannot hold the small items the Weibull
distribution keeps producing.  We rank by best fit, but add a mild bonus for
bins whose post-placement residual is large enough to still be "useful"
(i.e. at least a small threshold), so the rule does not systematically create
unusable slivers.
"""
import numpy as np

THRESHOLD = 8.0   # residuals below this are treated as near-useless slivers
BONUS = 2.0       # how strongly we prefer a residual above the threshold


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item
    score = -residual.astype(np.float64)
    # Mildly penalize residuals in (0, THRESHOLD) so bins keep absorbing power.
    sliver = (residual > 0) & (residual < THRESHOLD)
    score += np.where(sliver, -BONUS, 0.0)
    return score
# EVOLVE-BLOCK-END

