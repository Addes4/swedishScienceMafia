# EVOLVE-BLOCK-START
"""Best-fit variant: combine tight-fit residual with a small anti-shard preference."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties).

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (fitting bins only).
    """
    residual = bins - item
    # Base: prefer small residual (best fit).
    base = -residual.astype(np.float64)
    # Anti-shard: mildly penalize residuals that are very small but nonzero,
    # since those shards are often unusable; prefer exact fits (residual 0).
    shard_pen = np.where((residual > 0) & (residual < 8), -0.5, 0.0)
    # Secondary: slight preference for fuller bins (smaller capacity) to
    # consolidate load, weighted weakly so best-fit still dominates.
    consolidate = -0.01 * bins.astype(np.float64)
    return base + shard_pen + consolidate
# EVOLVE-BLOCK-END

