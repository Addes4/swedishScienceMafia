# EVOLVE-BLOCK-START
"""Best fit with a mild fullness tiebreak.

Primary: minimize the residual left after placing the item (classic best fit).
Tiebreak: among near-equal residuals, prefer the bin that is already fuller
(smaller remaining capacity before placement), which consolidates packing and
reduces scattering of usable space.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary key: best fit (smaller residual better) -> negative residual.
    # Tiny secondary term: prefer fuller bins (smaller current capacity).
    return -residual * 1000.0 - bins
# EVOLVE-BLOCK-END

