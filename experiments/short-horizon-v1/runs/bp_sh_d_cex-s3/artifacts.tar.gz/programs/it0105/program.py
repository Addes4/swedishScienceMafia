# EVOLVE-BLOCK-START
"""Harmonic-style bin choice.

Classify each arriving item by its size class, then for each class assign it to the
bin whose remaining capacity falls in the "target residual" interval for that class
(variants of the classic Harmonic / Harmonic++ family).  Within the selected
interval we pick the tightest fit (best-fit), and we slightly prefer already-used
bins over unused ones so we do not open new bins prematurely.
"""
import numpy as np

# Harmonic boundaries: classes for item/capacity ratio.
# Sizes 1..100 -> ratios.  Use the classical harmonic split with m = 10:
# three special intervals plus 1/(k+1) < s <= 1/k for k = m..2.
_BOUNDS = []  # list of (low, high) inclusive in item units, per class
# Build classes by integer item sizes 1..100
# floors for k: item <= 100/k
_classes = []
for k in range(10, 1, -1):
    hi = 100 // k          # largest item with item <= 100/k
    lo = 100 // (k + 1) + 1  # smallest item with item > 100/(k+1)
    if hi >= lo:
        _classes.append((lo, hi, k))
# small items: item <= 100/10 = 10 -> remaining classes {1/3,1/2,1} style
# We'll treat 1..100//11 as the smallest class
_small_hi = 100 // 11  # ~9
if _small_hi >= 1:
    _classes.append((1, _small_hi, 11))
# medium / large special classes: (1/4,1/2] and (1/2,1]
_medium = (100 // 4 + 1, 100 // 2)     # 26..50
_large = (100 // 2 + 1, 100)           # 51..100
_medium_lo, _medium_hi = _medium
_large_lo, _large_hi = _large
_small_lo, _small_hi = 1, _small_hi
_mid_lo, _mid_hi = _small_hi + 1, 100 // 4   # 10..25


def _class_of(item):
    if item >= _large_lo:
        return 'large'
    if item >= _medium_lo:
        return 'medium'
    if item <= _small_hi:
        return 'small'
    return 'mid'


def priority(item, bins):
    cls = _class_of(item)
    # target residual intervals
    if cls == 'large':
        # want residual in [0, 100 - item] but effectively tight best-fit
        return -(bins - item)
    if cls == 'medium':
        # item in (1/4, 1/2]; want a residual that is itself smallish (<= item)
        # prefer bins whose residual is in [item, 2*item] range but tight
        target_lo = item
        target_hi = 2 * item
        # bins here have residual >= item (they fit).  Score: in-band best fit first.
        inband = (bins >= target_lo) & (bins <= target_hi)
        # best fit inside band: closer to item is better; outside band: fall back to best fit
        score = np.where(inband, 200 - (bins - item), -(bins - item))
        return score.astype(np.float64)
    if cls == 'mid':
        # item in (1/10, 1/4]; want residual comparable: prefer ~ [item, 3*item]
        target_lo = item
        target_hi = 3 * item
        inband = (bins >= target_lo) & (bins <= target_hi)
        score = np.where(inband, 200 - (bins - item), -(bins - item))
        return score.astype(np.float64)
    # small: item <= ~9; prefer near-empty bins so small items do not fragment
    # best-fit among non-full, but with a mild preference for larger residual
    return bins.astype(np.float64)
# EVOLVE-BLOCK-END
