# EVOLVE-BLOCK-START
"""Best fit, but delay opening fresh bins for small/medium items."""
import numpy as np


def priority(item, bins):
    """Rank bins: best-fit among used bins; defer opening empty bins for small items."""
    residual = bins - item  # lower (more negative) = tighter fit = better
    # bins with remaining capacity 100 are unused; identify them.
    empty = (bins == 100)
    if item >= 50:
        # large items: pure best fit (treat empty bins normally)
        return -residual
    # small/medium items: push empty bins to the back, keep best-fit for used bins.
    score = -residual.astype(np.float64)
    score = np.where(empty, score - 1000.0, score)
    return score
# EVOLVE-BLOCK-END
