# EVOLVE-BLOCK-START
"""Best fit with a mild small-item residual penalty to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: pure best fit (tightest residual first)
    score = -residual.astype(np.float64)
    # For small items, slightly discourage leaving a tiny residual (0..3),
    # so we don't waste a nearly-full bin's ability to absorb a future small item.
    if item <= 60:
        tiny = (residual >= 0) & (residual <= 3)
        score += tiny.astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END
