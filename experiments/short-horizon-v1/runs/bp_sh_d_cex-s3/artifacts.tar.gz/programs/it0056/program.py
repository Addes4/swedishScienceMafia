# EVOLVE-BLOCK-START
"""Best-fit with a shard penalty informed by the running item-size distribution."""
import numpy as np


def priority(item, bins):
    """Return a priority per bin; highest wins (first on ties).

    item: integer size of arriving item, 1..100.
    bins: numpy int64 remaining capacities of fitting bins, in bin order.
    """
    residual = bins - item  # leftover if item placed in each bin (>= 0)

    # Stateful estimate of small usable item sizes seen so far.
    global _min_seen
    try:
        _min_seen
    except NameError:
        _min_seen = 100
    if item < _min_seen:
        _min_seen = item

    # Base: tightest fit (best-fit) -> most negative for fullest fitting bin.
    score = -residual.astype(np.float64)

    # Penalize leaving a shard smaller than the smallest item seen so far,
    # since such leftovers are hard to reuse. Exact fits (residual 0) are best.
    shard = residual < _min_seen
    score[shard & (residual > 0)] -= 1000.0

    return score
# EVOLVE-BLOCK-END
