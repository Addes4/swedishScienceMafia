# EVOLVE-BLOCK-START
"""Best-fit primary, with a small exact-fill / residual-targeting bonus.

Primary key is best-fit (smallest residual after placement). Among near-ties
(residuals within a small window), prefer residuals that are likely to be
filled exactly by a future item, approximated by a fixed set of common target
residuals derived from the Weibull-like distribution (mean size ~40).
Bins are all fitting, unused bins have residual 100.
"""
import numpy as np

# Target residuals: values a future item is reasonably likely to take,
# weighted a bit more near the mode of the size distribution.
_TARGETS = np.array([1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25, 30, 40, 50],
                    dtype=np.float64)
# Weight targets lightly so best-fit still dominates; window in residual units.
_WINDOW = 6.0


def priority(item, bins):
    residual = bins - item          # remaining capacity if placed here
    # Best-fit primary: smaller residual is better.
    base = -residual.astype(np.float64)
    # Bonus: how close the residual is to a likely future item size.
    d = np.abs(residual[:, None].astype(np.float64) - _TARGETS[None, :])
    nearest = d.min(axis=1)
    bonus = np.maximum(0.0, _WINDOW - nearest)
    # Only matters among near-best-fit residuals; keep magnitude small.
    return base + 0.05 * bonus
# EVOLVE-BLOCK-END
