# EVOLVE-BLOCK-START
"""Best fit, with a residual-aware tweak for small items to reduce waste."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item
    score = -residual.astype(np.float64)

    if item <= 25:
        # For small items, mildly penalize residuals in the 1..3 range so we don't
        # strand a bin with a sliver of capacity that nothing can use.
        small = (residual >= 1) & (residual <= 3)
        score -= small * 0.5
    return score
# EVOLVE-BLOCK-END
