# EVOLVE-BLOCK-START
"""Best fit with a tiny, safe histogram-based tie-break."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)
    residual = bins - item  # >= 0 for fitting bins

    # Update running histogram with incrementally decayed counts.
    _state.count += 1.0
    _state.hist *= 0.999
    _state.hist[item] += 1.0

    # Best-fit base score: smaller residual -> higher score.
    score = -residual.astype(np.float64)

    # Tiny tie-break bonus proportional to how "common" the resulting residual is
    # as a future item size. Kept << 1 so it only breaks ties in best-fit residual.
    total = _state.hist.sum()
    if total > 0.0:
        freq = _state.hist / total
        # residual may exceed 100 (unused bins have residual 100-item <= 99); clamp.
        idx = np.clip(residual, 0, 100)
        bonus = freq[idx]
        score = score + 1e-6 * bonus

    return score
# EVOLVE-BLOCK-END
