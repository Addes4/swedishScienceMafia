# EVOLVE-BLOCK-START
"""Best-fit with a capped tie-break that closes nearly-full bins fast.

Items are Weibull-shaped (mean ~40) with a heavy tail of large items.  Pure
best-fit leaves many bins with a small residual that no item can fit into,
while large items then still need fresh bins.  We keep best-fit as the
primary criterion (so packing stays tight) but add a small, bounded bonus
toward bins whose residual after placement is *very small*, which drains
fragmented bins quickly and leaves big empty bins for the heavy tail.
The bonus is small enough that best-fit still decides between comparable
candidates, so behaviour never degrades far from best-fit.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Residual capacity left in each bin after placing the item.
    residual = bins - item  # always >= 0 here

    # Primary: best-fit  -> smaller residual is better.
    primary = -residual.astype(np.float64)

    # Secondary bonus: reward residuals that are almost closed off (tiny or
    # zero), slightly preferring bins that become unusable for future items.
    # Normalised to lie in [0, 0.5] so it can never override best-fit.
    bonus = 0.5 * (1.0 - residual / 100.0)

    return primary + bonus
# EVOLVE-BLOCK-END
