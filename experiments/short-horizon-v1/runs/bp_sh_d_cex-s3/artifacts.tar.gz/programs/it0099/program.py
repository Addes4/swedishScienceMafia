# EVOLVE-BLOCK-START
"""Best fit, with a strong exact-fit bonus (stateful-safe, myopic)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: prefer the smallest residual (tightest fit).
    # Add a large bonus for exact fits so an available exact match is always chosen.
    return -residual + 1e6 * (residual == 0)
# EVOLVE-BLOCK-END
