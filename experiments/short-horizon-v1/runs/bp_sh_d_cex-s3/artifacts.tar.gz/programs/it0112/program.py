# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware exact-fill tie-break."""
import numpy as np

# State kept between calls within a stream.
_hist = np.zeros(101, dtype=np.float64)
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    _count += 1
    _hist[item] += 1.0
    if _count % 64 == 0:
        _hist *= 0.98

    residual = bins - item  # remaining capacity after placing the item

    # Primary: best fit -> smaller residual gets higher score.
    score = -residual.astype(np.float64)

    # Tie-break: favor residuals that match a frequently observed item size,
    # so the bin can be closed afterwards by a near-certain future item.
    total = _hist.sum()
    if total > 0:
        freq = _hist / total
        r = np.clip(residual, 0, 100)
        bonus = freq[r]
        score = score - 1e-3 * bonus

    return score
# EVOLVE-BLOCK-END
