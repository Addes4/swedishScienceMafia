# EVOLVE-BLOCK-START
"""Stateful best-fit variant: learn which residuals tend to get filled well.

The rule still relies mainly on the classic best-fit signal (prefer the
smallest sufficient bin, i.e. smallest residual), but adds a small learned
correction.  We keep an online estimate, per residual bucket, of how often
that residual has historically been "reusable" — meaning some later arriving
item exactly (or nearly) matched it and was placed there.  Residuals that are
frequently filled later are slightly preferred.
"""
import numpy as np


class _State:
    def __init__(self):
        # residual capacity -> count of times observed after a placement
        self.seen = np.zeros(101, dtype=np.float64)
        # residual capacity -> count of times a later item matched it well
        self.good = np.zeros(101, dtype=np.float64)
        self.prev_residual = None
        self.prev_item = None


_s = _State()


def _observe_prev(item, bins):
    """Update statistics for the placement made on the previous call."""
    st = _s
    if st.prev_residual is not None:
        r = st.prev_residual
        st.seen[r] += 1.0
        # Did the current item fit the residual we created last time?
        # If the previous placement left residual r and now an item of size
        # exactly r arrives, that residual was perfectly reusable.
        if item == r:
            st.good[r] += 1.0
        # Also count near-matches as partially good.
        elif item < r and r - item <= 2:
            st.good[r] += 0.5
    st.prev_item = item


def priority(item, bins):
    st = _s
    _observe_prev(item, bins)

    residual = bins - item  # capacity left after placing the item here
    score = -residual.astype(np.float64)  # primary: best fit

    # Secondary learned bonus: prefer residuals that have often been reused.
    p = (st.good + 1.0) / (st.seen + 2.0)
    bonus = p[residual] * 0.35
    score = score + bonus

    # Record the residual that *this* choice will create, so the next call
    # can credit or debit it.  We do not know which bin will be chosen by the
    # harness, so use the bin our own score picks (best match to harness).
    best = int(np.argmax(score))
    st.prev_residual = int(residual[best])

    return score
# EVOLVE-BLOCK-END
