# EVOLVE-BLOCK-START
"""Best-fit with a leftover-shard guard: pack tightly but avoid creating tiny unusable gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, first on ties.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item
    # Bins where the leftover is "useful" (>= half the item size) are preferred.
    useful = residual * 2 >= item
    # Among useful bins: prefer tightest fit (smallest residual) -> negative residual.
    # Among non-useful bins: still prefer tightest fit but rank them below all useful ones.
    return np.where(useful, -residual, -residual - 1000.0)
# EVOLVE-BLOCK-END

