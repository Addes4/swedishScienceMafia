# EVOLVE-BLOCK-START
"""First-fit style ranking: prefer low-index (earlier, already-used) bins that fit."""
import numpy as np


def priority(item, bins):
    """Highest priority to the earliest bin that fits; ties broken by tightest fit.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of bins the item fits in.
    """
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    # Strongly prefer lower index (first-fit). Slight tightness bonus as tiebreak.
    return -idx * 1000.0 - (bins - item)
# EVOLVE-BLOCK-END
