# EVOLVE-BLOCK-START
"""Best-fit backbone plus a bounded, distribution-aware residual bonus.

The item goes into the fitting bin whose residual after placement is closest to
the most common residual sizes observed so far (so it is likely to be closed by a
future item), with a mild preference for fresh bins for the heavy tail of large
items.  The bonus is capped so best-fit behaviour dominates.
"""
import numpy as np

_CAP = 100
_state = {"hist": np.zeros(_CAP + 1, dtype=np.float64), "n": 0}


def priority(item, bins):
    hist = _state["hist"]
    n = _state["n"]

    rem = bins - item                     # residual after placing the item (>= 0)

    # Best-fit backbone: tighter residuals score higher.
    score = -rem.astype(np.float64)

    if n >= 50:
        # Distribution-aware bonus: prefer residuals that are common item sizes,
        # so the leftover space is likely to be filled exactly later.
        freq = hist / n
        bonus = freq[rem]                 # 0..1, how common this residual is
        # small fresh-bin bonus if item is large (are rare but costly)
        if item >= 50:
            bonus = bonus + 0.15 * (bins == _CAP)
        score = score + 2.0 * bonus

    return score


def _observe(item):
    _state["hist"][item] += 1.0
    _state["n"] += 1
