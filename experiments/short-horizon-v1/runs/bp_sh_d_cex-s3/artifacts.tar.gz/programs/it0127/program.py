# EVOLVE-BLOCK-START
"""Distribution-aware best fit using an online item-size histogram to judge residuals."""
import numpy as np

_CAP = 100.0
# Running histogram of seen item sizes (1..100), used to estimate how usable a
# given residual is for a future item.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    global _COUNT
    # Update the online distribution estimate.
    _HIST[item] += 1.0
    _COUNT += 1.0

    residual = bins - item  # remaining capacity after placing the item

    # Score is dominated by best-fit (prefer small residual => tight packing).
    score = -residual.astype(np.float64)

    # Estimate usefulness of each created residual: probability that some future
    # item can fit exactly or nearly exactly (residual is near an item size).
    # Use a smoothed probability mass over item sizes seen so far.
    if _COUNT >= 8.0:
        prob = _HIST / _COUNT
        # For each unique residual value, compute a usability proxy: the max
        # probability mass in a small window around that residual.
        res = residual
        usable = np.zeros_like(score)
        # window of +/- 1 around residual size
        for d in (-1, 0, 1):
            idx = res + d
            valid = (idx >= 1) & (idx <= 100)
            contrib = np.zeros_like(score)
            contrib[valid] = prob[idx[valid]]
            usable = np.maximum(usable, contrib)
        # Small bonus: prefer residuals that future items are likely to fill.
        score += 0.5 * usable

    return score
# EVOLVE-BLOCK-END
