# EVOLVE-BLOCK-START
"""Best fit, with a bias toward leaving a residual that matches a seen item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # score: primary is tightest fit (-residual); add a small bonus if the
    # resulting residual equals an item size we have already seen, which makes
    # a later exact fill possible.
    score = -residual.astype(np.float64)

    # small deterministic bonus for "useful" residuals (never overrides tightness
    # ordering because magnitude < 1)
    seen = _seen_sizes
    if seen:
        mask = np.isin(residual, seen)
        score = score + 0.5 * mask.astype(np.float64)

    return score


# module-level state used across calls within a stream
_seen_sizes = []
_seen_set = set()


def _observe(item):
    if item not in _seen_set:
        _seen_set.add(item)
        _seen_sizes.append(int(item))


# hook: observe every item when priority is first called for it
_orig_priority = priority


def priority(item, bins):  # noqa: F811
    _observe(int(item))
    return _orig_priority(item, bins)
# EVOLVE-BLOCK-END
