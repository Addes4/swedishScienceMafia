# EVOLVE-BLOCK-START
"""Best fit with exact-fit preference and residual-size density bonus."""
import numpy as np


def priority(item, bins):
    """Score each bin: primary is best fit, with a large bonus for perfect/near-perfect fit."""
    residual = bins - item
    # Primary: best fit (smaller residual preferred)
    score = -residual.astype(np.float64)
    # Large bonus when placement fills the bin exactly or nearly
    score += 1000.0 * (residual == 0)
    score += 100.0 * (residual == 1)
    # Small density-based bonus for residuals that are likely future item sizes (mean ~40)
    # peak near 40, decay away
    score += 0.5 * np.exp(-((residual - 40.0) ** 2) / (2.0 * 20.0 ** 2))
    return score
# EVOLVE-BLOCK-END
