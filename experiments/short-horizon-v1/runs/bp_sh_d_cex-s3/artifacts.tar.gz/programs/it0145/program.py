# EVOLVE-BLOCK-START
"""Best fit with perfect-fit and reusable-residual tie-breaking (Weibull mean ~40)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Dominant term: best fit (prefer smallest residual).
    score = -residual.astype(np.float64)

    # Small bonus for a perfect fit (residual exactly 0).
    score[residual == 0] += 0.5

    # Nudge away from awkward tiny residuals (1..item-1) that cannot hold
    # another item of the same size; a small graduated penalty peaking at 1.
    awkward = (residual >= 1) & (residual < item)
    score[awkward] -= 0.25

    return score
# EVOLVE-BLOCK-END

