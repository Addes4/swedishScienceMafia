# EVOLVE-BLOCK-START
"""Distribution-aware best fit with awkward-residual avoidance."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Base: prefer tight fits (best fit) so bins are filled and big bins stay free
    # for large future items.
    score = -residual.astype(np.float64)

    # Penalize creating residuals that are too small to hold typical items but
    # too large to be "efficiently" closed: this leftover gap wastes capacity.
    awkward = (residual >= 1) & (residual <= 14)
    score[awkward] -= 2.0

    return score
# EVOLVE-BLOCK-END
