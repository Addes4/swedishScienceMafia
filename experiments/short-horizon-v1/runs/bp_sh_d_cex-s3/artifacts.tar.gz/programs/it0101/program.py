# EVOLVE-BLOCK-START
"""Harmonic-like scale-invariant best fit.

Classic fixed-interval / harmonic online bin packing splits items into size
classes and uses a class-specific bin rule.  A lightweight continuous version
is to prefer the bin whose residual is closest (in a scale-invariant sense) to
the item, i.e. minimise residual/item, but only among bins whose residual is
itself not "too large" for the item's class.  This behaves like best fit for
most items but avoids wasting near-empty bins on tiny items.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    # Scale-invariant tightness: small residual relative to the item is good.
    # Sort by the ratio residual / item; add a tiny absolute tie-break toward
    # the smallest residual (true best fit).
    ratio = bins.astype(np.float64) / float(item)
    return -(ratio) - 1e-6 * bins
# EVOLVE-BLOCK-END
