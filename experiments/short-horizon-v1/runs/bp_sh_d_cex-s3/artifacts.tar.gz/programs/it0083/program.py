# EVOLVE-BLOCK-START
"""Hybrid: exact-fit priority plus histogram-aware residual shaping over best-fit."""
import numpy as np

# state kept across calls within a stream
_hist = np.zeros(101, dtype=np.int64)
_total = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _total
    _hist[item] += 1
    _total += 1

    residual = bins - item  # >= 0 by contract

    # exact fill gets a strong boost
    score = -residual.astype(np.float64)

    # histogram-aware bonus: prefer residuals that are themselves likely future items
    if _total > 20:
        probs = _hist / float(_total)
        bonus = probs[residual]
        score = score + 5.0 * bonus

    return score
# EVOLVE-BLOCK-END
