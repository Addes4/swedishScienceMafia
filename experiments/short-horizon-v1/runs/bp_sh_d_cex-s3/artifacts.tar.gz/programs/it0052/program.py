# EVOLVE-BLOCK-START
"""Best fit with a shard-avoidance penalty driven by the observed item-size distribution."""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.int64), "n": 0}


def priority(item, bins):
    """Rank bins: prefer tight fits, but penalize leftovers smaller than a typical future item."""
    counts = _state["counts"]
    n = _state["n"]

    # Estimate the smallest item size that is reasonably likely to appear soon.
    if n >= 20:
        # Smallest size s such that roughly 5% of observed items are <= s.
        cum = np.cumsum(counts)
        target = 0.05 * n
        small = int(np.searchsorted(cum, target) + 1)
    else:
        small = 1
    small = max(1, min(small, 100))

    residual = bins - item  # remaining capacity after placing item

    # Base: best fit (prefer smallest resulting residual).
    score = -residual.astype(np.float64)

    # Penalize bins that would leave a leftover too small to be useful later,
    # but only if that leftover is nonzero (a clean 0 fill is good).
    bad = (residual > 0) & (residual < small)
    score[bad] -= 1000.0

    # Update the observed size histogram (state persists within a stream).
    counts[item] += 1
    _state["n"] = n + 1

    return score
# EVOLVE-BLOCK-END
