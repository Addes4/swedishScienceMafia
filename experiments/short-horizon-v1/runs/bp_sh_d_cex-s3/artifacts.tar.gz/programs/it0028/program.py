# EVOLVE-BLOCK-START
"""Best fit with a deterministic fuller-bin tie-break on exactly equal residuals.

Primary criterion: smallest post-placement residual (best fit). Secondary: among bins with
the same residual, prefer the one that is currently fullest (smallest remaining capacity),
which consolidates packing deterministically. Since the secondary term is scaled by an
epsilon far smaller than 1, it can never override a strictly better best-fit choice.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Dominant term: prefer smaller residual. Tie-break term: prefer fuller bin (smaller bins).
    return -residual.astype(np.float64) - 1e-9 * bins.astype(np.float64)
# EVOLVE-BLOCK-END
