# EVOLVE-BLOCK-START
"""Best fit with a tie-break preferring the fuller residual origin.

Put the item in the bin whose remaining capacity after placement is smallest.
Among bins producing the same resulting residual, prefer the bin that currently
has the larger remaining capacity (the one that was less full before placing),
which corresponds to classic best-fit's choice and avoids piling onto nearly
full bins when the resulting residual is identical.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smallest residual after placing (best fit).
    # Tie-break: larger current residual (less full bin) chosen first, so that
    # equal-residual bins are consumed in a consistent, low-fragmentation order.
    return -residual * 1000 + bins
# EVOLVE-BLOCK-END
