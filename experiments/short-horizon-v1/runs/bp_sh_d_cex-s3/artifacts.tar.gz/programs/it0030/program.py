# EVOLVE-BLOCK-START
"""Best-fit with a residual-window bias toward reusable holes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # For very large items just use best fit (residual minimized).
    if item >= 60:
        return -residual
    # For smaller items, prefer bins leaving a residual near a target window
    # so leftover gaps stay similar in size and remain reusable.
    target = 30
    return -np.abs(residual - target)
# EVOLVE-BLOCK-END

