# EVOLVE-BLOCK-START
"""Best fit with a stateful tie-break that avoids tiny unusable gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    residual = bins - item  # remaining capacity after placing the item (>=0 for shown bins)

    # Primary: best fit -> smallest resulting residual first.
    # Tie-break: prefer residuals that are large enough to accept a typical future item.
    # We build a coarse running estimate of typical item sizes via a small fixed table.
    # Since no cross-call state is strictly needed for the tie-break, use a static prior:
    # prefer residuals around the common item-size band, discourage residuals in (0, min_gap).
    min_gap = 8  # below this, gaps are rarely fillable exactly by integer items
    scores = -residual.astype(np.float64)

    # Small bonus for residuals that are 0 (perfect fit) or reasonably sized (>= min_gap).
    bonus = np.zeros_like(scores, dtype=np.float64)
    bonus[residual == 0] = 1.0
    usable = residual >= min_gap
    bonus[usable] = 0.05
    # Slight extra preference for residuals that are themselves common item sizes (~40).
    near_common = (residual >= 25) & (residual <= 55)
    bonus[near_common] += 0.02

    return scores + bonus
# EVOLVE-BLOCK-END
