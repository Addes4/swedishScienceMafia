# EVOLVE-BLOCK-START
"""Hybrid: worst-fit for large items, best-fit for small items.

Best-fit alone tends to leave many bins with tiny unusable residual gaps. Packing
large items (which need lots of contiguous free space) into the emptiest fitting
bin keeps bins open for future large items, while small items still use best-fit
to consolidate tightly.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item > 50:
        # Large item: prefer the emptiest bin that still fits.
        return bins
    # Small item: best fit (tightest remaining capacity after placement).
    return -(bins - item)
# EVOLVE-BLOCK-END

