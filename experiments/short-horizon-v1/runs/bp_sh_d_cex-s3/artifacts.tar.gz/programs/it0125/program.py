# EVOLVE-BLOCK-START
"""Distribution-aware best fit: pack tightly, but avoid stranding tiny slugs."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Base: pure best fit (prefer smallest residual -> tightest packing).
    score = -residual.astype(np.float64)

    # Avoid stranding tiny unusable slugs: if placing the item leaves a small
    # leftover (too small to be useful for typical future items) while some
    # other bin would leave a comfortable residual, nudge away from the slug.
    # Threshold scales mildly with item size so large items don't over-penalize.
    slug_hi = 1 + (item // 4)  # 1..25 for item 1..100
    if slug_hi > 1:
        awkward = (residual >= 1) & (residual <= slug_hi)
        score[awkward] -= 1.5
    return score
# EVOLVE-BLOCK-END

