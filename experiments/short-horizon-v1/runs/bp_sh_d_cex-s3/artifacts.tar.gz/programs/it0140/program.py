# EVOLVE-BLOCK-START
"""Best-fit with a light guard against stranding tiny unusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in,
          including unused bins (capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Always prefer best fit (small residual): pack bins tightly.
    score = -residual.astype(np.float64)

    # For small items, a residual in [0, item-1] is too small to fit another
    # item of this size, so it may become permanently stranded. Nudge such
    # choices down a bit so we keep reusable gaps for future items.
    if item < 40:
        stranded = (residual >= 0) & (residual < item)
        score[stranded] -= 1.0

    return score
# EVOLVE-BLOCK-END
