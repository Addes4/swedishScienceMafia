# EVOLVE-BLOCK-START
"""Best fit, with a stateful shard-filling bonus for small items.

Pure best fit creates tiny unusable leftovers ("shards"). When a small item
arrives, we prefer the bin whose leftover it can exactly consume, or otherwise
the fullest such shard, so those gaps get reused instead of being stranded.
For larger items we keep strict best fit (the behavior the short-stream
instances liked).  A running mean item size decides which regime we are in.
"""
import numpy as np


class _State:
    total = 0.0
    count = 0
    mean = 40.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = _state
    s.total += item
    s.count += 1
    s.mean = s.total / s.count

    residual = bins - item  # >= 0 for all shown bins

    # Strict best fit: smallest residual wins.
    score = -residual.astype(np.float64)

    if item <= s.mean:
        # Small item: gently prefer bins where the leftover is fully consumed,
        # otherwise the fullest remaining shard.  Keep it a small bonus so that
        # best fit still dominates except among nearly tied residuals.
        full_bonus = (residual == 0).astype(np.float64) * 2.0
        shard_bonus = -residual.astype(np.float64) * 0.01
        score = score + full_bonus + shard_bonus

    return score
# EVOLVE-BLOCK-END
