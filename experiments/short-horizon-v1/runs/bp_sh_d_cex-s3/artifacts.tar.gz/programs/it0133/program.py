# EVOLVE-BLOCK-START
"""Distribution-aware best fit that avoids stranding unusable tiny residuals."""
import numpy as np

# Module-level running histogram of observed item sizes (shared across a stream;
# reset implicitly because a stream is independent but state accumulates gently).
_SIZES = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def _reset_if_needed():
    global _SIZES, _COUNT
    if _COUNT == 0.0:
        _SIZES = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest score.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    global _SIZES, _COUNT

    # Record observed item (state persists within a stream).
    _SIZES[item] += 1.0
    _COUNT += 1.0

    residual = bins - item

    # Estimate a "usable" threshold: the smallest size that future items will
    # likely need. Use a low quantile of the observed item distribution so we
    # avoid stranding gaps that no future item can fill.
    if _COUNT >= 5.0:
        cdf = np.cumsum(_SIZES) / _COUNT
        # smallest size s such that P(item <= s) >= 0.15
        idx = int(np.searchsorted(cdf, 0.15))
        idx = max(1, min(100, idx))
        usable_min = idx
    else:
        usable_min = 5

    score = -residual.astype(np.float64)

    # Penalize residuals that are positive but too small to be visibly reusable.
    stranded = (residual >= 1) & (residual < usable_min)
    score[stranded] -= 3.0

    return score
# EVOLVE-BLOCK-END
