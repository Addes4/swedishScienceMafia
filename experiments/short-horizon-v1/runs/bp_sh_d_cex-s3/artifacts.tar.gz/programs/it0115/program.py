# EVOLVE-BLOCK-START
"""Randomized best-fit / first-fit hybrid: mostly best fit, but sometimes prefer the fullest bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Deterministic pseudo-random choice based on item size and number of bins seen so far.
    # This gives a stable but varied policy across streams without external state.
    h = (item * 2654435761 + bins.size * 40503) & 0xFFFFFFFF
    if (h % 100) < 20:
        # 20% of the time: put into the fullest bin that still fits (smallest remaining cap),
        # which tends to close off nearly full bins.
        return -bins
    # Otherwise: classic best fit (tightest fit).
    return -(bins - item)
# EVOLVE-BLOCK-END
