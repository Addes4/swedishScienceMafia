# EVOLVE-BLOCK-START
"""Distribution-aware bin choice: best fit for big items, reserve bands for small ones."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Large items: pure best fit (tight packing).
    if item >= 50:
        return -residual.astype(np.float64)

    score = -residual.astype(np.float64)

    # For small/mid items, prefer to leave residuals just under typical large
    # item sizes so those bins are effectively "closed" to large items but
    # still usable by other small items. Prefer residuals in a band below 50,
    # while still giving tightest-fit priority.
    # Band edges tied to this item size so packing self-organizes.
    upper = max(20, item * 2)
    good = (residual >= 1) & (residual < upper)
    score[good] += 0.6

    # Avoid stranded tiny gaps (residual 1..3) if alternatives exist.
    tiny = (residual >= 1) & (residual <= 3)
    score[tiny] -= 1.2

    return score
# EVOLVE-BLOCK-END
