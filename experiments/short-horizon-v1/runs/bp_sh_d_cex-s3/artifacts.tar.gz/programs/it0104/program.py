# EVOLVE-BLOCK-START
"""Best fit with a mild penalty for residuals that are hard to reuse."""
import numpy as np


def priority(item, bins):
    """Score bins: best fit, but slightly penalize leaving a tiny residual.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    score = -(residual).astype(np.float64)
    # Small residuals (1..3) are hard to reuse later; nudge away from creating them.
    tiny = (residual >= 1) & (residual <= 3)
    score[tiny] -= 1e-3
    return score
# EVOLVE-BLOCK-END
