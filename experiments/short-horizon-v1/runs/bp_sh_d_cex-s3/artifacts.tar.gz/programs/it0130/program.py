# EVOLVE-BLOCK-START
"""Best-fit with a tiny, monotone nudge away from stranded tiny residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Core rule: best fit (prefer smallest post-placement residual). A tiny monotone
    bonus rewards residuals that are likely to be reusable by future items, so that
    among nearly-tied bins we avoid stranding a residual of 1 (which almost nothing
    can fill). The bonus is small enough that best-fit stays dominant.
    """
    residual = (bins - item).astype(np.float64)  # remaining capacity after placement

    # Reusability: residual 0 is perfect; small residuals (1..15) tend to be wasted
    # because the distribution's items are mostly ~40. Give a small positive bonus
    # that grows with residual up to the typical item scale, then saturates.
    reusable = np.minimum(residual, 40.0)
    # Very mild weight so it only breaks near-ties in favor of less wasteful residuals.
    return -residual + 0.01 * reusable
# EVOLVE-BLOCK-END
