# EVOLVE-BLOCK-START
"""Two-regime rule: best-fit for large items, fullest-bin (fill gaps) for small items.

Items are Weibull-shaped with mean ~40. Large items need tight packing (best-fit).
Small items can be used to top off partially filled bins, so for small items we
prefer the fullest bin that still fits them (largest fill, smallest residual),
which consolidates leftovers and leaves fresh bins open for the big items.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # For large items: classic best fit -> smallest residual wins.
    # For small items: also prefer small residual (fullest bin), but give an
    # exact-fit bonus so gaps are closed tightly.
    residual = bins - item  # >= 0 for all bins shown

    if item >= 50:
        # best-fit: minimize residual
        return -residual.astype(np.float64)

    # small item: prefer the fullest bin (smallest residual), with a strong
    # bonus for exact fits to close gaps.
    score = -residual.astype(np.float64)
    score = np.where(residual == 0, 1e6, score)
    return score
# EVOLVE-BLOCK-END
