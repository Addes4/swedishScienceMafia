# EVOLVE-BLOCK-START
"""Best fit, but avoid leaving tiny unusable residuals: among bins whose residual
after placement is 0 or >= a small shard threshold, pick the tightest fit; among
bins leaving a shard smaller than the threshold, prefer the fuller bin (less waste)."""
import numpy as np

SHARD = 8  # residuals below this are unlikely to be reused by any item


def priority(item, bins):
    residual = bins - item
    # Primary: distance of residual from zero (tightness), but push shards out.
    # Map residuals in (0, SHARD) to a penalized (large) effective residual.
    eff = np.where((residual > 0) & (residual < SHARD), SHARD + (SHARD - residual), residual)
    # Higher score = better. Best fit => smaller eff is better => negative.
    # Tie-break toward fuller bins (smaller remaining capacity) to consolidate.
    return -eff * 1000.0 - bins
# EVOLVE-BLOCK-END
