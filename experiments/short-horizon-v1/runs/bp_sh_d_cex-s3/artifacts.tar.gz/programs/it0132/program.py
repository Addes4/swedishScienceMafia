# EVOLVE-BLOCK-START
"""Distribution-aware best fit using a running item-size histogram to value residuals."""
import numpy as np


class _State:
    def __init__(self):
        # Histogram of item sizes 1..100 (index 0 unused).
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0
        self.usable_bonus = np.ones(101, dtype=np.float64)  # P(some future item <= r)
        self.items_since_update = 0


_state = _State()


def _update_usable(state):
    """Recompute, for each residual r in 0..100, the probability a future item fits (<= r)."""
    total = state.count
    if total <= 0:
        # No data yet: assume uniform-ish; bonus mostly flat but favor tiny we can't know.
        state.usable_bonus = np.ones(101, dtype=np.float64)
        return
    # Cumulative distribution of observed item sizes.
    cdf = np.cumsum(state.hist) / total  # cdf[r] = P(item <= r)
    # For residual r, at least one of the next several items fitting matters; use
    # a soft version: probability a single future item fits, smoothed upward.
    # Emphasize the lower tail so that residual 1..small is penalized hard.
    state.usable_bonus = cdf.copy()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update histogram with the arriving item (stream statistics within a stream).
    _state.hist[item] += 1.0
    _state.count += 1.0
    _state.items_since_update += 1
    if _state.items_since_update >= 8 or _state.count <= 1:
        _update_usable(_state)
        _state.items_since_update = 0

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit dominant term: smaller residual is better.
    score = -residual.astype(np.float64)

    # Add a distribution-aware usability bonus for the created residual.
    # residual can be 0..100; clip for lookup.
    r = np.clip(residual, 0, 100).astype(np.int64)
    bonus = _state.usable_bonus[r]
    # Weight the bonus moderately so best-fit still dominates but near-ties break well.
    score += 2.0 * bonus

    return score
# EVOLVE-BLOCK-END

