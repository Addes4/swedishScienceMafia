# EVOLVE-BLOCK-START
"""Best-fit with residual-utility shaping: prefer leaving gaps that match common item sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Stateful histogram of recent item sizes, stored on the function object.
    hist = getattr(priority, "hist", None)
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        priority.hist = hist
        priority.hist_sum = 0.0

    # Exponential decay so older items matter less (adapts to the distribution).
    decay = 0.99
    hist *= decay
    priority.hist_sum *= decay
    hist[item] += 1.0
    priority.hist_sum += 1.0

    # Frequency map: how "fillable" is a residual of size r? Use recent item histogram.
    # Normalize to [0,1]-ish; small smoothing to avoid all-zero.
    if priority.hist_sum > 0:
        freq = hist / priority.hist_sum  # probability mass per exact size
    else:
        freq = hist

    # Bonus for residuals that are themselves likely future item sizes (closable gaps),
    # and bonus for residuals near 0 (tight packing).
    # residual may be large; skip bonus for unused bins (residual == 100 - item -> bin empty).
    bonus = np.zeros_like(residual, dtype=np.float64)
    valid = residual >= 0
    r = residual[valid]
    if r.size:
        # clip freq lookup: residuals up to 100
        b = np.zeros_like(r, dtype=np.float64)
        ok = r <= 100
        b[ok] = freq[r[ok].astype(np.int64)]
        # scale: prefer residuals that are commonly fillable; weight modestly.
        scale = 20.0
        bonus[valid] = b * scale
        # extra: strong preference for exact closure (residual 0)
        bonus[valid] += (r == 0) * 50.0

    # Primary: best-fit (minimize residual). Secondary: residual-utility bonus.
    return -residual.astype(np.float64) + bonus
# EVOLVE-BLOCK-END
