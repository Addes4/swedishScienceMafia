# EVOLVE-BLOCK-START
"""Best fit with a harmonic size-class matching bonus.

The item goes into the bin with the highest score (ties -> first bin).

Base rule is classic best fit: minimize the residual (bins - item). On top of that
we add a small bonus when the residual after placement is "compatible" with the
item size, i.e. the bin will look like it was formed by grouping items of a
similar size class. This biases the packing toward BFD-like pairings of
similar-sized items (a strong heuristic for Weibull-shaped sizes) while keeping
the tight-fit behaviour that makes best fit good for large items.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item

    # Harmonic size-class bonus: reward residuals that lie in the same
    # logarithmic size class as the item (so small items finish off small
    # residuals, large items finish off large residuals).
    # class(item) ~ floor(log2(item)); compare with class(residual+1).
    cls_item = np.floor(np.log2(np.maximum(item, 1)))
    cls_res = np.floor(np.log2(np.maximum(residual, 0) + 1))
    match = (cls_res == cls_item).astype(np.float64)

    # Also give a small extra bonus when the residual is a perfect/near fit,
    # which is the standard best-fit win.
    tight = 1.0 / (residual + 1.0)

    # Weight so that the bonus only breaks near-ties of tightness.
    return -residual.astype(np.float64) + 0.35 * match + 0.05 * tight
# EVOLVE-BLOCK-END
