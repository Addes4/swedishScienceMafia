# EVOLVE-BLOCK-START
"""Best fit with a stateful tie-break that rewards residuals matching common item sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Base rule: pure best fit (smallest resulting residual is best).
    residual = bins - item

    # Stateful histogram of item sizes seen so far in this stream.
    hist = priority.hist
    hist[item] += 1
    total = priority.total + 1
    priority.total = total

    # Prefer leaving a residual that matches a common recently-seen item size,
    # so the leftover gap can be filled exactly later. Small bonus only:
    # never overrides best-fit ordering (scaled below the residual difference of 1).
    freq = hist[residual]
    bonus = freq / total  # in [0, 1]

    return -residual + 0.5 * bonus


priority.hist = np.zeros(101, dtype=np.int64)
priority.total = 0
# EVOLVE-BLOCK-END
