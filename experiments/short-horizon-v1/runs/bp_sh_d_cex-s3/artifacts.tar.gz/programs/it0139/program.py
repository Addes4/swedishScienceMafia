# EVOLVE-BLOCK-START
"""Distribution-aware best fit with a smooth reserve term.

The core rule is best fit: prefer the bin whose residual (remaining capacity
after placing the item) is smallest.  On top of that we add a small bonus that
rewards residuals close to zero, scaled by how "small" the arriving item is.
For tiny items this pushes toward exactly filling a bin (perfect packing); for
large items the bonus nearly vanishes and the rule is pure best fit.  The bonus
decays smoothly so no hand-tuned hard threshold is needed.
"""
import numpy as np


def priority(item, bins):
    """Return a score per bin; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Base: best fit (smaller residual preferred).
    score = -residual.astype(np.float64)

    # Smooth reserve term: reward residuals near 0, weighted by how small the
    # item is.  weight -> ~1 for item=1, ~0.1 for item=40, ~0 for item>=80.
    weight = np.exp(-item / 12.0)
    near_fit = np.exp(-residual / 6.0)  # ~1 when residual == 0, decays quickly
    score += weight * near_fit

    return score
# EVOLVE-BLOCK-END
