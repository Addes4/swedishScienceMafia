# EVOLVE-BLOCK-START
"""Hybrid: best fit for larger items, worst fit for very small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    if item <= 25:
        # Worst fit: pack small items into the emptiest bins to consolidate free space.
        return residual.astype(np.float64)
    # Best fit: tightest squeeze into the fullest bin that still fits.
    return -residual
# EVOLVE-BLOCK-END
