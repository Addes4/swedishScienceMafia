# EVOLVE-BLOCK-START
"""Best fit with complementary-residual bonus for moderate items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining space after placing the item

    # Base: best fit -- prefer smallest residual.
    score = -residual.astype(np.float64)

    # Small item boost: if item is small, prefer leaving a residual that can still
    # hold a typical (mean ~40) item well, i.e., residual in a useful band.
    # But do this gently to not break pure best fit.
    if item <= 25:
        # Reward residuals that are still reasonably large (>= 35), scaled gently.
        useful = np.clip(residual - 30, 0, None).astype(np.float64)
        score += 0.05 * useful

    return score
# EVOLVE-BLOCK-END

