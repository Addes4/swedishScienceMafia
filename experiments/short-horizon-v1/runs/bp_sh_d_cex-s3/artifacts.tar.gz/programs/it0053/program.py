# EVOLVE-BLOCK-START
"""Best fit with a complementary-fill bonus.

Ranks bins by a combination of best-fit (tightest residual) and a bonus for
creating residuals that are common item sizes (so that a later item can fill
the bin exactly), plus a strong bonus for an exact perfect fill.
"""
import numpy as np


class _State:
    def __init__(self):
        # Laplace-smoothed histogram of item sizes 1..100
        self.counts = np.ones(101, dtype=np.float64)
        self.total = 101.0

    def update(self, item):
        self.counts[item] += 1.0
        self.total += 1.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins."""
    _state.update(item)

    # residual capacity left if we put the item in each candidate bin
    resid = bins - item  # all >= 0 since only fitting bins are shown

    # probability that a residual capacity equals a typical future item size
    # (normalized histogram).  We reward creating "fillable" residuals.
    freq = _state.counts / _state.total

    # score: prefer small residual (best fit), but add a bonus when the
    # residual left behind is a plausible future item size (complementary
    # pair), and a large bonus for an exact 0 residual (perfect fill).
    score = -resid.astype(np.float64)

    # complementary bonus: residual r is rewarded by how likely an item of
    # size r is to arrive next.
    comp = np.zeros_like(score)
    valid = resid > 0
    comp[valid] = freq[resid[valid]]
    # scale the complementary bonus so it only breaks near-ties in residual
    score += 0.35 * comp

    # exact fill gets a decisive bonus
    score[resid == 0] += 1.0

    return score
# EVOLVE-BLOCK-END
