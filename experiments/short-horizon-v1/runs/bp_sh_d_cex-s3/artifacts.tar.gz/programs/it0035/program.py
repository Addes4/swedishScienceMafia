# EVOLVE-BLOCK-START
"""Almost-Best-Fit: if the fullest fitting bin leaves a large residual, use it;
otherwise use best-fit. This consolidates large items and avoids tiny shards."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best-fit key: smaller residual is better.
    score = -residual.astype(np.float64)
    # Among bins where the fullest fitting choice still leaves a large residual,
    # prefer the fullest such bin (smallest residual >= threshold) to consolidate.
    # Implement: add a bonus that is large only for bins with residual >= threshold,
    # scaled by fullness so the fullest among them wins.
    threshold = 100.0 / 3.0
    large = residual >= threshold
    # bonus in (0,1) range so it only breaks ties among the large-residual group,
    # and within that group larger remaining -> sharper preference for fullest bin.
    bonus = np.where(large, (100.0 - residual) / 1000.0, 0.0)
    return score + bonus
# EVOLVE-BLOCK-END
