# EVOLVE-BLOCK-START
"""Best fit with item-aware tie-breaking on near-tied residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Dominant term: pure best fit (smaller residual is better).
    score = -residual.astype(np.float64)

    # Tie-breaker (strictly smaller than the unit gap between residuals):
    # among near-equal residuals prefer a perfect fit, or a residual that
    # can still hold another item of this size (reusable remainder).
    small_gap = (residual == 0)
    reusable = (residual >= item)
    score += 1e-3 * small_gap.astype(np.float64)
    score += 5e-4 * reusable.astype(np.float64)
    return score
# EVOLVE-BLOCK-END

