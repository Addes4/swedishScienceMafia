# EVOLVE-BLOCK-START
"""Best fit with a tie-break that preserves larger residual bins for future large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Primary objective: best fit minimizes the resulting residual.
    score = -residual.astype(np.float64)

    # Tie-break: among (near-)best-fit bins, prefer the one leaving the larger
    # residual, so that not-yet-used / roomy bins are preserved for future
    # large items. Since residuals are integers, a tiny epsilon scaled by the
    # residual magnitude orders only within an exact tie.
    return score + residual.astype(np.float64) * 1e-6
# EVOLVE-BLOCK-END

