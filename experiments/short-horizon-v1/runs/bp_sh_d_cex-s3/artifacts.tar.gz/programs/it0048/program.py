# EVOLVE-BLOCK-START
"""Best fit with a reusable-residual preference for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    if item >= 80:
        # Large items: tightest fit to avoid wasting big bins.
        return -residual
    # Small/medium items: prefer residuals close to a reusable target (~40),
    # so the leftover bin stays useful for future items. Break ties by tightest fit.
    target = 40.0
    aim = np.abs(residual - target)
    return -aim - 0.01 * residual
# EVOLVE-BLOCK-END
