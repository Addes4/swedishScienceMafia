# EVOLVE-BLOCK-START
"""Best-fit with a learned "can this residual be filled?" bonus.

Items arrive online. We keep a histogram of item sizes seen so far. When placing an
item, pure best-fit minimizes the leftover. But a leftover of size r is only useful
if a future item of size exactly r is likely. So we score each bin by best-fit
(min residual) but add a modest bonus when the resulting residual is a size that has
already appeared in the stream, making it a candidate to be filled exactly later.
"""
import numpy as np

# state kept between calls within a stream
_hist = np.zeros(101, dtype=np.int64)   # counts of item sizes seen so far
_total = 0


def _reset_if_fresh(bins):
    """Detect a new stream (all bins unused) and reset state."""
    global _hist, _total
    if bins.size and np.all(bins == 100):
        _hist = np.zeros(101, dtype=np.int64)
        _total = 0


def priority(item, bins):
    global _hist, _total

    _reset_if_fresh(bins)

    # record this item (state available for ranking: use prior history)
    resid = bins - item            # leftover after placing item here (>=0)

    # "fillable" bonus: residual is a size that already appeared before
    seen = np.zeros(resid.shape, dtype=np.float64)
    if _total > 0:
        r = resid
        mask = (r >= 1) & (r <= 100)
        seen[mask] = _hist[r[mask]] > 0

    # primary: minimize residual (best fit); secondary: prefer fillable residual
    score = -resid.astype(np.float64) + 0.5 * seen

    # update history with current item
    _hist[item] += 1
    _total += 1

    return score
# EVOLVE-BLOCK-END
