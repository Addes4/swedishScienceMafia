# EVOLVE-BLOCK-START
"""Best fit with a small stateful level-correction for tighter reuse of residuals."""
import numpy as np


_STATE = {"sizes": np.zeros(101, dtype=np.int64), "n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _STATE
    # Update running statistics of past item sizes (visible history only).
    st["sizes"][int(item)] += 1
    st["n"] += 1
    st["sum"] += float(item)

    residual = bins - item  # resulting remaining capacity after placing the item

    # Primary: best fit -> smallest resulting residual first.
    score = -residual.astype(np.float64)

    # Secondary: reward residuals that can likely be exactly filled by a common
    # future item size.  Use the observed histogram to find plausible fill sizes.
    hist = st["sizes"]
    # Consider item sizes that have appeared and whose probability is non-trivial.
    if st["n"] >= 8:
        plausible = np.nonzero(hist)[0]
        if plausible.size:
            # Probability weight of each plausible fill size.
            w = hist[plausible].astype(np.float64)
            w /= w.sum()
            r = residual.astype(np.float64)[:, None]
            d = np.abs(r - plausible[None, :].astype(np.float64))
            # Closeness to a likely exact-fill residual.
            bonus = (w[None, :] * np.exp(-d)).sum(axis=1)
            score += 0.05 * bonus

    # Slight penalty to opening a completely fresh bin when other options exist.
    fresh = (bins == 100)
    if np.any(~fresh):
        score[fresh] -= 1e-3

    return score
# EVOLVE-BLOCK-END
