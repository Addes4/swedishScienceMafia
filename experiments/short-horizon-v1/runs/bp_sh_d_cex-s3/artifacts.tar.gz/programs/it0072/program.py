# EVOLVE-BLOCK-START
"""Best fit with a mild fullness bonus to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (smaller residual better). Secondary: prefer fuller bins
    # (smaller original remaining capacity / larger used space) to consolidate.
    return -residual.astype(np.float64) * 1000.0 - bins.astype(np.float64)
# EVOLVE-BLOCK-END
