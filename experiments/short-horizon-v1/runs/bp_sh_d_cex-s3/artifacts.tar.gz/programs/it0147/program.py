# EVOLVE-BLOCK-START
"""Smooth best-fit with a size-weighted "reserve large gaps" tie-breaker.

Pure best fit (minimize resulting residual) is the dominant term.  A small,
strictly bounded tie-breaker rewards leaving residuals that a future typical
large item could still use, weighted down for large items (which can't be
picky anyway).  This keeps best-fit behavior while slightly avoiding the
fragmentation of big open bins by tiny items.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item

    # Dominant term: best fit (smaller residual -> higher score).
    score = -residual.astype(np.float64)

    # Tie-breaker: mildly reward residuals that remain usable by a future
    # large item (say >= 40), and mildly penalize tiny unusable leftovers.
    # Weight by (100 - item) so small items care more: they have more freedom
    # to avoid fragmenting big gaps, while large items stay pure best fit.
    weight = (100.0 - item) / 100.0  # 0 for item=100, ~1 for tiny items

    # Penalize very small leftovers (1..20) which are hard to reuse.
    awkward = (residual >= 1) & (residual <= 20)
    score[awkward] -= 0.3 * weight

    # Slight bonus for leaving a residual large enough for a typical big item.
    usable = residual >= 40
    score[usable] += 0.1 * weight

    return score
# EVOLVE-BLOCK-END

