# EVOLVE-BLOCK-START
"""Stateful best-fit with bounded, capped tie-breaking tweaks.

Primary rule: best fit (smallest residual after placing the item).
Secondary terms (all bounded, so best-fit always dominates) help consolidate
items on heavy-tailed streams:
  - slight preference for leftover gaps that are more likely to be useful
    (a "sum of squares" / residual-profile term), and
  - a tiny penalty for opening a fresh bin when an existing partial bin is
    comparably tight.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest."""
    residual = bins - item          # remaining capacity after placing the item
    # Primary: best fit -> prefer the smallest residual.
    fit = -residual.astype(np.float64)
    # Secondary: prefer residuals that are "cleaner" to fill (sum-of-squares style);
    # this is bounded and only breaks near-ties in favor of consolidating.
    sq = -(residual.astype(np.float64) ** 2) * 1e-4
    # Tiny penalty for opening a fresh (still-100) bin when another bin is close.
    fresh = np.where(bins >= 100, 1.0, 0.0) * 1e-3
    return fit + sq - fresh
# EVOLVE-BLOCK-END
