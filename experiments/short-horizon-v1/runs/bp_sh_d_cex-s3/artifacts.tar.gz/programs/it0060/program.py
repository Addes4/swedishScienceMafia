# EVOLVE-BLOCK-START
"""Best fit, lightly augmented with complementary-fit bonuses from a running histogram.

Pure best-fit (tightest residual) is already near-optimal here, so the base order is
left identical.  Two stateful nudges only act when they can help:
  * an exact completion (residual becomes 0) gets the top boost,
  * a residual that matches a commonly-seen item size gets a small boost, since a
    future item of that size will complete the bin exactly.
The nudges are tiny relative to the capacity scale so they never reorder bins that
differ by more than one unit, preserving the strong best-fit behaviour.
"""
import numpy as np

# histogram of past item sizes (index 0..100); plus items seen
_HIST = np.zeros(101, dtype=np.float64)
_SEEN = 0

# size of the boost awarded to exact completions, in residual units
_EXACT_BONUS = 0.5
# size of the boost for residuals matching a common item size
_MATCH_BONUS = 0.15
# how "common" a residual must be to earn the match bonus
_MATCH_MIN_FRAC = 0.02


def priority(item, bins):
    global _SEEN
    # update histogram with the arriving item (state persists across a stream)
    _HIST[item] += 1.0
    _SEEN += 1.0

    # base: best fit -> tightest residual is highest score
    score = -(bins - item).astype(np.float64)

    if _SEEN > 20:
        # residual that would remain after placing the item in each bin
        residual = bins - item

        # exact completion bonus
        score += np.where(residual == 0, _EXACT_BONUS, 0.0)

        # complement bonus: residual equals a frequent past item size
        frac = _HIST / _SEEN
        # gather frequency of each residual value (clip to table range)
        idx = np.clip(residual, 0, 100)
        common = frac[idx]
        score += np.where(common >= _MATCH_MIN_FRAC, _MATCH_BONUS * common, 0.0)

    return score
# EVOLVE-BLOCK-END
