# EVOLVE-BLOCK-START
"""Hybrid: fill bins exactly when possible, else best fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Strong bonus when the bin becomes exactly full (residual 0).
    exact_bonus = (residual == 0).astype(bins.dtype) * 1000
    return exact_bonus - residual
# EVOLVE-BLOCK-END
