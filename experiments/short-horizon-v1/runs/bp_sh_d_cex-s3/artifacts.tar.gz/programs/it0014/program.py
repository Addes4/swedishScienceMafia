# EVOLVE-BLOCK-START
"""Best fit with an online-learned residual class bonus.

Primary ordering is tightest fit (best fit). A small secondary term rewards residuals
that match size classes seen recently in the stream, mimicking the pairing advantage
of best-fit-decreasing while still being purely online.
"""
import numpy as np

# number of size classes for the residual histogram (0..100)
_NC = 21
_hist = np.zeros(_NC, dtype=np.float64)
_count = 0


def _classize(x):
    return min(_NC - 1, int(x * _NC / 101))


def priority(item, bins):
    global _hist, _count
    residuals = bins - item  # >= 0 for all shown bins
    # base: best fit (negative residual so higher score = tighter)
    base = -residuals.astype(np.float64)

    # secondary: reward residuals in classes that have been common recently
    if _count > 50 and residuals.size:
        w = _hist / _hist.sum() if _hist.sum() > 0 else _hist
        classes = np.minimum((residuals * _NC) // 101, _NC - 1).astype(np.int64)
        bonus = w[classes] * 2.0
    else:
        bonus = 0.0

    score = base + bonus

    # update history with the arriving item size
    _hist[_classize(item)] += 1.0
    _count += 1
    if _count > 500:
        # decay to stay adaptive
        _hist *= 0.995

    return score
# EVOLVE-BLOCK-END

