# EVOLVE-BLOCK-START
"""Best fit with a mild secondary preference for residuals near the typical item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual -> highest score).
    score = -residual.astype(np.float64)
    # Secondary: tiny nudge so that among comparable residuals we prefer leaving
    # a residual near the typical item size (mean ~40), which future items can fill.
    score -= 1e-3 * np.abs(residual - 40)
    return score
# EVOLVE-BLOCK-END

