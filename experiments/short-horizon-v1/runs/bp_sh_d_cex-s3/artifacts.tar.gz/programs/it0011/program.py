# EVOLVE-BLOCK-START
"""Best fit with a harmonic residual bonus for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    # Best fit: prefer smallest residual.
    base = -residual.astype(np.float64)

    # For small items, add a harmonic bonus that rewards residuals matching
    # common item sizes, encouraging complementary pairings.
    r = residual.astype(np.float64)
    with np.errstate(divide="ignore", invalid="ignore"):
        harmonic = np.where(r > 0, 1.0 / r, 0.0)

    # Apply harmonic nudge mainly for genuinely small items.
    weight = max(0.0, (40.0 - item) / 40.0) * 4.0
    return base + weight * harmonic
# EVOLVE-BLOCK-END
