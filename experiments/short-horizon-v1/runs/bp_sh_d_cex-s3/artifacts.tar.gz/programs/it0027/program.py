# EVOLVE-BLOCK-START
"""Best fit with a fullness tie-break: tightest residual first, then fullest bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smallest residual (best fit). Tie-break: smallest remaining capacity
    # (fullest bin) so that equal-quality fits are consolidated instead of scattered.
    return -(residual * 101 + bins)
# EVOLVE-BLOCK-END
