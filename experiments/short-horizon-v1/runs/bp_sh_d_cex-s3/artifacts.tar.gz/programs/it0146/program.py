# EVOLVE-BLOCK-START
"""Best fit with a mild tie-breaker protecting reusable large residuals for big items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item

    # Dominant term: classic best fit (minimize resulting residual).
    score = -residual.astype(np.float64)

    # Small item: among bins with near-equal residual, gently prefer to leave a
    # *larger* residual free so big future items still have room, but never
    # override the best fit. The bonus is tiny and capped so it only breaks ties.
    if item < 40:
        # reward larger residual, but saturate so it can't beat a better fit
        bonus = np.minimum(residual, 60).astype(np.float64) * 0.01
        score += bonus

    # Perfect fits get a strong (but still fit-dominant) nudge.
    score += (residual == 0).astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END
