# EVOLVE-BLOCK-START
"""Best fit with a stateful histogram-aware residual preference on ties."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.int64)
        self.count = 0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    # update histogram with the current item
    st.hist[item] += 1
    st.count += 1

    residual = bins - item  # >= 0 guaranteed
    # primary: best fit (smallest residual)
    score = -residual.astype(np.float64)

    # secondary bonus: among near-tied residuals, prefer leaving a residual that
    # is a common recent item size (so a future item can fill it exactly), but
    # only as a tiny tiebreaker so pure best-fit quality dominates.
    if st.count >= 20:
        # most common recent size
        common = int(np.argmax(st.hist))
        # bonus only when the resulting residual equals the common size
        match = (residual == common)
        score += match * 1e-3

    return score
# EVOLVE-BLOCK-END
