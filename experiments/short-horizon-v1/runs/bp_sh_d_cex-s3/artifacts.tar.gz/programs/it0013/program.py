# EVOLVE-BLOCK-START
"""Best fit with a fine-grained tie-break favor of mid-size residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary: prefer the tightest fit (smallest residual) -> best fit.
    score = -residual.astype(np.float64)

    # Secondary tie-break: among bins with essentially the same residual,
    # prefer residuals that are neither tiny nor huge (closer to typical
    # mid-size items), which helps future placements pack cleanly.
    # A smooth concave reward centered around ~40 stabilizes packing choices.
    bonus = -(np.abs(residual - 40.0))
    score = score * 100.0 + bonus

    return score
# EVOLVE-BLOCK-END
