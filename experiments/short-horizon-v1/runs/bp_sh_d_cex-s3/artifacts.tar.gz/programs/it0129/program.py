# EVOLVE-BLOCK-START
"""Distribution-aware best fit: reward residuals that future items are likely to reuse."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties).

    item: integer size of arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Estimate P(future item <= r) from a running histogram of observed sizes.
    # We store a small state on the function object; fall back to a smooth prior.
    hist = getattr(priority, "_hist", None)
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        hist[1:] = 1.0
        priority._hist = hist
        priority._count = 0.0

    # update histogram with current item
    hist[item] += 1.0
    priority._count += 1.0

    # cumulative distribution: prob a random item has size <= r
    cdf = np.cumsum(hist)
    total = cdf[-1]
    cdf = cdf / total

    # Fit probability for each residual: P(item <= residual)
    r = np.clip(residual, 0, 100)
    fit_prob = cdf[r.astype(np.int64)]

    # Best-fit tightness term (prefer small residual), scaled.
    tight = -residual.astype(np.float64)

    # Blend: tightly pack, but give a bonus to residuals likely to accept
    # a future item (avoids stranding unusable small gaps near-full bins).
    score = tight + 40.0 * fit_prob
    return score
# EVOLVE-BLOCK-END

