# EVOLVE-BLOCK-START
"""Best fit, with a light stateful bonus for consolidating residuals into
frequently-seen item sizes (helps small items fill shards exactly)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Base: best fit -- prefer the bin the item fits most tightly.
    score = -(bins - item)

    # Stateful bonus: for small items, nudge bins whose post-placement residual
    # matches a common past item size, so leftovers become reusable.
    freq = priority.freq
    if item <= 50:
        # residual after placing the item
        resid = bins - item
        # bonus for residuals that are common item sizes (0 if never seen)
        common = freq[resid]  # fancy-index with array of residuals
        score = score + 0.001 * common
    return score


priority.freq = np.zeros(101, dtype=np.float64)
# warm up: exact resonances are only mildly helpful, keep weight tiny
