# EVOLVE-BLOCK-START
"""Best-fit with a learned residual-value bonus.

The score is fundamentally best-fit (prefer small post-placement residual),
but we add a small bonus proportional to how "useful" the resulting residual
is likely to be for future items, estimated from a running histogram of item
sizes seen so far.  This nudges ties toward residuals that can still absorb
common future items, while keeping best-fit dominant.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item

    # Best-fit dominant term: smaller residual -> higher score.
    score = -residual.astype(np.float64)

    # Histogram-based residual value: reward residuals that equal (or are near)
    # a typical item size, since such gaps are likely reusable.
    hist = _state.get("hist")
    if hist is not None:
        # hist: counts over sizes 1..100 (index 0 unused)
        total = hist.sum()
        if total > 0:
            # density of item sizes at exactly the residual value
            # (residual of 0 is a perfect fill -> best, handled by best-fit)
            clipped = np.clip(residual, 0, 100).astype(np.int64)
            prob = hist[clipped] / total  # reuse likelihood for this residual
            score += 0.25 * prob
    return score


_state = {"hist": None, "count": 0}


def _update(item):
    hist = _state["hist"]
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        _state["hist"] = hist
    hist[item] += 1.0
    _state["count"] += 1


# wrap priority to update state after each call
_orig_priority = priority


def priority(item, bins):  # noqa: F811
    _update(item)
    return _orig_priority(item, bins)
# EVOLVE-BLOCK-END
