# EVOLVE-BLOCK-START
"""Histogram-aware best fit: keep residuals reusable for the observed size mix."""
import numpy as np

_state = {"count": 0, "sum": 0.0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Prioritize bins so that residual space stays usable for future items.

    Base rule is best fit (minimize resulting residual). On top, penalize
    creating residuals that are too small to hold a typical future item, using
    a running histogram of observed item sizes to estimate reusability.
    """
    # Update running statistics (this item is already "seen").
    hist = _state["hist"]
    hist[item] += 1.0
    _state["count"] += 1
    _state["sum"] += item

    n = _state["count"]
    residual = (bins - item).astype(np.float64)

    # Probability that a future item fits into a residual of size r,
    # estimated from past items: P(item <= r).
    # Use cumulative histogram but smooth heavily toward the prior to avoid
    # overreacting early in the stream.
    if n >= 20:
        cdf = np.cumsum(hist) / n
    else:
        # Weak prior: mean ~40 Weibull-ish; approximate CDF by residual size.
        cdf = np.clip(bins / 100.0, 0.0, 1.0)

    # Base: best fit.
    score = -residual

    # Reusability term only matters for non-perfect placements of smallish items.
    if item < 60:
        # Expected ability to reuse the residual: look up CDF at residual size.
        idx = np.clip(residual.astype(np.int64), 0, 100)
        p_fit = cdf[idx]
        # Reward residuals that are very likely reusable, penalize dead space.
        score = score + 3.0 * p_fit

        # Strong bonus for exact fit (residual 0): this is always good--fully
        # packed bins free up capacity elsewhere.
        score[residual == 0] += 4.0
    return score
# EVOLVE-BLOCK-END
