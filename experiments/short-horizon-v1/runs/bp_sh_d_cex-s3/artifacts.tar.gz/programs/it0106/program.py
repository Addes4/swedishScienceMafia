# EVOLVE-BLOCK-START
"""Best fit with a small stateful residual-match bonus."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    """Best fit, plus a capped bonus when the leftover capacity is a common item size."""
    global _COUNT
    # Score: prefer tightest fit (best fit). baseline = -(residual)
    residual = bins - item
    score = -residual.astype(np.float64)

    # Stateful bonus: if leftover equals a frequently observed item size,
    # it can likely be filled exactly later, mildly preferring such bins.
    if _COUNT > 0:
        freq = _HIST / _COUNT  # probabilities, sum ~1
        # bounded bonus in [0, ~0.4]; only for exact known leftovers
        bonus = 0.4 * freq[residual]
        score = score + bonus

    # update histogram with the current item
    _HIST[item] += 1.0
    _COUNT += 1.0

    return score
# EVOLVE-BLOCK-END
