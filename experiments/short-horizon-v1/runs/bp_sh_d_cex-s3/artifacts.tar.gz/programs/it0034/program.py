# EVOLVE-BLOCK-START
"""Hybrid: best-fit for small items, fullest-bin for large items.

Best-fit is very strong for the Weibull-shaped stream. Its main weakness is
that very large items tend to land in already-full bins and create shards that
small items can't fill. For large items we instead prefer the fullest bin
(smallest residual that still fits), which creates larger clean residuals.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since only fitting bins are shown
    if item >= 65:
        # Prefer the fullest bin that still fits: smallest residual first.
        return -residual.astype(np.float64)
    # Best fit: leave the smallest usable residual.
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
