# EVOLVE-BLOCK-START
"""Stateful variant of best fit.

Primary key is still best fit (prefer the smallest post-placement residual).
For "small" items (item <= running mean of past items) we instead try to
fill an existing shard: among bins whose residual is below a shard threshold
we prefer the fullest bin. This consumes near-unusable leftovers instead of
letting best-fit rathole tiny items into fresh bins.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest."""
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    residual = bins - item  # remaining capacity after placing the item

    if item <= mean:
        # Prefer the fullest bin among those that leave only a small shard;
        # otherwise fall back to best fit. Score: shard bins get a large bonus
        # scaled by how full they are; non-shard bins keep best-fit ordering.
        shard = 32
        mask = residual <= shard
        score = -residual.astype(np.float64)  # best fit ordering by default
        if mask.any():
            # bonus large enough to dominate within the shard set, and
            # tie-break by fullness (smaller residual -> higher score)
            score = np.where(mask, 1e6 - residual, score)
        return score

    return -residual
# EVOLVE-BLOCK-END
