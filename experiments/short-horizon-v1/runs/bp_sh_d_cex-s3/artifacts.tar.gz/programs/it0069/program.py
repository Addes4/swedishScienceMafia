# EVOLVE-BLOCK-START
"""Best-fit with a static "usable residual" tie-break.

Pure best-fit minimizes the residual left in the chosen bin.  The only room for
improvement is when several bins give residuals that are equally tight but not
equally *useful*: a residual of 0 is perfect, but among non-zero residuals the
ones that are large enough to hold typical future items are better than tiny
gaps that will never be filled again.

We keep best-fit as the primary key by encoding the residual into a small number
of "value classes": residual 0 gets the top class, then residuals are binned by
how many future items they could still absorb.  Within the same class we revert
to plain best-fit (smallest residual first, then earlier bin index).
"""
import numpy as np

# Static, distribution-agnostic breakpoints.  Item sizes come from a fixed
# Weibull-shaped distribution with mean ~40, so residuals roughly in the
# 40..100 range are still useful while residuals below ~20 are mostly dead.
_LEVELS = np.array([0, 10, 20, 30, 40, 55, 70, 85, 100], dtype=np.int64)


def priority(item, bins):
    """Score every candidate bin; highest wins (ties -> first bin)."""
    item = int(item)
    res = bins.astype(np.int64) - item          # residual after placement

    # Number of useful "size levels" the residual can still accommodate.
    # np.searchsorted with side='right' gives an integer bucket index.
    level = np.searchsorted(_LEVELS, res, side='right')

    # Primary key: smaller residual is better -> invert.
    # Secondary key: higher level is better.
    # Tertiary: earlier bin index (handled by the harness, so just use order).
    score = -res.astype(np.float64) + 0.01 * level.astype(np.float64)

    # Ensure a perfect fit (residual 0) always strictly dominates a non-zero
    # residual, regardless of the level bonus.
    perfect = (res == 0).astype(np.float64)
    score += 1000.0 * perfect

    return score
# EVOLVE-BLOCK-END
