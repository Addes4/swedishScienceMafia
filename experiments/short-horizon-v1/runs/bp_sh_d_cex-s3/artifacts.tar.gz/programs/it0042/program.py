# EVOLVE-BLOCK-START
"""Best fit with small-item consolidation tie-break."""
import numpy as np


def priority(item, bins):
    # Base: best fit -> highest score for smallest residual that still fits.
    score = -(bins - item).astype(np.float64)

    # For small/medium items, mildly boost bins that will be left with a
    # residual close to 0 or in a "reusable" band (>= item so they can take
    # another similar item). This nudges consolidation without hurting big items.
    if item <= 33:
        resid = bins - item  # >= 0 since bins only include fitting bins
        # reusable band: residual in [item, 2*item] or residual == 0
        boost = np.zeros_like(score)
        boost[(resid == 0)] = 1.0
        band = (resid >= item) & (resid <= 2 * item)
        boost[band] = 0.5
        # discourage creating tiny shards below item size (hard to reuse)
        shard = (resid > 0) & (resid < item)
        boost[shard] = -0.5
        score = score * 100.0 + boost

    return score
# EVOLVE-BLOCK-END
