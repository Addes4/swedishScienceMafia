# EVOLVE-BLOCK-START
"""Best fit with a convex penalty on the resulting residual (sum-of-squares style)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer the tightest fit (smallest residual after placement),
    # with a slight tie-break favoring larger residuals among equals.
    return -residual.astype(np.float64) + 0.001 * bins
# EVOLVE-BLOCK-END

