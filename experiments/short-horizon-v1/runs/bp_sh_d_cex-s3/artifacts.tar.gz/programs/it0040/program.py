# EVOLVE-BLOCK-START
"""Best fit with a penalty on creating tiny unusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in, in bin order.
    """
    residual = bins - item
    # Base: best fit prefers smallest residual.
    score = -residual.astype(np.float64)
    # Penalize shards: a residual in 1..3 is largely unusable unless an item that
    # small arrives. Slightly penalize, scaling with how close to full we got,
    # so the item rather lands where it leaves a usable remainder.
    tiny = (residual > 0) & (residual < 4)
    score -= tiny.astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END
