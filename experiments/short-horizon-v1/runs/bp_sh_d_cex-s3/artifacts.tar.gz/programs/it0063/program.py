# EVOLVE-BLOCK-START
"""Best fit with a tie-breaking bonus toward residuals that match common item sizes."""
import numpy as np


class _State:
    hist = np.zeros(101, dtype=np.float64)
    count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Core rule: best fit (smallest valid residual after placement).
    Tie-break: among bins giving the same residual, prefer the one whose residual matches
    a common item size, so future items can fill it exactly. This is a tiny secondary term.
    """
    new_res = bins - item  # >= 0 since bins only contains fitting bins

    # Update the running item-size histogram (stateful, but bounded influence).
    _State.hist[item] += 1.0
    _State.count += 1

    # Primary: best fit. Ties broken by a small bonus for "useful" residuals.
    # bonus is in [0,1), scaled below 1 so it only breaks exact best-fit ties.
    total = _State.count
    frac = _State.hist / total  # probability mass estimate per residual value

    bonus = np.zeros_like(new_res, dtype=np.float64)
    valid = new_res <= 100
    if valid.any():
        idx = new_res[valid]
        bonus[valid] = np.where(idx > 0, np.minimum(frac[np.clip(idx, 0, 100)], 0.999), 0.0)

    return -new_res + bonus
# EVOLVE-BLOCK-END
