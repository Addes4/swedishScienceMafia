# EVOLVE-BLOCK-START
"""Best-fit with a large-item fresh-bin safeguard."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Standard best-fit score: prefer smallest nonnegative residual.
    score = -residual.astype(np.float64)

    # If there is an exact fit, strongly prefer it.
    exact = residual == 0
    if exact.any():
        score = np.where(exact, 1e6, score)
        return score

    return score
# EVOLVE-BLOCK-END
