# EVOLVE-BLOCK-START
"""Classic online harmonic-style packing combined with best-fit within a target class.

Items are classified by size fraction x = item / 100.0. Small items are packed into the
fullest fitting bin that still leaves room (consolidation), preserving emptier bins for
future larger items. Otherwise we fall back to tightest-fit (best fit).
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Tightest fit baseline: residual after placement, negated (smaller residual -> higher score)
    residual = bins - item

    # Size class thresholds (fractions of capacity).
    # Small items: <= 1/3 capacity. Pack them into the fullest bin that still fits
    # (i.e. smallest residual) to consolidate; this is already what best-fit does, so
    # add a small preference against creating tiny shards.
    x = item / 100.0

    if x <= 1.0 / 3.0:
        # Prefer the fullest fitting bin (min residual), but avoid leaving a shard
        # smaller than a typical small item (~0.1 capacity): push such placements down.
        shard_penalty = np.where(residual < 10, -0.5, 0.0)
        return -residual + shard_penalty
    elif x <= 0.5:
        # Medium items: prefer bins where the residual exactly matches item size
        # (perfect-ish pairing) is rare; use tightest fit with extra weight on fullness.
        return -residual * 2.0
    else:
        # Large items: strictly best fit.
        return -residual
# EVOLVE-BLOCK-END
