# EVOLVE-BLOCK-START
"""Best fit with a fragmentation threshold: avoid creating unusable tiny residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Default: best fit (tightest residual). But if placing the item would leave a residual
    below a small fragmentation threshold, we still rank by tightest fit within the set of
    bins that either avoid that residual or leave a usable one, by adding a small penalty
    proportional to how far the residual is below the threshold.
    """
    residual = bins - item  # remaining capacity after placing the item
    # Fragmentation threshold: ~1/8 of capacity is small enough to be unlikely reusable,
    # but we weight the penalty so it only breaks near-ties.
    thr = 12.0
    penalty = np.where(residual < thr, (thr - residual), 0.0) * 0.5
    return -residual - penalty
# EVOLVE-BLOCK-END
