# EVOLVE-BLOCK-START
"""Best fit with a fragmentation-aware floor on the leftover residual.

Pure best-fit tends to shave bins down to tiny, unusable residuals. Here we rank
bins in two tiers:
  - Tier 1: the residual after placement is at least a floor F (reusable), ranked
    by tightest residual (still best-fit-like inside the tier).
  - Tier 2: everything else (leftover too small to be useful), also ranked by
    tightest residual but strictly below all tier-1 bins.
This keeps big items paired tightly while steering small items away from
creating useless shards.
"""
import numpy as np

# Items are integers 1..100; a leftover below this is judged a wasted shard.
FLOOR = 12


def priority(item, bins):
    """Return a priority per bin; highest wins, ties to the first bin."""
    residual = bins - item  # remaining capacity after placing the item here
    reusable = residual >= FLOOR
    # Primary: reusable bins first. Secondary: tighter residual (best fit).
    return reusable.astype(np.float64) * 1000.0 - residual
# EVOLVE-BLOCK-END
