# EVOLVE-BLOCK-START
"""Best fit with a learned residual-reusability bonus from a running item histogram."""
import numpy as np


_HIST = np.zeros(101, dtype=np.float64)   # observed item size counts
_TOTAL = 0.0


def priority(item, bins):
    """Rank bins by best fit, nudged toward residuals likely reusable by future items."""
    global _TOTAL
    residual = bins - item

    # Update running item-size histogram (state persists within a stream).
    _HIST[item] += 1.0
    _TOTAL += 1.0

    # Estimate probability mass of future items that would exactly fit into a
    # given residual r (>0), plus residual 0 being perfect. Smoother: count of
    # future items with size <= r weighted by frequency.
    hist = _HIST
    # cumulative mass of item sizes up to each possible residual
    cum = np.cumsum(hist) / (_TOTAL + 1.0)  # size 1..100 probabilities

    # For each bin residual, value = how much leftover space is likely usable.
    # Use probability that a future item fits (size <= residual), scaled.
    r = np.clip(residual, 0, 100).astype(np.int64)
    usable = cum[r]  # in [0,1]

    # Primary: best fit (smaller residual better). Secondary: tiny bonus for
    # high usability residuals. Keep bonus small so best fit dominates.
    score = -residual.astype(np.float64) + 0.5 * usable
    return score
# EVOLVE-BLOCK-END

