# EVOLVE-BLOCK-START
"""Best fit with light consolidation pressure: prefer exact fits, then best fit,
with a small bias toward staler (less recently touched) bins to encourage filling
existing gaps before opening new ones."""
import numpy as np

_state = {"t": 0, "last": {}}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    t = _state["t"]
    _state["t"] = t + 1
    last = _state["last"]
    n = len(bins)
    out = np.empty(n, dtype=np.float64)
    for i in range(n):
        r = int(bins[i])
        residual = r - item
        # best fit: smaller residual is better
        s = -float(residual)
        # exact fit bonus
        if residual == 0:
            s += 1e6
        # staleness bonus: bins not used for longer are slightly preferred
        li = last.get(i, -1)
        s += 1e-3 * (t - li < 0 and 0 or (t - li))
        # update last use lazily: caller selects the winner, we update all on next call
        out[i] = s
    return out
# EVOLVE-BLOCK-END

