# EVOLVE-BLOCK-START
"""Best-fit augmented with a stateful item-size histogram to favor exact complements."""
import numpy as np

# per-stream state: histogram of observed item sizes (1..100)
_hist = np.zeros(101, dtype=np.float64)
_count = 0


def priority(item, bins):
    """Score each bin; highest wins. Prefer tightest fit, boosted for exact complements."""
    global _count
    # update histogram with the arriving item (state within a stream)
    _hist[item] += 1.0
    _count += 1

    # resulting residual after placing item into each bin
    resid = bins - item  # all bins shown fit the item, so resid >= 0

    # Base: tightest fit (smaller residual = better)
    score = -resid.astype(np.float64)

    # Complement bonus: if the resulting residual equals (or nearly) a common
    # observed item size, a later item can fill it exactly. Weight by frequency.
    # Normalize frequencies.
    total = _hist.sum()
    if total > 0:
        freq = _hist / total
        # bonus for residual matching a likely future size
        # gather freq at resid values (resid within 0..100)
        r = resid.astype(np.int64)
        bonus = freq[np.clip(r, 0, 100)]
        # scale the bonus so it can override the tightest-fit difference,
        # but keep tightest-fit meaningful. Scale relative to item size.
        score += 80.0 * bonus

    return score
# EVOLVE-BLOCK-END
