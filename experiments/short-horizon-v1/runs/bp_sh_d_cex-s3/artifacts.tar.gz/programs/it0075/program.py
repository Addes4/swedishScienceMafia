# EVOLVE-BLOCK-START
"""Best-fit with stateful pseudo-random tie-breaking among near-equal residuals."""
import numpy as np

_rng_state = [12345]


def _next_rand():
    s = _rng_state[0]
    s = (1103515245 * s + 12345) & 0x7FFFFFFF
    _rng_state[0] = s
    return s


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    residual = bins - item
    # best-fit primary: smaller residual is better
    score = -residual.astype(np.float64)
    # Pseudo-random jitter (stateful) to break ties among equal residuals
    r = _next_rand()
    # small jitter in [0, 1), scaled to be strictly less than 1 so it only breaks ties
    jitter = (r % 1000000) / 1000000.0
    score = score + jitter
    return score
