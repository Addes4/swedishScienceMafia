# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware residual bonus.

Items arrive online. Pure best-fit leaves small residuals that no future item can use.
Here we track the empirical distribution of item sizes and score each candidate bin by
combining (a) tightest-fit and (b) a bonus when the resulting residual matches a
frequently-seen item size, so the leftover space is likely to be fillable later.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    global _HIST, _COUNT

    # update empirical distribution with current item (known before choosing bin)
    _HIST[item] += 1.0
    _COUNT += 1

    residual = bins - item  # remaining capacity after placing item in each bin
    # tightest fit: prefer small residual
    score = -residual.astype(np.float64)

    # bonus for residuals that match a commonly seen item size (likely fillable later)
    if _COUNT > 0:
        freq = _HIST / _COUNT
        r = residual
        valid = r >= 0
        matched = np.where(valid, freq[np.clip(r, 0, 100)], 0.0)
        # strong weight to bias toward fillable leftovers
        score += 5.0 * matched

    return score
# EVOLVE-BLOCK-END
