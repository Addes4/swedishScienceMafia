# EVOLVE-BLOCK-START
"""Best fit, with a stateful residual-utility tie-break."""
import numpy as np


class _State:
    def __init__(self):
        # histogram of past item sizes (1..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (ties -> first).

    Primary criterion: best fit (smallest resulting residual).
    Secondary: prefer resulting residuals that are "useful", i.e. match sizes
    that future items commonly take, and avoid tiny shards.
    """
    st = _state
    # ---- update state with the current item before scoring ----
    if 1 <= item <= 100:
        st.hist[item] += 1.0
        st.count += 1.0

    residual = bins - item  # resulting remaining capacity

    # Best-fit ordering: smaller residual is better -> use negative residual.
    # Scale so the secondary criterion can never override the primary one
    # (residuals are integers, gaps of at least 1).
    base = -residual.astype(np.float64) * 100.0

    # Secondary utility of the resulting residual.
    r = residual.astype(np.int64)
    # Probability-like weight that a future item exactly fills the residual.
    if st.count > 0:
        match = st.hist[r] / st.count
    else:
        match = np.zeros_like(base)

    # Penalize leaving a residual of 0? No -- exact fill is good (match handles it).
    # Mild bonus for residuals that are common item sizes; slight penalty for
    # residuals in a low-probability zone (tiny unusable shards and odd gaps).
    bonus = 30.0 * match

    return base + bonus
# EVOLVE-BLOCK-END
