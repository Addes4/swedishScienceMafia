# EVOLVE-BLOCK-START
"""Best fit with a smooth preference for tight fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Exponential decay on residual: sharply prefers tightest fit (residual 0),
    # but keeps smooth ordering so near-ties behave like best-fit.
    return -np.exp(residual / 8.0)
# EVOLVE-BLOCK-END

