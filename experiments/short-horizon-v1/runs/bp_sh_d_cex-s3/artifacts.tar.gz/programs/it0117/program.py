# EVOLVE-BLOCK-START
"""Distribution-aware best fit: best fit primary, bonus when the residual can be
exactly filled by a frequent observed item size."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)
        self.n = 0

    def update(self, item):
        self.hist[item] += 1.0
        self.n += 1


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    st = _state
    st.update(item)

    # Primary: best fit (smaller residual is better) -> negative residual.
    residual = bins - item  # >= 0 guaranteed since item fits

    # Empirical frequency of each size; normalized probability.
    if st.n > 0:
        prob = st.hist / st.n
    else:
        prob = st.hist

    # Probability mass of sizes <= some threshold we may exactly fill.
    # Bonus for residuals that are common exact-fill targets.
    bonus = proc = np.zeros_like(residual, dtype=np.float64)
    # map residual to probability of that exact size up to 100
    r = np.clip(residual, 0, 100).astype(np.int64)
    bonus = prob[r]
    # scale bonus so it breaks ties but doesn't overwhelm best fit
    return -residual + 0.5 * bonus
# EVOLVE-BLOCK-END
