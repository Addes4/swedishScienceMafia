# EVOLVE-BLOCK-START
"""Almost-Worst-Fit (AWF) with best-fit fallback.

Classic AWF: place the item in the fullest bin whose residual after placement is
within [item/2, item] (i.e. leaves a gap no more than half the item). If no such
bin exists, fall back to best-fit (tightest residual). This consolidates items
and avoids scattering small items into near-empty bins.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item
    # AWF window: residual in (item/2, item]  -> prefer fullest (smallest residual)
    # Score: high for bins inside the window, ordered by how full (smaller residual), else best-fit.
    lo = item / 2.0
    in_win = (residual > lo) & (residual <= item)
    # primary: 1 if in window else 0; secondary: smaller residual better
    # Encode as a single float score: window membership dominates.
    score = in_win.astype(np.float64) * 1000.0 - residual.astype(np.float64) * 1e-3
    return score
# EVOLVE-BLOCK-END
