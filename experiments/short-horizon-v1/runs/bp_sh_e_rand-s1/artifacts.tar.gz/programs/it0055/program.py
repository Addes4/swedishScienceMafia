# EVOLVE-BLOCK-START
"""Best-fit, but keep enough residual for likely future items when packing small ones."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    st = _state
    st["n"] += 1
    st["sum"] += item
    mean = st["sum"] / st["n"]

    residual = bins - item  # remaining capacity after placing item

    if item >= 50:
        # Large items: strict best fit to pack tightly.
        return -residual.astype(np.float64)

    # Smaller items: best fit, but among the tightest options prefer a bin
    # that does not leave a uselessly small residual (below ~mean/3).
    floor = max(1.0, mean / 3.0)
    penalty = np.where(residual < floor, (floor - residual) * 2.0, 0.0)
    return -residual.astype(np.float64) - penalty
# EVOLVE-BLOCK-END
