# EVOLVE-BLOCK-START
"""Best fit with a small "sliver consolidation" tie-break.

Plain best-fit (put the item in the bin it fits most tightly) is a strong, robust
online rule for Weibull-shaped items.  Here we keep best-fit as the primary
criterion but add a small bonus for bins whose post-placement residual would be
below a running estimate of the smallest item size seen so far.  Such "slivers"
are unlikely to ever be used again, so we nudge the choice toward creating them
in already-full bins rather than leaving them scattered, which slightly improves
packing without hurting the tight-fit behaviour.
"""
import numpy as np


_state = {"min_item": 100.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running estimate of the smallest item size seen (EMA toward small values).
    if item < _state["min_item"]:
        _state["min_item"] = item
    else:
        # slowly drift upward so the threshold adapts to the distribution
        _state["min_item"] = 0.999 * _state["min_item"] + 0.001 * item

    residual = bins - item  # >= 0 since only fitting bins are shown

    # Primary: tightest fit (smallest residual).  Secondary: bonus for tiny residuals.
    score = -residual.astype(np.float64)

    # Bonus when the residual falls below the running small-item estimate.
    thr = _state["min_item"]
    bonus = np.where(residual < thr, 1.0, 0.0)
    score += bonus

    return score
# EVOLVE-BLOCK-END
