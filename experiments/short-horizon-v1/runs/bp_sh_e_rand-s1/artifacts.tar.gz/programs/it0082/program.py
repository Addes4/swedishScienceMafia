# EVOLVE-BLOCK-START
"""Best fit with an explicit bonus for exact fills (zero residual)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tighter fit (smaller residual) is better -> use negative residual.
    # Strong extra bonus for exact fills (residual == 0) so full bins are created
    # rather than leaving near-full bins that can only accept tiny items.
    score = -residual.astype(np.float64)
    score += (residual == 0).astype(np.float64) * 1000.0
    return score
# EVOLVE-BLOCK-END

