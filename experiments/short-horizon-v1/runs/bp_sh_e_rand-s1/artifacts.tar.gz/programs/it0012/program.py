# EVOLVE-BLOCK-START
"""Best fit with a light, stateful large-item residual shaping.

Plain best fit (smallest leftover) is a strong online rule for this item
distribution.  We keep it as the primary criterion but, for items that are
larger than the running average, we slightly reshape the score to steer the
post-placement leftover toward a target of about half a typical item.  The
adjustment is small so it never overrides a clearly better best-fit choice.
"""
import numpy as np


class _State:
    __slots__ = ("n", "total")

    def __init__(self):
        self.n = 0
        self.total = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin; highest wins, first on ties."""
    st = _state
    st.n += 1
    st.total += item
    mean = st.total / st.n

    leftover = bins - item  # remaining capacity after placing the item

    # Primary term: strongly prefer the smallest leftover (best fit).
    score = -leftover.astype(np.float64)

    # For large items (>= running mean), nudge toward a target leftover that
    # tends to be fillable by later items, without disturbing best fit much.
    if item >= mean:
        target = 0.5 * mean
        score -= 0.01 * np.abs(leftover - target)

    return score
# EVOLVE-BLOCK-END
