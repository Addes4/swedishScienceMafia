# EVOLVE-BLOCK-START
"""Harmonic-inspired online bin choice: steer items toward low-waste residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem_after = bins - item  # residual capacity after placing the item, >= 0

    # Primary: prefer tightest fit (smallest residual after placement) -> best fit.
    # We encode a secondary preference: among near-equal residuals, prefer bins that
    # are already partially used (smaller original residual) to consolidate.
    score = rem_after.astype(np.float64)

    # Small tie-break: strongly prefer exact fills, then tight fits.
    # Add a tiny fraction of the original residual so that, when rem_after ties,
    # the fuller bin (smaller bins) wins.
    score = score * 1024.0 + bins.astype(np.float64)

    # Highest score = most preferred; we want smallest rem_after, so negate.
    return -score
# EVOLVE-BLOCK-END
