# EVOLVE-BLOCK-START
"""Best fit with a small index-based tie-break to consolidate residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary: best fit (smallest post-placement residual). Secondary (tiny): prefer
    lower bin indices so equal-residual bins consolidate instead of spreading.
    """
    residual = bins - item
    n = residual.shape[0]
    # Tiny index penalty ensures ties among identical residuals go to the earliest bin.
    idx = np.arange(n, dtype=np.float64)
    return -residual.astype(np.float64) - idx * 1e-6
# EVOLVE-BLOCK-END
