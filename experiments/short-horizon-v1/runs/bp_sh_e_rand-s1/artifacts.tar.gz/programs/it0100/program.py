# EVOLVE-BLOCK-START
"""Almost-exact best fit: prefer exact/near-exact fills, then tightest residual."""
import numpy as np


def priority(item, bins):
    """Score each bin; the item goes to the highest score (first bin on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: bucket the residual so that very snug fits (0, 1, 2, 3) are strictly
    # preferred over looser fits; within a bucket, prefer the tightest residual.
    # Using a smooth but dominant term keeps exact fills first while still
    # ordering by residual inside each snug class.
    snug = (residual == 0).astype(np.float64)
    near = (residual <= 2).astype(np.float64)
    return -(residual.astype(np.float64)) + 300.0 * snug + 150.0 * near
# EVOLVE-BLOCK-END
