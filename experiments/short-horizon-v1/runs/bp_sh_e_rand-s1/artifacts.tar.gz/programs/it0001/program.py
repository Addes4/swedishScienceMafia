# EVOLVE-BLOCK-START
"""Best fit, with a small preference for already-used bins to avoid opening new ones."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Tightest fit first: -(remaining - item) => higher for smaller remaining.
    scores = -(bins - item)
    # Small bonus for already-used bins to discourage opening empty bins.
    used = bins < 100
    scores = scores.astype(np.float64)
    scores[used] += 1e-3
    return scores
# EVOLVE-BLOCK-END
