# EVOLVE-BLOCK-START
"""Best fit, but strongly prefer reusing partially-filled bins over opening new ones."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual_after = bins - item  # what's left if we place the item here; >= 0 for all shown bins

    # Heavily penalize unused bins (remaining capacity exactly 100): reuse first.
    unused = bins >= 100

    # Within used bins, best-fit: prefer the tightest residual after placement.
    # Among ties, prefer residuals that leave a small, easily-refillable leftover
    # rather than a large slack (so the bin stays "warm" and packable).
    score = -residual_after.astype(np.float64)
    score -= unused.astype(np.float64) * 1e6

    return score
# EVOLVE-BLOCK-END
