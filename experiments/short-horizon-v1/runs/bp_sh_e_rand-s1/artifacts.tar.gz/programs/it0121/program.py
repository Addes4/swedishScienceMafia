# EVOLVE-BLOCK-START
"""Distribution-aware best fit.

Primary: minimize residual (best fit) so we pack tightly.
Secondary: among near-equal residuals, prefer residuals that equal a likely future
item size (so the leftover is not wasted), estimated from a learned histogram.
"""
import numpy as np

_state = {"hist": np.ones(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state
    # update learned histogram of item sizes (Laplace-smoothed)
    if 1 <= item <= 100:
        st["hist"][item] += 1.0
        st["n"] += 1.0

    residual = bins - item  # >= 0 for all shown bins

    # best fit primary: smaller residual -> higher score
    score = -residual.astype(np.float64)

    # bonus: residual that matches a likely future item size (esp. complements near 100-item)
    hist = st["hist"]
    # probability mass of each residual value (0..100)
    idx = residual.astype(np.int64)
    np.clip(idx, 0, 100, out=idx)
    prob = hist[idx]
    # exact fit (residual 0) already favored; give extra weight to residuals that
    # can absorb a whole future item well (larger, fillable leftovers)
    score += 1e-3 * prob * (idx > 0)

    # tie-break: prefer emptier (unused, cap 100) bins slightly so fresh capacity is conserved
    score += 1e-6 * (bins == 100)

    return score
# EVOLVE-BLOCK-END
