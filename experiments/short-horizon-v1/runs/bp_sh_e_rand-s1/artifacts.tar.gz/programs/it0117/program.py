# EVOLVE-BLOCK-START
"""Best-fit variant: minimize a convex penalty on the post-placement residual.

Pure best fit picks the smallest residual. Tiny residuals can leave gaps too small to
ever be filled again, wasting space. Instead, penalize the residual with a convex term
plus a mild magnitude term, which biases toward placements that keep usable space.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Convex penalty on the leftover: strongly dislike near-full (tiny residual) and
    # dislike large empty waste; the minimum sits at a moderate residual.
    return -residual - 0.05 * residual * residual
# EVOLVE-BLOCK-END
