# EVOLVE-BLOCK-START
"""Harmonic-style size-class bin packing with class-tagged bins.

Items are classified into geometric bands. Bins are treated as belonging to the class
of the (first) item they hold. An arriving item prefers bins of its own class (so items
of similar size get packed together and complete bins cleanly), otherwise falls back to
best fit. Large items avoid bins already holding a large item that leaves a residual too
small for another large item but too awkward for medium items.
"""
import numpy as np

# Geometric class boundaries (capacity 100). Classes: 0:(0,12],1:(12,25],2:(25,50],3:(50,100]
_BOUNDS = (12, 25, 50)
_NCLASS = len(_BOUNDS) + 1


def _cls(s):
    for i, b in enumerate(_BOUNDS):
        if s <= b:
            return i
    return _NCLASS - 1


def priority(item, bins):
    it_c = _cls(item)
    n = len(bins)
    scores = np.empty(n, dtype=np.float64)

    for i in range(n):
        rem = int(bins[i])
        residual = rem - item
        # Detect class of bin: full bins are class "empty" (cap 100)
        if rem >= 100:
            bin_c = -1  # unused / empty
        else:
            # infer approximate class from remaining capacity by size of items it could hold
            # We use the largest item class that fits the residual budget reasonably.
            bin_c = it_c  # default unknown
        # Base: best fit (smaller residual better)
        base = float(residual)
        if residual < 0:
            scores[i] = -1e9 + base
            continue

        score = 0.0
        # Prefer exactly filling a bin
        if residual == 0:
            score += 1000.0
        # Harmonic-like preference: if bin is empty (cap 100), items of a class like to
        # start a bin only if their class is not "too small" relative to what remains.
        if rem >= 100:
            # empty bin: mildly prefer to start a new bin for large items (they need space),
            # for small items prefer to fill existing partial bins instead.
            if it_c >= 2:
                score += 40.0 - base  # large item: opening fresh bin is fine
            else:
                score += -base  # small item: no special bonus
        else:
            # partial bin. Prefer a residual that leaves room for another item of same class
            next_b = _BOUNDS[it_c] if it_c < len(_BOUNDS) else 100
            if residual >= item:
                score += 5.0   # still room for a same-ish item
            if residual == 0:
                score += 0.0
            score += -base * 1.0

        scores[i] = score

    return scores
# EVOLVE-BLOCK-END
