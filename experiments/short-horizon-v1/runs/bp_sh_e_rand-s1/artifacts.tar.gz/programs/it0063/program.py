# EVOLVE-BLOCK-START
"""Best fit with a soft exponential residual shaping."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best fit dominates: smaller residual -> higher score.
    # Secondary shaping: mildly favor residuals that are small (pack tightly).
    return -residual - 0.02 * residual * residual
# EVOLVE-BLOCK-END
