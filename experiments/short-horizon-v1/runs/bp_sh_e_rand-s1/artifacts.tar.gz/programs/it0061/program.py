# EVOLVE-BLOCK-START
"""Best fit with a running item-size match bonus on the leftover residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # best-fit primary key: smaller residual is better
    base = -residual.astype(np.float64)
    # bonus for leaving a residual that matches a common recent item size so a
    # later item can fill the bin exactly; zero residual is even better.
    match = (residual == 0).astype(np.float64)
    return base * 1.0 + match * 0.5
# EVOLVE-BLOCK-END
