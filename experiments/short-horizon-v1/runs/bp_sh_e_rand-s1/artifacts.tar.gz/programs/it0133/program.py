# EVOLVE-BLOCK-START
"""Best fit with a small bonus for residuals that are reachable by future small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (smallest residual). Give a tiny bonus to residuals that are
    # not awkward small scraps, but keep best-fit ordering dominant.
    # residuals that are >= typical item complement are slightly preferred to avoid
    # creating tiny unfillable scraps; scaled small so exact/near-exact fits still win.
    score = -(residual.astype(np.float64))
    # small nudge: penalize residuals in 1..5 (hard to fill later)
    nudge = np.where((residual >= 1) & (residual <= 5), -0.5, 0.0)
    return score + nudge
# EVOLVE-BLOCK-END
