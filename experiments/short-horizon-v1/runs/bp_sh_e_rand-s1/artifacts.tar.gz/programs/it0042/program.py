# EVOLVE-BLOCK-START
"""Best fit, tempered by a soft reserve target to delay early bin closure."""
import numpy as np

_target = [40.0]
_n = [0]


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Running mean of item sizes (bounded state).
    m = _target[0]
    n = _n[0]
    m = (m * n + item) / (n + 1)
    _target[0] = m
    _n[0] = n + 1

    residual = bins - item  # post-placement remaining capacity, >= 0

    # Target reserve: aim to keep residuals near the mean item size when possible,
    # so bins stay useful for average-sized items.
    target = 0.85 * m

    # Prefer residual as close to target as possible, but never below a small floor.
    # Score: smaller |residual - target| is better -> use negative distance.
    return -np.abs(residual - target)
# EVOLVE-BLOCK-END
