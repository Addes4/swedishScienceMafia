# EVOLVE-BLOCK-START
"""Best-fit with a tolerance band; within the band, match residual to running mean item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Running estimate of mean item size, kept in a module-level dict so state
    # survives across calls within a stream (harness reimports per stream fresh).
    st = priority.__dict__
    n = st.get('n', 0)
    mean = st.get('mean', 40.0)
    # Welford-ish incremental update of the mean.
    n += 1
    mean += (item - mean) / n
    st['n'] = n
    st['mean'] = mean

    residual = bins - item            # post-placement leftover (>=0 guaranteed)

    best = residual.min()
    # Tolerance band: only consider bins whose leftover is close to the tightest.
    tol = 0.0
    band = residual <= (best + tol)

    # Within the band, prefer residual closest to the running mean item size.
    # With tol == 0 this is exactly best-fit (first tightest bin wins).
    score = -np.abs(residual - mean)
    score = np.where(band, score, -1e9)
    return score
# EVOLVE-BLOCK-END
