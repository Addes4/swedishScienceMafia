# EVOLVE-BLOCK-START
"""Stateful best-fit with residual-matching tie-break based on running mean size."""
import numpy as np


def priority(item, bins):
    """Rank bins by best-fit, breaking near-ties toward usable residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (capacity 100), in bin order.
    """
    residual = bins - item  # post-placement leftover (>= 0 since item fits)

    # Running statistics of past items (state kept across calls in this module).
    n = priority.n
    s = priority.s
    priority.n = n + 1
    priority.s = s + item
    mean = (s + item) / (n + 1) if (n + 1) > 0 else 40.0

    # Primary: best fit (smallest residual). Use residual directly as the key.
    # Secondary (small): bonus for residuals that are "usable" relative to the mean,
    # i.e. close to a typical future item size, avoiding tiny unusable remnants.
    # Scale the bonus small so it only breaks near-ties in residual.
    target = mean
    match = -np.abs(residual - target)  # higher is better when residual near target
    # Normalize match to [0,1]-ish and keep it small versus residual differences.
    score = -residual + 0.05 * match
    return score


priority.n = 0
priority.s = 0.0
# EVOLVE-BLOCK-END
