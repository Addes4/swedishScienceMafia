# EVOLVE-BLOCK-START
"""Best fit with a light historical-residual tie-break."""
import numpy as np


class _State:
    def __init__(self):
        # small histogram of recent item sizes (1..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0

    def update(self, item):
        self.hist[item] += 1.0
        self.count += 1.0
        if self.count > 4000.0:
            self.hist *= 0.5
            self.count *= 0.5


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    _state.update(item)

    residual = bins - item  # always >= 0 since bins are only those that fit

    # Dominant term: best fit (smallest positive residual).
    score = -residual.astype(np.float64)

    # Light tie-break: reward exactly closing a bin, or leaving a residual
    # that matches a frequently seen item size (so it can be closed later).
    freq = _state.hist
    tie = np.zeros_like(score)
    closed = (residual == 0)
    tie[closed] += 1.0
    pos = ~closed
    if np.any(pos):
        r = residual[pos]
        valid = (r >= 1) & (r <= 100)
        add = np.zeros(r.shape, dtype=np.float64)
        idx = r[valid]
        add[valid] = freq[idx] / max(_state.count, 1.0)
        tie[pos] = add
    # Scale so it never overrides a one-unit best-fit difference.
    return score + 0.001 * tie
# EVOLVE-BLOCK-END
