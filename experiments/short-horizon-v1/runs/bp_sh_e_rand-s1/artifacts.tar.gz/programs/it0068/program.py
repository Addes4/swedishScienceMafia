# EVOLVE-BLOCK-START
"""Best fit with tie-break toward the emptiest bin to reduce stranding."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize residual (best fit). Secondary: for equal residuals,
    # prefer the bin with larger current remaining capacity (emptier bin),
    # so leftovers are consolidated rather than scattered in nearly-full bins.
    return -residual * 1024 + bins
# EVOLVE-BLOCK-END

