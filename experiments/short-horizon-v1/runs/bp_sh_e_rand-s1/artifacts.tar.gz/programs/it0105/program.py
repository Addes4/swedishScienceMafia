# EVOLVE-BLOCK-START
"""Best fit refined by a mean-residual consolidation preference."""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    b = bins.astype(np.float64)
    resid = b - item                     # remaining capacity after placement
    # Primary: prefer exact fits (resid == 0).
    exact = (resid == 0).astype(np.float64)
    # Secondary: prefer residuals below the typical future item size (~mean 40),
    # so the bin becomes "sealed" instead of leaving a gap too small to reuse well.
    below = (resid < _MEAN).astype(np.float64)
    # Tertiary: tighter fit is still better.
    tight = -resid
    return exact * 1e6 + below * 1e3 + tight
# EVOLVE-BLOCK-END
