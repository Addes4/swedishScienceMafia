# EVOLVE-BLOCK-START
"""Best fit with a mild reservation of exactly-closing bins for larger items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Dominant term: classic best fit (tightest remaining capacity wins).
    score = -residual.astype(np.float64)
    # Tiny bounded secondary: discourage small items from exactly closing a bin,
    # reserving such bins for larger items that would otherwise not fit as tightly.
    if item < 40:
        score[residual == 0] -= 0.5
    return score
# EVOLVE-BLOCK-END
