# EVOLVE-BLOCK-START
"""Best-fit with a bounded "safe residual" preference for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    fits = bins >= item
    residual = np.where(fits, bins - item, -1)
    base = -residual.astype(float)

    # Stateful running mean of recent items, used to define a "safe" residual threshold.
    if not hasattr(priority, "mean"):
        priority.mean = 40.0
        priority.n = 0
    priority.n += 1
    alpha = 2.0 / (min(priority.n, 50) + 1.0)
    priority.mean = (1.0 - alpha) * priority.mean + alpha * item
    mean = priority.mean

    # Only adjust for items that are clearly smaller than typical (they cause the waste).
    if item <= 0.5 * mean:
        # Prefer bins that, after placement, leave a residual near the mean so the
        # leftover space is likely to be usable by a future item (pairing).
        target = mean
        # Small bonus for residuals close to the mean, but strictly dominated by best-fit.
        bonus = -np.abs(residual - target) * 1e-3
    else:
        bonus = 0.0

    return base + bonus
# EVOLVE-BLOCK-END
