# EVOLVE-BLOCK-START
"""Best fit with a mean-residual tie-break.

Primary rule: best fit (smallest post-placement residual).
Tie-break: among bins whose residuals are essentially tied, prefer the bin whose
post-placement residual is closest to the running mean item size seen so far,
aiming to leave a gap that a typical future item can fill.
"""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    _count += 1
    _mean += (item - _mean) / _count

    residual = bins - item  # remaining capacity after placing the item here

    # Dominant key: best fit (smallest residual -> highest score).
    best = -residual

    # Tiny secondary term: residual closest to running mean gets a small bonus.
    # Weight is far smaller than the integer gap of 1 in the best-fit key,
    # so it only breaks exact ties in the best-fit score.
    tie = 1.0 / (1.0 + np.abs(residual - _mean))

    return best + 1e-3 * tie
# EVOLVE-BLOCK-END
