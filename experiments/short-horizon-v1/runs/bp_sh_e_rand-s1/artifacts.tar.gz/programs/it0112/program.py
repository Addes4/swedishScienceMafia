# EVOLVE-BLOCK-START
"""Best fit with a stateful 'usable residual' bonus.

Pure best-fit leaves tiny unusable gaps. Here we still primarily prefer the
tightest fit, but we keep a running histogram of observed item sizes and add a
small bonus for bins whose post-placement residual matches a size we are likely
to see again, so leftover space stays fillable.
"""
import numpy as np

_STATE = {"hist": np.zeros(101, dtype=np.float64), "n": 0.0}


def _common_size_prob(r):
    """Probability-ish weight that residual r is a commonly seen item size."""
    if r <= 0:
        return 0.0
    h = _STATE["hist"]
    n = _STATE["n"]
    if n < 30.0:
        # Not enough data yet: fall back to a mild smoothing.
        return 0.5
    # normalized frequency of exactly this size, smoothed
    p = (h[int(r)] + 1.0) / (n + 101.0)
    return p


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    # update state with this item (past-only information is fine here)
    _STATE["hist"][int(item)] += 1.0
    _STATE["n"] += 1.0

    bins = np.asarray(bins, dtype=np.float64)
    new_res = bins - float(item)

    # primary: smaller post-placement residual is better
    score = -new_res

    # bonus: residual that matches a likely future item size stays usable
    # scale the bonus small enough not to override the tightest fit ordering
    # but large enough to break near-ties and reward fillable gaps.
    scale = 30.0
    for idx in range(new_res.shape[0]):
        r = new_res[idx]
        if r > 0:
            score[idx] += scale * _common_size_prob(r)

    return score
# EVOLVE-BLOCK-END
