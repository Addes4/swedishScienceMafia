# EVOLVE-BLOCK-START
"""Best fit with a bounded frequency-based residual tie-break.

Primary rule: best fit (minimize post-placement residual). A small, bounded
secondary term rewards a post-placement residual that matches a frequently seen
recent item size, so future arrivals can close the bin exactly. The secondary
term is too small to override genuine best-fit differences.
"""
import numpy as np

# State: exponentially decayed histogram of recently seen item sizes.
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    global _TOTAL
    # Update running histogram (recency-weighted) with the arriving item.
    _HIST *= 0.99
    _HIST[item] += 1.0
    _TOTAL = _TOTAL * 0.99 + 1.0

    residual = bins - item  # post-placement residual, always >= 0
    # Primary: best fit -> maximize the negative residual.
    score = -residual.astype(np.float64)

    # Secondary: small bonus if residual is a common size or zero.
    if _TOTAL > 0:
        freq = _HIST / _TOTAL
        # bonus in [0, 1) per residual value, scaled tiny.
        bonus = freq[np.clip(residual, 0, 100)]
        bonus[residual == 0] += 1.0
        score += 1e-3 * (bonus / (1.0 + bonus))
    return score
# EVOLVE-BLOCK-END
