# EVOLVE-BLOCK-START
"""Best fit, with a tiny stateful guard against leaving unfillable residuals."""
import numpy as np


class _State:
    def __init__(self):
        self.min_size = 100
        self.count = 0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary key: best fit (smallest residual after placement).
    Guard: if the tightest residual would be a tiny unfillable scrap (< smallest item
    size seen so far), prefer among nearly-as-tight bins the one leaving a residual that
    is still >= that minimum, so the space stays usable for future items.
    """
    # Update running state with the arriving item.
    if item < _state.min_size:
        _state.min_size = item
    _state.count += 1
    minsz = _state.min_size

    residual = bins - item  # remaining capacity after placing item (all >= 0)
    bestfit = -residual.astype(np.float64)  # higher = tighter

    # If the tightest fit leaves a scrap (< minsz), demote bins whose residual < minsz
    # relative to those whose residual stays usable.
    tight = residual.min()
    if tight > 0 and tight < minsz:
        # usable residuals (>= minsz) get a bonus so they beat scrap-leaving bins.
        usable = residual >= minsz
        return bestfit + usable.astype(np.float64) * 1000.0

    return bestfit
# EVOLVE-BLOCK-END
