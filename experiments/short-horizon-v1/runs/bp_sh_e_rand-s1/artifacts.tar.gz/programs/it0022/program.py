# EVOLVE-BLOCK-START
"""Best fit with residual matching bonus against recent item sizes."""
import numpy as np


class _State:
    def __init__(self):
        # recent item size counts, decaying
        self.seen = np.zeros(101, dtype=np.float64)
        self.count = 0

    def observe(self, item):
        self.seen *= 0.995
        self.seen[item] += 1.0
        self.count += 1


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _state.observe(item)

    leftover = bins - item  # >= 0 since bins only contains fitting bins

    # Base: best fit => smallest leftover gets highest score
    score = -leftover.astype(np.float64)

    # Bonus: if residual matches a common recent item size, prefer it.
    # seen[k] is (decayed) frequency of item size k in this stream.
    seen = _state.seen
    freq = seen[leftover]
    # Normalize so bonus is at most ~0.5 (less than 1 residual unit)
    bonus = 0.5 * freq / (1.0 + freq)
    score = score + bonus

    return score
# EVOLVE-BLOCK-END
