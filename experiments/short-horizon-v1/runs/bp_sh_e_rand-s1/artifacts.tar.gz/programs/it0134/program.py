# EVOLVE-BLOCK-START
"""Best fit, but avoid opening a fresh bin while a used bin can still fit the item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Bins that already hold items have residual < 100; unused bins have residual == 100.
    usable = bins > item  # every bin shown already fits the item
    used = bins < 100
    has_used = bool(np.any(np.logical_and(used, usable)))

    # Best-fit key: prefer the smallest residual that still holds the item.
    score = -(bins - item)

    if has_used:
        # Penalize unused (empty) bins so they are chosen only as a last resort.
        score = score - 1000.0 * (~used)

    return score
# EVOLVE-BLOCK-END
