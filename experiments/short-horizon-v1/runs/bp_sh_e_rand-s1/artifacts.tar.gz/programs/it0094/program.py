# EVOLVE-BLOCK-START
"""Best-fit with a tiny, deterministic tie-perturbation to explore near-fit bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary rule: best-fit (tightest post-placement residual).
    Secondary: a small deterministic bonus that occasionally favors a bin leaving a
    "reusable" residual, without disturbing the pure best-fit choice on small streams.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Dominant best-fit term: smaller residual => higher score.
    score = -100.0 * residual.astype(np.float64)

    # Tiny deterministic perturbation: prefer residuals near a mid-size reusable value.
    # Kept very small so it only breaks near-ties.
    pen = np.abs(residual - 20).astype(np.float64)
    score -= 0.01 * pen

    return score
# EVOLVE-BLOCK-END
