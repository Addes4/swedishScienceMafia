# EVOLVE-BLOCK-START
"""Best fit with a small 'don't waste tiny gaps' bonus.

Primary criterion: tightest post-placement residual (best fit), which is optimal on
short streams.  Small bonus: discourage leaving a residual smaller than a typical
item can fill, tracked online from past items.
"""
import numpy as np

_state = {"useful": 0.0, "_sizes": []}


def _update(item):
    s = _state["_sizes"]
    s.append(int(item))
    n = len(s)
    if n >= 20:
        # low percentile estimate of a "small but usable" item size
        arr = np.asarray(s, dtype=np.int64)
        lo = int(np.percentile(arr, 15))
        _state["useful"] = float(max(lo, 1))
    else:
        _state["useful"] = 0.0


def priority(item, bins):
    """Rank bins; item goes to highest score (first on ties)."""
    _update(item)
    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item
    useful = _state["useful"]
    if useful <= 0.0:
        return -residual.astype(np.float64)
    # dominant tight-fit term, tiny bonus for not creating a wasted gap
    bonus = (residual >= useful) & (residual >= 0)
    return -(residual.astype(np.float64)) + 0.5 * bonus.astype(np.float64)
# EVOLVE-BLOCK-END
