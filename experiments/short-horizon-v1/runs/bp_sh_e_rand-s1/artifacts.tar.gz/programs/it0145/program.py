# EVOLVE-BLOCK-START
"""Harmonic-style best fit: classify bins into residual size classes, then best-fit within class."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Uses a harmonic classification of residual capacity. For a fixed set of thresholds,
    bins fall into size classes by their residual. We prefer the smallest class that can
    still hold the item (that class has bins with residual >= item but as small as possible),
    and within that class use best-fit (tightest residual).
    """
    # Thresholds define class boundaries. Class 0 is the tightest meaningful class.
    # Geometric-ish spacing tuned for item sizes ~40 on capacity 100.
    thresholds = np.array([10, 15, 22, 33, 50, 100], dtype=np.int64)

    # Class index for each bin: number of thresholds strictly less than residual.
    # Small residual -> small class.
    cls = np.searchsorted(thresholds, bins, side='left')

    # For the arriving item, we want the smallest class whose lower bound >= item...
    # Actually we want: among bins that fit (residual >= item), pick the class with the
    # smallest lower-bound that is still >= item. Simpler: pick the smallest class among
    # fitting bins, then best-fit within it.
    fits = bins >= item
    # Assign each fitting bin a class, non-fitting bins get the worst (largest) score.
    big = np.int64(1 << 30)
    cls_fit = np.where(fits, cls, big)

    # Choose minimal class among fitting bins.
    min_cls = np.min(cls_fit)
    # Score: prefer bins in min_cls, and within that, tightest residual (best-fit).
    # Encode as: primary = whether in min_cls, secondary = -residual.
    in_class = (cls == min_cls) & fits
    score = np.where(in_class, -bins, -big)
    return score
# EVOLVE-BLOCK-END
