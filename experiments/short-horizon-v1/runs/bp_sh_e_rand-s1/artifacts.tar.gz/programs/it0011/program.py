# EVOLVE-BLOCK-START
"""Best-fit with a residual-fillability tie-break.

Primary objective: put the item in the bin it fits most tightly (minimize residual).
Tie-break: among bins leaving the same residual, prefer residuals that are likely to be
filled later (0, or a common item size), and mildly penalize residuals in the awkward
tiny range that tends to be wasted.
"""
import numpy as np

# A gentle preference curve for the leftover after placement.
# 0 is best (exact fill), tiny remainders (1..5) are somewhat wasteful,
# remainders that correspond to common item sizes (Weibull mean ~40) are good.
_IDEAL = np.zeros(101, dtype=np.float64)
for _r in range(101):
    _IDEAL[_r] = 0.0
# reward exact fills and roundish leftovers a bit
_IDEAL[0] = 1.0
for _r in (10, 20, 25, 30, 35, 40, 45, 50, 60, 75, 100):
    _IDEAL[_r] += 0.05
# penalize tiny useless leftovers
for _r in range(1, 6):
    _IDEAL[_r] -= 0.08


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item
    # Main term: smaller residual is better, so negate it and scale strongly.
    score = -residual.astype(np.float64) * 4.0
    # Secondary: fillability preference of the resulting leftover.
    score += _IDEAL[np.clip(residual, 0, 100)]
    return score
# EVOLVE-BLOCK-END
