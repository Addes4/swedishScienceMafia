# EVOLVE-BLOCK-START
"""Best fit plus a state-driven 'keep leftover usable' bonus.

Plain best fit places each item in the tightest gap.  It can waste a bin by leaving a
tiny unusable residual.  We keep per-stream state (a running mean of past item sizes)
and add a small bonus for bins whose post-placement leftover is large enough to still
accept a typical future item, while keeping best fit as the dominant term.
"""
import numpy as np

_INIT_MEAN = 40.0


def _state():
    st = getattr(_state, "_st", None)
    if st is None:
        st = {"n": 0, "sum": 0.0, "mean": _INIT_MEAN}
        _state._st = st
    return st


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    st = _state()
    mean = st["mean"]
    st["n"] += 1
    st["sum"] += item
    st["mean"] = st["sum"] / st["n"]

    leftover = bins - item  # remaining capacity after placing (>= 0 since bins all fit)

    # Primary: best fit -> prefer the smallest leftover.
    best_fit = -leftover

    # Secondary: mildly reward leftovers that can still hold a typical item.
    usable = (leftover >= mean).astype(np.float64)
    # reward being close to a whole multiple of the typical item (fewer wasted gaps)
    ratio = leftover / mean
    frac = np.abs(ratio - np.round(ratio))
    tidy = 1.0 - frac

    return best_fit + 0.25 * usable + 0.15 * tidy
# EVOLVE-BLOCK-END
