# EVOLVE-BLOCK-START
"""Best fit with a stable, bounded 'reserve nearly-closed bins from tiny items' rule."""
import numpy as np

_MEAN = 40.0
_SEEN = 0

def priority(item, bins):
    global _MEAN, _SEEN
    # Update a stable running mean of item sizes (starts at the distribution mean).
    _SEEN += 1
    _MEAN += (item - _MEAN) / _SEEN
    small = item < 0.6 * _MEAN

    residual = bins - item  # >= 0 for all bins shown

    # Primary: best fit (smallest residual) dominates.
    score = -residual.astype(np.float64)

    # Secondary (bounded, small enough never to override a strictly better fit):
    # for small items, softly avoid leaving a nearly-closed bin (residual in (0, small)).
    if small:
        avoid = (residual > 0) & (residual < item)
        score = score - 0.5 * avoid
    return score
# EVOLVE-BLOCK-END

