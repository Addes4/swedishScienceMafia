# EVOLVE-BLOCK-START
"""Best-fit with a histogram-based near-tie break to reduce leftover scraps."""
import numpy as np


class _State:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)  # size histogram, index 1..100
        self.total = 0.0
        self.n = 0

    def observe(self, item):
        if 1 <= item <= 100:
            self.counts[item] += 1.0
        self.total += item
        self.n += 1


_state = _State()


def priority(item, bins):
    """Rank bins: best-fit primary, near-tie broken by residual usefulness."""
    _state.observe(item)

    # Residual = space left after placing the item.
    residual = bins - item

    # Reachability proxy: can this residual be exactly filled by one typical future item?
    # Use running histogram to estimate probability a future item equals residual exactly.
    p_single = _state.counts / max(_state.n, 1.0)

    # Primary best-fit key: prefer smallest residual (most negative score for largest residual).
    score = -residual.astype(np.float64)

    # Among near-best fits, give a small bonus when the residual is likely fillable exactly
    # by a single future item (exact complement), and a small penalty for tiny scraps.
    if len(bins) > 0:
        r_float = residual.astype(np.float64)
        best_r = residual.min()
        window = 6.0  # consider residuals within 6 of the best fit as near-ties

        gain = np.zeros_like(r_float)
        valid = (residual >= 1) & (residual <= 100)
        # exact-fill bonus from histogram
        bonus = np.where(valid, p_single[np.clip(residual, 0, 100)], 0.0)
        # penalize very small unfillable scraps slightly (residual 1..3)
        scrap_pen = np.where(valid & (residual <= 3), 0.35, 0.0)

        near = (r_float - best_r) <= window
        gain = np.where(near, 2.0 * bonus - scrap_pen, 0.0)
        score = score + gain

    return score
# EVOLVE-BLOCK-END
