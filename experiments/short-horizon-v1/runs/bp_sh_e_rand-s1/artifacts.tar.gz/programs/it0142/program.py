# EVOLVE-BLOCK-START
"""Best fit with stateful scrap-avoidance using a tracked minimum usable residual."""
import numpy as np


class _State:
    def __init__(self):
        self.sizes = []
        self.count = 0

    def push(self, item):
        self.sizes.append(int(item))
        self.count += 1
        if len(self.sizes) > 200:
            self.sizes.pop(0)


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    _state.push(item)

    sizes = _state.sizes
    if len(sizes) >= 20:
        # smallest item size seen recently, used to judge "usable" residuals
        min_usable = int(np.min(sizes))
    else:
        min_usable = 1

    bins = np.asarray(bins)
    residual = bins - item  # leftover if placed here

    # primary key: tighter fit is better (smaller residual)
    key = -residual.astype(np.float64)

    # scrap penalty: residuals in (0, min_usable) are unusable scraps;
    # push them down so a bin leaving a usable residual is preferred when close.
    scrap = (residual > 0) & (residual < min_usable)
    key = key - scrap.astype(np.float64) * 0.5

    return key
# EVOLVE-BLOCK-END
