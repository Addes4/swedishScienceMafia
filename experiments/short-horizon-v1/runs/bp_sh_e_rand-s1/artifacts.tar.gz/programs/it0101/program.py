# EVOLVE-BLOCK-START
"""Harmonic-style banded best-fit.

Group bins by the residual they would leave after placing the item, then
prefer placements that keep the residual in a "large reusable" band rather
than an awkward tiny leftover, while still favoring tighter fits within a band.
"""
import numpy as np

# Residual band boundaries (capacity is 100).  The idea: a leftover residual
# is "reusable" only if it is at least as large as a typical remaining item.
# We segment [0,100] into bands and rank placements by band, then by residual.
_BANDS = np.array([0, 1, 11, 21, 31, 41, 61, 81, 101], dtype=np.int64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in, in bin order.
    """
    residual = bins - item  # >= 0 guaranteed by the harness

    # Band index: which residual bucket does this placement land in?
    # np.searchsorted gives the position in _BANDS; smaller index = smaller residual.
    band = np.searchsorted(_BANDS, residual, side="right")

    # Within the smallest band prefer tightest fit; but we want to *avoid*
    # tiny useless residuals (bands 0/1/2).  Reward larger bands mildly so
    # leftover capacity stays reusable, with exact fit (residual 0) special-cased
    # as it is always strictly optimal.
    exact = (residual == 0).astype(np.float64)

    # Primary key: exact-fit bonus.  Secondary: band (larger band preferred so
    # we don't strand tiny leftovers), tertiary: tightest residual within band.
    score = exact * 1e6 + band.astype(np.float64) * 1000.0 - residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
