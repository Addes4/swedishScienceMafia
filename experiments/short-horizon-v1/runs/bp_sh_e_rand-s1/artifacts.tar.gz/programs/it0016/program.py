# EVOLVE-BLOCK-START
"""Hybrid: large items go to the least-loaded fitting bin, small items use best fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item >= 50:
        # Large item: prefer the emptiest fitting bin (largest remaining capacity).
        return bins
    # Small item: best fit -> smallest leftover.
    return -(bins - item)
# EVOLVE-BLOCK-END

