# EVOLVE-BLOCK-START
"""Baseline: best fit, with an exact-completion tie-break among residual ties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smallest residual (best fit). Secondary: prefer exact completion (residual 0),
    # which only matters when two bins tie on residual.
    return -(residual.astype(np.float64) * 2.0) + (residual == 0).astype(np.float64)
# EVOLVE-BLOCK-END

