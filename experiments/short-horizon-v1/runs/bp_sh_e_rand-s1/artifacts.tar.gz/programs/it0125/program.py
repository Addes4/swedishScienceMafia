# EVOLVE-BLOCK-START
"""Best fit with a stateful gap-usability tie-break.

Primary objective: fill the bin as tightly as possible (best fit).
Tie-break: among near-tight fits, prefer a residual that a likely future
item (drawn from the empirical size distribution seen so far) can fill,
so we avoid leaving unfillable fragments.
"""
import numpy as np

_state = {"n": 0.0, "mean": 40.0, "hist": np.zeros(101), "total": 0}


def _observe(item):
    h = _state["hist"]
    if item <= 100:
        h[item] += 1.0
    _state["total"] += 1
    n = _state["n"] + 1.0
    _state["mean"] += (item - _state["mean"]) / n
    _state["n"] = n


def _fill_prob(cap):
    """Probability-ish score that a residual capacity `cap` is fillable."""
    if cap <= 0:
        return 0.0
    # Blend: high chance for tiny residuals (small items are common),
    # plus bonus if residual matches popular item sizes.
    h = _state["hist"]
    tot = h.sum()
    if tot <= 0:
        return 1.0 if cap < 20 else 0.0
    # probability of an item <= cap existing (fillable at all)
    p_le = h[1:cap + 1].sum() / tot if cap <= 100 else 1.0
    # bonus if some single item equals cap exactly
    p_eq = (h[cap] / tot) if 1 <= cap <= 100 else 0.0
    return p_le * 0.5 + p_eq * 2.0


def priority(item, bins):
    _observe(item)
    residual = bins - item  # post-placement remaining capacity (>=0)
    # Primary: tightest fit => smallest residual is best.
    primary = -residual.astype(np.float64)
    # Secondary: prefer residuals that are usable (fillable by future items)
    # but a nonzero small residual is better than a large unusable one only
    # when it can be filled. Score fillability of the residual.
    r = residual
    fill = np.where(r <= 0, 0.0, 0.0)
    # vectorized fillability approximation using running mean:
    mean = _state["mean"]
    # residual near 0 (exact fit) is ideal; large residual is a fresh-ish bin.
    # Encourage residuals that are multiples/close to typical item size.
    good = -np.abs(r - mean) / 100.0
    # exact fit gets a strong bonus
    exact = (r == 0).astype(np.float64) * 1.0
    return primary + 0.25 * (good + exact)
# EVOLVE-BLOCK-END
