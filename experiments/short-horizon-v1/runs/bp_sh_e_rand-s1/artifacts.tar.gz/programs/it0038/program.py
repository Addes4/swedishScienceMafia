# EVOLVE-BLOCK-START
"""Best-fit with a reserve: prefer the bin with the smallest residual that is still
at least a running target size, so small items keep away from almost-full bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    rem = bins - item  # post-placement residual, >= 0 for every shown bin

    # Running statistics of past items, kept as module-level state.
    hist = priority.hist
    total = priority.total + 1
    priority.total = total
    if item <= 100:
        hist[item] += 1

    mean = total and (priority.sum + item) / total or item
    priority.sum += item

    # Target residual: keep small items from closing near-full bins that a
    # typical item could later fill exactly.
    target = max(1.0, 0.35 * mean)

    # Ones where residual is below target are "too tight": penalize them more
    # the closer they are to zero (those bins should wait for an exact filler).
    too_tight = rem < target
    penalty = np.where(too_tight, (target - rem) / target, 0.0)

    # Primary: prefer small residual (tight fit), but subtract the penalty so
    # that a slightly larger residual can win over an almost-closed bin.
    return -(rem.astype(np.float64) - penalty * mean * 0.6)


priority.hist = np.zeros(101, dtype=np.int64)
priority.total = 0
priority.sum = 0.0
# EVOLVE-BLOCK-END
