# EVOLVE-BLOCK-START
"""Adaptive reserve best-fit: prefer tight fits but keep leftovers reusable."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for bins shown

    # Score: negative residual (best fit) dominates; add a bonus when the
    # leftover is exactly 0 (perfect fill) or large enough to be reusable.
    # Threshold ~ mean item size (~40), so leftover >= 40 is treated as usable.
    bonus = np.where(residual == 0, 100.0, 0.0)
    # bonus for leaving at least a "typical" amount of room, so the bin stays useful
    bonus += np.where(residual >= 40, 2.0, 0.0)
    return -(residual) + bonus
# EVOLVE-BLOCK-END
