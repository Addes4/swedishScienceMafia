# EVOLVE-BLOCK-START
"""Best fit with scrap-avoidance.

Primary key: best fit (tightest remaining capacity after placing the item).
Secondary consideration: avoid creating tiny unfillable residuals ("scrap") that
can never be filled by a future item, by tracking the smallest item seen so far.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Best-fit key: prefer the smallest resulting residual >= 0.
    residual = bins - item  # all bins shown fit the item, so residual >= 0

    # Minimum useful residual: an empty residual (0) is great (perfect fit).
    # A residual that is positive but very small risks becoming unfillable scrap.
    rem = getattr(priority, "_min_item", None)
    if rem is None:
        rem = item
    else:
        if item < rem:
            rem = item
    priority._min_item = rem

    # Score: best fit dominates; add a mild penalty for tiny positive scrap that
    # cannot hold the smallest item seen so far.
    base = -residual.astype(np.float64)
    # scrap penalty applies only to strictly tiny positive residuals
    tiny = (residual > 0) & (residual < rem)
    base = base - 0.5 * tiny.astype(np.float64)

    return base
# EVOLVE-BLOCK-END
