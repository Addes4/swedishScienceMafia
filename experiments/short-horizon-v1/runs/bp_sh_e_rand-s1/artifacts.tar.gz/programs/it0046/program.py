# EVOLVE-BLOCK-START
"""Best fit with a small stateful bias: keep near-full bins in reserve for large items."""
import numpy as np

_state = {"sum": 0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["sum"] += item
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]

    residual = bins - item  # >= 0 for all shown bins

    # Dominant term: best fit (smallest residual gets highest score).
    score = -(residual.astype(np.float64))

    # For small/mid items, if placing here would leave the bin nearly full
    # (residual well below half the mean), add a small penalty so that the
    # bin is more likely to be completed exactly by a future large item.
    threshold = mean * 0.5
    small = residual < threshold
    score[small] -= (threshold - residual[small]) * 0.05 * (item < mean)

    return score
# EVOLVE-BLOCK-END
