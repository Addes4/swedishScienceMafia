# EVOLVE-BLOCK-START
"""Best-fit with a stateful mean-based split: for very large items use best fit,
but for items near the typical size prefer the fuller bin to compact residual space."""
import numpy as np


def priority(item, bins):
    # Best fit: minimize post-placement residual (i.e., prefer fullest bin that fits).
    # Slight tie-break: for the tightest residuals, prefer the bin with smaller index
    # to consolidate leftover space in earlier bins.
    residual = bins - item
    return -residual
# EVOLVE-BLOCK-END
