# EVOLVE-BLOCK-START
"""Best fit with a mild residual-shaping penalty; keeps state across a stream."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Score bins; highest score wins (ties to first). Best-fit dominant with
    a small nudge based on the leftover relative to the running mean item size."""
    _state["n"] += 1
    _state["sum"] += float(item)
    mean = _state["sum"] / _state["n"]

    rem_after = bins - item  # always >= 0 since only fitting bins are shown

    # Base: strongly prefer tightest fit (best fit).
    # Nudge: mildly reward leftovers that are close to the running mean item size
    # (so the bin is likely to be completed by a typical future item).
    scale = max(mean, 1.0)
    nudge = -np.abs(rem_after - scale) / (100.0 * scale)
    return -rem_after + nudge
# EVOLVE-BLOCK-END

