# EVOLVE-BLOCK-START
"""Best fit with leftover matched to the running mean item size."""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = _state
    if s["count"] == 0:
        mean = 40.0
    else:
        mean = s["sum"] / s["count"]

    residual = bins - item  # remaining capacity after placement, all >= 0

    # Prefer residuals close to the running mean item size so the leftover
    # space stays reusable by future items. Strong bonus for exact fits.
    target = mean
    score = -np.abs(residual - target)
    score = score + 1000.0 * (residual == 0)
    # slight tie-break toward tighter fits
    score = score - 0.001 * residual

    s["sum"] += item
    s["count"] += 1
    return score
# EVOLVE-BLOCK-END
