# EVOLVE-BLOCK-START
"""Hybrid: best fit with a mild bonus for filling bins closer to capacity.

Primary signal is best fit (smallest leftover). A small concave bonus based on the
bin's post-placement fill ratio breaks near-ties in favor of fuller bins, which tends
to reduce the number of partially-filled bins left dangling.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (ties -> first).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacity of every fitting bin, in bin order.
    """
    leftover = bins - item
    fill = (100 - leftover) / 100.0          # post-placement fill ratio in [0,1]
    # Best fit dominates; concave bonus rewards fuller bins and is bounded by <1.
    return -leftover + 0.5 * (fill * fill)
# EVOLVE-BLOCK-END
