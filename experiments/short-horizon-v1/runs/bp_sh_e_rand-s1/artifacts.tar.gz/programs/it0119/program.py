# EVOLVE-BLOCK-START
"""Best fit with a small bias against opening fresh (unused) bins."""
import numpy as np


def priority(item, bins):
    """Rank bins: exact fit highest, then tightest fit, with a mild penalty for untouched bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    score = -residual
    # Mildly discourage consuming completely empty bins (residual == 100),
    # so that fresh capacity is kept in reserve for large future items.
    score = score - 2.0 * (bins == 100)
    return score
# EVOLVE-BLOCK-END
