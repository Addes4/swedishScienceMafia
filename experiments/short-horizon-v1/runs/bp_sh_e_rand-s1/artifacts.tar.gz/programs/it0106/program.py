# EVOLVE-BLOCK-START
"""Best-fit with a small-item consolidation bonus.

Items arrive one at a time. Pure best-fit (tightest residual) is near-optimal overall,
but on Weibull-shaped sizes many items are small; these can be tucked into leftover
space of partially-filled bins rather than opening fresh ones. We keep best-fit as the
primary ordering and add a small bonus that favors bins with more residual room when
the arriving item is itself small, so small items consolidate into existing bins.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing item here
    score = -residual.astype(np.float64)
    if item <= 40:
        # Small item: gently prefer bins with more leftover room (keep them "open"
        # for consolidation) instead of always cramming into the tightest bin.
        score = score + 0.05 * residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
