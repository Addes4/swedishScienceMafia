# EVOLVE-BLOCK-START
"""Adaptive best-fit: prefer exact fits, otherwise choose the bin whose residual
after placement is most likely to be consumed by a future item."""
import numpy as np

# Running histogram of observed item sizes (1..100). Persists within a stream.
_HIST = np.zeros(101)

# Precompute: is a residual value "useful"? We'll weight by histogram frequency.


def priority(item, bins):
    """Rank bins: exact fits first, then residual fillability, then tightest fit."""
    _HIST[item] += 1

    # post-placement residual for every candidate bin
    new_res = bins - item

    # frequency weight of a residual value r (1..100); r==0 is exact fit
    freq = np.zeros(new_res.shape, dtype=np.float64)
    valid = new_res >= 0
    r = new_res[valid]

    # empirical frequency of each residual value as a past item size
    sub = _HIST[:101]
    total = sub.sum()
    if total > 0:
        w = sub[r] / total
    else:
        w = np.zeros(r.shape, dtype=np.float64)
    freq[valid] = w

    # Score: exact fit (res 0) huge bonus; then fillability bonus;
    # then best-fit tightness (smaller residual better).
    score = np.zeros(new_res.shape, dtype=np.float64)
    score += (new_res == 0) * 1e6           # exact fit
    score += freq * 1e3                     # residual likely to be fillable later
    score += -(new_res.astype(np.float64))  # best-fit tie-break
    return score
# EVOLVE-BLOCK-END
