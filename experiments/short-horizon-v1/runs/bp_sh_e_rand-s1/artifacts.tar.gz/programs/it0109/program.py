# EVOLVE-BLOCK-START
"""Best fit with exact-fit bonus and fuller-bin tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority per bin; highest wins, ties to first (lowest index)."""
    resid = bins - item          # remaining capacity after placing the item
    # Primary: minimize residual (best fit). Larger score = better.
    score = -resid.astype(np.float64)
    # Bonus for exact fits (residual == 0) to consolidate perfectly.
    score += (resid == 0).astype(np.float64) * 0.5
    # Tertiary: among equal residuals, prefer fuller bins (smaller pre-residual).
    score += -bins.astype(np.float64) * 1e-6
    return score
# EVOLVE-BLOCK-END
