# EVOLVE-BLOCK-START
"""Best fit with a mild log-residual tie-break to reduce tiny unusable leftovers."""
import numpy as np


def priority(item, bins):
    """Rank bins: primary best-fit, secondary penalize awkward residuals."""
    r = bins - item  # remaining capacity after placing item (>= 0)
    # Best-fit: prefer smallest r. Secondary: mildly favor r==0 or larger reusable r.
    # log(r+1) grows slowly; subtracting it rewards smaller residuals further,
    # which is essentially best-fit amplified, nudging toward exact/empty fits.
    return -r - 0.001 * np.log(r + 1.0)
# EVOLVE-BLOCK-END

