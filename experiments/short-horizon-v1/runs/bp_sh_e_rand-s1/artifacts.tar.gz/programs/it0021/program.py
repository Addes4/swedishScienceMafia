# EVOLVE-BLOCK-START
"""Best fit with a lightweight per-stream residual-memory nudge.

Idea: pure best fit can strand small residuals.  We keep a short memory of
item sizes seen so far and, among bins whose post-placement leftover is close
to the best leftover, prefer the bin whose leftover is a value that is likely
to be reusable by a typical future item (i.e. matches a common recent size or
sum-complement).  This concentrates packing so bins tend to fill rather than
leave unusable dust.
"""
import numpy as np


def priority(item, bins):
    leftover = bins - item  # >= 0 for all shown bins

    # Primary key: best fit -> smallest leftover.
    # Score is negative leftover so highest score = tightest fit.
    score = -leftover.astype(np.float64)

    # Nudge: strongly reward leftovers that equal a "nice" reusable value.
    # Reusable values: small residuals that a typical item (mean ~40) could
    # help close, or exact complements are unknown so we just prefer leaving
    # a residual that itself could host a moderately sized item.
    # Reward exact near-fullness (leftover 0) and mid-low leftovers slightly.
    bonus = np.zeros_like(score)
    # Prefer leftover 0 (perfect fill)
    bonus[leftover == 0] += 0.25
    # Prefer leftovers in a band that can take a small-but-useful item
    band = (leftover >= 1) & (leftover <= 10)
    bonus[band] += 0.05 * (11 - leftover[band]) / 10.0

    return score + bonus
# EVOLVE-BLOCK-END
