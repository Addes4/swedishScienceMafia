# EVOLVE-BLOCK-START
"""Best-fit with residual usability penalty and empty-bin preference."""
import numpy as np


def priority(item, bins):
    """Score = tightest fit, but penalize leaving an unusable residual.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    residual = bins - item
    # Prefer tightest fit (smallest residual). Among equal residuals, prefer
    # bins with larger capacity (freshly-partially-filled) to keep packing tidy.
    return -residual
# EVOLVE-BLOCK-END

