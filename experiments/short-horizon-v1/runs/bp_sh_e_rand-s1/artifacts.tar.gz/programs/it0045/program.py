# EVOLVE-BLOCK-START
"""Best fit with a bounded, stateful mean-residual tie-break."""
import numpy as np


class _State:
    n = 0
    s = 0.0


def priority(item, bins):
    """Priority for each bin: best fit dominates, ties broken toward mean residual."""
    st = _State
    st.n += 1
    st.s += item
    mean = st.s / st.n

    resid = bins - item  # post-placement residual capacities (>= 0)
    # Primary: smallest residual (best fit). Secondary: residual closest to running mean.
    return -(resid) - 1e-3 * np.abs(resid - mean)
# EVOLVE-BLOCK-END
