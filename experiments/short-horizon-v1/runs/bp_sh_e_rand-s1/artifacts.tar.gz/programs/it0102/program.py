# EVOLVE-BLOCK-START
"""Best-fit with a residual-consolidation bonus.

Primary idea: best-fit (smallest residual) is a strong baseline for this
distribution.  To improve on it we add a secondary criterion that prefers
placements whose resulting residual is a near-multiple of a typical item
size, so leftover space in a bin is more likely to be reusable later.

The typical item size is estimated online from the stream itself (running
mean with a conservative prior), so no future information is used.
"""
import numpy as np

# --- module-level online state (reset per stream by the harness) ---
_state = {
    "count": 0,
    "sum": 0.0,
    # prior mean from the stated distribution (~40)
    "prior_mean": 40.0,
    "prior_weight": 8.0,
}


def _running_mean():
    c = _state["count"]
    s = _state["sum"]
    pw = _state["prior_weight"]
    pm = _state["prior_mean"]
    return (s + pw * pm) / (c + pw)


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties)."""
    # update running stats with the arriving item
    _state["count"] += 1
    _state["sum"] += item
    m = _running_mean()
    if m < 1.0:
        m = 1.0

    bins = np.asarray(bins)

    # residual after placing the item
    residual = bins - item  # >= 0 by harness guarantee

    # best-fit primary term: prefer the smallest residual.
    # Use a large negative weight on residual.
    score = -residual.astype(np.float64)

    # secondary: how close is the residual to a multiple of the typical item
    # size?  A residual of exactly k*m can (in principle) be filled by k
    # typical items, so it is "good".  Penalize distance to nearest multiple.
    ratio = residual / m
    nearest = np.floor(ratio + 0.5)
    dist = np.abs(ratio - nearest)          # in units of m, [0, 0.5]
    # Bonus in [0, 1]; scaled to stay strictly below the residual ordering,
    # so best-fit remains the dominant criterion and this only breaks near
    # ties in a way that improves residual reuse.
    bonus = (0.5 - dist)                   # 0 .. 0.5
    # Also mildly favour larger residuals when they are near-multiples,
    # i.e. bins that will hold more items.  Keep small.
    score = score + 0.4 * bonus

    return score
# EVOLVE-BLOCK-END
