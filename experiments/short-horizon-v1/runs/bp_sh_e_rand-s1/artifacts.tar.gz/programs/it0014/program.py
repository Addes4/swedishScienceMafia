# EVOLVE-BLOCK-START
"""Best fit with a residual-complement bonus, tuned for Weibull(mean~40) items."""
import numpy as np

# Common complementary residuals that future items are likely to exactly fill.
_TARGETS = np.array([10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70], dtype=np.float64)


def priority(item, bins):
    """Rank bins: primary best-fit gap, plus a bonus for fillable residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    leftover = bins - item  # >= 0 for all shown bins
    # Best fit: smaller leftover is better (negate).
    best_fit = -leftover.astype(np.float64)

    # For each leftover, distance to nearest common target residual.
    d = np.abs(leftover[:, None] - _TARGETS[None, :]).min(axis=1)

    # Bonus: strongly favor an exact target (d == 0), decaying for near misses.
    bonus = 3.0 / (1.0 + d * d)

    return best_fit + bonus
# EVOLVE-BLOCK-END
