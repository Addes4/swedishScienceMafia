# EVOLVE-BLOCK-START
"""Adaptive best fit: prefer bins whose post-placement residual is a likely future item size."""
import numpy as np


class _State:
    def __init__(self):
        # coarse count of observed item sizes (1..100)
        self.counts = np.zeros(101, dtype=np.float64)
        self.n = 0.0


_state = _State()


def priority(item, bins):
    """Score each bin so the item tends to leave a residual usable by future items."""
    st = _state
    st.counts[item] += 1.0
    st.n += 1.0

    # Estimated probability that a future item has each size 1..100.
    # Blend with a small uniform prior so early items don't dominate.
    probs = (st.counts + 0.5) / (st.n + 50.0)

    residuals = bins - item  # leftover capacity after placing the item here

    # For each bin, reward leftovers that are likely future item sizes.
    # p_like(res) uses the probability mass at exactly the residual size
    # (and we also give a boost to residual 0: a perfectly filled bin is free).
    idx = np.clip(residuals, 0, 100)
    like = probs[idx]

    # Primary: prefer residuals that are likely usable (higher is better).
    # Secondary: among equal usability, prefer the tightest fit (smallest residual).
    score = like * 10.0 - residuals * 1e-3

    # A residual of exactly 0 is ideal (bin fully closed).
    score = np.where(residuals == 0, 1e9, score)

    return score
# EVOLVE-BLOCK-END
