# EVOLVE-BLOCK-START
"""Best fit, with a mild tie-break that avoids leaving tiny unusable gaps."""
import numpy as np


_state = {"n": 0.0, "total": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running mean item size seen so far (online estimate).
    _state["n"] += 1.0
    _state["total"] += item
    mean_item = _state["total"] / _state["n"]

    residual = (bins - item).astype(np.float64)  # >= 0 for shown bins

    # Primary: best fit (smallest residual). Encode as a large negative term so that
    # smaller residual => higher score, with the secondary term only breaking near-ties.
    primary = -residual * 1000.0

    # Secondary: penalize residuals that are small but nonzero (fragmentation), since
    # such gaps are hard to reuse. Reward exact fits and comfortably large leftovers.
    with np.errstate(divide="ignore", invalid="ignore"):
        gap_pen = np.where(
            residual <= 0.0,
            0.0,  # exact fit: ideal, no penalty
            np.where(
                residual < mean_item,
                (mean_item - residual) / (mean_item + 1.0),  # small unusable gap
                -0.1,  # comfortably large leftover: tiny bonus
            ),
        )

    return primary - gap_pen
# EVOLVE-BLOCK-END
