# EVOLVE-BLOCK-START
"""Best-fit with a soft floor on post-placement residual to avoid premature closure."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = _state["sum"] + item
    n = _state["n"] + 1
    _state["sum"] = s
    _state["n"] = n
    mean = s / n

    residual = bins - item  # >= 0 for bins that fit

    # Primary: prefer tightest fit (smallest residual). But avoid closing a bin
    # to a residual that is hopelessly small when the item stream still has
    # average-sized items: add a soft penalty for residuals well below the mean.
    score = -residual.astype(np.float64)
    # Soft penalty: quadratic push away from residuals in the "too small to be
    # useful but nonzero" zone (0 < r < mean).
    small = np.clip(mean - residual, 0.0, None)
    score -= 0.5 * small  # gentle: best-fit still dominates
    return score
# EVOLVE-BLOCK-END
