# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware reservation for small items.

Pure best fit greedily packs, but a small item can leave a tiny residual that no future
item can use, wasting that bin's remaining space. We keep best fit as the primary rule,
but when the arriving item is smaller than the running average item size, we prefer
leaving a residual at least as large as the running mean (so the bin stays useful), and
only break back to strict best fit if no bin can satisfy that.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Running mean of past item sizes (state kept on the function object).
    state = priority.__dict__
    n = state.get("n", 0)
    mean = state.get("mean", 40.0)
    # Update with this item (exponential-ish running mean).
    n += 1
    mean = mean + (item - mean) / n
    state["n"] = n
    state["mean"] = mean

    residual = bins - item  # post-placement remaining capacity (>= 0 since item fits)

    if item < mean:
        # Prefer residuals that are at least the running mean (keep bin useful).
        good = residual >= mean
        if np.any(good):
            # Among "good" bins, take the tightest (smallest residual >= mean).
            score = np.where(good, -residual, -np.inf)
            return score
    # Strict best fit: smallest residual wins.
    return -residual
# EVOLVE-BLOCK-END
