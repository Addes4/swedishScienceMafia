# EVOLVE-BLOCK-START
"""Best fit with adaptive residual matching using a running item-size histogram."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def _reset():
    global _HIST, _COUNT
    _HIST = np.zeros(101, dtype=np.float64)
    _COUNT = 0.0


def priority(item, bins):
    """Score each bin; prefer small post-placement residual, matching common sizes."""
    global _HIST, _COUNT

    # Update running histogram (decay-heavy so it adapts, but stable).
    if _COUNT > 0:
        _HIST *= 0.999
    _HIST[item] += 1.0
    _COUNT += 1.0

    residual = bins - item
    # Primary: prefer smallest residual (best fit).
    primary = -(residual.astype(np.float64))

    # Secondary: reward residuals that are 0 or match common future item sizes.
    # Normalize histogram to a probability-like weight.
    total = _HIST.sum()
    if total <= 0:
        return primary

    prob = _HIST / total
    res = residual.astype(np.int64)
    res_clipped = np.clip(res, 0, 100)
    match = prob[res_clipped]

    # Exact-completion bonus dominates the histogram match.
    exact = (res == 0).astype(np.float64)
    secondary = exact * 1.0 + match

    # Primary dominates; secondary only acts as a fine tie-breaker.
    return primary + 0.01 * secondary
# EVOLVE-BLOCK-END
