# EVOLVE-BLOCK-START
"""Best fit with a bounded histogram-based tie-break.

Primary score is best fit (most negative post-placement residual).  A tiny
secondary term rewards placing the item so that the bin's remaining capacity
afterwards is a size that has been arriving frequently, which makes it more
likely that a future item closes the bin exactly.
"""
import numpy as np


_FREQ = np.zeros(101, dtype=np.float64)
_DECAY = 0.995


def priority(item, bins):
    # Update running histogram of item sizes (before scoring is fine; item is
    # already known and does not bias toward any bin).
    _FREQ *= _DECAY
    _FREQ[item] += 1.0

    residual = bins - item          # >= 0 guaranteed by the harness
    # Dominant key: best fit.
    score = -(residual.astype(np.float64))

    # Secondary term: reward residuals that are frequent item sizes
    # (including 0, meaning the bin is closed exactly).
    freq = _FREQ[residual]
    score += 1e-6 * freq

    return score
# EVOLVE-BLOCK-END
