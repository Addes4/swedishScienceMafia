# EVOLVE-BLOCK-START
"""Best fit with a stateful pairing hint: usually place best-fit, but when a bin can be
left with a residual that exactly matches a frequently seen recent item size (or the sum of
two recent items), gently prefer it so that residual space is more likely to be usable."""
import numpy as np

# module-level state (reset per stream by the harness re-importing / fresh module)
_recent = []
_count = 0
_hist = np.zeros(101, dtype=np.int64)
_ewma = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _ewma

    it = int(item)

    # best-fit distance: smaller residual after placement is better -> negate
    resid = bins - it                     # >= 0 guaranteed for shown bins
    base = -resid.astype(np.float64)      # dominant term (best fit)

    # strong signal only when there is enough history to trust statistics
    if _count >= 32:
        # probability that a future item exactly equals a residual r
        # use recent empirical frequency on residuals 1..100
        freq = _hist.astype(np.float64)
        tot = freq.sum()
        if tot > 0:
            p_r = freq / tot
            # bonus if the residual is a likely exact-fill target
            pair_bonus = p_r[np.clip(resid, 0, 100)] * 8.0
        else:
            pair_bonus = 0.0

        # also reward residuals equal to sum of two plausible future items (~2*mean)
        two = 2.0 * _ewma
        pair_bonus = pair_bonus + 1.5 * np.exp(-((resid - two) ** 2) / (2.0 * (0.25 * max(_ewma, 1.0)) ** 2))

        score = base + pair_bonus
    else:
        score = base

    # update state with the arriving item (after scoring so we never use the current item as "past")
    _recent.append(it)
    if len(_recent) > 200:
        _recent.pop(0)
    _hist[it] += 1
    _count += 1
    _ewma = 0.98 * _ewma + 0.02 * it

    return score
# EVOLVE-BLOCK-END
