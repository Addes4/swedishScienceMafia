# EVOLVE-BLOCK-START
"""Best fit with a tiny structure-aware tie-break based on recent item sizes."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0

    def update(self, item):
        self.hist[item] += 1.0
        self.count += 1


_state = _State()


def priority(item, bins):
    """Best-fit primary key; tiny secondary reward for 'useful' residuals."""
    _state.update(item)

    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item  # post-placement residual, >= 0 since bins already fit

    # Primary: smallest residual (pure best fit). Scale up so it dominates.
    primary = -residual.astype(np.float64)

    # Secondary: reward residuals that are 0 or match a common recent item size.
    total = max(_state.count, 1)
    freq = _state.hist / total  # probability mass per size
    # weight of the residual value; cap so it stays a tie-breaker
    sec = np.zeros(len(residual), dtype=np.float64)
    # residual <= 100 always
    idx = np.clip(residual, 0, 100)
    sec = freq[idx]
    # exact close-out is always best
    sec = np.where(residual == 0, 1.0, sec)

    # Primary dominates: 1 unit of residual >> any secondary difference.
    return primary * 4.0 + sec
# EVOLVE-BLOCK-END
