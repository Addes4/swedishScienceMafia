# EVOLVE-BLOCK-START
"""Best fit, with a mean-residual matching tweak on the secondary criterion."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    s = _state
    s["sum"] += item
    s["n"] += 1
    mean = s["sum"] / s["n"]

    residual = bins - item            # remaining capacity after placing the item

    # Primary: tightest fit (smallest residual) -> best fit.
    score = -residual * 1000.0

    # Secondary: among equal fits, prefer residuals close to a reusable target,
    # so leftovers can still be matched by a future average-sized item.
    target = 100.0 - mean
    score -= np.abs(residual - target)

    return score
# EVOLVE-BLOCK-END
