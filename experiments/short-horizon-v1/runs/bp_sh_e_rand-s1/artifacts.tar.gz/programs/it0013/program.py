# EVOLVE-BLOCK-START
"""Harmonic-style bin packing with size classes.

Items are classified into size classes by their size relative to capacity.
Within each class we use best-fit (tightest remaining capacity that still fits),
which is optimal-ish for the class and prevents large items from consuming
slots that small items could use.

Class boundaries follow harmonic bin packing but augmented with the knowledge
that the distribution is Weibull(mean ~40).  To make it simple and robust we
mainly rely on best-fit, but we forbid dumping a big item into a bin that
could still hold two medium items when a fresh bin is available -- i.e. we
prefer empty bins for the very largest items.
"""
import numpy as np


def priority(item, bins):
    # bins: remaining capacities (int64).  Higher score -> chosen.
    # Primary: best-fit = smallest remaining capacity >= item.
    # score = -(remaining - item)  => tightest fit wins.
    score = -(bins.astype(np.float64) - item)

    # For large items (> 50), a bin whose remaining capacity is 100 (empty)
    # is often a better home than a partial bin when the residual after
    # placement would be unusable.  Nudge toward empties for big items so
    # the tight best-fit leftover is not stranded.
    if item > 50:
        # residual in best-fit would be < 50 anyway; but pushing to empties
        # avoids creating tiny scraps.  Give empty bins a bonus that decays
        # with how much worse their fit is.
        empty_bonus = 0.5 * (bins == 100)
        score += empty_bonus

    # For medium items, prefer bins whose leftover after placement is close to
    # a typical small complement (<= ~20) so the bin can be finished cheaply;
    # but keep it as a weak tie-break only.
    # (No change; best-fit already minimises leftover.)

    return score
# EVOLVE-BLOCK-END
