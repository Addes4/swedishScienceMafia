# EVOLVE-BLOCK-START
"""Best fit with a stateful harmonic tie-break.

Primary rule: best fit (minimise post-placement residual), which is the strongest
simple online rule for this distribution.  Tie-break: among bins that achieve the
same best residual, prefer a bin whose post-placement residual is a "harmonic"
value -- i.e. it exactly matches a frequently seen item size (so a future item of
that size fills it perfectly) or is zero.  The frequency information is a cheap
running histogram maintained across calls within a stream.
"""
import numpy as np

_STATE = {"hist": np.zeros(101, dtype=np.float64), "count": 0.0}


def _freq_table():
    hist = _STATE["hist"]
    total = _STATE["count"]
    if total <= 0:
        return None
    return hist / total


def priority(item, bins):
    # update running histogram (state persists across calls within a stream)
    if 1 <= item <= 100:
        _STATE["hist"][item] += 1.0
        _STATE["count"] += 1.0
    # slow decay so the histogram tracks the stationary distribution but forgets
    if _STATE["count"] > 2000.0:
        _STATE["hist"] *= 0.999
        _STATE["count"] *= 0.999

    residual = bins - item          # post-placement residual, >= 0 guaranteed
    # Primary key: penalise larger residual (best fit).
    score = -residual.astype(np.float64)

    freq = _freq_table()
    if freq is not None:
        # bonus (strictly smaller than the integer gap of 1) for harmonics:
        # residual == 0 (perfect fit) or residual equals a common item size.
        bonus = np.zeros_like(score)
        nonzero = residual > 0
        if np.any(nonzero):
            r = residual[nonzero]
            f = freq[np.clip(r, 0, 100)]
            bonus[nonzero] = 0.4 * f
        # exact fit is a perfect harmonic
        bonus[residual == 0] = 0.5
        score = score + bonus

    return score
# EVOLVE-BLOCK-END
