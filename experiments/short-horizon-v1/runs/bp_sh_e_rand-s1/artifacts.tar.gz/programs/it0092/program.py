# EVOLVE-BLOCK-START
"""Best fit with a mild residual-reusability bonus driven by an online item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _total
    # update online histogram of past item sizes
    _counts[item] += 1.0
    _total += 1.0

    residual = bins - item  # >= 0 by contract

    # Dominant best-fit term: tighter fit -> higher score.
    score = -residual.astype(np.float64)

    # Reusability bonus: reward residuals that match a plausible future item size,
    # weighted by how common such a size has been.  Small weight so best-fit
    # ordering dominates on short streams where the histogram is unreliable.
    if _total >= 8.0:
        freq = _counts / _total
        # bonus is freq of the residual size (0 for zero/oversized residuals)
        bonus = np.zeros_like(score)
        mask = (residual >= 1) & (residual <= 100)
        bonus[mask] = freq[residual[mask]]
        score += 3.0 * bonus

    return score
# EVOLVE-BLOCK-END
