# EVOLVE-BLOCK-START
"""Best fit with scrap-avoidance tuned to the observed item distribution."""
import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.mean = 40.0
        # histogram of observed item sizes (1..100)
        self.hist = np.zeros(101, dtype=np.float64)


_STATE = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _STATE
    st.count += 1
    st.mean += (item - st.mean) / st.count
    st.hist[item] += 1.0

    n = bins.shape[0]
    # residual after placing the item in each bin
    resid = bins - item  # >= 0 for all shown bins

    # Best-fit primary key: we want smallest residual.
    # Compute the minimum residual achievable.
    min_resid = int(resid.min())

    # Estimate a "typical small item" floor: the smallest item size likely to
    # still appear, used to detect unfillable scrap.
    # Use the smallest observed item size (as an integer >=1).
    idx = np.nonzero(st.hist)[0]
    if idx.size:
        min_item = int(idx[0])
    else:
        min_item = 1
    if min_item < 1:
        min_item = 1

    # Score: primary = negative residual (best fit). Add a small bonus for
    # residuals that are "usable" (at least min_item) versus scrap.
    # Only apply the scrap penalty near the best-fit boundary to avoid
    # disturbing the strong best-fit ordering elsewhere.
    scores = -(resid.astype(np.float64))

    # For bins whose residual is tiny (scrap: 0 < resid < min_item), penalize
    # slightly so a near-tie usable bin is preferred, but keep exact fit best.
    scrap_mask = (resid > 0) & (resid < min_item)
    # Bonus magnitude must be < 1 so it never overrides residual ordering by
    # more than a single unit; near-ties benefit.
    scores = scores - 0.5 * scrap_mask

    return scores
# EVOLVE-BLOCK-END
