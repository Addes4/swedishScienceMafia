# EVOLVE-BLOCK-START
"""Best fit with a running-mean-aware switch for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit leftover (smaller leftover = higher priority)
    leftover = bins - item
    # Base score is negative leftover (best fit)
    return -leftover
# EVOLVE-BLOCK-END
