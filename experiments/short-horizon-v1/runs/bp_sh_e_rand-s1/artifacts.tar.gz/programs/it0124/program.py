# EVOLVE-BLOCK-START
"""Best fit with a running-mean residual tie-break."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.total = 0.0

    def update(self, item):
        self.n += 1
        self.total += item

    @property
    def mean(self):
        return self.total / self.n if self.n else 40.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    mean = _state.mean
    _state.update(item)

    # Primary: prefer small residual (best fit).
    tol = 2.0
    rmin = residual.min()
    near = residual <= rmin + tol

    # Secondary: among near-best-fit bins, prefer residual closest to the running mean.
    tie = -np.abs(residual - mean)

    score = np.where(near, tie, -residual.astype(float) - 1000.0)
    # Ensure primary ordering dominates: encode lexicographically.
    score = -residual.astype(float) + np.where(near, tie * 0.001, 0.0)
    return score
# EVOLVE-BLOCK-END
