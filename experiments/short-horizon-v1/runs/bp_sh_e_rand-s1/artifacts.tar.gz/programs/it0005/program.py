# EVOLVE-BLOCK-START
"""Hybrid: prefer perfect fits, else best fit, with a mild anti-new-bin nudge."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit (smallest residual is best).
    score = -residual.astype(np.float64)
    # Reward exact fits strongly so a zero residual always wins.
    score += (residual == 0) * 1e6
    # Mildly discourage opening brand-new bins (capacity still 100).
    score -= (bins == 100) * 1e-3
    return score
# EVOLVE-BLOCK-END
