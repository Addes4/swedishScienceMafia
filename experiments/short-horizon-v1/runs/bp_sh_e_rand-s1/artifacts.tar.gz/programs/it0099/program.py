# EVOLVE-BLOCK-START
"""Harmonic-style online bin packing rule.

Idea: instead of pure best-fit (which tightly packs but can leave tiny,
unusable residuals), prefer bins whose post-placement residual falls into a
coarse "harmonic" scale. Items are placed into a bin only if the resulting
residual is either 0 or at least the current harmonic threshold relative to
capacity. This keeps residuals large enough to be reusable.
"""
import numpy as np

CAP = 100.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    b = bins.astype(np.float64)
    residual = b - item  # remaining capacity after placing item here (>= 0 since item fits)

    # Exact fits are always best.
    exact = (residual == 0)

    # Harmonic residual: round residual down to the largest capacity/k class it
    # reaches (k = 1..8). Larger residual => more reusable, so we prefer it,
    # but weighted so that a smaller residual within the same class is still
    # preferred (tightest fit within class) to reduce waste.
    ratio = residual / CAP
    # largest k with 1/k <= ratio  => k = floor(1/ratio), clamped
    with np.errstate(divide='ignore', invalid='ignore'):
        k = np.where(residual > 0, np.floor(1.0 / ratio), 0.0)
    k = np.clip(k, 0.0, 8.0)

    # Primary: prefer higher harmonic class (larger reusable residual),
    # Secondary: tighter fit (smaller residual) to reduce slack.
    score = k * CAP - residual * 0.5
    score = np.where(exact, 1e6, score)
    return score
# EVOLVE-BLOCK-END
