# EVOLVE-BLOCK-START
"""Hybrid: best fit for large items, load-spreading for small ones."""
import numpy as np


def priority(item, bins):
    """Score bins: large items use best-fit; small items prefer roomier bins.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every fitting bin, in bin order.
    """
    # Post-placement residual: smaller is tighter (best fit).
    resid = bins - item
    bf = -resid.astype(np.float64)

    if item >= 34:
        # Large item: pure best fit (tightest remaining after placement).
        return bf

    # Small item: prefer bins whose remaining capacity is moderate-to-large,
    # i.e. avoid stuffing tiny items into nearly-full bins that a bigger
    # item could later complete. Reward larger current capacity, but still
    # slightly prefer tighter fits among large-capacity bins.
    score = bins.astype(np.float64) * 1.0 - resid.astype(np.float64) * 0.001
    return score
# EVOLVE-BLOCK-END
