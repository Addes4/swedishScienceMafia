# EVOLVE-BLOCK-START
"""Stateful best-fit with a penalty for leaving unfillable tiny residuals."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.total = 0

    def update(self, item):
        self.n += 1
        self.total += item

    @property
    def mean(self):
        return self.total / self.n if self.n else 40.0


_state = _State()


def priority(item, bins):
    """Score bins: strongly prefer tight fits, mildly penalize tiny unusable scraps.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state.update(item)
    mean = _state.mean

    residual = bins - item  # remaining capacity after placing item

    # Base: best-fit -> smaller residual is much better.
    # Secondary: a residual that is a small scrap (< ~ third of a typical item)
    # is likely to become permanently unusable, so penalize it slightly.
    # Rewards residuals in the vicinity of the running mean item size.
    tiny = residual < 0.25 * mean
    scrap_penalty = np.where(tiny, (0.25 * mean - residual), 0.0)

    return -(residual + 0.5 * scrap_penalty)
# EVOLVE-BLOCK-END
