# EVOLVE-BLOCK-START
"""Best fit, with a stateful tie-break for small items to reduce wasted slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    if item >= 30:
        # Large items: plain best fit.
        return -residual

    # Small items: best fit first, then prefer residuals that are not tiny slivers
    # (a residual of 0..item-1 would be hard to reuse). Keep integer residual dominant,
    # break ties within the same integer residual only.
    # Quantize the residual so that exact best-fit is strictly preferred, and among
    # equal residuals prefer a residual close to a typical small item size (~ item).
    primary = -residual
    # Tiny bonus: among identical residuals, prefer residual around the item size,
    # which allows another similar small item to fit. Scaled small so it never
    # overrides the residual ordering.
    bonus = -np.abs(residual - item) * 1e-3
    return primary + bonus
# EVOLVE-BLOCK-END

