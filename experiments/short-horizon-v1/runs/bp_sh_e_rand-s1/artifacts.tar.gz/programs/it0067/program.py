# EVOLVE-BLOCK-START
"""Best fit with a penalty for creating stranded residuals.

Pure best-fit minimizes the residual created. But a residual that is positive and
smaller than any item we ever see is wasted space: no future item can fill it.
This rule penalizes placements that create such a stranded residual, while keeping
best-fit as the dominant term, so items are steered into bins that either close
exactly or leave a genuinely reusable gap.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties)."""
    residual = bins - item
    # A residual r is "stranded" if 1 <= r < smallest item size likely to appear.
    # Use a soft threshold: penalize small positive residuals, reward 0.
    # Stranded-ness cost: high for tiny positive leftovers, ~0 for r==0 and large r.
    safe = np.where(residual <= 0, 1.0, np.where(residual >= 30, 1.0,
                    np.minimum(residual, 30) / 30.0))
    # Best-fit dominant term plus stranded-residual penalty.
    return -(bins - item) - 0.5 * (1.0 - safe)
# EVOLVE-BLOCK-END
