# EVOLVE-BLOCK-START
"""Harmonic-class bin choice: keep bins reserved per geometric size class."""
import numpy as np


def _classes():
    # Geometric bands over (0, 100]; each band covers (100/(k+1), 100/k].
    return [100.0 / k for k in range(1, 101)]


_BOUNDS = _classes()  # descending upper bounds


def _class_of(item):
    # find smallest k such that item <= 100/k  => class index k-1
    # _BOUNDS[k-1] = 100/k
    for idx, ub in enumerate(_BOUNDS):
        if item <= ub + 1e-12:
            return idx
    return len(_BOUNDS) - 1


def priority(item, bins):
    """Score bins for the arriving item; highest score wins (ties: first bin)."""
    bins = np.asarray(bins)
    n = bins.shape[0]
    if n == 0:
        return bins.astype(np.float64)

    c = _class_of(item)

    # A bin is "used in class c" if its remaining capacity lies in class c's range,
    # i.e. the bin was a full bin whose residual capacity places it in class c.
    # Harmonic bin packing: items of class c go into bins dedicated to class c.
    target_hi = _BOUNDS[c]                       # 100/(c+1)
    target_lo = _BOUNDS[c + 1] if c + 1 < len(_BOUNDS) else 0.0  # 100/(c+2)

    # Residual after this item is placed:
    residual = bins - item

    # For class-restricted packing: a bin "belongs" to class c if its current
    # remaining capacity is in [target_lo, target_hi] (it is a bin of class c),
    # or if it is still unused (capacity 100) and item is the first of its class.
    score = np.empty(n, dtype=np.float64)

    # Membership masks
    in_class = (bins >= target_lo - 1e-12) & (bins <= target_hi + 1e-12)
    unused = (bins == 100)

    # Base: best-fit within matching class bins, strongly preferred.
    # Priority tier 1: bins already in this class (residual already fits class range)
    # Priority tier 2: unused bins
    # Priority tier 3: everything else (best-fit fallback)

    # Use best-fit (smallest residual) as secondary key within tiers.
    bf = -np.abs(residual)

    score = bf.copy()

    # Tier 1: in-class bins get a large bonus (prefer closing out class bins)
    score = np.where(in_class, 1e6 + bf, score)

    # Tier 2: unused bins get medium bonus only if item is "large" (hard to place)
    # Large items: class index small (item > 50). Reserve unused bins for them.
    if item > 50:
        score = np.where(unused, 5e5 + bf, score)

    # Tier 3 (fallback): prefer placing residuals into the same class as the item
    # so that bins finish near class boundaries. Small tie-break.
    same_class_res = (residual >= target_lo - 1e-12) & (residual <= target_hi + 1e-12)
    score = score + np.where(same_class_res, 1e3, 0.0)

    return score
# EVOLVE-BLOCK-END

