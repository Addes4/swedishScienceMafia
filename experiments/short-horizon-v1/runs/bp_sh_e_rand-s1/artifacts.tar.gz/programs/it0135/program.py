# EVOLVE-BLOCK-START
"""Best-fit with a complement-histogram bonus for residuals that a common item can fill."""
import numpy as np


class _State:
    def __init__(self):
        # counts of items seen, bucketed by size 1..100
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0


_state = _State()


def priority(item, bins):
    """Best-fit, plus a bonus when the residual left equals a common future item size."""
    # Update histogram
    if 1 <= item <= 100:
        _state.counts[item] += 1.0
        _state.total += 1.0

    # Best-fit key: smaller residual -> larger score
    score = -(bins - item).astype(np.float64)

    # Residual after placing into each bin
    resid = bins - item

    # Bonus: residual is a size that appears often in the histogram (so a future
    # item can exactly fill it). Scale so it only breaks near-ties.
    if _state.total > 0:
        freq = _state.counts / _state.total
        # clamp residuals to valid index range
        idx = np.clip(resid, 0, 100)
        bonus = freq[idx]
        score = score + 0.5 * bonus

    return score
# EVOLVE-BLOCK-END
