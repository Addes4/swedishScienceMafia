# EVOLVE-BLOCK-START
"""First fit: place the item in the earliest bin (by index) it fits into."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = bins.shape[0]
    return -np.arange(n, dtype=np.float64)
# EVOLVE-BLOCK-END

