# EVOLVE-BLOCK-START
"""Best fit with a load-concentration tie-break for equal residuals."""
import numpy as np


def priority(item, bins):
    # Primary key: best fit (smallest non-negative residual).
    residual = bins - item

    # We cannot track bin identity reliably across calls because the harness passes
    # only the capacities of fitting bins in bin order (a copy). Bin index order is
    # stable within a stream, so we bias by bin position only through a mild
    # deterministic function that favors lower indices slightly (stable, no state).
    #
    # Concentrate leftovers: among bins with the same residual, prefer the one whose
    # remaining capacity (pre-placement) is smaller, i.e. the already-fuller bin.
    # This packs bins tight instead of spreading and helps stack items.
    return -(residual) - 1e-3 * bins
# EVOLVE-BLOCK-END

