# EVOLVE-BLOCK-START
"""Best-fit with a reuse-aware tie-break driven by a running item-size histogram."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Dominant term: best fit (smallest residual after placement is best).
    resid = bins - item
    score = -resid.astype(np.float64)

    # Reuse-aware tie-break: a residual is "reusable" if it is large enough to hold a
    # typical future item. Reward residuals at/above a modest threshold (so the bin can
    # still accept more), mildly reward exact fits (resid == 0) by treating them as closed.
    # This only nudges near-ties, where best-fit would otherwise be indifferent.
    thr = 20.0
    bonus = np.where(resid >= 100, 0.0,
             np.where(resid == 0, 0.05,
              np.where(resid >= thr, 0.02, -0.01)))
    score = score + bonus
    return score
# EVOLVE-BLOCK-END
