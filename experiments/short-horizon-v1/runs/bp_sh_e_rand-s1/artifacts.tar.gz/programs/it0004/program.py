# EVOLVE-BLOCK-START
"""Best-fit with a mild anti-fragmentation / bin-closing bias.

Pure best fit already does well, but on long streams it tends to leave many
partially-filled bins open.  We keep the tight-fit ranking as the dominant term
and add a small bonus for placing the item so that the bin's *new* remaining
capacity lands near 0, plus a tiny preference for already-nonempty bins.  This
nudges the rule toward fully closing bins rather than spreading items thinly.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # remaining capacity after putting the item in each bin

    # Dominant term: tightest fit (smallest leftover gets the highest score).
    score = -rem.astype(np.float64)

    # Anti-fragmentation: reward near-zero leftover more strongly.
    # Push leftover close to 0 with a convex penalty term.
    score -= 0.02 * (rem.astype(np.float64) ** 2) / 100.0

    # Slight preference for reusing bins that already contain items
    # (remaining < 100 means the bin is in use).
    score += 0.05 * (bins < 100)

    return score
# EVOLVE-BLOCK-END
