# EVOLVE-BLOCK-START
"""Best fit with a small reward for fully closing a bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smallest post-placement residual (best fit).
    # Secondary (small tie-break): prefer residual 0 to fully close bins.
    return -residual * 1000.0 - (residual == 0)
# EVOLVE-BLOCK-END
