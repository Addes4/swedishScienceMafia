# EVOLVE-BLOCK-START
"""Best-fit variant that penalizes leaving tiny unusable residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer near-exact fits, avoid small unusable leftovers."""
    residual = bins - item          # remaining capacity after placing item
    residual = np.asarray(residual, dtype=np.float64)

    # Base: smaller residual is better (best-fit).
    score = -residual

    # Penalize tiny positive residuals (wasted slivers that few future items can use).
    # A residual in (0, T] gets a penalty; residual == 0 gets a bonus.
    T = 15.0
    small = (residual > 0) & (residual < T)
    score -= small.astype(np.float64) * (T - residual) * 0.5

    # Small bonus for exact fits.
    score += (residual == 0).astype(np.float64) * 3.0

    return score
# EVOLVE-BLOCK-END
