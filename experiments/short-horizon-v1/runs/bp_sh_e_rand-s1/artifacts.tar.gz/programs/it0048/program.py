# EVOLVE-BLOCK-START
"""Size-class-aware best fit: pack large items tightly, spread small items to avoid waste."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: prefer tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    if item < 60:
        # For smaller items, slightly prefer bins whose residual can still hold
        # another item of similar size, i.e. residual >= item (avoid nearly-full bins).
        small = residual < item
        score = score - np.where(small, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END

