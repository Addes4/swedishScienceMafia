# EVOLVE-BLOCK-START
"""Best fit with scrap-avoidance: prefer tight fits, but avoid leaving unusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # A residual smaller than the largest item seen so far risks never being fillable.
    # Penalize such residuals heavily so a slightly looser fit is preferred when the
    # tightest fit would create (or keep) unfillable scrap. Exact fits (residual 0) are ideal.
    penalty = residual < 0  # never true, all bins fit; keep array same length
    max_item = priority.max_item

    # Bins that would leave a small-but-positive residual below max_item are "scrappy".
    scrappy = (residual > 0) & (residual < max_item)

    # Primary: avoid scrappy residuals. Secondary: best fit (tightest residual).
    score = np.where(scrappy, -1000.0, 0.0) - residual.astype(np.float64)

    # Track the largest item size observed so far (state across calls).
    if item > max_item:
        priority.max_item = item
    return score


priority.max_item = 1
# EVOLVE-BLOCK-END
