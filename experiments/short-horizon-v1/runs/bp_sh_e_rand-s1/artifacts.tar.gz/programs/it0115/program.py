# EVOLVE-BLOCK-START
"""Best fit, with a small nudge away from leaving unusable tiny gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary key is best fit (minimize post-placement residual).  As a tie-break-ish nudge,
    bins that end up exactly full are rewarded, and bins whose leftover is still large
    enough to accept another item of similar size are mildly preferred over those leaving
    a very small residual.
    """
    post = bins - item  # residual after placing the item
    score = -post.astype(np.float64)
    # reward exact fits
    score += 0.001 * (post == 0)
    # mildly prefer leftovers that can still hold a decent-sized item
    score += 0.0005 * (post >= 20)
    return score
# EVOLVE-BLOCK-END
