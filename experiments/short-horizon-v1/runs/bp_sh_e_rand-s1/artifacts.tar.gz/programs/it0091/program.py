# EVOLVE-BLOCK-START
"""Best-fit with a residual-quality tie-break near the tightest fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since bins only contains bins the item fits in
    # Primary: tightest fit. Secondary: small preference for residuals that leave
    # room at least as big as a small typical item, avoiding near-zero leftovers.
    return -(residual.astype(np.float64)) + 0.001 * np.minimum(residual, 20)
# EVOLVE-BLOCK-END

