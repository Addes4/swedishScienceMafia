# EVOLVE-BLOCK-START
"""Best fit with a mild "reusable residual" tilt.

Primary criterion is still tightest post-placement residual (best-fit, optimal on
short streams).  A small secondary term nudges toward bins whose post-placement
residual is near an online estimate of the typical item size, so the leftover
space is likely usable by a future item instead of being wasted.
"""
import numpy as np


def priority(item, bins):
    B = bins.astype(np.float64)
    residual = B - item  # remaining capacity after placing the item

    # Online estimate of typical item size, kept in a module-level accumulator.
    state = priority.state
    if state is None:
        state = {"n": 0.0, "sum": 0.0}
        priority.state = state
    state["n"] += 1.0
    state["sum"] += float(item)
    mean_item = state["sum"] / state["n"]

    # Soft tilt: reward residuals close to the running mean item size.
    # Scale small so best-fit (residual magnitude) stays dominant.
    tilt = -np.abs(residual - mean_item)

    # Dominant term: tightest residual.  Small tilt breaks near-ties.
    return -residual + 0.02 * tilt


priority.state = None
# EVOLVE-BLOCK-END
