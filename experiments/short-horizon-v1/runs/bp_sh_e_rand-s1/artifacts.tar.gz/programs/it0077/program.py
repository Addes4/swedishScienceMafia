# EVOLVE-BLOCK-START
"""Best fit with a consolidation bias for bins whose residue is already small."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Bins whose post-placement residual is zero (exact fill) or below a small
    # threshold are consolidated: we want to fill them up so leftover space is
    # not wasted.  A residual smaller than ~ the smallest plausible item can
    # rarely be reused, so it is nearly as good as an exact fit.
    # Use a fixed small threshold (items are integers >= 1); choosing the
    # current item itself as filler prefers tight packing.
    small = residual <= 0

    if small.any():
        # Exact fits are best.  Among them, an arbitrary but stable choice:
        # return higher score for smaller residual (residual == 0 -> biggest).
        return -residual

    # Otherwise: best fit -- the fullest bin that still fits (smallest residual).
    return -residual
# EVOLVE-BLOCK-END
