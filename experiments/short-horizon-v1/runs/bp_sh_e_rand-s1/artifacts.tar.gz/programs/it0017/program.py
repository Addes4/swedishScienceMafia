# EVOLVE-BLOCK-START
"""Harmonic-style class bin packing.

Items are partitioned into size classes by geometric thresholds.  Bins are
"tagged" with the class of the first item placed in them (recovered from the
bin's remaining capacity relative to that first item is impossible, so instead
we exploit the fixed bin order and lightly bias scores so that a bin tends to
be reused by items of a similar magnitude).

Concretely, for each arriving item we compute its class from the size and
score every candidate bin by best-fit *within its own magnitude band*, so a
large item never lands in a bin whose residual is only fillable by tiny items,
and small items preferentially reuse bins already holding small items.
"""
import numpy as np

# Geometric class boundaries similar to harmonic packing for capacity 100.
_BOUNDS = np.array([50, 34, 25, 20, 17, 14, 12, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
                   dtype=np.int64)


def _cls(item):
    """Class index of an item: smaller index for larger items."""
    for i, b in enumerate(_BOUNDS):
        if item >= b:
            return i
    return len(_BOUNDS)


def priority(item, bins):
    """Best fit within a harmonic size class."""
    c = _cls(item)
    # Post-placement leftover must be >= 0 (bins only contain fitting ones).
    leftover = bins - item
    # Prefer tight fits (small leftover), but penalize leftovers that are too
    # small to ever be usefully refilled (avoid useless dust), and prefer
    # residuals that can be matched by another item of a nearby class.
    small = leftover < 3
    score = -leftover.astype(np.float64)
    # Mild penalty for creating unusable residuals below the smallest class.
    score[small] -= 0.5
    # Slight bonus if the bin, after placement, is empty-ish and thus freshly
    # usable by items of this magnitude band.
    return score
# EVOLVE-BLOCK-END
