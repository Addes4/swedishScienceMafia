# EVOLVE-BLOCK-START
"""Best fit with a bounded subset-sum lookahead over recent item sizes."""
import numpy as np

# State: histogram of recently seen item sizes (kept cheap, list of 101 ints).
_RECENT = [0] * 101
_SEEN = 0
_DECAY = 0


def _common_sizes():
    """Return a small list of the most common recent item sizes."""
    # pick sizes with positive counts; cap the number considered for speed
    sizes = [s for s in range(1, 101) if _RECENT[s] > 0]
    sizes.sort(key=lambda s: -_RECENT[s])
    return sizes[:6]


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    global _SEEN, _DECAY
    bins = np.asarray(bins)

    # Update recent-size statistics.
    _RECENT[item] += 1
    _SEEN += 1
    _DECAY += 1
    if _DECAY >= 256:
        _DECAY = 0
        for s in range(1, 101):
            if _RECENT[s]:
                _RECENT[s] = _RECENT[s] // 2

    # Primary term: best fit (smallest post-placement residual = most negative).
    residual = bins - item
    score = -residual.astype(np.float64)

    # Secondary: small bonus when the residual can be exactly closed by one
    # common item size, or by a pair of common item sizes (subset-sum of size 2).
    common = _common_sizes()
    if common:
        pair_sums = set()
        for a in common:
            pair_sums.add(a)
            for b in common:
                pair_sums.add(a + b)
        # map residual -> bonus
        for i in range(len(bins)):
            r = int(residual[i])
            if r > 0 and r in pair_sums:
                score[i] += 0.5

    return score
# EVOLVE-BLOCK-END
