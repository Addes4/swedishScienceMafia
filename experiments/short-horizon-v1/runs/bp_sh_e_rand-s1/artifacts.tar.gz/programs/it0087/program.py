# EVOLVE-BLOCK-START
"""Best-fit with residual matching to a running mean item size.

Rank bins by how close the post-placement residual is to the running mean item size,
so leftovers stay reusable by future items. Reward exact fits strongly, and use
tighter fit as a tie-break. The mean estimate is seeded and robust so that short
streams behave like best-fit.
"""
import numpy as np

_state = {"sum": 0.0, "count": 0}
_SEED = 40.0  # prior for the mean item size


def priority(item, bins):
    # Update running mean with a prior so short streams stay close to best-fit.
    _state["sum"] += item
    _state["count"] += 1
    mean = (_state["sum"] + _SEED * 4.0) / (_state["count"] + 4.0)

    residual = bins - item  # >= 0 because only fitting bins are shown

    # Match residual to the mean so leftover stays fillable by a typical item.
    match = -np.abs(residual - mean)

    # Strong bonus for exact fits (residual 0).
    exact = (residual == 0).astype(np.float64) * 1e6

    # Secondary tie-break: prefer tighter fits (smaller residual).
    tie = -residual * 1e-3

    return match + exact + tie
# EVOLVE-BLOCK-END
