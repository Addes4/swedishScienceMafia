# EVOLVE-BLOCK-START
"""Matching rule: leave each used bin with a residual close to a typical future item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Target residual: a running estimate of a typical item size.  Start at the
    # distribution mean and update as we observe items.  Bins whose leftover ends
    # up near this target can be refilled by a future item, so prefer them.
    global _sum, _count
    try:
        _sum += item
        _count += 1
    except NameError:
        _sum = item
        _count = 1
    target = _sum / _count

    # Prefer residual close to target, but never worse than tighter fits if the
    # target residual would waste a lot of usable capacity.
    score = -np.abs(residual.astype(np.float64) - target)

    # Strongly favor exact fills (residual 0) and avoid tiny unusable slivers.
    score += np.where(residual == 0, 1e6, 0.0)
    score += np.where((residual > 0) & (residual < target / 4.0), -1e3, 0.0)

    return score
# EVOLVE-BLOCK-END
