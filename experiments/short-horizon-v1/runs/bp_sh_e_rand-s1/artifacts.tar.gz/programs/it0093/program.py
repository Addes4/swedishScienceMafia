# EVOLVE-BLOCK-START
"""Best fit with a residual-reuse tie-break that is safe on short streams.

The primary criterion is pure best fit (tightest post-placement residual), which is
optimal on the short-stream instance. Among bins that leave the same residual, we
prefer the bin whose residual is large enough to still accept a typical item, and
among those the one with the smaller remaining capacity (consolidate load). A fixed
threshold (no online learning) keeps short streams from regressing.
"""
import numpy as np


def priority(item, bins):
    # post-placement residual; smaller is better
    resid = bins - item
    # best fit as the dominant key
    key = -resid.astype(np.float64)
    # small tie-break: prefer residuals >= 20 (room for a typical future item)
    key += 0.25 * (resid >= 20)
    # prefer more-loaded bins (smaller pre-placement remaining) to consolidate
    key += 1e-3 * (100 - bins)
    return key
# EVOLVE-BLOCK-END
