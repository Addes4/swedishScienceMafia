# EVOLVE-BLOCK-START
"""Harmonic-tiered best fit.

Items are drawn from a Weibull-shaped distribution with mean ~40 (heavy mass below 40).
Pure best fit (tightest residual) is strong but leaves lots of unusable scrap.  A classic
cure is *harmonic* packing: partition bin residuals into geometrically spaced size classes
and prefer to use up residuals that fall just at a class boundary, so that leftovers stay in
broad, reusable bands instead of accumulating as tiny fragments.

Implementation choice (practical + fast): for each bin we compute a coarse "band" label of
its residual using integer thresholds.  We strongly prefer bins whose residual lands in the
same band as the arriving item (so the leftover after placing stays in a useful band), then
apply best fit as the fine-grained tie break.  This keeps the rule state-free and O(n) per item.
"""
import numpy as np

# Geometric-ish band edges on remaining capacity 1..100.
_EDGES = np.array(
    [0, 8, 16, 22, 28, 34, 40, 46, 52, 58, 64, 70, 78, 86, 93, 100],
    dtype=np.int64,
)


def _band(x):
    """Return the band index for a residual/commit value x (numpy array)."""
    # searchsorted with right=True gives the number of edges <= x, minus 1.
    return np.searchsorted(_EDGES, x, side="right") - 1


def priority(item, bins):
    """Score each candidate bin; highest score wins (ties -> earliest bin index).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of fitting bins, in bin order.
    """
    bins = np.asarray(bins, dtype=np.int64)

    # Residual left after putting the item here.
    resid = bins - item

    item_band = int(_band(np.array([item], dtype=np.int64))[0])

    # Band of the leftover; prefer leftovers that stay in the same band as the item
    # (keeps scraps grouped) -- reward with a strong bonus.
    resid_band = _band(resid)
    same_band = (resid_band == item_band).astype(np.float64)

    # Secondary: prefer residuals close to the item size (best fit).
    bestfit = -resid.astype(np.float64)

    # Primary: never waste the chance to use an exactly-fitting bin.
    exact = (resid == 0).astype(np.float64)

    # Primary ordering: exact fits, then same-band leftovers, then best fit.
    return exact * 1e6 + same_band * 1e3 + bestfit
# EVOLVE-BLOCK-END
