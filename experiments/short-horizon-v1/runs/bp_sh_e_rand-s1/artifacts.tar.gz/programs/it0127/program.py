# EVOLVE-BLOCK-START
"""Worst-fit variant: spread load by preferring bins with more remaining space,
but discourage opening brand-new (capacity-100) bins until necessary."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Worst-fit: prefer larger residual so loads stay balanced.
    score = residual.astype(np.float64)
    # Penalize empty/unused bins so we only open fresh capacity when needed.
    empty = bins == 100
    score[empty] -= 1e6
    return score
# EVOLVE-BLOCK-END
