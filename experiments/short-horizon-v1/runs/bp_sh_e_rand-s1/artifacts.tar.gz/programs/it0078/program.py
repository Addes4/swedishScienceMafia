# EVOLVE-BLOCK-START
"""Best fit with a mild balancing bonus toward reusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # leftover capacity after placing the item here
    # Best fit: prefer the smallest residual. Add a tiny bonus that favors residuals
    # not so small they become unusable, keeping scores monotone in tightness.
    score = -residual.astype(np.float64)
    # Mild preference against leaving a residual smaller than a typical small item.
    tiny = residual < 20
    score += tiny * 0.5
    return score
# EVOLVE-BLOCK-END
