# EVOLVE-BLOCK-START
"""Best fit plus a bonus for leftovers that match likely future item sizes."""
import numpy as np

# Items are integers 1..100 from a Weibull-shaped distribution (mean ~40).
# A leftover of size L after placement is valuable if it is a "common" item size,
# because the next item may fill it exactly. Small leftovers are common fillers.
# We give a big bonus for exact-fill-ish small leftovers and otherwise fall back to best fit.

# approximate probability weight of each possible item size (heuristic, distribution-free
# but shaped like the target): mid sizes are more common than extremes.
_SIZES = np.arange(1, 101)
# triangular-ish weight peaking around 40
_W = np.exp(-0.5 * ((_SIZES - 40.0) / 18.0) ** 2)
_W = _W / _W.sum()


def priority(item, bins):
    bins = np.asarray(bins)
    leftover = bins - item  # >= 0 for all shown bins

    # Base: prefer tightest fit (smallest leftover).
    score = -leftover.astype(np.float64)

    # Bonus: leftover matches a common item size -> likely to be filled later.
    idx = leftover - 1
    valid = (idx >= 0) & (idx < 100)
    w = np.where(valid, _W[np.clip(idx, 0, 99)], 0.0)
    score += 8.0 * w

    # Exact perfect fill gets an extra big push.
    score += 5.0 * (leftover == 0)

    return score
# EVOLVE-BLOCK-END
