# EVOLVE-BLOCK-START
"""Best fit with a small/medium-item consolidation rule.

Items larger than THRESH use classic best fit (tightest residual).
Smaller items additionally prefer bins whose post-placement residual is either
close to 0 (perfect packing) or still large enough to accept another typical
item, to avoid creating many tiny unusable gaps.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)
    post = bins - item  # residual after placing the item here
    # Primary: minimize post-placement residual (best fit).
    primary = -post.astype(np.float64)

    # Secondary adjustment: for relatively small items, penalize creating a
    # tiny residual that likely can't be reused, and reward exact fits.
    is_small = item <= 40
    if is_small:
        # Residual just above 0 but below `item` is "wasted" space.
        tiny = (post > 0) & (post < item)
        bonus = np.where(post == 0, 1.0, 0.0) - np.where(tiny, 0.5, 0.0)
        # Scale small enough to act only as a mild tie-breaker within best fit.
        return primary + 0.01 * bonus
    return primary
# EVOLVE-BLOCK-END
