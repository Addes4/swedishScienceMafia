# EVOLVE-BLOCK-START
"""Best-fit with a small, stateful reserve bias toward reusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # State: a small histogram of recent item sizes to estimate a useful reserve.
    hist = priority.hist
    mode = priority.mode
    if hist is None:
        hist = np.zeros(101, dtype=np.int64)
        priority.hist = hist
    hist[item] += 1

    # Estimate the most common small item size seen so far (used as reserve target).
    total = hist.sum()
    if total >= 32:
        small = hist[1:31]
        if small.sum() > 0:
            mode = 1 + int(np.argmax(small))
            priority.mode = mode

    residual = bins - item  # remaining capacity after placing the item

    # Base best-fit score (dominant).
    score = -residual.astype(np.float64)

    # Reserve bias: reward residuals that are 0 or at least the mode size
    # (so the leftover space can still hold a typical small item), and reward
    # residuals that are exactly 0 (perfectly filled) most.
    r = mode if mode is not None else 0
    if r > 0:
        # small penalty for tiny unusable residuals in (0, r)
        tiny = (residual > 0) & (residual < r)
        perfect = residual == 0
        # weights chosen to stay well below 1 of a capacity unit
        score = score + 0.4 * tiny.astype(np.float64) - 0.6 * perfect.astype(np.float64)

    return score


priority.hist = None
priority.mode = None
# EVOLVE-BLOCK-END
