# EVOLVE-BLOCK-START
"""Best fit with a boost for near-perfect fits (sub-minimum residuals)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer tighter fits: smaller residual -> higher priority.
    score = -residual.astype(np.float64)
    # Strongly favor bins that would be left with a residual so small it is
    # likely unusable by any future item (near-perfect fill).
    near_perfect = residual < 8
    score[near_perfect] += 100.0
    return score
# EVOLVE-BLOCK-END
