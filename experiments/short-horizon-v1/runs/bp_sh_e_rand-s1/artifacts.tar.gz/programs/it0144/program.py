# EVOLVE-BLOCK-START
"""Stateful best-fit with dominance/scrap rescue.

Primary rule: classic best fit (tightest residual after placement wins).
Rescue rule: if the best-fit choice would leave a residual that no recently
seen item size can fill (an unfillable scrap), and another fitting bin
would leave a *usable* residual, prefer the usable one whose residual is
closest to a common item size (best match for future packing).
"""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    bins = np.asarray(bins)
    # classic best fit residual
    resid = bins - item

    # update rolling histogram of item sizes (exponential forgetting)
    h = _state["hist"]
    h *= 0.999
    h[item] += 1.0
    _state["n"] += 1

    # a residual is "usable" if it is 0 (perfect) or can fit some item size seen
    # we approximate with the smallest item size with non-trivial mass, capped
    total = h.sum()
    if total > 0:
        cum = np.cumsum(h)
        # smallest item size s such that P(size <= s) >= 0.15
        small = int(np.searchsorted(cum, 0.15 * total))
        if small < 1:
            small = 1
    else:
        small = 1

    # best fit candidate
    best = int(np.argmin(resid))
    best_r = int(resid[best])

    score = -resid.astype(np.float64)

    # If best-fit leaves a small unfillable scrap (0 < resid < small and not zero),
    # look for an alternative bin whose residual is usable and close to a common size.
    if 0 < best_r < small:
        # usable residuals: zero, or >= small
        usable = (resid == 0) | (resid >= small)
        if usable.any():
            # among usable, prefer smallest residual >= small (tight usable fit),
            # else exact zero
            alt_res = resid.copy()
            alt_res[~usable] = 10**9
            # closeness to common item sizes: measure distance to nearest mode-ish size
            # approximate common size as the histogram-weighted nearest integer
            # precompute common sizes set
            cand = int(np.argmin(alt_res))
            if alt_res[cand] < 10**9 and cand != best:
                # boost alternative slightly above best fitness
                boost = float(bins.max() - item + 2.0)
                score[best] = score[best] - boost  # demote best
                score[cand] = score[cand] + boost  # promote candidate
    return score
# EVOLVE-BLOCK-END
