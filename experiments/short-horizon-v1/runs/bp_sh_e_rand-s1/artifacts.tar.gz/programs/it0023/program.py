# EVOLVE-BLOCK-START
"""Best fit with a fullness tie-break among near-equal residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest score.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    residual = bins - item              # leftover after placing the item
    # Prefer smallest residual (best fit), but among residuals within a tiny
    # tolerance prefer the currently fullest bin (smallest `bins`), which helps
    # close bins to exactly full on Weibull-shaped streams.
    score = -residual * 1000.0 - bins
    return score
# EVOLVE-BLOCK-END
