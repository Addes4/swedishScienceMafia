# EVOLVE-BLOCK-START
"""Best fit with exact-fit bonus and consolidation tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual). Bonus for exact fit.
    exact_bonus = (residual == 0).astype(np.float64) * 0.5
    # Secondary tie-break: prefer bins that were more loaded (smaller bins remaining),
    # i.e. smaller residual already implies tighter; use tiny weight on residual so it
    # never flips the primary ordering.
    return -residual.astype(np.float64) + exact_bonus
# EVOLVE-BLOCK-END

