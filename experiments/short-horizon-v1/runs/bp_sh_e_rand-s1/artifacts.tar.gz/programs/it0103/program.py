# EVOLVE-BLOCK-START
"""Waste-aware best fit.

Primary goal: never leave a residual so small that no future item can use it
while also not being able to fit the current item tightly.

Rule:
  1. Exact fit (residual 0) is always best -> huge bonus.
  2. Otherwise prefer bins where the residual after placement is small, but
     penalise residuals that fall below a threshold derived from an online
     estimate of the typical item size, because such residuals are likely to
     be wasted.  The estimate is updated from items seen so far.
"""
import numpy as np

_state = {"n": 0, "mean": 40.0}


def priority(item, bins):
    m = _state["mean"]
    # online estimate of typical item size (running mean)
    _state["n"] += 1
    _state["mean"] += (item - m) / _state["n"]
    m = _state["mean"]

    residual = bins - item  # remaining capacity after placing the item

    # threshold below which a residual is deemed likely wasted
    thresh = max(1.0, 0.5 * m)

    # small residuals (< thresh) are penalised proportionally to how far
    # below the threshold they fall; residuals >= thresh get no penalty.
    penalty = np.where(residual < thresh, (thresh - residual), 0.0)

    # exact fits dominate everything
    exact = (residual == 0).astype(float) * 1e9

    # base: tightest residual first (best fit)
    return exact - residual - penalty
# EVOLVE-BLOCK-END
