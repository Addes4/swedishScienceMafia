# EVOLVE-BLOCK-START
"""Hybrid: first-fit for loose fits, best-fit for tight fits."""
import numpy as np

TIGHT_FRACTION = 0.5


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    n = bins.shape[0]
    # Prefer tight fits: residual < TIGHT_FRACTION * item
    tight = residual < (TIGHT_FRACTION * item)
    # Base score: earliest bin wins by index ordering (use negative index).
    # When tight fits exist, restrict to tight bins by giving them a large bonus.
    idx = np.arange(n)[::-1]  # earlier bins get higher base score
    score = idx.astype(np.float64)
    if np.any(tight):
        score = np.where(tight, 1e9 - residual.astype(np.float64), score)
    return score
# EVOLVE-BLOCK-END
