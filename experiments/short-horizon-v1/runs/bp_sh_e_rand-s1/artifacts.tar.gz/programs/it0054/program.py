# EVOLVE-BLOCK-START
"""Best-fit with a size-aware reserve for small items.

Idea: pure best-fit packs small items into the fullest fitting bin, which often
leaves a tiny unusable residual.  For small items we instead insist that the
post-placement residual stays meaningfully large (>= reserve); when several such
bins exist we still take the tightest fit.  Large items use plain best-fit.
"""
import numpy as np


def priority(item, bins):
    """Priority for every bin; highest score chosen, first on ties.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacities of the fitting bins (bin order).
    """
    residual = bins - item  # >= 0 for every bin shown

    if item <= 20:
        # Small item: avoid leaving a useless sliver behind.
        reserve = 20 - item  # keep roughly a quarter-bin of usable space
        ok = residual >= reserve
        # Bins satisfying the reserve: tightest fit (smallest residual) wins.
        # Bins failing it: strongly penalized, ordered by residual too.
        score = np.where(ok, -residual, -residual - 1000.0)
    else:
        # Medium/large item: plain best-fit.
        score = -residual.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
