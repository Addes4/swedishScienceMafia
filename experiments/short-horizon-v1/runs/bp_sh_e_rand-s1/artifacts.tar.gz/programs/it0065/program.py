# EVOLVE-BLOCK-START
"""Best fit with a reuse-value correction.

The item goes into the bin whose post-placement residual is smallest (best fit),
but among closely tied residuals we prefer leftovers that are likely to be
reusable by future items, estimated from a running histogram of item sizes.
"""
import numpy as np

# Running histogram of observed item sizes (1..100), shared across calls.
_HIST = np.ones(101, dtype=np.float64)  # Laplace smoothing
_TOTAL = 101.0


def _reuse_value(res):
    """Estimated probability that a future item fits in a bin with residual `res`.

    Uses the running empirical distribution of item sizes.  Larger residual =>
    higher reuse value, but we care about the *shape* rather than raw size, so
    we return the cumulative mass of items <= res.
    """
    r = int(res)
    if r <= 0:
        return 0.0
    if r > 100:
        r = 100
    return _HIST[:r + 1].sum() / _TOTAL


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    global _TOTAL
    # Update the running histogram with the current item.
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _TOTAL += 1.0

    residuals = bins - item  # >= 0 since bins is pre-filtered to fitting bins

    # Best-fit dominant term: smaller residual => larger score.
    bf = -residuals.astype(np.float64)

    # Reuse-value correction: reward leftovers that can host future items.
    # Vectorized cumulative mass lookup, then scale to stay a tie-breaker.
    r = np.clip(residuals, 0, 100).astype(np.int64)
    cum = np.concatenate(([0.0], np.cumsum(_HIST)))
    reuse = cum[r + 1] / _TOTAL

    # Small weight so best-fit remains dominant but reuse breaks near-ties.
    return bf + 0.5 * reuse
# EVOLVE-BLOCK-END
