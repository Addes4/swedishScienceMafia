# EVOLVE-BLOCK-START
"""Best-fit with a smooth penalty against unfillable scraps.

Pure best-fit minimizes the post-placement residual, but that can leave small
scraps (e.g. residual 2-8) that no future item is likely to fill, turning them
into permanent waste.  We keep exact/near-exact fits as the top priority but
add a mild bonus for residuals that lie in the band of typical future item
sizes, so that whole bins can still be completed by a single later item.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item here

    # Base score: prefer smaller residual (best-fit).
    score = -residual.astype(np.float64)

    # Bonus for residuals that a typical future item (mean ~40) could fill well.
    # Penalize tiny positive scraps (hard to complete) and reward mid-range gaps.
    # r == 0 (exact fit) is already strongly favored by the base score.
    r = residual.astype(np.float64)
    # Penalty grows as r is small-but-positive (unfillable) or far above typical.
    target = 40.0
    # smooth: max around target, small near 0, decaying for very large r
    band_bonus = 2.0 * np.exp(-((r - target) / 25.0) ** 2)
    scrap_penalty = 3.0 * np.exp(-((r - 3.0) / 4.0) ** 2)  # discourage 1..6 scraps

    return score + band_bonus - scrap_penalty
# EVOLVE-BLOCK-END
