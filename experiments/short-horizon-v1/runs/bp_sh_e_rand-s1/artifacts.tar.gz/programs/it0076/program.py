# EVOLVE-BLOCK-START
"""Best fit with reinforcement of reusable residuals."""
import numpy as np

_state = {"mean": 40.0, "n": 0.0}


def priority(item, bins):
    """Rank bins for the arriving item: prefer tight fits, favor reusable leftovers."""
    _state["n"] += 1.0
    a = 1.0 / _state["n"]
    _state["mean"] = (1.0 - a) * _state["mean"] + a * float(item)
    mean = _state["mean"]

    residual = bins - item  # remaining capacity if item is placed here (>= 0)

    # Base: prefer smallest residual (best fit).
    score = -residual.astype(np.float64)

    # Reward residuals that are almost zero (very tight) a little extra.
    score -= 0.05 * residual

    # Reward residuals close to the typical item size, which keeps the bin
    # reusable for a future average-sized item (reduces fragmentation).
    score -= 0.02 * np.abs(residual - mean)

    return score
# EVOLVE-BLOCK-END
