# EVOLVE-BLOCK-START
"""Best fit, but strongly prefer exactly closing a bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: bins whose remaining capacity exactly equals the item (perfect fill).
    exact = (bins == item).astype(np.float64)
    # Secondary: best fit -> smallest post-placement residual.
    bf = -(bins - item).astype(np.float64)
    return exact * 1e6 + bf
# EVOLVE-BLOCK-END
