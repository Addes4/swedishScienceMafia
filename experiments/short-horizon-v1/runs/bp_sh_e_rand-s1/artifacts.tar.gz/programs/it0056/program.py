# EVOLVE-BLOCK-START
"""Best-fit with a light stateful residual-preference for likely future fills."""
import numpy as np


_STATE = {"seen": 0, "hist": None}


def priority(item, bins):
    """Rank bins mostly by best fit, with a small tie-bonus for fillable residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (all bins the item fits in).
    """
    n = bins.shape[0]

    # Stateful histogram of item sizes (1..100), initialized lazily.
    if _STATE["hist"] is None:
        _STATE["hist"] = np.zeros(101, dtype=np.float64)
    hist = _STATE["hist"]

    # Primary key: smaller residual after placement is better (best fit).
    residual = bins - item
    best = residual.min()

    # Build a lightweight "future fill" score for residuals near the best.
    # Only consider residual values within a small window above best.
    window = 8
    mask = residual <= best + window
    scores = -residual.astype(np.float64)

    if np.any(mask):
        # Prefer residuals that are likely to be exactly filled by a future item.
        # Use recent histogram mass of exact sizes, weighted mildly.
        # residual in [0, 100]
        idx = residual[mask].astype(np.int64)
        idx = np.clip(idx, 0, 100)
        freq = hist[idx]
        # normalize to avoid dominating the best-fit ordering
        maxf = freq.max()
        if maxf > 0:
            bonus = (freq / maxf) * 0.25
            scores[mask] += bonus

    # Update state after scoring (order within call is fine).
    _STATE["seen"] += 1
    hist[item] += 1.0
    # Slow decay to keep it recency-aware.
    if _STATE["seen"] % 64 == 0:
        hist *= 0.9

    return scores
# EVOLVE-BLOCK-END
