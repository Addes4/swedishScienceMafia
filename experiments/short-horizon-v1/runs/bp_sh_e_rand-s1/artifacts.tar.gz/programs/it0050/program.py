# EVOLVE-BLOCK-START
"""Tunable best-fit with a stateful residual-matching tie-break.

The dominant term is still best fit: bins whose post-placement residual is small
are strongly preferred, because tight packing usually wastes the least space.
On top of that we keep light running statistics of the item stream and, among
bins whose residual is close to the best-fit residual, mildly prefer residuals
that look like a plausible next item size (so the gap can actually be filled
later instead of being stranded). This only reorders near-ties, so the worst
case stays close to plain best fit.
"""
import numpy as np

_MEAN = 40.0          # initial estimate of the item mean (problem statement)
_ALPHA = 0.02         # EWMA rate for the running item mean
_RESID_BAND = 3       # residual difference considered "near a tie"
_MATCH_SIGMA = 8.0    # width of the bonus around the running mean


def priority(item, bins):
    """Score each bin: primarily best fit, lightly nudged toward fillable gaps."""
    global _MEAN

    # Running mean of recent items (stateful, cheap, no future info used).
    _MEAN += _ALPHA * (item - _MEAN)
    mu = _MEAN

    # Post-placement residual for every bin.
    resid = bins - item

    # Primary key: smaller residual (best fit) is better.
    score = -resid.astype(np.float64)

    # Light bonus when the residual is near a likely future item size,
    # strong only in the near-tie band so best-fit order is barely perturbed.
    r = resid.astype(np.float64)
    match = np.exp(-((r - mu) ** 2) / (2.0 * _MATCH_SIGMA * _MATCH_SIGMA))
    # Exact-ish complements are also good: residual that a small item could take.
    match += 0.5 * np.exp(-(r * r) / (2.0 * 6.0 * 6.0))

    # Apply the bonus only where the residual is close to the minimum residual,
    # i.e. among serious candidates.
    rmin = r.min()
    in_band = (r <= rmin + _RESID_BAND).astype(np.float64)

    return score + 0.75 * match * in_band
# EVOLVE-BLOCK-END
