# EVOLVE-BLOCK-START
"""Best fit with a mild consolidation-aware tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary: minimize post-placement residual (best fit).
    Secondary: among equal residuals, prefer the fuller bin (smaller pre residual),
    encoded with a small fractional component.
    """
    post = bins - item
    # Primary term dominates; secondary breaks ties toward fuller bins.
    return -(post * 128.0 + bins * 0.5)
# EVOLVE-BLOCK-END
