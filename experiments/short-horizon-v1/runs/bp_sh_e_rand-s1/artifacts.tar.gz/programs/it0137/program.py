# EVOLVE-BLOCK-START
"""Harmonic-style bin ranking with best-fit within residual bands.

Items arrive online. Pure best-fit is strong but leaves unusable scrap residuals.
We rank bins by a tiered "harmonic" bucket of their residual capacity: residuals
are grouped into bands sized relative to the current item and recent items, so
that bins whose residual is comfortably large enough to accept future items of
similar size are preferred, while within a band we still pick the tightest fit.
This is a stateless-in-effect rule (bands depend only on the given residual),
so it behaves well on very short streams too.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    r = np.asarray(bins, dtype=np.float64)

    # Band edges: partition residual space into classes [0, item), [item, 2*item),
    # [2*item, 3*item), ... but cap the number of bands for stability.
    # A bin whose residual is in a lower (tighter) band is preferred, so the item
    # goes into the smallest usable bin class first. Within a class, best-fit.
    step = float(item)
    if step < 1.0:
        step = 1.0

    # band index: which multiple of `step` the residual falls into
    band = np.floor(r / step + 1e-9)

    # Primary key: lower band preferred (i.e. tighter residual classes get filled
    # before spilling into larger ones), and within a band smaller residual wins.
    # We encode as a lexicographic-ish tuple via a large weight on the band.
    score = -(band * 1000.0 + r)
    return score
# EVOLVE-BLOCK-END
