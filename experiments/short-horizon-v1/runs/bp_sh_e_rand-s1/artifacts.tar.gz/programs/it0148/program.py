# EVOLVE-BLOCK-START
"""Best-fit with a stateful tie-breaker that avoids unfillable tiny scraps."""
import numpy as np

_state = {"small": 100}


def priority(item, bins):
    """Rank bins: primarily tightest fit; tie-break toward fillable residuals."""
    if item < _state["small"]:
        _state["small"] = item
    small = _state["small"]

    residual = bins - item  # >= 0 by construction
    # Primary: tighter fit (smaller residual) is better.
    primary = -residual.astype(np.float64)
    # Secondary bonus: a residual that can still host a future small item is
    # preferred over a tiny scrap; scaled tiny so it only breaks near-ties.
    usable = (residual >= small).astype(np.float64)
    scrap = (residual > 0) & (residual < small)
    secondary = usable * 1e-3 - scrap * 1e-3
    # Among fully empty bins (residual 100 -> 100-item), deprioritize slightly
    # so we don't open new bins when a used bin would do.
    return primary + secondary
# EVOLVE-BLOCK-END
