# EVOLVE-BLOCK-START
"""Best-fit with a hash-based tie-break among equally tight fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    # Primary: best fit (smallest residual after placement) -> larger (more negative) score.
    base = -residual.astype(np.float64)
    # Small deterministic tie-break depending on residual, breaking strict ties toward
    # bins whose resulting residual is slightly larger (less likely to strand tiny scraps).
    tie = (np.floor(residual / 3.0)).astype(np.float64) * 1e-3
    return base + tie
# EVOLVE-BLOCK-END
