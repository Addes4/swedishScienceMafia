# EVOLVE-BLOCK-START
"""Worst-fit with exact-fill priority.

The item goes into the fullest bin if it exactly fits; otherwise it goes into the
emptiest bin that still accommodates it (worst fit). Worst fit tends to keep bins
balanced, avoiding many unusable slivers when item sizes are heavy-tailed.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for every visible bin
    exact = residual == 0
    # Worst fit: prefer larger remaining capacity -> larger score.
    score = bins.astype(np.float64)
    # Strongly prefer exact fills.
    score = np.where(exact, score + 1e6, score)
    return score
# EVOLVE-BLOCK-END
