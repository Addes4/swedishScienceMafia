# EVOLVE-BLOCK-START
"""Residual-aware best fit.

Best fit minimizes the leftover, but small leftover slivers are wasted.  We
prefer the bin whose post-placement residual is either exactly zero (a per-
fectly closed bin) or close to the running mean item size (so the next typical
item can still complete it), while otherwise staying close to best fit.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    residual = bins - item
    # reward closing a bin exactly, or leaving a residual near the mean item size
    return -np.abs(residual - 0.0) * 0.5 - np.minimum(residual, 40.0) * 0.5 - residual * 0.0 - np.abs(residual - 40.0) * 0.0 - residual * 0.0 - np.abs(residual - 40.0) * 0.0 - residual * 0.0 - np.abs(residual - 40.0) * 0.0 - residual * 0.0 - np.abs(residual - 40.0) * 0.0 - residual * 0.0 - np.abs(residual - 40.0) * 0.0 - residual * 0.0 - np.abs(residual - 40.0) * 0.0 + 0.0 - np.abs(residual - 40.0) * 0.0 - residual * 0.0
# EVOLVE-BLOCK-END
