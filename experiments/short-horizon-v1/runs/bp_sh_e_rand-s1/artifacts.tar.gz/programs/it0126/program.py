# EVOLVE-BLOCK-START
"""Best-fit but avoid opening fresh bins while an existing partly-used bin can hold the item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Empty bins have remaining capacity exactly 100.
    empty = bins >= 100
    # Any non-empty bin available?
    has_nonempty = np.any(~empty)
    if has_nonempty:
        # Prefer non-empty bins strongly via best-fit; empty bins get a large penalty.
        score = -(bins - item).astype(np.float64)
        score[empty] -= 1000.0
        return score
    # Only empty bins fit (item larger than any free residual) -> best fit among them.
    return -(bins - item).astype(np.float64)
# EVOLVE-BLOCK-END
