# EVOLVE-BLOCK-START
"""Best-fit with a scrap-aware tie-break that keeps residuals usable."""
import numpy as np


def priority(item, bins):
    """Rank bins; the item goes to the highest score (first on ties).

    Primary order is best-fit (smallest residual that still fits). Ties and near-ties
    are broken to avoid leaving residuals that are too small to be useful.
    """
    residual = bins - item  # >= 0 for all bins we are shown
    # Primary: best fit -> larger score for smaller residual.
    # Small epsilon * (residual usefulness penalty) to break near-ties toward
    # residuals that are not tiny scraps.
    # A residual of 0 is perfect (exact fill). Otherwise, residuals in [1, 4]
    # tend to be hard to reuse for a Weibull-shaped stream with mean ~40 but
    # still better than leaving larger gaps when a tighter fit exists.
    # We keep best-fit dominant by scaling: score = -residual - tiny*scrap_penalty
    small = (residual > 0) & (residual < 5)
    penalty = np.where(small, (5 - residual) * 0.001, 0.0)
    return -residual.astype(np.float64) - penalty
# EVOLVE-BLOCK-END
