# EVOLVE-BLOCK-START
"""Best fit with a small-residual reserve: avoid leaving useless slivers.

Idea: pure best fit often leaves a tiny residual (e.g. 1..5) that no future item can
use, wasting space. For items that are not themselves tiny, prefer the bin whose
post-placement residual is either exactly 0 or at least a reserve floor R (a typical
small-item size), and otherwise fall back to plain best fit. This is a low-risk
perturbation that keeps best-fit's tightness while reducing wasted sliver space.
"""
import numpy as np

# Reserve floor: residuals below this are considered "useless slivers".
R = 6


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest."""
    residual = bins - item  # post-placement remaining capacity (>=0 since item fits)

    # Base: plain best fit (prefer smallest residual).
    score = -(residual.astype(np.float64))

    # Bonus for bins that end with residual 0 (perfectly filled).
    perfect = (residual == 0).astype(np.float64)
    score += 0.4 * perfect

    # Penalize residuals that are small-but-not-zero slivers, unless the item itself
    # is tiny (in which case we cannot afford to be picky).
    if item > R:
        sliver = ((residual > 0) & (residual < R)).astype(np.float64)
        score -= 0.25 * sliver

    return score
# EVOLVE-BLOCK-END
