# EVOLVE-BLOCK-START
"""Stateful best-fit with a waste-avoidance tie-break.

Primary key: best fit (smallest post-placement residual).
Tie-break: among bins whose residual is within a small tolerance of the minimum,
prefer the residual that corresponds to a "useful" gap, i.e. one likely to be
matched by a typical future item (near the running mean), rather than leaving a
tiny unfillable scrap.  Exact fits are always strongly preferred.

This keeps the strong best-fit behaviour but nudges away from generating many
nearly-full bins that can only accept the smallest items.
"""
import numpy as np

_MEAN = 40.0
_N = 0


def priority(item, bins):
    global _MEAN, _N
    # Update a running estimate of the mean item size (simple EWMA-free mean).
    _N += 1
    _MEAN += (item - _MEAN) / _N

    residual = bins - item  # post-placement remaining capacity, >= 0

    # Primary: smaller residual is better -> negate.
    score = -residual.astype(np.float64)

    # Tie-break bonus: residual close to a "typical" future item (near mean) is good.
    # Tiny scraps (residual in 1..few) are penalised mildly to avoid unfillable holes.
    r = residual.astype(np.float64)
    typical = _MEAN
    # closeness to a typical future item size, in [0,1]
    closeness = 1.0 - np.minimum(np.abs(r - typical) / typical, 1.0)
    # penalise very small nonzero scraps
    scrap = np.where((r > 0) & (r < typical * 0.5), 1.0, 0.0)

    score += 1e-3 * closeness - 1e-3 * scrap
    return score
# EVOLVE-BLOCK-END
