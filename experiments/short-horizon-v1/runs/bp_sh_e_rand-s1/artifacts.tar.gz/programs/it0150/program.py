# EVOLVE-BLOCK-START
"""Best fit with a consolidation tiebreaker on near-equal fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary key: tightest fit (smallest post-placement residual) -> best fit.
    Tiebreaker (near-ties within a small tolerance): prefer the bin that is already fuller
    (smaller remaining capacity), consolidating fills into fewer, more-full bins.
    """
    residual = bins - item
    # Primary: prefer smallest residual (best fit). Negate so higher score = better.
    # Secondary: among near-ties, prefer smaller bins (fuller), i.e. smaller `bins`.
    tol = 2
    order = np.argsort(residual, kind="stable")
    # Build rank: primary residual, then bin fullness for near-equal residuals.
    # Combine: score = -(residual * BIG + bins) where BIG dominates so residual leads.
    # But near-tie tolerance handled by bucketing residual//tol.
    bucket = residual // tol
    return -(bucket.astype(np.float64) * 1e6 + bins.astype(np.float64))
# EVOLVE-BLOCK-END
