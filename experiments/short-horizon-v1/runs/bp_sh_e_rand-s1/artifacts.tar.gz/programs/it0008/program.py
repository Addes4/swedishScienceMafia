# EVOLVE-BLOCK-START
"""Stateful best fit with a compatibility bonus for leftover sizes.

Plain best fit minimizes immediate leftover, but it can create awkward residuals that no
future item ever closes.  Track the empirical distribution of arriving item sizes and give
bins a small bonus when the residual left after placing the item is itself a size that
commonly appears in the stream, so the leftover is likely to be filled later.
"""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    counts = _state["counts"]
    n = _state["n"]

    rem = bins.astype(np.float64)
    after = rem - item  # leftover if placed here, >= 0 for all shown bins

    # Empirical complement usefulness: how often an item of size `after` is seen.
    if n > 0:
        freq = counts / n
    else:
        freq = np.zeros(101, dtype=np.float64)

    idx = after.astype(np.int64)
    complement = freq[np.clip(idx, 0, 100)]

    # Best fit dominance: strongly penalize leftover size.  Small bonus scaled to how
    # likely that residual is to be matched by a future item.
    score = -after * 1.0 + complement * 60.0

    # Update stream statistics with this item.
    counts[item] += 1.0
    _state["n"] = n + 1.0

    return score
# EVOLVE-BLOCK-END
