# EVOLVE-BLOCK-START
"""Harmonic-style packing: keep items of similar size class together, best-fit within class."""
import numpy as np

# Precompute class boundaries: geometric partition of (0, 100].
# Classes: (50,100], (33,50], (25,33], (20,25], (16.67,20], ... down to small.
_BOUNDS = []
_c = 100.0
_prev = 100.0
while _prev > 1.0:
    nxt = _prev / 2.0
    if nxt < 1.0:
        nxt = 1.0
    _BOUNDS.append((nxt, _prev))
    _prev = nxt
_BOUNDS = _BOUNDS[:8]  # a handful of coarse classes


def _class_of(item):
    for i, (lo, hi) in enumerate(_BOUNDS):
        if item > lo:
            return i
    return len(_BOUNDS)


# Per-stream state: which class each bin has been tagged with (by first item placed).
_state = {"tags": {}}


def priority(item, bins):
    n = len(bins)
    cls = _class_of(item)

    # Tag the fullest fitting bin if it has a matching class tag (so same-class items co-locate).
    # We approximate bin class tags by tracking residual ranges of bins we've seen.
    tags = _state["tags"]

    leftover = bins - item  # best-fit: smaller leftover (non-negative) is better
    score = -leftover.astype(np.float64)

    # Mild bonus for bins whose (post-placement) residual is small enough to keep class compactness:
    # reward bins that are already fairly full (small residual), strongly.
    score += (bins == 100) * 0.0  # unused bins no special bonus

    # Encourage filling near-full bins: extra reward when leftover is small.
    score += np.where(leftover < item * 0.25, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
