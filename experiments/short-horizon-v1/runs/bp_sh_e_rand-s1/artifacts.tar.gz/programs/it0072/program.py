# EVOLVE-BLOCK-START
"""Best-fit with a tiny-residual consolidation bonus.

Score = tightest fit (dominates), plus a bonus for leaving zero residual,
minus a penalty for leaving a small but nonzero residual that would likely
be unusable for typical future items.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for shown bins
    # Base: tightest fit wins (smaller residual -> larger score).
    score = -residual.astype(np.float64)
    # Bonus for exact fit.
    score += 1e6 * (residual == 0)
    # Small penalty for tiny nonzero residuals (likely wasted space).
    # Threshold: items are Weibull-ish mean ~40, but small items exist.
    tiny = (residual > 0) & (residual < 5)
    score -= 1e3 * tiny
    return score
# EVOLVE-BLOCK-END
