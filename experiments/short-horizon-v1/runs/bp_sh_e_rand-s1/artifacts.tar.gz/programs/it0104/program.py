# EVOLVE-BLOCK-START
"""Best-fit restricted to bins that leave a reusable residual (>= item mean)."""
import numpy as np

_MEAN = 40.0  # approximate mean item size


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Prefer bins whose resulting residual is still >= the mean item size, i.e. the
    # leftover space is likely to be usable by a future item.  Among those, tightest fit
    # wins (smaller residual => higher score).  Bins leaving a too-small residual get a
    # large penalty so they are only used as a last resort.
    usable = residual >= _MEAN
    score = np.where(usable, -residual.astype(float), -residual.astype(float) - 1e6)
    return score
# EVOLVE-BLOCK-END

