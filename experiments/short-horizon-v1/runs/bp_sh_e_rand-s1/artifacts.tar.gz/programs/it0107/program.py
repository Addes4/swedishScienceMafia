# EVOLVE-BLOCK-START
"""Best fit with a secondary tie-break that prefers the fuller bin.

Primary: minimize post-placement residual (classic best fit).
Secondary: among ties, prefer the bin with the smaller pre-placement residual
(equivalently the fuller bin), which tends to consolidate items into already-used
bins and leaves empty bins untouched.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    post = bins - item                      # residual after placing the item
    # Encode lexicographic order (smaller post first, then smaller bins first) into a
    # single descending score.  post in [0, 100], bins in [item, 100].
    return -(post * 101 + (bins - item))
# EVOLVE-BLOCK-END
