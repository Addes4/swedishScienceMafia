# EVOLVE-BLOCK-START
"""Residual-aware best fit: minimize waste while avoiding tiny unusable leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item  # >= 0 for all shown bins

    # Base: prefer small leftover (tight fit), like best fit, but with a convex penalty
    # that makes near-perfect fills dominant.
    score = -leftover.astype(np.float64)

    # Penalize leaving a small but nonzero leftover (hard to reuse efficiently),
    # while a leftover of exactly 0 is best and a larger leftover is more reusable.
    small = (leftover > 0) & (leftover <= 12)
    score[small] -= (13.0 - leftover[small])

    # Mildly prefer reusing already-used bins over opening a fresh empty bin.
    score[bins == 100] -= 0.5

    return score
# EVOLVE-BLOCK-END
