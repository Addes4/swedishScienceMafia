# EVOLVE-BLOCK-START
"""Best fit with a reusability adjustment on top of it.

score = -leftover + beta * indicator(leftover >= min_seen) - gamma * (harmful small leftover)

The dominant term remains best-fit (tightest fit wins).  A small secondary term
avoids deliberately creating residuals that are smaller than any item we have
seen, since those residuals can never be reused.  When two bins are equally
tight we also slightly prefer the one with more room left (deeper / newer bin),
which is a cheap and safe tie-break.
"""
import numpy as np

_MIN_SEEN = 100


def priority(item, bins):
    global _MIN_SEEN
    # update running estimate of the smallest item observed
    if item < _MIN_SEEN:
        _MIN_SEEN = item

    leftover = bins - item  # >= 0 for every bin shown

    # best-fit: minimizing leftover is the primary objective
    score = -leftover.astype(np.float64)

    # a residual that is smaller than the smallest item ever seen is dead
    # space; penalize it a little so we don't create it on purpose.
    dead = (leftover < _MIN_SEEN) & (leftover > 0)
    score -= 0.5 * dead

    # exact fits are ideal: mild bonus (never harmful, helps break ties)
    score += 0.25 * (leftover == 0)

    # among equally tight fits, prefer the bin with more remaining room
    # (the emptier/deeper bin) so we don't churn half-empty bins.
    score += 1e-3 * bins

    return score
# EVOLVE-BLOCK-END
