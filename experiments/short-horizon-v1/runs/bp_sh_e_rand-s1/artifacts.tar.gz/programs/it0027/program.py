# EVOLVE-BLOCK-START
"""Adaptive best-fit: close bins toward residuals that future items likely fit."""
import numpy as np

# Small stream-global state, reset per stream.
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Score bins by tight fit, with a bonus for residuals that match common item sizes.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities for every bin the item fits in,
          including unused bins (capacity 100), in bin order.
    """
    global _total
    # Update streaming size histogram (Laplace-smoothed later).
    idx = int(item)
    if 1 <= idx <= 100:
        _hist[idx] += 1.0
        _total += 1.0

    residual = bins - item  # leftover capacity after placing the item here

    # Tight fit is the dominant term (keeps short streams ~ best-fit).
    score = -residual.astype(np.float64) * 1000.0

    # Bonus if the leftover equals a size that has appeared in the stream,
    # weighted by how common that size is (and extra credit for exactly full).
    if _total > 0.0:
        counts = _hist.copy()
        counts[1:101] += 1.0  # Laplace smoothing so unseen sizes still count a bit
        w = counts / counts.sum()
        r = residual.astype(np.int64)
        r_clip = np.clip(r, 0, 100)
        bonus = w[r_clip] / w.max() if w.max() > 0 else np.zeros_like(residual, dtype=np.float64)
        score += bonus * 50.0

    return score
# EVOLVE-BLOCK-END
