# EVOLVE-BLOCK-START
"""Best fit with a tie-break that prefers closing already-full bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary key: best fit (smallest post-placement residual). Ties are broken by
    preferring the bin that already had the smallest remaining capacity, i.e. the
    bin closest to being closed.
    """
    residual = bins - item
    return -(residual.astype(np.float64) * 101.0 + bins.astype(np.float64))
