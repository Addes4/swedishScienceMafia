# EVOLVE-BLOCK-START
"""Nested best-fit: exact fit first, then tightest residual, tie-broken by
preferring a residual near a representative item size (so the leftover space
is likely to be reusable by a future item)."""
import numpy as np


def priority(item, bins):
    """Return a priority per bin; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every fitting bin, in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary: exact fit is strictly best (residual 0), then tightest fit.
    # Use a concave transform so smaller residuals dominate, but with a
    # tolerance band where the secondary criterion can act.
    primary = -residual.astype(np.float64)

    # Secondary: prefer leaving a residual close to a "reusable" size.
    # The Weibull-shaped distribution (mean ~40) makes residuals near 40
    # often re-fillable. Reward residuals near a representative size r0.
    r0 = 40.0
    usable = -np.abs(residual - r0).astype(np.float64)

    # Combine: primary is dominant; secondary only matters among bins whose
    # residuals are within 1 unit of the best residual seen here.
    best = residual.min()
    near = (residual <= best + 1).astype(np.float64)
    score = primary * 1000.0 + near * usable
    return score
# EVOLVE-BLOCK-END
