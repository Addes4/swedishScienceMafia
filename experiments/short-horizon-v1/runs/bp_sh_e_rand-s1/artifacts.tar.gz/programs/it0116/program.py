# EVOLVE-BLOCK-START
"""Best fit with a learned "fillable residual" bonus.

Primary rule is still best fit (minimize post-placement residual). We add a small
bonus for candidate bins whose leftover residual equals a frequently seen item
size, which tends to make leftovers usable later. On short streams the histogram
is sparse, so behavior reduces to best fit + tiny fuller-bin tie-break.
"""
import numpy as np

# state: counts of item sizes 1..100 seen so far in the current stream
_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Rank bins: best fit first, with a small bonus for fillable residuals."""
    global _total

    # update learned histogram with the current item (known at placement time)
    _counts[item] += 1.0
    _total += 1.0

    residual = bins - item  # >= 0 for all candidate bins
    resid = residual.astype(np.float64)

    # frequency (probability) that a future item equals this residual size
    p = _counts / _total  # length 101, index 0 unused

    # safe indexing: residual is in [0, 100]
    fillable = p[resid.astype(np.int64)]  # likelihood residual is a real item size

    # Secondary tie-break: mildly prefer fuller bins (smaller residual).
    # Combine: strongest term is best fit (small residual), small bonus for
    # fillable residuals, tiny nudge toward fuller bins.
    score = -(resid) + 6.0 * fillable - 0.01 * resid

    return score
# EVOLVE-BLOCK-END
