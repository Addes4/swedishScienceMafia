# EVOLVE-BLOCK-START
"""Best fit with exact-fit and residual-reuse tie-breaking.

Primary criterion remains best fit (tightest post-placement residual), which is
optimal on short streams.  On top of that we add small, monotone tie-break
bonuses that do not change the primary ordering except toward consolidating
slivers and exact fits, keeping behavior stable across streams.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    residual = bins - item  # post-placement remaining capacity (>= 0 for fitting bins)

    # Primary: tightest fit.  We want smaller residual -> higher score.
    # Use a large multiplier so this dominates all secondary bonuses.
    score = -residual * 1000.0

    # Secondary: reward exact fits (residual == 0) robustly.
    score += (residual == 0).astype(np.float64) * 10.0

    # Tertiary: small bonus for very tiny residuals (sliver consolidation).
    # These bins are hard to reuse, so packing them tightest is fine, but
    # this only matters among equal primary scores and stays tiny.
    score += (residual == 1).astype(np.float64) * 1.0

    return score
# EVOLVE-BLOCK-END
