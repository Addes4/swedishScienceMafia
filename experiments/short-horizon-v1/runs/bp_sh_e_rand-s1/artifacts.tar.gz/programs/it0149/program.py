# EVOLVE-BLOCK-START
"""Good-fit style rule: prefer leaving a residual near half a bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer residuals close to 50 (a balanced half-full bin), which tends to
    # consolidate items and reduce tiny unusable scraps.  Tie-break toward the
    # tightest fit (smallest residual) so nearly identical bins fill first.
    return -np.abs(residual - 50) * 2 - residual
# EVOLVE-BLOCK-END
