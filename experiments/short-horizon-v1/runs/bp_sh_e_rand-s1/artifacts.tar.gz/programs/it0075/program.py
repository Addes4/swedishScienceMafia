# EVOLVE-BLOCK-START
"""Best fit with unusable-residue consolidation.

Items arrive one at a time.  We must choose a bin immediately.  The classic
good online rule for this distribution is Best Fit: put the item in the bin
with the smallest remaining capacity that still fits it.  It has a bounded
competitive ratio, and its performance is limited mostly by the tiny unusable
residues it leaves behind.  We add one refinement that does not need future
knowledge: if placing the item would leave a residue smaller than the smallest
item ever seen, that residue can never be filled again, so we prefer to
consolidate into such a bin (turning a small residue into a possibly useful
larger one elsewhere).  Ties fall back to tightest fit.
"""
import numpy as np

# state kept between calls within one stream
_smallest_seen = 100


def priority(item, bins):
    """Return a priority for every bin; highest wins, ties go to the first bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of all bins the item fits in,
          in bin order, including unused bins (remaining capacity 100).
    """
    global _smallest_seen
    if item < _smallest_seen:
        _smallest_seen = item

    bins = np.asarray(bins)
    residual = bins - item  # >= 0 because only fitting bins are shown

    # Tightest fit baseline: smaller residual is better.
    score = -residual.astype(np.float64)

    # Bonus for placing the item into a bin that would leave an unusable
    # residue (residual < smallest item seen so far).  Such a residue can
    # never be used again, so filling it now costs nothing extra and may
    # free up capacity that is easier to reuse.
    unusable = residual < _smallest_seen
    score += unusable.astype(np.float64) * 0.25

    return score
# EVOLVE-BLOCK-END

