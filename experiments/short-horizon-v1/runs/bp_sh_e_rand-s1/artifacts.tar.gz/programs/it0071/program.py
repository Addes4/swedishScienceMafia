# EVOLVE-BLOCK-START
"""Best-fit with consolidation preference for unusable residues."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown

    # Best-fit dominant term: smaller residual is better.
    score = -residual.astype(np.float64)

    # Bonus for exact fit (residual == 0): closes the bin perfectly.
    score += np.where(residual == 0, 1000.0, 0.0)

    # For bins that are still reusable (residual >= 1), mildly prefer the
    # fuller bin (larger fill) so residuals stay as small as possible.
    # Empty bins (residual == 100 - item) get no bonus, so we fill partials first.
    fill = 100 - bins
    reusable = residual >= 1
    score += np.where(reusable, 0.01 * fill.astype(np.float64), 0.0)

    return score
# EVOLVE-BLOCK-END
