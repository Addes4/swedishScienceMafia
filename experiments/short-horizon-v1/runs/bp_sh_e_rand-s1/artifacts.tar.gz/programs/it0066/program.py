# EVOLVE-BLOCK-START
"""Consolidating best fit: prefer tight fits, and among similar fits pack into already-used bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (smallest residual is best, hence the negative sign).
    score = -(residual).astype(np.float64)
    # Secondary: lightly prefer bins that are already more loaded (smaller remaining
    # capacity), which consolidates items into active bins instead of opening new ones.
    score -= 0.05 * (item.astype(np.float64) / np.maximum(bins.astype(np.float64), 1.0))
    return score
# EVOLVE-BLOCK-END
