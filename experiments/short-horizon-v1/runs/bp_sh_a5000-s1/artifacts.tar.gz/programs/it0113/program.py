# EVOLVE-BLOCK-START
"""Best fit with a robust dead-gap guard using the recent minimum item size."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        # running minimum item size seen recently (proxy for smallest usable hole)
        self.min_item = 100.0

    def update(self, item):
        self.n += 1
        # slow decay upward allows the min to adapt if distribution shifts
        if self.n % 200 == 0:
            self.min_item = min(100.0, self.min_item * 1.02 + 0.05)
        if item < self.min_item:
            self.min_item = float(item)


_state = _State()


def priority(item, bins):
    """Pure best fit, except avoid leaving a residual smaller than the smallest item likely to arrive."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # best-fit candidate (smallest non-negative residual)
    best = int(np.argmin(residual))
    best_res = residual[best]

    # threshold: residual below this is likely unusable dead space
    thresh = max(1.0, _state.min_item)
    if best_res <= 0 or best_res >= thresh:
        return -residual.astype(np.float64)

    # best fit would strand a tiny hole: pick smallest residual that is >= thresh,
    # among bins that are actually usable; if none exist, fall back to best fit.
    usable = np.where((residual >= thresh) & (bins < 100))[0]
    if usable.size > 0:
        j = int(usable[np.argmin(residual[usable])])
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
