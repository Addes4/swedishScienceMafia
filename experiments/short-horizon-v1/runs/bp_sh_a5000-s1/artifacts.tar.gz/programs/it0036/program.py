# EVOLVE-BLOCK-START
"""Best fit biased toward residuals that match recent item sizes (complement matching)."""
import numpy as np


class _State:
    def __init__(self):
        self.recent = []          # short window of recent item sizes
        self.maxlen = 60
        self.hist = np.zeros(101) # decayed frequency of item sizes

    def update(self, item):
        self.recent.append(int(item))
        if len(self.recent) > self.maxlen:
            self.recent.pop(0)
        self.hist *= 0.97
        self.hist[int(item)] += 1.0


_state = _State()


def priority(item, bins):
    """Rank bins: prefer small post-placement residual, boosted if it matches recent sizes."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin
    n = bins.shape[0]

    # score = base best-fit preference (smaller residual better) ...
    score = -residual.astype(np.float64)

    # ... plus a bonus when the freed residual matches a likely future item size.
    hist = _state.hist
    # normalize into a per-size desirability weight
    w = hist / (hist.max() + 1e-9)
    # residual is in [0, 100]
    idx = np.clip(residual.astype(np.int64), 0, 100)
    bonus = 12.0 * w[idx]
    # only reward genuinely positive residuals that we leave in a used bin,
    # and never outrank an exact fit (residual 0)
    bonus = np.where(residual > 0, bonus, 0.0)
    # exact fits (residual==0) get a decisive boost already via base score ordering;
    # ensure complement bonus cannot beat an exact-fit bin:
    maxbase = score.max()
    # add bonus but cap so a residual-0 bin (score=max) stays on top
    score = score + bonus
    exact = np.where(residual == 0)[0]
    if exact.size > 0:
        score = np.where(residual == 0, 1e6, score)
    return score
# EVOLVE-BLOCK-END
