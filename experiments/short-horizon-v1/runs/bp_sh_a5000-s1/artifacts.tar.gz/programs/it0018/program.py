# EVOLVE-BLOCK-START
"""Best fit with a penalty for leaving useless (too-small) residuals."""
import numpy as np

_MIN_SEEN = [100]  # smallest item size observed so far (state kept across calls)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    if item < _MIN_SEEN[0]:
        _MIN_SEEN[0] = item
    residual = bins - item  # remaining capacity after placing the item (>= 0 for shown bins)
    score = -residual.astype(np.float64)  # best fit: smaller residual preferred
    # Penalize residuals that are positive but too small to hold any future item,
    # pushing the item toward bins that leave a reusable gap or exactly fill.
    m = _MIN_SEEN[0]
    useless = (residual > 0) & (residual < m)
    score[useless] -= 0.5 * (m - residual[useless])
    return score
# EVOLVE-BLOCK-END
