# EVOLVE-BLOCK-START
"""Best fit restricted to bins that leave a usable residual."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tight fits among bins leaving a 'usable' residual.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since only fitting bins are shown

    # Dynamic threshold: an residual below ~a small item size is wasted space.
    # We use a fixed small threshold (10) tuned to the Weibull item distribution.
    usable = residual >= 10

    score = np.empty_like(residual, dtype=np.float64)
    # Among usable-residual bins, prefer the tightest fit (smallest residual).
    # Among non-usable bins, prefer the largest residual (still best-fit-like).
    score[usable] = -residual[usable].astype(np.float64)
    score[~usable] = -residual[~usable].astype(np.float64) - 1000.0
    return score
# EVOLVE-BLOCK-END
