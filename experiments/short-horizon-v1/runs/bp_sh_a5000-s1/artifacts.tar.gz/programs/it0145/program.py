# EVOLVE-BLOCK-START
"""Best fit with a probability-gated exact-residual fast path."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.counts = {}      # recency-weighted count of small item sizes
        self.small = 10.0     # running estimate of a "small" item size

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            # periodic decay keeps the table "recent" and bounded
            if self.n % 400 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] *= 0.5
                    if self.counts[k] < 0.25:
                        del self.counts[k]


_state = _State()


def priority(item, bins):
    """Exact-residual match for probable small sizes, else best fit.

    The fast path only fires when the post-placement residual equals an
    item size that has genuinely appeared often enough to be likely to
    reappear, so the placement is a real (probable) exact fit rather than
    a speculative one.
    """
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Fast path: consider only residuals that are likely future item sizes.
    if _state.counts and _state.n > 50:
        total = float(sum(_state.counts.values()))
        if total > 0:
            # threshold: a size must carry at least ~2% of recent small mass
            min_w = 0.02 * total
            used = bins < 100
            if used.any():
                cand = np.where(used)[0]
                res_c = residual[cand]
                best_idx = -1
                best_w = 0.0
                for pos in range(cand.size):
                    r = int(res_c[pos])
                    w = _state.counts.get(r, 0.0)
                    if w >= min_w and w > best_w:
                        best_w = w
                        best_idx = cand[pos]
                if best_idx >= 0:
                    score = np.full(bins.shape, -1e9, dtype=np.float64)
                    score[best_idx] = 1.0
                    return score

    thresh = 0.6 * _state.small  # residual below this is hard to reuse

    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    if best_res <= 0 or best_res >= thresh:
        return -residual.astype(np.float64)

    usable = np.where((residual >= thresh) & (bins < 100))[0]
    if usable.size > 0:
        j = usable[np.argmin(residual[usable])]
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
