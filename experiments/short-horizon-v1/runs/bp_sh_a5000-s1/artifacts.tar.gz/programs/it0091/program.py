# EVOLVE-BLOCK-START
"""Best fit with a small soft bonus toward reusable residual sizes (no forced jumps)."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.counts = {}    # recent counts of item sizes (bounded memory)

    def update(self, item):
        self.n += 1
        # track mode of item sizes seen recently (bounded, decaying)
        self.counts[item] = self.counts.get(item, 0) + 1
        if self.n % 1000 == 0:
            for k in list(self.counts.keys()):
                self.counts[k] = self.counts[k] // 2
                if self.counts[k] == 0:
                    del self.counts[k]

    def common(self):
        """Return a set of the most common recent item sizes (small ones)."""
        best = {}
        for k, v in self.counts.items():
            if v >= 3 and k <= 40:
                best[k] = v
        return best


_state = _State()


def priority(item, bins):
    """Best fit, with a small bonus for residuals matching a common small item size."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    score = -residual.astype(np.float64)

    # Soft bonus: only nudges near-ties, never forces a large jump.
    common = _state.common()
    if common:
        used = bins < 100
        for k in common:
            hit = (residual == k) & used
            # bonus bounded well below 1.0 so it only breaks near-ties
            score += hit * 0.5

    return score
# EVOLVE-BLOCK-END
