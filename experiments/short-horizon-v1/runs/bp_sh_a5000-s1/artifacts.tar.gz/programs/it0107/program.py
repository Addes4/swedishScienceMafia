# EVOLVE-BLOCK-START
"""Best fit with an adaptive dead-gap guard based on the observed item-size floor."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.min_seen = 100.0   # smallest item size observed so far
        self.small = 20.0       # running estimate of a typical "small" leftover

    def update(self, item):
        self.n += 1
        if item < self.min_seen:
            self.min_seen = float(item)
        s = float(min(item, 50))
        self.small = 0.99 * self.small + 0.01 * s
        if self.small < 3.0:
            self.small = 3.0

    def thresh(self):
        # residuals below this are hard to reuse: tie to the typical small item
        # and the observed minimum item size.
        return max(self.min_seen, 0.5 * self.small, 3.0)


_state = _State()


def priority(item, bins):
    """Rank bins by best fit, but penalize leaving an unusable sliver."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    thresh = _state.thresh()

    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    # If best-fit leaves a decent residual, or an exact/near-exact fit, just do best fit.
    if best_res <= 0 or best_res >= thresh:
        return -residual.astype(np.float64)

    # Otherwise best fit would strand a tiny sliver; pick the used bin whose
    # residual is at least thresh and as small as possible (still best fit,
    # but over reusable residuals). If none exists, fall back to best fit.
    usable = np.where((residual >= thresh) & (bins < 100))[0]
    if usable.size > 0:
        j = usable[np.argmin(residual[usable])]
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
