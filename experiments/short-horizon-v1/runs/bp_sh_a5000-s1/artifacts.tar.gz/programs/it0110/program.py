# EVOLVE-BLOCK-START
"""Best fit with a strong prefer-fresh-bin guard against stranding tiny residuals."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0


_state = _State()


def priority(item, bins):
    """Best fit, but avoid stranding tiny residuals: prefer fresh bins when needed."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Dead-space threshold: a residual below this is likely useless.
    thresh = 0.5 * _state.small

    # Prefer an exact fit (residual 0) strongly if available.
    exact = np.where((residual == 0) & (bins < 100))[0]
    if exact.size > 0:
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[exact[0]] = 1.0
        return score

    used = bins < 100

    # Among used bins, find the best fit that leaves a usable residual.
    usable = np.where(used & (residual >= thresh))[0]
    if usable.size > 0:
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        j = usable[np.argmin(residual[usable])]
        score[j] = 1.0
        return score

    # No usable residual exists among used bins: either the item exactly fits
    # nothing reusable, or all used bins would leave dead space.
    # Prefer opening a fresh bin over stranding dead space.
    fresh = np.where(bins == 100)[0]
    if fresh.size > 0:
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[fresh[0]] = 1.0
        return score

    # Only bins that strand dead space remain: use best fit anyway.
    score = -residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END


