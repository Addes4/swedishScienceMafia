# EVOLVE-BLOCK-START
"""Best fit with a convex residual-shaping penalty that avoids tiny unusable gaps."""
import numpy as np


class _State:
    def __init__(self):
        self.mean = 40.0   # running estimate of typical item size
        self.n = 0

    def update(self, item):
        self.n += 1
        # EWMA of item sizes
        self.mean = 0.995 * self.mean + 0.005 * float(item)
        if self.mean < 5.0:
            self.mean = 5.0


_state = _State()


def priority(item, bins):
    """Score bins so tight fits win, but small unusable residuals get penalized."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual; <0 means doesn't fit (excluded anyway)

    # Convex shaping: cost grows with residual above a target, and tiny residuals
    # are cheap only if they can still hold a typical item. We use a piecewise
    # penalty that is minimal around residual ~ mean and rises steeply below it.
    m = _state.mean
    r = residual.astype(np.float64)

    # base tightness penalty (prefer small residual)
    cost = r

    # extra penalty for residuals that are too small to be refilled by a typical item
    small_pen = np.where(r < m, (m - r) * 0.0, 0.0)  # placeholder keeps array float

    # Penalize tiny residuals: gap can't hold many items -> wasted space.
    tiny = np.maximum(0.0, m * 0.5 - r)
    cost = cost + tiny * 0.5

    # Prefer to fill used bins rather than open fresh ones slightly: tiny tie-break.
    fresh = (bins >= 100)
    cost = cost + fresh * 1e-6

    score = -cost
    return score
# EVOLVE-BLOCK-END
