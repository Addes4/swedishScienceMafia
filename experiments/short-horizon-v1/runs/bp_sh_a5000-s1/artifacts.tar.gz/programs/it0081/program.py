# EVOLVE-BLOCK-START
"""Best fit with an online decaying histogram used to avoid 'dead' residual gaps."""
import numpy as np


class _State:
    def __init__(self):
        # exponentially decaying histogram of item sizes (1..100)
        self.h = np.zeros(101, dtype=np.float64)
        self.n = 0
        self.decay = 0.995

    def update(self, item):
        self.n += 1
        if self.n % 20 == 0:
            self.h *= self.decay
        self.h[item] += 1.0

    def smallest_common(self, frac=0.05):
        # smallest item size that occurs with at least `frac` of the max bin mass
        total = self.h.sum()
        if total <= 0:
            return 1
        thresh = frac * self.h.max()
        for s in range(1, 101):
            if self.h[s] >= thresh:
                return s
        return 1


_state = _State()


def priority(item, bins):
    """Prefer exact fits; else best fit, but avoid residuals too small to ever be reused."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Perfect fill first.
    zero = np.where(residual == 0)[0]
    if zero.size > 0:
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[zero[0]] = 1.0
        return score

    # Best fit residual.
    best = int(np.argmin(residual))
    best_res = residual[best]

    # If the best residual is a "dead" gap (smaller than the smallest commonly
    # occurring item), it will likely never be filled => look for a usable bin
    # whose residual is at least that threshold instead.
    small = _state.smallest_common()
    if 0 < best_res < small:
        usable = np.where((residual >= small) & (bins < 100))[0]
        if usable.size > 0:
            j = int(usable[np.argmin(residual[usable])])
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[j] = 1.0
            return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

