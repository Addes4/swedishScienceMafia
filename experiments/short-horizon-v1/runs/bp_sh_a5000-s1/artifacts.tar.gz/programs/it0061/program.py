# EVOLVE-BLOCK-START
"""Best Fit: place each item into the bin whose post-placement residual is smallest,
with a negligible bonus for already-used bins to avoid opening fresh ones unnecessarily."""
import numpy as np


def priority(item, bins):
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Primary: smaller residual is better (best fit).
    score = -residual.astype(np.float64)

    # Tiny bonus for reusing already-opened bins (capacity < 100) so we don't
    # open a new bin when an existing one is equally tight. Magnitude is small
    # enough that it never overrides a real residual difference.
    used = bins < 100
    score += used * 1e-6

    return score
# EVOLVE-BLOCK-END
