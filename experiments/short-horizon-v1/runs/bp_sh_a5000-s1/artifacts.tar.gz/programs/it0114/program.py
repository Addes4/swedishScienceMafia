# EVOLVE-BLOCK-START
"""Best fit with a robust small-residual guard using an online size percentile."""
import numpy as np


class _State:
    """Tracks a running distribution of recent item sizes to estimate small items."""

    BINS = 101  # integer sizes 1..100

    def __init__(self):
        self.n = 0
        self.hist = np.zeros(self.BINS, dtype=np.float64)
        self.small = 12.0  # running estimate of a small-item size

    def update(self, item):
        self.n += 1
        self.hist[item] += 1.0
        # exponentially decay the histogram occasionally to stay "recent"
        if self.n % 400 == 0:
            self.hist *= 0.5
        s = float(min(item, 40))
        self.small = 0.97 * self.small + 0.03 * s
        if self.small < 4.0:
            self.small = 4.0

    def pct(self, q):
        """Return an approximate q-th percentile (as int size) of recent items."""
        w = self.hist[1:]
        total = w.sum()
        if total <= 0:
            return 0
        cum = np.cumsum(w)
        target = q * total
        idx = int(np.searchsorted(cum, target))
        return idx + 1  # convert to size 1..100


_state = _State()


def priority(item, bins):
    """Best fit, but treat residuals below a robust small-item floor as dead space."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Robust floor: the item size below which a leftover hole is likely unusable.
    floor = _state.pct(0.05)
    if floor < 3:
        floor = 3

    # Prefer bins whose residual is at or above the floor (reusable), smallest such first.
    # Among those, best fit (smallest residual >= floor).
    mask_ok = residual >= floor
    if np.any(mask_ok):
        masked = np.where(mask_ok, residual, np.iinfo(np.int64).max)
        j = int(np.argmin(masked))
    else:
        # No bin leaves a reusable hole; just do pure best fit.
        j = int(np.argmin(residual))

    score = np.full(bins.shape, -1e9, dtype=np.float64)
    score[j] = 1.0
    return score
# EVOLVE-BLOCK-END
