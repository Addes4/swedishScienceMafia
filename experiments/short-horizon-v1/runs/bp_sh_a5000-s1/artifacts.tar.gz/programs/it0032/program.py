# EVOLVE-BLOCK-START
"""Best fit with an adaptive residual-quality guard."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0


_state = _State()


def priority(item, bins):
    """Return a priority per bin: best fit, unless it leaves a too-small residual."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Adaptive threshold: a residual is "wasted" only if it is small in
    # absolute terms relative to typical small items. For tiny items a tight
    # fit is fine (many tiny items can still fill the gap), so shrink the
    # threshold pressure when the arriving item itself is small.
    small = _state.small
    thresh = 0.6 * small

    # best-fit: smallest nonnegative residual
    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    if best_res <= 0 or best_res >= thresh:
        score = -residual.astype(np.float64)
        return score

    # Otherwise prefer the fullest used bin whose residual is >= thresh.
    usable = np.where((residual >= thresh) & (bins < 100))[0]
    if usable.size > 0:
        j = usable[np.argmin(residual[usable])]
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    # No usable alternative: fall back to pure best fit.
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

