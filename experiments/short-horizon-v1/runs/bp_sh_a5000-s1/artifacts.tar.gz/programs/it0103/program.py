# EVOLVE-BLOCK-START
"""Best fit with a small perfect-fit / dead-gap guard."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0
        self.n = 0

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0


_state = _State()


def priority(item, bins):
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    score = -residual.astype(np.float64)

    # Strong bonus for an exact fit (leaves no residual): strongly reuse full bins.
    exact = (residual == 0)
    if exact.any():
        score[exact] += 1e6

    return score
# EVOLVE-BLOCK-END
