# EVOLVE-BLOCK-START
"""Best fit with a small tie-breaking preference that balances tightness vs opening bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # leftover after placing
    # Best fit: minimize residual. Slightly penalize opening a brand-new bin
    # (residual would be large anyway), but also slightly reward very tight fits.
    score = -residual.astype(np.float64)
    # Small bonus for tighter fits (creates fuller bins over time)
    score -= 0.001 * residual
    return score
# EVOLVE-BLOCK-END
