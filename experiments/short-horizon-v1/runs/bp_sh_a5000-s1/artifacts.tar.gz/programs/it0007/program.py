# EVOLVE-BLOCK-START
"""Best fit with a small bonus for bins that become nearly full after placement."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: prefer tightest fit (smallest residual).
    score = -residual.astype(np.float64)
    # Small bonus for bins that close up completely (residual == 0),
    # which gently consolidates items into already-nearly-full bins.
    score += (residual == 0).astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END
