# EVOLVE-BLOCK-START
"""Best fit with a mild preference for reusing already-opened bins over fresh ones."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0

    def update(self, item):
        self.n += 1


_state = _State()


def priority(item, bins):
    """Best fit (tightest post-placement residual); break near-ties toward open bins."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Base score: prefer the tightest fit (smallest non-negative residual).
    score = -residual.astype(np.float64)

    # Mild bonus for bins that are already in use (capacity < 100), so we don't
    # open a fresh bin when an existing one is essentially as good.  The bonus is
    # smaller than one unit of residual, preserving best-fit ordering.
    used = bins < 100
    score += 0.5 * used

    return score
# EVOLVE-BLOCK-END


