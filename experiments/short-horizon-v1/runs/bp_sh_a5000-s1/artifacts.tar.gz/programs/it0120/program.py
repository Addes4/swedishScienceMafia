# EVOLVE-BLOCK-START
"""Best fit with a soft tie-break toward reusable residuals estimated from recent items."""
import numpy as np


class _State:
    def __init__(self):
        self.mean = 40.0   # running mean of item sizes
        self.n = 0

    def update(self, item):
        self.n += 1
        # slow EMA of full item size distribution
        self.mean += (float(item) - self.mean) / min(self.n, 500)


_state = _State()


def priority(item, bins):
    """Best fit (smallest residual) with a mild tie-break avoiding stranding."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Base rule: best fit -> maximize negative residual.
    score = -residual.astype(np.float64)

    # Mild tie-break: among bins, small positive residuals equal to small item
    # sizes are more reusable. Add a small bonus inversely proportional to how
    # far a positive residual is from a typical small item, without overriding
    # the dominant best-fit ordering.
    # Compute a small bonus only where residual is positive.
    pos = residual > 0
    if pos.any():
        # target residual ~ a fraction of the mean item (a "small" reusable hole)
        target = 0.5 * _state.mean
        dist = np.abs(residual - target)
        # bonus in [0, 1]; scaled tiny so it only breaks near-ties in best fit
        bonus = np.where(pos, 0.01 / (1.0 + dist), 0.0)
        score = score + bonus

    return score
# EVOLVE-BLOCK-END
