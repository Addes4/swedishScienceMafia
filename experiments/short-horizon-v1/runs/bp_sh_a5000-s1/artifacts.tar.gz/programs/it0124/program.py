# EVOLVE-BLOCK-START
"""Best fit with an exact-residual fast path over the recent small-item population."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0
        self.counts = {}    # recent counts of small item sizes

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def targets(self):
        """Residual values likely to be exactly fillable soon: top recent small sizes."""
        if not self.counts:
            return []
        items = sorted(self.counts.items(), key=lambda kv: -kv[1])
        top = items[:3]
        best_v = top[0][1]
        # keep only sizes that are comparably frequent to the mode
        keep = [k for k, v in top if v * 2 >= best_v]
        return keep


_state = _State()


def priority(item, bins):
    """Prefer an exact residual match to a common recent size, else best fit."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item

    targets = _state.targets()
    if targets:
        used = bins < 100
        score = None
        for t in targets:
            match = np.where((residual == t) & used)[0]
            if match.size > 0:
                if score is None:
                    score = np.full(bins.shape, -1e9, dtype=np.float64)
                score[match[0]] = 1.0
        if score is not None:
            return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
