# EVOLVE-BLOCK-START
"""Best fit with reuse-friendly tie-breaking."""
import numpy as np


def priority(item, bins):
    """Best fit (smallest non-negative post-placement residual) with reuse-friendly ties."""
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin (>=0 for fitting bins)

    n = bins.shape[0]
    score = np.empty(n, dtype=np.float64)

    # Primary key: prefer exact fit (residual 0) most, then smaller residual.
    # Secondary key: for equal residuals, prefer larger remaining capacity (bins value).
    # Encode as a single float: exact fit dominates; among ties larger 'bins' wins.
    # score = -residual - tiny * (bins)  so smaller residual wins, then larger bins loses penalty.
    score = -residual.astype(np.float64) - 1e-6 * bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
