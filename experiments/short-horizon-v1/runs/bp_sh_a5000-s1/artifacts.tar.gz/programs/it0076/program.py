# EVOLVE-BLOCK-START
"""Best fit with an exact-residual-match fast path and a soft reuse bonus for common gaps."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0    # running estimate of a "small" item size
        self.n = 0
        self.hist = {}       # decaying histogram of recent item sizes (all sizes)
        self.decay = 0.9995  # slow decay keeps "recent" common sizes prominent

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        # decaying histogram of item sizes (bounded: sizes 1..100)
        it = int(item)
        self.hist[it] = self.hist.get(it, 0.0) + 1.0
        if self.n % 200 == 0:
            for k in list(self.hist.keys()):
                self.hist[k] *= self.decay ** 200
                if self.hist[k] < 1e-3:
                    del self.hist[k]

    def mode_small(self):
        best_k, best_v = 0, 0.0
        for k, v in self.hist.items():
            if k <= 40 and v > best_v:
                best_v, best_k = v, k
        return best_k

    def reuse_weight(self, r):
        """Soft weight for a post-placement residual r: higher if r often appears as an item."""
        r = int(r)
        if r <= 0:
            return 0.0
        v = self.hist.get(r, 0.0)
        return v


_state = _State()


def priority(item, bins):
    """Prefer exact residual matches, else best fit with a gentle residual-reuse bonus."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Fast path: an existing used bin whose residual exactly matches a common small item.
    m = _state.mode_small()
    if m > 0:
        match = np.where((residual == m) & (bins < 100))[0]
        if match.size > 0:
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[match[0]] = 1.0
            return score

    # Base best-fit score: prefer smaller residual (more full bin).
    score = -residual.astype(np.float64)

    # Gentle tie-breaking bonus: reward residuals that match common future item sizes.
    # Scaled small so it only affects near-ties, not clear best-fit wins.
    if _state.hist:
        used = bins < 100
        if np.any(used):
            weights = np.array(
                [_state.reuse_weight(r) if u else 0.0
                 for r, u in zip(residual, used)],
                dtype=np.float64,
            )
            total = weights.sum()
            if total > 0:
                score = score + 0.05 * (weights / total)

    return score
# EVOLVE-BLOCK-END
