# EVOLVE-BLOCK-START
"""Best fit with an exact-residual-match fast path over a set of recent small-item sizes."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0
        self.n = 0
        self.counts = {}    # recent counts of small item sizes

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
        if self.n % 400 == 0:
            for k in list(self.counts.keys()):
                self.counts[k] = self.counts[k] // 2
                if self.counts[k] == 0:
                    del self.counts[k]

    def common_small(self):
        """Return a set of small sizes that have been seen more than once."""
        if not self.counts:
            return ()
        vals = sorted(self.counts.items(), key=lambda kv: -kv[1])
        return tuple(k for k, v in vals[:6] if v >= 2)


_state = _State()


def priority(item, bins):
    """Prefer a used bin whose residual matches a common small item, else best fit."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    common = _state.common_small()
    if common:
        used = bins < 100
        best_j = -1
        best_res = None
        for k in common:
            match = np.where((residual == k) & used)[0]
            if match.size > 0:
                j = match[0]
                r = residual[j]
                if best_res is None or r < best_res:
                    best_res = r
                    best_j = j
        if best_j >= 0:
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[best_j] = 1.0
            return score

    residual = bins - item
    thresh = 0.6 * _state.small

    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    if best_res <= 0 or best_res >= thresh:
        score = -residual.astype(np.float64)
        return score

    usable = np.where((residual >= thresh) & (bins < 100))[0]
    if usable.size > 0:
        j = usable[np.argmin(residual[usable])]
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
