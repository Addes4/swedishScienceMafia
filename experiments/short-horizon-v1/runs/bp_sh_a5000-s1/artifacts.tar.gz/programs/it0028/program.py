# EVOLVE-BLOCK-START
"""Best-fit with a dynamic "usable residual" preference."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Post-placement residual for every candidate bin.
    residual = bins - item  # all >= 0 since bins only contains fitting bins

    # Dynamic threshold: approximate the typical upcoming item size from a running
    # estimate of past items.  We keep state across calls on the function object.
    st = priority.__dict__
    if 'm' not in st:
        st['m'] = 40.0        # running mean item size
        st['n'] = 0
        st['thr'] = 20.0

    st['n'] += 1
    # Exponential moving average of item size (fast enough to track the distribution).
    st['m'] = 0.99 * st['m'] + 0.01 * item
    # A residual is "usable" if at least ~half of a typical item still fits.
    thr = 0.5 * st['m']

    # Best-fit baseline score: tighter placement (smaller residual) is better.
    score = -residual.astype(np.float64)

    # Among bins that would leave a usable residual, prefer the fullest such bin
    # (i.e. the tightest fit that still leaves a reusable gap) so we don't shut a
    # bin's remaining space out of future use, nor open fresh bins too early.
    usable = residual >= thr
    large_res = residual > 0.6 * st['m']
    # Slightly boost usable bins relative to creating a useless tiny gap.
    score = score + np.where(large_res, 0.5, 0.0)
    # Strongly prefer any usable bin over a bin that would be effectively closed,
    # but still consolidate: among usable bins lower residual wins via the -residual term.
    return score
# EVOLVE-BLOCK-END

