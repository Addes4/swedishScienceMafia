# EVOLVE-BLOCK-START
"""Harmonic-style best fit: prefer tight fits, but reward residuals that match likely future items."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)  # decaying histogram of item sizes
        self.n = 0

    def update(self, item):
        self.n += 1
        # decay so histogram tracks "recent" distribution
        self.hist *= 0.995
        self.hist[item] += 1.0

    def reuse_value(self, residuals):
        """Estimate probability mass that a residual can be exactly filled by a future item.

        We use the (normalized) recent histogram as an estimate of the item distribution.
        residuals is an int array of post-placement residuals.
        """
        total = self.hist.sum()
        if total <= 0:
            return np.zeros(residuals.shape, dtype=np.float64)
        probs = self.hist / total
        r = np.clip(residuals, 0, 100).astype(np.int64)
        return probs[r]


_state = _State()


def priority(item, bins):
    """Return a priority per bin.

    Base rule: best fit (prefer smallest post-placement residual).
    Bonus: if the post-placement residual exactly matches a common upcoming
    item size, that gap is likely to be reused, so give it extra priority.
    """
    _state.update(item)
    bins = np.asarray(bins)
    residual = (bins - item).astype(np.float64)  # post-placement residual

    # Base: negative residual (best fit). Only used bins can win the bonus;
    # unused bins (bins == 100) get no reuse bonus so we avoid opening new bins.
    score = -residual

    # Reuse bonus: reward residuals that equal a likely future item size.
    usage = _state.reuse_value(np.clip(residual, 0, 100))
    used_mask = (bins < 100) & (residual >= 0)
    score = score + 50.0 * usage * used_mask

    return score
# EVOLVE-BLOCK-END
