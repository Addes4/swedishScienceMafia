# EVOLVE-BLOCK-START
"""Best fit with a soft "reusable residual" bonus instead of a brittle exact-match guard."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0
        self.counts = {}    # recent counts of small item sizes (for mode)

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def mode_small(self):
        best_k, best_v = 0, 0
        for k, v in self.counts.items():
            if v > best_v:
                best_v, best_k = v, k
        return best_k


_state = _State()


def priority(item, bins):
    """Best fit, softly nudged to leave holes that match typical small items."""
    _state.update(item)
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # post-placement residual per bin

    small = _state.small
    mode = _state.mode_small()
    target = mode if mode > 0 else int(round(small))
    if target < 1:
        target = 1

    score = -residual  # base: best fit (prefer smallest residual)

    used = bins < 100.0

    # Reward leaving a residual close to the typical small item (reusable hole).
    # Scale reward modestly so it only breaks near-ties in best fit.
    close = np.abs(residual - target)
    score += 0.5 * np.exp(-close / max(small, 1.0))

    # Mild penalty for stranding a tiny, unusable residual in a used bin.
    dead = used & (residual >= 0) & (residual < 0.5 * small)
    score[dead] -= 0.5

    return score
# EVOLVE-BLOCK-END

