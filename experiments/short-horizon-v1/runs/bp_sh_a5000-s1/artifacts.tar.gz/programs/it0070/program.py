# EVOLVE-BLOCK-START
"""Best fit with a soft exact-residual bonus for reusable gaps."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.counts = {}   # recent counts of small item sizes
        self.small = 15.0

    def update(self, item):
        self.n += 1
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
        if self.n % 500 == 0:
            for k in list(self.counts.keys()):
                self.counts[k] //= 2
                if self.counts[k] == 0:
                    del self.counts[k]

    def small_set(self):
        # sizes with meaningful recent frequency
        if not self.counts:
            return set()
        vals = sorted(self.counts.values(), reverse=True)
        cut = max(2, vals[min(len(vals) - 1, 9)])
        return {k for k, v in self.counts.items() if v >= cut}


_state = _State()


def priority(item, bins):
    """Score = -residual, with a soft bonus for residuals matching common small items."""
    bins = np.asarray(bins)
    resid = bins - item  # post-placement residual
    score = -resid.astype(np.float64)

    smalls = _state.small_set()
    _state.update(item)

    # Bonus for residuals that exactly equal a common small item size,
    # so the gap can be filled later with high probability.
    if smalls:
        mask = np.isin(resid, list(smalls))
        score[mask] += 5.0

    return score
# EVOLVE-BLOCK-END
