# EVOLVE-BLOCK-START
"""Reserve-slack best fit.

Mostly best fit (tightest residual after placement), but a fresh bin is only
preferred when it strictly beats the best used-bin placement by reserving slack
for future large items. Adds a tiny bias toward leaving gaps that are at least
a small fraction of C, which are reusable by later items.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for bins the item fits in
    # best-fit priority: higher score for smaller residual
    score = -residual.astype(np.float64)

    # Penalize placements that leave a tiny, hard-to-reuse gap.
    # Small gap (< ~10% of capacity) is discouraged by a small penalty.
    small = np.clip(10.0 - residual, 0.0, None)  # penalty grows as residual -> 0
    score -= 0.01 * small

    # Slightly prefer full bins (smaller capacity remaining) over fresh ones,
    # keeping best-fit's ordering but breaking exact ties toward fuller bins.
    score -= 0.001 * bins.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
