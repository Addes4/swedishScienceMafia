# EVOLVE-BLOCK-START
"""Best fit with exact-residual fast paths driven by observed item-size statistics."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0
        self.n = 0
        self.counts = {}
        # track residuals we've created that we can hope to fill later
        self.min_recent = 100.0

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item < self.min_recent:
            # slowly relax toward current item, keep it small but responsive
            self.min_recent = 0.9 * self.min_recent + 0.1 * item
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def mode_small(self):
        best_k, best_v = 0, 0
        for k, v in self.counts.items():
            if v > best_v:
                best_v, best_k = v, k
        return best_k


_state = _State()


def _greedy_assign(score, idx):
    score[:] = -1e9
    score[idx] = 1.0
    return score


def priority(item, bins):
    """Return a priority per bin: prefer an exact residual match, else best fit."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item

    score = np.full(bins.shape, -1e9, dtype=np.float64)
    used = bins < 100

    # Fast path 1: exact residual match to the recent small-item mode.
    m = _state.mode_small()
    if m > 0:
        match = np.where((residual == m) & used)[0]
        if match.size > 0:
            return _greedy_assign(score, match[0])

    # Fast path 2: perfect fit (residual zero on a used bin).
    pf = np.where(residual == 0)[0]
    if pf.size > 0:
        return _greedy_assign(score, pf[0])

    # Otherwise strict best fit.
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
