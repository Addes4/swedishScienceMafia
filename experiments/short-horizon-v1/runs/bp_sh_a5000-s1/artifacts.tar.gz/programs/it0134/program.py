# EVOLVE-BLOCK-START
"""Best fit with an exact-residual-match fast path and tie-break toward reusable holes."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0
        self.counts = {}    # recent counts of small item sizes (for mode)

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def mode_small(self):
        best_k, best_v = 0, 0
        for k, v in self.counts.items():
            if v > best_v:
                best_v, best_k = v, k
        return best_k


_state = _State()


def priority(item, bins):
    """Prefer an exact residual matching a common small item, else best-fit with a reuse tie-break."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin
    used = bins < 100

    # Fast path: an existing used bin whose residual exactly matches a common small item.
    m = _state.mode_small()
    if m > 0:
        match = np.where((residual == m) & used)[0]
        if match.size > 0:
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[match[0]] = 1.0
            return score

    # Best fit: smallest non-negative residual. Exact fits (residual 0) take priority.
    exact = np.where((residual == 0) & used)[0]
    if exact.size > 0:
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[exact[0]] = 1.0
        return score

    valid = np.where(residual >= 0)[0]
    best_res = np.min(residual[valid])
    # Among bins with the best residual, prefer the larger remaining capacity so the
    # resulting hole is as big as possible (more likely to be exactly reusable later).
    tied = valid[residual[valid] == best_res]
    j = tied[np.argmax(bins[tied])]
    score = np.full(bins.shape, -1e9, dtype=np.float64)
    score[j] = 1.0
    return score
# EVOLVE-BLOCK-END
