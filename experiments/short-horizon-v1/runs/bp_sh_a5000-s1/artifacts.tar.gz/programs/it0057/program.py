# EVOLVE-BLOCK-START
"""Best fit with a smooth reusability-aware residual scoring (harmonic-style)."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 15.0   # running estimate of a "small/reusable" item size
        self.n = 0

    def update(self, item):
        self.n += 1
        s = float(min(item, 45))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 5.0:
            self.small = 5.0


_state = _State()


def priority(item, bins):
    """Smooth score: prefer tight fits but reward residuals large enough to be refillable."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin
    res = residual.astype(np.float64)

    # Reusability bonus: strongly favor residuals near/above the typical small size,
    # but only mildly, so it never overrides a genuinely tight fit.
    s = _state.small
    # penalty grows as residual falls below s (a leftover smaller than a typical
    # small item is hard to refill and likely wasted).
    short = np.maximum(s - res, 0.0)
    penalty = 0.15 * (short / s)

    # Base: smaller residual is better (best fit).
    score = -res - penalty
    return score
# EVOLVE-BLOCK-END
