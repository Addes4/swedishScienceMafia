# EVOLVE-BLOCK-START
"""Only-open-a-bin-when-useful rule on top of best fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Idea: classic best fit minimizes the post-placement residual, which tends to break
    large empty bins into half-filled ones. Instead we rank used bins by tightness
    (small residual = good), but treat the *unused* bins (remaining capacity 100) as a
    fallback: they receive the same tightness score plus a small penalty that grows
    with how much room a used bin would leave. As a result we open a fresh bin only
    when the best available used-bin residual is uncomfortably small relative to the
    item we just placed, otherwise we consolidate into used bins.
    """
    residual = bins - item  # >= 0 for every bin shown

    # Used bins: prefer the tightest placement (classic best fit).
    score = -residual.astype(np.float64)

    # Unused bins (remaining capacity exactly 100) are the fallback.
    unused = (bins == 100)
    if np.any(unused):
        # Find the tightest residual achievable with a used bin (if any).
        used = ~unused
        if np.any(used):
            best_used_res = residual[used].min()
        else:
            best_used_res = 100  # no used bins: opening a new bin is forced

        # Penalize a fresh bin based on how much slack the best used bin leaves.
        # If the best used bin is nearly full (tiny residual), opening a fresh bin
        # is worthwhile; if it leaves a healthy gap, prefer closing that gap.
        # The penalty must be large enough to actually switch the decision, hence
        # it can exceed the residual differences between bins.
        penalty = 100.0 - float(best_used_res)
        score[unused] -= penalty

    return score
# EVOLVE-BLOCK-END
