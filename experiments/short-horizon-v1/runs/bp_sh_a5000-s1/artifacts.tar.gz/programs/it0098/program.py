# EVOLVE-BLOCK-START
"""Best fit with a pure residual-smallest rule plus a dead-gap guard."""
import numpy as np


def priority(item, bins):
    """Score each bin by smallest post-placement residual (best fit).

    A small guard penalizes bins whose leftover would be a 'dead gap' (tiny,
    hard-to-reuse residual) when a cleaner placement is available, but never
    forces a large jump away from the best fit.
    """
    bins = np.asarray(bins)
    residual = bins - item

    # Base: best fit (smallest non-negative residual).
    score = -residual.astype(np.float64)

    # Dead-gap guard: residuals in (0, 12) are hard to reuse, so slightly
    # penalize them relative to bins that fit well; this is a soft nudge and
    # does not override a genuinely smaller residual by much.
    dead = (residual > 0) & (residual < 12)
    score[dead] -= 6.0

    # Prefer perfect fills: residual 0 should always win.
    perfect = residual == 0
    score[perfect] += 1000.0

    return score
# EVOLVE-BLOCK-END
