# EVOLVE-BLOCK-START
"""Best fit with a learned target residual: prefer bins whose leftover after
placing the item is close to the typical residual we have created so far."""
import numpy as np


_state = {"sum_residual": 0.0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of bins the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing item here

    # Learned target: mean residual we have left behind so far (~avg future item)
    if _state["count"] > 0:
        target = _state["sum_residual"] / _state["count"]
    else:
        target = 20.0  # rough prior for a mean-40 distribution

    # Prefer residuals close to target: tighter (small residual) is generally good,
    # but leaving near-target residual keeps bins useful for future items.
    score = -np.abs(residual - target)

    # Slight preference for already-used bins (residual < 100-... ) to avoid opening new
    # bins when fits are comparable.
    score = score - 0.5 * (bins == 100)

    # Update statistics with the residual we would create for the current best bin.
    best = int(np.argmax(score))
    _state["sum_residual"] += float(residual[best])
    _state["count"] += 1

    return score
# EVOLVE-BLOCK-END
