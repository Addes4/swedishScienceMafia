# EVOLVE-BLOCK-START
"""Best fit with reserved slack: tightest fit normally, but pack small items into gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    free = bins - item  # residual capacity after placing the item

    if item <= 20:
        # For small items, prefer the bin that leaves the largest residual but still
        # below 100 (i.e. an already-used bin), so we fill existing gaps instead of
        # opening fresh bins. Among already-used bins, largest residual wins.
        used = bins < 100
        score = np.where(used, free.astype(float), -1e9)
        # Slight preference for larger residual among used bins.
        return score

    # Otherwise: tightest fit (smallest residual).
    return -free.astype(float)
# EVOLVE-BLOCK-END

