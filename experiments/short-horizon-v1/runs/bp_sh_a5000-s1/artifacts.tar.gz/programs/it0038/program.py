# EVOLVE-BLOCK-START
"""Best fit with a tolerant tie-break toward the most-full bin of near-equal residual."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0


_state = _State()


def priority(item, bins):
    """Best fit; among near-tight placements prefer the fullest bin."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin
    thresh = 0.6 * _state.small  # residual below this is hard to reuse

    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    # If best fit leaves a usable residual (or is a fresh bin), keep it,
    # but among placements within a tiny tolerance of the best residual,
    # prefer the most-full bin (smallest current capacity) to avoid
    # opening/using looser bins unnecessarily.
    if best_res <= 0 or best_res >= thresh:
        tol = 1.0
        close = np.where((residual >= best_res) & (residual <= best_res + tol) & (bins < 100))[0]
        if close.size > 0:
            j = close[np.argmin(bins[close])]
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[j] = 1.0
            return score
        return -residual.astype(np.float64)

    # Otherwise prefer the fullest used bin whose residual is >= thresh.
    usable = np.where((residual >= thresh) & (bins < 100))[0]
    if usable.size > 0:
        j = usable[np.argmin(residual[usable])]
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

