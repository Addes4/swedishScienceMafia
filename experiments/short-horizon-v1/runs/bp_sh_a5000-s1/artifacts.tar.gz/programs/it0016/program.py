# EVOLVE-BLOCK-START
"""Best fit with a consolidation bonus: pick the tightest fit, but among
near-ties prefer the bin that is already the fullest (smallest remaining),
so residual gaps accumulate in fewer bins and stay reachable by best-fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item            # capacity left in each bin after placing here
    # Primary: tightest fit (smallest residual). Secondary: prefer already-fuller bins.
    return -(residual.astype(np.float64) * 1000.0 + bins * 1.0)
# EVOLVE-BLOCK-END
