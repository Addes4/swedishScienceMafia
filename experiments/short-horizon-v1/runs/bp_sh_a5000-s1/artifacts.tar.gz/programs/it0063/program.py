# EVOLVE-BLOCK-START
"""Best fit with an exact-residual fast path plus a waste-aware guard."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0
        self.counts = {}    # recent counts of small item sizes (for mode)
        self.min_seen = 100

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item < self.min_seen:
            self.min_seen = item
        # track mode of small item sizes seen recently (bounded memory)
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def mode_small(self):
        best_k, best_v = 0, 0
        for k, v in self.counts.items():
            if v > best_v:
                best_v, best_k = v, k
        return best_k


_state = _State()


def priority(item, bins):
    """Prefer exact residual matches to a common small size, else best fit with waste guard."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Fast path: an existing used bin whose residual exactly matches a common small item.
    m = _state.mode_small()
    if m > 0:
        match = np.where((residual == m) & (bins < 100))[0]
        if match.size > 0:
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[match[0]] = 1.0
            return score

    # Minimal plausible residual to be reusable: the smallest item we've seen
    # (fall back to a fraction of the running small estimate).
    waste_cut = max(1.0, 0.5 * _state.small)

    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    # If the tightest fit is a good (reusable) one, just take it.
    if best_res >= waste_cut:
        return -residual.astype(np.float64)

    # Tightest fit would leave an unusable residual. Look for a used bin whose
    # residual is reusable and not much larger than the tightest one; only then
    # divert, otherwise fall back to best fit to avoid over-opening bins.
    used = np.where((residual >= waste_cut) & (bins < 100))[0]
    if used.size > 0:
        j = used[np.argmin(residual[used])]
        # only divert if the reusable option isn't too wasteful
        if residual[j] <= best_res + 1.5 * _state.small:
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[j] = 1.0
            return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
