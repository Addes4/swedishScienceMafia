# EVOLVE-BLOCK-START
"""Smooth residual-quality best fit driven by a running item-size estimate."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0


_state = _State()


def priority(item, bins):
    """Best fit with a smooth penalty for leaving unusably small residuals."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item           # post-placement residual per bin
    thresh = 0.6 * _state.small      # residual below this is hard to reuse

    r = residual.astype(np.float64)
    # Base: prefer smallest residual (best fit).
    score = -r

    # Smooth penalty: for residuals in (0, thresh), add a convex bump that
    # discourages leaving a tiny gap. Fresh bins (bins == 100) are unaffected
    # since their residual is large.
    tiny = (r > 0.0) & (r < thresh)
    if np.any(tiny):
        t = r[tiny] / thresh             # in (0,1)
        # bump peaks near t=0 and decays toward thresh; magnitude tuned so it
        # only overrides near-ties in best fit.
        bump = thresh * (1.0 - t) ** 2
        score[tiny] -= bump
        # small bias: still prefer larger residuals among tiny ones
        score[tiny] -= 0.05 * t

    return score
# EVOLVE-BLOCK-END

