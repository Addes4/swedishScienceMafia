# EVOLVE-BLOCK-START
"""Learned best-fit: tightest fit, with a small bonus for residuals that match common item sizes."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)  # counts of item sizes seen so far (index 1..100)
_total = 0.0


def priority(item, bins):
    """Rank bins: prefer tightest fit; give a small bonus when the leftover is a common size."""
    global _total
    # Update the running size histogram with the current item.
    _hist[item] += 1.0
    _total += 1.0

    residual = bins - item  # post-placement leftover in each bin

    # Frequency-based desirability of a leftover: how often we've seen an item of that size.
    # Normalize so the bonus stays in [0, 1) and never overturns best-fit ties.
    freq = _hist / _total  # probabilities, ~0..1
    # Look up frequencies at residual values; clamp indices to a safe range.
    idx = np.clip(residual, 0, 100)
    leftover_bonus = freq[idx]

    # Core: tightest fit -> most negative residual gets highest score.
    # Tiny bonus for residuals matching common sizes (breaks near-ties toward reusable gaps).
    return -residual + 0.5 * leftover_bonus
# EVOLVE-BLOCK-END
