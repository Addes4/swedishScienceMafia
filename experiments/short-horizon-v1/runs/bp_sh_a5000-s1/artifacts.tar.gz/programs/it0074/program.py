# EVOLVE-BLOCK-START
"""Best fit with an exact-fill fast path for used bins."""
import numpy as np


_state = {"n": 0}


def priority(item, bins):
    """Prefer bins the item exactly fills; otherwise pick the tightest (best) fit."""
    bins = np.asarray(bins)
    residual = bins - item

    # Fast path: favor a used bin that the item fills exactly (residual 0).
    exact = np.where((residual == 0) & (bins < 100))[0]
    if exact.size > 0:
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[exact[0]] = 1.0
        return score

    # Otherwise standard best fit: smallest non-negative residual.
    score = -np.abs(residual).astype(np.float64)
    score[residual < 0] = -1e18
    return score
# EVOLVE-BLOCK-END
