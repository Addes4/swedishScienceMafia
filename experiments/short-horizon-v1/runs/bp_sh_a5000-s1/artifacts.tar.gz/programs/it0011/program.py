# EVOLVE-BLOCK-START
"""Best fit with a mild anti-fragmentation bias.

Plain best-fit minimizes the post-placement residual. That occasionally produces
tiny unusable gaps. We instead score each bin so that the tightest fit still
wins, but ties/near-ties are broken toward leaving a slightly larger (more
reusable) residual.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest."""
    residual = bins - item  # leftover capacity if placed here (>= 0 by construction)

    # Primary: tighter fit (smaller residual) is better -> negative residual.
    # Secondary: mildly prefer a residual that is large enough to stay useful,
    # but only as a small perturbation so it never overrides the tightest fit
    # except in near-ties.
    score = -residual.astype(np.float64)

    # Small bonus for residuals that are clearly reusable (a few percent of cap),
    # scaled to remain far below 1.0 so the tightest fit still dominates.
    useful = np.minimum(residual, 8.0) / 8.0  # in [0, 1]
    score += 0.02 * useful

    return score
# EVOLVE-BLOCK-END
