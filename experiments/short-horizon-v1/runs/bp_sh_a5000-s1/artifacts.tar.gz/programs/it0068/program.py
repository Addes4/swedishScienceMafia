# EVOLVE-BLOCK-START
"""Best fit with a soft penalty for unusable tiny residuals.

The dominant cost for this distribution (mean ~40, ~2.5 items per bin) is
wasted capacity: a tight best fit leaves a residual too small to hold a
typical item, stranding capacity.  Instead of a hard cutoff we score each bin
by its post-placement residual but add a smooth penalty when that residual
lands in the "hard to reuse" zone (small but positive).  We also give a soft
bonus when the residual will exactly equal the current estimate of a typical
small item, so future small items can fill it cleanly.
"""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0    # running estimate of a "small" reusable residual
        self.mean = 40.0     # running estimate of item mean
        self.n = 0

    def update(self, item):
        self.n += 1
        self.mean += (item - self.mean) / self.n
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0


_state = _State()


def priority(item, bins):
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Base: prefer small residual (best fit).
    score = -residual.astype(np.float64)

    # Penalize residuals that are positive but too small to be useful.
    small = _state.small
    # dead-zone: 0 < residual < small is hard to reuse; penalize smoothly.
    dead = (residual > 0) & (residual < small)
    score[dead] -= 0.5 * (small - residual[dead])

    # Soft bonus for a near-exact match to the typical small item.
    gap = np.abs(residual - small)
    match = (residual > 0) & (gap < 1.0)
    score[match] += 2.0

    # Never prefer staying with an empty bin when a used bin works equally.
    score[bins >= 100] -= 0.01

    return score
# EVOLVE-BLOCK-END
