# EVOLVE-BLOCK-START
"""Best fit with a recent-item-size-aware fast path for creating reusable holes."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0
        self.n = 0
        self.counts = {}      # recent counts of item sizes (bounded)
        self.recent = {}      # recency-weighted presence of item sizes

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 60:
            self.recent[item] = self.n
        if self.n % 500 == 0:
            cutoff = self.n - 1500
            for k in list(self.recent.keys()):
                if self.recent[k] < cutoff:
                    del self.recent[k]

    def is_recent(self, size):
        return size in self.recent


_state = _State()


def priority(item, bins):
    """Best fit; among near-best residuals prefer one matching a recently seen item size."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item

    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    # If the best-fit residual is negative (shouldn't happen) or an exact fit, take it.
    if best_res == 0:
        score = -residual.astype(np.float64)
        return score

    # Look for a bin whose post-placement residual matches a recently-arrived item size,
    # but only among bins that are reasonably full (residual not too large).
    if best_res > 0:
        limit = best_res + max(2, int(0.3 * _state.small))
        cand = np.where((residual > 0) & (residual <= limit) & (bins < 100))[0]
        if cand.size > 0:
            best_key = None
            best_bin = -1
            for j in cand:
                r = int(residual[j])
                if _state.is_recent(r):
                    key = (r, int(bins[j]))
                    if best_key is None or key < best_key:
                        best_key = key
                        best_bin = j
            if best_bin >= 0:
                score = np.full(bins.shape, -1e9, dtype=np.float64)
                score[best_bin] = 1.0
                return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
