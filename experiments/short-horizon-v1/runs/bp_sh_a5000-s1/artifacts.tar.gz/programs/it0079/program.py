# EVOLVE-BLOCK-START
"""Best fit with perfect-fill priority and bounded-gap avoidance using an online
estimate of the smallest likely item size."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        # running minimum-ish estimate of small item sizes (lower quantile proxy)
        self.small = 20.0

    def update(self, item):
        self.n += 1
        # track a slowly-adapting estimate of a "small" item size
        s = float(min(item, 40))
        self.small = 0.99 * self.small + 0.01 * s
        if self.small < 3.0:
            self.small = 3.0


_state = _State()


def priority(item, bins):
    """Priority per bin: perfect fill first, else best fit avoiding unusable gaps."""
    _state.update(item)
    bins = np.asarray(bins)
    used = bins < 100
    residual = bins - item  # post-placement residual per bin

    # 1) Perfect fill: position leaves residual 0.
    perfect = np.where(residual == 0)[0]
    if perfect.size > 0:
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[perfect[0]] = 1.0
        return score

    # 2) Best fit among used bins (avoid wasting a fresh bin if possible).
    if used.any():
        used_res = np.where(used, residual, np.iinfo(np.int64).max)
        best_idx = int(np.argmin(used_res))
        best_res = residual[best_idx]
    else:
        best_idx = int(np.argmin(residual))
        best_res = residual[best_idx]

    # 3) If best residual is a tiny gap that future items likely can't fill,
    #    prefer the smallest residual that is at least the small-item estimate.
    thresh = max(1, int(round(0.5 * _state.small)))
    if 0 < best_res < thresh:
        ok = np.where((residual >= thresh) & used)[0]
        if ok.size == 0:
            # allow a new bin if no used bin gives a usable residual
            ok = np.where(residual >= thresh)[0]
        if ok.size > 0:
            j = int(ok[np.argmin(residual[ok])])
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[j] = 1.0
            return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
