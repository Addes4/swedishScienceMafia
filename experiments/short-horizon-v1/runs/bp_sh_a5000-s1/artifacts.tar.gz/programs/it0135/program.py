# EVOLVE-BLOCK-START
"""Best fit with an exact-residual fast path driven by a recent-item-size window."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0
        self.n = 0
        self.recent = {}   # value -> count within the recent window (small items only)
        self.order = []    # insertion order of recent keys (for bounded decay)

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 60:
            self.recent[item] = self.recent.get(item, 0) + 1
            if self.n % 250 == 0:
                for k in list(self.recent.keys()):
                    self.recent[k] -= 1
                    if self.recent[k] <= 0:
                        del self.recent[k]

    def recent_sizes(self):
        return self.recent


_state = _State()


def priority(item, bins):
    """Prefer an exact residual match to a recently seen item size, else best fit."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Fast path: find bins whose residual equals a recently seen item size.
    recent = _state.recent_sizes()
    if recent:
        # weight match by how frequently that size has been arriving recently
        best_j = -1
        best_w = 0.0
        # iterate over recent keys, do vectorized match per key (keys are few)
        for k, v in recent.items():
            if k <= 0:
                continue
            match = np.where((residual == k) & (bins < 100))[0]
            if match.size > 0:
                if v > best_w:
                    best_w = v
                    best_j = match[0]
        if best_j >= 0:
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[best_j] = 1.0
            return score

    thresh = 0.6 * _state.small

    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    if best_res <= 0 or best_res >= thresh:
        return -residual.astype(np.float64)

    usable = np.where((residual >= thresh) & (bins < 100))[0]
    if usable.size > 0:
        j = usable[np.argmin(residual[usable])]
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
