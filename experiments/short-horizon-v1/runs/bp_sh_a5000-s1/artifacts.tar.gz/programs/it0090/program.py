# EVOLVE-BLOCK-START
"""Best fit with a mild exact-residual preference for common small sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority per bin: best fit, with a mild bonus for reusable residuals."""
    bins = np.asarray(bins)
    residual = bins - item

    score = -residual.astype(np.float64)

    # Mild bonus for residuals that are common small item sizes, so a perfectly
    # reusable gap is preferred over a marginally smaller dead gap.
    # These sizes are typical of the sum-two-small-items regime of this distribution.
    reusable = (residual >= 5) & (residual <= 15) & (bins < 100)
    score[reusable] += 1.0

    return score
# EVOLVE-BLOCK-END
