# EVOLVE-BLOCK-START
"""Plain best fit: put the item in the bin leaving the smallest residual capacity."""
import numpy as np


def priority(item, bins):
    """Return a priority per bin; highest score (smallest residual) wins."""
    bins = np.asarray(bins)
    residual = bins - item
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
