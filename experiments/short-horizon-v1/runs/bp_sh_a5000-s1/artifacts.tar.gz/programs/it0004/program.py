# EVOLVE-BLOCK-START
"""Best fit, but avoid repeatedly targeting bins that would be left with tiny slivers."""
import numpy as np

# Threshold under which a leftover residual is considered a useless sliver.
SLIVER = 4


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Base: best fit = tightest residual after placing.
    residual = bins - item
    score = -residual.astype(np.float64)

    # Penalize placements that would create a tiny useless leftover, since that
    # fragment is unlikely to be reusable for future (larger) items.
    sliver = (residual > 0) & (residual <= SLIVER)
    score[sliver] -= 8.0

    return score
# EVOLVE-BLOCK-END
