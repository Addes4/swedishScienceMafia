# EVOLVE-BLOCK-START
"""Best fit with an exact-residual-match fast path driven by common small item sizes."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0
        self.n = 0
        self.counts = {}

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def common_small(self, k=3, min_count=5):
        """Return up to k frequently-seen small item sizes."""
        items = sorted(self.counts.items(), key=lambda kv: -kv[1])
        out = []
        for size, cnt in items:
            if cnt >= min_count and size > 0:
                out.append(size)
            if len(out) >= k:
                break
        return out


_state = _State()


def priority(item, bins):
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item

    # Fast path: prefer a used bin whose residual exactly matches a common small item.
    targets = _state.common_small()
    if targets:
        used = bins < 100
        best_idx = -1
        best_res = None
        for t in targets:
            match = np.where((residual == t) & used)[0]
            if match.size > 0:
                r = residual[match[0]]
                if best_res is None or r < best_res:
                    best_res = r
                    best_idx = match[0]
        if best_idx >= 0:
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[best_idx] = 1.0
            return score

    thresh = 0.6 * _state.small

    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    if best_res <= 0 or best_res >= thresh:
        return -residual.astype(np.float64)

    usable = np.where((residual >= thresh) & (bins < 100))[0]
    if usable.size > 0:
        j = usable[np.argmin(residual[usable])]
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

