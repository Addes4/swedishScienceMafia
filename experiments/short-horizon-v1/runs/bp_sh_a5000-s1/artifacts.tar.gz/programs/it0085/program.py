# EVOLVE-BLOCK-START
"""Best fit biased toward residuals that can still fit a typical upcoming item."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0

    def update(self, item):
        self.n += 1
        # running mean of item sizes
        self.mean += (item - self.mean) / min(self.n, 200)


_state = _State()


def priority(item, bins):
    bins = np.asarray(bins)
    _state.update(item)
    residual = bins - item  # post-placement leftover per bin

    typical = _state.mean  # expected size of a future item

    # Base score: smaller residual is better (best fit).
    score = -residual.astype(np.float64)

    # Bonus when the residual is large enough to still fit a typical item,
    # which keeps the bin "alive" for reuse; penalty for tiny dead gaps.
    dead = residual < typical
    score[dead] -= 50.0

    return score
# EVOLVE-BLOCK-END
