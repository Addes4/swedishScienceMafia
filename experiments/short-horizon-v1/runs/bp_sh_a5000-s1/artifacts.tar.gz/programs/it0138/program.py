# EVOLVE-BLOCK-START
"""Slightly convex best fit: a smooth, stateless ranking that avoids unfillable holes."""
import numpy as np


def priority(item, bins):
    """Rank bins by a mildly convex penalty on the post-placement residual.

    Pure best-fit minimizes the immediate residual, but a very small nonzero
    residual can be impossible to fill later, wasting the bin. Adding a small
    quadratic term makes the rule marginally prefer residuals that are either
    zero (perfect fit) or comfortably large, without special-case state.
    """
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item

    # Base reward: leave as little space as possible (best fit).
    score = -residual

    # Mildly penalize tiny nonzero holes more than the linear best-fit term
    # already does, so unfillable slivers are discouraged. Zero residual is
    # left untouched (exact fits stay optimal).
    tiny = (residual > 0) & (residual < 3.0)
    score -= tiny * (3.0 - residual) * 0.05

    return score
# EVOLVE-BLOCK-END
