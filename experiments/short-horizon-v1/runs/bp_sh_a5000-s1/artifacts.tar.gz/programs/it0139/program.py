# EVOLVE-BLOCK-START
"""Best fit with an adaptive recency-weighted exact-residual fast path."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.small = 12.0
        # recency-weighted frequency per item size (exponential decay)
        self.freq = np.zeros(101, dtype=np.float64)
        self.decay = 0.99

    def update(self, item):
        self.n += 1
        self.freq *= self.decay
        self.freq[item] += 1.0
        s = float(min(item, 40))
        self.small = 0.99 * self.small + 0.01 * s
        if self.small < 4.0:
            self.small = 4.0

    def weight(self, size):
        # likelihood that an arriving item of that exact residual size shows up,
        # gently favoring residuals near the typical small item size
        if size <= 0 or size > 100:
            return 0.0
        return self.freq[size]


_state = _State()


def priority(item, bins):
    """Prefer exact-residual matches weighted by recency, else best fit with guard."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Fast path: existing used bin whose post-placement residual exactly
    # matches a recently frequent item size (likely to be filled soon).
    used = bins < 100
    best_idx = -1
    best_w = 0.0
    if item <= 45:
        f = _state.freq
        # candidates: residuals that are a plausible future item size
        cand = np.where(used & (residual > 0) & (residual <= 45))[0]
        for j in cand:
            w = f[residual[j]]
            if w > best_w:
                best_w = w
                best_idx = j
    if best_idx >= 0 and best_w > 0:
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[best_idx] = 1.0
        return score

    thresh = 0.6 * _state.small  # residual below this is hard to reuse

    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    if best_res <= 0 or best_res >= thresh:
        return -residual.astype(np.float64)

    usable = np.where((residual >= thresh) & used)[0]
    if usable.size > 0:
        j = usable[np.argmin(residual[usable])]
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
