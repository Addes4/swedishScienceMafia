# EVOLVE-BLOCK-START
"""Best fit with a mild convex penalty that discourages leaving tiny unusable holes."""
import numpy as np


def priority(item, bins):
    """Score bins: strongly prefer exact fits, else best fit with a slight penalty on small residuals."""
    bins = np.asarray(bins)
    residual = (bins - item).astype(np.float64)

    # Base: prefer smaller residual (best fit).
    score = -residual

    # Strong bonus for exact fits.
    score = np.where(residual == 0, 1.0, score)

    # Mild convex penalty: a nonzero-but-tiny leftover hole is usually wasted,
    # so slightly penalize residuals in a small band to avoid creating them.
    small_penalty = np.where((residual > 0) & (residual < 10), -0.05 * (10.0 - residual), 0.0)
    score = score + small_penalty

    return score
# EVOLVE-BLOCK-END

