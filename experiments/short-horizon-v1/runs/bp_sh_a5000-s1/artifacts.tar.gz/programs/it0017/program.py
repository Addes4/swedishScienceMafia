# EVOLVE-BLOCK-START
"""Hybrid: fullest-bin preference with best-fit tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer the bin whose residual after placement is smallest.
    residual = bins - item
    # Primary: tightest fit (smallest residual). Secondary encoded by scaling so that
    # among equal residuals, the more-full bin (smaller remaining capacity) wins.
    return -residual.astype(np.float64) * 1000.0 - bins.astype(np.float64)
# EVOLVE-BLOCK-END
