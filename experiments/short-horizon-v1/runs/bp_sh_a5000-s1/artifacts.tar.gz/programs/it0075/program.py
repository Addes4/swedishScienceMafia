# EVOLVE-BLOCK-START
"""Best fit with an exact-residual-match fast path driven by the recent small-item mode."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0
        self.hist = {}      # exponentially-decayed counts of small item sizes
        self.decay = 0.999  # per-item multiplicative decay

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        # exponentially-decayed histogram of small item sizes (bounded memory)
        if item <= 40:
            h = self.hist
            for k in list(h.keys()):
                v = h[k] * self.decay
                if v < 1e-3:
                    del h[k]
                else:
                    h[k] = v
            h[item] = h.get(item, 0.0) + 1.0

    def mode_small(self):
        best_k, best_v = 0, 0.0
        for k, v in self.hist.items():
            if v > best_v:
                best_v, best_k = v, k
        return best_k


_state = _State()


def priority(item, bins):
    """Return a priority per bin: prefer an exact residual match, else best fit with a guard."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Fast path: an existing used bin whose residual exactly matches a common small item.
    m = _state.mode_small()
    if m > 0:
        match = np.where((residual == m) & (bins < 100))[0]
        if match.size > 0:
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[match[0]] = 1.0
            return score

    thresh = 0.6 * _state.small  # residual below this is hard to reuse

    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    if best_res <= 0 or best_res >= thresh:
        score = -residual.astype(np.float64)
        return score

    usable = np.where((residual >= thresh) & (bins < 100))[0]
    if usable.size > 0:
        j = usable[np.argmin(residual[usable])]
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END


