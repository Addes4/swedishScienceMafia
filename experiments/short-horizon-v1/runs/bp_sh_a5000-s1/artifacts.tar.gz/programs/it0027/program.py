# EVOLVE-BLOCK-START
"""Best fit with a mild near-tie tiebreak toward larger residual."""
import numpy as np


def priority(item, bins):
    """Rank bins for the arriving item by tightest fit, breaking near-ties.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item               # remaining capacity after placing item
    # Primary: prefer small residual (best fit). Secondary: among near-ties,
    # prefer the bin that leaves a slightly larger residual (less risk of
    # leaving an unusable tiny gap next time).
    return -(residual.astype(np.float64)) + 0.01 * residual.astype(np.float64)
# EVOLVE-BLOCK-END

