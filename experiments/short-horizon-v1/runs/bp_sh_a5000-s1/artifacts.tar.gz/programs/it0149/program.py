# EVOLVE-BLOCK-START
"""Best fit with a smooth residual-frequency bonus favoring reusable holes."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0
        self.n = 0
        self.counts = {}   # recency-ish counts of item sizes (bounded)

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        # track frequency of all sizes (bounded decay)
        self.counts[item] = self.counts.get(item, 0) + 1
        if self.n % 500 == 0:
            for k in list(self.counts.keys()):
                self.counts[k] = self.counts[k] // 2
                if self.counts[k] == 0:
                    del self.counts[k]


_state = _State()


def priority(item, bins):
    """Best fit, with a smooth bonus for residuals matching frequent item sizes."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item

    # Base: best fit (smaller residual better). Big weight dominates.
    base = -residual.astype(np.float64) * 1000.0

    # Bonus: prefer residual equal to a frequently-seen future item size,
    # scaled smoothly by that size's relative frequency. Never overrides
    # the dominant best-fit term, only breaks near-ties.
    total = float(_state.n)
    if total > 0:
        # map residual -> frequency bonus via a lookup over observed sizes
        bonus = np.zeros(bins.shape, dtype=np.float64)
        for k, v in _state.counts.items():
            if k <= 0:
                continue
            freq = v / total
            match = residual == k
            if match.any():
                bonus[match] = freq
        # scale small enough to only break ties within the best-fit band
        base += bonus

    return base
# EVOLVE-BLOCK-END
