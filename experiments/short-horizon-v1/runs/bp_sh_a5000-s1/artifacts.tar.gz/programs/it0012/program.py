# EVOLVE-BLOCK-START
"""Learned best-fit: prefer tightest fit, but reward residuals that match common item sizes."""
import numpy as np


class _Hist:
    def __init__(self, n=101):
        self.counts = np.zeros(n, dtype=np.float64)
        self.total = 0.0

    def add(self, item):
        self.counts[int(item)] += 1.0
        self.total += 1.0

    def freq(self, size):
        if self.total <= 0:
            return 0.0
        s = int(round(size))
        if s < 1 or s > 100:
            return 0.0
        return self.counts[s] / self.total


_H = _Hist()


def priority(item, bins):
    """Score each candidate bin.

    Base: tightest fit (smallest residual after placement).
    Refinement: a bin whose post-placement residual equals a frequently-seen
    item size is slightly preferred, since that leftover is likely reusable.
    """
    residual = bins - item  # >= 0 for bins we are shown

    # Running histogram is updated after scoring so it reflects past items.
    freq = _H.freq
    n = residual.shape[0]
    bonus = np.zeros(n, dtype=np.float64)
    if _H.total > 8.0:
        for i in range(n):
            bonus[i] = freq(residual[i])

    # Normalize bonus to a modest magnitude relative to residual differences.
    score = -residual.astype(np.float64) + 0.5 * bonus

    _H.add(item)
    return score
# EVOLVE-BLOCK-END
