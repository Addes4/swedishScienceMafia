# EVOLVE-BLOCK-START
"""Best fit with a gated exact-fill fast path and a modal-size dead-gap guard."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.counts = {}          # decaying histogram of recent item sizes
        self.bins_used = 0        # count of items placed so far (proxy via calls in used bins)

    def update(self, item):
        self.n += 1
        self.counts[item] = self.counts.get(item, 0) + 1
        if self.n % 500 == 0:
            for k in list(self.counts.keys()):
                self.counts[k] //= 2
                if self.counts[k] == 0:
                    del self.counts[k]

    def mode(self):
        best_k, best_v = 0, 0
        for k, v in self.counts.items():
            if v > best_v:
                best_v, best_k = v, k
        return best_k


_state = _State()


def priority(item, bins):
    """Prefer exact fill (residual 0), avoid leaving a dead gap; else pure best fit."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual

    # 1) Perfect fill: take it (always good, cheap).
    zero = np.where(residual == 0)[0]
    if zero.size > 0:
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[zero[0]] = 1.0
        return score

    # 2) Best-fit candidate.
    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    # If best-fit residual is comfortably reusable, just best-fit.
    m = _state.mode()
    dead = m if m > 0 else 0

    # A residual is a "dead gap" only if it can't hold even a tiny item (residual in 1..min_item-1).
    # Use a conservative threshold: only divert if residual < (approx smallest common item).
    if dead <= 1 or best_res <= 0 or best_res >= dead:
        return -residual.astype(np.float64)

    # 3) Best-fit leaves a dead gap; try a bin that avoids it while staying small.
    usable = np.where((bins < 100) & (residual > 0) & (residual >= dead))[0]
    if usable.size > 0:
        j = usable[np.argmin(residual[usable])]
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

