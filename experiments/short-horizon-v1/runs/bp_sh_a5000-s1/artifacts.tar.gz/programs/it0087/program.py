# EVOLVE-BLOCK-START
"""Best fit with perfect-fill priority and a dead-gap repair step."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0
        self.counts = {}    # recent counts of small item sizes (mode)

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def mode_small(self):
        best_k, best_v = 0, 0
        for k, v in self.counts.items():
            if v > best_v:
                best_v, best_k = v, k
        return best_k


_state = _State()


def priority(item, bins):
    """Perfect fill first, else best fit, repairing dead-gap residuals when possible."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item.astype(np.int64)  # post-placement residual per bin

    # 1) Perfect fill if any bin matches exactly.
    perfect = np.where(residual == 0)[0]
    if perfect.size > 0:
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[perfect[0]] = 1.0
        return score

    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    # 2) Pure best fit when the residual is large enough to be reusable,
    #    or when no used bin exists at all.
    dead_thresh = 0.6 * _state.small
    if best_res >= dead_thresh or best_res <= 0:
        return -residual.astype(np.float64)

    # 3) Best fit leaves a dead gap. Try to find a used bin whose residual
    #    after placement can still fit the recent small-item mode.
    m = _state.mode_small()
    if m > 0:
        good = np.where((residual >= m) & (bins < 100))[0]
        if good.size > 0:
            j = good[np.argmin(residual[good])]
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[j] = 1.0
            return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
