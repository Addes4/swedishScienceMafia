# EVOLVE-BLOCK-START
"""Best fit softened by a convex penalty on leaving a small, likely-unusable residual."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 5.0   # running estimate of small item sizes
        self.n = 0

    def update(self, item):
        self.n += 1
        if item <= 40:
            self.small = 0.99 * self.small + 0.01 * float(item)
        if self.small < 2.0:
            self.small = 2.0
        if self.small > 30.0:
            self.small = 30.0


_state = _State()


def priority(item, bins):
    """Rank bins: prefer tight fit, penalize small unusable residuals."""
    _state.update(item)
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # post-placement residual per bin

    s = _state.small
    # Base: strongly prefer smallest residual (best fit).
    score = -residual

    # Penalize residuals that are positive but too small to be reused.
    # A smooth, monotone penalty that is ~0 once residual >= s.
    small_res = np.clip(residual, 0.0, None)
    # For residual < s, subtract a penalty that grows as residual -> 0+ .
    pen = np.where(residual < s, (s - small_res) ** 2 / (s * s), 0.0)
    score = score - 0.5 * pen

    return score
# EVOLVE-BLOCK-END
