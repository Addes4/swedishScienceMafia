# EVOLVE-BLOCK-START
"""Best fit, with a strong boost for bins whose residual exactly matches the item size."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer smallest nonnegative residual; the tightest fit wins ties."""
    bins = np.asarray(bins)
    residual = bins - item
    # Pure best fit: smallest nonnegative residual first.
    score = -residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
