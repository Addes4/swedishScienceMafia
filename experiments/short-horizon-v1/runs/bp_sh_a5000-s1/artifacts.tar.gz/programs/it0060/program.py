# EVOLVE-BLOCK-START
"""Best fit with a small preference for leaving a residual large enough to fit a typical item."""
import numpy as np


class _State:
    def __init__(self):
        self.mean = 40.0
        self.n = 0

    def update(self, item):
        self.n += 1
        self.mean += (item - self.mean) / min(self.n, 200.0)


_state = _State()


def priority(item, bins):
    _state.update(item)
    bins = np.asarray(bins)
    residual = (bins - item).astype(np.float64)

    m = _state.mean
    # Best fit base score (higher = better = smaller residual).
    score = -residual
    # Tiny bonus when the post-placement residual is around one typical item,
    # so the bin stays reusable rather than being closed with a useless sliver.
    diff = np.abs(residual - m)
    score += 0.5 * np.exp(-diff / 10.0)
    return score
# EVOLVE-BLOCK-END
