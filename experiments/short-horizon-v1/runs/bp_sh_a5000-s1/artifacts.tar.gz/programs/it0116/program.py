# EVOLVE-BLOCK-START
"""Exact-residual fast path over a small window, else plain best fit."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0    # running estimate of a "small" item size
        self.n = 0
        self.counts = {}     # recent counts of small item sizes

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def mode_small(self):
        best_k, best_v = 0, 0
        for k, v in self.counts.items():
            if v > best_v:
                best_v, best_k = v, k
        return best_k


_state = _State()


def priority(item, bins):
    """Prefer an existing bin whose residual matches a common small item; else best fit."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item

    # Fast path: try to leave a residual equal to the recent small-item mode,
    # searching a tiny window around it to increase hit rate.
    m = _state.mode_small()
    if m > 0:
        used = bins < 100
        best_idx = -1
        best_target = -1.0
        for d in (0, -1, 1, -2, 2):
            t = m + d
            if t <= 0:
                continue
            match = np.where((residual == t) & used)[0]
            if match.size > 0:
                # prefer the smallest bin that achieves this residual (least waste)
                j = match[np.argmin(bins[match])]
                return np.where(np.arange(bins.shape[0]) == j, 1.0, -1e9).astype(np.float64)

    # Otherwise: best fit (smallest non-negative residual).
    score = -residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
