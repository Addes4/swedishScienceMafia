# EVOLVE-BLOCK-START
"""Best fit with a soft bounded bonus for residuals matching common small item sizes."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0
        self.counts = {}    # recent counts of small item sizes (for mode)

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def top_modes(self, k=3):
        """Return up to k most common small item sizes."""
        items = sorted(self.counts.items(), key=lambda kv: kv[1], reverse=True)
        return [kv[0] for kv in items[:k]]


_state = _State()


def priority(item, bins):
    """Best-fit base with a bounded soft bonus for common small residual matches."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    base = -residual.astype(np.float64)

    # Dead-gap guard: if best-fit would leave a residual too small to hold a
    # typical upcoming item, prefer the smallest usable (non-dead) residual.
    thresh = 0.6 * _state.small
    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]
    if 0 < best_res < thresh:
        usable = np.where((residual >= thresh) & (bins < 100))[0]
        if usable.size > 0:
            j = usable[np.argmin(residual[usable])]
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[j] = 1.0
            return score

    # Soft bounded bonus: reward residuals matching a common small item size,
    # without ever overriding a genuinely better (smaller) residual.
    modes = _state.top_modes(3)
    if modes:
        used = bins < 100
        bonus = np.zeros(bins.shape, dtype=np.float64)
        for m in modes:
            bonus = np.maximum(bonus, (residual == m).astype(np.float64))
        # bonus magnitude smaller than 1 residual unit, applied only to used bins
        base = base + 0.5 * bonus * used

    return base
# EVOLVE-BLOCK-END


