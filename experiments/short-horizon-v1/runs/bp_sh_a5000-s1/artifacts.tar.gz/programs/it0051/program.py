# EVOLVE-BLOCK-START
"""Best fit with an exact-residual fast path driven by a recent item-size histogram."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.hist = np.zeros(101, dtype=np.float64)  # smoothed recent item-size histogram
        self.decay = 0.995

    def update(self, item):
        self.n += 1
        self.hist *= self.decay
        self.hist[item] += 1.0

    def best_targets(self):
        """Return the most promising residual targets (item sizes likely to reappear)."""
        # mass-weighted top sizes
        order = np.argsort(-self.hist[1:41]) + 1  # only sizes <=40 are plausible fillers
        return order[:5]

    def mass(self, size):
        if 1 <= size <= 100:
            return self.hist[size]
        return 0.0


_state = _State()


def priority(item, bins):
    """Prefer binds whose residual is a frequently-seen small item size; else best fit."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = (bins - item).astype(np.int64)

    # Fast path: a used bin whose residual exactly matches a frequent small item size.
    if item <= 60:
        targets = _state.best_targets()
        best_bin = -1
        best_score = 0.0
        used = bins < 100
        for t in targets:
            if t <= 0:
                continue
            m = (residual == t) & used
            if m.any():
                sc = _state.mass(t) / max(t, 1.0)
                if sc > best_score:
                    best_score = sc
                    idxs = np.where(m)[0]
                    best_bin = idxs[0]
        if best_bin >= 0:
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[best_bin] = 1.0
            return score

    # Otherwise: best fit, but avoid leaving a tiny, unusable residual if possible.
    thresh = 6.0
    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    if best_res <= 0 or best_res >= thresh:
        return -residual.astype(np.float64)

    usable = np.where((residual >= thresh) & (bins < 100))[0]
    if usable.size > 0:
        j = usable[np.argmin(residual[usable])]
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
