# EVOLVE-BLOCK-START
"""Best fit with a soft, bounded preference for reusable residuals."""
import numpy as np


def priority(item, bins):
    """Score bins: best-fit base, soft bonus for residuals matching common small sizes."""
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    score = -residual.astype(np.float64)

    # Soft preference for residuals that common small items could fill:
    # residual in a "golden" band (small enough to be filled soon) gets a bonus.
    # Bonus magnitude stays well below 1 so it only breaks near-ties.
    golden = (residual >= 5) & (residual <= 20)
    score = score + golden * 0.4

    return score
# EVOLVE-BLOCK-END

