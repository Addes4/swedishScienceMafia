# EVOLVE-BLOCK-START
"""Best fit with a soft bonus for residuals matching common small item sizes."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.counts = {}   # recent counts of small item sizes

    def update(self, item):
        self.n += 1
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 1000 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def common_sizes(self):
        # sizes observed at least a few times recently (candidate reusable gaps)
        return {k for k, v in self.counts.items() if v >= 3}


_state = _State()


def priority(item, bins):
    """Best fit (score = -residual) plus a tiny bonus for common reusable residuals."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    score = -residual.astype(np.float64)

    # Soft bonus: prefer bins that will leave a residual matching a common small item.
    # Magnitude is small (0.25) so it only breaks near-ties, never overrides a
    # clearly tighter fit chosen by best-fit.
    used = bins < 100
    common = _state.common_sizes()
    if common:
        for sz in common:
            score[(residual == sz) & used] += 0.25

    return score
# EVOLVE-BLOCK-END
