# EVOLVE-BLOCK-START
"""Hybrid: best-fit for small/medium items; for large items prefer a bin whose
post-placement residual is not tiny, to avoid fragmenting space that a large item
would need later. This reduces end-of-stream waste compared to plain best-fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all shown bins

    # Base: tightest fit (best fit) => smaller residual is better.
    base = -residual.astype(np.float64)

    if item >= 55:
        # For large items, slightly prefer bins that leave a usable residual
        # (around a typical item size), instead of shaving to near-zero.
        target = 25.0
        # closeness to leaving `target` capacity after placement
        bonus = -np.abs(residual - target).astype(np.float64)
        return base + 0.15 * bonus

    return base
# EVOLVE-BLOCK-END
