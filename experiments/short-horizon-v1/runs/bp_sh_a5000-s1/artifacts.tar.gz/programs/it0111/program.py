# EVOLVE-BLOCK-START
"""Best fit with a reusable-residual fast path driven by recent small-item sizes."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0
        self.counts = {}    # recent counts of small item sizes (for reuse targets)

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def targets(self):
        """Return the set of small residuals we'd like to leave open for reuse."""
        t = set()
        # mode of recent small items
        best_k, best_v = 0, 0
        for k, v in self.counts.items():
            if v > best_v:
                best_v, best_k = v, k
        if best_k > 0:
            for d in (-1, 0, 1):
                if best_k + d > 0:
                    t.add(best_k + d)
        # a window around the running small-item estimate
        base = int(round(self.small))
        for d in (-2, -1, 0, 1, 2):
            if base + d > 0:
                t.add(base + d)
        return t


_state = _State()


def priority(item, bins):
    """Prefer leaving a reusable hole; otherwise best fit with a dead-gap guard."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item

    # Fast path: prefer a used bin whose residual lands on a reusable target.
    targets = _state.targets()
    if targets:
        used = bins < 100
        mask = np.zeros(bins.shape, dtype=bool)
        tlist = list(targets)
        for t in tlist:
            mask |= (residual == t)
        mask &= used
        match = np.where(mask)[0]
        if match.size > 0:
            # among matches, prefer the smallest positive residual (tightest reusable hole)
            j = match[np.argmin(residual[match])]
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[j] = 1.0
            return score

    thresh = 0.6 * _state.small  # residual below this is hard to reuse

    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    if best_res <= 0 or best_res >= thresh:
        score = -residual.astype(np.float64)
        return score

    usable = np.where((residual >= thresh) & (bins < 100))[0]
    if usable.size > 0:
        j = usable[np.argmin(residual[usable])]
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
