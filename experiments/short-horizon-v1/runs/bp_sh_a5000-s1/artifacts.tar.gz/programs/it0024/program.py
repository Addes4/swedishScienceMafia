# EVOLVE-BLOCK-START
"""Two-regime rule: best fit normally, reuse gaps for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Maintain a running mean of item sizes seen so far.
    global _sum, _count
    try:
        _sum += item
        _count += 1
    except NameError:
        _sum = item
        _count = 1
    mean = _sum / _count

    residual = bins - item  # remaining capacity if placed here

    if item < mean:
        # Small item: prefer the fullest bin whose residual stays usable,
        # i.e. large enough to still hold a typical future item.
        usable = residual >= mean
        scores = np.where(usable, -residual, np.float64(-1e18) + residual * 0.0 - residual)
    else:
        # Normal/large item: tightest fit.
        scores = -residual

    return scores
# EVOLVE-BLOCK-END
