# EVOLVE-BLOCK-START
"""Best fit with a mild preference: smallest non-negative residual, index-stable."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0

    def update(self, item):
        self.n += 1


_state = _State()


def priority(item, bins):
    """Score = -(post-placement residual); among equal residuals keep first bin (stable)."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

