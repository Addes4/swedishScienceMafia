# EVOLVE-BLOCK-START
"""Best fit with a small-residual guard.

Standard best fit puts the item in the bin with the smallest remaining capacity that
still fits, i.e. it minimizes the residual (bins - item). This is strong online, but it
often leaves a tiny, unusable residual that future items cannot exploit.

Here we keep best fit as the default, but when the tightest placement would leave a
residual below a small threshold (a gap too small for most future items), we instead
prefer the placement among the near-best candidates that leaves the largest residual.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since the harness only shows fitting bins

    # Smallest residual achievable right now (classic best fit target).
    min_res = residual.min()

    # If the tightest placement leaves a comfortably reusable gap, plain best fit is fine.
    if min_res >= 10:
        return -residual.astype(np.float64)

    # Otherwise (tightest placement would strand a tiny gap), among the near-tightest
    # candidates prefer the placement that leaves the largest reusable residual.
    near = residual <= min_res + 9
    scores = np.where(near, residual.astype(np.float64), -1.0)
    return scores
# EVOLVE-BLOCK-END

