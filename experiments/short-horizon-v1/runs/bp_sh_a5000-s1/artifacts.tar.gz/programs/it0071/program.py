# EVOLVE-BLOCK-START
"""Pure Best-Fit: place the item into the fitting bin with the smallest residual."""
import numpy as np


def priority(item, bins):
    """Score = negative post-placement residual, so the tightest fit wins."""
    bins = np.asarray(bins)
    residual = bins - item
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

