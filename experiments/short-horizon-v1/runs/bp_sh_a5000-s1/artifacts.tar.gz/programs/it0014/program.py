# EVOLVE-BLOCK-START
"""Adaptive best-fit with a gentle "reusable gap" tie-break.

Core rule is best-fit: put the item in the bin with the smallest remaining
capacity that still fits it (tightest fit).  Ties (and near-ties within a
small tolerance) are broken by preferring the bin whose post-placement
residual is closest to the running mean item size -- such gaps are the most
likely to be reused by a future item.  A tiny bonus prefers already-used bins
over fresh ones when the item is not large.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0, "counts": None}


def _update(item):
    st = _state
    st["n"] += 1
    st["sum"] += item
    if st["counts"] is None:
        st["counts"] = np.zeros(101, dtype=np.float64)
    st["counts"][item] += 1.0


def priority(item, bins):
    """Return a priority per bin; highest wins, first on ties."""
    _update(item)

    resid = bins.astype(np.float64) - float(item)   # residual after placing
    used = bins < 100                               # non-fresh bins

    n = _state["n"]
    mean = _state["sum"] / n if n else 40.0

    # Tolerance: how close in residual we consider a "near-tie".
    tol = 0.06 * float(item) + 1.0

    # Base: prefer tightest fit (most negative residual -> smallest remaining).
    # First, find the minimal residual to define the near-tie band.
    min_res = resid.min()
    in_band = resid <= min_res + tol

    # Within the band, prefer residual close to the empirical mean item size
    # (reusable gap), and mildly prefer used bins.
    scale = max(mean, 1.0)
    gap_bonus = -np.abs(resid - mean) / scale        # in [-inf, 0]
    used_bonus = np.where(used, 0.02, 0.0)

    # Only the band gets the bonus; outside the band, plain tightness dominates.
    score = -resid
    score = score + np.where(in_band, gap_bonus + used_bonus, 0.0)

    return score
# EVOLVE-BLOCK-END
