# EVOLVE-BLOCK-START
"""Best fit softened by a frequency-weighted exact-residual reuse bonus."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 20.0
        self.n = 0
        self.counts = {}

    def update(self, item):
        self.n += 1
        s = float(min(item, 60))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 5.0:
            self.small = 5.0
        # track counts of all item sizes seen (bounded via periodic decay)
        self.counts[item] = self.counts.get(item, 0) + 1
        if self.n % 500 == 0:
            for k in list(self.counts.keys()):
                self.counts[k] = self.counts[k] // 2
                if self.counts[k] == 0:
                    del self.counts[k]

    def total(self):
        t = 0
        for v in self.counts.values():
            t += v
        return t

    def freq(self, k):
        return self.counts.get(k, 0)


_state = _State()


def priority(item, bins):
    """Rank bins: base is best fit (smallest residual); add a bounded bonus when
    the post-placement residual matches a frequently requested small item size."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = (bins - item).astype(np.float64)

    total = _state.total()
    if total <= 0:
        return -residual

    # base best-fit score
    score = -residual

    # soft bonus for residuals that match a common recent item size
    # scale of "meaningful" residual: around the typical item size, capped
    cap = _state.small * 1.2
    # Only consider residual values that are plausible item sizes
    uniq, inv = np.unique(residual.astype(np.int64), return_inverse=True)
    for i, r in enumerate(uniq):
        if r <= 0 or r > 100:
            continue
        f = _state.freq(int(r))
        if f > 0 and r <= cap:
            add = (f / total) * r  # bounded by residual magnitude
            score[inv == i] += add

    # dead-gap guard: strongly avoid leaving a tiny hard-to-reuse residual
    thresh = 0.4 * _state.small
    tiny = (residual > 0) & (residual < thresh)
    score[tiny] -= thresh

    return score
# EVOLVE-BLOCK-END
