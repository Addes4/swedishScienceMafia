# EVOLVE-BLOCK-START
"""Best fit with a smoothed residual-utility ranking driven by a running median estimate."""
import numpy as np


class _State:
    def __init__(self):
        self.med = 40.0     # running estimate of a typical item size
        self.n = 0

    def update(self, item):
        self.n += 1
        # exponentially weighted estimate of typical (median-ish) item size
        self.med = 0.997 * self.med + 0.003 * float(item)
        if self.med < 12.0:
            self.med = 12.0


_state = _State()


def priority(item, bins):
    """Rank bins: prefer smallest nonnegative residual, but avoid unusable slivers."""
    _state.update(item)
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # post-placement residual per bin

    t = 0.5 * _state.med  # sliver threshold: residual below this is hard to reuse

    # Base: strongly prefer the tightest fit (smallest nonnegative residual).
    # Negative residual (item doesn't fit) must never be chosen: push it far down.
    base = -residual.copy()

    # Penalize slivers: when residual is tiny but positive, the leftover gap is
    # likely wasted. Add a penalty that grows as residual shrinks toward 0.
    # Fresh bins (residual large) and properly fitting residuals are unaffected.
    pen = np.zeros_like(residual)
    sliver = (residual > 0) & (residual < t)
    # smooth penalty: strongest near residual ~ 0, fading to 0 at residual = t
    pen[sliver] = (t - residual[sliver]) / t

    # non-fitting bins are impossible; guard anyway
    infeasible = residual < 0
    pen[infeasible] = 1e9

    score = base - 5.0 * pen
    return score
# EVOLVE-BLOCK-END
