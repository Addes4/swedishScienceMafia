# EVOLVE-BLOCK-START
"""Best fit enhanced with an exact-residual-match fast path driven by a recent-size histogram."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0    # running estimate of a "small" item size
        self.n = 0
        self.hist = {}       # decaying counts of small item sizes

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        # decaying histogram of small items (bounded memory)
        if item <= 40:
            self.hist[item] = self.hist.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.hist.keys()):
                    self.hist[k] //= 2
                    if self.hist[k] == 0:
                        del self.hist[k]

    def top_small(self, k):
        if not self.hist:
            return []
        return sorted(self.hist.keys(), key=lambda x: -self.hist[x])[:k]


_state = _State()


def priority(item, bins):
    """Prefer an exact residual match to a common small item; else best fit."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Fast path: a used bin whose residual exactly matches a common reusable gap.
    for m in _state.top_small(3):
        if m > 0:
            match = np.where((residual == m) & (bins < 100))[0]
            if match.size > 0:
                score = np.full(bins.shape, -1e9, dtype=np.float64)
                # among matches pick the fullest bin (smallest residual is fixed = m)
                score[match[0]] = 1.0
                return score

    thresh = 0.6 * _state.small  # residual below this is hard to reuse

    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    if best_res <= 0 or best_res >= thresh:
        score = -residual.astype(np.float64)
        return score

    usable = np.where((residual >= thresh) & (bins < 100))[0]
    if usable.size > 0:
        j = usable[np.argmin(residual[usable])]
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
