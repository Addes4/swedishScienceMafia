# EVOLVE-BLOCK-START
"""Best fit with a residual-match fast path driven by the recent item-size distribution."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.counts = {}   # recent counts of item sizes (all sizes)

    def update(self, item):
        self.n += 1
        self.counts[item] = self.counts.get(item, 0) + 1
        if self.n % 500 == 0:
            for k in list(self.counts.keys()):
                self.counts[k] //= 2
                if self.counts[k] == 0:
                    del self.counts[k]

    def score_residual(self, res):
        """How likely is it that a future item will fit exactly into residual 'res'."""
        if res <= 0 or res >= 100:
            return 0.0
        return float(self.counts.get(int(res), 0))


_state = _State()


def priority(item, bins):
    """Prefer bins whose post-placement residual matches a recently common item size."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item

    # best-fit candidate among bins the item fits into
    fits = np.where(bins >= item)[0]
    if fits.size == 0:
        return -residual.astype(np.float64)

    best = fits[np.argmin(residual[fits])]
    best_res = residual[best]

    # If the best-fit residual is itself a commonly-seen item size, take it.
    if best_res > 0 and _state.score_residual(best_res) > 0:
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[best] = 1.0
        return score

    # Otherwise look for a used bin whose residual matches a common size.
    if len(_state.counts) > 0:
        vals = np.array(list(_state.counts.keys()), dtype=np.int64)
        present = np.intersect1d(residual[fits], vals)
        if present.size > 0:
            # choose the most common such residual, smallest residual as tie-break
            best_r, best_c = None, -1
            for r in present:
                if r <= 0:
                    continue
                c = _state.counts.get(int(r), 0)
                if c > best_c or (c == best_c and (best_r is None or r < best_r)):
                    best_c, best_r = c, int(r)
            if best_r is not None:
                cand = fits[residual[fits] == best_r][0]
                score = np.full(bins.shape, -1e9, dtype=np.float64)
                score[cand] = 1.0
                return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
