# EVOLVE-BLOCK-START
"""Best fit with an adaptive exact-residual fast path keyed to a recency-weighted
histogram of small item sizes (multi-target instead of a single stale mode)."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0
        self.n = 0
        self.weights = {}   # size -> recency-decayed weight for small items

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        # recency-weighted histogram over small item sizes
        if item <= 40:
            self.weights[item] = self.weights.get(item, 0.0) + 1.0
        # periodic global decay so the histogram reflects recent arrivals
        if self.n % 200 == 0:
            for k in list(self.weights.keys()):
                self.weights[k] *= 0.85
                if self.weights[k] < 1e-3:
                    del self.weights[k]

    def targets(self):
        """Most likely upcoming small residual sizes, most probable first."""
        if not self.weights:
            return []
        items = sorted(self.weights.items(), key=lambda kv: -kv[1])
        return [k for k, _ in items[:8]]


_state = _State()


def priority(item, bins):
    """Prefer an existing used bin whose post-placement residual matches a likely
    future small item; otherwise best fit (minimize residual)."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item

    # Fast path: exact residual match against likely upcoming small sizes.
    if item <= 40:
        for t in _state.targets():
            match = np.where((residual == t) & (bins < 100))[0]
            if match.size > 0:
                score = np.full(bins.shape, -1e9, dtype=np.float64)
                score[match[0]] = 1.0
                return score

    score = -residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
