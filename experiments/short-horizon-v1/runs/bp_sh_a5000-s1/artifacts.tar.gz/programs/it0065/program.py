# EVOLVE-BLOCK-START
"""Best fit with a small-item reuse bonus driven by the recent size histogram."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.counts = {}    # recent counts of item sizes (bounded memory)

    def update(self, item):
        self.n += 1
        self.counts[item] = self.counts.get(item, 0) + 1
        if self.n % 1000 == 0:
            for k in list(self.counts.keys()):
                self.counts[k] = self.counts[k] // 2
                if self.counts[k] == 0:
                    del self.counts[k]

    def small_sizes(self):
        # return set of sizes <= ~30 that have been observed recently
        return set(k for k, v in self.counts.items() if k <= 30 and v >= 1)


_state = _State()


def priority(item, bins):
    """Best fit, with a bonus for a residual that matches a plausible next small item."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    score = -residual.astype(np.float64)

    # Bonus: residual matches a commonly seen small item -> reusable soon.
    small = _state.small_sizes()
    if small:
        common = np.array(sorted(small), dtype=np.int64)
        # For each bin, check if residual is in the common set.
        # Vectorized: since sets are small, do it via broadcasting.
        r = residual.reshape(-1, 1)
        c = common.reshape(1, -1)
        match = (r == c).any(axis=1)
        used = bins < 100
        score += np.where(match & used, 1.5, 0.0)

    return score
# EVOLVE-BLOCK-END
