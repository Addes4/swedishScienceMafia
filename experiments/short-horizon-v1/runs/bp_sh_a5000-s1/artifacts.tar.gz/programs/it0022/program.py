# EVOLVE-BLOCK-START
"""Randomized best-fit: sample among near-tightest fits to diversify packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest score.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # residual after placing the item: smaller is a tighter fit (better)
    resid = bins - item
    # base best-fit score
    score = -resid.astype(np.float64)
    # add small random jitter so ties/near-ties get broken diversely,
    # while keeping the tightest fit strongly favored.
    noise = np.random.random(bins.shape[0])
    return score + 0.5 * noise
# EVOLVE-BLOCK-END
