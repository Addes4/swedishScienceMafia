# EVOLVE-BLOCK-START
"""Best-fit with a dead-gap-aware residual penalty and perfect-fill preference."""
import numpy as np


class _State:
    def __init__(self):
        self.mean = 40.0     # running estimate of typical item size
        self.n = 0

    def update(self, item):
        self.n += 1
        self.mean = 0.99 * self.mean + 0.01 * float(item)
        if self.mean < 5.0:
            self.mean = 5.0


_state = _State()


def priority(item, bins):
    """Score bins: perfect fill first, then avoid dead gaps, then best fit."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = (bins - item).astype(np.float64)

    # Typical upcoming item size -> threshold below which a residual is a "dead gap".
    # A gap this small is unlikely to be reused by a future average-sized item.
    dead = 0.5 * _state.mean

    # Base: prefer smaller residual (best fit). Perfect fill (residual 0) is best.
    score = -residual

    # Penalize residuals that are nonzero but too small to fit a typical item soon.
    # This nudges the item away from leaving unusable slivers.
    small_positive = (residual > 0) & (residual < dead)
    score[small_positive] -= dead

    return score
# EVOLVE-BLOCK-END

