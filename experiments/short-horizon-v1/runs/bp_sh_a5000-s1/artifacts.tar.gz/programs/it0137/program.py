# EVOLVE-BLOCK-START
"""Best fit, with an exact-residual fast path for small items driven by frequent recent residuals."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.resid_counts = {}   # counts of small item sizes seen recently (candidate residuals)

    def update(self, item):
        self.n += 1
        if item <= 40:
            self.resid_counts[item] = self.resid_counts.get(item, 0) + 1
            if self.n % 400 == 0:
                for k in list(self.resid_counts.keys()):
                    self.resid_counts[k] = self.resid_counts[k] // 2
                    if self.resid_counts[k] == 0:
                        del self.resid_counts[k]

    def frequent_residuals(self, topn=4):
        if not self.resid_counts:
            return []
        items = sorted(self.resid_counts.items(), key=lambda kv: -kv[1])[:topn]
        return [k for k, v in items if v >= 2]


_state = _State()


def priority(item, bins):
    """Prefer an exact residual match to a frequent recent small size, else best fit."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Fast path: only for small arriving items, try to hit a frequent reusable hole.
    if item <= 40:
        freq = _state.frequent_residuals()
        if freq:
            used = bins < 100
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            found = False
            for f in freq:
                match = np.where((residual == f) & used)[0]
                if match.size > 0:
                    score[match[0]] = 1.0
                    found = True
                    break
            if found:
                return score

    # Fallback: best fit (smallest non-negative post-placement residual).
    score = -residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
