# EVOLVE-BLOCK-START
"""Best fit with a small consolidation bonus for already-used bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Base score: tightest fit -> residual after placement, smaller is better.
    residual = bins - item

    # Used bins have remaining capacity strictly less than 100.
    used = bins < 100

    # Consolidation bonus: nudge toward already-used bins so their gaps get reused,
    # scaled so it only matters for near-ties in residual size.
    score = -residual.astype(np.float64)
    score += used.astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
