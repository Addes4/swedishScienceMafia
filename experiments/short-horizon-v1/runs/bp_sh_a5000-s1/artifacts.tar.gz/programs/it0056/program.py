# EVOLVE-BLOCK-START
"""Smooth best-fit with a reusable-residual bonus based on a recent size histogram."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 20.0
        self.n = 0
        self.weights = None   # EWMA histogram over item sizes 1..100

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.99 * self.small + 0.01 * s
        if self.small < 3.0:
            self.small = 3.0
        w = self.weights
        if w is None:
            w = np.zeros(101, dtype=np.float64)
            self.weights = w
        w *= 0.99
        w[item] += 1.0


_state = _State()


def priority(item, bins):
    """Best-fit with an additive bonus for residuals that match frequent recent sizes."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item
    # Only bins that can hold the item contribute; others get a very low score.
    fits = residual >= 0
    score = -residual.astype(np.float64)

    if _state.n >= 50:
        w = _state.weights
        # bonus proportional to how often this exact residual size is seen (reusable)
        # and how small the item is (small items pair with residuals more usefully)
        resid_ok = fits & (residual <= 100) & (residual > 0)
        idx = residual[resid_ok].astype(np.int64)
        if idx.size:
            freq = w[idx] / (w.sum() + 1e-9)
            score[resid_ok] += 0.5 * freq

        # mild penalty for leaving a residual too small to be reused, but not zero
        guard = 0.5 * _state.small
        tiny = fits & (residual > 0) & (residual < guard)
        score[tiny] -= 1.0

    score[~fits] = -1e9
    return score
# EVOLVE-BLOCK-END

