# EVOLVE-BLOCK-START
"""Best fit with a tie-break that favors fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual => highest priority).
    # Secondary (tiny): prefer bins that are already fuller (smaller remaining capacity).
    return -(residual.astype(np.float64) + 1e-4 * bins.astype(np.float64))
# EVOLVE-BLOCK-END
