# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware bonus for residuals that recent items tend to fill."""
import numpy as np


class _State:
    def __init__(self):
        # running histogram of recent item sizes (1..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.n = 0
        self.counts = {}   # recent small item counts for mode

    def update(self, item):
        self.n += 1
        # exponential decay to emphasize recent items
        self.hist *= 0.995
        self.hist[item] += 1.0
        # mode of small items
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def mode_small(self):
        best_k, best_v = 0, 0
        for k, v in self.counts.items():
            if v > best_v:
                best_v, best_k = v, k
        return best_k

    def fill_prob(self, r):
        """Loose probability that a residual of size r will later be exactly fillable."""
        if r <= 0:
            return 0.0
        return float(self.hist[int(round(r))])


_state = _State()


def priority(item, bins):
    """Rank bins: best fit base, with a bounded bonus for reusable residuals."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Fast path: an existing used bin whose residual exactly matches a common small item.
    m = _state.mode_small()
    if m > 0:
        match = np.where((residual == m) & (bins < 100))[0]
        if match.size > 0:
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[match[0]] = 1.0
            return score

    n = self_n = _state.n
    total = max(_state.hist.sum(), 1.0)
    # reuse potential: prefer residuals that recent items are likely to fill exactly
    fill = np.array([_state.hist[int(r)] / total if r > 0 else 0.0
                     for r in np.round(residual)], dtype=np.float64)

    # dead-gap guard: residuals below a fraction of the modal small size are hard to reuse
    small = max(_state.mode_small(), 3)
    dead = (residual > 0) & (residual < 0.6 * small)

    score = -residual.astype(np.float64)
    # bounded soft bonus for reusable residuals
    score += 5.0 * fill
    # penalize dead gaps so best-fit avoids creating unusable leftovers
    score -= 20.0 * dead.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
