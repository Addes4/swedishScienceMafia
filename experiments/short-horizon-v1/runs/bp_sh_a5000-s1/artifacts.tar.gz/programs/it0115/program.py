# EVOLVE-BLOCK-START
"""Best fit with a residual-reusability tie-breaker for dead-space avoidance."""
import numpy as np


class _State:
    def __init__(self):
        self.mean_item = 40.0   # running estimate of the mean item size
        self.n = 0

    def update(self, item):
        self.n += 1
        a = 1.0 / min(self.n, 200.0)
        self.mean_item = (1.0 - a) * self.mean_item + a * float(item)


_state = _State()


def priority(item, bins):
    """Rank bins: primary best fit (smallest residual); tie-break toward reusable holes."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Smallest residual favors tightest fit (best fit).
    # Among bins with equal residual, prefer the one whose residual is closer to the
    # typical item size, since that hole is more likely to be refilled exactly.
    target = _state.mean_item
    tiebreak = -np.abs(residual - target)

    # Combine: primary term dominates, tie-break only breaks near-ties.
    score = -residual.astype(np.float64) * 1000.0 + tiebreak
    return score
# EVOLVE-BLOCK-END
