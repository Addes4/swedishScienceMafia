# EVOLVE-BLOCK-START
"""Best-fit with a soft reusable-residual preference driven by the recent small-item scale."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0


_state = _State()


def priority(item, bins):
    """Rank bins: favor best fit, with a mild bonus for a reusable (small) post-placement residual."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = (bins - item).astype(np.float64)

    # Base: best fit (smallest non-negative residual preferred).
    # Separate exact-fit / used-bin behavior from creating a fresh bin.
    score = -residual

    # Mild bonus when the leftover residual is a plausible future small item:
    # the closer the residual is to the running small-item scale, the more reusable.
    small = _state.small
    # only reward actually-used bins (bins < 100); fresh bins have residual large and unused.
    used = bins < 100
    closeness = np.abs(residual - small)
    bonus = np.where(used, 1.0 / (1.0 + closeness), 0.0)
    score = score + 0.5 * bonus

    return score
# EVOLVE-BLOCK-END
