# EVOLVE-BLOCK-START
"""Best fit that avoids stranding tiny unusable residuals (dead gaps)."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a reusable "small" residual
        self.n = 0

    def update(self, item):
        self.n += 1
        # track a lower-ish percentile of item sizes as the reusable threshold
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0


_state = _State()


def priority(item, bins):
    """Prefer tightest fit, but skip bins that would strand a dead gap."""
    _state.update(item)
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # post-placement residual per bin

    thresh = 0.5 * _state.small  # residuals below this are hard to reuse

    # Tightest fit overall.
    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    # If the tightest fit leaves a reusable or zero residual, take it.
    if best_res <= 0 or best_res >= thresh:
        return -residual

    # Otherwise, look for the smallest residual that is reusable.
    usable = np.where(residual >= thresh)[0]
    if usable.size > 0:
        j = usable[np.argmin(residual[usable])]
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual
# EVOLVE-BLOCK-END
