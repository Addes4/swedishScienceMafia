# EVOLVE-BLOCK-START
"""Best fit augmented with a safe perfect-fill path and a soft dead-gap guard."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0
        self.counts = {}    # recent counts of small item sizes (for mode)

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def mode_small(self):
        best_k, best_v = 0, 0
        for k, v in self.counts.items():
            if v > best_v:
                best_v, best_k = v, k
        return best_k


_state = _State()


def priority(item, bins):
    """Return a priority per bin: perfect fill first, otherwise best fit with a soft gap guard."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Safe fast path: an exact perfect fill (only used bins, residual 0).
    perfect = np.where((residual == 0) & (bins < 100))[0]
    if perfect.size > 0:
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[perfect[0]] = 1.0
        return score

    # Base score: best fit (smaller residual is better).
    score = -residual.astype(np.float64)

    # Soft guard: give a tiny bounded bonus to residuals that exactly match the
    # modal small item, so a leftover can likely be filled later, without forcing
    # large jumps away from best fit.
    m = _state.mode_small()
    if m > 0:
        match = (residual == m) & (bins < 100)
        score = score + 0.5 * match.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
