# EVOLVE-BLOCK-START
"""Best fit with a dead-gap guard and a light periodic fresh-bin preference."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0


_state = _State()


def priority(item, bins):
    """Best fit base, with a bonus for exact fits and an occasional fresh-bin choice."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Base: best fit (prefer smallest post-placement residual, i.e. tightest fit).
    score = -residual.astype(np.float64)

    # Strong bonus for exact fit (residual 0): perfectly fills the bin.
    score += 5.0 * (residual == 0)

    # Dead-gap guard: a used bin left with a residual too small to reuse is a
    # stranded sliver; when it would also force that residual, demote slightly.
    thresh = 0.6 * _state.small
    used = bins < 100
    dead = used & (residual > 0) & (residual < thresh)
    score -= 0.5 * dead

    # Light periodic preference for opening a fresh bin, to avoid piling many
    # tiny residuals into already-used bins. Rare enough to keep best fit dominant.
    if _state.n % 7 == 0:
        score += 0.25 * (bins == 100)

    return score
# EVOLVE-BLOCK-END
