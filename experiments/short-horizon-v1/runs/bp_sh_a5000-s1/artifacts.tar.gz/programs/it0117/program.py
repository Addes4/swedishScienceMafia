# EVOLVE-BLOCK-START
"""Best fit with an exact-residual-match fast path and a conservative gap guard."""
import numpy as np


class _State:
    def __init__(self):
        self.min_item = 100  # running minimum item size seen
        self.n = 0
        self.counts = {}     # recent counts of small item sizes (for mode)

    def update(self, item):
        self.n += 1
        if item < self.min_item:
            self.min_item = item
        # track mode of small item sizes seen recently (bounded memory)
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                # decay counts to keep it "recent"
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def mode_small(self):
        best_k, best_v = 0, 0
        for k, v in self.counts.items():
            if v > best_v:
                best_v, best_k = v, k
        return best_k


_state = _State()


def priority(item, bins):
    """Return a priority per bin: prefer an exact residual match, else best fit with a guard."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Fast path: an existing used bin whose residual exactly matches a common small item.
    m = _state.mode_small()
    if m > 0:
        match = np.where((residual == m) & (bins < 100))[0]
        if match.size > 0:
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[match[0]] = 1.0
            return score

    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    # Only guard against residuals that are smaller than any item ever seen
    # (truly unusable dead space), and only when a better usable bin exists.
    thresh = max(1, _state.min_item - 1)

    if best_res <= 0 or best_res >= thresh:
        score = -residual.astype(np.float64)
        return score

    usable = np.where((residual >= thresh) & (bins < 100))[0]
    if usable.size > 0:
        j = usable[np.argmin(residual[usable])]
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

