# EVOLVE-BLOCK-START
"""Best fit with a reusable-hole priority driven by recently-seen small residuals."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0
        self.counts = {}    # recent counts of small item sizes

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def small_sizes(self):
        """Return the set of small item sizes seen recently (well-represented)."""
        if not self.counts:
            return ()
        mx = max(self.counts.values())
        # keep sizes with at least a modest share of the max count
        floor = max(1, mx // 8)
        return tuple(k for k, v in self.counts.items() if v >= floor)


_state = _State()


def priority(item, bins):
    """Prefer a bin whose post-placement residual matches a common small item."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = (bins - item).astype(np.float64)

    sizes = _state.small_sizes()
    if sizes:
        sizes_arr = np.array(sizes, dtype=np.float64)
        # distance from each residual to the nearest recent small item size
        d = np.abs(residual[:, None] - sizes_arr[None, :]).min(axis=1)
        # only used bins, and only residuals of value >= 0
        used = bins < 100
        cand = np.where(used & (residual >= 0))[0]
        if cand.size > 0:
            dmin = d[cand].min()
            # window: match tightly enough to be meaningful
            if dmin <= 2.0:
                winners = cand[d[cand] == dmin]
                # among winners pick the largest residual (least waste-to-create)
                j = winners[np.argmax(residual[winners])]
                score = np.full(bins.shape, -1e9, dtype=np.float64)
                score[j] = 1.0
                return score

    # strict best-fit fallback
    return -residual
# EVOLVE-BLOCK-END

