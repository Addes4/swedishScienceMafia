# EVOLVE-BLOCK-START
"""Strict best fit: minimize post-placement residual; among ties prefer used bins."""
import numpy as np


def priority(item, bins):
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual (>=0 for fitting bins)

    # Best fit: smallest residual wins. Ties go to earlier index automatically,
    # which corresponds to used bins being earlier in stream order.
    # Exact matches (residual == 0) are ideal; smallest positive next.
    score = -residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
