# EVOLVE-BLOCK-START
"""Best fit with a large-item reservation heuristic.

Small items are packed tight (classic best fit). Large items avoid being shoved
into bins that would then be left with an unusable sliver, so they prefer the
bin whose residual after placement is largest among those leaving a residual at
or above a running threshold derived from seen item sizes.
"""
import numpy as np


def priority(item, bins):
    # Track a running mean item size (per-stream state kept on the function).
    state = priority.state
    n = state[0] + 1
    mean = state[1]
    new_mean = mean + (item - mean) / n
    state[0] = n
    state[1] = new_mean

    # Threshold: a residual is "usable" only if it can plausibly hold a
    # future item. Use a fraction of the running mean as the bar.
    thresh = 0.5 * new_mean

    # Remainder after placing this item.
    resid = bins - item

    if item >= new_mean:
        # Large item: prefer bins leaving a decent reusable residual.
        reusable = resid >= thresh
        if np.any(reusable):
            # Among reusable outcomes, take the tightest fit (smallest residual).
            score = np.where(reusable, -resid.astype(float), -1e9)
            return score
        # Otherwise fall back to tightest fit overall.
        return -resid

    # Small item: classic best fit.
    return -resid


priority.state = [0, 40.0]
# EVOLVE-BLOCK-END
