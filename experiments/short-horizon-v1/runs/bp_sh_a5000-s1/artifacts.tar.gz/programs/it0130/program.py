# EVOLVE-BLOCK-START
"""Best fit with a recent-set exact-residual fast path."""
import numpy as np


class _State:
    def __init__(self):
        # Recent occurrence counts of item sizes (for exact-hole matching).
        self.counts = {}
        self.n = 0

    def update(self, item):
        self.n += 1
        self.counts[item] = self.counts.get(item, 0) + 1
        # periodic decay keeps the set "recent"
        if self.n % 400 == 0:
            for k in list(self.counts.keys()):
                self.counts[k] = self.counts[k] // 2
                if self.counts[k] == 0:
                    del self.counts[k]


_state = _State()


def priority(item, bins):
    """Prefer an exact residual match against a recently seen item size, else best fit."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Fast path: pick a used bin whose residual exactly matches a recent item size.
    # Among such candidates, choose the one with the most frequent matching size
    # (fall back to smallest residual).
    best_idx = -1
    best_freq = -1
    best_res = None
    for idx in range(bins.shape[0]):
        r = int(residual[idx])
        if bins[idx] < 100 and r > 0:
            f = _state.counts.get(r, 0)
            if f > 0:
                if f > best_freq or (f == best_freq and (best_res is None or r < best_res)):
                    best_freq = f
                    best_idx = idx
                    best_res = r

    if best_idx >= 0:
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[best_idx] = 1.0
        return score

    # Fallback: strict best fit (smallest non-negative residual).
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

