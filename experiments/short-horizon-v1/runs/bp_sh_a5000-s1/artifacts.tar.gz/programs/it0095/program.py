# EVOLVE-BLOCK-START
"""Best fit with a gated exact-residual-match fast path driven by recent small items."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0
        self.counts = {}    # recent counts of small item sizes (for mode)

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def mode_small(self):
        best_k, best_v = 0, 0
        for k, v in self.counts.items():
            if v > best_v:
                best_v, best_k = v, k
        return best_k


_state = _State()


def priority(item, bins):
    """Return a priority per bin: prefer a gated exact residual match, else best fit."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Best-fit candidate (used both as fallback and as the reference to gate on).
    used = bins < 100
    resid_used = np.where(used, residual, np.iinfo(np.int64).max)
    best = int(np.argmin(resid_used))
    best_res = residual[best]

    # Gated exact-match fast path: an existing bin whose residual exactly matches a
    # common small item, but only when it does not cost too much versus best-fit.
    m = _state.mode_small()
    if m > 0:
        match = np.where((residual == m) & used)[0]
        if match.size > 0:
            j = int(match[0])
            # Only divert if the matched bin's current "waste" (post-residual) is no
            # worse than leaving too-small a gap in the best-fit bin.
            if m <= best_res or best_res < 3:
                score = np.full(bins.shape, -1e9, dtype=np.float64)
                score[j] = 1.0
                return score

    thresh = 0.6 * _state.small  # residual below this is hard to reuse

    if best_res <= 0 or best_res >= thresh:
        score = -residual.astype(np.float64)
        # unused bins should not be preferred over used best-fit when residual huge
        return score

    usable = np.where((residual >= thresh) & used)[0]
    if usable.size > 0:
        j = int(usable[np.argmin(residual[usable])])
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
