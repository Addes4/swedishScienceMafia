# EVOLVE-BLOCK-START
"""Best fit augmented with a distribution-aware reusable-residual bonus."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        # histogram over small item sizes (1..40); index 0 unused
        self.hist = np.zeros(41, dtype=np.float64)

    def update(self, item):
        self.n += 1
        if item <= 40:
            self.hist[item] += 1.0
        # periodic decay to keep the estimate "recent" and bounded
        if self.n % 1000 == 0:
            self.hist *= 0.5

    def prob(self):
        # normalized probability that the next item has residual size r
        tot = self.hist.sum()
        if tot <= 0:
            return np.zeros(41, dtype=np.float64)
        p = self.hist / tot
        # desired residual r lies in 1..40; map to bonus value
        return p


_state = _State()


def priority(item, bins):
    bins = np.asarray(bins)
    _state.update(item)

    residual = (bins - item).astype(np.float64)

    # base: best fit (most negative residual = fullest bin that still fits)
    score = -residual

    # distribution-aware bonus: reward residuals that equal a likely future item size
    p = _state.prob()
    prob_lookup = np.zeros(101, dtype=np.float64)
    prob_lookup[1:41] = p[1:41]

    r = residual.astype(np.int64)
    valid = (r >= 1) & (r <= 40)
    if valid.any():
        bonus = np.zeros_like(residual)
        bonus[valid] = prob_lookup[r[valid]] * 30.0
        score = score + bonus

    return score
# EVOLVE-BLOCK-END
