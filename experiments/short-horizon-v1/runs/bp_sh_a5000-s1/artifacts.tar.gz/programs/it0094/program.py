# EVOLVE-BLOCK-START
"""Best fit with a soft, bounded preference for reusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority per bin: best fit, with a tiny bonus for reusable leftovers."""
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Base score: best fit (most negative residual = tightest packing).
    score = -residual.astype(np.float64)

    # Small bonus when the leftover is exactly 0 (perfect fill) — never forces a jump,
    # only breaks near-ties in favor of perfectly filled bins.
    score[residual == 0] += 0.5

    return score
# EVOLVE-BLOCK-END
