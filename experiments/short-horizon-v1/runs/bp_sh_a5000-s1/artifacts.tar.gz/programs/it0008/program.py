# EVOLVE-BLOCK-START
"""Modified best fit: prefer tightest fit among used bins; only open a new bin when no
used bin can absorb the item without leaving a very large residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins)
    # Base: tightest fit first (smallest residual after placing).
    score = -(bins - item).astype(np.float64)

    # Penalize opening a brand-new bin (residual == 100) unless it's clearly needed.
    # A new bin is only attractive if no used bin keeps the leftover under `keep`.
    full = bins >= 100  # unused bins
    # We want: if any used bin exists with residual reasonably tight, prefer it.
    # Add a penalty to unused bins proportional to how large the item is,
    # so small items don't waste a fresh bin.
    score = score - full.astype(np.float64) * (item * 0.5)
    return score
# EVOLVE-BLOCK-END

