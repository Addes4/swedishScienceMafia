# EVOLVE-BLOCK-START
"""Best fit with a smooth residual-utility ranking driven by running item statistics."""
import numpy as np


class _State:
    def __init__(self):
        self.mean = 40.0
        self.small = 8.0
        self.n = 0

    def update(self, item):
        self.n += 1
        a = 2.0 / (self.n + 1.0)
        if a > 0.05:
            a = 0.05
        self.mean = (1 - a) * self.mean + a * float(item)
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0


_state = _State()


def priority(item, bins):
    """Smooth score: prefer tight fits, but penalize un-reusable residuals."""
    _state.update(item)
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # post-placement residual per bin

    # Base preference: strongly prefer smallest nonnegative residual (best fit).
    score = -residual

    # Penalty for residuals that are small but not zero (hard to reuse),
    # scaled by how small relative to the running small-item estimate.
    s = _state.small
    tiny = (residual > 1e-9) & (residual < s)
    score = np.where(tiny, score - 0.5 * (s - residual), score)

    # Slight bonus for leaving a residual close to nothing (exact fill).
    return score.astype(np.float64)
# EVOLVE-BLOCK-END
