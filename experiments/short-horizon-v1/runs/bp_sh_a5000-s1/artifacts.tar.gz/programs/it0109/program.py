# EVOLVE-BLOCK-START
"""Nearest-fit on residual-to-typical-item, with a dead-space guard."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0


_state = _State()


def priority(item, bins):
    """Rank bins: penalize residual, but strongly reward residuals close to a typical item."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    target = _state.small          # typical size of a small arriving item
    thresh = 0.5 * target          # residual below this is likely dead space

    score = -residual.astype(np.float64)

    # Strongly reward residual that closely matches a likely future item size,
    # which makes the leftover hole reusable.
    match = (residual > 0) & (residual < 100)
    closeness = np.abs(residual.astype(np.float64) - target)
    reuse_bonus = np.where(match, 60.0 / (1.0 + closeness), 0.0)
    score = score + reuse_bonus

    # Penalize leaving a too-small (dead) residual in a used bin.
    dead = (residual > 0) & (residual < thresh) & (bins < 100)
    score = np.where(dead, score - 40.0, score)

    return score
# EVOLVE-BLOCK-END
