# EVOLVE-BLOCK-START
"""Worst-fit-with-cap hybrid: prefer tightest fit that still leaves a usable gap."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # capacity left after placement (>=0 for fitting bins)
    # A gap is "usable" if it can still hold a reasonably small future item.
    # Use a modest threshold; below it the residual is effectively wasted.
    threshold = 8
    usable = residual >= threshold
    # Base score: tightest fit -> smallest residual gets highest score.
    score = -residual.astype(np.float64)
    # Among usable bins, prefer the fullest (smallest usable residual) too, which is
    # already captured by -residual. Bins that would leave an unusable tiny gap get a
    # penalty so they are only chosen when nothing better exists.
    score = np.where(usable, score, score - 1e6)
    return score
# EVOLVE-BLOCK-END
