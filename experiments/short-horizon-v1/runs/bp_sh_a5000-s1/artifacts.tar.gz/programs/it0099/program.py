# EVOLVE-BLOCK-START
"""Adaptive best fit: prefer residuals matching the recent item-size mix, softly."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        # running histogram of item sizes 1..100 (recency-weighted)
        self.hist = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.n += 1
        if self.n % 1000 == 0:
            self.hist *= 0.5
        self.hist[item] += 1.0

    def fill_prob(self):
        """Return prob array prob[r] = fraction of recent items of size r (0..100)."""
        total = self.hist.sum()
        if total <= 0:
            return np.zeros(101, dtype=np.float64)
        return self.hist / total


_state = _State()


def priority(item, bins):
    """Rank bins by best fit, softly rewarding residuals that recent items can fill."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    p = _state.fill_prob()

    # Base score: best fit (smaller residual preferred).
    score = -residual.astype(np.float64)

    # Soft bonus: value of the leftover according to recent item-size mix.
    # residual clipped to [0,100] index into prob.
    idx = np.clip(residual, 0, 100).astype(np.int64)
    bonus = p[idx]
    # Only reward usable leftovers (residual >= smallest common item => p>0 region)
    # Scale bounded so it never overwhelms best-fit ordering.
    score += 5.0 * bonus

    return score
# EVOLVE-BLOCK-END
