# EVOLVE-BLOCK-START
"""Best fit with a soft hole-filling bonus for residuals that look like usable small items."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0

    def update(self, item):
        self.n += 1


_state = _State()


def priority(item, bins):
    """Best fit, plus a smooth bonus when the residual lands near a typical small item size."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = (bins - item).astype(np.float64)

    # Primary: best fit (smallest non-negative residual).
    score = -residual

    # Soft hole-filling bonus: residuals in [1, 40] are potentially reusable.
    # Reward mid-range holes (roughly matching a small item) more than tiny strands.
    hole = residual >= 1.0
    # Gaussian-like bump centered around 10 (typical small item), width ~10.
    bonus = np.where(hole, np.exp(-((residual - 10.0) / 12.0) ** 2), 0.0)
    score = score + 0.5 * bonus

    # Strongly prefer using existing bins over opening a fresh full bin only when
    # the residual is reasonably large; keep best-fit otherwise.
    score = np.where(bins >= 100, score, score)

    return score
# EVOLVE-BLOCK-END


