# EVOLVE-BLOCK-START
"""Best fit with a consolidation tie-break among equal residuals."""
import numpy as np


def priority(item, bins):
    """Prefer the smallest post-placement residual; break ties by consolidating
    partial bins (smaller pre-placement remaining capacity) so that holes stay
    large and reusable."""
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Primary: minimize residual. Secondary: prefer more-filled bins (smaller bins).
    # Combine into a single lexicographic-style key using integer weights that
    # keep the primary term dominant.
    key = residual.astype(np.int64) * 1024 + bins.astype(np.int64)
    best = int(np.argmin(key))
    score = np.full(bins.shape, -1e9, dtype=np.float64)
    score[best] = 1.0
    return score
# EVOLVE-BLOCK-END
