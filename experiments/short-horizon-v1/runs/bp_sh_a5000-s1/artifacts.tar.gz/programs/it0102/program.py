# EVOLVE-BLOCK-START
"""Best fit with a bounded perfect-fill / dead-gap guard, no forced jumps."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0


_state = _State()


def priority(item, bins):
    """Rank by best fit (min residual); give a bounded bonus to bins that end up
    perfectly full or leave a residual too small to reuse (avoiding dead gaps)."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = (bins - item).astype(np.float64)

    # Base: prefer smallest non-negative residual (best fit).
    score = -residual

    thresh = 0.6 * _state.small  # residual below this is hard to reuse
    # Strong but bounded bonus for near-perfect fills / dead-gap-avoiding choices.
    dead = (residual >= 0) & (residual < thresh)
    if np.any(dead):
        # Add a bonus large enough to dominate residual differences but bounded
        # so it never causes a big jump to a much worse (larger residual) bin.
        bonus = np.where(dead, (thresh - residual), 0.0)
        score = score + bonus.astype(np.float64)

    return score
# EVOLVE-BLOCK-END


