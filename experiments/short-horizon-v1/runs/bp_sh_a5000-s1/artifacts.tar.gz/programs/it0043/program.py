# EVOLVE-BLOCK-START
"""Best fit with a sum-of-squares tilt on the residual to tighten packing."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0

    def update(self, item):
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0


_state = _State()


def priority(item, bins):
    """Rank bins: strongly prefer small nonnegative residual (tight fit)."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item
    thresh = 0.6 * _state.small

    # Bins that fit the item (residual >= 0). Strongly prefer tighter fits.
    fits = residual >= 0
    # Score: higher for smaller residual. Squared tilt tightens packing.
    # Add a mild penalty for leaving a residual below thresh (hard to reuse).
    score = np.full(bins.shape, -1e9, dtype=np.float64)
    if np.any(fits):
        r = residual[fits]
        s = 1.0 / (1.0 + r * r)
        # penalize residuals in the "dead zone" (0, thresh)
        dead = (r > 0) & (r < thresh)
        s = np.where(dead, s * 0.5, s)
        score[fits] = s
    return score
# EVOLVE-BLOCK-END
