# EVOLVE-BLOCK-START
"""Best fit plus a continuous exact-hole bonus based on recently observed item sizes."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0
        self.counts = {}    # recent counts of item sizes (for residual-value weighting)
        self.total = 0

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        # track recent frequency of item sizes (bounded memory, periodic decay)
        key = int(item)
        self.counts[key] = self.counts.get(key, 0) + 1
        self.total += 1
        if self.n % 500 == 0:
            for k in list(self.counts.keys()):
                self.counts[k] //= 2
                if self.counts[k] == 0:
                    del self.counts[k]
            self.total = sum(self.counts.values()) + 1

    def freq(self, residuals):
        """Relative frequency of each residual value among recent item sizes."""
        if self.total <= 0:
            return np.zeros(residuals.shape, dtype=np.float64)
        out = np.zeros(residuals.shape, dtype=np.float64)
        for k, v in self.counts.items():
            if k <= 0:
                continue
            out += np.where(residuals == k, v / self.total, 0.0)
        return out


_state = _State()


def priority(item, bins):
    """Best fit, with a bonus when the post-placement residual matches a common recent item size."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    score = -residual.astype(np.float64)
    # Bonus for bins whose residual equals a recently frequent item size:
    # such holes are likely to be filled exactly by a future item.
    bonus = _state.freq(residual)
    score += 2.0 * bonus
    return score
# EVOLVE-BLOCK-END

