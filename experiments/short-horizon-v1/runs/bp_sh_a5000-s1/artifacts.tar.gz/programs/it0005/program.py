# EVOLVE-BLOCK-START
"""Best fit with a mild harmonic-fit-style residual preference."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    # Update running mean of item sizes seen.
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    # Target residual after placement: a small fraction of the mean item size.
    # Leaving a small reusable gap tends to keep bins packable.
    target = 0.15 * mean

    residual = bins - item  # remaining capacity if placed here
    # Best fit: prefer small residual. Add mild preference for residual near target
    # (so we don't pack a bin so tight that its leftover is unusable, nor leave
    # a big residual that wastes the bin). Unused bins (residual == 100 - item) are
    # naturally handled since their residual is large.
    return -(residual) - 0.05 * np.abs(residual - target)
# EVOLVE-BLOCK-END
