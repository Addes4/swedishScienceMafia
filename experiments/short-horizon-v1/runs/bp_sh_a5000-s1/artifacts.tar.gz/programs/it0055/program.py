# EVOLVE-BLOCK-START
"""Best fit with an exact-residual-match fast path and a soft reusability bias."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0
        self.counts = {}    # recent counts of small item sizes (for mode)

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def mode_small(self):
        best_k, best_v = 0, 0
        for k, v in self.counts.items():
            if v > best_v:
                best_v, best_k = v, k
        return best_k


_state = _State()


def priority(item, bins):
    """Prefer an exact residual match; otherwise tight fit with a soft reusability bias."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Fast path: an existing used bin whose residual exactly matches a common small item.
    m = _state.mode_small()
    if m > 0:
        match = np.where((residual == m) & (bins < 100))[0]
        if match.size > 0:
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[match[0]] = 1.0
            return score

    # Soft best fit: smaller residual is better, but avoid leaving a residual that is
    # below the typical small item size (hard to reuse). Penalize gently so a
    # much tighter fit still wins over a barely-usable one.
    small = _state.small
    r = residual.astype(np.float64)
    # penalty for residuals in (0, small): the closer to zero-but-positive, the worse.
    tiny = (r > 0) & (r < small)
    pen = np.where(tiny, (small - r) * 0.5, 0.0)
    score = -(r + pen)
    # fully-filled or negative residuals (shouldn't happen since bins are filtered) get baseline.
    return score
# EVOLVE-BLOCK-END

