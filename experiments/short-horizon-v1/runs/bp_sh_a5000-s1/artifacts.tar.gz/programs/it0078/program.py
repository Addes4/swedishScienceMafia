# EVOLVE-BLOCK-START
"""Best fit with an exact-residual-match fast path over the top common small sizes."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0
        self.n = 0
        self.counts = {}   # counts of small item sizes (recent, decayed)

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 60:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def common_sizes(self, k=3):
        # most frequent recent small sizes, as a set
        items = sorted(self.counts.items(), key=lambda kv: -kv[1])
        return set(s for s, _ in items[:k])


_state = _State()


def priority(item, bins):
    """Prefer a used bin whose residual exactly equals a common reusable size."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    common = _state.common_sizes(3)
    if common:
        best_res = np.min(residual)
        cand = None
        cand_res = None
        for s in common:
            if s <= best_res:
                continue  # not better than plain best-fit
            idx = np.where((residual == s) & (bins < 100))[0]
            if idx.size > 0:
                if cand_res is None or s < cand_res:
                    cand_res = s
                    cand = idx[0]
        if cand is not None:
            score = np.full(bins.shape, -1e9, dtype=np.float64)
            score[cand] = 1.0
            return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

