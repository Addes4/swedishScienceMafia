# EVOLVE-BLOCK-START
"""Best fit with a smooth residual-quality penalty driven by a running item-size estimate."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0   # running estimate of a "small" item size
        self.n = 0

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0


_state = _State()


def priority(item, bins):
    """Rank bins by post-placement residual, with a smooth penalty for tiny residuals."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin
    thresh = 0.6 * _state.small

    # Base: prefer smallest nonnegative residual (best fit). residual==0 is ideal.
    score = -residual.astype(np.float64)

    # Smooth penalty: residuals in (0, thresh) are "hard to reuse" -> push them below
    # residuals at/above thresh and below perfect fits. Use a gentle ramp so that
    # near-boundary choices avoid over-committing.
    mask = (residual > 0) & (residual < thresh)
    if np.any(mask):
        # penalty grows as residual shrinks toward 0; cap so it stays bounded
        r = residual[mask]
        pen = (thresh - r) / max(thresh, 1e-9)  # in (0,1)
        score[mask] -= pen * max(_state.small, 1.0)

    return score
# EVOLVE-BLOCK-END

