# EVOLVE-BLOCK-START
"""Best fit with a reusable-residual bonus targeting the running mean item size."""
import numpy as np


class _State:
    def __init__(self):
        self.mean = 40.0
        self.n = 0

    def update(self, item):
        self.n += 1
        # slow EWMA of the item mean, clamped to a sane range
        self.mean = 0.995 * self.mean + 0.005 * float(item)
        if self.mean < 5.0:
            self.mean = 5.0
        elif self.mean > 60.0:
            self.mean = 60.0


_state = _State()


def priority(item, bins):
    """Score = -residual plus a bonus for residuals near the typical item size."""
    _state.update(item)
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item

    # Base: best fit (smallest non-negative residual first).
    score = -residual

    # Bonus: post-placement residual close to the running mean item size is
    # likely to be filled exactly by a future item, so it is more valuable
    # than a slightly smaller residual that will become long-term waste.
    target = _state.mean
    bonus = 0.02 * np.exp(-np.abs(residual - target) / target)
    score = score + bonus

    # Strongly penalize overfill (shouldn't happen; harness shows fitting bins).
    score = np.where(residual < 0, -1e9, score)
    return score
# EVOLVE-BLOCK-END
