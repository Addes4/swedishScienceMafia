# EVOLVE-BLOCK-START
"""Best fit with a tie-break toward the fullest bin among near-minimal residuals."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0

    def update(self, item):
        self.n += 1


_state = _State()


def priority(item, bins):
    """Rank bins: minimize residual, breaking ties toward the most-full bin.

    Bins are only shown when the item fits, so residual = remaining - item >= 0.
    We prefer the smallest residual (best fit), and among bins whose residual is
    within a small band of the minimum, we prefer the one with the smallest
    remaining capacity (fullest bin) to consolidate load and keep large empty
    bins free for future large items.
    """
    _state.update(item)
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item

    min_res = residual.min()
    # Band: allow slightly larger residuals in exchange for a fuller bin.
    band = min_res + 0.01

    candidate = residual <= band
    # Among near-best residuals, prefer fullest bin (smallest remaining capacity).
    # Score higher = better; primary key is residual, secondary is fullness.
    score = np.where(candidate, 1e9 - bins, -residual)
    return score
# EVOLVE-BLOCK-END
