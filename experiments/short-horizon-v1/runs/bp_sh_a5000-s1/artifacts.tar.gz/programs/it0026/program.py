# EVOLVE-BLOCK-START
"""Best fit with tie-breaking toward less-full bins to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (item fits where bins >= item).
    """
    residual = bins - item  # >= 0 for all shown bins
    # Primary: smaller residual is better (tightest fit).
    # Tie-break: among near-equal residuals, prefer the less-full bin (larger bins),
    # which tends to keep gaps more reusable later.
    return -(residual.astype(np.float64)) + 1e-3 * bins.astype(np.float64)
# EVOLVE-BLOCK-END

