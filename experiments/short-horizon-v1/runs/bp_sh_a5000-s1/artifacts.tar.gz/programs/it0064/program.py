# EVOLVE-BLOCK-START
"""Best-fit with a residual-quality penalty that avoids stranding small residuals."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0        # running estimate of item mean
        self.small = 10.0       # running estimate of typical small residual

    def update(self, item):
        self.n += 1
        a = max(1.0 / min(self.n, 500.0), 0.002)
        self.mean = (1.0 - a) * self.mean + a * float(item)
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0


_state = _State()


def priority(item, bins):
    """Best fit, with a penalty for residuals that strand usable space."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = (bins - item).astype(np.float64)

    # Base: prefer smallest non-negative residual (best fit).
    score = -residual

    # Penalize residuals that fall below the typical item size (hard to reuse),
    # but only among non-negative residuals, scaled smoothly.
    m = _state.mean
    gap = np.where((residual >= 0) & (residual < m),
                   (m - residual) / max(m, 1.0), 0.0)
    score = score - 0.5 * gap * m

    return score
# EVOLVE-BLOCK-END
