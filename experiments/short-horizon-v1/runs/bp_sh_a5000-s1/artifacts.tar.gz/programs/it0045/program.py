# EVOLVE-BLOCK-START
"""Best fit with a tie-break toward fuller bins to reduce fragmentation."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0

    def update(self, item):
        self.n += 1


_state = _State()


def priority(item, bins):
    """Rank bins: prefer the smallest nonnegative post-placement residual,
    breaking near-ties toward the bin with the smallest remaining capacity."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Bins that fit (residual >= 0). Unused/fresh bins have bin cap 100.
    score = -residual.astype(np.float64)

    # Among bins that fit, a tiny penalty on large remaining capacity breaks
    # near-ties toward fuller bins without overriding the best fit.
    fit = residual >= 0
    if np.any(fit):
        score = score - 1e-3 * bins.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
