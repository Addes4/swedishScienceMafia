# EVOLVE-BLOCK-START
"""Best fit: place the item in the bin with the smallest post-placement residual."""
import numpy as np


def priority(item, bins):
    """Return a priority per bin: highest score = smallest post-placement residual."""
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
