# EVOLVE-BLOCK-START
"""Best fit with a probabilistic exact-residual-match fast path."""
import numpy as np


class _State:
    def __init__(self):
        self.small = 10.0      # running estimate of a "small" item size
        self.n = 0
        self.counts = {}       # recency-weighted counts of small item sizes

    def update(self, item):
        self.n += 1
        s = float(min(item, 40))
        self.small = 0.98 * self.small + 0.02 * s
        if self.small < 3.0:
            self.small = 3.0
        if item <= 40:
            self.counts[item] = self.counts.get(item, 0) + 1
            if self.n % 500 == 0:
                for k in list(self.counts.keys()):
                    self.counts[k] = self.counts[k] // 2
                    if self.counts[k] == 0:
                        del self.counts[k]

    def best_match(self, target_list):
        """Pick the most probable small-item size among the given residuals."""
        best_k, best_v = 0, 0
        for k in target_list:
            v = self.counts.get(k, 0)
            if v > best_v:
                best_v, best_k = v, k
        return best_k, best_v


_state = _State()


def priority(item, bins):
    """Prefer the exact residual whose size is the most likely future item; else best fit with guard."""
    _state.update(item)
    bins = np.asarray(bins)
    residual = bins - item  # post-placement residual per bin

    # Fast path: exact residual match to a probable small item, weighted by recency counts.
    if _state.counts:
        used = bins < 100
        match_idx = np.where((residual >= 1) & (residual <= 40) & used)[0]
        if match_idx.size > 0:
            targets = [int(residual[i]) for i in match_idx]
            best_k, best_v = _state.best_match(targets)
            if best_v > 0:
                # choose the earliest bin whose residual equals the most probable target
                for i in match_idx:
                    if int(residual[i]) == best_k:
                        score = np.full(bins.shape, -1e9, dtype=np.float64)
                        score[i] = 1.0
                        return score

    thresh = 0.6 * _state.small  # residual below this is hard to reuse

    order = np.argsort(residual, kind="stable")
    best = order[0]
    best_res = residual[best]

    if best_res <= 0 or best_res >= thresh:
        score = -residual.astype(np.float64)
        return score

    usable = np.where((residual >= thresh) & (bins < 100))[0]
    if usable.size > 0:
        j = usable[np.argmin(residual[usable])]
        score = np.full(bins.shape, -1e9, dtype=np.float64)
        score[j] = 1.0
        return score

    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

