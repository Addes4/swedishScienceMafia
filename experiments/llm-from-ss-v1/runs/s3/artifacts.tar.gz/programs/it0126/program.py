# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and expected-cost tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin
is chosen, since closing a bin is always at least as good as any other placement. Ties on the SoS
delta are broken by a one-step look-ahead: among the resulting residual classes r, pick the r that
minimises the expected increase of sum_g N(g)^2 when the *next* item (drawn from the known
distribution) is placed greedily. The function is shown only the bins the item fits in, so it
keeps its own record of every opened bin; used bins are always a prefix of the bin array. Each
instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Precompute the item-size distribution (Weibull-shaped, mean ~40, integer 1..100).
_ITEM_P = np.zeros(CAP + 1)
try:
    from scipy.stats import weibull_min
    _c = None
    best_err = 1e9
    for c in np.linspace(0.9, 2.5, 33):
        scale = 40.0 / weibull_min.mean(c)
        m = weibull_min.mean(c) * scale
        if abs(m - 40.0) < best_err:
            best_err = abs(m - 40.0)
            _c = c
    _scale = 40.0 / weibull_min.mean(_c)
    edges = np.arange(0.5, CAP + 1.5)
    vals = weibull_min.cdf(edges, _c, scale=_scale)
    probs = np.diff(vals)
    probs = np.clip(probs, 0.0, None)
    probs[1:] /= probs[1:].sum() if probs[1:].sum() > 0 else 1.0
    _ITEM_P[:] = probs[:CAP + 1]
except Exception:
    # Fallback: smooth unimodal distribution centred near 40.
    x = np.arange(CAP + 1)
    w = np.exp(-0.5 * ((x - 40.0) / 15.0) ** 2)
    w[0] = 0.0
    w /= w.sum()
    _ITEM_P[:] = w


def _expected_delta_newbin(r_new):
    """Expected SoS increase if the next item is placed into a brand-new bin.

    State has current class counts _N plus a hypothetical bin with residual r_new.
    We approximate by summing over next-item sizes the best (minimum) delta among all
    reachable placements (existing classes + this bin + a fresh bin). This is a coarse
    but deterministic tie-break.
    """
    return 0.0  # not used in primary tie-break path


def _lookahead_penalty(r):
    """Expected next-step SoS increase given that the current placement leaves residual r.

    We consider the next item size t with probability _ITEM_P[t]. Among all placement options
    for t (each existing class g>=t, the new residual r>=t, or a fresh bin), the greedy choice
    yields some residual; we sum the resulting instantaneous SoS delta weighted by probability.
    Classes with count 0 contribute nothing; we only track the counts we can affect.
    """
    if r <= 0:
        return -1e18  # closing a bin is best; keep it dominant
    n_r_after = _N[r] + 1  # the bin we just created sits in class r
    total = 0.0
    p = _ITEM_P
    for t in range(1, CAP + 1):
        pt = p[t]
        if pt <= 0.0:
            continue
        best = None
        # existing classes g in (0,CAP), g != r
        for g in range(t, CAP):
            if g == r:
                continue
            ng = _N[g]
            if ng <= 0:
                continue
            r2 = g - t
            delta = -2 * ng + 1 + (2 * _N[r2] + 1 if r2 > 0 else 0)
            if best is None or delta < best:
                best = delta
        # the bin with residual r
        if r >= t:
            ng = n_r_after
            r2 = r - t
            delta = -2 * ng + 1 + (2 * _N[r2] + 1 if r2 > 0 else 0)
            if best is None or delta < best:
                best = delta
        # a fresh bin
        r2 = CAP - t
        delta = 2 * _N[r2] + 1 if r2 > 0 else 0
        if best is None or delta < best:
            best = delta
        total += pt * best
    return total


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            tie = _lookahead_penalty(r) if r > 0 else -1e18
            # rank by delta (primary, ascending), then expected penalty (ascending),
            # then smaller r. Encode all into a single maximised score.
            scores[k] = -(delta * 1e12 + tie * 1e3 + (CAP - r))
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        tie_new = _lookahead_penalty(r_new) if r_new > 0 else -1e18
        scores[len(fitting):] = -(delta_new * 1e12 + tie_new * 1e3 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
