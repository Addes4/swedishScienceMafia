# EVOLVE-BLOCK-START
"""Bounded sum-of-squares rule with exact-fit override and merge tie-break.

Each item goes where it minimises sum_g min(N(g),K)^2 over residual classes, with K a small cap
so that one heavily populated class cannot dominate the ordering. If some fitting bin can take the
item exactly (residual 0), that bin is chosen instead, since closing a bin is always at least as
good as any other placement. Ties on the bounded delta go to the placement merging into the most
populated residual class, then to the smaller residual. The function is shown only the bins the
item fits in, so it keeps its own record of every opened bin; used bins are always a prefix of the
bin array. Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_K = 3
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _cost():
    return sum(min(n, _K) * min(n, _K) for n in _N)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        base = _cost()
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            # bounded delta from removing class g and adding class r
            d = (min(_N[g] - 1, _K) ** 2 - min(_N[g], _K) ** 2)
            if r > 0:
                d += (min(_N[r] + 1, _K) ** 2 - min(_N[r], _K) ** 2)
            nr = _N[r] if r > 0 else 0
            scores[k] = -(d * 100000.0 + nr * 100.0 + (CAP - r))
        r_new = CAP - s
        d_new = 0
        if r_new > 0:
            d_new = (min(_N[r_new] + 1, _K) ** 2 - min(_N[r_new], _K) ** 2)
        nr_new = _N[r_new] if r_new > 0 else 0
        scores[len(fitting):] = -(d_new * 100000.0 + nr_new * 100.0 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
