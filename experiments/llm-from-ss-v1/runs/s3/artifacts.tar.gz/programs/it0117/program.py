# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin is chosen instead,
since closing a bin is always at least as good as any other placement. Ties on the SoS delta go to the
smaller resulting residual. N(g) is computed directly from the `bins` array each call: fitting existing
bins have remaining capacity < 100, unused bins have remaining capacity 100.
"""
import numpy as np

CAP = 100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = int(item)
    n = len(bins)
    caps = np.asarray(bins)

    # Count open bins by remaining capacity class from the current view.
    N = [0] * (CAP + 1)
    for g in caps:
        gi = int(g)
        if 0 < gi < CAP:
            N[gi] += 1

    # fitting existing bins: caps < 100 (used). unused bins appear as 100.
    is_used = caps < CAP
    fit_mask = is_used & (caps >= s)

    scores = np.empty(n, dtype=np.float64)

    # Exact-fit override: an existing fitting bin with residual 0.
    exact = np.nonzero(fit_mask & (caps == s))[0]
    if exact.size > 0:
        scores[:] = 0.0
        scores[exact[0]] = 1.0
        return scores

    # SoS delta for each bin.
    # Existing fitting bin with residual r=g-s:
    #   removing class g (-1) and adding class r (+1 if r>0):
    #   delta = -2*N[g] + 1 + (2*N[r] + 1 if r>0 else 0)
    # Unused bin: adds class r=CAP-s: delta = 2*N[r] + 1 if r>0 else 0
    for k in range(n):
        g = int(caps[k])
        if fit_mask[k]:
            r = g - s
            delta = -2 * N[g] + 1 + (2 * N[r] + 1 if r > 0 else 0)
        else:
            r = CAP - s
            delta = 2 * N[r] + 1 if r > 0 else 0
        # primary: smaller delta (better); secondary: smaller residual
        if fit_mask[k]:
            r2 = int(caps[k]) - s
        else:
            r2 = CAP - s
        scores[k] = -(delta * 100000.0 + (CAP - r2))

    return scores
# EVOLVE-BLOCK-END
