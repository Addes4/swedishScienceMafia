# EVOLVE-BLOCK-START
"""Best-Fit rule with a light SoS tie-break.

Each arriving item is placed in the fitting bin whose remaining capacity after placement is
smallest (classic Best Fit). Because the harness gives us only the bins the item fits in and
opens unused bins in index order, used bins form a prefix; we track capacities ourselves.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Best fit: smallest residual gets the highest score.
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        scores[k] = -r

    # Unused bins: residual is CAP - s; use a slightly larger residual penalty so
    # used bins are preferred whenever they fit at least as tightly.
    r_new = CAP - s
    scores[len(fitting):] = -r_new - 0.5

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _caps[j] = g - s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
