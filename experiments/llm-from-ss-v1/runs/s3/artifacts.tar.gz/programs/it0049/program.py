# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and history-weighted residual match.

Each item goes where it minimises sum_g N(g)^2 (N counts open bins with residual g, 0<g<100).
Exact-fit (residual 0) is chosen if available, since closing a bin is always at least as good.
Ties on the SoS delta are broken by a history-based estimate: how often past items fell short
enough to be closed by this residual class, favouring residuals likely to be paired soon.
The function keeps its own record of open bins (used bins form a prefix of the bin array).
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0] * (CAP + 1)        # _hist[s]: count of past items of size s


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _hist
    s = int(item)
    _hist[s] += 1
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # Complement potential of a residual r: how much historical mass lands in (r - margin, r].
        # Larger means an item of that size has often appeared, so r is likely to be closed soon.
        margin = 5
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            if r > 0:
                comp = sum(_hist[max(1, r - margin):r + 1])
            else:
                comp = 0
            match = 1.0 if (r > 0 and _N[r] >= 1) else 0.0
            scores[k] = -(delta * 1000000.0 + match * 100000.0 + comp * 100.0 + (CAP - r))
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        if r_new > 0:
            comp_new = sum(_hist[max(1, r_new - margin):r_new + 1])
        else:
            comp_new = 0
        match_new = 1.0 if (r_new > 0 and _N[r_new] >= 1) else 0.0
        scores[len(fitting):] = -(delta_new * 1000000.0 + match_new * 100000.0
                                  + comp_new * 100.0 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

