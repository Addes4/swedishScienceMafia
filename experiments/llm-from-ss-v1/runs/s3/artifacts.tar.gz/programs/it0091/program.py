# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and best-fit tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin is chosen instead,
since closing a bin is always at least as good as any other placement. Among placements with equal
SoS delta, ties are broken by preferring a placement whose resulting residual exactly matches the
complement of an existing open class (so a future item can close it), then by the smallest positive
residual (classic best-fit). The function is shown only the bins the item fits in, so it keeps its own
record of every opened bin; used bins are always a prefix of the bin array. Each instance runs in a
fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.zeros(n_bins, dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break

    if exact_pos >= 0:
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        best_key = None
        choice = 0
        # Need complement presence for tie-break: complement of r is CAP - r
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            # tie-break: prefer r whose complement (CAP-r) is an existing class, then smaller r
            has_pair = (r > 0 and r < CAP and N_or(_N, CAP - r) > 0)
            key = (delta, 0 if has_pair else 1, r)
            if best_key is None or key < best_key:
                best_key = key
                choice = k
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        has_pair_new = (r_new > 0 and r_new < CAP and N_or(_N, CAP - r_new) > 0)
        key_new = (delta_new, 0 if has_pair_new else 1, r_new)
        use_new = _unused_can_open(n_unused, best_key, key_new)
        if use_new:
            choice = n_bins - 1  # any unused bin index; all unused are equivalent
            best_key = key_new

        # Assign scores so argmax picks `choice` (first occurrence on ties).
        inv = -1e9
        for k in range(n_bins):
            scores[k] = inv
        if choice < len(fitting):
            scores[choice] = 1.0
        else:
            # pick first unused index
            scores[len(fitting)] = 1.0
            choice = len(fitting)

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores


def N_or(arr, idx):
    return arr[idx] if 0 <= idx <= CAP else 0


def _unused_can_open(n_unused, best_key, key_new):
    if n_unused <= 0:
        return False
    if best_key is None:
        return True
    return key_new < best_key
# EVOLVE-BLOCK-END

