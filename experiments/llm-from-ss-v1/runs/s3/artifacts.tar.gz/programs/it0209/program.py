# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override, RRC-lite pairing bonus.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100), using p = 1.0 (the standard sum-of-squares /
"least loaded classes" potential known to be near-optimal in this capacity regime). If some
fitting bin can take the item exactly (residual 0), that bin is chosen instead. Ties on the
potential delta are broken by preferring a resulting residual that matches a more common existing
open class, then a fuller bin. A small bonus rewards placements whose resulting residual is close
to a frequently-seen recent item size (so the bin may be closed cheaply soon). The function keeps
its own record of every opened bin; used bins are always a prefix of the bin array.
"""
import numpy as np

CAP = 100
_P = 1.0
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight
_hist = np.zeros(CAP + 1, dtype=np.float64)   # decaying histogram of recent item sizes
_HIST_DECAY = 0.99
_hist_total = 0.0
_PAIR_W = 0.05                 # small weight for the pairing bonus


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist, _hist_total
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # normalized recent-item histogram; a residual r is "likely fillable" if h[r] is large
        def pair_bonus(r):
            if r <= 0 or _hist_total <= 0.0:
                return 0.0
            return _PAIR_W * (_hist[r] / _hist_total)

        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -_W[g] * (2 * _N[g] - 1)
            if r > 0:
                delta += _W[r] * (2 * _N[r] + 1)
            match = _N[r] if r > 0 else 0
            bonus = pair_bonus(r)
            scores[k] = -(delta * 100000.0 + match * 100.0 + r) + bonus * 100000.0
        r_new = CAP - s
        delta_new = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        match_new = _N[r_new] if r_new > 0 else 0
        bonus_new = pair_bonus(r_new)
        base_new = -(delta_new * 100000.0 + match_new * 100.0 + r_new)
        scores[len(fitting):] = base_new + bonus_new * 100000.0
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update decaying item-size histogram after placement decision
    _hist *= _HIST_DECAY
    _hist_total *= _HIST_DECAY
    _hist[s] += 1.0
    _hist_total += 1.0
    return scores
# EVOLVE-BLOCK-END
