# EVOLVE-BLOCK-START
"""Best-fit rule with exact-fit override and residual-class tie-break.

Each item goes to the fitting bin whose resulting residual r = g - s is smallest (classic best fit),
which keeps bins tight and tends to close them. If any fitting bin can take the item exactly
(r == 0), that bin is chosen first, since closing a bin is always at least as good as anything else.
Ties on r are broken by preferring residuals that already occur among open bins (so future items can
pair classes complementarily), then by larger current capacity (closer to perfectly tight already).
The used bins are always a prefix of the bin array; the function records every opened bin itself.
Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos < 0 and n_unused > 0 and s == CAP:
        exact_pos = len(fitting)      # item of size 100 fills a fresh bin exactly
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            match = 1.0 if _N[r] >= 1 else 0.0
            scores[k] = -(r * 1e5 + (1.0 - match) * 100.0 + (CAP - g))
        r_new = CAP - s
        match_new = 1.0 if _N[r_new] >= 1 else 0.0
        scores[len(fitting):] = -(r_new * 1e5 + (1.0 - match_new) * 100.0 + (CAP - CAP))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
