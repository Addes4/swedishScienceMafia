# EVOLVE-BLOCK-START
"""Best-Fit rule with exact-fit override and residual-class tie-break.

Best-Fit: among the bins the item fits in, place it in the one that leaves the smallest
remaining capacity (tightest fit). This is the classic strong online heuristic for random
Weibull item sizes. Ties are broken by preferring the resulting residual to already be a
nonempty class (so future items can pair complementarily), then by the smaller residual.
We also keep the exact-fit override (residual 0) since closing a bin is optimal. The function
is shown only the bins the item fits in, so it keeps its own record of every opened bin; used
bins are always a prefix of the bin array. Each instance runs in a fresh process, so
module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # Primary: Best-Fit -> smallest residual r = g - s. Secondary: prefer r that already
        # exists as a class (pairing), then smaller r. Encode with large weights.
        for k, j in enumerate(fitting):
            r = _caps[j] - s
            match = 1.0 if (r > 0 and _N[r] >= 1) else 0.0
            # descending order: by -r (smaller r better). Use negative r as main term.
            scores[k] = -(r * 1000000.0) + match * 1000.0
        r_new = CAP - s
        match_new = 1.0 if (r_new > 0 and _N[r_new] >= 1) else 0.0
        scores[len(fitting):] = -(r_new * 1000000.0) + match_new * 1000.0
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
