# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and a distribution-aware tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin
is chosen instead, since closing a bin is always at least as good as any other placement.
Ties on the SoS delta are broken by preferring the resulting residual that is most likely to
still accept a typical future item (mean item size ~40), i.e. larger residuals are preferred
when they still can accept average-sized items; among those, the smaller residual is preferred
to reduce fragmentation. The function keeps its own record of every opened bin.
"""
import numpy as np

CAP = 100
MEAN_ITEM = 40.0
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _tiebreak(r):
    """Lower is better: prefer residuals that still fit typical items, then smaller residual."""
    # 0 if r >= MEAN_ITEM (can still hold a typical item), else 1
    return (0 if r >= MEAN_ITEM else 1, CAP - r)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            a, b = _tiebreak(r)
            scores[k] = -(delta * 1e6 + a * 1e3 + b)
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        a, b = _tiebreak(r_new)
        scores[len(fitting):] = -(delta_new * 1e6 + a * 1e3 + b)
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
