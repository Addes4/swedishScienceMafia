# EVOLVE-BLOCK-START
"""Best-Fit primary rule with Sum-of-Squares secondary tie-break and exact-fit override.

The item goes to the fitting bin (including a new unused bin) whose post-placement residual is
smallest, which packs bins tightly. Among placements with the same residual, we prefer the one
minimising the change in sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100); this keeps the open-bin state concentrated in few capacity classes and reduces
future fragmentation. If some fitting bin can take the item exactly (residual 0), it is preferred,
since closing a bin is never worse than any other placement. The function is shown only the bins
the item fits in, so it keeps its own record of every opened bin. The harness opens unused bins in
index order (ties go to the first bin), so used bins are always a prefix of the bin array. Each
instance runs in a fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Compute per-placement keys: primary = residual (smaller better), secondary = SoS delta.
    def dstr(r):
        # larger N[r] and smaller r preferred as tertiary refinement
        nr = _N[r] if r > 0 else 0
        return nr * 100.0 + (CAP - r)

    best_pos = -1
    best_res = 10 ** 9
    best_delta = 10 ** 9
    best_ter = -1.0
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        ter = dstr(r)
        if (r < best_res or
                (r == best_res and delta < best_delta) or
                (r == best_res and delta == best_delta and ter > best_ter)):
            best_res = r
            best_delta = delta
            best_ter = ter
            best_pos = k

    # Candidate: open a new bin.
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    ter_new = dstr(r_new)
    new_better = False
    if n_unused > 0:
        if (r_new < best_res or
                (r_new == best_res and delta_new < best_delta) or
                (r_new == best_res and delta_new == best_delta and ter_new > best_ter)):
            new_better = True

    scores[:] = 0.0
    if best_pos >= 0 and not new_better:
        choice = best_pos
    elif n_unused > 0:
        choice = len(fitting)  # first unused bin
    else:
        choice = best_pos

    scores[choice] = 1.0

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
