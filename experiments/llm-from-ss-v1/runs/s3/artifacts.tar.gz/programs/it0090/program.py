# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and pairing-aware tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin is chosen instead,
since closing a bin is always at least as good as any other placement. Among SoS-optimal placements the
tie is broken by preferring the resulting residual r whose complement 100-r is already present as a
class (so a future item of size 100-r closes one of them), then by the smaller residual (best-fit).
The function keeps its own record of every opened bin; used bins are always a prefix of the bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1e9
        choice = exact_pos
    else:
        def key(r):
            # lower delta is better; among SoS-equal prefer complement present; then smaller r
            delta = (2 * _N[r] + 1) if r > 0 else 0
            if r > 0:
                delta -= 2 * _N[0]  # (unused: N[0] always 0, keeps formula symmetric)
            comp_present = 0
            if r > 0 and (CAP - r) < CAP and _N[CAP - r] > 0:
                comp_present = 1
            return (delta, -comp_present, r)

        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            d = -2 * _N[g] + 1 + ((2 * _N[r] + 1) if r > 0 else 0)
            comp_present = 1 if (r > 0 and _N[CAP - r] > 0) else 0
            scores[k] = -(d * 1000.0 + (-comp_present) * 10.0 + r)
        r_new = CAP - s
        d_new = (2 * _N[r_new] + 1) if r_new > 0 else 0
        comp_new = 1 if (r_new > 0 and _N[CAP - r_new] > 0) else 0
        scores[len(fitting):] = -(d_new * 1000.0 + (-comp_new) * 10.0 + r_new)
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

