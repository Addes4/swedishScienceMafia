# EVOLVE-BLOCK-START
"""Best-Fit with residual-class awareness.

Place each item into the fitting bin whose resulting residual is smallest (best fit), which is
the strongest simple online heuristic for Weibull-shaped sizes. Ties are broken by preferring a
residual that already occurs among open bins (so a future complementary item can close one of
the pair), then by the residual that occurs most often. Exact fits (residual 0) are preferred
outright. The function keeps its own record of every opened bin; used bins form a prefix of the
bin array. Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []
_N = [0] * (CAP + 1)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            cnt = _N[r] if r > 0 else 0
            # primary: smaller residual (best fit); bonus if residual already present
            bonus = 1.0 if cnt >= 1 else 0.0
            scores[k] = -(r * 1000.0 - bonus * 100.0 + (100 - r))
        r_new = CAP - s
        cnt_new = _N[r_new] if r_new > 0 else 0
        bonus_new = 1.0 if cnt_new >= 1 else 0.0
        scores[len(fitting):] = -(r_new * 1000.0 - bonus_new * 100.0 + (100 - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
