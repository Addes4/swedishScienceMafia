# EVOLVE-BLOCK-START
"""Best-Fit residual rule with exact-fit override and count-aware consolidation tie-break.

Among fitting bins, pick the placement leaving the smallest positive residual (classic Best-Fit),
which is strong on random Weibull data. Ties on the residual are broken by preferring the residual
class with the highest existing open-bin count (N[r]), since stacking bins into a common residual
class raises the chance of future exact fills and closures; remaining ties prefer the fuller bin
in bin order. An exact fit (placement leaving residual 0) always wins. The function only sees bins
the item fits in, so it reconstructs the used-bin prefix from its own record of opened bins.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            match = _N[r] if r > 0 else 0
            scores[k] = -(r * 100000.0 + match * 100.0 - r * 0.001)
        r_new = CAP - s
        if r_new > 0:
            match_new = _N[r_new]
            scores[len(fitting):] = -(r_new * 100000.0 + match_new * 100.0 - r_new * 0.001)
        else:
            scores[len(fitting):] = 0.0  # unused bin taking item of size 100 -> residual 0
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

