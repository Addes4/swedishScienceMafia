# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override and adaptive exponent.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). The weighting exponent p balances how much the
rule penalizes multiplying near-full residual classes (whose closure is the dominant saving) versus
counts of large-residual classes. If some fitting bin can take the item exactly (residual 0), that
bin is chosen instead, since closing a bin is always at least as good as any other placement. Ties
on the potential delta go to the placement whose resulting residual matches an existing open bin's
class, and then to the smaller residual. The exponent is adapted online from observed item sizes:
larger typical items make near-full classes relatively more important, so p is nudged upward as the
observed mean grows. Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** 0.8) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight
_sum = 0.0
_cnt = 0
_P = 0.8
_lastp = -1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _sum, _cnt, _P, _lastp, _W
    s = int(item)
    _sum += s
    _cnt += 1
    mean = _sum / _cnt
    # map observed mean (~40) to exponent, clamped to a safe range around known optimum
    p = 0.8 + (mean - 40.0) * 0.004
    if p < 0.6:
        p = 0.6
    elif p > 1.0:
        p = 1.0
    if p != _lastp:
        _W = [((CAP / g) ** p) if g > 0 else 0.0 for g in range(CAP + 1)]
        _lastp = p
    _P = p

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -_W[g] * (2 * _N[g] - 1)
            if r > 0:
                delta += _W[r] * (2 * _N[r] + 1)
            match = (_N[r] >= 2) if r > 0 else False
            scores[k] = -(delta * 100000.0 + (1.0 if match else 0.0) * 100.0 + (CAP - r))
        r_new = CAP - s
        delta_new = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        match_new = (_N[r_new] >= 1) if r_new > 0 else False
        scores[len(fitting):] = -(delta_new * 100000.0 + (1.0 if match_new else 0.0) * 100.0 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

