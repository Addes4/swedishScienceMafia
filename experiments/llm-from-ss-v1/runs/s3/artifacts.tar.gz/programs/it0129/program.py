# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and expected-SoS look-ahead tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin is chosen instead,
since closing a bin is always at least as good as any other placement.

Among placements tied on the immediate SoS delta, we add a bounded one-step look-ahead: estimate the
expected SoS delta of the *next* item under the item-size distribution and prefer the residual class
whose future expected delta is smallest. This rewards leaving residuals that either others can fill
exactly or that complement existing open bins, reducing long-run fragmentation beyond the weak match
flag. The function is shown only the bins the item fits in, so it keeps its own record of every opened
bin; used bins are always a prefix of the bin array. Each instance runs in a fresh process, so
module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
    else:
        # secondary: small residual (best-fit flavor); tertiary: smaller r for determinism
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            look = _future_delta(r)
            scores[k] = -(delta * 100000.0 + look * 1000.0 + (CAP - r))
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        look_new = _future_delta(r_new)
        scores[len(fitting):] = -(delta_new * 100000.0 + look_new * 1000.0 + (CAP - r_new))
    choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores


def _future_delta(r):
    """Expected SoS delta of the next item, roughly, given we just created residual r.

    If r==0 the bin is closed (no effect). Otherwise r's class gained a bin, so a future item
    that exactly fills it removes a bin from class r; small r are cheap because random items
    rarely land exactly, so we instead value residuals that existing classes can complement.
    We approximate by counting how many open classes g' would be exactly closed by a random item
    landing in the new class r (i.e. some future item of size r) and how many residual classes it
    can pair with.
    """
    if r <= 0:
        return 0.0
    # Value of r: fewer other open bins in classes that would collide keeps the delta positive;
    # a class with few members is cheap to keep (low squared increment). We also mildly reward
    # residuals that complement an existing class (r + g' == 100) so future items can close bins.
    sq = 2 * _N[r] + 1
    comp = 0
    for g in range(1, CAP):
        if _N[g] > 0 and g + r == CAP:
            comp += _N[g]
    # lower expected delta is better: subtract a complement bonus
    return sq - 0.5 * comp
# EVOLVE-BLOCK-END
