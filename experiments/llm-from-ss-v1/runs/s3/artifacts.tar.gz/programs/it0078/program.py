# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a soft exact-fit bonus.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). An exact-fit placement (resulting residual 0) receives a large but finite bonus so that
it is strongly preferred but not forced when another placement has a strictly better SoS delta. Ties
are broken toward the smaller resulting residual. The function is shown only the bins the item fits in,
so it keeps its own record of every opened bin; used bins are always a prefix of the bin array. Each
instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

EXACT_BONUS = 10.0             # large but finite: prefer closing unless SoS strongly disagrees


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        bonus = EXACT_BONUS if r == 0 else 0.0
        scores[k] = -(delta + bonus) * 1000.0 - r

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    bonus_new = EXACT_BONUS if r_new == 0 else 0.0
    scores[len(fitting):] = -(delta_new + bonus_new) * 1000.0 - r_new

    choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
