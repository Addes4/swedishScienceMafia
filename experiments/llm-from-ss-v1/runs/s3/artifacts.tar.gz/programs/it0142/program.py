# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and empirical-frequency tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin is chosen instead.
The SoS delta is computed exactly (one-step change of sum N^2) and used as the primary score. Ties on
the SoS delta are broken by an empirical histogram of item sizes seen so far: we prefer the placement
whose resulting residual r has been observed most often (that bin is likeliest to be exactly filled by
a future item of size r). A final tie-break prefers the smaller residual (tightest fit). The function
keeps its own record of every opened bin; used bins are always a prefix of the bin array. Each instance
runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # observed count of arriving item size s

_PRIM = 1e6                    # weight of the SoS delta (primary)
_SEC = 1e2                     # weight of the frequency tie-break


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _freq
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: an existing fitting bin whose residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # Existing fitting bins.
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            fr = _freq[r] if r > 0 else 0
            scores[k] = -delta * _PRIM + fr * _SEC - (CAP - r)
        # Brand-new bins (remaining capacity CAP); all identical.
        r = CAP - s
        delta = 2 * _N[r] + 1 if r > 0 else 0
        fr = _freq[r] if r > 0 else 0
        scores[len(fitting):] = -delta * _PRIM + fr * _SEC - (CAP - r)
        choice = int(np.argmax(scores))

    # Apply the placement and update our bookkeeping.
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        nr = g - s
        _caps[j] = nr
        if nr > 0:
            _N[nr] += 1
    elif n_unused > 0:
        nr = CAP - s
        _caps.append(nr)
        if nr > 0:
            _N[nr] += 1
    _freq[s] += 1
    return scores
# EVOLVE-BLOCK-END
