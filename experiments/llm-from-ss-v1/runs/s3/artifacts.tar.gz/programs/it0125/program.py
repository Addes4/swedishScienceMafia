# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and a residual-value tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). The SoS-delta for moving a class-g bin to class-(g-s) is -2N(g)+1 + (2N(g-s)+1 if g-s>0).
If some fitting bin can take the item exactly (residual 0), that bin is chosen instead, since closing a
bin is always at least as good as any other placement. Ties on the SoS delta are broken by preferring the
resulting residual r that is most likely to be exactly matched by a future item, using a weight derived
from the known Weibull(mean~40) item distribution concentrated around ~30-40. The function is shown only
the bins the item fits in, so it keeps its own record of every opened bin; used bins are always a prefix
of the bin array. Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Value of leaving residual r: higher means more likely to be filled exactly by a future item.
# Approximate the item distribution (Weibull-shaped, mean ~40) empirically with a fixed weight vector.
_value = [0.0] * (CAP + 1)
for _r in range(1, CAP + 1):
    # peak weight near r ~ 30..40, tapering off; exact-fit residual 0 is handled separately
    _d = (_r - 35.0)
    _value[_r] = np.exp(-_d * _d / (2.0 * 18.0 * 18.0)) - 1.0 * (abs(_r - 35.0) / 65.0)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            scores[k] = -(delta * 100000.0 + (_value[r] if r > 0 else 0.0) * 1000.0 + (CAP - r))
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        scores[len(fitting):] = -(delta_new * 100000.0
                                  + (_value[r_new] if r_new > 0 else 0.0) * 1000.0
                                  + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
