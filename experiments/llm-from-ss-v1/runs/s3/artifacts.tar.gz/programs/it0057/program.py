# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and empirical pairing tie-break.

Primary key: minimise the change in sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Closely tied placements are resolved by a learned preference: keep a
running histogram of observed item sizes and prefer the placement whose resulting residual r
(and complement 100-r) is most likely to be closed by a future item, using a smoothed estimate
of the item-size distribution. Exact fits are handled first since closing a bin is optimal.
Used bins are always a prefix of the bin array; module state starts empty per process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0.0] * (CAP + 1)      # smoothed count of observed item sizes
_seen = 0.0


def _pair_prob(r):
    """Smoothed estimate that a future item will close a bin left with residual r."""
    if r <= 0:
        return 0.0
    # weight items that could pair with an r-residual bin (size in [r, 100])
    tot = 0.0
    for t in range(r, CAP + 1):
        tot += _freq[t]
    return tot / (_seen + CAP)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _freq, _seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: closing a bin is always at least as good.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            tie = _pair_prob(r)
            scores[k] = -(delta * 1000000.0 + tie * 1000.0 + (CAP - r))
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        tie_new = _pair_prob(r_new)
        scores[len(fitting):] = -(delta_new * 1000000.0 + tie_new * 1000.0 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update empirical item-size histogram
    _freq[s] += 1.0
    _seen += 1.0
    return scores
# EVOLVE-BLOCK-END
