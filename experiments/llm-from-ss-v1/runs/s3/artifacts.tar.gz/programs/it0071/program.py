# EVOLVE-BLOCK-START
"""Sum-of-Squares (SoS) bin-choice rule with exact-fit override.

Each item goes where it minimises the change in sum_g N(g)^2, where N(g) counts open bins with
remaining capacity g (0 < g < CAP). If some fitting bin can take the item exactly (residual 0),
that bin is chosen instead, since closing a bin is always at least as good as any other placement.

Ranking is done with a clean lexicographic integer key (no fragile multiplicative encoding):
  primary   = SoS delta (integer, smaller is better)
  secondary = prefer exact fit / closing a bin
  tertiary  = prefer resulting residuals that are more plentiful (to enable future pairings)
  quaternary= prefer smaller resulting residual (classic best-fit flavour)
  quinary   = prefer an existing fitting bin over opening a fresh one (stable, avoids waste)
The function is shown only the bins the item fits in, so it keeps its own record of every opened
bin; used bins are always a prefix of the bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # Build a lexicographic key: higher score wins. We assemble a single integer score
        # per candidate so ordering is exact and deterministic.
        best_key = None
        choice = 0
        # candidate placements into existing fitting bins
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            # key: (primary smaller delta) -> use negation; secondary: r==0 bonus;
            # tertiary: more plentiful resulting residual; quaternary: smaller residual;
            # quinary: existing bin preferred (bonus).
            key = (
                -delta,                       # primary: smaller SoS delta
                1 if r == 0 else 0,           # secondary: closing a bin
                _N[r] if r > 0 else -1,       # tertiary: plentiful resulting residual
                -r,                           # quaternary: smaller residual
                1,                            # quinary: existing bin
            )
            scores[k] = 0.0
            if best_key is None or key > best_key:
                best_key = key
                choice = k
        # candidate placements into fresh (unused) bins
        if n_unused > 0:
            r = CAP - s
            delta = 2 * _N[r] + 1 if r > 0 else 0
            key = (
                -delta,
                1 if r == 0 else 0,
                _N[r] if r > 0 else -1,
                -r,
                0,                            # fresh bin is less preferred than existing
            )
            if best_key is None or key > best_key:
                best_key = key
                choice = len(fitting)
        # encode scores so that np.argmax picks `choice`
        scores[:] = 0.0
        scores[choice] = 1.0

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
