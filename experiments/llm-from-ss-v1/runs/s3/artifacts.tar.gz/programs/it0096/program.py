# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and pairing-aware tie-break.

Each item goes where it minimises the sum-of-squares cost over residual classes N(g),
where N(g) counts open bins with remaining capacity g (0 < g < 100). If some fitting bin
can take the item exactly (residual 0), that bin is chosen instead. Ties on the SoS delta
are broken by preferring the placement that maximises the total number of closeable
complementary pairs P = sum_g min(N[g], N[100-g]) after the move, then by smaller residual.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin; used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _pair_score():
    """Total number of closeable complementary pairs sum_g min(N[g], N[100-g])."""
    tot = 0
    for g in range(1, CAP):
        c = _N[g]
        if c:
            c2 = _N[CAP - g]
            tot += c if c < c2 else c2
    return tot >> 1  # each pair counted twice


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        base_pairs = _pair_score()
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            # pairing contribution change (approximate, per-item local effect)
            pairs = 0
            if r > 0:
                cr = _N[r]
                cc = _N[CAP - r]
                pairs += (cr + 1) if (cr + 1) < cc else cc
                if g > 0:
                    cg = _N[g]
                    ccg = _N[CAP - g]
                    pairs -= (cg - 1) if (cg - 1) < ccg else ccg
            else:
                if g > 0:
                    cg = _N[g]
                    ccg = _N[CAP - g]
                    pairs -= (cg - 1) if (cg - 1) < ccg else ccg
            scores[k] = -(delta * 100000.0 + pairs * 100.0 + (CAP - r))
        r_new = CAP - s
        if r_new > 0:
            cr = _N[r_new]
            cc = _N[CAP - r_new]
            new_pairs = (cr + 1) if (cr + 1) < cc else cc
        else:
            new_pairs = 0
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        scores[len(fitting):] = -(delta_new * 100000.0 + new_pairs * 100.0 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

