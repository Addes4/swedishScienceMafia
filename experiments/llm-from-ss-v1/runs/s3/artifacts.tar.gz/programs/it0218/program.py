# EVOLVE-BLOCK-START
"""Residual-class matching first, capacity-weighted potential as tie-break, exact fit override.

Each arriving item is placed immediately. The primary rule is: if placing the item leaves a
residual r>0 that equals the residual of some *other* currently-open bin, that placement is
preferred, because it merges the item into an existing reusable residual class and avoids
creating a new, possibly-never-reusable fragment. Among such matching placements, and among all
placements when no match exists, the tie-break is the capacity-weighted sum-of-squares potential
delta P = sum_g (100/g)^p * N(g)^2, then the resulting class count, then a fuller bin.
An exact fit (resulting residual 0) is always taken when available. The function is shown only
the bins the item fits in, so it keeps its own record of every opened bin; used bins are always
a prefix of the bin array.
"""
import numpy as np

CAP = 100
_P = 0.8
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            # weighted potential delta: -w_g*(2N[g]-1) + (w_r*(2N[r]+1) if r>0 else 0)
            delta = -_W[g] * (2 * _N[g] - 1)
            if r > 0:
                delta += _W[r] * (2 * _N[r] + 1)
            r = g - s
            # primary: does resulting residual match an existing open class (excluding this bin)?
            if r > 0:
                cnt = _N[r] - (1 if _caps[j] == r else 0)
                match = 1 if cnt > 0 else 0
            else:
                match = 0
            # encode lexicographically: match dominates, then lower delta, then fuller bin
            scores[k] = match * 1e9 - delta * 1000.0 - r
        r_new = CAP - s
        delta_new = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        match_new = 1 if (r_new > 0 and _N[r_new] > 0) else 0
        scores[len(fitting):] = match_new * 1e9 - delta_new * 1000.0 - r_new
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
