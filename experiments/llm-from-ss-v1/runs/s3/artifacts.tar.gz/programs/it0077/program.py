# EVOLVE-BLOCK-START
"""Sum-of-Squares bin-choice rule with best-fit tie-break.

Each arriving item goes where it minimises the increase in sum_g N(g)^2, where N(g) counts
open bins (including unused ones, capacity 100) with remaining capacity g. This SoS delta is
the principled greedy objective: it favours closing bins (residual 0) and equalising residual
class sizes so that future items can pair complementarily. Ties on the SoS delta go to the
placement leaving the smaller residual (best-fit), a classical low-risk packing heuristic.
Every bin the item fits in is scored, including unused bins (capacity 100), so the comparison
is uniform. The function keeps its own record of all opened bin capacities; unused bins are a
suffix of the bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: bins with remaining capacity g, 1 <= g <= CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n - len(fitting)
    scores = np.empty(n, dtype=np.float64)

    # Score every existing fitting bin by (-SoS delta*1000 - residual).
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * 1000.0 + r)

    # Unused bins all have g = CAP; identical SoS delta, residual CAP - s.
    if n_unused > 0:
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        scores[len(fitting):] = -(delta_new * 1000.0 + r_new)

    choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

