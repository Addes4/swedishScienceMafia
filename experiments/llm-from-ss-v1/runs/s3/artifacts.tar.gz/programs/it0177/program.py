# EVOLVE-BLOCK-START
"""Best-Fit rule with exact-fit preference.

Place the item in the fitting bin whose remaining capacity after placement is smallest
(i.e. tightest packing), which is the classic Best Fit online bin packing heuristic.
Exact fits are chosen first (residual 0). Ties among equal residuals go to the first bin.
"""
import numpy as np

CAP = 100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = int(item)
    # residual after placing into each shown bin
    residual = bins - s
    # Best Fit: smaller residual is better -> score = -residual (larger score wins)
    scores = -residual.astype(np.float64)
    return scores
# EVOLVE-BLOCK-END
