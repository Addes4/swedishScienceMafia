# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and exact post-state SoS tie-break.

Each item goes where it minimises the marginal change of sum_g N(g)^2, where N(g) counts open bins
with remaining capacity g (0 < g < 100). If some fitting bin can take the item exactly (residual 0),
that bin is chosen instead, since closing a bin is always at least as good as any other placement.
Ties on the SoS delta are resolved by the exact post-placement value of sum_g N(g)^2 (a one-step
exact evaluation of the objective, not an approximation), then by the smaller resulting residual.
The function is shown only the bins the item fits in, so it keeps its own record of every opened bin;
used bins are always a prefix of the bin array. Each instance runs in a fresh process, so
module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_SOS = 0                       # cached sum_g N(g)^2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _SOS
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        best_sos = None
        best_r = None
        choice = -1
        # existing fitting bins
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            post = _SOS + delta
            key = (delta, post, r)
            if best_sos is None or key < best_sos:
                best_sos = key
                choice = k
        # unused bins
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        post_new = _SOS + delta_new - 2 * _N[CAP] + 1 - 1  # removing one unused bin (N[CAP]--)
        key_new = (delta_new, post_new, r_new)
        if n_unused > 0 and (best_sos is None or key_new < best_sos):
            best_sos = key_new
            choice = len(fitting)

        # build scores so that argmax picks choice
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            if k == choice:
                scores[k] = 1.0
            else:
                scores[k] = 0.0
        for k in range(len(fitting), len(bins)):
            scores[k] = 1.0 if k == choice else 0.0

    # apply the choice / update state
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _SOS -= 2 * _N[g] + 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
            _SOS += 2 * _N[g - s] - 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
            _SOS += 2 * _N[CAP - s] - 1
    return scores
# EVOLVE-BLOCK-END
