# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override and a "keep bin alive" tie-break.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). The weighting exponent p balances how much the
rule penalizes multiplying near-full residual classes versus counts of large-residual classes.
If some fitting bin can take the item exactly (residual 0), that bin is chosen instead, since
closing a bin is always at least as good as any other placement.

For non-exact placements the primary key is the (scaled) potential delta. As a secondary key we
prefer placements whose resulting residual is at least a running estimate of the typical item size
(so the bin remains able to accept a normal future item instead of becoming dead weight), and the
final tie-break prefers the fuller bin (smaller residual). A running mean of seen item sizes
estimates the typical item size; the estimate is initialised from nothing and updated each call.

The function is shown only the bins the item fits in, so it keeps its own record of every opened
bin; used bins are always a prefix of the bin array. Each instance runs in a fresh process, so
module-level state starts empty.
"""
import numpy as np

CAP = 100
_P = 0.8
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight
_seen = 0                      # number of items seen so far
_sum = 0.0                     # running sum of item sizes
_typ = 40.0                    # running estimate of a typical item size


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _seen, _sum, _typ
    s = int(item)
    _seen += 1
    _sum += s
    _typ = _sum / _seen

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            # weighted potential delta: -w_g*(2N[g]-1) + (w_r*(2N[r]+1) if r>0 else 0)
            delta = -_W[g] * (2 * _N[g] - 1)
            if r > 0:
                delta += _W[r] * (2 * _N[r] + 1)
            # secondary: reward residuals that still fit a typical future item (bin stays alive)
            alive = 1.0 if (r > 0 and r >= _typ) else 0.0
            scores[k] = -(delta * 100000.0) + alive * 100.0 - r
        r_new = CAP - s
        delta_new = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        alive_new = 1.0 if (r_new > 0 and r_new >= _typ) else 0.0
        scores[len(fitting):] = -(delta_new * 100000.0) + alive_new * 100.0 - r_new
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
