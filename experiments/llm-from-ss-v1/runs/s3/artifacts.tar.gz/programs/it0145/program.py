# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and histogram-guided tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin is chosen instead,
since closing a bin is always at least as good as any other placement. Ties on the SoS delta are broken
by an adaptive key based on a running histogram of item sizes: prefer the placement whose resulting
residual r is most likely to be exactly matched soon (either r itself is a common item size, or r's
complement 100-r is common so a later item can close the bin), and finally prefer a smaller residual.
The function is shown only the bins the item fits in, so it keeps its own record of every opened bin;
used bins are always a prefix of the bin array. Each instance runs in a fresh process, so module-level
state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0] * (CAP + 1)        # running histogram of item sizes seen
_seen = 0


def _resid_priority(r):
    """Likelihood that a residual r is exactly matched by a future item (heuristic score)."""
    if r <= 0:
        return -1
    # r matched directly by a future item of size r, or r filled by an item of size CAP-r
    # (the latter closes the bin), weight by observed frequencies.
    return _hist[r] * 2 + _hist[CAP - r]


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist, _seen
    s = int(item)
    _hist[s] += 1
    _seen += 1
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            # secondary: prefer residuals likely to be exactly matched (bigger is better)
            key2 = _resid_priority(r)
            scores[k] = -(delta * 1e7 + (-key2) * 1e3 + (CAP - r))
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        key2_new = _resid_priority(r_new)
        scores[len(fitting):] = -(delta_new * 1e7 + (-key2_new) * 1e3 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

