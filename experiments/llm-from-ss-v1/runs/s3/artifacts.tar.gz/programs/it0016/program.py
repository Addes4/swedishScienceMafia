# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and orphan-residual avoidance.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100); ties go to the tighter fit. If some fitting bin can take the item
exactly, that bin is chosen. Additionally, we avoid leaving a tiny "orphan" residual (1 or 2)
when a nearly-as-good placement avoids it, since such residuals are hard to fill later.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (ties go to the first bin).
Each instance runs in a fresh process, so module-level state starts empty per instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: prefer a bin whose residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos < 0 and CAP == s:
        exact_pos = len(fitting)
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # base score for fitting bins: delta (primary) and -r (tie-break)
        base = np.empty(len(fitting) + n_unused, dtype=np.float64)
        resid = np.empty(len(fitting) + n_unused, dtype=np.int64)
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            base[k] = delta
            resid[k] = r
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        base[len(fitting):] = delta_new
        resid[len(fitting):] = r_new

        best_delta = base.min()
        # candidate set: all placements within small delta slack of the best
        near = np.nonzero(base <= best_delta + 4)[0]
        # avoid orphan residuals unless every near candidate is an orphan
        chosen = -1
        for idx in near:
            r = int(resid[idx])
            if r == 0 or r > 2:
                chosen = idx
                break
        if chosen < 0:
            chosen = int(np.argmin(base - resid * 1e-6))
        # now pick, within the same "orphan class" as chosen, the tightest residual
        r_chosen = int(resid[chosen])
        better = base + (resid != r_chosen) * 1e6 - resid * 1e-6
        scores[:] = 0.0
        for k in range(len(bins)):
            pass
        # build score array: fitting bins get scores, unused get scores
        arr = -(base * 1000.0 + resid)
        arr_unused = -((base[len(fitting):]) * 1000.0 + resid[len(fitting):])
        scores[:len(fitting)] = arr[:len(fitting)]
        scores[len(fitting):] = arr_unused
        # apply orphan preference: demote orphan residuals that exceed chosen class
        for k, j in enumerate(fitting):
            r = int(resid[k])
            if r in (1, 2) and r != r_chosen:
                scores[k] -= 1e7
        if r_new in (1, 2) and r_new != r_chosen:
            scores[len(fitting):] -= 1e7
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
