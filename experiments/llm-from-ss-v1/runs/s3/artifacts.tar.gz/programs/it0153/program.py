# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit as a tie-broken candidate.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). An exact-fit placement (residual 0) decrements N[g] without incrementing any class, so it
is naturally favoured by the SoS delta; we still add a small tie-break preferring it when several
placements share the same delta. Ties beyond that go to the placement whose resulting residual matches an
existing residual class (so future items can pair classes complementarily), then to the smaller residual.
The function is shown only the bins the item fits in, so it keeps its own record of every opened bin; used
bins are always a prefix of the bin array. Each instance runs in a fresh process, so module-level state
starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    def key(delta, exact, match, r):
        # Primary: SoS delta (smaller better). Secondary: exact fit. Tertiary: match/doubling.
        # Quaternary: smaller resulting residual.
        return -(delta * 1000000.0
                 + (1.0 if exact else 0.0) * 100000.0
                 + (1.0 if match else 0.0) * 1000.0
                 + (CAP - r))

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        match = (_N[r] >= 2) if r > 0 else False
        scores[k] = key(delta, r == 0, match, r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    match_new = (_N[r_new] >= 1) if r_new > 0 else False
    scores[len(fitting):] = key(delta_new, False, match_new, r_new)
    choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
