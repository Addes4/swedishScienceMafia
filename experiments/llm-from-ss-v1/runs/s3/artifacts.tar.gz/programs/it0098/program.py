# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with pairing-aware override and residual tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Before applying SoS, we check for a "closing" opportunity: if some fitting bin can take
the item exactly (residual 0), that bin is chosen -- closing a bin is always at least as good as any
other placement. Failing that, if some fitting bin leaves a residual r > 0 for which a complementary
class with remaining capacity 100-r already exists, we take the best such placement, since the two
classes can later pair to close a bin. Otherwise plain SoS-delta ordering applies, ties broken toward
the placement whose resulting residual equals an existing class and then toward the smaller residual.
The function is shown only the bins the item fits in, so it keeps its own record of every opened bin;
used bins are always a prefix of the bin array. Each instance runs in a fresh process, so module-level
state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Look for a "closing" placement: exact fit (r == 0) or a complementary-class pair (r > 0
    # with an existing class of capacity 100 - r), among existing bins and among unused bins.
    close_pos = -1
    close_key = None
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        if r == 0:
            key = (0, 0)
        elif _N[CAP - r] > 0:
            key = (1, CAP - r)
        else:
            continue
        if close_key is None or key < close_key:
            close_key = key
            close_pos = k
    r_new = CAP - s
    if n_unused > 0:
        if r_new == 0:
            key = (2, 0)
        elif _N[CAP - r_new] > 0:
            key = (2, CAP - r_new)
        else:
            key = None
        if key is not None and (close_key is None or key < close_key):
            close_key = key
            close_pos = len(fitting)

    if close_pos >= 0:
        scores[:] = 0.0
        scores[close_pos] = 1.0
        choice = close_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            # secondary: r>0 merges into an existing class; tertiary: smaller r
            match = (_N[r] >= 1) if r > 0 else False
            scores[k] = -(delta * 100000.0 + (1.0 if match else 0.0) * 100.0 + (CAP - r))
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        match_new = (_N[r_new] >= 1) if r_new > 0 else False
        scores[len(fitting):] = -(delta_new * 100000.0 + (1.0 if match_new else 0.0) * 100.0 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
