# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override and stranded-residual penalty.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). Small residuals (below a typical item size)
are penalized extra, since a bin whose leftover cannot fit a typical future item is effectively
wasted. Exact fits (residual 0) are still preferred via an override. Ties go to fuller bins.
"""
import numpy as np

CAP = 100
_P = 0.8
_TYP = 40                      # typical item size (distribution mean)
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight
# stranded penalty: a residual below _TYP wastes the leftover gap
_S = [0.0] * (CAP + 1)
for _g in range(1, CAP + 1):
    if _g < _TYP:
        _S[_g] = (CAP / _g) - 1.0
    else:
        _S[_g] = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            # weighted potential delta: -w_g*(2N[g]-1) + (w_r*(2N[r]+1) if r>0 else 0)
            delta = -_W[g] * (2 * _N[g] - 1)
            if r > 0:
                delta += _W[r] * (2 * _N[r] + 1)
            # stranded-residual penalty (added cost for leaving a tiny gap)
            stranded = _S[r] if r > 0 else 0.0
            # graded match bonus: reward residuals matching a more common open class
            match = _N[r] if r > 0 else 0
            # tie-break prefers fuller bins (smaller residual)
            scores[k] = -(delta * 100000.0 + match * 100.0 + stranded * 50.0 + r)
        r_new = CAP - s
        delta_new = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        match_new = _N[r_new] if r_new > 0 else 0
        stranded_new = _S[r_new] if r_new > 0 else 0.0
        scores[len(fitting):] = -(delta_new * 100000.0 + match_new * 100.0 + stranded_new * 50.0 + r_new)
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
