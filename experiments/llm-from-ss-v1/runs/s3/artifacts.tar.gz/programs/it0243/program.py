# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override and greedy-lookahead tie-break.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). When several candidate placements have
essentially the same potential delta, the rule breaks the tie by simulating a short greedy
best-fit packing of future items (drawn from a running histogram of observed sizes) on the
resulting residual multiset, preferring the placement that packs more of those samples into
the existing bins. This uses no future information.
"""
import numpy as np

CAP = 100
_P = 0.8
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight

# --- running histogram of observed item sizes for lookahead sampling ---
_HIST = np.zeros(CAP + 1, dtype=np.float64)
_SAMPLES = 24                  # number of sampled future items per candidate evaluation


def _pack_samples(residuals):
    """Greedy best-fit: pack sampled future items into a copy of `residuals`; return bins opened.

    residuals: list of positive remaining capacities (the existing open bins).
    Samples are drawn deterministically from the running histogram in a fixed pattern.
    """
    caps = list(residuals)
    total = _HIST.sum()
    if total <= 0:
        return 0
    opened = 0
    # fixed deterministic sample of sizes weighted by observed frequency
    for t in range(_SAMPLES):
        # cheap deterministic sampler: walk CDF at evenly spaced quantiles offset by t
        target = ((t + 0.5) / _SAMPLES) * total
        c = 0.0
        s = 1
        for g in range(1, CAP + 1):
            c += _HIST[g]
            if c >= target:
                s = g
                break
        # best fit into existing caps
        best = -1
        best_rem = CAP + 1
        for i, cap in enumerate(caps):
            if cap >= s and cap - s < best_rem:
                best_rem = cap - s
                best = i
        if best >= 0:
            caps[best] -= s
        else:
            opened += 1
    return opened


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # record observed item size for the lookahead histogram (before deciding)
    if s <= CAP:
        _HIST[s] += 1.0

    # Exact-fit override.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        n_fit = len(fitting)
        n_eval = n_fit + (1 if n_unused > 0 else 0)
        deltas = np.empty(n_eval, dtype=np.float64)
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -_W[g] * (2 * _N[g] - 1)
            if r > 0:
                delta += _W[r] * (2 * _N[r] + 1)
            deltas[k] = delta
        if n_unused > 0:
            r_new = CAP - s
            deltas[n_fit] = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        else:
            r_new = None

        # candidates within a small window of the best delta get a lookahead evaluation
        dmin = deltas[:n_eval].min()
        w_span = abs(dmin) * 0.5 + 1.0
        best_score = -1e18
        best_m = 0
        for m in range(n_eval):
            if deltas[m] > dmin + w_span:
                continue
            # build candidate residual multiset (cap the number of bins simulated)
            cand = []
            if n_fit:
                for j in fitting:
                    cand.append(_caps[j])
            cnt = 0
            for idx, cap in enumerate(cand):
                if idx == m:
                    cap -= s
                if cap > 0 and cnt < 60:
                    cand_out = cap
                    cnt += 1
            # rebuild properly with the substitution applied
            cand2 = []
            for idx, g in enumerate([_caps[j] for j in fitting]):
                if idx == m:
                    g -= s
                if g > 0:
                    cand2.append(g)
            if n_unused > 0 and m == n_fit:
                rr = CAP - s
                if rr > 0:
                    cand2.append(rr)
            packed = _pack_samples(cand2)
            # prefer fewer opened bins, then smaller delta
            score = -(packed * 1000.0) - deltas[m]
            if score > best_score:
                best_score = score
                best_m = m
        # fill scores, keeping ordering stable
        scores[:] = -1e18
        order = sorted(range(n_eval), key=lambda m: scores.__setitem__(m, 0) or m)
        for m in range(n_eval):
            scores[m] = 0.0
        scores[:] = 0.0
        # assign final score: chosen candidate gets 1, others 0
        scores[:] = 0.0
        scores[best_m] = 1.0
        choice = best_m

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
