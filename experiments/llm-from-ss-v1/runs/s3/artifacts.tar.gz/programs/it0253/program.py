# EVOLVE-BLOCK-START
"""Residual-resonance rule: place item to leave a residual that future items are likely to fill.

Items are Weibull-shaped with mean ~40. A bin's remaining capacity g is "useful" if it equals a
size that arriving items commonly take, because a later item landing exactly in g closes the bin.
We score each placement by the potential delta (sum over residual classes of (100/g)^p * N(g)^2)
plus a resonance bonus rewarding residuals that match likely future item sizes, with exact fits
dominating. Tie-break prefers fuller bins. The function only sees fitting bins, so it keeps its
own record of opened bins (used bins are always a prefix of the array).
"""
import numpy as np
from math import exp

CAP = 100
_P = 0.8
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight

# Resonance: probability mass of item sizes near each residual, from a Weibull(k=2, lambda~45)
# fit to mean ~40 (Weibull mean = lambda*Gamma(1+1/k) ~ 45*0.8862 ~ 39.9).
_K = 2.0
_LAM = 45.0
_res = [0.0] * (CAP + 1)
for _g in range(1, CAP + 1):
    # density of item size close to g (smoothing width of a few units)
    v = (0.5 * ((_g - 0.5) / _LAM) ** _K) - (0.5 * ((_g + 0.5) / _LAM) ** _K)
    _res[_g] = max(0.0, 1.0 - exp(v) if _g < CAP else 0.0)
# normalize resonance values
_sum = sum(_res) or 1.0
_res = [r / _sum for r in _res]


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: closing a bin is always at least as good as any other placement.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            # weighted potential delta: -w_g*(2N[g]-1) + (w_r*(2N[r]+1) if r>0 else 0)
            delta = -_W[g] * (2 * _N[g] - 1)
            if r > 0:
                delta += _W[r] * (2 * _N[r] + 1)
            # resonance bonus: reward residuals that future items are likely to fill exactly
            res = _res[r] if r > 0 else 0.0
            # tie-break prefers fuller bins (smaller residual)
            scores[k] = -(delta * 100000.0 - res * 300.0 + r)
        r_new = CAP - s
        delta_new = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        res_new = _res[r_new] if r_new > 0 else 0.0
        scores[len(fitting):] = -(delta_new * 100000.0 - res_new * 300.0 + r_new)
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
