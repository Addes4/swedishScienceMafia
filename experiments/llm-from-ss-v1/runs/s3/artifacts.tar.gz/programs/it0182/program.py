# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override, class-match tie-break,
and an expected-closure weighting derived from a running item-size histogram.

Each item goes where it minimises the potential P = sum_g w_g * N(g)^2, with the class weight
w_g = (100/g)^p scaled by a factor (1 + kappa * c_g) where c_g is the observed fraction of past
items that, if they arrived now, could almost close a bin of residual g (i.e. exactly fit g or
leave a small residual). This makes the rule prefer placements whose resulting residual classes
are more likely to be consumed by future items and thus actually close bins, while retaining the
robust sum-of-squares pairing mechanism. Exact fits are taken first; ties go to the placement
whose resulting residual matches an existing open class, then to the larger residual for pairing.
State is module-level and each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_P = 0.8
_KAPPA = 0.6
_HIST = [0.0] * (CAP + 1)      # smoothed counts of observed item sizes
_HIST_TOTAL = 0.0
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]


def _closure_score(g):
    """Estimate fraction of past items that would nearly close a bin of residual g."""
    if g <= 0 or _HIST_TOTAL <= 0.0:
        return 0.0
    # items s with s <= g and g - s small (residual after placement -> 0 or tiny)
    total = 0.0
    lo = max(1, g - 5)
    for s in range(lo, g + 1):
        total += _HIST[s]
    return total / _HIST_TOTAL


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _HIST, _HIST_TOTAL
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # exact-fit override
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            up = _W[g] * (1.0 + _KAPPA * _closure_score(g))
            delta = -up * (2 * _N[g] - 1)
            if r > 0:
                ur = _W[r] * (1.0 + _KAPPA * _closure_score(r))
                delta += ur * (2 * _N[r] + 1)
            match = (_N[r] >= 1) if r > 0 else False
            scores[k] = -(delta * 100000.0 + (1.0 if match else 0.0) * 100.0 + (CAP - r))
        r_new = CAP - s
        u_new = _W[r_new] * (1.0 + _KAPPA * _closure_score(r_new)) if r_new > 0 else 0.0
        delta_new = u_new * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        match_new = (_N[r_new] >= 1) if r_new > 0 else False
        scores[len(fitting):] = -(delta_new * 100000.0 + (1.0 if match_new else 0.0) * 100.0 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update running histogram (Laplace-smoothed) and recompute closure fractions lazily
    _HIST[s] += 1.0
    _HIST_TOTAL += 1.0

    return scores
# EVOLVE-BLOCK-END
