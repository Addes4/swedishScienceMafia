# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and complementary-residual tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin
is chosen instead, since closing a bin is always at least as good as any other placement. Ties
on the SoS delta are broken by preferring the resulting residual r that can pair well with
existing open residuals (maximizing complementary mass, i.e. sum of N[g] over g whose value
makes r+g == 100 or close), and then by smaller residual. The function keeps its own record of
every opened bin; used bins form a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _complement(r):
    """Heuristic: how much open-bin mass pairs well with a residual r."""
    if r <= 0:
        return 0.0
    total = 0
    # exact complement closes a future bin with a perfect fit
    c = CAP - r
    if 0 < c < CAP:
        total += 4 * _N[c]
    # near complements are still good (future item can merge two leftovers)
    for g in range(1, CAP):
        if _N[g]:
            d = abs((r + g) - CAP)
            if 0 < d <= 10:
                total += _N[g] * (2 if d <= 3 else 1)
    return float(total)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            # secondary: complementary mass of resulting residual; tertiary: smaller r
            comp = _complement(r)
            scores[k] = -(delta * 100000.0 + (100000.0 - comp) * 100.0 + (CAP - r))
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        comp_new = _complement(r_new)
        scores[len(fitting):] = -(delta_new * 100000.0 + (100000.0 - comp_new) * 100.0 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

