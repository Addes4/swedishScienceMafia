# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and distribution-aware tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin is chosen instead,
since closing a bin is always at least as good as any other placement. Ties on the SoS delta go to the
placement whose resulting residual is most likely to be exactly filled by a future item, according to
the fixed item distribution (Weibull-shaped, mean ~40), and then to the smaller residual. The function
keeps its own record of every opened bin; used bins are always a prefix of the bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Precompute a rough item-size distribution (Weibull shape 2, scale ~45 -> mean ~40).
_item_prob = [0.0] * (CAP + 1)

def _build_dist():
    xs = np.arange(1, CAP + 1, dtype=np.float64)
    shape = 1.8
    scale = 45.0
    # Weibull pdf on 1..100, renormalised over the integer range.
    pdf = (shape / scale) * (xs / scale) ** (shape - 1.0) * np.exp(-(xs / scale) ** shape)
    tot = pdf.sum()
    if tot <= 0:
        pdf = np.ones_like(xs) / len(xs)
    else:
        pdf = pdf / tot
    for idx, v in enumerate(pdf):
        _item_prob[idx + 1] = float(v)

_build_dist()
# Cumulative probability that some item is exactly r, used as a tie value.
_prob_exact = list(_item_prob)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            # secondary: likelihood a future item exactly fills the residual; tertiary: smaller r
            future = _prob_exact[r] if r > 0 else 1.0
            scores[k] = -(delta * 100000.0 - future * 100.0 + (CAP - r))
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        future_new = _prob_exact[r_new] if r_new > 0 else 1.0
        scores[len(fitting):] = -(delta_new * 100000.0 - future_new * 100.0 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
