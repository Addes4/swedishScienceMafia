# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and diversity tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin is chosen instead,
since closing a bin is always at least as good as any other placement. Ties on the SoS delta are broken
by a light deterministic pseudo-random rule seeded from a call counter, so ties resolve differently over
the instance instead of always committing to the same residual class. The function is shown only the bins
the item fits in, so it keeps its own record of every opened bin; used bins are always a prefix of the
bin array. Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_calls = 0
_rng_state = 0x9E3779B9


def _next_rand():
    global _rng_state
    # xorshift32
    x = _rng_state & 0xFFFFFFFF
    x ^= (x << 13) & 0xFFFFFFFF
    x ^= (x >> 17)
    x ^= (x << 5) & 0xFFFFFFFF
    _rng_state = x & 0xFFFFFFFF
    return _rng_state


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _calls, _rng_state
    s = int(item)
    _calls += 1
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # compute primary SoS delta for each candidate
        deltas = []
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            deltas.append((delta, k, r))
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        deltas.append((delta_new, -1, r_new))  # -1 marks unused bin option

        # primary: minimize delta. tie-break: deterministic pseudo-random among equal deltas
        best_delta = min(d[0] for d in deltas)
        candidates = [d for d in deltas if d[0] == best_delta]
        if len(candidates) == 1:
            chosen = candidates[0]
        else:
            chosen = candidates[_next_rand() % len(candidates)]

        scores[:] = 0.0
        delta_chosen, k_chosen, _ = chosen
        # Build scores consistent with the chosen candidate; encode primary as -delta.
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            scores[k] = -delta * 1000.0
        scores[len(fitting):] = -delta_new * 1000.0
        # ensure the chosen one wins
        if k_chosen == -1:
            scores[len(fitting):] = -delta_new * 1000.0 + 999.0
            choice = len(fitting)
        else:
            scores[k_chosen] = -best_delta * 1000.0 + 999.0
            choice = k_chosen

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
