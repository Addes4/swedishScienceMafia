# EVOLVE-BLOCK-START
"""Greedy minimisation of sum_g N(g)^2 with exact one-step objective tie-break.

Each item goes where it minimises sum_g N(g)^2 over open bins with residual 0<g<100, i.e. the
exact marginal change delta = -2*N[g] + 1 + (2*N[r] + 1 if r>0 else 0). When several placements
share the same minimal marginal SoS delta, the tie is broken by the actual resulting objective
value (one-step exact look-ahead), which captures the benefit of pairing/complementing residual
classes for the immediate future. The function is shown only the bins the item fits in, so it
keeps its own record of every opened bin. Each instance runs in a fresh process, so module-level
state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_S = 0                         # sum_g N(g)^2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _S
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: residual 0 always best (closes a bin, no new residual class).
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # resulting objective after placement, given the move (g -> r), r = g - s
        def obj_after(g, r):
            # remove one bin of class g, add one of class r (if r>0)
            val = _S
            if g > 0:
                val += -2 * _N[g] + 1
            if r > 0:
                val += 2 * _N[r] + 1
            return val

        best_k = -1
        best_delta = None
        best_obj = None
        best_r = None
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            obj = obj_after(g, r)
            better = False
            if best_k < 0:
                better = True
            elif delta < best_delta:
                better = True
            elif delta == best_delta:
                if obj < best_obj:
                    better = True
                elif obj == best_obj and r < best_r:
                    better = True
            if better:
                best_k = k
                best_delta = delta
                best_obj = obj
                best_r = r
        # unused bins
        r_new = CAP - s
        if n_unused > 0:
            delta_new = (2 * _N[r_new] + 1) if r_new > 0 else 0
            obj_new = obj_after(CAP, r_new)
            better = False
            if best_k < 0:
                better = True
            elif delta_new < best_delta:
                better = True
            elif delta_new == best_delta:
                if obj_new < best_obj:
                    better = True
                elif obj_new == best_obj and r_new < best_r:
                    better = True
            if better:
                best_k = len(fitting)
                best_delta = delta_new
                best_obj = obj_new
                best_r = r_new

        if best_k < 0:
            # should not happen (unused bins always present), fallback first bin
            best_k = 0
            best_delta = 0
            best_obj = 0
            best_r = 0

        scores[:] = -1.0
        scores[best_k] = 1.0
        if best_k < len(fitting):
            choice = best_k
        else:
            # pick an unused-bin slot
            choice = best_k

    # apply the move
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        r = g - s
        _S += -2 * _N[g] + 1
        _N[g] -= 1
        _caps[j] = r
        if r > 0:
            _S += 2 * _N[r] + 1
            _N[r] += 1
    elif n_unused > 0:
        r = CAP - s
        if r > 0:
            _S += 2 * _N[r] + 1
            _N[r] += 1
        _caps.append(r)
    return scores
# EVOLVE-BLOCK-END
