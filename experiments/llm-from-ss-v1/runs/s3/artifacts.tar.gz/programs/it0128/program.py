# EVOLVE-BLOCK-START
"""Best-Fit (tightest-fit) bin packing rule with a mild penalty on opening new bins.

Each arriving item goes into the fitting bin whose remaining capacity is smallest (i.e. the
placement that leaves the smallest residual). An exact fit (residual 0) always wins, closing
that bin. Unused bins all have remaining capacity 100, so they are only chosen when no
existing bin can beat them; a tiny penalty is added to unused bins so an existing bin with
the same resulting residual is preferred (avoids needless opening of fresh bins).

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin; used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_used = len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Best fit: maximise score = -(residual). Exact fit (residual 0) -> score 0.
    # Existing bins: score = -r, where r = g - s.
    for k, j in enumerate(fitting):
        r = _caps[j] - s
        scores[k] = -(float(r))

    # Unused bins: residual = CAP - s, but add a small penalty so a genuine existing
    # best-fit with the same residual is preferred.
    r_new = CAP - s
    scores[n_used:] = -(float(r_new)) - 1e-6

    choice = int(np.argmax(scores))

    if choice < n_used:
        j = fitting[choice]
        _caps[j] -= s
        if _caps[j] == 0:
            _caps.pop(j)
    else:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
