# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-class concentration tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Ties on the SoS delta are broken by preferring the placement that
reduces the number of distinct residual classes (concentrating mass makes future exact fills
more likely), then by the smaller residual. Used bins are always a prefix of the bin array,
so the function keeps its own record of every opened bin. Each instance runs in a fresh
process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # secondary: does this placement remove the source class g (and maybe create r)?
        removes_g = (_N[g] <= 1)
        match = (_N[r] >= 1) if r > 0 else False
        scores[k] = -(delta * 1000000.0
                      + (0.0 if match else 1.0) * 10000.0
                      + (0.0 if removes_g else 1.0) * 100.0
                      + (CAP - r))

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    match_new = (_N[r_new] >= 1) if r_new > 0 else False
    scores[len(fitting):] = -(delta_new * 1000000.0
                              + (0.0 if match_new else 1.0) * 10000.0
                              + (CAP - r_new))
    choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
