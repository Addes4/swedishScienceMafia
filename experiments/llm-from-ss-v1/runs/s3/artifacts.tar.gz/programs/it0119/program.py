# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and distribution-aware look-ahead tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin is chosen instead,
since closing a bin is always at least as good as any other placement. Ties on the SoS delta are broken
by a one-step look-ahead: we estimate the expected next-step SoS cost using the known item distribution
(Weibull-shaped, mean ~40), and prefer the candidate residual that minimises it. The function is shown
only the bins the item fits in, so it keeps its own record of every opened bin; used bins are always a
prefix of the bin array. Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Precompute a plausible item-size PMF (Weibull-shaped, mean ~40). We don't know the exact
# shape, but a discretised Weibull(k=2, lambda~45) capped to 1..100 approximates well enough
# that the look-ahead ordering is stable. Normalised over integer sizes 1..100.
def _build_pmf():
    # Discretised Weibull with shape 2, scale chosen so mean ~40.
    k, lam = 2.0, 45.0
    sizes = np.arange(1, CAP + 1, dtype=np.float64)
    # Weibull pdf on continuous size; approximate probability mass per integer size.
    pdf = (k / lam) * (sizes / lam) ** (k - 1.0) * np.exp(-(sizes / lam) ** k)
    pdf = np.maximum(pdf, 0.0)
    total = pdf.sum()
    if total <= 0:
        pdf[:] = 1.0
        total = pdf.sum()
    return pdf / total

_PMF = _build_pmf()
# Cumulative start/end for fast expectation over items that fit a residual r.
# For a look-ahead we only need expected SoS-cost deltas; precompute per-size weights.

def _expected_next_cost(N, pmf):
    """Return array E[r] = expected immediate SoS-delta of the optimal next placement,
    given current class counts N, for the class we just created at residual r.
    Precisely: given we have just moved counts to state N, compute for the resulting
    candidate the expected SoS increase of the best next item placement."""
    # This is expensive to do exactly; we approximate with a cheap surrogate:
    # expected delta of placing a random item s into the best-fitting class.
    # For each possible next item size s (with prob p_s), the best move places s into
    # a bin and creates residual r2 = g - s. The optimal-current SoS delta is
    # delta(s) = min_{g} [-2 N[g] + 1 + (2 N[g-s] + 1 if g-s>0 else 0)].
    # We approximate by ignoring the class we just changed (small effect) so this is O(100^2)/call.
    deltas = np.full(CAP + 1, 0.0)
    # Precompute N as array for speed
    narr = np.asarray(N, dtype=np.float64)
    for s in range(1, CAP + 1):
        ps = pmf[s - 1]
        if ps <= 0:
            continue
        # candidate g from s..CAP (need N[g] >0, but treat all as possible for smoothness)
        best = np.inf
        for g in range(s, CAP + 1):
            if narr[g] <= 0:
                continue
            r2 = g - s
            d = -2.0 * narr[g] + 1.0 + (2.0 * narr[r2] + 1.0 if r2 > 0 else 0.0)
            if d < best:
                best = d
        if best == np.inf:
            best = 1.0  # would open new bin; baseline delta
        deltas[s] = best * ps
    return deltas.sum()

def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # Gather candidates as (delta, is_existing_index or -1 for new).
        cands = []
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            cands.append((delta, k, j, g, r))
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        cands.append((delta_new, -1, -1, CAP, r_new))

        # Primary: minimal delta. Tie-break: distribution-aware look-ahead.
        # Compute look-ahead only among the delta-tied group to save time.
        best_delta = min(c[0] for c in cands)
        tied = [c for c in cands if c[0] == best_delta]

        if len(tied) == 1:
            chosen = tied[0]
        else:
            # For each tied candidate, simulate applying its move and evaluate expected next cost.
            best_val = None
            chosen = tied[0]
            for (delta, k, j, g, r) in tied:
                # Build a temporary N array copy reflecting this move.
                Nt = _N[:]  # list copy
                if j >= 0:
                    Nt[g] -= 1
                    if r > 0:
                        Nt[r] += 1
                else:
                    if r_new > 0:
                        Nt[r_new] += 1
                val = _expected_next_cost(Nt, _PMF)
                # Tiebreak secondary: prefer larger residual (keeps room), then smaller index.
                key = (val, -r)
                if best_val is None or key < best_val:
                    best_val = key
                    chosen = (delta, k, j, g, r)

        delta, k, j, g, r = chosen
        # Assign scores: give chosen max, others lower (must be strictly-ordered, no NaN).
        scores[:] = -(abs(delta) * 1e6 + 1.0)
        if j >= 0:
            scores[k] = 1.0
        else:
            # new bin: corresponds to one of the trailing unused positions.
            if n_unused > 0:
                scores[len(fitting)] = 1.0
            else:
                scores[0] = 1.0
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
