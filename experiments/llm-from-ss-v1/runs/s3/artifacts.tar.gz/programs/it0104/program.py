# EVOLVE-BLOCK-START
"""Sum-of-Squares rule (exact integer delta), with pooling and small-residual tie-breaks.

Each arriving item is placed to minimise the true change in C = sum_g N(g)^2, where N(g) counts
open bins (including full bins, class 0) with remaining capacity g. This is the classic
"sum of squares" / aggregation heuristic: keeping the residual-class counts flat tends to leave
well-matched pairs of holes for future items. Because a placement that exactly fills a bin moves
that bin into class 0 (a hole worth g is consumed) it is naturally favoured by the SoS delta,
so no magic override is needed. Ties on the SoS delta are broken by preferring the resulting
residual r with the largest N(r) (pool holes that future items may complement), then by the
smallest residual (best fit). The function sees only the bins the item fits in, so it keeps its
own record of every opened bin; used bins are always a prefix of the bin array, and each instance
runs in a fresh process (module state starts empty).
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 <= g <= CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    def key(g):
        """Exact SoS delta for placing into a bin with residual g, plus tie-break keys."""
        r = g - s
        # change in sum N(.)^2: remove a hole from class g, add one to class r
        delta = (-2 * _N[g] + 1) + (2 * _N[r] + 1)
        # tie-breaks: larger N[r] preferred (pool complements), then smaller r
        return -((delta * 1000000) + ((-_N[r]) * 1000) + (CAP - r))

    for k, j in enumerate(fitting):
        scores[k] = key(_caps[j])
    r_new = CAP - s
    delta_new = (2 * _N[r_new] + 1)
    new_key = -((delta_new * 1000000) + ((-_N[r_new]) * 1000) + (CAP - r_new))
    scores[len(fitting):] = new_key
    choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

