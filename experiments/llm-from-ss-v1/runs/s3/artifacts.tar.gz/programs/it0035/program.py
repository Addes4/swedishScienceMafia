# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and a "live residual" tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). The exact-fit override closes a bin whenever possible. Among
equal-SoS placements, ties prefer residuals that are already populated in the global
capacity-class histogram and, as a final refinement, avoid leaving tiny "dead" residuals
below a small threshold (default 10) that most future items cannot fit into.
"""
import numpy as np

CAP = 100
DEAD = 10                      # residuals below this are likely useless for future items
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            conc = _N[r] if r > 0 else 0
            live = 0 if (0 < r < DEAD) else 1
            scores[k] = -(delta * 1000000.0 + conc * 1000.0 + live * 100.0 + (CAP - r))
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        conc_new = _N[r_new] if r_new > 0 else 0
        live_new = 0 if (0 < r_new < DEAD) else 1
        scores[len(fitting):] = -(delta_new * 1000000.0 + conc_new * 1000.0 + live_new * 100.0 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
