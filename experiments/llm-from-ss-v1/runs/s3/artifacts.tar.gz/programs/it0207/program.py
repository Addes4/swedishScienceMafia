# EVOLVE-BLOCK-START
"""Best-fit rule with exact-fit override and a "closeability" bonus.

For each fitting bin we compute the residual r = remaining - item. A bin is scored by:
  - an exact fit (r == 0) is by far the best (closes a bin for free);
  - otherwise, larger scores go to smaller residuals (fuller bin first, classic best-fit),
    but we add a small bonus when r matches a size that has appeared often among recent items,
    since such a residual is likely to be exactly filled soon and close the bin.
A decaying histogram of past item sizes provides the recency signal. The function keeps its own
record of opened bins because it only sees the bins the item fits in.
"""
import numpy as np

CAP = 100
_caps = []          # remaining capacity of every opened bin, in bin-index order
_freq = np.zeros(CAP + 1, dtype=np.float64)   # decaying histogram of past item sizes
_DECAY = 0.995


def priority(item, bins):
    s = int(item)
    # decay history and record this item
    global _caps, _freq
    _freq *= _DECAY
    _freq[s] += 1.0

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    def score_res(r):
        # exact fit: huge reward
        if r == 0:
            return 1e12
        # base: prefer smaller residual (fuller bin first)
        base = -r * 1.0
        # closeability bonus: residual matches a recently common item size
        freq_r = _freq[r] if r <= CAP else 0.0
        # normalise by a soft cap so it stays a mild tie-break
        bonus = 50.0 * (freq_r / (1.0 + freq_r)) if freq_r > 0 else 0.0
        return base + bonus

    for k, j in enumerate(fitting):
        r = _caps[j] - s
        scores[k] = score_res(r)
    r_new = CAP - s
    scores[len(fitting):] = score_res(r_new)

    choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _caps[j] = g - s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END

