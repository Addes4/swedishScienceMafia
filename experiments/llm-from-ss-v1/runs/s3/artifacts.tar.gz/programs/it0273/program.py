# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override and graded tie-breaks.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). The weighting exponent p balances how much the
rule penalizes multiplying near-full residual classes versus counts of large-residual classes.
If a placement yields residual 0 (closing a bin exactly), that placement is chosen since closing a
bin is always at least as good. Ties on the potential delta prefer the placement whose resulting
residual matches a more common existing open class, then the fuller bin. The function keeps its own
record of every opened bin; used bins are a prefix of the bin array, and module state starts empty.
"""
import numpy as np

CAP = 100
_P = 0.8
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: any placement (existing bin or fresh unused bin) with residual 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos < 0 and n_unused > 0 and s == CAP:
        exact_pos = len(fitting)          # unused bin closed exactly (item == full capacity)

    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # Primary key: potential delta (negative = preferred). Folded with large, safe weights
        # so lexicographic order is preserved without float leakage between levels.
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -_W[g] * (2 * _N[g] - 1)
            if r > 0:
                delta += _W[r] * (2 * _N[r] + 1)
            match = _N[r] if r > 0 else 0
            scores[k] = -(delta * 1e6) + match * 1e3 - r
        r_new = CAP - s
        delta_new = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        match_new = _N[r_new] if r_new > 0 else 0
        scores[len(fitting):] = -(delta_new * 1e6) + match_new * 1e3 - r_new
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

