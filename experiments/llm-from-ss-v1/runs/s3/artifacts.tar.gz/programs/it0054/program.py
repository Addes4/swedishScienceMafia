# EVOLVE-BLOCK-START
"""Target-residual best-fit rule with SoS-delta and exact-fit override.

Each item goes into the fitting bin whose resulting residual r = g - s is closest to a
target residual t = alpha * s (alpha = 0.6). This biases towards leaving moderate free
space that statistically matches the arrival distribution's complementary structure,
avoiding both tight fragments (r near 0) and large gaps (r near 100). Ties on |r - t|
are broken by the classic SoS-delta (-2 N(g) + 1 + 2 N(r) + 1) which minimizes sum N(g)^2,
and further by preferring residuals that duplicate an existing open-bin residual class
(pairable) and finally by smaller r. Exact-fit (r == 0) always wins. The function keeps
its own record of opened bins; used bins form a prefix of the bin array, so the array is
consistent across calls. Module-level state starts empty per process.
"""
import numpy as np

CAP = 100
ALPHA = 0.6
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    target = ALPHA * s

    # Exact-fit override
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            # primary: closeness of resulting residual to target (want |r-t| small)
            dist = abs(r - target)
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            match = (_N[r] >= 1) if r > 0 else False
            scores[k] = -(
                dist * 1000000.0
                + (delta + 5) * 1000.0
                + (0.0 if match else 1.0) * 10.0
                + (CAP - r)
            )
        r_new = CAP - s
        dist_new = abs(r_new - target)
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        match_new = (_N[r_new] >= 1) if r_new > 0 else False
        scores[len(fitting):] = -(
            dist_new * 1000000.0
            + (delta_new + 5) * 1000.0
            + (0.0 if match_new else 1.0) * 10.0
            + (CAP - r_new)
        )
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
