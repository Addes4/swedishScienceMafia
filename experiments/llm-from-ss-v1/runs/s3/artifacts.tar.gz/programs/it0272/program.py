# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override and fuller-bin tie-break.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). The weighting exponent p balances how much the
rule penalizes multiplying near-full residual classes versus counts of large-residual classes.
If some fitting bin can take the item exactly (residual 0), that bin is chosen instead, since
closing a bin is always at least as good as any other placement. The comparison is done with a
clean lexicographic key (exact-fit, then potential delta, then a count-based match bonus, then
fuller bin) so no tie-break term can leak into the primary decision. The function is shown only
the bins the item fits in, so it keeps its own record of every opened bin; used bins are always a
prefix of the bin array. Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_P = 0.85
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    n = len(bins)
    scores = np.empty(n, dtype=np.float64)

    def key(exact, delta, match, r):
        # exact fits dominate; then smaller potential delta; then larger match; then fuller bin.
        return (-1.0 if exact else 0.0, -delta, match, -r)

    keys = []

    exact_pos = -1
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -_W[g] * (2 * _N[g] - 1)
        if r > 0:
            delta += _W[r] * (2 * _N[r] + 1)
        match = _N[r] if r > 0 else 0
        if r == 0 and exact_pos < 0:
            exact_pos = k
        keys.append(key(r == 0, delta, match, r))

    r_new = CAP - s
    delta_new = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
    match_new = _N[r_new] if r_new > 0 else 0
    key_new = key(False, delta_new, match_new, r_new)

    if exact_pos >= 0:
        # some fitting bin closes exactly; that is always best
        choice = exact_pos
        for k in range(len(fitting)):
            scores[k] = 1.0 if k == exact_pos else 0.0
        scores[len(fitting):] = 0.0
    else:
        # rank all fitting bins, then unused bins, by lexicographic key
        best = key_new
        choice = len(fitting)  # points into the unused region if it wins
        for k, kk in enumerate(keys):
            if kk > best:
                best = kk
                choice = k
        # encode scores so argmax reproduces the lexicographic winner
        for k in range(n):
            if k < len(fitting):
                scores[k] = 0.0
            else:
                scores[k] = 0.0
        if choice < len(fitting):
            scores[choice] = 1.0
        else:
            if n_unused > 0:
                scores[len(fitting)] = 1.0
            else:
                scores[0 if len(fitting) else 0] = 1.0
                choice = int(np.argmax([keys[k] for k in range(len(fitting))])) if fitting else 0

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    return scores
# EVOLVE-BLOCK-END

