# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override and robust argmax.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). The weighting exponent p balances how much the
rule penalizes multiplying near-full residual classes versus counts of large-residual classes.
If some fitting bin can take the item exactly (residual 0), that bin is chosen instead, since
closing a bin is always at least as good as any other placement. Among near-optimal placements
(within a small epsilon of the best potential delta), the rule prefers the placement whose
resulting residual matches a more common existing open class, then the fuller bin. The function
is shown only the bins the item fits in, so it keeps its own record of every opened bin; used bins
are always a prefix of the bin array.
"""
import numpy as np

CAP = 100
_P = 1.0
_EPS = 1e-9
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    nfit = len(fitting)

    scores = np.zeros(n, dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # compute best delta among fitting existing bins
        deltas = np.empty(nfit, dtype=np.float64)
        matches = np.empty(nfit, dtype=np.float64)
        residuals = np.empty(nfit, dtype=np.float64)
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -_W[g] * (2 * _N[g] - 1)
            if r > 0:
                delta += _W[r] * (2 * _N[r] + 1)
            deltas[k] = delta
            matches[k] = _N[r] if r > 0 else 0
            residuals[k] = r
        if nfit > 0:
            best = deltas.min()
            # near-optimal candidates
            cand = np.where(deltas <= best + _EPS)[0]
            # prefer higher match, then smaller residual, then earlier index
            bestk = cand[0]
            for k in cand:
                mk, rk = matches[k], residuals[k]
                mb, rb = matches[bestk], residuals[bestk]
                if mk > mb or (mk == mb and rk < rb):
                    bestk = k
            scores[bestk] = 1.0
            choice = int(bestk)
        else:
            choice = -1

        # unused bins
        r_new = CAP - s
        delta_new = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        match_new = _N[r_new] if r_new > 0 else 0
        if nfit == 0 or delta_new < best - _EPS:
            # unused bin strictly better: choose first unused
            scores[:] = 0.0
            scores[nfit] = 1.0
            choice = nfit
        elif nfit == 0:
            scores[:] = 0.0
            scores[nfit] = 1.0
            choice = nfit

    if choice < nfit and choice >= 0:
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        if n > nfit:
            _caps.append(CAP - s)
            if CAP - s > 0:
                _N[CAP - s] += 1
        else:
            # fallback: best fitting
            if nfit > 0:
                j = fitting[0]
                g = _caps[j]
                _N[g] -= 1
                _caps[j] = g - s
                if g - s > 0:
                    _N[g - s] += 1
    return scores
# EVOLVE-BLOCK-END

