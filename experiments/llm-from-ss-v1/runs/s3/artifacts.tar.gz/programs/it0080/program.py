# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with consolidation tie-break on equal SoS delta.

Primary key: change in sum_g N(g)^2 from placing the item. This is the classic
online heuristic that keeps the number of open residual classes balanced.
Exact-fit placements (residual 0) close a bin and always win.
Ties on the SoS delta are broken by a consolidation metric: prefer the placement
that minimizes the number of distinct nonzero residual classes (so future items can
exactly close the classes), then by the smaller residual.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _distinct_classes(N):
    c = 0
    for g in range(1, CAP):
        if N[g] > 0:
            c += 1
    return c


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: an existing fitting bin whose residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        base_distinct = _distinct_classes(_N)
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            # consolidation: change in number of distinct nonzero residual classes
            d_distinct = 0
            if _N[g] == 1:
                d_distinct -= 1
            if r > 0 and _N[r] == 0:
                d_distinct += 1
            scores[k] = -(delta * 1000000.0 + (d_distinct + 1) * 1000.0 + (CAP - r))
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        d_distinct_new = 1 if (r_new > 0 and _N[r_new] == 0) else 0
        scores[len(fitting):] = -(delta_new * 1000000.0 + (d_distinct_new + 1) * 1000.0 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

