# EVOLVE-BLOCK-START
"""Sum-of-Squares rule.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100); ties go to the tighter fit. The function is shown only the bins
the item fits in, so it keeps its own record of every opened bin. The harness opens unused
bins in index order (ties go to the first bin), so used bins are always a prefix of the bin
array. Each instance runs in a fresh process, so the module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    caps = _caps
    N = _N

    scores = np.empty(len(bins), dtype=np.float64)

    n_fit = 0
    j = 0
    m = len(caps)
    # iterate over known open bins, only those with g >= s fit
    for idx in range(m):
        g = caps[idx]
        if g >= s:
            r = g - s
            delta = -2 * N[g] + 1 + (2 * N[r] + 1 if r > 0 else 0)
            scores[n_fit] = -(delta * 1000 + r)
            n_fit += 1
        else:
            # moved past: keep scanning (caps not sorted), continue
            pass

    # unused bins (remaining capacity 100) are the tail of `bins`
    r_new = CAP - s
    delta_new = 2 * N[r_new] + 1 if r_new > 0 else 0
    if r_new > 0:
        scores[n_fit:] = -(delta_new * 1000 + r_new)
    else:
        scores[n_fit:] = -(delta_new * 1000)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score

    # apply the chosen placement to our own bookkeeping
    if choice < n_fit:
        # find the (choice)-th fitting bin
        cnt = 0
        for idx in range(m):
            g = caps[idx]
            if g >= s:
                if cnt == choice:
                    N[g] -= 1
                    nr = g - s
                    caps[idx] = nr
                    if nr > 0:
                        N[nr] += 1
                    break
                cnt += 1
    else:
        caps.append(CAP - s)
        if CAP - s > 0:
            N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
