# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and complementary-pair tie-break.

Each item goes where it minimises sum_g N(g)^2 over open bins with remaining capacity g (0<g<100).
An exact-fit bin (residual 0) is chosen preferentially since closing a bin is always good. When
several placements share the primary SoS delta, the tie-break prefers a placement whose resulting
residual r can be paired with an existing open class (a class g' with g'+r == CAP would let a
future item of that size close a bin), then to the smaller residual. The function keeps its own
record of opened bins; used bins form a prefix of the bin array. Module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _pair_bonus(r):
    """Higher is better: how useful residual r is for forming a closing complementary pair.

    If some open class g' has g' == CAP - r, a future item of size r closes that bin (very good).
    Otherwise use the SoS gain of placing an item of size r against the closest existing class.
    """
    if r <= 0:
        return 0
    comp = CAP - r
    if comp > 0 and _N[comp] > 0:
        return 2
    best = 0
    for g in range(1, CAP):
        if _N[g] and g + r <= CAP:
            d = _N[g] * _N[g] - ((_N[g] - 1) ** 2 + (1 if g + r < CAP else 0) + _N[r] ** 2 - (1 if g + r < CAP else 0) * 0)
            # simpler monotone proxy: closing a class reduces its square
            if g + r == CAP:
                best = max(best, 1)
    return best


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break

    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            bonus = _pair_bonus(r)
            scores[k] = -(delta * 100000.0 + (2.0 - bonus) * 100.0 + (CAP - r))
        r_new = CAP - s
        bonus_new = _pair_bonus(r_new)
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        scores[len(fitting):] = -(delta_new * 100000.0 + (2.0 - bonus_new) * 100.0 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

