# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override and distribution-aware weighting.

Each item goes where it minimises the potential P = sum_g w_g * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100) and w_g = (100/g)^p combines the value of
closing a near-full class with the empirical probability that an arriving item exactly equals g
(so leaving residuals that items actually consume is favored). p=1.2 balances count-multiplying
effects. If some fitting bin can take the item exactly (residual 0), that bin is chosen instead.
Ties on the potential delta go to the placement whose resulting residual matches a more common
existing open class (graded by count), and then to the bin leaving the smaller residual.
The function keeps its own record of every opened bin; used bins are always a prefix of the array.
"""
import numpy as np

CAP = 100
_P = 1.2
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = np.zeros(CAP + 1)      # observed item-size histogram
_n_items = 0


def _weight(g, N):
    """Weight for residual class g: (100/g)^p scaled by empirical exact-fill probability."""
    if g <= 0:
        return 0.0
    base = (CAP / g) ** _P
    if _n_items > 0:
        prob = _hist[g] / _n_items
        return base * (0.5 + 5.0 * prob)
    return base


def priority(item, bins):
    global _caps, _N, _hist, _n_items
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # update observed histogram
    _hist[s] += 1.0
    _n_items += 1

    # Exact-fit override.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            wg = _weight(g, _N)
            delta = -wg * (2 * _N[g] - 1)
            if r > 0:
                delta += _weight(r, _N) * (2 * _N[r] + 1)
            match = _N[r] if r > 0 else 0
            scores[k] = -(delta * 100000.0 + match * 100.0 + r)
        r_new = CAP - s
        delta_new = _weight(r_new, _N) * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        match_new = _N[r_new] if r_new > 0 else 0
        scores[len(fitting):] = -(delta_new * 100000.0 + match_new * 100.0 + r_new)
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
