# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and future-fit tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin is chosen instead,
since closing a bin is always at least as good as any other placement. Ties on the SoS delta are broken
by a "future-fit" score: how many open residual classes could be exactly filled by a later item equal to
the new residual plus that class's capacity, weighted by the empirical frequency of item sizes. This
favours leaving residuals that the distribution is likely to close exactly. The function is shown only
the bins the item fits in, so it keeps its own record of every opened bin; used bins are always a prefix
of the bin array. Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_H = [0.0] * (CAP + 1)         # empirical histogram of item sizes (smoothed)


def _future_fit(r, s):
    """Estimate likelihood that leaving residual r lets some open class be exactly filled later.

    For each open class g' (0 < g' < CAP), an item of size g'+r would exactly fill a bin of
    residual g'. Weight that by the empirical frequency of that item size. Rewards residuals
    that create complementary pairings likely to be realised by the distribution.
    """
    if r <= 0:
        return 0.0
    tot = 0.0
    for gp in range(1, CAP):
        if _N[gp]:
            need = gp + r
            if 1 <= need <= CAP:
                tot += _N[gp] * _H[need]
    return tot


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _H
    s = int(item)
    _H[s] += 1.0
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            ff = _future_fit(r, s)
            # primary SoS delta (larger is better => use negative), then future-fit, then best-fit
            scores[k] = -(delta * 1000.0) + ff * 1.0 + (CAP - r) * 1e-6
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        ff_new = _future_fit(r_new, s)
        scores[len(fitting):] = -(delta_new * 1000.0) + ff_new * 1.0 + (CAP - r_new) * 1e-6
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
