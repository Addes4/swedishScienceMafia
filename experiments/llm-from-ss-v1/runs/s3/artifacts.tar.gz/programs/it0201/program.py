# EVOLVE-BLOCK-START
"""Adaptive capacity-weighted sum-of-squares rule with exact-fit override.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). The weighting exponent p balances how much the
rule penalizes multiplying near-full residual classes versus counts of large-residual classes.
If some fitting bin can take the item exactly (residual 0), that bin is chosen instead, since
closing a bin is always at least as good as any other placement. Ties on the potential delta go to
the placement whose resulting residual matches a more common existing open class, and then to the
bin leaving the smaller residual (fuller bin first).

The exponent p is adapted online: several candidate exponents are run in parallel (shadow
simulations) and the one currently using the fewest bins is adopted for the real placement. This
adapts to the actual item stream instead of committing to a single fixed p. The function is shown
only the bins the item fits in, so each tracker keeps its own record of every opened bin; used bins
are always a prefix of the bin array. Each instance runs in a fresh process, so module-level state
starts empty.
"""
import numpy as np

CAP = 100
_P_CANDIDATES = (0.6, 0.8, 1.0, 1.2)
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Shadow trackers: for each candidate p, its own _caps and _N.
_shadow_caps = [[] for _ in _P_CANDIDATES]
_shadow_N = [[0] * (CAP + 1) for _ in _P_CANDIDATES]
_W_tables = [
    [((CAP / g) ** p) if g > 0 else 0.0 for g in range(CAP + 1)]
    for p in _P_CANDIDATES
]


def _delta_score(s, caps, N, W):
    """Return (scores_list, chosen_index) for the fitting bins in `caps` plus unused bins."""
    fitting = [j for j, g in enumerate(caps) if g >= s]
    n_unused = len(caps) - len(fitting)  # only used to size; real length handled by caller
    best_val = None
    best_idx = -1
    n_fit = len(fitting)
    for k, j in enumerate(fitting):
        g = caps[j]
        r = g - s
        delta = -W[g] * (2 * N[g] - 1)
        if r > 0:
            delta += W[r] * (2 * N[r] + 1)
        match = N[r] if r > 0 else 0
        val = -(delta * 100000.0 + match * 100.0 + r)
        if best_val is None or val > best_val:
            best_val = val
            best_idx = k
    return fitting, best_idx, best_val


def _place(s, caps, N, W, n_bins_available):
    """Choose a placement index into `caps` (or -1 meaning open a new bin) and update the tracker."""
    fitting = [j for j, g in enumerate(caps) if g >= s]
    # exact-fit override
    exact = -1
    for k, j in enumerate(fitting):
        if caps[j] == s:
            exact = k
            break
    if exact >= 0:
        j = fitting[exact]
        g = caps[j]
        N[g] -= 1
        caps[j] = g - s
        if g - s > 0:
            N[g - s] += 1
        return 0
    best_val = None
    best_k = -1
    for k, j in enumerate(fitting):
        g = caps[j]
        r = g - s
        delta = -W[g] * (2 * N[g] - 1)
        if r > 0:
            delta += W[r] * (2 * N[r] + 1)
        match = N[r] if r > 0 else 0
        val = -(delta * 100000.0 + match * 100.0 + r)
        if best_val is None or val > best_val:
            best_val = val
            best_k = k
    # new-bin option
    r_new = CAP - s
    delta_new = W[r_new] * (2 * N[r_new] + 1) if r_new > 0 else 0.0
    match_new = N[r_new] if r_new > 0 else 0
    val_new = -(delta_new * 100000.0 + match_new * 100.0 + r_new)
    if best_val is None or val_new > best_val:
        # open new bin
        caps.append(CAP - s)
        if CAP - s > 0:
            N[CAP - s] += 1
        return len(caps) - 1
    j = fitting[best_k]
    g = caps[j]
    N[g] -= 1
    caps[j] = g - s
    if g - s > 0:
        N[g - s] += 1
    return j


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)

    # --- run shadow trackers to pick the currently-best exponent ---
    for t in range(len(_P_CANDIDATES)):
        _place(s, _shadow_caps[t], _shadow_N[t], _W_tables[t], n_bins)

    best_t = 0
    best_len = len(_shadow_caps[0])
    for t in range(1, len(_P_CANDIDATES)):
        L = len(_shadow_caps[t])
        if L < best_len:
            best_len = L
            best_t = t
    W = _W_tables[best_t]

    # --- real placement using the chosen exponent ---
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(_caps)
    scores = np.empty(n_bins, dtype=np.float64)

    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
        return scores

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -W[g] * (2 * _N[g] - 1)
        if r > 0:
            delta += W[r] * (2 * _N[r] + 1)
        match = _N[r] if r > 0 else 0
        scores[k] = -(delta * 100000.0 + match * 100.0 + r)
    r_new = CAP - s
    delta_new = W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
    match_new = _N[r_new] if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 100000.0 + match_new * 100.0 + r_new)
    choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
