# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override and future-fit tie-break.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). The weighting exponent p balances how much the
rule penalizes multiplying near-full residual classes versus counts of large-residual classes.
If some fitting bin can take the item exactly (residual 0), that bin is chosen instead, since
closing a bin is always at least as good as any other placement.

Tie-breaks (after the potential delta) now use a "future-fit value" derived from an empirical
histogram of past item sizes: a resulting residual is more valuable if it equals a common item
size (likely to be closed exactly by a single future item) or is a sum of two common item sizes.
This nudges bins into residuals that are easy to consume exactly.

The function is shown only the bins the item fits in, so it keeps its own record of every opened
bin; used bins are always a prefix of the bin array. Each instance runs in a fresh process, so
module-level state starts empty.
"""
import numpy as np

CAP = 100
_P = 0.8
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight

# empirical item-size model: coarse histogram plus derived future-fit values
_BUCKET = 5                    # bucket width for the coarse histogram
_NBUCK = CAP // _BUCKET + 1
_hist = [0] * _NBUCK          # bucketed counts of past item sizes
_hist_total = 0
_ffv_cache = [0.0] * (CAP + 1)  # future-fit value per residual, recomputed occasionally
_cache_ok = False


def _bucket(s):
    b = s // _BUCKET
    if b >= _NBUCK:
        b = _NBUCK - 1
    return b


def _freq(s):
    """Estimated relative frequency of an item size s from the coarse histogram."""
    if s < 1 or s > CAP:
        return 0.0
    return (_hist[_bucket(s)] + 1.0) / (_hist_total + _NBUCK)


def _rebuild_ffv():
    """Future-fit value for each residual r: chance a single item or a pair of items fits r."""
    global _cache_ok, _ffv_cache
    # representative size of each bucket
    rep = [min(CAP, (b + 0.5) * _BUCKET) for b in range(_NBUCK)]
    freq = [( _hist[b] + 1.0) / (_hist_total + _NBUCK) for b in range(_NBUCK)]
    single = [0.0] * (CAP + 1)
    pair = [0.0] * (CAP + 1)
    for b in range(_NBUCK):
        s = int(rep[b])
        f = freq[b]
        if 1 <= s <= CAP:
            single[s] = max(single[s], f)
        for b2 in range(b, _NBUCK):
            s2 = int(rep[b2])
            t = s + s2
            if 1 <= t <= CAP:
                val = f * freq[b2]
                if val > pair[t]:
                    pair[t] = val
    for r in range(CAP + 1):
        _ffv_cache[r] = max(single[r], 0.5 * pair[r])
    _cache_ok = True


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _hist, _hist_total, _cache_ok
    s = int(item)

    # update the item-size histogram for future-fit scoring
    _hist[_bucket(s)] += 1
    _hist_total += 1
    _cache_ok = False

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        if not _cache_ok:
            _rebuild_ffv()
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            # weighted potential delta: -w_g*(2N[g]-1) + (w_r*(2N[r]+1) if r>0 else 0)
            delta = -_W[g] * (2 * _N[g] - 1)
            if r > 0:
                delta += _W[r] * (2 * _N[r] + 1)
            # graded match bonus: reward residuals matching a more common open class
            match = _N[r] if r > 0 else 0
            # future-fit bonus: reward residuals likely consumable exactly later
            ffv = _ffv_cache[r] if r > 0 else 0.0
            # tie-break prefers fuller bins (smaller residual)
            scores[k] = -(delta * 100000.0 + match * 100.0 + ffv * 50.0 + r)
        r_new = CAP - s
        delta_new = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        match_new = _N[r_new] if r_new > 0 else 0
        ffv_new = _ffv_cache[r_new] if r_new > 0 else 0.0
        scores[len(fitting):] = -(delta_new * 100000.0 + match_new * 100.0 + ffv_new * 50.0 + r_new)
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
