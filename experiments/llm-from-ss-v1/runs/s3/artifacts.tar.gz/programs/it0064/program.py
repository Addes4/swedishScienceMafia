# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and histogram-driven pairing tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). If some fitting bin can take the item exactly (residual 0, including a fresh bin for
item size 100), that bin is chosen instead, since closing a bin is always at least as good. Ties on the
SoS delta go to the placement whose resulting residual r best complements what we expect future items
to be: we estimate P(future item == 100-r) from the running empirical item-size histogram (with a
Laplace-style floor) and prefer the largest such probability, then the smaller residual. The function
is shown only the bins the item fits in, so it keeps its own record of every opened bin; used bins are
always a prefix of the bin array. Each instance runs in a fresh process, so module-level state starts
empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0] * (CAP + 1)        # observed item sizes (index 1..CAP)
_total = 0                     # total items observed so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _hist, _total
    s = int(item)
    _hist[s] += 1
    _total += 1

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: a fitting existing bin with residual 0, or (for s==CAP) a fresh bin.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos < 0 and s == CAP and n_unused > 0:
        exact_pos = len(fitting)
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # Laplace-smoothed probability estimate that a future item equals target.
        inv = 1.0 / (_total + CAP)
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            if r > 0:
                p = (_hist[CAP - r] + 1) * inv   # prob a future item exactly fills r
            else:
                p = 1.0
            scores[k] = -(delta * 1000000.0 + p * 1000.0 + (CAP - r))
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        if r_new > 0:
            p_new = (_hist[CAP - r_new] + 1) * inv
        else:
            p_new = 1.0
        scores[len(fitting):] = -(delta_new * 1000000.0 + p_new * 1000.0 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
