# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override and complement bonus.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). The weighting exponent p balances how much the
rule penalizes multiplying near-full residual classes versus counts of large-residual classes.
If some fitting bin can take the item exactly (residual 0), that bin is chosen instead, since
closing a bin is always at least as good as any other placement. As a soft secondary preference
(below the potential-delta ordering but above the raw residual tie-break), placements whose
resulting residual complements an existing open class are rewarded proportionally to that class's
count, since complementary pairs are the main mechanism for closing bins. Ties then go to the
smaller residual. State starts empty in each fresh process.
"""
import numpy as np

CAP = 100
_P = 0.8
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            # weighted potential delta: -w_g*(2N[g]-1) + (w_r*(2N[r]+1) if r>0 else 0)
            delta = -_W[g] * (2 * _N[g] - 1)
            if r > 0:
                delta += _W[r] * (2 * _N[r] + 1)
            match = (_N[r] >= 1) if r > 0 else False
            # complementary closure bonus: reward residuals that complement an open class
            comp = (CAP - r) if 0 < r < CAP else 0
            comp_bonus = _N[comp] if comp > 0 else 0
            scores[k] = -(delta * 100000.0
                          + (1.0 if match else 0.0) * 100.0
                          + comp_bonus * 10.0
                          + (CAP - r))
        r_new = CAP - s
        delta_new = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        match_new = (_N[r_new] >= 1) if r_new > 0 else False
        comp_new = (CAP - r_new) if 0 < r_new < CAP else 0
        comp_bonus_new = _N[comp_new] if comp_new > 0 else 0
        scores[len(fitting):] = -(delta_new * 100000.0
                                  + (1.0 if match_new else 0.0) * 100.0
                                  + comp_bonus_new * 10.0
                                  + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
