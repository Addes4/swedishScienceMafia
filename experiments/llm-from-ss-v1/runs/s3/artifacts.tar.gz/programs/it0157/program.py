# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override, residual-class-match tie-break, and a
two-step complementary-fit bonus.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). If some fitting bin can take the item exactly (residual 0), that
bin is chosen instead, since closing a bin is always at least as good as any other placement.
Ties on the SoS delta go to the placement whose resulting residual equals the residual of
another open bin (so future items can pair the two classes complementarily), and then to the
smaller residual. On top of this, a small two-step bonus rewards a placement whose residual r
can be paired with an existing bin of capacity r + t (for some item size t already seen), which
would enable a near-future exact-fit that the one-step delta cannot anticipate yet. The
function is shown only the bins the item fits in, so it keeps its own record of every opened
bin; used bins are always a prefix of the bin array. Each instance runs in a fresh process, so
module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_seen = [False] * (CAP + 1)    # item sizes seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _seen
    s = int(item)
    _seen[s] = True
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    def pair_bonus(r):
        # reward if residual r can complementarily pair with an existing class r + t
        if r <= 0:
            return 0.0
        best = 0
        for t in range(1, CAP - r + 1):
            if _seen[t] and _N[r + t] > 0:
                best = 1
                break
        return float(best)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            match = (_N[r] >= 2) if r > 0 else False
            bonus = pair_bonus(r)
            scores[k] = -(delta * 100000.0 + (1.0 if match else 0.0) * 100.0
                          + (CAP - r) - bonus * 0.5)
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        match_new = (_N[r_new] >= 1) if r_new > 0 else False
        bonus_new = pair_bonus(r_new)
        scores[len(fitting):] = -(delta_new * 100000.0 + (1.0 if match_new else 0.0) * 100.0
                                  + (CAP - r_new) - bonus_new * 0.5)
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
