# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override and histogram-aware tie-break.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). If some fitting bin can take the item exactly
(residual 0), that bin is chosen instead. Ties on the potential delta are broken by rewarding a
resulting residual that the observed item-size histogram says is likely to be closed later, then
by preferring the fuller bin (smaller residual). The function keeps its own record of every opened
bin and of the item sizes seen, since it is shown only the bins the item fits in.
"""
import numpy as np

CAP = 100
_P = 0.8
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight
_H = [0] * (CAP + 1)           # histogram of item sizes seen
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _H, _seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # update running item-size histogram
    _H[s] += 1
    _seen += 1

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        inv_seen = 1.0 / _seen
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -_W[g] * (2 * _N[g] - 1)
            if r > 0:
                delta += _W[r] * (2 * _N[r] + 1)
            # histogram bonus: reward residuals likely to be exactly closed later
            match = (_H[r] * inv_seen) if r > 0 else 0.0
            scores[k] = -(delta * 100000.0 + match * 1000.0 + r * 0.01)
        r_new = CAP - s
        delta_new = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        match_new = (_H[r_new] * inv_seen) if r_new > 0 else 0.0
        scores[len(fitting):] = -(delta_new * 100000.0 + match_new * 1000.0 + r_new * 0.01)
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
