# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with closure-aware tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Ties are broken toward residuals that are "closable": the residual r after placement
equals an existing open-bin capacity (N[r] > 0), or equals an exact fit possibility. The function keeps
its own record of every opened bin since it is only shown the fitting bins.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Candidate list: (is_existing, index_in_caps_or_None, residual, delta)
    # Exact fit first: residual 0 is always optimal.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos < 0 and CAP == s:
        exact_pos = len(fitting)
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1e18
        choice = exact_pos
    else:
        best_key = None
        choice = -1
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            # closure bonus: residual equals an existing open capacity or is a plausible size
            closable = 1 if (r > 0 and _N[r] > 0) else 0
            key = (delta, -closable, r)
            if best_key is None or key < best_key:
                best_key = key
                choice = k
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        closable_new = 1 if (r_new > 0 and _N[r_new] > 0) else 0
        key_new = (delta_new, -closable_new, r_new)
        if n_unused > 0 and (best_key is None or key_new < best_key):
            best_key = key_new
            choice = len(fitting)
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            closable = 1 if (r > 0 and _N[r] > 0) else 0
            scores[k] = -(delta * 1000.0 + (-closable) * 0.5 + r * 0.001)
        scores[len(fitting):] = -(delta_new * 1000.0 + (-closable_new) * 0.5 + r_new * 0.001)

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
