# EVOLVE-BLOCK-START
"""Exact post-move sum-of-squares rule with exact-fit override and merge tie-break.

Each item goes where it minimises sum_g N(g)^2 evaluated *after* the placement, where N(g)
counts open bins with remaining capacity g (0 < g < 100). If some fitting bin can take the
item exactly (resulting residual 0), that bin is chosen instead, since closing a bin is
always at least as good as any other placement. Ties on the exact SoS cost prefer the
placement whose resulting residual class is already the most populated (merging classes
helps future items fill them), then the smaller resulting residual. The function keeps its
own record of every opened bin; used bins are always a prefix of the bin array. Each
instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # Precompute base sum of squares over current open residual classes.
        base_sos = 0
        for g in range(1, CAP):
            c = _N[g]
            if c:
                base_sos += c * c

        def post_sos(g, r):
            # Exact SoS after removing one bin of class g and adding one of class r.
            d = 0
            cg = _N[g]
            d += (cg - 1) * (cg - 1) - cg * cg          # class g loses one
            if r > 0:
                cr = _N[r]
                if r == g:
                    # class g gained one back (net unchanged count): handled by cg term below
                    # net: cg -> cg  (remove then add), so cancel
                    d += 0
                else:
                    d += (cr + 1) * (cr + 1) - cr * cr
            return base_sos + d

        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            cost = post_sos(g, r)
            merge = _N[r] if r > 0 else 0
            scores[k] = -(cost * 100000.0 + (CAP - 1 - merge) * 100.0 + (CAP - r))
        r_new = CAP - s
        cost = post_sos(CAP, r_new)
        merge = _N[r_new] if r_new > 0 else 0
        scores[len(fitting):] = -(cost * 100000.0 + (CAP - 1 - merge) * 100.0 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
