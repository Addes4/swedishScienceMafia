# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit and complement-fit overrides.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). The weighting exponent p balances how much the
rule penalizes multiplying near-full residual classes versus counts of large-residual classes.
Two overrides fire before the potential comparison:
  (1) exact fit: some fitting bin's residual equals the item (closes a bin immediately);
  (2) complement fit: some fitting bin's residual equals a frequently-seen item size, so the bin
      is very likely closeable on a subsequent item.
Ties on the potential delta go to the placement whose resulting residual matches a more common
open class (graded by count), then to the bin leaving the smaller residual (fuller bin first).
The function is shown only the bins the item fits in, so it keeps its own record of every opened
bin; used bins are always a prefix of the bin array. Each instance runs in a fresh process, so
module-level state starts empty.
"""
import numpy as np

CAP = 100
_P = 0.8
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight
_ihist = [0] * (CAP + 1)       # running count of item sizes seen
_MIN_HITS = 20                 # an item size must be reasonably common to count as a target


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    _ihist[s] += 1

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    n_tot = len(bins)
    scores = np.empty(n_tot, dtype=np.float64)

    # Layer 1: exact-fit override (existing fitting bins).
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # Layer 2: complement-fit override. Prefer a fitting bin whose residual after placement
        # is itself a common item size, so it will likely be closed on the next matching item.
        best_comp = -1
        best_comp_hits = _MIN_HITS - 1
        for k, j in enumerate(fitting):
            r = _caps[j] - s
            if r > 0 and _ihist[r] > best_comp_hits:
                best_comp_hits = _ihist[r]
                best_comp = k
        # A brand-new bin's residual is CAP-s; also a plausible complement target.
        r_new = CAP - s
        new_comp_hits = _ihist[r_new] if r_new > 0 else 0

        if best_comp >= 0 and best_comp_hits >= new_comp_hits:
            scores[:] = 0.0
            scores[best_comp] = 1.0
            choice = best_comp
        else:
            # Layer 3: potential-delta primary key, with graded-match and fuller-bin tie-breaks.
            for k, j in enumerate(fitting):
                g = _caps[j]
                r = g - s
                delta = -_W[g] * (2 * _N[g] - 1)
                if r > 0:
                    delta += _W[r] * (2 * _N[r] + 1)
                match = _N[r] if r > 0 else 0
                scores[k] = -(delta * 1000.0 + match * 10.0 + r)
            delta_new = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
            match_new = _N[r_new] if r_new > 0 else 0
            scores[len(fitting):] = -(delta_new * 1000.0 + match_new * 10.0 + r_new)
            choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
