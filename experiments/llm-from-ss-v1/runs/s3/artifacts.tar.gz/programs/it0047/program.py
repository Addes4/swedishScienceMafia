# EVOLVE-BLOCK-START
"""Best-fit rule with exact-fit override and small-residual preference.

Each item goes into the fitting bin that leaves the smallest positive residual (best-fit),
which keeps bins tightly packed and tends to preserve large-capacity bins for large future
items. If some fitting bin can take the item exactly (residual 0), that bin is chosen, since
closing a bin is always at least as good as any other placement. The function is shown only the
bins the item fits in, so it keeps its own record of every opened bin; used bins are always a
prefix of the bin array. Each instance runs in a fresh process, so module-level state starts
empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            r = _caps[j] - s
            # prefer smaller residual (best-fit); residual 0 already handled above
            scores[k] = -(r if r > 0 else 0)
        r_new = CAP - s
        # new bins are last resort: only chosen when they beat all fitting bins
        scores[len(fitting):] = -(r_new) - 0.5 if r_new > 0 else -0.5
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _caps[j] = g - s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
