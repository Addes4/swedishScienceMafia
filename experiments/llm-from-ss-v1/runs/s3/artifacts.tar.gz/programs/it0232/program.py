# EVOLVE-BLOCK-START
"""Potential rule with empirical residual-usefulness weighting.

Each item goes where it minimises the potential P = sum_g u_g * N(g)^2, where N(g) counts open
bins with remaining capacity g (0 < g < 100) and u_g is a per-class weight measuring how valuable
a bin with residual g is. Unlike a fixed (100/g)^p weighting, u_g is estimated online from the
observed item-size histogram: a residual class is valuable when many arriving items are close to
its value, since a later item can then fit (or exactly fill) that bin. The weight combines the
empirical probability of an item of size g (exact fill) with a smoothing term favouring small
residuals. An exact-fit override is kept for closing bins, and ties go to the fuller bin.
Module state starts empty each process; used bins are always a prefix of the bin array.
"""
import numpy as np

CAP = 100
_MASK = 0xFFFFFFFF
_A = 0.0           # smoothing floor added to every weight
_cnt = [0] * (CAP + 1)   # observed item size counts
_tot = 0                 # total observed items
_caps = []               # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)     # N[g]: open bins with remaining capacity g


def _weight(g):
    """Value of a bin with residual g: empirical exact-fill probability plus a small-size term."""
    if g <= 0:
        return 0.0
    p = _cnt[g] / _tot if _tot > 0 else 0.0
    return _A + p + 0.002 * (CAP / g)


def priority(item, bins):
    global _caps, _N, _cnt, _tot
    s = int(item)
    _cnt[s] += 1
    _tot += 1

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            wg = _weight(g)
            delta = -wg * (2 * _N[g] - 1)
            if r > 0:
                delta += _weight(r) * (2 * _N[r] + 1)
            scores[k] = -(delta * 100000.0 + r)
        r_new = CAP - s
        if r_new > 0:
            delta_new = _weight(r_new) * (2 * _N[r_new] + 1)
        else:
            delta_new = 0.0
        scores[len(fitting):] = -(delta_new * 100000.0 + r_new)
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
