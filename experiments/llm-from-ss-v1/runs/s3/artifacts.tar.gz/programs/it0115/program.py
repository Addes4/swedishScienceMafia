# EVOLVE-BLOCK-START
"""Sum-of-Squares rule computed directly from the shown `bins`, with exact-fit override.

The harness hands us the remaining capacity of every bin the item fits in: unused bins have
capacity 100 and used bins have 1..99, all in bin-index order. So the fitting existing bins are
exactly the entries with value < 100, and we can count residual classes N[g] straight from the
array instead of maintaining a parallel mirror that could drift. Each placement changes
sum_g N(g)^2 by delta = -2*N[g] + 1 + (2*N[r]+1 if r>0), where r = g - item is the new residual.
We pick the placement with the smallest delta (exact fit gives r=0, the smallest possible delta),
breaking ties by the smaller resulting residual (true best-fit, which reduces fragmentation).
"""
import numpy as np

CAP = 100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = int(item)
    arr = np.asarray(bins)
    n = arr.shape[0]

    # Residual classes derived directly from the shown capacities (used bins: 1..99).
    counts = [0] * (CAP + 1)
    for g in arr.tolist():
        if 0 < g < CAP:
            counts[g] += 1

    scores = np.empty(n, dtype=np.float64)
    best_choice = -1
    best_key = None

    for j in range(n):
        g = int(arr[j])
        if g < s:
            scores[j] = -1e18
            continue
        r = g - s
        delta = -2 * counts[g] + 1 + (2 * counts[r] + 1 if 0 < r < CAP else 0)
        # primary: minimise delta; secondary: smaller positive residual (best fit)
        key = (delta, r if r > 0 else 0)
        scores[j] = -delta * 1000.0 - (r if r > 0 else 0)
        if best_key is None or key < best_key:
            best_key = key
            best_choice = j

    return scores
# EVOLVE-BLOCK-END
