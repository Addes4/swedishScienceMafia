# EVOLVE-BLOCK-START
"""Exact-fit override, then best-fit-style merge, then smallest residual.

Each arriving item is placed as follows:
1. If a bin can take it exactly (residual 0), use that bin (closing it is always good).
2. Otherwise prefer the placement whose resulting residual class already has the most open
   bins (N[r] largest) -- putting the item where its leftover joins a popular class keeps the
   number of distinct capacities small, which reliably reduces fragmentation.
3. Break remaining ties by the smaller resulting residual (classic best fit).

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin; used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = -1.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            # primary: bigger N[r] is better (merge into popular class)
            # secondary: smaller r is better (best fit)
            scores[k] = _N[r] * 1000.0 + (CAP - r)
        r_new = CAP - s
        scores[len(fitting):] = _N[r_new] * 1000.0 + (CAP - r_new)
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
