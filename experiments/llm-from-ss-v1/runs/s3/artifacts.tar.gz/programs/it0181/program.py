# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override and probabilistic fill bonus.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). The weighting exponent p balances how much
the rule penalizes multiplying near-full residual classes versus counts of large-residual classes.
If some fitting bin can take the item exactly (residual 0), that bin is chosen instead, since
closing a bin is always at least as good as any other placement. Ties on the potential delta go
to the placement whose resulting residual is most likely to be fillable by a future item, estimated
from a running histogram of past item sizes, then to the smaller residual. The function keeps its
own record of every opened bin; used bins are always a prefix of the bin array. Each instance runs
in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_P = 0.8
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight
_hist = [0] * (CAP + 1)        # histogram of past item sizes
_seen = 0                      # number of past items


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _hist, _seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # probability that a residual r will be exactly filled by some future item, from history
    if _seen > 0:
        fill_p = [_hist[r] if r > 0 else _seen for r in range(CAP + 1)]
    else:
        fill_p = [_seen for r in range(CAP + 1)]

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            # weighted potential delta: -w_g*(2N[g]-1) + (w_r*(2N[r]+1) if r>0 else 0)
            delta = -_W[g] * (2 * _N[g] - 1)
            if r > 0:
                delta += _W[r] * (2 * _N[r] + 1)
            bonus = fill_p[r] if r > 0 else _seen
            scores[k] = -(delta * 100000.0 + bonus * 0.1 + (CAP - r))
        r_new = CAP - s
        delta_new = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        bonus_new = fill_p[r_new] if r_new > 0 else _seen
        scores[len(fitting):] = -(delta_new * 100000.0 + bonus_new * 0.1 + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    _hist[s] += 1
    _seen += 1
    return scores
# EVOLVE-BLOCK-END
