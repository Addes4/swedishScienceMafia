# EVOLVE-BLOCK-START
"""Best-Fit bin packing rule with exact-fit override.

Among all bins the item fits in, choose the placement that leaves the smallest remaining
capacity (the "fullest" bin that still fits). This is the classic Best-Fit heuristic, which
performs very well on random item-size data. Because a zero residual after placement is the
smallest possible, the exact-fit case is automatically favoured, but we keep it explicit for
clarity and tie-break correctness (residual 0 is the best possible, since closing a bin is
always at least as good as any alternative).

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin; used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty.

Ties prefer the earliest bin index (handled by argmax). Unused bins all leave residual
CAP - item, so they are the natural last resort.
"""
import numpy as np

CAP = 100
_caps = []   # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps
    s = int(item)
    n = len(bins)

    # Residual (remaining capacity) after placing the item, per bin.
    # For the bins we've opened (a prefix of the array) use our record; the rest are unused.
    k_open = len(_caps)
    scores = np.empty(n, dtype=np.float64)

    # Existing bins: residual = current capacity - item.
    for j in range(min(k_open, n)):
        scores[j] = float(_caps[j] - s)
    # Unused bins: residual = CAP - item.
    if n > k_open:
        scores[k_open:] = float(CAP - s)

    # Best-Fit: smallest residual wins. Maximize negative residual.
    scores = -scores
    choice = int(np.argmax(scores))

    # Update our record of opened bins.
    if choice < k_open:
        _caps[choice] -= s
    else:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END

