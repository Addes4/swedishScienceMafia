# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override and parity-aware tie-break.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). The weighting exponent p balances how much the
rule penalizes multiplying near-full residual classes versus counts of large-residual classes.
If some fitting bin can take the item exactly (residual 0), that bin is chosen instead, since
closing a bin is always at least as good as any other placement. Among near-tied placements the
rule prefers the one whose resulting residual yields the largest reduction in the number of odd
counts (parity), which helps future items complete pairs into closed bins, and then the bin
leaving the smaller residual. The function is shown only the bins the item fits in, so it keeps
its own record of every opened bin; used bins are always a prefix of the bin array.
"""
import numpy as np

CAP = 100
_P = 0.8
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight


def _parity_gain(g_old, r_new):
    """Change in number of odd-count classes when a class loses one and another gains one."""
    gain = 0
    if g_old > 0:
        # removing one from g_old: odd -> even improves (-1), even -> odd worsens (+1)
        gain += -1 if (_N[g_old] % 2 == 1) else 1
    if r_new > 0:
        # adding one to r_new: even -> odd worsens (+1), odd -> even improves (-1)
        gain += 1 if (_N[r_new] % 2 == 0) else -1
    return -gain  # positive parity_gain = fewer odd classes (good)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -_W[g] * (2 * _N[g] - 1)
            if r > 0:
                delta += _W[r] * (2 * _N[r] + 1)
            parity = _parity_gain(g, r)
            scores[k] = -(delta * 100000.0 - parity * 1000.0 + r)
        r_new = CAP - s
        delta_new = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        parity_new = _parity_gain(0, r_new)
        scores[len(fitting):] = -(delta_new * 100000.0 - parity_new * 1000.0 + r_new)
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
