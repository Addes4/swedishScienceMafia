# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and complement/class tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin is chosen instead,
since closing a bin is always at least as good as any other placement. Ties on the SoS delta are broken
lexicographically: prefer the placement producing residual 0, then a residual r whose complement 100-r
is already an open class (so a future item can close the pair), then a smaller residual. The function is
shown only the bins the item fits in, so it keeps its own record of every opened bin; used bins are always
a prefix of the bin array. Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    n = len(bins)
    scores = np.empty(n, dtype=np.float64)

    # Precompute the SoS delta and tie-break keys for existing bins.
    deltas = [0] * len(fitting)
    exact = [False] * len(fitting)
    match = [False] * len(fitting)
    resid = [0] * len(fitting)
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        deltas[k] = delta
        exact[k] = (r == 0)
        match[k] = (r > 0) and (_N[r] > 0) and (_N[CAP - r] > 0)
        resid[k] = r

    # New-bin placement (if any unused bin exists).
    r_new = CAP - s
    delta_new = (2 * _N[r_new] + 1) if r_new > 0 else 0
    exact_new = (r_new == 0)
    match_new = (r_new > 0) and (_N[r_new] > 0) and (_N[CAP - r_new] > 0)

    if n_unused > 0:
        deltas.append(delta_new)
        exact.append(exact_new)
        match.append(match_new)
        resid.append(r_new)

    # Lexicographic ranking encoded into a single float with safe integer weights.
    # residual is in [0, 99], deltas are bounded by ~1e4 in the worst case.
    RMAX = 128.0
    for idx in range(n):
        if idx < len(deltas):
            d = deltas[idx]
            e = 1 if exact[idx] else 0
            m = 1 if match[idx] else 0
            r = resid[idx]
            key = (d * RMAX * 8.0) + (e * RMAX * 4.0) + (m * RMAX * 2.0) + r
            scores[idx] = -key
        else:
            scores[idx] = -1e18  # unreachable: only when idx>=len(deltas)

    choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
