# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override and lexicographic tie-breaks.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). The weighting exponent p balances how much the
rule penalizes multiplying near-full residual classes versus counts of large-residual classes.
If some fitting bin can take the item exactly (residual 0), that bin is chosen instead, since
closing a bin is always at least as good as any other placement. Genuine ties on the potential
delta go to the placement whose resulting residual matches a more common existing open class,
and then to the bin leaving the smaller residual (fuller bin first). The three keys are compared
lexicographically so the potential delta always dominates the tie-breakers. The function is shown
only the bins the item fits in, so it keeps its own record of every opened bin; used bins are
always a prefix of the bin array. Each instance runs in a fresh process, so module-level state
starts empty.
"""
import numpy as np

CAP = 100
_P = 0.8
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_W = [((CAP / g) ** _P) if g > 0 else 0.0 for g in range(CAP + 1)]  # class weight


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break

    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # Build lexicographic keys: (delta, -match, r). Smaller delta is better.
        keys = []
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -_W[g] * (2 * _N[g] - 1)
            if r > 0:
                delta += _W[r] * (2 * _N[r] + 1)
            match = _N[r] if r > 0 else 0
            keys.append((delta, -match, r, k))
        r_new = CAP - s
        delta_new = _W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        match_new = _N[r_new] if r_new > 0 else 0
        for k in range(len(fitting), len(bins)):
            keys.append((delta_new, -match_new, r_new, k))

        keys.sort()
        best = keys[0]
        choice_key = best[3]

        # Assign scores so argmax picks the lexicographically best bin.
        # Use rank-based scores: best gets highest score.
        scores[:] = 0.0
        # Recover: the chosen index
        choice = choice_key
        # Encode ranking: assign score by negation of rank (argmax picks smallest rank).
        for rank, key in enumerate(keys):
            scores[key[3]] = -float(rank)

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

