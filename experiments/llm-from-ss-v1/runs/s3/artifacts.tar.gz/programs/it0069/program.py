# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and residual-pairing tie-break.

Each item is placed in the bin that minimises the change in sum_g N(g)^2, where N(g) counts open
bins with remaining capacity g (0 < g < 100). If a fitting bin becomes exactly full, that bin is
chosen instead, since closing a bin is at least as good as any other placement. Ties on the SoS
delta are broken by preferring a resulting residual equal to the arriving item size (a symmetric
residual pair can then recur and later be closed exactly), then by the smaller residual. The
function is shown only the bins the item fits in, so it keeps its own record of every opened bin;
used bins are always a prefix of the bin array. Each instance runs in a fresh process, so
module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # Scale factor: keep the primary comparison meaningful even when many bins are open.
        denom = float(len(fitting) + 1)
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            tie = (0.0 if r == s else 1.0) if r > 0 else 0.0
            scores[k] = -(delta / denom * 1000.0 + tie * 10.0 + (CAP - r) * 0.001)
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        tie_new = (0.0 if r_new == s else 1.0) if r_new > 0 else 0.0
        scores[len(fitting):] = -(delta_new / denom * 1000.0 + tie_new * 10.0 + (CAP - r_new) * 0.001)
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

