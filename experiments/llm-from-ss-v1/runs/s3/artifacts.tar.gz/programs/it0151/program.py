# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with Best-Fit tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among placements achieving the minimal SoS delta, the one leaving
the smallest resulting residual is chosen (Best-Fit), which consolidates leftover space into
reusable classes instead of fragmenting it. Opening a new bin is treated as a placement into
a capacity-100 bin, so it is naturally penalised when a tight existing fit exists. Ties in
both keys go to the first bin. The function is shown only the bins the item fits in, so it
keeps its own record of every opened bin; used bins are always a prefix of the bin array.
Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)

    # Score for a placement that changes residual from g to r = g - s:
    #   primary  = -delta (bigger is better), delta = -2*N[g] + 1 + (2*N[r] + 1 if r>0 else 0)
    #   secondary = -r (Best-Fit: smaller resulting residual is better)
    # Encoded so that one unit of delta dominates all secondary differences.
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -delta * 1000.0 - r

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -delta_new * 1000.0 - r_new

    choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

