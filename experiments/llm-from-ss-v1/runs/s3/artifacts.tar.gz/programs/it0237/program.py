# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override and data-driven class weights.

Placement minimises a potential P = sum_g w(g) * N(g)^2 over open residual classes g (0<g<100),
where w(g) blends the capacity scaling (100/g)^p with the observed likelihood that an item of
size g arrives (which would close such a bin). Exact residual-0 placements win outright. Ties go
to the residual matching a more common open class, then to the fuller bin. State is rebuilt fresh
per instance; used bins always form a prefix of the shown array.
"""
import numpy as np

CAP = 100
_P = 0.8
_hist = np.ones(CAP + 1, dtype=np.float64)   # smoothed observed item-size counts
_total = float(CAP)                          # total observed items (= sum of _hist - prior)
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _weight(g):
    if g <= 0:
        return 0.0
    base = (CAP / g) ** _P
    prob = _hist[g] / _total
    return base * (1.0 + 4.0 * prob)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _total
    s = int(item)
    _hist[s] += 1.0
    _total += 1.0

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)
    W = [_weight(g) for g in range(CAP + 1)]

    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -W[g] * (2 * _N[g] - 1)
            if r > 0:
                delta += W[r] * (2 * _N[r] + 1)
            match = _N[r] if r > 0 else 0
            scores[k] = -(delta * 100000.0 + match * 100.0 + r)
        r_new = CAP - s
        delta_new = W[r_new] * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        match_new = _N[r_new] if r_new > 0 else 0
        scores[len(fitting):] = -(delta_new * 100000.0 + match_new * 100.0 + r_new)
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
