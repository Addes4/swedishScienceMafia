# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and residual-class-match tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin is chosen instead,
since closing a bin is always at least as good as any other placement. Ties on the SoS delta go to the
placement whose resulting residual equals the residual of another open bin (so future items can pair
the two classes complementarily), and then to the smaller residual. The function is shown only the bins
the item fits in, so it keeps its own record of every opened bin; used bins are always a prefix of the
bin array. Each instance runs in a fresh process, so module-level state starts empty.

The hot path is vectorized with numpy: `_caps` is a growable numpy array and the per-call work is done
with array operations rather than a Python loop over fitting bins.
"""
import numpy as np

CAP = 100
_caps = np.empty(0, dtype=np.int64)   # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)                  # N[g]: open bins with remaining capacity g, 0 < g < CAP
_Narr = np.zeros(CAP + 1, dtype=np.int64)  # mirror of _N for vectorized lookups


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _Narr
    s = int(item)
    n_total = len(bins)

    fit_mask = _caps >= s
    fit_idx = np.nonzero(fit_mask)[0]
    n_fit = fit_idx.size
    n_unused = n_total - n_fit
    scores = np.empty(n_total, dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    if n_fit:
        gfit = _caps[fit_idx]
        exact_rel = np.nonzero(gfit == s)[0]
    else:
        exact_rel = np.empty(0, dtype=np.int64)

    if exact_rel.size:
        scores[:] = 0.0
        scores[exact_rel[0]] = 1.0
        choice = int(exact_rel[0])
    else:
        if n_fit:
            g = _caps[fit_idx]
            r = g - s
            nr = _Narr[r]
            delta = -2 * _Narr[g] + 1 + np.where(r > 0, 2 * nr + 1, 0)
            match = np.where(r > 0, nr >= 2, False)
            scores[:n_fit] = -(delta * 100000.0 + match.astype(np.float64) * 100.0
                               + (CAP - r).astype(np.float64))
        r_new = CAP - s
        if r_new > 0:
            delta_new = 2 * _Narr[r_new] + 1
            match_new = _Narr[r_new] >= 1
        else:
            delta_new = 0
            match_new = False
        scores[n_fit:] = -(delta_new * 100000.0 + (100.0 if match_new else 0.0)
                           + (CAP - r_new))
        choice = int(np.argmax(scores))

    if choice < n_fit:
        j = int(fit_idx[choice])
        g = int(_caps[j])
        _N[g] -= 1
        _Narr[g] -= 1
        r = g - s
        _caps[j] = r
        if r > 0:
            _N[r] += 1
            _Narr[r] += 1
    elif n_unused > 0:
        r = CAP - s
        _caps = np.append(_caps, r)
        if r > 0:
            _N[r] += 1
            _Narr[r] += 1
    return scores
# EVOLVE-BLOCK-END

