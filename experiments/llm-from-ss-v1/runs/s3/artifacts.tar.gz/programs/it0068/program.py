# EVOLVE-BLOCK-START
"""Best-fit with complement-pairing priority.

Each item goes to the fitting bin that leaves the smallest residual (best fit), which packs tightly.
Before that, any bin that can take the item exactly (residual 0) is preferred, since closing a bin is
strictly beneficial. Among non-exact placements the tie-break prefers a residual r whose complement
(100 - r) already exists as an open bin class, so a future item can pair the two classes exactly.
The function is shown only the bins the item fits in, so it keeps its own record of every opened bin;
used bins are always a prefix of the bin array. Each instance runs in a fresh process, so module-level
state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: existing fitting bin whose residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # Best-fit with complement pairing. Primary key = smallest residual r (best fit).
        # Boost when the complement class 100-r already has an open bin, enabling a future exact pair.
        for k, j in enumerate(fitting):
            r = _caps[j] - s
            comp = CAP - r
            boost = 1.0 if (r > 0 and comp <= CAP and _N[comp] >= 1) else 0.0
            scores[k] = -(r - boost * 50.0)
        r_new = CAP - s
        comp_new = CAP - r_new
        boost_new = 1.0 if (r_new > 0 and comp_new <= CAP and _N[comp_new] >= 1) else 0.0
        scores[len(fitting):] = -(r_new - boost_new * 50.0)
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

