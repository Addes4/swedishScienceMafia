# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and a clean lexicographic tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin
is chosen instead, since closing a bin is always at least as good as any other placement.

Among placements with equal SoS delta, ties are broken lexicographically (no float scaling):
prefer leaving a residual whose capacity class is already populated (concentration), then prefer
the smaller positive residual. The function is shown only the bins the item fits in, so it keeps
its own record of every opened bin. The harness opens unused bins in index order (ties go to the
first bin), so used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        # Build a lexicographic key per placement: (delta, -concentration, residual_for_tiebreak)
        def key(delta, r):
            conc = _N[r] if r > 0 else 0
            # prefer populated class (larger conc first) -> negative, then smaller r
            return (delta, -conc, r)

        keys = []
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            keys.append(key(delta, r))
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        new_key = key(delta_new, r_new)

        best_val = None
        best_pos = 0
        for k, kv in enumerate(keys):
            if best_val is None or kv < best_val:
                best_val = kv
                best_pos = k
        if new_key < best_val:
            best_pos = len(fitting)

        scores[:] = 0.0
        scores[best_pos] = 1.0
        choice = best_pos

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
