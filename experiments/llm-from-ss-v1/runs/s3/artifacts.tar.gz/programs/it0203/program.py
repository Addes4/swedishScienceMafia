# EVOLVE-BLOCK-START
"""Best-fit rule: place each item in the fullest bin it still fits in.

For every fitting bin, the resulting residual is r = (remaining capacity) - item. Placing in
the bin with the smallest r minimizes wasted space in that bin, which is exactly the classic
Best-Fit heuristic. Exact fits (r == 0) are therefore chosen automatically. Ties on r go to the
placement whose resulting residual matches a more common existing open class, to encourage
grouping equal residuals (which makes future exact fits more likely). The function sees only the
bins the item fits in, and used bins form a prefix of the bin array, so module-level state starts
empty each instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Existing fitting bins: prefer smallest residual, tie-break on common residual class.
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        match = _N[r] if r > 0 else 0
        scores[k] = -(r * 100000.0 + match)

    # Unused bins all yield the same residual CAP - s.
    r_new = CAP - s
    match_new = _N[r_new] if r_new > 0 else 0
    scores[len(fitting):] = -(r_new * 100000.0 + match_new)

    choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
