# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and distribution-aware tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). If some fitting bin can take the item exactly (residual 0), that bin is chosen instead,
since closing a bin is always at least as good as any other placement. Ties on the SoS delta are broken
by a distribution-aware expected-exact-fill estimate: among candidates with equal delta, prefer the
resulting residual r that has the highest probability mass of a single future item exactly filling it,
computed from the known Weibull(mean~40) item size distribution precomputed as an array. The function
keeps its own record of every opened bin; used bins are always a prefix of the bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Precompute a proxy for the item size distribution: Weibull with mean ~40.
# We model P(size == k) using a discretised Weibull shape (k=1..100).
def _build_pmf():
    shape = 2.0
    # mean = scale * Gamma(1 + 1/shape); choose scale so mean ~ 40
    from math import gamma
    scale = 40.0 / gamma(1.0 + 1.0 / shape)
    pmf = np.zeros(CAP + 1, dtype=np.float64)
    for k in range(1, CAP + 1):
        x = (k + 0.5) / scale
        x0 = (k - 0.5) / scale
        pmf[k] = (x ** (shape - 1.0)) * np.exp(-(x ** shape)) - (x0 ** (shape - 1.0)) * np.exp(-(x0 ** shape))
    pmf = np.clip(pmf, 0.0, None)
    tot = pmf.sum()
    if tot > 0:
        pmf /= tot
    return pmf

_PMF = _build_pmf()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: only when an existing fitting bin's residual after placement is 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            # secondary: distribution-aware exact-fill probability of residual r
            fill_score = _PMF[r] if r > 0 else 1.0
            scores[k] = -(delta * 100000.0) + fill_score * 1000.0 + (CAP - r) * 0.001
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        fill_new = _PMF[r_new] if r_new > 0 else 1.0
        scores[len(fitting):] = -(delta_new * 100000.0) + fill_new * 1000.0 + (CAP - r_new) * 0.001
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
