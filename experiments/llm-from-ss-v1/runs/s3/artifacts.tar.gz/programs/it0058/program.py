# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit override and complementarity tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). If some fitting bin can take the item exactly (residual 0), that
bin is chosen instead, since closing a bin is always at least as good as any other placement.
Ties on the SoS delta go to the placement whose resulting residual r (r>0) has open complement
bins (residual CAP-r present), so two classes can pair up to fill each other; then to the
smaller residual. Used bins are always a prefix of the bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact-fit override: existing fitting bin with residual 0.
    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        def key(r):
            # r: resulting residual of this placement (may be 0 for exact fit on new? no)
            delta = 0
            # primary: SoS change handled outside
            return r

        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            comp = _N[CAP - r] if r > 0 else 0
            keyv = delta * 1000000.0 - comp * 1000.0 + (CAP - r)
            scores[k] = -keyv
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        comp_new = _N[CAP - r_new] if r_new > 0 else 0
        keyv = delta_new * 1000000.0 - comp_new * 1000.0 + (CAP - r_new)
        scores[len(fitting):] = -keyv
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
