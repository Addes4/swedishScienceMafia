# EVOLVE-BLOCK-START
"""Capacity-weighted sum-of-squares rule with exact-fit override and fuller-bin tie-break.

Each item goes where it minimises the potential P = sum_g (100/g)^p * N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). The weighting exponent p balances how much the
rule penalizes multiplying near-full residual classes versus counts of large-residual classes.
Small residuals are clipped so their large (100/g) weights do not dominate placement decisions.
If some fitting bin can take the item exactly (residual 0), that bin is chosen. Ties on the
potential delta go to the placement whose resulting residual matches a more common existing open
class, then to the bin leaving the smaller residual (fuller bin first). The function keeps its own
record of every opened bin; used bins are always a prefix of the bin array.
"""
import numpy as np

CAP = 100
_P = 0.8
_MIN_R = 8                     # clip: residuals below this treated as if this size
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _w(g):
    if g <= 0:
        return 0.0
    gg = g if g >= _MIN_R else _MIN_R
    return (CAP / gg) ** _P


def _wres(r):
    # reward residuals large enough to accept more future items: small residuals are
    # treated as if slightly larger so the rule does not overvalue creating them
    if r <= 0:
        return 0.0
    rr = r if r >= _MIN_R else _MIN_R
    return (CAP / rr) ** _P


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    exact_pos = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_pos = k
            break
    if exact_pos >= 0:
        scores[:] = 0.0
        scores[exact_pos] = 1.0
        choice = exact_pos
    else:
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -_w(g) * (2 * _N[g] - 1)
            if r > 0:
                delta += _wres(r) * (2 * _N[r] + 1)
            match = _N[r] if r > 0 else 0
            scores[k] = -(delta * 100000.0 + match * 100.0 + r)
        r_new = CAP - s
        delta_new = _wres(r_new) * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
        match_new = _N[r_new] if r_new > 0 else 0
        scores[len(fitting):] = -(delta_new * 100000.0 + match_new * 100.0 + r_new)
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
