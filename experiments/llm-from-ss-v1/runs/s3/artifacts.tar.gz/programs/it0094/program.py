# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with one-step expected-cost tie-break.

Each item goes where it minimises a two-part key: (1) the immediate sum_g N(g)^2 delta,
and (2) the expected minimum SoS delta over the next item, estimated from the empirical
distribution of item sizes seen so far (plus a small prior over the fixed Weibull-shaped
distribution). Fallbacks use best-fit. The function is shown only the bins the item fits
in, so it keeps its own record of every opened bin; used bins are always a prefix of the
bin array. Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0] * (CAP + 1)        # empirical item-size histogram (index 1..100)
_seen = 0

# Representative next-item sizes for the lookahead (typical of a mean-40 Weibull shape).
_PROBE_SIZES = (5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 80, 90)


def _sos_delta(g, r):
    """Change in sum N(g)^2 from removing a bin of capacity g and adding capacity r."""
    d = -2 * _N[g] + 1
    if r > 0:
        d += 2 * _N[r] + 1
    return d


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist, _seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    n_bins = len(bins)
    scores = np.empty(n_bins, dtype=np.float64)

    # Probability weights for probe sizes from empirical history plus an even prior.
    weights = []
    for p in _PROBE_SIZES:
        c = _hist[p] if p < len(_hist) else 0
        weights.append((c + 1.0) / (_seen + len(_PROBE_SIZES)))
    wtot = sum(weights) or 1.0

    def lookahead_term(g, r):
        """Expected best SoS delta for a random next item after state change (g->r)."""
        # Apply tentative state change to _N.
        _N[g] -= 1
        if r > 0:
            _N[r] += 1
        acc = 0.0
        for p, w in zip(_PROBE_SIZES, weights):
            if p > CAP:
                continue
            best = None
            # existing bins: those with current capacity >= p (excluding the just-changed one ideally,
            # but we approximate using updated _N counts).
            for gg in range(p, CAP + 1):
                cnt = _N[gg]
                if cnt <= 0:
                    continue
                d = _sos_delta(gg, gg - p)
                if best is None or d < best:
                    best = d
            # new bin option
            if best is None:
                best = 0
            # approximate: weigh by probability that such an option exists (skip exact correction)
            acc += w * best
        # revert
        if r > 0:
            _N[r] -= 1
        _N[g] += 1
        return acc / wtot

    # Existing fitting bins.
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        key1 = _sos_delta(g, r) * 1e6
        key2 = lookahead_term(g, r) * 1e3
        key3 = (CAP - r)  # best-fit fallback (smaller residual preferred)
        scores[k] = -(key1 + key2 + key3)

    # Unused bins: state change is 100 -> (100-s) effectively (opening a fresh bin).
    r_new = CAP - s
    key1 = 0.0
    if r_new > 0:
        key1 = 2 * _N[r_new] + 1
    key2 = lookahead_term(CAP, r_new) * 1e3
    key3 = (CAP - r_new)
    scores[len(fitting):] = -(key1 * 1e6 + key2 + key3)

    choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    _hist[s] += 1
    _seen += 1
    return scores
# EVOLVE-BLOCK-END
