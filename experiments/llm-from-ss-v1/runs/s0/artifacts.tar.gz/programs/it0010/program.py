# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with mild perfect-fit and best-fit bias.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), which is known to
be asymptotically optimal for this kind of online bin packing. Ties are broken by preferring
a perfect fit (residual 0) and then the tighter fit, using tiny weights so the SS ordering is
not disturbed. The function is shown only the bins the item fits in, so it keeps its own
record of every opened bin. Used bins are a prefix of the bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n = len(bins)
    scores = np.empty(n, dtype=np.float64)

    best_ss = None
    # Evaluate SS delta for every fitting bin, plus the new-bin option.
    ds = []
    for k in range(n):
        if k < len(_caps):
            g = _caps[k]
            if g < s:
                ds.append(None)
                continue
        else:
            g = CAP
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        ds.append(delta)
        if best_ss is None or delta < best_ss:
            best_ss = delta

    for k in range(n):
        delta = ds[k]
        if delta is None:
            scores[k] = -1.0e18
            continue
        # SS term dominant; small bonuses: perfect fit and tighter residual.
        if k < len(_caps):
            g = _caps[k]
        else:
            g = CAP
        r = g - s
        bonus = 0.0
        if r == 0:
            bonus += 0.5
        scores[k] = -(delta) * 1000.0 + bonus - r * 1e-3

    choice = int(np.argmax(scores))
    if choice < len(_caps):
        g = _caps[choice]
        _N[g] -= 1
        _caps[choice] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

