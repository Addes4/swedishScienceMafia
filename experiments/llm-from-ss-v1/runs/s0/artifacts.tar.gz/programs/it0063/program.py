# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with perfect-fit prioritisation and frequency-aware tie-break.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), known to be
asymptotically optimal for online bin packing. Ties and near-ties are broken by preferring a
perfect fit (residual 0) and, failing that, by favouring residuals that match frequently seen
item sizes (so future items can fill them exactly). The function keeps its own record of every
opened bin, since it is shown only the bins the item fits in. Used bins form a prefix of the
bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0.0] * (CAP + 1)      # decayed frequency of item sizes seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _freq
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Decay then record this item's size.
    for i in range(1, CAP + 1):
        _freq[i] *= 0.999
    _freq[s] += 1.0

    # Prefer perfect fits: find if any fitting bin has residual 0.
    perfect_exists = any(_caps[j] == s for j in fitting)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        if r == 0:
            base = -1.0e9
        else:
            base = float(delta)
        # small frequency-aware bonus for residuals that match common sizes
        freq_bonus = _freq[r] if r > 0 else 0.0
        scores[k] = -(base * 1000.0 + r - 0.5 * freq_bonus)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        scores[len(fitting):] = -1.0e12
    else:
        freq_bonus_new = _freq[r_new] if r_new > 0 else 0.0
        scores[len(fitting):] = -(float(delta_new) * 1000.0 + r_new - 0.5 * freq_bonus_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
