# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a bounded perfect-fit / near-fit bonus.

Each item goes to the bin that minimises the sum-of-squares cost change (the SS rule), which
is asymptotically optimal for online bin packing of i.i.d. items. The exact SS cost change is
used as the primary key. A small bounded bonus is added for residuals that exactly match a
recently observed item size (likely to be filled exactly soon) and for perfect fits. The
function is shown only fitting bins, so it keeps its own record of every opened bin.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_seen = [0] * (CAP + 1)        # counts of recently seen item sizes (decayed)
_seen_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _seen, _seen_total
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Decayed counts of recently seen item sizes -> probable future item sizes.
    _seen_total *= 0.995
    _seen[s] += 1.0
    _seen_total += 1.0

    # Prefer perfect fits.
    perfect_exists = any(_caps[j] == s for j in fitting)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        base = float(delta)
        # Small bounded bonus: perfect fit top priority; then residual matching a recent size.
        if r == 0:
            bonus = 1.0
        elif r <= CAP and _seen[r] > 0:
            bonus = 0.25 * (_seen[r] / _seen_total)
        else:
            bonus = 0.0
        scores[k] = -(base - bonus)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        scores[len(fitting):] = -1.0e12
    else:
        scores[len(fitting):] = -float(delta_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
