# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a scale-aware perfect-fit bonus.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), which is known to
be asymptotically optimal for this kind of online bin packing. A residual-0 placement gets a
bounded bonus proportional to the current spread of the SS deltas, so it wins unless its SS
cost is substantially worse than the best alternative. The function is shown only the bins the
item fits in, so it keeps its own record of every opened bin. Used bins are a prefix of the bin
array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)

    deltas = []
    for j in fitting:
        g = _caps[j]
        r = g - s
        d = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        deltas.append((j, g, r, d))

    r_new = CAP - s
    d_new = -2 * _N[CAP] + 1 + (2 * _N[r_new] + 1 if r_new > 0 else 0)

    all_d = [d for (_, _, _, d) in deltas] + [d_new]
    spread = max(all_d) - min(all_d)
    # Bonus bounded by the observed spread: a perfect fit wins unless its SS cost is clearly
    # worse than the best alternative (a fraction-of-spread margin).
    bonus = spread * 0.75 + 1.0

    scores = np.empty(len(bins), dtype=np.float64)
    for k, (j, g, r, d) in enumerate(deltas):
        base = float(d) - (bonus if r == 0 else 0.0)
        scores[k] = -(base * 1000.0 + r)
    base_new = float(d_new) - (bonus if r_new == 0 else 0.0)
    scores[len(fitting):] = -(base_new * 1000.0 + r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
