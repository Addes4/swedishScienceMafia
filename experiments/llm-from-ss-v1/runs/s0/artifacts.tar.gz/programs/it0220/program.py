# EVOLVE-BLOCK-START
"""Softened Sum-of-Squares rule.

Classic SS: place the item where the change in sum_g N(g)^2 is most negative, which for
placement into a bin with residual g leaving residual r = g - s is
    delta = 2*N(r) + 1 - (2*N(g) + 1)   (with N(0)-terms dropped off the end).
The exact integer delta has coarse granularity: many placements tie. Instead we score with
a softened, strictly monotone surrogate of the quadratic cost:
    cost(a, b) = h(a) - h(b) for placing residual a=g into residual b=r,
    h(x) = x^p  with p slightly below 2 (so h is sub-quadratic),
which preserves the "consolidate into already-populated classes" pressure of SS while
giving finer-grained comparisons among placements. A small residual tie-break keeps
flexible free space when costs are very close. We track opened bins ourselves since the
function only sees the fitting bins.
"""
import numpy as np

CAP = 100
P = 1.85                        # sub-quadratic exponent, softer than 2
_caps = []                      # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)            # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _h(x):
    return float(x) ** P


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # softened SS delta (negative = good); add tiny residual tie-break
        delta = _h(_N[r]) - _h(_N[g]) if r > 0 else -_h(_N[g])
        scores[k] = -(delta * 1000.0 - r)

    r_new = CAP - s
    delta_new = _h(_N[r_new]) if r_new > 0 else 0.0
    scores[len(fitting):] = -(delta_new * 1000.0 - r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
