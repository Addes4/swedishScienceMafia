# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-matching tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule, asymptotically optimal for
online bin packing). Among placements with equal SS cost change, we prefer placements whose
resulting residual equals the size of a currently open bin (enabling a future exact fill),
then the tightest fit. The function is shown only the bins the item fits in, so it keeps its
own record of every opened bin. Used bins are a prefix of the bin array; each instance runs
in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_seen_sizes = [False] * (CAP + 1)  # sizes observed so far (for residual matching)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _seen_sizes
    s = int(item)
    _seen_sizes[s] = True

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    perfect_exists = any(_caps[j] == s for j in fitting)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # Exact SS cost change from moving this item into a bin of remaining g.
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        if r == 0:
            base = -1.0e9                      # perfect fit dominates
        elif _seen_sizes[r] and _N[r] > 0:
            base = float(delta) - 0.5          # residual matches an open capacity: bonus
        else:
            base = float(delta)
        scores[k] = -(base * 1000.0 + r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        scores[len(fitting):] = -1.0e12        # discourage opening when a perfect fit exists
    else:
        scores[len(fitting):] = -(float(delta_new) * 1000.0 + r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
