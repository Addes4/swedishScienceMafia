# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with adaptive perfect-fit prioritisation.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), which is known to
be asymptotically optimal for this kind of online bin packing. A perfect fit (residual 0) is
given a bounded, moderate bonus rather than an overwhelming hard preference, so a clearly
better SS move can still win and fragmentation is limited. A small extra bonus rewards
residuals matching a frequently seen item size, which builds usably-fillable gaps. The
function keeps its own record of every opened bin. Used bins are a prefix of the bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_seen = [0] * (CAP + 1)        # how often each item size has been seen

PERFECT_BONUS = 5000.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _seen
    s = int(item)
    _seen[s] += 1

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # SS delta dominates; residual breaks near-ties; perfect fit gets a bounded bonus.
        base = float(delta)
        score = -(base * 1000.0 + r)
        if r == 0:
            score += PERFECT_BONUS
        elif _seen[r] > 0:
            # reward residuals that some already-seen item size can fill exactly
            score += min(_seen[r], 10) * 5.0
        scores[k] = score

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    new_score = -(float(delta_new) * 1000.0 + r_new)
    if n_unused > 0:
        scores[len(fitting):] = new_score
    if len(fitting) == 0:
        # no fitting used bin exists; scores must leave at least one option positive; all equal
        pass

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
