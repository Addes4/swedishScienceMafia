# EVOLVE-BLOCK-START
"""Bounded sum-of-squares (subharmonic) bin-choice rule.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. We use the *bounded* variant where the per-bin delta is
clipped to a fixed magnitude, which is known to keep the good asymptotic behaviour while
reducing variance / over-reacting to heavily loaded capacity classes. The clipped delta is an
exact integer so it stays the dominant criterion; among placements with equal clipped delta we
prefer the placement that leaves the larger residual, keeping flexible free space available for
future large items. The function is shown only the bins the item fits in, so it keeps its own
record of every opened bin.
"""
import numpy as np

CAP = 100
BOUND = 40
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _clip_delta(raw):
    if raw > BOUND:
        return BOUND
    if raw < -BOUND:
        return -BOUND
    return raw


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        raw = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        delta = _clip_delta(raw)
        # Dominant: clipped SS delta (as large negative as possible).
        # Tie-break: prefer the larger residual (more flexible free space).
        scores[k] = -(float(delta) * 1000.0 - r)

    r_new = CAP - s
    raw_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    delta_new = _clip_delta(raw_new)
    scores[len(fitting):] = -(float(delta_new) * 1000.0 - r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
