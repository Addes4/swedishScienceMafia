# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with complementary-fit tie-breaking.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), which is
asymptotically optimal for this kind of online bin packing. Ties in the SS delta are broken by
preferring a residual that matches the most frequent item size seen so far (a complementary-fit
signal), and failing that by the tighter fit. The function is shown only the bins the item fits
in, so it keeps its own record of every opened bin. Used bins are a prefix of the bin array;
each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # empirical count of arriving item sizes


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _freq
    s = int(item)
    _freq[s] += 1

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Perfect fit gets top priority (asymptotically optimal to take it).
    perfect_exists = any(_caps[j] == s for j in fitting)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        if r == 0:
            base = -1.0e9
        else:
            base = float(delta)
        # Tie-break key: prefer residual that is a common future item size, then tighter fit.
        comp = _freq[r] if r > 0 else 0
        scores[k] = -(base * 100000.0 - comp * 100.0 + r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        scores[len(fitting):] = -1.0e12
    else:
        comp_new = _freq[r_new] if r_new > 0 else 0
        scores[len(fitting):] = -(float(delta_new) * 100000.0 - comp_new * 100.0 + r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

