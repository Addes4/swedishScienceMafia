# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a "useless small residual" tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion. Among placements with equal SS delta we prefer the placement that keeps
the fewest unusably-small residual slots: a bin whose residual drops below a running estimate
of the typical item size is (nearly) dead weight, wasting a whole bin.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_sum = 0.0                     # running sum of item sizes
_cnt = 0                       # running count of items


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _sum, _cnt
    s = int(item)
    _sum += s
    _cnt += 1
    # Running estimate of a "typical" item size (mean so far, clamped to >=1).
    tau = _sum / _cnt
    if tau < 1.0:
        tau = 1.0

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Secondary: count residuals that become/become-not "useless" (< tau).
        # We want to avoid increasing the number of sub-tau residuals.
        before = 1 if g < tau else 0
        after = 1 if r < tau else 0
        useless_delta = after - before  # +1 worsens, -1 improves
        scores[k] = -(float(delta) * 1000.0 + float(useless_delta))

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    after_new = 1 if r_new < tau else 0
    scores[len(fitting):] = -(float(delta_new) * 1000.0 + float(after_new))

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
