# EVOLVE-BLOCK-START
"""Best-fit primary rule with SS tie-break.

Best-fit (smallest resulting residual) is a strong classic heuristic for this
distribution, packing tightly and avoiding fragmentation. Pure best-fit can be
suboptimal asymptotically, so among placements whose residual is equal we break
ties using the SS delta (the asymptotically-optimal sum-of-squares criterion).
The function keeps its own record of every opened bin because it is only shown
the bins the item fits in. Used bins form a prefix of the bin array; each
instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Primary: best-fit (small residual -> large score).
        # Secondary: prefer the more negative (better) SS delta on ties.
        scores[k] = -(float(r) * 1000.0 - delta)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(float(r_new) * 1000.0 - delta_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    return scores
# EVOLVE-BLOCK-END
