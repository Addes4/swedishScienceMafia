# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a fit-quality tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion. Among placements with equal SS delta we prefer the placement whose
resulting residual is most "fillable", i.e. most likely to be exactly matched by a future
item. We approximate fillability by rewarding residuals that are close to a common item size
(the distribution is Weibull-shaped with mean ~40). Used bins form a prefix of the bin array;
each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Precompute a "fillability" score for every residual 0..CAP. Residuals equal to a typical
# item size (mean ~40, spread out to ~70) are the most likely to be exactly matched later.
_FILL = np.zeros(CAP + 1, dtype=np.float64)
for _r in range(CAP + 1):
    _FILL[_r] = np.exp(-((_r - 40.0) ** 2) / (2.0 * 18.0 ** 2))


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta (as large negative as possible).
        # Tie-break: prefer the more fillable residual.
        scores[k] = -(float(delta) * 1000.0 - _FILL[r])

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(float(delta_new) * 1000.0 - _FILL[r_new])

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

