# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with flexibility-preserving tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer and is the dominant
criterion. Among placements with equal SS delta we prefer the placement that leaves the larger
residual, keeping flexible free space for future large items. The tie-break only activates on
exact delta ties, so it never overrides the asymptotically-optimal SS ordering.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    deltas = []
    residuals = []
    for j in fitting:
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        deltas.append(delta)
        residuals.append(r)
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0

    # Scale so residual tie-break only matters when deltas are exactly equal:
    # deltas are integers, so an offset < 1 per unit delta guarantees ordering by delta.
    # Residual lies in [0, 99], so use 1/128 as the residual weight.
    W = 1.0 / 128.0

    for k in range(len(fitting)):
        scores[k] = -(deltas[k]) + W * residuals[k]

    for k in range(n_unused):
        scores[len(fitting) + k] = -(delta_new) + W * r_new

    choice = int(np.argmax(scores))          # first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
