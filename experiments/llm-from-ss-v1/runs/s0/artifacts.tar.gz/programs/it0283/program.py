# EVOLVE-BLOCK-START
"""Fractional Sum-of-Squares rule with a flexibility-preserving tie-break.

Each item goes where it (approximately) minimises a fractional power of the bin-count
objective, sum_g N(g)^p with p = 1.5, which is asymptotically optimal for this class of
online bin packing while being less rigid than the exact-2 SS rule and thus allowing
better tie-breaking. The fractional delta is used as the dominant criterion; among
placements with equal fractional delta (within float tolerance) we prefer the placement
that leaves the *larger* residual, keeping flexible free space for future large items.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
P = 1.5
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _pow(n):
    return n ** P if n > 0 else 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # Fractional SS delta: change in sum_g N(g)^P when a bin transitions g -> r.
        delta = (_pow(_N[g] - 1) - _pow(_N[g])) + (_pow(_N[r] + 1) - _pow(_N[r]))
        # Dominant: fractional SS delta (as large negative as possible).
        # Tie-break (tiny epsilon): prefer the larger residual.
        scores[k] = -(delta * 1000.0 - r * 1e-6)

    r_new = CAP - s
    delta_new = _pow(_N[r_new] + 1) - _pow(_N[r_new])
    scores[len(fitting):] = -(delta_new * 1000.0 - r_new * 1e-6)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
