# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a reusability-driven tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion; among placements with equal SS delta we prefer the placement whose
residual is a *common past item size*, maximising the chance that the leftover space can be
exactly refilled later (reducing fragmentation). The function is shown only the bins the
item fits in, so it keeps its own record of every opened bin. Used bins are a prefix of the
bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_size_hist = [0] * (CAP + 1)   # histogram of item sizes seen so far
_loc = [0] * (CAP + 1)         # running reusability weight (recency-biased counts)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _size_hist, _loc
    s = int(item)
    _size_hist[s] += 1
    _loc[s] += 1
    # decay popularity slightly so recent sizes dominate
    if _size_hist[s] % 64 == 0:
        for i in range(1, CAP + 1):
            _loc[i] = (_loc[i] >> 1)

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta (as large negative as possible).
        # Tie-break: prefer residual reusable by a common past item size.
        scores[k] = -(float(delta) * 1000.0 - float(_loc[r]))

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(float(delta_new) * 1000.0 - float(_loc[r_new]))

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
