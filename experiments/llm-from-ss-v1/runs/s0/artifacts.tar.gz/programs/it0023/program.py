# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with perfect-fit prioritisation.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), which is known to
be asymptotically optimal for this kind of online bin packing. Ties and near-ties are broken
by preferring a perfect fit (residual 0) and, failing that, the tighter fit. The function is
shown only the bins the item fits in, so it keeps its own record of every opened bin. Used
bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_seen = [0] * (CAP + 1)        # whether an item of size g has been observed
_min_seen = CAP + 1            # smallest item size seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _min_seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Prefer perfect fits: find if any fitting bin has residual 0.
    perfect_exists = any(_caps[j] == s for j in fitting)

    # residual-matching target: smallest size seen so far (likely to appear again)
    target = _min_seen if _min_seen <= CAP else -1

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # High-order: perfect fit gets top priority; then SS delta; then tighter fit.
        if r == 0:
            base = -1.0e9
        else:
            base = float(delta)
        # Small bonus if residual matches the smallest seen item (fillable later).
        match_bonus = 1 if (target > 0 and r == target) else 0
        scores[k] = -(base * 1000.0 + r) + match_bonus * 500.0

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        # Discourage opening a new bin when a perfect fit exists.
        scores[len(fitting):] = -1.0e12
    else:
        scores[len(fitting):] = -(float(delta_new) * 1000.0 + r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update seen statistics
    if not _seen[s]:
        _seen[s] = 1
        if s < _min_seen:
            _min_seen = s
    return scores
# EVOLVE-BLOCK-END
