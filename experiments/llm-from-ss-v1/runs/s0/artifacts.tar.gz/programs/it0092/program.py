# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a smooth capacity-value tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for online bin packing. The exact SS delta is the dominant term of the score. Ties and
near-ties are broken smoothly by a capacity-value term that slightly prefers placements whose
resulting residual keeps more usable space (so bins are packed in a balanced, consolidating
way) without ever overriding the SS ordering. The function is shown only the bins the item
fits in, so it keeps its own record of every opened bin.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

EPS = 1.0e-3                   # small weight for the smooth tie-break


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    scores = np.empty(len(bins), dtype=np.float64)

    # Bins the item fits in are exactly those with record g >= s; they are a prefix in order.
    # The harness only shows fitting bins plus unused bins (remaining 100). Unused bins have
    # no record entry (g == CAP == 100 >= s always), so we identify fitting recorded bins.
    n_rec = len(_caps)
    n_shown = len(bins)
    n_unused = n_shown - n_rec if n_shown > n_rec else 0

    for j in range(n_rec):
        g = _caps[j]
        r = g - s
        if r < 0:
            scores[j] = -1.0e18     # shouldn't happen (not shown), but never chosen
            continue
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Smooth tie-break: mildly prefer larger residual (more usable leftover space).
        scores[j] = delta + EPS * r

    # Unused bins: opening a new bin.
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    for j in range(n_rec, n_shown):
        scores[j] = delta_new + EPS * r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < n_rec:
        j = choice
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

