# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a best-fit tie-break inside equal SS deltas.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion; among placements with equal SS delta we prefer the *smaller* residual
(classic best fit), i.e. pack as tightly as possible without violating the SS objective.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)

    n_show = len(bins)
    scores = np.empty(n_show, dtype=np.float64)

    # Walk the shown bins directly using our own capacity record. The shown array is a
    # prefix of bin indices (fits) followed by unused bins, all with capacity CAP.
    n_used = len(_caps)
    for j in range(n_used):
        g = _caps[j]
        if g >= s:
            r = g - s
            # Primary: exact SS delta (negative = fewer high-count bins; choose most negative).
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            # Secondary: best fit -> smaller residual preferred.
            scores[j] = -(float(delta) * 1000.0 + r)
        else:
            scores[j] = -1e18  # never selected (item does not fit)
    for j in range(n_used, n_show):
        r_new = CAP - s
        # Opening a new bin: residual after placing s.
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        scores[j] = -(float(delta_new) * 1000.0 + r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < n_used and _caps[choice] >= s:
        g = _caps[choice]
        _N[g] -= 1
        _caps[choice] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif choice >= n_used:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
