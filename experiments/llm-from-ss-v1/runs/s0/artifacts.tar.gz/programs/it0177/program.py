# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a fragmentation-sensitive tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion. Among placements with equal SS delta we break ties by a fragmentation
penalty over the open-bin residual multiset: residuals that can no longer fit a typical item
(large) and tiny unusable residuals (small) are penalised, so the tie-break steers placement
towards keeping a pool of moderately-sized residuals. The function keeps its own record of
every opened bin because it only sees the bins the item fits in. Used bins form a prefix of
the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
MEAN = 40
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_Nopen = [0]                   # total number of open (used) bins


def _frag(r):
    """Fragmentation penalty of a residual r: how undesirable it is to have such a leftover.

    Residuals in the 'sweet spot' that can still hold a mean-sized item are cheap; both
    too-small (unusable) and too-large (wasted) residuals incur increasing penalties.
    """
    if r <= 0:
        return 0.0
    # Distance from a comfortable residual band around MEAN.
    if r >= MEAN:
        return float(r - MEAN)
    return float(MEAN - r)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Aggregate fragmentation cost of the current open-bin residual pool.
    base_frag = 0.0
    for g in range(1, CAP):
        c = _N[g]
        if c:
            base_frag += c * _frag(g)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Change in fragmentation cost when g is replaced by r.
        dfrag = _frag(r) - _frag(g)
        scores[k] = -(float(delta) * 1000.0 + dfrag)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    dfrag_new = _frag(r_new) - _frag(CAP)
    scores[len(fitting):] = -(float(delta_new) * 1000.0 + dfrag_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
