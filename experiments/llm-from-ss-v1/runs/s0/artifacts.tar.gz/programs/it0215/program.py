# EVOLVE-BLOCK-START
"""Best-Fit bin-choice rule for online bin packing.

Each item goes into the fitting bin with the smallest remaining capacity (tightest fit),
which is a classic, robust heuristic for online bin packing and handles Weibull-shaped item
sizes well. Ties (equal residual) go to the first such bin. The function is shown only the
bins the item fits in; it keeps its own record of every opened bin. Used bins are a prefix of
the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # Best-fit: prefer the smallest residual (tightest fit).
        scores[k] = -float(r)

    r_new = CAP - s
    scores[len(fitting):] = -float(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _caps[j] = g - s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END

