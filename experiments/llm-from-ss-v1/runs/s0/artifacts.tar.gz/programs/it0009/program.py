# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with density-weighted residual guidance.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), known to be
asymptotically optimal for online bin packing. On top of the SS delta, a small term rewards
moving to a residual capacity r where typical future items (drawn from the Weibull-shaped
distribution, mean ~40) fit exactly, using a precomputed discrete density of item sizes.
Perfect fits still get top priority. The function only sees fitting bins, so it keeps its
own record of every opened bin.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Build a discrete density of item sizes for the Weibull-shaped distribution (mean ~40).
# We approximate with a Weibull with shape k=2, scale chosen so mean = 40, truncated to 100.
try:
    from scipy.stats import weibull_min as _wb
    _k = 2.0
    _scale = 40.0 / 0.8862269254527580  # Gamma(1+1/k) for k=2
    _xs = np.arange(1, 101, dtype=np.float64)
    _pdf = _wb.pdf(_xs, _k, scale=_scale)
    _pdf = _pdf / _pdf.sum()
except Exception:
    _pdf = np.ones(101, dtype=np.float64)
    _pdf = _pdf / _pdf.sum()

# weight for a residual r: sum over sizes t of pdf[t] if a future item could land exactly
_MATCH = np.zeros(CAP + 1, dtype=np.float64)
for _r in range(1, CAP + 1):
    _MATCH[_r] = _pdf[_r] if _r <= 100 else 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    perfect_exists = any(_caps[j] == s for j in fitting)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        if r == 0:
            base = -1.0e9
        else:
            # reward reasonableness of the new residual (density of sizes that match it)
            match_bonus = _MATCH[r] * 8.0
            base = float(delta) - match_bonus
        scores[k] = -(base * 1000.0 + r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        scores[len(fitting):] = -1.0e12
    else:
        match_bonus_new = _MATCH[r_new] * 8.0 if r_new > 0 else 0.0
        scores[len(fitting):] = -((float(delta_new) - match_bonus_new) * 1000.0 + r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
