# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a distribution-aware best-fit tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer used as the dominant
criterion. Among placements with equal SS delta we prefer the residual r maximising the
empirical probability that the next items reuse it well: we keep an online histogram of
observed item sizes and score r by the mass of sizes that fit snugly into r (closest-fit
flavour), which favours residuals matching the Weibull mode. The function is shown only the
bins the item fits in, so it keeps its own record of every opened bin; used bins form a
prefix of the bin array and each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = np.zeros(CAP + 1, dtype=np.float64)   # empirical item-size histogram
_seen = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _hist, _seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Fit quality of a residual r: probability mass of sizes <= r weighted toward snug fits.
    # Offline we just use the histogram; a snug residual r with high mass just below it is
    # preferred, encouraging consolidation around the item-size mode.
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        if r > 0:
            # mass of item sizes that would fit snugly in r (sizes in [r//2, r])
            lo = (r + 1) // 2
            snug = float(_hist[lo:r + 1].sum())
        else:
            snug = 0.0
        scores[k] = -(float(delta) * 1000000.0 - snug)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if r_new > 0:
        lo = (r_new + 1) // 2
        snug_new = float(_hist[lo:r_new + 1].sum())
    else:
        snug_new = 0.0
    scores[len(fitting):] = -(float(delta_new) * 1000000.0 - snug_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    _hist[s] += 1.0
    _seen += 1.0
    return scores
# EVOLVE-BLOCK-END
