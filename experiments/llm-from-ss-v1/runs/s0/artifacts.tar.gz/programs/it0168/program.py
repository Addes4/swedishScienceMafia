# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an adaptive residual-shaping tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion. SS ties are frequent; among equal SS deltas we prefer the placement whose
residual after placement equals a "high-value" size that is likely to appear again soon,
so that the resulting bin can be refilled rather than left partially empty. The high-value
size is estimated online from a size histogram of past items (the mode of recent sizes),
which is the size the residual is most likely to match on a future arrival.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0] * (CAP + 1)        # histogram of item sizes seen so far
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _hist, _seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    n = len(bins)
    scores = [0.0] * n

    # Preferred residual: the most frequent recent size (mode of the histogram),
    # clipped so it can actually be matched by a residual 0..CAP.
    best_res = 0
    best_cnt = -1
    for v in range(1, CAP + 1):
        if _hist[v] > best_cnt:
            best_cnt = _hist[v]
            best_res = v

    def key(delta, r):
        # Dominant: SS delta (smaller delta = better). Secondary: prefer residual close to
        # the expected next size (helps refill), tertiary: larger residual for flexibility.
        match = 0 if r == best_res else 1
        return (-delta, match, -r)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = key(delta, r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    new_key = key(delta_new, r_new)
    for k in range(len(fitting), n):
        scores[k] = new_key

    # First highest score wins: emulate with explicit comparison over tuple-like floats is
    # unsafe, so compare keys directly.
    best_idx = 0
    best_key_val = None if n == 0 else scores[0]
    for k in range(1, n):
        if scores[k] < best_key_val if isinstance(best_key_val, tuple) else False:
            pass
    # (The block above is a no-op placeholder; real selection below.)

    choice = 0
    bestv = scores[0]
    for k in range(1, n):
        if scores[k] < bestv:
            bestv = scores[k]
            choice = k

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    _hist[s] += 1
    _seen += 1
    # Return numpy array of per-bin scores; harness picks the FIRST highest, so invert.
    out = np.empty(n, dtype=np.float64)
    for k in range(n):
        d = scores[k]
        out[k] = -(d[0] * 100000.0 + d[1] * 1000.0 + d[2])
    return out
# EVOLVE-BLOCK-END

