# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with bounded perfect-fit prioritisation.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), which is known to
be asymptotically optimal for this kind of online bin packing. Perfect fits (residual 0) get a
large but bounded bonus so the SS cost-change stays primary and can still override a perfect
fit that would badly unbalance the distribution. The function is shown only the bins the item
fits in, so it keeps its own record of every opened bin. Used bins are a prefix of the bin
array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Bonus (in SS-delta units) added to the delta of a perfect-fit placement.
PERFECT_BONUS = 6.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n = len(bins)
    scores = np.empty(n, dtype=np.float64)

    k = 0
    for j in range(len(_caps)):
        g = _caps[j]
        if g < s:
            continue
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Perfect fit: subtract a fixed, bounded bonus from its delta (lower delta is better).
        if r == 0:
            delta -= PERFECT_BONUS
        # Primary: SS delta. Secondary: tighter fit (smaller residual).
        scores[k] = -(float(delta) * 1000.0 + r)
        k += 1

    n_fitting = k
    # Unused (new) bins: residual is CAP - s, with a fresh bin counted once.
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[n_fitting:] = -(float(delta_new) * 1000.0 + r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < n_fitting:
        # Recover which existing bin this corresponds to.
        j = -1
        cnt = 0
        for jj in range(len(_caps)):
            if _caps[jj] >= s:
                if cnt == choice:
                    j = jj
                    break
                cnt += 1
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

