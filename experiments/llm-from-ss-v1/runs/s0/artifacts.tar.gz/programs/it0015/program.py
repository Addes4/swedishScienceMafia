# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a bounded residual-usability correction.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for online bin packing.  Pure SS ignores the fact that residual gaps far below the smallest
frequent item sizes are wasted; we keep an exact SS delta as the dominant term and add a small
bounded correction that mildly penalises leaving residuals that are unlikely to be useful, and
mildly rewards leaving residuals close to common item sizes.  The function is shown only the
bins the item fits in, so it keeps its own record of every opened bin.  Used bins are a prefix
of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_cnt = [0] * (CAP + 1)         # how many items of each size we have seen


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _cnt
    s = int(item)
    _cnt[s] += 1

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    perfect_exists = any(_caps[j] == s for j in fitting)

    # A small, bounded "usability" bonus for residuals: prefer leaving a gap that equals a
    # size we have actually seen before (so a future item can slot in), and mildly penalise
    # residuals that are too small to ever be useful.
    def usable(r):
        if r <= 0:
            return 0.0
        if r <= 3:
            return -0.5
        return 0.5 if _cnt[r] > 0 else 0.0

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        corr = usable(r)
        if r == 0:
            base = -1.0e9
        else:
            base = float(delta)
        scores[k] = -(base * 1000.0 - corr * 10.0 + r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    corr_new = usable(r_new)
    if perfect_exists:
        scores[len(fitting):] = -1.0e12
    else:
        scores[len(fitting):] = -(float(delta_new) * 1000.0 - corr_new * 10.0 + r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

