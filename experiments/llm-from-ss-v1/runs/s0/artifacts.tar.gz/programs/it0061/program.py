# EVOLVE-BLOCK-START
"""Best-fit with perfect-fit priority and SS-based new-bin tie-break.

Items arrive online. The rule prefers a perfect fit (residual 0) absolutely; otherwise it
places the item into the bin with the smallest positive residual (classic best-fit), which
tends to preserve large residuals and is empirically near-optimal on Weibull-shaped sizes.
Opening a new bin is allowed whenever no fitting bin exists in the shown array; its priority
is computed from the sum-of-squares delta so unused bins are still ranked sensibly. The
function keeps its own record of every opened bin, since only fitting bins are shown.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        if r == 0:
            scores[k] = 1.0e9          # absolute priority for a perfect fit
        else:
            # Best fit: smaller residual => higher score.
            scores[k] = -float(r) * 1000.0

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    new_score = -(float(delta_new) * 1000.0 + r_new)
    if n_unused > 0:
        scores[len(fitting):] = new_score
    # (If n_unused == 0 there are no unused slots to rank; fitting covers all bins.)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
