# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with perfect-fit prioritisation and reusable-residual tie-breaks.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), which is known to
be asymptotically optimal for this kind of online bin packing. Ties and near-ties are broken
by preferring a perfect fit (residual 0) and, failing that, the tighter fit. A small extra
adjustment rewards residuals that can be exactly filled by an item size seen so far and
penalises residuals smaller than the smallest item seen (likely wasted). The function is
shown only the bins the item fits in, so it keeps its own record of every opened bin. Used
bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_seen = [False] * (CAP + 1)    # item sizes seen so far
_min_seen = CAP + 1            # smallest item size seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _seen, _min_seen

    s = int(item)
    seen = _seen
    min_seen = _min_seen

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Prefer perfect fits: find if any fitting bin has residual 0.
    perfect_exists = any(_caps[j] == s for j in fitting)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        if r == 0:
            base = -1.0e9
        else:
            base = float(delta)
            # small helper: penalise very small residuals, reward reusable residuals
            if r < min_seen:
                base += 0.02
            if seen[r]:
                base -= 0.02
        scores[k] = -(base * 1000.0 + r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        # Discourage opening a new bin when a perfect fit exists.
        scores[len(fitting):] = -1.0e12
    else:
        base_new = float(delta_new)
        if r_new < min_seen:
            base_new += 0.02
        if seen[r_new]:
            base_new -= 0.02
        scores[len(fitting):] = -(base_new * 1000.0 + r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update statistics with the arriving item (state for future calls)
    seen[s] = True
    if s < min_seen:
        _min_seen = s

    return scores
# EVOLVE-BLOCK-END
