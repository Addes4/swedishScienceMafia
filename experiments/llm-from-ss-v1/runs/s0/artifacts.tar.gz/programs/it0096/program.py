# EVOLVE-BLOCK-START
"""Best-fit rule.

Each item goes into the fitting bin with the smallest residual (tightest fit); a perfect fit
(residual 0) is thus chosen first. If no existing bin fits, a new bin is opened. Best-fit is
a classic O(1)-per-item online heuristic with a good worst-case constant on Weibull-like
item-size distributions. The function is shown only the bins the item fits in, so it keeps
its own record of every opened bin (used bins are a prefix of the bin array).
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps
    s = int(item)
    fitting = [(g - s, j) for j, g in enumerate(_caps) if g >= s]
    scores = np.empty(len(bins), dtype=np.float64)

    for k, (r, j) in enumerate(fitting):
        # Tighter fit (smaller residual) scores higher; perfect fit r == 0 is best.
        scores[k] = -float(r)

    r_new = CAP - s
    if fitting:
        # Discourage opening a new bin when an existing bin fits.
        scores[len(fitting):] = -1.0e12
    else:
        scores[len(fitting):] = -float(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice][1]
        _caps[j] -= s
    else:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END

