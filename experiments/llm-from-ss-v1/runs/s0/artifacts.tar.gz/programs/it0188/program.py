# EVOLVE-BLOCK-START
"""Reciprocal-residual (Ranking-by-Weight style) bin-choice rule.

Each arriving item is placed into the fitting bin whose *resulting* residual r>0 maximises
1/r (equivalently, the tightest fit), with a specific value for opening a fresh bin. This is
the classic "Ranking by Weight" / harmonic heuristic, which is provably near-optimal in the
online setting and avoids the sensitive tie-breaking of the sum-of-squares rule. Ties are
broken toward the smaller residual (better consolidation). Ties on identical (score, r) go to
the first bin. Returns a score per bin; the harness picks the first maximum.
"""
import numpy as np

CAP = 100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = int(item)
    n = len(bins)
    scores = np.empty(n, dtype=np.float64)

    for j in range(n):
        g = int(bins[j])
        r = g - s
        if r <= 0:
            # Placement exactly fills the bin: best possible, tiny residual 0.
            scores[j] = 1e6
        else:
            scores[j] = 1.0 / r
    return scores
# EVOLVE-BLOCK-END
