# EVOLVE-BLOCK-START
"""Best-fit style rule with perfect-fit prioritisation.

The item is placed in the fitting bin that leaves the smallest residual (classic Best Fit),
which is strong for online bin packing. A perfect fit (residual 0) is additionally rewarded so
it is essentially always taken, and opening a fresh bin is delayed slightly by giving unused
bins a mild penalty relative to a tight fit. The function keeps its own record of every opened
bin, since it is only shown the bins the item fits in. Used bins form a prefix of the bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_bins = len(bins)
    scores = np.empty(n_bins, dtype=np.float64)

    # Existing fitting bins: prefer the smallest residual (tightest fit); reward perfect fit.
    for k, j in enumerate(fitting):
        r = _caps[j] - s
        if r == 0:
            scores[k] = 1.0e6
        else:
            scores[k] = -float(r)

    # Unused bins: mild penalty so we only open a new bin when no good fit exists.
    for k in range(len(fitting), n_bins):
        scores[k] = -float(CAP - s) - 1.0

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        _caps[j] -= s
    else:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
