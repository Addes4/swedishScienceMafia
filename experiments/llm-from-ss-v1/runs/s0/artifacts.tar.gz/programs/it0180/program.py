# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a global fragmentation tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion. Among placements with equal SS delta we use a global fragmentation
tie-break: prefer the placement that minimises the sum over all open bins of 1/residual after
the placement (treating residual 0 as contributing 0). This keeps the residual multiset
spread out and avoids fragmenting free space. The function is shown only the bins the item
fits in, so it keeps its own record of every opened bin. Used bins are a prefix of the bin
array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_recip_sum = [0.0]             # running sum over open bins of 1/residual (index 0 ignored-ish)


def _update_recip(g, delta_sign):
    """Add/subtract 1/g from the running reciprocal sum for residual g (g>0)."""
    if g > 0:
        _recip_sum[0] += delta_sign / g


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Fragment penalty: change in sum of 1/residual from removing g and adding r.
        frag = _recip_sum[0]
        if g > 0:
            frag -= 1.0 / g
        if r > 0:
            frag += 1.0 / r
        # Dominant: exact SS delta (as large negative as possible).
        # Tie-break: smaller fragmentation (larger is worse) -> we negate frag.
        scores[k] = -(float(delta) * 1000.0 + frag)

    for k in range(len(fitting), len(bins)):
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        frag_new = _recip_sum[0]
        if r_new > 0:
            frag_new += 1.0 / r_new
        scores[k] = -(float(delta_new) * 1000.0 + frag_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _update_recip(g, -1.0)
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
            _update_recip(g - s, +1.0)
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
            _update_recip(CAP - s, +1.0)
    return scores
# EVOLVE-BLOCK-END
