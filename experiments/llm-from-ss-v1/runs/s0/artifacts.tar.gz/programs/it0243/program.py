# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an empirical "closability" tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion; among placements with equal SS delta we prefer the placement whose
residual r is most likely to be exactly fillable by a future item, estimated from a
recency-weighted histogram of the items seen so far (mass of sizes s' with s' <= r, plus a
bonus for an exact match s' == r). This encourages leaving residual classes that upcoming
items can close rather than fragmenting free space further.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0.0] * (CAP + 1)      # recency-weighted item-size histogram
_hist_sum = [0.0] * (CAP + 1)  # prefix sums of _hist, rebuilt lazily
_decay = 0.999
_prefix_valid = False


def _prefix():
    global _hist_sum, _prefix_valid
    if not _prefix_valid:
        acc = 0.0
        for i in range(CAP + 1):
            acc += _hist[i]
            _hist_sum[i] = acc
        _prefix_valid = True
    return _hist_sum


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist, _prefix_valid, _hist_sum
    s = int(item)

    # update recency-weighted item histogram
    for i in range(CAP + 1):
        _hist[i] *= _decay
    _hist[s] += 1.0
    _prefix_valid = False

    ps = _prefix()

    def closability(r):
        if r <= 0:
            return 0.0
        # mass of future items that would fit-or-close this residual
        return ps[r] + _hist[r]

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(float(delta) * 1000.0 - closability(r))

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(float(delta_new) * 1000.0 - closability(r_new))

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

