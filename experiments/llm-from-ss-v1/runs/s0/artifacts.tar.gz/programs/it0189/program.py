# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a mode-consolidating tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is the strictly
dominant criterion; among placements with equal SS delta we prefer the residual closest to the
mode of the currently-open residual distribution, which pulls bins toward a common residual
size so they can be completed/freed together. The function is shown only the bins the item
fits in, so it keeps its own record of every opened bin. Used bins are a prefix of the bin
array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_bincount = [0] * (CAP + 1)    # total placements into each resulting residual, for mode tracking
_total = 0


def _mode_residual():
    """Return the residual value that currently has the highest open-bin count (mode)."""
    best_g = 0
    best_c = -1
    for g in range(1, CAP):
        if _N[g] > best_c:
            best_c = _N[g]
            best_g = g
    return best_g


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    mode = _mode_residual()

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta (as large negative as possible).
        # Tie-break: prefer residual closest to the current mode.
        tie = -abs(r - mode)
        scores[k] = -(float(delta) * 1000.0 - tie)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    tie_new = -abs(r_new - mode)
    scores[len(fitting):] = -(float(delta_new) * 1000.0 - tie_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
