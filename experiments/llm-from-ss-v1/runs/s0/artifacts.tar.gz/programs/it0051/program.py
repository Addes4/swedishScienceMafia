# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a smoothed best-fit tie-break.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), which is known to
be asymptotically optimal for this kind of online bin packing. Deltas that are near-equal are
treated as ties (tolerance-based), and among those we pick the placement that leaves the
largest residual (best-fit to the fullest bin), keeping big empty bins free for large items.
Perfect fits get a small bounded bonus so they win without a hard override. The function is
shown only the bins the item fits in, so it keeps its own record of every opened bin.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    n_bins = len(bins)

    # Collect candidate placements and their exact SS cost-change.
    deltas = []
    residuals = []
    idxs = []                  # bin-index in _caps, or -1 for a new bin
    for j in fitting:
        g = _caps[j]
        r = g - s
        d = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        deltas.append(d)
        residuals.append(r)
        idxs.append(j)
    if n_unused > 0:
        r_new = CAP - s
        d_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        deltas.append(d_new)
        residuals.append(r_new)
        idxs.append(-1)

    deltas = np.asarray(deltas, dtype=np.float64)
    residuals = np.asarray(residuals, dtype=np.float64)

    # Perfect-fit bonus: a bounded reward for creating a zero residual.
    perfect = (residuals == 0).astype(np.float64)
    key = deltas - 0.5 * perfect

    # Smoothed best-fit: among near-tied deltas pick the largest residual (looser fit).
    tol = 0.25
    mn = key.min()
    near = np.abs(key - mn) <= tol
    # Prefer larger residual inside the tie band; then smaller key; then first index.
    band_penalty = np.where(near, 0.0, 1.0)
    rank = band_penalty * 1e6 + key * 10.0 - residuals * 0.01

    best = int(np.argmin(rank))
    chosen = idxs[best]

    # Apply the move to internal bookkeeping.
    if chosen >= 0:
        g = _caps[chosen]
        _N[g] -= 1
        _caps[chosen] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # Build per-bin scores for the harness: chosen candidate gets highest, others lower.
    scores = np.empty(n_bins, dtype=np.float64)
    # lower rank -> higher score; reuse rank to keep ordering consistent with our choice.
    scores[:] = -1e6
    if chosen >= 0:
        scores[chosen] = 1.0
    else:
        scores[len(fitting):] = 1.0
    return scores
# EVOLVE-BLOCK-END
