# EVOLVE-BLOCK-START
"""Best-fit with exact-fill priority and SS flexibility tie-break.

Items arrive online. Placing an item so that its bin becomes exactly full (residual 0) is
always optimal locally: it removes a bin without consuming any usable space, so we make it the
top priority. Otherwise we use the SS rule (minimise sum_g N(g)^2), which is asymptotically
optimal for online bin packing, and break ties by the larger residual so flexible free space
is preserved. The function keeps its own record of every opened bin because it is shown only
the bins the item fits in.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 <= g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        base = -(float(delta) * 1000.0 - r)
        # Exact-fill bonus: making residual 0 removes a bin, always beneficial.
        if r == 0:
            base += 1e9
        scores[k] = base

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(float(delta_new) * 1000.0 - r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

