# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with history-driven residual matching.

Each item goes where it minimises sum_g N(g)^2 (the sum-of-squares / SS rule), which is
asymptotically optimal for online bin packing. Ties and near-ties are broken by a
history-driven heuristic: we track the set of item sizes seen so far and mildly prefer
residuals that can be exactly filled by some seen item size (creating future perfect fits),
and, best of all, residuals of 0 (current perfect fit). The SS delta stays dominant; the
history terms only break near-ties. The function is shown only the bins the item fits in, so
it keeps its own record of every opened bin; unused bins are a prefix of the bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_seen = [False] * (CAP + 1)    # sizes of items observed so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    _seen[s] = True

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Prefer perfect fits: find if any fitting bin has residual 0.
    perfect_exists = any(_caps[j] == s for j in fitting)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        if r == 0:
            base = -1.0e9
        else:
            base = float(delta)
        # History tie-break: prefer residuals that some seen item can exactly fill.
        hist = 0.0
        if r > 0 and _seen[r]:
            hist = 1.0
        scores[k] = -(base * 1000.0 + r - hist * 0.5)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        # Discourage opening a new bin when a perfect fit exists.
        scores[len(fitting):] = -1.0e12
    else:
        hist_new = 1.0 if (r_new > 0 and _seen[r_new]) else 0.0
        scores[len(fitting):] = -(float(delta_new) * 1000.0 + r_new - hist_new * 0.5)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
