# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with perfect-fit prioritisation.

Each item goes where it minimises sum_g N(g)^2 (the sum-of-squares / SS rule), which is
asymptotically optimal for this kind of online bin packing. Ties are broken by preferring a
perfect fit (residual 0) and, failing that, the tighter fit. The function is shown only the
bins the item fits in, so it keeps its own record of every opened bin. Used bins are a prefix
of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    n_used = len(_caps)
    n_new = n_bins - n_used

    scores = np.full(n_bins, -np.inf, dtype=np.float64)

    if n_new > 0:
        # Option: open a fresh bin.  Its residual is CAP - s.
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        scores[n_used:] = float(delta_new)

    perfect_exists = False
    if n_used > 0:
        caps = np.asarray(_caps, dtype=np.int64)
        fit = caps >= s
        if not perfect_exists:
            perfect_exists = bool(np.any(caps == s))

        idx = np.nonzero(fit)[0]
        if idx.size:
            g = caps[idx]
            r = g - s
            N = np.asarray(_N, dtype=np.int64)
            # SS cost change: -2*N[g] + 1 + (2*N[r] + 1 if r > 0 else 0)
            delta = -2 * N[g] + 1
            pos = r > 0
            delta[pos] += 2 * N[r[pos]] + 1
            scores[idx] = delta.astype(np.float64)

    if perfect_exists:
        # Hard override: only perfect fits are allowed.
        scores = np.where(scores == -np.inf, -np.inf, scores)
        # identify perfect-fit positions
        caps_arr = np.asarray(_caps, dtype=np.int64) if n_used > 0 else np.empty(0, dtype=np.int64)
        perfect_mask = np.zeros(n_bins, dtype=bool)
        if n_used > 0:
            perfect_mask[:n_used] = (caps_arr == s)
        # everything that is not a perfect fit gets pushed far down
        scores = np.where(perfect_mask, -1.0e-9, 1.0e9) + np.where(perfect_mask, 0.0, 0.0)
        # perfect fits ranked by tighter? residual is 0 for all -> keep first
    else:
        # break ties toward the tighter (smaller) residual
        caps_arr = np.asarray(_caps, dtype=np.int64) if n_used > 0 else np.empty(0, dtype=np.int64)
        r_all = np.empty(n_bins, dtype=np.int64)
        if n_used > 0:
            r_all[:n_used] = caps_arr - s
        r_all[n_used:] = CAP - s
        # primary: smaller delta; secondary: smaller residual -> combine lexicographically
        scores = scores * 1000.0 + r_all.astype(np.float64)

    choice = int(np.argmax(scores))
    if choice < n_used:
        g = _caps[choice]
        _N[g] -= 1
        _caps[choice] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

