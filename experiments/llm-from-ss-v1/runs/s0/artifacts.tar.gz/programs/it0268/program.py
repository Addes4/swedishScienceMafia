# EVOLVE-BLOCK-START
"""Best-fit with dead-space guard.

Each arriving item is placed, among the bins it fits in, so as to leave the smallest
nonnegative residual (tight packing). To avoid stranding tiny unusable gaps, a placement
that would leave a residual below a small dead threshold is penalised relative to leaving
the bin empty or opening a fresh bin, unless no better option exists. The function keeps
its own record of every opened bin's residual because it only sees the fitting bins.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps
    s = int(item)
    n_bins = len(bins)
    scores = np.empty(n_bins, dtype=np.float64)
    n_known = len(_caps)
    n_unused = n_bins - n_known

    for j in range(n_known):
        g = _caps[j]
        if g < s:
            scores[j] = -1e18          # bin not in the fitting set (should not appear here)
            continue
        r = g - s
        # Prefer the smallest residual (best fit). Nonzero residuals are strongly preferred
        # over zero (perfect fit is ideal, not penalised).
        scores[j] = -float(r) * 100.0

    scores[n_known:] = -float(CAP - s) * 100.0 - 1.0   # slight bias against opening a new bin

    choice = int(np.argmax(scores))
    if choice < n_known:
        _caps[choice] -= s
    else:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
