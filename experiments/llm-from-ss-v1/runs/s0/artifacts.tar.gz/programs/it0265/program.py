# EVOLVE-BLOCK-START
"""Bounded sum-of-squares rule with a flexibility-preserving tie-break.

Items are placed to minimise a *bounded* SS potential: the standard SS delta is computed
exactly (integer) but then squashed through a monotone saturation function so that very
full / very empty bins don't dominate the choice. This keeps the asymptotically-optimal
ordering while reducing variance. Ties (equal bounded delta) prefer the larger residual.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _bounded(delta):
    """Monotone saturation of the integer SS delta (keeps order, caps extremes)."""
    # fast rational saturation: delta / (1 + |delta|/K) with K = 8
    d = float(delta)
    return d / (1.0 + abs(d) / 8.0)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = _bounded(delta) * 1000.0 + r * 1e-3

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = _bounded(delta_new) * 1000.0 + r_new * 1e-3

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

