# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a residual-sweet-spot tie-break.

The dominant criterion is the exact integer Sum-of-Squares delta: place the item where
sum_g N(g)^2 increases least (the SS rule, asymptotically optimal for this item class).
Among placements with equal SS delta, we prefer the bin whose residual r=g-s is closest to
the distribution's typical item size (~40), which keeps a "sweet spot" of free space so
that a future average item can reuse the bin instead of opening a new one. Existing bins
are preferred over brand-new bins on ties, and r=0 (perfect fit) is treated as the best
residual since it wastes no capacity. The function is shown only the bins the item fits
in, so it keeps its own record of every opened bin. Used bins form a prefix of the array.
"""
import numpy as np

CAP = 100
TARGET = 40
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _resid_key(r):
    # Best residual is 0 (perfect fit), otherwise closeness to TARGET.
    if r == 0:
        return 0
    return abs(r - TARGET) + 1


def priority(item, bins):
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Primary: SS delta (minimize increase). Secondary: residual sweet spot.
        # Tertiary: existing bin beats opening a new one.
        scores[k] = -float(delta) * 1000000.0 - _resid_key(r) * 1000.0 + 1.0

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -float(delta_new) * 1000000.0 - _resid_key(r_new) * 1000.0

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

