# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a resumable-residual tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for online bin packing. The SS delta is an exact integer and is the dominant criterion. Among
placements with equal SS delta we prefer the one whose residual is more "resumable": a leftover
that matches a typical item size (so it can be filled exactly later) is better than hoarding a
single large residual. Concretely we count how often each residual value arises as a leftover
that is close to observed item sizes, and break remaining ties by the larger residual.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_size_hits = [0] * (CAP + 1)   # count of past items equal to each size (small, online stats)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _size_hits
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta (as large negative as possible).
        # Tie-break: prefer residuals that match frequently seen item sizes (resumable),
        # then prefer the larger residual (more flexible free space).
        resumable = _size_hits[r] if r > 0 else 0
        scores[k] = -(float(delta) * 100000.0 - resumable * 100.0 - r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    resumable_new = _size_hits[r_new] if r_new > 0 else 0
    scores[len(fitting):] = -(float(delta_new) * 100000.0 - resumable_new * 100.0 - r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    _size_hits[s] += 1
    return scores
# EVOLVE-BLOCK-END
