# EVOLVE-BLOCK-START
"""Best-fit with small-residual avoidance.

Each item goes into the fitting bin that leaves the smallest residual capacity, except that
residuals in a tiny, wasteful band (1..3) are strongly penalised unless no alternative exists.
A perfect fit (residual 0) always gets the highest priority. This keeps bins tightly packed
while avoiding the fragmentation that pure best-fit suffers from at the tail.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    perfect_exists = any(_caps[j] == s for j in fitting)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        if r == 0:
            scores[k] = 1.0e12
        else:
            # Prefer tight fit; penalise residuals 1..3 slightly less severely than pure best-fit
            penalty = 0.0
            if 1 <= r <= 3:
                penalty = 5.0 * (4 - r)
            scores[k] = -r - penalty

    r_new = CAP - s
    if perfect_exists:
        scores[len(fitting):] = -1.0e12
    else:
        penalty_new = 0.0
        if 1 <= r_new <= 3:
            penalty_new = 5.0 * (4 - r_new)
        scores[len(fitting):] = -r_new - penalty_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

