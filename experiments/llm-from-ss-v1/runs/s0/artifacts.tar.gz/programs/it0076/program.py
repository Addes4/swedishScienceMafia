# EVOLVE-BLOCK-START
"""Sum-of-Squares (SS) rule with a true SS delta including the new-bin option.

Each arriving item is placed to minimise the increase in sum_g N(g)^2 over remaining
capacities (the classic SS / sum-of-squares rule, asymptotically optimal for online bin
packing). Ties are broken toward the tighter fit (smaller residual). The harness shows only
the bins the item fits in, so we keep our own record of every opened bin: used bins form a
prefix of the bin array, and the unseen tail consists of unused bins (remaining capacity CAP).
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # SS delta: removing one bin of capacity g, adding one of capacity r.
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(float(delta) * 100.0 + r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(float(delta_new) * 100.0 + r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
