# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an adaptive, mean-residual tie-break.

Items go where they minimise sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer and is used as the
strictly dominant criterion (scaled by a large constant so the tie-break can never leak into
adjacent SS deltas). Among placements with equal SS delta we prefer the residual that is
closest to the running average item size seen so far -- such leftovers are most likely to be
consumed by future items, keeping bins reusable -- and secondarily the larger residual, which
keeps free space flexible. The function is shown only the bins the item fits in, so it keeps
its own record of every opened bin. Used bins are a prefix of the bin array; each instance
runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_sum_items = 0
_cnt_items = 0
SCALE = 1_000_000.0            # guarantees lexicographic dominance of the SS delta


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _sum_items, _cnt_items
    s = int(item)

    # running mean item size (before seeing this item), used as a target residual
    if _cnt_items > 0:
        target = _sum_items / _cnt_items
    else:
        target = s

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: SS delta (dominant). secondary: residual close to running mean.
        # tertiary: larger residual for flexibility.
        closeness = -abs(r - target)
        scores[k] = -(float(delta) * SCALE - closeness * 1000.0 - r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    closeness_new = -abs(r_new - target)
    scores[len(fitting):] = -(float(delta_new) * SCALE - closeness_new * 1000.0 - r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    _sum_items += s
    _cnt_items += 1
    return scores
# EVOLVE-BLOCK-END
