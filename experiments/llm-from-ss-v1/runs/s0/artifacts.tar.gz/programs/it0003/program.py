# EVOLVE-BLOCK-START
"""Best-fit with a fragmentation-aware tie-break.

The base rule is classic Best Fit: place the item into the fitting bin with the smallest
remaining capacity after the item (tightest fit). Among bins with equal tightened residual,
prefer the one whose resulting capacity class r already contains many open bins, which tends
to keep the capacity-class distribution concentrated and reduce future fragmentation. Unused
bins (remaining capacity 100) are handled with the same rule using their resulting capacity.
The function keeps its own record of every opened bin because it is shown only fitting bins.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        scores[k] = -(r * 1000 + (_N[r] if r > 0 else 0))
    r_new = CAP - s
    scores[len(fitting):] = -(r_new * 1000 + (_N[r_new] if r_new > 0 else 0))

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

