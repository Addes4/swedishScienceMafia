# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a typical-item-size-aware tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion; among placements with equal SS delta we prefer the placement whose post
placement residual is closest to (but not below) a running estimate of the typical future
item size, keeping free space in a range that is actually usable for future items.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_recent = []                   # recent item sizes for a running typical-size estimate
_typ = [40.0]                  # running estimate of the typical item size


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)

    # Update a running typical item size (bounded window mean).
    _recent.append(s)
    if len(_recent) > 200:
        _recent.pop(0)
    _typ[0] = sum(_recent) / len(_recent)
    t = int(round(_typ[0]))

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta (as large negative as possible).
        # Tie-break: prefer residual closest to (but not below) the typical size.
        if r >= t:
            key = -(r - t)
        else:
            key = -(t - r) - 1000.0
        scores[k] = -(float(delta) * 1000.0 - key)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if r_new >= t:
        key_new = -(r_new - t)
    else:
        key_new = -(t - r_new) - 1000.0
    scores[len(fitting):] = -(float(delta_new) * 1000.0 - key_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
