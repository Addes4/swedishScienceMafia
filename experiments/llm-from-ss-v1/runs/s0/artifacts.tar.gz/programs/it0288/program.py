# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an adaptive, reusable-residual tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer and is used as the
dominant criterion. Among placements with equal SS delta we prefer the residual that is
closest to the running mean item size: such leftover space is most likely to be reusable by
a typical future item, and avoiding both extremes (fragmenting tiny slivers and hoarding one
huge free bin) tends to reduce fragmentation. A slight preference for larger residuals is
used as a secondary key. The function keeps its own record of every opened bin since it is
shown only the bins the item fits in.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_sum = 0.0                     # running sum of item sizes
_cnt = 0                       # number of items seen


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _sum, _cnt
    s = int(item)
    _sum += s
    _cnt += 1
    target = _sum / _cnt                # running mean item size

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta (as negative as possible).
        # Tie-break: prefer residual closest to the running mean item size,
        # then prefer the larger residual.
        closeness = -abs(r - target)
        scores[k] = -(float(delta) * 100000.0 - closeness * 100.0 - r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    closeness_new = -abs(r_new - target)
    scores[len(fitting):] = -(float(delta_new) * 100000.0 - closeness_new * 100.0 - r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
