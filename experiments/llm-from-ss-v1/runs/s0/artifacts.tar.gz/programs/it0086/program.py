# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with empirical complementary-fit tie-breaking.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), the classic
asymptotically optimal online rule. Among placements with (near) equal SS delta, prefer the
one whose leftover residual matches a frequently arriving item size, so the bin is likely to
be closed exactly by a future item. The function is shown only the bins the item fits in, so
it keeps its own record of every opened bin. Used bins are a prefix of the bin array and each
instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # running histogram of item sizes seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _freq
    s = int(item)
    _freq[s] += 1
    # crude normalised frequency of item sizes, used only as a gentle tie-break
    total = sum(_freq)

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # exact SS delta: 1 + 2*N[r] (new residual) minus (2*N[g] - 1) (bin leaves capacity g)
        delta = 1 + (2 * _N[r] + 1 if r > 0 else 0) - (2 * _N[g] - 1)
        # tie-break: reward residuals that are common item sizes (complementarity)
        comp = _freq[r] / total if (r > 0 and total > 0) else 0.0
        scores[k] = -(delta + 0.5 * comp)

    r_new = CAP - s
    delta_new = (2 * _N[r_new] + 1) if r_new > 0 else 0
    comp_new = _freq[r_new] / total if (r_new > 0 and total > 0) else 0.0
    scores[len(fitting):] = -(float(delta_new) + 0.5 * comp_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

