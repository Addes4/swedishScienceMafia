# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with consolidation tie-break and perfect-fit bonus.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), which is known to
be asymptotically optimal for online bin packing. Among placements with equal SS delta, we
break ties by preferring the residual r that currently has the largest open-bin count N[r],
which consolidates open bins toward fewer distinct residual classes. A perfect fit (r == 0)
gets a modest bonus since it closes a bin. The function is shown only the bins the item fits
in, so it keeps its own record of every opened bin. Used bins are a prefix of the bin array;
each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Primary: exact SS delta. Secondary: consolidation count N[r]. Tertiary: tighter fit.
    def rank(r, delta):
        # higher score = better. delta smaller is better -> negate.
        bonus = 1.0e6 if r == 0 else 0.0
        return -(float(delta)) + bonus + 1.0e-3 * float(_N[r]) - 1.0e-6 * float(r)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = rank(r, delta)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = rank(r_new, delta_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
