# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with perfect-fit and harmonic residual tie-breaks.

The primary rule is the classical sum-of-squares (SS) criterion: place the item so that
sum_g N(g)^2 increases the least, which is asymptotically optimal for online bin packing.
SS leaves many small unusable residuals, so ties (and near-ties) are broken by:
  * a perfect fit (residual 0) getting strong priority,
  * then preferring residuals that are "harmonically large" (can still hold a sizable item),
  * then a tighter fit.
The function keeps its own record of every opened bin since it only sees fitting bins.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Harmonic residual thresholds: bigger residuals are more useful.
_BIG = 50      # can still hold a large item
_MID = 33      # can hold a medium item
_SML = 25      # can hold a small item


def _residual_rank(r):
    """Higher is better: prefers residuals that keep useful room."""
    if r == 0:
        return 4
    if r > _BIG:
        return 3
    if r > _MID:
        return 2
    if r > _SML:
        return 1
    return 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    perfect_exists = any(_caps[j] == s for j in fitting)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        base = float(delta)
        # Secondary: harmonic residual usefulness; tertiary: tighter fit.
        sec = _residual_rank(r)
        scores[k] = -(base * 10000.0) - (sec * 100.0) - r

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        scores[len(fitting):] = -1.0e18
    else:
        sec_new = _residual_rank(r_new)
        scores[len(fitting):] = -(float(delta_new) * 10000.0) - (sec_new * 100.0) - r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
