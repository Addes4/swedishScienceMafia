# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with perfect-fit prioritisation and a residual reserve tie-break.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), which is known to
be asymptotically optimal for this kind of online bin packing. Ties and near-ties are broken
by preferring a perfect fit (residual 0) and, failing that, by preferring a residual that is
useful for future large items. The function is shown only the bins the item fits in, so it
keeps its own record of every opened bin. Used bins are a prefix of the bin array; each
instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Prefer perfect fits: find if any fitting bin has residual 0.
    perfect_exists = any(_caps[j] == s for j in fitting)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # High-order: perfect fit gets top priority; then SS delta; then a residual reserve
        # tie-break that favours residuals useful for future large items (item mean ~40).
        if r == 0:
            base = -1.0e9
        else:
            base = float(delta)
        scores[k] = -(base * 1000.0 - _reserve(r))

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        # Discourage opening a new bin when a perfect fit exists.
        scores[len(fitting):] = -1.0e12
    else:
        scores[len(fitting):] = -(float(delta_new) * 1000.0 - _reserve(r_new))
    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores


def _reserve(r):
    """Small bounded preference for residuals that are useful for future large items.

    Larger residuals are useful only up to roughly the largest typical future item; residuals
    around the item-mean (~40) can absorb a typical item, while very small residuals are near
    useless and very large residuals belong to (nearly) empty bins. Range roughly [-0.5, 0.5].
    """
    # Peak usefulness around 40, decaying for residuals far from that band.
    d = abs(r - 40.0)
    if d >= 40.0:
        return -0.5
    return 0.5 - d / 80.0
# EVOLVE-BLOCK-END
