# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with perfect-fit prioritisation and waste-aware lookahead.

Each item goes where it minimises a weighted combination of the sum-of-squares delta (SS rule,
asymptotically optimal) and the change in a fractional-waste proxy sum of residuals. Ties are
broken by preferring a perfect fit and then the tighter fit. The function is shown only the
bins the item fits in, so it keeps its own record of every opened bin.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    perfect_exists = any(_caps[j] == s for j in fitting)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # sum-of-squares delta
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # waste-aware correction: penalise creating a small non-empty residual r
        # (a gap that cannot be cleanly reused), mildly, scaled down vs the SS term.
        waste = 0.0
        if r > 0:
            # prefer residuals that are either 0 or reasonably large
            waste = -1.0 / r
        else:
            waste = 1.0 / CAP
        if r == 0:
            base = -1.0e9
        else:
            base = float(delta) + 0.5 * waste
        scores[k] = -(base * 1000.0 + r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        scores[len(fitting):] = -1.0e12
    else:
        scores[len(fitting):] = -(float(delta_new) * 1000.0 + r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
