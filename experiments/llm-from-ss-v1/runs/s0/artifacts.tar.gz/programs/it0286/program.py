# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with flexibility-preserving tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), asymptotically optimal for
online bin packing. The SS delta is an exact integer used as the dominant criterion. Among
placements with equal SS delta we prefer the placement that leaves the larger residual,
keeping flexible free space available for future large items. Opening a fresh bin is
penalised slightly on ties against fitting into an existing bin, since existing bins are
already "spent" and their residual is worth more than a brand-new full bin's.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta (as large negative as possible).
        # Secondary: prefer larger residual (more flexible free space).
        scores[k] = -(float(delta) * 10000.0 - r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    # Add a small penalty for opening a fresh bin so that on SS-delta ties an existing
    # bin wins; existing bins are already spent and their residual is worth preserving.
    scores[len(fitting):] = -(float(delta_new) * 10000.0 - r_new) - 0.5

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
