# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with tie-break by tightest fit.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), which is known to
be asymptotically optimal for this kind of online bin packing. Exact SS-delta ties are broken
by preferring the tightest residual (perfect fit first, then smallest residual), a classic
heuristic that improves packing without disturbing the SS ordering. The function is shown only
the bins the item fits in, so it keeps its own record of every opened bin. Used bins are a
prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    N = len(bins)
    scores = np.empty(N, dtype=np.float64)

    # Scale factor strictly larger than the maximum possible residual (<=100), so that
    # SS-delta dominates the residual tie-break, and integer deltas stay strictly ordered.
    SCALE = 1000.0

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant term: -delta (lower SS increase is better). Tie-break: -r (tighter better).
        scores[k] = -(delta * SCALE + r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * SCALE + r_new)

    choice = int(np.argmax(scores))          # first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
