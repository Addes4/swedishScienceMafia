# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with robustness-preserving tie-break.

Each item goes where it minimises the sum-of-squares cost change (SS rule), asymptotically
optimal for this kind of online bin packing. Deltas are computed as exact integers and scaled
by 1000, so the primary key is clean; ties (equal SS delta) are broken by the tighter fit
(smaller residual). A perfect fit is given a strong bounded bonus so it always wins when an
SS-equal alternative is available.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    n_fitting = 0
    for g in _caps:
        if g >= s:
            n_fitting += 1
    n_unused = n_bins - n_fitting
    scores = np.empty(n_bins, dtype=np.float64)

    perfect_exists = False
    k = 0
    for j, g in enumerate(_caps):
        if g < s:
            continue
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        if r == 0:
            perfect_exists = True
        # primary: integer SS delta scaled, secondary: smaller residual preferred
        scores[k] = -(float(delta) * 1000.0 + r)
        k += 1

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        scores[n_fitting:] = -1.0e12          # strongly discourage opening a new bin
    else:
        scores[n_fitting:] = -(float(delta_new) * 1000.0 + r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < n_fitting:
        j = [jj for jj, g in enumerate(_caps) if g >= s][choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

