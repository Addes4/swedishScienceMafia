# EVOLVE-BLOCK-START
"""SS (sum-of-squares) rule with a recency-weighted target-residual tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion; among placements with equal SS delta we prefer the residual r closest to a
target T, where T is a running percentile (60th) of recently seen item sizes. This keeps
partially-open bins sized for typical future items instead of uniformly chasing the largest
residual. The function is shown only the bins the item fits in, so it keeps its own record of
every opened bin. Used bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_recent = []                   # recent item sizes (bounded window)
_WIN = 200


def _target():
    """Running 60th percentile of recent item sizes, clamped to [1, CAP]."""
    if not _recent:
        return 40
    arr = np.array(_recent, dtype=np.float64)
    t = int(np.percentile(arr, 60))
    if t < 1:
        t = 1
    elif t > CAP:
        t = CAP
    return t


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    T = _target()

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta (as large negative as possible).
        # Tie-break: prefer residual r closest to the running target T.
        scores[k] = -(float(delta) * 1000.0 - abs(r - T))

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(float(delta_new) * 1000.0 - abs(r_new - T))

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update recent-item window
    _recent.append(s)
    if len(_recent) > _WIN:
        del _recent[0]

    return scores
# EVOLVE-BLOCK-END
