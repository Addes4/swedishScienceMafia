# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with perfect-fit prioritisation (vectorized).

Each item goes where it minimises sum_g N(g)^2 (the SS rule), known to be asymptotically
optimal for this online bin packing setting. Values are computed directly from the `bins`
array the harness provides, so there is no parallel bookkeeping to desync. Ties are broken
by preferring a perfect fit (residual 0), then the tighter fit.
"""
import numpy as np

CAP = 100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = int(item)
    g = bins.astype(np.int64, copy=False)

    # Residual distribution of currently OPEN bins (remaining capacity exclusive of full bins).
    # Note: the harness only shows bins the item fits in, so g >= s for all shown bins.
    counts = np.bincount(g, minlength=CAP + 1)  # counts[0] unused here; full bins not shown

    r = g - s                                   # residual after placing the item
    r_safe = np.where(r > 0, r, 0)              # avoid indexing N[0] contributions

    # Exact SS cost change: delta = N[r]+1 if r>0 else 0, minus N[g]  (bin g loses, residual gains)
    delta = (counts[r_safe] + (r > 0)) - counts[g]

    # Perfect-fit override: residual 0 is a hard priority.
    perfect = (r == 0)

    # Combined score: perfect fits first, then minimal delta, then tighter (smaller) residual.
    # Encode as negative combined key so argmax picks it (ties -> first bin).
    score = -(delta * (CAP + 1) + r) - perfect * (1 << 30)
    return score
# EVOLVE-BLOCK-END
