# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-matching tie-break.

Each item goes where it minimises sum_g N(g)^2 (the sum-of-squares / SS rule), known to be
good for online bin packing. The primary key is the true SS cost change
(2*N[r] - 2*N[g] + 1, with r the residual). Ties are broken lexicographically by:
  (1) perfect fit (r == 0),
  (2) residual that equals a recently seen item size (helps future exact fills),
  (3) smaller residual (best fit).
The function keeps its own record of every opened bin; used bins are a prefix of the bin
array and each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                       # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)             # N[g]: open bins with remaining capacity g, 0 < g < CAP
_seen_size = [0] * (CAP + 1)     # counts of recent item sizes (sliding-ish, simple EMA/no decay)


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest score (first on ties)."""
    global _caps, _N, _seen_size
    s = int(item)

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    perfect_exists = any(_caps[j] == s for j in fitting)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # True SS cost change (used as primary, negated for argmax).
        delta = 2 * _N[r] - 2 * _N[g] + 1 if r > 0 else (0 - 2 * _N[g] + 1)
        primary = -float(delta)
        if r == 0:
            tb1 = 1.0        # perfect fit is best
        else:
            tb1 = 0.0
        if r > 0 and _seen_size[r] > 0:
            tb2 = 1.0        # residual matches a seen size -> potentially fillable later
        else:
            tb2 = 0.0
        # Combine: primary dominates; tie-breaks lexicographic in a bounded way.
        # Use a large multiplier on primary so it never gets overridden.
        scores[k] = primary * 8.0 + tb1 * 2.0 + tb2 * 1.0 - r * 0.001

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        scores[len(fitting):] = -1.0e12
    else:
        scores[len(fitting):] = -float(delta_new) * 8.0 - r_new * 0.001

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # record seen size
    _seen_size[s] += 1
    return scores
# EVOLVE-BLOCK-END
