# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a size-aware gap-closing tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion. Among placements with equal SS delta we prefer the residual that is most
likely to be filled soon: we score the residual by how well it matches sums of recently seen
item sizes (a short recent window), so gaps that can be closed with common small/medium items
are preferred, while otherwise falling back to the larger residual to keep flexible free space.
The function is shown only the bins the item fits in, so it keeps its own record of every opened
bin. Used bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_recent = []                   # short window of recently seen item sizes
_RECENT_LEN = 24
# Precompute useful summary: cheap reachability of residuals by 1-2 recent item sizes.
_recent_sizes = []


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _recent, _recent_sizes
    s = int(item)

    # update recency window
    _recent.append(s)
    if len(_recent) > _RECENT_LEN:
        _recent.pop(0)
    _recent_sizes = sorted(set(_recent))

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # reward residuals that are reachable as a sum of up to two recent sizes (gap closing)
    def gap_bonus(r):
        if r == 0:
            return 1000.0
        best = 0.0
        for a in _recent_sizes:
            if a > r:
                break
            if a == r:
                return 1000.0
            for b in _recent_sizes:
                sm = a + b
                if sm == r:
                    return 500.0
                if sm > r:
                    break
        return best

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta. Tie-break: gap-closing bonus, then larger residual.
        scores[k] = -(float(delta) * 1000000.0) + gap_bonus(r) * 1000.0 + r

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(float(delta_new) * 1000000.0) + gap_bonus(r_new) * 1000.0 + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

