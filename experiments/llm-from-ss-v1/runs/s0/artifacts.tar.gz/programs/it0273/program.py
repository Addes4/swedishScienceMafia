# EVOLVE-BLOCK-START
"""Best-fit with a flexibility gate.

Classic best-fit (smallest sufficient residual) is the strongest practical online rule for
randomly-distributed integer items. To avoid creating useless dead space, we add a bonus
whenever a placement leaves a residual at least as large as the arriving item (i.e. the bin
could still hold a copy of this item), which keeps such bins "reusable" for similar future
items. The function keeps its own record of every opened bin because it is shown only bins
the item fits in.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # Primary: smaller residual is better -> score decreases with r.
        # Bonus: residual large enough to hold another copy of this item.
        bonus = 1000.0 if r >= s else 0.0
        scores[k] = bonus - float(r)

    r_new = CAP - s
    bonus_new = 1000.0 if r_new >= s else 0.0
    scores[len(fitting):] = bonus_new - float(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        _caps[j] = _caps[j] - s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END

