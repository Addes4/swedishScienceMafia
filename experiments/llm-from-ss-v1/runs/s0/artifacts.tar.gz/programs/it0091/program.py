# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with perfect-fit prioritisation.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), which is known to
be asymptotically optimal for this kind of online bin packing. Ties and near-ties are broken
by preferring a perfect fit (residual 0) and, failing that, a mid-sized residual that is most
likely reusable. The function is shown only the bins the item fits in, so it keeps its own
record of every opened bin. Used bins are a prefix of the bin array; each instance runs in a
fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_sum = [0]                     # running sum of item sizes (for mean estimate)
_cnt = [0]                     # running count of items


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    _sum[0] += s
    _cnt[0] += 1
    mean_item = _sum[0] / _cnt[0]
    # target residual: roughly enough for a mid-sized item, keeps bins reusable
    target = mean_item * 0.5

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Prefer perfect fits: find if any fitting bin has residual 0.
    perfect_exists = any(_caps[j] == s for j in fitting)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # secondary: closeness of residual to target (smaller is better)
        fit_cost = abs(r - target) if r > 0 else 0.0
        if r == 0:
            base = -1.0e9
            scores[k] = -(base * 1000.0 + fit_cost)
        else:
            scores[k] = -(float(delta) * 1000.0 + fit_cost)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        # Discourage opening a new bin when a perfect fit exists.
        scores[len(fitting):] = -1.0e12
    else:
        fit_cost_new = abs(r_new - target) if r_new > 0 else 0.0
        scores[len(fitting):] = -(float(delta_new) * 1000.0 + fit_cost_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
