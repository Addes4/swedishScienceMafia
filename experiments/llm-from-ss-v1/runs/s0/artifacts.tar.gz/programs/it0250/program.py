# EVOLVE-BLOCK-START
"""Best-Fit style rule for online bin packing.

Items arrive online and are placed into the bin where they leave the smallest positive
residual (Best-Fit). Perfectly filling a bin (residual 0) is preferred above everything,
and among equal residuals the first bin (smallest index, typically the fullest) wins. The
function is shown only the bins that fit, so it keeps its own record of every opened bin.
Used bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []      # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Best-Fit: prefer the smallest residual. Encode so higher score == better and ties
    # go to the earlier bin index (numpy argmax picks the first max).
    for k, j in enumerate(fitting):
        r = _caps[j] - s
        scores[k] = -float(r)          # smaller residual -> higher score

    # New bin: residual = CAP - s, placed after all used bins in the array.
    r_new = CAP - s
    scores[len(fitting):] = -float(r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        _caps[j] = _caps[j] - s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
