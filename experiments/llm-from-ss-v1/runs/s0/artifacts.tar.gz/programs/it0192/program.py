# EVOLVE-BLOCK-START
"""Best-Fit (dominant) with Sum-of-Squares tie-break.

Classic online bin packing heuristics: Best-Fit puts the item into the fitting bin with the
smallest *resulting residual* (tightest fit), which minimises wasted space and matches the
lower bound closely on smooth size distributions. Pure SS is asymptotically optimal but its
integer delta creates many ties that fragment bins. Here we use the exact residual as the
strictly dominant key and resolve residual ties with the exact SS delta (fewer remaining bins
of the same capacity class), combining the two: tight fits first, SS-smoothness second.

The harness shows only the bins the item fits in, so we keep our own record of opened bins.
Used bins form a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: smallest resulting residual (best fit).
        # Tie-break: smallest SS delta (more negative is better).
        scores[k] = -(float(r) * 1000.0 + float(delta))

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(float(r_new) * 1000.0 + float(delta_new))

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
