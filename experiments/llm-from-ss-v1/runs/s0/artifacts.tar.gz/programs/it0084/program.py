# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a graded best-fit tie-break.

Each item goes where it minimises the sum-of-squares (SS) delta, which is asymptotically
optimal for online bin packing. Instead of a brittle hard perfect-fit override, near-perfect
fits get a modest graded bonus, and exact SS ties are broken by the tighter (smaller) residual.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Graded perfect-fit bonus: exact fit strongly preferred, near fits mildly.
        bonus = 0.0
        if r == 0:
            bonus = 50.0
        elif r <= 5:
            bonus = 6.0 - r
        # Primary: SS delta (lower is better). Secondary: tighter residual.
        scores[k] = -(float(delta) * 100.0 - bonus + r * 0.01)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(float(delta_new) * 100.0 + r_new * 0.01)

    choice = int(np.argmax(scores))          # harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
