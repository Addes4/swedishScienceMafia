# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with perfect-fit prioritisation and frequency-aware tie-break.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), which is known to
be asymptotically optimal for this kind of online bin packing. Perfect fits are given top
priority. Among remaining placements whose SS delta is (nearly) tied, we prefer the residual
that matches the most frequently seen past item size, since such a residual is more likely to
be filled exactly by a future item. The function is shown only the bins the item fits in, so
it keeps its own record of every opened bin. Used bins are a prefix of the bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # empirical frequency of arriving item sizes


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first ties)."""
    global _caps, _N, _freq
    s = int(item)
    _freq[s] += 1

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    def fit_bonus(r):
        # small bonus when residual r matches a commonly seen item size
        if r <= 0:
            return 0.0
        return float(_freq[r])

    # Best delta among existing bins for tie-breaking.
    deltas = []
    for j in fitting:
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        deltas.append((delta, r, j))
    best_delta = min((d for d, r, j in deltas), default=0)

    perfect_exists = any(_caps[j] == s for j in fitting)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        if r == 0:
            base = -1.0e9
        else:
            # nudge by fit bonus only within the tied-delta group, scaled tiny
            bonus = fit_bonus(r) * 1e-6 if delta == best_delta else 0.0
            base = float(delta) - bonus
        scores[k] = -(base * 1000.0 + r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        scores[len(fitting):] = -1.0e12
    else:
        scores[len(fitting):] = -(float(delta_new) * 1000.0 + r_new)

    choice = int(np.argmax(scores))          # harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
