# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a mode-size-aware tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion. Among placements with equal SS delta we prefer the placement whose residual
after placement is smallest among those that remain useful, i.e. at least the running mode of
item sizes seen so far -- this keeps free space shaped for the most common future item while
not wasting capacity on smaller-than-useful residuals. The function keeps its own record of
every opened bin since it is only shown the bins the item fits in.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_size_count = [0] * (CAP + 1)  # running histogram of item sizes
_mode_size = [1]               # current most common item size (mutable cell)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _caps, _N
    s = int(item)

    # Update running mode of item sizes (cheap, single-item update).
    _size_count[s] += 1
    if _size_count[s] >= _size_count[_mode_size[0]]:
        _mode_size[0] = s
    mode = _mode_size[0]

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta. Tie-break: prefer the smallest residual that is still
        # at least the running mode size (useful), else prefer the largest residual.
        if r >= mode:
            tie = -r          # prefer smallest useful residual
        else:
            tie = r - CAP     # prefer larger residual when below mode (less negative)
        scores[k] = -(float(delta) * 1000.0 - tie)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if r_new >= mode:
        tie_new = -r_new
    else:
        tie_new = r_new - CAP
    scores[len(fitting):] = -(float(delta_new) * 1000.0 - tie_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
