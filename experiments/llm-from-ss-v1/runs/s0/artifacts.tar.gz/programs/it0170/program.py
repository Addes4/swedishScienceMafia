# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a residual-mode-preserving tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer and is used as the
dominant criterion. Among placements with equal SS delta we prefer the placement whose
resulting residual equals the currently most common open-bin residual (the mode), so that
free space stays concentrated in a few residual classes rather than fragmented across many.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Unused bins have remaining capacity CAP and are kept as a class too.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_counts = np.zeros(CAP + 1, dtype=np.int64)   # counts by residual 1..CAP (incl. empty=CAP)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _counts
    s = int(item)
    L = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = L - len(fitting)
    scores = np.empty(L, dtype=np.float64)

    # Current modal residual among all existing bins (fit or not) and empty bins.
    if L > 0:
        mode_r = int(np.argmax(_counts[1:])) + 1
    else:
        mode_r = CAP

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        bonus = 1.0 if r == mode_r else 0.0
        scores[k] = -(float(delta) * 1000.0 - bonus)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    bonus_new = 1.0 if r_new == mode_r else 0.0
    scores[len(fitting):] = -(float(delta_new) * 1000.0 - bonus_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _counts[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
            _counts[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        _counts[CAP] -= 1
        if CAP - s > 0:
            _N[CAP - s] += 1
            _counts[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
