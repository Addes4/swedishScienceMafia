# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a complementary-fit tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion; among placements with equal SS delta we prefer the residual that is most
likely to be exactly consumed by a future item, i.e. a residual value that matches a recent
item size (so leftover space is reused rather than stranded). The function is shown only the
bins the item fits in, so it keeps its own record of every opened bin. Used bins are a prefix
of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_ITEM = [0] * (CAP + 1)        # recency-weighted count of item sizes seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _ITEM
    s = int(item)
    # decay item history and record this item
    if s <= CAP:
        _ITEM[s] += 1
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Tie-break: prefer residual that is a popular future item size (reusable), and
        # secondarily the larger residual.
        reuse = _ITEM[r] if 0 < r <= CAP else 0
        scores[k] = -(float(delta) * 100000.0 - float(reuse) * 100.0 - r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    reuse_new = _ITEM[r_new] if 0 < r_new <= CAP else 0
    scores[len(fitting):] = -(float(delta_new) * 100000.0 - float(reuse_new) * 100.0 - r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
