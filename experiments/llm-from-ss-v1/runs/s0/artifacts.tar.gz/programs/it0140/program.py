# EVOLVE-BLOCK-START
"""Exact Sum-of-Squares rule with a Best-Fit tie-break.

Csirik, Johnson, Kenyon, Orlin, Shor, Weber's "Sum of Squares" (SS) rule is asymptotically
optimal for items bounded by a constant fraction of the bin capacity. Each item is placed to
minimise the increase in sum_g N(g)^2, where N(g) is the number of open bins with residual g.
Because N(g)^2 grows, SS strongly prefers filling already-full-ish bins rather than opening new
ones, matching the asymptotic optimum.

Concretely, placing the item into a bin with residual g (residual becomes r = g - s) changes the
sum by  delta = -2*N(g) + 1 + (2*N(r) + 1 if r > 0 else 0).
We rank bins by delta (smaller is better). On an exact tie in delta (which happens often) we
use Best Fit: prefer the smaller residual r, concentrating large free residuals so future
large items can still be packed. New (unused) bins have residual 100, so they are considered
last among tied deltas.

The function is only shown the bins the item fits in, so it keeps its own record of every
opened bin in bin-index order (used bins form a prefix).
"""
import numpy as np

CAP = 100
_caps = []                     # residual capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with residual capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _caps, _N
    s = int(item)

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta (negated so argmax picks the smallest delta).
        # Tie-break: smaller residual r is better (Best Fit), so subtract r scaled below 1.
        scores[k] = -float(delta) * 1000.0 - r * 0.001

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -float(delta_new) * 1000.0 - r_new * 0.001

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
