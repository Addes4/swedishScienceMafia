# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a fragmentation-minimising tie-break.

The SS rule (place the item to minimise sum_g N(g)^2) is asymptotically optimal for online
bin packing. Its delta is an exact integer, so it is used as the strictly dominant criterion.
Among placements with equal SS delta we break ties by preferring the placement that leaves the
fewest distinct residual sizes among open bins (a measure of state fragmentation), which keeps
future SS decisions clean and helps avoid opening extra bins. The function is shown only the
bins the item fits in, so it keeps its own record of every opened bin.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta (as large negative as possible).
        # Tie-break: prefer fewer distinct residual sizes (new size counts if it would appear).
        if r > 0:
            new_size = 1 if _N[r] == 0 and r != g else 0
        else:
            new_size = 0 if _N[g] > 1 else 0
        # removing g: size g disappears if it was the only bin with that residual
        g_disappears = 1 if _N[g] == 1 and r != g else 0
        frag = new_size - g_disappears
        scores[k] = -(float(delta) * 1000.0 + frag)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    new_size = 1 if r_new > 0 and _N[r_new] == 0 else 0
    scores[len(fitting):] = -(float(delta_new) * 1000.0 + new_size)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
