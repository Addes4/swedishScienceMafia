# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with usefulness-weighted tie-breaking.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), which is known to
be asymptotically optimal for this kind of online bin packing. Among bins with equal SS delta
we break ties by preferring the residual that is most "useful" according to the empirical
item-size histogram observed so far: residuals of 0 (perfect fit) are best, then residuals that
match a frequently seen item size, then everything else. This is implemented as a small
fractional bonus so it never overrides a genuine SS delta difference. The function keeps its
own record of every opened bin (used bins are a prefix of the bin array; each instance runs in
a fresh process).
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0.0] * (CAP + 1)      # smoothed histogram of observed item sizes
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _hist, _total
    s = int(item)

    # Smoothed empirical histogram update (Laplace-ish smoothing).
    for i in range(1, CAP + 1):
        _hist[i] *= 0.999
    _hist[s] += 1.0
    _total = _total * 0.999 + 1.0

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    perfect_exists = any(_caps[j] == s for j in fitting)

    def usefulness(r):
        # Higher = better residual for future items. Perfect fit is handled separately.
        if r <= 0:
            return 0.0
        return _hist[r] / _total if _total > 0 else 0.0

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        if r == 0:
            base = -1.0e9
        else:
            # SS delta plus a small usefulness bonus for the residual we would leave.
            base = float(delta) - 0.05 * usefulness(r)
        scores[k] = -(base * 1000.0 + r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        scores[len(fitting):] = -1.0e12
    else:
        base_new = float(delta_new) - 0.05 * usefulness(r_new)
        scores[len(fitting):] = -(base_new * 1000.0 + r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
