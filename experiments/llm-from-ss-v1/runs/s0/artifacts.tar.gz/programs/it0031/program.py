# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with perfect-fit prioritisation and residual-matching tie-break.

Each item goes where it minimises sum_g N(g)^2 (the sum-of-squares / SS rule), which is
asymptotically optimal for this kind of online bin packing. The primary key is the true SS
cost change delta = 2*N[r]-2*N[g]+1. A perfect fit (r == 0) is given a bounded dominant
offset so it always wins when available. Remaining ties are broken by preferring residuals
that exactly match an item size seen so far (tracked by frequency), then by the tighter fit.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                          # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)                # N[g]: open bins with remaining capacity g, 0 < g < CAP
_SEEEN = np.zeros(CAP + 1, dtype=np.int64)   # count of each item size seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    _SEEEN[s] += 1
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    m = len(bins)
    scores = np.empty(m, dtype=np.float64)

    # Distinct item sizes seen so far (boolean mask over sizes, excluding 0).
    seen_mask = _SEEEN > 0

    perfect_exists = any(_caps[j] == s for j in fitting)

    # Bounded dominant offset for perfect fit (larger than any real SS delta).
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = 2 * _N[r] - 2 * _N[g] + 1
        key = float(delta)
        if r == 0:
            key -= 1.0e6                    # perfect fit dominates SS
        else:
            # tiny tie-break: prefer residual matching a seen item size, then tighter fit
            resid_bonus = 0.5 if seen_mask[r] else 0.0
            key += (-resid_bonus) - r * 1.0e-4
        scores[k] = -key

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    key_new = float(delta_new) - r_new * 1.0e-4
    if perfect_exists:
        scores[len(fitting):] = -1.0e9      # discourage opening a new bin when a perfect fit exists
    else:
        scores[len(fitting):] = -key_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
