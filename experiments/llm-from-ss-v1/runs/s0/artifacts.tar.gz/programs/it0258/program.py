# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a match-frequency tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer and is the dominant
criterion. Among placements with equal SS delta we break ties by preferring the residual that
has historically been filled exactly by past item sizes most often (a recency-weighted count),
falling back to the larger residual. The function is shown only the bins the item fits in, so
it keeps its own record of every opened bin; used bins form a prefix of the bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_fillcnt = [0.0] * (CAP + 1)   # recency-weighted count of items equal to each residual value
_decay = 0.9995
_t = [0]


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _fillcnt, _t
    s = int(item)
    _t[0] += 1
    # decay match counts toward more recent behaviour
    if _t[0] % 64 == 0:
        d = _decay ** 64
        for g in range(1, CAP + 1):
            _fillcnt[g] *= d

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta. Tie-break: prefer residual historically fillable, then larger.
        match = _fillcnt[r] if r > 0 else 0.0
        scores[k] = -(float(delta) * 1000.0) + match * 0.5 + r * 0.001

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    match_new = _fillcnt[r_new] if r_new > 0 else 0.0
    scores[len(fitting):] = -(float(delta_new) * 1000.0) + match_new * 0.5 + r_new * 0.001

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # record this item's size as evidence of a fillable residual value
    if 1 <= s <= CAP:
        _fillcnt[s] += 1.0
    return scores
# EVOLVE-BLOCK-END

