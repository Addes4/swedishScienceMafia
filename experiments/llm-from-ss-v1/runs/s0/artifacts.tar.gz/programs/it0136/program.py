# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a distribution-aware tie-break.

An item goes where it minimises sum_g N(g)^2 (the SS rule), an asymptotically optimal online
rule for this item-size class. The SS delta is an exact integer; we make it strictly dominant
by scaling with a multiplier larger than any possible tie-break value. Among placements with an
equal SS delta we prefer the resulting residual that is closest to the typical arriving item
size (mean ~40), preserving bins that can still fit a typical item while not over-fragmenting.

The function only sees bins the item fits in, so it keeps its own record of every opened bin.
Used bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
MEAN = 40.0
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# max |delta| <= 2*CAP+1 = 201, so multiplier 1000 makes SS strictly dominant over tie-break
# which is bounded by CAP (< 100).
SS_MULT = 1000.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Tie-break: prefer residual closest to typical item size (flexible, not fragmented).
        fit = -abs(r - MEAN)
        scores[k] = -float(delta) * SS_MULT + fit

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    fit_new = -abs(r_new - MEAN)
    scores[len(fitting):] = -float(delta_new) * SS_MULT + fit_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

