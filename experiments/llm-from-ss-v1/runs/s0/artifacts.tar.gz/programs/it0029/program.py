# EVOLVE-BLOCK-START
"""Best-fit rule with a residual-matching tie-break.

Each item goes into the fitting bin whose residual after placement is smallest (classic Best
Fit). Among bins with the same residual, prefer one whose residual is a size that has actually
been seen among recent arrivals, since such a residual is likely to be filled exactly. The
function is shown only the bins the item fits in, so it keeps its own record of every opened
bin. Used bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                       # remaining capacity of every opened bin, in bin-index order
_seen = np.zeros(CAP + 1, dtype=np.int64)   # decayed counts of item sizes seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]

    _seen[s] += 4
    _seen >>= 1                  # decay old observations

    scores = np.empty(len(bins), dtype=np.float64)

    # Best fit: smallest residual first; tie-break by whether that residual is a seen size.
    for k, j in enumerate(fitting):
        r = _caps[j] - s
        tie = 1.0 if (r > 0 and _seen[r] > 0) else 0.0
        scores[k] = -(r * 2.0 + (1.0 - tie))

    r_new = CAP - s
    tie_new = 1.0 if (r_new > 0 and _seen[r_new] > 0) else 0.0
    scores[len(fitting):] = -(r_new * 2.0 + (1.0 - tie_new) + 1.0)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        _caps[j] -= s
    elif len(bins) > len(fitting):
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END

