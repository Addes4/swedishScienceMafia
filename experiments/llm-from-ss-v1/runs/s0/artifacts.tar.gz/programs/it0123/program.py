# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a one-step lookahead tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion; among placements with equal SS delta we apply a cheap one-step lookahead:
we imagine the next item having the distribution's typical size (P = 40) and prefer the
placement for which the *best possible* such placement incurs the smallest SS-delta increase.
This keeps future average-sized items packable without opening new bins. The function is shown
only the bins the item fits in, so it keeps its own record of every opened bin.
"""
import numpy as np

CAP = 100
P = 40                         # typical (mean) item size used for the lookahead
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _best_future_delta():
    """Smallest SS-delta achievable by placing one item of size P now."""
    best = None
    for g in range(P, CAP):
        if _N[g] > 0:
            r = g - P
            d = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            if best is None or d < best:
                best = d
    # opening a fresh bin
    r_new = CAP - P
    d_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if best is None or d_new < best:
        best = d_new
    return best


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # dominant: exact SS delta. tie-break: smaller future lookahead penalty.
        # Apply the temporary change to _N to evaluate the lookahead.
        _N[g] -= 1
        if r > 0:
            _N[r] += 1
        fut = _best_future_delta()
        if r > 0:
            _N[r] -= 1
        _N[g] += 1
        scores[k] = -(float(delta) * 1000.0 + float(fut))

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(float(delta_new) * 1000.0 + float(_best_future_delta()))

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
