# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a flexibility-preserving tie-break plus a dead-space penalty.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion; among placements with equal SS delta we prefer the placement that leaves
the *larger* residual, keeping flexible free space available for future large items. As an
extra nudge within the residual ranking, residuals that are too small to ever be filled by a
future item (below the running minimum observed item size, and nonzero) are slightly
penalized, since they are effectively wasted space. The function keeps its own record of
every opened bin. Used bins are a prefix of the bin array; each instance runs in a fresh
process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_smin = [CAP + 1]              # running minimum observed item size


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _smin
    s = int(item)
    if s < _smin[0]:
        _smin[0] = s
    smin = _smin[0]
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    def resid_score(r):
        # Larger residual is generally better (more flexibility).
        v = float(r) * 1000.0
        # Penalize nonzero residuals that are too small to ever be filled
        # (below the smallest item size seen so far): effectively dead space.
        if r > 0 and r < smin:
            v -= 100.0
        return v

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta (as large negative as possible).
        # Tie-break: larger residual, minus a dead-space penalty.
        scores[k] = -(float(delta) * 1e6) + resid_score(r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(float(delta_new) * 1e6) + resid_score(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

