# EVOLVE-BLOCK-START
"""Best-Fit rule.

Each item goes into the fitting bin with the smallest remaining capacity that still holds it
(tightest fit). This concentrates items into already-opened bins and avoids fragmenting free
space, which reduces the number of bins opened. Since unused bins have remaining capacity 100
(the maximum), they are only chosen when no opened bin has enough residual space; ties go to
the earliest bin index. The harness enforces capacity, so we only rank the bins it shows us.
"""
import numpy as np

CAP = 100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    g = np.asarray(bins, dtype=np.float64)
    # Smallest remaining capacity => highest score. Use -g so argmax picks the tightest fit.
    return -g
# EVOLVE-BLOCK-END
