# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-class tie-breaking.

Each item goes where it minimises the true sum-of-squares (SS) cost change
    2*N[r] - 2*N[g] + 1   (r = residual after placement, g = current residual, N = #bins with that residual)
which is asymptotically optimal for this kind of online bin packing. Because the primary key is
an integer the ranking is exact and free of scaling artefacts. Ties are broken lexicographically:
first residual class (harmonic classes {>50, >33, >25, ...} are 'useful' because they can still
hold a large item), then the smaller residual. Perfect fits (r == 0) have cost change that is
usually minimal and are additionally favoured by the residual tie-break. The function is shown
only the bins the item fits in, so it keeps its own record of every opened bin. Used bins are a
prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _rclass(r):
    """Residual class: lower is 'more useful'. Perfect fit best, then large-ish residuals."""
    if r == 0:
        return 0
    if r > 50:
        return 1
    if r > 33:
        return 2
    if r > 25:
        return 3
    if r > 20:
        return 4
    if r > 16:
        return 5
    if r > 10:
        return 6
    return 7


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        cr = _rclass(r)
        # Primary: SS delta (smaller is better -> higher score). Ties: residual class, residual.
        scores[k] = -float(delta * 100000 + cr * 1000 + r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    crn = _rclass(r_new)
    scores[len(fitting):] = -float(delta_new * 100000 + crn * 1000 + r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
