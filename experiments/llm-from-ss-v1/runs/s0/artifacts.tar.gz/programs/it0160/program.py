# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a heavy-tail-aware tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer and is used as the
dominant criterion via a lexicographic integer key (so distinct deltas never collide). Among
placements with equal SS delta we break ties by preferring a residual that keeps room for the
largest item sizes seen so far (a good "best-fit for big items" surrogate): specifically we
prefer the residual that is the smallest one still >= the running maximum item size, otherwise
the largest residual, which avoids fragmenting large free spaces.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_max_item = [1]                # largest item size seen so far (mutable holder)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _max_item
    s = int(item)
    if s > _max_item[0]:
        _max_item[0] = s
    big = _max_item[0]

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.int64)

    # Tie-break rank: prefer the smallest residual that is still >= the largest item seen,
    # so big items keep a home; otherwise fall back to the largest residual available.
    # Encode smaller residual as better with -r, but shift the "room for big items" set up.
    def tie(r):
        if r <= 0:
            # exact fill: very good, but keep it just below any r>=big to avoid wasting big room
            return 2 * CAP + 1 if r == 0 else 2 * CAP - r
        if r >= big:
            # residual can host the biggest item: prefer the tightest such (best fit for big)
            return 2 * (CAP - r) + 1
        # residual too small for the biggest item: prefer the largest (least fragmentation)
        return 2 * (CAP - r) + 1

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = delta * 100000 + (tie(r) - 5000)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = delta_new * 100000 + (tie(r_new) - 5000)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

