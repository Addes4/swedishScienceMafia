# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with observed-size residual matching.

The primary criterion is the sum-of-squares (SS) rule: place the item in the bin that
minimises sum_g N(g)^2, which is asymptotically optimal for online bin packing. Ties and
near-ties are broken by rewarding a residual that equals an item size already observed (so it
can plausibly be exactly filled later) and, secondarily, by the tighter fit. The function is
shown only the bins the item fits in, so it keeps its own record of every opened bin. Used
bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_seen = [False] * (CAP + 1)    # _seen[s]: item size s has been observed at least once


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _seen
    s = int(item)
    _seen[s] = True
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    def residual_reward(r):
        # Reward residuals that match an already-seen item size (likely fillable later).
        if r == 0:
            return 1.0
        return 0.6 if _seen[r] else 0.0

    # Find minimal SS delta among fitting bins (and the new-bin option).
    best_delta = None
    deltas = []
    for j in fitting:
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        deltas.append(delta)
        if best_delta is None or delta < best_delta:
            best_delta = delta
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if best_delta is None or delta_new < best_delta:
        best_delta = delta_new

    # Higher score = better. Primary: -delta (minimise). Then residual reward, then tighter fit.
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = deltas[k]
        near = 1.0 if delta <= best_delta + 1 else 0.0
        scores[k] = -delta * 1000.0 + near * 100.0 + residual_reward(r) * 10.0 - r
    near_new = 1.0 if delta_new <= best_delta + 1 else 0.0
    scores[len(fitting):] = -float(delta_new) * 1000.0 + near_new * 100.0 \
        + residual_reward(r_new) * 10.0 - r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

