# EVOLVE-BLOCK-START
"""Sum-of-Squares rule, exact integer key, with a flexibility-preserving tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer and is made strictly
dominant by scaling it far above any possible tie-break contribution. Among placements with
equal SS delta we prefer, in order: (1) reusing an existing bin over opening a fresh one,
(2) leaving a residual that is still large enough to host a typical future item, since
concentrating items and leaving flexible space is better than fragmenting bins.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Strictly dominant scale for the SS delta (delta magnitudes are tiny, < 2*CAP+2).
    SS_SCALE = 1 << 20

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Secondary: existing-bin bonus, then prefer a smaller residual (fill tighter).
        tie = 0.5 - r * 1e-4
        scores[k] = -delta * SS_SCALE + tie

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    # New bin is strictly worse than any existing-bin tie at equal SS delta.
    scores[len(fitting):] = -float(delta_new) * SS_SCALE - 1.0

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
