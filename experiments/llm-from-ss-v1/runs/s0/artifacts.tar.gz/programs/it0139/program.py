# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a distribution-aware tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is computed exactly and used as the strictly
dominant key. Among placements with equal SS delta, we prefer the placement whose resulting
residual is close to a running estimate of the typical remaining "room" that future items want
(the largest common item size we have seen recently), so bins are neither over-fragmented into
tiny slivers nor left too loose. The function keeps its own record of every opened bin, since
the harness only shows the bins the item fits in.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_MAXSEEN = [1]                 # running max observed item size


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    if s > _MAXSEEN[0]:
        _MAXSEEN[0] = s
    target = _MAXSEEN[0]        # residual we roughly want available for a future large item

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta (as large negative as possible).
        # Tie-break: residual closest to the target room for future items.
        scores[k] = -(float(delta) * 1000.0 + abs(r - target) * 0.01)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(float(delta_new) * 1000.0 + abs(r_new - target) * 0.01)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
