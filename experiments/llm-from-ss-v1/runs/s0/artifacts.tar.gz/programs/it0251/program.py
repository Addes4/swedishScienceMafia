# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a "matchable small residual" tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion; among placements with equal SS delta we prefer residuals r that are exactly
fillable by a recently-common small item size (those tiny items are what most often close gaps),
and only then prefer the larger residual (more flexible free space for future large items).
The function is shown only the bins the item fits in, so it keeps its own record of every opened
bin. Used bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Recency-weighted frequency of recent small item sizes, so we know which residuals
# are likely to be exactly filled by upcoming small items.
_freq = np.zeros(CAP + 1, dtype=np.float64)
_decay = 0.99
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _freq, _seen
    s = int(item)

    # Update recency-weighted histogram of item sizes.
    _freq *= _decay
    _freq[s] += 1.0
    _seen += 1

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    def match_bonus(r):
        # How likely is r to be exactly closed by an upcoming single item?
        return _freq[r] if r > 0 else 0.0

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta (as large negative as possible).
        # Secondary: residual likely fillable by a common small item.
        # Tertiary: prefer the larger residual (more flexible free space).
        scores[k] = -(float(delta) * 1000000.0 - match_bonus(r) * 1000.0 - float(r))

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(float(delta_new) * 1000000.0 - match_bonus(r_new) * 1000.0 - float(r_new))

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
