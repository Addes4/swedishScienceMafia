# EVOLVE-BLOCK-START
"""Harmonic (H_k) bin-selection rule.

The objective SUM over open bins of h(remaining capacity) is maintained, where
h(g) = 1/g (harmonic weight). Placing an item of size s into a bin with capacity g
removes one class-g bin and adds one class-(g-s) bin, so the delta is
h(g-s) - h(g). The item goes to the arrangement with the smallest (most negative)
delta. To keep exact integer arithmetic we compare deltas using a fixed common
denominator (LCM-style scaling by 100!-free approach): we instead use a scaled
integer weight W(g) = round(SCALE / g) with a large SCALE, and compare exact
integer deltas; this approximates h closely enough. The function keeps its own
record of every opened bin since it only sees fitting bins.
"""
import numpy as np

CAP = 100
SCALE = 10 ** 12
# Precomputed scaled harmonic weights W(g) = round(SCALE / g), g = 0..100.
_W = [0] * (CAP + 1)
for _g in range(1, CAP + 1):
    _W[_g] = SCALE // _g
_W[0] = 0

_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    s = int(item)
    W = _W
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        # delta of objective W: new residual r replaces g
        delta = W[g - s] - W[g]
        # Prefer most negative delta (largest reduction); scale to float.
        scores[k] = -float(delta)

    r_new = CAP - s
    delta_new = W[r_new] - W[CAP]
    scores[len(fitting):] = -float(delta_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        _caps[j] -= s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END

