# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual matching.

Each item goes where it minimises sum_g N(g)^2 (the sum-of-squares / SS rule), which is
asymptotically optimal for online bin packing. Among moves with (nearly) equal SS delta we
prefer residuals that were themselves item sizes already seen: such a residual can be filled
exactly by a future item of that size, eliminating wasted space. The function is shown only
the bins the item fits in, so it keeps its own record of every opened bin. Used bins are a
prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_seen = [False] * (CAP + 1)    # item sizes observed so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest score (first on ties)."""
    global _caps, _N, _seen
    s = int(item)
    _seen[s] = True
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # match bonus: residual 0 (perfect fit) or a residual that is a seen item size
        if r == 0:
            match = 2
        elif _seen[r]:
            match = 1
        else:
            match = 0
        scores[k] = -(float(delta) * 1000.0 + (0 if match == 2 else (500 - match * 400)) + r * 0.001)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(float(delta_new) * 1000.0 + 900.0 + r_new * 0.001)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
