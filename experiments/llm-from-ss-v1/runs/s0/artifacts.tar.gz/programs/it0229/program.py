# EVOLVE-BLOCK-START
"""Smoothed sum-of-squares rule (behavioral SS, finer-grained).

The classic SS rule (minimise sum_g N(g)^2) is asymptotically optimal, but its exact integer
delta produces coarse ties that our tie-breaks keep mishandling. Here we replace the discrete
population N(g) by a smoothed weight W(g) = sum over open bins with residual g of g/(g+a).
This keeps the "consolidate the same residual" gradient of SS while making it continuous, so
near-optimal placements are ranked by a smooth score instead of falling back on a hand-made
tie-break. The gain of moving an item of size s into a bin with residual g is
    -(2*W(g)+1) + (2*W(g-s)+1 if g-s>0 else 0) * scaling
which mirrors the SS delta but on the smoothed weights. We keep our own record of open bins
(the array shown is a copy, and used bins form a prefix).
"""
import numpy as np

CAP = 100
_alpha = 0.5                   # smoothing of the residual-weight function
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_W = [0.0] * (CAP + 1)         # smoothed weight per residual class


def _w(r):
    return r / (r + _alpha) if r > 0 else 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties)."""
    global _caps, _W
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    base_gain = -2.0 * _W[s] - 1.0  # W(r) with r relevant
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        gain = -(2.0 * _W[g] + 1.0)
        if r > 0:
            gain += 2.0 * _W[r] + 1.0
        # tie-break: prefer larger residual (more flexible free space)
        scores[k] = gain * 1000.0 + r

    # opening a new bin: residual CAP-s
    r_new = CAP - s
    gain_new = 0.0
    if r_new > 0:
        gain_new = 2.0 * _W[r_new] + 1.0
    scores[len(fitting):] = gain_new * 1000.0 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _W[g] -= _w(g)
        _caps[j] = g - s
        if g - s > 0:
            _W[g - s] += _w(g - s)
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _W[CAP - s] += _w(CAP - s)
    return scores
# EVOLVE-BLOCK-END
