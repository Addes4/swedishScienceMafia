# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with soft perfect-fit preference.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), which is known to
be asymptotically optimal for this kind of online bin packing. A small bonus is given to
perfect fits and to tighter fits, but the SS delta remains the dominant term so the packing
stays balanced. The function is shown only the bins the item fits in, so it keeps its own
record of every opened bin. Used bins are a prefix of the bin array; each instance runs in a
fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Find if any fitting bin has residual 0 (perfect fit).
    perfect_exists = any(_caps[j] == s for j in fitting)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Primary: minimise SS delta.  Secondary: prefer perfect fit, then tighter fit.
        score = -float(delta)
        if r == 0:
            score += 0.5          # soft perfect-fit bonus, small vs delta of 1
        score -= r * 1e-6         # tiny tie-break toward tighter fit
        scores[k] = score

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    new_score = -float(delta_new)
    if perfect_exists:
        new_score -= 0.6          # discourage opening a new bin when a perfect fit exists
    new_score -= r_new * 1e-6
    scores[len(fitting):] = new_score

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
