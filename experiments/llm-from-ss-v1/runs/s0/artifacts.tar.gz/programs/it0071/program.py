# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a bounded perfect-fit bonus.

Each item goes where it minimises sum_g N(g)^2 (the sum-of-squares / SS rule), which is
asymptotically optimal for this kind of online bin packing. A bounded bonus is added when the
placement yields a perfect fit (residual 0), so perfect fits are preferred but the SS rule can
still override in extreme cases. The function is shown only the bins the item fits in, so it
keeps its own record of every opened bin. Used bins are a prefix of the bin array; each
instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    base = np.empty(len(bins), dtype=np.float64)
    resid = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # SS cost-change for moving item into this bin.
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        base[k] = float(delta)
        resid[k] = 0.0 if r == 0 else float(r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    base[len(fitting):] = float(delta_new)
    resid[len(fitting):] = 0.0 if r_new == 0 else float(r_new)

    # Primary: minimise SS delta. Secondary: perfect fit (residual 0). Tertiary: tighter fit.
    perfect_bonus = np.where(resid == 0.0, 1.0, 0.0)
    scores = -(base) + 0.5 * perfect_bonus - 1.0e-4 * resid

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
