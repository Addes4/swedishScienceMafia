# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with best-fit tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), asymptotically optimal for this
class of online bin packing. The SS delta is an exact integer and is used as the strictly
dominant key (encoded with a large multiplier so residual can never override it). Among
placements with equal SS delta we prefer the *smallest* positive residual (best-fit), which
packs bins more tightly without needlessly opening new bins. Ties then go to the first bin.
The function keeps its own record of every opened bin; used bins are a prefix of the bin
array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_K = 1000000                   # multiplier: guarantees delta dominance over residual key
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta (more negative is better).
        # Tie-break: best-fit -> smaller positive residual preferred.
        scores[k] = -(delta * _K + r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * _K + r_new)

    choice = int(np.argmax(scores))          # first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
