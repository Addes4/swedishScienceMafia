# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an item-size-aware tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion; among placements with equal SS delta we prefer the placement whose resulting
residual is most likely to be useful for a future item, estimated from the empirical distribution
of item sizes seen so far. This keeps free space flexible instead of fragmenting bins to chase
tight/perfect fits. The function is shown only the bins the item fits in, so it keeps its own
record of every opened bin. Used bins are a prefix of the bin array; each instance runs in a
fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_size_hist = np.zeros(CAP + 1)  # histogram of item sizes seen so far
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _size_hist, _seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Probability that a future item fits in a residual r, estimated from history.
    def reuse(r):
        if r <= 0:
            return 0.0
        # fraction of past items of size <= r
        if _seen > 0:
            return float(_size_hist[:r + 1].sum()) / _seen
        # before any history, approximate with a rough default (mean ~40)
        return min(1.0, r / 40.0)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta (as large negative as possible).
        # Tie-break: prefer residual with the highest reuse probability, scaled by its size.
        scores[k] = -(float(delta) * 1000.0 - (reuse(r) * r))

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(float(delta_new) * 1000.0 - (reuse(r_new) * r_new))

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # Update the item-size history after placement.
    if 0 <= s <= CAP:
        _size_hist[s] += 1
        _seen += 1
    return scores
# EVOLVE-BLOCK-END
