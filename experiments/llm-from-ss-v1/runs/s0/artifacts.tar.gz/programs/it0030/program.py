# EVOLVE-BLOCK-START
"""Exact sum-of-squares rule with perfect-fit tie-breaking.

Each item goes where it minimises sum_g N(g)^2 (the Sum-of-Squares / SS rule), which is known
to be asymptotically optimal for online bin packing.  The exact integer SS cost change of a
move is 2*N[r] - 2*N[g] + 1, where g is the bin's current residual and r = g - s the residual
after placement (N[0] is irrelevant).  Ties (equal SS change) are broken by preferring a
perfect fit (r == 0) and then the smaller residual.  The function is shown only the bins the
item fits in, so it keeps its own record of every opened bin.  Used bins form a prefix of the
bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact SS cost change for placing into an existing bin with residual g.
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = 2 * _N[r] - 2 * _N[g] + 1
        # Primary: minimise exact SS delta.  Tie-break: perfect fit first, then smaller residual.
        # Encode lower delta (better) -> higher score; smaller r -> higher score on ties.
        scores[k] = -(delta * 100000.0 + r)

    # Opening a new bin: residual r_new = CAP - s.
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1
    scores[len(fitting):] = -(delta_new * 100000.0 + r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
