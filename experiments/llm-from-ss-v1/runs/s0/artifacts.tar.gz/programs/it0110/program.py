# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a best-fit residual tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion via an exact integer combination rather than float scaling. Among
placements with equal SS delta we prefer a tight fit (smaller positive residual) to consolidate
small residual classes; residual zero (exactly full bin) is the most preferred.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Number of bins that can exist is at most 5000 (one per item); reserve generous slots so the
# integer combination of (delta, tiebreak) never collides for realistic delta magnitudes.
_TIE = 4096                    # multiplier for the tie-break sub-key
_DELTA_SHIFT = 64              # integer offset so deltas are non-negative before mixing


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    L = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = L - len(fitting)
    scores = np.empty(L, dtype=np.int64)

    # Dominant key: best SS delta (most negative). Convert to a monotone "goodness" key:
    # goodness = -delta. Tie-break: prefer tight fit, i.e. small positive residual; r == 0
    # (bin becomes exactly full) is best of all, handled via tie value 0 vs (r) for r > 0.
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        good = _DELTA_SHIFT - delta              # larger is better
        tie = 0 if r == 0 else r                 # smaller residual is better
        scores[k] = good * _TIE - tie

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    good_new = _DELTA_SHIFT - delta_new
    tie_new = 0 if r_new == 0 else r_new
    scores[len(fitting):] = good_new * _TIE - tie_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
