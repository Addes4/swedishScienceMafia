# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a data-driven tie-break.

Each item goes where it minimises the exact sum-of-squares delta
    delta(r) = -2*N[g] + 1 + (2*N[r] + 1 if r>0 else 0)   (g = residual before, r = residual after),
which is asymptotically optimal for online bin packing. Among placements with equal delta,
prefer the one whose resulting residual r is more likely to be refilled by a future item,
estimated from a running histogram of the sizes seen so far. The function is shown only the
bins the item fits in, so it keeps its own record of every opened bin.
"""
import numpy as np

CAP = 100
_caps = []                        # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)              # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0] * (CAP + 1)          # histogram of item sizes seen so far
_seen = 0                         # number of items seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist, _seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Probability weight that residual r gets refilled: frequency of size r seen so far.
    total = _seen if _seen > 0 else 1

    def fill_weight(r):
        if r <= 0:
            return 0.0
        return _hist[r] / total

    W = 0.5  # small weight so delta dominates but ties are broken sensibly

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(float(delta) - W * fill_weight(r))

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if n_unused > 0:
        # Opening a new bin also gets the same delta criterion plus the same tie-break weight.
        scores[len(fitting):] = -(float(delta_new) - W * fill_weight(r_new))
    else:
        scores[len(fitting):] = -1.0e18

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    _hist[s] += 1
    _seen += 1
    return scores
# EVOLVE-BLOCK-END

