# EVOLVE-BLOCK-START
"""Consolidating best-fit rule.

Among bins the item fits in, we prefer the placement whose residual after placement is a
value already present among open bins (so residual classes stay consolidated and future
items of a given size find ready slots), breaking ties by the *smallest* residual (classic
best-fit, known to be strong for well-behaved distributions). This is tracked exactly with
the function's own record of open bins, in integer arithmetic.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        existing = 1 if (r == 0 or _N[r] > (1 if r == g else 0)) else 0
        # Dominant: consolidate onto an existing residual class.
        # Secondary: smaller (tighter) residual is better.
        scores[k] = existing * 1000000.0 - r

    r_new = CAP - s
    existing_new = 1 if (r_new == 0 or _N[r_new] > 0) else 0
    scores[len(fitting):] = existing_new * 1000000.0 - r_new

    choice = int(np.argmax(scores))          # harness: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
