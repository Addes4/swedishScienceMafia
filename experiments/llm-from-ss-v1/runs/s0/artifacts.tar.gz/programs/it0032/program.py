# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with perfect-fit prioritisation and pairwise match tie-break.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares / SS rule), which is known to
be asymptotically optimal for this kind of online bin packing. Ties and near-ties are broken
by preferring a perfect fit (residual 0) and, failing that, a residual that is likely to be
exactly matched in the future (either by a single observed item size or by the sum of two
observed item sizes that fit together). The function is shown only the bins the item fits in,
so it keeps its own record of every opened bin. Used bins are a prefix of the bin array; each
instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_seen = set()                  # observed single item sizes
_pairmask = [False] * (CAP + 1)  # True if r is a sum of two observed sizes <= CAP


def _note(s):
    global _seen, _pairmask
    if s not in _seen:
        _seen.add(s)
        for a in _seen:
            b = s + a
            if b <= CAP:
                _pairmask[b] = True
            b = s
            b2 = a
            # also mark sums of s with everything already there (a loop above covers a)
    # mark s combined with all seen
    for a in _seen:
        t = s + a
        if t <= CAP:
            _pairmask[t] = True
    if s <= CAP:
        _pairmask[s] = True


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    perfect_exists = any(_caps[j] == s for j in fitting)

    def sub(r):
        # bounded secondary key: 0 best (perfect), then pairwise-matchable, then single-matchable
        if r == 0:
            return 0.0
        if r <= CAP and _pairmask[r]:
            return 1.0
        return 2.0

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        if r == 0:
            base = -1.0e9
        else:
            base = float(delta)
        scores[k] = -(base * 1000.0 + sub(r) * 10.0 + r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if perfect_exists:
        scores[len(fitting):] = -1.0e12
    else:
        scores[len(fitting):] = -(float(delta_new) * 1000.0 + sub(r_new) * 10.0 + r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    _note(s)
    return scores
# EVOLVE-BLOCK-END
