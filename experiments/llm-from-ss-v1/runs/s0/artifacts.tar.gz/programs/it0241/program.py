# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a recyclable-residual tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for this class of online bin packing. The SS delta is an exact integer, so it is used as the
dominant criterion; among placements with equal SS delta we prefer the residual that is most
likely to be refilled by an upcoming item. That is estimated with a small recency-weighted
histogram of observed item sizes: a residual equal to a common recent item size is valuable.
The function is shown only the bins the item fits in, so it keeps its own record of opened bins.
Used bins are a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# recency-weighted item-size histogram (exponentially decayed counts)
_H = np.zeros(CAP + 1, dtype=np.float64)
_DECAY = 0.995


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _H
    s = int(item)

    # update the recency-weighted histogram with this item
    _H *= _DECAY
    _H[s] += 1.0

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta. Tie-break: value the residual by how often
        # a similar-sized item has arrived recently (recyclable free space).
        bonus = float(_H[r]) if r > 0 else 0.0
        scores[k] = -(float(delta) * 1000.0 - bonus)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    bonus_new = float(_H[r_new]) if r_new > 0 else 0.0
    scores[len(fitting):] = -(float(delta_new) * 1000.0 - bonus_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
