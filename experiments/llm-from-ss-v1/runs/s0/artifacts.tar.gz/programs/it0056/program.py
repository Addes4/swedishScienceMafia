# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with robust tie-breaking.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), which is asymptotically optimal
for online bin packing. The exact SS cost change is the primary criterion; ties are broken by
preferring a perfect fit first, then the tighter fit (smaller residual). The function is shown
only the bins the item fits in, so it keeps its own record of every opened bin. Used bins form
a prefix of the bin array; each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    scores = np.empty(n_bins, dtype=np.float64)

    # SS cost change for placing into an existing bin with residual g:
    #   remove one bin at g, add one bin at r = g - s.
    # delta = -2*N[g] + 1 + (2*N[r] + 1 if r > 0 else 0)
    # For a brand-new bin: delta_new = 2*N[r_new] + 1 if r_new > 0 else 0.
    # Primary key: -delta (higher score = lower cost). Secondary: residual after placement,
    # with perfect fit (r==0) strongly preferred, then tighter fit.

    # Collect deltas and residuals for the opened bins (prefix of bins).
    n_open = len(_caps)
    # New-bin residual
    r_new = CAP - s

    best = None
    # Determine whether a perfect fit exists among fitting open bins.
    perfect_exists = False
    for j in range(n_open):
        if _caps[j] == s:
            perfect_exists = True
            break

    choice_open = -1
    best_key = None
    for j in range(n_open):
        g = _caps[j]
        if g < s:
            continue
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # key: (is_perfect, delta, r) minimized
        if perfect_exists and r != 0:
            rank = 2
        elif r == 0:
            rank = 0
        else:
            rank = 1
        key = (rank, delta, r)
        if best_key is None or key < best_key:
            best_key = key
            choice_open = j
            best = (rank, delta, r, False)

    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    new_rank = 2 if perfect_exists else (0 if r_new == 0 else 1)
    new_key = (new_rank, delta_new, r_new)
    open_new = False
    if best_key is None or new_key < best_key:
        best_key = new_key
        open_new = True

    # Assign scores: chosen bin highest, then decreasing by key order.
    # Simpler: score all bins by their key converted to a descending value; harness picks
    # first maximum, so make scores strictly decreasing with key quality.
    for k in range(n_bins):
        if k < n_open:
            g = _caps[k]
            if g < s:
                scores[k] = -1.0e15
                continue
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            if perfect_exists and r != 0:
                rank = 2
            elif r == 0:
                rank = 0
            else:
                rank = 1
            key = (rank, delta, r)
        else:
            r = r_new
            delta = delta_new
            key = (new_rank, delta, r)
        # Encode key so smaller key -> higher score, with residual as fine tie-break.
        scores[k] = -(key[0] * 1.0e6 + key[1] * 1.0e3 + key[2])

    choice = int(np.argmax(scores))
    if choice < n_open:
        j = choice
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(r_new)
        if r_new > 0:
            _N[r_new] += 1
    return scores
# EVOLVE-BLOCK-END
