# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an adaptive frequency-based tie-break.

Each item goes where it minimises sum_g N(g)^2 (the SS rule), asymptotically optimal for
this online bin packing class. The SS delta is an exact integer and is the dominant
criterion; among placements with equal SS delta we prefer the residual whose capacity
equals an item size that has been observed most frequently so far, so future items are
more likely to find a snug fit instead of forcing a new bin. Frequency counts are a pure
tie-break (bounded below 1.0) and never override the SS ordering.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [1.0] * (CAP + 1)      # _freq[s]: smoothed count of items of size s seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _freq
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Update the empirical frequency of this item size (smoothed, so nothing is zero).
    _freq[s] += 1.0

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Dominant: exact SS delta. Tie-break (bounded in [0,1)): prefer residuals that
        # match the most frequently observed item sizes, to enable snug future fits.
        tie = _freq[r] / (1.0 + _freq[r]) if r > 0 else 0.0
        scores[k] = -float(delta) - tie

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    tie_new = _freq[r_new] / (1.0 + _freq[r_new]) if r_new > 0 else 0.0
    scores[len(fitting):] = -float(delta_new) - tie_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

