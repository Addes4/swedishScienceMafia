# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with soft perfect-fit bonus and clean deltas.

Each item goes where it minimises the change in sum_g N(g)^2 (the sum-of-squares / SS rule),
which is asymptotically optimal for this kind of online bin packing. The new-bin option is
evaluated with its true SS delta against the current residual histogram (no artificial
penalty). A small, bounded bonus (in delta units, much smaller than typical delta gaps) softly
prefers exact fits and, among equal deltas, prefers leaving a residual that is a common item
size so it is more likely to be filled later. The function sees only the bins the item fits
in, so it keeps its own record of every opened bin. Used bins form a prefix of the bin array;
each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # empirical frequency of arriving item sizes


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _freq
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    total = sum(_freq)
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # SS delta: remove bin with residual g, add bin with residual r (if r>0).
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Soft bounded bonus for exact fit and for "useful" residual.
        bonus = 0.0
        if r == 0:
            bonus += 0.5
        elif total > 0:
            bonus += 0.25 * (_freq[r] / total)
        scores[k] = -(float(delta) - bonus)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -float(delta_new)

    # Update state according to the harness's choice (first highest score).
    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    _freq[s] += 1
    return scores
# EVOLVE-BLOCK-END
