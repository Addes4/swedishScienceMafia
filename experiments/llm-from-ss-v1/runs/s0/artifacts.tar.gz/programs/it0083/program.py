# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a complementary-fit tie-break.

Each item goes where it minimises sum_g N(g)^2 (the sum-of-squares / SS rule), which is known
to be asymptotically optimal for this kind of online bin packing. The exact SS delta is the
primary criterion. Among placements with equal delta (a common situation) we break ties by
preferring the residual that best complements the most common item size seen so far, which
encourages packing pairs that close bins quickly. The function is shown only the bins the
item fits in, so it keeps its own record of every opened bin. Used bins form a prefix of the
bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # observed item-size frequencies (to find a common complement)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _freq
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Most common item size seen so far (the best complement to look for).
    top = 1
    topc = _freq[1]
    for v in range(2, CAP + 1):
        if _freq[v] > topc:
            topc = _freq[v]
            top = v

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Tie-break: prefer a residual equal to the most common item size (good complement),
        # else prefer the residual with the highest bin count (consolidation), else tighter.
        if r == top:
            tb = -1
        elif r == 0:
            tb = 0
        else:
            tb = _N[r] + 1
        scores[k] = -(float(delta) * 1000.0 + tb * 10.0 + r * 1e-3)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    tbn = -1 if r_new == top else (_N[r_new] + 1 if r_new > 0 else 0)
    scores[len(fitting):] = -(float(delta_new) * 1000.0 + tbn * 10.0 + r_new * 1e-3)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    if 0 < s <= CAP:
        _freq[s] += 1
    return scores
# EVOLVE-BLOCK-END
