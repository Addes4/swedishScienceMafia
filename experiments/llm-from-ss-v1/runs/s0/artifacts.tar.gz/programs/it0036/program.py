# EVOLVE-BLOCK-START
"""Pure sum-of-squares rule.

Each item goes where it minimises the change in sum_g N(g)^2 (the SS rule), which is known
to be asymptotically optimal for online bin packing with items from a fixed distribution.
The perfect-fit case (residual 0) is already encoded in the honest SS delta, so no separate
bonus is needed. Ties are broken deterministically toward the earliest fitting bin.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_bins = len(bins)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Higher score = better = smaller delta. Small epsilon tie-break: earlier bin first.
        scores[k] = -float(delta) - 1e-9 * k

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -float(delta_new) - 1e-9 * np.arange(len(fitting), n_bins)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
