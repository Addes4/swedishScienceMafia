# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a guarded perfect-fit override.

Each item goes where it minimises sum_g N(g)^2 (the sum-of-squares / SS rule), which is
asymptotically optimal for this kind of online bin packing. A perfect fit (residual 0) is
taken *only* when it is nearly SS-optimal: if its SS delta is within a small threshold of the
best available delta, it wins; otherwise exact SS governs, so we never fragment bins just to
chase an exact fit far from the SS optimum. Remaining ties are broken by tighter fit.
Everything else (new bin delta, perfect-fit suppression of new bins) matches the SS rule.
The function sees only the bins the item fits in, so it keeps its own record of opened bins;
used bins are a prefix of the bin array and each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

PERFECT_TOL = 4                # how far a perfect fit may deviate from the SS optimum


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    m = len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact SS deltas for every fitting bin.
    deltas = []
    perfect_idx = -1
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        d = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        deltas.append(d)
        if r == 0 and perfect_idx < 0:
            perfect_idx = k

    # SS delta for opening a fresh bin.
    r_new = CAP - s
    d_new = 1 + (2 * _N[r_new] + 1 if r_new > 0 else 0)

    # Best SS delta available (over fitting bins and a new bin).
    best = d_new
    for d in deltas:
        if d < best:
            best = d

    # Take a perfect fit only if it is close to SS-optimal.
    use_perfect = (perfect_idx >= 0 and deltas[perfect_idx] <= best + PERFECT_TOL)

    for k in range(m):
        g = _caps[j] if False else _caps[fitting[k]]
        r = g - s
        scores[k] = -(deltas[k] * 1000.0 + r)

    if use_perfect:
        scores[perfect_idx] = 1.0e18
        scores[m:] = -1.0e12            # discourage opening a new bin
    else:
        scores[m:] = -(d_new * 1000.0 + r_new)

    choice = int(np.argmax(scores))     # harness's choice: first highest score
    if choice < m:
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
