# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a usability threshold tiebreak.

Primary signal: minimize sum_g N(g)^2 (i.e. minimize the sum-of-squares delta of residual
class counts). Bins whose residual class already exists are preferred (they consolidate
classes). Among those, prefer the placement whose residual is >= tmin when tmin-gap options
exist (i.e. leave a residual usable by at least the smallest item seen so far); otherwise
among equal delta pick the smallest residual (best fit).
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_tmin = CAP                    # smallest item size seen so far (usability threshold)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _tmin
    s = int(item)
    if s < _tmin:
        _tmin = s
    n_bins = len(bins)
    fitting = []
    # _caps is the full history of opened bins; iterate only up to len(_caps)
    for j, g in enumerate(_caps):
        if g >= s:
            fitting.append(j)
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    TMIN = _tmin  # threshold: residual >= TMIN is considered "usable"

    def key_of(r):
        # primary: minimize sum-of-squares delta (bigger delta -> worse)
        if r > 0:
            delta = -2 * _N[r] - 1  # contribution: removing g_ref not tracked; see below
        else:
            delta = 0
        return delta

    # For each fitting bin, compute the true sum-of-squares delta:
    #   removing an item of size g_ref from class N[g_ref], adding to class N[r].
    #   delta_change = (N[g_ref]-1)^2 - N[g_ref]^2 + (N[r]+1)^2 - N[r]^2
    #                = -(2*N[g_ref]-1) + (2*N[r]+1)  if r>0 else -(2*N[g_ref]-1)
    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        d_remove = -(2 * _N[g_ref] - 1)
        if r > 0:
            d_add = 2 * _N[r] + 1
            exists = 1 if _N[r] > 0 else 0
        else:
            d_add = 0
            exists = 1
        delta = d_remove + d_add
        # Prefer (a) smaller delta, then (b) residual that already exists or is 0,
        # then (c) residual >= TMIN (usable) if any candidate can provide it,
        # then (d) smaller residual.
        usable = 1 if (r == 0 or r >= TMIN) else 0
        scores[k] = (-delta) * 1e9 + exists * 1e6 + usable * 1e3 - r

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
        exists_new = 1 if _N[r_new] > 0 else 0
    else:
        delta_new = 0
        exists_new = 1
    usable_new = 1 if (r_new == 0 or r_new >= TMIN) else 0
    scores[len(fitting):] = (-delta_new) * 1e9 + exists_new * 1e6 + usable_new * 1e3 - r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

