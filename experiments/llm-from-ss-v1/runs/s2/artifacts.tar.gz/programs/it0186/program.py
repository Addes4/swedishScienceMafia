# EVOLVE-BLOCK-START
"""Best-fit residual rule with a tightness tie-break.

Only the bins the item fits in are shown, but unused bins have remaining capacity 100 and are
included in that array. Used bins form a prefix of the bin array in index order, so I track
each opened bin's remaining capacity myself.

Choice rule: among the bins the item fits in, prefer the one leaving the smallest residual
(best fit). Ties on residual are broken by the smallest bin index (natural, via first-max on
ties). This is the classic best-fit heuristic, which is very strong for this kind of item
distribution.
"""
import numpy as np

CAP = 100


def priority(item, bins):
    s = int(item)
    remaining = bins  # remaining capacity of every bin the item fits in (index order) = all bins
    # Best fit: choose the bin with the smallest remaining capacity that still fits,
    # i.e. smallest post-placement residual r = remaining - s.
    # score = -remaining -> argmax picks smallest remaining capacity (first on ties).
    scores = -remaining.astype(np.float64)
    return scores
# EVOLVE-BLOCK-END
