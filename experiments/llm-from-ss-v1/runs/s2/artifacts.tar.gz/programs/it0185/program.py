# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with symmetric new-bin handling.

Each item goes where it minimises the increase in sum_g N(g)^2, where N(g) counts bins
with remaining capacity g. Used bins contribute residuals 0 < g < CAP, and the pool of
unused bins is counted as N[CAP] (residual CAP). Opening a new bin therefore removes one
CAP-bin and adds one (CAP-s)-bin, so its sum-of-squares delta is computed exactly like a
used-bin placement with g_ref = CAP. Exact-delta ties are broken by the largest
post-placement residual.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (the harness opens unused bins
in index order and ties go to the first bin). Each instance runs in a fresh process, so
the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: bins with remaining capacity g (0 < g < CAP), plus N[CAP]


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    n_used = len(_caps)
    _N[CAP] = n_bins - n_used     # unused bins are the residual-CAP pool

    scores = np.empty(n_bins, dtype=np.float64)

    # Used bins: exact delta of sum N(g)^2, tie-break by largest post-placement residual.
    for j in range(n_used):
        g = _caps[j]
        if g >= s:
            r = g - s
            if r > 0:
                delta = 2 * _N[r] + 1 - 2 * _N[g] + 1
            else:
                delta = -2 * _N[g] + 1
            scores[j] = -delta * 1000.0 + r
        else:
            scores[j] = -1e18

    # Unused bins: identical formula with g_ref = CAP.
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1 - 2 * _N[CAP] + 1
    else:
        delta_new = -2 * _N[CAP] + 1
    scores[n_used:] = -delta_new * 1000.0 + r_new

    choice = int(np.argmax(scores))
    if choice < n_used:
        g = _caps[choice]
        _N[g] -= 1
        _caps[choice] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_used < n_bins:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
