# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with tightest-fit tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken by preferring the smallest positive
post-placement residual r (best-fit / tightest pack), which closes bins sooner.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_fit = len(fitting)

    # Compute exact integer sum-of-squares delta for each candidate placement.
    # All fitting bins plus the option of opening a new bin (residual CAP - s).
    deltas = []
    residuals = []
    for j in fitting:
        g = _caps[j]
        r = g - s
        if r > 0:
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g] + 1
        deltas.append(delta)
        residuals.append(r)
    # opening a new bin
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    deltas.append(delta_new)
    residuals.append(r_new)

    min_delta = min(deltas)

    scores = np.empty(n_bins, dtype=np.float64)
    # Determine best tie-break value among the min-delta candidates.
    # Prefer smaller positive residual; residual 0 treated as worst tiebreak (rare).
    best_r = None
    for d, r in zip(deltas, residuals):
        if d == min_delta:
            rr = r if r > 0 else 10**6
            if best_r is None or rr < best_r:
                best_r = rr

    # Assign scores: highest score to the chosen candidate(s), earliest index wins.
    # Use a large base so delta dominates, then residual.
    # We only need argmax; make chosen bins get +1 tiers above non-candidates.
    for k, j in enumerate(fitting):
        d = deltas[k]
        r = residuals[k]
        rr = r if r > 0 else 10**6
        if d == min_delta and rr == best_r:
            scores[k] = 2.0
        elif d == min_delta:
            scores[k] = 1.0
        else:
            scores[k] = 0.0
    # new-bin option
    d = deltas[n_fit]
    r = residuals[n_fit]
    rr = r if r > 0 else 10**6
    if d == min_delta and rr == best_r:
        new_score = 2.0
    elif d == min_delta:
        new_score = 1.0
    else:
        new_score = 0.0
    scores[n_fit:] = new_score

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < n_fit:
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_bins > n_fit:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

