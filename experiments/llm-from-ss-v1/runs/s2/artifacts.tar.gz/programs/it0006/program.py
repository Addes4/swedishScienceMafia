# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact fragmentation tie-breaking.

Each item goes where it minimises sum_g N(g)^2 over open residual classes (0 < g < 100).
Among equal delta, prefer the placement that minimises the resulting number of distinct
residual classes (merging/consolidating residuals), then tighter fit. The function keeps
its own record of every opened bin since it is shown only the bins the item fits in.
Used bins are a prefix of the array, so recording is exact.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_distinct = 0                  # number of residual classes g with 0 < g < CAP and N[g] > 0


def _add(g):
    global _distinct
    if 0 < g < CAP and _N[g] == 0:
        _distinct += 1
    _N[g] += 1


def _remove(g):
    global _distinct
    _N[g] -= 1
    if 0 < g < CAP and _N[g] == 0:
        _distinct -= 1


def priority(item, bins):
    """Priority for every bin, highest wins (first on ties)."""
    global _caps
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # helper computing (delta, resulting distinct-class count) for a placement in g -> r
    def key(g_ref, r):
        delta = -2 * _N[g_ref] + 1
        removed = 1 if (0 < g_ref < CAP and _N[g_ref] == 1) else 0
        if r > 0:
            delta += 2 * _N[r] + 1
            added = 1 if _N[r] == 0 else 0
        else:
            added = 0
        new_distinct = _distinct - removed + added
        # primary: smaller delta; secondary: smaller resulting distinct classes;
        # tertiary: tighter (smaller) residual
        return (-delta, -new_distinct, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        a, b, c = key(g_ref, r)
        scores[k] = a * 1e9 + b * 1e6 + c

    r_new = CAP - s
    a, b, c = key(CAP, r_new)
    scores[len(fitting):] = a * 1e9 + b * 1e6 + c

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _remove(g)
        _caps[j] = g - s
        if g - s > 0:
            _add(g - s)
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _add(CAP - s)
    return scores
# EVOLVE-BLOCK-END
