# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact lexicographic tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Placements are ordered with an exact integer lexicographic key
(no float scaling), so the primary objective is honoured precisely and near-ties are resolved
deterministically. Exact fills (residual 0) are the strict best placement.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)

    # best[j] = (delta, tie) stored as a tuple key; we want minimum delta, then largest residual.
    # Encode as: delta*1000 + (100 - residual)  -> smaller is better (residual in [0,100)).
    best_key = None
    best_j = -1
    for j in fitting:
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = (-2 * _N[g_ref] + 1) + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # smaller delta better; on equal delta prefer larger residual r
        key = delta * 1000 + (100 - r)
        if best_key is None or key < best_key:
            best_key = key
            best_j = j

    # option: open a new (unused) bin
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    key_new = delta_new * 1000 + (100 - r_new)

    choose_new = n_unused > 0 and (best_key is None or key_new < best_key)

    scores = np.empty(n_bins, dtype=np.float64)
    if choose_new:
        # give all unused bins top score, slightly above any fitting bin
        top = 1.0
        if best_key is not None:
            top = -best_key * 1e-6
        for k in range(len(fitting), n_bins):
            scores[k] = top
        for k in range(len(fitting)):
            scores[k] = top - 1.0
    else:
        # fit path: best_j is the chosen bin
        for k in range(len(fitting)):
            if fitting[k] == best_j:
                scores[k] = 1.0
            else:
                scores[k] = 0.0
        for k in range(len(fitting), n_bins):
            scores[k] = -1.0

    choice = int(np.argmax(scores))
    if choice < len(fitting) and fitting[choice] == best_j:
        j = best_j
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif choice >= len(fitting):
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    else:
        # fallback: should not happen but keep consistency
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1

    return scores
# EVOLVE-BLOCK-END
