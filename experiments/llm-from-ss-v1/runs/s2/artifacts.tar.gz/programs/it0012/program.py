# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with near-tie residual consolidation.

Each item goes where it minimises sum_g N(g)^2 (over open bins with 0 < g < 100). The delta
is quantized into coarse buckets so that near-ties (not only exact ties) are resolved by
preferring a post-placement residual r that already occurs among open bins (or r == 0),
consolidating residual classes. It keeps its own record of every opened bin. Used bins are
always a prefix of the bin array (harness opens unused bins in index order, ties go to the
first bin). Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Quantization of the sum-of-squares delta into near-tie buckets.
# delta ranges over a few units; bucket width ~1 keeps exact-balance distinctions visible
# while allowing small fragmentation differences to be overridden by consolidation.
_DQ = 1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def rank(r, delta):
        # primary: quantized sum-of-squares delta (smaller delta -> better)
        # larger bucket multiplier => more weight on balance vs. consolidation.
        q = int(round(delta * _DQ))
        # tiebreak tier: prefer residual that already exists (or 0)
        if r == 0 or _N[r] > 0:
            tb = 1
        else:
            tb = 0
        # secondary numeric tiebreak: prefer smaller residual (tighter fit)
        return (q, tb, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        q, tb, sm = rank(r, delta)
        scores[k] = (q * 1e9 + tb * 1e6 - sm)

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    q_new = int(round(delta_new * _DQ))
    if r_new == 0 or _N[r_new] > 0:
        tb_new = 1
    else:
        tb_new = 0
    scores[len(fitting):] = (q_new * 1e9 + tb_new * 1e6 - r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
