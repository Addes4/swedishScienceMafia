# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with largest-residual tie-breaking.

Each item goes where it minimises the change in sum_g N(g)^2, where N(g) counts open bins
with remaining capacity g (0 < g < 100). Exact ties are broken by preferring the placement
that leaves the largest post-placement residual, keeping more usable free space available.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)

    # Map each provided bin (which the item fits in) to its index in _caps, in order.
    # Bins are given in fixed index order and used bins are a prefix, so a two-pointer
    # walk over _caps reproduces the correspondence exactly.
    fit_indices = []
    it = 0
    for g in bins:
        g = int(g)
        while it < len(_caps) and _caps[it] != g:
            it += 1
        if it < len(_caps):
            fit_indices.append(it)
            it += 1
        else:
            fit_indices.append(-1)  # unused bin with capacity CAP

    scores = np.empty(n_bins, dtype=np.float64)

    for k in range(n_bins):
        j = fit_indices[k]
        if j >= 0:
            g_ref = _caps[j]
            r = g_ref - s
            if r > 0:
                delta = (-2 * _N[g_ref] + 1) + (2 * _N[r] + 1)
            else:
                delta = -2 * _N[g_ref] + 1
        else:
            g_ref = CAP
            r = CAP - s
            delta = (2 * _N[r] + 1) if r > 0 else 0
        # Primary: lower delta wins (hence negate). Secondary: larger residual wins.
        scores[k] = -delta * 1e6 + r

    choice = int(np.argmax(scores))
    j = fit_indices[choice]
    if j >= 0:
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
