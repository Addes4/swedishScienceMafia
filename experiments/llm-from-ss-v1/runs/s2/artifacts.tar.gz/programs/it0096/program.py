# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-matching tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among near-optimal placements, we prefer a residual that equals the
current item size (so a future identical item would perfectly fill the bin), then prefer the
larger post-placement residual to keep usable free space.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_EPS = 1.0                     # near-tie tolerance on the delta


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def rank(r):
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        return (-delta, r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r)
        scores[k] = key[0] * 1e9 + key[1]

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -delta_new * 1e9 + r_new

    # residual-matching tie-break: among near-optimal placements, prefer residuals == item size
    base = np.array(scores, dtype=np.float64)
    best = base.max()
    near = base >= best - _EPS * 1e9
    match_idx = -1
    for k in range(len(fitting)):
        if near[k] and (_caps[fitting[k]] - s) == s:
            match_idx = k
            break
    if match_idx < 0 and len(fitting) < n_bins and near[len(fitting)] and r_new == s:
        match_idx = len(fitting)
    if match_idx >= 0:
        scores[:] = -1e18
        scores[match_idx] = 1e18
        choice = match_idx
    else:
        choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
