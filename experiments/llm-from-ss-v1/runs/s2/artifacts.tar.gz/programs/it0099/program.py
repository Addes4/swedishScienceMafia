# EVOLVE-BLOCK-START
"""Best-fit rule with sum-of-squares tie-breaking.

Each item goes into the fitting bin that leaves the smallest non-negative residual
(classic best-fit), which packs tightly. Ties among placements with equal residual are
broken by the sum-of-squares occupancy delta: minimise sum_g N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). Using an unused bin is preferred only
when no fitting bin gives a strictly smaller residual-plus-delta cost. A tiny primary
weight keeps the residual signal dominant while the sum-of-squares term resolves ties.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _ss_delta(g_ref, r):
    """Change in sum N(g)^2 when a bin with residual g_ref becomes residual r."""
    delta = -2 * _N[g_ref]
    if r > 0:
        delta += 2 * _N[r]
    if r == g_ref:
        delta -= 1  # the bin still exists but we removed then need to re-add
    # more precisely: remove old contribution then add new
    return delta


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    best = None
    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        # exact sum-of-squares delta for this placement
        delta = -2 * _N[g_ref] + 1
        if r > 0:
            delta += 2 * _N[r] + 1
        # primary: minimize residual (best-fit); secondary: minimize delta
        key = (r, delta)
        scores[k] = -(r * 1e9 + delta)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 1
    scores[len(fitting):] = -(r_new * 1e9 + delta_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
