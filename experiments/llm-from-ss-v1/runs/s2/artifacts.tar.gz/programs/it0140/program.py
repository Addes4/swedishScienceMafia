# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact lexicographic tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken lexicographically by integer keys:
first prefer the smallest positive residual (compact leftover), then prefer residuals that
are close to common item sizes so the leftover stays usable.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # observed frequency of item sizes


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _freq
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # observed item-size frequency (used as a light tie-break signal)
    _freq[s] += 1

    def key(g_ref, r):
        # primary: sum-of-squares delta (minimised => negative delta preferred)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # tie-break: prefer compact leftover; residual 0 is strictly best.
        # secondary: prefer residual matching a common item size (keeps leftover usable).
        if r == 0:
            tb1 = -1
        else:
            tb1 = r
        tb2 = 0 if r > 0 else -1
        return (delta, tb1, tb2)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        d, t1, _ = key(g_ref, r)
        # encode lexicographically as a single float key (delta dominates, then t1)
        scores[k] = d * 1e6 + t1

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if r_new == 0:
        t1_new = -1
    else:
        t1_new = r_new
    scores[len(fitting):] = delta_new * 1e6 + t1_new

    choice = int(np.argmax(-scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
