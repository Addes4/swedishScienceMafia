# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with empirical-fill tie-breaking.

Each item goes where it minimises sum_g N(g)^2 over open-bin residual classes.
Exact ties in that delta are broken by an empirical estimate of how likely the resulting
post-placement residual can still be filled by future items: we keep a decaying histogram of
observed item sizes and prefer residuals whose future fill probability (single-item or pair)
is highest; r == 0 is treated as best. Only the bins the item fits in are shown, so we keep
our own record of every opened bin; unused bins appear after used ones.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_H = [0.0] * (CAP + 1)         # decaying histogram of observed item sizes
_decay = 0.9998
_obs = 0.0


def _fill_prob(r, H, obs):
    """Empirical probability that residual r > 0 can be closed by one future item or a pair."""
    if r <= 0:
        return 2.0
    tot = obs if obs > 0 else 1.0
    p1 = H[r] / tot
    # probability that some pair (a, b) with a+b == r lands in the bin (single current residual
    # class, approximate by product of marginals accumulated per r)
    p2 = 0.0
    lo = 1
    hi = r - 1
    while lo <= hi:
        p2 += H[lo] * H[hi]
        lo += 1
        hi -= 1
    p2 /= (tot * tot)
    return p1 + p2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _H, _obs
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    H = _H
    obs = _obs

    def key(g_ref, r):
        # primary: sum-of-squares delta (smaller delta -> better)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # tiebreak: prefer residual with higher empirical future-fill probability
        fp = _fill_prob(r, H, obs)
        return (-delta, fp, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        a, b, c = key(g_ref, r)
        scores[k] = a * 1e9 + b * 1e3 - c * 1e-3

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    fp_new = _fill_prob(r_new, H, obs)
    scores[len(fitting):] = (-delta_new * 1e9 + fp_new * 1e3 - r_new * 1e-3)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update decaying evidence: item sizes seen so far (this item; known since arrival)
    for i in range(CAP + 1):
        H[i] *= _decay
    H[s] += 1.0
    _obs = _obs * _decay + 1.0
    return scores
# EVOLVE-BLOCK-END

