# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-class tie-breaking and next-item proxy.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken by preferring a post-placement residual r
that already occurs among open bins (or r == 0), which consolidates residual classes.
A tiny fractional bonus (strictly below one delta unit so the primary ordering is untouched)
favours residuals that match a recently seen item size, making clean closes more likely.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0] * (CAP + 1)        # running histogram of observed item sizes
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _hist, _seen
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # fractional next-item proxy: relative frequency that residual r is a likely next size
    if _seen > 0:
        denom = float(_seen)
    else:
        denom = 1.0

    def rank(r):
        # primary: sum-of-squares delta (smaller delta -> better)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # tiebreak tier: prefer residual that already exists (or 0)
        if r == 0 or _N[r] > 0:
            tb = 1
        else:
            tb = 0
        # secondary numeric tiebreak: prefer smaller residual (tighter fit)
        return (-delta, tb, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r)
        if r > 0:
            frac = _hist[r] / denom          # in [0, 1)
        else:
            frac = 1.0                       # perfect close is always attractive
        scores[k] = (key[0] * 1e9 + key[1] * 1e6 - key[2] + frac)

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
        frac_new = _hist[r_new] / denom
    else:
        delta_new = 0
        frac_new = 1.0
    if r_new == 0 or _N[r_new] > 0:
        tb_new = 1
    else:
        tb_new = 0
    scores[len(fitting):] = (-delta_new * 1e9 + tb_new * 1e6 - r_new + frac_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update running item-size histogram
    _hist[s] += 1
    _seen += 1
    return scores
# EVOLVE-BLOCK-END

