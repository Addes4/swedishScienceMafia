# EVOLVE-BLOCK-START
"""Sum-of-squares rule with a distribution-aware fragmentation tiebreak.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < CAP); ties are broken using the estimated item-size distribution so that
gaps left behind are likely to be exactly usable by a future item. The function keeps its own
record of every opened bin because it is shown only the bins the item fits in.
"""
import numpy as np

CAP = 100
_caps = []                       # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)             # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Estimate of the item-size distribution: counts of (s, count) accumulated so far.
_hist = np.zeros(CAP + 1, dtype=np.float64)
_total = 0.0

# Smoothing priors for the expected item size (roughly Weibull mean ~40).
for _s in range(1, CAP + 1):
    _hist[_s] = 1.0
_total = float(CAP)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _total
    s = int(item)

    # Probability that a random item is large enough to use a leftover of size r.
    # Use 1 - CDF_est(r) as the chance a leftover r gets consumed later.
    cdf = np.cumsum(_hist[: CAP + 1]) / _total  # cdf[g] = P(item <= g)

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Tiebreak: prefer leftovers that are likely to be filled exactly later.
        if r > 0:
            # probability that some future item exactly equals r (exact-fit reuse)
            p_exact = _hist[r] / _total
        else:
            p_exact = 1.0  # perfect fit, great
        scores[k] = -(delta * 1000.0) - r + 50.0 * p_exact

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000.0) - r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # Update the running item-size estimate.
    _hist[s] += 1.0
    _total += 1.0

    return scores
# EVOLVE-BLOCK-END

