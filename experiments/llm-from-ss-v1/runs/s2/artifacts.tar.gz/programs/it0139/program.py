# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-quality tie-breaking.

Primary objective: minimise the change in sum_g N(g)^2 (the classic sum-of-squares / SS
bin-choice rule), which strongly discourages leaving many partially-filled bins.

Tie-break: among placements with an identical sum-of-squares delta, prefer (1) an exact
fill (residual 0), then (2) the placement whose residual does not create a small, hard to
reuse leftover. Concretely we prefer larger residuals because small residuals below the
typical item size tend to be wasted.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g <= CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    n_open = len(_caps)
    scores = np.empty(n_bins, dtype=np.float64)

    # Rebuild a fast lookup of open bins per remaining capacity.
    used = 0
    best_key = None
    best_idx = n_open  # default: first unused bin
    for j in range(n_open):
        g = _caps[j]
        if g >= s:
            used += 1
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            # Tie-break: exact fill best; otherwise larger residual is preferred.
            tb = (0 if r == 0 else 1, -r)
            key = (delta, tb)
            if best_key is None or key < best_key:
                best_key = key
                best_idx = j

    if used < n_bins:
        r_new = CAP - s
        delta_new = (2 * _N[r_new] + 1) if r_new > 0 else 0
        tb_new = (0 if r_new == 0 else 1, -r_new)
        key = (delta_new, tb_new)
        if best_key is None or key < best_key:
            best_key = key
            best_idx = n_open

    # Build scores: encoded so that argmax picks best_idx, ties to first bin.
    # Everything gets -inf except the chosen bin, but we must avoid NaN and keep argmax valid.
    scores.fill(-1e18)
    if best_idx >= n_bins:
        best_idx = n_bins - 1
    scores[best_idx] = 0.0

    # Update state.
    if best_idx < n_open:
        g = _caps[best_idx]
        _N[g] -= 1
        _caps[best_idx] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    return scores
# EVOLVE-BLOCK-END
