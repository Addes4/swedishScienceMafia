# EVOLVE-BLOCK-START
"""Best-Fit with residual-class consolidation tie-breaking.

Primary rule: Best Fit, i.e. minimise the post-placement residual (tightest fit).
This is a strong online rule for Weibull-ish item sizes. The sum-of-squares rule in
the previous version behaves like Worst-Fit, which tends to fragment bins.

Tie-break: when two bins give the same residual, prefer the one whose resulting
residual already occurs among the open bins (or is 0), which consolidates residual
classes. We also keep a bounded lookahead-free secondary preference for smaller
residuals among the equal-primary cases.

The function is shown only the bins the item fits in, so it keeps its own record of
every opened bin. Used bins are always a prefix of the bin array (harness opens
unused bins in index order and ties go to the first bin). Each instance runs in a
fresh process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def rank(r):
        # primary: Best Fit -> smaller residual is better
        # tier: prefer residual that already exists (or 0)
        if r == 0 or _N[r] > 0:
            tb = 1
        else:
            tb = 0
        return (-r, tb)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r)
        # encode: primary (negative residual, lower residual -> higher score),
        # then consolidation tier, then smaller residual again for final tie.
        scores[k] = (r * -1.0) * 1e6 + tb * 1e3

    r_new = CAP - s
    if r_new == 0 or _N[r_new] > 0:
        tb_new = 1
    else:
        tb_new = 0
    scores[len(fitting):] = (-r_new) * 1e6 + tb_new * 1e3

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
