# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with best-fit tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the tightest fit
(smallest post-placement residual r = g - item), which packs bins more densely and reduces
the number of bins opened.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)

    # Primary: minimize sum-of-squares delta (more negative is better => higher score).
    # Secondary: minimize residual r (tighter fit better).
    best_val = None
    best_r = None
    best_is_new = False
    best_j = -1

    for j in fitting:
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        val = -delta          # higher is better
        cand = (val, -r)
        if best_val is None or cand > (best_val, -best_r if best_r is not None else -10**9):
            best_val = val
            best_r = r
            best_is_new = False
            best_j = j

    # Opening a new bin: delta = +2*N[r_new]+1 if r_new>0 else 0, where r_new = CAP - s.
    r_new = CAP - s
    if r_new > 0:
        val_new = -(2 * _N[r_new] + 1)
    else:
        val_new = 0
    cand_new = (val_new, -r_new)
    if best_val is None or cand_new > (best_val, -best_r):
        best_is_new = True

    # Build scores in bin-array order (unused bins after fitting ones).
    scores = np.empty(n_bins, dtype=np.float64)
    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        scores[k] = (-delta) * 1e6 + (-r)
    scores[len(fitting):] = val_new * 1e6 + (-r_new)

    choice = int(np.argmax(scores))

    if not best_is_new and best_j >= 0:
        j = best_j
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
