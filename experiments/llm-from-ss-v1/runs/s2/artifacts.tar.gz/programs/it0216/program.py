# EVOLVE-BLOCK-START
"""Sum-of-Squares rule computed directly from the bins array.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts bins with remaining
capacity g. The candidate residuals after placing the item are derived from the bins the
item fits in (plus opening a new bin), so no bookkeeping of past bins is needed. Exact-delta
ties are broken by preferring the placement that leaves the largest residual.

The delta for choosing a fitting bin j with residual g_ref = bins[j] and new residual r:
    delta(r) = (increase in sum N^2) = -2*N[g_ref] + 1 + (2*N[r] + 1 if r>0 else 0)
Opening a new bin (residual r_new = CAP - item) gives delta = (2*N[r_new]+1 if r_new>0 else 0).
Minimising delta is the rule; larger r breaks exact ties.
"""
import numpy as np

CAP = 100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    s = int(item)
    n_bins = len(bins)
    b = np.asarray(bins, dtype=np.int64)

    # Counts of remaining capacities among all bins currently present.
    N = np.bincount(b, minlength=CAP + 1)

    # Indices of bins the item fits in.
    fit_mask = b >= s
    fit_idx = np.nonzero(fit_mask)[0]
    g_ref = b[fit_idx]
    r = g_ref - s

    # Sum-of-squares delta for placing into each fitting bin (exact integers).
    delta = -2 * N[g_ref] + 1 + np.where(r > 0, 2 * N[np.minimum(r, CAP)] + 1, 0)

    n_unused = n_bins - len(fit_idx)

    scores = np.full(n_bins, -np.inf, dtype=np.float64)

    if len(fit_idx) > 0:
        # Primary: minimise delta -> maximise -delta. Secondary: maximise r.
        # Encode safely: deltas are small ints, r <= CAP.
        scores[fit_idx] = -delta * (CAP + 1.0) + r

    if n_unused > 0:
        r_new = CAP - s
        if r_new > 0:
            delta_new = 2 * N[r_new] + 1
        else:
            delta_new = 0
        new_score = -delta_new * (CAP + 1.0) + r_new
        unused_idx = np.nonzero(~fit_mask)[0]
        scores[unused_idx] = new_score

    return scores
# EVOLVE-BLOCK-END
