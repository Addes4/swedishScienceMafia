# EVOLVE-BLOCK-START
"""Cubic (harmonic-like) residual rule with largest-residual tie-breaking.

Each item goes where it minimises sum_g N(g)^3, where N(g) counts open bins with remaining
capacity g (0 < g < CAP). The cubic weight punishes clustering of bins at the same residual
far more strongly than the quadratic rule, which tends to break apart near-full bins and
yield tighter overall packing on Weibull-shaped item sizes.
Exact-delta ties are broken by preferring the placement that leaves the largest residual.
The function keeps its own record of every opened bin (used bins are a prefix of the bin
array since the harness opens unused bins in index order and ties go to the first bin).
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def delta_used(g_ref, r):
        # change in sum_g N(g)^3 when a bin with residual g_ref is used and becomes r
        # N(a)^3 delta for losing g_ref: (N-1)^3 - N^3 = -3N^2 + 3N - 1
        term = -3 * _N[g_ref] * _N[g_ref] + 3 * _N[g_ref] - 1
        if r > 0:
            term += 3 * _N[r] * _N[r] + 3 * _N[r] + 1
        return term

    def delta_new(r):
        # new bin opened (residual 100 -> r); 100 never counted in _N, r may be counted
        if r > 0:
            return 3 * _N[r] * _N[r] + 3 * _N[r] + 1
        return 0

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        scores[k] = -delta_used(g_ref, r)

    r_new = CAP - s
    scores[len(fitting):] = -delta_new(r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        r = g - s
        # recompute exact delta from stored state to update _N safely
        _N[g] -= 1
        _caps[j] = r
        if r > 0:
            _N[r] += 1
    elif n_unused > 0:
        r = CAP - s
        _caps.append(r)
        if r > 0:
            _N[r] += 1
    return scores
# EVOLVE-BLOCK-END

