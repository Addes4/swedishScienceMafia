# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact post-placement delta and best-fit fallback.

Each item goes where it minimises sum_g N(g)^2 over open bins with remaining capacity g
(0 < g < 100), where the delta includes the creation of the new residual bucket. Among
placements with equal delta we prefer the one that leaves the largest resulting residual,
which keeps more flexible free space. State is kept in module globals; each instance runs
in a fresh process so it starts empty. Opened bins form a prefix of the bins array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    n_open = len(_caps)
    n_unused = n_bins - n_open
    scores = np.empty(n_bins, dtype=np.float64)

    # Score each open bin that fits the item.
    k = 0
    fitting = []
    for j in range(n_open):
        g = _caps[j]
        if g >= s:
            fitting.append(j)
            r = g - s
            # delta = -N[g]^2 + N[g-1]^2 (remove) ... full post-placement change:
            # before: N[g] counts this bin; after: N[g]-1 and N[r]+1 (if r>0)
            delta = (-(2 * _N[g] - 1)) + (2 * _N[r] + 1 if r > 0 else 0)
            scores[k] = delta * 1e9 + r
            k += 1

    # Score unused bins (remaining capacity CAP).
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if n_unused > 0:
        scores[k:] = delta_new * 1e9 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        nr = g - s
        _caps[j] = nr
        if nr > 0:
            _N[nr] += 1
    elif n_unused > 0:
        nr = CAP - s
        _caps.append(nr)
        if nr > 0:
            _N[nr] += 1
    return scores
# EVOLVE-BLOCK-END

