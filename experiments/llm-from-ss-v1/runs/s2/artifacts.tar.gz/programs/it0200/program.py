# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with matchable-residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Ties in that exact delta are broken by preferring a placement whose
new residual r equals an already-open residual class (N[r] > 0) or 0, since that keeps a
"matchable" pair available for a future exact fill, then by largest residual.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def key_for(g_ref, r):
        # exact primary: delta of sum N(g)^2 if this placement is made
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # secondary: reward matchable residual (r==0 or already open), then larger r
        matchable = 1 if (r == 0 or (r > 0 and _N[r] > 0)) else 0
        return (-delta, -matchable, r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        a, b, c = key_for(g_ref, r)
        scores[k] = a * 1e18 + b * 1e12 + c

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    matchable = 1 if (r_new == 0 or (r_new > 0 and _N[r_new] > 0)) else 0
    scores[len(fitting):] = -delta_new * 1e18 + (-matchable) * 1e12 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
