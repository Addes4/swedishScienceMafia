# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with recent-item-size tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken by preferring a post-placement residual r
that is 0, or that matches a commonly seen recent item size (so the bin is likely closable
by a single future item), and otherwise by the smallest positive r. The function is shown
only the bins the item fits in, so it keeps its own record of every opened bin. Used bins
are always a prefix of the bin array (harness opens unused bins in index order and ties go
to the first bin). Each instance runs in a fresh process, so the module-level state starts
empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_item_hist = [0.0] * (CAP + 1) # decaying histogram of recent item sizes


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _item_hist
    s = int(item)
    n_bins = len(bins)

    # update decaying item-size histogram
    for k in range(1, CAP + 1):
        _item_hist[k] *= 0.995
    _item_hist[s] += 1.0

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def rank(r):
        # primary: sum-of-squares delta (smaller delta -> better)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # tiebreak tier: prefer residual that is fillable (0 or common recent item size)
        if r == 0:
            tb = 2
        elif _item_hist[r] > 0.5:
            tb = 1
        else:
            tb = 0
        return (-delta, tb, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r)
        scores[k] = (key[0] * 1e9 + key[1] * 1e6 - key[2])

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if r_new == 0:
        tb_new = 2
    elif _item_hist[r_new] > 0.5:
        tb_new = 1
    else:
        tb_new = 0
    scores[len(fitting):] = (-delta_new * 1e9 + tb_new * 1e6 - r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

