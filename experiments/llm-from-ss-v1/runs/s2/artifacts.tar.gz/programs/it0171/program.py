# EVOLVE-BLOCK-START
"""Harmonic (1/g^2) residual rule with largest-residual tie-breaking.

Each item goes where it minimises sum_g N(g) * (1/g^2) over open bins with remaining
capacity g (0 < g < 100), a smoother version of the sum-of-squares idea that weights
small residuals much more heavily. Exact-delta ties are broken by preferring the
placement that leaves the largest post-placement residual, keeping more usable free
space available. The function is shown only the bins the item fits in, so it keeps its
own record of every opened bin. Used bins are always a prefix of the bin array.
Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_INV2 = [0.0] * (CAP + 1)      # precomputed 1/g^2 for g >= 1
for _g in range(1, CAP + 1):
    _INV2[_g] = 1.0 / (_g * _g)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def delta(r, g_ref):
        # change in sum 1/g^2 when one bin moves from g_ref to r
        d = -_INV2[g_ref]
        if r > 0:
            d += _INV2[r]
        return d

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        d = delta(r, g_ref)
        # primary: minimise d (smaller is better); tie-break: larger residual
        scores[k] = d * 1e6 - r * 1e-3

    r_new = CAP - s
    d_new = -_INV2[CAP]
    if r_new > 0:
        d_new += _INV2[r_new]
    scores[len(fitting):] = d_new * 1e6 - r_new * 1e-3

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
