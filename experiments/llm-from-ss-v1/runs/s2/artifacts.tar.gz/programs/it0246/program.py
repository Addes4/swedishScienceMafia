# EVOLVE-BLOCK-START
"""Best-Fit with exact-fit and sum-of-squares secondary criterion, using `bins` directly.

For each item we consider the bins it fits in (as given by the harness array `bins`), plus the
unused bins (remaining capacity 100). We rank placements by:
  1. exact fit (residual 0) preferred strongly;
  2. otherwise minimize the change in sum-of-squares Sum_g N(g)^2 where N(g) counts bins with
     residual g, which approximates the best-fit packing that keeps residuals spread out;
  3. as a final tie-break prefer the larger residual (more usable free space).
Opening a new bin is treated like placing into a residual-100 bin, so it is penalized when a
fitting existing bin gives a comparable sum-of-squares outcome. State is kept across calls
because each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_N = [0] * (CAP + 1)           # N[g]: bins with remaining capacity g, 0 < g < CAP
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _N, _caps
    s = int(item)
    n_bins = len(bins)
    n_used = len(_caps)
    scores = np.empty(n_bins, dtype=np.float64)

    # score for placing into an existing bin with residual r = g - s (g = current remaining cap)
    # delta = (2*N(r)+1 if r>0 else 0) - (2*N(g)+1 if g>0 else 0)
    for j in range(n_bins):
        g = int(bins[j])
        r = g - s
        old_p = (2 * _N[g] + 1) if 0 < g < CAP else 0
        new_p = (2 * _N[r] + 1) if 0 < r < CAP else 0
        delta = new_p - old_p
        # primary: minimize delta; secondary: prefer exact fit then larger residual
        exact = 1 if r == 0 else 0
        scores[j] = -delta * 1e6 + exact * 1e5 + r

    # unused bins are those beyond the used prefix (harness keeps used bins as a prefix)
    if n_used < n_bins:
        r_new = CAP - s
        new_p = (2 * _N[r_new] + 1) if 0 < r_new < CAP else 0
        exact_new = 1 if r_new == 0 else 0
        scores[n_used:] = -new_p * 1e6 + exact_new * 1e5 + r_new

    return scores
# EVOLVE-BLOCK-END
