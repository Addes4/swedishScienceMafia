# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-concentration tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). This is the exact change in the sum-of-squares objective caused
by the placement. Exact-delta ties are broken by preferring the placement whose
post-placement residual r already has the most bins at that capacity (larger N[r]); this
concentrates residual mass, which creates more future perfect-fill opportunities and is
directionally consistent with minimising sum_g N(g)^2. A final tie-break prefers the
larger residual.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

BIG = 1e12                     # safely exceeds any secondary term so the delta dominates


def _secondary(r):
    """Tie-break value: prefer larger N[r] (concentration), then larger residual r."""
    return _N[r] * 1000.0 + r


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        # change in sum N(g)^2 when moving this bin from residual g_ref to residual r
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
            sec = _secondary(r)
        else:
            delta = -2 * _N[g_ref] + 1
            sec = 0.0
        scores[k] = -delta * BIG + sec

    # opening a fresh bin: residual r_new gains one bin
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
        sec_new = _secondary(r_new)
    else:
        delta_new = 0
        sec_new = 0.0
    scores[len(fitting):] = -delta_new * BIG + sec_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
