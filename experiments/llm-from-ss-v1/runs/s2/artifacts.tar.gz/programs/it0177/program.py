# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with consistent handling of unused bins.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with
remaining capacity g (0 < g <= 100). Unused bins (remaining capacity 100) are part
of the same histogram, so opening a fresh bin is ranked with the exact same delta
as reusing an existing bin. Ties are broken by preferring the largest post-placement
residual, which preserves usable free space for future items.

The function is shown only the bins the item fits in, so it keeps its own record of
every opened bin. Used bins are always a prefix of the bin array (harness opens
unused bins in index order and ties go to the first bin). Each instance runs in a
fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g <= CAP


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.int64)

    def key_for(r):
        # exact delta of sum_g N(g)^2 when a bin with residual g_ref moves g_ref -> r
        # primary objective: minimise delta; secondary: maximise r
        if r > 0:
            delta = 1 + 2 * _N[r]
        else:
            delta = 0
        return delta

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        delta = key_for(r) - (1 + 2 * _N[g_ref])
        # secondary: prefer larger residual r
        scores[k] = -delta * 1000 + r

    # unused bins: treat as residual 100 -> r_new, one of them will be consumed
    r_new = CAP - s
    delta_new = key_for(r_new) + 1 - (1 + 2 * _N[CAP])
    scores[len(fitting):] = -delta_new * 1000 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _N[CAP] -= 1
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
