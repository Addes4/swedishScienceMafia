# EVOLVE-BLOCK-START
"""Sum-of-Squares rule.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). This is the classic sum-of-squares online bin packing rule.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (the harness opens unused bins
in index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # Score for a used bin: we prefer the *smallest* delta = change in sum N(g)^2.
    # delta = -2*N[g_ref] + 1 + (2*N[r] + 1 if r > 0 else 0), where g_ref = current cap,
    # r = g_ref - s. Highest score => smallest delta.
    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        delta = -2 * _N[g_ref] + 1
        if r > 0:
            delta += 2 * _N[r] + 1
        scores[k] = -delta

    # New (unused) bin: current cap = CAP, r = CAP - s.
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -delta_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
