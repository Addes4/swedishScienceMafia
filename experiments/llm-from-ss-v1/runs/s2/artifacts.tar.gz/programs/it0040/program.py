# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with histogram-aware residual consolidation.

Each item goes where it minimises sum_g N(g)^2 (sum-of-squares, SS), where N(g) counts open
bins with remaining capacity g (0 < g < 100). This is the classic SS heuristic objective;
on exact/close SS deltas the placement that leaves a residual r already present among open
bins (or r == 0, i.e. closing the bin) is preferred, which consolidates residual classes.

We additionally keep a running histogram of observed item sizes and give a tiny bonus to
placements whose post-placement residual matches a frequently-seen item size, since such
residuals are the most likely to be perfectly filled by a future item of that size. The
bonus is strictly subordinate to the integer SS delta so it never overrides the primary rule.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # running histogram of observed item sizes


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _freq
    s = int(item)
    _freq[s] += 1
    total = sum(_freq) or 1

    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def bonus(r):
        # small reward for leaving a residual that is a common item size; only within (0,1)
        if r <= 0:
            return 0.0
        return float(_freq[r]) / total

    def rank(r):
        # primary: sum-of-squares delta (smaller delta -> better)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # tiebreak tier: prefer residual that already exists (or 0)
        if r == 0 or _N[r] > 0:
            tb = 1
        else:
            tb = 0
        # secondary numeric tiebreak: prefer smaller residual (tighter fit)
        return (-delta, tb, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r)
        # integer SS delta dominates; tiebreak tier next; then histogram bonus; then tightness
        scores[k] = key[0] * 1e9 + key[1] * 1e6 + bonus(r) * 1e5 - key[2]

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if r_new == 0 or _N[r_new] > 0:
        tb_new = 1
    else:
        tb_new = 0
    scores[len(fitting):] = (-delta_new * 1e9 + tb_new * 1e6
                             + bonus(r_new) * 1e5 - r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
