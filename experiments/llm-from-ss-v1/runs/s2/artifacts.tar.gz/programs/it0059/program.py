# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with Best-Fit-style residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among placements with (nearly) equal delta, we prefer residuals
that already occur among open bins (or r == 0), then prefer the smallest residual (tighter
fit), which consolidates residual classes and reduces fragmentation.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # Primary signal: delta of sum N(g)^2. Lower delta is better -> use -delta.
    # Secondary: prefer existing residual class (tb=1) over a brand-new one (tb=0).
    # Tertiary: prefer smaller residual (tighter fit), scaled small.
    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        n_r = _N[r] if r > 0 else 0
        delta = -2 * _N[g_ref] + 1 + (2 * n_r + 1 if r > 0 else 0)
        tb = 1 if (r == 0 or (r > 0 and _N[r] > 0)) else 0
        scores[k] = (-delta) * 1e6 + tb * 1e3 - r

    r_new = CAP - s
    n_rnew = _N[r_new] if r_new > 0 else 0
    delta_new = (2 * n_rnew + 1) if r_new > 0 else 0
    tb_new = 1 if (r_new == 0 or (r_new > 0 and _N[r_new] > 0)) else 0
    scores[len(fitting):] = (-delta_new) * 1e6 + tb_new * 1e3 - r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
