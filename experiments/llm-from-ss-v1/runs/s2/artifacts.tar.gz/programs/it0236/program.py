# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with tightest-residual tie-breaking, scored on the harness array.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the smallest positive
post-placement residual (tightest packing), which concentrates residual mass into fewer,
more fillable gap values. Scoring is done directly against the harness-provided `bins`
array so it stays correct regardless of the array's length; a private record keeps the
counts N and the bin-index order. Unused bins appear as capacity 100 in the array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    scores = np.empty(n_bins, dtype=np.float64)

    # Map each bin in the provided array to a residual r = remaining - s.
    for k in range(n_bins):
        g = int(bins[k])
        r = g - s
        if g < CAP:
            # An opened bin: residual is r, current capacity is g.
            delta = -2 * _N[g] - 1
            if r > 0:
                delta += 2 * _N[r] + 1
        else:
            # Unused bin (capacity CAP): opening it puts residual r_new into the counts.
            if r > 0:
                delta = 2 * _N[r] + 1
            else:
                delta = 0
        # Primary: minimise delta (so maximise -delta). Secondary: smallest positive residual.
        tie = r if r > 0 else CAP + 1
        scores[k] = -delta * 1e6 - tie

    choice = int(np.argmax(scores))

    # Update private state using the chosen bin.
    g = int(bins[choice])
    if g < CAP:
        # Find the matching opened bin in _caps (identical capacity, first occurrence).
        for j in range(len(_caps)):
            if _caps[j] == g:
                _N[g] -= 1
                ng = g - s
                _caps[j] = ng
                if ng > 0:
                    _N[ng] += 1
                break
    else:
        ng = CAP - s
        _caps.append(ng)
        if ng > 0:
            _N[ng] += 1

    return scores
# EVOLVE-BLOCK-END
