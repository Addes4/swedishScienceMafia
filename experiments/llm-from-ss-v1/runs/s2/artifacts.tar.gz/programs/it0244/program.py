# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with distribution-aware residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the residual r that
maximises the empirical frequency of past item sizes <= r, i.e. the leftover space is most
likely to still be usable by a future item. The function keeps its own record of every
opened bin; used bins are a prefix of the bin array. Each instance runs in a fresh process,
so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_size_hist = [0] * (CAP + 1)   # counts of past item sizes
_total = 0                     # number of items seen so far


def _usable(r):
    """Fraction of past items that would fit in a residual of r (a rough usability score)."""
    if r <= 0:
        return 0.0
    if _total == 0:
        return float(r)
    upto = min(r, CAP)
    c = 0
    for v in range(1, upto + 1):
        c += _size_hist[v]
    return c / _total


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _size_hist, _total
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def rank(r):
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        return (-delta, _usable(r), r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r)
        scores[k] = key[0] * 1e6 + key[1] * 1e3 + key[2]

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -delta_new * 1e6 + _usable(r_new) * 1e3 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    _size_hist[s] += 1
    _total += 1
    return scores
# EVOLVE-BLOCK-END
