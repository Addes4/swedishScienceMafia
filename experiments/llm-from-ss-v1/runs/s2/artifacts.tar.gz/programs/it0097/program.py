# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with largest-residual tie-breaking (corrected).

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the placement that
leaves the largest post-placement residual. The function keeps its own record of every
opened bin, since unused bins are a prefix of the array and ties go to the first bin.
Each instance runs in a fresh process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

SCALE = 1000.0                 # primary delta is an integer; residual is < 100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.full(n_bins, -1e18, dtype=np.float64)

    # For each fitting bin j with residual capacity g = _caps[j], placing the item changes
    # sum_g N(g)^2 by: -(2*N[g]+1) + (2*N[g-s]+1 if g-s>0 else 0).
    ng_arr = np.array([_N[_caps[j]] for j in fitting], dtype=np.int64)
    resid_arr = np.array([_caps[j] - s for j in fitting], dtype=np.int64)
    delta = -2 * ng_arr - 1
    pos = resid_arr > 0
    if pos.any():
        delta[pos] += 2 * np.array([_N[r] for r in resid_arr[pos]], dtype=np.int64) + 1

    # Score: maximise (-delta), tie-break by larger residual.
    for k in range(len(fitting)):
        scores[k] = -float(delta[k]) * SCALE + float(resid_arr[k])

    # Unused bin: opens new bin with residual CAP - s, adds one to N[CAP-s].
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -float(delta_new) * SCALE + float(r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
