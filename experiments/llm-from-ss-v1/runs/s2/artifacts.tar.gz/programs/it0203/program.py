# EVOLVE-BLOCK-START
"""Best-fit-with-no-stranding rule.

Primary key: prefer a perfect fill (resulting residual r == 0). Otherwise prefer the
smallest resulting positive residual r (best-fit), which concentrates items tightly and
leaves large free space available. Unused-bin opens are ranked last, ordered by how much
space they leave. Small residuals are never "stranded" here because items arrive with
sizes spanning the whole range including tiny ones (1..100), so even r == 1 is usable.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # Rank fitting bins: perfect fill first, then smallest positive residual.
    for k, j in enumerate(fitting):
        r = _caps[j] - s
        # r == 0 -> best; smaller r -> better. Encode so higher score = better.
        if r == 0:
            scores[k] = 1e9
        else:
            scores[k] = -r

    # Rank unused-bin opens: worse than every fitting bin.
    r_new = CAP - s
    scores[len(fitting):] = -1e9 - r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        _caps[j] -= s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
