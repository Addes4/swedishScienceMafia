# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with largest-residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the placement that
leaves the largest post-placement residual, which keeps more usable free space available
for future items.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    caps = _caps
    N = _N

    # Identify fitting already-opened bins.
    fitting = [j for j in range(len(caps)) if caps[j] >= s]
    n_fit = len(fitting)
    n_unused = n_bins - n_fit
    scores = np.empty(n_bins, dtype=np.float64)

    # Primary: delta of sum N(g)^2 when moving a bin from residual g_ref to r = g_ref - s.
    # delta = (2*N(r)+1 if r>0 else 0) - (2*N(g_ref)+1)
    for k in range(n_fit):
        j = fitting[k]
        g_ref = caps[j]
        r = g_ref - s
        delta = 0
        if r > 0:
            delta += 2 * N[r] + 1
        delta -= 2 * N[g_ref] + 1
        # Pack primary delta (negated so argmax picks minimal delta) and residual tie-break.
        scores[k] = -delta * 1e9 + r

    # Unused-bin option: opening a new bin creates residual r_new = CAP - s.
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * N[r_new] + 1
    else:
        delta_new = 0
    scores[n_fit:] = -delta_new * 1e9 + r_new

    choice = int(np.argmax(scores))
    if choice < n_fit:
        j = fitting[choice]
        g = caps[j]
        N[g] -= 1
        caps[j] = g - s
        if g - s > 0:
            N[g - s] += 1
    elif n_unused > 0:
        caps.append(CAP - s)
        if CAP - s > 0:
            N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
