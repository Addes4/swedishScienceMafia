# EVOLVE-BLOCK-START
"""Best-Fit with harmonic residual preference.

Primary criterion: minimise the post-placement residual r = g - s (classic Best-Fit).
Tie-break: prefer residuals that are 'harmonic-friendly' -- i.e. residual values that are
multiples of common small item sizes (so future items can still fill them exactly), then
prefer more-common residuals. Keeps a persistent histogram of open-bin residuals.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _harmonic_fit(r):
    """Small bonus for residuals that are easy to exactly fill later."""
    if r <= 0:
        return 0.0
    # reward r divisible by small common sizes
    bonus = 0.0
    for d in (2, 3, 5, 7, 10, 20, 25):
        if d <= r and r % d == 0:
            bonus += 1.0 / d
    return bonus


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def key(r):
        # primary: minimal residual -> larger key; secondary: harmonic bonus; tertiary: count
        return -r + 0.25 * _harmonic_fit(r) + 0.05 * _N[r]

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        scores[k] = key(r)

    r_new = CAP - s
    scores[len(fitting):] = key(r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
