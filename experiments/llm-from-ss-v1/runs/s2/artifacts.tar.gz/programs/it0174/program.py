# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with best-fit tie-breaking.

Objective: minimise the delta of sum_g N(g)^2 over open residual capacities, where N(g)
counts open bins with remaining capacity g. This is the classical sum-of-squares online
bin packing rule. Exact ties in the delta are broken by best-fit: among placements with the
same delta, pick the one leaving the smallest residual, which keeps larger free space
undisturbed. The function is shown only the bins the item fits in, so it tracks all opened
bins itself. Used bins always form a prefix of the harness bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    best_key = None
    best_pos = -1

    def consider(pos, delta, r):
        nonlocal best_key, best_pos
        # lower delta is better -> key -delta; tie-break: smaller residual r better
        key = (-delta, r)
        if best_key is None or key < best_key:
            best_key = key
            best_pos = pos

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        consider(k, delta, r)

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if n_unused > 0:
        consider(len(fitting), delta_new, r_new)

    # assign scores: best_pos highest, everything else lower
    scores[:] = 0.0
    if best_pos >= 0:
        scores[best_pos] = 1.0

    if best_pos >= 0 and best_pos < len(fitting):
        j = fitting[best_pos]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif best_pos >= 0 and n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
