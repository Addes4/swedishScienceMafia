# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a one-step expected-fill tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). This "sum of squares" delta is kept as a strictly dominant integer
term. Ties are broken by a continuous sub-unit bonus that measures how likely the residual
left behind is to be exactly filled by the next item: for a residual r we sum the running
size histogram over item sizes equal to r (and, more generally, we reward residuals that
match frequently seen item sizes). This shrinks the number of small "leftover" bins.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0] * (CAP + 1)        # running histogram of observed item sizes
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _hist, _seen
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # expected-fill value of a residual r: probability the next item exactly fills it.
    total = _seen if _seen > 0 else 1
    # normalized, capped into [0, 1)
    fill = [(h / total) for h in _hist]

    def rank(r):
        # primary: sum-of-squares delta (smaller delta -> better)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # continuous sub-unit tiebreak: reward residuals likely to be filled next
        if r > 0 and r <= CAP:
            bonus = fill[r]
        elif r == 0:
            bonus = 1.0  # perfect fill: no leftover bin
        else:
            bonus = 0.0
        return delta, bonus, -r

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        d, b, t = rank(r)
        scores[k] = (-d) * 1e6 + b * 1e3 + t * 1e-3

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
        bonus_new = fill[r_new]
    elif r_new == 0:
        delta_new = 0
        bonus_new = 1.0
    else:
        delta_new = 0
        bonus_new = 0.0
    scores[len(fitting):] = (-delta_new) * 1e6 + bonus_new * 1e3 - r_new * 1e-3

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update histogram after placing
    _hist[s] += 1
    _seen += 1
    return scores
# EVOLVE-BLOCK-END

