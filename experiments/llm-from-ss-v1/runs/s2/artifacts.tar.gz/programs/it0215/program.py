# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with largest-residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the placement that
leaves the largest post-placement residual.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    n_used = len(_caps)
    scores = np.empty(n_bins, dtype=np.float64)

    # Fitting bins: those among the opened prefix with capacity >= s.
    fit_count = 0
    fit_idx = []
    fit_r = []
    for j in range(n_used):
        g = _caps[j]
        if g >= s:
            g_ref = g
            r = g - s
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            fit_idx.append(j)
            fit_r.append(r)
            scores[j] = -delta * 1e9 + r
            fit_count += 1

    # Unused bins (rest of array), all identical.
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if fit_count < n_bins:
        scores[fit_count:] = -delta_new * 1e9 + r_new

    choice = int(np.argmax(scores))
    if choice < fit_count:
        j = fit_idx[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_bins > n_used:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
