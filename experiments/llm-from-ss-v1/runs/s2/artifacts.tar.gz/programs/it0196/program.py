# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-reuse tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Ties in that exact delta are broken by preferring a placement that
leaves a residual already present among the open bins (residual reuse), which lets future
items close bins exactly; exact fills (residual 0) are preferred most. The function keeps its
own record of every opened bin; used bins are a prefix of the bin array. State starts empty
each instance (fresh process).
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # Secondary key (larger is better): prefer residual 0, then reuse of an existing residual.
    def sec(r):
        if r == 0:
            return 2
        if 0 < r < CAP and _N[r] > 0:
            return 1
        return 0

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        scores[k] = (-delta) * 1e9 + sec(r) * 1e6 + r

    r_new = CAP - s
    delta_new = (2 * _N[r_new] + 1) if r_new > 0 else 0
    scores[len(fitting):] = (-delta_new) * 1e9 + sec(r_new) * 1e6 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
