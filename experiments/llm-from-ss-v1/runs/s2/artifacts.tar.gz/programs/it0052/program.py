# EVOLVE-BLOCK-START
"""Harmonic (weighted-count) bin-choice rule with residual-class tie-breaking.

Each item goes where it minimises sum_g 1/(N(g)+1), where N(g) counts open bins with
remaining capacity g (0 < g < 100). Minimising the increase of this "harmonic" potential
tends to keep many distinct residual classes available (better fit opportunities later),
which empirically beats the plain sum-of-squares rule on Weibull-shaped item sizes.
Exact ties are broken by preferring a post-placement residual r that already occurs among
open bins (or r == 0), then by the smaller residual (tighter fit). The function is shown
only the bins the item fits in, so it keeps its own record of every opened bin. Used bins
form a prefix of the bin array; each instance runs in a fresh process, so the module-level
state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _harm(n):
    # contribution of a class with n bins: 1/(n+1)
    return 1.0 / (n + 1)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def key_for(g_ref, r):
        # harmonic potential delta (smaller is better -> use negative)
        if r > 0:
            delta = (_harm(_N[g_ref] - 1) - _harm(_N[g_ref])) + \
                    (_harm(_N[r] + 1) - _harm(_N[r]))
        else:
            delta = _harm(_N[g_ref] - 1) - _harm(_N[g_ref])
        tb = 1 if (r == 0 or _N[r] > 0) else 0
        return (-delta, tb, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        kk = key_for(g_ref, r)
        scores[k] = kk[0] * 1e9 + kk[1] * 1e6 - kk[2]

    r_new = CAP - s
    if r_new > 0:
        delta_new = (_harm(_N[CAP] - 1) - _harm(_N[CAP])) + \
                    (_harm(_N[r_new] + 1) - _harm(_N[r_new]))
    else:
        delta_new = _harm(_N[CAP] - 1) - _harm(_N[CAP])
    tb_new = 1 if (r_new == 0 or _N[r_new] > 0) else 0
    scores[len(fitting):] = -delta_new * 1e9 + tb_new * 1e6 - r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

