# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with robust lexicographic tie-breaking.

Each item goes where it minimises sum_g N(g)^2 (Stein's greedy rule), where N(g) counts open
bins with remaining capacity g (0 < g < 100). Exact-delta ties are broken lexicographically by
preferring the placement whose post-placement residual r = g_ref - s is closest to the item
size, i.e. the tightest sensible fit, which keeps larger residual classes intact.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (the harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)

    # Exact integer primary key (negated delta), then integer secondary tie key.
    prim = np.empty(n_bins, dtype=np.int64)
    sec = np.empty(n_bins, dtype=np.int64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        prim[k] = -delta
        # Secondary: prefer smaller resulting residual (tightest fit).
        sec[k] = r

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    prim[len(fitting):] = -delta_new
    sec[len(fitting):] = r_new

    # Lexicographic argmax: max primary, then min secondary, then first index.
    best = np.argmax(prim)          # ties -> first occurrence
    best_prim = prim[best]
    cand = np.nonzero(prim == best_prim)[0]
    choice = int(cand[np.argmin(sec[cand])])

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # Return a score vector consistent with the chosen ordering (higher = better).
    scores = prim.astype(np.float64) - sec.astype(np.float64) * 1e-6
    return scores
# EVOLVE-BLOCK-END
