# EVOLVE-BLOCK-START
"""Best-fit with sum-of-squares delta as the primary key.

Items go to the bin that minimises the sum-of-squares objective. Exact ties (very common,
since the delta only depends on the residual counts N[g]) are broken by best-fit: prefer the
smallest post-placement residual, i.e. pack the item into the fullest bin that still fits.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            # Delta from: removing a g_ref bin and adding an r bin.
            delta = (-2 * _N[g_ref] + 1) + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # Primary: minimise delta. Tie-break: best-fit (smallest residual).
        scores[k] = -delta * 1e9 - r

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -delta_new * 1e9 - r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
