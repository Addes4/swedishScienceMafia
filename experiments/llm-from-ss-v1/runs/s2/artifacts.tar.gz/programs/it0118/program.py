# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an exact-fill bonus and largest-residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100), with an additional bonus applied when a placement fills a bin
exactly (residual 0), because closing a bin removes its capacity class and reduces future
fragmentation. Exact-delta ties are broken by preferring the largest post-placement residual.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def delta(r, n) :
        d = -2 * n + 1
        if r > 0:
            d += 2 * _N[r] + 1
        return d

    def key(r, n):
        d = delta(r, n)
        # extra bonus for exact fills: more negative is better
        if r == 0:
            d -= n
        return (-d, r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        kk = key(r, _N[g_ref])
        scores[k] = kk[0] * 1e9 + kk[1]

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -delta_new * 1e9 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
