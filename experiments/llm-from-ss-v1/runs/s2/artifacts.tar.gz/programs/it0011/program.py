# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with item-size-aware residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken in this order:
  1. prefer a post-placement residual r that equals a previously observed item size
     (such a residual can be perfectly closed by a future item),
  2. prefer a residual that already occurs among open bins (or r == 0),
  3. prefer a tighter fit (smaller r).
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_seen = [0] * (CAP + 1)        # _seen[s]: count of items of size s seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _seen
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def key_for(g_ref, r):
        # primary: sum-of-squares delta (smaller delta -> better)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # tier 1: residual matches a previously seen item size (closable)
        if r > 0 and _seen[r] > 0:
            tb = 2
        elif r == 0 or _N[r] > 0:
            tb = 1
        else:
            tb = 0
        return delta, tb, r

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        delta, tb, rr = key_for(g_ref, r)
        # smaller delta better -> negate; larger tb better; smaller r better
        scores[k] = (-delta) * 1e9 + tb * 1e6 - rr

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if r_new > 0 and _seen[r_new] > 0:
        tb_new = 2
    elif r_new == 0 or _N[r_new] > 0:
        tb_new = 1
    else:
        tb_new = 0
    scores[len(fitting):] = (-delta_new) * 1e9 + tb_new * 1e6 - r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # record the arrived item for future tie-breaking
    if 0 < s <= CAP:
        _seen[s] += 1

    return scores
# EVOLVE-BLOCK-END
