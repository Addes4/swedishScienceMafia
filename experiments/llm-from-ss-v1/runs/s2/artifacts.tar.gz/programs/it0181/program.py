# EVOLVE-BLOCK-START
"""Sum-of-Squares rule (canonical) with clean integer lexicographic tie-breaking.

Each item goes where it minimises the post-placement sum of N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). The delta for moving a bin from
capacity g_ref to r = g_ref - s is  (2*N[r]+1) - (2*N[g_ref]-1) = 2*N[r] - 2*N[g_ref] + 2
(treating N as the counts after removal of g_ref). Ties are broken by preferring the
placement with the smaller resulting residual-free fragmentation, i.e. we simply keep
the first bin (lowest index) on exact ties, which matches the harness convention and the
canonical algorithm.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to the first bin."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_open = len(_caps)
    scores = np.empty(n_bins, dtype=np.float64)

    # Used bins.
    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = 2 * _N[r] - 2 * _N[g_ref] + 2
        else:
            delta = -2 * _N[g_ref] + 1
        scores[k] = float(delta)

    # Unused bins: opening a fresh bin.
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = float(delta_new)

    # Lower delta is better; argmax picks highest score, so negate.
    choice = int(np.argmax(-scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_bins - len(fitting) > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

