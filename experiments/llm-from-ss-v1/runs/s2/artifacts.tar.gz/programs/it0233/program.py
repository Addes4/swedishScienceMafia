# EVOLVE-BLOCK-START
"""Best-fit with sum-of-squares consolidation tie-break.

Primary rule: place the item where the change in sum_g N(g)^2 (N(g) = number of open bins
with remaining capacity g, 0 < g < 100) is smallest. This balances opening new bins against
concentrating residuals. Ties in the exact sum-of-squares delta are broken by preferring the
placement whose resulting residual already appears among the open bins (consolidation, so
that pairings/merges remain possible), and then by the largest residual.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array; each instance runs in a fresh
process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)

    # Find bins this item fits in, using our own cap record.
    fitting = []
    for j, g in enumerate(_caps):
        if g >= s:
            fitting.append(j)

    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    best_all = None  # (delta, consolidate_penalty, -r, bin_index_type)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # delta = -2N(g) + 1  (bin at g removed)  + (2N(r)+1 if r>0 else 0)  (bin at r added)
        if r > 0:
            delta = -2 * _N[g] + 1 + 2 * _N[r] + 1
        else:
            delta = -2 * _N[g] + 1
        # consolidation: prefer r already present (and not equal to g unless it's the same)
        cons = 0 if (r == 0 or _N[r] > 0) else 1
        scores[k] = -(delta) * 1e9 - cons * 1e6 + r * 1e-3

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -(delta_new) * 1e9 + r_new * 1e-3

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
