# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with histogram-aware residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken with a small bonus (< 1 delta unit) given to
placements whose post-placement residual r matches a frequently observed past item size (a
proxy for future arrivals), and a tiny bonus for avoiding a fresh unused bin. The bonus is
strictly smaller than the integer sum-of-squares delta step, so the primary rule dominates.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0] * (CAP + 1)        # observed item-size histogram
_seen = 0                      # total items observed


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist, _seen
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # frequency proxy: fraction of past items equal to a given size
    tot = _seen if _seen > 0 else 1

    def resid_bonus(r):
        # strictly less than 1 so integer delta dominates; prefer common residuals
        if r == 0:
            return 0.5
        return 0.4 * (_hist[r] / tot)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        b = resid_bonus(r) + 0.05  # small bonus for using an existing bin
        scores[k] = -delta + b

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -delta_new + resid_bonus(r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update histogram after choosing
    _hist[s] += 1
    _seen += 1
    return scores
# EVOLVE-BLOCK-END

