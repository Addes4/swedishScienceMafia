# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a frequency-aware residual tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the placement whose
post-placement residual is a frequently-seen item size, which keeps free space fillable.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # _freq[s]: count of items of size s seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _freq
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # update running item-size frequency (used by the tie-break)
    _freq[s] += 1

    def key(r):
        # primary: sum-of-squares delta (smaller is better -> larger score)
        delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        # tie-break: prefer residual that is a more common item size (larger freq better)
        return (-delta, _freq[r])

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        d, tb = key(r)
        scores[k] = d * 1e6 + tb

    g_ref = CAP
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = (-delta_new) * 1e6 + _freq[r_new]

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
