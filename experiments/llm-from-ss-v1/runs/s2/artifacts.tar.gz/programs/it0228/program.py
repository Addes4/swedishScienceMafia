# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with histogram-aware tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < CAP). Exact-delta ties are broken by preferring the placement whose
resulting residual r best matches the empirical size distribution — i.e. r is a size the
item stream has been producing often, so a future item is likely to fill it exactly.
A rolling histogram of past item sizes supplies that probability estimate.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = np.zeros(CAP + 1, dtype=np.float64)  # empirical counts of item sizes seen so far
_total = 0.0


def _freq_quality(r):
    """Higher is better: expected usefulness of leaving residual r."""
    if r <= 0:
        return 0.0
    # Probability a future item exactly equals r, weighted by the count in the histogram.
    return _hist[r] / (_total + 1.0)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist, _total
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def rank(r):
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # Secondary: prefer residual r that historically is a common item size.
        q = _freq_quality(r)
        return (-delta, q, r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        delta, q, rr = rank(r)
        # Primary = sum-of-squares delta; secondary = frequency quality; tertiary = largest residual.
        scores[k] = -delta * 1e6 + q * 1e3 + rr

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    q_new = _freq_quality(r_new)
    scores[len(fitting):] = -delta_new * 1e6 + q_new * 1e3 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # Update histogram of item sizes for future tie-breaks.
    _hist[s] += 1.0
    _total += 1.0
    return scores
# EVOLVE-BLOCK-END
