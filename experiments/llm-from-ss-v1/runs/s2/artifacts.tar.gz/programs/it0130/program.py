# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with histogram-aware residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). The function keeps its own record of every opened bin because the
harness only shows it fitting bins. Used bins are always a prefix of the bin array (harness
opens unused bins in index order and ties go to the first bin). Each instance runs in a
fresh process, so module-level state starts empty for every instance.

Ties and near-ties in the primary objective are broken by a cheap, online estimate of how
"useful" the resulting residual is: residuals that match commonly-seen item sizes (and exact
fits) are preferred, which helps pack future items tightly without wasting free space.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_item_count = [0] * (CAP + 1)  # observed item-size histogram
_total_items = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _item_count, _total_items
    s = int(item)

    # update observed item-size histogram
    _item_count[s] += 1
    _total_items += 1

    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # precompute residual-quality function: how likely some future item fits a residual r.
    # cheap proxy: sum over item sizes v of hist[v] * [v <= r] normalized.
    # We approximate with a coarse cumulative over item sizes (recomputed lazily once).
    inv_total = 1.0 / _total_items

    def residual_quality(r):
        # fraction of seen items that would fit in residual r
        if r <= 0:
            return 0.0
        acc = 0
        # sample only coarse buckets for speed: step 4
        v = 1
        while v <= r and v <= CAP:
            acc += _item_count[v]
            v += 1
        return acc * inv_total

    def rank(r):
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        q = residual_quality(r)
        return (-delta, q, r)

    rq_cache = {}
    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r not in rq_cache:
            rq_cache[r] = residual_quality(r)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        q = rq_cache[r]
        scores[k] = (-delta) * 1e6 + q * 1e3 + r * 1e-3

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    q_new = rq_cache.get(r_new) if r_new in rq_cache else residual_quality(r_new)
    scores[len(fitting):] = (-delta_new) * 1e6 + q_new * 1e3 + r_new * 1e-3

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
