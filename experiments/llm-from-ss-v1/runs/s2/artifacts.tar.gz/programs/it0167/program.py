# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with largest-residual tie-breaking (clean lexicographic form).

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Ties are broken by preferring the placement that leaves the
largest post-placement residual, keeping more usable free space for future items.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # For each candidate placement we compute the exact change in sum_g N(g)^2:
    #   removing residual g_ref contributes -2*N[g_ref]+1,
    #   adding residual r contributes +2*N[r]+1 (0 if r == 0).
    # Primary objective: minimize delta. Secondary: maximize resulting residual r.
    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        delta = -2 * _N[g_ref] + 1
        if r > 0:
            delta += 2 * _N[r] + 1
        # binary priority: delta minimization is primary, r maximization secondary
        scores[k] = -delta * 1e6 + r

    # Opening a fresh bin: only the "add residual" term applies.
    r_new = CAP - s
    delta_new = (2 * _N[r_new] + 1) if r_new > 0 else 0
    scores[len(fitting):] = -delta_new * 1e6 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
