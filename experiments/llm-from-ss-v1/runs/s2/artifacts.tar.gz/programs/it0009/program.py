# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with item-size-aware residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken by preferring a post-placement residual r
that matches a frequently seen item size (so a later item can close that bin exactly),
then by residual-existence, then by tighter fit.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_H = [0.0] * (CAP + 1)         # decaying histogram of past item sizes


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _H
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # update decaying histogram (lightweight)
    for g in range(1, CAP + 1):
        _H[g] *= 0.995
    _H[s] += 1.0

    def key_for(r, delta):
        tb_match = 1 if (r > 0 and _H[r] > 2.0) else 0
        tb_exists = 1 if (r == 0 or _N[r] > 0) else 0
        return (-delta, tb_match, tb_exists, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        kk = key_for(r, delta)
        scores[k] = (kk[0] * 1e12 + kk[1] * 1e9 + kk[2] * 1e6 - kk[3])

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    kk = key_for(r_new, delta_new)
    scores[len(fitting):] = (kk[0] * 1e12 + kk[1] * 1e9 + kk[2] * 1e6 - kk[3])

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
