# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with item-size-aware tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken by preferring a post-placement residual r
that is a recently observed item size (so the bin can likely be closed by one future item),
then r == 0, then the smallest residual. The function is shown only the bins the item fits
in, so it keeps its own record of every opened bin and a decaying item-size histogram.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0.0] * (CAP + 1)      # decaying count of recently seen item sizes

DECAY = 0.999                  # slow decay: ~5000-item effective window


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _freq
    s = int(item)

    # decay the histogram and record this item
    for v in range(1, CAP + 1):
        _freq[v] *= DECAY
    _freq[s] += 1.0

    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def rank(g_ref, r):
        # primary: sum-of-squares delta (smaller delta -> better)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # tiebreak tier 1: r is a likely single-item filler
        if r > 0 and _freq[r] > 0:
            tb = 3
        elif r == 0:
            tb = 2
        else:
            tb = 1
        # tier 2: strength of that filler / downward residual preference
        aux = _freq[r] if r > 0 else 0.0
        return (-delta, tb, aux, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(g_ref, r)
        scores[k] = (key[0] * 1e9 + key[1] * 1e6 + key[2] * 1e3 - key[3])

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if r_new > 0 and _freq[r_new] > 0:
        tb_new = 3
    elif r_new == 0:
        tb_new = 2
    else:
        tb_new = 1
    aux_new = _freq[r_new] if r_new > 0 else 0.0
    scores[len(fitting):] = (-delta_new * 1e9 + tb_new * 1e6 + aux_new * 1e3 - r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
