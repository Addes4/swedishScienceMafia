# EVOLVE-BLOCK-START
"""Sum-of-Squares rule computed directly from the provided `bins` array.

For each fitting bin with remaining capacity g, the placement changes the residual histogram
by moving one bin from bucket g to bucket r = g - item. Using the exact Sum-of-Squares
criterion (minimise sum_t N(t)^2 after placement) gives the ranking:
    delta(g -> r) = (2*N(r) + [r>0]) - (2*N(g) + [g>0])
The item goes to the bin minimising this delta. Unused bins (capacity CAP) act as g = CAP
with no prior occupancy. This rule is applied to the harness-provided `bins` array each call,
so it cannot desync from the true bin states. Ties break toward the smallest residual.
"""
import numpy as np

CAP = 100


def priority(item, bins):
    s = int(item)
    g_all = bins.astype(np.int64)
    n = len(g_all)

    # Histogram of residual capacities among fitting bins, plus unused-bin accounting.
    # We use the harness array directly as the source of truth.
    N = np.bincount(g_all, minlength=CAP + 1)  # counts bins by remaining capacity

    fits = g_all >= s
    # For fitting bins, r = g - s.
    g_fit = g_all[fits]
    r_fit = g_fit - s

    # delta = (2*N(r)+[r>0]) - (2*N(g)+[g>0])
    def bucket_count(vals):
        # counts in the original N for those values (including g==CAP for unused handled below)
        return 2.0 * N[vals] + (vals > 0)

    term_r = bucket_count(r_fit)
    term_g = bucket_count(g_fit)
    delta = term_r - term_g

    # score: highest = best. Primary minimise delta, secondary smallest r.
    # Encode lexicographically; deltas are bounded so scaling is safe.
    scores = -delta * 1e6 - r_fit

    out = np.full(n, -1e18, dtype=np.float64)
    idx = np.where(fits)[0]
    out[idx] = scores
    return out
# EVOLVE-BLOCK-END
