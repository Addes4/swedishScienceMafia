# EVOLVE-BLOCK-START
"""Exact-delta Sum-of-Squares with largest-residual tie-breaking.

Each item goes where it minimises the true change in sum_g N(g)^2, where N(g) counts open
bins with remaining capacity g (0 < g < 100). For a placement that turns a bin of residual
g_ref into residual r = g_ref - s, the change is:
    + (2*N[r] + 1)   if r > 0   (a bin joins the r-class)
    - (2*N[g_ref] - 1) if g_ref > 0 (a bin leaves its old class)
Opening a fresh bin changes the objective by +(2*N[r_new] + 1) if r_new > 0.
Exact ties are broken by preferring the largest post-placement residual.
The harness opens unused bins in index order, so used bins form a prefix. State starts
empty in every fresh instance process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        delta = -2 * _N[g_ref] + 1
        if r > 0:
            delta += 2 * _N[r] + 1
        scores[k] = -delta * 1e9 + r

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -delta_new * 1e9 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
