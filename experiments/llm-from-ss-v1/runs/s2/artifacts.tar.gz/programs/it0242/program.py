# EVOLVE-BLOCK-START
"""Sum-of-Squares rule driven directly by the provided `bins` array.

Each arriving item is placed so as to minimise the change in sum_g N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100).  The `bins` argument given to priority()
is the authoritative view of every bin the item fits in, so we use it directly to compute the
score for each visible bin instead of maintaining a private positional map.  A private copy
of the full bin state is kept only to evaluate the sum-of-squares term N().

Exact ties are broken by preferring the largest post-placement residual (best-fit-like), which
tends to keep the most usable free space available.  The module-level state is reset per
instance because every instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_vis = len(bins)          # number of bins shown (all that fit the item)
    scores = np.empty(n_vis, dtype=np.float64)

    # Scores for the bins the harness actually shows.  `bins` is the remaining capacity of
    # every bin the item fits in; the item may still create a new bin, which we score last.
    for k in range(n_vis):
        g_ref = int(bins[k])
        r = g_ref - s
        # Change in sum N(g)^2 when capacity g_ref loses a bin and residual r gains one.
        delta = (2 * _N[r] + 1 if r > 0 else 0) - (2 * _N[g_ref] + 1)
        # Prefer the most negative delta (reduces the sum of squares); break ties by larger r.
        scores[k] = -delta * 1e9 + r

    # Never open a new bin unless nothing else helps: heavily penalise it.
    r_new = CAP - s
    delta_new = (2 * _N[r_new] + 1) if r_new > 0 else 0
    scores[-1] = -delta_new * 1e9 + r_new - 1e12

    choice = int(np.argmax(scores))
    g_ref = int(bins[choice])
    r = g_ref - s
    _N[g_ref] -= 1
    if r > 0:
        _N[r] += 1
    _caps.append(r)            # not used for scoring, kept for parity with the bin log
    return scores
# EVOLVE-BLOCK-END
