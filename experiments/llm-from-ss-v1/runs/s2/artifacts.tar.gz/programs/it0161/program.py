# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with historical-residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < CAP). Near-ties in the delta are broken by preferring the placement
whose post-placement residual exactly matches an item size that has already been observed
at least once (such a bin can later be filled exactly); otherwise we prefer the largest
residual. The function keeps its own record of every opened bin because it only sees the
fitting bins. Used bins are a prefix of the bin array, and ties go to the first bin.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_seen = [0] * (CAP + 1)        # _seen[s]: how many items of size s have arrived


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _seen
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def base_delta(g_ref, r):
        # change in sum_g N(g)^2 from removing residual g_ref and adding residual r
        if r > 0:
            return -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        return -2 * _N[g_ref] + 1

    def key(delta, r):
        # primary: smaller delta (better). Secondary: residual that is a known item size.
        match = 1 if (r > 0 and _seen[r] > 0) else 0
        return (-delta, match, r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        delta = base_delta(g_ref, r)
        kk = key(delta, r)
        scores[k] = kk[0] * 1e9 + kk[1] * 1e6 + kk[2]

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    kk = key(delta_new, r_new)
    scores[len(fitting):] = kk[0] * 1e9 + kk[1] * 1e6 + kk[2]

    # update historical item-size counts after scoring so the current item is not counted
    _seen[s] += 1

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
