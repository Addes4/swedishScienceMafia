# EVOLVE-BLOCK-START
"""Best-fit rule driven by post-placement residual.

Items arrive online and must be placed immediately. Classic best-fit (pick the fitting bin
that leaves the smallest nonnegative residual) is a strong, well-established packing
heuristic that keeps large free spaces intact for big future items. The function is shown
only the bins the item fits in, so it keeps its own record of the remaining capacity of
every opened bin, in bin-index order (unused bins are always appended last).
"""
import numpy as np

CAP = 100
_caps = []   # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps
    s = int(item)
    n_bins = len(bins)
    n_caps = len(_caps)
    n_unused = n_bins - n_caps

    scores = np.empty(n_bins, dtype=np.float64)
    best = -1.0

    # Best-fit: smaller resulting residual is better -> higher score.
    for j in range(n_caps):
        g = _caps[j]
        if g >= s:
            r = g - s
            scores[j] = -r
        else:
            scores[j] = -1e9

    # Unused bins: prefer the one that becomes fullest (CAP - s), same criterion as a fresh bin.
    scores[n_caps:] = -(CAP - s)

    choice = int(np.argmax(scores))
    if choice < n_caps:
        _caps[choice] -= s
    else:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
