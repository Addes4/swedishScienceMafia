# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact consolidation tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among placements with equal sum-of-squares delta, we prefer the
post-placement residual r whose class is most populated after placement (best consolidation),
then smaller residual (tighter fit). Selection is done with exact integer arithmetic and
numpy lexicographic comparison, avoiding float-key precision loss.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n_bins = len(bins)
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_fit = len(fitting)

    # candidate placements: (delta, neg_consolidation, -r, position_index)
    # We build arrays then pick the lexicographic minimum of (delta, -cons, -r).
    m = n_fit + 1  # +1 for the option of opening a new bin
    deltas = np.empty(m, dtype=np.int64)
    negcons = np.empty(m, dtype=np.int64)
    negr = np.empty(m, dtype=np.int64)
    pos = np.empty(m, dtype=np.int64)
    # map option index -> bin position (0..n_fit-1) or n_fit meaning "unused"

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # delta of sum-of-squares change: remove N(g), add N(r) (if r>0)
        if r > 0:
            deltas[k] = (-2 * _N[g] + 1) + (2 * _N[r] + 1)
            cons = _N[r] + 1
        else:
            deltas[k] = -2 * _N[g] + 1
            cons = 0  # r == 0 is a closing move; give it top consolidation priority
        negcons[k] = cons
        negr[k] = -r
        pos[k] = k

    # new bin option
    r_new = CAP - s
    g = CAP
    if r_new > 0:
        deltas[n_fit] = (2 * _N[r_new] + 1) if g == CAP and _N[CAP] == 0 else (2 * _N[r_new] + 1)
        cons = _N[r_new] + 1
    else:
        deltas[n_fit] = 0
        cons = 0
    negcons[n_fit] = cons
    negr[n_fit] = -r_new
    pos[n_fit] = n_fit

    # choose lexicographically smallest (deltas, -cons -> i.e. largest cons, -r -> smallest r)
    order = np.lexsort((pos, negr, -negcons, deltas))
    best = int(order[0])

    # Build scores so that np.argmax picks `best`: highest score at index best (first on ties).
    scores = np.empty(n_bins, dtype=np.float64)
    scores[:] = 0.0
    if best < n_fit:
        chosen_binpos = fitting[best]
        scores[chosen_binpos] = 1.0
        # also make all later unused bins lower; earlier fitting bins 0 is fine (tie goes to first)
        # ensure chosen index is the first with score 1.0 -> set only it
        g = _caps[chosen_binpos]
        _N[g] -= 1
        _caps[chosen_binpos] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        # open a new bin: choose the first unused bin (index n_fit fit bins + earlier unused)
        new_idx = n_fit
        scores[new_idx] = 1.0
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    return scores
# EVOLVE-BLOCK-END

