# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with empirical-residual bonus tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). On top of this dominant term, a small adaptive bonus rewards
placements whose post-placement residual equals a frequently-seen item size (easy to close
later), using a running histogram of past item sizes. Exact ties still prefer a residual that
already occurs among open bins (or r == 0). State starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0.0] * (CAP + 1)      # decaying counts of seen item sizes (1..CAP)
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _seen
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # empirical frequency of a residual being consumable later
    tot = _seen if _seen > 0 else 1
    hist = _freq

    def rank(r):
        # primary: sum-of-squares delta (smaller delta -> better)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # tiebreak tier: prefer residual that already exists (or 0)
        if r == 0 or _N[r] > 0:
            tb = 1
        else:
            tb = 0
        # adaptive bonus: residual is a common item size -> easier to close
        bonus = hist[r] / tot if r > 0 else 0.0
        return (-delta, tb, bonus, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r)
        scores[k] = (key[0] * 1e9 + key[1] * 1e6 + key[2] * 1e3 - key[3])

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if r_new == 0 or _N[r_new] > 0:
        tb_new = 1
    else:
        tb_new = 0
    bonus_new = hist[r_new] / tot if r_new > 0 else 0.0
    scores[len(fitting):] = (-delta_new * 1e9 + tb_new * 1e6 + bonus_new * 1e3 - r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    # update the running item-size histogram with global decay
    _seen += 1
    if _seen > 400:
        for v in range(1, CAP + 1):
            _freq[v] *= 0.995
    _freq[s] += 1.0
    return scores
# EVOLVE-BLOCK-END

