# EVOLVE-BLOCK-START
"""Best-fit rule over a self-maintained record of open bins.

The harness shows only bins the item fits in, so the function keeps its own list of the
remaining capacity of every opened bin, in bin-index order (used bins form a prefix).
Among fitting bins, choose the one whose post-placement residual is smallest (best fit),
breaking ties by preferring the largest current remaining capacity. Unused bins are only
picked when nothing else fits.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _caps
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # prefer smallest residual (best fit); secondary: largest current capacity
        scores[k] = -r * 1e6 + g

    # unused bins: capacity CAP, residual CAP - s
    if n_unused > 0:
        r_new = CAP - s
        scores[len(fitting):] = -r_new * 1e6 + CAP

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        _caps[j] -= s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END

