# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact-fit-first and tightest-fit tie-breaking.

Primary rule: sum-of-squares (minimise sum_g N(g)^2) keeps open-bin residual classes
consolidated. Two refinements layer on top:
  1. If some fitting bin has remaining capacity exactly equal to the item, take it
     (a perfect fit costs no future slack).
  2. Otherwise, among placements tied on the sum-of-squares delta, prefer the smallest
     positive post-placement residual (tightest fit), which closes bins sooner.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def score_fit(r):
        # r = post-placement remaining capacity
        if r > 0:
            delta = 2 * _N[r] + 1 - 2 * _N[r + s] + 1  # not exact; recomputed below
        # recompute exact delta using the bin's own class g = r + s
        g = r + s
        if r > 0:
            delta = (-2 * _N[g] + 1) + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g] + 1
        # tier 1: smaller delta better (use -delta as high-is-better)
        # tier 2: exact-fit r == 0 strongly preferred (huge bonus)
        # tier 3: smaller positive r (tighter fit)
        return delta, r

    # exact-fit override
    exact_idx = -1
    for k, j in enumerate(fitting):
        if _caps[j] == s:
            exact_idx = k
            break

    if exact_idx >= 0:
        for k, j in enumerate(fitting):
            scores[k] = 1.0 if k == exact_idx else 0.0
        scores[len(fitting):] = -1.0
        choice = exact_idx
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        if g - s > 0:
            _N[g - s] += 1
        _caps[j] = g - s
        return scores

    # sum-of-squares primary with tightest-fit tie-break
    best_delta = None
    best_r = None
    best_k = None
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        if r > 0:
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g] + 1
        if (best_delta is None or delta < best_delta
                or (delta == best_delta and r < best_r)):
            best_delta = delta
            best_r = r
            best_k = k

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if (best_delta is None or delta_new < best_delta
            or (delta_new == best_delta and r_new < best_r)):
        # unused bin is best
        for k in range(len(fitting)):
            scores[k] = 0.0
        scores[len(fitting):] = 1.0
        choice = len(fitting)
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
        return scores

    for k in range(len(fitting)):
        scores[k] = 1.0 if k == best_k else 0.0
    scores[len(fitting):] = -1.0
    choice = best_k
    j = fitting[choice]
    g = _caps[j]
    _N[g] -= 1
    if g - s > 0:
        _N[g - s] += 1
    _caps[j] = g - s
    return scores
# EVOLVE-BLOCK-END
