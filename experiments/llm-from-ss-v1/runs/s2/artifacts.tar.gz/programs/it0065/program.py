# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-class consolidation.

Each item goes where it minimises sum_g N(g)^2 over open bins with remaining capacity g
(0 < g < 100). This is the classic worst-fit-like rule that keeps few residual classes open.
Exact ties are broken by preferring residual 0, then an existing residual class, then the
largest such residual. The function keeps its own record of all opened bins, since it is
only shown the bins the item fits in. Used bins are a prefix of the array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # tier: residual 0 best, then existing class, then new class
        if r == 0:
            tb = 2
        elif _N[r] > 0:
            tb = 1
        else:
            tb = 0
        scores[k] = (-delta) * 1e9 + tb * 1e6 + r

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if r_new == 0:
        tb_new = 2
    elif _N[r_new] > 0:
        tb_new = 1
    else:
        tb_new = 0
    scores[len(fitting):] = (-delta_new) * 1e9 + tb_new * 1e6 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
