# EVOLVE-BLOCK-START
"""Smooth sum-of-squares rule (Worst-Fit) with intrinsic residual-class consolidation.

Each item goes where it minimises the sum over residual classes g of N(g)^2, where N(g)
counts open bins with remaining capacity g (0 < g < 100). This is the classic "Worst-Fit"
relaxation: a placement that consumes residual g and creates residual r changes the sum by
delta = (-2*N[g] + 1) + (2*N[r] + 1) (the +1/-1 corrects for the bin being counted before
and after). Placing into an unused bin changes the sum by 2*N[r] + 1 (r = 100 - item).

Exact-delta ties are broken by an *intrinsic* fractional bonus that prefers a residual r
that already occurs among open bins (or r == 0), which consolidates residual classes and
lets bins close sooner. The bonus is small enough that it never overrides the integer delta.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (the harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

_EPS = 0.25                    # fractional consolidation bonus (never overrides integer delta)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    scores = np.empty(n_bins, dtype=np.float64)

    def tie_bonus(r):
        # prefer residual r that already exists among open bins (consolidation), or r == 0
        if r == 0 or _N[r] > 0:
            return _EPS
        return 0.0

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # score = -delta (larger better) plus fractional consolidation bonus
        scores[k] = -delta + tie_bonus(r)

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -delta_new + tie_bonus(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
