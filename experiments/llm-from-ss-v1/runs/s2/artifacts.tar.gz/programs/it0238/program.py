# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with largest-residual tie-breaking (robust lexicographic selection).

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the placement that
leaves the largest post-placement residual, which keeps more usable free space available
for future items.
The function keeps its own record of every opened bin. Used bins are always a prefix of the
bin array (harness opens unused bins in index order and ties go to the first bin). Module-level
state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # Compute exact delta for each fitting bin and the new-bin option.
    deltas = []
    residuals = []
    for j in fitting:
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        deltas.append(delta)
        residuals.append(r)

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0

    best_delta = None
    best_res = None
    best_index = -1  # index into scores array

    for k in range(len(fitting)):
        d = deltas[k]
        r = residuals[k]
        if best_delta is None or d < best_delta or (d == best_delta and r > best_res):
            best_delta = d
            best_res = r
            best_index = k

    if n_unused > 0:
        if best_delta is None or delta_new < best_delta or (delta_new == best_delta and r_new > best_res):
            best_delta = delta_new
            best_res = r_new
            best_index = len(fitting)  # marks new-bin option

    # Build scores so that argmax picks best_index (tie -> first, we make it unique largest).
    scores[:] = -1.0
    scores[best_index] = 1.0

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
