# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with histogram-aware tie-breaking.

Primary criterion is the exact sum-of-squares delta, sum_g N(g)^2, where N(g) counts open
bins with remaining capacity g (0 < g < 100). Exact ties are broken first by preferring a
post-placement residual r that already occurs among open bins (or r == 0), then by a small
adaptive bonus if r is a common item size seen so far (so the bin is likely to close soon).
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0] * (CAP + 1)        # observed item-size histogram
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _hist, _seen
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # bonus for residuals that are common item sizes (likely to be closed soon)
    if _seen > 0:
        max_hist = max(_hist) or 1
    else:
        max_hist = 1

    def rank(g_ref, r):
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        if r == 0 or _N[r] > 0:
            tb = 1
        else:
            tb = 0
        if 0 < r < CAP:
            bonus = _hist[r] / max_hist
        else:
            bonus = 0.0
        return (-delta, tb, bonus, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(g_ref, r)
        scores[k] = key[0] * 1e9 + key[1] * 1e6 + key[2] * 1e3 + key[3] * 1e-3

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if r_new == 0 or _N[r_new] > 0:
        tb_new = 1
    else:
        tb_new = 0
    if 0 < r_new < CAP:
        bonus_new = _hist[r_new] / max_hist
    else:
        bonus_new = 0.0
    scores[len(fitting):] = (-delta_new * 1e9 + tb_new * 1e6
                             + bonus_new * 1e3 - r_new * 1e-3)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    _hist[s] += 1
    _seen += 1
    return scores
# EVOLVE-BLOCK-END

