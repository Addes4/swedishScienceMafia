# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact integer delta tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among placements with equal sum-of-squares delta, prefer the one
that closes a bin (r == 0), then one whose post-placement residual r already occurs among
open bins (consolidation), then the smallest residual (tightest fit). Keys are exact integers
so no floating point rounding can reorder near-ties. The function keeps its own record of
every opened bin; used bins are always a prefix of the bin array. Each instance runs in a
fresh process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    scores = np.empty(n_bins, dtype=np.int64)

    best_key = None
    best_score = -1

    # choose the placement with the lexicographically smallest key
    # key = (delta, closing_penalty, tb, r)
    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        closing = 0 if r == 0 else 1
        tb = 0 if (r == 0 or _N[r] > 0) else 1
        key = (delta, closing, tb, r)
        if best_key is None or key < best_key:
            best_key = key
            best_score = k

    r_new = CAP - s
    delta_new = (2 * _N[r_new] + 1) if r_new > 0 else 0
    closing_new = 0 if r_new == 0 else 1
    tb_new = 0 if (r_new == 0 or _N[r_new] > 0) else 1
    key_new = (delta_new, closing_new, tb_new, r_new)
    if best_key is None or key_new < best_key:
        best_key = key_new
        best_score = len(fitting)

    # assign scores so that lower key -> higher score (first highest wins on ties)
    scores[:] = 0
    scores[best_score] = 1

    if best_score < len(fitting):
        j = fitting[best_score]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_bins > len(fitting):
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
