# EVOLVE-BLOCK-START
"""Best-fit-guarded-by-min-item rule with sum-of-squares fallback.

Each item is placed by preferring the tightest fit (smallest residual) among bins whose
residual is at least the smallest item size seen so far -- so leftover space is still
usable. If no fitting bin meets that guard, the rule falls back to minimizing the
sum-of-squares change (delta) as a secondary objective, with largest-residual
tie-breaking.

`bins` is shown only for the bins the item fits in, so the function keeps its own record
of every opened bin. Used bins form a prefix of the bin array. Each instance runs in a
fresh process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_min_seen = CAP                # smallest item size observed so far


def priority(item, bins):
    """Rank every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _min_seen
    s = int(item)
    if s < _min_seen:
        _min_seen = s
    guard = _min_seen

    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # Primary: prefer tightest fit whose residual is still >= guard.
    # Secondary: smaller sum-of-squares delta; tertiary: larger residual.
    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = 2 * _N[r] + 1 - 2 * _N[g_ref] + 1
        else:
            delta = -2 * _N[g_ref] + 1
        if r >= guard:
            primary = 0.0
        else:
            primary = 1.0
        scores[k] = primary * 1e16 - delta * 1e8 + (CAP - r)

    # Unused bin (opens a fresh bin): residual CAP - s.
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if r_new >= guard:
        primary_new = 0.0
    else:
        primary_new = 1.0
    scores[len(fitting):] = primary_new * 1e16 - delta_new * 1e8 + (CAP - r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

