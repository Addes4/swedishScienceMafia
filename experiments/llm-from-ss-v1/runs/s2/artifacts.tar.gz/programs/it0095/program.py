# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-minimizing near-tie-breaking."""
import numpy as np

CAP = 100
_caps = []
_N = [0] * (CAP + 1)


def priority(item, bins):
    s = int(item)
    n_bins = len(bins)
    global _caps, _N
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        old = _N[g]
        if r > 0:
            delta = -2 * old + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * old + 1
        scores[k] = delta * 1000.0 + r

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = delta_new * 1000.0 + r_new

    choice = int(np.argmin(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
