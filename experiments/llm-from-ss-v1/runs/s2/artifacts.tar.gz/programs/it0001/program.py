# EVOLVE-BLOCK-START
"""Best-Fit rule with a small tie-break.

Each item is placed into the fitting bin with the smallest remaining capacity
after insertion (classic Best Fit). Among ties we prefer the bin that is
currently fuller. Unused bins are only chosen when no partly-filled bin fits.

The function is shown only the bins the item fits in, so it keeps its own
record of every opened bin. The harness opens unused bins in index order, so
used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # For used bins: prefer tightest fit (smallest leftover r), tie-break by larger used size.
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # smaller r -> higher score; secondary: smaller g (fuller original bin)
        scores[k] = -(r * 1000 + g)

    # Unused bins get the worst scores among feasible options (encourage reuse).
    r_new = CAP - s
    # give them the largest leftover possible so they lose to any used bin
    scores[len(fitting):] = -(r_new * 1000 + CAP) - 1e9

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _caps[j] = g - s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
