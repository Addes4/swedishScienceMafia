# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with observed-size residual matching.

Each item goes where it minimises sum_g N(g)^2 (N(g) = open bins with remaining capacity g),
which is the standard proxy for expected waste. Ties and near-ties are broken by preferring
a post-placement residual r that matches a frequently observed item size (so that a future
item is likely to fill the bin exactly) and by consolidating residual classes.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are assumed to be a prefix of the bin array. Each instance runs in a
fresh process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_size_count = [0] * (CAP + 1)  # observed count of item sizes
_total_items = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _size_count, _total_items
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # update size statistics with current item
    _size_count[s] += 1
    _total_items += 1
    total = float(_total_items)

    def pop_of(r):
        # observed probability that a future item equals residual r (count of that size)
        if r <= 0:
            return 0.0
        return _size_count[r] / total

    def rank(r):
        # primary: sum-of-squares delta (smaller delta -> better)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # tiebreak tier: prefer residual that already exists (or 0)
        if r == 0 or _N[r] > 0:
            tb = 1
        else:
            tb = 0
        return (-delta, tb, pop_of(r), -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r)
        scores[k] = (key[0] * 1e9 + key[1] * 1e6 + key[2] * 1e3 + key[3])

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if r_new == 0 or _N[r_new] > 0:
        tb_new = 1
    else:
        tb_new = 0
    scores[len(fitting):] = (-delta_new * 1e9 + tb_new * 1e6 + pop_of(r_new) * 1e3 - r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
