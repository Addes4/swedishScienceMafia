# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-class tie-breaking and a light probabilistic lookahead.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken by preferring a post-placement residual r
that already occurs among open bins (or r == 0). A small histogram-based bonus favors
placements whose new residual is likely to be consumed by an upcoming item (clean closes).
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = np.ones(CAP + 1, dtype=np.float64)   # Laplace-smoothed item-size counts, idx 1..100
_hist_tot = float(CAP)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _hist, _hist_tot
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # probability mass of item sizes, for the lookahead bonus
    mass = _hist / _hist_tot  # index by size, 1..100

    def close_bonus(r):
        # estimate prob that a future item exactly closes residual r (then bin freed)
        if 1 <= r <= CAP:
            return mass[r]
        return 0.0

    def rank(r):
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        if r == 0 or _N[r] > 0:
            tb = 1
        else:
            tb = 0
        return (-delta, tb, -r, close_bonus(r))

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r)
        scores[k] = (key[0] * 1e9 + key[1] * 1e6 - key[2] * 1e3 + key[3])

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if r_new == 0 or _N[r_new] > 0:
        tb_new = 1
    else:
        tb_new = 0
    scores[len(fitting):] = (-delta_new * 1e9 + tb_new * 1e6 - r_new * 1e3 + close_bonus(r_new))

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update item-size statistics for future lookahead
    _hist[s] += 1.0
    _hist_tot += 1.0
    return scores
# EVOLVE-BLOCK-END
