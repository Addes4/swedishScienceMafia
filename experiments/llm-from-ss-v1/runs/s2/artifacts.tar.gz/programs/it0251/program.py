# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with demand-aware tie-breaking.

Primary criterion: minimise sum_g N(g)^2 via the exact delta of placing the item,
which is essentially Best-Fit for residual counts. Exact-delta ties are broken by
preferring the residual r that has been *least* frequently demanded as an item size
so far (online histogram), keeping frequently-demanded residuals available for the
future. Keeps its own record of every opened bin.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_demand = [0] * (CAP + 1)      # observed item-size histogram


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _demand
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def rank(r):
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # secondary: prefer residual rarely demanded as an item size (keep valuable residuals free)
        demand = _demand[r] if 0 < r < CAP else 0
        return (-delta, demand, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r)
        scores[k] = key[0] * 1e12 + key[1] * 1e6 + key[2]

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    demand_new = _demand[r_new] if 0 < r_new < CAP else 0
    scores[len(fitting):] = -delta_new * 1e12 + demand_new * 1e6 + (-r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    _demand[s] += 1
    return scores
# EVOLVE-BLOCK-END
