# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with largest-residual tie-breaking.

Each item goes where it minimises the change in sum_g N(g)^2, where N(g) counts open bins
with remaining capacity g (0 < g < 100). Exact-delta ties are broken by preferring the
placement that leaves the largest post-placement residual, which keeps more usable free
space available for future items.
Scoring is aligned with the provided `bins` array: each slot in `bins` gets the score of
that bin's own remaining capacity, so the returned array position k corresponds to bin k.
Each instance runs in a fresh process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    scores = np.empty(n_bins, dtype=np.float64)

    # Determine which bin indices are "real" opened bins according to our own record.
    n_open = len(_caps)

    for k in range(n_bins):
        if k < n_open:
            g = _caps[k]
        else:
            g = CAP
        if g < s:
            # This bin cannot fit the item; give it a very low score.
            scores[k] = -1e18
            continue
        r = g - s
        g_ref = g
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # Primary: minimise the change in sum of squares (delta smaller is better).
        # Secondary (tie-break): prefer larger post-placement residual r.
        scores[k] = -delta * 1e9 + r

    choice = int(np.argmax(scores))
    if choice < n_open:
        g = _caps[choice]
        _N[g] -= 1
        _caps[choice] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
