# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with true delta and smallest-positive-residual tie-break.

Each open bin contributes its remaining capacity g (0 < g < 100) as a bucket. Placing an
item into a bin with residual g and leaving residual r changes sum_g N(g)^2 by exactly
delta = (2*N(r)+1) - (2*N(g)+1), where N(r) is read before the move (r != g). We choose the
bin minimizing delta; ties are broken lexicographically to prefer r == 0 (perfect fit), then
the smallest positive r, keeping the largest usable spaces intact for future items.

The function is shown only the bins the item fits in; it keeps its own record of every opened
bin. Used bins are always a prefix of the bin array (harness opens unused bins in index order
and ties go to the first bin). Each instance runs in a fresh process, so module state starts
empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    best_key = None
    best_idx = 0

    def consider(idx, delta, r):
        nonlocal best_key, best_idx
        # tie-break: prefer r == 0, else smallest positive residual
        if r == 0:
            tb = (0, 0)
        else:
            tb = (1, r)
        key = (delta, tb)
        if best_key is None or key < best_key:
            best_key = key
            best_idx = idx

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = (2 * _N[r] + 1) - (2 * _N[g] + 1)
        consider(k, delta, r)
        scores[k] = delta + (r * 1e-6)

    r_new = CAP - s
    delta_new = (2 * _N[r_new] + 1) if r_new > 0 else 1
    for off in range(n_unused):
        consider(len(fitting) + off, delta_new, r_new)
    if n_unused > 0:
        scores[len(fitting):] = delta_new + (r_new * 1e-6)

    # Selection by the exact key, ignoring the tiny float noise in `scores`.
    choice = best_idx

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # Harness uses argmax(scores); make scores reflect our chosen bin.
    scores[:] = 0.0
    scores[choice] = 1.0
    return scores
# EVOLVE-BLOCK-END
