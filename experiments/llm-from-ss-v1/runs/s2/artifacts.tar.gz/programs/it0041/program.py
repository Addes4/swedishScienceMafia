# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with complement-residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken by preferring a post-placement residual r
that is a frequently observed item size (so a future item can fill the bin exactly), then
by preferring residuals that already occur among open bins (or r == 0).

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # running count of observed item sizes (1..CAP)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _freq
    s = int(item)
    _freq[s] += 1
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def tb(r):
        # complement bonus: residual matches a common item size -> future exact fill
        comp = _freq[r] if r > 0 else 0
        # existing residual class bonus
        exist = 1 if (r == 0 or _N[r] > 0) else 0
        return comp * 1.0 + exist * 0.5

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        scores[k] = (-delta) + min(tb(r), 0.9)

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = (-delta_new) + min(tb(r_new), 0.9)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
