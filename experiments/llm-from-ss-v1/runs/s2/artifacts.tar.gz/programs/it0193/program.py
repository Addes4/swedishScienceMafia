# EVOLVE-BLOCK-START
"""Harmonic residual-utility rule with exact-fit tie-breaking.

Each item goes where it maximises a harmonic utility of the resulting residual:
    score_for_bin = 1/(r+1)   where r = remaining capacity after placement.
This gently prefers placements leaving small residuals (tight packing) while a
tiny secondary bonus rewards exact fills (r == 0). Exact lexicographic comparison
avoids floating-point encoding problems.
The function keeps its own record of every opened bin; unused bins are treated as
residual CAP bins implicitly (opening one yields r = CAP - s).
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # Primary: harmonic utility of residual (bigger is better). Secondary: exact-fit bonus.
    primary = []
    secondary = []
    bins_for_score = []

    for j in fitting:
        g = _caps[j]
        r = g - s
        bins_for_score.append(j)
        primary.append(1.0 / (r + 1))
        secondary.append(1.0 if r == 0 else 0.0)

    if n_unused > 0:
        r_new = CAP - s
        bins_for_score.append(-1)  # sentinel: open a new bin
        primary.append(1.0 / (r_new + 1))
        secondary.append(1.0 if r_new == 0 else 0.0)

    best_idx = 0
    best_p = primary[0]
    best_s = secondary[0]
    for i in range(1, len(primary)):
        p = primary[i]
        sc = secondary[i]
        if p > best_p or (p == best_p and sc > best_s):
            best_p = p
            best_s = sc
            best_idx = i

    # Fill scores array (highest score -> chosen; use small epsilon encoded safely).
    # We construct scores so argmax reproduces best_idx.
    maxp = max(primary)
    for k in range(n_bins):
        scores[k] = -1.0
    for i, j in enumerate(bins_for_score):
        if j >= 0:
            scores[j] = primary[i] + 1e-6 * secondary[i]
    # ensure the chosen one has the strictly-highest value
    for i, j in enumerate(bins_for_score):
        if j >= 0:
            val = primary[i] + 1e-6 * secondary[i]
            if i == best_idx:
                scores[j] = maxp + 1.0
            else:
                scores[j] = val
        # sentinel (open new bin) handled by ensuring scores of unused > current best if chosen

    if bins_for_score[best_idx] == -1:
        # opening a new bin is chosen: give every unused bin a high score
        for k in range(n_bins):
            if k not in set(j for j in fitting):
                scores[k] = maxp + 2.0

    choice = int(np.argmax(scores))
    if choice < n_bins and choice in fitting:
        g = _caps[choice]
        _caps[choice] = g - s
    else:
        # choose an unused bin: append new bin (tie-break naturally opens first unused)
        # ensure we don't reuse a fitting bin
        if choice not in fitting:
            _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
