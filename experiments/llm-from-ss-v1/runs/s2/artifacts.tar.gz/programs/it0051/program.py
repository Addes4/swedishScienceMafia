# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-class tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken by preferring a post-placement residual r
that already occurs among open bins (or r == 0), which consolidates residual classes. Final
tie-break prefers the tighter fit (smaller residual).

Scores are built by exact integer tuple comparison (no float scaling), so no precision is
lost as the residual-class counts grow.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)

    # Build a comparison key per candidate. Higher key is better; ties -> first bin.
    # key tuple compared as: (-delta, tb, r_neg)
    #   delta : sum-of-squares change (want it small / negative)
    #   tb    : 1 if residual r == 0 or N[r] > 0 (class already exists), else 0
    #   r_neg : -r (prefer smaller residual = tighter fit)
    best_key = None
    best_pos = 0

    for pos, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        tb = 1 if (r == 0 or _N[r] > 0) else 0
        key = (-delta, tb, -r)
        if best_key is None or key > best_key:
            best_key = key
            best_pos = pos

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    tb_new = 1 if (r_new == 0 or _N[r_new] > 0) else 0
    key_new = (-delta_new, tb_new, -r_new)

    if n_unused > 0:
        if best_key is None or key_new > best_key:
            best_key = key_new
            best_pos = len(fitting)   # position among unused bins (first unused = lowest index)

    # Materialise scores so the harness picks the same bin.
    scores = np.empty(n_bins, dtype=np.float64)
    # Encode the chosen comparison as a simple one-hot so argmax picks best_pos.
    scores[:] = 0.0
    scores[best_pos] = 1.0

    # Update internal state according to the actual choice.
    if best_pos < len(fitting):
        j = fitting[best_pos]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    return scores
# EVOLVE-BLOCK-END

