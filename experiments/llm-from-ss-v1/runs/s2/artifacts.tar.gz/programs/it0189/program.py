# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with perfect-fit / exact-pair tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Ties in the sum-of-squares delta are broken by preferring the
placement that leaves the largest post-placement residual, which keeps more usable free
space available for future items. In addition, a small bonus is applied when a placement
closes a bin exactly (residual 0) or creates a residual equal to the incoming item size
(an exact pair that a later item of the same size can fill perfectly), since such moves
tend to reduce the total number of open bins.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_EPS = 1e-3                    # tiny relative bonus for a good structural move


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        base = -delta * 1e9 + r
        # structural bonus: closing a bin, or creating an exact-pair residual
        if r == 0 or r == s:
            base += 1e6
        scores[k] = base

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    base_new = -delta_new * 1e9 + r_new
    if r_new == s:
        base_new += 1e6
    scores[len(fitting):] = base_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
