# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with self-consistent-residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring a placement whose
resulting residual r equals the item size s (a "self-consistent" residual that tends to
enable future exact fits), then by the largest residual.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)

    # key = (neg_delta, self_consistent, residual)
    neg_deltas = np.empty(n_bins, dtype=np.int64)
    selfc = np.zeros(n_bins, dtype=np.int64)
    resid = np.empty(n_bins, dtype=np.int64)

    def delta_of(g_ref, r):
        if r > 0:
            return -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        return -2 * _N[g_ref] + 1

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        neg_deltas[k] = -delta_of(g_ref, r)
        selfc[k] = 1 if r == s else 0
        resid[k] = r

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    neg_deltas[len(fitting):] = -delta_new
    selfc[len(fitting):] = 1 if r_new == s else 0
    resid[len(fitting):] = r_new

    # lexicographic argmax: neg_delta, then self_consistent, then residual
    best = -1
    best_key = None
    for i in range(n_bins):
        key = (int(neg_deltas[i]), int(selfc[i]), int(resid[i]))
        if best_key is None or key > best_key:
            best_key = key
            best = i

    choice = best
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    scores = (neg_deltas.astype(np.float64) * 1e6
              + selfc.astype(np.float64) * 1e3
              + resid.astype(np.float64))
    return scores
# EVOLVE-BLOCK-END
