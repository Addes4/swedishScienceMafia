# EVOLVE-BLOCK-START
"""Decayed sum-of-squares rule with residual-class tie-breaking.

Each item goes where it minimises a *current* sum_g N(g)^2, where N(g) counts open bins
with remaining capacity g. Older bin states are forgotten via exponential decay, so the
rule keeps balancing residual classes while adapting to the current mix of open bins.
Exact ties break by preferring a post-placement residual that already occurs (or r == 0).
The function is shown only the bins the item fits in, so it records every opened bin.
Used bins are always a prefix of the bin array. State is module-level and starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0.0] * (CAP + 1)         # decayed N[g]: open bins with remaining capacity g, 0<g<CAP
_DECAY = 0.999                 # per-call decay so old classes fade slowly


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)

    # decay all class counts once per arriving item
    for g in range(1, CAP):
        _N[g] *= _DECAY

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        # sum-of-squares delta: leaving g_ref adds -N[g_ref] (loses), leaving r adds +N[r]
        delta = 2.0 * _N[g_ref] - 1.0 if False else (-2.0 * _N[g_ref] + 1.0)
        if r > 0:
            delta = delta + (2.0 * _N[r] + 1.0)
        tb = 1 if (r == 0 or _N[r] > 0.5) else 0
        scores[k] = -(delta) * 1e9 + tb * 1e6 - r

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2.0 * _N[r_new] + 1.0
    else:
        delta_new = 0.0
    tb_new = 1 if (r_new == 0 or _N[r_new] > 0.5) else 0
    scores[len(fitting):] = -delta_new * 1e9 + tb_new * 1e6 - r_new

    choice = int(np.argmax(scores))          # harness choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1.0
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1.0
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1.0
    return scores
# EVOLVE-BLOCK-END
