# EVOLVE-BLOCK-START
"""Smoothed sum-of-squares bin-choice rule.

Items go where they minimise the increase in a convex potential over open bins'
remaining capacities, using a Gaussian-smoothed occupancy so that near-equal
residuals are also discouraged from stacking up. This keeps the load-balancing
behaviour of the exact sum-of-squares rule but is less brittle to integer
granularity. Exact ties are broken toward the larger post-placement residual.
Uses the bins array only for the number of unused bins; tracks opened bins itself.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Gaussian smoothing kernel over residual capacity
_SIGMA = 2.0
_KSIZE = 3
_OFFS = np.arange(-_KSIZE, _KSIZE + 1, dtype=np.float64)
_KERN = np.exp(-0.5 * (_OFFS / _SIGMA) ** 2)
# potential derivative weight: sum over g of K(g-r) * 2 * N(g)
# We use a precomputed weight table for the smoothed count around each residual r.


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def smoothed(r):
        # smoothed occupancy density near residual r
        if r <= 0:
            return 0.0
        total = 0.0
        for o in range(-_KSIZE, _KSIZE + 1):
            g = r + o
            if 1 <= g <= CAP:
                total += _KERN[o + _KSIZE] * _N[g]
        return total

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        # placing here moves a bin from gap g_ref to gap r.
        # Delta of sum_g (smoothed_count(g))^2 ~ uses smoothed occupancy as slope proxy.
        old = smoothed(g_ref)
        new = smoothed(r)
        # approximate delta of convex potential: (new^2 - old^2) proxy with counts
        delta = (2 * new + _KERN[_KSIZE]) - old
        scores[k] = -delta * 1e6 + r

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * smoothed(r_new) + _KERN[_KSIZE]
    else:
        delta_new = 0.0
    scores[len(fitting):] = -delta_new * 1e6 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
