# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a size-frequency-informed tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). This is equivalent to Best-Fit but is expressed so that exact ties
in the delta can be broken by a secondary criterion.

Ties are broken by preferring the residual r that most often equals a recently seen item size:
a bin left with residual r is most useful if future items frequently have exactly size r (then
they fill it precisely, wasting no space). We keep an exponentially-decayed histogram of item
sizes to gauge this without tuning to individual instances.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_demand = [0.0] * (CAP + 1)    # decayed histogram of observed item sizes


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _demand
    s = int(item)
    n_bins = len(bins)

    # decay and record this item's size
    for g in range(1, CAP + 1):
        _demand[g] *= 0.99
    _demand[s] += 1.0

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def delta_of(r):
        # sum-of-squares change from moving a bin from capacity g_ref=s+r to residual r
        if r > 0:
            return 2 * _N[r] + 1
        return 0

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        n_before = _N[g_ref]
        # delta = (+ new count of r) - (- removed from g_ref)
        if r > 0:
            delta = -2 * n_before + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * n_before + 1
        key = (-delta, _demand[r] if r > 0 else 0.0, r)
        scores[k] = key[0] * 1e9 + key[1] * 1e3 + key[2]

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -delta_new * 1e9 + (_demand[r_new] if r_new > 0 else 0.0) * 1e3 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
