# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with recency-weighted residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the placement that
leaves a post-placement residual r matching a recently observed item size, since items are
i.i.d. so recurring sizes create frequent exact fits; otherwise we prefer the largest
residual, which keeps more usable free space available for future items.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_recency = [0] * (CAP + 1)     # exponentially decayed count of recent item sizes


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _recency
    s = int(item)
    n_bins = len(bins)

    # decay recency statistics, then record this item
    for g in range(1, CAP + 1):
        _recency[g] *= 31
        _recency[g] //= 32
    _recency[s] += 1

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)

    # exact integer sum-of-squares deltas
    deltas = []
    residuals = []
    for j in fitting:
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        deltas.append((delta, r))

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    deltas.append((delta_new, r_new))   # index len(fitting): opening a new bin

    best_delta = min(d for d, _ in deltas)

    # secondary: recency-weighted r match, then largest r
    def sec(r):
        return (_recency[r] if r > 0 else 0, r)

    best_sec = None
    choice = 0
    for k, (d, r) in enumerate(deltas):
        if d != best_delta:
            continue
        sk = sec(r)
        if best_sec is None or sk > best_sec:
            best_sec = sk
            choice = k

    scores = np.zeros(n_bins, dtype=np.float64)
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
        scores[choice] = 1.0
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
        # unused bins start at index len(fitting); pick the first one
        scores[len(fitting)] = 1.0
    return scores
# EVOLVE-BLOCK-END
