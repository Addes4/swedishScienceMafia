# EVOLVE-BLOCK-START
"""Best-fit rule with a "refillable residual" tie-break.

Each item goes to the fitting bin that leaves the smallest non-negative residual (best fit).
Among equal residuals, prefer the residual that matches an item size seen more often in the
past (higher chance to be exactly filled later), then the larger residual.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                      # remaining capacity of every opened bin, in bin-index order
_seen = [0] * (CAP + 1)         # _seen[s]: how often size s has arrived


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _seen
    s = int(item)
    _seen[s] += 1
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        r = _caps[j] - s
        # best fit: smaller r is better -> negate; tie-break: higher _seen[r] better, larger r better
        scores[k] = -r * 1e6 + _seen[r] * 1e3 + r

    r_new = CAP - s
    # opening a new bin: residual r_new; treat as fallback with worst priority among new-bin options
    scores[len(fitting):] = -r_new * 1e6 + _seen[r_new] * 1e3 + r_new - 1e9

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _caps[j] = g - s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
