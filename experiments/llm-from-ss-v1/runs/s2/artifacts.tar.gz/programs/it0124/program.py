# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with largest-residual tie-breaking, computed from the bins array.

For each fitting bin with remaining capacity g and residual r = g - item, the change in
sum_g N(g)^2 is -2*N(g) + 1 + (2*N(r) + 1 if r>0 else 0), where N(g) counts open bins
(both fitting original capacities and already-updated residuals) with remaining capacity g,
0 < g < CAP. Counts are recomputed each call from the harness's bins array, so no fragile
module state is kept. Exact-delta ties are broken by preferring the largest residual, which
leaves more usable free space for future items. Unused bins have capacity CAP.
"""
import numpy as np

CAP = 100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    s = int(item)
    caps = np.asarray(bins, dtype=np.int64)
    n = caps.shape[0]
    r_all = caps - s
    fits = r_all >= 0

    # Residual-class counts over opened bins (0 < g < CAP). Unused bins (g == CAP) excluded.
    N = np.zeros(CAP + 1, dtype=np.int64)
    opened = caps[(caps < CAP) & (caps > 0)]
    for g in opened:
        N[g] += 1

    scores = np.empty(n, dtype=np.float64)
    for j in range(n):
        if not fits[j]:
            scores[j] = -1e18
            continue
        g_ref = int(caps[j])
        r = int(r_all[j])
        delta = -2 * N[g_ref] + 1
        if r > 0:
            delta += 2 * N[r] + 1
        scores[j] = -delta * 1e9 + r
    return scores
# EVOLVE-BLOCK-END
