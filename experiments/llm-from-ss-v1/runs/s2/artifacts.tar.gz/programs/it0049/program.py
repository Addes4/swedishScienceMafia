# EVOLVE-BLOCK-START
"""Best-Fit with residual-class consolidation.

The item goes into the fitting bin whose post-placement residual r = g - s is most likely to be
useful: first we prefer placements where r already occurs as an open residual class (so equal
residuals stack up and can be closed by a matching future item), and among those we prefer the
tightest fit (smallest positive r). Fresh unused bins get a penalty so an open bin is preferred.
The function is shown only the bins the item fits in, so it keeps its own record of every opened
bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh process, so
module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    KEY = 1000.0

    def key(r):
        # tier 1: does residual r already exist as an open class (or exactly close the bin)?
        if r == 0:
            tb = 2
        elif _N[r] > 0:
            tb = 1
        else:
            tb = 0
        # tier 2: prefer larger existing class (consolidation), then tighter fit (smaller r)
        return tb * KEY - r, tb

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        kb, _ = key(r)
        # scale so tier1 dominates tier2; keep within float range
        scores[k] = kb

    r_new = CAP - s
    kb, _ = key(r_new)
    # penalty for fresh bin: subtract a small amount that is < spacing between open-bin scores
    scores[len(fitting):] = kb - 0.5

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

