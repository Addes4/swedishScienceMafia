# EVOLVE-BLOCK-START
"""Online sum-of-squares (Best-Fit style) bin-choice rule.

The item is placed where it minimises the change in sum_g N(g)^2, where N(g) counts open
bins with remaining capacity g (0 < g < CAP). Ties are broken by preferring the placement
that leaves the largest post-placement residual, keeping more usable free space.
The harness shows only the bins the item fits in; unused bins have remaining capacity 100.
Bins are given in fixed index order, so mapping the fitting positions back to bin indices
is done via the capacity values themselves. The rule keeps an internal histogram for the
SS delta but recomputes each bin's residual from the provided `bins` array so the ranking
always matches the true harness state.
"""
import numpy as np

CAP = 100
_N = [0] * (CAP + 1)           # N[g]: observed open bins with remaining capacity g (0<g<CAP)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _N
    s = int(item)
    n_bins = len(bins)
    scores = np.empty(n_bins, dtype=np.float64)

    # ranking keys: primary minimize delta (larger key = better), secondary maximize residual r
    for k in range(n_bins):
        g = int(bins[k])
        r = g - s
        if r > 0:
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g] + 1
        scores[k] = -delta * 1e9 + r

    choice = int(np.argmax(scores))
    g = int(bins[choice])
    # update internal histogram to reflect the chosen placement
    if 0 < g < CAP:
        _N[g] -= 1
    r = g - s
    if 0 < r < CAP:
        _N[r] += 1
    return scores
# EVOLVE-BLOCK-END
