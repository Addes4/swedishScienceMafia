# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with dead-space-aware tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Ties are broken by preferring placements that leave a residual
which can actually be refilled later: we keep a running histogram of seen item sizes and
favour residuals matching common sizes, while avoiding tiny "dead" residuals below the
smallest item size observed. The function keeps its own record of every opened bin because
it is shown only the bins the item fits in; used bins are a prefix of the bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_size_hist = [0] * (CAP + 1)   # counts of item sizes seen so far
_min_size = CAP                # smallest item size seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _size_hist, _min_size
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    total_seen = sum(_size_hist) + 1  # include current item

    def tie_score(r):
        # Prefer residuals that are refillable: matching a common item size is good,
        # being below the smallest item seen (dead space) is bad.
        if r <= 0:
            return 0.0
        if r < _min_size:
            return -1.0 - (10.0 / r)
        return _size_hist[r] / total_seen

    def rank(r):
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        return (-delta, tie_score(r))

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        td, ts = rank(r)
        scores[k] = td * 1e6 + ts

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -delta_new * 1e6 + tie_score(r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    _size_hist[s] += 1
    if s < _min_size:
        _min_size = s

    return scores
# EVOLVE-BLOCK-END

