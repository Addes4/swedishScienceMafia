# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with soft consolidation correction.

Primary objective: place each item where the sum of squares of open-bin residual counts
changes least (sum_g N(g)^2). This alone is a strong online rule, but exact ties are common.
Rather than overriding the primary with an arbitrary tie-break, we add a tiny correction
term proportional to how "consolidatable" the resulting residual is: a residual r that has
many existing bins (N[r] large) is a residual already favoured for future matching, so
prefer it slightly. The correction is small enough to never override a genuine difference in
the exact delta, but large enough to settle ties consistently toward tighter packing.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # Secondary: prefer placements whose residual has a high existing count (consolidation),
    # with a tiny penalty when residual equals 0 (closing a bin is good but should not
    # dominate the primary objective). Kept well below 1 so it only settles true ties.
    EPS = 1e-3 * 0.0  # reserved; see below

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # secondary consolidation bonus: prefer larger N[r] (more bins at that residual)
        sec = _N[r] if r > 0 else 0
        scores[k] = -delta + sec * EPS

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
        sec_new = _N[r_new]
    else:
        delta_new = 0
        sec_new = 0
    scores[len(fitting):] = -delta_new + sec_new * EPS

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
