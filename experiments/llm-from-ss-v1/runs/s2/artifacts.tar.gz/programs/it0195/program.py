# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with perfect-fit / best-fit tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken lexicographically: first prefer a
placement that closes the bin (residual 0), then prefer the smallest sufficient residual
(tighter best-fit packing). Opening a new bin is strongly discouraged when a fitting
placement of equal delta exists.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def key_for(r):
        # primary: negated sum-of-squares delta (higher is better)
        if r > 0:
            delta = -2 * _N[_caps[j_ref]] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[_caps[j_ref]] + 1
        # secondary: prefer residual 0 (perfect fill), else smallest residual
        sec = -r
        return delta, sec

    def sec_rank(r):
        # lower tuple value is better; make a big primary, then a small secondary
        if r == 0:
            return 0        # perfect fill best
        return 1 + r        # smaller residual better

    best_val = None
    choice = 0
    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        val = (-delta) * 1000000 - sec_rank(r)
        scores[k] = val
        if best_val is None or val > best_val:
            best_val = val
            choice = k

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    val_new = (-delta_new) * 1000000 - sec_rank(r_new) - 1  # slight penalty for opening
    if n_unused > 0:
        for k in range(len(fitting), n_bins):
            scores[k] = val_new

    if best_val is not None and best_val >= val_new:
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    else:
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    return scores
# EVOLVE-BLOCK-END
