# EVOLVE-BLOCK-START
"""Sum-of-Squares bin-choice rule.

Each item goes to the bin that minimises the sum over open bins of N(g)^2, where N(g)
counts bins with remaining capacity g. Writing g for a bin's current residual and r for
its residual after placing the item, the change in this objective is
    delta(g -> r) = 1 - 2*N[g] + 2*N[r]      (r > 0, using the "leave no empty bin" convention)
and for opening a fresh bin (g = CAP, r = CAP - s)
    delta_new     = 1 + 2*N[r].
Smaller delta is better, so we pick the largest  -delta, i.e. we maximise
    -1 + 2*N[g] - 2*N[r].
We read capacity classes directly off the `bins` array the harness hands us: fitting bins
have g = bins[j] (0 < g <= CAP) and, since the harness always opens unused bins in index
order, the bins with g == CAP are the still-unused ones.
"""
import numpy as np

CAP = 100
_N = [0] * (CAP + 1)           # N[g]: bins with remaining capacity g, 1 <= g <= CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _N
    s = int(item)
    n_bins = len(bins)

    # Score each fitting bin by -(delta) so that a higher score is better.
    scores = np.empty(n_bins, dtype=np.float64)
    for j in range(n_bins):
        g = int(bins[j])
        r = g - s
        if r > 0:
            scores[j] = -(-2 * _N[g] + 2 * _N[r] + 1)
        else:
            scores[j] = -(-2 * _N[g] + 1)

    choice = int(np.argmax(scores))

    # Update our running histogram to reflect the placement.
    g = int(bins[choice])
    r = g - s
    _N[g] -= 1
    if r > 0:
        _N[r] += 1

    return scores
# EVOLVE-BLOCK-END
