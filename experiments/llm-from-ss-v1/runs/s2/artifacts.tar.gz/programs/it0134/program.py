# EVOLVE-BLOCK-START
"""Best-fit with a minimum-useful-residual guard.

Each item goes to the fitting bin that leaves the smallest residual r = g - s, which is the
classic Best-Fit rule and packs tightly. The single twist: a residual r with 0 < r < min_seen
is treated as wasted space (too small for any item seen so far), so such placements are
demoted below placements that leave r == 0 or r >= min_seen. This keeps Best-Fit's strong
packing while avoiding creating tiny unusable fragments, which is exactly the failure mode
Best-Fit suffers on Weibull-shaped item sizes.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_min_seen = CAP                # smallest item size observed so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _min_seen
    s = int(item)
    if s < _min_seen:
        _min_seen = s
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    m = _min_seen

    for k, j in enumerate(fitting):
        r = _caps[j] - s
        if r == 0 or r >= m:
            # useful residual: primary = smallest residual (best-fit), secondary = larger bin
            scores[k] = 1e12 - r
        else:
            # wasted tiny fragment: demote hard, order by smaller residual
            scores[k] = -r

    r_new = CAP - s
    if r_new == 0 or r_new >= m:
        scores[len(fitting):] = 1e12 - r_new
    else:
        scores[len(fitting):] = -r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _caps[j] = g - s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
