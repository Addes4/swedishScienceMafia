# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with distribution-aware residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the placement that
leaves a residual which is likely to be fillable later, estimated from a decaying histogram
of recently seen item sizes. This keeps leftover gaps usable while retaining the strong
worst-fit-like consolidation of the sum-of-squares rule.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = np.zeros(CAP + 1)      # decaying histogram of recently seen item sizes
_DECAY = 0.99


def _fill_score(r):
    """Estimate how fillable a residual r is: expected number of future items that fit/use it."""
    if r <= 0:
        return 0.0
    total = _hist.sum()
    if total <= 0.0:
        return 0.0
    # probability mass of items with size <= r (a later item can use this gap)
    fit_mass = _hist[:r + 1].sum() / total
    # prefer residuals that can still receive a sizable item, weight by usable fraction
    return fit_mass


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # update histogram with this item (for future tie-breaks)
    _hist *= _DECAY
    _hist[s] += 1.0

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        tie = _fill_score(r)
        scores[k] = -delta * 1e9 + tie

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -delta_new * 1e9 + _fill_score(r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
