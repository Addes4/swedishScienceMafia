# EVOLVE-BLOCK-START
"""Exact sum-of-squares bin choice with clean tie-breaking.

Each item is placed where it minimises the exact change in sum_g N(g)^2, where N(g) counts
open bins with remaining capacity g (0 < g < 100). Exact ties are broken by preferring the
placement that leaves the smallest positive residual (best-fit), which keeps large free
spaces intact for later items.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # Primary key: exact delta of sum N(g)^2 (lower is better).
    # Place into fitting bin j with residual r = g_ref - s:
    #   N(g_ref) decreases by 1, N(r) increases by 1 (if r>0)
    #   delta = (N(g_ref)-1)^2 + (N(r)+1)^2 - N(g_ref)^2 - N(r)^2
    #         = -2*N(g_ref)+1 + 2*N(r)+1   (r>0)
    #         = -2*N(g_ref)+1              (r==0)
    # Unused bin: N(s') increases by 1 for r_new = CAP - s
    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        delta = -2 * _N[g_ref] + 1
        if r > 0:
            delta += 2 * _N[r] + 1
        # Secondary key: smaller residual preferred (best-fit); encode below delta.
        scores[k] = delta * 1000.0 + r

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = delta_new * 1000.0 + r_new

    choice = int(np.argmin(scores[:len(fitting)]) ) if len(fitting) else -1
    best_fit = scores[choice] if choice >= 0 else None
    best_new = scores[len(fitting)] if n_unused > 0 else None
    if best_fit is not None and (best_new is None or best_fit <= best_new):
        target = choice
    else:
        target = len(fitting)  # pick an unused bin (first one)

    if target < len(fitting):
        j = fitting[target]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

