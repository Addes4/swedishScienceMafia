# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with distribution-aware tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact delta ties are broken by preferring the post-placement
residual r that is most likely to be exactly consumable by a future item, estimated from the
observed item-size histogram (a residual r is "closable" with weight = frequency of items of
size r, plus a fraction of paired sizes). This consolidates bins that can actually be closed
without changing the proven primary rule. The function is shown only the bins the item fits
in, so it keeps its own record of every opened bin. Used bins are always a prefix of the bin
array (harness opens unused bins in index order and ties go to the first bin). Each instance
runs in a fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0.0] * (CAP + 1)      # empirical item-size frequency, size 1..CAP
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _freq, _total
    s = int(item)

    # update empirical item-size histogram
    _freq[s] += 1.0
    _total += 1.0

    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def closability(r):
        # how likely residual r can be exactly consumed by future items
        if r <= 0:
            return 0.0
        c = _freq[r]
        # add partial credit for two-item closures (u + v == r), scaled
        half = r // 2
        for u in range(1, half + 1):
            v = r - u
            if 1 <= v <= CAP:
                c += 0.25 * _freq[u] * _freq[v] / (_total if _total > 0 else 1.0)
        return c

    _clos_cache = {}

    def rank(r):
        # primary: sum-of-squares delta (smaller delta -> better)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        if r not in _clos_cache:
            _clos_cache[r] = closability(r)
        # tiebreak tiers: (1) exact-delta, (2) higher closability, (3) exact existing residual
        if r == 0 or _N[r] > 0:
            tb = 1
        else:
            tb = 0
        return (-delta, tb, _clos_cache[r], -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r)
        scores[k] = (key[0] * 1e9 + key[1] * 1e6 + key[2] - key[3] * 1e-6)

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if r_new == 0 or _N[r_new] > 0:
        tb_new = 1
    else:
        tb_new = 0
    if r_new not in _clos_cache:
        _clos_cache[r_new] = closability(r_new)
    scores[len(fitting):] = (-delta_new * 1e9 + tb_new * 1e6
                             + _clos_cache[r_new] - r_new * 1e-6)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

