# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a distribution-adaptive tie-break.

Primary objective: place the item so as to minimise the exact change in sum_g N(g)^2,
where N(g) counts open bins with remaining capacity g (0 < g < 100). This is the classic
"sum of squares" / conservation rule that keeps bin residuals spread out and usable.

Exact-delta ties are broken with an online estimate of the item distribution: we keep a
running histogram of item sizes seen so far and prefer the placement whose post-placement
residual best matches (is the smallest residual >= ) a size that occurs frequently,
i.e. a residual that is likely to be filled exactly by a future item.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0] * (CAP + 1)        # running histogram of observed item sizes
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist, _seen
    s = int(item)

    # update distribution estimate
    _hist[s] += 1
    _seen += 1

    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # popularity of a residual value r as a future exact fill = mass of item sizes near r
    def fill_score(r):
        if r <= 0:
            return 0.0
        # weight by how often a size <= r but close to r was seen (perfect-fit likelihood)
        lo = r - 10 if r - 10 > 0 else 0
        tot = 0
        for v in range(lo, r + 1):
            tot += _hist[v] * (v + 1)
        return tot / (_seen + 1.0)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # primary: exact delta (lower is better -> negate). secondary: fill-score (higher better).
        scores[k] = -delta * 1e6 + fill_score(r)

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -delta_new * 1e6 + fill_score(r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
