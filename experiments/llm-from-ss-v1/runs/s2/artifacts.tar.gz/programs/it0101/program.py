# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a frequency-aware residual tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring a post-placement
residual that matches the most common item size seen so far, which keeps bins available for
likely future items.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                       # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)             # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)          # observed item-size frequency
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _freq, _seen
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # update frequency statistics (before scoring this item)
    _freq[s] += 1
    _seen += 1

    # most common item size so far (a cheap "likely next residual" target)
    target = 0
    best_c = -1
    for v in range(1, CAP + 1):
        c = _freq[v]
        if c > best_c:
            best_c = c
            target = v

    def delta_for(r):
        # change in sum_g N(g)^2 when moving a bin from g_ref to r
        return 0  # replaced below

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = (-2 * _N[g_ref] + 1) + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # tie-break: prefer residual equal to the most common item size, then larger residual
        match = 1 if r == target and r > 0 else 0
        scores[k] = delta * 1e9 - match * 1e6 - r

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    match_new = 1 if r_new == target and r_new > 0 else 0
    scores[len(fitting):] = delta_new * 1e9 - match_new * 1e6 - r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
