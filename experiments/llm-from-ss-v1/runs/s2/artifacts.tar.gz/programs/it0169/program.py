# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact integer lexicographic scoring.

Each item goes where it minimises the change in sum_g N(g)^2, where N(g) counts open bins
with remaining capacity g (0 < g < 100). The unused-bin option is folded into the same
objective, and exact ties are broken by preferring the placement with the largest residual
(keeping more free space usable) with a small extra bias toward reusing existing bins.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)

    # Store the exact integer primary key (delta) plus a secondary residual key.
    # Encoding: key = delta * 101 + residual, where residual in [0, 100].
    # Small delta is best -> we negate to use argmax.
    keys = [0] * n_bins

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -(2 * _N[g_ref] + 1) + (2 * _N[r] + 1)
        else:
            delta = -(2 * _N[g_ref] + 1)
        keys[k] = -delta * 101 + r  # smaller delta better; larger residual better

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    # Reuse bias: subtract 1 so that on exact equality an existing bin is preferred.
    keys[len(fitting):] = [-delta_new * 101 + r_new - 1] * n_unused

    scores = np.array(keys, dtype=np.int64)
    choice = int(np.argmax(scores))

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
