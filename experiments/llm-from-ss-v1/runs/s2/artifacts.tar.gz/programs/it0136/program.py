# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact integer keys and a residual-usefulness tie-break.

Each item is placed to minimise the change in sum_g N(g)^2, where N(g) counts open bins with
remaining capacity g (0 < g < 100). This "harmonic"-style objective keeps the distribution of
free capacities balanced and avoids fragmentation.

Ties in the primary objective are broken exactly using integer keys rather than the fragile
1e9-scaled float encoding:
   primary  = -delta          (higher is better: smaller sum-of-squares increase)
   secondary= r               (prefer larger post-placement residual)
   tertiary = -g_ref          (prefer fuller source bin, i.e. tighter fit)

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (the harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    n_open = len(_caps)

    scores = np.empty(n_bins, dtype=np.float64)

    # --- score the opened bins that fit ---
    n_fit = 0
    for j in range(n_open):
        g = _caps[j]
        if g < s:
            continue
        r = g - s
        # exact delta of sum N(g)^2 for this placement
        delta = -2 * _N[g] + 1
        if r > 0:
            delta += 2 * _N[r] + 1
        # primary: minimise delta -> maximise -delta ; then larger r ; then tighter fit (-g)
        key = (-delta) * 1_000_000 + r * 1000 - g
        scores[n_fit] = key
        n_fit += 1

    # --- score the unused (empty) bins ---
    r_new = CAP - s
    delta_new = (2 * _N[r_new] + 1) if r_new > 0 else 0
    key_new = (-delta_new) * 1_000_000 + r_new * 1000 - CAP
    scores[n_fit:] = key_new

    choice = int(np.argmax(scores))
    # Recover which opened bin corresponds to `choice` (walk again, cheap)
    if choice < n_fit:
        seen = 0
        for j in range(n_open):
            g = _caps[j]
            if g < s:
                continue
            if seen == choice:
                r = g - s
                _N[g] -= 1
                _caps[j] = r
                if r > 0:
                    _N[r] += 1
                break
            seen += 1
    elif n_bins - n_open > 0:
        _caps.append(r_new)
        if r_new > 0:
            _N[r_new] += 1
    return scores
# EVOLVE-BLOCK-END
