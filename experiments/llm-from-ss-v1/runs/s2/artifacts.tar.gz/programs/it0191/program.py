# EVOLVE-BLOCK-START
"""Sum-of-Squares rule over the full residual histogram (including unused bins).

Objective: minimise sum_g N(g)^2 where N(g) counts bins (open AND unused) whose remaining
capacity is g, for 0 <= g <= 100. Since unused bins all have residual CAP=100, they act as
a shared bucket. Placing an item of size s into a bin with residual g_ref moves that bin's
residual from g_ref to r = g_ref - s, changing the objective by:
    (2*N[r] + 1) - (2*N[g_ref] - 1)
(an opened bin leaves its old bucket and enters the new one; an unused bin leaves the CAP
bucket and enters bucket r as an open bin). Ties are broken by preferring the placement that
leaves the largest post-placement residual, which keeps more usable free space available.

The function is shown only the bins the item fits in, so it maintains its own record of
every opened bin. Used bins are always a prefix of the bin array (harness opens unused bins
in index order and ties go to the first bin). Module-level state starts empty per instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: bins (open + unused) with remaining capacity g


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_opened = len(_caps)
    n_unused = n_bins - n_opened
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        # change in sum N(g)^2:
        #   leave bucket g_ref (open bin): - (2*N[g_ref] - 1)
        #   enter bucket r (open bin):    + (2*N[r] + 1)
        delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        scores[k] = -delta * 1e9 + r

    if n_unused > 0:
        r_new = CAP - s
        # leave CAP bucket (unused -> open): - (2*N[CAP] - 1)
        # enter bucket r_new (open bin):     + (2*N[r_new] + 1)   [r_new > 0 since s < CAP]
        delta_new = -2 * _N[CAP] + 1 + (2 * _N[r_new] + 1) if r_new > 0 else -2 * _N[CAP] + 1
        scores[n_opened:] = -delta_new * 1e9 + r_new

    choice = int(np.argmax(scores))
    if choice < n_opened:
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        _N[g - s] += 1
    else:
        _N[CAP] -= 1
        _caps.append(CAP - s)
        _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
