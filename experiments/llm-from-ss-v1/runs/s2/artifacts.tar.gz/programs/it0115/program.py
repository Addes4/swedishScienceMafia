# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-concentration tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the placement whose
post-placement residual already has the most open bins (concentrating free space into
reusable slots), then the largest residual. The function is shown only the bins the item
fits in, so it keeps its own record of every opened bin. Used bins are always a prefix of
the bin array. Each instance runs in a fresh process, so module state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

SCALE = 1 << 20                # primary key scale; secondary must stay well below this


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def rank(r):
        # primary: exact sum-of-squares delta (minimise) -> negated delta
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        primary = -delta
        # secondary: concentration of the target residual, then larger residual
        conc = _N[r] if r > 0 else -1
        return primary * SCALE + (conc * (CAP + 1) + r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        scores[k] = rank(r)

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    primary_new = -delta_new
    conc_new = _N[r_new] if r_new > 0 else -1
    scores[len(fitting):] = primary_new * SCALE + (conc_new * (CAP + 1) + r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
