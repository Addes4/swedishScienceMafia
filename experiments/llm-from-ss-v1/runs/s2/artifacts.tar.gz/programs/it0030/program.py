# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-class consolidation bonus.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among near-tied placements we add a small continuous bonus for
residual classes that already have many open bins (or r == 0), which consolidates small
residual classes and reduces fragmentation. The function keeps its own record of every
opened bin; used bins are a prefix of the bin array. Each instance runs in a fresh process,
so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    scores = np.empty(n_bins, dtype=np.float64)

    # weight of the consolidation bonus relative to the primary delta of 1
    BONUS = 0.35

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
            bonus = (1 if r == 0 else _N[r]) * BONUS
        else:
            delta = -2 * _N[g_ref] + 1
            bonus = BONUS * 2  # exact fill is strongly good
        scores[k] = -delta + bonus

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
        bonus_new = _N[r_new] * BONUS
    else:
        delta_new = 0
        bonus_new = BONUS * 2
    scores[len(fitting):] = -delta_new + bonus_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

