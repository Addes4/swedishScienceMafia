# EVOLVE-BLOCK-START
"""Best-fit with usable-gap guard and residual consolidation tie-breaking.

Primary rule: best fit (smallest remaining capacity that still fits the item), the classic
strong online rule for short-tailed item distributions. Refinement: if best fit would leave a
positive residual smaller than the smallest item observed so far, that bin is effectively
wasted, so we prefer a bin whose residual is large enough to still hold a typical small item
(but as small as possible). Exact ties are broken by preferring a residual that already
exists among open bins (or residual 0), which consolidates residual classes.

The function keeps its own record of every opened bin because it is only shown the bins the
item fits in. Used bins form a prefix of the bin array (the harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_min_seen = CAP                # smallest item size seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _min_seen
    s = int(item)
    if s < _min_seen:
        _min_seen = s
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def key(g_ref, r):
        # primary: best fit (smaller residual preferred)
        # guard: a positive residual below _min_seen wastes the bin -> demote
        if r == 0:
            tier = 2
        elif r >= _min_seen:
            tier = 1
        else:
            tier = 0
        # consolidation: prefer residual that already exists among open bins
        if r == 0 or _N[r] > 0:
            tb = 1
        else:
            tb = 0
        # score: higher is better. tier dominates, then best-fit (smaller r), then consolidation
        return tier * 1e9 + tb * 1e6 - r

    for k, j in enumerate(fitting):
        scores[k] = key(_caps[j], _caps[j] - s)

    r_new = CAP - s
    if r_new == 0:
        tier_new = 2
    elif r_new >= _min_seen:
        tier_new = 1
    else:
        tier_new = 0
    if r_new == 0 or _N[r_new] > 0:
        tb_new = 1
    else:
        tb_new = 0
    scores[len(fitting):] = tier_new * 1e9 + tb_new * 1e6 - r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

