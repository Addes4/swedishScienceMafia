# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact lexicographic tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken by preferring a post-placement residual r
that already occurs among open bins (or r == 0), which consolidates residual classes.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)

    # Build a lexicographic key per placement: (primary delta asc, existing-class desc,
    # residual desc). We map to integer ranks so np.argmax picks the first best bin.
    keys = []
    for j in fitting:
        g_ref = _caps[j]
        r = g_ref - s
        delta = (-2 * _N[g_ref] + 1) + (2 * _N[r] + 1 if r > 0 else 0)
        tb = 1 if (r == 0 or _N[r] > 0) else 0
        keys.append((delta, -tb, -r))

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    tb_new = 1 if (r_new == 0 or _N[r_new] > 0) else 0
    keys.append((delta_new, -tb_new, -r_new))

    # choose the placement minimising this tuple; ties -> earliest index (harness rule)
    best = 0
    best_key = keys[0]
    for idx in range(1, len(keys)):
        if keys[idx] < best_key:
            best_key = keys[idx]
            best = idx

    # produce scores where max score is the chosen bin and ties resolve to earlier bins
    scores = np.empty(n_bins, dtype=np.float64)
    n_key = len(keys)
    for idx in range(n_bins):
        if idx < n_key:
            k = keys[idx]
            # higher score for "better" (smaller tuple), with strong separation
            scores[idx] = -(k[0] * 1e6) + (k[1] * 1e3) + (k[2] * 1.0) - idx * 1e-9
        else:
            scores[idx] = -1e18

    choice = best
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

