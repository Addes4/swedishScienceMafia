# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a small anti-fragmentation tie term.

Each item goes where it minimises sum_g N(g)^2 (the exact Best-Fit delta), plus a tiny
penalty -c/(r+1) on the post-placement residual r, which breaks exact ties toward leaving
larger usable residuals. The function is shown only the bins the item fits in, so it keeps
its own record of every opened bin. Unused bins have remaining capacity 100 and appear
after the opened bins; ties go to the first bin.
"""
import numpy as np

CAP = 100
EPS = 1e-6
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        # exact Best-Fit delta for placing into this bin
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # lower delta is better -> negate; small penalty favours larger residual r
        scores[k] = -delta - EPS / (r + 1)

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -delta_new - EPS / (r_new + 1)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
