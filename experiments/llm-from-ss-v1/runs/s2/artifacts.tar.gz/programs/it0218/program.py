# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-utility tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the placement that
leaves a residual r most likely to be usefully consumed by a future item, using a fixed
preference curve over residual sizes derived from the Weibull-like item distribution
(mean ~40). This tends to keep residuals that future items can fit into well.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Preference for a residual r: higher is better when sum-of-squares deltas tie.
# A residual is "useful" if it equals a likely upcoming item size (small residuals that
# match common item sizes) or is large enough to hold typical items. We approximate the
# item distribution (Weibull, mean ~40) with a discrete weight over r = 1..100.
_RW = None


def _residual_weight():
    global _RW
    if _RW is None:
        r = np.arange(0, CAP + 1, dtype=np.float64)
        # Weibull(k=~1.5, lambda=~45) shape, mean ~40, over item sizes 1..100.
        k = 1.5
        lam = 45.0
        # Approximate item pmf for size s (continuous Weibull density on integers).
        s = np.arange(1, CAP + 1, dtype=np.float64)
        dens = (k / lam) * (s / lam) ** (k - 1.0) * np.exp(-((s / lam) ** k))
        pmf = dens / dens.sum()
        pmf_full = np.zeros(CAP + 1, dtype=np.float64)
        pmf_full[1:] = pmf
        # weight(r) = expected value of placing next item into a bin with residual r:
        # probability the item fits (s <= r) plus a small bonus for exact matches.
        cdf = np.cumsum(pmf_full)
        w = cdf[r].copy()
        w[0] = 0.0
        # Bonus for residuals that exactly equal a common item size.
        w += 0.5 * pmf_full[r]
        _RW = w
    return _RW


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.int64)

    W = _residual_weight()

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # primary: minimise delta -> -delta; tie-break by residual utility weight.
        w = int(W[r] * 1000.0)
        scores[k] = -delta * 100000 + w

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    w_new = int(W[r_new] * 1000.0)
    scores[len(fitting):] = -delta_new * 100000 + w_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
