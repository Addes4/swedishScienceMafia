# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with largest-residual tie-breaking (clean integer lexicographic keys).

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken by preferring the placement that leaves the
largest post-placement residual r, keeping more usable free space for future items.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (the harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)

    n_opened = len(_caps)
    n_unused = n_bins - n_opened

    best_key = None
    best_idx = 0
    scores = np.zeros(n_bins, dtype=np.float64)

    nr_of = _N  # local alias

    # Candidate existing (opened) bins that fit.
    for j in range(n_opened):
        g = _caps[j]
        if g < s:
            continue
        r = g - s
        if r > 0:
            delta = nr_of[r] - nr_of[g] + 1
        else:
            delta = -nr_of[g]
        key = (delta, -r)
        if best_key is None or key < best_key:
            best_key = key
            best_idx = j

    # Candidate unused bins (fresh bin), all with remaining capacity CAP.
    if n_unused > 0:
        r_new = CAP - s
        if r_new > 0:
            delta_new = nr_of[r_new] + 1
        else:
            delta_new = 0
        key = (delta_new, -r_new)
        if best_key is None or key < best_key:
            best_key = key
            best_idx = n_opened  # first unused bin index

    # Build scores: best candidate gets the highest score, everything else lower.
    scores[:] = 0.0
    scores[best_idx] = 1.0

    # Commit the choice into our private record.
    if best_idx < n_opened:
        g = _caps[best_idx]
        _N[g] -= 1
        _caps[best_idx] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    return scores
# EVOLVE-BLOCK-END
