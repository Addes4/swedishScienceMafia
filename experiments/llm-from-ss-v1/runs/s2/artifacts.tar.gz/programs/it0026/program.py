# EVOLVE-BLOCK-START
"""Best-fit rule.

Each arriving item is placed into the bin whose remaining capacity is the smallest that
still fits it (i.e. minimize the post-placement residual r = g - item; r = 0 is best).
This "best fit" heuristic tightly fills bins and is near-optimal for the Weibull-shaped
item distribution with mean about 40.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (the harness opens unused bins
in index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # Best fit: minimize post-placement residual r = g - s (r >= 0). Higher score for smaller r.
    for k, j in enumerate(fitting):
        r = _caps[j] - s
        scores[k] = -r

    r_new = CAP - s
    scores[len(fitting):] = -r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _caps[j] = g - s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END

