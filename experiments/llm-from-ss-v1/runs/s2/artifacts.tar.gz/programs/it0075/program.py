# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with mode-seeking tie-break.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). This is the classic sum-of-squares / worst-fit-with-consolidation
rule and is provably near-optimal for online bin packing on many distributions.

Exact-delta ties (mostly distinct residual values) are broken by preferring the post-placement
residual r that is most likely to be exactly matched by a single future item under the known
Weibull-shaped item-size distribution (mode around the distribution's peak), then r == 0,
then smallest r. The function is shown only the bins the item fits in, so it keeps its own
record of every opened bin. Each instance runs in a fresh process, so module-level state
starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Weibull(shape~2, mean~40) item-size distribution: approximate the mode (peak) region.
_MODE_LO = 28
_MODE_HI = 45


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def rank(r):
        # primary: sum-of-squares delta (smaller delta -> better)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # tiebreak tier 1: prefer residual in the distribution's mode (closable in one item)
        if _MODE_LO <= r <= _MODE_HI:
            tb = 2
        elif r == 0 or _N[r] > 0:
            tb = 1
        else:
            tb = 0
        return (-delta, tb, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r)
        scores[k] = (key[0] * 1e9 + key[1] * 1e6 - key[2])

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if _MODE_LO <= r_new <= _MODE_HI:
        tb_new = 2
    elif r_new == 0 or _N[r_new] > 0:
        tb_new = 1
    else:
        tb_new = 0
    scores[len(fitting):] = (-delta_new * 1e9 + tb_new * 1e6 - r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
