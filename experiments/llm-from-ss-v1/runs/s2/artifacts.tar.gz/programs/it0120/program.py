# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with largest-residual tie-breaking (exact lexicographic encoding).

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g. Exact-delta ties are broken by preferring the placement that leaves the largest
post-placement residual, which keeps more usable free space available for future items.

The comparison key (delta, -r) is encoded as an exact integer so that float rounding cannot
disturb the ordering. Deltas are bounded by roughly 2*num_bins, so a fixed integer scale is
safe. The function is shown only the bins the item fits in, so it keeps its own record of
every opened bin. Module-level state resets for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Large integer scale for lexicographic encoding: delta dominates, then -r (largest residual).
SCALE = 1 << 20


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        # exact sum-of-squares delta
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # higher score = better; delta is negated so smaller delta -> larger score,
        # then larger residual r is preferred.
        scores[k] = -delta * SCALE + r

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -delta_new * SCALE + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
