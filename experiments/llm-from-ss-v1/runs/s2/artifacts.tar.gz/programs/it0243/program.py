# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with distribution-aware residual tie-breaking.

Primary criterion: minimize the increase in sum_g N(g)^2 (N(g) = open bins with remaining
capacity g), which is essentially Best-Fit but avoids fragmenting residuals. Exact-delta
ties are broken using an online histogram of past item sizes: among equally-good
placements, prefer the one whose resulting residual r has been requested least often as an
item size so far, since such residuals are less likely to be filled soon.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0.0] * (CAP + 1)      # observed frequency of items of each size
_seen = 0.0                    # total items observed


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _freq, _seen
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # update item histogram with the current item before ranking
    _freq[s] += 1.0
    _seen += 1.0
    inv_seen = 1.0 / _seen

    def rank(r):
        # primary: exact change in sum of squares
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # secondary: prefer residual whose size is rarely requested (small frequency)
        rarity = _freq[r] * inv_seen if r > 0 else 1.0
        return (-delta, -rarity, r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r)
        scores[k] = key[0] * 1e9 + key[1] * 1e6 + key[2]

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
        rarity_new = _freq[r_new] * inv_seen
    else:
        delta_new = 0
        rarity_new = 1.0
    scores[len(fitting):] = -delta_new * 1e9 - rarity_new * 1e6 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
