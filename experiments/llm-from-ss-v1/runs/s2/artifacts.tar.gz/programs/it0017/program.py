# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with best-fit tie-breaking on exact deltas.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < CAP). Among placements with the exact minimum delta, prefer the smallest
positive post-placement residual (tightest fit that consolidates residual classes), and
prefer r == 0 (exact close) above all.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_fit = len(fitting)

    scores = np.empty(n_bins, dtype=np.float64)

    # Compute exact integer deltas for fitting bins.
    # delta(r) = (N(r)+1)^2 - N(r)^2  +  (N(g)-1)^2 - N(g)^2
    #          = 2*N(r)+1 - 2*N(g)+1   (for r>0; the N(r) term vanishes for r==0)
    deltas = np.empty(n_fit + 1, dtype=np.int64)
    residuals = np.empty(n_fit + 1, dtype=np.int64)

    for k in range(n_fit):
        g = _caps[fitting[k]]
        r = g - s
        if r > 0:
            d = 2 * _N[r] + 1 - 2 * _N[g] + 1
        else:
            d = -2 * _N[g] + 1
        deltas[k] = d
        residuals[k] = r

    r_new = CAP - s
    if r_new > 0:
        deltas[n_fit] = 2 * _N[r_new] + 1
    else:
        deltas[n_fit] = 0
    residuals[n_fit] = r_new

    # primary: minimise delta  -> score = -delta scaled large
    # tiebreak: prefer r == 0, then prefer smallest positive residual (best fit)
    # encode into a single float: -delta * BIG + tie
    # residuals range 0..CAP, use tiebreak in (-CAP-1, 0]
    BIG = 1000.0
    tb = np.where(residuals == 0, 0.0,
                  -(residuals.astype(np.float64)))  # r==0 -> 0 (best), else -r
    # smaller positive residual -> less negative (better) ; but r==0 best of all
    # adjust so r==0 tops: shift
    tb = np.where(residuals == 0, 1.0, -residuals.astype(np.float64))
    all_scores = -deltas.astype(np.float64) * BIG + tb

    scores[:n_fit] = all_scores[:n_fit]
    scores[n_fit:] = all_scores[n_fit]

    choice = int(np.argmax(scores))
    if choice < n_fit:
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_bins > n_fit:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

