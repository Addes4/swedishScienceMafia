# EVOLVE-BLOCK-START
"""Best-fit with tight-residual preference.

For each arriving item, among the bins it fits in choose the one with the smallest
non-negative residual after placement (classic best-fit); a perfect fill (residual 0) is
strictly best. Unused bins (residual 100-s) are considered last, so an existing bin is
preferred whenever it can hold the item without waste better than opening a new one.
Ties are broken by the largest residual to preserve bigger free blocks.

The function is shown only the bins the item fits in, but the harness passes an array in
fixed bin-index order with unused bins appended. Used bins are always a prefix, so we
rebuild our own record of every opened bin each call from that prefix.
"""
import numpy as np

CAP = 100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    s = int(item)
    n_bins = len(bins)
    scores = np.empty(n_bins, dtype=np.float64)

    # bins is a copy; unused bins have remaining capacity == CAP and appear at the end.
    # Treat a bin as "used" if its remaining capacity is < CAP (i.e. it already holds items).
    # Any bin with remaining >= s can receive the item.
    chosen_used = -1
    best_res = None  # smallest residual so far
    best_g = -1

    for j in range(n_bins):
        g = int(bins[j])
        if g < s:
            scores[j] = -1e18
            continue
        r = g - s
        if g < CAP:
            # used bin
            if best_res is None or r < best_res or (r == best_res and g > best_g):
                # prefer smaller residual; on tie prefer larger residual bin (larger g)
                best_res = r
                best_g = g
                chosen_used = j
            scores[j] = r
        else:
            # unused bin: mark with a large residual so used bins win when r_used <= r_unused
            scores[j] = r + CAP  # offset so used bins always preferable unless no used fits
    # Build a clean score array: highest score goes to chosen used bin.
    final = np.full(n_bins, -1e18, dtype=np.float64)
    if chosen_used >= 0:
        final[chosen_used] = 0.0
        return final
    # No used bin fits: pick the unused bin (largest residual = CAP-s, all equal, first wins).
    for j in range(n_bins):
        if int(bins[j]) >= s:
            final[j] = 0.0
            return final
    return final
# EVOLVE-BLOCK-END
