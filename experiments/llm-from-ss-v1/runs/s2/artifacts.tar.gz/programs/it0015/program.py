# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with frequency-weighted residual-class tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken by preferring a post-placement residual r
whose class is most populated (consolidating residual classes), falling back to the
smallest residual (tighter fit). The function is shown only the bins the item fits in, so
it keeps its own record of every opened bin. Used bins are always a prefix of the bin
array (harness opens unused bins in index order and ties go to the first bin).
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def rank(g_ref, r):
        # primary: sum-of-squares delta (smaller delta -> better)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # tiebreak tier: frequency-weighted preference for a populated residual class
        cnt = _N[r] if r > 0 else 0
        return (-delta, cnt, r if r > 0 else 0, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(g_ref, r)
        scores[k] = (key[0] * 1e9 + key[1] * 1e3 + key[2] * 1e-1 - key[3])

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    cnt_new = _N[r_new] if r_new > 0 else 0
    scores[len(fitting):] = (-delta_new * 1e9 + cnt_new * 1e3 - r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
