# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with fillability-aware tie-breaking.

Primary rule: place the item to minimise sum_g N(g)^2, where N(g) counts open bins with
remaining capacity g (0 < g < 100). This balances residual capacities.

Tie-break: among placements with identical primary delta, prefer the one whose post-placement
residual r is a "useful" size — one that matches a frequently-seen recent item size (so the
gap is easier to close later). Ties within that fall back to the largest residual.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0.0] * (CAP + 1)      # decaying histogram of recent item sizes


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist
    s = int(item)
    n_bins = len(bins)

    # decay history and record this item
    for g in range(1, CAP + 1):
        _hist[g] *= 0.995
    _hist[s] += 1.0

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # weight that favors residuals matching a recent item size
    def fill_w(r):
        if r <= 0:
            return 0.0
        return _hist[r]

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        primary = -delta
        sec = fill_w(r)
        tert = r
        scores[k] = primary * 1e12 + sec * 1e3 + tert

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    primary_new = -delta_new
    scores[len(fitting):] = primary_new * 1e12 + fill_w(r_new) * 1e3 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
