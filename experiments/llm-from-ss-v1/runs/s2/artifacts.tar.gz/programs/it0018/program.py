# EVOLVE-BLOCK-START
"""Residual-matching rule with sum-of-squares tie-breaking.

The dominant heuristic for online bin packing is to place an item so that it either closes
a bin exactly or best matches an existing residual gap (best-fit). We keep an exact record
of every opened bin's remaining capacity, since the harness only shows the fitting bins.
Primary score: prefer the bin whose remaining capacity is closest to the item size from above
(smallest residual), which is best-fit. Ties on residual are broken by the sum-of-squares
delta (balance). Unused bins always tie and are handled last.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        # primary: best fit (smallest residual); tiebreak: balance delta (smaller)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        scores[k] = (1000 - r) * 1e6 - delta

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = (1000 - r_new) * 1e6 - delta_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

