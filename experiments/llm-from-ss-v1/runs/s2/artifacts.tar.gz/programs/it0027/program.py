# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-class consolidation tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among placements with equal sum-of-squares delta, prefer a
post-placement residual r that already occurs among open bins (or r == 0), then the residual
class with the largest current count, then the smallest residual. The function is shown only
the bins the item fits in, so it keeps its own record of every opened bin. Used bins are
always a prefix of the bin array. Each instance runs in a fresh process, so the module-level
state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)
    BIG = 1 << 30

    def key_for(r, g_ref_neg2):
        # primary: sum-of-squares delta (smaller delta -> better) encoded so larger score wins
        # delta = (2*N[r]+1 if r>0 else 0) + (-2*N[g_ref]+1)
        if r > 0:
            delta = g_ref_neg2 + 2 * _N[r] + 1
        else:
            delta = g_ref_neg2
        # tier 1: prefer existing residual class (or r == 0)
        tb1 = 1 if (r == 0 or _N[r] > 0) else 0
        # tier 2: prefer residual class with larger current count
        cnt = _N[r] if r > 0 else 0
        return (-delta, tb1, cnt, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = key_for(r, -2 * _N[g_ref] + 1)
        scores[k] = (key[0] * BIG + key[1] * (BIG // 4) + key[2] * (BIG // 16) - key[3])

    r_new = CAP - s
    g_ref = CAP
    key = key_for(r_new, 0)
    scores[len(fitting):] = (-key[0] * BIG + key[1] * (BIG // 4) + key[2] * (BIG // 16) - key[3])

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
