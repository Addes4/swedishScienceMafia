# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with largest-residual tie-breaking (exact integer keys).

Each item goes where it minimises the change in sum_g N(g)^2, where N(g) counts open bins
with remaining capacity g (0 < g < 100). Exact primary ties are broken by preferring the
placement leaving the largest post-placement residual, so the most usable free space stays
available for future items.

The ranking uses exact integer keys (no 1e9 float scaling), so nothing is distorted by
floating-point precision. The function keeps its own record of every opened bin because the
harness only shows the bins the item fits in; used bins are always a prefix of the bin array
(harness opens unused bins in index order and ties go to the first bin). Module-level state
starts empty per instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, first on ties."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)

    # Best key seen so far, encoded as a single integer to allow exact comparison.
    # Sorting is equivalent to choosing, so we just track the best.
    # Encoding: primary (minimize delta) dominates; tie-break maximize r.
    best_key = None
    best_is_fit = False
    best_j = -1
    best_r = -1

    # --- fitting existing bins ---
    n_fit = 0
    for j, g in enumerate(_caps):
        if g >= s:
            r = g - s
            if r > 0:
                # delta = -2*N[g] + 1 + 2*N[r] + 1
                delta = -2 * _N[g] + 2 * _N[r] + 2
            else:
                delta = -2 * _N[g] + 1
            # key: (delta, -r) lexicographic; combine exactly with a wide multiplier.
            key = delta * (CAP + 1) - r
            if best_key is None or key < best_key:
                best_key = key
                best_is_fit = True
                best_j = j
                best_r = r
            n_fit += 1

    # --- opening a new bin (only if any unused bins exist) ---
    n_unused = n_bins - n_fit
    if n_unused > 0:
        r_new = CAP - s
        if r_new > 0:
            delta_new = 2 * _N[r_new] + 1
        else:
            delta_new = 0
        key_new = delta_new * (CAP + 1) - r_new
        if best_key is None or key_new < best_key:
            best_key = key_new
            best_is_fit = False
            best_r = r_new

    # --- apply the choice ---
    if best_is_fit:
        g = _caps[best_j]
        _N[g] -= 1
        ng = g - s
        _caps[best_j] = ng
        if ng > 0:
            _N[ng] += 1
    elif n_unused > 0:
        ng = CAP - s
        _caps.append(ng)
        if ng > 0:
            _N[ng] += 1

    # Build the returned score array (harness ignores it; it only uses argmax of returned).
    # Make the chosen actual bin rank highest. Since we return scores matched to `bins`,
    # the item's bin index in `bins` equals its index in _caps (used bins are a prefix).
    scores = np.zeros(n_bins, dtype=np.float64)
    if best_is_fit:
        scores[best_j] = 1.0
    else:
        # find the newly opened bin's index (== n_fit, the first unused position)
        scores[n_fit] = 1.0
    return scores
# EVOLVE-BLOCK-END
