# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with largest-residual tie-breaking (vectorized).

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Ties are broken by preferring the placement that leaves the
largest post-placement residual, which keeps more usable free space available for future
items.
The scores are computed with vectorized numpy operations over the recorded capacities.
Used bins are always a prefix of the bin array (harness opens unused bins in index order and
ties go to the first bin). Each instance runs in a fresh process, so module-level state
starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_N_arr = np.zeros(CAP + 1, dtype=np.float64)   # numpy mirror of _N for fast lookups
_caps_arr = np.zeros(0, dtype=np.float64)      # numpy mirror of _caps


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _N_arr, _caps_arr
    s = int(item)
    n_bins = len(bins)
    n_used = len(_caps)
    n_fitting = 0
    if n_used:
        # capacities of used bins (prefix of the array)
        caps = _caps_arr
        fit_mask = caps >= s
        n_fitting = int(fit_mask.sum())

    scores = np.empty(n_bins, dtype=np.float64)

    if n_fitting:
        g_ref = caps[:n_fitting]        # fitting bins are the first n_fitting used bins
        r = g_ref - s                   # residual after placement
        # delta = change in sum N(g)^2 if we place in this bin
        # placing in bin with residual g_ref removes g_ref, adds r
        delta = -2.0 * _N_arr[g_ref.astype(np.int64)] + 1.0
        nz = r > 0
        delta[nz] += 2.0 * _N_arr[r[nz].astype(np.int64)] + 1.0
        # smaller delta is better; tie-break by larger residual r
        scores[:n_fitting] = -delta * 1e9 + r

    # unused bins: r_new = CAP - s, and adding a bin only adds N(r_new) (if >0)
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2.0 * _N_arr[r_new] + 1.0
    else:
        delta_new = 0.0
    scores[n_fitting:] = -delta_new * 1e9 + r_new

    choice = int(np.argmax(scores))
    if choice < n_fitting:
        g = int(_caps[choice])
        _N[g] -= 1
        _N_arr[g] -= 1.0
        ng = g - s
        _caps[choice] = ng
        _caps_arr[choice] = ng
        if ng > 0:
            _N[ng] += 1
            _N_arr[ng] += 1.0
    elif n_fitting < n_bins:
        ng = CAP - s
        _caps.append(ng)
        _caps_arr = np.append(_caps_arr, float(ng))
        if ng > 0:
            _N[ng] += 1
            _N_arr[ng] += 1.0
    return scores
# EVOLVE-BLOCK-END
