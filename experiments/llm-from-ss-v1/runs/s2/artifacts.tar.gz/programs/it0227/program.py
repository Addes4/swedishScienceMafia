# EVOLVE-BLOCK-START
"""Harmonic-flavoured rule with sum-of-squares secondary pressure.

For a placement leaving residual r (r >= 0), define a harmonic weight h(r):
  - r == 0 contributes 0 (perfect fill),
  - otherwise h(r) = 1/ceil(100/r) (Harmonic packing weight, coarse-grained).
Primary criterion: minimise sum over existing bins of (h applied so the placement is
best), implemented as a per-bin benefit: placing into a bin removes its old residual class
weight and adds the new one. We use a small-delta form aligned with the sum-of-squares
rule so bins with equal primary value are separated by the proven N(g)^2 delta.

The function keeps its own record of every opened bin (used bins are always a prefix).
Each instance runs in a fresh process, so module state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _harm(r):
    """Coarse harmonic weight of a residual r (>= 0). Smaller r -> higher weight."""
    if r <= 0:
        return 0.0
    return 1.0 / float(-(-CAP // r))   # ceil(100 / r)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        # harmonic pressure: reducing the residual increases the harmonic weight of the bin,
        # so a *lower* resulting weight is better (we want free space to be small classes).
        hw = _harm(r)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # primary: minimise hw (tighter harmonic class first); secondary: proven SS delta.
        scores[k] = -hw * 1e6 + (-delta)

    r_new = CAP - s
    hw_new = _harm(r_new)
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -hw_new * 1e6 - delta_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
