# EVOLVE-BLOCK-START
"""Best-fit primary rule with a sum-of-squares tie-breaker.

Items are placed in the bin that leaves the smallest sufficient residual (classic best fit),
which is strong on Weibull-shaped sizes. Exact best-fit ties are broken by the resulting
count of open bins with that residual (prefer producing fewer such bins), and opening a new
bin is slightly disfavoured. State tracks opened bins since only fitting bins are shown.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, first on ties."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def score_for(r):
        # primary: smaller residual r is better -> use -r
        # secondary: prefer residual value that is rarer (lower post-count)
        post = _N[r] + (1 if r > 0 else 0)
        return -r * 1000.0 - post

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        scores[k] = score_for(r)

    # opening a new bin: residual r_new = CAP - s
    r_new = CAP - s
    post_new = _N[r_new] + (1 if r_new > 0 else 0)
    # slight penalty for opening a new bin relative to using an existing one
    scores[len(fitting):] = (score_for(r_new) - 0.5) if n_unused > 0 else -1e18

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
