# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with size-dependent residual tie-breaking.

Primary rule: place the item where it minimises sum_g N(g)^2, where N(g) counts open bins
with remaining capacity g (0 < g < 100). This is a strong online objective.

Ties (equal sum-of-squares delta) are broken by a size-dependent rule: large items (>= 50)
prefer the placement that leaves the LARGEST post-placement residual (keeping usable space
for future large items), while smaller items prefer the SMALLEST positive residual
(best-fit-flavored tightening, reducing fragmentation for the many small items).

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    big = s >= 50

    def rank(r):
        # primary: smaller sum-of-squares delta is better -> higher score
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # secondary tie-break, size-dependent
        if big:
            # prefer larger residual
            tie = r
        else:
            # prefer smallest positive residual; r == 0 (perfect fill) best
            tie = -r
        return (-delta, tie)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r)
        scores[k] = key[0] * 1e9 + key[1]

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if big:
        tie_new = r_new
    else:
        tie_new = -r_new
    scores[len(fitting):] = -delta_new * 1e9 + tie_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
