# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with harmonic-style residual consolidation tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). The primary objective (sum-of-squares) strongly favours placements
that keep the multiset of residual capacities concentrated, which correlates with using few
bins. Exact ties in the primary objective are broken by preferring a post-placement residual r
that already occurs among open bins (or r == 0), which consolidates residual classes and lets
future items close bins exactly.

Scoring is encoded as a single float using exact integer arithmetic placed into disjoint
magnitude tiers (times a large enough base) so that no numerical cross-talk occurs between
tiers.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Tier bases: primary delta magnitude is bounded by ~2*MAXBINS+2, tiebreak tiers are small.
_BASE_TB2 = 1 << 20            # room for tier-1 value encoded below
_BASE_TB1 = 1 << 14            # room for tier-2 value encoded below
_BASE_D = 1 << 21             # primary delta tier


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def encode(g_ref, r):
        # primary: sum-of-squares delta (smaller delta -> better -> larger encoded value)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = 0
        val_d = -delta                                   # prefer smaller delta
        # tier 1: prefer residual that already exists (or 0) -> consolidates classes
        tb1 = 1 if (r == 0 or _N[r] > 0) else 0
        # tier 2 (tertiary): prefer smaller residual (tighter fit)
        tb2 = (CAP - r)                                  # smaller r -> larger -> better
        return (val_d * _BASE_D + tb1 * _BASE_TB1 + tb2)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        scores[k] = encode(g_ref, r)

    r_new = CAP - s
    # opening a fresh bin: delta relative to current N is 2*N[r_new]+1 (r_new>0) or 0
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    tb1_new = 1 if (r_new == 0 or _N[r_new] > 0) else 0
    tb2_new = (CAP - r_new)
    scores[len(fitting):] = (-delta_new * _BASE_D + tb1_new * _BASE_TB1 + tb2_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
