# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with data-driven residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the residual that best
matches the observed item-size distribution, keeping more usable free space for the future.
The function keeps its own record of every opened bin since it is only shown the bins the
item fits in. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0] * (CAP + 1)        # histogram of past item sizes (for tie-breaking)
_hist_total = 0


def _tie_value(r):
    """Secondary key: prefer residuals close to typical item sizes (keeps space usable)."""
    if r <= 0:
        return -10 ** 6
    # fraction of past items that would fit exactly-or-loose in residual r
    fit = 0
    for v in range(1, min(r, CAP) + 1):
        fit += _hist[v]
    # prefer the smallest residual that still fits most of the seen sizes
    return fit * 1000 - r


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist, _hist_total
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.int64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        scores[k] = -delta * 10 ** 7 + _tie_value(r)

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = -delta_new * 10 ** 7 + _tie_value(r_new) - 10 ** 6

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    _hist[s] += 1
    _hist_total += 1
    return scores
# EVOLVE-BLOCK-END
