# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with largest-residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the placement that
leaves the largest post-placement residual, which keeps more usable free space available
for future items.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)

    # Select best bin using exact integer comparison: primary = sum-of-squares delta
    # (lower is better), secondary = larger residual (better).
    best_key = None
    best_choice = -1

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        key = (delta, -r)  # lower delta better; -r => larger residual better
        if best_key is None or key < best_key:
            best_key = key
            best_choice = k

    # Consider opening a fresh bin (residual CAP - s).
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if n_unused > 0:
        key_new = (delta_new, -r_new)
        if best_key is None or key_new < best_key:
            best_key = key_new
            best_choice = len(fitting)  # marker for "open new bin"

    scores = np.empty(n_bins, dtype=np.float64)
    # Encode scores so argmax picks best_choice: give it 1.0, everything else 0.0.
    scores[:] = 0.0
    if best_choice == len(fitting) and n_unused > 0:
        # first unused bin index is len(fitting)
        scores[len(fitting)] = 1.0
    elif best_choice >= 0:
        scores[best_choice] = 1.0
    else:
        # No fitting bin and no unused bin (shouldn't happen); fall back to first bin.
        scores[0] = 1.0

    # Apply state update based on best_choice.
    if best_choice == len(fitting) and n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    elif 0 <= best_choice < len(fitting):
        j = fitting[best_choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1

    return scores
# EVOLVE-BLOCK-END
