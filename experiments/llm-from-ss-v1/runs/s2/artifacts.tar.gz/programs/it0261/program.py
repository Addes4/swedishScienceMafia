# EVOLVE-BLOCK-START
"""Sum-of-Squares rule (best-fit) with a demand-aware tie-break.

Primary criterion: minimise the sum-of-squares delta, i.e. a best-fit proxy.
Secondary tie-break: among placements with identical delta, prefer the one whose post-placement
residual r best matches the recent item-size demand, estimated from an online histogram of
observed items. This steers bins toward residuals that future items are likely to consume,
reducing harmful fragmentation.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_demand = np.zeros(CAP + 2)    # smoothed demand histogram over item sizes (index = size)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _demand
    s = int(item)

    # Update demand estimate (exponential smoothing over the integer size axis).
    _demand *= 0.995
    _demand[s] += 1.0

    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)

    # Build lexicographic keys: primary = delta (minimise), secondary = -demand[r] (maximise).
    keys = []

    for j in fitting:
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        keys.append((delta, -float(_demand[r]), j))

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    for _ in range(n_unused):
        keys.append((delta_new, -float(_demand[r_new]), -1))

    # Choose: minimise delta, then maximise demand[r], then first bin.
    best = min(keys)
    choice_idx = keys.index(best)

    if choice_idx < len(fitting):
        j = fitting[choice_idx]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # Return scores aligned with provided `bins` order. bins[j] may be 100 for unused bins.
    # Map our key ordering into a score array (higher = better), preserving tie order.
    scores = np.empty(n_bins, dtype=np.float64)

    # Assign scores so that the chosen placement has the highest score.
    # Use negative encoded key so argmax reproduces min-key selection.
    for k in range(n_bins):
        if k < len(fitting):
            j = fitting[k]
            g_ref = _caps[j] if False else None  # placeholder, recomputed below
        # fallthrough handled below
        pass

    # Recompute per-bin keys directly from `bins` (the true remaining capacities),
    # so alignment with the harness's bin indices is exact.
    for k in range(n_bins):
        g_ref = int(bins[k])
        r = g_ref - s
        if g_ref == CAP:
            if r > 0:
                delta = 2 * _N[r] + 1
            else:
                delta = 0
        else:
            if r > 0:
                delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
            else:
                delta = -2 * _N[g_ref] + 1
        # primary: smaller delta better; secondary: larger demand[r] better
        scores[k] = -(delta * 1e6) + float(_demand[r]) * 1.0

    return scores
# EVOLVE-BLOCK-END
