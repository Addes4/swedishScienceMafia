# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with largest-residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken by preferring the placement that leaves the
largest post-placement residual, keeping more usable free space for future items.
Ranking uses an exact lexicographic comparison (primary: delta; secondary: -residual) rather
than a scaled float encoding.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]

    deltas = np.empty(n_bins, dtype=np.int64)
    residuals = np.empty(n_bins, dtype=np.int64)

    # Fitting bins: delta of the SS change, residual after placement.
    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        deltas[k] = delta
        residuals[k] = r

    # Unused bins (suffix): opening a fresh bin of capacity CAP.
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    deltas[len(fitting):] = delta_new
    residuals[len(fitting):] = r_new

    # Primary: minimize delta. Secondary: maximize residual r.
    # Build a lexicographic ordering: sort by (delta asc, residual desc), take first.
    order = np.lexsort((-residuals, deltas))
    choice = int(order[0])

    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # Return a score that makes `choice` win (matches lexicographic priority).
    scores = -deltas.astype(np.float64) * 1000.0 + residuals.astype(np.float64)
    return scores
# EVOLVE-BLOCK-END
