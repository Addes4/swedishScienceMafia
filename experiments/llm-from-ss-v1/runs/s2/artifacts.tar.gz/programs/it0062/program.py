# EVOLVE-BLOCK-START
"""Best-Fit bin choice with residual-class consolidation tie-break.

Each item goes into the fitting bin whose post-placement residual r = g - item is smallest
(any r >= 0). Among bins leaving the same residual, prefer the one whose residual already
exists among open bins (or r == 0), and then the smaller residual, to consolidate classes.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                      # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)            # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def score_of(r):
        # primary: Best-Fit (smaller residual better) -> encode as negative residual
        # tiebreak tier: prefer residual that already exists (or 0)
        tb = 1 if (r == 0 or _N[r] > 0) else 0
        return (-r) * 1e6 + tb * 1e3

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        scores[k] = score_of(r)

    r_new = CAP - s
    tb_new = 1 if (r_new == 0 or _N[r_new] > 0) else 0
    scores[len(fitting):] = (-r_new) * 1e6 + tb_new * 1e3

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

