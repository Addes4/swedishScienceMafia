# EVOLVE-BLOCK-START
"""Best-Fit primary with sum-of-squares tie-break, aligned to the given bins array.

The harness gives us the remaining capacity of every bin the item fits in (unused bins have
100). We rank by minimal post-placement residual r = g - s (classic Best-Fit), and break exact
residual ties with the sum-of-squares signal: prefer the placement whose residual r is currently
the least represented (minimising the growth in sum_g N(g)^2 balances open-bin capacities and
reduces fragmentation). Remaining ties prefer the largest residual.

State: N[g] counts open bins with remaining capacity g (0 < g < 100), tracked across calls.
Each instance runs in a fresh process, so module state starts empty.
"""
import numpy as np

CAP = 100
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_opened = False                # whether we have any open bins tracked yet


def priority(item, bins):
    """Rank every bin in `bins`; the item goes to the highest score (first on ties)."""
    global _N, _opened
    s = int(item)
    n = len(bins)
    caps = bins

    scores = np.empty(n, dtype=np.float64)
    best = None
    best_idx = 0
    for j in range(n):
        g = int(caps[j])
        if g < s:
            scores[j] = -1.0
            continue
        r = g - s
        # Best-fit primary: smaller residual is better. Sum-of-squares tie-break:
        # among equal residuals, prefer the one that keeps N balanced.
        # We encode: primary = -r (higher is better), secondary = -N[r] (prefer rarified).
        scores[j] = (-r) * 1e6 + (-_N[r]) * 1e3 + r * 1e-3
        if best is None or scores[j] > scores[best_idx]:
            best_idx = j
            best = scores[j]

    if best is not None:
        g = int(caps[best_idx])
        r = g - s
        if g > 0 and g < CAP:
            _N[g] -= 1
        if r > 0 and r < CAP:
            _N[r] += 1
        _opened = True

    return scores
# EVOLVE-BLOCK-END
