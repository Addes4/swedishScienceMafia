# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a learned "useful residual" tie-break.

The primary objective minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). This keeps the distribution of open residuals compact, which is
near-optimal for this Weibull-sized item stream.

Among placements with the same sum-of-squares delta we prefer the one whose post-placement
residual is more "likely to be filled later": we keep a decaying histogram H of item sizes
seen so far and score a residual r by how often a future item of size exactly r has been
observed. Residuals that match common item sizes are more valuable (they will be consumed
rather than wasted), so they are preferred. Remaining capacity 0 is always best (perfect
fill) and is handled by the same delta as before.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty per instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_H = [0.0] * (CAP + 1)         # decaying histogram of item sizes seen so far
_decay = 0.999


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _H
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # primary: delta (smaller delta -> better, so use -delta). tie-break: usefulness of r.
        h = _H[r] if r > 0 else 0.0
        scores[k] = -delta * 1e6 + h

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
        h_new = _H[r_new]
    else:
        delta_new = 0
        h_new = 0.0
    scores[len(fitting):] = -delta_new * 1e6 + h_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update decaying histogram of item sizes
    for i in range(1, CAP + 1):
        _H[i] *= _decay
    _H[s] += 1.0

    return scores
# EVOLVE-BLOCK-END
