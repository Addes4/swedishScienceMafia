# EVOLVE-BLOCK-START
"""Sum-of-Squares with a tolerance band for largest-residual selection.

Primary objective: minimise the increase in sum_g N(g)^2 (an empirically strong online
rule). Instead of only resolving *exact* delta ties by the largest post-placement residual,
we accept every bin whose SS delta is within TOL of the smallest delta and, among those,
pick the one leaving the largest residual. This keeps the near-optimal SS decisions while
biasing toward placements that preserve usable free space.

The function is shown only the bins the item fits in, so it records every opened bin itself.
Used bins are prefixes of the bin array (harness opens unused bins in order, ties go first),
and each instance runs in a fresh process, so module state starts empty.
"""
import numpy as np

CAP = 100
TOL = 1                        # tolerance band on the SS delta
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority per bin; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)

    m = len(fitting)
    deltas = [0] * (m + 1)
    resids = [0] * (m + 1)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        resids[k] = r
        if r > 0:
            deltas[k] = -2 * _N[g] + (2 * _N[r] + 1)
        else:
            deltas[k] = -2 * _N[g] + 1

    r_new = CAP - s
    resids[m] = r_new
    deltas[m] = (2 * _N[r_new] + 1) if r_new > 0 else 0

    min_delta = min(deltas[:m]) if m > 0 else deltas[m]
    # (even with no fitting bin the harness always offers a fresh bin, so we can open)
    limit = min_delta + TOL
    open_ok = (n_unused > 0) and (deltas[m] <= limit)

    scores = np.full(n_bins, -1e18, dtype=np.float64)
    for k, j in enumerate(fitting):
        if deltas[k] <= limit:
            scores[j] = float(resids[k])
    if open_ok:
        scores[m:] = float(r_new)

    choice = int(np.argmax(scores))

    if choice < m:
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
