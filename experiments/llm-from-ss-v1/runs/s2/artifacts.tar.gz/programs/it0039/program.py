# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with capacity-consolidating tie-break.

Primary objective: place the item where it minimises sum_g N(g)^2 over open bins
(the classic "sum of squares" online heuristic). Exact ties in this integer delta are
broken by preferring placements that keep many bins "useful", i.e. leave residual
capacity >= 40 (the distribution mean), so bins stay big enough to accept typical items.
State is per-process; each instance starts fresh.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_BIG = [0] * (CAP + 1)         # _BIG[g]: count of bins with residual >= g (only g in 0..CAP)

MEAN = 40


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # number of bins (excluding the chosen one) with residual >= MEAN is a tie-break signal.
    # Precompute count of open bins with residual >= MEAN.
    big_now = 0
    for g in range(MEAN, CAP + 1):
        big_now += _N[g] if g < CAP else 0
    # _N only tracks 0<g<CAP, so handle bins with residual == CAP separately is not needed
    # because unused bins aren't in _N and active bins never exceed CAP-1 after first item.

    def score_for(g_ref, r):
        # primary: sum-of-squares delta (smaller delta -> better), integer
        if r > 0 and r < CAP:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # how many bins would remain >= MEAN after this placement
        big_after = big_now
        if g_ref >= MEAN:
            big_after -= 1
        if r >= MEAN:
            big_after += 1
        # prefer smaller delta (higher -delta); then prefer more big bins; then tighter fit
        return -delta, big_after, -r

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        a, b, c = score_for(g_ref, r)
        scores[k] = a * 1e9 + b * 1e6 - c

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    big_after_new = big_now + (1 if r_new >= MEAN else 0)
    scores[len(fitting):] = -delta_new * 1e9 + big_after_new * 1e6 - r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if 0 < g - s < CAP:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if 0 < CAP - s < CAP:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
