# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-matching and largest-residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). This is the classic "best approximate" objective: creating a
residual that already exists costs (2N+1) + (2N-1) = 4N + 2, while creating a new residual
costs far less, so the rule keeps the multiset of residuals as diverse as possible.

Breaking exact-delta ties, we prefer the *smallest* residual (best-fit flavour), which
tends to close bins tightly.  Additionally we add a mild preference for placements whose
new residual already exists among the open bins (a "matchable pair"), which enables future
exact fills.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # Primary key: -delta (higher is better).  Secondary: small residual preferred.
    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # Secondary: prefer smallest positive residual that still keeps the bin openable.
        # Bonus (positive reward) if the new residual r already exists among open bins.
        match = 1 if (0 < r < CAP and _N[r] > 0) else 0
        scores[k] = -delta * 1e6 + (CAP - r) + match * 1e5

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    match_new = 1 if (0 < r_new < CAP and _N[r_new] > 0) else 0
    scores[len(fitting):] = -delta_new * 1e6 + (CAP - r_new) - 1 + match_new * 1e5

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
