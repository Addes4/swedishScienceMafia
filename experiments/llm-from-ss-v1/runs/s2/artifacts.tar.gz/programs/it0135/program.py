# EVOLVE-BLOCK-START
"""Best-fit primary with sum-of-squares tie-break.

Choose the fitting bin that leaves the smallest residual (tightest pack, r==0 preferred).
Among bins giving the same residual, use the sum-of-squares delta as a tie-break so the
placement that keeps global capacity least fragmented wins. Unused bins are only chosen
when no opened bin fits, and then the one with the largest residual (all equal) is fine.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # Precompute sum-of-squares delta for each candidate residual.
    def ss_delta(g_ref, r):
        # change in sum_g N(g)^2 when a bin of residual g_ref becomes residual r
        d = -2 * _N[g_ref] + 1
        if r > 0:
            d += 2 * _N[r] + 1
        return d

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        # primary: smallest residual -> larger (negative) key; tie: smaller ss_delta
        scores[k] = -r * 1e6 - ss_delta(g_ref, r)

    r_new = CAP - s
    delta_new = ss_delta(CAP, r_new)
    # treat unused bins as a residual of CAP-s each; same primary term
    scores[len(fitting):] = -r_new * 1e6 - delta_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
