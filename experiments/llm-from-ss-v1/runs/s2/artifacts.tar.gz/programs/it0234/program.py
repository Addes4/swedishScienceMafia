# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-rarity and largest-residual tie-breaking.

Primary: minimises Δ(Σ_g N(g)^2), the classic Sum-of-Squares (SS) bin-choice rule.
Exact-Δ ties: prefer the placement whose residual r is most likely to be exactly closed
later, using an online frequency estimate of observed item sizes; finally prefer the
largest residual (keeps more usable free space) as a deterministic fallback.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_F = [0] * (CAP + 1)           # _F[s]: decayed count of observed items of size s
_TOTAL = 0.0                    # decayed total of observed items


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _F, _TOTAL
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def tiebreak(r):
        # Prefer residuals that match likely future item sizes (closable exactly),
        # then larger residuals (more usable free space).
        freq = _F[r] if 0 <= r <= CAP else 0
        return (freq, r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # Primary term dominates; tie-break packed into small weighted slots.
        fb = tiebreak(r)
        scores[k] = (-delta) * 1e9 + fb[0] * 1e2 + fb[1]

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    fb = tiebreak(r_new)
    scores[len(fitting):] = (-delta_new) * 1e9 + fb[0] * 1e2 + fb[1]

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # Update online item-size frequency estimate (mild decay keeps it adaptive).
    for i in range(CAP + 1):
        _F[i] *= 0.999
    _TOTAL = _TOTAL * 0.999 + 1.0
    _F[s] += 1.0

    return scores
# EVOLVE-BLOCK-END
