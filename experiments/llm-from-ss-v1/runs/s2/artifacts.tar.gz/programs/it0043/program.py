# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-class tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken by preferring placements into existing bins
(over opening a fresh unused bin), then by a tighter fit (smaller positive residual, with
residual 0 best), which consolidates residual classes.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        # primary: sum-of-squares delta (smaller delta -> better -> larger score)
        delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # secondary (within (-delta, -delta+1)): tighter fit, and reward existing-bin use
        #   already an existing bin (bonus ~0.66), prefer residual 0, else smaller residual
        if r == 0:
            frac = 0.9
        else:
            frac = 0.5 * (1.0 - r / CAP) + 0.1
        scores[k] = -delta + frac

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if r_new == 0:
        frac_new = 0.9
    else:
        frac_new = 0.5 * (1.0 - r_new / CAP)
    scores[len(fitting):] = -delta_new + frac_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
