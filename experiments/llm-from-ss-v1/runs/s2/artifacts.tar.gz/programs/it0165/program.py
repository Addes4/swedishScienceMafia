# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with largest-residual tie-breaking (exact integer keys).

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the placement that
leaves the largest post-placement residual, which keeps more usable free space available
for future items. The primary delta and the secondary residual are combined into a single
exact integer key (no float scaling), so the lexicographic comparison is exact.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    n_open = len(_caps)
    scores = np.empty(n_bins, dtype=np.int64)

    # Exact lexicographic key: higher key = higher priority.
    # primary objective: minimise delta = -2*N[g_ref] + 1 + (2*N[r] + 1)
    # secondary: maximise residual r.
    # key = (-delta) * BASE + r  with BASE > max possible residual (CAP+1).
    BASE = CAP + 2
    filled = 0
    for j in range(n_open):
        g_ref = _caps[j]
        if g_ref < s:
            continue
        r = g_ref - s
        delta = -2 * _N[g_ref] + 1
        if r > 0:
            delta += 2 * _N[r] + 1
        scores[filled] = (-delta) * BASE + r
        filled += 1

    r_new = CAP - s
    delta_new = (2 * _N[r_new] + 1) if r_new > 0 else 0
    scores[filled:] = (-delta_new) * BASE + r_new
    filled = n_bins  # all unused bins share this key

    choice = int(np.argmax(scores))
    if choice < n_open and _caps[choice] >= s:
        g = _caps[choice]
        _N[g] -= 1
        ng = g - s
        _caps[choice] = ng
        if ng > 0:
            _N[ng] += 1
    elif n_bins > n_open:
        ng = CAP - s
        _caps.append(ng)
        if ng > 0:
            _N[ng] += 1
    return scores
# EVOLVE-BLOCK-END
