# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact lexicographic tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the placement that
leaves the largest post-placement residual, which keeps more usable free space available
for future items.  The comparison is done in pure Python on exact integer deltas, avoiding
any float64 precision loss from packing the two keys into one number.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)

    # best placement among existing bins: maximise delta, then maximise residual r
    best_delta = None
    best_r = -1
    best_j = -1
    for j in fitting:
        g_ref = _caps[j]
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        if best_delta is None or delta > best_delta or (delta == best_delta and r > best_r):
            best_delta = delta
            best_r = r
            best_j = j

    # opening a fresh bin: residual CAP - s, only the "+1" self term (no -2*N term)
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0

    # decide between best existing placement and opening a new bin
    if n_unused > 0:
        if best_delta is None or delta_new > best_delta or (delta_new == best_delta and r_new > best_r):
            use_new = True
        else:
            use_new = False
    else:
        use_new = False

    scores = np.zeros(n_bins, dtype=np.float64)
    if use_new:
        choice = len(fitting)          # first unused slot
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    else:
        choice = best_j
        g = _caps[best_j]
        _N[g] -= 1
        _caps[best_j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    scores[choice] = 1.0
    return scores
# EVOLVE-BLOCK-END
