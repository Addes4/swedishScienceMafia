# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with frequency-weighted residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the placement whose
post-placement residual r is a frequently seen item size, so future items are more likely to
find an exact fit, then by largest residual.
The function keeps its own record of every opened bin plus a histogram of past item sizes.
Used bins are always a prefix of the bin array. Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_F = [0] * (CAP + 1)           # F[s]: count of past items of size s


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _F
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        # exact sum-of-squares delta
        delta = -2 * _N[g_ref] + 1
        if r > 0:
            delta += 2 * _N[r] + 1
        # tie-break: prefer residual that is a common past item size, then larger r
        tie = _F[r] * 1e6 if r > 0 else -1e6
        scores[k] = delta * 1e9 + tie + r

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    tie_new = _F[r_new] * 1e6 if r_new > 0 else -1e6
    scores[len(fitting):] = delta_new * 1e9 + (tie_new + r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    _F[s] += 1
    return scores
# EVOLVE-BLOCK-END
