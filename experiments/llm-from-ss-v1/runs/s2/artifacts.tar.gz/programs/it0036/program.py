# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact integer lexicographic tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken by preferring a post-placement residual of 0
(which closes a bin, strictly reducing the open-bin count), then a residual that already
occurs among open bins, then the smallest positive residual (tightest fit). The function is
shown only the bins the item fits in, so it keeps its own record of every opened bin. Used
bins are always a prefix of the bin array. Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.int64)

    def key_for(g_ref, r):
        # primary: sum-of-squares delta (smaller delta -> better)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        elif g_ref < CAP:
            delta = -2 * _N[g_ref] + 1
        else:
            delta = 0
        # tiebreak tier: closing a bin (r==0) is best, existing residual next, else new
        if r == 0:
            tb = 2
        elif _N[r] > 0:
            tb = 1
        else:
            tb = 0
        # secondary numeric tiebreak: prefer smaller residual (tighter fit)
        return (-delta, -tb, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        a, b, c = key_for(g_ref, r)
        scores[k] = a * 1000000 + b * 100000 + c

    r_new = CAP - s
    a, b, c = key_for(CAP, r_new)
    scores[len(fitting):] = a * 1000000 + b * 100000 + c

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

