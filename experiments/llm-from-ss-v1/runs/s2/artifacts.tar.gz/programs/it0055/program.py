# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-class tie-breaking and a "close the bin" bonus.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken by preferring a post-placement residual r
that already occurs among open bins (or r == 0), which consolidates residual classes.
A small extra bonus rewards placements that fill a bin exactly (residual 0).
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    # Precompute for the "new bin" candidate.
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0

    def rank(g_ref, r):
        # primary: sum-of-squares delta (smaller delta -> better)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # tiebreak tier: prefer residual that already exists (or 0)
        tb = 1 if (r == 0 or _N[r] > 0) else 0
        # "close the bin" bonus
        close = 1 if r == 0 else 0
        return delta, tb, close, r

    # Gather candidate keys and pick the best with pure Python lexicographic comparison
    # (minimise delta, then maximise tb, then maximise close, then minimise r).
    best_idx = None
    best_key = None

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        delta, tb, close, _ = rank(g_ref, r)
        key = (delta, -tb, -close, r)
        if best_key is None or key < best_key:
            best_key = key
            best_idx = k

    # New-bin candidate
    tb_new = 1 if (r_new == 0 or _N[r_new] > 0) else 0
    close_new = 1 if r_new == 0 else 0
    new_key = (delta_new, -tb_new, -close_new, r_new)
    if n_unused > 0 and (best_key is None or new_key < best_key):
        best_key = new_key
        best_idx = len(fitting)

    # Build scores: strictly decreasing with rank so the first best bin wins.
    n_total = n_bins
    scores = np.empty(n_total, dtype=np.float64)

    def enc(delta, tb, close):
        # Larger is better. delta ranges roughly [-200, 200]; use big weights.
        return (-delta) * 1e12 + tb * 1e9 + close * 1e6

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        delta, tb, close, _ = rank(g_ref, r)
        # tiny residual term to keep unique-ish values; prefer smaller r
        scores[k] = enc(delta, tb, close) - r
    if n_unused > 0:
        # unused bins share the same key; assign decreasing so first unused wins among them
        base = enc(delta_new, tb_new, close_new) - r_new
        for q in range(n_unused):
            scores[len(fitting) + q] = base - q * 1e-3
    else:
        # no unused slot; assign very low score to keep argmax consistent (shouldn't happen)
        pass

    choice = best_idx
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

