# EVOLVE-BLOCK-START
"""Best-fit rule with exact-fit preference.

Each item goes into the fitting bin with the smallest resulting residual r (tightest fit).
Ties (equal r) are broken by preferring the smallest bin index, which the harness already does,
so we just encode r as the descending score. Unused bins are only chosen when nothing else fits.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps
    s = int(item)
    n_bins = len(bins)
    scores = np.empty(n_bins, dtype=np.float64)

    n_fit = 0
    base = 0
    for j, g in enumerate(_caps):
        if g >= s:
            scores[base] = -(g - s)
            base += 1

    # unused bins: lowest priority, prefer largest resulting residual among them is irrelevant,
    # so just give them a fixed low score.
    scores[base:] = -1e9

    choice = int(np.argmax(scores))
    if choice < base:
        g = _caps[choice]
    else:
        choice = None

    if choice is not None:
        g = _caps[choice]
        _caps[choice] = g - s
    else:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
