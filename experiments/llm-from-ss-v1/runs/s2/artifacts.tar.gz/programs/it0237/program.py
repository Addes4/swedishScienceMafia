# EVOLVE-BLOCK-START
"""Residual-reusability rule guided by the empirical item-size distribution.

Each arriving item is placed so that the *residual* left behind is as likely as possible to
be exactly matched by some future item.  We track an online histogram of observed item
sizes; a residual r is "reusable" if r is (or is near) a size that actually occurs.  When
several placements are equally reusable we fall back to the sum-of-squares balance rule,
and finally to the largest-residual tie-break.

State resets every instance because each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_H = [0.0] * (CAP + 2)         # decaying histogram of observed item sizes (index = size)
_H_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _H, _H_total
    s = int(item)

    # Update the empirical size histogram with exponential decay.
    decay = 0.9995
    _H_total *= decay
    for v in range(1, CAP + 1):
        _H[v] *= decay
    _H[s] += 1.0
    _H_total += 1.0

    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def reusability(r):
        """Density of the empirical size distribution around residual r (0 means useless dust)."""
        if r <= 0:
            return 0.0
        # simple triangular smoothing over neighbours r-1..r+1
        d = _H[r]
        if r > 1:
            d += 0.5 * _H[r - 1]
        if r < CAP:
            d += 0.5 * _H[r + 1]
        return d / (_H_total + 1e-9)

    def rank(r, g_ref):
        # primary: how likely is residual r to be matched later (higher is better)
        prim = reusability(r)
        # secondary: sum-of-squares balance of the resulting residual distribution
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # tertiary: prefer larger residual to keep space usable
        return (prim, -delta, r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r, g_ref)
        scores[k] = key[0] * 1e9 + key[1] * 1e3 + key[2] * 1e-3

    r_new = CAP - s
    prim_new = reusability(r_new)
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    scores[len(fitting):] = prim_new * 1e9 - delta_new * 1e3 + r_new * 1e-3

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
