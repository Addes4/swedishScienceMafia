# EVOLVE-BLOCK-START
"""Best-Fit rule with residual-class consolidation tie-breaking.

Each item goes into the fitting bin that leaves the smallest positive residual (classic
Best Fit). Exact ties are broken by preferring a post-placement residual r that already
occurs among open bins, and preferring r == 0 (perfectly packed). This consolidates residual
classes so future items can close bins cleanly.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def rank(r):
        # primary: prefer smaller residual (classic Best Fit); r==0 is best
        # tiebreak tier: prefer residual that already exists (or 0)
        tb = 1 if (r == 0 or _N[r] > 0) else 0
        return (-r, tb)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r)
        scores[k] = (key[0] * 1e9 + key[1] * 1e6)

    r_new = CAP - s
    tb_new = 1 if (r_new == 0 or _N[r_new] > 0) else 0
    scores[len(fitting):] = (-r_new * 1e9 + tb_new * 1e6)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
