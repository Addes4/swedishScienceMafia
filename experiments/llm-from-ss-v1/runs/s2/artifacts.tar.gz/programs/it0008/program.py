# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with complementary-residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken by preferring a post-placement residual r
that already occurs among open bins (or r == 0); among those, prefer a residual that some
recently-arrived item could exactly fill, which helps form complementary pairs.
The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_recent = [0] * (CAP + 1)      # decaying count of recent item sizes (item sizes seen lately)


def _decay():
    for i in range(1, CAP):
        v = _recent[i]
        if v:
            _recent[i] = v - 1


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def rank(r, g_ref):
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        if r == 0 or _N[r] > 0:
            tb = 2
        else:
            tb = 0
        # bonus if this residual is a size we've seen recently (future item may fill it)
        if r > 0 and _recent[r] > 0:
            tb += 1
        return (-delta, tb, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r, g_ref)
        scores[k] = (key[0] * 1e9 + key[1] * 1e6 - key[2])

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if r_new == 0 or _N[r_new] > 0:
        tb_new = 2
    else:
        tb_new = 0
    if r_new > 0 and _recent[r_new] > 0:
        tb_new += 1
    scores[len(fitting):] = (-delta_new * 1e9 + tb_new * 1e6 - r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update recent-size statistics: decay then record this item's size
    _decay()
    if 1 <= s < CAP:
        _recent[s] += 1

    return scores
# EVOLVE-BLOCK-END

