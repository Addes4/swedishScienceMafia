# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with exact lexicographic tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among equal sum-of-squares cost, prefer (in order):
  1) a post-placement residual r == 0 (perfectly filled bin),
  2) a residual r whose class currently has the largest count (consolidation),
  3) the smallest residual (tightest fit).
Encoded exactly with integer keys so there is no floating-point cross-talk.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    scores = np.empty(n_bins, dtype=np.float64)

    def delta(r):
        # change in sum_g N(g)^2 when moving an item from bin g_ref to residual r
        if r > 0:
            return -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        return -2 * _N[g_ref] + 1

    def key(g_ref, r):
        d = delta(r)
        # tier 1: prefer r == 0
        t1 = 1 if r == 0 else 0
        # tier 2: prefer larger existing count of residual class
        t2 = _N[r] if r > 0 else 0
        # tier 3: prefer smaller residual
        t3 = -r
        return (-d, t1, t2, t3)

    # lexicographic integer encoding (delta range is small; counts < 5000; r <= 100)
    B = 1 << 20
    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        kk = key(g_ref, r)
        scores[k] = float((kk[0] + 200) * (B ** 3) + kk[1] * (B ** 2) + kk[2] * B + kk[3])

    r_new = CAP - s
    kk = key(CAP, r_new)
    new_score = float((kk[0] + 200) * (B ** 3) + kk[1] * (B ** 2) + kk[2] * B + kk[3])
    scores[len(fitting):] = new_score

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_bins > len(fitting):
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
