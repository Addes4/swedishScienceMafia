# EVOLVE-BLOCK-START
"""Sum-of-Squares rule (Best-Fit proxy) with largest-residual tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact-delta ties are broken by preferring the placement that
leaves the largest post-placement residual, which keeps more usable free space available
for future items.

The function is shown only the bins the item fits in, so it keeps its own record of every
opened bin. Used bins are always a prefix of the bin array (harness opens unused bins in
index order and ties go to the first bin). Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    scores = np.empty(n_bins, dtype=np.float64)

    # First slot: the best fitting bin, tracked by (delta, -r) lexicographically.
    best_key = None
    best_pos = -1
    n_placed = len(_caps)

    for j in range(n_placed):
        g_ref = _caps[j]
        if g_ref < s:
            continue
        r = g_ref - s
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # lexicographic key: minimize delta, then maximize r
        key = (delta, -r)
        if best_key is None or key < best_key:
            best_key = key
            best_pos = j

    # The unused bins (index >= n_placed) all have remaining capacity CAP; an item placed
    # there yields residual r_new with delta_new. Compute its key once.
    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    new_key = (delta_new, -r_new)

    use_new = n_bins > n_placed and (best_key is None or new_key < best_key)

    # Build scores so that argmax picks the right bin. Put a single high value at the chosen
    # slot and low values elsewhere; ties go to the first, so we must be careful to only
    # mark the intended slot as high.
    scores[:] = 0.0
    if use_new:
        pos = n_placed
    elif best_pos >= 0:
        pos = best_pos
    else:
        # No fitting bin at all (should not happen: unused bins always fit). Fall back to 0.
        pos = 0

    scores[pos] = 1.0

    # Update state according to the actual placement.
    choice = pos
    if choice < n_placed:
        g = _caps[choice]
        _N[g] -= 1
        _caps[choice] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_bins > n_placed:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
