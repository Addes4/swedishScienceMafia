# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-class and closing-bonus tie-breaking.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Exact ties are broken first by preferring a post-placement residual
r that already occurs among open bins (or r == 0), then by preferring a residual that matches
a frequent recent item size (so a future item can close the bin exactly), then by smaller r.
The function keeps its own record of every opened bin; unused bins are a prefix-free tail.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# decaying histogram of recent item sizes (index 1..100), to estimate future item sizes
_freq = [0.0] * (CAP + 1)
_decay = 0.99


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _freq
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    def rank(r):
        # primary: sum-of-squares delta (smaller delta -> better)
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # tiebreak tier 1: prefer residual that already exists (or 0)
        if r == 0 or _N[r] > 0:
            tb1 = 1
        else:
            tb1 = 0
        # tiebreak tier 2: prefer residual that is a frequent future item size
        tb2 = _freq[r] if r > 0 else 0.0
        # secondary numeric tiebreak: prefer smaller residual (tighter fit)
        return (-delta, tb1, tb2, -r)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        key = rank(r)
        scores[k] = (key[0] * 1e12 + key[1] * 1e9 + key[2] * 1e3 - key[3])

    r_new = CAP - s
    g_ref = CAP
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    if r_new == 0 or _N[r_new] > 0:
        tb1_new = 1
    else:
        tb1_new = 0
    tb2_new = _freq[r_new] if r_new > 0 else 0.0
    scores[len(fitting):] = (-delta_new * 1e12 + tb1_new * 1e9 + tb2_new * 1e3 - r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update decaying histogram of item sizes for future tie-breaks
    for t in range(1, CAP + 1):
        _freq[t] *= _decay
    _freq[s] += 1.0
    return scores
# EVOLVE-BLOCK-END
