# EVOLVE-BLOCK-START
"""Exponential-residual bin packing rule.

Each item goes to the bin minimising the change in a soft potential
    P = sum over open bins of W(residual),  W(g) = exp(-g / SCALE),
so a placement that turns residual g_ref into r contributes W(r) - W(g_ref).
Small SCALE approaches best-fit (steeply penalises small residuals),
large SCALE approaches worst-fit. We also add a tiny preference for the
largest residual among ties to keep usable space around.

The harness shows only fitting bins; used bins are a prefix of the array,
unused bins have capacity 100. We track our own record of opened bins.
State is module-level and resets each fresh process / instance.
"""
import numpy as np
import math

CAP = 100
SCALE = 18.0
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_W = [0.0] * (CAP + 1)         # cached W(g) for g in 0..CAP

for _g in range(CAP + 1):
    _W[_g] = math.exp(-_g / SCALE)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        delta = _W[r] - _W[g_ref]
        # primary: minimise delta (i.e. lowest increase in potential)
        # secondary: prefer larger residual
        scores[k] = -delta * 1e6 + r

    r_new = CAP - s
    delta_new = _W[r_new]
    scores[len(fitting):] = -(delta_new if n_unused > 0 else 1e9) * 1e6 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _caps[j] = g - s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
