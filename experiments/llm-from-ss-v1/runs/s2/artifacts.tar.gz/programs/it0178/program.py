# EVOLVE-BLOCK-START
"""Sum-of-Squares objective with Best-Fit tie-breaking.

Each item goes where it minimises sum_g N(g)^2 (N(g) = open bins with remaining capacity g,
0 < g < 100). Exact-delta ties are broken by Best-Fit: the placement leaving the smallest
residual. This preserves the larger free gaps for large future items. Opening a new bin is
used only as a last resort (a large positive delta once all fitting bins tie).
The harness shows only bins the item fits in; the function tracks all opened bins itself.
Used bins are a prefix of the array, so state is rebuilt in bin-index order.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _caps, _N
    s = int(item)
    n_bins = len(bins)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = n_bins - len(fitting)
    scores = np.empty(n_bins, dtype=np.float64)

    for k, j in enumerate(fitting):
        g_ref = _caps[j]
        r = g_ref - s
        # delta of sum N(g)^2 when moving a bin from g_ref to r
        if r > 0:
            delta = -2 * _N[g_ref] + 1 + (2 * _N[r] + 1)
        else:
            delta = -2 * _N[g_ref] + 1
        # primary: minimised delta (negate); secondary: best-fit wants small residual
        scores[k] = -delta * 1e6 - r

    r_new = CAP - s
    if r_new > 0:
        delta_new = 2 * _N[r_new] + 1
    else:
        delta_new = 0
    # opening a new bin: big positive delta, and never preferred over an equal fitting bin
    scores[len(fitting):] = -delta_new * 1e6 + 1e-3

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
