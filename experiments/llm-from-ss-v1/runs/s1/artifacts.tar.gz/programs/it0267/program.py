# EVOLVE-BLOCK-START
"""Sum-of-Squares rule: minimise sum_g N(g)^2 at every step.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among exact sum-of-squares ties, prefer the bin with the largest
remaining capacity (loosest fit), which spreads load and avoids prematurely creating tiny
unusable residuals.

The function keeps its own record of every opened bin. The harness opens unused bins in index
order (ties go to the first bin), so used bins are always a prefix of the bin array. Each
instance runs in a fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    m = len(_caps)
    n_bins = len(bins)
    scores = np.empty(n_bins, dtype=np.float64)

    caps = np.array(_caps, dtype=np.int64) if m else np.empty(0, dtype=np.int64)
    N = np.array(_N, dtype=np.int64)

    fitting = np.nonzero(caps >= s)[0] if m else np.empty(0, dtype=np.int64)
    n_fit = len(fitting)
    n_unused = n_bins - n_fit

    if n_fit:
        g = caps[fitting]
        r = g - s
        delta = -2 * N[g] + 1
        pos = r > 0
        delta[pos] += 2 * N[r[pos]] + 1
        # primary: minimise delta; tiebreak: prefer larger residual (loosest fit)
        scores[:n_fit] = -(delta.astype(np.float64) * 1000) + r

    if n_unused:
        r_new = CAP - s
        delta_new = (2 * N[r_new] + 1) if r_new > 0 else 0
        scores[n_fit:] = -(delta_new * 1000) + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < n_fit:
        j = int(fitting[choice])
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
