# EVOLVE-BLOCK-START
"""Residual-weighted bin choice rule.

Each item is placed to minimise a linear cost on the resulting residual r = g - s:
a strong reward for perfect fits (r == 0) and a mild preference for tight fits
(small r), with a very small loosest-fit tiebreak to avoid pathological equalities.
The function keeps its own record of every opened bin; since the harness opens
unused bins in index order and ties go to the first bin, used bins are always a
prefix of the bin array.  State resets per instance because each instance runs in
a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps
    s = int(item)
    n_used = len(_caps)
    n_bins = len(bins)
    scores = np.empty(n_bins, dtype=np.float64)

    for j in range(n_used):
        g = _caps[j]
        if g < s:
            scores[j] = -1e18          # cannot fit; harness never shows it, but be safe
        else:
            r = g - s
            # prefer perfect fits, then smaller residuals, tiny loosest-fit tiebreak
            scores[j] = -(r) * 10.0 + (1000.0 if r == 0 else 0.0) + r * 0.001

    # unused bins (remaining capacity 100)
    r_new = CAP - s
    base = -(r_new) * 10.0 + (1000.0 if r_new == 0 else 0.0)
    scores[n_used:] = base

    choice = int(np.argmax(scores))
    if choice < n_used:
        _caps[choice] -= s
    else:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
