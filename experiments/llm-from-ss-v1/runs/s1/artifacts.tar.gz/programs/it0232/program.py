# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a reusable-residual tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer the bin whose resulting residual is most
"reusable": an exact fit (r = 0) is best, otherwise prefer a residual that already has several open
bins (so similar future items can match), breaking remaining ties toward the larger residual
(loosest fit) to spread load.

The function keeps its own record of every opened bin. Unused bins are a prefix-free suffix: the
harness opens unused bins in index order and ties go to the first bin, so used bins are always a
prefix of the bin array. Each instance runs in a fresh process, so module state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta (scale keeps exact SOS ordering);
        # tiebreak: residual reuse. r==0 strongly preferred, else cluster + loosest fit.
        if r == 0:
            tb = 1_000_000.0
        else:
            tb = _N[r] * 1000.0 + r
        scores[k] = -(delta * 1_000_000_000.0) + tb
    r_new = CAP - s
    if r_new == 0:
        tb_new = 1_000_000.0
    else:
        tb_new = _N[r_new] * 1000.0 + r_new
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1_000_000_000.0) + tb_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

