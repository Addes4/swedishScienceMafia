# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a distribution-aware residual penalty.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100); ties go to the tighter fit. A small extra penalty is added for creating residuals that
are unlikely to be filled later. The penalty is suppressed when the residual matches a size that has
appeared often among past items, since such residuals are easy to reuse later.
The function keeps its own record of every opened bin. The harness opens unused bins in index order
(ties go to the first bin), so used bins are always a prefix of the bin array. Each instance runs in a
fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # empirical count of item sizes seen so far
_seen = 0                      # number of items seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _freq, _seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    def penalty(r):
        # discourage residuals that are unlikely to be filled. Suppress the penalty when the
        # residual is a size that appears often among past items (easy to reuse later).
        if r <= 0:
            return 0
        if _seen > 0:
            share = _freq[r] / _seen
        else:
            share = 0.0
        # baseline small-residual penalty, damped when the residual is a common size
        base = 0.0
        if r <= 4:
            base += 3
        base += 0.15 * r
        # if the residual is common, it is more likely to be reusable, so reduce penalty
        return base * (1.0 - min(0.9, share * 8.0))

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * 1000 + r) - penalty(r)
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000 + r_new) - penalty(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    _freq[s] += 1
    _seen += 1
    return scores
# EVOLVE-BLOCK-END
