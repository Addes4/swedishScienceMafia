# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a distribution-aware fillability tiebreaker.

Primary: exact integer sum-of-squares delta (minimising sum_g N(g)^2), scaled so ties are exact.
Tiebreak: among equal deltas, prefer the residual r that is most likely to be filled exactly (or
to combine with one more item into an exact fill), estimated from the empirical histogram of
recent items. This keeps the strong near-optimal SS behaviour while resolving its frequent ties
using the actual item-size distribution rather than an arbitrary rule.
The function keeps its own record of every opened bin. The harness opens unused bins in index
order, so used bins are always a prefix of the bin array. Each instance runs in a fresh process,
so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0.0] * (CAP + 1)      # smoothed empirical item-size histogram (index = size)
_hist_total = 0.0
_RECENT = 400                  # window length used to re-estimate the histogram


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score (first on ties)."""
    global _caps, _N, _hist, _hist_total
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    L = len(bins)
    scores = np.empty(L, dtype=np.float64)

    # ---- fillability estimate from the empirical distribution ----
    # p[r] ~ fraction of recent items that exactly equal r (plus smoothing).
    inv = 1.0 / (_hist_total + 1.0)

    def fill(r):
        # value of leaving residual r: probability it is exactly filled soon
        # plus probability that a single arriving item leaves 0 from r.
        if r <= 0:
            return 0.0
        v = _hist[r]
        # discounted chance of a second item completing it
        # expected completion via some item t <= r-1 leaving r-t fillable
        # cheap approximation: sum over sizes t of hist[t]*hist[r-t] contribution
        acc = 0.0
        lo = max(1, r - CAP)
        # only consider t in a plausible range to keep it O(small)
        for t in range(lo, r):
            if _hist[t]:
                acc += _hist[t] * _hist[r - t]
        return v + 0.05 * acc

    BIG = 1 << 40  # safe for exact integer ordering within double range for deltas < ~few thousand

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta; tiebreak: maximise fillability (then prefer smaller r)
        scores[k] = -(delta * BIG) + fill(r) * 1e6 - r * 1e-3
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * BIG) + fill(r_new) * 1e6 - r_new * 1e-3

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # ---- update empirical histogram (smoothed, moving average) ----
    _hist[s] += 1.0
    _hist_total += 1.0
    decay = 1.0 - 1.0 / _RECENT
    if _hist_total > _RECENT:
        # rescale to keep the histogram a decaying window
        for i in range(CAP + 1):
            _hist[i] *= decay
        _hist_total *= decay
    return scores
# EVOLVE-BLOCK-END
