# EVOLVE-BLOCK-START
"""Exact sum-of-squares rule with a loosest-fit tiebreaker.

Each arriving item is placed in the bin whose resulting placement minimises the exact
sum over residual capacities g of N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Compared to an incremental delta, this directly evaluates the
true post-placement fragmentation, including the removal of the chosen bin's old capacity
and the addition of its new residual. Among exact ties, we prefer the largest residual
(loosest fit), which spreads load and avoids creating tiny unusable residuals.

The function keeps its own record of every opened bin. The harness opens unused bins in
index order (ties go to the first bin), so used bins are always a prefix of the bin array.
Each instance runs in a fresh process, so module-level state starts empty for each instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_SOS = 0                       # sum over g of N[g]^2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _SOS
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # Exact SOS change: remove g, add r.
        delta = (-(2 * _N[g] - 1)) + ((2 * _N[r] + 1) if r > 0 else 0)
        # primary: minimise delta; tiebreak: prefer larger residual (loosest fit)
        scores[k] = -(delta * 1000) + r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000) + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        r = g - s
        delta = (-(2 * _N[g] - 1)) + ((2 * _N[r] + 1) if r > 0 else 0)
        _SOS += delta
        _N[g] -= 1
        _caps[j] = r
        if r > 0:
            _N[r] += 1
    elif n_unused > 0:
        r = CAP - s
        delta = 2 * _N[r] + 1 if r > 0 else 0
        _SOS += delta
        _caps.append(r)
        if r > 0:
            _N[r] += 1
    return scores
# EVOLVE-BLOCK-END

