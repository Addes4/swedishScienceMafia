# EVOLVE-BLOCK-START
"""Best-Fit rule.

Each arriving item is placed into the fullest bin it fits in, i.e. the bin whose remaining
capacity is smallest while still >= item size. Among ties (equal residual) prefer the bin
that leaves the residual most likely to be paired later: nothing special — ties go to the
first bin, which is fine because residual value already determines quality.

The function keeps its own record of every opened bin. The harness opens unused bins in
index order (ties go to the first bin), so used bins are always a prefix of the bin array.
Each instance runs in a fresh process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, first on ties.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps
    s = int(item)
    n_old = len(_caps)
    n_total = len(bins)
    scores = np.empty(n_total, dtype=np.float64)

    # Existing used bins: prefer smallest residual r = g - s  => highest score = -r
    for j in range(n_old):
        g = _caps[j]
        if g >= s:
            scores[j] = -(g - s)
        else:
            scores[j] = -np.inf

    # Unused bins all have capacity CAP; residual CAP - s, same for all.
    scores[n_old:] = -(CAP - s)

    choice = int(np.argmax(scores))
    if choice < n_old:
        _caps[choice] -= s
    else:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
