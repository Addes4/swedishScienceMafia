# EVOLVE-BLOCK-START
"""Exact-fit first, then exact sum-of-squares, then loosest fit.

Each item goes to a bin where it fits exactly (residual 0) if any exists, since closing a bin
outright is always beneficial. Otherwise it minimises the exact change in sum_g N(g)^2 over open
residuals, where N(g) counts bins with remaining capacity g (0 < g < CAP). The exact change is
computed rather than the marginal approximation so the greedy criterion is truly optimal for its
objective. Among ties, prefer the largest residual (loosest fit). The function keeps its own record
of opened bins; since the harness opens unused bins in index order, used bins form a prefix.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    def delta_for(g):
        r = g - s
        # exact change in sum N^2: remove g, add r
        d = -2 * _N[g] + 1
        if r > 0:
            d += 2 * _N[r] + 1
        return d, r

    for k, j in enumerate(fitting):
        g = _caps[j]
        d, r = delta_for(g)
        # primary: minimise d; secondary: prefer exact fit (r==0) then loosest fit
        exact = 1e6 if r == 0 else 0.0
        scores[k] = -(d * 1000.0) + exact + r

    r_new = CAP - s
    d_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    exact_new = 1e6 if r_new == 0 else 0.0
    scores[len(fitting):] = -(d_new * 1000.0) + exact_new + r_new

    choice = int(np.argmax(scores))          # first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
