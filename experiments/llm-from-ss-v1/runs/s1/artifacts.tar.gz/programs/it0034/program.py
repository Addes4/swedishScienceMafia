# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a learned hot-residual tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer the bin whose resulting residual is a
frequently-seen recent item size (so that bin is likely to be closed exactly by a later item),
falling back to loosest fit.

The function keeps its own record of every opened bin plus an online frequency table of recent item
sizes. The harness opens unused bins in index order (ties go to the first bin), so used bins are
always a prefix of the bin array. Each instance runs in a fresh process, so module-level state starts
empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # decayed frequency of recently seen item sizes


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _freq
    s = int(item)
    # update learned frequency table with mild exponential decay
    for i in range(1, CAP + 1):
        _freq[i] = int(_freq[i] * 0.997)
    _freq[s] += 1000

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta; secondary: prefer hot residual; tertiary: loosest fit
        hot = _freq[r] if r > 0 else 0
        scores[k] = -(delta * 1_000_000) + hot * 100 + r

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    hot_new = _freq[r_new] if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1_000_000) + hot_new * 100 + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

