# EVOLVE-BLOCK-START
"""Smoothed sum-of-squares rule with a loosest-fit tiebreaker.

The classic greedy "sum of N(g)^2" rule is near-optimal because it steers the multiset of
residual capacities toward a desirable steady state. Counting residuals *exactly* is brittle,
though: two bins with residuals 41 and 42 are nearly interchangeable for future items but sit
in different buckets, which lets the rule "smooth out" a perfectly good residual and waste
space. To fix this I group nearby residuals into coarse bands (rounding to a grid of width Q)
and run the sum-of-squares objective over band counts. Among band-level ties, prefer the bin
with the largest remaining capacity (loosest fit) to spread load and avoid tiny unusable
residuals. The function keeps its own record of every opened bin; the harness opens unused
bins in index order, so used bins are always a prefix of the bin array. Each instance runs in
a fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
Q = 4                          # residual-band width for the smoothed histogram
NB = CAP // Q + 2              # number of bands (with a slot for residual 0)
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * NB                  # N[b]: open bins whose residual band is b


def _band(r):
    """Band index for a residual capacity r (0 means an empty/closed bin)."""
    if r <= 0:
        return 0
    return (r + Q - 1) // Q    # ceil(r/Q), so band 1 holds 1..Q, band 2 holds Q+1..2Q, ...


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        gb = _band(g)
        rb = _band(r)
        delta = -2 * _N[gb] + 1 + (2 * _N[rb] + 1 if r > 0 else 0)
        # primary: minimise delta; tiebreak: prefer larger residual (loosest fit)
        scores[k] = -(delta * 1000) + r
    r_new = CAP - s
    rb_new = _band(r_new)
    delta_new = 2 * _N[rb_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000) + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[_band(g)] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[_band(g - s)] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[_band(CAP - s)] += 1
    return scores
# EVOLVE-BLOCK-END

