# EVOLVE-BLOCK-START
"""Distribution-aware sum-of-squares rule.

Each item goes where it minimises the exact change in sum_g N(g)^2, where N(g) counts open bins
with remaining capacity g (0 < g < 100). This keeps open-bin capacities balanced so that future
items are likely to find good fits. Among near-equal sum-of-squares deltas we prefer the residual
that a future item is most likely to fill exactly, using a running histogram of item sizes seen so
far. This discourages prematurely creating residuals that no arriving item can consume.

The function keeps its own record of every opened bin (used bins are always a prefix of the bin
array because the harness opens unused bins in index order and ties go to the first bin). Each
instance runs in a fresh process so module state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = np.zeros(CAP + 2)      # running counts of arriving item sizes
_seen = 0.0                    # total items seen


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist, _seen
    s = int(item)

    # update running item-size distribution (for the tiebreak below)
    _hist[s] += 1.0
    _seen += 1.0

    # empirical probability that a future item exactly equals a residual r
    probs = _hist / _seen  # length CAP+2, index by size

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # exact change in sum_g N(g)^2: remove one bin of capacity g, add one of capacity r
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # tiebreak: prefer residuals likely to be filled by a future item (best future-fit)
        fill_bonus = (probs[r] * 1000.0) if r > 0 else 1000.0
        scores[k] = -(delta * 100000.0) + fill_bonus + r * 0.001

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    fill_new = (probs[r_new] * 1000.0) if r_new > 0 else 1000.0
    scores[len(fitting):] = -(delta_new * 100000.0) + fill_new + r_new * 0.001

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

