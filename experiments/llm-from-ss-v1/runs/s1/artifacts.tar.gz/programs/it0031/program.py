# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a distribution-aware residual bonus.

Each item goes where it minimises sum_g N(g)^2 (the online sum-of-squares objective), where N(g)
counts open bins with remaining capacity g (0 < g < 100). Among near-ties the choice is nudged by
an online histogram of recent item sizes: a residual that equals a frequently-seen item size is
valuable because a later item is likely to close that bin exactly, so we add a small bonus for it.
This keeps the sum-of-squares signal dominant while exploiting the (unknown but stationary)
Weibull-shaped size distribution. The harness opens unused bins in index order (ties go to the first
bin), so used bins are always a prefix of the bin array. Each instance runs in a fresh process, so
the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = np.zeros(CAP + 1)      # online histogram of seen item sizes (decayed)

DECAY = 0.999
BONUS = 0.3                    # weight of the residual-match bonus


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    global _hist
    _hist *= DECAY

    def bonus(r):
        if r <= 0:
            return 0.0
        return BONUS * _hist[r]

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta; nudge toward residuals matching frequent recent sizes;
        # tiebreak: prefer larger residual (loosest fit)
        scores[k] = -(delta * 1000) + bonus(r) + r * 1e-3
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000) + bonus(r_new) + r_new * 1e-3

    _hist[s] += 1.0

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
