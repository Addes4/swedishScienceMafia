# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a frequency-aware tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). SOS is the primary term; among exact SOS ties, prefer a residual
that matches a commonly-seen past item size (creating future perfect-fit opportunities),
falling back to loosest fit. A running histogram of item sizes supplies the frequency signal,
scaled strictly below one delta unit so it never overrides the SOS primary.
The harness opens unused bins in index order (ties go to the first bin), so used bins are
always a prefix of the bin array. Each instance runs in a fresh process, so module-level state
starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # frequency of past item sizes
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _freq, _seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # frequency-aware tiebreaker, strictly below one delta unit
        freq_term = _freq[r] / (_seen + 1.0) if r > 0 else 0.0
        scores[k] = -(delta * 1000.0) + freq_term * 500.0 + r * 1e-3
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    freq_new = _freq[r_new] / (_seen + 1.0) if r_new > 0 else 0.0
    scores[len(fitting):] = -(delta_new * 1000.0) + freq_new * 500.0 + r_new * 1e-3

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    _freq[s] += 1
    _seen += 1
    return scores
# EVOLVE-BLOCK-END
