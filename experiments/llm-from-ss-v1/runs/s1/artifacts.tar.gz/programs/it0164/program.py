# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an exact-fit-aware tiebreaker.

Each item goes where it minimises the change in sum_g N(g)^2, where N(g) counts open bins with
remaining capacity g (0 < g < 100). This is a strong proxy for the classic "minimise the number of
bins" objective because concentrating items into already-used bins keeps N(g) small.

Among exact sum-of-squares ties we prefer, in order:
  1. a bin whose post-placement residual exactly equals a size seen among past items (leftover
     capacity that is likely to be reused soon), choosing the smallest such residual;
  2. otherwise the bin with the largest remaining capacity (loosest fit), which spreads load and
     avoids prematurely creating tiny unusable residuals.

The function keeps its own record of every opened bin. The harness opens unused bins in index order
(ties go to the first bin), so used bins are always a prefix of the bin array. Each instance runs in a
fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_seen = [0] * (CAP + 1)        # _seen[s]: how many past items of size s we have observed


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta.  tiebreak: exact-fit-to-seen-size beats loosest fit.
        if r > 0 and _seen[r]:
            tie = 1000.0 - r * 0.01   # reward a reusable residual, smaller residual slightly better
        else:
            tie = float(r)            # loosest fit otherwise
        scores[k] = -(delta * 1000000.0) + tie
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if r_new > 0 and _seen[r_new]:
        tie_new = 1000.0 - r_new * 0.01
    else:
        tie_new = float(r_new)
    scores[len(fitting):] = -(delta_new * 1000000.0) + tie_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    _seen[s] += 1
    return scores
# EVOLVE-BLOCK-END

