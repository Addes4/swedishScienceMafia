# EVOLVE-BLOCK-START
"""Best-Fit rule with a fragmentation-aware tiebreaker.

Each item goes into the bin that leaves the smallest non-negative residual (best fit).
Best-fit is a strong classic online rule that packs nearly-full bins, avoiding the
fragmentation that loosest-fit can create. Among exact best-fit ties (same residual),
prefer a bin whose resulting residual already exists among open bins, since concentrating
equal residuals reduces the number of distinct leftovers and helps later exact fits.

The function keeps its own record of every opened bin. The harness opens unused bins in
index order (ties go to the first bin), so used bins are always a prefix of the bin array.
Each instance runs in a fresh process, so module-level state starts empty per instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # primary: minimise residual (best fit); tiebreak: prefer an already-present residual
        present = 1 if (r > 0 and _N[r] > 0) else 0
        scores[k] = -(r * 1000) + present

    r_new = CAP - s
    present_new = 1 if (r_new > 0 and _N[r_new] > 0) else 0
    scores[len(fitting):] = -(r_new * 1000) + present_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
