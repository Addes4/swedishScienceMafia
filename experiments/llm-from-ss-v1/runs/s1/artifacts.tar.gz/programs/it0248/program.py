# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with residual-matching tiebreaker.

Primary: minimise sum_g N(g)^2 (exact delta = 2*(N[r]-N[g]) + 1, 0 if r==0).
Tiebreak: prefer a resulting residual r that equals a current bin capacity g in an open bin
(so an existing open bin's leftover could be matched later), and finally loosest fit.
"""
import numpy as np

CAP = 100
_caps = []
_N = [0] * (CAP + 1)


def priority(item, bins):
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = 2 * (_N[r] - _N[g]) + 1 if r > 0 else 2 * (-_N[g]) + 1
        match = _N[r] if r > 0 else 0   # bins already holding residual r
        scores[k] = (-delta) * 1_000_000 + match * 1000 + r
    r_new = CAP - s
    delta_new = 2 * (_N[r_new] - 0) + 1 if r_new > 0 else 1
    match_new = _N[r_new] if r_new > 0 else 0
    scores[len(fitting):] = (-delta_new) * 1_000_000 + match_new * 1000 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
