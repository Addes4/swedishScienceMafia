# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a distribution-aware tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among exact sum-of-squares ties, prefer the residual that is most
"likely to be consumed" according to an empirical histogram of item sizes seen so far: a
residual r is valued by how often a past item equal to r (or close to r) occurred, which
gently pushes bins toward residuals that later items can fill exactly.

The function keeps its own record of every opened bin. The harness opens unused bins in
index order (ties go to the first bin), so used bins are always a prefix of the bin array.
Each instance runs in a fresh process, so the module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0] * (CAP + 1)        # empirical counts of past item sizes
_hist_total = 0
_SMOOTH = 1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist, _hist_total
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    inv_total = 1.0 / (_hist_total + _SMOOTH * CAP) if _hist_total >= 0 else 0.0
    base_prob = _SMOOTH * inv_total

    def resid_value(r):
        # Probability-ish weight that a future item exactly matches residual r.
        if r <= 0:
            return 0.0
        return (_hist[r] * inv_total) if r <= CAP else 0.0

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * 10000.0) + resid_value(r) * 100.0 + r * 1e-3

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 10000.0) + resid_value(r_new) * 100.0 + r_new * 1e-3

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    if 1 <= s <= CAP:
        _hist[s] += 1
        _hist_total += 1
    return scores
# EVOLVE-BLOCK-END
