# EVOLVE-BLOCK-START
"""Best-Fit with loosest-fit tiebreaker.

Each item goes into the fitting bin that leaves the smallest positive residual (classic
best-fit), which packs tightly and closes bins efficiently. Among exact residual ties, prefer
the bin with the largest remaining capacity (loosest fit) to avoid prematurely locking in
tight bins. The function keeps its own record of every opened bin. The harness opens unused
bins in index order (ties go to the first bin), so used bins are always a prefix of the bin
array. Each instance runs in a fresh process, so the module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # primary: minimise residual (best fit); tiebreak: prefer larger original gap
        scores[k] = -r * 1000 + g
    r_new = CAP - s
    scores[len(fitting):] = -r_new * 1000 + CAP

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _caps[j] = g - s
    else:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END

