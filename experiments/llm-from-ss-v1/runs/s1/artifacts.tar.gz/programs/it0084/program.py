# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a capacity-aware pairing tiebreak.

Primary objective: place the item where it minimises the change in sum_g N(g)^2,
where N(g) counts open bins with remaining capacity g (0 < g < 100). This is an
exact integer delta so there is no overflow.

Secondary (tiebreak): among placements with identical integer delta, prefer the
residual r that is most "useful" for future items. Usefulness is measured with a
small, bounded score computed from the current residual histogram: a residual
that closes a bin (r == 0) is best, a residual that equals an already-open
capacity (so a future item can fill it exactly) is good, and otherwise prefer
larger residuals so load is spread and tiny unusable residuals are avoided.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.int64)

    def tie(r):
        # bounded usefulness score in [0, ~1000]
        base = r                       # spread load: prefer larger residual
        if r == 0:
            base += 200                # closing a bin is excellent
        elif r <= CAP and _N[r] > 0:
            base += 100                # residual matches an already-open capacity
        return base

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # lexicographic: primary minimises delta, secondary maximises tie(r)
        scores[k] = -(delta * 4096) + tie(r)
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 4096) + tie(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
