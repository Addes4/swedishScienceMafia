# EVOLVE-BLOCK-START
"""Global sum-of-squares rule.

Each arrived item is placed so as to minimise the exact increase in sum_g N(g)^2, where
N(g) counts open bins with remaining capacity g (0 < g < 100).  The increase caused by
moving a bin from capacity g to residual r = g - s is

    dN(r)^2 + 1  -  (dN(g)^2 - 1)   =  2*N(r) + 1 - (2*N(g) - 1)   (for r > 0)

and for a brand new bin (g = 100, which is not counted in N) the increase is 2*N(r) + 1.

Ties in the SOS cost are broken by preferring the largest residual (loosest fit), which
keeps loads spread and avoids producing tiny residuals that rarely match later items.

State: the function records every bin it opens, in bin-index order.  The harness opens
unused bins in index order (ties go to the first bin), so used bins always form a prefix
of the array `bins`.  A fresh process per instance keeps the module state empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: opened bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a score for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    SCALE = 1e9  # large enough that SOS cost strictly dominates the residual tiebreak

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # exact increase in sum N(g)^2
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * SCALE) + r

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * SCALE) + r_new

    choice = int(np.argmax(scores))          # harness picks first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

