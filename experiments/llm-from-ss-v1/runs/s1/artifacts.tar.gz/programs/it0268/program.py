# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a distinct-residual tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). This is the standard "best-fit-like" SOS ranking. Among exact
sum-of-squares ties, prefer the candidate whose new residual merges into an already-existing
residual capacity (minimising the number of distinct residual values), and only then fall
back to the largest residual (loosest fit).

The function keeps its own record of every opened bin. The harness opens unused bins in
index order (ties go to the first bin), so used bins are always a prefix of the bin array.
Each instance runs in a fresh process, so module-level state starts empty every time.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)

    n_used = len(_caps)
    fitting = []               # (position in scores, bin index in _caps)
    for j in range(n_used):
        if _caps[j] >= s:
            fitting.append(j)
    n_fit = len(fitting)
    n_unused = len(bins) - n_fit

    scores = np.empty(len(bins), dtype=np.float64)

    # Score each fitting used bin.
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # SOS delta: -2*N[g]+1 (removing from g) plus adding to r if r>0.
        delta = -2 * _N[g] + 1
        if r > 0:
            delta += 2 * _N[r] + 1
        # tiebreaker: merging (r already exists) is better -> smaller distinct count.
        merge = 1 if (r > 0 and _N[r] > 0) else 0
        scores[k] = -(delta * 100000) + merge * 1000 + r

    # Unused bins (capacity 100): all identical.
    r_new = CAP - s
    delta_new = (2 * _N[r_new] + 1) if r_new > 0 else 0
    merge_new = 1 if (r_new > 0 and _N[r_new] > 0) else 0
    scores[n_fit:] = -(delta_new * 100000) + merge_new * 1000 + r_new

    choice = int(np.argmax(scores))          # harness's choice: first highest score
    if choice < n_fit:
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

