# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a pairing-aware tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100).  Among exact sum-of-squares ties the placement is preferred whose resulting residual
already exists among the open bins (so a future item can close a bin cleanly); otherwise the looser
(larger) residual wins.  The exact tie comparison is done with Python integers so it is fully
lexicographic and free of floating-point scaling artefacts.
The function keeps its own record of every opened bin.  The harness opens unused bins in index order
(ties go to the first bin), so used bins are always a prefix of the bin array.  Each instance runs in
a fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Build integer lexicographic keys; smaller key = better placement.
    keys = []
    for j in fitting:
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        pair = 0 if (r > 0 and _N[r] > 0) else 1     # prefer pairing with an open residual
        keys.append((delta, pair, -r))               # then prefer larger residual
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    new_pair = 0 if (r_new > 0 and _N[r_new] > 0) else 1
    new_key = (delta_new, new_pair, -r_new)

    if n_unused > 0:
        keys.extend([new_key] * n_unused)

    # Map keys to scores: smaller key -> higher score, order-preserving.
    order = sorted(range(len(keys)), key=lambda i: keys[i])
    for rank, i in enumerate(order):
        scores[i] = -rank

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
