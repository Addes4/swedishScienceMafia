# EVOLVE-BLOCK-START
"""Best-fit with an anti-fragmentation penalty.

Rank each candidate bin by the residual r it would leave, preferring the smallest r
(classic Best Fit). To counter Best Fit's tendency to strand tiny residuals that no
future item can use, subtract a small penalty whenever the residual falls strictly
below the historical minimum item size observed so far -- such a bin is effectively
dead capacity, so avoid producing it unless there is no better option.

The function keeps its own record of every opened bin. The harness opens unused bins
in index order (ties go to the first bin), so used bins are always a prefix of the bin
array. Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_min_item = [CAP + 1]          # smallest item size seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest score."""
    global _caps
    s = int(item)
    if s < _min_item[0]:
        _min_item[0] = s
    min_item = _min_item[0]

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        pen = 1.0 if (0 < r < min_item) else 0.0
        # primary: prefer smallest residual (best fit); penalty discourages dead capacity
        scores[k] = -(r + pen)

    r_new = CAP - s
    pen_new = 1.0 if (0 < r_new < min_item) else 0.0
    scores[len(fitting):] = -(r_new + pen_new)

    choice = int(np.argmax(scores))          # first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _caps[j] = g - s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END

