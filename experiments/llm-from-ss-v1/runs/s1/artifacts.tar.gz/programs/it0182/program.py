# EVOLVE-BLOCK-START
"""Usefulness-weighted Sum-of-Squares rule with a loosest-fit tiebreaker.

Classic SOS minimises sum_g N(g)^2 over open-bin residual capacities g. That rule assumes every
residual is equally useful in the future, but here the item distribution is Weibull-shaped with
mean ~40, so a residual of 3 is nearly worthless while a residual of ~40 is very valuable.

We keep the SOS structure but weight each residual bucket by a usefulness factor w(g):
useless residuals (below the smallest item seen recently) contribute ~0, and usefulness rises
to a peak near the running mean item size. This penalises fragmenting *useful* residuals while
letting tiny dead residuals be consumed cheaply. Loosest-fit is kept as the tiebreaker.

The function records every opened bin. The harness opens unused bins in index order, so used bins
form a prefix of the bin array. Each instance runs in a fresh process, so module state is empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# running statistics of past items, used to shape the usefulness weighting
_min_item = CAP                 # smallest item size seen so far (starts large)
_sum_item = 0.0
_cnt_item = 0
_mean_item = 40.0              # running mean item size


def _weight(g):
    """Usefulness weight of a residual capacity g in (0, CAP)."""
    if g <= 0:
        return 0.0
    # dead residual: smaller than any item we have seen -> worthless
    if g < _min_item:
        return 0.05
    # usefulness grows toward the mean item size, then flattens (larger is still fine)
    if g <= _mean_item:
        return 0.4 + 0.6 * (g / _mean_item)
    return 1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _min_item, _sum_item, _cnt_item, _mean_item
    s = int(item)

    # update running item statistics (excluding the very first few for stability)
    if _cnt_item > 0:
        _min_item = min(_min_item, s)
    else:
        _min_item = s
    _sum_item += s
    _cnt_item += 1
    _mean_item = _sum_item / _cnt_item

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        wg = _weight(g)
        wr = _weight(r) if r > 0 else 0.0
        # weighted change in sum w(g) N(g)^2: removing one g, adding one r
        delta = -wg * (2 * _N[g] - 1) + (wr * (2 * _N[r] + 1) if r > 0 else 0.0)
        scores[k] = -(delta * 1000.0) + r
    r_new = CAP - s
    wr_new = _weight(r_new) if r_new > 0 else 0.0
    delta_new = wr_new * (2 * _N[r_new] + 1) if r_new > 0 else 0.0
    scores[len(fitting):] = -(delta_new * 1000.0) + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
