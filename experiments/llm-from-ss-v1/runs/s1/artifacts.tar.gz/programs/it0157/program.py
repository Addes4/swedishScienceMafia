# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a residual-usefulness tiebreak.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among exact sum-of-squares ties, prefer the placement whose
resulting residual is a size that has been observed frequently among past items, since such
residuals are likely to be exactly filled later. The function keeps its own record of every
opened bin. The harness opens unused bins in index order (ties go to the first bin), so used
bins are always a prefix of the bin array. Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_item_freq = [0] * (CAP + 1)   # observed frequency of item sizes 1..100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _item_freq
    s = int(item)
    _item_freq[s] += 1

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # large scale for SOS delta (primary), smaller scale for the residual preference
    BIG = 1e9

    def resid_bonus(r):
        if r <= 0:
            return 0.0
        return _item_freq[r]

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * BIG) + resid_bonus(r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * BIG) + resid_bonus(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

