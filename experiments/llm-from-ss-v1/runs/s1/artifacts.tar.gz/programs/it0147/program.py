# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an "expected-fill" tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among exact sum-of-squares ties, prefer the bin whose remaining
capacity is closest to the running mean of item sizes seen so far (seeded at 40, the known
distribution mean). A residual near a typical future item size is the most likely to be
exactly matched by a single later item, so this ties the SOS spread with a mild
"exact-fill-odds" signal, without changing the proven primary objective. Each instance
runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_sum_items = 0.0
_cnt_items = 0
_MEAN0 = 40.0                  # seed = distribution mean


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _sum_items, _cnt_items
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # running mean of item sizes (updated after scoring; used as target residual)
    mean = (_sum_items / _cnt_items) if _cnt_items > 0 else _MEAN0

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta; tiebreak: residual closest to typical item size
        close = -abs(r - mean)
        scores[k] = -(delta * 1000.0) + close
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000.0) - abs(r_new - mean)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    _sum_items += s
    _cnt_items += 1
    return scores
# EVOLVE-BLOCK-END

