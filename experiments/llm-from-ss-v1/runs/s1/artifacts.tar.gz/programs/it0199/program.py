# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a loosest-fit tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among exact sum-of-squares ties, prefer the bin with the largest
remaining capacity (loosest fit), which spreads load and avoids prematurely creating tiny
unusable residuals. Bookkeeping is kept in numpy arrays for speed.
"""
import numpy as np

CAP = 100
_rem = np.zeros(0, dtype=np.int64)     # remaining capacity of every opened bin, in bin order
_N = np.zeros(CAP + 1, dtype=np.int64) # N[g]: open bins with remaining capacity g


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _rem, _N
    s = int(item)
    n = len(bins)

    if _rem.size == 0:
        scores = np.empty(n, dtype=np.float64)
        # all bins unused
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        scores[:] = -(delta_new * 1000) + r_new
        # harness will pick first bin; record the new bin
        _rem = np.array([r_new], dtype=np.int64)
        if r_new > 0:
            _N[r_new] += 1
        return scores

    fitmask = _rem >= s
    opened = _rem.size
    n_unused = n - opened
    scores = np.empty(n, dtype=np.float64)

    if opened > 0:
        g_fit = _rem[fitmask]
        r_fit = g_fit - s
        deltas = -2 * _N[g_fit] + 1
        rr = r_fit[r_fit > 0]
        deltas[r_fit > 0] += 2 * _N[rr] + 1
        scores[:opened][fitmask] = -(deltas * 1000.0) + r_fit
        scores[:opened][~fitmask] = -np.inf

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[opened:] = -(delta_new * 1000.0) + r_new

    choice = int(np.argmax(scores))
    if choice < opened and fitmask[choice]:
        g = int(_rem[choice])
        _N[g] -= 1
        r = g - s
        _rem[choice] = r
        if r > 0:
            _N[r] += 1
    elif n_unused > 0:
        _rem = np.append(_rem, r_new)
        if r_new > 0:
            _N[r_new] += 1
    return scores
# EVOLVE-BLOCK-END
