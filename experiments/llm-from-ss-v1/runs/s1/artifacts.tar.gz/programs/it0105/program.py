# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a smooth anti-fragmentation secondary term.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). The brittle integer ties of the raw delta are broken not by an
arbitrary loosest/best rule but by a smooth real-valued term: among placements the primary
delta plus a small penalty for tiny residuals (1/(r+1)) and a mild preference for larger
residuals. This blends load-spreading with avoidance of unusable 1-slot fragments.

State: the function keeps its own record of every opened bin. The harness opens unused bins
in index order (ties go to the first bin), so used bins are always a prefix of the bin array.
Each instance runs in a fresh process, so the module-level state starts empty per instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

_SQ = 1000.0                   # weight so the integer sum-of-squares delta dominates


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta (scaled). secondary: smoother residual preference.
        # penalise tiny residuals but otherwise prefer larger residuals mildly.
        sec = r - 40.0 / (r + 1.0)
        scores[k] = -(delta * _SQ) + sec
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    sec_new = r_new - 40.0 / (r_new + 1.0)
    scores[len(fitting):] = -(delta_new * _SQ) + sec_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
