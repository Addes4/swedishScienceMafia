# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a learned perfect-fit tiebreaker.

Primary objective: minimise the sum-of-squares of the residual-capacity histogram
(delta = -2*N[g] + 1 + (2*N[r]+1 if r>0 else 0)). This is a strong online rule.

Ties are broken by preferring a residual r that equals a "hot" item size (a size that
has appeared often recently), because such a bin can very likely be exactly filled by a
future item. A decaying histogram of past item sizes supplies the hotness weight.
Final fallback: loosest fit (largest residual), which spreads load.

State: _caps (remaining capacity of each opened bin, in index order), _N (histogram of
open residuals) and _hot (decaying counts of past item sizes). Fresh process per instance.
"""
import numpy as np

CAP = 100
_caps = []                      # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)            # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hot = [0.0] * (CAP + 1)        # decaying weight per item size 1..CAP
_DECAY = 0.90


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hot
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        hot = _hot[r] if r > 0 else 0.0
        # primary: minimise delta; secondary: hot residual; tertiary: loosest fit
        scores[k] = -(delta * 1e6) + hot * 1e3 + r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    hot_new = _hot[r_new] if r_new > 0 else 0.0
    scores[len(fitting):] = -(delta_new * 1e6) + hot_new * 1e3 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update decaying histogram of item sizes
    for sz in range(1, CAP + 1):
        _hot[sz] *= _DECAY
    _hot[s] += 1.0
    return scores
# EVOLVE-BLOCK-END
