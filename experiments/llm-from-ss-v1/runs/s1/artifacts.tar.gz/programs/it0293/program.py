# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a waste-aware tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). The true marginal delta of this objective is
    delta = -2*N[g] + 1 + (2*N[r] + 1 if r > 0 else 0)
where g is the chosen bin's capacity, r = g - s its residual, and opening a fresh bin gives
    delta_new = (2*N[r_new] + 1 if r_new > 0 else 0),  r_new = 100 - s.

Among exact sum-of-squares ties, prefer the placement that does NOT create an unusable
orphan bin (a residual smaller than ORPHAN_T, i.e. a bin that can essentially never be
filled again), and break any remaining tie by loosest fit (largest residual). This reduces
stranded capacity without disturbing the strong SOS primary objective.

The function keeps its own record of every opened bin. The harness opens unused bins in
index order (ties go to the first bin), so used bins are always a prefix of the bin array.
Each instance runs in a fresh process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
ORPHAN_T = 5                    # capacity strictly below this counts as an unusable orphan
_caps = []                      # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)            # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _orphans_after(g, s):
    """Number of orphan bins (capacity < ORPHAN_T) after placing size s into capacity g."""
    r = g - s
    # current orphans (approx from the global count below threshold) plus the change
    add = 1 if (0 < r < ORPHAN_T) else 0
    return add


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # baseline orphan count over current open bins (capacity < ORPHAN_T)
    base_orphans = sum(_N[t] for t in range(1, ORPHAN_T))

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        new_orphans = base_orphans
        # remove old orphan status of this bin
        if g < ORPHAN_T:
            new_orphans -= 1
        # add new orphan status of resulting residual
        if 0 < r < ORPHAN_T:
            new_orphans += 1
        scores[k] = -(delta * 1000) - new_orphans + (r / 1000.0)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    new_orphans_new = base_orphans + (1 if 0 < r_new < ORPHAN_T else 0)
    scores[len(fitting):] = -(delta_new * 1000) - new_orphans_new + (r_new / 1000.0)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
