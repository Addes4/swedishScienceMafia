# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an empirical future-fit value for residuals.

The primary rule minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100); ties go to the tighter fit. A secondary term estimates, from
the online item-size histogram, how likely a residual r is to be filled later (by a
future item of size <= r), and rewards residuals that are more likely to be reused. This
keeps tight fits valuable without the cruder fixed tiny-residual penalty.

The function keeps its own record of every opened bin. The harness opens unused bins in
index order (ties go to the first bin), so used bins are always a prefix of the bin array.
Each instance runs in a fresh process, so the module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                       # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)             # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0] * (CAP + 1)          # _hist[v]: number of items of size v seen so far
_seen = 0                        # total items seen

# cumulative "mass of items <= v" cache, recomputed lazily
_mass = None


def _build_mass():
    global _mass
    m = [0] * (CAP + 2)
    c = 0
    for v in range(1, CAP + 1):
        c += _hist[v]
        m[v] = c
    m[0] = 0
    _mass = m


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _hist, _seen, _mass
    s = int(item)

    # update online item histogram for future-fit estimates
    _hist[s] += 1
    _seen += 1
    _build_mass()

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    total = _seen if _seen > 0 else 1
    scale = float(total)

    def future_fit_value(r):
        # Empirical expected count of future items that could fit in a residual of size r.
        # Probability an item has size <= r, times typical number of remaining items.
        if r <= 0:
            return 0.0
        if r >= CAP:
            prob = 1.0
        else:
            prob = _mass[r] / scale
        # weight by r too, since a larger residual can absorb more distinct sizes
        return prob * r

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * 1000 + r) + future_fit_value(r)
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000 + r_new) + future_fit_value(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
