# EVOLVE-BLOCK-START
"""Best-fit variant.

Place each item into the fitting bin that leaves the smallest nonzero residual (best fit),
which packs tightly and tends to reduce bin count on this distribution.
"""
import numpy as np

CAP = 100


def priority(item, bins):
    s = int(item)
    scores = bins.astype(np.float64).copy()
    # residual after placing; smaller is better => negate.
    # unused bins (cap 100) get residual 100-s, naturally ranked last when tighter fits exist.
    scores = -scores  # highest score = smallest remaining capacity = best fit
    return scores
# EVOLVE-BLOCK-END
