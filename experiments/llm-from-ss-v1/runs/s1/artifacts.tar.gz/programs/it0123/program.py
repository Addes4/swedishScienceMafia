# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a loosest-fit tiebreaker and a small perfect-fill bonus.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). To nudge toward placements that are structurally good for future items, we add a small
bonus when the resulting residual is 0 (bin closes) or equals the current item size (likely to be closed
by an identical future item). Among ties, prefer the bin with the largest remaining capacity (loosest
fit), spreading load and avoiding tiny unusable residuals. The function keeps its own record of every
opened bin; used bins are always a prefix of the harness array since ties go to the first bin.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        bonus = 0
        if r == 0:
            bonus = 2
        elif r == s:
            bonus = 1
        # primary: minimise delta (scaled); secondary: perfect-fill bonus; tertiary: loosest fit
        scores[k] = -(delta * 1000) + (bonus * 50) + r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000) + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
