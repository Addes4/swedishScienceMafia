# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a complementarity-aware tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). The exact integer delta is the primary key (no scaling, so ties are
genuine). Among exact sum-of-squares ties, rank by a principled tiebreaker:
  1. prefer a residual r whose complement (100 - r) is already an open capacity, so the two
     bins can be closed together by a single future item of that complement size;
  2. then prefer r that already matches an open capacity (keeps capacity classes clustered);
  3. then prefer the largest residual (loosest fit), spreading load.
The function keeps its own record of every opened bin; the harness opens unused bins in index
order, so used bins form a prefix. Each instance runs in a fresh process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _secondary(r):
    """Tiebreaker score for residual r (higher is better)."""
    # (1) complement already open -> can be paired and closed by one future item
    comp = CAP - r
    c1 = 1 if (r > 0 and comp > 0 and _N[comp] > 0) else 0
    # (2) residual matches an already-open capacity
    c2 = 1 if (r > 0 and _N[r] > 0) else 0
    # (3) loosest fit: prefer larger residual
    return (c1 * 1_000_000) + (c2 * 100_000) + r


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * 1_000_000_000) + _secondary(r)
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1_000_000_000) + _secondary(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

