# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a distribution-aware tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer the bin whose residual, after placing the item,
is most likely to be exactly matched by a future item, estimated from the empirical histogram of the
items seen so far. This keeps the strong sum-of-squares primary objective while breaking ties in a way
that adapts to the actual item-size distribution.

The function keeps its own record of every opened bin. The harness opens unused bins in index order
(ties go to the first bin), so used bins are always a prefix of the bin array. Each instance runs in a
fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_item_count = [0] * (CAP + 1)  # histogram of item sizes seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _item_count
    s = int(item)
    _item_count[s] += 1
    total = sum(_item_count)

    # Probability mass concentrated near each residual: how likely is a future item to fit a residual r
    # exactly or nearly? We compute a smoothed opportunity score for each residual value.
    def opp(r):
        if r <= 0:
            return 0.0
        # how much probability mass sits at size r (exact fill) and at sizes just above r (near fits)
        exact = _item_count[r]
        # small smoothed estimate: probability an item exactly equals r
        return exact / total if total > 0 else 0.0

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta; tiebreak: prefer residual most likely to be exactly refilled
        scores[k] = -(delta * 1000.0) + opp(r)
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000.0) + opp(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
