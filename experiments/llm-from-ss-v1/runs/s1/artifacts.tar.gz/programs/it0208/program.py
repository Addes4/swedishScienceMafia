# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a residual-targeting tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer the bin that leaves a residual equal to a
frequently-seen recent item size (so a later item can fill it exactly), then a residual of 0
(perfectly filled), then the largest remaining capacity (loosest fit).
The function keeps its own record of every opened bin. The harness opens unused bins in index order
(ties go to the first bin), so used bins are always a prefix of the bin array. Each instance runs in a
fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_seen = [0] * (CAP + 1)        # frequency of recent item sizes (decayed)
_decay = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _seen, _decay
    s = int(item)
    _decay += 1
    # decay past item counts every so often to stay recent
    if _decay >= 200:
        _decay = 0
        for k in range(1, CAP + 1):
            _seen[k] >>= 1
    _seen[s] += 1

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    n = len(bins)
    scores = np.empty(n, dtype=np.float64)

    def key(g):
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta. secondary: prefer residual that is a seen size, then r==0, then large r
        dup = _seen[r] if r > 0 else 0
        return (-delta, dup, 1 if r == 0 else 0, r)

    for k, j in enumerate(fitting):
        a, b, c, d = key(_caps[j])
        scores[k] = ((a * 1000000 + b) * 4 + c) * 1000 + d
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    dup = _seen[r_new] if r_new > 0 else 0
    scores[len(fitting):] = (((-delta_new) * 1000000 + dup) * 4 + (1 if r_new == 0 else 0)) * 1000 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
