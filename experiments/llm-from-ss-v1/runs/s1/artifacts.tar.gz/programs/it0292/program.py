# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a residual-matching tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer the bin whose resulting residual is closest to
the most common existing open-bin residual (whichever positive gap is currently most frequent), since
matching an existing gap size makes it likelier that a later item exactly fills it. Final fallback is
loosest fit (larger residual). The function keeps its own record of every opened bin; used bins are a
prefix of the bin array, and each instance runs in a fresh process so module state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _common_residual():
    """Return the currently most frequent positive residual size (0 if none)."""
    best_g = 0
    best_c = 0
    for g in range(1, CAP):
        c = _N[g]
        if c > best_c:
            best_c = c
            best_g = g
    return best_g


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    target = _common_residual()

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta; tiebreak: match the most common residual, then loosest fit
        scores[k] = -(delta * 100000.0) - abs(r - target) + r * 1e-4
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 100000.0) - abs(r_new - target) + r_new * 1e-4

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
