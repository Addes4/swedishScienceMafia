# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an adaptive residual-frequency tiebreaker.

Primary term: minimise the sum-of-squares increment (dominant, strong online packing rule).
Secondary term (scaled strictly below one SOS delta unit): among near-ties, prefer leaving a
residual that has historically been a common incoming item size, i.e. a residual most likely to
be filled by a future item. A small item-size histogram is learned online from past arrivals.
Bins are kept in bin-index order (unused bins form a suffix), so we track every opened bin.
"""
import numpy as np

CAP = 100
_caps = []                       # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)             # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = np.zeros(CAP + 1)        # historical counts of arriving item sizes
_total = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist, _total
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # adaptive residual attractiveness: probability that a future item equals residual r
    if _total > 0:
        p = _hist / _total
    else:
        p = None

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        bonus = p[r] if (p is not None and r > 0) else 0.0
        # primary SOS delta dominates; sub-unit bonus prefers likely-to-be-filled residuals
        scores[k] = -(delta * 1000.0) + bonus * 100.0 + r * 1e-3
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    bonus_new = p[r_new] if (p is not None and r_new > 0) else 0.0
    scores[len(fitting):] = -(delta_new * 1000.0) + bonus_new * 100.0 + r_new * 1e-3

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update learned item-size histogram
    _hist[s] += 1
    _total += 1
    return scores
# EVOLVE-BLOCK-END
