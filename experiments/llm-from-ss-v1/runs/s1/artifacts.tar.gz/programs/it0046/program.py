# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a residual-frequency bonus and loosest-fit tiebreak.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Onto that objective we add a small bonus for a bin whose resulting
residual matches an item size often seen in the past, since such residuals are likely to be
closed by a future item exactly. Among near-ties, prefer the bin with the largest remaining
capacity (loosest fit). The function keeps its own record of every opened bin and a running
histogram of item sizes. The harness opens unused bins in index order (ties go to the first
bin), so used bins are always a prefix of the bin array. Each instance runs in a fresh process,
so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # count of past items of each size


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _freq
    s = int(item)
    _freq[s] += 1
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise sum-of-squares change; small bonus if residual is a common size
        bonus = _freq[r] if r > 0 else 0
        scores[k] = -(delta * 1000) + bonus * 0.5 + r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    bonus_new = _freq[r_new] if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000) + bonus_new * 0.5 + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
