# EVOLVE-BLOCK-START
"""Lexicographic sum-of-squares rule with a pairing bonus.

Primary key: the exact change in sum_g N(g)^2 caused by placing the item in a bin.
Secondary key: a small integer bonus. Closing a bin (residual 0) or creating a residual equal to
some already-open residual gets the largest bonus (these residuals form pairs and can be filled
later). All other placements get a bonus of 0.
Integer packing guarantees truly lexicographic comparison without float precision loss.
The function keeps its own record of every opened bin; used bins are always a prefix of the array.
Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

BIG = 1000                     # multiplier for the exact sum-of-squares delta


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.int64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        if r == 0:
            bonus = 2                       # cleanly closes a bin
        elif _N[r] > 0:
            bonus = 1                       # residual pairs with an existing open residual
        else:
            bonus = 0
        scores[k] = -(delta * BIG) + bonus

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if _N[r_new] > 0:
        bonus_new = 1
    else:
        bonus_new = 0
    scores[len(fitting):] = -(delta_new * BIG) + bonus_new

    choice = int(np.argmax(scores))          # harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
