# EVOLVE-BLOCK-START
"""Sum-of-squares rule with an empirical-histogram tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Many exact ties occur, so ties are broken by preferring the placement whose residual is
most likely to be exactly reusable by a future item: we keep an empirical histogram of item sizes seen
so far and score a residual r by the (smoothed) frequency of items that would exactly fill it. This
falls back to loosest fit when no size information distinguishes candidates.

The function keeps its own record of every opened bin. The harness opens unused bins in index order
(ties go to the first bin), so used bins are always a prefix of the bin array. Each instance runs in a
fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0.0] * (CAP + 1)      # smoothed empirical counts of item sizes seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _hist
    s = int(item)
    # update item-size histogram with a small amount of decay so it tracks the distribution
    for g in range(1, CAP + 1):
        _hist[g] *= 0.999
    _hist[s] += 1.0

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    def tiebreak(r):
        # prefer residuals that are exactly reusable (frequent residual == frequent item size)
        if 1 <= r < CAP:
            return _hist[r]
        return 0.0

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * 10000) + tiebreak(r) * 10.0 + r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 10000) + tiebreak(r_new) * 10.0 + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
