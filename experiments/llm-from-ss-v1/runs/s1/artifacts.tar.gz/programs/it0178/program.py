# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a mean-aware tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer the bin whose residual after placement is
closest to the running mean item size (so leftover space best matches the typical next item),
breaking remaining ties toward the loosest fit (largest residual).
The function keeps its own record of every opened bin. The harness opens unused bins in index order
(ties go to the first bin), so used bins are always a prefix of the bin array. Each instance runs in a
fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_sum = 0                       # sum of past item sizes
_cnt = 0                       # number of past items


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _sum, _cnt
    s = int(item)
    mean = (_sum / _cnt) if _cnt else 50.0
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # secondary: residual closest to running mean; prefer 0 too; fallback loosest fit
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        tie = -abs(r - mean) * 10 - r * 0.001
        scores[k] = -(delta * 10000.0) + tie
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    tie_new = -abs(r_new - mean) * 10 - r_new * 0.001
    scores[len(fitting):] = -(delta_new * 10000.0) + tie_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    _sum += s
    _cnt += 1
    return scores
# EVOLVE-BLOCK-END
