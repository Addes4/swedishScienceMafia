# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an empirical "fillable residual" secondary term.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). The sum-of-squares term is the dominant signal (keeps the classic good global behavior).
As a secondary signal, among near-equal sum-of-squares candidates, we prefer the residual that matches
a common past item size, since such a residual is more likely to be filled exactly later.

The harness opens unused bins in index order (ties go to the first bin), so used bins are always a
prefix of the bin array. Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_size_count = [0] * (CAP + 1)  # empirical counts of arriving item sizes
_size_total = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _size_count, _size_total
    s = int(item)
    _size_count[s] += 1
    _size_total += 1

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # empirical fillability weight: fraction of past items equal to residual r (plus small prior)
    inv_total = 1.0 / (_size_total + 1.0)

    def secondary(r):
        # reward residual values that are common item sizes (likely to be filled exactly)
        if r <= 0:
            return 0.0
        freq = _size_count[r] * inv_total
        # tiny residuals are still mildly discouraged (hard to fill exactly with large items)
        tiny = 3.0 if r <= 3 else 0.0
        return 4.0 * freq - tiny

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * 1000) + secondary(r)
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000) + secondary(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

