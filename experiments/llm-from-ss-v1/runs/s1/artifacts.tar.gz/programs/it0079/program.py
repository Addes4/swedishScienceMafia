# EVOLVE-BLOCK-START
"""Best-fit with a residual-utility threshold.

Items arrive online. Each item should go into the fullest bin it fits in, but not so full
that the residual becomes too small to be usable by future (mean ~40) items. We therefore
score each bin by a lexicographic integer key:

  primary  : residual positivity (bin must fit; residual < CAP is preferred to staying empty
             only when it is worthwhile)
  key      : maximise the threshold t (the largest t in a descending ladder) such that
             residual r = g - s still satisfies r >= t, i.e. we prefer the tougest bin whose
             residual is still useful; among those, prefer the smallest residual (best fit).

Bins with residual below the smallest useful threshold get progressively worse scores, so
they are only used when nothing better exists; unused bins (capacity 100) are worst.

The function keeps its own record of open bins. Unused bins are opened in index order, so
used bins form a prefix of the array. State is per-instance (fresh process each time).
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, bin-index order

# descending utility ladder for residuals: prefer residuals >= these values
_LADDER = [50, 40, 30, 20, 10, 5, 1]


def priority(item, bins):
    """Return a score per bin; the item goes into the bin with the highest (first on ties)."""
    global _caps
    s = int(item)
    n_opened = len(_caps)
    n_unused = len(bins) - n_opened
    scores = np.empty(len(bins), dtype=np.float64)

    for j in range(n_opened):
        g = _caps[j]
        r = g - s
        if r < 0:
            scores[j] = -1e18
            continue
        # find best ladder rank for residual r
        rank = len(_LADDER)  # worse than all ladder entries
        for i, t in enumerate(_LADDER):
            if r >= t:
                rank = i
                break
        # primary: lower rank is better. secondary: smaller residual is better (best fit).
        scores[j] = -rank * 1000.0 - r

    # unused bins: treat as residual CAP - s but ranked worse than any opened bin usage
    r_new = CAP - s
    rank_new = len(_LADDER)
    for i, t in enumerate(_LADDER):
        if r_new >= t:
            rank_new = i
            break
    scores[n_opened:] = -rank_new * 1000.0 - r_new - 1e6

    choice = int(np.argmax(scores))
    if choice < n_opened:
        g = _caps[choice]
        _caps[choice] = g - s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END

