# EVOLVE-BLOCK-START
"""Best-Fit rule with loosest-fit tiebreaker.

Classic Best-Fit: place the item into the bin with the smallest remaining capacity that
still fits it. This minimizes fragmentation among open bins and is the strongest simple
online rule for this capacity/item-size regime. Ties (equal residual) are broken by the
larger remaining capacity (loosest fit) via the harness's first-max rule.
The harness opens unused bins in index order, so used bins are always a prefix of the
bin array. Module-level state starts empty in each fresh instance process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps
    s = int(item)
    n_open = len(_caps)
    scores = np.empty(len(bins), dtype=np.float64)

    # Used bins: score = -residual (best fit -> minimal positive residual wins),
    # minus a tiny loosest-fit bonus so larger capacity wins exact ties.
    for j in range(n_open):
        g = _caps[j]
        if g >= s:
            r = g - s
            scores[j] = -(r * 1.0) + g * 1e-6
        else:
            scores[j] = -np.inf

    # Unused bins: residual = 100 - s, prefer largest capacity on ties.
    r_new = CAP - s
    for j in range(n_open, len(bins)):
        scores[j] = -(r_new * 1.0) + CAP * 1e-6

    choice = int(np.argmax(scores))
    if choice < n_open:
        _caps[choice] -= s
    else:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END

