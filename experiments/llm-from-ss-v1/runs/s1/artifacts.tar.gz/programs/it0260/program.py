# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a learned residual-preference tiebreaker.

Primary rule: place each item to minimise the increase of sum_g N(g)^2, where N(g) counts open
bins with remaining capacity g (0 < g < 100). This tends to keep the residual distribution uniform,
which empirically packs well under a stable random item distribution.

Tiebreak: among placements with an identical SOS increment, prefer the placement whose resulting
residual is most "useful" according to a slowly-learned preference over residuals. The preference
is derived from a running histogram of arriving item sizes: a residual r is valuable if it equals a
frequently-seen item size (a future perfect fit). The preference is scaled strictly below one SOS
delta unit so the primary SOS term always dominates, and it is only applied after a warmup period.

The function keeps its own record of every opened bin. The harness opens unused bins in index
order (ties go to the first bin), so used bins are always a prefix of the bin array. Each instance
runs in a fresh process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = np.zeros(CAP + 1)      # running histogram of past item sizes
_count = 0                     # number of items seen so far
_WARMUP = 200


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist, _count
    s = int(item)

    # update running item-size histogram (before scoring, harmless)
    _hist[s] += 1.0
    _count += 1

    # normalised frequency (0..1) per residual; used as lexicographic tiebreak below SOS
    total = _hist.sum()
    freq = _hist / total if total > 0.0 else _hist

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    apply_tb = _count > _WARMUP

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        if apply_tb and r > 0:
            tb = freq[r]                    # in [0,1], strictly < 1 delta unit
        elif apply_tb:
            tb = 0.0
        else:
            tb = 0.0
        # primary: minimise delta; tiebreak: prefer frequently-matched residual
        scores[k] = -(delta * 1000.0) + tb

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if apply_tb and r_new > 0:
        tb_new = freq[r_new]
    else:
        tb_new = 0.0
    scores[len(fitting):] = -(delta_new * 1000.0) + tb_new

    choice = int(np.argmax(scores))          # first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
