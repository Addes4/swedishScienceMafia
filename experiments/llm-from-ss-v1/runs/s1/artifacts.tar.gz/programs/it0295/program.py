# EVOLVE-BLOCK-START
"""Best-Fit rule with an "exact-fill residual" tiebreaker.

Primary objective: place the item so the resulting residual is as small as possible (Best Fit),
which is the strongest simple online rule for this distribution. Among placements with equal
residual, prefer a residual r that equals some already-seen item size (tracked in a frequency
table), since such a gap is exactly fillable by a future item of that size. Remaining ties prefer
a larger residual. State is a frequency table of past item sizes; the record of open bins is read
from the harness's authoritative `bins` array.
"""
import numpy as np

CAP = 100
_seen = [0] * (CAP + 1)         # how many past items had each size


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _seen
    s = int(item)
    _seen[s] += 1

    n = len(bins)
    scores = np.empty(n, dtype=np.float64)
    for j in range(n):
        g = int(bins[j])
        r = g - s
        # primary: minimise residual (Best Fit) -> larger (100-r) is better
        # tiebreak: reward exactly-fillable residual sizes, then larger residual
        fill = 1.0 if (r > 0 and _seen[r] > 0) else 0.0
        scores[j] = (CAP - r) * 10000.0 + fill * 100.0 + r
    return scores
# EVOLVE-BLOCK-END
