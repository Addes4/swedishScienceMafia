# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an online future-fit tiebreaker.

Primary rule (unchanged): place the item where it minimises sum_g N(g)^2, the standard
"sum of squares" rewrite of the classic near-optimal harmonic-style packing bound; this is
competitive with the lower bound on Weibull-shaped items.

Tiebreak (new): among choices that leave (nearly) the same sum-of-squares delta, weakly
prefer the residual r that has the highest estimated probability of being exactly filled by
a future item.  The estimate is an online histogram of item sizes seen so far: residuals
equal to a frequently-arriving size are more likely to be closed exactly, which reduces the
number of bins.  The tiebreak magnitude stays far below the 1000 multiplier used to separate
the primary deltas, so it only resolves genuine ties.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = np.zeros(CAP + 1, dtype=np.float64)   # counts of item sizes seen so far
_seen = 0


def _fit_value(r):
    """Estimated usefulness of leaving residual r (higher = more likely to be filled)."""
    if r <= 0:
        return 0.0
    return _hist[r] / (_seen + 1.0)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties go to the first."""
    global _caps, _N, _hist, _seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * 1000 + r) - _fit_value(r)
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000 + r_new) - _fit_value(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    _hist[s] += 1.0
    _seen += 1
    return scores
# EVOLVE-BLOCK-END
