# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a tiered tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Ties in the sum-of-squares delta are broken as follows:
  1. among ties, prefer producing a residual >= USEFUL (tight but not a near-zero leftover),
  2. then prefer the loosest fit (largest residual) to spread load,
  3. then prefer the largest residual once more as a stable fallback.
The function keeps its own record of every opened bin. Unused bins have remaining capacity 100 and are
opened in index order, so used bins form a prefix of the bin array. Each instance runs in a fresh
process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
USEFUL = 8                     # residuals at least this large are considered "useful"
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # tier 1: reward useful residuals; tier 2: loosest fit; tier 3: residual (stable)
        useful = 1 if r >= USEFUL else 0
        scores[k] = -delta * 1000000.0 + useful * 10000.0 + r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    useful_new = 1 if r_new >= USEFUL else 0
    scores[len(fitting):] = -delta_new * 1000000.0 + useful_new * 10000.0 + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
