# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a loosest-fit tiebreaker (cleanly separated terms).

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). The SOS delta is scaled by a large constant so the secondary loosest-fit term
(prefer the largest residual) only resolves exact SOS ties, never competing with the primary objective.
The function keeps its own record of every opened bin. The harness opens unused bins in index order
(ties go to the first bin), so used bins are always a prefix of the bin array. Each instance runs in a
fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
BIG = 10 ** 6
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta (scaled); tiebreak: prefer larger residual (loosest fit)
        scores[k] = -(delta * BIG) + r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * BIG) + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
