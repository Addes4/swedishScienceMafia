# EVOLVE-BLOCK-START
"""Best-fit rule with a small residual-matching bonus.

Among bins the item fits in, prefer the tightest fit (smallest resulting residual).
A mild bonus is added when the resulting residual equals the item size or a recently
seen item size, since such residuals can likely be filled exactly later. This keeps the
strong tight-fit signal while reducing wasted fragments.

The function keeps its own record of every opened bin. The harness opens unused bins in
index order (ties go to the first bin), so used bins are always a prefix of the bin array.
Each instance runs in a fresh process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_recent = [0] * (CAP + 1)      # recency-weighted counts of item sizes seen


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _recent
    s = int(item)
    _recent[s] += 1

    # total number of items seen (for normalizing recency weights)
    total = sum(_recent)
    # recency weighting: sizes seen more often get a mild bonus as matchable residuals
    inv_total = 1.0 / total if total > 0 else 0.0

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    def match_bonus(r):
        # reward residuals that are common item sizes (likely fillable exactly)
        if r <= 0:
            return 0.0
        return 5.0 * _recent[r] * inv_total

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # primary: tightest fit => smaller residual higher score
        scores[k] = -r + match_bonus(r)

    r_new = CAP - s
    scores[len(fitting):] = -r_new + match_bonus(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _caps[j] = g - s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
