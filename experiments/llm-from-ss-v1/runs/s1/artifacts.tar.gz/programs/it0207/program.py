# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a consolidation (duplicate-residual) tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer the residual r that already occurs most often
(consolidation), which reduces fragmentation and keeps residuals reusable by similar future items.
The function keeps its own record of every opened bin. The harness opens unused bins in index order
(ties go to the first bin), so used bins are always a prefix of the bin array. Each instance runs in a
fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_BIG = 10 ** 9                 # multiplier large enough that ties in delta are exact


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    scores = np.empty(len(bins), dtype=np.float64)
    k = 0
    for j, g in enumerate(_caps):
        if g < s:
            continue
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta; tiebreak: prefer residual already present (consolidation),
        # then prefer larger residual (loosest fit) to spread load.
        scores[k] = -(delta * _BIG) + (_N[r] if r > 0 else 0) * 1000 + r
        k += 1

    n_fitting = k
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    val_new = -(delta_new * _BIG) + (_N[r_new] if r_new > 0 else 0) * 1000 + r_new
    for k in range(n_fitting, len(bins)):
        scores[k] = val_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < n_fitting:
        # map choice back to bin index j
        idx = 0
        for j, g in enumerate(_caps):
            if g < s:
                continue
            if idx == choice:
                _N[g] -= 1
                _caps[j] = g - s
                if g - s > 0:
                    _N[g - s] += 1
                break
            idx += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
