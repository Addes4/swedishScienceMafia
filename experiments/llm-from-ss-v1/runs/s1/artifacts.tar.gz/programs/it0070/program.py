# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a reuse-oriented tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer a residual of 0 (closing a bin cleanly); if no
such bin exists, prefer the residual that is as small as possible but still at least the running
average item size when feasible, otherwise the smallest residual. This tends to leave reusable gaps
rather than stranding large or useless residuals. Bins are tracked locally; used bins are always a
prefix of the bin array because ties go to the first bin and unused bins arrive at the end.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_sum_items = 0                 # running sum of all arriving item sizes
_count_items = 0               # running count of all arriving items

BIG = 10 ** 9


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _sum_items, _count_items
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Tiebreaker: prefer residual 0; else penalty grows with distance from 0.
    # A residual of 0 is ideal; among nonzero, smaller residual frees bins earlier.
    def tie(r):
        return 0.0 if r == 0 else float(CAP - r)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * BIG) + tie(r)
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * BIG) + tie(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    _sum_items += s
    _count_items += 1
    return scores
# EVOLVE-BLOCK-END
