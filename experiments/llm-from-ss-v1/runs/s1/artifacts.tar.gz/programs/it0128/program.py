# EVOLVE-BLOCK-START
"""Best-fit (tightest residual) with a pairing-aware tiebreak.

Each item goes into the fitting bin whose resulting residual r = g - s is smallest (best fit/decreasing-style),
which tends to pack tightly and reduce waste. Among placements with equal residual, prefer the one whose
residual already exists as an open bin's remaining capacity or equals the item size, since a future item can
close it; otherwise prefer larger residual to keep big bins available.

The function keeps its own record of every opened bin. The harness opens unused bins in index order (ties go
to the first bin), so used bins are always a prefix of the bin array. Each instance runs in a fresh process,
so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g <= CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # precompute counts of residuals among fitting placements for match detection
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # primary: tighter fit (smaller residual) is better -> higher score
        # secondary: reward residual that matches an existing open capacity or equals item size
        match = 1.0 if (r > 0 and (_N[r] > 0 or r == s)) else 0.0
        scores[k] = -r * 1000.0 + match * 10.0 + r * 0.0
    r_new = CAP - s
    match_new = 1.0 if (r_new > 0 and (_N[r_new] > 0 or r_new == s)) else 0.0
    scores[len(fitting):] = -r_new * 1000.0 + match_new * 10.0

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
