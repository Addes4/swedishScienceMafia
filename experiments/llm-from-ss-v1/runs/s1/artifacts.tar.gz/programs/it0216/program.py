# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a residual-reuse tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among exact sum-of-squares ties, prefer the bin whose residual
equals the arriving item size (so a future item of the same size can close it cleanly),
then loosest fit. The function keeps its own record of every opened bin. The harness opens
unused bins in index order (ties go to the first bin), so used bins are always a prefix of
the bin array. Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # recompute N from current caps
    N = [0] * (CAP + 1)
    for g in _caps:
        if 0 < g < CAP:
            N[g] += 1

    step = 10000.0
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * N[g] + 1 + (2 * N[r] + 1 if r > 0 else 0)
        # primary: minimise delta; tiebreak: residual == item size, then loosest fit
        bonus = step if r == s else 0.0
        scores[k] = -(delta * step) + bonus + r
    r_new = CAP - s
    delta_new = 2 * N[r_new] + 1 if r_new > 0 else 0
    bonus_new = step if r_new == s else 0.0
    scores[len(fitting):] = -(delta_new * step) + bonus_new + r_new

    choice = int(np.argmax(scores))          # harness's choice: first highest score
    if choice < len(fitting):
        _caps[fitting[choice]] -= s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
