# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a residual-histogram lookahead tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100).  This primary objective is evaluated exactly with integer deltas.
Among exact sum-of-squares ties we apply a secondary heuristic: prefer the placement whose
resulting residual is most useful for future items, measured against the current residual
histogram (reward residuals that pair with an existing open capacity, avoid leaving an
isolated tiny residual that few items can use).  The function keeps its own record of every
opened bin; since the harness opens unused bins in index order, used bins are always a
prefix of the bin array.  Fresh process per instance => module state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _score_residual(r):
    """Secondary value of leaving residual r (>0).  Higher is better.

    Reward residuals that can pair with an existing open capacity (i.e. r + g == 100 for
    some open g), and prefer residuals that are reasonably large so they remain usable.
    """
    if r <= 0:
        return 0
    val = 0
    # pairing bonus: does residual r complement an already-open capacity?
    comp = CAP - r
    if 1 <= comp <= CAP:
        val += 3 * _N[comp]
    # usability: larger residual is generally better, capped moderately
    val += r
    return val


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        sec = _score_residual(r)
        # primary delta dominates via large multiplier; secondary breaks ties (capped small)
        scores[k] = -(delta * 100000) + sec
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 100000) + _score_residual(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
