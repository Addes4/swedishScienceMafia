# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a data-driven residual tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer the residual most likely to be reused soon,
estimated from a running histogram of item sizes seen so far. Bins are opened in index order
(unused bins form a prefix), so the module-level record tracks used bins in order.
Each instance runs in a fresh process, so module state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = np.zeros(CAP + 1, dtype=np.float64)  # running histogram of item sizes
_n_items = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist, _n_items
    s = int(item)

    # update running histogram
    _hist[s] += 1.0
    _n_items += 1

    # empirical reuse score for a residual r: how many past items were <= r, weighted toward
    # matching the residual. Use probability mass of items fitting into r.
    # cumulative distribution: mass of items with size <= r
    cdf = np.cumsum(_hist) / max(_n_items, 1)

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # tiebreak: prefer residual with high reuse probability (cdf[r]); r=0 gets a moderate bonus
        reuse = cdf[r] if r > 0 else 0.5
        scores[k] = -(delta * 1000.0) + reuse
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    reuse_new = cdf[r_new] if r_new > 0 else 0.5
    scores[len(fitting):] = -(delta_new * 1000.0) + reuse_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
