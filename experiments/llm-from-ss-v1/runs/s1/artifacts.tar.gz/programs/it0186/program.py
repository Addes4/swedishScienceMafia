# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a smarter tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among exact sum-of-squares ties, we break by preferring the residual
that keeps bins healthy: a residual close to the running mean item size (which tends to remain
refillable) is preferred, with a fallback to the tighter residual on equal distance to reduce
fragmentation. The SOS primary objective is unchanged, so the strong packing remains.

The function keeps its own record of every opened bin. The harness opens unused bins in index
order (ties go to the first bin), so used bins are always a prefix of the bin array. Each
instance runs in a fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_sum_items = 0
_count_items = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _sum_items, _count_items
    s = int(item)
    _sum_items += s
    _count_items += 1
    target = _sum_items / _count_items   # running mean item size

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta; tiebreak: residual distance from healthy target,
        # then loosest residual so ties resolve before running out of alternatives.
        scores[k] = -(delta * 1000.0) - abs(r - target) + r * 0.001
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000.0) - abs(r_new - target) + r_new * 0.001

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
