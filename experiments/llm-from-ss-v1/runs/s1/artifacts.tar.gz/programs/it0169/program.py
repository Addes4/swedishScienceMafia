# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an adaptive residual tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). The SOS delta is the decisive objective. Among exact SOS ties, we prefer the bin whose
residual after placement is "most useful" — specifically the residual value that has historically been
the most common item size so far (so that leftover space can be efficiently filled later). This is a
tiny, self-normalising perturbation that only fires on genuine ties, so it cannot disturb the proven
SOS ordering.

The function keeps its own record of every opened bin. The harness opens unused bins in index order
(ties go to the first bin), so used bins are always a prefix of the bin array. Each instance runs in a
fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_size_count = [0] * (CAP + 1)  # how many arriving items of each size we've seen
_n_items = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _size_count, _n_items
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Track item-size statistics for the adaptive tiebreak.
    _size_count[s] += 1
    _n_items += 1

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # secondary term: favours residual values that are common item sizes
        sec = _size_count[r] if r > 0 else _size_count[s]
        # primary: minimise delta; tiebreak: prefer useful residual, then loosest fit
        scores[k] = -(delta * 100000.0) + sec * 100.0 + r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    sec_new = _size_count[r_new] if r_new > 0 else _size_count[s]
    scores[len(fitting):] = -(delta_new * 100000.0) + sec_new * 100.0 + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

