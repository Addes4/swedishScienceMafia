# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a loosest-fit tiebreaker (vectorized).

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer the bin with the largest remaining capacity
(loosest fit), which spreads load and avoids prematurely creating tiny unusable residuals.
State is kept as a numpy array of live capacities (one entry per opened bin, in bin-index order) plus
a small count vector N[g]. The harness opens unused bins in index order and breaks ties toward the
first bin, so the used bins are always a prefix; the extra shown bins are the still-unused ones.
"""
import numpy as np

CAP = 100
_caps = np.zeros(0, dtype=np.int64)     # remaining capacity of every opened bin, in bin-index order
_N = np.zeros(CAP + 1, dtype=np.int64)  # N[g]: open bins with remaining capacity g, 0 < g < CAP
_N[0] = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    nb = len(bins)
    n_used = _caps.shape[0]
    scores = np.empty(nb, dtype=np.float64)

    if n_used:
        kept = _caps >= s
        idx = np.nonzero(kept)[0]
        g = _caps[idx]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1) * (r > 0)
        scores[idx] = -(delta * 100000.0) + r

    m = idx.shape[0] if n_used else 0
    r_new = CAP - s
    delta_new = (2 * _N[r_new] + 1) if r_new > 0 else 0
    scores[m:] = -(delta_new * 100000.0) + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < m:
        j = idx[choice]
        g = int(_caps[j])
        _N[g] -= 1
        g2 = g - s
        _caps[j] = g2
        if g2 > 0:
            _N[g2] += 1
    elif m < nb:
        _caps = np.append(_caps, CAP - s)
        if r_new > 0:
            _N[r_new] += 1
    return scores
# EVOLVE-BLOCK-END
