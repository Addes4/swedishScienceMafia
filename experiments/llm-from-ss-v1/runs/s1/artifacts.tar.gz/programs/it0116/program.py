# EVOLVE-BLOCK-START
"""Sum-of-Squares primary with a learned residual-compatibility tiebreaker.

Each item goes where it minimises the change in sum_g N(g)^2, where N(g) counts open bins with
remaining capacity g (0 < g < 100). This exact delta term is the proven near-optimal primary
objective, so it is preserved unchanged.

Exact ties are common, so the tiebreaker matters. Instead of loosest fit, we prefer placements
whose resulting residual r is a likely *future item size*: we keep a decaying histogram of past
item sizes and rank tie-breakers by that histogram, then by smallest positive residual, then by
largest residual. The harness opens unused bins in index order and ties go to the first bin, so
used bins are always a prefix of the bin array. Each instance runs in a fresh process, so the
module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = np.zeros(CAP + 1)      # decaying histogram of past item sizes


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _hist
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta; tiebreak: residual compatibility, then smallest, then largest
        if r == 0:
            tb = 1e6
        else:
            tb = _hist[r] * 100.0 - r * 0.001
        scores[k] = -(delta * 1000) + tb
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if r_new == 0:
        tb_new = 1e6
    else:
        tb_new = _hist[r_new] * 100.0 - r_new * 0.001
    scores[len(fitting):] = -(delta_new * 1000) + tb_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update the decaying item-size histogram after placing
    _hist *= 0.999
    _hist[s] += 1.0
    return scores
# EVOLVE-BLOCK-END
