# EVOLVE-BLOCK-START
"""Sum-of-Squares rule (keyed on the harness's own bins array) with residual-reuse tiebreak.

Each item goes where it minimises sum_g N(g)^2, the standard sum-of-squares (SOS) fragmentation
objective: delta = -2*N[g] + 1 + (2*N[r] + 1 if r > 0 else 0), where g is the bin's current
remaining capacity and r = g - item is the resulting residual.

We compute N(g) directly from the harness's authoritative `bins` array on every call, so our
scoring never drifts from the real bin set. Among exact SOS ties we add a small secondary
preference for placements whose residual already exists as an open-bin capacity (reusing
residuals avoids leaving many distinct unusable fragments), then prefer the loosest fit.
"""
import numpy as np

CAP = 100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = int(item)
    caps = np.asarray(bins, dtype=np.int64).ravel()
    m = caps.shape[0]
    scores = np.empty(m, dtype=np.float64)

    # Histogram of the authoritative bin remaining capacities (only 0<g<CAP matter for N).
    N = np.zeros(CAP + 1, dtype=np.int64)
    vals, cnts = np.unique(caps, return_counts=True)
    for v, c in zip(vals.tolist(), cnts.tolist()):
        if 0 < v < CAP:
            N[v] = c

    for k in range(m):
        g = int(caps[k])
        r = g - s
        if r < 0:
            scores[k] = -1e18          # should not happen (bins are the fitting ones)
            continue
        delta = -2 * int(N[g]) + 1 + (2 * int(N[r]) + 1 if r > 0 else 0)
        # secondary: reward residual already existing as an open capacity; then loosest fit
        reuse = int(N[r]) if r > 0 else 0
        scores[k] = -(delta * 1_000_000.0) + (reuse * 1000.0) + r

    return scores
# EVOLVE-BLOCK-END
