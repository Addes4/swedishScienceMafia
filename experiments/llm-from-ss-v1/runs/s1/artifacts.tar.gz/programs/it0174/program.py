# EVOLVE-BLOCK-START
"""Smoothed Sum-of-Squares rule with a loosest-fit tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). To make the objective robust to discretisation, N(g) is a *smoothed* count: every open
bin contributes 1 to its own residual bucket and 1/2 to each neighbouring bucket. Among exact smoothed
SOS ties, prefer the bin with the largest remaining capacity (loosest fit), which spreads load and
avoids prematurely creating tiny unusable residuals.

The function keeps its own record of every opened bin. The harness opens unused bins in index order
(ties go to the first bin), so used bins are always a prefix of the bin array. Each instance runs in a
fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
THRESH = 12                    # scratch array size for deltas
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = np.zeros(CAP + 1)         # N[g]: smoothed count of open bins with remaining capacity g


def _delta(g, s):
    """Change in sum of smoothed counts when a bin of residual g becomes residual g-s."""
    r = g - s
    d = 0.0
    # losing bucket g
    d -= 2.0 * _N[g] - 1.0
    for ng in (g - 1, g + 1):
        if 0 < ng <= CAP:
            d -= _N[ng]
    # gaining bucket r
    if r > 0:
        d += 2.0 * _N[r] + 1.0
        for nr in (r - 1, r + 1):
            if 0 < nr <= CAP:
                d += _N[nr]
    return d


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_fit = 0
    deltas = np.empty(len(bins), dtype=np.float64)
    resids = np.empty(len(bins), dtype=np.int64)

    for j, g in enumerate(_caps):
        if g >= s:
            deltas[n_fit] = _delta(g, s)
            resids[n_fit] = g - s
            n_fit += 1

    n_unused = len(bins) - len(_caps)
    r_new = CAP - s
    deltas[n_fit:n_fit + n_unused] = _delta(CAP, s)
    resids[n_fit:n_fit + n_unused] = r_new

    scores = -(deltas * 1000.0) + resids

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < n_fit:
        j = choice
        g = _caps[j]
        r = g - s
        # update smoothed counts
        _N[g] -= 1.0
        for ng in (g - 1, g + 1):
            if 0 < ng <= CAP:
                _N[ng] -= 0.5
        if r > 0:
            _N[r] += 1.0
            for nr in (r - 1, r + 1):
                if 0 < nr <= CAP:
                    _N[nr] += 0.5
        _caps[j] = r
    elif n_unused > 0:
        r = CAP - s
        _N[CAP] -= 1.0
        _N[CAP - 1] -= 0.5
        if r > 0:
            _N[r] += 1.0
            for nr in (r - 1, r + 1):
                if 0 < nr <= CAP:
                    _N[nr] += 0.5
        _caps.append(r)
    return scores
# EVOLVE-BLOCK-END

