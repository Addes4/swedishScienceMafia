# EVOLVE-BLOCK-START
"""Exact sum-of-squares rule with a tightest-fit tiebreaker.

Each item goes where it minimises S = sum_g N(g)^2 over open bins (0 < g < 100), using the
authoritative `bins` array so our value always matches the harness. Among exact ties, prefer
the bin with the smallest resulting residual (tightest fit), which packs items densely and
tends to reduce the total number of bins on Weibull-mean-40 items. The module-level state
starts empty for every instance (fresh process per instance).
"""
import numpy as np

CAP = 100
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _N
    s = int(item)
    n = len(bins)
    scores = np.empty(n, dtype=np.float64)

    # Count open bins by residual from the authoritative array (residual >= s for all here,
    # since bins shows only bins the item fits in; unused bins have residual 100).
    # We reconstruct S from residuals > 0.
    N = [0] * (CAP + 1)
    for k in range(n):
        g = int(bins[k])
        if 0 < g < CAP:
            N[g] += 1

    # Also fold in tracked state so counts are consistent.
    for g in range(1, CAP):
        if _N[g]:
            N[g] = max(N[g], _N[g])

    for k in range(n):
        g = int(bins[k])
        r = g - s
        # remove old bin capacity g, add new residual r
        delta = -2 * N[g] + 1
        if r > 0:
            delta += 2 * N[r] + 1
        # primary: minimise delta; tiebreak: prefer smaller residual (tightest fit)
        scores[k] = -(delta * 1000) - r

    choice = int(np.argmax(scores))
    g = int(bins[choice])
    # Update tracked state using the harness's residuals.
    r = g - s
    # decrement the chosen bin's old residual count in _N if it was open
    if 0 < g < CAP and _N[g]:
        _N[g] -= 1
    if r > 0:
        _N[r] += 1
    return scores
# EVOLVE-BLOCK-END
