# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a usable-residual tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Pure sum-of-squares ties are common; break them in favour of the
bin whose residual is a "good" residual: one that matches a frequently seen recent item size
(so the bin can be closed exactly later), else the smallest residual that is still at least
the smallest item we have seen. This consolidates leftover space instead of scattering it,
while never creating residuals smaller than any item we expect to receive.

The function keeps its own record of every opened bin. The harness opens unused bins in index
order (ties go to the first bin), so used bins are always a prefix of the bin array. Each
instance runs in a fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # recent-item frequency table
_recent = []                   # rolling window of recent items
_WINDOW = 400
_min_item = CAP                # smallest item size seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _freq, _recent, _min_item
    s = int(item)

    # update online stats with the arriving item
    _freq[s] += 1
    _recent.append(s)
    if len(_recent) > _WINDOW:
        old = _recent.pop(0)
        if _freq[old] > 0:
            _freq[old] -= 1
    if s < _min_item:
        _min_item = s

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # secondary: prefer a "good" residual
        if r == 0:
            good = 2                                     # closes the bin entirely
        elif r >= _min_item and _freq[r] > 0:
            good = 1                                     # closable by a common item
        elif r >= _min_item:
            good = 0                                     # usable, just not hot
        else:
            good = -1                                    # too small to expect to fill
        scores[k] = -(delta * 4) + good
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 4) + 0

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

