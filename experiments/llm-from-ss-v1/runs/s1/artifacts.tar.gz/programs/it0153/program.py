# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a matchable-residual tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among exact sum-of-squares ties, prefer the placement whose residual
equals the capacity of some other open bin (so it can be closed later by an exact fill), and
otherwise prefer the largest residual (loosest fit) to avoid creating tiny unusable scraps.

The function keeps its own record of every opened bin. The harness opens unused bins in index
order (ties go to the first bin), so used bins are always a prefix of the bin array. Each
instance runs in a fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    m = len(bins)
    scores = np.empty(m, dtype=np.float64)

    # Unused bins live at the tail of `bins`; index them first via a simple pass on _caps.
    n_used = len(_caps)
    # Used bins that fit: position k in the fitting list corresponds to bin index j.
    fit_idx = []
    for j in range(n_used):
        if _caps[j] >= s:
            fit_idx.append(j)

    # Precompute residual for each fitting used bin and reuse tiebreak logic.
    k = 0
    nfit = len(fit_idx)
    for j in fit_idx:
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # Tiebreak: matchable residual (r equals another open bin's capacity) is best,
        # then loosest fit.
        match = 1 if (r > 0 and _N[r] > 0) else 0
        scores[k] = -(delta * 100000) + match * 1000 + r
        k += 1

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    match_new = 1 if (r_new > 0 and _N[r_new] > 0) else 0
    scores[nfit:] = -(delta_new * 100000) + match_new * 1000 + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < nfit:
        j = fit_idx[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

