# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an online distribution-aware tiebreaker.

Primary objective: minimise sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < CAP). This is the classic best-fit-like objective in residual space.

Tiebreaker: among placements with identical integer delta, prefer the residual that the
current item stream is most likely to *use well* — i.e. a residual whose size matches
item sizes we have recently seen (so it can be closed exactly or nearly exactly by an
upcoming item), which reduces fragmentation. The item histogram is maintained online with
light exponential decay so the rule adapts to the fixed distribution without tuning to a
single instance. The tiebreaker is a small bounded term, so it never overrides the exact
primary objective.
"""
import numpy as np

CAP = 100
_caps = []                       # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)             # N[g]: open bins with remaining capacity g, 0 < g < CAP

# online decayed histogram of item sizes (smoothed)
_decay = 0.999
_hist = np.ones(CAP + 1, dtype=np.float64)   # pseudo-counts so we never divide by zero


def _record(s):
    _hist *= _decay
    _hist[s] += 1.0


def _usefulness(r):
    """How likely is residual r to be well-used by upcoming items (higher = better)."""
    if r <= 0:
        return 0.0
    # mass of recent items that fit into r, weighted toward exact/near-exact closing
    tot = _hist.sum()
    if tot <= 0.0:
        return 0.0
    fit_mass = _hist[1:r + 1].sum() / tot
    # weight items that close r nearly exactly
    close_mass = 0.0
    lo = max(1, r - 5)
    for k in range(lo, r + 1):
        close_mass += _hist[k] * (1.0 + 4.0 * k / r)
    close_mass /= tot
    return fit_mass + 2.0 * close_mass


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    _record(s)

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary (integer delta) dominates; tiebreaker is bounded by < 1
        scores[k] = -(delta * 1000) + min(_usefulness(r), 0.9)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000) + min(_usefulness(r_new), 0.9)

    choice = int(np.argmax(scores))          # harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
