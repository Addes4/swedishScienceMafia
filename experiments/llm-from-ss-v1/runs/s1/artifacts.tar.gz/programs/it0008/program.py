# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a fill-probability tiebreak.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). The strong sum-of-squares signal decides the primary choice; ties
(equal delta) are broken by preferring the residual that past item sizes have most often been
able to fill, which keeps gaps usable instead of leaving isolated waste. The function keeps its
own record of every opened bin; used bins are a prefix of the bin array, and each instance runs
in a fresh process so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = [0] * (CAP + 1)        # observed counts of arriving item sizes

_ALPHA = 0.6                   # weight for the fill-probability tiebreak (kept small)


def _fill_score(r):
    """Rough probability that residual r can still be filled by a future item.

    Uses a smoothed view of the observed item-size distribution: sum of relative frequencies
    of sizes that fit into r, weighted mildly towards larger r.
    """
    if r <= 0:
        return 0.0
    total = 0
    hit = 0
    for sz in range(1, r + 1):
        c = _hist[sz]
        total += c
        hit += c
    # fraction of history that fits in r
    denom = sum(_hist) or 1
    return hit / denom


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist
    s = int(item)
    _hist[s] += 1

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * 1000) + _ALPHA * _fill_score(r) - 0.01 * r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000) + _ALPHA * _fill_score(r_new) - 0.01 * r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
