# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a learned residual-demand tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer the bin whose residual after placement is
closest to a frequently-seen item size (learned online), so the left-over space is more likely to be
filled by a future item. Loosest fit is the final fallback. The function records every opened bin;
since the harness opens unused bins in index order, used bins are always a prefix of the bin array.
Each instance runs in a fresh process, so module state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_demand = [0] * (CAP + 1)      # demand[r]: count of past items equal to r


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _demand
    s = int(item)
    _demand[s] += 1
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # highest seen frequency among all item sizes, used to normalise the demand bonus
    max_freq = max(_demand) if max(_demand) > 0 else 1

    def demand_bonus(r):
        # residual r is good if a future item of exactly size r is likely to arrive
        if r <= 0 or r > CAP:
            return 0.0
        return _demand[r] / max_freq

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta; tiebreak: favour demanded residual, then loosest fit
        scores[k] = -(delta * 1000) + demand_bonus(r) * 100 + r * 0.01
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000) + demand_bonus(r_new) * 100 + r_new * 0.01

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
