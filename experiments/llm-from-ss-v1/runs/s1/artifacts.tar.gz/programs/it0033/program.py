# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a usable-residual tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among exact sum-of-squares ties, we prefer the bin with the
smallest residual that is still usable (residual >= the smallest item size seen so far),
which consolidates gaps that can still be filled rather than scattering many mid-sized
gaps. If no tie-bin is usable, fall back to the loosest fit.
The function keeps its own record of every opened bin. The harness opens unused bins in
index order (ties go to the first bin), so used bins are always a prefix of the bin array.
Each instance runs in a fresh process, so the module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_min_item = CAP                # smallest item size observed so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _min_item
    s = int(item)
    if s < _min_item:
        _min_item = s
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta; tiebreak: usable-residual preference, then loosest fit
        if r >= _min_item:
            usable = 1
            tie = -r                      # prefer smallest usable residual
        else:
            usable = 0
            tie = r                       # prefer largest residual
        scores[k] = -(delta * 1000000) + usable * 100000 + tie
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if r_new >= _min_item:
        usable = 1
        tie = -r_new
    else:
        usable = 0
        tie = r_new
    scores[len(fitting):] = -(delta_new * 1000000) + usable * 100000 + tie

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
