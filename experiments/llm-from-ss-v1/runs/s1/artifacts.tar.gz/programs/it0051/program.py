# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a collision-aware secondary term.

Each item goes to the bin that minimises the change in sum_g N(g)^2, where N(g) counts open bins
with remaining capacity g (0 < g < 100). Among near-ties, prefer the bin whose resulting residual
is closest to some currently-open residual (so future items are more likely to hit an exact or
near-exact fit and close bins cleanly), with loosest fit as a final fallback.

The function keeps its own record of every opened bin. The harness opens unused bins in index
order (ties go to the first bin), so used bins are always a prefix of the bin array. Each instance
runs in a fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _nearest_residual(r):
    """Distance from residual r to the nearest currently-open residual, or a large value if none."""
    if r <= 0:
        return 0.0
    lo = None
    for g in range(r, 0, -1):
        if _N[g] > 0:
            lo = r - g
            break
    hi = None
    for g in range(r, CAP):
        if _N[g] > 0:
            hi = g - r
            break
    if lo is None and hi is None:
        return 50.0
    if lo is None:
        return float(hi)
    if hi is None:
        return float(lo)
    return float(min(lo, hi))


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta; secondary: prefer terminal residuals (r==0) and
        # residuals close to an existing open residual (collision-friendly); then loosest fit.
        close = _nearest_residual(r)
        scores[k] = -(delta * 1000.0) - (close * 2.0) + r * 0.01

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    close_new = _nearest_residual(r_new)
    scores[len(fitting):] = -(delta_new * 1000.0) - (close_new * 2.0) + r_new * 0.01

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
