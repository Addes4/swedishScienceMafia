# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a size-aware loosest-fit tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among exact sum-of-squares ties, prefer the bin with the largest
remaining capacity, but only when that residual is at least the largest item size seen so far
(i.e. the residual is actually reusable); otherwise order by residual closeness to that
threshold. This keeps the potential-minimising choice while avoiding scattering into gaps that
can never be filled. The function keeps its own record of every opened bin; unused bins have
remaining capacity 100 and appear in index order, so used bins are always a prefix.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_max_item = 1                  # largest item size seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _max_item
    s = int(item)
    if s > _max_item:
        _max_item = s
    thr = _max_item
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta; tiebreak: prefer residuals that are reusable (>= thr),
        # largest first; residuals below thr are ranked by closeness to thr from below.
        tb = r if r >= thr else -thr + r
        scores[k] = -(delta * 1000000) + tb
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    tb_new = r_new if r_new >= thr else -thr + r_new
    scores[len(fitting):] = -(delta_new * 1000000) + tb_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

