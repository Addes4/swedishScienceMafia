# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a distribution-aware tiebreaker.

Primary objective: place the item where it minimises the change in sum_g N(g)^2,
where N(g) counts open bins with remaining capacity g (0 < g < 100). This is the
classic sum-of-squares (SOS) proxy for future packing quality.

Tiebreaker: among bins whose SOS delta differs by a negligible amount, prefer the
placement whose resulting residual r is more "reusable": we give a small bonus for
larger r (loosest fit, spreads load) plus a small bonus proportional to how common
that residual already is in the pool (N[r]) and whether it complements a frequently
seen item size. The bonuses are deliberately small so SOS remains the primary driver.

The function keeps its own record of every opened bin. The harness opens unused
bins in index order (ties go to the first bin), so used bins are always a prefix of
the bin array. Each instance runs in a fresh process, so module-level state starts
empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_itemhist = [0] * (CAP + 1)    # counts of arriving items sizes (decayed)
_decay = 0.995


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _itemhist
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # --- soft tiebreaker weights (small relative to the primary SOS term) ---
    # approximate weighting of a residual r: prefer larger r, prefer common r,
    # prefer r that complements frequently seen item sizes.
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        if r > 0:
            bonus = 0.5 * r + 3.0 * _N[r] + 0.5 * _itemhist[r]
        else:
            bonus = 0.0
        scores[k] = -(delta * 1000) + bonus

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if r_new > 0:
        bonus_new = 0.5 * r_new + 3.0 * _N[r_new] + 0.5 * _itemhist[r_new]
    else:
        bonus_new = 0.0
    scores[len(fitting):] = -(delta_new * 1000) + bonus_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update the (decayed) empirical item-size histogram
    for t in range(CAP + 1):
        _itemhist[t] *= _decay
    _itemhist[s] += 1.0

    return scores
# EVOLVE-BLOCK-END
