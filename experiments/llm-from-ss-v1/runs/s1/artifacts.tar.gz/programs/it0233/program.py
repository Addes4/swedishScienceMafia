# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a loosest-fit tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer the bin with the largest remaining capacity
(loosest fit), which spreads load and avoids prematurely creating tiny unusable residuals.
The function keeps its own record of every opened bin. The harness opens unused bins in index order
(ties go to the first bin), so used bins are always a prefix of the bin array. Each instance runs in a
fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n_unused = len(bins) - len(_caps)
    scores = np.empty(len(bins), dtype=np.float64)

    if _caps:
        caps = np.asarray(_caps, dtype=np.int64)
        fit_mask = caps >= s
        fit_idx = np.nonzero(fit_mask)[0]
        if fit_idx.size:
            g = caps[fit_idx]
            r = g - s
            N = np.asarray(_N, dtype=np.int64)
            Nr = np.where(r > 0, N[r], 0)
            delta = -2 * N[g] + 1 + 2 * Nr + (r > 0)
            scores[fit_idx] = delta.astype(np.float64) * (-100000.0) + r
    r_new = CAP - s
    delta_new = (2 * _N[r_new] + 1) if r_new > 0 else 0
    scores[len(_caps):] = -(delta_new * 100000.0) + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(_caps):
        g = _caps[choice]
        _N[g] -= 1
        _caps[choice] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

