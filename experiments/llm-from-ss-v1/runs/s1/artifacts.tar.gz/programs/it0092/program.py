# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a convex residual-shape tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). The primary objective is computed exactly in integers by comparing
delta = -2*N[g] + 1 + (2*N[r] + 1 if r > 0 else 0) for g = old remaining capacity and r = g - s.

Among exact sum-of-squares ties we break the tie with a convex penalty on the residual r:
pen(r) = r * (CAP - r). This is minimal at r = 0 and r = CAP (a bin closed exactly, or left
untouched) and maximal for a half-empty bin, so ties prefer placements that keep residuals
"extreme" rather than leaving awkward mid-sized leftovers. This is deterministic, needs no
online estimation, and costs nothing.

The function keeps its own record of every opened bin. The harness opens unused bins in index
order (ties go to the first bin), so used bins are always a prefix of the bin array. Each
instance runs in a fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        pen = r * (CAP - r) if 0 < r < CAP else 0
        # primary: minimise delta; tiebreak: minimise convex residual penalty
        scores[k] = -(delta * 10000) - pen
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    pen_new = r_new * (CAP - r_new) if 0 < r_new < CAP else 0
    scores[len(fitting):] = -(delta_new * 10000) - pen_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
