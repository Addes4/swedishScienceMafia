# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a "reusable residual" tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer the bin whose resulting residual r is itself a
size that appears in the recent item stream (so that residual can be filled exactly later), and break
any remaining tie by loosest fit. The function keeps its own record of every opened bin. The harness
opens unused bins in index order (ties go to the first bin), so used bins are always a prefix of the
bin array. Each instance runs in a fresh process, so the module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_item_seen = [0.0] * (CAP + 1) # recency-weighted count of past item sizes

_DECAY = 0.999


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _item_seen
    s = int(item)

    # decay the recency-weighted item histogram, then record this item
    for v in range(1, CAP + 1):
        _item_seen[v] *= _DECAY
    _item_seen[s] += 1.0

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta; tiebreak: reusable residual, then loosest fit
        reusable = _item_seen[r] if r > 0 else 0.0
        scores[k] = -(delta * 100000.0) + reusable * 1000.0 + r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    reusable_new = _item_seen[r_new] if r_new > 0 else 0.0
    scores[len(fitting):] = -(delta_new * 100000.0) + reusable_new * 1000.0 + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
