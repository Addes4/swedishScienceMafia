# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a perfect-pair tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Sum-of-squares measures fragmentation of the residual-capacity
profile; minimising it is a well known near-optimal online packing objective. Among exact
sum-of-squares ties, prefer the bin whose resulting residual r already equals some open bin's
capacity (so that r can be closed by a later item of exactly that size), then prefer the
larger residual (loosest fit). The function keeps its own record of every opened bin. The
harness opens unused bins in index order (ties go to the first bin), so used bins are always a
prefix of the bin array. Each instance runs in a fresh process, so module level state starts
empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.int64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # secondary: 1 if residual r matches an existing open capacity (perfect pair), else 0
        sec = 1 if (r > 0 and _N[r] > 0) else 0
        # pack lexicographically: primary small delta wins, then perfect pair, then larger r
        scores[k] = (-delta) * 1000000 + sec * 10000 + r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    sec_new = 1 if (r_new > 0 and _N[r_new] > 0) else 0
    scores[len(fitting):] = (-delta_new) * 1000000 + sec_new * 10000 + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
