# EVOLVE-BLOCK-START
"""Best-fit with a residual-match bonus.

The item goes into the bin giving the tightest fit (smallest remaining capacity that still fits),
which minimizes immediate waste. To encourage exact packing, bins whose resulting residual equals
a commonly seen item size are preferred via a small bonus, so future items can fill them exactly.
The function keeps its own record of every opened bin. The harness opens unused bins in index order
(ties go to the first bin), so used bins are always a prefix of the bin array. Each instance runs in
a fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_seen = np.zeros(CAP + 1)      # smoothed frequency of item sizes seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    scores = np.empty(len(bins), dtype=np.float64)

    # weight so best-fit dominates but residual-match breaks near ties
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # tightest fit: -g ; residual-match bonus if r is a common size
        bonus = _seen[r] if 1 <= r <= CAP else 0.0
        scores[k] = -g * 1000.0 + bonus
    r_new = CAP - s
    bonus_new = _seen[r_new] if 1 <= r_new <= CAP else 0.0
    scores[len(fitting):] = -CAP * 1000.0 + bonus_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _caps[j] = g - s
    else:
        _caps.append(CAP - s)
    _seen[s] += 1.0
    return scores
# EVOLVE-BLOCK-END
