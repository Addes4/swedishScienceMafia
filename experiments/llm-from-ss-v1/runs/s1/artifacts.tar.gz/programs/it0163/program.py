# EVOLVE-BLOCK-START
"""Best-fit decreasing-style online rule.

Place each item into the fitting bin with the smallest remaining capacity (best fit).
This tightens packing and avoids leaving many partially-filled bins. Unused bins
(remaining capacity 100) are considered too, so a fresh bin is chosen only when no
open bin fits better. Ties go to the first bin, matching the harness.
"""
import numpy as np

CAP = 100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = int(item)
    # Prefer the smallest remaining capacity that still fits -> best fit.
    scores = 100.0 - bins.astype(np.float64)
    return scores
# EVOLVE-BLOCK-END
