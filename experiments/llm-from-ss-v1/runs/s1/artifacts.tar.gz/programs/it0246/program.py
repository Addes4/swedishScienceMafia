# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a loosest-fit tiebreaker plus a common-item match bonus.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among bins that achieve the minimum sum-of-squares increment, prefer the bin with the
largest remaining capacity (loosest fit); a small extra bonus is given when the resulting residual
exactly equals a frequently-seen item size, so future copies of that common item can fill the bin
perfectly. The function keeps its own record of every opened bin. Used bins are always a prefix of the
bin array because the harness opens unused bins in index order. State starts empty per instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # how often each item size has been seen


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _freq
    s = int(item)
    _freq[s] += 1
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # exact SOS increment for each fitting bin; find the optimum among them
    deltas = []
    for j in fitting:
        g = _caps[j]
        r = g - s
        delta = 2 * (_N[r] - _N[g]) + 1
        deltas.append(delta)
    best_delta = min(deltas) if deltas else None

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = deltas[k]
        common = 1 if (r > 0 and _freq[r] > 0) else 0
        # primary: minimise delta; then loosest fit; small bonus for matching a common item size
        scores[k] = -(delta * 100000) + r * 10 + common

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    common_new = 1 if (r_new > 0 and _freq[r_new] > 0) else 0
    scores[len(fitting):] = -(delta_new * 100000) + r_new * 10 + common_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
