# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a learned "hot residual" tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer a residual that a recent item size is likely to
fill exactly: we maintain an online histogram of recently seen item sizes and reward residuals whose
size is a frequent recent item size, which tends to enable future exact fits and reduce wasted capacity.
The function keeps its own record of every opened bin. The harness opens unused bins in index order
(ties go to the first bin), so used bins are always a prefix of the bin array. Each instance runs in a
fresh process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # recent item-size histogram (decayed)
_seen = 0                      # number of items seen


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _freq, _seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    def score_for(g, unused=False):
        r = g - s
        if unused:
            delta = 2 * _N[r] + 1 if r > 0 else 0
        else:
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # tiebreak: reward residual that a frequent recent item size fills exactly
        hot = _freq[r] / (_seen + 1) if r > 0 else 1.0
        return -(delta * 100000.0) + r + hot

    for k, j in enumerate(fitting):
        scores[k] = score_for(_caps[j])
    if n_unused > 0:
        scores[len(fitting):] = score_for(CAP, unused=True)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update recent-size histogram with light decay so it tracks the distribution
    _seen += 1
    if _seen % 64 == 0:
        for i in range(CAP + 1):
            _freq[i] = _freq[i] // 2
    _freq[s] += 1
    return scores
# EVOLVE-BLOCK-END
