# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an empirical best-fit tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). This is the exact "reduce the number of distinct fragments"
objective. Among exact sum-of-squares ties we break toward the residual r that is most
likely to be exactly filled by an incoming item, using the online empirical distribution
of past item sizes. Failing that, prefer larger residuals (loosest fit).

The function keeps its own record of every opened bin. The harness opens unused bins in
index order (ties go to the first bin), so used bins are always a prefix of the bin array.
Each instance runs in a fresh process, so the module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_sizecount = [0] * (CAP + 1)   # how many past items had each size
_seen = 0                      # number of past items


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _sizecount, _seen
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # probability mass of a future item exactly equal to a given residual r
    def fill_prob(r):
        if r <= 0 or r > CAP:
            return 0.0
        return _sizecount[r] / _seen if _seen > 0 else 0.0

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta (exact sum-of-squares). tiebreak: prefer residual most
        # likely to be exactly fillable, then loosest fit.
        scores[k] = -(delta * 1000000.0) + fill_prob(r) * 1000.0 + r

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000000.0) + fill_prob(r_new) * 1000.0 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1

    # update empirical distribution with the arriving item
    _sizecount[s] += 1
    _seen += 1
    return scores
# EVOLVE-BLOCK-END

