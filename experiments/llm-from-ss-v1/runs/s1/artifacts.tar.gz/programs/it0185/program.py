# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a small loosest-fit tiebreaker.

Each item goes where it minimises the increase in sum_g N(g)^2, where N(g) counts open bins
with remaining capacity g (0 < g < CAP). Among exact sum-of-squares ties, prefer the bin with
the largest remaining capacity (loosest fit), which spreads load and avoids creating tiny
unusable residuals.

State is derived from the harness-provided `bins` array on every call, so the function is
robust to any bin layout the harness uses. Used bins (fitting) come first in index order and
unused bins have remaining capacity CAP, matching the harness's "first highest score" rule.
"""
import numpy as np

CAP = 100
_N = np.zeros(CAP + 2, dtype=np.int64)   # N[g]: open bins with remaining capacity g
_seen = 0                                 # number of items processed


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _N, _seen
    s = int(item)
    m = len(bins)

    # Capacities of all bins the item fits in (harness guarantees all of `bins` fit).
    caps = np.asarray(bins, dtype=np.int64)

    # Residual after placing the item in each candidate bin.
    res = caps - s
    res_ok = res > 0

    # SOS delta for each candidate: -2*N[g] + 1 + (2*N[r] + 1 if r > 0 else 0)
    delta = -2.0 * _N[caps] + 1.0
    delta += np.where(res_ok, 2.0 * _N[res] + 1.0, 0.0)

    # Primary: minimise delta. Tiebreak: prefer larger residual (loosest fit), but keep the
    # tiebreak far smaller than one SOS unit so it never overrides the primary objective.
    scores = -delta + (res.astype(np.float64) / (CAP + 1))

    choice = int(np.argmax(scores))
    g = int(caps[choice])
    r = g - s

    # Update N using the harness's actual capacity at the chosen bin.
    _N[g] -= 1
    if r > 0:
        _N[r] += 1
    _seen += 1

    return scores
# EVOLVE-BLOCK-END
