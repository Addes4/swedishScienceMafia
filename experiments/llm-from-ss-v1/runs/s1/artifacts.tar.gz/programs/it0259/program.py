# EVOLVE-BLOCK-START
"""Best-fit rule with a sum-of-squares tiebreak.

Place each item into the bin with the smallest remaining capacity that still fits it (best fit),
which packs items densely and keeps large residuals available for large future items. Among
placements with an equal residual, prefer the one that least increases the sum-of-squares of the
open-bin capacity distribution, which tends to smooth the distribution of residuals and reduce
fragmentation. Ties beyond that prefer the loosest fit.

The function keeps its own record of every opened bin. Unused bins arrive as capacity 100 in bin
index order, so used bins are always a prefix of the bin array and module state starts empty per
instance (fresh process).
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise residual (best fit); secondary: minimise SOS delta; tertiary: looser fit
        scores[k] = -(r * 100000.0) - (delta * 1000.0) + r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(r_new * 100000.0) - (delta_new * 1000.0) + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
