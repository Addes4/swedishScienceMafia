# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a size-aware residual reward.

The classical online rule minimising sum_g N(g)^2 (N(g) = number of open bins with residual g)
is near-optimal.  Here the primary signal stays sum-of-squares, but the within-tie term is
changed from "prefer the tightest fit" to "prefer a residual that a frequent item size can close",
estimated from an online histogram of arriving item sizes.  When no clear preference exists the
rule still falls back to the tightest fit.  Module-level state records every opened bin; since the
harness opens unused bins in index order, the used bins always form a prefix of `bins`.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # frequency of seen item sizes
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, first wins ties."""
    global _caps, _N, _freq, _seen
    s = int(item)
    _freq[s] += 1
    _seen += 1
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # A residual r is "good" if it equals a size that arrives often, so it can be closed exactly.
    def match_bonus(r):
        if r <= 0:
            return 0.0
        # normalized frequency of items of size r
        return _freq[r] / _seen if _seen else 0.0

    def penalty(r):
        if r <= 0:
            return 0.0
        p = 0.0
        if r <= 4:
            p += 3.0
        p += 0.15 * r
        return p

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * 1000 + r) - penalty(r) + 25.0 * match_bonus(r)
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000 + r_new) - penalty(r_new) + 25.0 * match_bonus(r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

