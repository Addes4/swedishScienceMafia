# EVOLVE-BLOCK-START
"""Best-fit primary with sum-of-squares secondary and loosest-fit tertiary tiebreak.

Each item goes into the fitting bin with the smallest residual (best fit), which packs bins
tightly and tends to reduce the number of bins used online. Ties on residual are broken by the
exact sum-of-squares delta, and final ties prefer the loosest bin. The function keeps its own
record of every opened bin; the harness opens unused bins in index order, so used bins are always
a prefix of the bin array. Each instance runs in a fresh process, so module state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # exact change in sum_g N(g)^2 when moving this item into the bin with residual r
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: smallest residual (best fit); secondary: smallest delta; tertiary: looser fit
        scores[k] = -(r * 1000000) - (delta * 1000) + g

    if n_unused > 0:
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        # unused bins all identical; score must scale in the same units as fitting scores
        scores[len(fitting):] = -(r_new * 1000000) - (delta_new * 1000) + CAP

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

