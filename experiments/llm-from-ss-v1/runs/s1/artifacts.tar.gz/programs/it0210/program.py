# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a loosest-fit tiebreaker (vectorized).

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among exact sum-of-squares ties, prefer the bin with the largest
remaining capacity (loosest fit), which spreads load and avoids prematurely creating tiny
unusable residuals.

The function keeps its own record of every opened bin. Unused bins are always at the end of
the array and all have remaining capacity CAP, so their SOS delta is identical; only the
opened bins need per-bin treatment. The objective is evaluated with numpy vectorization.
"""
import numpy as np

CAP = 100
_M = CAP + 1
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * _M                  # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n = len(bins)
    n_open = len(_caps)
    scores = np.empty(n, dtype=np.float64)

    if n_open:
        caps_arr = np.array(_caps, dtype=np.int64)
        # indices of opened bins that still fit the item
        fit_idx = np.nonzero(caps_arr >= s)[0]
        scores[:n_open] = -np.inf
        if fit_idx.size:
            g = caps_arr[fit_idx]
            r = g - s
            Ng = np.array(_N, dtype=np.int64)[g]
            Nr = np.array(_N, dtype=np.int64)[r]
            delta = -2 * Ng + 1
            pos = r > 0
            delta = delta + np.where(pos, 2 * Nr + 1, 0)
            scores[fit_idx] = -(delta * 1000.0) + r

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if n_open < n:
        scores[n_open:] = -(delta_new * 1000.0) + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < n_open:
        g = _caps[choice]
        _N[g] -= 1
        _caps[choice] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_open < n:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
