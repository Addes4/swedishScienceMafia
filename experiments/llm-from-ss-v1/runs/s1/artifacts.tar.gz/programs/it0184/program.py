# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a loosest-fit tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer the bin with the largest remaining capacity
(loosest fit), which spreads load and avoids prematurely creating tiny unusable residuals.
The function keeps its own record of every opened bin's remaining capacity, indexed by bin position.
The harness opens unused bins in index order (ties go to the first bin), so used bins are always a
prefix of the bin array. Each instance runs in a fresh process, so the module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    n = len(bins)
    scores = np.empty(n, dtype=np.float64)

    # capacities of opened bins (prefix), plus unused bins reported as CAP
    used = len(_caps)
    caps = np.full(n, CAP, dtype=np.int64)
    if used:
        caps[:used] = _caps

    # residuals for every bin
    res = caps - s

    # SOS delta (change in sum_g N(g)^2) for each candidate bin
    Ng = np.array(_N, dtype=np.int64)
    # contribution from removing a bin at capacity caps[i] and adding residual res[i]
    delta = np.empty(n, dtype=np.int64)
    for i in range(n):
        g = int(caps[i])
        r = int(res[i])
        d = -2 * _N[g] + 1
        if r > 0:
            d += 2 * _N[r] + 1
        delta[i] = d

    # primary: minimise delta; tiebreak: prefer larger residual (loosest fit)
    scores = -(delta.astype(np.float64) * 1000.0) + res

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    g = int(caps[choice])
    r = g - s
    _N[g] -= 1
    if choice < used:
        _caps[choice] = r
    else:
        _caps.append(r)
    if r > 0:
        _N[r] += 1
    return scores
# EVOLVE-BLOCK-END
