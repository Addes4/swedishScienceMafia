# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a learned "good residual" tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer the bin whose resulting residual r is a
"useful" capacity: one that is likely to be exactly filled by a typical future item size. We estimate
this online from the observed item-size histogram, giving preference to residuals that match common
item sizes (which tend to be perfect fits later), breaking any remaining tie by loosest fit.

The function keeps its own record of every opened bin. The harness opens unused bins in index order
(ties go to the first bin), so used bins are always a prefix of the bin array. Each instance runs in a
fresh process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                       # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)             # N[g]: open bins with remaining capacity g, 0 < g < CAP
_item_count = [0] * (CAP + 1)    # observed item-size histogram
_items_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _items_seen
    s = int(item)

    # update the item-size histogram before ranking (use current knowledge)
    _item_count[s] += 1
    _items_seen += 1

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # tiebreak: how common is this residual as an item size? (perfect-fit potential)
        fit_score = _item_count[r] if r > 0 else 0
        scores[k] = -(delta * 1e6) + fit_score * 1000 + r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    fit_new = _item_count[r_new] if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1e6) + fit_new * 1000 + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
