# EVOLVE-BLOCK-START
"""Best-Fit rule.

Place each item in the fitting bin that leaves the smallest residual (tightest fit). If the item
fits in an unused bin (remaining capacity 100 is shown as a fitting bin), it is naturally preferred
only when no used bin has residual >= item. This is the classic Best-Fit heuristic, which is
strong and simple for online bin packing.

The function keeps its own record of every opened bin. The harness opens unused bins in index order
(ties go to the first bin), so used bins are always a prefix of the bin array. Each instance runs in
a fresh process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # best fit: smallest residual -> highest score
    for k, j in enumerate(fitting):
        scores[k] = -( _caps[j] - s )
    # unused bins leave residual CAP - s, usually larger -> lower score than tight used bins
    scores[len(fitting):] = -( CAP - s )

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _caps[j] = g - s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END

