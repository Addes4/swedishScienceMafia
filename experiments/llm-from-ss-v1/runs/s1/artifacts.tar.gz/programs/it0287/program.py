# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a loosest-fit tiebreaker, keyed off the harness bins array.

Each item goes where it minimises the sum-of-squares delta of open-bin capacity counts
N(g). Among exact sum-of-squares ties, prefer the bin with the largest remaining capacity
(loosest fit), which spreads load and avoids prematurely creating tiny unusable residuals.
All residual bookkeeping is derived from the harness-supplied `bins` array (the authoritative
set of bins the item fits in), so our counts never drift from reality. Unused bins always have
remaining capacity 100. Each instance runs in a fresh process, so module state starts empty.
"""
import numpy as np

CAP = 100
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_used = 0                      # number of bins already opened (with capacity < CAP)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _N, _used
    s = int(item)
    caps = bins                       # authoritative remaining capacities, bin order
    n = len(caps)

    scores = np.empty(n, dtype=np.float64)
    for j in range(n):
        g = int(caps[j])
        if g >= s:
            r = g - s
            if g == CAP:
                # unused bin: opening it. Removal of a full bin adds no count change.
                delta = (2 * _N[r] + 1) if r > 0 else 0
            else:
                # moving from residual g to residual r
                delta = -2 * _N[g] + 1 + ((2 * _N[r] + 1) if r > 0 else 0)
            scores[j] = -(delta * 1000) + r
        else:
            scores[j] = -np.inf

    choice = int(np.argmax(scores))   # harness picks first highest score

    # Update our counts to mirror the placement the harness will make.
    g = int(caps[choice])
    r = g - s
    if g != CAP:
        _N[g] -= 1
    if r > 0 and r != CAP:
        _N[r] += 1
    if g == CAP:
        _used += 1
    # Refresh: unused bins still at CAP contribute nothing to _N.
    return scores
# EVOLVE-BLOCK-END
