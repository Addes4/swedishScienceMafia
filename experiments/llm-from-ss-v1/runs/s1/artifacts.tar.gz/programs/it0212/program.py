# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a "future-fillable residual" tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among exact sum-of-squares ties, prefer the bin whose residual is
most likely to be usefully filled later: we precompute, from a static Weibull(shape=1.5)
approximation of the item distribution, a score fill[r] = probability that a future item of
size exactly r arrives (a perfect single-item fill), with a mild preference for larger
residuals as a final fallback (loosest fit).

State is module-level; each instance runs in a fresh process so it starts empty.
"""
import numpy as np
from scipy.stats import weibull_min

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# Static estimate of the item distribution (mean ~40 Weibull-shaped).
_shape = 1.5
_scale = 40.0 / 0.9027452929509336  # mean of Weibull(1.5) = scale * Gamma(1 + 1/1.5)
_x = np.arange(1, CAP + 1)
_pmf = weibull_min.pdf(_x, _shape, scale=_scale)
_pmf = _pmf / _pmf.sum()
_fill = np.zeros(CAP + 1, dtype=np.float64)
for r in range(1, CAP):
    _fill[r] = _pmf[r - 1]     # prob of an item of size exactly r arriving
_fill = _fill / _fill.max() if _fill.max() > 0 else _fill
# small bonus so SOS ties fall back to loosest fit smoothly
_fill = _fill * 1000.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * 1e9) + _fill[r] + r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1e9) + _fill[r_new] + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
