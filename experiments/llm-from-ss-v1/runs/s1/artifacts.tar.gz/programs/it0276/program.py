# EVOLVE-BLOCK-START
"""Exact sum-of-squares rule.

Each arriving item is placed so as to minimise the resulting sum over distinct capacity
values g of N(g)^2, where N(g) counts open bins with remaining capacity g (0 < g < 100).
Rather than ranking bins by a local incremental delta, we evaluate the *exact* objective
that would result from each candidate: remove the candidate's current capacity, add the
new residual, and compute the change to sum N(g)^2. Among exact ties we prefer the larger
residual (loosest fit) to spread load and avoid stranding tiny unusable leftovers.
The function keeps its own record of every opened bin; since the harness opens unused bins
in index order, used bins always form a prefix of the bin array. State is module-level and
resets per process (fresh per instance).
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Exact objective change for placing into an existing bin with capacity g:
    # remove g from its group, add residual r = g - s to its group.
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        # change from removing one bin of capacity g (if g>0)
        d = -2 * _N[g] + 1
        # change from adding one bin of capacity r (if r>0)
        if r > 0:
            d += 2 * _N[r] + 1
        scores[k] = -(d * 1000) + r

    # Opening an unused bin: only adds a new residual r_new = CAP - s.
    r_new = CAP - s
    d_new = (2 * _N[r_new] + 1) if r_new > 0 else 0
    scores[len(fitting):] = -(d_new * 1000) + r_new

    choice = int(np.argmax(scores))          # harness picks first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
