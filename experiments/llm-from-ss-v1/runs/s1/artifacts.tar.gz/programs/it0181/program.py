# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a size-aware tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with
remaining capacity g (0 < g < CAP). The SOS objective is the primary key; among exact
SOS ties we break toward the residual that best matches a robust running estimate of
typical upcoming item size (a running median), which keeps useful residuals available
without the aggressive waste of pure "loosest fit".

The function keeps its own record of every opened bin. The harness opens unused bins in
index order (ties go to the first bin), so used bins are always a prefix of the bin array.
Each instance runs in a fresh process, so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_sizes = []                    # item sizes seen so far (for a running median estimate)


def _median_est():
    if not _sizes:
        return 40
    k = len(_sizes)
    if k < 100:
        return sorted(_sizes)[k // 2]
    # recent window median to adapt quickly
    w = _sizes[-200:]
    w = sorted(w)
    return w[len(w) // 2]


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _sizes
    s = int(item)
    mid = _median_est()
    _sizes.append(s)
    if len(_sizes) > 400:
        del _sizes[:200]

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Tiebreak: prefer residual closest to the running median item size.
    def tie(r):
        if r <= 0:
            return 0.0
        return -abs(r - mid)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * 100000.0) + tie(r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 100000.0) + tie(r_new)

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

