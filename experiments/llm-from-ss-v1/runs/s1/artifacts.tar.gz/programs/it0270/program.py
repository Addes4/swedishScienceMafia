# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a residual-size-aware tiebreaker.

Primary objective: minimise the change in sum_g N(g)^2, where N(g) counts open bins with
remaining capacity g (0 < g < 100). This is the classic sum-of-squares bin-choice rule.

Tiebreak: among exact SOS ties, prefer candidates whose residual is either exactly 0 (a
perfectly closed bin) or large enough to be plausibly refilled, and mildly penalise tiny
residuals (1..MIN_SMALL) which tend to strand space that future items cannot use.

The function keeps its own record of every opened bin. The harness opens unused bins in
index order (ties go to the first bin), so used bins are always a prefix of the bin array.
Each instance runs in a fresh process, so module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_MIN_SMALL = 4                 # residuals 1.._MIN_SMALL are considered "small/wasteful"


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # secondary key: penalise small wasteful residuals, reward exact 0
        if r == 0:
            bonus = 2
        elif r <= _MIN_SMALL:
            bonus = -1
        else:
            bonus = 1
        scores[k] = -(delta * 1000) + bonus
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if r_new == 0:
        bonus_new = 2
    elif r_new <= _MIN_SMALL:
        bonus_new = -1
    else:
        bonus_new = 1
    scores[len(fitting):] = -(delta_new * 1000) + bonus_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
