# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with loosest-fit tiebreaker plus residual-population heuristic.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among exact ties, prefer the bin with the largest remaining
capacity (loosest fit). This strong objective is augmented with a small heuristic bonus
rewarding residuals whose value is common among currently open bins, which tends to let
later items close bins exactly. The harness opens unused bins in index order, so used bins
are always a prefix of the bin array.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        bonus = 0.0
        if r == 0:
            bonus = 1.0
        elif r > 0:
            # reward a residual that already matches a common open capacity
            bonus = 0.25 * _N[r]
        scores[k] = -(delta * 1000) + r + bonus
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    bonus_new = 0.0
    if r_new == 0:
        bonus_new = 1.0
    elif r_new > 0:
        bonus_new = 0.25 * _N[r_new]
    scores[len(fitting):] = -(delta_new * 1000) + r_new + bonus_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
