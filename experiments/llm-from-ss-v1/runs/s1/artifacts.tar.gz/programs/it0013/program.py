# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an empirical residual-value penalty.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100); ties go to the tighter fit. The secondary penalty rewards residuals that match a
frequently observed item size (so the residual can likely be filled exactly later) and mildly
penalises waste. The function keeps its own record of every opened bin. The harness opens unused bins
in index order (ties go to the first bin), so used bins are always a prefix of the bin array. Each
instance runs in a fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_cnt = np.zeros(CAP + 1)       # observed item sizes

def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _cnt
    s = int(item)
    _cnt[s] += 1
    total = _cnt.sum()
    # empirical probability that a residual r can be filled exactly by a common item size
    # (normalised count of item size == r, with light smoothing)
    p_fill = (_cnt / max(total, 1.0))

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    def penalty(r):
        if r <= 0:
            return 0.0
        # reward residuals equal to a common item size; penalise waste mildly.
        return -8.0 * p_fill[r] + 0.05 * r

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * 1000 + r) - penalty(r)
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000 + r_new) - penalty(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
