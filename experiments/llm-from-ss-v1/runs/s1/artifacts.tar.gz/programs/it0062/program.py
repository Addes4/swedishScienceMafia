# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a mean-residual tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among exact sum-of-squares ties, prefer the bin whose residual after
placement is closest to the running mean item size: residuals near the typical item size are the
most likely to be consumed by a future item, which keeps bins refillable and avoids stranding
unusable small gaps. The primary key is the exact integer delta, so it is truly lexicographic
(no scaling artefacts). The function keeps its own record of every opened bin; unused bins are
always a prefix extension of the bin array, so used bins form a prefix.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_count = 0                     # number of items seen so far
_sum = 0                       # sum of item sizes seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _count, _sum
    s = int(item)
    _count += 1
    _sum += s
    mean = _sum / _count

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)

    deltas = np.empty(len(bins), dtype=np.float64)
    residuals = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        deltas[k] = delta
        residuals[k] = r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    deltas[len(fitting):] = delta_new
    residuals[len(fitting):] = r_new

    # lexicographic: minimise delta; among ties prefer residual closest to mean item size
    tiebreak = -np.abs(residuals - mean)
    # combine with a scale large enough to dominate the (bounded) tiebreak
    scores = -(deltas * 1_000_000.0) + tiebreak

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
