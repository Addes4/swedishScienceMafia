# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an adaptive frequency-based tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining capacity g
(0 < g < 100). Among exact sum-of-squares ties, prefer the placement whose resulting residual equals a
historically frequent item size (as tracked by a rolling histogram of observed items), so that bin can
later be exactly filled. Remaining ties go to the largest residual (loosest fit). The harness opens
unused bins in index order, so used bins are always a prefix of the bin array; each instance runs in a
fresh process, so module-level state starts empty per instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # rolling count of observed item sizes


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _freq
    s = int(item)
    _freq[s] += 1
    # exponentially decayed histogram keeps the tiebreaker adaptive but recent
    if sum(_freq) > 0 and sum(_freq) % 50 == 0:
        for i in range(CAP + 1):
            _freq[i] = _freq[i] * 3 // 4

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    def prio(r):
        # primary (minimise delta), tiebreak: residual matches a frequent item size, then looser
        freq_bonus = _freq[r] if r > 0 else 0
        return freq_bonus * 10**6 + r

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = -(delta * 10**12) + prio(r)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 10**12) + prio(r_new)

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
