# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a one-step-lookahead tiebreaker.

Primary objective: place the item where it minimises sum_g N(g)^2, where N(g) counts open bins
with remaining capacity g (0 < g < 100). This is the exact change in the sum of squares of the
residual capacities, a strong near-optimal proxy for the remaining number of bins.

Tiebreaker: ties in the sum-of-squares delta are broken by a one-step lookahead. We maintain a
decaying histogram of past item sizes and, for each tied placement, estimate the expected
sum-of-squares delta if one more item were drawn from that histogram and placed optimally. The
placement with the smallest expected future delta wins. This adapts the tiebreak to the item
distribution while using only past observations.

The harness opens unused bins in index order (ties go to the first bin), so used bins are
always a prefix of the bin array. Each instance runs in a fresh process, so module-level state
starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_hist = np.zeros(CAP + 1)      # decaying histogram of past item sizes (index = size)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _hist
    s = int(item)

    # update the decaying histogram of observed item sizes (used only for tiebreaking)
    _hist *= 0.9995
    _hist[s] += 1.0
    total_hist = _hist.sum()
    if total_hist > 0:
        probs = _hist / total_hist
    else:
        probs = None

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # helper: expected sum-of-squares delta for one future item given current N and a candidate residual r
    def expected_future_delta(residual_now):
        if probs is None:
            return 0.0
        # simulate adding residual_now to the population temporarily
        Nloc = _N[:]  # copy
        if residual_now > 0:
            Nloc[residual_now] += 1
        exp = 0.0
        for t in range(1, CAP + 1):
            p = probs[t]
            if p == 0.0:
                continue
            # find best delta if item t is placed: consider fitting residuals >= t and a new bin
            best = None
            for g in range(t, CAP + 1):
                if Nloc[g] == 0:
                    continue
                r = g - t
                delta = -2 * Nloc[g] + 1 + (2 * Nloc[r] + 1 if r > 0 else 0)
                if best is None or delta < best:
                    best = delta
            # new bin option
            r_new = CAP - t
            delta_new = 2 * Nloc[r_new] + 1 if r_new > 0 else 0
            if best is None or delta_new < best:
                best = delta_new
            exp += p * best
        return exp

    # compute primary deltas and, for ties, the lookahead value
    prims = []
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        prims.append(delta)
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0

    # find minimal primary delta among all options
    min_delta = min(prims) if prims else None
    if min_delta is None or delta_new < min_delta:
        min_delta = delta_new

    # for tied candidates, compute lookahead score (only if there are ties)
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = prims[k]
        if delta == min_delta and probs is not None:
            look = expected_future_delta(r)
            # prefer larger lookahead-adjusted residual: score = -(delta major) - look, but delta is tied
            scores[k] = -look + r * 1e-6
        else:
            scores[k] = -delta * 1000.0 + r
    if delta_new == min_delta and probs is not None:
        look = expected_future_delta(r_new)
        scores[len(fitting):] = -look + r_new * 1e-6
    else:
        scores[len(fitting):] = -delta_new * 1000.0 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
