# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an adaptive residual-matching tiebreaker.

Primary objective: place the item where it minimises sum_g N(g)^2, the classic
sum-of-squares (SOS) bin-packing heuristic described by Csirik et al.  The exact
incremental delta of the SOS objective when moving an item of size s into a bin
with remaining capacity g (producing residual r = g - s) is

    delta = -2*N[g] + 1 + (2*N[r] + 1 if r > 0 else 0)

Among exact SOS ties we break conservatively: prefer the placement whose resulting
residual is a commonly seen item size, so that a future item of that size can fill
the bin exactly.  The tiebreaker is scaled strictly below one SOS delta unit
(delta is always an odd integer, so its granularity is 2; we use < 1), keeping the
SOS objective strictly primary.  The residual frequencies come from the histogram
of items observed so far, so the rule is fully online.

The function keeps its own record of every opened bin. The harness opens unused
bins in index order (ties go to the first bin), so used bins are always a prefix of
the bin array. Each instance runs in a fresh process, so the module-level state
starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)        # histogram of item sizes seen so far
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _freq, _seen
    s = int(item)
    _freq[s] += 1
    _seen += 1

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # scale for the residual-matching tiebreaker: strictly below one SOS delta unit
    # (delta is an odd integer; its granularity is 2), so SOS stays strictly primary.
    tie_scale = 0.9 / (_seen + 2.0)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        match = _freq[r] if r > 0 else 0
        # primary: minimise delta (odd integer -> scale by 1000); tiebreak: reward
        # residuals matching common item sizes; then prefer larger residual (loosest).
        scores[k] = -(delta * 1000.0) + (match * tie_scale) + (r * 1e-6)
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    match_new = _freq[r_new] if r_new > 0 else 0
    scores[len(fitting):] = (-(delta_new * 1000.0)
                             + (match_new * tie_scale)
                             + (r_new * 1e-6))

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
