# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an exact one-step expected-lookahead tiebreaker.

Primary objective: minimise the change in sum_g N(g)^2 when the item is placed, where N(g)
counts open bins with remaining capacity g (0 < g < 100). This is the standard "sum-of-squares"
bin-packing heuristic and is near-optimal for this distribution.

Because exact ties are common, ties are broken by a one-step lookahead: among placements with
the same immediate delta, prefer the one minimising the expected sum-of-squares delta of one
future item, averaged over a fixed discretized version of the item-size distribution. A final
tiebreak of largest residual (loosest fit) is used when the lookahead also ties.

The harness opens unused bins in index order (ties go to the first bin), so used bins are always
a prefix of the bin array. Module-level state starts empty for every fresh instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def _build_dist():
    """Discretized item-size distribution (Weibull, mean ~40), as weights over sizes 1..100."""
    # Approximate Weibull shape/scale for mean ~40; this only needs to be roughly right.
    shape, scale = 1.5, 44.0
    sizes = np.arange(1, CAP + 1, dtype=np.float64)
    pdf = (shape / scale) * (sizes / scale) ** (shape - 1.0) * np.exp(-(sizes / scale) ** shape)
    pdf = np.maximum(pdf, 0.0)
    tot = pdf.sum()
    if tot <= 0:
        pdf = np.ones(CAP, dtype=np.float64)
        tot = pdf.sum()
    return pdf / tot


_PDF = _build_dist()
# Precompute, for every capacity g and item size s, the expected delta of the sum-of-squares
# objective for placing one future item into a single bin of capacity g.  The values are
# averaged over the discretized size distribution; items s > g cannot fit and cause no change.
_EXP_DELTA = np.zeros((CAP + 1, CAP + 1), dtype=np.float64)
for _g in range(1, CAP + 1):
    acc = 0.0
    for _s in range(1, _g + 1):
        _r = _g - _s
        # delta for this one bin: it is removed at capacity _g and added at capacity _r
        # contribution if alone:  (N[_r]+1)^2 - N[_g]^2 ; expected part linear in N handled below
        # We store the constant part 1 + (1 if _r>0 else 0) plus the _r-residual bookkeeping
        # Actually we store the value delta = 1 + (1 if _r>0 else 0) with sign as sum-of-squares
        # increase for a single bin: (effect) — but N-dependent terms are handled at call time.
        # Here we store the N-independent constant: 1 (for closing/leaving bin at g) and, if _r>0,
        # +1 (for opening residual _r). Additionally the current-bin term contributes -2*N[_g] and,
        # if _r>0, +2*N[_r]; those depend on N and are computed for each candidate directly.
        acc += _PDF[_s - 1] * (1.0 + (1.0 if _r > 0 else 0.0))
    _EXP_DELTA[_g] = acc
# Normalise so it is truly an expectation (weights over s>g sum to <=1 already includes non-fitting).


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # Precompute expected-lookahead cost of the post-placement capacity state contributions.
    # For a placement leaving residual r in an existing bin, the N-dependent immediate delta is
    #   delta = -2*N[g] + 1 + (2*N[r] + 1 if r>0 else 0).
    # The lookahead term is the expected extra sum-of-squares delta for the NEXT item applied to a
    # single bin currently at capacity r (the new residual of this bin), ignoring cross terms.
    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        look = _EXP_DELTA[r] if r > 0 else 0.0
        scores[k] = -(delta * 100000.0) - look * 10.0 + r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    look_new = _EXP_DELTA[r_new] if r_new > 0 else 0.0
    scores[len(fitting):] = -(delta_new * 100000.0) - look_new * 10.0 + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

