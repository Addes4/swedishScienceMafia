# EVOLVE-BLOCK-START
"""Best-fit with a usability floor, sum-of-squares as a backstop.

The item goes to the fitting bin whose residual is smallest but still at least the smallest
item size observed so far (so we don't burn capacity into unusable slivers), using the
classic best-fit tightness as the primary signal. When no such residual exists we fall back
to the exact sum-of-squares delta (minimise sum_g N(g)^2), which is a good continuous proxy
for future bin count. The harness opens unused bins in index order and ties go to the first
bin, so used bins are always a prefix; the module state is rebuilt fresh per instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP
_min_item = CAP                # smallest item size seen so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _min_item
    s = int(item)
    if s < _min_item:
        _min_item = s
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    floor = _min_item

    def bonus(r):
        # primary: prefer smallest usable residual (>= floor) -> best-fit tightness
        # secondary: prefer larger residual (loosest fit) among equally tight ones
        # tertiary: sum-of-squares delta (minimise) as continuous proxy
        delta = 0
        if r > 0:
            delta = 2 * _N[r] + 1
        usable = 1 if r >= floor else 0
        return usable * 1000000 + (floor - r if r < floor else -r) * 1 + (-delta) * 0.001

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        scores[k] = bonus(r) - delta * 0.0001
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = bonus(r_new) - delta_new * 0.0001

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
