# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a loosest-fit tiebreaker (kept as the proven best).

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among exact sum-of-squares ties, prefer the bin with the largest
remaining residual (loosest fit). This spreads load and has proven the most robust of the
tiebreaks tried. The function keeps its own record of every opened bin. The harness opens
unused bins in index order (ties go to the first bin), so used bins are always a prefix of the
bin array. Each instance runs in a fresh process, so the module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = int(item)
    scores = np.empty(len(bins), dtype=np.float64)

    if len(bins) == len(_caps):
        # No unused bins available: only existing open bins, all of which fit (or some don't).
        for j, g in enumerate(_caps):
            if g >= s:
                r = g - s
                delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
                scores[j] = -(delta * 1000) + r
            else:
                # Bin does not fit; keep it in the array but push its score far below.
                scores[j] = -1e18
    else:
        fitting = [j for j, g in enumerate(_caps) if g >= s]
        for k, j in enumerate(fitting):
            g = _caps[j]
            r = g - s
            delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
            scores[k] = -(delta * 1000) + r
        r_new = CAP - s
        delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
        scores[len(fitting):] = -(delta_new * 1000) + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(_caps):
        g = _caps[choice]
        if g < s:
            # Should not happen because such bins are scored -1e18; guard anyway.
            return scores
        _N[g] -= 1
        _caps[choice] = g - s
        if g - s > 0:
            _N[g - s] += 1
    else:
        # Choosing an unused bin: append it as a new opened bin.
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

