# EVOLVE-BLOCK-START
"""Best-fit packing rule.

Each arriving item is placed into the fitting bin with the smallest remaining capacity
(the tightest fit). Unused bins (capacity 100) are treated as ordinary fitting bins, so the
packer naturally avoids opening a new bin unless no partially-filled bin offers a tight fit.
The function keeps its own record of every opened bin. Unused bins appear in index order and
used bins are always a prefix of the bin array; each instance runs in a fresh process so the
module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        scores[k] = -_caps[j]           # prefer the tightest fit
    scores[len(fitting):] = -CAP          # unused bins are equivalent to capacity 100

    choice = int(np.argmax(scores))       # first highest score
    if choice < len(fitting):
        j = fitting[choice]
        _caps[j] -= s
    elif n_unused > 0:
        _caps.append(CAP - s)
    return scores
# EVOLVE-BLOCK-END
