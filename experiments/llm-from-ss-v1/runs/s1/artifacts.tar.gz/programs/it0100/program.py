# EVOLVE-BLOCK-START
"""Discounted sum-of-squares rule with a loosest-fit tiebreaker.

Each item goes where it minimises sum_g w_g * N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100) and w_g is a per-residual weight derived from the empirical item-size
distribution seen so far. Because the item-size distribution is fixed but unknown a priori, the
weights adapt online, sharpening the sum-of-squares penalty near residuals that commonly appear.

Among exact ties, prefer the bin with the largest remaining capacity (loosest fit), which spreads
load and avoids prematurely creating tiny unusable residuals.

The function keeps its own record of every opened bin. The harness opens unused bins in index
order (ties go to the first bin), so used bins are always a prefix of the bin array. Each instance
runs in a fresh process, so the module-level state starts empty for every instance.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0.0] * (CAP + 1)         # N[g]: weighted count of open bins with remaining capacity g
_total = 0.0                   # total weight of observed items
_hist = [0.0] * (CAP + 1)      # exponential forgetting histogram of item sizes
_DECAY = 0.997                 # forgetting factor


def _weight(r):
    """Weight for a residual r: fraction of recent items no larger than r.

    A residual that few items can fill is nearly wasted, so we down-weight the sum-of-squares
    penalty there and let the tiebreaker favor more useful residuals indirectly.
    """
    if r <= 0:
        return 0.0
    tot = _total if _total > 0 else 1.0
    cum = 0.0
    cap = r if r < CAP else CAP
    for k in range(1, cap + 1):
        cum += _hist[k]
    return 1.0 + 3.0 * (cum / tot)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _total, _hist
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2.0 * _N[g] + 1.0
        if r > 0:
            delta += 2.0 * _N[r] + 1.0
        wr = _weight(r) if r > 0 else 0.0
        # primary: minimise weighted delta; tiebreak: prefer larger residual (loosest fit)
        scores[k] = -(delta * 1000.0) + r * 1.0 + wr * 0.0 + r
    r_new = CAP - s
    delta_new = 2.0 * _N[r_new] + 1.0 if r_new > 0 else 0.0
    scores[len(fitting):] = -(delta_new * 1000.0) + r_new * 1.0 + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1.0
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1.0
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1.0

    # update empirical distribution
    for k in range(1, CAP + 1):
        _hist[k] *= _DECAY
    _hist[s] += 1.0
    _total = _total * _DECAY + 1.0
    return scores
# EVOLVE-BLOCK-END
