# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a group-merging tiebreaker.

Each item goes where it minimises the sum-of-squares of the open-bin residual counts,
sum_g N(g)^2. Among exact SOS ties, prefer a residual that already exists as an open
residual group (so the number of distinct residual sizes does not grow), and only then
prefer the loosest fit. This targets fragmentation while keeping the strong primary
objective untouched.

The function keeps its own record of every opened bin. Unused bins are opened in index
order (ties go to the first bin), so used bins always form a prefix of the bin array.
Each instance runs in a fresh process, so module state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta (SOS). tiebreak: prefer merging into an existing
        # residual group, then looser fit.
        merge_bonus = 1 if (r > 0 and _N[r] > 0) else 0
        scores[k] = -(delta * 100000) + merge_bonus * 1000 + r
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    merge_new = 1 if (r_new > 0 and _N[r_new] > 0) else 0
    scores[len(fitting):] = -(delta_new * 100000) + merge_new * 1000 + r_new

    choice = int(np.argmax(scores))
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END

