# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with an adaptive residual-matching tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). Among exact sum-of-squares ties, prefer the bin whose resulting
residual best matches frequently seen recent item sizes, which tends to create residuals that
later items can consume exactly. Falls back to loosest fit. State is per-process.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP

# recent item-size histogram (windowed) to estimate which residual sizes are valuable
_recent = [0] * (CAP + 1)
_recent_total = 0
WINDOW = 64


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _caps, _N, _recent, _recent_total
    s = int(item)

    # update recent histogram (approximate sliding window via decaying counts)
    if _recent_total >= WINDOW:
        # decay: halve all counts periodically to keep window bounded
        for i in range(1, CAP + 1):
            _recent[i] >>= 1
        _recent_total = sum(_recent)
    if 0 < s <= CAP:
        _recent[s] += 1
        _recent_total += 1

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        bonus = _recent[r] if r > 0 else 0
        # primary: minimise delta; tiebreak: residual matches common item sizes, else loosest fit
        scores[k] = -(delta * 100000) + (bonus * 100) + r

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    bonus_new = _recent[r_new] if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 100000) + (bonus_new * 100) + r_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
