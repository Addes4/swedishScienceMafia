# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a matching-residual tiebreaker.

Each item goes where it minimises sum_g N(g)^2, where N(g) counts open bins with remaining
capacity g (0 < g < 100). The primary key is the exact integer sum-of-squares delta, so there
is no numeric scaling/precision loss. Among exact primary ties we use a deterministic
secondary key: prefer the residual that already exists among open bins (forming a perfect
future pair) and, secondarily, the smallest residual (which closes bins tightest). The
harness opens unused bins in index order, so used bins are always a prefix of the array, and
each instance runs in a fresh process so module-level state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                     # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)           # N[g]: open bins with remaining capacity g, 0 < g < CAP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N
    s = int(item)
    fitting = [j for j, g in enumerate(_caps) if g >= s]

    # Determine, per fitting bin, the exact integer primary delta and secondary key.
    # Primary: sum-of-squares delta. Secondary: prefer residual r with _N[r] > 0 (perfect
    # pair exists); then prefer smaller r. We pack into a single integer score.
    BONUS = 1000  # secondary magnitude; delta is small so no interference

    best_scores = []
    for j in fitting:
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        if r > 0 and _N[r] > 0:
            sec = 1          # perfect pair available
        else:
            sec = 0
        # prefer smaller delta; among ties prefer sec=1, then smaller residual r
        key = -(delta * BONUS * 1000) + sec * 1000 - r
        best_scores.append(key)

    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    if r_new > 0 and _N[r_new] > 0:
        sec_new = 1
    else:
        sec_new = 0
    key_new = -(delta_new * BONUS * 1000) + sec_new * 1000 - r_new

    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)
    for k in range(len(fitting)):
        scores[k] = best_scores[k]
    scores[len(fitting):] = key_new

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
