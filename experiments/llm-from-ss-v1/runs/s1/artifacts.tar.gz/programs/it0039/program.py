# EVOLVE-BLOCK-START
"""Sum-of-Squares rule with a learned residual-match tiebreaker.

Each item goes where it minimises sum_g N(g)^2 (N(g) = open bins with remaining capacity g).
This potential is the exchange-potential whose greedy minimisation is optimal for the
"ranking" objective and near-optimal online for bin packing. Among exact sum-of-squares
ties, we learned that residuals which can be closed exactly by a recently seen item size
are valuable, so we prefer residuals near frequent recent item sizes, still preferring
larger residuals when the match quality is equal (loosest fit spreads load). We keep an
online frequency table of recent item sizes. The function also keeps its own record of
every opened bin; the harness opens unused bins in index order, so used bins are always a
prefix of the bin array. Each instance runs in a fresh process, so module state starts empty.
"""
import numpy as np

CAP = 100
_caps = []                      # remaining capacity of every opened bin, in bin-index order
_N = [0] * (CAP + 1)            # N[g]: open bins with remaining capacity g, 0 < g < CAP
_freq = [0] * (CAP + 1)         # recent item-size frequency (decayed)
_decay = 0.999


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _caps, _N, _freq
    s = int(item)
    # decay the recent-item histogram so it tracks the current item regime
    if s <= CAP:
        for g in range(1, CAP + 1):
            if _freq[g]:
                _freq[g] *= _decay
        _freq[s] += 1.0

    fitting = [j for j, g in enumerate(_caps) if g >= s]
    n_unused = len(bins) - len(fitting)
    scores = np.empty(len(bins), dtype=np.float64)

    # small weight for the residual-match tiebreak (must stay below the delta granularity)
    w = 0.4

    def match_bonus(r):
        # reward residuals that are exactly a recent item size (closable later)
        if r <= 0:
            return 0.0
        f = _freq[r]
        # normalise by a running scale; use sqrt to damp large frequencies
        return f ** 0.5

    for k, j in enumerate(fitting):
        g = _caps[j]
        r = g - s
        delta = -2 * _N[g] + 1 + (2 * _N[r] + 1 if r > 0 else 0)
        # primary: minimise delta; tiebreak: prefer closable/looser residuals
        scores[k] = -(delta * 1000) + w * match_bonus(r) + r * 1e-6
    r_new = CAP - s
    delta_new = 2 * _N[r_new] + 1 if r_new > 0 else 0
    scores[len(fitting):] = -(delta_new * 1000) + w * match_bonus(r_new) + r_new * 1e-6

    choice = int(np.argmax(scores))          # the harness's choice: first highest score
    if choice < len(fitting):
        j = fitting[choice]
        g = _caps[j]
        _N[g] -= 1
        _caps[j] = g - s
        if g - s > 0:
            _N[g - s] += 1
    elif n_unused > 0:
        _caps.append(CAP - s)
        if CAP - s > 0:
            _N[CAP - s] += 1
    return scores
# EVOLVE-BLOCK-END
