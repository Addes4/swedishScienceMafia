# EVOLVE-BLOCK-START
"""Best fit with a Gaussian-smoothed residual-usefulness tie-break plus a small reusable-size bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0

# offset grid for the Gaussian smoothing kernel over residuals 0..100
_offs = np.arange(-8, 9, dtype=np.float64)
_sigma = 3.0
_gauss = np.exp(-0.5 * (_offs / _sigma) ** 2)
_gauss = _gauss / _gauss.sum()
_half = len(_offs) // 2


def _smooth(freq):
    smoothed = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_gauss):
        off = k - _half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    return smoothed


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    r = residual.astype(np.int64)
    smoothed = _smooth(_counts)
    use = smoothed[r]

    # best-fit dominates: smaller residual strongly preferred
    tight = -1.0 * residual.astype(np.float64)
    score = tight + 0.6 * use

    # small bounded bonus for residuals near the running mean item size (reusable sweet spot)
    if _n > 0.0:
        mean_item = _sum / _n
        reuse = 0.4 * np.exp(-((residual.astype(np.float64) - mean_item) ** 2) /
                             (2.0 * (0.25 * mean_item + 1.0) ** 2))
        score = score + reuse

    # exact fill bonus applied last so it can break near-ties
    score = score + 1000.0 * (residual == 0)

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
