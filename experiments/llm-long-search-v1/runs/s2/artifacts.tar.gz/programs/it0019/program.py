# EVOLVE-BLOCK-START
"""Best fit with a mild residual-reusability tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first bin."""
    residual = bins - item
    # Dominant: tightest fit (smallest residual -> highest score).
    # Secondary: encourage residuals that are either 0 (perfectly packed) or
    # reasonably large (>= 20) over awkward small leftovers.
    useful = (residual >= 20).astype(np.float64)
    return -residual + 0.5 * useful
# EVOLVE-BLOCK-END
