# EVOLVE-BLOCK-START
"""Best fit with a strong residual-ordering core plus a sub-unit fillability tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown
    resid = residual.astype(np.float64)

    # empirical fillability of the residual: how often past items matched this remaining gap
    fill = _counts[np.clip(residual.astype(np.int64), 0, 100)]

    # dominant best-fit term; the sub-unit fillability bonus only breaks residual ties
    score = -1000.0 * resid + fill

    if _n > 0.0:
        pass  # bonus already bounded by cumulative counts, kept from disturbing ordering

    score[residual == 0] += 1e12

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
