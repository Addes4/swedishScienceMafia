# EVOLVE-BLOCK-START
"""Best fit with a strictly-subordinate tie-break favoring larger residuals among ties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    # Strictly dominant best-fit term: gaps of >=1 in residual always dominate.
    score = -residual.astype(np.float64) * 8.0

    # Tiny tie-break (magnitude < 8, so it can never overturn best-fit):
    # among equal residuals, prefer the larger residual only when it still
    # leaves a gap >= item-ish; here we simply prefer larger residuals to
    # avoid stranding many tiny unusable gaps, plus exact-fill bonus.
    score = score + 0.01 * residual.astype(np.float64)

    score[residual == 0] += 1000.0
    return score
# EVOLVE-BLOCK-END

