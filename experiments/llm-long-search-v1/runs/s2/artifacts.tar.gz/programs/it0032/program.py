# EVOLVE-BLOCK-START
"""Best fit with a smoothed histogram-usefulness tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # usefulness of a residual r: expected "match quality" against future item sizes.
    # smooth the empirical histogram with a small triangular kernel so exact-fit noise
    # from the early sample doesn't dominate the tie-break.
    w = np.array([1.0, 2.0, 3.0, 2.0, 1.0])
    w = w / w.sum()
    freq = np.convolve(_counts, w, mode="same")

    # usefulness(r) = frequency mass of items that would leave residual near 0
    # i.e. items of size ~= r.  Also treat r==0 (closing a bin) as maximally useful.
    idx = residual.astype(np.int64)
    use = freq[idx]
    use[idx == 0] += 1.0

    # dominant term: best fit (smallest residual after placement).
    tight = -residual.astype(np.float64)

    score = tight + 0.5 * use

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
