# EVOLVE-BLOCK-START
"""Best fit as strict primary key, with a bounded smoothed-histogram tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Smoothed running histogram of item sizes.
    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    # Best-fit is strictly dominant: residual within [0,100], so multiply by a large
    # factor to guarantee any residual gap of >=1 beats the bounded tie-break bonus.
    score = -1000.0 * res

    # Bounded tie-break (|.| <= ~0.5): among equal residuals prefer the residual that is
    # itself a likely upcoming item size (mass at exactly that residual).
    r = residual.astype(np.int64)
    likely = np.zeros_like(res)
    mask = (r >= 1) & (r <= 100)
    likely[mask] = smoothed[r[mask]]
    norm = smoothed.sum() + 1.0
    score = score + 0.5 * (likely / norm)

    score[residual == 0] += 1e6

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
