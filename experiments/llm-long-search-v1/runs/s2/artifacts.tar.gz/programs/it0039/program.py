# EVOLVE-BLOCK-START
"""Best fit with a smoothed distribution-based residual-utility tie-break."""
import numpy as np

# Empirical histogram of item sizes (index 1..100 used)
_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # Build a smoothed estimate of the item-size distribution.
    # Add-1 smoothing so unseen sizes get small but nonzero mass.
    total = _n + 100.0
    prob = (_counts + 1.0) / total  # prob[s] for s in 0..100

    # Probability that a future item is <= residual (occupancy usefulness).
    # prob[0] is tiny; residual 0 means the bin is exactly closed -> treat specially.
    # Use cumulative sum of prob as P(item <= r).
    cdf = np.cumsum(prob)  # cdf[r] = P(size <= r), r in 0..100

    # Primary: best fit -> smallest residual (negative residual large magnitude better)
    tight = -residual.astype(np.float64)

    # Secondary: prefer residuals that can still be used by future items, weighted
    # by how likely they are to be exactly filled (prob[r]) plus occupancy chance.
    use = cdf[residual] + prob[residual]

    score = tight + 0.5 * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
