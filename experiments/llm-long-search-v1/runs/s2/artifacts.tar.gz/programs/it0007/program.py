# EVOLVE-BLOCK-START
"""Best fit with a mild preference for leaving a reusable residual capacity."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item
    # Primary: tightest fit (smallest leftover). Secondary: prefer residuals that stay
    # reusable (roughly one typical item, ~40), and discourage near-zero fragments.
    reuse_bonus = -np.abs(leftover - 40.0) * 1e-3
    return -leftover * 1.0 + reuse_bonus
# EVOLVE-BLOCK-END
