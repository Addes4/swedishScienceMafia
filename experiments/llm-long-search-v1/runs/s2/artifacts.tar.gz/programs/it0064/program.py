# EVOLVE-BLOCK-START
"""Best fit, but strongly prefer residuals that equal 0 or a common future item size (exact-fit closing)."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # primary: best fit -> smallest residual is best
    score = -residual.astype(np.float64)

    # secondary: reward residuals that equal a common item size (can be closed with ~zero waste)
    freq = _counts / _n if _n > 0 else _counts
    # residual==0 means a perfectly tight bin: highest reward
    score += 2.0 * freq[residual]
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END

