# EVOLVE-BLOCK-START
"""Best fit, ties broken by expected future waste from the empirical item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)  # offsets -2..+2

# Precomputed cache of expected-waste values indexed by residual (0..100).
_waste_cache = None
_waste_dirty = True
_last_n = -1.0


def _expected_waste():
    """Estimate, for each possible residual r, the expected unusable capacity left
    in a bin with that residual, given the empirical histogram of past item sizes."""
    global _waste_cache, _waste_dirty, _last_n
    if not _waste_dirty and _last_n == _n:
        return _waste_cache

    freq = _counts
    total = freq.sum()
    if total <= 0:
        _waste_cache = np.zeros(101, dtype=np.float64)
        _waste_dirty = False
        _last_n = _n
        return _waste_cache

    probs = freq / total  # probability of each item size
    sizes = np.arange(101, dtype=np.int64)
    res = np.arange(101, dtype=np.int64)

    # For residual r, expected waste = min over item size s<=r of ... a simple proxy:
    # expected final leftover = min over s<=r of (r - s) weighted by reaching-then-stuck.
    # We approximate: waste(r) = sum_{s<=r} p(s) * ((r - s) if no item of size<=r-s arrives).
    # Simpler tractable proxy: expected leftover after packing greedily ~ E[(r - best fit)]
    # Use: waste(r) = min_{s<=r such that p(s)>0} (r - s) is zero trivial; instead use
    # expected value of the smallest possible remaining gap given histogram:
    # For each r, expected leftover = sum_{s<=r} p(s) * waste(r - s), with waste(0)=0.
    waste = np.zeros(101, dtype=np.float64)
    # precompute cumulative probability of items fitting in each residual
    for r in range(1, 101):
        acc = 0.0
        w = 0.0
        # probability that the bin can still accept *some* item
        can_fit = probs[: r + 1].sum()
        if can_fit <= 0:
            waste[r] = r
            continue
        # expected leftover conditioned on some item fitting: weighted average of waste(r-s)
        for s in range(1, r + 1):
            p = probs[s]
            if p <= 0:
                continue
            acc += p
            w += p * waste[r - s]
        if acc > 0:
            waste[r] = w / acc
        else:
            waste[r] = r
    _waste_cache = waste
    _waste_dirty = False
    _last_n = _n
    return _waste_cache


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _waste_dirty

    residual = bins - item  # >= 0 for all bins shown

    _waste_dirty = True
    waste = _expected_waste()

    r = residual.astype(np.int64)
    # Best-fit dominant: prefer smallest residual. Tie-break: prefer larger expected waste
    # of this residual (i.e. bins that would leave more unusable space are slightly worse,
    # so we favor smaller waste -> add negative waste as a sub-unit tie-break).
    tight = -residual.astype(np.float64)
    score = tight - 0.4 * waste[r]

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
