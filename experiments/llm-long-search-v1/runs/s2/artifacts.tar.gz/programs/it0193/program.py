# EVOLVE-BLOCK-START
"""Best fit with a bounded, principled 'completable residual' tie-break.

Primary term: best fit (strictly dominant). Tie-break: prefer placing the item so the
resulting residual is a value that we often see complemented by future items, estimated
from the live empirical item-size distribution.
"""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)   # empirical item-size histogram
_n = 0.0
_sum = 0.0
_pair = np.zeros(101, dtype=np.float64)    # cached convolution (pairs sum) values

_K = 2000.0  # makes best-fit strictly dominate any bounded tie-break in [-1, 1)


def _recompute_pair():
    """P(s) ~ sum_a freq(a)*freq(s-a): how often a pair sums to s (normalized)."""
    total = _n if _n > 0.0 else 1.0
    f = _counts / total
    # convolution over sums 2..200, restricted to item sizes 1..100
    c = np.convolve(f[1:101], f[1:101])
    out = np.zeros(101, dtype=np.float64)
    # index s-2 in c corresponds to sum s
    for s in range(2, 101):
        out[s] = c[s - 2]
    m = out.max()
    if m > 0.0:
        out /= m
    return out


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _pair

    residual = bins - item  # >= 0 for all bins shown

    # periodically refresh the pairwise-completion estimate from the live distribution
    if _n > 0.0 and (_n % 25.0) == 0.0:
        _pair = _recompute_pair()

    # bonus: how likely is this residual to be exactly filled by a single future item
    # (residual itself being a common item size), using the live histogram
    total = _n if _n > 0.0 else 1.0
    freq = _counts / total
    r = residual.astype(np.int64)
    single = freq[r]                      # chance a future item exactly equals residual

    # bonus: how likely is this residual to be completed by a pair of future items
    pairb = _pair[r]                      # normalized pair-completion likelihood

    combo = np.clip(single + 0.5 * pairb, 0.0, 1.0)  # bounded in [0, 1)

    tight = -residual.astype(np.float64)
    score = _K * tight + combo

    # exact fits always first
    score[residual == 0] += 1e6

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
