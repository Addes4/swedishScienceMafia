# EVOLVE-BLOCK-START
"""Best fit (smallest residual) with a tiny normalized histogram tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    # smoothed probability that a future item can roughly fill this residual
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * _counts[lo:hi]
    total = _n if _n > 1e-9 else 1.0
    use = smoothed[r] / total  # in [0,1]-ish

    tight = -residual.astype(np.float64)
    global _scale
    try:
        _scale
    except NameError:
        _scale = 1.0
    score = tight - 0.01 * use  # tiny bonus: prefer residuals that are likely future sizes

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
