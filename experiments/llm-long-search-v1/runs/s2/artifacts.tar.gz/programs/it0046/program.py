# EVOLVE-BLOCK-START
"""Best-fit with a scaled exact-refillability tie-break based on the empirical item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
# smoothing kernel over residual sizes (offsets -2..+2)
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    total = _n if _n > 0 else 1.0
    prob = smoothed / total  # probability mass of future items near each residual size

    r = residual.astype(np.int64)
    use = prob[r]

    tight = -residual.astype(np.float64)
    # primary: tightness; tie-break: scaled refillability (multiplicative so it grows with tightness)
    score = tight * (1.0 + 4.0 * use) + 0.3 * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
