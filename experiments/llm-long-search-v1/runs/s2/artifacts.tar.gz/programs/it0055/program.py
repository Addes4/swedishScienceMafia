# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware residual-usefulness tie-break from the running histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
# smoothing kernel over residual sizes: an item near residual size can close/open the bin well
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # smoothed item-count histogram (running estimate of the distribution)
    half = len(_kernel) // 2
    smoothed = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        if hi > lo:
            smoothed[lo + off:hi + off] += w * _counts[lo:hi]

    # usefulness: how likely a future item can nearly fill this residual
    r = np.clip(residual, 0, 100).astype(np.int64)
    use = smoothed[r]

    # primary: best fit (min residual). secondary: prefer residuals easy to refill.
    score = -residual.astype(np.float64) + 0.6 * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
