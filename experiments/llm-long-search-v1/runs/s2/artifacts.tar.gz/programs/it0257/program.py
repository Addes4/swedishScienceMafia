# EVOLVE-BLOCK-START
"""Best fit with deterministic exact-fill priority and per-slot residual EMA tie-break."""
import numpy as np

_slot_ema = np.full(101, 50.0, dtype=np.float64)
_alpha = 0.05

# Exact-fill bonus must dominate; best-fit gaps are >= 1, so 1.0 is enough.
FILL_BONUS = 1000.0
# Tiny weight so it only breaks residual ties (residual differences are >= 1).
TIE_WEIGHT = 0.25


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest score (first on ties)."""
    residual = bins - item  # >= 0 for every bin shown
    r = residual.astype(np.int64)

    # Best-fit dominates; exact fills get a huge bonus.
    score = -residual.astype(np.float64)

    # Tie-break: prefer placements whose resulting residual slot has, on average,
    # historically been left in bins that later got filled well (lower EMA = tighter).
    tie = -_slot_ema[r]
    score += TIE_WEIGHT * tie

    score[r == 0] += FILL_BONUS

    # Update EMA of the residual left in the chosen bin (highest score, first tie).
    best = int(np.argmax(score))
    new_res = int(r[best])
    _slot_ema[new_res] += _alpha * (float(new_res) - _slot_ema[new_res])

    return score
# EVOLVE-BLOCK-END
