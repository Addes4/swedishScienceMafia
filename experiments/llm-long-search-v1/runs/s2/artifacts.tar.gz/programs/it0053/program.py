# EVOLVE-BLOCK-START
"""Best fit with an adaptive histogram-based tie-break for near-ties."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
# smoothing kernel over residual sizes
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    n = min(len(_kernel), 101)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    r = residual.astype(np.int64)
    # normalized fill probability for this residual
    total = smoothed.sum()
    if total > 0:
        use = smoothed[r] / total
    else:
        use = np.zeros(r.shape, dtype=np.float64)

    # primary: tightness (prefer smallest residual); secondary: fill probability scaled small
    tight = -residual.astype(np.float64)
    score = tight + 5.0 * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
