# EVOLVE-BLOCK-START
"""Best fit with smoothed residual-usefulness, a mean-reuse bonus, and a mode-residual bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
# small smoothing kernel over residual sizes: an item of size ~r can fill a bin of residual r or slightly larger
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    # smoothed usefulness: probability that a future item can roughly fill this residual
    # treat residual 0 as fully useful (bin is closed with no waste)
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    tight = -residual.astype(np.float64)
    score = tight + 0.5 * use

    # small bounded bonus for residuals near the running mean item size (reusable sweet spot)
    if _n > 0.0:
        mean_item = _sum / _n
        # closeness of residual to mean_item, scaled to a small bounded magnitude (< 0.5)
        reuse = 0.4 * np.exp(-((residual.astype(np.float64) - mean_item) ** 2) /
                             (2.0 * (0.25 * mean_item + 1.0) ** 2))
        score = score + reuse

    # tiny bonus for residuals exactly matching frequent recent item sizes (histogram peaks),
    # so a leftover a single typical future item can perfectly consume is preferred in near-ties
    score = score + 0.1 * freq[r]

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END

