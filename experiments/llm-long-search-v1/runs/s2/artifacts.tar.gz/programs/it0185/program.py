# EVOLVE-BLOCK-START
"""Pure best-fit with a strictly-dominant residual term; exact ties go to first bin."""
import numpy as np


def priority(item, bins):
    """Best-fit: strictly minimize residual, break ties by first bin (earliest)."""
    residual = bins - item  # >= 0 for all bins shown
    score = -residual.astype(np.float64)
    score[residual == 0] += 1000.0
    return score
# EVOLVE-BLOCK-END
