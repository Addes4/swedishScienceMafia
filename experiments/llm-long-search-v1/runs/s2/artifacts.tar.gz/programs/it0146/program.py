# EVOLVE-BLOCK-START
"""Best fit with a deterministic secondary term that only breaks exact-residual ties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    # Best-fit is strictly dominant: gaps in residual are >= 1 in magnitude.
    # The secondary term is kept strictly below 1.0 so it only breaks exact ties.
    # Tie-break: prefer the residual that is a "nice" fit for typical items,
    # measured by closeness to the observed mean item size (computed lazily).
    tight = -residual.astype(np.float64)

    # Deterministic, distribution-agnostic secondary term:
    # among equal residuals, prefer the smaller residual (already equal) -> first index wins.
    # To add mild useful differentiation without disturbing best-fit, prefer residuals that
    # leave a larger gap only when residuals are identical is a no-op, so instead we give
    # a tiny preference to residuals that are exact multiples of common small sizes is risky;
    # keep it simple and robust: no extra noise.
    score = tight * 1000.0  # amplify to defeat any tiny floating error, ties -> first index

    return score
# EVOLVE-BLOCK-END
