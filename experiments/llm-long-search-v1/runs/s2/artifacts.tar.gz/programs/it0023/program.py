# EVOLVE-BLOCK-START
"""Best fit refined: prefer bins the item fills proportionally best, tie-break tightest."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Fraction of the bin's current free space used by this item (higher = better).
    frac = item / bins
    # Tie-break: prefer the smaller resulting residual (tighter fit); tiny epsilon.
    residual = bins - item
    return frac - 1e-6 * residual
# EVOLVE-BLOCK-END

