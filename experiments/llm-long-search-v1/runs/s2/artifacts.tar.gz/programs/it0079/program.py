# EVOLVE-BLOCK-START
"""Best fit with a histogram-driven tie-break among near-equal residuals."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    r = residual.astype(np.int64)

    # Dominant key: smallest residual (best fit). Scale by 4 so residual ties are discrete.
    tight = -4.0 * residual.astype(np.float64)

    # Tie-break: prefer residuals that are commonly occurring item sizes.
    freq = _counts[r]
    denom = _n if _n > 0.0 else 1.0
    tie = freq / denom  # in [0, 1]

    score = tight + tie

    # Exact fills are strictly best.
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
