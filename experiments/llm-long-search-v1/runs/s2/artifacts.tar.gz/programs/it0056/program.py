# EVOLVE-BLOCK-START
"""Best fit with a smoothed residual-usefulness tie-break based on the empirical item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def _smoothed():
    f = _counts
    s = f.copy()
    # light smoothing: mix in neighbors so unseen exact sizes still get some credit
    s[1:] += 0.5 * f[:-1]
    s[:-1] += 0.5 * f[1:]
    s[0] += 0.5 * f[1]
    s[100] += 0.5 * f[99]
    tot = s.sum()
    if tot > 0:
        s /= tot
    return s


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    p = _smoothed()
    r = residual.astype(np.int64)
    use = p[r]

    tight = -residual.astype(np.float64)
    score = tight + 0.5 * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
