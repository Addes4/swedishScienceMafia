# EVOLVE-BLOCK-START
"""Best-fit with a probability-weighted near-tie correction using the empirical item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_WINDOW = 6  # only consider residuals within this many units of the best as "near ties"


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    r = residual.astype(np.int64)
    # probability that some future item exactly equals this residual (laplace-smoothed)
    total = _n + 101.0
    prob = (_counts[r] + 1.0) / total

    tight = -(r.astype(np.float64))

    # near-tie correction: among residuals close to the minimum, prefer those with
    # high exact-fill probability; farther residuals get no benefit.
    best_r = int(r.min())
    band = np.clip(best_r + _WINDOW - r, 0, _WINDOW).astype(np.float64)
    # more benefit the closer to best_r, scaled by exact-fill probability
    corr = 0.6 * band * prob

    score = tight + corr
    score[r == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
