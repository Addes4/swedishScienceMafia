# EVOLVE-BLOCK-START
"""Best fit with a strictly-dominant primary term and a sub-1.0 reuse bonus
derived from the online item-size distribution."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)  # offsets -2..+2

# Precompute the smoothed item-size distribution on demand, cached per call.
_cache = None
_cache_n = -1.0


def _smoothed_dist():
    global _cache, _cache_n
    if _cache_n == _n and _cache is not None:
        return _cache
    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    total = smoothed.sum()
    if total > 0:
        smoothed = smoothed / total
    _cache = smoothed
    _cache_n = _n
    return _cache


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    # Primary term: strict best fit. Residuals are integers, so scaling the
    # negative residual by a large constant keeps best-fit strictly dominant
    # while leaving room for sub-unit tie-breaking bonuses.
    score = -residual.astype(np.float64) * 10.0

    if _n > 0.0:
        dist = _smoothed_dist()
        # For each bin, the value of reusing its residual gap is the probability
        # (mass) that a future item exactly hits a residual compatible with it.
        # We approximate by the smoothed probability of the residual itself,
        # which favors residuals matching common future item sizes.
        use = dist[r]
        score += 0.9 * use

        # Slight extra preference for residuals near the current mean item size,
        # a proxy for "typical" usable gaps.
        mean_item = _sum / _n
        reuse = np.exp(-((residual.astype(np.float64) - mean_item) ** 2) /
                       (2.0 * (0.3 * mean_item + 1.0) ** 2))
        score += 0.09 * reuse

    # Exact fits always preferred.
    score[r == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
