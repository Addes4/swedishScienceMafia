# EVOLVE-BLOCK-START
"""Best fit dominated by a sub-unit complement-frequency tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    r = residual.astype(np.int64)

    # sub-unit signal: how often this exact residual was itself a plausible future item size
    use = _counts[r]
    use = use / (1.0 + use)  # squash to [0,1), keeps it below the unit best-fit gap

    # strict best-fit dominance: smaller residual always wins by >= 1.0
    score = -residual.astype(np.float64) + 0.5 * use

    # exact fill is always best
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
