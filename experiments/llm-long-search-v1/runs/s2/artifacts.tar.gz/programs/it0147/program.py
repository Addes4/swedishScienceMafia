# EVOLVE-BLOCK-START
"""Best fit with a coarse-histogram tie-break that favors perfectly closable gaps."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # Best-fit is strictly dominant: smaller residual -> higher score.
    score = -residual.astype(np.float64)

    # Break exact-residual ties: prefer residuals that are frequent item sizes,
    # since such gaps are more likely to be closed exactly by a future item.
    if _n > 0.0:
        p = _counts / _n
        # coarsen into groups of 5 to reduce noise in the tail
        coarse = np.zeros(101, dtype=np.float64)
        for g in range(0, 101, 5):
            coarse[g:g + 5] = p[g:g + 5].sum()
        r = residual.astype(np.int64)
        tie = coarse[r]
        # scale below 1.0 so it cannot change which residual is chosen
        score = score + 0.9 * tie

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
