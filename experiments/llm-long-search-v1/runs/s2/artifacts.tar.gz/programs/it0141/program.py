# EVOLVE-BLOCK-START
"""Best fit with a smoothed empirical future-fit tie-break, strictly sub-unit."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    total = smoothed.sum()
    if total > 0.0:
        prob = smoothed / total
    else:
        prob = np.full(101, 1.0 / 101.0)

    use = prob[r]

    # best-fit dominant: -residual differs by >= 1, and the tie-break term is < 1,
    # so it can only reorder bins with identical residual.
    score = -residual.astype(np.float64) + 0.9 * use

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
