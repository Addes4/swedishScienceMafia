# EVOLVE-BLOCK-START
"""Best fit with a mild residual-reusability tie-break via normalized leftover."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: prefer tightest fit (smallest residual).
    # Secondary (tiny): mildly prefer residuals that are large enough to be reusable
    # for typical future items, avoiding burying space in unusably small gaps.
    # Use a smooth reward peaking around moderate residuals.
    r = residual.astype(np.float64)
    # reward decreases as residual shrinks below ~item, and is flat otherwise
    reuse = np.minimum(r, item) / np.maximum(item, 1.0)
    return -(r) + 0.01 * reuse
# EVOLVE-BLOCK-END
