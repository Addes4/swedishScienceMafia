# EVOLVE-BLOCK-START
"""Best fit with a sliver-avoiding tie-break using the empirical item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_total = 0.0
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _total, _n
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    use = freq[residual]  # usefulness of residual r

    # running mean item size (estimate of "typical" item)
    mean_item = (_total / _n) if _n > 0 else 40.0

    # tightness term: prefer smallest residual (best fit)
    tight = -residual.astype(np.float64)

    # combine: tightness dominates, histogram usefulness breaks near-ties
    score = tight + 0.5 * use

    # strong reward for perfectly filling the bin
    score[residual == 0] += 1000.0

    # penalize wasted slivers: positive residual too small to fit a typical item
    sliver = (residual > 0) & (residual < mean_item)
    score -= 0.25 * sliver

    # update stats
    _counts[item] += 1.0
    _total += item
    _n += 1.0

    return score
# EVOLVE-BLOCK-END

