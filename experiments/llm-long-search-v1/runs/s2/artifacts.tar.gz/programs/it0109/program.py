# EVOLVE-BLOCK-START
"""Best fit with an exact-leftover-matching tie-break that batches equal items together."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    # Primary: best fit -- smallest residual first (more negative is better).
    score = -residual.astype(np.float64)

    # Tie-break: if the leftover after placement equals the current item size,
    # the bin can still take another copy of this item; batch equal items together.
    score = score + 0.5 * (residual == item)

    # Bins that become exactly full (residual 0) are perfect, strongly prefer them.
    score = score + 1000.0 * (residual == 0)

    return score
# EVOLVE-BLOCK-END

