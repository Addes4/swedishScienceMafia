# EVOLVE-BLOCK-START
"""Best fit with exact-fill dominance and a lightweight per-bin packing-history tie-break."""
import numpy as np

# Per-bin exponential moving average of the residual left after a placement.
# Used only as a strictly subordinate tie-break among equal-residual bins.
_bin_ema = np.zeros(1, dtype=np.float64)   # grows lazily to number of bins
_bin_seen = np.zeros(1, dtype=np.float64)
_alpha = 0.3


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _bin_ema, _bin_seen
    n = bins.shape[0]
    if _bin_ema.shape[0] < n:
        grow = n - _bin_ema.shape[0]
        _bin_ema = np.concatenate([_bin_ema, np.zeros(grow, dtype=np.float64)])
        _bin_seen = np.concatenate([_bin_seen, np.zeros(grow, dtype=np.float64)])

    residual = (bins - item).astype(np.float64)

    # Primary key: best fit (smaller residual => higher score).
    score = -residual

    # Secondary key (magnitude < 0.5, so within an equal-residual group only):
    # prefer the bin whose historical average residual after placement is closest
    # to this item's size (i.e. bins that tend to be re-usable).
    ema = _bin_ema[:n]
    seen = _bin_seen[:n]
    # Only meaningful once a bin has history; unknown bins get a neutral 0.
    diff = np.abs(ema - item) * (seen > 0.0)
    score = score - 0.25 * (diff / 100.0)

    # Exact fill is strictly dominant.
    score[residual == 0] += 1000.0

    # Update history for the chosen bin (highest score, first on ties).
    chosen = int(np.argmax(score))
    if _bin_seen[chosen] == 0.0:
        _bin_ema[chosen] = residual[chosen]
    else:
        _bin_ema[chosen] = (1.0 - _alpha) * _bin_ema[chosen] + _alpha * residual[chosen]
    _bin_seen[chosen] += 1.0

    return score
# EVOLVE-BLOCK-END
