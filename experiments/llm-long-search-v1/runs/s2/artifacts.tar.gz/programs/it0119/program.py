# EVOLVE-BLOCK-START
"""Best fit (dominant) plus a one-step-lookahead exact-refill bonus from the empirical size histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    rf = residual.astype(np.float64)

    # dominant best-fit term: strongly prefer the smallest feasible residual
    score = -100.0 * rf

    # one-step-lookahead: reward residuals that are likely to be exactly refilled
    # by a future item of the same size (probability from the running histogram).
    prob = _counts / _n if _n > 0.0 else np.zeros(101, dtype=np.float64)
    ri = residual.astype(np.int64)
    ri = np.clip(ri, 0, 100)
    bonus = prob[ri]  # P(next-item ~ residual)
    score = score + bonus

    # exact fill is always a win
    score[residual == 0] += 1e6

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
