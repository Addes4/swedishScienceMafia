# EVOLVE-BLOCK-START
"""Best fit with a mild preference to avoid leaving slivers that block large future items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit (prefer the smallest non-negative residual).
    score = -residual.astype(np.float64)
    # Mild bonus for residuals that are either perfectly full or large enough to
    # still accept items up to the largest size seen so far.
    score += 0.25 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
