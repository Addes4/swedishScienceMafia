# EVOLVE-BLOCK-START
"""Best-fit with a tiny smoothed-histogram tie-break that only breaks exact residual ties."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
# smoothing kernel over residuals: an item of size ~r can fill a bin of residual r
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown (bins only includes bins the item fits)

    # Build a smoothed histogram of past item sizes once per call.
    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    tot = smoothed.sum()
    if tot > 0:
        smoothed /= tot

    r = residual.astype(np.int64)
    # Tightness is the dominant term: smaller residual => higher score.
    # The histogram usefulness is scaled to be strictly below 1 capacity unit
    # so it can never overturn the tightness ordering, only break residual ties.
    use = smoothed[r] * 0.5
    score = -residual.astype(np.float64) + use

    # Slight emphasis on perfect fills, still below the tie-break scale conflict:
    # residual 0 is already the tightest, so just add a nominal bonus.
    score[residual == 0] += 1e-3

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END

