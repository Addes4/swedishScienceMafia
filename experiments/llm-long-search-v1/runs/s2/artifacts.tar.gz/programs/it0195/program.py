# EVOLVE-BLOCK-START
"""Best-fit dominant with a smoothed residual-usefulness tie-breaker."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0

_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)
_smoothed = np.zeros(101, dtype=np.float64)
_half = len(_kernel) // 2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n

    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    # Rebuild smoothed frequency estimate (bounded tie-breaker input).
    smoothed = _smoothed
    smoothed[:] = 0.0
    freq = _counts
    for k in range(len(_kernel)):
        off = k - _half
        w = _kernel[k]
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    use = smoothed[r]

    # Dominant best-fit term: tighter residual strictly preferred.
    score = -1000.0 * residual.astype(np.float64) + 0.4 * use

    # Exact fit always wins.
    score[residual == 0] += 1e9

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
