# EVOLVE-BLOCK-START
"""Best fit with a deterministic complementary-fit bonus from a smoothed item-size histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def _make_smoothed(freq):
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    return smoothed


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n

    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    smoothed = _make_smoothed(_counts)
    # normalize to a probability-like scale so the bonus stays below the 1.0 best-fit gap
    total = smoothed.sum()
    if total > 0.0:
        prob = smoothed / total
    else:
        prob = smoothed

    # complementary-fit bonus: residual matching a frequent past item size
    # (bin is likely to be exactly closed by a common forthcoming item)
    use = prob[r]

    tight = -residual.astype(np.float64)
    score = tight + 0.5 * use

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
