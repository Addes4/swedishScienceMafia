# EVOLVE-BLOCK-START
"""Best fit with a reusable-leftover tie-break: prefer small residuals, but not ones too small to fit a typical item."""
import numpy as np

_n = 0.0
_sum = 0.0
_sum2 = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _sum2
    residual = (bins - item).astype(np.float64)

    # primary term: best fit (smallest residual first)
    score = -residual

    # tie-break: reward residuals that are >= typical item size so the leftover is reusable,
    # and slightly reward residuals that are themselves close to a typical item size.
    if _n > 1.0:
        mean_item = _sum / _n
        var = max(_sum2 / _n - mean_item * mean_item, 0.0)
        sd = var ** 0.5
        # threshold: a leftover smaller than ~half the mean is likely stranded
        thr = 0.5 * mean_item
        reusable = (residual >= thr).astype(np.float64)
        # closeness of the whole residual to a typical item magnitude (reusable sweet spot)
        denom = 2.0 * (sd + 1.0) ** 2
        sweet = np.exp(-((residual - mean_item) ** 2) / denom)
        score = score + 0.3 * reusable + 0.2 * sweet

    # exact fill: strong bonus
    score[residual == 0.0] += 1000.0

    _n += 1.0
    _sum += item
    _sum2 += item * item

    return score
# EVOLVE-BLOCK-END
