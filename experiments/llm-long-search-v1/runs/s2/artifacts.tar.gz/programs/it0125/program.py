# EVOLVE-BLOCK-START
"""Best fit dominant, with an empirical exact-residual-match tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_smoothed = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _smoothed
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    # Empirical frequency of exact residuals, lightly smoothed so unseen sizes still get a value.
    p = _counts / _n if _n > 0.0 else np.zeros(101, dtype=np.float64)
    # probability that this exact residual is a likely future item size
    match = p[r]

    # Best fit is strictly dominant: a unit residual gap (>=1) must beat any tie-break.
    # Match bonus stays in [0,1) so it only breaks ties between equal residuals.
    score = -residual.astype(np.float64) + match

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
