# EVOLVE-BLOCK-START
"""Best fit with a running-histogram reusability tie-break over residual values."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
# precompute integer residual grid
_res = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    rf = residual.astype(np.float64)

    freq = _counts
    total = _n if _n > 0.0 else 1.0
    p = freq / total  # empirical pmf of past item sizes

    # Dominant best-fit term.
    score = -rf

    if _n > 0.0:
        # For each candidate residual r, estimate the probability that a future item
        # fits into the leftover and leaves a small remainder. We smooth the pmf over
        # item sizes so near-ties are broken by how "usable" the leftover is.
        mean_item = _sum / _n
        sigma = 0.35 * mean_item + 1.0

        # Build a smoothed pmf once per call over the integer grid.
        d = _res[:, None] - _res[None, :]
        K = np.exp(-(d * d) / (2.0 * sigma * sigma))
        # Normalize columns so each source size spreads unit mass.
        K /= K.sum(axis=0, keepdims=True)
        smooth = K @ p  # smooth[r] = smoothed density of item sizes at r

        r_int = np.clip(residual.astype(np.int64), 0, 100)
        use = smooth[r_int]

        # Penalize residuals that are too small to hold a typical item: only residuals
        # at least as large as a modest fraction of the mean are truly reusable.
        reusable = 1.0 / (1.0 + np.exp(-(rf - 0.5 * mean_item) /
                                       (0.2 * mean_item + 1.0)))
        score = score + 0.7 * use * reusable

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
