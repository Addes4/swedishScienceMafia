# EVOLVE-BLOCK-START
"""Best fit with tie-break by residual usefulness derived from online histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    rf = residual.astype(np.float64)

    # Strict best-fit dominates: score is -residual plus a fraction < 1 that
    # depends only on the integer residual, so it breaks ties among equal
    # residuals without ever reordering distinct integer residuals.
    frac = np.zeros_like(rf)
    if _n > 0.0:
        # expected future-use metric: probability that some upcoming item
        # exactly fills this residual, estimated from running histogram,
        # smoothed over neighbors of the residual.
        freq = _counts / _n
        # smooth: spread each residual's match probability to nearby residuals
        w = 0.5 * freq[r] if False else None  # placeholder (kept simple below)
    # matched-probability: direct frequency of residual value as an item size
    # plus a small share of neighboring residuals
    r = residual.astype(np.int64)
    p = _counts[r] + 0.5 * _counts[np.clip(r - 1, 0, 100)] + 0.5 * _counts[np.clip(r + 1, 0, 100)]
    if _n > 0.0:
        p = p / (_n + 1.0)
    # Scale into [0, 1) so integer best-fit ordering remains strictly dominant.
    frac = p / (1.0 + p)

    score = -rf + frac
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
