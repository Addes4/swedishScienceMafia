# EVOLVE-BLOCK-START
"""Best-fit with a small empirical exact/near-fit reward tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_smoothed = np.zeros(101, dtype=np.float64)
_dirty = False

# small kernel over residual sizes for near-fit smoothing (offsets -2..+2)
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _dirty

    residual = bins - item  # >= 0 for all bins shown

    if _dirty or _n < 1.0:
        sm = np.zeros(101, dtype=np.float64)
        half = len(_kernel) // 2
        for k, w in enumerate(_kernel):
            off = k - half
            lo = max(0, -off)
            hi = min(101, 101 - off)
            sm[lo + off:hi + off] += w * _counts[lo:hi]
        _smoothed[:] = sm
        _dirty = False

    r = residual.astype(np.int64)

    # primary: best fit (tightest residual)
    score = -residual.astype(np.float64)

    # secondary: reward residuals that a future item can fill exactly/nearly
    if _n > 0:
        use = _smoothed[r] / _n
        score += 0.5 * use

    # exact fit is valuable: close the bin with zero waste
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _dirty = True

    return score
# EVOLVE-BLOCK-END
