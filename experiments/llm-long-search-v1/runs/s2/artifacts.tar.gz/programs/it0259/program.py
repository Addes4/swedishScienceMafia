# EVOLVE-BLOCK-START
"""Best fit dominant, with a bounded subordinate bonus for residuals that a recent
single item or a recent pair-of-items could exactly fill."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)      # count of each item size seen
_pair = np.zeros(201, dtype=np.float64)        # smoothed count of pair-sums seen
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    tight = -residual.astype(np.float64)  # best-fit, dominant ordering (gaps >= 1)

    # subordinate bonus in [0, 0.4): favor residuals equal to a recent single item
    # size, or equal to a recent pair-sum, so free space can be consumed exactly later.
    single = _counts[r] if _n > 0.0 else None
    bonus = np.zeros(r.shape[0], dtype=np.float64)
    if _n > 0.0:
        # single-item match: normalized by running max count
        cnt = _counts[r]
        mx = _counts.max()
        if mx > 0.0:
            bonus += 0.2 * (cnt / mx)
        # pair-sum match: r in [0,100] maps into _pair indices
        pc = _pair[r]
        pmx = _pair.max()
        if pmx > 0.0:
            bonus += 0.2 * (pc / pmx)

    score = tight + bonus
    score[r == 0] += 1000.0  # exact fill is always dominant

    # update statistics for future calls
    _counts[item] += 1.0
    _n += 1.0
    # update pair sums (item + previously seen item); cheap because we only add
    # the current item against the running distribution via convolution-free loop
    _pair[item:item + 101] += _counts[0:101] if item + 101 <= 201 else _counts[0:201 - item]

    return score
# EVOLVE-BLOCK-END
