# EVOLVE-BLOCK-START
"""Pure best fit: place the item in the bin with the smallest remaining capacity that still fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown
    # Smaller residual is better: strongly dominant primary key.
    score = -residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
