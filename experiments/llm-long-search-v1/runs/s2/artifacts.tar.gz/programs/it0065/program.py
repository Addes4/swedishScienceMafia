# EVOLVE-BLOCK-START
"""Best-fit: place the item so the leftover residual is as small as possible."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown
    score = -residual.astype(np.float64)
    # tiny extra reward for perfect fills (already implied by best-fit, kept for clarity)
    score[residual == 0] += 1e-6
    return score
# EVOLVE-BLOCK-END
