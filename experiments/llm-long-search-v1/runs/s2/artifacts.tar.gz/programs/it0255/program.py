# EVOLVE-BLOCK-START
"""Best fit with a strict, fine-grained empirical fixability tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown
    residual_f = residual.astype(np.float64)

    # Strictly dominant best-fit term: minimize residual.
    score = -residual_f

    # Subordinate tie-break (magnitude < 1 so it never overrides residual ordering):
    # among equal residuals, prefer a bin whose resulting residual matches a size we
    # have already seen, i.e. a gap that a future item of that size could exactly fill.
    r = residual.astype(np.int64)
    fixable = _counts[r]
    norm = fixable.max()
    if norm > 0.0:
        score = score + 0.5 * (fixable / norm)

    # Exact fill strictly dominant.
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
