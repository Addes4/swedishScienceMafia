# EVOLVE-BLOCK-START
"""Best fit with a smoothed residual-usefulness tie-break plus a small reusable-size bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_prev = 0  # previous item size
# small smoothing kernel over residual sizes: an item of size ~r can fill a bin of residual r or slightly larger
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _prev
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    # smoothed usefulness: probability that a future item can roughly fill this residual
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    tight = -residual.astype(np.float64)
    score = tight + 0.5 * use

    # small bounded bonus for residuals near the running mean item size (reusable sweet spot)
    if _n > 0.0:
        mean_item = _sum / _n
        reuse = 0.4 * np.exp(-((residual.astype(np.float64) - mean_item) ** 2) /
                             (2.0 * (0.25 * mean_item + 1.0) ** 2))
        score = score + reuse

    # tiny bonus for residuals that a typical 2-item pair (prev+item) could complete
    pair = _prev + item
    if _n > 1.0 and 1 <= pair <= 100:
        score = score + 0.05 * np.exp(-((residual.astype(np.float64) - pair) ** 2) / 2.0)

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item
    _prev = item

    return score
# EVOLVE-BLOCK-END
