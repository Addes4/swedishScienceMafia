# EVOLVE-BLOCK-START
"""Best-fit dominant with a bounded, smoothed residual-fill-probability tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0

_KERNEL = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)
_HALF = len(_KERNEL) // 2

# Precompute smoothing gather indices
def _smoothed(freq):
    smoothed = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_KERNEL):
        off = k - _HALF
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    return smoothed


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest-scoring bin."""
    global _n, _sum
    residual = bins - item  # >= 0 everywhere

    scored = np.zeros(bins.shape[0], dtype=np.float64)

    if _n > 0.0:
        freq = _counts / _n
        smoothed = _smoothed(freq)
        r = residual.astype(np.int64)
        # probability mass near the resulting residual
        fill_prob = smoothed[np.clip(r, 0, 100)]
    else:
        fill_prob = np.zeros(bins.shape[0], dtype=np.float64)

    # Primary: best-fit, dominant by large scale.
    scored = -1000.0 * residual.astype(np.float64)

    # Tie-break (bounded well below 1000*1 gap): prefer residuals that are common
    # item sizes / gaps, so they are likely to be filled exactly later.
    scored += fill_prob

    # Exact fill tie-break: strong but still far below the best-fit gap of 1000.
    scored[residual == 0] += 100.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return scored
# EVOLVE-BLOCK-END
