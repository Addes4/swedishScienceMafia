# EVOLVE-BLOCK-START
"""Best fit with a mild fill-level tie-break to consolidate placements."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: best fit -> prefer smallest resulting residual.
    residual = bins - item
    # Secondary (tiny): prefer bins that end up fuller, breaking ties toward
    # consolidating into already-used bins rather than opening fresh ones.
    fill = (100 - residual) / 100.0
    return -residual.astype(np.float64) + 1e-3 * fill
# EVOLVE-BLOCK-END
