# EVOLVE-BLOCK-START
"""Best fit with a distribution-weighted residual-usefulness tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    # light smoothing kernel over residual space (offsets -2..+2)
    for off, w in ((-2, 0.15), (-1, 0.25), (0, 0.35), (1, 0.15), (2, 0.10)):
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    use = smoothed[r]

    tight = -residual.astype(np.float64)
    score = tight + 0.5 * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
