# EVOLVE-BLOCK-START
"""Best fit with a smoothed residual-usefulness tie-break plus a mode-targeted reuse bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_ema = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    res_f = residual.astype(np.float64)

    freq = _counts
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    tight = -res_f
    score = tight + 0.5 * use

    # bonus for residuals near the current histogram mode (most likely future single item)
    if _n > 0.0:
        mode = float(np.argmax(_ema))
        if mode > 0.0:
            reuse = 0.4 * np.exp(-((res_f - mode) ** 2) / (2.0 * (0.25 * mode + 1.0) ** 2))
            score = score + reuse

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _ema = 0.995 * _ema + 0.005 * (np.arange(101) == item)
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
