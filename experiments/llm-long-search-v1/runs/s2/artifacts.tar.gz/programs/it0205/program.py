# EVOLVE-BLOCK-START
"""Best fit with strictly sub-1.0 tie-breaking bonuses that never flip best-fit ordering."""
import numpy as np

# Online histogram of item sizes for residual-refill likelihood.
_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    # Primary term: strict best fit (smallest residual -> highest score).
    # Integer spacing of >=1 keeps best-fit ordering dominant.
    score = -residual.astype(np.float64)

    # Sub-1.0 bonus: prefer residuals likely to be exactly filled by a future item.
    # freq[r] = normalized empirical frequency of item size == r (a plausible refill).
    freq = _counts
    r = residual.astype(np.int64)
    use = np.zeros_like(score)
    if _n > 0.0:
        use = freq[np.clip(r, 0, 100)] / _n
    # Bonus strictly below 1.0 so it only breaks ties among equal residuals.
    score = score + 0.9 * use

    # Exact fit always wins outright.
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
