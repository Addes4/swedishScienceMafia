# EVOLVE-BLOCK-START
"""Strict best-fit with a bounded recency-based exact-fill tie-break."""
import numpy as np

_recent = np.zeros(101, dtype=np.int64)
_order = np.zeros(101, dtype=np.int64)
_tick = 0


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest score (first on ties)."""
    global _tick
    residual = bins - item

    r = residual.astype(np.int64)

    # Recency-weighted indicator: how recently residual value was seen as an item size.
    rec = _recent.astype(np.float64) * (1.0 + 0.0 * _order)  # placeholder avoided
    # Use simple count-based recency: values seen many times recently get a bonus.
    recency = _order.astype(np.float64)
    # bonus is tiny and bounded so best-fit (gap units of 1) stays strictly dominant
    bonus = np.zeros(101, dtype=np.float64)
    nz = np.nonzero(_recent)[0]
    if nz.size:
        bonus[nz] = 0.9 * (recency[nz] / (recency[nz].max() + 1.0))

    use = bonus[r]

    tight = -residual.astype(np.float64)
    score = tight + use

    score[residual == 0] += 1000.0

    _tick += 1
    _recent[item] += 1
    _order[item] = _tick

    return score
# EVOLVE-BLOCK-END
