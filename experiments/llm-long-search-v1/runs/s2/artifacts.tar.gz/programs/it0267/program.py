# EVOLVE-BLOCK-START
"""Best fit with a strictly-tie-breaking sharp complement-usefulness read."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_decay = 0.9995


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum

    residual = bins - item  # >= 0 for all bins shown

    # Sharp read of a decayed item-size histogram: how often each exact size has appeared.
    freq = _counts
    r = residual.astype(np.int64)
    use = freq[r]

    # Strict best-fit dominates (gaps separated by >=1); usefulness only breaks exact ties.
    score = -residual.astype(np.float64) + 0.45 * use

    score[residual == 0] += 1000.0

    _counts *= _decay
    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
