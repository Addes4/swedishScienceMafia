# EVOLVE-BLOCK-START
"""Best fit refined by an empirical item-histogram usefulness bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # Probability that a future item can fill the residual well (exact or with small slack).
    # Build a smoothed empirical histogram: counts of past items by size.
    freq = _counts
    total = _n + 1.0

    # cumulative "can fill up to residual" style usefulness: exact match dominates,
    # plus a decaying bonus for near matches.
    r = residual.astype(np.int64)
    use = freq[r] / total  # probability an item exactly equals this residual

    # small near-match contributions
    for d in (1, 2, 3):
        idx_lo = np.maximum(r - d, 0)
        idx_hi = np.minimum(r + d, 100)
        use += (freq[idx_lo] + freq[idx_hi]) / total * (0.5 / d)

    tight = -residual.astype(np.float64)
    score = tight + 0.8 * use
    score[residual == 0] += 1000.0  # prefer perfect fills strongly

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END

