# EVOLVE-BLOCK-START
"""Best fit with a sharp exact-residual usefulness tie-break."""

import numpy as np

_counts = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    # Exact-residual usefulness: how often we have seen an item exactly this size.
    use = freq[r]

    # Best-fit is strictly dominant: residual ordering separated by >= 1.
    tight = -residual.astype(np.float64)
    score = tight + 0.45 * use

    # Exact fill always wins outright.
    score[residual == 0] += 1000.0

    _counts[item] += 1.0

    return score
# EVOLVE-BLOCK-END
