# EVOLVE-BLOCK-START
"""Best-fit dominant rule with a small bounded bonus for residuals likely to be filled soon."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_total = 0.0
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)
_smoothed = np.zeros(101, dtype=np.float64)
_dirty = False


def _rebuild():
    global _smoothed, _dirty
    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    _smoothed = smoothed
    _dirty = False


def priority(item, bins):
    """Priority = best-fit (dominant), plus a small bonus for residuals matching likely future items."""
    global _total, _dirty
    residual = bins - item  # >= 0

    if _dirty:
        _rebuild()

    r = residual.astype(np.int64)
    # Bonus: reward bins whose residual is a likely future item size (so it can be exactly filled).
    if _total > 0.0:
        prob = _smoothed[r] / _total
    else:
        prob = np.zeros(r.shape, dtype=np.float64)

    # Dominant: minimize residual (best fit). Exact fill gets a large extra push.
    score = -residual.astype(np.float64) + 0.5 * prob
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _total += 1.0
    _dirty = True

    return score
# EVOLVE-BLOCK-END
