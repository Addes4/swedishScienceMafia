# EVOLVE-BLOCK-START
"""Best fit primary term, with a distribution-based "refillability" tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_total = 0.0
# prefix-based estimate of how many future items can fit in a residual of size r
_cum = None          # cumulative counts, freq of item <= r
_cum_dirty = True


def _rebuild():
    global _cum, _cum_dirty
    _cum = np.cumsum(_counts)         # _cum[r] = #items with size <= r
    _cum_dirty = False


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _total, _cum_dirty

    residual = (bins - item).astype(np.float64)

    if _cum_dirty:
        _rebuild()

    # probability mass of future items that fit into residual r, weighted by how many
    # distinct sizes remain usable (a rough refillability proxy).
    r = residual.astype(np.int64)
    np.clip(r, 0, 100, out=r)
    fit_mass = _cum[r]                # count of past items that would fit in r

    # tighter is better (best-fit), plus a bonus proportional to (normalized) refillability.
    tight = -residual
    dens = fit_mass / (_total + 1.0)

    score = tight + 50.0 * dens

    # exact fits are the most valuable: strongly prefer closing a bin.
    score[residual == 0] += 1e6

    _counts[item] += 1.0
    _total += 1.0
    _cum_dirty = True

    return score
# EVOLVE-BLOCK-END
