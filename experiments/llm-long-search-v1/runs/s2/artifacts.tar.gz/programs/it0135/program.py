# EVOLVE-BLOCK-START
"""Best-fit with a strictly subdominant empirical refill-likelihood tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    freq = _counts
    total = _n if _n > 0.0 else 1.0
    # empirical probability that a future item exactly equals this residual
    refill = freq[r] / total

    # best-fit dominant: gaps of >= 1 always beat a worse residual
    score = -residual.astype(np.float64) + 0.5 * refill

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
