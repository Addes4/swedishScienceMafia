# EVOLVE-BLOCK-START
"""Strict best-fit with a small deterministic leftover-compatibility tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    # Strict best-fit: residual ordering dominates because it is scaled large.
    score = -1000.0 * residual.astype(np.float64)

    # Bounded tie-break well below the 1000 gap: prefer leftovers that past items
    # tend to exactly fill (likely to be closed off cleanly later).
    use = smoothed[r]
    score = score + np.minimum(use, 1.0)

    # Exact-fit always wins.
    score[residual == 0] += 1e6

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
