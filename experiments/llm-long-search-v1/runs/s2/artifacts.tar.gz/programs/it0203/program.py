# EVOLVE-BLOCK-START
"""Best fit with a bounded learned perfect-fit bonus based on observed item frequencies."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    r = residual.astype(np.int64)

    # Strict best-fit: smaller residual dominates (gaps >= 1 in residual).
    score = (-residual).astype(np.float64)

    # Bounded tie-breaker: prefer a residual whose value is a frequently seen item size,
    # since such a gap is more likely to be filled exactly by a future item.
    if _n > 0.0:
        freq = _counts / _n
        norm = freq.max()
        if norm > 0.0:
            hit = freq[r] / norm  # in [0, 1]
        else:
            hit = np.zeros_like(r, dtype=np.float64)
        score = score + 0.5 * hit

    score[r == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
