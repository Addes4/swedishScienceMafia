# EVOLVE-BLOCK-START
"""Best fit with a residual-usefulness tie-break based on the empirical item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _n
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    use = freq[residual]

    # tightness term: prefer smallest residual (best fit), normalized so range is ~[0,1]
    tight = -residual.astype(np.float64) / 100.0

    # usefulness of a residual r: how often items of size ~r have appeared (or r==0)
    # scaled small so it only breaks near-ties; scaled by item size for stability
    score = tight + (0.02 * item / 40.0) * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
