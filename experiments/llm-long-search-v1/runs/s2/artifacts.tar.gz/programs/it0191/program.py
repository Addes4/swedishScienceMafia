# EVOLVE-BLOCK-START
"""Pure best-fit with a dominant exact-fill bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    # Best fit dominates: smallest residual first, scaled far above any tie-break.
    score = -1000.0 * residual.astype(np.float64)

    # Exact fill (residual 0) gets an extra push; it is already the max of best-fit
    # but this guards against any residual scaling that could be overridden.
    score[residual == 0] += 1.0

    return score
# EVOLVE-BLOCK-END
