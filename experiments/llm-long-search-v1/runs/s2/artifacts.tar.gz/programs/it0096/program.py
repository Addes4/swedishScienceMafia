# EVOLVE-BLOCK-START
"""Best fit (dominant) plus a probabilistic 'expected future waste of the leftover' tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    total = _n if _n > 0.0 else 1.0
    # probability that a future item has size exactly s (running estimate)
    p = freq / total

    r = residual.astype(np.int64)

    # Expected leftover after placing a future item of size s into a bin with residual r:
    #   leftover = r - s if s <= r else r (item doesn't fit -> bin unusable for it, keep r)
    # We value smaller expected leftover (less waste).
    sizes = np.arange(101, dtype=np.float64)
    # For each candidate residual, compute E[min-waste].
    # waste(r) = sum_{s<=r} p[s]*(r-s) + sum_{s>r} p[s]*r
    cum_le = np.cumsum(p)              # P(s <= x) index x
    # weighted sum of s for s<=x
    ws = np.cumsum(p * sizes)          # sum_{s<=x} p[s]*s
    x = np.clip(r, 0, 100)
    ple = cum_le[x]
    wle = ws[x]
    # waste = (r*ple - wle) + r*(1 - ple) = r - wle
    waste = r.astype(np.float64) - wle

    tight = -residual.astype(np.float64)
    score = tight + 0.5 * (-waste)  # prefer residues with low expected future waste

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
