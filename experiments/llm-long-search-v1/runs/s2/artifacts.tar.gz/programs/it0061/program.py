# EVOLVE-BLOCK-START
"""Best-fit with exact-fit reward and a one-step-lookahead residual-closeability tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_mean = 40.0
# smoothing kernel over residual sizes (offsets -2..+2)
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)
_half = len(_kernel) // 2
_smoothed = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _mean

    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    # Build smoothed empirical histogram (probability mass near each residual).
    freq = _counts
    _smoothed[:] = 0.0
    for k, w in enumerate(_kernel):
        off = k - _half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        _smoothed[lo + off:hi + off] += w * freq[lo:hi]
    total = _n + 1.0
    prob = _smoothed / total  # probability a future item is ~this size

    # Primary: best-fit tightness (smaller residual is better).
    tight = -residual.astype(np.float64)

    # Lookahead: how likely is this residual to be closed exactly/nicely by a future item?
    # Use probability mass near the residual (a future item of that size would fill it exactly).
    close = prob[r]

    # Expected number of items to close this residual (residual / mean item size),
    # used to mildly prefer residuals that consolidate well.
    consolidate = -residual.astype(np.float64) / (_mean + 1e-9)

    score = tight + 0.6 * close * 100.0 + 0.3 * consolidate
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _mean += (item - _mean) / _n

    return score
# EVOLVE-BLOCK-END
