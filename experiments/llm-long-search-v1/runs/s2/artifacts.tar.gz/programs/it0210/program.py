# EVOLVE-BLOCK-START
"""Best fit with a strictly-tie-breaking residual-pairing bonus."""
import numpy as np

_n = 0.0
_sum = 0.0
_counts = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    # strict best-fit dominates: distinct integer residuals ordered by tightness
    score = -residual.astype(np.float64)

    # tie-break: among equal residual, prefer a gap that can pair with another gap
    # to form a likely future item size, so one of them becomes an exact fill.
    if _n > 0.0:
        mean_item = _sum / _n
        # how frequently a residual of this size could be completed by a future item
        r = residual.astype(np.int64)
        f = _counts[r] / _n  # empirical frequency of items equal to the gap
        reuse = 0.5 * (f / (f.max() + 1e-12)) if f.max() > 0 else np.zeros_like(f)
        # only a tie-breaker: keep magnitude below 1.0 so best-fit is never reordered
        score = score + reuse

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
