# EVOLVE-BLOCK-START
"""Best fit with a scale-invariant complement-frequency tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    r = residual.astype(np.int64)
    freq = _counts
    total = _n if _n > 0.0 else 1.0

    # Complement frequency: how often have we seen an item that exactly fills
    # the resulting residual?  Normalized to [0,1].
    complement = freq[np.clip(r, 0, 100)] / total

    # Strictly best-fit dominant: smaller residual always wins (gaps >= 1).
    tight = -residual.astype(np.float64)
    score = tight + 0.5 * complement

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
