# EVOLVE-BLOCK-START
"""Best fit with an adaptive residual-reusability correction."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    rem = np.asarray(bins, dtype=float)
    residual = rem - item  # leftover after placing

    # Primary: tightest fit (smaller residual = better).
    score = -residual

    # Correction: residual close to a typical item size is reusable -> small bonus.
    # Tiny residuals are wasted -> small penalty. Smooth, bounded.
    bonus = np.exp(-((residual - mean) ** 2) / (2.0 * mean * mean))
    penalty = np.exp(-residual / max(mean * 0.3, 1.0))
    score += 0.05 * (bonus - penalty)

    return score
# EVOLVE-BLOCK-END

