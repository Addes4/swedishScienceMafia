# EVOLVE-BLOCK-START
"""Best fit dominant, with a tie-break rewarding residuals that a typical future item can fill exactly."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    rf = residual.astype(np.float64)

    # Dominant term: best fit => smallest residual.
    score = -rf

    if _n > 0.0:
        freq = _counts
        total = _n
        # probability mass of future items at each size (smoothed slightly)
        prob = freq / total
        # Secondary: reward residuals that equal a typical future item size,
        # so leftover can likely be filled exactly by a single future item.
        # Use smoothed probability in a small window around the residual.
        r = residual.astype(np.int64)
        r = np.clip(r, 0, 100)
        # exact-match probability plus small share of neighbors
        p_exact = prob[r]
        p_left = prob[np.clip(r - 1, 0, 100)]
        p_right = prob[np.clip(r + 1, 0, 100)]
        typ = p_exact + 0.4 * (p_left + p_right)

        # scale to a small magnitude so it only breaks near-ties
        score = score + 0.35 * typ * 100.0 / max(np.max(p_exact) * 100.0, 1e-9) * 0.0 + 0.02 * typ * 100.0

    # exact-fill bonus: a residual of 0 is perfectly closed
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
