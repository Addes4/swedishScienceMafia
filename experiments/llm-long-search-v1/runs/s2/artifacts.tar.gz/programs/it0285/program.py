# EVOLVE-BLOCK-START
"""Log-penalty best fit with smoothed usefulness bonus, exact-residual and sum-complement reuse bonuses."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2
_maxfreq = 1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _maxfreq
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    rf = residual.astype(np.float64)

    # log penalty preserves best-fit dominance (monotone decreasing in residual)
    tight = -np.log1p(rf)
    score = 4.0 * tight + 0.4 * use

    if _n > 0.0:
        mean_item = _sum / _n
        reuse = 0.25 * np.exp(-((rf - mean_item) ** 2) /
                              (2.0 * (0.25 * mean_item + 1.0) ** 2))
        score = score + reuse

    # bounded exact-residual-match bonus: rewards leftovers equal to common item sizes,
    # kept strictly below the integer gap of best-fit so it cannot override tighter fits.
    exact = freq[r] / _maxfreq
    score = score + 0.2 * exact

    # sum-complement bonus: reward residuals that equal the sum of two common small item
    # sizes (a frequent multi-item fill pattern). Still bounded below the integer gap.
    comp = np.zeros(101, dtype=np.float64)
    counts = freq
    small = np.nonzero(counts)[0]
    small = small[small <= 60]
    if len(small) > 0:
        wsmall = counts[small] / _maxfreq
        for a, wa in zip(small, wsmall):
            for b, wb in zip(small, wsmall):
                s = int(a) + int(b)
                if 1 <= s <= 100:
                    comp[s] += wa * wb
    compmx = comp.max() if comp.max() > 0 else 1.0
    score = score + 0.15 * (comp[r] / compmx)

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item
    if _counts[item] > _maxfreq:
        _maxfreq = _counts[item]

    return score
# EVOLVE-BLOCK-END
