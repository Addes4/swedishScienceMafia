# EVOLVE-BLOCK-START
"""Best fit with a strictly-dominant primary term and a subset-sum-aware gap tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)   # raw histogram of past item sizes
_knapsack = np.zeros(101, dtype=np.float64) # subset-sum reachability (how often a total is exactly coverable)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)


def _update_subset_sums(item):
    """Maintain how frequently each total 0..100 is exactly achievable by combos of past items."""
    global _knapsack
    # Prefer recent items: decay the reachability profile slightly each step.
    _knapsack *= 0.98
    _knapsack[0] = 1.0
    if item <= 100:
        # unbounded contribution of this item size to subset-sum reachability
        for total in range(item, 101):
            _knapsack[total] = min(1.0, _knapsack[total] + 0.5 * _knapsack[total - item])


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    residual_f = residual.astype(np.float64)

    # Strict best-fit dominant primary key: smallest residual wins by a wide margin.
    score = -1000.0 * residual_f

    # --- subset-sum-aware gap tie-break (only matters within the minimal-residual class) ---
    r = residual.astype(np.int64)
    reach = _knapsack[r]                       # how likely the resulting gap is exactly fillable
    # Also reward gaps matching a common single item size.
    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    gap_utility = 0.9 * reach + 0.3 * smoothed[r]
    score = score + gap_utility

    # exact fit strongly preferred
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _update_subset_sums(item)
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
