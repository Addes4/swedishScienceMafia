# EVOLVE-BLOCK-START
"""Best fit with a strictly-monotone residual-favorability tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    tight = -residual.astype(np.float64)
    # usefulness bonus kept below 1.0 in magnitude so best-fit (gaps of >=1) stays dominant
    score = tight + 0.4 * use

    # deterministic residual-favorability bump:  prefer leaving a residual near the
    # typical post-placement leftover (~30), discouraging tiny hard-to-fill gaps
    # and huge sparse ones alike; strictly below 1.0 so best-fit stays dominant.
    resid = residual.astype(np.float64)
    target = 30.0
    sigma = 18.0
    score = score + 0.3 * np.exp(-((resid - target) ** 2) / (2.0 * sigma * sigma))

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
