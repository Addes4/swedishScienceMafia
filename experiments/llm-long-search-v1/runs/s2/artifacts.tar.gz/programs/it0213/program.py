# EVOLVE-BLOCK-START
"""Best fit with an exact-tie break by expected future fill from a running item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0

# smoothing kernel over item sizes (offsets -2..+2), normalized
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)
_kernel = _kernel / _kernel.sum()
_half = len(_kernel) // 2


def priority(item, bins):
    """Rank bins: smallest residual first; among equal residuals prefer the most likely to be
    filled exactly by a future item (higher smoothed probability that an item equals residual)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    # smoothed probability weight for each residual value via convolution
    smoothed = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_kernel):
        off = k - _half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    r = residual.astype(np.int64)
    reuse = smoothed[r]

    # strict best-fit dominance: residual gaps are integers >= 1, so scaling reuse below 1
    # keeps the smallest residual always optimal while breaking exact ties.
    score = -residual.astype(np.float64) + 0.9 * reuse

    # exact fits are always taken (huge but finite bonus)
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
