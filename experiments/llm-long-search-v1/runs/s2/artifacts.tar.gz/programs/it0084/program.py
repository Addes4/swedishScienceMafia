# EVOLVE-BLOCK-START
"""Best-fit dominance with a static, calibrated residual-quality tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0

# Static prior over item sizes (Weibull-shaped, mean ~40): used only as a lightweight,
# scale-stable secondary signal, never overriding the best-fit (tightest residual) key.
_sizes = np.arange(101, dtype=np.float64)
_shape = 1.35
_scale = 43.0
_prior = (_sizes / _scale) ** (_shape - 1.0) * np.exp(-(_sizes / _scale) ** _shape)
_prior /= _prior.sum()

# smoothed prior: probability an item of ~this residual size will arrive
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)
_half = len(_kernel) // 2
_smoothed_prior = np.zeros(101, dtype=np.float64)
for k, w in enumerate(_kernel):
    off = k - _half
    lo = max(0, -off)
    hi = min(101, 101 - off)
    _smoothed_prior[lo + off:hi + off] += w * _prior[lo:hi]


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0

    r = residual.astype(np.int64)
    # static expected usefulness of keeping this residual open
    use = _smoothed_prior[r]

    # dominant: tightest residual (best fit). Secondary: likelihood a future item fills it.
    tight = -residual.astype(np.float64)
    score = tight + 0.75 * use
    score[residual == 0] += 1000.0  # always prefer exact fills

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
