# EVOLVE-BLOCK-START
"""Exact-fit preference + best-fit, with a small nudge toward reusable residuals."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # dominant key: tightest residual (best fit), exact fill gets a huge bonus
    score = -residual.astype(np.float64)

    # nudge: among small residuals, favor ones not smaller than a typical item,
    # so we avoid making tiny unusable slivers. Scale kept small vs best-fit gap of 1.
    r = residual.astype(np.float64)
    reusable = np.minimum(r, 40.0) / 40.0  # 0 for exact fill, grows then plateaus
    score += 0.1 * reusable

    # exact fills are always ideal
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END

