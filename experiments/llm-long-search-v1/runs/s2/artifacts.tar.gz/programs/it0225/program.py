# EVOLVE-BLOCK-START
"""Best fit, with a bounded within-tie bonus favoring residuals likely to be exactly filled soon."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    rf = residual.astype(np.float64)

    # Best-fit is the strictly dominant primary key: gaps of >= 1 dominate any tie-break.
    score = -rf

    # Smoothed running histogram of past item sizes (len 101).
    smoothed = np.convolve(_counts, np.array([0.15, 0.2, 0.3, 0.2, 0.15]), mode="same")

    # Bounded bonus (in [0,1)) favoring residuals that are a likely upcoming item size,
    # so a near-exact fit is preferred within the same minimal-residual class.
    r = residual.astype(np.int64)
    mass = smoothed[r]
    mx = mass.max()
    if mx > 0.0:
        score = score + mass / (mx + 1.0)

    # Exact fit still slightly favored inside the same bucket ordering.
    score[residual == 0] += 0.5

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
