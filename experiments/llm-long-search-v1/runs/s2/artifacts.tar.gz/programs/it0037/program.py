# EVOLVE-BLOCK-START
"""Best fit, with near-ties broken toward residuals closest to the typical item size."""
import numpy as np

_sum = 0.0
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _sum, _n
    residual = bins - item  # >= 0 for all bins shown

    # running mean item size (online estimate of typical future item)
    mean_item = (_sum / _n) if _n > 0 else 40.0

    # tightness term: prefer smallest residual (best fit)
    tight = -residual.astype(np.float64)

    # tie-break: prefer residual close to the typical item size, so leftover
    # capacity is likely to be exactly consumed by a future item (reduces waste).
    match = -np.abs(residual.astype(np.float64) - mean_item)

    score = tight + 0.5 * match
    score[residual == 0] += 1000.0

    _sum += item
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
