# EVOLVE-BLOCK-START
"""Best fit with a strong new-bin-avoidance tie-break and reuse bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    # Dominant best-fit term: smaller residual is better.
    tight = -residual.astype(np.float64)

    # Tie-break 1: penalize bins that are completely empty (residual == 100),
    # strongly discouraging opening new bins while good partial bins exist.
    empty_penalty = np.where(bins == 100, -0.6, 0.0)

    # Tie-break 2: usefulness of residual from empirical histogram.
    use = _counts[np.clip(residual, 0, 100).astype(np.int64)]
    usefulness = 0.3 * (use / (1.0 + use))

    score = tight + empty_penalty + usefulness

    # Reuse bonus: reward residual close to typical item size (likely closable).
    if _n > 0.0:
        mean_item = _sum / _n
        reuse = 0.25 * np.exp(-((residual.astype(np.float64) - mean_item) ** 2) /
                              (2.0 * (0.25 * mean_item + 1.0) ** 2))
        score = score + reuse

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
