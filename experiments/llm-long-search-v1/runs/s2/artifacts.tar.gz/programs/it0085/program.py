# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and a sliver-avoidance tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)

    # Dominant key: tighter residual (best fit). Sliver avoidance: among bins whose
    # residual differs by at most a small bucket, prefer leaving a slightly larger
    # residual so we don't create unusable tiny gaps.
    bucket = np.floor(r / 4.0)
    score = -bucket

    # Within the same coarse bucket, prefer the larger residual (less fragmentation).
    score = score * 1000.0 + r

    # Strong preference for exact fills (residual 0): always optimal.
    score[r == 0] += 1e9

    return score
# EVOLVE-BLOCK-END
