# EVOLVE-BLOCK-START
"""Best fit, but avoid leaving residuals smaller than the smallest seen item."""
import numpy as np

_state = {"min_seen": 101}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item < _state["min_seen"]:
        _state["min_seen"] = item
    min_seen = _state["min_seen"]

    residual = bins - item  # >= 0 for all shown bins
    tight = -residual  # best-fit: prefer smallest residual

    # Penalize bins whose post-placement residual is a tiny sliver that future
    # items (as small as min_seen) could never fill: 0 < residual < min_seen.
    # Such bins are wasted. Push them down unless the fit is exact (residual 0).
    sliver = (residual > 0) & (residual < min_seen)
    return tight - sliver * 1000.0
# EVOLVE-BLOCK-END
