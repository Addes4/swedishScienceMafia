# EVOLVE-BLOCK-START
"""Best fit with a sub-1.0 tie-break favoring residuals that can be reused soon."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    residual_f = residual.astype(np.float64)

    # Primary rule: strict best fit (smallest residual). Gaps of >=1 dominate the bonus.
    score = -residual_f

    # Sub-1.0 tie-break: prefer a residual that, combined with the most frequent item size,
    # leaves another plausible item size, i.e. reuse more likely in the near future.
    if _n > 0.0:
        mode_size = float(np.argmax(_counts[1:]) + 1)
        reuse_res = residual_f + mode_size  # residual after a future mode-sized item
        # value of reuse_res: higher where some observed item size fits it exactly
        freq = _counts
        idx = np.clip(reuse_res.astype(np.int64), 0, 100)
        val = freq[idx] / max(1.0, _n)
        score = score + 0.5 * val

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
