# EVOLVE-BLOCK-START
"""Pure best-fit: place each item into the bin with the smallest remaining capacity that still fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown
    # Strict best-fit: smaller residual is better. Ties go to the first bin.
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
