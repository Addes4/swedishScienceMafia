# EVOLVE-BLOCK-START
"""Best fit with a smoothed residual-usefulness tie-break based on the empirical item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item

    freq = _counts
    r = residual.astype(np.int64)

    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    tight = -residual.astype(np.float64)
    score = tight + 0.6 * use
    # slight extra reward for closing a bin exactly
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END

