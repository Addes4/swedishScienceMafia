# EVOLVE-BLOCK-START
"""Best fit with a tiny tie-break preferring residuals that equal a frequent past item size."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, ties go to first bin."""
    global _n
    residual = bins - item

    # exact-frequency lookup: how often a past item exactly matched this residual
    r = residual.astype(np.int64)
    r = np.clip(r, 0, 100)
    freq = _counts[r]

    # normalize frequency to a small bump; primary key is still tightness (-residual)
    total = _n if _n > 0 else 1.0
    bonus = freq / total  # in [0, 1], tiny relative to residual differences

    score = -residual.astype(np.float64) + 0.25 * bonus
    # a perfectly filled bin is always best
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
