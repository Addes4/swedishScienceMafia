# EVOLVE-BLOCK-START
"""Best-fit dominant, with an empirical-histogram tie-break on exact residuals."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    # Smoothed empirical probability that a future item fills this exact residual.
    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    # best-fit dominant; empirical fill-probability only breaks exact ties (<1.0 scale)
    score = -residual.astype(np.float64) + 0.5 * use

    _counts[item] += 1.0
    return score
# EVOLVE-BLOCK-END
