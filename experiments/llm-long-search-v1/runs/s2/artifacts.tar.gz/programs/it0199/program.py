# EVOLVE-BLOCK-START
"""Best fit (dominant) plus a bounded bonus preferring the modal recent item size."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_decay = 0.9975  # exponential forgetting so the recent distribution tracks drift


def priority(item, bins):
    """Score each bin: strict best-fit dominates, plus a small "refill-likely" bonus."""
    global _n, _sum

    residual = bins - item  # >= 0 for all bins shown

    # Modal / most-likely upcoming item size from a decayed empirical histogram.
    # Cheap proxy: the mode of the decayed counts (ties -> smaller size).
    freq = _counts
    if _n > 0.0:
        mode_size = int(np.argmax(freq))
    else:
        mode_size = item

    refill = 0.6 * np.exp(-((residual.astype(np.float64) - mode_size) ** 2) /
                          (2.0 * 3.0 * 3.0))

    # strict best-fit ordering (integer gaps >= 1) with bounded tie-breaker
    score = -residual.astype(np.float64) + refill

    score[residual == 0] += 1000.0

    _counts *= _decay
    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
