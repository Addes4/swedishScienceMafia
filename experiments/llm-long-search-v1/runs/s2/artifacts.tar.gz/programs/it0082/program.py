# EVOLVE-BLOCK-START
"""Best fit with a smoothed residual-usefulness tie-break based on the empirical item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
# small smoothing kernel over residual sizes: an item of size ~r can fill a bin of residual r or slightly larger
_kernel = np.array([0.10, 0.20, 0.40, 0.20, 0.10], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    n = min(len(_kernel), 101)
    half = len(_kernel) // 2
    smoothed = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    # normalize to a probability so the bonus stays bounded and never dominates best-fit
    total = smoothed.sum()
    if total > 0:
        smoothed = smoothed / total

    use = smoothed[r]

    tight = -residual.astype(np.float64)
    score = tight + 0.5 * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
