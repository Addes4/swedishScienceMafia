# EVOLVE-BLOCK-START
"""Best fit with a residual-reusability tie-break: prefer leftover sizes that are themselves common item sizes."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    # Dominant term: best fit (smallest residual) -> prefer nearly full bins.
    tight = -residual.astype(np.float64)

    # Secondary term: reusability of the leftover residual as a future item size.
    # Normalize the running histogram to a probability; smooth slightly so unseen sizes aren't zeroed.
    total = _n if _n > 1.0 else 1.0
    prob = _counts / total
    # light smoothing over neighbors so residuals near a common size still get credit
    sm = prob.copy()
    sm[1:] += 0.2 * prob[:-1]
    sm[:-1] += 0.2 * prob[1:]

    use = sm[r]

    score = tight + 0.5 * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END

