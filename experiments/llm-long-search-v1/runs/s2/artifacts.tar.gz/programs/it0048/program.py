# EVOLVE-BLOCK-START
"""Best fit with a consolidation bonus: among equally tight residuals, prefer the
residual size that the bin population most concentrates on, so future items of that
size can refill bins exactly."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    # exact-refill usefulness only (kernel peaked at offset 0)
    r = residual.astype(np.int64)
    use = freq[r]

    tight = -residual.astype(np.float64)
    # consolidation: reward residuals that are common future item sizes (exact refill),
    # weight kept small so best-fit tightness stays primary
    score = tight + 0.5 * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
