# EVOLVE-BLOCK-START
"""Best fit with an exact-close bonus and no noisy perturbations."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    # Best fit: smaller residual is better (strictly dominant since gaps are >= 1).
    score = -residual.astype(np.float64)

    # Strongly prefer closing a bin exactly, but keep below 1.0 so it only
    # breaks ties among equal residuals.
    score[residual == 0] += 0.5

    return score
# EVOLVE-BLOCK-END

