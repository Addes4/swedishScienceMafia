# EVOLVE-BLOCK-START
"""Pure best-fit: place into the bin leaving the smallest non-negative residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    # Smaller residual (fuller bin) is strictly preferred -> classic best fit.
    score = -residual.astype(np.float64)

    # Exact fit is by far the best.
    score[residual == 0] += 1000.0

    return score
# EVOLVE-BLOCK-END
