# EVOLVE-BLOCK-START
"""Best fit with a bounded histogram tie-break that only breaks exact residual ties."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    # Normalize histogram to [0, 1] so it can only break exact residual ties.
    denom = smoothed.max()
    if denom > 0.0:
        use = smoothed[r] / denom
    else:
        use = np.zeros_like(residual, dtype=np.float64)

    # Best-fit dominates: residual is multiplied so a residual gap of 1 beats any tie-break.
    score = -residual.astype(np.float64) * 1000.0 + use

    score[residual == 0] += 1e9

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
