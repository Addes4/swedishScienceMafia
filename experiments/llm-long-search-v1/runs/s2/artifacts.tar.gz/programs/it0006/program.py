# EVOLVE-BLOCK-START
"""Best fit with a small preference for leaving reusable residual capacity."""
import numpy as np


def priority(item, bins):
    """Rank bins: tightest fit first, but mildly prefer leftovers that stay reusable."""
    rem_after = bins - item
    # Primary: tightest fit (smallest remainder). Secondary: prefer larger remainders
    # when they are at least a typical item size (~40), so the residual space stays useful.
    return -(rem_after) + 0.05 * np.minimum(rem_after, 40)
# EVOLVE-BLOCK-END
