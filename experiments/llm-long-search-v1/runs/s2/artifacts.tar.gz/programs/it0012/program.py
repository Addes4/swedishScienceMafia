# EVOLVE-BLOCK-START
"""Size-aware fit: small items -> best fit, large items -> spread into emptier bins."""
import numpy as np


class _State:
    n = 0
    total = 0.0


_state = _State()


def priority(item, bins):
    s = _state
    # running mean of seen items (guard for first call)
    mean = s.total / s.n if s.n > 0 else 40.0
    s.n += 1
    s.total += item

    if item >= mean:
        # large item: prefer the emptiest bin it fits in (worst fit),
        # i.e. maximize remaining capacity
        return bins.astype(np.float64)
    else:
        # small item: tightest fit (best fit)
        return -(bins - item)
# EVOLVE-BLOCK-END
