# EVOLVE-BLOCK-START
"""Best fit with a smoothed empirical 'near-exact-fill' tie-break bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.15, 0.25, 0.4, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def _smooth(freq):
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    return smoothed


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    smoothed = _smooth(freq)
    total = smoothed.sum() + 1e-9
    prob = smoothed / total  # empirical probability an item has this size

    r = residual.astype(np.int64)
    # Probability this residual can be exactly closed by one upcoming item:
    close_prob = prob[r]

    # Probability residual equals a sum of two common items (pair-fill), approximated by
    # the empirical distribution convolved with itself, sampled at r.
    conv = np.convolve(prob, prob)  # length 201
    lens = np.arange(len(conv))
    pair = np.zeros(101, dtype=np.float64)
    valid = (lens >= 0) & (lens <= 100)
    pair[lens[valid]] = conv[valid]

    fill = close_prob + 2.0 * pair[r]

    # best-fit remains strictly dominant: residual gap >= 1 dominates any bonus < 1
    score = -residual.astype(np.float64) + 0.9 * fill
    # exact-fit (residual == 0) is always taken immediately
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
