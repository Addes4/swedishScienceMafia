# EVOLVE-BLOCK-START
"""Best fit with a bounded reuse-shape bonus favoring residuals near the mean item size."""
import numpy as np

_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum

    residual = bins - item  # >= 0 for all bins shown
    res_f = residual.astype(np.float64)

    # Dominant primary term: strict best fit (smallest residual wins).
    score = -res_f

    if _n > 4.0:
        mean_item = _sum / _n
        sigma = 0.35 * mean_item + 1.0
        reuse = np.exp(-((res_f - mean_item) ** 2) / (2.0 * sigma * sigma))
        # bounded well below 1.0 so best-fit gaps of >=1 always dominate this tie-break
        score = score + 0.45 * reuse

    # Exact fills always dominate everything.
    score[residual == 0] += 1000.0

    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
