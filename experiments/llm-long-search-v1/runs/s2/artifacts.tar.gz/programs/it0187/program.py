# EVOLVE-BLOCK-START
"""Best fit with a strictly-tie-breaking gap-fill probability tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    total = freq.sum()
    if total > 0.0:
        prob = freq / total
    else:
        prob = freq  # all zeros

    r = residual.astype(np.int64)
    # probability that a future item exactly fills the residual (roughly),
    # clipped to [0,1]; kept below 1 so best-fit dominance is preserved
    fill_prob = prob[np.clip(r, 0, 100)]

    tight = -residual.astype(np.float64)
    score = tight + 0.4 * fill_prob

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
