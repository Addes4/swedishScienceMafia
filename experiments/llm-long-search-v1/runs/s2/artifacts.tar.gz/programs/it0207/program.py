# EVOLVE-BLOCK-START
"""Best fit with a strictly sub-1.0 tie-breaking bonus for reusable residuals."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # Strict best-fit primary term: smaller residual wins by at least 1.0 gap.
    score = -residual.astype(np.float64)

    # Tie-breaking bonus (strictly < 1.0, cannot reorder distinct integer residuals):
    # reward residuals that either exactly match a frequent item size (likely to be
    # refilled later) or are exactly 0 (closing a bin immediately).
    if _n > 0.0:
        freq = _counts / _n
        r = residual.astype(np.int64)
        prob = freq[r]                    # probability a future item equals this residual
        score += 0.5 * prob               # bounded by 0.5 < 1.0

    score[residual == 0] += 0.9           # strongly prefer closing bins, still < 1.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
