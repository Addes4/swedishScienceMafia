# EVOLVE-BLOCK-START
"""Strict best-fit with an online empirical tie-breaker.

Primary term: prefer the smallest residual (best fit). Because residuals are
integers, the primary score `-residual` dominates any tie-breaker whose total
magnitude stays strictly below 1, so best-fit ordering is preserved across
bins whose residuals differ by at least 1.

Tie-breaker: among residuals that are equal (or within the same best-fit gap),
prefer the residual value whose corresponding item size has been observed most
often so far, since such a gap is most likely to be exactly refilled by a
future item. A small novelty term also rewards gaps that are neither too small
nor too large relative to the running mean item size.
"""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_sumsq = 0.0


def priority(item, bins):
    global _n, _sum, _sumsq
    residual = bins - item  # >= 0

    tight = -residual.astype(np.float64)

    # Empirical probability that a future item equals the residual (exact refill).
    total = _n if _n > 0.0 else 1.0
    freq = _counts / total  # in [0, 1]

    r = residual.astype(np.int64)
    # smoothed frequency over a small window to soften sparse counts
    sm = 0.5 * freq + 0.25 * np.roll(freq, 1) + 0.25 * np.roll(freq, -1)
    sm[0] = freq[0]  # residual 0 can't be refilled anyway
    refill = sm[r]

    # Novelty/usefulness prior: prefer residuals near the running mean item size.
    if _n > 0.0:
        mean_item = _sum / _n
        scale = 0.5 * mean_item + 1.0
        useful = np.exp(-((residual.astype(np.float64) - mean_item) ** 2) / (2.0 * scale * scale))
    else:
        useful = np.zeros_like(refill)

    # Keep the combined bonus strictly below 1.0 to preserve best-fit dominance.
    score = tight + 0.5 * refill + 0.4 * useful

    # Hard prefer exact fills (residual 0) - dominant, still below 1 spacing.
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item
    _sumsq += item * item

    return score
# EVOLVE-BLOCK-END
