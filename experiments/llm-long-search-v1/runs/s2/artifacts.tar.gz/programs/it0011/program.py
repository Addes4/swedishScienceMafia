# EVOLVE-BLOCK-START
"""Harmonic-class best fit: rank bins by closeness to capacity-class boundaries."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Remaining capacity after placing the item.
    leftover = bins - item  # >= 0 since bins only contains fitting bins

    # Best-fit core: prefer the smallest leftover.
    base = -(leftover.astype(np.float64))

    # Harmonic-style correction: reward leaving a residual that is not tiny
    # relative to the half-open class of the pre-placement capacity.
    # Small items benefit from consolidating into already-partly-used bins;
    # large items should still pack tightly. This term is small enough to act
    # as a tie-breaker around the best-fit ordering.
    safe = np.maximum(leftover, 1)
    frac = item / (bins.astype(np.float64) + 1.0)  # how much of the bin the item occupies
    bonus = (1.0 - frac) * np.log1p(safe)

    return base + 0.5 * bonus
# EVOLVE-BLOCK-END
