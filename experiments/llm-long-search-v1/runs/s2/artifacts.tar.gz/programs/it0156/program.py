# EVOLVE-BLOCK-START
"""Best fit dominant, with a small complementary-fit tie-break toward residual 1..small items."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # Dominant: best fit (smallest residual). Scale so any residual difference outweighs tie-breaks.
    score = -residual.astype(np.float64) * 1000.0

    # Tie-break: prefer resulting residual that is a common small item size (likely closeout soon).
    r = residual.astype(np.int64)
    # smoothed frequency of residual values as future item sizes
    smoothed = np.zeros(101, dtype=np.float64)
    freq = _counts
    smoothed[0:99] += 0.25 * freq[1:100]
    smoothed[1:100] += 0.5 * freq[1:100]
    smoothed[2:101] += 0.25 * freq[1:100]
    # bounded below 1 so it cannot override a full-unit residual difference
    score += 0.9 * smoothed[r] / (1.0 + smoothed[r])

    # exact fit strongly preferred (still within same residual class anyway)
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
