# EVOLVE-BLOCK-START
"""Best fit with a bounded penalty for leaving unusably small residuals."""
import numpy as np

_small_count = 0.0
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _small_count, _n
    residual = (bins - item).astype(np.float64)  # >= 0 for all bins shown

    # Estimate a "small item" scale: track items well below the mean (~40).
    # Residuals under roughly this size are hard to refill and waste capacity.
    if _n > 0.0:
        # rough low-end scale, grows slowly; floor to avoid zero
        low_scale = max(3.0, 0.12 * (40.0))
    else:
        low_scale = 5.0

    # Strict best-fit: tighter residual is better (integer gaps).
    score = -residual

    # Penalize residuals below low_scale so we prefer a slightly larger,
    # refillable gap over a near-useless tiny one. Magnitude just over 1
    # lets this break the best-fit ordering only by a single unit.
    waste_penalty = np.where(residual < low_scale,
                             1.2 * (low_scale - residual) / (low_scale + 1.0),
                             0.0)
    score = score - waste_penalty

    # Perfect fill is still strongly preferred.
    score[residual == 0] += 1000.0

    if item < low_scale:
        _small_count += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
