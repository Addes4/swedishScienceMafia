# EVOLVE-BLOCK-START
"""Pure best-fit with a dominant residual key; ties broken by fullest bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    # Dominant: smallest residual wins. Large scale so ties are only near-exact.
    score = -residual.astype(np.float64) * 1000.0

    # Tie-break: prefer the fullest bin (smallest prior remaining capacity = smallest residual+item),
    # i.e. smallest residual; already captured, so add tiny preference for smaller residual again
    # is redundant. Instead prefer bins with smaller prior capacity beyond residual scale.
    # Among equal residual, bins all have equal residual -> identical. Use prior capacity:
    # prior capacity = residual + item, which is identical for equal residual. So no info.
    # Fall back to a stable, deterministic secondary: prefer exact fill strongly.
    score[residual == 0] += 1.0

    return score
# EVOLVE-BLOCK-END
