# EVOLVE-BLOCK-START
"""Best-fit dominant rule with a bounded, deterministic future-fit tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_last_count = -1
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)


def _smoothed_histogram():
    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    total = smoothed.sum()
    if total > 0.0:
        smoothed /= total
    return smoothed


def priority(item, bins):
    """Best fit (smallest residual) dominates; exact-residual ties break by future-fit."""
    global _n, _sum

    residual = bins - item  # >= 0 for all bins shown

    # Strict best-fit primary key: large scale keeps residual ordering dominant.
    score = -residual.astype(np.float64) * 100.0

    if _n > 0.0:
        smoothing = _smoothed_histogram()
        # For each bin, the benefit of the residual being hit exactly by a future item.
        # Bounded to [0, 1); cannot overturn a residual difference of 1 (which is 100).
        bonus = smoothing[residual.astype(np.int64)]
        mean_item = _sum / _n
        # Slight preference toward residual near the mean item size (most likely fill).
        scale = 0.25 * mean_item + 1.0
        bonus = bonus + 0.1 * np.exp(-((residual.astype(np.float64) - mean_item) ** 2) /
                                     (2.0 * scale * scale))
        score = score + bonus

    # Prefer exact fills of a remaining gap immediately (still under 100).
    score[residual == 0] += 50.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
