# EVOLVE-BLOCK-START
"""Best fit as a dominant primary rule, with an empirical exact-residual-match tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2
_MAXSIZE = 100.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    # Empirical frequency of residual == 0 handling and of matching a common item size.
    # Normalize use to [0,1] so it acts as a bounded tie-break only.
    if _n > 0.0:
        umax = smoothed.max()
        use = use / umax if umax > 0.0 else use
    reuse = 0.4 * use

    # Best-fit strictly dominant: any residual difference (>=1) outweighs all tie-breaks.
    score = -_MAXSIZE * residual.astype(np.float64) + reuse

    score[residual == 0] += 1e6

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
