# EVOLVE-BLOCK-START
"""Log-penalty best fit with a scale-relative residual padding bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    rf = residual.astype(np.float64)

    # Best-fit dominance: strictly decreasing in residual.
    score = 4.0 * (-np.log1p(rf))

    # Bonus tied to the arriving item: reward leftovers that are either nearly empty
    # (finish a bin) or close to the item's own magnitude (pair like-sized items).
    window = 0.30 * item + 1.0
    near_item = np.exp(-((rf - item) ** 2) / (2.0 * window * window))
    score = score + 0.35 * near_item

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
