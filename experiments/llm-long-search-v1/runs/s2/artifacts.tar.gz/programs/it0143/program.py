# EVOLVE-BLOCK-START
"""Best fit with a stable smoothed-histogram tie-break on the residual."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0

# Smoothing kernel over item-size offsets (length 5).
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)
_half = len(_kernel) // 2


def _smoothed_histogram():
    """Return a length-101 array: smoothed probability that an item equals each size."""
    freq = _counts
    total = freq.sum()
    if total <= 0.0:
        return None
    prob = freq / total
    smoothed = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_kernel):
        off = k - _half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * prob[lo:hi]
    return smoothed


def priority(item, bins):
    """Best fit; ties broken by likelihood the residual exactly matches a future item."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # Best-fit is strictly dominant: smaller residual => higher score.
    score = -residual.astype(np.float64)

    r = residual.astype(np.int64)
    # Ties in residual (integer gaps) get broken by the smoothed item-size probability.
    # Probabilities are < 1.0, so this only ever distinguishes bins with different
    # residuals when they are within one unit; exact-residual ties are cleanly broken.
    prob = _smoothed_histogram()
    if prob is not None:
        use = prob[r]
        # Keep the bonus strictly below 1.0 so best-fit dominance is preserved.
        score = score + 0.5 * use

    # An exactly filled bin (residual 0) of the current best-fit is preferred last-resort.
    score[residual == 0] += 1e-6

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
