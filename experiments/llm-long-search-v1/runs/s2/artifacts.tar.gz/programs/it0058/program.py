# EVOLVE-BLOCK-START
"""Best fit with a bounded smoothed-histogram tie-break favoring closeable residuals."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)

    # smoothed usefulness: probability a future item can roughly fill this residual
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    total = _n if _n > 1.0 else 1.0
    # normalized to a bounded [0, ~1] usefulness estimate
    use = smoothed[r] / total
    np.clip(use, 0.0, 1.0, out=use)

    tight = -residual.astype(np.float64)
    # small bounded bonus so it only breaks near-ties, not override best-fit
    score = tight + 0.3 * use
    # closing a bin exactly (zero waste) is strongly preferred
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
