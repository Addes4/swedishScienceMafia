# EVOLVE-BLOCK-START
"""Pure best-fit with a tiny, bounded recent-size tie-break."""
import numpy as np

_recent = np.zeros(101, dtype=np.float64)
_recent_n = 0.0
_decay = 0.98


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    global _recent_n
    residual = bins - item  # >= 0

    r = residual.astype(np.float64)

    # Dominant term: strict best-fit (smallest residual wins).
    score = -r

    # Small bounded bonus (< 1) favoring residuals that match a recently-seen
    # item size, so gaps likely to be filled exactly are preferred on ties.
    if _recent_n > 1.0:
        bonus = 0.5 * (_recent / _recent_n)
        ri = residual.astype(np.int64)
        score = score + bonus[ri]

    # Exact fits always win.
    score[residual == 0] += 1000.0

    # Update decayed recent-size statistics.
    _recent *= _decay
    _recent_n *= _decay
    _recent[item] += 1.0
    _recent_n += 1.0

    return score
# EVOLVE-BLOCK-END
