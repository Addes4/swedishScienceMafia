# EVOLVE-BLOCK-START
"""Best fit, with a within-tie preference for bins that are most likely to be refilled soon."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_smoothed_cache = None


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _smoothed_cache

    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    # best fit dominates: bins with smaller residual get strictly higher score.
    # gaps are >= 1, so a tie-break bonus below 1.0 never overrides best fit.
    score = -residual.astype(np.float64)

    # Smoothed histogram of past item sizes (used only as a tie-break).
    if _n > 0.0:
        # recompute the smooth histogram lazily (once per call is fine)
        freq = _counts
        k = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)
        smoothed = np.zeros(101, dtype=np.float64)
        half = len(k) // 2
        for kk, w in enumerate(k):
            off = kk - half
            lo = max(0, -off)
            hi = min(101, 101 - off)
            smoothed[lo + off:hi + off] += w * freq[lo:hi]
        mass = smoothed.sum()
        if mass > 0.0:
            smoothed /= mass

            # probability that the residual gets exactly filled by some future item
            exact = smoothed[r]
            # current residual best fit among bins sharing the same minimal residual
            score = score + 0.6 * exact

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END

