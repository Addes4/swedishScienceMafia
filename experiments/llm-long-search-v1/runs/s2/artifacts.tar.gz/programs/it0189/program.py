# EVOLVE-BLOCK-START
"""Best fit with a strictly-tie-breaking residual-reusability bonus from the live histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # Dominant best-fit term: scaled so any residual difference outweighs the bonus.
    score = -1000.0 * residual.astype(np.float64)

    # Live empirical distribution of item sizes seen so far.
    n = _n
    if n > 0.0:
        p = _counts / n
    else:
        p = np.full(101, 1.0 / 101.0)

    # For each possible residual r, estimate how likely it is that future items
    # can exactly fill it (r itself, or useful combinations).  We use the
    # probability mass at residue classes of r via divisors.
    reuse = np.zeros(101, dtype=np.float64)
    # direct match weight
    reuse += 3.0 * p
    # two-item combination weight (convolution, estimated cheaply)
    for r in range(1, 101):
        pass
    # cheap convolution of p with itself for pairs summing to r
    # build via cumulative: corr[r] = sum_k p[k]*p[r-k]
    pp = np.convolve(p, p)[:101]
    reuse += 0.5 * pp
    # three-item combination, downweighted
    ppp = np.convolve(pp, p)[:101]
    reuse += 0.15 * ppp

    use = reuse[residual.astype(np.int64)]

    # Bonus bounded well below the best-fit gap (1000), so best-fit stays dominant.
    score = score + 20.0 * use

    # Exact fill is always best; give it a large but finite kick.
    score[residual == 0] += 500000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
