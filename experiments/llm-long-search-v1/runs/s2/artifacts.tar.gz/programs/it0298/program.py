# EVOLVE-BLOCK-START
"""Log-penalty best fit with a direct common-item-size reuse bonus and exact-match bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_maxfreq = 1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _maxfreq
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    rf = residual.astype(np.float64)

    # log penalty preserves best-fit dominance (monotone decreasing in residual)
    tight = -np.log1p(rf)
    score = 4.0 * tight

    # reward residuals that are themselves common item sizes (likely future exact fill),
    # scaled strictly below the best-fit integer gap so tightness stays dominant.
    use = freq[r] / _maxfreq
    score = score + 0.4 * use

    # bounded exact-residual-match bonus: rewards a leftover that a common item size fills.
    score = score + 0.2 * use

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item
    if _counts[item] > _maxfreq:
        _maxfreq = _counts[item]

    return score
# EVOLVE-BLOCK-END
