# EVOLVE-BLOCK-START
"""Best fit, with a small-item nudge to keep residual gaps reusable.

For each arriving item we rank bins by the residual they would leave
(smaller residual = better fit).  Pure best-fit is hard to beat, but it tends
to bury the distribution's small-item tail inside fresh bins, wasting gaps that
future small items could have filled.  So for items that are small compared to
the running mean of seen items, we additionally reward bins whose residual
after placement is comfortably large (still reusable by a typical small item),
blending this in lightly so the tight-fit preference is preserved elsewhere.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    residual = bins - item

    # Tight-fit score: prefer the smallest residual.
    score = -residual.astype(np.float64)

    # Running mean item size (kept as function attribute).
    n = getattr(priority, "n", 0) + 1
    mean = getattr(priority, "mean", 0.0)
    mean = mean + (item - mean) / n
    priority.n = n
    priority.mean = mean

    # Only for genuinely small items do we nudge the choice.
    if item < 0.5 * mean:
        # Reward residuals that are still reusable by a small item, but do not
        # let this dominate the tight-fit preference.
        reusable = np.minimum(residual, 0.5 * mean) / max(0.5 * mean, 1.0)
        score = score + 0.25 * reusable

    return score
# EVOLVE-BLOCK-END
