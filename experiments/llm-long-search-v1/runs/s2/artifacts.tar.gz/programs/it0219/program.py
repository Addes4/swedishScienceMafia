# EVOLVE-BLOCK-START
"""Best fit with a strictly tie-breaking reuse potential from the running item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    # Best-fit dominates: smaller residual is always strictly better.
    tight = -residual.astype(np.float64)

    # Tie-break only: among equal minimal residuals, prefer the bin whose leftover
    # space is likely to be exactly reused by an upcoming item (histogram mass at r).
    freq = _counts
    r = residual.astype(np.int64)
    score = tight

    # bounded tie-break: < 0.5 so it never crosses an integer best-fit gap
    mass = np.where(r <= 100, freq[np.clip(r, 0, 100)], 0.0)
    score = score + 0.45 * (mass / (_n + 1.0))

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END

