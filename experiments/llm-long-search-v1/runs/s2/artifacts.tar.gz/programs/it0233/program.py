# EVOLVE-BLOCK-START
"""Best fit with a dominant exact-fit preference, plus a small tie-break that
rewards leaving gaps reachable by short sums of recent item sizes."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
# precomputed kernel for smoothing the histogram over item sizes
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)
_half = len(_kernel) // 2


def _smooth(freq):
    smoothed = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_kernel):
        off = k - _half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    return smoothed


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    # --- dominant primary key: strict best fit (smallest residual) ---
    score = -residual.astype(np.float64) * 1000.0

    # --- tie-break: prefer gaps that are reachable as short sums of recent sizes ---
    if _n > 0.0:
        freq = _counts
        smoothed = _smooth(freq)
        tot = smoothed.sum()
        if tot > 0.0:
            p = smoothed / tot
            # reachability over residual values via up to 3 recent-size steps
            reach = p.copy()
            reach = reach + np.convolve(reach, p)[:101]
            reach = reach + np.convolve(reach, p)[:101]
            # tie-break bonus magnitude < 1 so best-fit stays strictly dominant
            score = score + 0.5 * reach[r]

    # exact fit should always win its residual class
    score = score + (r == 0).astype(np.float64) * 0.2

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
