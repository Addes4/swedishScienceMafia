# EVOLVE-BLOCK-START
"""Best fit with a lightly-weighted smoothed-histogram tie-break.

Primary rule: best fit (smallest residual).  Tie-break: slightly prefer residuals
that match a common future item size, using a smoothed empirical histogram of the
items seen so far.
"""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
# smoothing kernel over residual sizes (offsets -2..+2)
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)
_half = len(_kernel) // 2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    # smoothed histogram of past item sizes
    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_kernel):
        off = k - _half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    use = smoothed[r]

    score = -residual.astype(np.float64) + 0.10 * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
