# EVOLVE-BLOCK-START
"""Best fit with a normalized smoothed residual-usefulness tie-break from the empirical item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
# small smoothing kernel over residual sizes: an item of size ~r can fill a bin of residual r or slightly larger
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)

    # build smoothed counts via shifting the histogram
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    # normalize to a probability-like quantity so the bonus stays bounded over the whole run
    denom = _n if _n > 0.0 else 1.0
    smoothed /= denom

    use = smoothed[r]

    # tightness dominates; usefulness nudges among similar residuals
    tight = -residual.astype(np.float64)
    score = tight + 0.5 * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
