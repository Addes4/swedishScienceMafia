# EVOLVE-BLOCK-START
"""Best fit with a subordinate dead-space / reuse tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_min_seen = 101.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _min_seen
    residual = bins - item  # >= 0 for all bins shown
    res_f = residual.astype(np.float64)

    # Primary: best fit (smallest residual first). Magnitude >> secondary terms.
    score = -res_f

    # Secondary: prefer residuals that are effectively dead space (too small for
    # any item seen so far), so waste is consolidated instead of creating small
    # reusable-but-fragmenting gaps. Keep well below 1.0 so best-fit ordering holds.
    if _n > 0.0:
        dead = res_f < _min_seen
        score = score + 0.3 * dead.astype(np.float64)

    # Exact fill always wins outright.
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item
    if item < _min_seen:
        _min_seen = item

    return score
# EVOLVE-BLOCK-END
