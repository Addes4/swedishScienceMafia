# EVOLVE-BLOCK-START
"""Best fit with a bounded tie-break bonus centered on the online-estimated typical item size."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    residual_f = residual.astype(np.float64)

    # Strict best-fit primary term: smaller residual is always better.
    score = -residual_f

    if _n > 0.0:
        mean_item = _sum / _n
        # Bounded bonus (< 1.0) favoring residuals near the typical item size,
        # so a gap likely to be exactly refilled is slightly preferred.
        sigma = 0.25 * mean_item + 1.0
        bonus = 0.5 * np.exp(-((residual_f - mean_item) ** 2) / (2.0 * sigma * sigma))
        score = score + bonus

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
