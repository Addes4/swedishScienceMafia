# EVOLVE-BLOCK-START
"""Best fit with a mild preference for already-fuller bins."""
import numpy as np


def priority(item, bins):
    """Rank bins: tightest fit first, with a small bonus for fuller bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item               # leftover space after placing; smaller is better
    fill = (100 - bins).astype(np.float64)  # how full the bin already was
    return -residual.astype(np.float64) + 0.3 * fill / 100.0
# EVOLVE-BLOCK-END
