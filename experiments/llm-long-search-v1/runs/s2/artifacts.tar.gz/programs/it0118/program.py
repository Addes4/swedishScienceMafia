# EVOLVE-BLOCK-START
"""Best fit (dominant) with a one-step exact-fill lookahead tie-break from the running histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    total = _n if _n > 0.0 else 1.0

    # probability that a future item exactly fills this residual (residual 0 -> already full/closed)
    r = residual.astype(np.int64)
    prob_exact = freq[r] / total

    # best-fit dominates: strongly prefer small residual
    tight = -residual.astype(np.float64)
    score = tight + 3.0 * prob_exact

    # residuals equal to 0 are effectively closed with no waste
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
