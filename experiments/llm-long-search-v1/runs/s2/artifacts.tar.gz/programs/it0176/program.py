# EVOLVE-BLOCK-START
"""Best fit with a strictly-tie-breaking residual affordance bonus (pure best-fit core)."""
import numpy as np

# fixed prior on future item sizes (Weibull-shaped, mean ~40); prefer gaps that a
# typical future item can approximately fill, breaking exact-best-fit ties.
_r = np.arange(101, dtype=np.float64)
_PRIOR = (_r / 40.0) * np.exp(-_r / 40.0)  # rough shape, peaks near a typical item size


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # best-fit core strictly dominates: residual ordering is decisive (scaled by 100).
    score = -100.0 * res
    # tie-break (< 1.0 magnitude relative to the 100-unit core step): prefer residuals
    # that a typical future item could partially fill, i.e. small-but-nonzero affordance.
    score += _PRIOR[residual.astype(np.int64)]
    # exact fit is always best.
    score[residual == 0] += 1e6
    return score
# EVOLVE-BLOCK-END
