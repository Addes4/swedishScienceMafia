# EVOLVE-BLOCK-START
"""Best fit refined by an online estimate of the 'natural' residual left by placements.

Pure best fit tends to create tiny slivers that can never be filled again.  We keep
a running average of the residuals we actually leave behind (only counting non-zero
residuals) and, as a tie-break on top of best fit, reward bins whose post-placement
residual is near that empirical target -- i.e. bins that end up in a "normal" state
rather than a degenerate sliver.
"""
import numpy as np

_res_sum = 0.0      # sum of non-zero residuals left behind
_res_cnt = 0.0      # count of such placements
_alpha = 0.0        # weight of the residual-target tie-break


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _res_sum, _res_cnt, _alpha

    residual = bins - item  # >= 0 for all bins shown

    # empirical target residual (mean of past non-zero residuals), default ~ mean item size
    target = (_res_sum / _res_cnt) if _res_cnt > 0 else 40.0

    # best fit: strongest signal is the tightest (smallest) residual
    tight = -residual.astype(np.float64)

    # tie-break: closeness of the resulting residual to the empirical target.
    # Only matters for near-ties thanks to the small weight.
    closeness = -np.abs(residual.astype(np.float64) - target)

    score = tight + _alpha * closeness
    score[residual == 0] += 1000.0   # closing a bin perfectly is always best

    # update the running residual estimate with this placement's outcome.
    # (We don't know the chosen bin here, so track the histogram of residuals
    #  weighted by how likely such a placement is: use the smallest residual
    #  the item achieves, which is what best fit will pick.)
    best_res = residual.min()
    if best_res > 0:
        _res_sum += float(best_res)
        _res_cnt += 1.0

    # let the tie-break gain modest influence once the estimate stabilises
    _alpha = min(0.6, 0.02 * _res_cnt)

    return score
# EVOLVE-BLOCK-END

