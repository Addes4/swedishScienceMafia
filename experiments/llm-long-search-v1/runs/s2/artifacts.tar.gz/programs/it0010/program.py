# EVOLVE-BLOCK-START
"""Best fit with a fill-fraction bonus to consolidate small items into open bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Tightest fit is the primary driver.
    base = -(bins - item)
    # Fill fraction of each bin (unused buses have fill 0).
    fill = (100 - bins).astype(np.float64)
    # Small bonus for placing into already-open bins; scales with how full they are.
    # Using item/100 keeps the bonus modest relative to the integer fit gap.
    bonus = fill * (item / 100.0) * 0.01
    return base + bonus
# EVOLVE-BLOCK-END
