# EVOLVE-BLOCK-START
"""Worst-fit (emptiest-bin) placement with exact-fill override."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    # Primary objective: worst-fit -> prefer the bin with the largest remaining capacity,
    # so loads stay balanced.  Exact fills get a huge bonus.
    score = residual.astype(np.float64)

    score[residual == 0] += 1000.0

    return score
# EVOLVE-BLOCK-END
