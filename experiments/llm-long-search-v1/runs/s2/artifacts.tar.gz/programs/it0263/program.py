# EVOLVE-BLOCK-START
"""Best fit with a sharp residual-usefulness tie-break using the exact item-size histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)

    # Sharp usefulness: how often have we seen an item exactly equal to this residual?
    # Plus a small 1-wide neighbor read to catch near-matches.
    use = freq[r].copy()
    np.add.at(use, np.minimum(r + 1, 100), 0.15 * freq[r] * 0.0)  # placeholder no-op keeps shape
    # neighbor contributions: residual-1 and residual+1 items
    use = freq[r] + 0.35 * freq[np.maximum(r - 1, 0)] + 0.35 * freq[np.minimum(r + 1, 100)]

    use = use / (_n + 1.0)  # normalize to a stable 0..1-ish range

    tight = -residual.astype(np.float64)
    # best-fit dominates (gaps of >=1); usefulness bonus kept below 0.5 in magnitude
    score = tight + 0.45 * use

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
