# EVOLVE-BLOCK-START
"""Best fit with a tiny recency-based residual tie-break."""
import numpy as np

_last = -1.0
_prev = -1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _last, _prev
    residual = bins - item  # >= 0 for all bins shown

    # Strictly dominant best-fit term: smaller residual -> larger score.
    # Multiplied by a large constant so residual differences (>=1) always dominate ties.
    score = -1000.0 * residual.astype(np.float64)

    # Tiny tie-break (always < 500): among equal best-fit residuals, mildly prefer
    # gaps that would exactly fit a plausible next item, estimated by recency.
    if _last >= 1.0:
        target = _last
        if _prev >= 1.0:
            target = 0.5 * (_last + _prev)
        d = np.abs(residual.astype(np.float64) - target)
        score = score - 0.01 * d
    else:
        score = score - 0.001 * residual.astype(np.float64)

    score[residual == 0] += 1e9

    _prev = _last
    _last = float(item)

    return score
# EVOLVE-BLOCK-END
