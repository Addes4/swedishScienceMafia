# EVOLVE-BLOCK-START
"""Best fit with a smoothed 'future usability' tie-break from the empirical item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _n
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    total = _n if _n > 0.0 else 1.0
    # probability that a future item has size <= residual (usability of leftover capacity),
    # computed via cumulative sums of the empirical item histogram
    cdf = np.cumsum(freq) / total  # cdf[r] = P(item <= r)
    use = cdf[residual]

    # tightness term: prefer smallest residual (best fit)
    tight = -residual.astype(np.float64)

    # combine: tightness dominates, usability breaks near-ties
    score = tight + 0.5 * use
    score[residual == 0] += 1000.0

    # update histogram with current item
    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
