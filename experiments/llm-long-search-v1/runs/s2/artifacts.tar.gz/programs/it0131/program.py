# EVOLVE-BLOCK-START
"""Best fit with a strictly-tie-breaking empirical reuse bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)

    # Empirical probability that a future item exactly equals this residual,
    # so the bin can be perfectly closed. Smoothed with neighbors.
    smoothed = np.zeros(101, dtype=np.float64)
    smoothed[1:] += freq[1:]
    smoothed[:-1] += freq[1:]
    smoothed[1:] += freq[:-1]
    smoothed[:-1] += freq[:-1]
    denom = max(_n, 1.0)
    reuse = smoothed[r] / denom  # in [0, ~2], typically small

    # Best-fit is strictly dominant: unit gaps in residual overwhelm tie-break.
    tight = -residual.astype(np.float64)

    # Tie-break only matters among equal best-fit residuals (residual differs by >=1
    # means score gap >=1, but reuse <= 2 so we scale it safely below 1).
    score = tight + 0.5 * reuse

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
