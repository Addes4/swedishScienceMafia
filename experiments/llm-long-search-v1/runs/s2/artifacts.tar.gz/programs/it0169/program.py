# EVOLVE-BLOCK-START
"""Best fit with a bounded smoothed-residual reusability bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.10, 0.20, 0.40, 0.20, 0.10], dtype=np.float64)  # offsets -2..+2

# Precompute the smoothed-histogram scatter for each bin-residual value lazily.
_smoothed = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties go first."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    smoothed = _smoothed
    smoothed[:] = 0.0
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    r = residual.astype(np.int64)
    use = smoothed[r]

    tight = -residual.astype(np.float64)
    # bounded reusability bonus, magnitude < 1 so best-fit residual ordering dominates
    score = tight + 0.4 * use

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
