# EVOLVE-BLOCK-START
"""Best fit with a strictly-tie-breaking smoothed residual-usefulness and reuse bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    tight = -residual.astype(np.float64)
    # usefulness bonus kept below 1.0 in magnitude so best-fit (gaps of >=1) stays dominant
    score = tight + 0.4 * use

    if _n > 0.0:
        # mode of observed item sizes (smoothed) is a better predictor of the next
        # item than the mean, so exact-residual ties favor fillable gaps.
        mode = float(np.argmax(smoothed[1:]) + 1)
        reuse = 0.25 * np.exp(-((residual.astype(np.float64) - mode) ** 2) /
                              (2.0 * (0.25 * mode + 1.0) ** 2))
        score = score + reuse

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END

