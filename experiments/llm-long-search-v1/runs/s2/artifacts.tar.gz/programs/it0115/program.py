# EVOLVE-BLOCK-START
"""Best-fit dominant rule with a sharp exact-fill lookahead bonus over the running item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0

# sharp smoothing kernel over residual sizes (offsets -1..+1), weight concentrated at +0
_k1 = np.array([0.20, 0.60, 0.20], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _n

    residual = bins - item  # >= 0 for every bin shown
    rf = residual.astype(np.float64)
    ri = residual.astype(np.int64)

    # best-fit: strongly prefer the smallest resulting residual
    score = -3.0 * rf

    # smoothed probability that a future item can (near-)exactly fill this residual
    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_k1) // 2
    for k, w in enumerate(_k1):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    score += 0.5 * smoothed[ri]

    # extra sharp bonus: residual is exactly a frequently-seen item size -> closable cleanly later
    score += 0.4 * freq[ri]

    # closed bins get priority to prevent tiny accidental waste
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END

