# EVOLVE-BLOCK-START
"""Lexicographic best-fit: tightest residual first, histogram usefulness only breaks ties."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    # smoothed usefulness histogram: probability a future item roughly fills this residual
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    r = residual.astype(np.int64)
    use = smoothed[r]

    min_res = residual.min()
    # Primary: tightest residual (best fit). Tie-break: higher expected usefulness.
    score = use.copy()
    score[residual != min_res] -= 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
