# EVOLVE-BLOCK-START
"""Hybrid: best-fit with a residual-target that avoids mid-size slivers."""
import numpy as np

_state = {"res": None, "n": 0, "mean_item": 40.0}


def priority(item, bins):
    """Best-fit, but mildly prefer residuals near a useful target."""
    res = bins - item  # resulting free capacity if item placed here

    # Use a fixed-ish target: aim to leave a residual that is either 0 (packed)
    # or at least roughly the mean item size, else the tightest fit wins.
    # Score = closeness to ideal residual; smaller residual >= 0 is good,
    # but residual in (0, small) is treated as slightly worse than 0.
    score = -res.astype(np.float64)

    # Penalize tiny-but-nonzero residuals (slivers that block future fits)
    tiny = (res > 0) & (res < 20)
    score[tiny] -= 0.5

    return score
# EVOLVE-BLOCK-END
