# EVOLVE-BLOCK-START
"""Best fit, with a small-gap exact-fill preference from a smoothed running histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.10, 0.20, 0.40, 0.20, 0.10], dtype=np.float64)
_alpha = 0.02  # smoothing toward uniform prior


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    total = freq.sum()
    # smoothed density over residuals 0..100
    smoothed = _alpha * np.ones(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    if total > 0.0:
        smoothed /= (smoothed.sum() / 101.0)  # keep scale near 1 for stability

    r = residual.astype(np.int64)
    # probability-density-like weight of filling this exact residual later
    fill = smoothed[r]

    # Best-fit dominance via large negative residual term.
    score = -residual.astype(np.float64) * 1000.0
    # Within equal residual, prefer gaps that are likely exact-fill targets.
    score = score + fill

    score[residual == 0] += 1e9

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
