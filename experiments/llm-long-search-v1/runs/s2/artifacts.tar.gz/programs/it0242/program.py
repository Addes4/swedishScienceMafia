# EVOLVE-BLOCK-START
"""Pure best fit, with strict tie-breaking by fullest bin (smallest prior capacity)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    # Dominant key: smallest resulting residual (best fit).
    score = -residual.astype(np.float64)

    # Explicit exact-fit boost (redundant with above but harmless and clear).
    score[residual == 0] += 1000.0

    return score
# EVOLVE-BLOCK-END
