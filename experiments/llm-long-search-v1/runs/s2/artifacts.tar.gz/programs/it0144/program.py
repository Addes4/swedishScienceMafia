# EVOLVE-BLOCK-START
"""Best fit, decisive tie-break on smoothed histogram match, no noisy mean term."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)

_smoothed = None
_dirty = True


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _dirty, _smoothed

    residual = bins - item
    r = residual.astype(np.int64)

    freq = _counts
    if _dirty:
        smoothed = np.zeros(101, dtype=np.float64)
        half = len(_kernel) // 2
        for k, w in enumerate(_kernel):
            off = k - half
            lo = max(0, -off)
            hi = min(101, 101 - off)
            smoothed[lo + off:hi + off] += w * freq[lo:hi]
        _smoothed = smoothed
        _dirty = False
    smoothed = _smoothed

    use = smoothed[r]

    # best-fit strictly dominant; ties broken by smoothed probability the residual is a real size
    score = -residual.astype(np.float64) * 1000.0 + use

    score[residual == 0] += 1e9

    _counts[item] += 1.0
    _n += 1.0
    _dirty = True

    return score
# EVOLVE-BLOCK-END
