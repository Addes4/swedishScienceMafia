# EVOLVE-BLOCK-START
"""Log-penalty best fit with learned complement-pairing bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
# smoothed item-size frequency kernel (offsets -2..+2)
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)

# learned map: for each prior item size bucket, frequency of resulting residual buckets.
_pair = np.zeros((101, 101), dtype=np.float64)
_cur_item = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _cur_item
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    # smoothed prior item-size frequency
    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    # complement pairing: how often this item-size bucket has been paired with
    # a bin leaving this exact residual, normalized per item size.
    if _n > 0.0:
        row = _pair[min(item, 100)]
        rowsum = row.sum()
        if rowsum > 0.0:
            pair = row[r] / rowsum
        else:
            pair = np.zeros_like(use)
    else:
        pair = np.zeros_like(use)

    # log penalty preserves best-fit dominance (monotone decreasing in residual)
    tight = -np.log1p(residual.astype(np.float64))
    score = 4.0 * tight + 0.4 * use + 1.5 * pair

    if _n > 0.0:
        mean_item = _sum / _n
        reuse = 0.25 * np.exp(-((residual.astype(np.float64) - mean_item) ** 2) /
                              (2.0 * (0.25 * mean_item + 1.0) ** 2))
        score = score + reuse

    score[residual == 0] += 1000.0

    # update learned tables
    _counts[item] += 1.0
    _pair[min(_cur_item, 100)][r] += 1.0  # last placement's item vs current residuals is not
    # aligned; instead record (current item size, resulting residuals) is done at next call.
    # Simpler: accumulate (item, chosen residual) is not directly available, so use
    # item size vs each bin's residual as an estimate.
    _n += 1.0
    _sum += item
    _cur_item = item

    return score
# EVOLVE-BLOCK-END

