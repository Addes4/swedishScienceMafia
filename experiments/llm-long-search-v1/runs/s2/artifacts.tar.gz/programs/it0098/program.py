# EVOLVE-BLOCK-START
"""Best fit dominant, with a histogram-derived expected-waste tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    residual_f = residual.astype(np.float64)

    # Empirical distribution over item sizes, lightly smoothed so it reflects likely future items.
    freq = _counts
    base = freq.copy()
    if _n > 0.0:
        # smooth once with a small kernel to avoid zero-probability artifacts
        kern = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)
        sm = np.zeros(101, dtype=np.float64)
        half = len(kern) // 2
        for k, w in enumerate(kern):
            off = k - half
            lo = max(0, -off)
            hi = min(101, 101 - off)
            sm[lo + off:hi + off] += w * freq[lo:hi]
        sm /= sm.sum()
        base = sm
    else:
        base = np.full(101, 1.0 / 101.0)

    # expected waste left when we hold a residual r and the next item is drawn from `base`:
    # if item <= r it can be placed and leaves r-item; if item > r the bin is left with r (waste).
    # We approximate the value of a residual as the fraction of it that can eventually be filled,
    # favoring residuals large enough to host typical items but not so large as to be wasteful.
    r = residual.astype(np.int64)
    # probability that a typical item fits into residual r
    fit = np.array([float(base[:max(0, min(101, ri)) ].sum()) if ri > 0 else 0.0
                    for ri in r])
    # reward residuals that are numerically typical item sizes (good complements), bounded small
    complement = base[np.clip(r, 0, 100)]
    score = -residual_f + 0.5 * fit + 0.5 * complement

    if _n > 0.0:
        mean_item = _sum / _n
        reuse = 0.4 * np.exp(-((residual_f - mean_item) ** 2) /
                             (2.0 * (0.25 * mean_item + 1.0) ** 2))
        score = score + reuse

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
