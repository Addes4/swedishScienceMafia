# EVOLVE-BLOCK-START
"""Best fit: place the item in the fullest bin it still fits in."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    # Dominant term: strict best fit -> smallest resulting residual.
    # Tie-break: prefer the bin that was already fullest (smallest prior capacity).
    prior = bins.astype(np.float64)
    score = -residual.astype(np.float64) * 1000.0 - prior

    # Exact-fit safety: never miss a perfect placement.
    score[residual == 0] += 1e9

    return score
# EVOLVE-BLOCK-END
