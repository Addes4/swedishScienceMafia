# EVOLVE-BLOCK-START
"""Best fit primary, with a converging empirical-histogram tie-break on residuals."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
# smoothing kernel over residual sizes: an item of size ~r can fill a bin of residual r or slightly larger
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # Build smoothed empirical histogram of item sizes once per call.
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * _counts[lo:hi]

    r = residual.astype(np.int64)
    # Usefulness: probability a future item can roughly fill this residual.
    use = smoothed[r]

    # Converging weight: sharper as more items are observed.
    w_use = 0.5 * (1.0 - (1.0 / (1.0 + _n)))

    # Primary term: best fit (smallest residual). Secondary: fill usefulness.
    score = -residual.astype(np.float64) + w_use * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
