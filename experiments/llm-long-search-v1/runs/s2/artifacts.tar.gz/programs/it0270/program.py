# EVOLVE-BLOCK-START
"""Best fit with a strictly-tie-breaking residual-usefulness bonus (sharp histogram read)."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    r = residual.astype(np.int64)
    # sharp read: how often has exactly this residual been available as a leftover?
    use = _counts[r]

    # strictly best-fit dominant: smaller residual always wins (gaps of >=1)
    tight = -residual.astype(np.float64)
    # tie-break among equal residuals: prefer residual that has historically been refillable
    score = tight + 0.4 * use

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
