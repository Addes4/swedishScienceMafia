# EVOLVE-BLOCK-START
"""Best fit with a sharp, bounded exact-fill tie-break from the running item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # Primary key: best fit = smallest residual.  Multiply by 4 so that any
    # integer gap (>=1) dominates the bounded tie-break below (<1).
    score = -4.0 * residual.astype(np.float64)

    # Tie-break: within equal residual, prefer residuals that are likely to be
    # exactly filled by a future item.  Use the running histogram counts.
    freq = _counts
    r = residual.astype(np.int64)
    # bonus in [0,1): probability mass (unnormalized, squashed) at that residual
    bonus = freq[r] / (freq[r] + 8.0)
    score = score + bonus

    # Empty bin (residual 0) can still take the item; strongly prefer it so the
    # harness closes a bin as soon as it is exactly full.
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
