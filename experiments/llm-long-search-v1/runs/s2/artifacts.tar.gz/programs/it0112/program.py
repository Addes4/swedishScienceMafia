# EVOLVE-BLOCK-START
"""Best fit with a Gaussian-smoothed residual-usefulness tie-break plus a reusable-size bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0

# Gaussian kernel over residual offsets -6..+6, precomputed once.
_offs = np.arange(-6, 7)
_sigma = 2.0
_gk = np.exp(-(_offs ** 2) / (2.0 * _sigma ** 2))
_gk /= _gk.sum()
_half = len(_offs) // 2


def _build_smoothed(freq):
    """Convolve the histogram with the Gaussian kernel (edge-clamped)."""
    sm = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_gk):
        off = k - _half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        sm[lo + off:hi + off] += w * freq[lo:hi]
    return sm


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item          # >= 0 for all bins shown
    r = residual.astype(np.int64)
    rf = residual.astype(np.float64)

    smoothed = _build_smoothed(_counts)
    use = smoothed[r]

    # best-fit backbone: prefer smallest residual
    score = -rf + 0.5 * use

    # small bounded bonus for residuals near the running mean item size (reusable sweet spot)
    if _n > 0.0:
        mean_item = _sum / _n
        sd = 0.25 * mean_item + 1.0
        score = score + 0.4 * np.exp(-((rf - mean_item) ** 2) / (2.0 * sd * sd))

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
