# EVOLVE-BLOCK-START
"""Best fit with a strictly-tie-breaking residual-likelihood bonus from a smoothed running histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_kernel = np.array([0.08, 0.17, 0.5, 0.17, 0.08], dtype=np.float64)


def _smoothed():
    freq = _counts
    sm = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        sm[lo + off:hi + off] += w * freq[lo:hi]
    return sm


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    # Strict best-fit dominates; the histogram term only breaks equal-residual ties.
    score = -residual.astype(np.float64) * 1000.0

    if _n >= 20.0:
        sm = _smoothed()
        total = sm.sum()
        if total > 0.0:
            p = sm / total
            # favor resulting gaps that look like a typical future item size
            score = score + p[r]

    score[residual == 0] += 1e9

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
