# EVOLVE-BLOCK-START
"""Best fit, with exact-residual ties broken toward the largest remaining gap (worst-fit)."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = (bins - item).astype(np.float64)  # >= 0 for all bins shown

    # Dominant term: best fit (smallest residual), gaps of >=1 always outweigh the tie-break below.
    score = -residual

    # Among bins with the same residual, prefer the one whose other capacity usage is lower,
    # i.e. break ties using the bin's total free space before placement (worst-fit style).
    # This remains strictly below 1.0 in magnitude so best-fit dominance is preserved.
    use = _counts[(bins).astype(np.int64)]
    score = score + 0.4 * (use / (1.0 + use))

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
