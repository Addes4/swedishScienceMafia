# EVOLVE-BLOCK-START
"""Best fit with a scale-free residual-usefulness tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # frequency of each residual size among past items (residual 0 is always "useful": bin closed)
    use = _counts[residual]

    # scale-free tightness: prefer smallest residual relative to current item size
    tight = -residual.astype(np.float64) / max(item, 1)

    # combine: tightness dominates, histogram usefulness only breaks near-ties
    score = tight + 0.05 * use
    score[residual == 0] += 1000.0

    # update histogram with current item
    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
