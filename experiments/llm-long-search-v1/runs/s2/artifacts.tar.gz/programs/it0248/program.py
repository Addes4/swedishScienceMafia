# EVOLVE-BLOCK-START
"""Best fit with a bounded deterministic harmonic secondary term."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
# fixed small set of "typical" item sizes used as a deterministic secondary criterion
_targets = np.array([10.0, 20.0, 30.0, 40.0, 50.0, 60.0], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    rf = residual.astype(np.float64)

    # numerically-safe smoothed frequency estimate (only for a soft packability hint)
    freq = _counts
    if _n > 0.0:
        freq = freq / _n  # normalized so use is in [0, 1]

    # deterministic "harmonic" packability: how well residual can absorb a typical target
    # maximize sum over targets of (1 - leftover/target) ; larger = residual is a good fit
    best = np.zeros_like(rf)
    for t in _targets:
        leftover = np.abs(rf - t * np.round(rf / t))
        best = np.maximum(best, 1.0 - leftover / t)

    # soft weighting by how common a matching item size is (bounded, small)
    idx = np.clip(rf.astype(np.int64), 0, 100)
    common = 0.5 + 0.5 * freq[idx]

    # best-fit is strictly dominant due to the large multiplier on -residual
    tight = -rf
    score = 1000.0 * tight + (best * common) * 0.5

    if _n > 0.0:
        mean_item = _sum / _n
        reuse = 0.25 * np.exp(-((rf - mean_item) ** 2) /
                              (2.0 * (0.25 * mean_item + 1.0) ** 2))
        score = score + reuse

    score[residual == 0] += 1e9

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
