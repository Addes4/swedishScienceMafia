# EVOLVE-BLOCK-START
"""Best fit with a bounded, histogram-driven tie-break toward exactly-fillable residuals."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_smoothed = np.zeros(101, dtype=np.float64)
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _smoothed
    residual = bins - item  # >= 0 for all bins shown

    # Rebuild the smoothed running histogram of item sizes (small 101-length array).
    freq = _counts
    smoothed = _smoothed
    smoothed[:] = 0.0
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    r = residual.astype(np.int64)
    exact_mass = smoothed[r]  # likelihood the gap will be exactly filled next

    # Secondary: reward gaps that are reachable by adding a common small item,
    # i.e. residual r is likely after placing a likely next item into some bin.
    secondary = np.zeros(r.shape[0], dtype=np.float64)
    # Use the most-likely item sizes (top few histogram bins) — cheap and stable.
    if _n > 0.0:
        top_sizes = np.argpartition(smoothed, -6)[-6:]
        for s in top_sizes:
            if s <= 0:
                continue
            target = r - s
            mask = target >= 0
            secondary[mask] += smoothed[np.clip(target[mask], 0, 100)]

    # Best-fit is the strict primary key: gaps >= 1 dominate any tie-break.
    best_fit = -residual.astype(np.float64) * 10.0
    # Tie-break kept well below 1.0 in magnitude so it only resolves equal residuals.
    tie_break = 0.3 * exact_mass + 0.05 * secondary

    score = best_fit + tie_break
    score[residual == 0] += 1e6  # exact fit always wins

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
