# EVOLVE-BLOCK-START
"""Best-fit with a subordinate tie-break favoring residuals equal to a frequent item size."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n

    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    # normalized frequency of each residual size (smoothed lightly to avoid sparse noise)
    if _n > 0.0:
        freq = _counts / _n
    else:
        freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    smoothed[1:100] = 0.25 * freq[0:99] + 0.5 * freq[1:100] + 0.25 * freq[2:101]

    use = smoothed[r]

    tight = -residual.astype(np.float64)
    # best-fit dominates; the frequency tie-break is bounded well under 1.0 gap
    score = tight + 0.45 * use

    if _n > 0.0:
        mean_item = float(np.dot(np.arange(101), _counts)) / _n
        reuse = 0.25 * np.exp(-((residual.astype(np.float64) - mean_item) ** 2) /
                              (2.0 * (0.25 * mean_item + 1.0) ** 2))
        score = score + reuse

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
