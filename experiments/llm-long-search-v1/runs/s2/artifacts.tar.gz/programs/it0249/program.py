# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus and a mild mean-residual reuse bias."""
import numpy as np

_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    rf = residual.astype(np.float64)

    # Best-fit is strictly dominant: larger residual => lower score by far.
    score = -rf

    # Among near-best fills, mildly favor residuals close to the running mean item size,
    # a cheap proxy for leaving a "packable" gap.
    if _n > 0.0:
        mean_item = _sum / _n
        reuse = 0.25 * np.exp(-((rf - mean_item) ** 2) /
                              (2.0 * (0.25 * mean_item + 1.0) ** 2))
        score = score + reuse

    # Strictly dominate everything with a perfect fill.
    score[residual == 0] += 1000.0

    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
