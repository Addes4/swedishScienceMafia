# EVOLVE-BLOCK-START
"""Best fit with a small near-tie window favoring the most reusable residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown

    # Primary: best fit -> prefer smallest post-placement residual.
    # Near-ties (residual within a small window of the min) are broken by
    # preferring the bin that still leaves a usable (small) residual,
    # which tends to pack bins more tightly than pure best-fit.
    r = residual.astype(np.float64)
    rmin = r.min()
    window = 3.0

    tight = -r
    # small bonus for residuals close to (but not exceeding) the window edge,
    # keeping bins "just filled" rather than leaving large holes
    near = np.where(r <= rmin + window,
                    (r - rmin) / (window + 1.0),  # prefer larger usable residual in window
                    0.0)

    score = tight + 0.25 * near
    score[residual == 0] += 1000.0  # always close a bin exactly filled

    return score
# EVOLVE-BLOCK-END
