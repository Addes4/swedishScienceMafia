# EVOLVE-BLOCK-START
"""Pure best-fit: highest score for the smallest non-negative residual, exact fill wins."""
import numpy as np


def priority(item, bins):
    """Best-fit: prefer the bin leaving the smallest feasible residual (exact fill best)."""
    residual = bins - item  # >= 0
    score = -residual.astype(np.float64)
    score[residual == 0] += 1000.0
    return score
# EVOLVE-BLOCK-END
