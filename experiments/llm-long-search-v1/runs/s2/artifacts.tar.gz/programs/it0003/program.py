# EVOLVE-BLOCK-START
"""Best fit with a small fill-based tie-breaker to consolidate residual space."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tighter fit (smaller residual). Secondary: prefer placing into bins
    # that are already more filled (smaller current remaining capacity), which
    # consolidates leftover space and slightly reduces the number of bins.
    return -residual * 1000.0 - bins
# EVOLVE-BLOCK-END
