# EVOLVE-BLOCK-START
"""Best fit with a mild penalty for creating tiny unfillable slivers."""
import numpy as np

THRESH = 20


def priority(item, bins):
    residual = bins - item
    # base: prefer tightest fit (smallest residual)
    score = -residual.astype(np.float64)
    # demote residuals that are nonzero but smaller than THRESH (awkward slivers)
    sliver = (residual > 0) & (residual < THRESH)
    score -= 100.0 * sliver
    return score
# EVOLVE-BLOCK-END
