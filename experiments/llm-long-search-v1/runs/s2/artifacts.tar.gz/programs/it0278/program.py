# EVOLVE-BLOCK-START
"""Best fit with a bounded, low-noise complement-frequency tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    # Strict best-fit dominance: -residual has integer gaps of >= 1.
    score = -residual.astype(np.float64)

    if _n > 0.0:
        # Secondary signal in [0, 1): how often the exact resulting residual size shows up
        # as an incoming item (i.e. how likely this leftover is to be filled later).
        r = residual.astype(np.int64)
        smoothed = np.zeros(101, dtype=np.float64)
        smoothed[1:] = _counts[1:]
        smoothed[0] = _counts[1]  # treat 0 like a fillable small gap
        smoothed /= (_n + 1.0)
        score += 0.9 * smoothed[r]

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
