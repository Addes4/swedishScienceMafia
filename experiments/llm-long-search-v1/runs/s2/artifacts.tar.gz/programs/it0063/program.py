# EVOLVE-BLOCK-START
"""Best fit with a residual-closeability tie-break learned from the empirical item histogram.

The idea: among bins the item fits in, prefer the tightest residual (best fit). To break
near-ties and avoid stranding awkward residuals, add a small penalty g(residual) that is
large when the residual is unlikely to be exactly closed by future items, estimated from
the empirical histogram of observed items.
"""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0

# cache: closeability cost per residual 0..100, refreshed occasionally
_cost = np.zeros(101, dtype=np.float64)
_last_n = -1.0
_min_size = 1


def _refresh_cost():
    """Estimate cost[r] = expected waste when a bin is left with residual r."""
    global _cost, _last_n, _min_size
    freq = _counts
    total = freq.sum()
    if total <= 0:
        _cost[:] = 0.0
        _last_n = 0.0
        return
    p = freq / total  # probability of each item size 1..100
    # find smallest size with meaningful probability
    sizes = np.nonzero(freq > 0)[0]
    _min_size = int(sizes.min()) if sizes.size else 1

    # f[r] = expected tail waste starting from residual r, using a greedy "fill with the
    # largest common size that fits" estimate, plus penalty for residuals below min size.
    # Approximate via DP: f[0]=0; f[r] = E_waste for r>0.
    # A residual r can be closed exactly if it is representable; here we approximate the
    # probability-to-close with a coin-change reachability relaxation weighted by p.
    cost = np.zeros(101, dtype=np.float64)
    reach = np.zeros(101, dtype=np.float64)  # relative "closeability" score
    reach[0] = 1.0
    # iterate a few relaxation steps (knapsack-style) to spread closeability
    for _ in range(3):
        new = reach.copy()
        for s in sizes:
            if s > 100:
                continue
            # shifting: a state r+s is more closeable if r was closeable
            new[s:] = np.maximum(new[s:], reach[:-s] * p[s])
        reach = new
    # normalize reach into [0,1]
    m = reach.max()
    if m > 0:
        reach = reach / m
    # cost: leftover residual that is hard to close -> but for choosing bins we mainly
    # want to avoid residuals that are small but nonzero and hard to close.
    cost = (1.0 - reach)
    _cost = cost
    _last_n = total


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    if _n != _last_n:
        _refresh_cost()

    r = residual.astype(np.int64)
    # primary: tightest residual (best fit)
    score = -residual.astype(np.float64)
    # tie-break: small penalty for residuals that are hard to close later
    score -= 0.3 * _cost[r]
    # exact-fit gets a clear bonus (bin closed with zero waste)
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
