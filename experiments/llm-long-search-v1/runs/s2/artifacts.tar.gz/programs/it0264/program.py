# EVOLVE-BLOCK-START
"""Best fit with an asymmetric, exact-match-heavy residual-usefulness tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
# Asymmetric kernel over offsets -2..+3: strongest at offset 0 (exact match),
# with mild preference for residuals a bit above common sizes (future fit).
_offsets = np.array([-2, -1, 0, 1, 2, 3], dtype=np.int64)
_weights = np.array([0.10, 0.20, 0.45, 0.15, 0.07, 0.03], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    for off, w in zip(_offsets, _weights):
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    r = residual.astype(np.int64)
    use = smoothed[r]

    tight = -residual.astype(np.float64)
    # usefulness bonus kept below 1.0 in magnitude so best-fit (gaps of >=1) stays dominant
    score = tight + 0.45 * use

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
