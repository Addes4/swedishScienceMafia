# EVOLVE-BLOCK-START
"""Pure best-fit: place the item into the bin whose residual is smallest, with exact fills preferred."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    # Dominant key: tighter residual is better (smaller residual -> higher score).
    score = -residual.astype(np.float64)

    # Strongly prefer bins that this item fills exactly (residual 0).
    score[residual == 0] += 1000.0

    return score
# EVOLVE-BLOCK-END
