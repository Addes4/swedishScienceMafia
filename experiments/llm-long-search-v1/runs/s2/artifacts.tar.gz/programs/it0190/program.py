# EVOLVE-BLOCK-START
"""Best fit with a live empirical 'residual is a common item size' tie-break bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin; best-fit strictly dominates, histogram is a tie-break."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    # Best fit: strongly dominant primary term (gaps differ by >=1, but scaled huge).
    score = -residual.astype(np.float64) * 1000.0

    # Live empirical probability that a residual equals a common future item size.
    freq = _counts
    total = _n if _n > 0.0 else 1.0
    frac = freq / total
    use = frac[residual.astype(np.int64)]
    # bounded strictly below the 1000.0 best-fit scale; only matters among equal residuals
    score = score + use

    score[residual == 0] += 500.0  # exact fill is always best

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
