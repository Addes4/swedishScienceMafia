# EVOLVE-BLOCK-START
"""Residual-aware best fit with harmonic capacity classes.

The item is placed in the bin that yields the tightest fit, but near-ties are
broken by preferring bins whose resulting residual lands in a small set of
"usable" capacity classes (halves/quarters of 100).  This tends to keep leftover
space large enough to be reused by later items while still consolidating small
fragments, which helps for Weibull-shaped item sizes.
"""
import numpy as np

# Class boundaries: residual values just below these are especially reusable.
_BOUNDS = np.array([12.5, 25.0, 33.3333, 50.0, 66.6667, 75.0], dtype=np.float64)


def priority(item, bins):
    """Return a priority per bin; highest score wins (first on ties)."""
    residual = bins - item  # resulting leftover after placing here

    # Primary: tightest fit -> smallest residual.
    primary = -residual.astype(np.float64)

    # Secondary: reward residuals that sit in a reusable capacity class.
    # A normalized "harmonic level" 1/ceil(100/residual) style bonus.
    r = residual.astype(np.float64)
    safe = np.maximum(r, 1.0)
    level = 100.0 / safe           # roughly how many such residuals fit per bin
    frac = level - np.floor(level)  # fractional part near 0 => class boundary
    boundary_bonus = -np.abs(frac - 0.5)

    # Slight preference for the bin whose residual is just below a class edge.
    extra = 1e-3 * boundary_bonus

    return primary + extra
# EVOLVE-BLOCK-END
