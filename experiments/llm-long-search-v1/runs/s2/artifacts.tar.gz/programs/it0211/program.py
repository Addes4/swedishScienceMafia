# EVOLVE-BLOCK-START
"""Best fit with a bounded deviation toward frequently reusable residuals."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)

    # Empirical probability that a future item exactly fills this residual.
    p_fill = freq[r] / max(_n, 1.0)

    # Strict best-fit is the primary term: larger (less negative) residual is worse,
    # so -residual dominates. Distinct residuals differ by at least 1 in this term,
    # and the bonus below is capped under 1.0 so ordering of distinct residuals is
    # preserved except when the fill probability strongly favors a specific value.
    score = -residual.astype(np.float64) + 0.9 * p_fill

    # Prefer exact fits strongly (residual == 0), but only within the dominant term.
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
