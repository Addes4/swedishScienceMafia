# EVOLVE-BLOCK-START
"""First-fit style: prefer the earliest bin index that the item fits in.

Bins are listed in fixed index order and every bin shown already fits the item,
so returning a score that decreases with index makes the harness place the item
into the lowest-index (oldest) fitting bin. This packs existing bins full before
opening new ones, which is a strong baseline for online bin packing.
"""
import numpy as np


def priority(item, bins):
    """Return a priority per bin; highest wins, ties go to the first bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin,
          in bin-index order (unused bins have capacity 100 and appear last).
    """
    n = bins.shape[0]
    # Prefer earliest indices (First-Fit). Add a tiny best-fit tiebreak so that
    # among empty bins the tightest fit is still favored when residuals tie.
    idx = np.arange(n, dtype=np.float64)
    return -idx * 1e6 - (bins - item) * 1e-3
# EVOLVE-BLOCK-END

