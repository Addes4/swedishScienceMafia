# EVOLVE-BLOCK-START
"""Best fit with a strictly-dominant residual ordering and deterministic tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = (bins - item).astype(np.float64)  # >= 0 for all bins shown

    # Best-fit is strictly dominant: larger residual = worse (more negative score).
    score = -residual

    # Exact fill is the best possible choice, so it must dominate everything.
    score[residual == 0] += 1e6

    return score
# EVOLVE-BLOCK-END
