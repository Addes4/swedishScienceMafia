# EVOLVE-BLOCK-START
"""Best fit with a strictly-sub-1.0 bonus favoring residuals that match typical item sizes."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)


def priority(item, bins):
    global _n, _sum
    residual = bins - item
    r = residual.astype(np.int64)

    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    # strict best-fit: smaller residual dominates (integer gaps >= 1)
    score = -residual.astype(np.float64)
    # bonuses strictly below 1.0 so best-fit ordering is preserved
    score = score + 0.4 * use

    if _n > 0.0:
        mean_item = _sum / _n
        reuse = 0.25 * np.exp(-((residual.astype(np.float64) - mean_item) ** 2) /
                              (2.0 * (0.25 * mean_item + 1.0) ** 2))
        score = score + reuse

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
