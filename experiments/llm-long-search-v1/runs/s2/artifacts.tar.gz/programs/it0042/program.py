# EVOLVE-BLOCK-START
"""Best fit with an adaptive smoothed residual-usefulness tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_kernel = np.array([0.10, 0.20, 0.40, 0.20, 0.10], dtype=np.float64)  # offsets -2..+2

# adaptive weight state
_w = 0.5
_w_lo = 0.2
_w_hi = 0.9
_w_step = 0.02
_last_best_res = None
_last_call_used_best = True
_success = 0.0
_trials = 0.0
_patience = 0.0


def _build_smoothed(freq):
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    return smoothed


def priority(item, bins):
    global _n, _w, _last_best_res, _last_call_used_best, _success, _trials, _patience
    residual = bins - item

    r = residual.astype(np.int64)
    clamped = np.clip(r, 0, 100)
    smoothed = _build_smoothed(_counts)
    use = smoothed[clamped]

    tight = -residual.astype(np.float64)
    score = tight + _w * use
    score[residual == 0] += 1000.0

    # adaptive tuning proxy: track whether the chosen bin had minimal residual
    best_idx = int(np.argmax(score))
    chosen_res = int(r[best_idx])
    min_res = int(r.min())
    used_best = (chosen_res == min_res)

    # reward/penalty previous weight based on whether it led to best-fit choices
    if _last_call_used_best and not used_best:
        _w -= _w_step
        _patience = 0.0
    elif used_best and not _last_call_used_best:
        _w += _w_step
        _patience = 0.0
    else:
        _patience += 1.0
        if _patience > 250.0:
            # random-ish walk by deterministic parity to escape plateau
            _w += _w_step if (int(_n) % 4 < 2) else -_w_step
            _patience = 0.0

    if _w < _w_lo:
        _w = _w_lo
    elif _w > _w_hi:
        _w = _w_hi
    _last_call_used_best = used_best
    _last_best_res = chosen_res

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
