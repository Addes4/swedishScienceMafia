# EVOLVE-BLOCK-START
"""Log-penalty best fit with a stable, predictive "leftover is a common item size" tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_maxfreq = 1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _maxfreq
    residual = bins - item  # >= 0 for all bins shown
    rf = residual.astype(np.float64)

    # Best-fit dominance: strictly monotone decreasing in residual.
    tight = -np.log1p(rf)

    # Cheap predictive tie-break: a residual that is itself a common item size can be
    # exactly filled by a single future item. Use the raw frequency history directly
    # (no convolution, no order-sensitive smoothing).
    r = residual.astype(np.int64)
    common = _counts[r] / _maxfreq  # in [0, 1]

    # Keep tie-break strictly below the best-fit integer gap so tightness dominates.
    score = 4.0 * tight + 0.4 * common

    # Bounded exact perfect-fill bonus (residual 0).
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item
    if _counts[item] > _maxfreq:
        _maxfreq = _counts[item]

    return score
# EVOLVE-BLOCK-END
