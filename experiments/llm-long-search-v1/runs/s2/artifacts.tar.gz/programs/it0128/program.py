# EVOLVE-BLOCK-START
"""Best fit (dominant) with a bounded empirical expected-waste tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)   # empirical item-size histogram
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    rf = residual.astype(np.float64)

    # Dominant term: best fit (smallest residual wins). Unit gap far exceeds tie-break range.
    score = -rf * 1000.0

    # Tie-break: expected waste if this bin's residual ends up never exactly closed.
    # A residual r can be reduced well only if future items fit closely; estimate the
    # probability mass of items <= r and the expected leftover after placing one.
    freq = _counts
    # cumulative distribution of item sizes
    if _n > 0.0:
        cum = np.cumsum(freq) / _n            # cum[s] = P(item <= s)
        # probability that at least one future item can fit into residual r
        # (loosely: for each residual, chance it gets reused improves as more items fit)
        r = residual.astype(np.int64)
        # expected number of usable item sizes for residual r, relative measure
        usable = cum[np.minimum(r, 100)]
        rem = r - item  # not used; placeholder to avoid accidental optimization reuse
        # reward residuals that are easy to fill: higher usable mass -> less likely wasted
        score = score + 40.0 * usable
        # penalize tiny residuals that rarely match an exact item (awkward gaps)
        exact = np.zeros_like(rf)
        sizes = np.arange(1, 101)
        # probability of an exact match for residual r
        for rr in np.unique(r):
            if rr > 0:
                exact[r == rr] = freq[rr]
        exact = exact / _n
        score = score + 30.0 * exact

    score[residual == 0] += 1e9

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
