# EVOLVE-BLOCK-START
"""Best fit with a strictly-tie-breaking smoothed residual-usefulness and reuse bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0

# smoothed histogram weights (offsets -3..+3) for estimating P(round -> r)
_kernel = np.array([0.05, 0.10, 0.20, 0.30, 0.20, 0.10, 0.05], dtype=np.float64)
_half = len(_kernel) // 2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    # Smoothed histogram of past item sizes, used as a proxy for P(next item == r)
    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_kernel):
        off = k - _half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    r = residual.astype(np.int64)
    fill_prob = smoothed[r]  # likelihood this exact residual gets filled by a future item

    # Best-fit core: tightest residual dominates (gaps >= 1, so *2 keeps ordering strict)
    tight = -2.0 * residual.astype(np.float64)
    # bounded bonus (<1) rewarding gaps likely to be filled exactly
    score = tight + np.minimum(fill_prob, 0.9)

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END

