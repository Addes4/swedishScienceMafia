# EVOLVE-BLOCK-START
"""Best fit with a smoothed self-convolution tie-break: reward residuals that a pair of typical
future items can fill exactly, on top of the dominant smallest-residual key."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
# smoothing kernel over residual sizes (offsets -2..+2)
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)


def _smooth(freq):
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    return smoothed


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    smoothed = _smooth(_counts)
    total = smoothed.sum()
    if total > 0:
        probs = smoothed / total
    else:
        probs = smoothed

    # probability a pair of independent typical items sums exactly to r
    pair = np.convolve(probs, probs)[:101]
    pair_max = pair.max() if pair.size else 0.0
    if pair_max > 0:
        pair = pair / pair_max

    r = residual.astype(np.int64)
    use = pair[r]

    tight = -residual.astype(np.float64)
    score = tight + 0.5 * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
