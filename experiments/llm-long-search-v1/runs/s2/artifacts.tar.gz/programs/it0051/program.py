# EVOLVE-BLOCK-START
"""Best fit with an exact-refill-probability tie-break from the empirical item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
# smoothing kernel over residual sizes; residual r is "refillable" if a future item ~r appears
_kernel = np.array([0.10, 0.20, 0.40, 0.20, 0.10], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # build smoothed histogram of item sizes seen so far, blended with a small uniform prior
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    freq = _counts
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    # light prior so early behavior is robust
    smoothed += 0.5
    smoothed /= smoothed.sum()

    r = residual.astype(np.int64)
    use = smoothed[r]  # probability a future item can exactly fill this residual

    tight = -residual.astype(np.float64)
    score = tight + 0.3 * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END

