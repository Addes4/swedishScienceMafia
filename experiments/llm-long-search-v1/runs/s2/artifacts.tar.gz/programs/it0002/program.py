# EVOLVE-BLOCK-START
"""Best fit with a small preference for already-fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    fit = -(bins - item)          # tighter fit is better
    fuller = (100.0 - bins)       # bins with less remaining space are slightly favored
    return fit + 0.01 * fuller
# EVOLVE-BLOCK-END

