# EVOLVE-BLOCK-START
"""Best fit with a strictly-dominant residual term and a recency-weighted exact-match tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0

_resid = None
_w = None


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _resid, _w
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    if _w is None or len(_w) != len(freq):
        _w = freq.copy()
    # recency-weighted histogram: decay old counts, add current
    _w *= 0.995
    _w[item] += 1.0

    r = residual.astype(np.int64)
    use = _w[r]

    best = residual.min()
    # strictly dominant best-fit term: any residual gap >=1 overwhelms tie-breaks
    score = -1000.0 * residual.astype(np.float64)

    # tie-break only matters among bins with residual == best
    # prefer residuals that match a recently-common item size (likely exact refill)
    score = score + (use / (use.max() + 1.0))

    if _n > 0.0:
        mean_item = _sum / _n
        reuse = 0.25 * np.exp(-((residual.astype(np.float64) - mean_item) ** 2) /
                              (2.0 * (0.25 * mean_item + 1.0) ** 2))
        score = score + reuse

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
