# EVOLVE-BLOCK-START
"""Strict best fit with a deterministic tie-break on the resulting bin's residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    # Dominant term: prefer the tightest fit (smallest residual).
    tight = -residual.astype(np.float64)

    # Strictly tie-breaking term: among equal residuals, prefer the bin whose
    # index is smallest (first) by adding a tiny decreasing function of position.
    n = bins.shape[0]
    tie = -np.arange(n, dtype=np.float64) * 1e-9

    score = tight + tie

    # Exact fit is always best.
    score[residual == 0] += 1e6

    return score
# EVOLVE-BLOCK-END
