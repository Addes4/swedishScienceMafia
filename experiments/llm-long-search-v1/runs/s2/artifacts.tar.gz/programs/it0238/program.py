# EVOLVE-BLOCK-START
"""Best fit with a strictly-tie-breaking fillability bonus from a smoothed running histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    # Strict best-fit dominates: residual term scaled so that any gap >= 1 beats tie-break.
    score = -10000.0 * residual.astype(np.float64)
    score = score + use  # only breaks exact-residual ties, favors fillable gaps

    score[residual == 0] += 1e9

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END

