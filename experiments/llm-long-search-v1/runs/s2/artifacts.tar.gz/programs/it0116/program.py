# EVOLVE-BLOCK-START
"""Best-fit dominant rule with an exact-residual reuse-frequency tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0

# precomputed smoothed histogram cache
_cache_valid = False
_smoothed = np.zeros(101, dtype=np.float64)
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _cache_valid, _smoothed

    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    if not _cache_valid:
        sm = np.zeros(101, dtype=np.float64)
        half = len(_kernel) // 2
        for k, w in enumerate(_kernel):
            off = k - half
            lo = max(0, -off)
            hi = min(101, 101 - off)
            sm[lo + off:hi + off] += w * _counts[lo:hi]
        _smoothed = sm
        _cache_valid = True

    # usefulness: probability a future item exactly fills this residual (smoothed over +-2)
    use = _smoothed[r]

    # best-fit dominates: primary term is -residual (weight 1).
    # tie-break term is bounded below 1 by normalizing usefulness.
    tight = -residual.astype(np.float64)
    if _n > 0.0:
        tie = use / (_n + 1.0)  # in [0,1), only breaks ties
    else:
        tie = 0.0

    score = tight + tie

    # exact fill is strictly best
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _cache_valid = False

    return score
# EVOLVE-BLOCK-END
