# EVOLVE-BLOCK-START
"""Best fit with strictly-best-fit dominance and a deterministic small-magnitude tie-break."""
import numpy as np

_idx = None

def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    # Dominant signal: strictly best fit = smallest non-negative residual.
    score = -residual.astype(np.float64)

    # Deterministic, tiny tie-break: prefer bins that fit more snugly after placement
    # only when residuals are exactly equal is unnecessary since -residual already
    # orders them; add a vanishing index preference to consolidate into lower-index bins.
    n = residual.shape[0]
    score += -1e-6 * np.arange(n, dtype=np.float64)

    # Exact fill (residual == 0) gets an overwhelming but safe bonus, above any tie-break.
    score[residual == 0] += 1e6

    return score
# EVOLVE-BLOCK-END
