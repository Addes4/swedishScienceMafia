# EVOLVE-BLOCK-START
"""Strict best-fit dominance plus a bounded, frequency-weighted residual-usefulness bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Priority for every bin; highest score wins (ties -> first)."""
    residual = bins - item
    r = residual.astype(np.int64)

    # Frequency of the exact resulting residual (how likely a future item fits it perfectly).
    freq = _counts
    total = _n if _n > 0.0 else 1.0
    use = freq[r] / total

    # Best-fit dominance: residual gap of >=1 dominates (tight is integer step).
    # Bonus strictly below 1.0 in magnitude, so it only breaks equal-residual ties.
    score = -residual.astype(np.float64) + 0.999 * use

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
