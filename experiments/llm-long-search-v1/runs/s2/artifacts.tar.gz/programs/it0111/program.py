# EVOLVE-BLOCK-START
"""Best fit (dominant) with a small tie-break matching the most probable future item size."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0

# recent (exponential moving average) item-size histogram for the reuse tie-break
_ema = np.zeros(101, dtype=np.float64)
_ema_built = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _ema_built

    residual = bins - item  # >= 0 for all bins shown
    rf = residual.astype(np.float64)

    # primary: best fit, strongly dominant so the tie-break cannot flip the ordering
    score = -10.0 * rf

    # tie-break: prefer a residual that equals the most probable single future item size,
    # so the leftover space is likely to be exactly refillable.
    if _ema_built:
        best_size = int(np.argmax(_ema))
        if best_size > 0:
            score = score - 0.5 * np.abs(rf - best_size)

        # above argument: if residual > best_size, find the best complementary pair
        # (residual - best_size) should also be reusable -> handled implicitly by argmax shape

    # exact-fill bonus (dominates everything, but residual 0 is already the min residual)
    score[residual == 0] += 1e6

    # update statistics
    _counts[item] += 1.0
    _n += 1.0
    decay = 0.01
    _ema *= (1.0 - decay)
    _ema[item] += decay
    _ema_built = 1

    return score
# EVOLVE-BLOCK-END
