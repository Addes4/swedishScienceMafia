# EVOLVE-BLOCK-START
"""Coarse best-fit bucketing with histogram-based tie-break within each bucket."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)


def priority(item, bins):
    """Rank bins: coarse best-fit bucket first, then likely-useful residual within the bucket."""
    global _n
    residual = bins - item
    residual = residual.astype(np.float64)

    # smoothed histogram of future item sizes
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * _counts[lo:hi]
    tot = smoothed.sum()
    if tot > 0:
        smoothed /= tot

    r = residual.astype(np.int64)
    r = np.clip(r, 0, 100)
    # probability that a future item exactly fills this residual
    use = smoothed[r]

    # coarse bucket: bins within the same 8-unit residual band are considered tied,
    # and within that band prefer the residual a future item is most likely to fill exactly
    bucket = -(r // 8).astype(np.float64)
    score = bucket + 0.9 * use
    score[r == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
