# EVOLVE-BLOCK-START
"""Best fit with a strictly-subordinate smoothed complementary-fit closeout bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    # normalize to a probability-like weight so the bonus stays in [0,1)
    tot = smoothed.sum()
    if tot > 0.0:
        smoothed = smoothed / tot
    use = smoothed[residual.astype(np.int64)]

    # best-fit strictly dominant: residual gaps are at least 1, bonus is < 1
    score = -residual.astype(np.float64) + use

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
