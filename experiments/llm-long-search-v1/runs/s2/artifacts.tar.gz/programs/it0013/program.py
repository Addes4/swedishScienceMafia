# EVOLVE-BLOCK-START
"""Best fit with a small harmonic bonus for reusable residuals."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Best fit: prefer smallest residual. Add a tiny bonus when the residual
    # equals a size that typical small future items can exactly fill, so we
    # don't waste leftover space in un-usable slivers.
    score = -residual.astype(np.float64)
    # Reward residuals that match common small item sizes (1..item):
    # a mild, monotone-in-"reusability" bump without overriding best fit.
    reusable = np.minimum(residual, item).astype(np.float64)
    score += 1e-3 * reusable
    return score
# EVOLVE-BLOCK-END
