# EVOLVE-BLOCK-START
"""Best fit with a smoothed empirical histogram tie-break on exact residuals."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    # Dominant: best fit (smaller residual first). Kept strictly dominant by scaling
    # residual by a large constant versus the bounded tie-break in [0,1].
    tight = -residual.astype(np.float64) * 4.0

    # Tie-break: prefer residuals that have historically been common item sizes,
    # i.e. gaps likely to be exactly closed by a future arrival.
    total = smoothed.sum()
    if total > 0.0:
        use = smoothed[r] / total
    else:
        use = np.zeros_like(r, dtype=np.float64)

    score = tight + use

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
