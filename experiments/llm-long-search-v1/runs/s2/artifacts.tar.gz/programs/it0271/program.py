# EVOLVE-BLOCK-START
"""Best fit with a precomputed exact-match tie-break on equal residuals."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    use = freq[r]  # exact-match count for the residual

    tight = -residual.astype(np.float64)
    # usefulness bonus kept strictly below 1.0 in magnitude so best-fit (gaps of >=1) stays dominant
    score = tight + 0.4 * use

    if _n > 0.0:
        mean_item = _sum / _n
        reuse = 0.25 * np.exp(-((residual.astype(np.float64) - mean_item) ** 2) /
                              (2.0 * (0.25 * mean_item + 1.0) ** 2))
        score = score + reuse

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
