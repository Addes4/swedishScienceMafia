# EVOLVE-BLOCK-START
"""Log-penalty best fit with frequency-based tie-breaks for residual reuse."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_maxfreq = 1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _maxfreq
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)

    rf = residual.astype(np.float64)

    # log penalty preserves best-fit dominance (monotone decreasing in residual)
    tight = -np.log1p(rf)
    score = 5.0 * tight

    # Reward residuals whose size is itself a common future item size, so the
    # leftover can be filled exactly by a single later item. Bounded strictly
    # below the integer gap of best-fit so tighter fits always win.
    typical = freq / _maxfreq
    score = score + 0.3 * typical[r]

    # Small bonus when leftover exactly matches the current item size.
    exact = freq[r] / _maxfreq
    score = score + 0.15 * exact

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item
    if _counts[item] > _maxfreq:
        _maxfreq = _counts[item]

    return score
# EVOLVE-BLOCK-END
