# EVOLVE-BLOCK-START
"""Best fit (dominant) with a sharp one-step-ahead exact-fill tie-break.

The primary rule is best fit: smallest resulting residual wins. To break near-ties,
reward a residual whose value equals a frequently observed item size, because such a
bin can later be closed exactly. The bonus is bounded strictly below 1.0 so it can
never override a genuine best-fit difference of at least one unit.
"""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    freq = _counts

    # Sharp one-step-ahead exact-fill signal: how often have we seen an item exactly
    # equal to this residual? Normalize so the bonus stays well below 1.0.
    total = _n if _n > 0.0 else 1.0
    fill = freq[r] / total  # in [0, 1]

    tight = -residual.astype(np.float64)  # best fit: -residual, larger (closer to 0) is better
    score = tight + fill  # fill < 1.0, so it only breaks ties/near-ties within one unit

    # Exact fill of the current item perfectly closes a bin: reward strongly.
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
