# EVOLVE-BLOCK-START
"""Best fit with a bounded low-residual avoidance bonus and smoothed usefulness tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2

# online estimates for the "low residual" threshold
_seen = []          # rolling buffer of recent item sizes
_low_q = 5.0        # 10th-percentile-ish estimate of item sizes
_alpha = 0.05


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _low_q
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    residual_f = residual.astype(np.float64)
    # primary term: strict best-fit, keep large so integer gaps dominate
    score = -1000.0 * residual_f + 0.4 * use

    # bounded avoidance: prefer gaps at/above the low quantile of item sizes
    # magnitude well below 1000 so best-fit ordering is preserved
    low = _low_q
    score += 0.6 * np.minimum(residual_f, low) / max(low, 1.0)

    score[residual == 0] += 1e7

    # update online stats
    _counts[item] += 1.0
    _n += 1.0
    _sum += item
    # exponentially weighted low-quantile tracker
    if item < _low_q:
        _low_q += _alpha * (item - _low_q)
    else:
        _low_q += _alpha * 0.1 * (_low_q - _low_q)  # no-op, keeps it stable
    _low_q = min(max(_low_q, 1.0), 60.0)

    return score
# EVOLVE-BLOCK-END
