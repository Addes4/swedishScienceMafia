# EVOLVE-BLOCK-START
"""Best fit with a residual-usefulness tie-break based on the empirical item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # frequency of each residual size among past items (residual 0 is always "useful": bin closed)
    freq = _counts
    # usefulness of a residual r: how often items of size ~r have appeared (or r==0)
    use = freq[residual]

    # tightness term: prefer smallest residual (best fit)
    tight = -residual.astype(np.float64)

    # combine: tightness dominates, histogram usefulness breaks near-ties
    score = tight + 0.5 * use
    score[residual == 0] += 1000.0

    # update histogram with current item
    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
