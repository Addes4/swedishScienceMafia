# EVOLVE-BLOCK-START
"""Best fit with a strictly-sub-1.0 tie-break that keeps bins in a stable, sparse layout."""
import numpy as np

_n = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # Primary: best fit. Scale so residual ordering strictly dominates any tie-break below.
    score = -1000.0 * residual.astype(np.float64)

    # Tie-break (|value| < 1000 so it never overrides residual ordering):
    # among equal residuals prefer recently-touched bins (larger index) to keep the
    # earlier, untouched bins available for larger future items.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    score += 0.001 * idx

    score[residual == 0] += 1e9
    _n += 1
    return score
# EVOLVE-BLOCK-END
