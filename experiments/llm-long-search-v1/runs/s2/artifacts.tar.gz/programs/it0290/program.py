# EVOLVE-BLOCK-START
"""Log-penalty best fit with tuned exact-residual reuse bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_maxfreq = 1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _maxfreq
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)

    rf = residual.astype(np.float64)

    # log penalty preserves best-fit dominance (monotone decreasing in residual)
    tight = -np.log1p(rf)
    score = 4.0 * tight

    # bounded exact-residual-match bonus: rewards leftovers equal to common item sizes,
    # kept strictly below the integer gap of best-fit so it cannot override tighter fits.
    exact = freq[r] / _maxfreq
    score = score + 0.35 * exact

    # small bonus for near-perfect fills (very small residual) using current-item context
    score = score + 0.05 * np.exp(-rf / (0.5 * item + 1.0))

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item
    if _counts[item] > _maxfreq:
        _maxfreq = _counts[item]

    return score
# EVOLVE-BLOCK-END
