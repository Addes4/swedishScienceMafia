# EVOLVE-BLOCK-START
"""Best fit with a strictly-tie-breaking smoothed residual-usefulness and reuse bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_sq = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2

# Precompute the smoothing as a matrix-vector-friendly structure once
_smoothed = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _sq
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    tight = -residual.astype(np.float64)
    # usefulness bonus kept below 1.0 in magnitude so best-fit (gaps of >=1) stays dominant
    score = tight + 0.4 * use

    if _n > 0.0:
        mean_item = _sum / _n
        var = max(_sq / _n - mean_item * mean_item, 1.0)
        sd = var ** 0.5
        reuse = 0.25 * np.exp(-((residual.astype(np.float64) - mean_item) ** 2) /
                              (2.0 * (sd + 1.0) ** 2))
        score = score + reuse

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item
    _sq += item * item

    return score
# EVOLVE-BLOCK-END
