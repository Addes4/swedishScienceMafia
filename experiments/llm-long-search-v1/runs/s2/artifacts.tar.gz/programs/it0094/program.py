# EVOLVE-BLOCK-START
"""Best fit with a smoothed residual-usefulness tie-break plus a histogram-mode reuse bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
# small smoothing kernel over residual sizes
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    # smoothed usefulness: probability that a future item can roughly fill this residual
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    tight = -residual.astype(np.float64)
    score = tight + 0.5 * use

    # reusability sweet spot: residual near a common future item size (histogram-weighted),
    # rather than near the mean, which is a poor location summary for a skewed distribution
    if _n > 0.0:
        # weight residual r by how frequently an item of that exact size arrives soon
        peak = freq[r] / _n            # probability item size == residual
        near = 0.0
        for off in (-1, 1):
            rr = r + off
            mask = (rr >= 0) & (rr <= 100)
            near = near + np.where(mask, freq[np.clip(rr, 0, 100)], 0.0)
        near = near / _n
        # bounded bonus (< 0.5) favoring reusable residual sizes
        reuse = 0.45 * (3.0 * peak + 1.0 * near)
        reuse = np.minimum(reuse, 0.45)
        score = score + reuse

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END

