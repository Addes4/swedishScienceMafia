# EVOLVE-BLOCK-START
"""Best fit (tightest residual) with a calibrated future-fit tie-break from the running item histogram."""
import numpy as np

_counts = np.ones(101, dtype=np.float64)  # Laplace smoothing
_n = 100.0
_total = 100.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _total
    residual = bins - item  # >= 0 for all bins shown

    # Primary key: tightest residual (best fit). Residual 0 gets a very strong bonus.
    tight = -residual.astype(np.float64)

    # Future-fit: probability that a future item exactly fills the residual
    prob = _counts / _total
    r = residual.astype(np.int64)
    fit = prob[r]  # in [0,1]

    # Use fit as a small tie-break; also slightly reward slightly larger residual
    # when its exact-fill probability is high (helps smooth the discreteness).
    score = tight + 0.01 * fit
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _total += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END

