# EVOLVE-BLOCK-START
"""Best fit, with a small sub-1.0 tie-break favoring commonly reusable residuals."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Primary term: strict best-fit (smallest residual wins).
    score = -res

    # Sub-1.0 tie-break: prefer residuals whose exact-fill probability is high.
    # Use the empirical frequency of item sizes seen so far as a reuse proxy.
    freq = _counts
    r = residual.astype(np.int64)
    reuse = freq[r] / (_n + 1.0)  # in [0, 1]
    score = score + 0.9 * reuse

    # Exact fit is always best.
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
