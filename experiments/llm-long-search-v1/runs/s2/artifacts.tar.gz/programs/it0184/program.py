# EVOLVE-BLOCK-START
"""Pure best fit: always place the item in the bin with the smallest remaining capacity that still fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown
    # Best fit: strongly prefer the smallest residual (tightest fit).
    score = -residual.astype(np.float64)
    # Exact fill (residual == 0) is the perfect outcome; dominate all other choices.
    score[residual == 0] += 1000.0
    return score
# EVOLVE-BLOCK-END
