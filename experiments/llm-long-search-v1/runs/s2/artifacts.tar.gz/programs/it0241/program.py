# EVOLVE-BLOCK-START
"""Best fit with a near-tie lookahead that favors packable residuals (harmonic/best-fit hybrid)."""
import numpy as np

_n = 0.0
_sum = 0.0
_m2 = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _m2
    residual = bins - item  # >= 0 for all bins shown

    r = residual.astype(np.float64)

    # Dominant best-fit term, but quantized into unit buckets so that near-equal
    # residuals can still be ordered by a secondary packability heuristic.
    # Scale large enough to keep best-fit strictly dominant.
    score = -r * 1e6

    if _n >= 5.0:
        mean_item = _sum / _n
        var = _m2 / _n
        var = var if var > 1.0 else 1.0
        sd = var ** 0.5
        # Prefer residuals that are close to the mean item size (easiest to exactly fill
        # with a single future item), normalized by the item-size spread.
        z = (r - mean_item) / sd
        pack = np.exp(-0.5 * z * z)
        # Tie-break bonus is tiny compared to the 1e6 residual scale, so it only
        # matters when residuals are equal or differ by less than 1 unit within a bin choice.
        score = score + pack

    score[residual == 0] += 1e9

    _counts_update(item)
    return score


def _counts_update(item):
    global _n, _sum, _m2
    delta = item - (_sum / _n) if _n > 0.0 else 0.0
    mean_old = _sum / _n if _n > 0.0 else 0.0
    _n += 1.0
    _sum += item
    new_mean = _sum / _n
    _m2 += delta * (item - new_mean)
# EVOLVE-BLOCK-END
