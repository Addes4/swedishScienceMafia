# EVOLVE-BLOCK-START
"""Best fit with a histogram-based residual-desirability tie-break for future fillability."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
# smoothing kernel over residual sizes: mass at residual r approximates probability some
# future item size lands near r, so the bin can later be closed with little waste.
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)

# smoothed histogram cache, rebuilt lazily every few items
_smoothed = np.zeros(101, dtype=np.float64)
_dirty = 0


def _rebuild(freq):
    global _smoothed
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    # normalize to a probability-like scale
    tot = smoothed.sum()
    if tot > 0:
        smoothed /= tot
    _smoothed = smoothed


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _dirty
    residual = bins - item  # >= 0 for all bins shown

    if _dirty <= 0:
        _rebuild(_counts)
        _dirty = 8
    _dirty -= 1

    r = residual.astype(np.int64)
    # desirability: how likely this residual can later be filled by a common item size
    use = _smoothed[r]

    # primary: best fit (smallest residual); secondary: future fillability
    tight = -residual.astype(np.float64)
    score = tight + 0.5 * use
    # exact fit closes the bin with zero waste
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _dirty = 0  # force rebuild next call after histogram update

    return score
# EVOLVE-BLOCK-END
