# EVOLVE-BLOCK-START
"""Best fit with a small exact-residual reuse bonus; tightness dominates via a strong log penalty."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_maxfreq = 1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _maxfreq
    residual = bins - item  # >= 0 for all bins shown

    rf = residual.astype(np.float64)

    # strong log penalty: tightness (best fit) dominates all tie-break terms
    score = 12.0 * (-np.log1p(rf))

    # cheap reuse signal: reward residuals equal to a common past item size
    r = residual.astype(np.int64)
    score += 0.2 * (_counts[r] / _maxfreq)

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    if _counts[item] > _maxfreq:
        _maxfreq = _counts[item]

    return score
# EVOLVE-BLOCK-END
