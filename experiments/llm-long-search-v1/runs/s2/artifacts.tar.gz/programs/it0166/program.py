# EVOLVE-BLOCK-START
"""Worst-fit among fitting bins, with exact-fit preferred."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    # Worst-fit: among bins that fit, prefer the one with the most remaining space.
    score = residual.astype(np.float64)

    # Never waste an exact fit.
    score[residual == 0] += 1000.0

    return score
# EVOLVE-BLOCK-END
