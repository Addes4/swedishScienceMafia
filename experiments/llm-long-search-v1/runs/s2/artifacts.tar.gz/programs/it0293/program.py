# EVOLVE-BLOCK-START
"""Best-fit dominance with cheap raw-frequency exact-residual reuse tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_maxfreq = 1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum, _maxfreq
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64,
                        copy=False) if False else residual.astype(np.int64)

    rf = residual.astype(np.float64)

    # log penalty preserves best-fit dominance (monotone decreasing in residual)
    tight = -np.log1p(rf)
    score = 4.0 * tight

    if _n > 0.0:
        mean_item = _sum / _n
        reuse = 0.25 * np.exp(-((rf - mean_item) ** 2) /
                              (2.0 * (0.25 * mean_item + 1.0) ** 2))
        score = score + 0.4 * reuse

    # bounded exact-residual-match bonus: rewards leftovers equal to common item sizes,
    # kept strictly below the integer gap of best-fit so it cannot override tighter fits.
    exact = freq[r] / _maxfreq
    score = score + 0.2 * exact

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item
    if _counts[item] > _maxfreq:
        _maxfreq = _counts[item]

    return score
# EVOLVE-BLOCK-END
