# EVOLVE-BLOCK-START
"""Best fit with a smoothed-histogram residual-affinity tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.10, 0.20, 0.40, 0.20, 0.10], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    # residual affinity: how often a residual of this size has been "needed"
    use = smoothed[r]

    # best-fit remains strictly dominant (gaps >= 1 in residual)
    score = -residual.astype(np.float64) * 100.0

    # sub-unit tie-break: prefer residuals matching frequent item sizes,
    # bounded well below 100 so it can only act among equal residuals
    norm = use / (use.max() + 1.0)
    score = score + 0.9 * norm

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
