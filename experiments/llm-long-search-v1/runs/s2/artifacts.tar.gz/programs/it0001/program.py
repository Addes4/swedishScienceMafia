# EVOLVE-BLOCK-START
"""Best fit with a small bonus for very tight fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    slack = bins - item
    # Base: best fit (prefer smallest remaining slack).
    score = -slack.astype(np.float64)
    # Bonus for near-perfect fits so those bins empty out.
    score += 0.5 * (slack == 0) + 0.25 * (slack == 1) + 0.125 * (slack == 2)
    return score
# EVOLVE-BLOCK-END
