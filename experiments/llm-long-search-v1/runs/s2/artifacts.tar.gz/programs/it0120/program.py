# EVOLVE-BLOCK-START
"""Best fit with a one-step expected-waste lookahead tie-break using the empirical item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown

    # dominant best-fit term: prefer the smallest residual (tightest packing)
    score = -residual.astype(np.float64)

    # one-step lookahead tie-break: reward residuals that can be exactly filled by a
    # likely future item (avoiding waste), and slightly reward near-fill.
    if _n > 0.0:
        p = _counts / _n  # empirical distribution over item sizes 1..100
        r = residual.astype(np.int64)
        r = np.clip(r, 0, 100)
        # probability that a future item exactly equals this residual
        exact = p[r]
        # near-fill: residual within 1 or 2 of a likely item size
        near1 = np.zeros_like(exact)
        near2 = np.zeros_like(exact)
        m = r >= 1
        near1[m] = p[np.clip(r[m] - 1, 0, 100)] + p[np.clip(r[m] + 1, 0, 100)]
        near2[m] = p[np.clip(r[m] - 2, 0, 100)] + p[np.clip(r[m] + 2, 0, 100)]
        # small weight so best-fit still dominates
        score = score + 0.9 * exact + 0.15 * near1 + 0.05 * near2

    # strongly prefer exact fit (bin closed with zero waste)
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
