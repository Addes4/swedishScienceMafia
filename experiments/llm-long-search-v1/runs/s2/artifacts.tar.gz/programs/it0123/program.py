# EVOLVE-BLOCK-START
"""Best fit with a strictly-tie-breaking smoothed residual-usefulness and reuse bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    # primary: best fit (most negative residual), strictly dominant with unit gap
    tight = -residual.astype(np.float64)

    # tie-break: smoothed usefulness, kept well below the best-fit unit gap
    score = tight + 0.3 * use

    if _n > 0.0:
        total = _n
        # exact-residual matching: reward residual values that were common item sizes,
        # so bins likely to be exactly closed later are preferred among ties.
        match = _counts[r] / total
        score = score + 0.25 * match

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END

