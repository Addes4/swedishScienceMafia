# EVOLVE-BLOCK-START
"""Best fit with strictly-dominant scaling, plus smoothed residual-usefulness and reuse tie-breaks."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown
    residual_f = residual.astype(np.float64)

    freq = _counts
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[r]

    # dominant best-fit term: strictly decreases with residual by at least 1000
    score = -1000.0 * residual_f

    # usefulness bonus: favor residuals that tend to be exact item sizes
    score = score + 0.4 * use

    if _n > 0.0:
        mean_item = _sum / _n
        reuse = 0.25 * np.exp(-((residual_f - mean_item) ** 2) /
                              (2.0 * (0.25 * mean_item + 1.0) ** 2))
        score = score + reuse

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END

