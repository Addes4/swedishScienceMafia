# EVOLVE-BLOCK-START
"""Best fit with an exact-fill / histogram-usefulness tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n

    residual = bins - item  # >= 0 for all bins shown

    # Best-fit dominance: smaller residual is much better (avoids fragmentation).
    tight = -residual.astype(np.float64)

    # Usefulness of the *resulting* residual: how likely is a future item to exactly fill it?
    r = residual.astype(np.int64)
    # exact-fill bonus is strong (zero waste), other residuals get a mild histogram bonus
    use = _counts[r] / (_n + 1.0)
    score = tight + 0.3 * use

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END

