# EVOLVE-BLOCK-START
"""Best fit with a Gaussian-smoothed residual-usefulness tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0

# precomputed symmetric Gaussian kernel over offsets -4..+4
_off = np.arange(-4, 5, dtype=np.float64)
_kernel = np.exp(-0.5 * (_off / 1.5) ** 2)
_kernel /= _kernel.sum()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    # Gaussian-smoothed histogram of past item sizes -> probability a future item
    # roughly fills a residual of that size.  Zero-pad and convolve.
    padded = np.concatenate((np.zeros(4), _counts, np.zeros(4)))
    smoothed = np.convolve(padded, _kernel, mode='valid')

    r = residual.astype(np.int64)
    use = smoothed[r]

    # best-fit dominates; usefulness only refines near-ties and fades for large residuals
    tight = -residual.astype(np.float64)
    decay = np.exp(-residual.astype(np.float64) / 40.0)
    score = tight + 0.6 * use * decay

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
