# EVOLVE-BLOCK-START
"""Best fit dominant, with a smoothed residual-usefulness tie-break and reusable-size bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.1, 0.2, 0.4, 0.2, 0.1], dtype=np.float64)
# indices for the smoothed histogram offsets
_half = len(_kernel) // 2


def _smooth(freq):
    smoothed = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_kernel):
        off = k - _half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    return smoothed


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item
    rf = residual.astype(np.float64)

    smoothed = _smooth(_counts)
    use = smoothed[residual.astype(np.int64)]

    tight = -rf
    score = tight + 0.7 * use

    if _n > 0.0:
        mean_item = _sum / _n
        sigma = 0.3 * mean_item + 1.0
        reuse = 0.4 * np.exp(-((rf - mean_item) ** 2) / (2.0 * sigma * sigma))
        score = score + reuse

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
