# EVOLVE-BLOCK-START
"""Strict best-fit with a lexicographic smoothed-histogram tie-break on equal residuals."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)


def priority(item, bins):
    """Best-fit primary; smoothed-histogram usefulness breaks exact ties."""
    residual = bins - item  # >= 0 for all shown bins

    # smoothed histogram of past items
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * _counts[lo:hi]

    r = residual.astype(np.int64)
    use = smoothed[r]

    # lexicographic: primary = tightest residual (smallest), tie-break = usefulness
    # scale so usefulness is a tiny fraction of one residual unit
    min_r = r.min()
    score = use.copy()
    score[r != min_r] = -1e6 + r[r != min_r] * -1.0  # keep non-min worse, ordered
    # bins with min residual: score in [0, small), so they all beat non-min ones
    # (use is bounded because counts are nonnegative and kernel sums to 1)
    score[r == min_r] = use[r == min_r]
    score[r != min_r] = r[r != min_r] * -1.0 - 1e6

    _counts[item] += 1.0
    _n += 1.0
    return score
# EVOLVE-BLOCK-END
