# EVOLVE-BLOCK-START
"""Best fit with an exact-residual match tie-break using the empirical item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Smallest residual (best fit); ties broken by likelihood that residual is an exact future item size."""
    residual = bins - item  # >= 0 for all bins shown

    r = residual.astype(np.int64)
    # probability that a future item exactly equals this residual size
    freq = _counts / _n if _n > 0 else _counts
    use = freq[r]

    # primary: smaller residual wins (best fit); secondary: exact-match usefulness
    score = -residual.astype(np.float64) + 0.5 * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
