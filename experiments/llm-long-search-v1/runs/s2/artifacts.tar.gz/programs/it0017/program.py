# EVOLVE-BLOCK-START
"""Best fit with index-based tie breaking to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = bins.shape[0]
    # Primary: tightest fit (minimize residual after placement).
    residual = bins - item
    # Secondary: tiny index-dependent jitter to break ties toward varied bins.
    idx = np.arange(n)
    jitter = (idx % 7) * 1e-6
    return -residual.astype(np.float64) + jitter
# EVOLVE-BLOCK-END
