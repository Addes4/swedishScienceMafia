# EVOLVE-BLOCK-START
"""Best-fit with a sharp exact-match tie-break among equal residuals."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_exact = np.zeros(101, dtype=np.float64)   # count of items of each exact size
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    r = residual.astype(np.int64)
    np.clip(r, 0, 100, out=r)

    # Exact-match usefulness: how often have we seen an item exactly equal to this residual?
    # Higher = leaving this gap is more likely to be perfectly fillable later.
    use = _exact[r]

    # Best-fit dominance: -residual strictly orders bins; bonus stays well under 0.5 in magnitude
    score = -residual.astype(np.float64) + 0.2 * use

    # Exact fill always wins.
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _exact[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
