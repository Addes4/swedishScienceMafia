# EVOLVE-BLOCK-START
"""Best fit with strict dominance and a deterministic fullest-bin tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    # Strict best-fit dominance: smaller residual always wins among distinct residuals.
    score = -residual.astype(np.float64) * 1000.0

    # Among equal residuals, prefer the fuller bin (smaller prior remaining capacity = bins).
    score = score - bins.astype(np.float64)

    # Perfect fill gets a large extra bonus.
    score[residual == 0] += 1e9

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
