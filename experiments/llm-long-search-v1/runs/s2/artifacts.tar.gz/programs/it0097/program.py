# EVOLVE-BLOCK-START
"""Best fit with smoothed residual-usefulness tie-break plus a bounded complement-reuse bonus."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
# smoothing kernel over residual sizes: an item of size ~r can fill a bin of residual r or slightly larger
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)  # offsets -2..+2

# accumulated histogram of "filled amounts" (item + residual at placement) to detect common bin sums
_fill = np.zeros(202, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    # smoothed usefulness: probability that a future item can roughly fill this residual
    r = residual.astype(np.int64)
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    use = smoothed[np.clip(r, 0, 100)]

    tight = -residual.astype(np.float64)
    score = tight + 0.5 * use

    # bounded bonus for residuals that bring (item + residual) into a commonly-filled bin sum region
    if _n > 0.0:
        fill = _fill
        tot = item + residual.astype(np.int64)
        tot = np.clip(tot, 0, 201)
        # local density of completed bin-fill sums near tot
        comp = np.zeros(tot.shape, dtype=np.float64)
        for off in (-2, -1, 0, 1, 2):
            idx = np.clip(tot + off, 0, 201)
            w = 1.0 - 0.2 * abs(off)
            comp += w * fill[idx]
        comp = comp / (_n + 1.0)
        score = score + 0.4 * np.tanh(comp)

    score[residual == 0] += 1000.0

    # record this placement's fill sum (item + chosen residual not known here, assume item fills)
    _counts[item] += 1.0
    _n += 1.0
    _sum += item
    # approximate accumulation: the item plus its own size class as a proxy of fill sums
    _fill[min(201, item * 2)] += 1.0

    return score
# EVOLVE-BLOCK-END
