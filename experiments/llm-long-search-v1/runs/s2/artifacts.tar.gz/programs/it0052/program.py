# EVOLVE-BLOCK-START
"""Best fit with a sharpened smoothed-histogram tie-break from the empirical item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0

# A sharper kernel over residual usefulness: an item of size ~r can fill a bin of residual r.
_kernel = np.array([0.05, 0.15, 0.60, 0.15, 0.05], dtype=np.float64)  # offsets -2..+2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    # smoothed usefulness: probability that a future item can roughly fill this residual
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    r = residual.astype(np.int64)
    use = smoothed[r]

    # primary term: best fit (tightest residual). secondary: smoothed fill usefulness.
    tight = -residual.astype(np.float64)
    score = tight + 0.5 * use
    # exact fill gets a decisive bonus
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
