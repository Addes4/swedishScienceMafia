# EVOLVE-BLOCK-START
"""Pure best-fit: place each item in the bin with the smallest fitting residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown
    # best fit: prefer smallest residual; exact fills (residual 0) strongly favored
    score = -residual.astype(np.float64)
    score[residual == 0] += 1000.0
    return score
# EVOLVE-BLOCK-END
