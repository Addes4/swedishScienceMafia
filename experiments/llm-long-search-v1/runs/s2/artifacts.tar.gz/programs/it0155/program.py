# EVOLVE-BLOCK-START
"""Best-fit dominant with a smoothed-histogram complementary-fit tie-break."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_kernel = np.array([0.05, 0.10, 0.20, 0.30, 0.20, 0.10, 0.05], dtype=np.float64)


def priority(item, bins):
    """Prioritize bins; highest score wins, ties go to the first bin."""
    global _n

    residual = bins - item  # >= 0 for all bins shown

    # Smoothed empirical distribution of item sizes seen so far.
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    freq = _counts
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    total = smoothed.sum()
    if total > 0.0:
        smoothed = smoothed / total

    r = residual.astype(np.int64)
    # Probability that residual r is closed exactly by a future item of size r.
    closeout = smoothed[r]

    # Best-fit dominance: -residual differs by >= 1 across distinct residuals.
    tight = -residual.astype(np.float64)

    score = tight + 0.9 * closeout

    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
