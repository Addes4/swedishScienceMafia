# EVOLVE-BLOCK-START
"""Lexicographic best-fit: tightest residual primary, histogram tie-break only on ties."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_kernel = np.array([0.06, 0.12, 0.24, 0.16, 0.24, 0.12, 0.06], dtype=np.float64)
_half = len(_kernel) // 2


def _smoothed():
    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_kernel):
        off = k - _half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]
    return smoothed


def priority(item, bins):
    """Return a priority per bin: lexicographic (min residual, then histogram usefulness)."""
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    for k, w in enumerate(_kernel):
        off = k - _half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    min_r = int(r.min())
    is_min = (r == min_r)
    use = smoothed[r]

    # Primary: tightest residual (smaller better). Secondary: usefulness.
    # Encode lexicographically as -residual dominant, usefulness as small tie-break.
    score = -residual.astype(np.float64) + 1e-3 * use
    # Boost only the tied-minimal-residual bins so they dominate the rest cleanly.
    score += np.where(is_min, 1000.0, 0.0)

    _counts[item] += 1.0
    return score
# EVOLVE-BLOCK-END

