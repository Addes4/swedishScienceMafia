# EVOLVE-BLOCK-START
"""Best fit with a residual-frequency tie-break based on the empirical item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # best fit: prefer smallest post-placement residual
    tight = -residual.astype(np.float64)

    # tie-break: residual equal to a frequently seen item size keeps the bin usable
    freq = _counts
    use = freq[np.minimum(residual, 100)]

    # tightness dominates (unit steps); usefulness only separates true near-ties
    score = tight + 0.05 * use
    # closing a bin is always maximally preferred
    score[residual == 0] += 1000.0

    # update histogram with current item
    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
