# EVOLVE-BLOCK-START
"""Leftover-usability ranking: prefer residuals that are likely to be useful for future items."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _n
    residual = bins - item  # >= 0 for all bins shown

    # Empirical CDF of item sizes: P(random future item <= r).
    # Add a mild Laplace smoothing so early calls still behave sensibly.
    cdf = np.cumsum(_counts) + 1.0
    total = _n + 100.0
    use = cdf[np.clip(residual, 0, 100)] / total

    # Tightness: prefer the smallest residual (best fit). Use residual normalized by
    # capacity so the two terms are comparable.
    tight = -residual.astype(np.float64) / 100.0

    # Combine: best-fit is primary, usefulness of leftover breaks near-ties.
    score = tight + 0.3 * use
    # A closed bin (residual 0) is "fully used"; make it clearly best.
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0

    return score
# EVOLVE-BLOCK-END
