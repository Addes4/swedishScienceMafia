# EVOLVE-BLOCK-START
"""Best fit with an expected-fill-cost tie-break derived from the running item histogram."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_kernel = np.array([0.15, 0.25, 0.35, 0.25, 0.15], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum
    residual = bins - item  # >= 0 for all bins shown

    freq = _counts
    smoothed = np.zeros(101, dtype=np.float64)
    half = len(_kernel) // 2
    for k, w in enumerate(_kernel):
        off = k - half
        lo = max(0, -off)
        hi = min(101, 101 - off)
        smoothed[lo + off:hi + off] += w * freq[lo:hi]

    r = residual.astype(np.int64)
    use = smoothed[r]

    # expected number of future items to close this bin ~ residual / mean item size
    mean = (_sum / _n) if _n > 0 else 40.0
    if mean < 1.0:
        mean = 1.0
    cost = residual.astype(np.float64) / mean

    # primary: prefer tight residual (best fit); secondary: low expected fill cost,
    # tertiary: residual that matches a common item size (easier exact close)
    score = -residual.astype(np.float64) - 1.2 * cost + 0.6 * use
    score[residual == 0] += 1000.0

    _counts[item] += 1.0
    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END

