# EVOLVE-BLOCK-START
"""Best fit with a deterministic consolidation tie-break."""
import numpy as np

_n = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _n, _sum

    residual = bins - item  # >= 0 for all bins shown

    # Strict best-fit dominance: smaller residual is strictly better.
    tight = -residual.astype(np.float64)

    # Tiny, strictly tie-breaking preference: among equal residuals,
    # prefer the fullest bin (consolidation) via a tiny negative residual term
    # already captured by tight; add index-based consolidation among true ties.
    idx = np.arange(len(bins), dtype=np.float64)
    score = tight - 1e-6 * idx

    # Exact fit is strongly dominant but must not override best-fit ordering
    # (an exact fit has residual 0, which is already the smallest residual).
    score[residual == 0] += 1000.0

    _n += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END
