# EVOLVE-BLOCK-START
"""Best-fit with an online-statistics tie-break on the post-placement remainder."""
import numpy as np

_count = np.zeros(101, dtype=np.float64)   # histogram of seen item sizes
_total = 0.0

# Precompute a "future fit value" of a remainder r in 0..100.
# value(r) high if r is close to a common item size (can be filled tightly),
# low if r is stranded far from any common size.
_sizes = np.arange(1, 101)


def _value(r):
    # r: array of possible remainders. Return array of scores.
    if _total < 1:
        # no data yet: neutral
        return np.zeros_like(r, dtype=np.float64)
    p = _count[1:101] / _total          # probability of each size 1..100
    # For a remainder r, best future fill leaves small leftover |r - s|.
    # Expected leftover after placing the best-fitting typical item:
    # weight by closeness: sum_s p[s] * min leftover.
    # Approximate leftover by |r - s|.
    diff = np.abs(r[:, None] - _sizes[None, :])   # (len(r), 100)
    exp_left = (diff * p[None, :]).sum(axis=1)
    return -exp_left                              # higher (less leftover) is better


def priority(item, bins):
    """Rank bins: tightest fit first, with a small nudge from expected future fit."""
    global _total
    rem = bins - item                              # post-placement remainder >= 0
    base = np.asarray(rem, dtype=np.float64)
    v = _value(base)                               # expected leftover (negated)

    # Update histogram with the arriving item.
    if 1 <= int(item) <= 100:
        _count[int(item)] += 1.0
        _total += 1.0

    # Dominant term: smaller remainder is better (tightest fit).
    # Tie-break: smaller expected future leftover is better.
    return -(base * 1000.0) + v
# EVOLVE-BLOCK-END
