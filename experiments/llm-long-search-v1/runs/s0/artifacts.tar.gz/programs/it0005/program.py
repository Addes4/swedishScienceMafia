# EVOLVE-BLOCK-START
"""Residual-cost bin choice: minimize the squared leftover capacity after placement."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item
    return -(rem.astype(np.float64) ** 2)
# EVOLVE-BLOCK-END
