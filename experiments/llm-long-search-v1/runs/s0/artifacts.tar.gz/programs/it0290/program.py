# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break based on a running mean and a
histogram of seen item sizes (to nudge residuals toward frequently reusable sizes)."""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100), used to reward residuals that match
# a common leftover size.
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    # Penalize residuals that are positive but smaller than a typical item:
    # such slivers are effectively wasted capacity.
    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Small bonus for very tight fits (residual 0) to strongly prefer exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Data-driven complement bonus: reward residuals that equal a frequently
    # seen item size so far, since such a leftover is the size most likely to
    # be reusable by a future item.  Use the full histogram (smoothed) rather
    # than a single mode to reduce noise.
    r = residual
    valid = r >= 1
    if _count > 0:
        h = _hist[1:].copy()
        # light smoothing so unseen-but-near-large values still get credit
        hs = h + 0.5 * np.concatenate(([0.0], h[:-1])) + 0.5 * np.concatenate((h[1:], [0.0]))
        total = hs.sum()
        if total > 0:
            prob = hs / total
        else:
            prob = np.zeros_like(hs)
        # map residuals (1..100) to the histogram index; residuals > 100 impossible
        idx = np.clip(r - 1, 0, 99)
        reuse = np.where(valid, prob[idx], 0.0)
    else:
        reuse = np.zeros_like(r, dtype=np.float64)
    complement = reuse * 300.0

    # Waste-aware term: a residual just below the mean item size will likely
    # never be reused and is effectively lost capacity.
    near_full = (residual > 0) & (residual < m)
    waste = np.where(near_full, (1.0 - residual / m) * 1.0, 0.0)

    return tightness - penalty + exact + complement - waste
# EVOLVE-BLOCK-END

