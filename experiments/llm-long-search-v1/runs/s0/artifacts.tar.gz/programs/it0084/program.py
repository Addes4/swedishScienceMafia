# EVOLVE-BLOCK-START
"""Worst-fit onto open (partially used) bins, only opening a fresh bin when necessary."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    empty = bins == 100
    # Prefer partially-used bins (not empty) over empty ones, and among
    # partially-used bins choose the one with the largest remaining capacity
    # (worst fit) to keep open bins balanced and avoid fragmentation.
    return np.where(empty, bins - item - 1000, -(bins))
# EVOLVE-BLOCK-END
