# EVOLVE-BLOCK-START
"""Best fit with a tie-break that prefers residuals matching the most
frequently seen item size so far (to make leftovers more reusable)."""
import numpy as np

_count = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _count, _hist

    # Record this item for the histogram used in tie-breaking.
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Dominant best-fit term: strictly prefer smaller residual.
    score = -residual.astype(np.float64)

    # Tie-break only: among equal residuals, prefer one equal to the most
    # commonly seen item size so far (more likely to be reusable later).
    modal = int(np.argmax(_hist[1:])) + 1
    tie = (residual == modal).astype(np.float64) * 1e-6

    return score + tie
# EVOLVE-BLOCK-END
