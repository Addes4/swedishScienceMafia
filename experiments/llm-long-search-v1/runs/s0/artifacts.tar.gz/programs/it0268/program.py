# EVOLVE-BLOCK-START
"""Best fit with a strictly-subordinate tie-break that, among bins whose residual
is the same, prefers residuals that are large enough to still be reusable by a
typical future item over dead slivers. The tie-break uses a scale < 1 so the
primary best-fit ordering (smaller residual) is never disturbed."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = (bins - item).astype(np.float64)  # remaining capacity after placing here

    # Primary term: best-fit => prefer smaller residual (strict ordering).
    tightness = -residual

    # Strictly subordinate tie-break in [-0.5, 0.5): among equal residuals this
    # prefers residuals >= the running mean (reusable by a typical future item)
    # over smaller dead slivers, and prefers exact fills most.
    m = _mean
    frac = np.clip(residual / (m if m > 1.0 else 1.0), 0.0, 1.0)
    tiebreak = 0.5 * frac
    tiebreak = np.where(residual == 0.0, 0.49, tiebreak)

    return tightness + tiebreak
# EVOLVE-BLOCK-END
