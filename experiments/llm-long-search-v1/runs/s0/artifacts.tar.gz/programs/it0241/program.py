# EVOLVE-BLOCK-START
"""Best fit with a recency-weighted histogram tie-break that nudges residuals
toward sizes that have recently been reusable, without disturbing the dominant
best-fit ordering (the bonus is bounded well below 1 capacity unit)."""
import numpy as np

# Recency-weighted counts of seen item sizes (1..100). Older observations decay,
# so the histogram tracks the current "reusable leftover" sizes.
_hist = np.zeros(101, dtype=np.float64)
_decay = 0.9995


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist

    residual = bins - item  # remaining capacity after placing the item here

    # Dominant best-fit: prefer the smallest (tightest) residual.
    score = -residual.astype(np.float64)

    # Bounded tie-break bonus: reward residuals equal to a size that has been
    # seen recently (likely reusable later). Weighted by recency-normalized
    # frequency, but capped below 1.0 so it never overrides best-fit.
    total = _hist.sum()
    if total > 0:
        freq = _hist / total
        r = residual
        valid = (r >= 1) & (r <= 100)
        # Map each valid residual to its recency-frequency via fancy indexing.
        idx = np.where(valid, r, 0).astype(np.int64)
        bonus = freq[idx] * valid.astype(np.float64)
        # Scale so the maximum possible bonus is < 1.0.
        score = score + bonus * 0.99

    # Update the recency-weighted histogram AFTER scoring.
    _hist *= _decay
    _hist[item] += 1.0

    return score
# EVOLVE-BLOCK-END
