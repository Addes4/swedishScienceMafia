# EVOLVE-BLOCK-START
"""Best fit with a mild histogram tie-break: prefer the smallest post-placement
residual; break exact-residual ties in favor of a leftover that matches a
frequently seen item size (so the leftover is likely reusable later)."""
import numpy as np

_count = 0
# Histogram of seen item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _count, _hist

    # Update histogram of past items (before scoring this one).
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Dominant rule: best fit (prefer smallest residual).
    tightness = -residual.astype(np.float64) * 1000.0

    # Tie-break on equal residual: reward leftovers equal to a frequent item size.
    r = residual
    valid = r >= 1
    r_idx = np.where(valid, r, 0).astype(np.int64)
    freq = np.where(valid, _hist[r_idx] / _count, 0.0)

    return tightness + freq
# EVOLVE-BLOCK-END
