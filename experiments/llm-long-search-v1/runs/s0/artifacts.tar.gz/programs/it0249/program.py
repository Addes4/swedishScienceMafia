# EVOLVE-BLOCK-START
"""Best-fit with a bounded sliver-avoidance correction: strongly prefer the
smallest feasible residual (classic best fit), but mildly penalize leaving a
small positive residual that is much less than a typical item, since such
slivers are effectively wasted capacity. A fixed reference mean of 40 is used
so the rule is data-independent and does not chase per-instance noise."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the
    highest-scoring bin (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin
          order.
    """
    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Best-fit core: prefer the smallest residual (largest -residual).
    tightness = -r

    # Sliver avoidance: penalize small positive residuals that are unlikely to
    # be reusable by a future item (bounded, never overrides a real difference
    # in fit strength for reasonable item sizes).
    m = 40.0
    sliver = (r > 0) & (r < m)
    penalty = np.where(sliver, (m - r) / m, 0.0)

    return tightness - penalty
# EVOLVE-BLOCK-END
