# EVOLVE-BLOCK-START
"""Best fit with an online-calibrated 'fillable residual' adjustment.

For each bin, the post-placement remainder r = bins[i] - item.  Pure best fit
minimises r.  Here we score by tightness but add a mild bonus for remainders
that are close to a running estimate of the typical item size (so the leftover
gap is likely to be filled by future items) and a mild penalty for remainders
that are large enough to be wasteful but not aligned with typical items.
The bonus is kept small so best-fit behaviour dominates.
"""
import numpy as np


def priority(item, bins):
    # Online statistics of past items (state between calls).
    state = priority.__dict__
    n = state.get("n", 0) + 1
    total = state.get("total", 0.0) + item
    state["n"] = n
    state["total"] = total
    mean_size = total / n

    remainder = bins - item

    # Base: best fit (prefer smallest remainder).
    score = -remainder.astype(np.float64)

    # Bonus for remainders near the running mean item size (fillable gaps).
    # Scale ~ a fraction of an item so it only breaks near-ties.
    bonus = -np.abs(remainder - mean_size).astype(np.float64)
    score += 0.35 * bonus

    return score
# EVOLVE-BLOCK-END
