# EVOLVE-BLOCK-START
"""Best-fit with a secondary tie-break favoring small/useful remainders."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    # Primary: smaller residual (best fit). Secondary: reward small remainders
    # (<= 33) since they pack efficiently with small items; mildly reward full (0).
    # Scale secondary tiny so it only breaks ties / near-ties.
    small = (residual <= 33).astype(np.float64)
    return -residual.astype(np.float64) + 1e-3 * small
# EVOLVE-BLOCK-END
