# EVOLVE-BLOCK-START
"""Best fit with a strong exact-fill bonus and a stable small-residual
usability nudge, keeping the noise-prone histogram terms out."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here
    m = _mean

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -residual.astype(np.float64)

    # Penalize residuals that are positive but smaller than a typical item:
    # such slivers are effectively wasted capacity.
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 8.0

    # Stable usability bonus: residuals near the running mean are the most
    # likely to be refillable by a single upcoming item.
    r = residual
    valid = r > 0
    refill = np.where(valid, -(np.abs(r - m) / max(m, 1.0)) * 2.0, 0.0)

    return tightness - penalty + exact + refill
# EVOLVE-BLOCK-END

