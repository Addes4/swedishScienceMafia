# EVOLVE-BLOCK-START
"""Best fit, softly biased toward remainders that a typical next item can fill."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # remaining capacity after placing the item
    # running mean of item sizes (fallback 40)
    _state["sum"] += item
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]

    # Base: prefer tight fits (small remainder).
    score = -rem.astype(np.float64)

    # Soft bonus: remainders close to a typical item size are likely fillable.
    # Weight is small so it only breaks near-ties among tight fits.
    score -= 0.02 * np.abs(rem - mean)

    return score
# EVOLVE-BLOCK-END
