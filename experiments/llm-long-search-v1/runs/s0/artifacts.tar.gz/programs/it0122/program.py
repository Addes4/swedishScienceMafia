# EVOLVE-BLOCK-START
"""Best fit with a soft residual-usability penalty based on a running mean item size."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (before scoring this one, then include it).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = (bins - item).astype(np.float64)  # remaining capacity after placing here

    # Best-fit tightness: prefer smaller residual (slightly scaled down so the
    # usability term below can dominate among near-tied residuals).
    tightness = -0.5 * residual

    # Soft "wasted capacity" estimate: a positive residual smaller than a typical
    # item is likely to remain unusable, so penalize it smoothly, peaking around
    # half the mean item size and vanishing for exact fits and large residuals.
    m = _mean if _mean > 1.0 else 1.0
    frac = residual / m
    # Waste weight: ~1 for slivers near m/2, ~0 for residual==0 or residual>=m.
    waste_weight = 4.0 * frac * (1.0 - frac)
    waste_weight = np.where((residual > 0) & (residual < m), waste_weight, 0.0)
    penalty = waste_weight * residual

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    return tightness - penalty + exact
# EVOLVE-BLOCK-END
