# EVOLVE-BLOCK-START
"""Best fit: place item in the bin with the smallest post-placement remainder."""
import numpy as np


def priority(item, bins):
    """Higher score wins; ties go to the first bin.

    Best fit: minimizes the leftover capacity after placing the item.
    """
    return -(bins - item)
# EVOLVE-BLOCK-END
