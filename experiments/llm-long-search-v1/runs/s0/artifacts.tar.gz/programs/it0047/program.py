# EVOLVE-BLOCK-START
"""Best fit with a quadratic (sum-of-squares) residual ranking.

Scoring a bin by the negative square of the residual gap is equivalent to
preferring the tightest fit, but it additionally concentrates the ranking so
that a small improvement in the gap dominates the tie-breaking and slightly
rewards consolidating into fuller bins.  This is a cheap, vectorised variant
of Best Fit that avoids fragmentation without expensive per-call work.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    gap = bins - item
    # Prefer tightest fit via negative squared gap; add a tiny consolidation
    # bonus proportional to how full the bin already is.
    return -(gap.astype(np.float64) ** 2) + 0.01 * (100.0 - bins)
# EVOLVE-BLOCK-END
