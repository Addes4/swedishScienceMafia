# EVOLVE-BLOCK-START
"""Best fit with a data-driven residual-usability tie-break.

Primary ordering is best-fit (smallest residual). Additional soft terms use a
running histogram of seen item sizes to reward leftovers that future items can
reuse (via the empirical CDF), penalize slivers, and mildly favor exact fills.
"""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100), used to estimate the distribution.
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -residual.astype(np.float64)

    m = _mean
    r = residual

    # Penalize slivers: positive residuals smaller than a typical item are
    # effectively wasted capacity.
    sliver = (r > 0) & (r < m)
    penalty = np.where(sliver, (m - r) * 2.0, 0.0)

    # Strongly prefer exact fills.
    exact = (r == 0).astype(np.float64) * 5.0

    # Data-driven reusability: probability that a future item (drawn from the
    # observed distribution) fits in the residual = P(item <= residual).
    valid = r >= 1
    r_idx = np.where(valid, r, 0).astype(np.int64)
    if _count > 0:
        cdf = np.cumsum(_hist) / _count  # cdf[k] = P(item <= k)
        reuse = np.where(valid, cdf[r_idx], 0.0)
    else:
        # Fall back to a smooth heuristic before any data: r/m scaled.
        reuse = np.where(valid, np.minimum(r / m, 1.0), 0.0)
    complement = reuse * 3.0

    # Waste-aware term: a residual just below the mean item size is likely
    # never reused, so add a mild extra penalty the closer it is to the mean.
    near_full = (r > 0) & (r < m)
    waste = np.where(near_full, (1.0 - r / m) * 1.0, 0.0)

    return tightness - penalty + exact + complement - waste
# EVOLVE-BLOCK-END
