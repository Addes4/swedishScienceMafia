# EVOLVE-BLOCK-START
"""Best fit with a tiny residual-matching bonus for remainders likely fillable exactly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item
    # Primary: tightest fit (smallest remainder).
    score = -rem.astype(np.float64)
    # Secondary bonus: remainders that are exactly fillable later are attractive.
    # Small bonus only, so it breaks near-ties without disturbing the tightness order.
    fillable = (rem == 0) | ((rem >= 1) & (rem <= 100))
    # Prefer remainder that itself could equal a typical item size (~40) strongly fillable.
    bonus = np.where((rem == 0), 0.25, 0.0)
    # Favor remainders in the common item-size region (roughly 20..60).
    bonus = bonus + np.where((rem >= 20) & (rem <= 60), 0.05, 0.0)
    return score + bonus
# EVOLVE-BLOCK-END

