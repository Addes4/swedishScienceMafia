# EVOLVE-BLOCK-START
"""Best fit with a slight preference for fuller bins (consolidation)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    gap = bins - item
    # Primary: tightest fit (smallest gap). Secondary: prefer fuller bins
    # (smaller remaining capacity) so partial bins get consolidated.
    # Weight chosen small so we stay near best-fit.
    used = 100 - bins
    return -gap + 0.05 * used
# EVOLVE-BLOCK-END
