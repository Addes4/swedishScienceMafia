# EVOLVE-BLOCK-START
"""Best fit with a data-driven residual-usability refinement.

Primary rule: best-fit (smallest residual). Soft terms:
 - sliver penalty scaled by running mean,
 - exact-fill bonus,
 - complement bonus rewarding residuals matching frequent item sizes,
 - waste-aware term distinguishing reusable leftovers from dead slivers.
"""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _mean, _count, _hist

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    exact = (residual == 0).astype(np.float64) * 5.0

    r = residual
    valid = r >= 1
    r_idx = np.where(valid, r, 0).astype(np.int64)
    if _count > 0:
        freq = _hist[r_idx] / _count
    else:
        freq = np.zeros_like(r, dtype=np.float64)
    freq = np.where(valid, freq, 0.0)
    complement = freq * 3.0

    near_full = (residual > 0) & (residual < m)
    waste = np.where(near_full, (1.0 - residual / m) * 1.0, 0.0)

    # Data-driven usability of the resulting residual: fraction of seen items
    # that would still fit into this residual (capped at residual size).
    # A residual that can host many typical items is genuinely useful, while
    # a residual too small for common items is effectively dead capacity.
    if _count > 0 and len(r) > 0:
        cum = np.cumsum(_hist) / _count  # cum[s] = P(item <= s)
        rr = np.clip(r_idx, 0, 100)
        # P(item <= residual) approximated: residual can fit items up to its size
        can_fit_frac = cum[rr]
        can_fit_frac = np.where(valid, 1.0 - can_fit_frac, 0.0)  # P(item > residual) -> dead if high
    else:
        can_fit_frac = np.zeros_like(r, dtype=np.float64)

    dead = np.where(valid, can_fit_frac * 1.5, 0.0)

    return tightness - penalty + exact + complement - waste - dead
# EVOLVE-BLOCK-END
