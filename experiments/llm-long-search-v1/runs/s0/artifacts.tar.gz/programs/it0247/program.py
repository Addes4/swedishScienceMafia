# EVOLVE-BLOCK-START
"""Best fit with a bounded, fixed-mean sliver penalty plus an exact-fill bonus.

Residuals smaller than a typical item size are effectively wasted capacity, so
they get a mild, bounded penalty.  Best-fit ordering dominates; the small
corrections only break near-ties toward leaving a reusable leftover.
"""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -r

    # Prefer exact fills strongly so we never needlessly open/fill a new bin.
    exact = (r == 0).astype(np.float64) * 5.0

    # Mild, bounded penalty for "sliver" residuals: positive but smaller than a
    # typical item size, which are unlikely to be reusable.  Bounded in [0, 1]
    # so it never overrides best-fit ordering, only near-ties.
    m = _MEAN
    sliver = (r > 0) & (r < m)
    penalty = np.where(sliver, (1.0 - r / m), 0.0)

    return tightness + exact - penalty
# EVOLVE-BLOCK-END
