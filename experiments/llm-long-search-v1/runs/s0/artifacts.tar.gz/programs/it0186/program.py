# EVOLVE-BLOCK-START
"""Best fit plus a light perfect-pairing tie-break.

Preserve best-fit tightness (smallest positive residual dominates), then break
ties by rewarding residuals exactly equal to the current item size so that two
identical items can fill a bin together, reducing fragmentation.
"""
import numpy as np

_prev_item = -1


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _prev_item

    residual = bins - item  # remaining capacity after placing the item here

    # Dominant term: best-fit tightness (smaller residual preferred).
    tightness = -residual.astype(np.float64)

    # Deterministic sub-1 tie-break: reward placing into a bin whose residual
    # exactly equals the current item size (perfect pairing of equal items).
    pair = (residual == item).astype(np.float64) * 0.5

    _prev_item = item
    return tightness + pair
# EVOLVE-BLOCK-END
