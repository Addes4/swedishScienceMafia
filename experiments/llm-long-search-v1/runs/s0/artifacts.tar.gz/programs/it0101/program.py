# EVOLVE-BLOCK-START
"""Hybrid best-fit with learned residual-closing bias.

Pure best-fit minimizes immediate waste but often leaves tiny unusable remainders.
By tracking a histogram of past items we can bias small/medium items toward
producing remainders equal to common item sizes (closing bins exactly), while
large items still go to the tightest fit.
"""
import numpy as np

# module-level state, reset lazily per instance by tracking a call counter
_state = {"n": 0, "hist": np.zeros(101, dtype=np.float64)}
_EXPECTED = 1000


def _reset():
    _state["n"] = 0
    _state["hist"][:] = 0.0


def priority(item, bins):
    """Return a priority per bin; highest score wins (first on ties)."""
    n = _state["n"]
    hist = _state["hist"]

    # Weibull(mean~40) shaped weights: approximate common item sizes.
    # Exponential decay centered near small/mid sizes; used only as a prior.
    if n < 50:
        # prior: gamma-ish weights favoring 10..60
        prior = np.exp(-((np.arange(101) - 35.0) ** 2) / (2 * 20.0 ** 2))
    else:
        prior = None

    # combined weight for each candidate remainder
    if prior is not None:
        w = prior
    else:
        h = hist / max(n, 1)
        # smooth histogram
        k = np.array([0.1, 0.2, 0.4, 0.2, 0.1])
        s = np.convolve(h, k, mode="same")
        w = 0.5 * s + 0.5 * np.exp(-((np.arange(101) - 35.0) ** 2) / (2 * 20.0 ** 2))
        w = w / (w.max() + 1e-9)

    # record this item after computing (online: only past items)
    _state["n"] = n + 1
    if item <= 100:
        hist[item] += 1.0

    bins = np.asarray(bins)
    rem = bins - item  # post-placement remainder, >= 0 guaranteed

    # tightness term: strongly prefer small remainder (best fit)
    tight = -(rem.astype(np.float64))

    # residual-closing bonus: prefer remainders that are common future items
    # index into weight vector (remainder 0 = closed, also good)
    idx = np.clip(rem, 0, 100)
    bonus = w[idx]
    bonus = np.where(rem == 0, 1.0, bonus)  # exact closure is ideal

    # Scale bonus by how "small" the item is: large items care about tightness,
    # small items can afford to chase good remainders. Item size proxy = rarity.
    item_weight = 1.0 - min(item, 100) / 200.0  # 1.0 for item=0, 0.5 for item=100

    return tight + item_weight * bonus * 5.0
# EVOLVE-BLOCK-END
