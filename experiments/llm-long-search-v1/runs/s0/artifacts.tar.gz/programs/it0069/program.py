# EVOLVE-BLOCK-START
"""Best fit with concave waste weighting and online size statistics."""
import numpy as np

_state = {
    "n": 0,
    "mean": 40.0,
}

# helper: cached quantile-ish estimate of a "typical" item size
def _typical():
    return _state["mean"]


def priority(item, bins):
    n = _state["n"]
    mean = _state["mean"]
    # update running mean of item sizes (for a typical fill target)
    if n == 0:
        _state["mean"] = float(item)
    else:
        _state["mean"] = mean + (float(item) - mean) / (n + 1)
    _state["n"] = n + 1
    typ = _state["mean"]

    rem = bins - item  # remaining capacity after placing item (>=0 since bins fit item)
    # Penalize small remainders (likely wasted): concave weighting of waste.
    # score high for small non-trivial remainder; avoid tiny remainders.
    # weight = -rem + bonus for remainders near a typical item size
    score = -(rem.astype(np.float64))
    # discourage remainders that are too small to be useful (below ~half typical)
    tiny = rem < (0.5 * typ)
    score[tiny] -= (0.5 * typ - rem[tiny]) * 0.5
    # slight bonus for remainders close to a typical item size (closure potential)
    score -= 0.1 * np.abs(rem - typ)
    return score
# EVOLVE-BLOCK-END
