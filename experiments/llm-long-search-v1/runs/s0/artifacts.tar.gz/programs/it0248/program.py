# EVOLVE-BLOCK-START
"""Best-fit core with a data-driven, bounded penalty for leaving a small sliver
residual (dead capacity) plus a bonus for leaving a residual equal to a
frequently seen item size (likely reusable)."""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _mean, _count, _hist

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # capacity left if placed here
    m = _mean

    # Strong best-fit term: smaller residual is strictly better.
    tightness = -residual.astype(np.float64)

    # Bounded penalty: a positive residual smaller than half a typical item is
    # nearly dead capacity. Cap at 3 so it only breaks near-ties.
    sliver = (residual > 0) & (residual < 0.5 * m)
    penalty = np.where(sliver, np.minimum((0.5 * m - residual) * 0.3, 3.0), 0.0)

    # Bonus when the leftover exactly equals a common seen item size.
    modal = int(np.argmax(_hist[1:])) + 1 if _count > 0 else 0
    match = (residual == modal).astype(np.float64)
    complement = match * 1.5

    return tightness - penalty + complement
# EVOLVE-BLOCK-END
