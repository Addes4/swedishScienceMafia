# EVOLVE-BLOCK-START
"""Best fit with a deterministic bias toward residuals near the typical item size."""
import numpy as np


def priority(item, bins):
    """Rank bins: exact fits first, else best-fit, with a mild bias to a 40-ish residual."""
    residual = bins - item
    # Prefer exact fits strongly.
    score = -(residual.astype(np.float64))
    # Bias: reward residuals close to the mean future item size (~40), penalize far ones.
    # Only active for near-ties in residual since the spread of the bias is < 1.
    score += -0.001 * np.abs(residual - 40.0)
    return score
# EVOLVE-BLOCK-END

