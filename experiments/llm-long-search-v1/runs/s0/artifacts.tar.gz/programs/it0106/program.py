# EVOLVE-BLOCK-START
"""Spread-fit: prefer tight fits but discourage repeatedly leaving small unusable gaps."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_seen = 0.0


def priority(item, bins):
    # update running histogram of item sizes (for tie-breaking statistics)
    global _seen
    if _seen > 1e6:
        _hist *= 0.5
        _seen *= 0.5
    _hist[item] += 1.0
    _seen += 1.0

    rem = bins.astype(np.float64) - float(item)  # post-placement remainder
    tight = -(bins.astype(np.float64) - float(item))  # best-fit: smaller remainder preferred

    # penalty for leaving a small but non-zero remainder (likely unusable waste)
    small_waste = ((rem > 0) & (rem < 5)).astype(np.float64)

    # tiny exact-fit boost
    exact = (rem == 0).astype(np.float64)

    return tight - 0.001 * small_waste + 0.0001 * exact
# EVOLVE-BLOCK-END
