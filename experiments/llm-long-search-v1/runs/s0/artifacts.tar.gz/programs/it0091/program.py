# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware residual bonus.

Among bins the item fits in, prefer the tightest fit (small remainder), but add a bonus
for remainders that are likely to be exactly fillable by a future item, estimated from the
empirical distribution of items seen so far.
"""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    # update empirical item-size distribution (size 1..100)
    c = _state["counts"]
    c[item] += 1.0
    _state["n"] += 1.0

    rem = bins - item  # remainder after placing item

    # best-fit base term: prefer small remainder (tight fit)
    base = -rem.astype(np.float64)

    # distribution-aware bonus: reward remainders that are likely fillable exactly.
    # probability that remainder r can be exactly matched by some future single item
    # is roughly (count of items equal to r) / n; scale modestly so it only breaks ties.
    n = _state["n"]
    if n < 20:
        return base

    prob = c / n
    # clip remainder index into valid range
    idx = np.clip(rem, 0, 100).astype(np.int64)
    bonus = prob[idx]
    # zero the bonus for remainder 0 (already perfectly full) - it's ideal on its own;
    # actually r==0 means bin exactly filled, keep tiny bonus removed to not disturb.
    bonus = np.where(rem == 0, 0.0, bonus)

    # weight chosen small relative to base differences (base spans up to 100)
    return base + 3.0 * bonus
# EVOLVE-BLOCK-END
