# EVOLVE-BLOCK-START
"""Best fit with tiny non-disruptive tie-breaks based on a running mean and a
histogram of seen item sizes (to nudge residuals toward frequently reusable sizes)."""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100), used to reward residuals that match
# a common leftover size.
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual. This is the dominant term;
    # all others are scaled small enough to only break ties.
    tightness = -residual.astype(np.float64)

    m = _mean

    # Tiny exact-fill bonus: breaks ties toward a cleanly emptied bin.
    exact = (residual == 0).astype(np.float64) * 1e-3

    # Tiny complement bonus: reward residuals matching the most frequently
    # seen item size so far (most likely reusable leftover).
    r = residual
    valid = r >= 1
    if _count > 0:
        modal = int(np.argmax(_hist[1:])) + 1
        match = (valid & (r == modal)).astype(np.float64)
    else:
        match = np.zeros_like(r, dtype=np.float64)
    complement = match * 1e-3

    # Tiny waste penalty for dead slivers (positive residual below the mean),
    # again small enough not to disturb strict best-fit ordering.
    sliver = (residual > 0) & (residual < m)
    waste = np.where(sliver, (1.0 - residual / m), 0.0) * 1e-3

    return tightness + exact + complement - waste
# EVOLVE-BLOCK-END

