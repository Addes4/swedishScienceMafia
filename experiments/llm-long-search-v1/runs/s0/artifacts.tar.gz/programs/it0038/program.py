# EVOLVE-BLOCK-START
"""Best-fit with quantized remainders: bins that end up in the same capacity class are
treated as equal, breaking ties toward the emptier bin to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    rem = bins - item
    # Quantize the remainder into coarse classes (25-unit buckets) so near-ties in
    # fit become genuine ties, avoiding best-fit's tendency to nibble tiny remainders.
    cls = rem // 25
    primary = -cls.astype(np.float64)          # prefer fuller classes (small remainder)
    secondary = -rem.astype(np.float64)        # within class, tightest fit
    tertiary = bins.astype(np.float64)         # final tie-break: emptier bin (balance)
    return primary * 1e6 + secondary * 1e3 + tertiary
# EVOLVE-BLOCK-END
