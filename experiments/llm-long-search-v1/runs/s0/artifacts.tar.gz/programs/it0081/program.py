# EVOLVE-BLOCK-START
"""Best fit with a remainder-band tie-break tuned to keep residual space fillable."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    bins = np.asarray(bins, dtype=np.int64)
    rem = bins - item  # post-placement remainder, >= 0
    # Primary: best fit (smallest remainder). Secondary tiny push toward
    # remainders around 30-60 which match the bulk of the item distribution,
    # keeping residual space fillable by typical future items.
    band = rem.astype(np.float64)
    # Distance from a favorable band [25, 65]
    d = np.maximum(0.0, np.maximum(25.0 - band, band - 65.0))
    return -band - 0.02 * d
# EVOLVE-BLOCK-END
