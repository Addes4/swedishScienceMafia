# EVOLVE-BLOCK-START
"""Best fit with a data-driven complement bonus: reward residuals whose size is
frequent among seen items, so the leftover is likely reusable by a future item."""
import numpy as np

_count = 0
# Histogram of seen item sizes (1..100), used to score how reusable a residual is.
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _hist

    # Update histogram of past items (before scoring this one).
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    # Small bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Data-driven complement bonus: reward residuals whose value is a common
    # seen item size (likely to be refilled exactly later), scaled by frequency.
    r = residual
    valid = (r >= 1) & (r <= 100)
    freq = np.zeros_like(r, dtype=np.float64)
    if _count > 0:
        freq[valid] = _hist[r[valid]]
        freq /= _count
    complement = freq * 1000.0

    return tightness + exact + complement
# EVOLVE-BLOCK-END
