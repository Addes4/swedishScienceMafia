# EVOLVE-BLOCK-START
"""Best fit with near-tie consolidation: tighten on residual, break close ties by fullness."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # leftover capacity after placing the item
    gap = residual.astype(np.float64)

    # Among bins whose residual is close to the minimum, prefer the fullest bin
    # (smallest residual overall). Tolerance scales mildly with item size.
    min_gap = gap.min()
    tol = 0.05 * item + 0.5

    # Primary: tightest fit (negated gap). Consolidation bonus among near-ties:
    # fullness = 100 - bins, but only applied when the gap is within tolerance.
    load = (100 - bins).astype(np.float64)
    near = (gap <= min_gap + tol).astype(np.float64)

    # Small weight so it only breaks near-ties, never overrides a clearly tighter fit.
    return -gap + 0.01 * near * load
# EVOLVE-BLOCK-END
