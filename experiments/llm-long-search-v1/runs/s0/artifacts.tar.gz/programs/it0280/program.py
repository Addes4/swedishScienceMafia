# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break based on a running mean and a
distribution over seen item sizes (to nudge residuals toward frequently reusable sizes)."""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100), used to reward residuals that match
# a common leftover size.
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    # Penalize residuals that are positive but smaller than a typical item:
    # such slivers are effectively wasted capacity.
    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Small bonus for very tight fits (residual 0) to strongly prefer exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Data-driven complement bonus: reward residuals whose value is a very
    # common, small item size, since such leftovers are the most likely to be
    # reusable by a future (frequently small) item.
    r = residual
    valid = r >= 1
    if _count > 0:
        # Smooth reuse value: probability-like mass of the residual size in the
        # empirical histogram, but only up to a modest scale so it refines
        # ordering without disturbing best-fit.
        reuse = np.zeros_like(r, dtype=np.float64)
        # clip residual indices into [0, 100]
        idx = np.clip(r, 0, 100).astype(np.int64)
        counts = _hist[idx]
        maxc = _hist.max()
        if maxc > 0:
            reuse = valid * (counts / maxc)
    else:
        reuse = np.zeros_like(r, dtype=np.float64)
    complement = reuse * 2.0

    # Waste-aware term: a residual just below the mean is effectively lost
    # capacity, so add a mild extra penalty scaled by how close it is to the mean.
    near_full = (residual > 0) & (residual < m)
    waste = np.where(near_full, (1.0 - residual / m) * 1.0, 0.0)

    return tightness - penalty + exact + complement - waste
# EVOLVE-BLOCK-END
