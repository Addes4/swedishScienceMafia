# EVOLVE-BLOCK-START
"""Best fit with a small residual-based tie-breaker."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    rem = bins - item
    # Primary: tightest fit (larger rem is worse).
    # Secondary: slight preference for remainders that are either 0 (perfect fill)
    # or close to the item size (reusable), reducing fragmentation.
    return -rem + 0.02 * np.minimum(rem, item)
# EVOLVE-BLOCK-END

