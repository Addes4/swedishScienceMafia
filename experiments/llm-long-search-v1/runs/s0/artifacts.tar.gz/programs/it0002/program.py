# EVOLVE-BLOCK-START
"""Best fit with a fragmentation-aware tie-break on the resulting remainder."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tightest fit, but break ties using the leftover remainder.

    The item goes to the highest-scoring bin. We compute the remainder each bin
    would have after receiving the item, then reward remainders that are either
    very small (nearly sealed bin) or large enough to still hold a typical
    future item (~40), and penalize medium remainders that fragment capacity.
    """
    rem = bins - item  # remaining capacity if item placed here
    # score: tightest fit first; among ties, prefer "good" remainders.
    # smaller rem -> larger -(rem) term
    # good remainder: <= 5 (sealed) or >= 40 (still usable) get a bonus.
    good = (rem <= 5) | (rem >= 40)
    return -(rem.astype(np.float64)) + 0.5 * good
# EVOLVE-BLOCK-END
