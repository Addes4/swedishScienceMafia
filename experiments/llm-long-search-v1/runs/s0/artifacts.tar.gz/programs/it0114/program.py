# EVOLVE-BLOCK-START
"""Hybrid: best fit normally, but consolidate large items into already-used bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit score: prefer the bin that leaves the smallest usable residual.
    best_fit = -(bins - item)

    if item >= 40:
        # For large items, consolidate: strongly prefer fuller (lower remaining) bins
        # that still fit, so large items stack together instead of opening new bins.
        return -bins

    return best_fit
# EVOLVE-BLOCK-END
