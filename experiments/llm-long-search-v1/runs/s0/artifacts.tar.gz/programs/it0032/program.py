# EVOLVE-BLOCK-START
"""Best fit with a secondary preference for larger useful remainders."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary rule: best fit (smallest post-placement remainder).
    Secondary rule (tie-break only): among equally tight fits, prefer the bin
    that still leaves a remainder large enough to accept the typical item,
    which avoids wasting a bin on a remainder that can never be used again.
    """
    rem = bins - item
    # Primary: small rem is good -> large -(rem).
    # Secondary encoded in the fractional part so it only breaks exact ties.
    useful = rem >= 20  # remainder still usable by many item sizes
    return -(rem.astype(np.float64)) + 1e-6 * useful
# EVOLVE-BLOCK-END
