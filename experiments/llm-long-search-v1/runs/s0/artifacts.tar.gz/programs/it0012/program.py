# EVOLVE-BLOCK-START
"""Best-fit with penalty on hard-to-reuse middle remainders."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item
    # Base: prefer smaller remainder (best fit)
    score = -rem.astype(np.float64)
    # Penalize remainders in the "wasted middle" range (hard to reuse with mean-40 items)
    wasted = (rem > 0) & (rem < 40)
    score -= wasted.astype(np.float64) * 2.0
    return score
# EVOLVE-BLOCK-END
