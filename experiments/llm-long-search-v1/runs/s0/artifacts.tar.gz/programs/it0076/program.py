# EVOLVE-BLOCK-START
"""Best fit with a small index-aware tie-break that prefers fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = bins.shape[0]
    # Tightest fit dominates: smaller remainder -> higher score.
    tight = -(bins - item)
    # Tiny index-based nudge: among equal remainders, prefer earlier (fuller) bins,
    # which are more likely to be genuinely used bins rather than fresh empty ones.
    nudge = -np.arange(n) * 1e-6
    return tight + nudge
# EVOLVE-BLOCK-END

