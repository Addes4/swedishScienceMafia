# EVOLVE-BLOCK-START
"""Best fit: prefer the smallest residual after placement, with a strong
exact-fill bonus. Best-fit ordering strictly dominates; only exact fills and
true near-ties are influenced by the tie-break terms."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Strict best-fit: smallest residual wins. Large factor so residual
    # differences dominate any tie-break terms below.
    tightness = -residual.astype(np.float64) * 100.0

    # Strong bonus for exact fills (residual 0): never open/leave slack when a
    # perfect fit is available.
    exact = (residual == 0).astype(np.float64) * 50.0

    # Mild penalty for tiny slivers (residual positive but very small): such
    # leftovers are effectively wasted capacity.
    sliver = (residual > 0) & (residual < 10)
    penalty = np.where(sliver, (10.0 - residual), 0.0)

    return tightness + exact - penalty
# EVOLVE-BLOCK-END
