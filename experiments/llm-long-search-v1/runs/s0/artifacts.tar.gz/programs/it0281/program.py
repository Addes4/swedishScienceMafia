# EVOLVE-BLOCK-START
"""Best fit with a smooth, histogram-based residual-reuse tie-break.

Primary rule: best fit (smallest residual). Secondary/smoothing rules:
- reward residuals that equal a frequently-seen item size (reusable leftovers),
- small bonus for exact fills.
These refine ordering among near-equal residuals without breaking the
strong best-fit primary ordering that drives the score.
"""
import numpy as np

_count = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _count, _hist

    _hist[item] += 1.0
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here

    # Primary: best-fit tightness (prefer smaller residual).
    score = -residual.astype(np.float64)

    # Data-driven reuse value: residual that equals a common past item size is
    # likely to be filled later. Normalize histogram to a small weight so it
    # only refines ordering among similar residuals.
    if _count > 0:
        h = _hist[1:] / _count            # index 0 -> size 1
        r = residual
        valid = (r >= 1) & (r <= 100)
        idx = np.clip(r, 1, 100) - 1
        reuse = np.where(valid, h[idx], 0.0)
        score += reuse * 2.0

    # Small bonus for exact fills (never overrides best-fit since < 2 and
    # reuse term is bounded by 2).
    score += (residual == 0).astype(np.float64) * 1.0

    return score
# EVOLVE-BLOCK-END
