# EVOLVE-BLOCK-START
"""Best fit with a small bonus for placements that set up a reusable residual.

Dominant term is best-fit tightness (prefer the smallest positive residual).
On top of it, two cheap, fixed-scale bonuses steer ties toward the two most
valuable configurations:
  * residual == 0            (exact fill, kills no future capacity)
  * residual == item size    (bin becomes the exact complement of the current
                              item, so the next identical item can be paired)
The histogram / sliver / waste terms from earlier variants have consistently
hurt, so they are removed. No state is kept.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -residual.astype(np.float64)

    # Strong bonus for an exact fill.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Mild bonus when the leftover equals the current item size, forming a
    # perfect complementary pair with the next identical item.
    pair = (residual == item).astype(np.float64) * 2.0

    return tightness + exact + pair
# EVOLVE-BLOCK-END
