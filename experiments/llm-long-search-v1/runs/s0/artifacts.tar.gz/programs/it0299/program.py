# EVOLVE-BLOCK-START
"""Best fit with a small self-scaling load tie-break: prefer the smallest
positive residual, and among close residuals prefer the fuller bin to limit
future fragmentation. Exact fills are strongly preferred."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Best-fit tightness: smaller residual is better.
    tightness = -r

    # Strong bonus for exact fills (always optimal).
    exact = (residual == 0).astype(np.float64) * 8.0

    # Self-scaling load tie-break: prefer the fuller bin (smaller residual)
    # slightly more than pure tightness would, scaled so it never overrides
    # a genuine residual difference.
    load = -r / 100.0

    return tightness + exact + load
# EVOLVE-BLOCK-END
