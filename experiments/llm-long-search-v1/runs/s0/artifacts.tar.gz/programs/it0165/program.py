# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus and a small mirror-residual tie-break."""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _mean, _count, _hist

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    # Penalize positive residuals smaller than a typical item (wasted slivers).
    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Strongly prefer exact fills.
    exact = (residual == 0).astype(np.float64) * 20.0

    # Small tie-break: leaving a residual equal to the item size creates a
    # mirror-image bin that a future identical item can fill exactly.
    mirror = (residual == item).astype(np.float64) * 0.25

    return tightness - penalty + exact + mirror
# EVOLVE-BLOCK-END
