# EVOLVE-BLOCK-START
"""Best-fit with a scale-relative tightness and a strong exact-fill bonus."""
import numpy as np

CAP = 100.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)

    # Scale-relative best fit: prefer smaller residual (measured against capacity).
    tightness = -residual / CAP

    # Strong exact-fill bonus: strongly prefer placing into a bin that becomes full.
    exact = (residual == 0).astype(np.float64) * 5.0

    return tightness + exact
# EVOLVE-BLOCK-END
