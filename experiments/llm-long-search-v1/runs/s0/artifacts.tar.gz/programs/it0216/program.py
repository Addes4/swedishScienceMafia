# EVOLVE-BLOCK-START
"""Best fit with exact-fill priority plus a stable "reusability" bonus derived
from the running mean item size (mean ~40)."""
import numpy as np

# Running mean of observed item sizes (used to estimate typical refill sizes).
_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _mean, _count

    # Update running mean of past items before scoring this one.
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Best-fit tightness: prefer smaller residual.
    tightness = -r

    # Strong bonus for exact fills.
    exact = (r == 0).astype(np.float64) * 5.0

    # Reusability bonus: residuals close to a typical single item or to two
    # typical items can likely be refilled by upcoming items. Use scale = mean.
    m = _mean
    if m > 0:
        # dist to nearest multiple of m (1*m or 2*m), in residual space.
        k = np.round(r / m)
        k = np.clip(k, 0.0, 3.0)
        dist = np.abs(r - k * m)
        reuse = np.exp(-(dist / (0.35 * m)) ** 2) * 1.5
    else:
        reuse = np.zeros_like(r)

    # Mild penalty for small positive slivers that are hard to reuse.
    sliver = (r > 0) & (r < 0.5 * m)
    penalty = np.where(sliver, (0.5 * m - r) * 0.5, 0.0)

    return tightness + exact + reuse - penalty
# EVOLVE-BLOCK-END
