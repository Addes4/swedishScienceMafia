# EVOLVE-BLOCK-START
"""Best fit with a useful-remainder refinement.

Score = -residual - penalty, where the penalty is small when the post-placement
remainder is either 0 (perfect closure) or at least a typical item size, and
larger when it falls in the "useless small gap" region. Falls back to plain
best fit for clear decisions.
"""
import numpy as np

# running mean estimate of recently seen items (updated online)
_state = {"mean": 40.0, "count": 0}


def priority(item, bins):
    s = _state
    # online mean of item sizes
    s["count"] += 1
    s["mean"] += (item - s["mean"]) / s["count"]
    target = s["mean"]

    residual = bins - item  # >= 0 for all shown bins

    # penalty: small if remainder is 0, moderately small if remainder >= target,
    # large-ish if 0 < remainder < target (a likely wasted gap)
    # scale penalty relative to item so it stays a soft tie-break
    wasted = (residual > 0) & (residual < target)
    penalty = np.where(wasted, (target - residual) / (target + 1.0), 0.0)

    return -(residual + penalty)
# EVOLVE-BLOCK-END
