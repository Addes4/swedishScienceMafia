# EVOLVE-BLOCK-START
"""Best fit with an online residual-match tie-break.

Primary: minimize post-placement remainder (best fit).
Secondary (small weight): prefer remainders near a common recent item size, so the
resulting gap is more likely to be exactly fillable later. The common-size signal is
an exponentially-weighted running histogram of past item sizes (no future info).
"""
import numpy as np

# Exponentially weighted counts over item sizes 1..100, shared mutable state.
_hist = np.zeros(101, dtype=np.float64)
_decay = 0.99
_INIT = False


def priority(item, bins):
    global _hist, _INIT
    if not _INIT:
        _INIT = True

    # Update histogram with the current item (uses only past/current info).
    _hist *= _decay
    _hist[item] += 1.0

    rem = bins - item  # post-placement remainder, >= 0 for fitting bins

    # Common recent sizes: normalized histogram mass at each remainder value.
    h = _hist
    tot = h.sum()
    if tot <= 0:
        return -(bins - item).astype(np.float64)
    common = h / tot  # probability-like weight that a future item equals size r

    # Score: tightest fit primary; among similar fits prefer a remainder that is a
    # plausible future item size (larger `common[rem]`), scaled small vs tightness.
    # Tightness term dominates; residual-match is a fine tie-breaker.
    tight = -rem.astype(np.float64)
    match = common[np.clip(rem, 0, 100)]
    return tight + 0.5 * match
# EVOLVE-BLOCK-END
