# EVOLVE-BLOCK-START
"""Best-fit core with an exact-fill bonus and a stable, distribution-based
reward for residuals near the mean item size (most likely to be refillable)."""
import numpy as np

# Distribution-derived constants (fixed, not tuned per instance).
_MEAN = 40.0
_SIGMA = 22.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    # Strong reward for exact fills.
    exact = (residual == 0).astype(np.float64) * 8.0

    # Smooth reward for residuals near the mean item size: such a leftover is
    # most likely to be reusable by a single upcoming item.
    r = residual.astype(np.float64)
    near_mean = np.exp(-((r - _MEAN) ** 2) / (2.0 * _SIGMA * _SIGMA))
    near_mean = np.where(residual > 0, near_mean, 0.0) * 3.0

    return tightness + exact + near_mean
# EVOLVE-BLOCK-END

