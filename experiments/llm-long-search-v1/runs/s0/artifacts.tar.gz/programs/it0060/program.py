# EVOLVE-BLOCK-START
"""Best fit with an online exact-closure bonus.

Primary criterion is tightest fit (classic best fit). A small bonus is added when the
post-placement remainder can be exactly closed by a typical past item size, estimated
from an online histogram of items seen so far. Best fit remains dominant so behaviour
degrades gracefully when the histogram is uninformative.
"""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    st = _state
    counts = st["counts"]
    n = st["n"]

    # Post-placement remainder for each bin.
    rem = bins - item

    # Estimate probability that some typical past size equals a given remainder.
    if n > 0:
        freq = counts / n
    else:
        freq = counts  # all zeros

    # Closure bonus: how likely a future item exactly matches the remainder.
    # rem is in [0, 99] since item >= 1 and bins >= item.
    closure = freq[rem]

    # Best fit: smaller remainder is better -> -rem. Closure term is a weak tie-break.
    score = -rem.astype(np.float64) + 0.01 * closure

    # Update online histogram (exponential-ish: simple counts with decay to stay adaptive).
    st["counts"] = counts * 0.999
    st["counts"][item] += 1.0
    st["n"] = n * 0.999 + 1.0

    return score
# EVOLVE-BLOCK-END
