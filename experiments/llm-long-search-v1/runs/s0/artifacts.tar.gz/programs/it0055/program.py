# EVOLVE-BLOCK-START
"""Best fit with a running-mean "useful remainder" tie-break.

Primary: tightest fit (smallest post-placement remainder).
Tie-break: among bins whose remainder lies in a tiny band around the best
remainder, prefer a remainder that is either 0 or at least the running
mean item size (so the leftover gap can still accept a typical item).
"""
import numpy as np


class _State:
    total = 0.0
    count = 0


_state = _State()


def priority(item, bins):
    # online running mean of item sizes (decaying) to estimate a "typical" item
    s = _state
    s.total += item
    s.count += 1
    mean_item = s.total / s.count

    rem = bins - item  # post-placement remainder, >= 0 since bins only contain fitting bins

    # primary score: prefer tightest fit
    score = -rem.astype(np.float64)

    # tie-break band: bins almost as tight as the tightest
    best = rem.min()
    band = best + 1.0
    tight = rem <= band

    # within band, prefer remainders that are 0 or >= mean_item (usable gaps)
    useful = (rem == 0) | (rem >= mean_item)
    score = score + np.where(tight & useful, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
