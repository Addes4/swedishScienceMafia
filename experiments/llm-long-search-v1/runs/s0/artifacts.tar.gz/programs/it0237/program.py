# EVOLVE-BLOCK-START
"""Pure best-fit bin-choice rule: place the item in the bin that leaves the
smallest non-negative residual (tightest fit). A small bonus strongly prefers
exact fills (residual 0), which is best-fit-dominant and avoids wasteful slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit: prefer the tightest fit (smallest residual).
    tightness = -residual.astype(np.float64)

    # Strongly prefer exact fills: residual == 0 wastes nothing.
    exact = (residual == 0).astype(np.float64) * 5.0

    return tightness + exact
# EVOLVE-BLOCK-END
