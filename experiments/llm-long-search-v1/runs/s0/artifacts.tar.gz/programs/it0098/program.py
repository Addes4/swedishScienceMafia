# EVOLVE-BLOCK-START
"""Residual-smoothing best fit: tightest fit, but softly avoid leaving tiny unusable slivers."""
import numpy as np

_state = {"seen": []}


def priority(item, bins):
    _state["seen"].append(item)
    rem = bins - item
    # best fit: smaller remainder is better
    score = -(rem.astype(np.float64))
    # penalize remainders that are small but nonzero (likely unusable slivers)
    small = (rem > 0) & (rem < item)
    score[small] -= 0.5 * (item - rem[small])
    return score
# EVOLVE-BLOCK-END
