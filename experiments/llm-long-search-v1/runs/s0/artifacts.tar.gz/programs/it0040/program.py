# EVOLVE-BLOCK-START
"""Best fit with a harmonic-style tie-break toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: smallest residual gap after placement (best fit).
    gap = bins - item
    # Secondary: prefer the fuller bin (smaller remaining capacity before placement),
    # which reduces fragmentation and mimics harmonic packing.
    return -(gap + 1e-3 * bins)
# EVOLVE-BLOCK-END
