# EVOLVE-BLOCK-START
"""Best fit (smallest residual) with a sub-unit tie-break that prefers exact
fills, so the strict best-fit ordering is never disturbed."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Dominant term: strict best fit (smallest residual gets the highest score).
    # Multiply by a large factor so residual differences of 1 are decisive, and
    # the tie-break below (strictly < factor) can never overturn it.
    tightness = -residual.astype(np.float64) * 2.0

    # Tie-break (magnitude < 2.0, so it only matters for equal residuals):
    # prefer exact fills, which are always beneficial.
    exact = (residual == 0).astype(np.float64)

    return tightness + exact
# EVOLVE-BLOCK-END
