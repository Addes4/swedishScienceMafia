# EVOLVE-BLOCK-START
"""Best fit with a live-histogram expected-waste tie-break."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)  # counts of seen item sizes 0..100
_count = 0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _hist, _count

    # Small penalty for leaving a residual that no seen item can ever fill.
    if _count > 0:
        # P(seen item size > r) for each residual r, via suffix sums of the histogram.
        # Number of seen items strictly larger than r:
        total = _count
        # suffix[r] = count of seen items with size > r
        suffix = np.cumsum(_hist[::-1])[::-1]  # suffix[r] includes sizes >= r
        # items strictly larger than r = suffix[r+1]
        larger_frac = np.empty(101, dtype=np.float64)
        larger_frac[:100] = suffix[1:] / total
        larger_frac[100] = 0.0
    else:
        larger_frac = np.zeros(101, dtype=np.float64)

    residual = bins - item  # remaining capacity after placing the item here
    tightness = -residual.astype(np.float64)

    # Waste-awareness: a positive residual that is smaller than everything seen so far
    # is dead space; mildly penalize it so best-fit can still dominate.
    res_clip = np.clip(residual, 0, 100)
    dead = np.where(residual > 0, larger_frac[res_clip], 0.0)

    # Update histogram after scoring.
    _hist[item] += 1.0
    _count += 1

    return tightness - 3.0 * dead
# EVOLVE-BLOCK-END
