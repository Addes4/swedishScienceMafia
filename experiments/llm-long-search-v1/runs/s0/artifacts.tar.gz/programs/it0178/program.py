# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break based on a running mean and small
target residuals (to nudge residuals toward reusable leftover sizes)."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -residual.astype(np.float64)

    m = _mean

    # Penalize residuals that are positive but smaller than a typical item:
    # such slivers are effectively wasted capacity.
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Complement bonus: reward residuals equal to the current item size or half
    # of it, so identical/similar items can pair up into a full bin. Keep this
    # strictly below 1.0 so it only breaks near-ties in the tightness term.
    half = item // 2
    complement = ((residual == item).astype(np.float64)
                  + (residual == half).astype(np.float64) * 0.5) * 0.9

    return tightness - penalty + exact + complement
# EVOLVE-BLOCK-END
