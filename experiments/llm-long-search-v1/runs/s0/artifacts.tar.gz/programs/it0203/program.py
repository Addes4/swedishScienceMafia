# EVOLVE-BLOCK-START
"""Best fit with a sliver penalty and an exact-fit bonus.

Empirical evidence across attempts shows the data-driven histogram/complement
terms only add noise. The robust signal is: fill bins completely when possible
and avoid leaving tiny unusable slivers.
"""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    global _mean, _count

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    # Penalize positive residuals smaller than a typical item: such slivers are
    # effectively wasted capacity and unlikely to be reused.
    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 6.0

    return tightness - penalty + exact
# EVOLVE-BLOCK-END
