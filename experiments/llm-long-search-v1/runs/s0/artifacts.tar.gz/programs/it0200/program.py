# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break based on the empirical item-size
distribution of seen items (nudge residuals toward sizes a future item can fill)."""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -residual.astype(np.float64)

    # Penalize residuals that are positive but smaller than a typical item:
    # such slivers are effectively wasted capacity.
    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Small bonus for very tight fits (residual 0) to strongly prefer exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Data-driven complement bonus: reward residuals by the empirical probability
    # that a typical future item can actually fill the leftover. We use the CDF of
    # seen item sizes: value(r) = fraction of past items <= r. Larger, reusably
    # sized leftovers get more credit, without overpowering tightness.
    if _count > 0:
        cdf = np.cumsum(_hist[1:]) / _count  # cdf[k-1] = P(item <= k)
        r = residual
        idx = np.clip(r, 1, 100).astype(np.int64) - 1
        reuse = np.where(r >= 1, cdf[idx], 0.0)
    else:
        reuse = np.zeros_like(residual, dtype=np.float64)
    complement = reuse * 3.0

    # Waste-aware term: a residual just below the mean item size will likely
    # never be reused (lost capacity), so mildly penalize closeness to the mean.
    near_full = (residual > 0) & (residual < m)
    waste = np.where(near_full, (1.0 - residual / m) * 1.0, 0.0)

    return tightness - penalty + exact + complement - waste
# EVOLVE-BLOCK-END

