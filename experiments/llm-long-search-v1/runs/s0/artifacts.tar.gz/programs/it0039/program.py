# EVOLVE-BLOCK-START
"""Best fit refined by an online estimate of the item-size distribution.

The idea: plain best fit minimizes the immediate residual gap, but a residual
that no future item can use is wasted space.  We keep a small online histogram
of the item sizes seen so far and reward bins whose post-placement remainder is
a "usable" size, i.e. close to a size the distribution actually produces.
Best fit remains the primary signal via a tight-fit term so we never regress to
plain worst-fit behaviour.
"""
import numpy as np

# Online empirical histogram of item sizes (1..100).  Kept as module state so
# it persists across the 5000 calls of an instance.
_hist = np.zeros(101, dtype=np.float64)
_count = 0
_SIZES = np.arange(101, dtype=np.float64)


def _usable_value(rem):
    """How valuable it is to leave `rem` capacity free.

    A remainder is valuable if it is large enough to hold a typical item or if
    it matches the two most likely / large item sizes seen so far (so that a
    future item can drop in near-exactly).
    """
    if _count < 30:
        return 0.0
    # probability-weighted score: chance a future item of size s fits in rem,
    # weighted by s so that big usable remainders are worth more.
    probs = _hist[1:] / _count
    fits = (rem >= _SIZES[1:]).astype(np.float64)
    return float(np.dot(fits, probs * _SIZES[1:]))


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest."""
    global _count
    _hist[item] += 1.0
    _count += 1

    bins = np.asarray(bins)
    rem = bins - item  # post-placement remainder for each candidate bin

    # Primary: tightest fit (smallest remainder) -> -rem.
    # Secondary: value of the remainder for future placement.  Weighted small
    # so it only matters when remainders are comparable.
    primary = -rem.astype(np.float64)

    if _count < 30:
        return primary

    probs = _hist[1:] / _count
    sizes = _SIZES[1:]
    # value for each remainder
    fits = (rem[:, None] >= sizes[None, :]).astype(np.float64)
    value = fits @ (probs * sizes)

    return primary + 1e-6 * value
# EVOLVE-BLOCK-END
