# EVOLVE-BLOCK-START
"""Best fit with a stable, bin-order tie-break that favors concentrating items
into earlier (existing) bins among equal residuals, reducing fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    n = bins.shape[0]
    # Dominant term: best fit -> prefer the smallest residual.
    tightness = -residual.astype(np.float64)

    # Strictly sub-1 tie-break: among equal residuals, prefer the earliest bin
    # (which is more likely an already-open bin), concentrating fills instead of
    # spreading across many partially-used bins.
    idx = np.arange(n, dtype=np.float64)
    order_bonus = (n - idx) / (n + 1.0)

    # Also break ties in favor of exact fills (residual 0).
    exact = (residual == 0).astype(np.float64) * 0.5

    return tightness + order_bonus + exact
# EVOLVE-BLOCK-END
