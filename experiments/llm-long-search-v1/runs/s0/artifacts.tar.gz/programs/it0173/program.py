# EVOLVE-BLOCK-START
"""Best-fit with a small sub-1.0 tie-break that prefers leaving a residual
equal to the current item size (reusable pairing) plus a modest exact-fill bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)  # remaining capacity after placing here

    # Dominant term: best fit (prefer smallest residual).
    score = -residual

    # Sub-1.0 tie-break: among bins with equal residual, prefer leaving a
    # residual that equals the current item size, making it reusable by the
    # next identical item.
    pair = (residual == item).astype(np.float64) * 0.5

    # Modest exact-fill bonus (residual 0) so exact fills are strongly preferred.
    exact = (residual == 0).astype(np.float64) * 2.0

    return score + pair + exact
# EVOLVE-BLOCK-END
