# EVOLVE-BLOCK-START
"""Best fit with residual-usability tie-breaks based on a running mean item size."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (before scoring this one, then include it).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Best-fit tightness: prefer smaller residual.
    tightness = -r

    m = _mean

    # Penalize residuals that are positive but too small to be useful:
    # slivers below the running mean are effectively wasted capacity.
    sliver = (residual > 0) & (r < m)
    penalty = np.where(sliver, (m - r) * 2.0, 0.0)

    # Bonus for near-exact fills (residual 0).
    exact = (residual == 0).astype(np.float64) * 5.0

    # Bonus for residuals close to a multiple of the running mean, i.e. residuals
    # that a typical future item (or a few of them) can neatly fill.
    if m > 1.0:
        frac = r / m
        dist = np.abs(frac - np.round(frac))
        usable = (residual > 0) & (dist < 0.15)
        multi_bonus = np.where(usable, 1.0 - dist * 4.0, 0.0)
    else:
        multi_bonus = np.zeros_like(r)

    return tightness - penalty + exact + multi_bonus
# EVOLVE-BLOCK-END
