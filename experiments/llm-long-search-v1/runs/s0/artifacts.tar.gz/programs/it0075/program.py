# EVOLVE-BLOCK-START
"""Best fit with a rough alignment penalty to the running mean item size."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Rank bins: tightest fit, adjusted so post-placement remainder aligns with typical items."""
    _state["sum"] += item
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]

    rem = bins - item  # remaining capacity after placing item (>=0 for shown bins)
    base = -rem.astype(np.float64)

    # Alignment: penalize remainders that are not close to a multiple of the running mean.
    if mean > 0 and _state["n"] >= 20:
        k = np.round(rem / mean)
        aligned = k * mean
        roughness = np.abs(rem - aligned)
        base -= 0.15 * roughness
    return base
# EVOLVE-BLOCK-END
