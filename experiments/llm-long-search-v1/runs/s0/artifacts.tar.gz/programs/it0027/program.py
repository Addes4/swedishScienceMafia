# EVOLVE-BLOCK-START
"""Best fit with a slight preference against leaving remainders that can't fit typical items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary score is best-fit (smaller post-placement remainder is better).
    A very small secondary term penalizes remainders that are too small to fit a
    typical item (~40) but not empty, encouraging bins that stay usable.
    """
    rem = bins - item
    # Primary: prefer small remainder (best fit)
    score = -rem.astype(np.float64)
    # Secondary: small penalty for remainders in the awkward range (1..39),
    # i.e., too small to fit a mean item but not zero. Scale tiny so it only
    # breaks near-ties, never overrides best-fit ordering by more than 1 unit.
    awkward = ((rem > 0) & (rem < 40)).astype(np.float64)
    score -= 1e-3 * awkward
    return score
# EVOLVE-BLOCK-END

