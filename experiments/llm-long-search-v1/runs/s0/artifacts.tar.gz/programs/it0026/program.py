# EVOLVE-BLOCK-START
"""Best fit with a deterministic hashed tie-break among equal residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    Primary term: best-fit residual (prefer smallest leftover after placement).
    Tie-break: a cheap hash of the bin index so equal-residual bins are
    chosen in a scattered, non-systematic order.
    """
    idx = np.arange(bins.shape[0], dtype=np.int64)
    # Deterministic pseudo-random tie-break in [0, 1).
    h = (idx * 2654435761 + item * 40503) & 0xFFFFFFFF
    h = (h ^ (h >> 16)) & 0xFFFFFFFF
    tie = h / 4294967296.0
    return -(bins - item) * 2.0 + tie * 0.5
# EVOLVE-BLOCK-END
