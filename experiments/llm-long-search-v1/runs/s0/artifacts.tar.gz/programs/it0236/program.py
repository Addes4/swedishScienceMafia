# EVOLVE-BLOCK-START
"""Best fit (score = -residual) as the dominant rule, with a small,
deterministic, data-driven tie-break that favors residuals which are common
item sizes in the running distribution (most likely to be reused exactly)."""
import numpy as np

_count = 0
# Histogram of seen item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)
# Cached normalized reusability weight per residual value (1..100).
_weight = np.zeros(101, dtype=np.float64)
_last_update = -1


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _hist, _weight, _last_update

    # Update histogram of past items.
    _hist[item] += 1.0
    _count += 1

    residual = bins - item  # remaining capacity after placing here

    # Refresh the reusability weights occasionally (cheap, avoids per-call cost).
    if _count - _last_update >= 25:
        h = _hist[1:]
        total = h.sum()
        if total > 0:
            _weight[1:] = h / total
        _last_update = _count

    # Dominant term: tighter fit (smaller residual) is strictly better.
    score = -residual.astype(np.float64)

    # Tie-break only: small bonus proportional to how common this residual is
    # as a future item size, i.e. how likely the leftover can be reused exactly.
    r = residual
    valid = (r >= 1) & (r <= 100)
    tie = np.zeros_like(score)
    if valid.any():
        idx = r[valid]
        tie[valid] = _weight[idx]
    # Scale small enough that it never overrides a strict residual difference
    # (residuals are integers, so a scale < 0.5 keeps -residual dominant).
    return score + tie * 0.4
# EVOLVE-BLOCK-END
