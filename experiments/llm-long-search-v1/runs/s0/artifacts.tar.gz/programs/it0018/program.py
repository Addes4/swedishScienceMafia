# EVOLVE-BLOCK-START
"""Best fit with a small capacity-aware tie-break to escape large residue ties."""
import numpy as np


def priority(item, bins):
    """Score bins: primarily best fit (min post-placement remainder), tie-break to
    prefer bins that still have more remaining capacity *before* placement (i.e. the
    emptier bin), which tends to keep partially filled bins from fragmenting."""
    # Primary: minimize remainder after placement => -(bins - item)
    rem = bins - item
    # Tie-break: prefer the bin with the larger pre-placement capacity (fresher bin),
    # scaled tiny so it never overrides the primary best-fit decision.
    return -(rem.astype(np.float64)) * 1e6 + bins.astype(np.float64)
# EVOLVE-BLOCK-END
