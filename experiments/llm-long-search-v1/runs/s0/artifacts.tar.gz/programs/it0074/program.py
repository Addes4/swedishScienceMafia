# EVOLVE-BLOCK-START
"""Adaptive best fit: pick the bin whose post-placement remainder has the least
expected waste under the empirical item-size distribution seen so far."""
import numpy as np

# module-level state
_hist = np.ones(101, dtype=np.float64)   # counts for sizes 0..100 (index 0 unused)
_hist[0] = 0.0
_total = 0.0
_last_n = 0

# cache the waste table keyed by total count bucket
_waste_cache = {}
_waste_key = None


def _expected_waste():
    """For each remainder r in 0..100, expected leftover capacity after greedily
    packing a stream of items drawn from the current empirical distribution."""
    global _waste_key, _waste_cache
    # rebuild at most every few items
    key = int(_total)
    if key == _waste_key:
        return _waste_cache
    p = _hist / _hist.sum()
    # sizes actually present
    sizes = np.nonzero(_hist)[0]
    ps = p[sizes]

    # waste(r): expected leftover of a bin that currently has r free capacity,
    # item arrives, if it fits (size <= r) it goes in (best fit greedy),
    # leftover = waste(r - size); else bin is closed with r wasted.
    waste = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        fit = sizes[sizes <= r]
        if fit.size == 0:
            waste[r] = float(r)
            continue
        pf = p[fit]
        pf_sum = pf.sum()
        # probability no future item fits -> bin closed
        # expected remaining: sum over fit sizes of p_s*(r-s is used up then recursively)
        acc = 0.0
        for s, prob in zip(fit, pf):
            acc += prob * waste[r - s]
        nofit = 1.0 - pf_sum
        waste[r] = acc + nofit * float(r)
    _waste_key = key
    _waste_cache = waste
    return waste


def priority(item, bins):
    """Score bins by (negative) expected waste of the resulting remainder."""
    global _total
    # update histogram
    _hist[item] += 1.0
    _total += 1.0

    waste = _expected_waste()
    rem = bins - item  # post-placement remainders
    # remaining capacity after placement is in [0, 100]
    score = -waste[rem]
    return score
# EVOLVE-BLOCK-END

