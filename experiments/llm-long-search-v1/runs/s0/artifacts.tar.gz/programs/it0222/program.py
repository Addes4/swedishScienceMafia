# EVOLVE-BLOCK-START
"""Best fit with a data-driven, frequency-weighted complement bonus: reward
residuals whose size matches a commonly seen item size (so the leftover is
likely to be reusable), plus a strong exact-fill bonus and a mild sliver penalty."""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100), used to reward residuals that match
# a common leftover size.
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    # Penalize residuals that are positive but smaller than a typical item:
    # such slivers are effectively wasted capacity.
    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 6.0

    # Data-driven complement bonus: reward residuals whose size matches a
    # commonly seen item size, weighted by the empirical frequency of that size.
    r = residual
    valid = r >= 1
    if _count > 0:
        # Frequency (normalized) of each size, indexed by residual value.
        freq = _hist / _count
        rr = np.where(valid, r, 0).astype(np.int64)
        match = freq[rr]
    else:
        match = np.zeros_like(r, dtype=np.float64)
    complement = match * 40.0

    # Waste-aware term: residuals just below the mean item size will likely
    # never be reused and are effectively lost capacity.
    near_full = (residual > 0) & (residual < m)
    waste = np.where(near_full, (1.0 - residual / m) * 1.0, 0.0)

    return tightness - penalty + exact + complement - waste
# EVOLVE-BLOCK-END

