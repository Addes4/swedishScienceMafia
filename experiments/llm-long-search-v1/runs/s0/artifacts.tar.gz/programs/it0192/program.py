# EVOLVE-BLOCK-START
"""Best fit (prefer the smallest residual) with a strictly-dominant scale, plus a
small tie-break that rewards residuals equal to the arriving item size so the
leftover can be filled exactly by an identical future item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual, scaled so it strictly dominates.
    tightness = -residual.astype(np.float64) * 1000.0

    # Small tie-break: reward a residual exactly equal to the current item size
    # (perfect future pairing) and exact fills, without overriding real residual
    # differences.
    exact = (residual == 0).astype(np.float64) * 2.0
    pair = (residual == item).astype(np.float64) * 1.0

    return tightness + exact + pair
# EVOLVE-BLOCK-END
