# EVOLVE-BLOCK-START
"""Best fit with periodic-sum bin packing via harmonic-like closure bonus.

Items arrive online. We use a hybrid of best-fit and a "closure" preference:
among bins whose post-placement remainder is small (tight fit), we prefer the
one whose remainder exactly equals a frequently seen item size, so the bin can
later be closed exactly. The histogram is built online from past items.
"""
import numpy as np

# Online histogram of item sizes (1..100)
_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score chosen."""
    global _total

    # Update histogram lazily (exclude current item, it's the one being placed)
    if _total > 0:
        freq = _counts / _total
    else:
        freq = np.zeros(101, dtype=np.float64)

    rem = bins - item  # post-placement remainder, >= 0 since bins are those it fits in

    # Base: best fit (smaller remainder is better)
    score = -rem.astype(np.float64)

    # Closure bonus: reward remainders that are common future item sizes (0..100)
    # or that can be exactly closed (remainder itself is a frequent size).
    # Only apply meaningfully to non-trivial remainders so we don't disturb exact fits.
    idx = np.clip(rem, 0, 100)
    closure = freq[idx]
    score += 0.5 * closure

    # Encourage keeping bins that leave a remainder of 0 (exact close) strongly
    score += 1e-3 * (rem == 0)

    # Update histogram with the current item AFTER scoring
    _counts[item] += 1.0
    _total += 1.0

    return score
# EVOLVE-BLOCK-END
