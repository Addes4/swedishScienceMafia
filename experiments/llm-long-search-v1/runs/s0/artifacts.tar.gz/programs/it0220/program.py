# EVOLVE-BLOCK-START
"""Best fit with a stable, distribution-based tie-break: reward residuals
close to the running mean item size (most likely to be refillable)."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here
    m = _mean

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -residual.astype(np.float64)

    # Penalize positive residuals smaller than a typical item: likely wasted slivers.
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Stable complement bonus: reward residuals close to the mean item size,
    # since such a leftover is most likely to be reusable by one future item.
    diff = np.abs(residual - m)
    complement = np.where(residual > 0, np.maximum(0.0, 1.0 - diff / m) * 2.0, 0.0)

    return tightness - penalty + exact + complement
# EVOLVE-BLOCK-END
