# EVOLVE-BLOCK-START
"""Best fit with a small "already well-filled bin" bonus as a tie-breaker."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: tightest fit (best fit).  Secondary: small bonus for bins that are
    # already more filled (smaller remaining capacity), which discourages scattering
    # items across many nearly-empty bins.
    tightness = -(bins - item)
    fill_bonus = -(bins.astype(np.float64)) * 1e-3
    return tightness + fill_bonus
# EVOLVE-BLOCK-END
