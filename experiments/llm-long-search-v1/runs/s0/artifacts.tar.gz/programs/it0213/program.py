# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus plus a smooth, distribution-based
"fillability" bonus: reward residuals that a typical upcoming item can fill
tightly, using a Weibull-shaped size model estimated from the running mean."""
import numpy as np

_mean = 40.0
_count = 0

# Weibull shape fixed from the described distribution; scale fit to running mean.
_SHAPE = 1.6


def _weibull_pdf(x, scale):
    """Weibull pdf with fixed shape and given scale (x in items sizes)."""
    x = np.asarray(x, dtype=np.float64)
    out = np.zeros_like(x)
    m = x > 0
    z = x[m] / scale
    out[m] = (_SHAPE / scale) * (z ** (_SHAPE - 1.0)) * np.exp(-(z ** _SHAPE))
    return out


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _mean, _count

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Best-fit tightness: prefer smaller residual.
    tightness = -r

    # Strong bonus for exact fills (residual 0): the bin becomes fully packed.
    exact = (residual == 0).astype(np.float64) * 8.0

    # Fillability bonus: a residual r is reusable if a typical future item s
    # satisfies s <= r with s close to r (tight refill). Estimate this with the
    # Weibull model: probability that an item of size near r arrives, plus a
    # term for an item that leaves a small residual after refilling.
    scale = max(_mean, 1.0)
    fill_prob = _weibull_pdf(r, scale) * scale  # density-based, O(1) scale
    # Reward residuals that themselves look like a likely item size.
    fillability = fill_prob * 6.0

    # Mild penalty for tiny positive slivers that no item can fill.
    sliver = (r > 0) & (r < 0.5 * _mean)
    sliver_pen = np.where(sliver, (0.5 * _mean - r) / (0.5 * _mean), 0.0)

    return tightness + exact + fillability - sliver_pen
# EVOLVE-BLOCK-END
