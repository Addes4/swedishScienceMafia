# EVOLVE-BLOCK-START
"""Best fit with a small preference for reusing already-open bins."""
import numpy as np


def priority(item, bins):
    """Rank bins: primarily tightest fit, with a mild bonus for non-empty bins."""
    # post-placement remainder; smaller is better (best fit)
    base = -(bins - item)
    # bonus for already-open bins (remaining < 100) to discourage opening new bins
    open_bonus = np.where(bins < 100, 0.5, 0.0)
    return base + open_bonus
# EVOLVE-BLOCK-END
