# EVOLVE-BLOCK-START
"""Best fit with a data-driven residual-reuse bonus: score a residual by how
likely a future item exactly equals it, estimated from the empirical histogram
of past item sizes (smoothed)."""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)


def _reuse_lookup():
    """Return array lookup[r] = estimated probability a future item == r (smoothed)."""
    h = _hist[1:101].copy()
    total = h.sum()
    if total <= 0:
        return np.zeros(101, dtype=np.float64)
    p = h / total
    # Smooth with a small triangular kernel to reduce noise / share evidence.
    kernel = np.array([1.0, 2.0, 3.0, 2.0, 1.0])
    kernel /= kernel.sum()
    smooth = np.convolve(p, kernel, mode="same")
    out = np.zeros(101, dtype=np.float64)
    out[1:101] = smooth
    return out


def priority(item, bins):
    global _mean, _count, _hist

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item
    tightness = -residual.astype(np.float64)

    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)
    exact = (residual == 0).astype(np.float64) * 5.0

    # Data-driven reuse value of the leftover residual: probability a future
    # item exactly fills it.  Scaled to refine ordering without overriding
    # best-fit tightness.
    lookup = _reuse_lookup()
    r = residual
    valid = (r >= 1) & (r <= 100)
    reuse = np.where(valid, lookup[np.clip(r, 0, 100)], 0.0) * 30.0

    return tightness - penalty + exact + reuse
# EVOLVE-BLOCK-END
