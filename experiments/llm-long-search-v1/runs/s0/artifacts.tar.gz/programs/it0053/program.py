# EVOLVE-BLOCK-START
"""Best fit refined by a running estimate of the typical upcoming item size."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Rank bins: prefer tightest fit, but avoid leaving gaps too small for a typical item."""
    # Running mean of recent items (exponential moving average, warm-started)
    a = 0.05
    _state["sum"] += item
    _state["n"] += 1
    if "_ema" not in _state:
        _state["_ema"] = item
    else:
        _state["_ema"] = (1.0 - a) * _state["_ema"] + a * item
    typical = _state["_ema"]
    if _state["n"] < 20:
        typical = _state["sum"] / _state["n"]

    residual = bins - item  # remaining capacity after placing
    # Best-fit primary score (higher = tighter fit)
    score = -residual.astype(np.float64)
    # Penalize leaving a positive remainder that is too small for a typical item,
    # which wastes usable capacity; strongly prefer a remainder >= typical.
    small_waste = (residual > 0) & (residual < typical)
    score[small_waste] -= (typical - residual[small_waste])
    return score
# EVOLVE-BLOCK-END
