# EVOLVE-BLOCK-START
"""Best fit ordering (prefer the smallest non-negative residual), with a very
small non-disruptive bonus for exact fills and for residuals whose value has
been frequently seen among past items (so the leftover is reusable)."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist

    _hist[item] += 1.0

    residual = (bins - item).astype(np.float64)

    # Core: best fit. Smaller residual => higher score. Scale by large factor
    # so this strictly dominates any tie-break term below.
    tightness = -residual * 1000.0

    # Exact fill: small clearly-positive nudge (does not change best-fit order
    # because residual 0 already has the largest tightness; this only helps
    # when the harness were to compare equal residuals).
    exact = (residual == 0).astype(np.float64) * 0.5

    # Complement bonus: reward residuals equal to a frequently seen item size,
    # since such a leftover is likely reusable. Tiny scale keeps ordering intact.
    r = np.where(residual >= 1, residual, -1.0)
    idx = np.clip(r.astype(np.int64), 0, 100)
    freq = _hist[idx]
    freq = np.where(residual >= 1, freq, 0.0)
    denom = _hist.sum()
    if denom > 0:
        complement = (freq / denom) * 0.1
    else:
        complement = np.zeros_like(r)

    return tightness + exact + complement
# EVOLVE-BLOCK-END
