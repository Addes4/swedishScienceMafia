# EVOLVE-BLOCK-START
"""Best fit with a harmonic/remainder-class tie-break.

Primary objective: best fit (smallest post-placement remainder) as usual, since
that is the strongest myopic rule for this distribution.  Secondary objective:
among near-tied remainders, prefer the placement that leaves a remainder which
is either very small or reasonably large, rather than a remainder stranded in
the "middle" band (roughly one typical item, ~40) which is hardest to reuse.
"""
import numpy as np


def priority(item, bins):
    remainder = bins - item

    # Best fit: smaller remaining capacity (tighter fit) ranks higher.
    best_fit = -bins.astype(np.float64)

    # Penalty for stranded middle-band remainders.  Ranges are in capacity units.
    r = remainder.astype(np.float64)
    # Peak penalty around ~40 (typical item), fading toward 0 and toward 100.
    middle = np.exp(-((r - 40.0) ** 2) / (2.0 * 18.0 * 18.0))
    # Small bonus for near-full (tiny remainder) bins.
    tight = np.exp(-(r ** 2) / (2.0 * 6.0 * 6.0))

    # Keep best-fit dominant; tie-break with penalty/bonus.
    return best_fit * 1.0 - 0.5 * middle + 0.2 * tight
# EVOLVE-BLOCK-END
