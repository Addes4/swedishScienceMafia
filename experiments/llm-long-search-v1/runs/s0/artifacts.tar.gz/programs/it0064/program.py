# EVOLVE-BLOCK-START
"""Best fit with a small structural bonus/penalty and index-based jitter."""
import numpy as np

_MIN_SEEN = 100


def priority(item, bins):
    """Rank bins: prefer tight fits, but reward perfect closes and avoid dead leftovers."""
    global _MIN_SEEN
    if item < _MIN_SEEN:
        _MIN_SEEN = item

    rem = bins - item  # resulting remainder (>=0 since item fits)
    score = -(rem.astype(np.float64))

    # Reward exact closes; small but meaningful.
    score += 0.01 * (rem == 0)

    # Penalize leftovers too small to ever accept any item seen so far.
    score -= 0.02 * (rem < _MIN_SEEN) * (rem != 0)

    # Stable index-based jitter to break the best-fit plateau (based on bin content).
    idx = np.arange(bins.shape[0], dtype=np.float64)
    score += 1e-6 * ((idx * 2654435761.0) % 1000.0) / 1000.0

    return score
# EVOLVE-BLOCK-END
