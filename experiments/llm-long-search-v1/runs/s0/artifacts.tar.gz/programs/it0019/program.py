# EVOLVE-BLOCK-START
"""Best fit with a randomized tie-break on equal residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by best-fit residual, breaking exact ties pseudo-randomly by index.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary score: smaller residual is better -> use negative residual.
    score = -residual.astype(np.float64)
    # Small pseudo-random perturbation deterministic in bin index to break ties.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    perturb = np.sin(idx * 12.9898 + item * 78.233) * 43758.5453
    perturb = perturb - np.floor(perturb)
    score = score + perturb * 1e-3
    return score
# EVOLVE-BLOCK-END
