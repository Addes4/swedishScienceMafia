# EVOLVE-BLOCK-START
"""Best-fit with a gentle residual-usability tie-break based on a running mean item size."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (include this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual (dominant term, big weight).
    tightness = -residual.astype(np.float64) * 100.0

    m = _mean if _mean > 0 else 40.0

    # Gentle bonus for residuals that are usefully fillable: close to 0, or close
    # to a multiple of the mean (so several typical items still fit), while leaving
    # tiny slivers slightly penalized. Scale stays small so best-fit dominates.
    r = residual.astype(np.float64)
    frac = np.mod(r, m) / m           # 0..1: closeness to a mean-multiple boundary
    boundary_bonus = (1.0 - np.minimum(frac, 1.0 - frac))  # peaks at multiples of m

    # Exact fill gets the strongest small bonus.
    exact = (r == 0).astype(np.float64)

    # Wasted slivers (positive but too small for a typical item) get a tiny penalty.
    sliver = (r > 0) & (r < 0.5 * m)
    penalty = np.where(sliver, (0.5 * m - r) / m, 0.0)

    return tightness + 1.0 * boundary_bonus + 3.0 * exact - 2.0 * penalty
# EVOLVE-BLOCK-END
