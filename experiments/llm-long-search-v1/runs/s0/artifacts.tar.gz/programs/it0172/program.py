# EVOLVE-BLOCK-START
"""Best fit: place each item into the bin with the smallest remaining capacity
after placement (tightest fit). Strongly prefer exact fills (residual 0), and
use a tiny sub-1 tie-break to slightly favor residuals that leave room for a
typical item rather than dead slivers."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual (integer score dominates).
    tightness = -residual.astype(np.float64)

    # Strong exact-fill bonus.
    exact = (residual == 0).astype(np.float64) * 10.0

    # Tiny sub-1 tie-break: mildly prefer leaving room for a typical item over
    # an unusable sliver. Scaled strictly below 1 so it never overrides best-fit.
    m = _mean
    reusable = np.where(residual >= m, 0.5, np.where(residual > 0, 0.0, 0.5))

    return tightness + exact + reusable
# EVOLVE-BLOCK-END
