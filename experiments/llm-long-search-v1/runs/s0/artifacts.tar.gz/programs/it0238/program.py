# EVOLVE-BLOCK-START
"""Pure best-fit for the dominant ordering, with a tiny bounded
histogram-based tie-break toward reusable residuals."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _hist

    residual = bins - item  # remaining capacity after placing here

    # Dominant: best fit (smallest residual). Scaled so tie-breaks never
    # override a strictly tighter fit.
    score = -residual.astype(np.float64) * 1000.0

    # Register this item in the histogram (state for future calls).
    _hist[item] += 1.0

    # Tiny tie-break: reward residuals matching the current modal item size,
    # since such a leftover is the size most likely to be reusable.
    r = residual
    valid = (r >= 1) & (r <= 100)
    if _hist[1:].sum() > 0:
        modal = int(np.argmax(_hist[1:])) + 1
        match = (valid & (r == modal)).astype(np.float64)
        score = score + match  # at most 1, far below the 1000x fit scale

    return score
# EVOLVE-BLOCK-END
