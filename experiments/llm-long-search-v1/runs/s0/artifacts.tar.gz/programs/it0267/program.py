# EVOLVE-BLOCK-START
"""Best fit with a strictly-monotone tie-break favoring reusable residuals.

Core ordering: minimize the residual (rem = bins - item) -> maximize -rem.
Tie-breaks (scale 1e-3, never disturb the residual ordering):
  * exact fill (rem == 0) gets a tiny extra push, so exact fills win ties;
  * among nonzero residuals, prefer ones at least a typical item big
    (likely reusable) over dead slivers smaller than a typical item.
"""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    m = _mean

    residual = bins - item  # remaining capacity after placing the item here
    rem = residual.astype(np.float64)

    # Core: best-fit (smaller residual is better). Scale keeps it dominant.
    tightness = -rem

    # Tiny, monotone tie-breaks (magnitude < 0.5 so residual ordering is intact).
    exact = np.where(rem == 0, 1e-3, 0.0)          # exact fills win ties
    # Prefer dead-sliver avoidance: residual > 0 and >= typical item is better.
    reusable = np.where((rem > 0) & (rem >= m), 1e-4, 0.0)
    dead = np.where((rem > 0) & (rem < m), -1e-4, 0.0)

    return tightness + exact + reusable + dead
# EVOLVE-BLOCK-END

