# EVOLVE-BLOCK-START
"""Best fit with a strong exact-fill bonus and a residual-usability tie-break."""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _mean, _count, _hist

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Strong bonus for exact fills (residual 0) — dominated by tightness before.
    exact = (residual == 0).astype(np.float64) * 50.0

    r = residual
    valid = r >= 1
    if _count > 0:
        modal = int(np.argmax(_hist[1:])) + 1
        match = (valid & (r == modal)).astype(np.float64)
    else:
        match = np.zeros_like(r, dtype=np.float64)
    complement = match * 3.0

    near_full = (residual > 0) & (residual < m)
    waste = np.where(near_full, (1.0 - residual / m) * 1.0, 0.0)

    return tightness - penalty + exact + complement - waste
# EVOLVE-BLOCK-END

