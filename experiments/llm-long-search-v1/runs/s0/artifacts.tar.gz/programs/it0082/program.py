# EVOLVE-BLOCK-START
"""Best fit with a waste-potential penalty on large remainders that will likely be stranded."""
import numpy as np


def priority(item, bins):
    """Rank bins: tight fit first, but penalize remainders that will likely go unused.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacities of the bins the item fits in, including unused (100s).
    """
    rem = bins - item
    # Post-placement remainder. A remainder is "usable" only if a future item can fill it.
    # Without knowing the distribution we assume any remainder up to ~item can still be
    # filled by a future item of similar size, so a moderate remainder is fine; a very
    # large remainder (near 100) is nearly as wasteful as a fresh bin. Best fit already
    # minimizes remainder, so we add a mild concave reward for keeping remainder away
    # from 0 only when it's tiny (sub-minimum), otherwise stick to pure tightness.
    # Penalize remainders that are too small to ever hold another item (below 1) and
    # mildly reward remainders that are at least a plausible small item size.
    stranded = rem < 1
    score = -rem.astype(np.float64)
    # discourage stranding (remainder too small to be reused), but only weakly, so
    # best-fit behavior dominates and ties break toward reusable remainders.
    score -= stranded * 0.5
    return score
# EVOLVE-BLOCK-END
