# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and a bonus for leaving a residual
equal to the current item size (a likely reusable slot)."""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _mean, _count, _hist

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item

    tightness = -residual.astype(np.float64)

    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    exact = (residual == 0).astype(np.float64) * 20.0

    # Bonus when the leftover exactly equals the current item size, making this
    # bin a perfect future target for another identical item.
    selfmatch = (residual == item).astype(np.float64) * 3.0

    near_full = (residual > 0) & (residual < m)
    waste = np.where(near_full, (1.0 - residual / m) * 1.0, 0.0)

    return tightness - penalty + exact + selfmatch - waste
# EVOLVE-BLOCK-END
