# EVOLVE-BLOCK-START
"""Best-fit with a smooth residual-reusability correction.

Core: strong best-fit ordering (score = -residual) so the tightest fitting bin
wins. On top of that we add a small, bounded correction based on how likely the
resulting leftover is to be reused by a future item. Future item sizes follow a
fixed Weibull-shaped distribution (mean ~40); residuals equal to anything in the
plausible item range are useful, but tiny residuals below the typical item size
are dead capacity and get penalized. The correction is bounded well below 1 so
it never overturns a genuine best-fit choice unless two fits are nearly equal.
"""
import numpy as np

_MEAN = 40.0
# Typical spread of item sizes around the mean (Weibull-shaped, mean ~40).
_SIG = 20.0
# Precomputed usefulness of every possible residual (0..100).
_RES = np.arange(101, dtype=np.float64)
# A residual near the mean is most reusable; small residuals are dead slivers.
_USE = np.exp(-0.5 * ((_RES - _MEAN) / _SIG) ** 2)
# Residual 0 means a perfectly filled bin: the best possible outcome.
_USE[0] = 1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Pure best-fit: prefer the smallest nonnegative residual.
    tightness = -residual.astype(np.float64)

    r = residual
    valid = r >= 0
    ric = np.where(valid, r, 0).astype(np.int64)

    # Reusability of the leftover: near-mean residuals are useful, tiny ones are dead.
    usefulness = _USE[ric]

    # Small correction, bounded by 0.5 so best-fit ordering dominates.
    return tightness + 0.5 * usefulness
# EVOLVE-BLOCK-END
