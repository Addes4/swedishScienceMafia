# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware reusability tie-break.

Prefer the smallest residual (best fit). Among near-equal residuals, avoid
leaving tiny slivers (residuals well below the running mean item size) that
are effectively wasted, and give a strong bonus to exact fills.
"""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    m = _mean

    residual = (bins - item).astype(np.float64)  # remaining capacity after placing here

    # Best-fit tightness: strongly prefer smaller residual.
    tightness = -residual

    # Sliver penalty: positive residuals below the running mean are likely
    # unreusable dead capacity; penalize them, scaled by how dead they are.
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Strong bonus for exact fills (residual 0).
    exact = np.where(residual == 0.0, 5.0, 0.0)

    # Extra incentive not to create a small-but-nonzero residual when a larger
    # reusable residual is nearly as good is already captured by tightness;
    # keep the rule clean to avoid overriding genuine best-fit choices.

    return tightness - penalty + exact
# EVOLVE-BLOCK-END
