# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break. Prior versions showed that any
large deviation from best-fit hurts; here we keep best-fit dominant and use a
fixed, distribution-informed threshold for the sliver/waste penalties (the item
distribution is Weibull-shaped with mean ~40), avoiding the noise of a running
estimate."""
import numpy as np

# Fixed threshold derived from the problem's stated distribution (mean ~40).
# A residual below this is likely a dead sliver; above it is plausibly reusable.
_T = 30.0

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _mean, _count

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -residual.astype(np.float64)

    # Penalize dead slivers (positive residual below the typical item size).
    sliver = (residual > 0) & (residual < _T)
    penalty = np.where(sliver, (_T - residual) * 2.0, 0.0)

    # Strongly prefer exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Extra waste term: residual just below T is especially likely unreusable.
    near = (residual > 0) & (residual < _T)
    waste = np.where(near, (1.0 - residual / _T) * 1.0, 0.0)

    return tightness - penalty + exact - waste
# EVOLVE-BLOCK-END
