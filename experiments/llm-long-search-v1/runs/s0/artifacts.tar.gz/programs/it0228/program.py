# EVOLVE-BLOCK-START
"""Best fit with exact-fill, modal-complement, and a mean-reusability bonus."""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _mean, _count, _hist

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item
    tightness = -residual.astype(np.float64)

    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    exact = (residual == 0).astype(np.float64) * 5.0

    r = residual
    valid = r >= 1
    if _count > 0:
        modal = int(np.argmax(_hist[1:])) + 1
        match = (valid & (r == modal)).astype(np.float64)
    else:
        match = np.zeros_like(r, dtype=np.float64)
    complement = match * 3.0

    # Gentle reusability bonus: residual near the running mean is the most
    # likely size to be reused next; narrower peak so it acts as a tie-break.
    sigma = max(m * 0.25, 5.0)
    reuse = valid.astype(np.float64) * np.exp(-((r - m) ** 2) / (2.0 * sigma * sigma)) * 0.5

    return tightness - penalty + exact + complement + reuse
# EVOLVE-BLOCK-END
