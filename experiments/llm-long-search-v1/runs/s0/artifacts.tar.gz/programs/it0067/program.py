# EVOLVE-BLOCK-START
"""Best fit with a mild penalty for leaving unusable tiny remainders."""
import numpy as np


def priority(item, bins):
    """Rank bins: tightest fit first, but avoid leaving remainders too small to reuse."""
    rem = bins - item
    # A remainder of r can still be useful if it can hold some future item.
    # Discount scores that leave a tiny remainder, since that space is likely wasted.
    # Normalize penalty so it only matters at small r scaled by item size.
    tiny = rem < 10
    penalty = np.where(tiny, (10 - rem) * 0.05, 0.0)
    return -(rem) - penalty
# EVOLVE-BLOCK-END
