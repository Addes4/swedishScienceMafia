# EVOLVE-BLOCK-START
"""Best fit with a lightweight, deterministic complement tie-break.

Primary score is best-fit tightness (prefer the smallest residual, so exact
fills win naturally). A strictly-sub-1 tie-break mildly prefers leaving a
residual that is likely to be reusable by a future item (a small set of common
sizes around the running mean), so we avoid dead slivers without letting the
tie-break ever override the tightness ordering.
"""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority per bin; item goes to the highest (first on ties)."""
    global _mean, _count

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = (bins - item).astype(np.float64)

    # Dominant term: best fit -> smallest residual is best.
    tightness = -residual

    # Exact fills get a small decisive but bounded bonus.
    exact = (residual == 0).astype(np.float64) * 0.5

    # Sub-1 tie-break: prefer leaving a residual that is a "useful" size,
    # i.e. close to a typical item size (around the running mean). This keeps
    # leftover space reusable instead of leaving dead slivers.
    m = _mean
    if m < 1.0:
        m = 1.0
    # How close residual is to a common size (m or 2m), in [0, 1].
    d1 = np.abs(residual - m) / m
    d2 = np.abs(residual - 2.0 * m) / (2.0 * m)
    closeness = np.maximum(0.0, 1.0 - np.minimum(d1, d2))
    useful = closeness * 0.1

    # Exact fill already handled; don't double count residual 0.
    useful = np.where(residual == 0, 0.0, useful)

    return tightness + exact + useful
# EVOLVE-BLOCK-END
