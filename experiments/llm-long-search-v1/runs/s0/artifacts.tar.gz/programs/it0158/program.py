# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break based on a running mean.

Prefers the smallest non-negative residual (best fit), with a strong bonus for
exact fills and a mild penalty for unusable slivers below a typical item size.
"""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    # Penalize residuals that are positive but smaller than a typical item:
    # such slivers are effectively wasted capacity.
    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 1.5, 0.0)

    # Strong bonus for exact hits (residual 0).
    exact = (residual == 0).astype(np.float64) * 8.0

    # Waste-aware term: a residual just below the mean is likely never reused.
    near_full = (residual > 0) & (residual < m)
    waste = np.where(near_full, (1.0 - residual / m) * 1.0, 0.0)

    return tightness - penalty + exact - waste
# EVOLVE-BLOCK-END
