# EVOLVE-BLOCK-START
"""Best fit with a soft sweet-spot bias on the post-placement residual.

Primary term is best-fit tightness (smaller residual = better). A small
secondary bonus prefers leaving a residual that is likely reusable by a
future item (roughly in [10, 60]), while still being dominated by the
tightness term so the tightest fitting bin is essentially always chosen.
"""
import numpy as np

# small weight for the residual sweet-spot bonus; must not override tightness
_W = 1e-3


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # post-placement remaining capacity (>= 0)

    # Sweet-spot bonus: peak around residual ~ 30 (typical future item size ~40),
    # zero far from it. Small so it only breaks near-ties in tightness.
    bonus = _W * np.exp(-((residual - 30.0) ** 2) / (2.0 * 20.0 ** 2))

    # Primary: tighter fit (smaller residual) is better -> use negative residual.
    return -residual.astype(np.float64) + bonus
# EVOLVE-BLOCK-END
