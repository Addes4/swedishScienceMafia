# EVOLVE-BLOCK-START
"""Best fit with a small guard against creating permanently unusable slivers."""
import numpy as np

_state = {"min_seen": 100}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    global _state
    if item < _state["min_seen"]:
        _state["min_seen"] = item
    rem = bins - item  # resulting remaining capacity
    # Base: tightest fit (most negative rem highest). Add exact-close bonus
    # and penalize remainders below the smallest item ever seen (waste).
    score = -rem.astype(np.float64)
    exact = (rem == 0)
    tiny = rem < _state["min_seen"]
    score = score + 0.5 * exact - 0.25 * tiny
    return score
# EVOLVE-BLOCK-END

