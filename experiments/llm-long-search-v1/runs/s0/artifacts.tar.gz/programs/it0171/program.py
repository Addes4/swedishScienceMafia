# EVOLVE-BLOCK-START
"""Best fit with a smooth tie-break: dominant tightness term plus a mild
preference for residuals that are 'balanced' (neither near-empty slivers nor
near-full wasted bins), computed purely from the bin array (no histogram)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Dominant term: best fit (smaller residual preferred).
    tightness = -r

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Mild penalty for slivers that are too small to hold a typical item
    # (mean ~40): such residuals are effectively wasted.
    sliver = (r > 0) & (r < 20.0)
    sliver_pen = np.where(sliver, (20.0 - r) * 0.1, 0.0)

    # Mild preference for balanced residuals around half a bin, which tend to
    # remain reusable, without dominating the tightness term.
    balanced = -np.abs(r - 50.0) * 0.02

    return tightness + exact - sliver_pen + balanced
# EVOLVE-BLOCK-END
