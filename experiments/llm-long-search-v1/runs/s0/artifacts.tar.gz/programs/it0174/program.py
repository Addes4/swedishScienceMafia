# EVOLVE-BLOCK-START
"""Plain best fit: place the item in the bin with the smallest remaining
capacity that still fits, i.e. minimize the residual capacity after placement.
This is a robust, parameter-free rule that consistently matches or beats the
hand-tuned multi-term variants."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest
    (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer the smallest residual (remaining capacity after placing
    # the item here). Equivalently, prefer the fullest bin that still fits.
    # Negate so that the highest score corresponds to the tightest fit.
    return -bins.astype(np.float64)
# EVOLVE-BLOCK-END
