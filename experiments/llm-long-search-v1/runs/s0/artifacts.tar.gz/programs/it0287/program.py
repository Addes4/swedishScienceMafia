# EVOLVE-BLOCK-START
"""Best fit with a small exact-fill bonus.

The core rule is best-fit: place the item where the residual is smallest.
A small bonus is added for exact fills (residual 0) so that perfect matches
are strongly preferred. All noisy histogram/mean-based penalties are removed
so that ordering within near-equal residuals isn't distorted.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    # Small bonus for exact fills (residual 0) to strongly prefer perfect matches.
    exact = (residual == 0).astype(np.float64) * 1.0

    return tightness + exact
# EVOLVE-BLOCK-END
