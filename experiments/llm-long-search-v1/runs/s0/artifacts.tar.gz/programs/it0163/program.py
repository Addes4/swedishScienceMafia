# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus and a small live-histogram complement
tie-break that rewards residuals likely to be reusable as future items."""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _mean, _count, _hist

    # Update running stats before scoring this item.
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing here

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -residual.astype(np.float64)

    # Strong exact-fill bonus.
    exact = (residual == 0).astype(np.float64) * 20.0

    # Penalize dead slivers: positive residuals smaller than a typical item.
    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Small live-histogram complement bonus: reward residuals that match a
    # frequently-seen item size, scaled strictly below 1 so it only breaks
    # ties among equal-tightness residuals.
    r = residual
    valid = r >= 1
    r_idx = np.where(valid, r, 0).astype(np.int64)
    if _count > 0:
        freq = _hist[r_idx] / _count
    else:
        freq = np.zeros_like(r, dtype=np.float64)
    freq = np.where(valid, freq, 0.0)
    complement = freq * 0.9

    return tightness + exact - penalty + complement
# EVOLVE-BLOCK-END
