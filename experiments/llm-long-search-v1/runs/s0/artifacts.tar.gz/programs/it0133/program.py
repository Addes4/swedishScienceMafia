# EVOLVE-BLOCK-START
"""Best fit with a small exact-fill bonus; monotone in post-placement residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties go to first bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit: prefer the smallest residual. Dominant, monotone term.
    score = -residual.astype(np.float64)

    # Tiny bonus for exact fills so a perfect fit is never displaced by an
    # equal-residual alternative (keep it small so it never overrides best-fit).
    exact = (residual == 0).astype(np.float64) * 1e-3

    return score + exact
# EVOLVE-BLOCK-END
