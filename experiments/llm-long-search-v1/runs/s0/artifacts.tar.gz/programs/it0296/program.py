# EVOLVE-BLOCK-START
"""Best fit with a data-driven expected-reuse bonus.

Core is best-fit (prefer small residual). We add:
  * a strong bonus for exact fills (residual 0),
  * a penality for slivers (residual < mean item size, but > 0),
  * a smooth bonus proportional to the empirical probability that the
    residual is exactly the size of a coming item, using a histogram of
    seen items, and a light term rewarding residuals that combine with a
    typical future item.
"""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    m = _mean

    # Penalize residuals that are positive but smaller than a typical item:
    # such slivers are effectively wasted capacity.
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Smooth data-driven expected-reuse bonus: probability (from the empirical
    # histogram) that the residual equals an item size that will arrive later.
    valid = residual >= 1
    p = np.zeros_like(residual, dtype=np.float64)
    if _count > 0:
        norm = _hist[1:].sum()
        if norm > 0:
            probs = _hist[1:] / norm
            r = residual.astype(np.int64)
            in_range = valid & (r <= 100)
            safe_r = np.clip(r, 1, 100)
            p = np.where(in_range, probs[safe_r - 1], 0.0)
    complement = p * 3.0

    # Light waste-aware term: residuals just below the mean are more likely
    # to go permanently unused.
    near_full = (residual > 0) & (residual < m)
    waste = np.where(near_full, (1.0 - residual / m) * 1.0, 0.0)

    return tightness - penalty + exact + complement - waste
# EVOLVE-BLOCK-END

