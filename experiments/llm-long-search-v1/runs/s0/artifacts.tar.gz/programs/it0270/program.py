# EVOLVE-BLOCK-START
"""Best fit with a monotone tie-break that favors residuals large enough to be
reusable (at least a typical item size), so genuine best-fit ordering is never
disturbed but useful leftovers are preferred."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here

    # Primary: best-fit tightness (smaller residual first).
    tightness = -residual.astype(np.float64)

    # Tie-break: among equal residuals, mildly prefer leftover capacity that is
    # large enough to still be reusable by a future item (>= running mean).
    # Scale is tiny and strictly monotone in residual so the true best-fit
    # choice is never overridden.
    reusable = (residual >= _mean).astype(np.float64)

    return tightness + reusable * 1e-3
# EVOLVE-BLOCK-END

