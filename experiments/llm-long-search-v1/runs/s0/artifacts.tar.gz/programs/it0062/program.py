# EVOLVE-BLOCK-START
"""Proportional-fit: rank bins by how well the item's size matches the bin's remaining capacity."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    b = bins.astype(np.float64)
    return item / (item + b)
# EVOLVE-BLOCK-END
