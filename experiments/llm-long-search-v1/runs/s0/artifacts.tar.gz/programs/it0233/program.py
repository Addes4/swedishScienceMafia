# EVOLVE-BLOCK-START
"""Best fit with a gentle, distribution-aware tie-break.

Core: best-fit (smallest residual). Ties are broken by rewarding residuals that
are likely to be reusable by a future item, using only the running mean of seen
items (a robust, low-variance statistic) rather than a noisy histogram/modal.
"""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Best-fit tightness: strongly prefer smaller residual.
    tightness = -r

    # Strong bonus for exact fills (perfect packing).
    exact = (residual == 0).astype(np.float64) * 6.0

    # Gentle reusability bonus: a residual near the running-mean item size is
    # the single most likely leftover to be useful next, since future items
    # cluster around that mean. This only breaks ties among equal tightness.
    m = _mean
    if m > 1.0:
        reuse = np.exp(-((r - m) ** 2) / (2.0 * (0.5 * m) ** 2))
    else:
        reuse = np.zeros_like(r)
    # Only reward positive residuals (a full bin has no leftover).
    reuse = np.where(r > 0, reuse, 0.0)

    return tightness + exact + reuse * 1.5
# EVOLVE-BLOCK-END
