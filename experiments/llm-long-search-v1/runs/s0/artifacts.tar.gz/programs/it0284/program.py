# EVOLVE-BLOCK-START
"""Best-fit with a bounded, self-scaling refinement: tightness dominates;
exact fills and small-sliver avoidance only break near-ties."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity if placed here
    r = residual.astype(np.float64)
    m = _mean

    # Primary: best-fit tightness (prefer smallest residual). This term changes
    # by 1.0 between adjacent integer residuals, so it decides ordering.
    tightness = -r

    # Secondary terms are strictly bounded by 0.95 in magnitude so they can only
    # refine ties or near-ties and never override the best-fit ordering.
    # Strong but bounded bonus for an exact fill.
    exact = (residual == 0).astype(np.float64) * 0.9

    # Smooth waste term: a residual that is positive but below a typical item is
    # largely unrecoverable dead space. Penalize strictly by how far below the
    # running mean it is, normalized into [0, 1) so it stays a tie-breaker.
    sliver = (residual > 0) & (r < m)
    waste = np.where(sliver, (1.0 - r / np.maximum(m, 1.0)) * 0.5, 0.0)

    return tightness + exact - waste
# EVOLVE-BLOCK-END
