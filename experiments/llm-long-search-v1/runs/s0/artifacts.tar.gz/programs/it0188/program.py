# EVOLVE-BLOCK-START
"""Dominant best-fit: prefer the smallest residual after placing the item, with
exact fills strongly preferred. All decisions are dominated by residual; no
noisy data-driven terms (which previously hurt) are used."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual. Scaled so it strictly
    # dominates any tie-break term below.
    tightness = -residual.astype(np.float64) * 1000.0

    # Exact fill gets a bonus that only matters within the same residual (can't
    # exceed the 1000 gap between adjacent residuals).
    exact = (residual == 0).astype(np.float64) * 10.0

    return tightness + exact
# EVOLVE-BLOCK-END
