# EVOLVE-BLOCK-START
"""Best-fit with a sub-unit exact-fill tie-break.

The dominant term is best-fit (smaller residual first). Because residuals are
integers, a bonus strictly less than 1 can only break ties between bins with
equal residual and can never disturb the primary best-fit ordering. We use this
to strongly prefer exact fills (residual 0) whenever they are tied.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary: best-fit (prefer smaller residual).
    tightness = -residual.astype(np.float64)

    # Sub-unit bonus for exact fills: only affects ties, never the main order.
    exact = (residual == 0).astype(np.float64) * 0.5

    return tightness + exact
# EVOLVE-BLOCK-END

