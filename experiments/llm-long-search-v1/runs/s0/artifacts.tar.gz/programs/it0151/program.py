# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break based on a running histogram of
seen item sizes. The residual is rewarded by how much of the empirical item-size
distribution still fits in it (reusable capacity), which naturally penalizes
dead slivers just below the mean item size and rewards fully reusable leftovers."""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)
# Cumulative distribution (CDF) of seen item sizes: _cdf[s] = P(past item <= s).
_cdf = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties)."""
    global _mean, _count, _hist, _cdf

    # Update running mean, histogram, and CDF of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0
    if _count > 0:
        _cdf = np.cumsum(_hist) / _count

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -residual.astype(np.float64)

    # Exact fill bonus.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Data-driven reusability: fraction of past items that would still fit in
    # the residual. Small residuals that can't hold typical items are penalized,
    # large reusable leftovers are rewarded.
    r = residual
    valid = r >= 1
    r_idx = np.where(valid, r, 0).astype(np.int64)
    r_idx = np.where(r_idx > 100, 100, r_idx)
    reusable = np.where(valid, _cdf[r_idx], 0.0)
    complement = reusable * 3.0

    return tightness + exact + complement
# EVOLVE-BLOCK-END
