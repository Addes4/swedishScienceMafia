# EVOLVE-BLOCK-START
"""Best fit with a strong (but small) preference for exact fills."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit: prefer smaller residual (dominant term).
    score = -residual.astype(np.float64)

    # Small bonus for exact fills so a perfect placement is never displaced.
    score += (residual == 0).astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END

