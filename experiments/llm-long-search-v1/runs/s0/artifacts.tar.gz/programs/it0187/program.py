# EVOLVE-BLOCK-START
"""Best fit with a large-scale tightness term so auxiliary terms only act as
tie-breakers among equal residuals."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    global _mean, _count
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing item here

    # Dominant: prefer the smallest non-negative residual (best fit).
    tightness = -residual.astype(np.float64) * 1000.0

    # Strong preference for exact fills.
    exact = (residual == 0).astype(np.float64) * 100000.0

    # Mild penalty for tiny slivers that are likely never reusable.
    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual), 0.0)

    return tightness + exact - penalty
# EVOLVE-BLOCK-END
