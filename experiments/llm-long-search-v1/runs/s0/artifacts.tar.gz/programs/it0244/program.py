# EVOLVE-BLOCK-START
"""Best-fit with a tiny bounded histogram-based tie-break.

The dominant term is pure best-fit (-residual), which is strong for online bin
packing. A small bonus (< 1) rewards residuals equal to a frequently seen item
size, nudging near-ties toward more reusable leftovers without ever overriding
the best-fit ordering (since best-fit differences are at least 1).
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update histogram of past items (before scoring this one).
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Pure best-fit: prefer smaller residual. Integer residuals differ by >= 1,
    # so a bonus strictly below 1 cannot override best-fit ordering.
    tightness = -residual.astype(np.float64)

    # Tiny reusability bonus: reward residuals that match a frequently seen item
    # size, since such a leftover is more likely to be exactly reused.
    total = _hist[1:].sum()
    if total > 0:
        freq = _hist / total
        bonus = freq[residual]  # 0 for residual <= 0 or > 100
    else:
        bonus = np.zeros_like(tightness)

    # Bound the bonus to stay below 1 and avoid NaNs.
    bonus = np.clip(bonus, 0.0, 0.9)

    return tightness + bonus
# EVOLVE-BLOCK-END
