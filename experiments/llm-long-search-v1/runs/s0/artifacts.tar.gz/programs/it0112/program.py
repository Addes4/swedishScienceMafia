# EVOLVE-BLOCK-START
"""Best fit with a bonus for leaving small-but-still-usable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (smallest residual after placing).
    # Secondary: small bonus for residuals that are still usable (>= 5) but very tight,
    # which slightly favors leaving compact gaps over slivers.
    usable = residual >= 5
    return -(residual.astype(np.float64)) + 0.01 * usable - 0.5 * ((residual < 5) & (residual > 0))
# EVOLVE-BLOCK-END
