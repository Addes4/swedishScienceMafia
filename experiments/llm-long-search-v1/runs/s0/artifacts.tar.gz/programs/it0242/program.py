# EVOLVE-BLOCK-START
"""Best fit with a small, frequency-weighted complement bonus from a running
histogram of seen item sizes, used only to break near-ties in favor of
residuals that are likely reusable."""
import numpy as np

_count = 0
# Histogram of seen item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)
# Cached, normalized histogram used as a complement bonus lookup.
_bonus = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _count, _hist, _bonus

    # Update histogram of past items and refresh the normalized bonus lookup.
    _count += 1
    _hist[item] += 1.0
    _bonus[:] = _hist / _count  # fraction of past items of each size

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer the smallest residual (dominant term).
    tightness = -residual.astype(np.float64)

    r = residual.astype(np.int64)

    # Frequency-weighted complement bonus: reward residuals whose size matches a
    # common seen item size, since such a leftover is most likely reusable.
    valid = (r >= 1) & (r <= 100)
    match_bonus = np.where(valid, _bonus[np.clip(r, 0, 100)], 0.0)

    return tightness + match_bonus * 2.0
# EVOLVE-BLOCK-END
