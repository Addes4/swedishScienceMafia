# EVOLVE-BLOCK-START
"""Best fit with a matching bonus: prefer bins that the item completes toward a full bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    gap = bins - item
    # Primary: tighter fit (smaller post-placement remainder) is better.
    score = -gap.astype(np.float64)
    # Bonus: strongly favor bins that would end nearly full (small residual waste).
    score += 0.5 * (gap == 0)
    score += 0.25 * (gap == 1)
    return score
# EVOLVE-BLOCK-END
