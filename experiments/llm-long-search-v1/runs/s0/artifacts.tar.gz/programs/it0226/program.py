# EVOLVE-BLOCK-START
"""Best fit with a smoothed frequency-weighted complement bonus.

Prefer small residuals (best fit), strongly prefer exact fills, and mildly
reward residuals whose size is a commonly seen item size so the leftover is
likely reusable. Frequencies are smoothed so the term generalizes instead of
chasing a noisy single mode.
"""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    # Penalize unusable slivers: positive residuals smaller than a typical item.
    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Smoothed frequency-weighted complement bonus: reward residuals matching
    # common item sizes, weighted by their (normalized) empirical frequency.
    if _count > 0:
        freq = _hist / _count
        # Light smoothing so rare sizes still get a tiny, stable weight.
        weights = freq + (1.0 / (101.0 * max(_count, 1)))
        r = residual.astype(np.int64)
        valid = (r >= 1) & (r <= 100)
        comp = np.zeros_like(weights)
        comp[1:] = weights[1:]
        score = np.where(valid, comp[np.clip(r, 0, 100)], 0.0)
        complement = score * 200.0
    else:
        complement = np.zeros_like(residual, dtype=np.float64)

    return tightness - penalty + exact + complement
# EVOLVE-BLOCK-END
