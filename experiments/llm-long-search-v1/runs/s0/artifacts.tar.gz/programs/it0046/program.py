# EVOLVE-BLOCK-START
"""Best fit with a small penalty for producing tiny unusable remainders."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remain = bins - item
    # Primary: tightest fit (smallest remainder). Secondary: penalize remainders
    # that are smaller than a typical future item (likely wasted), so we prefer
    # bins whose leftover is more likely reusable.
    penalty = np.maximum(0, item - remain)
    return -remain - 0.05 * penalty
# EVOLVE-BLOCK-END
