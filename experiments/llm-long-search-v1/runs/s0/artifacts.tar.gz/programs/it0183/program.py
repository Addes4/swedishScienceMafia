# EVOLVE-BLOCK-START
"""Best-fit bin packing: place each item into the bin with the smallest
remaining capacity that still fits it (smallest resulting residual).

This is the classic Best-Fit heuristic, which is near-optimal for many
distributions and avoids the noisy extra terms that previously overrode the
tightness signal and reduced the packing quality.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer the smallest residual (most tightly packed bin).
    # residual >= 0 for all shown bins, so -residual ranks tighter bins higher.
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
