# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break derived from the empirical
item-size distribution of items seen so far."""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)
_min_seen = 100


def priority(item, bins):
    global _mean, _count, _hist, _min_seen

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0
    if item < _min_seen:
        _min_seen = item

    residual = bins - item
    r = residual.astype(np.float64)

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -r

    m = _mean
    # Sliver penalty: positive residuals smaller than the smallest item seen
    # (or a typical item) can never be reused -> effectively wasted capacity.
    dead = (r > 0) & (r < _min_seen)
    dead_penalty = np.where(dead, (_min_seen - r) * 4.0, 0.0)
    # Smaller slivers below typical item size get a mild extra nudge to fill.
    sliver = (r > 0) & (r < m)
    sliver_penalty = np.where(sliver, (m - r) * 0.5, 0.0)

    # Strong bonus for exact fills.
    exact = (r == 0).astype(np.float64) * 6.0

    # Reusability bonus: reward residual that is a multiple of a frequently
    # seen size (most likely to be exactly filled later), scaled by that
    # size's frequency share.
    bonus = np.zeros_like(r)
    if _count > 0:
        total = _count
        # Consider the most common item sizes seen so far.
        order = np.argsort(_hist[1:])[::-1][:5] + 1
        for s in order:
            freq = _hist[s]
            if freq <= 0:
                continue
            share = freq / total
            multi = (r >= 1) & (r % s == 0)
            bonus += multi.astype(np.float64) * share * 2.0

    return tightness - dead_penalty - sliver_penalty + exact + bonus
# EVOLVE-BLOCK-END
