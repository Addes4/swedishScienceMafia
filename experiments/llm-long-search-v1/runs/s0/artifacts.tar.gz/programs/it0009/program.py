# EVOLVE-BLOCK-START
"""Best fit with a penalty for stranding a mid-sized remainder."""
import numpy as np

_TYPICAL = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    rem = bins - item
    # Base: prefer tightest fit (smallest remainder).
    score = -rem.astype(np.float64)
    # Penalize remainders that are hard to reuse: small but not tiny, below a typical item.
    # rem in (0, _TYPICAL) is bad; rem == 0 or rem >= _TYPICAL is fine.
    bad = np.clip(_TYPICAL - rem, 0.0, _TYPICAL)  # 0 if rem>=40, grows as rem shrinks
    # Exclude the exactly-zero (perfect) case from the penalty.
    bad = np.where(rem == 0, 0.0, bad)
    score -= 0.5 * bad
    return score
# EVOLVE-BLOCK-END
