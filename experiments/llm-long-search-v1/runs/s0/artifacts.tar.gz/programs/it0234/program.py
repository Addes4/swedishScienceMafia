# EVOLVE-BLOCK-START
"""Best fit with a bounded residual-usability tie-break based on a running
histogram of seen item sizes (to nudge residuals toward frequently reusable
sizes) without disturbing the dominant best-fit ordering."""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100), used to reward residuals that match
# a common leftover size.
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual. Scaled so it dominates.
    tightness = -residual.astype(np.float64) * 10.0

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Data-driven complement bonus: reward residuals that equal the most
    # frequently seen item size so far, since such a leftover is the size most
    # likely to be reusable by a future item. Kept small (< tightness step)
    # so it only breaks ties between equal residuals.
    r = residual
    valid = r >= 1
    if _count > 0:
        modal = int(np.argmax(_hist[1:])) + 1
        # decay the bonus as the histogram grows, keeping it a gentle tie-break
        strength = 3.0 / (1.0 + 0.001 * _count)
        match = (valid & (r == modal)).astype(np.float64)
    else:
        match = np.zeros_like(r, dtype=np.float64)
        strength = 0.0
    complement = match * strength

    return tightness + exact + complement
# EVOLVE-BLOCK-END
