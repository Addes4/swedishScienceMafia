# EVOLVE-BLOCK-START
"""Best-fit plus a bonus for remainders matching a previously seen item size."""
import numpy as np

_seen = np.zeros(101, dtype=np.int64)
_seen_counts = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # post-placement remainder (>= 0 since bins are only those that fit)

    # Match score: how many past items had size exactly equal to this remainder.
    # Rows: remainder value 0..100. Use the online histogram of past item sizes.
    match = _seen_counts[rem]

    # Primary: best-fit tightness (smaller remainder is better => larger negative penalty).
    # Secondary: bonus when the leftover gap can be exactly filled by a seen item size.
    score = -rem.astype(np.float64) + 3.0 * match

    # Update history with the current item AFTER scoring (item is not its own successor).
    _seen_counts[item] += 1.0

    return score
# EVOLVE-BLOCK-END
