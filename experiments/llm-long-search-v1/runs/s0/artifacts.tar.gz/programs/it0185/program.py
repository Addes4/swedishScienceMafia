# EVOLVE-BLOCK-START
"""Best-fit with residual-usability tie-breaks driven by a small running
histogram of seen item sizes. Tightness (smallest residual) is the dominant
decision; extra terms only reshape near-ties to favor leftovers that are
likely reusable."""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)

# Size buckets: estimates of what counts as a "common" reusable leftover.
# A residual is more attractive if it is close to one of these.
_BUCKETS = np.array([5.0, 10.0, 15.0, 20.0, 25.0, 30.0, 40.0, 50.0], dtype=np.float64)
_BUCKET_IDX = _BUCKETS.astype(np.int64)


def priority(item, bins):
    global _mean, _count, _hist

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item
    tightness = -residual.astype(np.float64)

    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    exact = (residual == 0).astype(np.float64) * 8.0

    # Data-driven complement: residual equal to the current item size (perfect
    # pairing of identical items) gets a bonus.
    same = (residual == item).astype(np.float64) * 4.0

    # Reward residuals close to common reusable leftover buckets.
    r = residual.astype(np.float64)
    valid = residual >= 1
    best_dist = np.full(r.shape, 1e9, dtype=np.float64)
    for b in _BUCKETS:
        d = np.abs(r - b)
        best_dist = np.minimum(best_dist, d)
    bucket_bonus = np.where(valid, np.exp(-(best_dist ** 2) / 50.0) * 2.0, 0.0)

    # Histogram frequency bonus for residuals equal to a frequently-seen size.
    r_idx = np.where(valid, residual, 0).astype(np.int64)
    freq = _hist[r_idx] / _count if _count > 0 else np.zeros_like(r)
    freq = np.where(valid, freq, 0.0)
    complement = freq * 3.0

    near_full = (residual > 0) & (residual < m)
    waste = np.where(near_full, (1.0 - residual / m) * 1.0, 0.0)

    return tightness - penalty + exact + same + bucket_bonus + complement - waste
# EVOLVE-BLOCK-END
