# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break based on the empirical size
histogram: prefer tight fits, but among similar residuals favor those most
likely to be exactly refillable by upcoming items."""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100), used to estimate reuse value of
# candidate residuals.
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins.astype(np.int64) - item  # remaining capacity after placing here
    residual = np.clip(residual, 0, 100)

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    m = _mean

    # Penalize residuals that are positive but smaller than a typical item:
    # such slivers are effectively wasted capacity.
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Strong bonus for exact fills (residual 0).
    exact = (residual == 0).astype(np.float64) * 5.0

    # Reuse value: estimate how likely a residual can be exactly refilled by
    # a single future item (empirical frequency) plus a bonus if it could be
    # filled by two typical items summing to the residual. This favors keeping
    # leftovers that are actually recoverable.
    if _count > 0:
        total = _count
        single = _hist[residual] / total  # P(next item == residual)
        # Two-item refill likelihood (coarse): for residual r, sum over splits.
        # Use a normalized convolution of the histogram with itself.
        h = _hist / total
        conv = np.convolve(h, h)  # index = sum of two item sizes
        pair = np.zeros_like(residual, dtype=np.float64)
        valid = residual >= 2
        conv_len = conv.shape[0]
        idx = np.clip(residual, 0, conv_len - 1)
        pair = np.where(valid, conv[idx], 0.0)
        # Scale reuse strength to act as a fine tie-breaker under tightness.
        reuse = (single + 0.5 * pair) * 20.0
    else:
        reuse = np.zeros_like(residual, dtype=np.float64)

    return tightness - penalty + exact + reuse
# EVOLVE-BLOCK-END

