# EVOLVE-BLOCK-START
"""Best fit with a tiny structural tie-break toward low-fragmentation remainders."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (smaller residual best).
    base = -(residual.astype(np.float64))
    # Secondary, tiny: prefer residual near 0 (exact fill) or near mean item size ~40
    # (leaving room for a typical future item), penalize awkward middle remainders.
    d0 = residual.astype(np.float64)
    d40 = np.abs(residual - 40.0).astype(np.float64)
    secondary = -(0.002 * d0) - (0.001 * d40)
    return base + secondary
# EVOLVE-BLOCK-END
