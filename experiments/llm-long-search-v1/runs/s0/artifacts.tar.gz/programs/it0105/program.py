# EVOLVE-BLOCK-START
"""Best fit with a strong exact-fill bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remainder = bins - item          # post-placement remaining capacity (>= 0)
    tight = -remainder.astype(np.float64)
    exact = (remainder == 0).astype(np.float64) * 1000.0
    return tight + exact
# EVOLVE-BLOCK-END
