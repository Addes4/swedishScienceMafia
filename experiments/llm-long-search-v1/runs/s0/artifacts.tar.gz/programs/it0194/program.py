# EVOLVE-BLOCK-START
"""Best fit with a strictly-dominant tightness term and a small tie-break that
rewards residuals matching the current item size (encouraging exact pairing)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness, scaled so it strictly dominates any tie-break.
    tightness = -residual.astype(np.float64) * 1000.0

    # Small bonus when the leftover equals the current item size: the residual
    # can later host an identical item, an exact pairing.
    pair = (residual == item).astype(np.float64)

    return tightness + pair
# EVOLVE-BLOCK-END
