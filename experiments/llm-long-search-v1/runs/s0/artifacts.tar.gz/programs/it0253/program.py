# EVOLVE-BLOCK-START
"""Best fit with a smooth, bounded dead-sliver penalty based on a running mean
of seen item sizes. Best-fit ordering dominates; residuals that fall below a
typical item size are mildly discouraged because they are unlikely to be reused."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    # Smooth, bounded penalty for residuals that are positive but below a
    # typical item size (dead slivers), scaled so it can only break ties among
    # near-equal best-fit candidates.
    m = _mean
    r = residual.astype(np.float64)
    dead = (r > 0) & (r < m)
    penalty = np.where(dead, 1.0 - r / m, 0.0)

    return tightness - penalty
# EVOLVE-BLOCK-END

