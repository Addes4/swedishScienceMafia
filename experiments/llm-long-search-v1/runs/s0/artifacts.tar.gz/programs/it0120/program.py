# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break based on a running mean item size."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (before scoring this one, then include it).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    # Penalize residuals that are positive but clearly too small to be useful:
    # only slivers below half the typical item are effectively wasted capacity.
    m = _mean
    thresh = 0.5 * m
    sliver = (residual > 0) & (residual < thresh)
    penalty = np.where(sliver, (thresh - residual) * 1.5, 0.0)

    # Small bonus for exact fills to strongly prefer filling bins completely.
    exact = (residual == 0).astype(np.float64) * 5.0

    return tightness - penalty + exact
# EVOLVE-BLOCK-END
