# EVOLVE-BLOCK-START
"""Best-fit blended with a small worst-fit correction driven by an online mean.

Primary criterion is best-fit (tightest remaining gap). But when the resulting
remainder is small (below the online running mean item size), such a gap is
likely to become unusable, so we instead prefer the bin that leaves the largest
possible remainder. This keeps tight fills when they close a bin nicely and
avoids scattering tiny unusable gaps otherwise.
"""
import numpy as np


def priority(item, bins):
    # online running mean of item sizes (updated after scoring is fine; item
    # is included so the estimate shifts toward the current item's scale)
    state = priority.state
    state['n'] += 1
    state['sum'] += item
    mean = state['sum'] / state['n']

    rem = bins - item          # post-placement remainder for each bin
    # tightness: smaller remainder => higher score
    score = -rem.astype(np.float64)
    # Where the remainder is a tiny (likely unusable) gap, push toward larger
    # remainders instead by adding a bonus proportional to how small rem is
    # relative to a useful gap size (the mean item size).
    tiny = rem < mean
    score[tiny] += (mean - rem[tiny]) * 0.5
    return score


priority.state = {'n': 0, 'sum': 0.0}
# EVOLVE-BLOCK-END
