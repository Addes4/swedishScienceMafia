# EVOLVE-BLOCK-START
"""Best fit with soft, secondary terms: a sliver penalty for unusably small
residuals, an exact-fill bonus, and a data-driven complement bonus that rewards
leftovers matching frequently seen item sizes. Best-fit ordering stays dominant."""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100), used to reward residuals that match
# a common leftover size.
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness dominates: a large weight keeps the best-fit order
    # (smallest residual first) as the primary key.
    tightness = -residual.astype(np.float64) * 10.0

    # Penalize residuals that are positive but smaller than a typical item:
    # such slivers are effectively wasted capacity.
    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Bonus for exact fills (residual 0) to strongly prefer exact matches.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Data-driven complement bonus: reward residuals that equal an item size we
    # have seen frequently, so the leftover is likely reusable.
    r = residual
    valid = r >= 1
    r_idx = np.where(valid, r, 0).astype(np.int64)
    if _count > 0:
        freq = _hist[r_idx] / _count
    else:
        freq = np.zeros_like(r, dtype=np.float64)
    freq = np.where(valid, freq, 0.0)
    complement = freq * 3.0

    return tightness - penalty + exact + complement
# EVOLVE-BLOCK-END

