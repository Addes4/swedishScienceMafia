# EVOLVE-BLOCK-START
"""Best-fit core with exact-fill bonus, a reusable-residual bonus keyed to the
most common seen item size, and a mild penalty for unusable slivers."""
import numpy as np

_count = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _count, _hist

    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing here
    r = residual.astype(np.float64)

    # Best-fit tightness: prefer smaller residual.
    score = -r

    # Strong bonus for exact fill.
    score += np.where(residual == 0, 6.0, 0.0)

    # Reward residuals that can be filled tightly by the most common item size
    # seen so far (reusable leftover).
    if _count > 0:
        modal = int(np.argmax(_hist[1:])) + 1
        score += np.where(residual == modal, 2.0, 0.0)

    # Mild penalty for positive residuals smaller than a common item: such
    # slivers are effectively wasted capacity.
    if _count > 1:
        mean = float(np.dot(np.arange(1, 101), _hist[1:]) / _count)
        sliver = (residual > 0) & (r < mean)
        score -= np.where(sliver, (mean - r) * 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
