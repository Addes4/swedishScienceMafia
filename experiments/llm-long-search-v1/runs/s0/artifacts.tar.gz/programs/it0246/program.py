# EVOLVE-BLOCK-START
"""Best fit with a stable sliver penalty and a small data-driven reusability bonus."""
import numpy as np

_REF = 40.0  # fixed reference (mean of the known distribution)
_count = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _count, _hist

    _hist[item] += 1.0
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Core: best-fit (prefer the smallest residual).
    tightness = -r

    # Stable sliver penalty: residuals clearly below a typical item size are
    # effectively wasted. Bounded and smooth so best-fit ordering dominates.
    m = _REF
    frac = np.clip(r / m, 0.0, 1.0)
    sliver = (r > 0) & (r < m)
    penalty = np.where(sliver, (1.0 - frac) * 1.5, 0.0)

    # Strong bonus for exact fills.
    exact = (r == 0).astype(np.float64) * 6.0

    # Small data-driven bonus: reward residuals equal to a frequently-seen item
    # size, which are the most likely to be exactly reusable.
    if _count > 0:
        modal = int(np.argmax(_hist[1:])) + 1
        match = ((r >= 1) & (r == modal)).astype(np.float64)
    else:
        match = np.zeros_like(r)
    complement = match * 2.0

    return tightness - penalty + exact + complement
# EVOLVE-BLOCK-END
