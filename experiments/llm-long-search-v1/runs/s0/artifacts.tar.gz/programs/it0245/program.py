# EVOLVE-BLOCK-START
"""Strict best-fit with a small exact-fill bonus.

Among the bins the item fits in, prefer the one leaving the smallest residual
(standard best-fit). A tiny extra bonus for an exact fill (residual 0) slightly
biases toward closing bins, which reduces total bin count. No noisy
mean/histogram perturbations.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    score = -residual.astype(np.float64)

    # Strongly prefer exact fills.
    score += (residual == 0).astype(np.float64) * 5.0

    return score
# EVOLVE-BLOCK-END
