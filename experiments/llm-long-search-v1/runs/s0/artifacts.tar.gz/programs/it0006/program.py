# EVOLVE-BLOCK-START
"""Best fit with a tie-break that favors perfect fills and same-class bins."""
import numpy as np


def priority(item, bins):
    """Score each bin; highest wins (first on ties).

    Primary rule: best fit. Tie-break: prefer exact fills (remainder 0) and
    bins in the same capacity class as the item, reducing fragmentation.
    """
    rem = bins - item
    # Perfect fill gets a strong bonus.
    perfect = (rem == 0).astype(np.float64)
    # Same-class preference: residual within a modest band is preferred over
    # residual near a full item size (which fragments).
    class_bonus = 1.0 / (1.0 + np.abs(rem - item * 0.5))
    return -rem + 0.001 * perfect + 0.0005 * class_bonus
# EVOLVE-BLOCK-END
