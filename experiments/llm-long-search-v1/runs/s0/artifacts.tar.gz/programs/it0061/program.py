# EVOLVE-BLOCK-START
"""Best fit with a reserve term that keeps gaps usefully large."""
import numpy as np

_state = {"mean": 40.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # post-placement remainder, always >= 0 since item fits

    # Online exponentially weighted estimate of the typical item size.
    m = _state["mean"]
    n = _state["n"]
    if n == 0:
        m = float(item)
    else:
        m = 0.97 * m + 0.03 * float(item)
    _state["mean"] = m
    _state["n"] = n + 1

    reserve = 0.5 * m  # gap worth keeping

    # Dominant term: tightest fit.  Secondary term: reward remainders that are
    # either empty-ish or large enough to hold a typical future item.
    reward = np.where(rem >= reserve, 1.0, 0.0)
    return -(rem) * 1000.0 + reward * reserve
# EVOLVE-BLOCK-END
