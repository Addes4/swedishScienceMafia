# EVOLVE-BLOCK-START
"""Best fit with a mild fillability bonus on the post-placement remainder."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # remaining capacity after placing the item here
    # Primary: tightest fit (smallest remainder is best). Best fit is the strongest
    # simple online rule, so keep it as the dominant term.
    score = -rem.astype(np.float64)

    # Mild secondary term: reward remainders that are exactly divisible into many
    # "typical" items of size ~40 (the distribution mean), i.e. remainders near a
    # multiple of a representative chunk size, which tend to be cleanly fillable
    # later. Keep the magnitude small so best-fit ordering is rarely overridden.
    small = rem > 0
    frac = (rem % 40).astype(np.float64)
    fill_bonus = np.where(small, (20.0 - np.abs(frac - 20.0)) / 20.0, 0.0)
    score += 0.05 * fill_bonus

    return score
# EVOLVE-BLOCK-END

