# EVOLVE-BLOCK-START
"""Best fit with a mild residual-usability tie-break driven by a running mean
and a histogram of seen item sizes."""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant best-fit term: prefer the smallest residual.
    tightness = -r

    # Small bonus for exact fills.
    exact = (r == 0).astype(np.float64) * 2.0

    # Mild reusability bonus: reward residuals equal to the most frequent seen size.
    valid = r >= 1
    modal = int(np.argmax(_hist[1:])) + 1
    match = (valid & (r == modal)).astype(np.float64)
    complement = match * 1.5

    return tightness + exact + complement
# EVOLVE-BLOCK-END
