# EVOLVE-BLOCK-START
"""Best fit with a self-scaling dead-zone penalty and an exact/near-exact fill
bonus based on the current item size, avoiding fragile running-mean statistics."""
import numpy as np

_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _count
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Best-fit tightness: prefer smaller residual.
    tightness = -r

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 6.0

    # Mild dead-zone penalty: positive residuals smaller than the current item
    # are likely unusable slivers; scale by the current item size so the term
    # is self-scaling and not dependent on noisy running statistics.
    m = float(item)
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - r) / m * 1.5, 0.0)

    # Small bonus for residuals that are a near-complement of the item size,
    # i.e. residuals close to the item size, which pair well with similar items.
    near = (residual > 0)
    complement = np.where(near, -np.abs(r - m) / m * 0.5, 0.0)

    return tightness + exact - penalty + complement
# EVOLVE-BLOCK-END
