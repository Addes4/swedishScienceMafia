# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware remainder bonus.

Primary: tightest fit (smallest residual gap), as in classic Best Fit.
Secondary (tie-breaker within a tolerance): prefer the bin whose post-placement
remainder matches a frequent item size seen so far, so that future items can fill
it exactly. This targets the Weibull-shaped size distribution without tuning to
specific instances.
"""
import numpy as np


class _State:
    def __init__(self):
        # Coarse histogram of item sizes (1..100), used to score remainders.
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0

    def update(self, item):
        self.hist[item] += 1.0
        self.count += 1.0

    def remainder_value(self, rem):
        """How valuable is a leftover capacity `rem` (0..100)?

        Value is high when `rem` is close to a common future item size, so that
        the bin can be filled exactly later.
        """
        if rem <= 0:
            return 0.0
        h = self.hist
        if self.count <= 0.0:
            # Fallback: prefer small remainders that are "round-ish".
            return -float(rem)
        # Weight of item sizes near rem (within a small window).
        lo = max(1, rem - 3)
        hi = min(100, rem + 3)
        near = h[lo:hi + 1].sum()
        return near / self.count


_state = _State()


def priority(item, bins):
    """Rank bins: best fit first, then prefer remainders likely to be filled."""
    _state.update(item)
    gap = bins - item  # >= 0 for bins shown
    rem = gap  # remaining capacity after placement
    # Value of the remainder: higher is better (we negate gap to make higher=better).
    val = np.array([_state.remainder_value(int(r)) for r in rem], dtype=np.float64)
    # Tolerance: a bin whose gap is within this much of the tightest gap is
    # treated as a near-tie, and its remainder value breaks the tie.
    tol = max(1.0, 0.05 * item)
    return -gap.astype(np.float64) + tol * val
# EVOLVE-BLOCK-END
