# EVOLVE-BLOCK-START
"""Best fit with a mild exact-fill bonus; dominant rule stays best-fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness dominates: prefer smaller residual.
    score = -residual.astype(np.float64)

    # Mild bonus that increases as the residual shrinks toward zero, favoring
    # exact and near-exact fills without disturbing the best-fit ordering.
    score += 1.0 / (residual.astype(np.float64) + 1.0)

    return score
# EVOLVE-BLOCK-END
