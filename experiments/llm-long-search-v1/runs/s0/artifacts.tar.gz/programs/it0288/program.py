# EVOLVE-BLOCK-START
"""Best fit with a tiny exact-fill bonus.

Pure best-fit is a strong online rule for this distribution. The only addition
is a small, bounded bonus for an exact fill (residual 0), which is always
strictly good (wastes nothing and closes a bin), and a negligible tie-break
that prefers fuller bins among equal residuals.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit: prefer the smallest residual.
    score = -residual.astype(np.float64)

    # Tiny bonus for exact fills: strictly beneficial, bounded so it only
    # breaks ties toward closing a bin.
    score += (residual == 0) * 1e-3

    # Negligible tie-break among equal residuals: prefer the fuller bin
    # (smaller remaining capacity before placement) to reduce fragmentation.
    score += (100.0 - bins.astype(np.float64)) * 1e-6

    return score
# EVOLVE-BLOCK-END
