# EVOLVE-BLOCK-START
"""Best fit with a strong exact-fill bonus and a smooth sliver penalty."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Rank bins: prefer the tightest fit, heavily reward exact fills."""
    global _mean, _count

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -r

    # Strong bonus for exact fills: residual 0 means a perfectly packed bin.
    exact = (residual == 0).astype(np.float64) * 8.0

    # Penalize positive residuals that are smaller than a typical item: such
    # slivers are effectively wasted capacity and unlikely to be reused.
    m = _mean
    sliver = (r > 0) & (r < m)
    penalty = np.where(sliver, (1.0 - r / m) * 4.0, 0.0)

    return tightness + exact - penalty
# EVOLVE-BLOCK-END

