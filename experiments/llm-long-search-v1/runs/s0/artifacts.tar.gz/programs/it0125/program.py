# EVOLVE-BLOCK-START
"""Best-fit augmented with a residual-usability target derived from a live item-size histogram."""
import numpy as np

# Histogram of item sizes 1..100 seen so far, used to estimate how "usable" a residual is.
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _count

    # Update histogram of past items BEFORE scoring this one (uses only past info).
    if _count > 0:
        hist = _hist / _count
    else:
        hist = None

    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # remaining capacity after placing the item here
    res = residual.astype(np.float64)

    # Best-fit tightness: smaller residual is better.
    tightness = -res

    if hist is None:
        return tightness

    # Estimate, for each residual value, the probability it can be "closed" well later.
    # A residual r is usable if some future item of size exactly r (or filling it) arrives.
    # We value residuals by the probability mass of items that could fit into r,
    # discounted to reward tighter (less wasted) packing.
    sizes = np.arange(1, 101, dtype=np.float64)
    # Probability a single future item fits in a residual of size r.
    # For each candidate residual, sum the probability mass of items <= r.
    cum = np.cumsum(hist)          # cum[r-1] = P(size <= r)
    # Usability of residual r: chance it is fillable, times how much space it uses well.
    # We build a per-integer lookup for residuals 0..100.
    r = np.arange(0, 101, dtype=np.float64)
    fill_prob = np.zeros(101, dtype=np.float64)
    fill_prob[1:] = cum  # fill_prob[ri] = P(item <= ri) for ri>=1
    fill_prob[0] = 1.0   # residual 0 is perfectly good (exact fill)

    ri = np.clip(residual, 0, 100).astype(np.int64)
    usability = fill_prob[ri]

    # Reward residuals that are still fillable; discourage leaving unusable space.
    # Weight usability relative to best-fit tightness so best-fit still dominates.
    return tightness + 3.0 * usability
# EVOLVE-BLOCK-END

