# EVOLVE-BLOCK-START
"""Best fit with a light histogram-aware bonus on the post-placement remainder."""
import numpy as np

# Running histogram of item sizes seen so far (1..100), and total count.
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority per bin; highest wins (first on ties)."""
    global _count

    # Update running histogram (state kept between calls).
    _hist[item] += 1.0
    _count += 1.0

    rem = bins - item  # post-placement remaining capacity, all >= 0 since bins shown fit item

    # Base: best fit -> smaller remainder is better.
    score = -rem.astype(np.float64)

    # Fraction of observed items that would fit exactly-ish into a remainder r.
    # We want remainders that are likely to be fillable by future items.
    if _count > 0:
        # probability mass of item sizes <= remainder, normalized
        cum = np.cumsum(_hist)  # cum[r] = #items with size <= r
        tot = _count
        # For each bin remainder r, estimate "fillable" quality:
        # good if r == 0 (closed) or r can host a typical item (r >= mean-ish).
        # Use a smooth measure: expected fill fraction.
        r_clip = np.clip(rem, 0, 100).astype(np.int64)
        fillable = cum[r_clip] / tot  # in [0,1]
        # Bonus proportional to how fillable the remainder is; scale small so it only
        # breaks near-ties in the best-fit ordering.
        score += 0.5 * fillable

    return score
# EVOLVE-BLOCK-END
