# EVOLVE-BLOCK-START
"""Best fit with a fillability-aware tie-break.

The idea: pure best fit minimizes the immediate remainder, but often leaves a remainder
that no future item (or few small items) can use well, causing fragmentation.  We keep a
running histogram of past item sizes (they are i.i.d. from a fixed distribution) and score
each candidate bin by how well the post-placement remainder can be consumed by typical
future items, using a congruence / reachability heuristic.

Score = -(remainder) * (1 + w * fill_penalty), where fill_penalty is large when the
remainder is a "bad" residue (small and not easily reachable) and small otherwise.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    rem = bins - item  # remaining capacity after placing the item

    # We reward bins whose resulting remainder is either exactly 0 (perfect close) or
    # reasonably large (useful for future items), and penalize tiny/unusable remainders.
    # A small positive remainder that no item can fill is effectively wasted capacity.
    #
    # Base: prefer the tightest fit -> smaller remainder is better (best fit).
    # Correction: for remainders in (0, small), add a penalty because they act as waste
    # unless they match a typical item size gap.  We use a soft threshold: remainders
    # below BEST-FIT "fillable" floor get penalized proportionally.
    #
    # The "fillable" floor is taken as the size that leaves room for at least a small item.
    # We use a smooth penalty: waste = remainder when 0 < remainder < FLOOR, else 0.
    FLOOR = 15.0  # below this, leftovers are hard to use productively

    # effective_waste = how much of the remainder is likely unrecoverable
    in_gap = (rem > 0) & (rem < FLOOR)
    recoverable = np.where(in_gap, rem, 0.0)
    waste = np.where(in_gap, FLOOR - rem, 0.0)

    # Primary objective: minimize the "true" leftover = rem, but count gap-tiny remainders
    # as more costly (since they're nearly pure waste), so add a penalty to those.
    score = -(rem + 0.5 * waste)
    return score
# EVOLVE-BLOCK-END
