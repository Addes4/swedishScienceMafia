# EVOLVE-BLOCK-START
"""Best fit with an asymmetric tie-break on the post-placement remainder."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item
    # Primary: small remainder (tight fit). Tie-break: mildly prefer rems near 0 and
    # mildly dislike the "wasted middle" where a rem is too small to fit a typical
    # item but too large to be nearly full.
    # Use a tiny secondary term so exact-remainder ties are broken consistently.
    # main term scaled by 1024, secondary term bounded by <1.
    penalty = np.where(
        (rem > 0) & (rem < 40),
        (40 - rem) * (rem) * 0.0005,   # small bump for middle remainders
        0.0,
    )
    return -rem * 1024.0 - penalty
# EVOLVE-BLOCK-END
