# EVOLVE-BLOCK-START
"""Best fit with a small exact-fill bonus and a strictly monotone tie-break.

The base ordering is classic best-fit (prefer the bin leaving the smallest
residual), which is the strongest simple online packing rule here. We make the
ordering explicit and only add a tiny, strictly monotone refinement that never
overrides genuine best-fit choices: among equal residuals, prefer the one that
is exactly zero, then the larger residual (more reusable leftover).
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    r = residual.astype(np.float64)

    # Dominant term: best-fit tightness (smaller residual is better).
    tightness = -r

    # Tiny refinement (scale far below 1, so it only breaks ties among equal
    # residuals): reward exact fills most, then larger residuals.
    exact = (residual == 0).astype(np.float64) * 1e-3
    refine = r * 1e-6

    return tightness + exact + refine
# EVOLVE-BLOCK-END
