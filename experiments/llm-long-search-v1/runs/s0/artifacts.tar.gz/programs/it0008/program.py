# EVOLVE-BLOCK-START
"""Best fit with an exponential penalty on the leftover, to discourage stranding."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # post-placement remainder, always >= 0 since only fit bins are shown
    # Penalize leftovers super-linearly so that near-full bins are strongly preferred,
    # but avoid the degenerate "always take tightest" by scaling with remainder.
    return -rem.astype(np.float64) * (1.0 + rem / 100.0)
# EVOLVE-BLOCK-END
