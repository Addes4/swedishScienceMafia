# EVOLVE-BLOCK-START
"""Best-fit with a residual-usability shaping term.

Pure best fit minimizes leftover capacity, but a small residual like 3-15
cannot hold a typical future item (mean ~40), so it becomes wasted capacity.
We keep best fit as the dominant term but add a gentle bonus for residuals
that are either essentially zero (perfect fit) or large enough to stay
useful, and a penalty for the "dead sliver" mid range.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # leftover capacity if item placed here

    # Base: best fit (prefer smallest residual).
    score = -residual.astype(np.float64)

    # Shaping: reward residuals near 0, penalize mid-range dead slivers,
    # mildly reward large residuals that can still host a typical item.
    # u in [0, 1] is the residual fraction.
    u = residual.astype(np.float64) / 100.0
    # peaks at u=0, dips in the middle, rises again for large u.
    shape = (u - 0.5) ** 2  # 0 at u=0.5, larger toward 0 and 1
    # want: small u -> reward; mid u -> penalize; large u -> mild reward
    bonus = np.where(
        residual <= 2,
        1.0,                      # near-perfect fill: strong reward
        np.where(
            residual >= 60,
            0.3,                  # large residual: still useful
            -0.6 * (1.0 - shape * 4.0) * (1.0 - u)  # mid-range penalty
        ),
    )
    # scale the shaping term so it only breaks near-ties
    return score + 0.15 * bonus
# EVOLVE-BLOCK-END
