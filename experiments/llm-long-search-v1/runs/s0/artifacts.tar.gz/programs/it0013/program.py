# EVOLVE-BLOCK-START
"""Hybrid best-fit with a soft anti-fragmentation tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item
    # Primary: classic best fit (most tightly packed, smallest remainder).
    primary = -rem.astype(np.float64)

    # Secondary: avoid leaving remainders in the "hard to reuse" middle band.
    # Remainders near 0 or large enough for another typical item (~40) are fine.
    mid_penalty = np.zeros_like(primary)
    hard = (rem > 5) & (rem < 30)
    mid_penalty[hard] = -0.05 * (30.0 - rem[hard])

    return primary + mid_penalty
# EVOLVE-BLOCK-END
