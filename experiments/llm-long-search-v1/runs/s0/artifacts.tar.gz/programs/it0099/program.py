# EVOLVE-BLOCK-START
"""Best-fit with a small fill-level bonus to encourage closing open bins."""
import numpy as np


def priority(item, bins):
    """Rank bins by residual (best-fit) with a mild preference for fuller bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing item
    # Best-fit dominant term: smaller residual -> higher score.
    score = -residual.astype(np.float64)
    # Mild bonus for bins that are already partially filled (residual < 100 - item),
    # i.e. closing an existing open bin is slightly preferred over opening a new one.
    fill = (100 - bins).astype(np.float64)  # how full the bin currently is
    score += 0.02 * fill
    # Tiny extra push for exact fits.
    score += 0.1 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
