# EVOLVE-BLOCK-START
"""Best fit with a learned-style value-function tie-break on the post-placement remainder."""
import numpy as np

# Precompute (once) an estimate of the "expected usable fraction" of a remainder r.
# The item distribution is approximately Weibull with mean ~40; we use a fixed
# smoothed model of the item size distribution to score remainders.
_R = np.arange(0, 101, dtype=np.float64)

# Approximate item distribution: Weibull(k~1.8, lambda~45) truncated to [1,100].
_k = 1.8
_l = 45.0
_S = np.arange(1, 101, dtype=np.float64)
_pdf = (_k / _l) * (_S / _l) ** (_k - 1.0) * np.exp(-(_S / _l) ** _k)
_pdf = _pdf / _pdf.sum()


def _usable(r):
    """Expected fraction of the remainder that can be filled by future items."""
    r = float(r)
    if r <= 0:
        return 0.0
    # Probability that a future item fits and how tightly it packs.
    fits = _S <= r
    if not fits.any():
        return 0.0
    # Weight mass that fits; use a concave reward so near-full is best but
    # large remainders still useful (they can accept many future items).
    mass = _pdf[fits].sum()
    # Mean post-remainder after best fit for the mass that fits.
    # Approximate: items that fit are packed, so consumed ~ expected fitting item.
    mean_item = (_pdf[fits] * _S[fits]).sum() / max(mass, 1e-12)
    return mass * (1.0 - 0.5 * (r - mean_item) / max(r, 1.0)) if r > 0 else 0.0


# Value table for remainders 0..100 (larger is better).
_VALUE = np.array([_usable(r) if r > 0 else 0.0 for r in _R], dtype=np.float64)
# Primary term dominates: prefer smallest remainder (best fit). The value table
# only breaks near-ties, encoded by subtracting a tiny multiple of the value.
_ALPHA = 1e-3


def priority(item, bins):
    """Rank bins: best fit primary, with a tiny value-function tie-break."""
    rem = bins - item
    # Clip to valid remainder range.
    idx = np.clip(rem, 0, 100).astype(np.int64)
    return -rem.astype(np.float64) + _ALPHA * _VALUE[idx]
# EVOLVE-BLOCK-END
