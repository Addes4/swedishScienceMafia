# EVOLVE-BLOCK-START
"""Best fit with a large-item reservation guard.

Normally place each item in the tightest-fitting bin (best fit).  For large
items, if the tightest fit creates a tiny remainder that later (typically
smaller) items are unlikely to use well, prefer instead a slightly looser bin
whose post-placement remainder is still comfortably large.
"""
import numpy as np

_state = {"sizes": []}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    sizes = _state["sizes"]
    sizes.append(item)
    if len(sizes) > 200:
        del sizes[:100]

    rem = bins - item  # nonnegative since only fitting bins are shown

    base = -rem.astype(np.float64)

    if item >= 50 and len(sizes) >= 10:
        med = float(np.median(sizes))
        # boost bins whose remainder is at least around the median item size
        big = rem >= med
        base = base + 3.0 * big
    return base
# EVOLVE-BLOCK-END
