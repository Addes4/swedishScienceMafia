# EVOLVE-BLOCK-START
"""Exponential-remainder best fit: prefer small post-placement remainders with an
asymmetric exponential penalty that strongly rewards near-full bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item
    # Exponential penalty on the post-placement remainder: monotonically favors
    # the tightest fit but heavily emphasizes driving remainders to near zero.
    return -np.exp(rem / 10.0)
# EVOLVE-BLOCK-END
