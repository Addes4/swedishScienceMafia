# EVOLVE-BLOCK-START
"""Hybrid: first-fit for small items, best-fit for large ones."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["sum"] += item
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]

    residual = bins - item  # remaining capacity after placing the item

    if item < mean:
        # Small item: prefer to fill older/used bins (first-fit) to consolidate
        # and avoid opening new bins.  Best-fit tightness as tiebreak.
        used = bins < 100
        score = used.astype(np.float64) * 2.0 - residual * 0.01
    else:
        # Large item: strict best fit (tightest residual).
        score = -residual.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
