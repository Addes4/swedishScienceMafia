# EVOLVE-BLOCK-START
"""Best fit (smallest residual) with a tiny exact-fill tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit: prefer the smallest residual.
    score = -residual.astype(np.float64)

    # Tiny bonus for exact fills so an exact-fit bin beats an equal-residual alternative.
    score += (residual == 0) * 1e-3

    return score
# EVOLVE-BLOCK-END
