# EVOLVE-BLOCK-START
"""Best-fit with a light histogram-based tie-break for complement formation."""
import numpy as np

# Exponential moving histogram of seen item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)
_alpha = 0.02
_seen = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen

    # Update a smoothed histogram of seen item sizes (before scoring this one).
    _hist *= (1.0 - _alpha)
    _hist[item] += _alpha
    _seen += 1

    residual = bins - item  # remaining capacity after placing here

    # Dominant term: best-fit tightness (prefer smaller residual).
    tightness = -residual.astype(np.float64)

    # Light tie-break: reward residuals that could be exactly filled by a
    # frequently-seen item size, favoring the creation of perfectly packed bins.
    # Weight is small so best-fit remains dominant.
    h = _hist
    pos = residual > 0
    # Probability mass concentrated on residuals likely to be exactly matched.
    match = np.where(pos & (residual <= 100), h[np.clip(residual, 0, 100)], 0.0)

    # Small bonus for exact fills, kept modest.
    exact = (residual == 0).astype(np.float64) * 0.5

    return tightness + 1.0 * match + exact
# EVOLVE-BLOCK-END
