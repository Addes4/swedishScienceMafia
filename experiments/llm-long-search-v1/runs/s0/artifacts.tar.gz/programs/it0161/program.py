# EVOLVE-BLOCK-START
"""Best-fit dominant scoring with a sub-unit tie-break that, among bins with
equal residual, favors residuals likely to be reusable (exact fill or matching
a commonly seen item size). The tie-break magnitude stays below 1 so it cannot
reorder bins with different residuals."""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _mean, _count, _hist

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: smaller residual is strictly better.
    tightness = -r * 10.0

    # Tie-break (< 1 total): exact fill is best, then reuse likelihood of residual.
    exact = (residual == 0).astype(np.float64)

    valid = residual >= 1
    r_idx = np.where(valid, residual, 0).astype(np.int64)
    if _count > 0:
        freq = _hist[r_idx] / _count
    else:
        freq = np.zeros_like(r)
    freq = np.where(valid, freq, 0.0)
    # Scale frequency into [0, 0.5) so it cannot flip residual ordering.
    reuse = freq * 0.5

    return tightness + exact + reuse
# EVOLVE-BLOCK-END
