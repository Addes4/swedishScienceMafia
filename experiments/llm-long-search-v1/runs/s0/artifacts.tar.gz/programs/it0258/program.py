# EVOLVE-BLOCK-START
"""Best fit with a tightly-bounded "dead sliver" penalty.

Best-fit (-residual) ordering is kept dominant; the only extra term is a mild
penalty for residuals that are positive but so small (below half the running
mean) that they are effectively unreusable, and would otherwise cause best-fit
to "waste" a nearly-empty bin that could still accept medium items.
"""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual (dominant ordering).
    tightness = -residual.astype(np.float64)

    # Penalize only residuals that are positive but below half the running mean:
    # such slivers will likely never be reused and represent dead capacity.
    m = _mean
    thresh = 0.5 * m
    sliver = (residual > 0) & (residual < thresh)
    penalty = np.where(sliver, (thresh - residual) * 1.0, 0.0)

    # Small bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 2.0

    return tightness - penalty + exact
# EVOLVE-BLOCK-END
