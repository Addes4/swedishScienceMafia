# EVOLVE-BLOCK-START
"""Best fit with a usefulness-aware tie-break on near-ties."""
import numpy as np

_MEAN = 40.0  # approximate mean item size of the Weibull-shaped distribution


def priority(item, bins):
    """Rank bins: prefer tightest fit, but among near-ties prefer the fullest bin."""
    residual = bins - item  # leftover capacity after placing the item (>=0)
    # Primary: tightest fit -> smaller residual is better.
    score = -residual.astype(np.float64)
    # Tie-break region: residuals within a small window are effectively ties.
    # Among those, reward fuller bins (smaller current remaining capacity),
    # i.e. prefer bins that already carry more load.
    load = 100.0 - bins.astype(np.float64)
    # A tiny additive nudge proportional to load; magnitude < 1 so it only
    # breaks ties among equal residuals, never overrides the tight-fit rule.
    score = score * 1000.0 + load * 1e-3
    return score
# EVOLVE-BLOCK-END
