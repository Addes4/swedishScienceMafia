# EVOLVE-BLOCK-START
"""Best-fit with a complementary-pairing bonus for large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    b = bins.astype(np.float64)
    residual = b - item
    # Primary: best fit (smallest residual).
    score = -residual
    # Bonus: reward residuals near the "half full" target (~50), where a large
    # complementary item can later complete the bin, and reward exact fills.
    target = 100.0 - 40.0  # typical complementary remainder (~40 large item already placed side)
    score -= 0.05 * np.abs(residual - (100.0 - item))
    exact = residual <= 0
    score = np.where(exact, score + 1e6, score)
    return score
# EVOLVE-BLOCK-END
