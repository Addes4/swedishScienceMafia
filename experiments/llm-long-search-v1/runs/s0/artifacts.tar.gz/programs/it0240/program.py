# EVOLVE-BLOCK-START
"""Best fit (score = -residual), the strongest simple online rule for this problem.

A single deterministic, bounded tie-break rewards residuals that are close to the
running mean item size, since those are the most likely to be exactly reusable by
future items. The tie-break is kept strictly smaller than 1 so it can never
override a genuinely tighter fit; it only orders bins with the same residual.
"""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _mean, _count

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here
    tightness = -residual.astype(np.float64)

    # Bounded tie-break in [0, 1): reward residuals closest to the running mean
    # size, i.e. the most likely to be reuseable by a future item. Since it is
    # < 1 in magnitude it only orders equal-residual bins.
    m = _mean if _mean > 0 else 1.0
    tiebreak = np.exp(-np.abs(residual - m) / m)

    return tightness + tiebreak
# EVOLVE-BLOCK-END
