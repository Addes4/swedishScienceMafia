# EVOLVE-BLOCK-START
"""Harmonic-bucketed best fit: primary key is post-placement remainder size-class, tie-break is tighter fit."""
import numpy as np

# Harmonic partition of capacity 100 into classes.
# Class boundaries chosen so each class can hold at least one item of the class's typical size.
_BOUNDS = np.array([0, 20, 34, 43, 50, 58, 67, 80, 100], dtype=np.int64)


def _class_of(rem):
    # index of the bucket; larger index = larger remainder
    return np.searchsorted(_BOUNDS, rem, side='right') - 1


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # post-placement remainder, >= 0 for all shown bins
    # Primary: prefer remainders that fall into a "clean" class where leftover space
    # can still host common items. Favor near-zero remainder (perfect fill) and
    # remainders that open a fresh usable slot, softly penalize awkward middles.
    # Use a smooth log-ish value that peaks at small rem, using class membership.
    cls = _class_of(rem)
    # value: perfect/near-perfect fills (cls 0) are great; larger clean classes are good;
    # convert to a float score. Combination of tightness and class cleanliness.
    # Tightness term dominates (best-fit), class term breaks ties meaningfully.
    tight = -rem.astype(np.float64)
    clean = cls.astype(np.float64) * 0.5
    # slight bonus for exactly filling or leaving a full-bin-sized remainder
    bonus = np.where(rem == 0, 5.0, 0.0)
    return tight + clean + bonus
# EVOLVE-BLOCK-END
