# EVOLVE-BLOCK-START
"""Best fit with a small leveling bias: fill partly-used bins before opening new ones."""
import numpy as np

_state = {"count": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Dominant term: best fit (tightest remaining capacity after placement).
    Small bias: prefer bins that are already partly used (remainder < 100) so that
    small items top up existing bins instead of opening fresh ones; the bias is
    scaled well below 1 so it only breaks near-ties in tightness.
    """
    rem = bins - item  # remaining capacity after placing the item here

    # best-fit tightness: smaller remainder -> higher score
    score = -rem.astype(np.float64)

    # leveling bias: prefer already-used bins (rem < 100) over empty ones.
    # Magnitude < 1 keeps it a tie-breaker; scaled down further for large items.
    used = (bins < 100).astype(np.float64)
    score += 0.25 * used

    return score
# EVOLVE-BLOCK-END

