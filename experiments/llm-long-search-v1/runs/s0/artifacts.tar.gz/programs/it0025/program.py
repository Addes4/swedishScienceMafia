# EVOLVE-BLOCK-START
"""Best fit with a mild fragmentation-aware tie bias.

Primary rule is classic best fit (smallest post-placement residual).  We add a
tiny secondary term that nudges near-ties toward remainders that are "useful"
for the known Weibull(mean~40) item distribution: an exact fill (residual 0)
or a residual close to the mean item size, which is more likely to be consumed
by a future item.  The perturbation is scaled small enough that it only breaks
ties / near-ties and does not override tight packing.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing item (all >= 0)
    # Primary: prefer smallest residual (best fit). Larger score = chosen.
    primary = -residual.astype(np.float64)

    # Secondary fragmentation bias: reward residuals close to 0 or ~40.
    # distance to nearest "useful" value among {0, 40}
    d0 = residual.astype(np.float64)
    d40 = np.abs(residual.astype(np.float64) - 40.0)
    usefulness = 1.0 / (1.0 + np.minimum(d0, d40))

    return primary + 1e-3 * usefulness
# EVOLVE-BLOCK-END
