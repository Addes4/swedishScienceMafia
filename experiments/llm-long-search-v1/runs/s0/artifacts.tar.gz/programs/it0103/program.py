# EVOLVE-BLOCK-START
"""Hybrid: best-fit for small items, half-fill targeting for large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # remaining capacity after placement
    tight = -rem  # best-fit primary term (higher = tighter fit)
    if item <= 25:
        return tight
    # For larger items, prefer leaving a remainder that is itself a plausible item size,
    # especially near the half-capacity so pairs can fill a bin exactly.
    return tight + 0.5 * (-np.abs(rem - 50))
# EVOLVE-BLOCK-END
