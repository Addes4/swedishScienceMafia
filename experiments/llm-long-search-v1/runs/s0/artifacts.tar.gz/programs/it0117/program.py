# EVOLVE-BLOCK-START
"""Best fit with a consolidation tie-break: prefer tight fits, and among
near-equal fits prefer bins that are already fuller (smaller remaining
capacity), which consolidates items and avoids leaving unusable slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest
    (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Main term: best fit -> smallest residual is best.
    # Tie-break: among similar residuals, prefer fuller bins (smaller bins value)
    # to consolidate packing.
    return -(residual.astype(np.float64) * 100.0 + bins.astype(np.float64))
# EVOLVE-BLOCK-END
