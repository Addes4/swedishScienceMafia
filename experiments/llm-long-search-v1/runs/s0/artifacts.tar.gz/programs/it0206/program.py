# EVOLVE-BLOCK-START
"""Best fit with a smooth reusable-residual bonus aimed at leaving leftovers
that a typical future item can fill well."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties)."""
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    # Strong bonus for an exact fill (no leftover).
    exact = (residual == 0).astype(np.float64) * 6.0

    # Reusable-residual bonus: reward leftovers that a typical future item can
    # fill snugly, i.e. residuals close to the running mean item size.
    m = _mean
    gap = np.abs(residual - m)
    reuse = np.where(residual > 0, 3.0 / (1.0 + gap / m), 0.0)

    # Penalize tiny unusable slivers (positive but well below a typical item).
    sliver = (residual > 0) & (residual < m * 0.5)
    penalty = np.where(sliver, (m * 0.5 - residual) * 1.5, 0.0)

    return tightness + exact + reuse - penalty
# EVOLVE-BLOCK-END
