# EVOLVE-BLOCK-START
"""Best fit with a mild consolidation bonus toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    gap = bins - item                # residual space after placing the item
    filled = 100 - bins              # amount already packed in each bin
    # Primary: tightest fit (smallest gap). Secondary: prefer fuller bins within 1 unit gap.
    return -gap.astype(np.float64) + 0.001 * filled.astype(np.float64)
# EVOLVE-BLOCK-END
