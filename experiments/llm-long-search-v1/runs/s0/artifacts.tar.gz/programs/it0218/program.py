# EVOLVE-BLOCK-START
"""Best fit plus exact-fill and small-residual bonuses; keeps the proven tightness
core and avoids noisy histogram/modal terms that hurt generalization."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -r

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 8.0

    # Deterministic small-fill bonus: residuals that are small but nonzero are
    # easy to reuse with a small upcoming item, so mildly prefer them over
    # large residuals (which tightness already handles). This is a stable,
    # distribution-free nudge that doesn't depend on noisy per-item history.
    small = (residual > 0) & (residual <= 10)
    small_bonus = np.where(small, (11.0 - r) * 0.15, 0.0)

    # Penalize unusable slivers: positive residual far below the mean is dead space.
    sliver = (residual > 0) & (r < _mean * 0.5)
    sliver_penalty = np.where(sliver, (_mean * 0.5 - r) * 0.3, 0.0)

    return tightness + exact + small_bonus - sliver_penalty
# EVOLVE-BLOCK-END
