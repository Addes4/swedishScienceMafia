# EVOLVE-BLOCK-START
"""Best fit with a dominant exact-fill bonus and a fixed-reference complement
bonus.  Best-fit ordering (smaller residual first) is preserved for all
non-exact, non-complement residuals; the bonuses only reorder among residuals
that are otherwise close."""
import numpy as np

# Fixed reference: expected item size, used only for the complement bonus.
_REF = 40.0
# Histogram of seen item sizes (1..100) for the complement bonus.
_hist = np.zeros(101, dtype=np.float64)
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count

    _hist[item] += 1.0
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here
    tightness = -residual.astype(np.float64)

    # Strong preference for exact fills: they cleanly free a bin.
    exact = (residual == 0).astype(np.float64) * 2.0

    # Complement bonus: reward residuals equal to a frequently seen item size,
    # so the leftover is likely reusable.  Scaled small so best-fit still rules.
    r = residual
    valid = r >= 1
    freq = np.where(valid, _hist[np.clip(r, 0, 100)], 0.0)
    total = max(_count, 1)
    complement = (freq / total) * 1.0

    return tightness + exact + complement
# EVOLVE-BLOCK-END

