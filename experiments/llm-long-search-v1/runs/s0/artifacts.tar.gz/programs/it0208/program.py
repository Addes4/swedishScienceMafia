# EVOLVE-BLOCK-START
"""Best fit with a reusable-residual bonus: strongly prefer exact fills, prefer
tight fits, and reward residuals that stay close to a typical item size so the
leftover capacity remains reusable by future items."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Best-fit tightness: prefer smaller residual.
    tightness = -r

    # Strong bonus for exact fills (residual 0).
    exact = (r == 0).astype(np.float64) * 6.0

    m = _mean

    # Penalize tiny unusable slivers that can never be reused.
    sliver = (r > 0) & (r < m)
    penalty = np.where(sliver, (m - r) * 2.0, 0.0)

    # Reusable-residual bonus: reward residuals close to a typical item size,
    # since such leftover capacity is most likely to be fully reused later.
    scale = max(m, 1.0)
    near_typical = (r >= 1)
    bonus = np.where(near_typical, np.exp(-((r - m) / scale) ** 2) * 2.0, 0.0)

    return tightness - penalty + exact + bonus
# EVOLVE-BLOCK-END
