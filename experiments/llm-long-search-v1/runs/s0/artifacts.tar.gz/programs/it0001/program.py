# EVOLVE-BLOCK-START
"""Best fit with a tilt toward useful remainders."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    remainder = bins - item
    # Primary: tightest fit (smallest remaining capacity).
    score = -(remainder.astype(np.float64))
    # Small tilt: prefer remainders that can still hold a typical future item.
    score += 0.5 * (remainder >= 40)
    return score
# EVOLVE-BLOCK-END
