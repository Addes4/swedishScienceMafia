# EVOLVE-BLOCK-START
"""Best fit with a small, deterministic "residual gap avoidance" nudge.

Pure best-fit is hard to beat, but it can leave a bin with a tiny remainder
(e.g. 1-3) that no future item fits, effectively wasting that space.  Here we
mostly keep best-fit, but when the tightest fit would leave a very small
remainder, we prefer a bin that leaves a somewhat larger, more "usable"
remainder, while still keeping a strong bias toward tight fits.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest."""
    rem = bins - item  # post-placement remainder for every fitting bin
    # Best-fit base: tighter fit (smaller remainder) -> higher score.
    score = -rem.astype(np.float64)
    # Penalize very small remainders (1..3) that are unlikely to be fillable.
    small = (rem >= 1) & (rem <= 3)
    score[small] -= 2.0
    return score
# EVOLVE-BLOCK-END
