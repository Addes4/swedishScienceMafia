# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break based on a running median and a
histogram of seen item sizes (to nudge residuals toward frequently reusable sizes)."""
import numpy as np

_median = 40.0
_count = 0
# Histogram of seen item sizes (1..100), used to reward residuals that match
# a common leftover size and to estimate a robust central item size.
_hist = np.zeros(101, dtype=np.float64)


def _running_median():
    """Estimate the median item size from the histogram (returns size)."""
    total = _hist.sum()
    if total <= 0:
        return 40.0
    cum = np.cumsum(_hist)
    half = total * 0.5
    idx = int(np.searchsorted(cum, half))
    if idx < 1:
        idx = 1
    elif idx > 100:
        idx = 100
    return float(idx)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _median, _count, _hist

    # Update running median estimate and histogram of past items (before scoring).
    _hist[item] += 1.0
    _count += 1
    _median = _running_median()

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    # Use a robust central size (median) instead of the mean. Slivers below this
    # are effectively wasted capacity; penalize them proportionally to how far
    # below the median they fall.
    m = _median
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Small bonus for very tight fits (residual 0) to strongly prefer exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Data-driven complement bonus: reward residuals that equal an item size we
    # have seen frequently, so the leftover is likely reusable.
    r = residual
    valid = r >= 1
    r_idx = np.where(valid, r, 0).astype(np.int64)
    if _count > 0:
        freq = _hist[r_idx] / _count
    else:
        freq = np.zeros_like(r, dtype=np.float64)
    freq = np.where(valid, freq, 0.0)
    complement = freq * 3.0

    # Waste-aware term: a residual just below the median will likely never be
    # reused and is effectively lost capacity.
    waste = np.where(sliver, (1.0 - residual / m) * 1.0, 0.0)

    return tightness - penalty + exact + complement - waste
# EVOLVE-BLOCK-END
