# EVOLVE-BLOCK-START
"""Best fit with a discrete 'slot match' bonus for near-perfect fits."""
import numpy as np

_state = {"small": 100}


def priority(item, bins):
    """Rank bins by tightest fit, but give a strong bonus when the fit is (near) exact.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    if item < _state["small"]:
        _state["small"] = item
    s = _state["small"]

    rem = np.asarray(bins, dtype=np.float64)
    after = rem - item

    # Base: tightest fit wins.
    score = -after

    # Strong bonus: exact fit closes a bin perfectly.
    exact = (after == 0).astype(np.float64)
    score += 5.0 * exact

    # Moderate bonus: leaves a remainder too small to ever hold another item
    # (below the smallest item seen) -> that capacity is effectively wasted,
    # so we mildly discourage it relative to a usable remainder.
    wasted = (after < s).astype(np.float64)
    score -= 1.0 * wasted * (after > 0)

    return score
# EVOLVE-BLOCK-END
