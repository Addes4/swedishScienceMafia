# EVOLVE-BLOCK-START
"""Best fit with a mild live-histogram residual-usability tie-break."""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)   # item size counts 1..100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _mean, _count, _hist

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -residual.astype(np.float64)

    # Mild penalty for genuinely wasted slivers (positive but too small for a typical item).
    m = _mean
    sliver = (residual > 0) & (residual < 0.5 * m)
    penalty = np.where(sliver, (0.5 * m - residual) * 0.5, 0.0)

    # Bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 3.0

    # Mild tie-break: reward residuals that match a commonly seen item size,
    # so the leftover can likely be filled later.
    if _count > 50:
        freq = _hist / _count
        r = np.clip(residual, 0, 100).astype(np.int64)
        usability = freq[r] * 30.0
    else:
        usability = 0.0

    return tightness - penalty + exact + usability
# EVOLVE-BLOCK-END
