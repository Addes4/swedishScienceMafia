# EVOLVE-BLOCK-START
"""Best fit that mildly favors already-used bins, to cut fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item
    # small bonus for already-used bins (remaining < 100) to avoid opening new ones
    used_bonus = np.where(bins < 100, 0.01, 0.0)
    return -rem.astype(np.float64) + used_bonus
# EVOLVE-BLOCK-END
