# EVOLVE-BLOCK-START
"""Best fit with an anticipatory value function over remaining capacity."""
import numpy as np

# Approximate the item-size distribution (Weibull-shaped, mean ~40) as a discrete PMF.
# We build it once at import time; no files or network are used.
def _build_pmf():
    from math import exp
    # Weibull with shape k and scale lam chosen so mean ~40.
    # mean = lam * Gamma(1 + 1/k). Try k=1.5 -> Gamma(1.6667) ~ 0.9027 => lam ~ 44.3
    k = 1.5
    lam = 40.0 / 0.9027  # ~44.3
    pmf = np.zeros(101, dtype=np.float64)  # index 1..100
    for s in range(1, 101):
        # discretized Weibull density on integer sizes, P(X ~ s)
        cdf_hi = 1.0 - exp(-((s + 0.5) / lam) ** k)
        cdf_lo = 1.0 - exp(-((s - 0.5) / lam) ** k)
        pmf[s] = max(cdf_hi - cdf_lo, 0.0)
    # Normalize over 1..100
    total = pmf[1:].sum()
    if total > 0:
        pmf[1:] /= total
    return pmf

_PMF = _build_pmf()
_CUM = np.cumsum(_PMF)  # _CUM[c] = P(size <= c)

# Value function V[c]: expected number of items that can be packed into a bin with
# remaining capacity c under "perfect" packing. Computed by DP: V[0]=0, and
# V[c] = best over waiting for an item of size s<=c of (1 + V[c-s]).
# To keep it cheap we approximate with a randomized-greedy upper estimate:
# V[c] ~ c / E[size | size <= c] weighted, which approximates how many average
# small-enough items fit. This is monotone and cheap.
def _build_value():
    V = np.zeros(101, dtype=np.float64)
    for c in range(1, 101):
        # Expected usable slots: integral over sizes <= c of relative density.
        # Approximate by c divided by mean size in (0, c].
        p_le = _CUM[c] if c <= 100 else 1.0
        if p_le <= 1e-9:
            V[c] = 0.0
            continue
        # mean of sizes in 1..c weighted by pmf
        sizes = np.arange(1, c + 1)
        w = _PMF[1:c + 1]
        wsum = w.sum()
        mean_le = (sizes * w).sum() / wsum if wsum > 0 else c
        V[c] = c / mean_le if mean_le > 0 else 0.0
    return V

_V = _build_value()


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties).

    Primary: best fit (minimize post-placement remainder), but break near-ties by
    preferring the remainder with the highest anticipated reuse value V[c], so
    leftover space stays as packable as possible.
    """
    rem = bins - item  # post-placement remaining capacities (all >= 0)
    fit_ids = rem >= 0
    score = np.full(bins.shape, -1e18, dtype=np.float64)
    if not fit_ids.any():
        return score
    r = rem[fit_ids]
    # Value of the leftover bin: expected future items it can still hold.
    v = _V[r]
    # Primary tie-break: prefer smaller remainder to keep best-fit behaviour,
    # but weight the anticipatory value enough to matter only among close fits.
    # Using remainder + penalty where higher V reduces penalty.
    score[fit_ids] = -(r.astype(np.float64)) + 0.5 * v
    return score
# EVOLVE-BLOCK-END
