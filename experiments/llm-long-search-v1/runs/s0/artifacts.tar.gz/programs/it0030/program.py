# EVOLVE-BLOCK-START
"""Best-fit with an online-learned histogram tie-breaker.

Primary rule: best fit (tightest residual).  Ties / near-ties are broken by how
well the leftover capacity matches the current empirical item-size distribution,
so a bin is preferred if its remainder can still be filled well by likely future
items.  The histogram is learned online from past items only.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # --- update online histogram of past item sizes (1..100) ---
    hist = priority.hist
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        priority.hist = hist
    hist[item] += 1.0
    total = hist.sum()

    # probability of surviving next item(s) is not modelled; instead use the
    # empirical distribution directly to score remainders.
    sizes = np.arange(1, 101, dtype=np.float64)
    p = hist[1:101] / total  # length 100, p[k-1] = P(item = k)

    residual = bins - item  # >= 0 for all shown bins

    # Fill quality of a remainder r: expected best utilization if we keep filling
    # r with items drawn from the empirical distribution.  Use a cheap proxy:
    # the probability that some item fits exactly-ish and the density of the
    # distribution just below r.  We reward remainders that are likely to be
    # closed to 0 by a future single item, and reward small remainders.
    # density mass that fits in r (items <= r) for r in 0..100
    r_int = np.clip(residual.astype(np.int64), 0, 100)
    cumfit = np.concatenate(([0.0], np.cumsum(p[:100])))  # cumfit[r] = P(item<=r)

    # "closability": probability that a single future item can nearly finish the bin
    close_mass = cumfit[r_int]

    # Reward small remainders and high closability; keep best-fit dominant.
    score = -(residual * 1e6) + 1.0 * close_mass - 0.01 * residual

    return score
# EVOLVE-BLOCK-END
priority.hist = None
