# EVOLVE-BLOCK-START
"""Best-fit with a least-loaded tie-break.

Pure best-fit (smallest residual) is the dominant rule. When two bins offer
essentially the same residual, prefer the bin that is already fuller, which
keeps a few bins tightly packed instead of many partially-used ones.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual. Dominant term.
    tightness = -residual.astype(np.float64)

    # Least-loaded tie-break: among near-equal residuals, prefer the bin that is
    # already fuller (smaller residual), i.e. already-packed bins stay packed.
    return tightness
# EVOLVE-BLOCK-END
