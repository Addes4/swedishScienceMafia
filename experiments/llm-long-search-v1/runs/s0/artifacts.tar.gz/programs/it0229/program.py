# EVOLVE-BLOCK-START
"""Best fit with exact-fill bonus and a frequency-weighted complement bonus
based on the running histogram of seen item sizes."""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100), used to reward residuals that match
# a commonly seen item size (likely reusable leftovers).
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    m = _mean

    # Penalize residuals that are positive but smaller than a typical item:
    # such slivers are effectively wasted capacity.
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Data-driven complement bonus: reward residuals that match a commonly
    # seen item size (frequency-weighted), since such leftovers are likely
    # reusable. Also mildly reward the residual matching the current item size.
    r = np.clip(residual, 0, 100).astype(np.int64)
    valid = residual >= 1
    freq = _hist[r]
    total = _count if _count > 0 else 1.0
    freq_bonus = np.where(valid, (freq / total) * 6.0, 0.0)

    match_self = (valid & (residual == item)).astype(np.float64) * 1.5

    return tightness - penalty + exact + freq_bonus + match_self
# EVOLVE-BLOCK-END

