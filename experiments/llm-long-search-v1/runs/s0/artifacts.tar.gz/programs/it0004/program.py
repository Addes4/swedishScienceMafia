# EVOLVE-BLOCK-START
"""Best fit with a residual-utility tie-break.

Primary: put the item where it fits most tightly (largest remaining-capacity
reduction is identical to smallest post-remainder). To avoid creating tiny
useless leftovers, we score bins by a shaped function of the post-placement
remainder r: bins that become nearly full (r ~ 0) or that keep a remainder
in a "useful" band (large enough to accept a typical item ~ mean 40) are
preferred over bins left with a small unusable remainder.
"""
import numpy as np


def priority(item, bins):
    """Score each bin; item goes to the highest-scoring bin (first on ties)."""
    r = bins - item  # remaining capacity after placement, >= 0 for shown bins
    m = 40.0         # typical item size
    # Waste is the leftover that is too small to hold a typical item.
    # We penalize leftovers in (0, m) proportionally, and slightly reward
    # near-full bins. Ties in waste still prefer the tightest fit.
    waste = np.where(r < m, (m - r) / m, 0.0)
    # Primary key: tightest fit; secondary: less waste.
    return -(r + waste) + (r == 0) * 0.5
# EVOLVE-BLOCK-END
