# EVOLVE-BLOCK-START
"""Best-fit with small tie-breakers: a mild sliver penalty and a confidence-
scaled complement bonus based on a running histogram of seen item sizes."""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100), used to reward residuals that match
# a common leftover size.
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual. Scale so this dominates.
    tightness = -residual.astype(np.float64) * 10.0

    # Mild penalty for tiny positive residuals (slivers smaller than typical
    # items are effectively wasted capacity). Kept small so best-fit ordering
    # is preserved for meaningful residual differences.
    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 0.1, 0.0)

    # Small bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 0.5

    # Data-driven complement bonus: reward residuals that equal an item size we
    # have seen frequently, so the leftover is likely reusable. Confidence
    # scaling keeps this from dominating early on.
    r = residual
    valid = r >= 1
    r_idx = np.where(valid, r, 0).astype(np.int64)
    if _count > 0:
        freq = _hist[r_idx] / _count
        conf = min(1.0, _count / 500.0)
    else:
        freq = np.zeros_like(r, dtype=np.float64)
        conf = 0.0
    freq = np.where(valid, freq, 0.0)
    complement = freq * conf * 1.0

    return tightness - penalty + exact + complement
# EVOLVE-BLOCK-END
