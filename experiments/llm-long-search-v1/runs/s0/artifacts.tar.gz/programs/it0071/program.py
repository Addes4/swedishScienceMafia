# EVOLVE-BLOCK-START
"""Best fit with a penalty for creating unusably small remainders."""
import numpy as np


def priority(item, bins):
    """Rank bins: tightest fit, but discount leaving a remainder no future item can fill."""
    rem = bins - item  # resulting remaining capacity (>= 0 since item fits)
    # Score: prefer small remainder (tight fit), tiny extra bonus for exact fill.
    score = -rem.astype(np.float64)
    # Penalize remainders in (0, min_item) since such holes are almost certainly wasted.
    # Use a fixed small threshold (1..~) — the smallest possible item is 1, so a
    # remainder of 1..3 is very likely unfillable waste.
    small = (rem > 0) & (rem < 4)
    score -= small.astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END
