# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break based on a running mean and a
histogram of seen item sizes (to nudge residuals toward frequently reusable sizes)."""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100), used to reward residuals that match
# a common leftover size.
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    m = _mean

    # Penalize residuals that are positive but smaller than a typical item
    # (below the mean): such slivers are effectively wasted capacity.
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Small bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Data-driven complement bonus: reward residuals that equal an item size we
    # have seen frequently, so the leftover is likely reusable.
    r = residual
    valid = r >= 1
    r_idx = np.where(valid, r, 0).astype(np.int64)
    if _count > 0:
        freq = _hist[r_idx] / _count
    else:
        freq = np.zeros_like(r, dtype=np.float64)
    freq = np.where(valid, freq, 0.0)
    complement = freq * 3.0

    # Waste-aware term: residuals just below the mean are likely never reused,
    # so add a mild extra penalty scaled by closeness to the mean.
    near_full = (residual > 0) & (residual < m)
    waste = np.where(near_full, (1.0 - residual / m) * 1.0, 0.0)

    # Bonus for residuals large enough to still hold a typical (mean-sized) item,
    # which makes the leftover genuinely reusable rather than a near-dead sliver.
    reuse = np.where(residual >= m, np.minimum(residual, m) / m * 0.5, 0.0)

    return tightness - penalty + exact + complement - waste + reuse
# EVOLVE-BLOCK-END
