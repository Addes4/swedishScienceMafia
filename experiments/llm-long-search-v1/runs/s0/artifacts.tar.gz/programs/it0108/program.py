# EVOLVE-BLOCK-START
"""Best fit with a learned 'residual matches typical item size' secondary term."""
import numpy as np

_state = {"count": 0, "mean": 40.0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running statistics online (before scoring, using past items only).
    c = _state["count"]
    m = _state["mean"]
    m = (m * c + item) / (c + 1) if c > 0 else float(item)
    _state["count"] = c + 1
    _state["mean"] = m
    _state["hist"][item] += 1.0

    residual = bins - item  # post-placement remaining capacity (>= 0)

    # Primary: best fit (prefer small residual).
    primary = -residual.astype(np.float64)

    # Secondary: prefer residual close to the learned typical item size, so that
    # a future item of typical size can fill the gap exactly.
    scale = m if m > 1.0 else 1.0
    secondary = -np.abs(residual.astype(np.float64) - scale) / scale

    # Exact fill is always best.
    exact = (residual == 0).astype(np.float64)

    return primary + 0.5 * secondary + 0.1 * exact
# EVOLVE-BLOCK-END
