# EVOLVE-BLOCK-START
"""Best fit with a data-driven residual-reusability tie-break.

Primary ordering is best-fit (smaller residual first). Secondary terms reward
residuals that are themselves common item sizes (so the leftover is likely to
be filled exactly by a future item) and penalize dead slivers below the mean.
"""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    m = _mean

    # Penalize residuals that are positive but smaller than a typical item:
    # such slivers are effectively wasted capacity.
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    r = residual
    valid = (r >= 1) & (r <= 100)

    # Data-driven reuse value: a residual equal to a frequently seen item size
    # is likely to be reusable by a future item. Use the empirical frequency
    # of that residual size, normalized by the max frequency, as a smooth bonus.
    reuse = np.zeros_like(r, dtype=np.float64)
    if _count > 0:
        idx = np.where(valid, r, 1).astype(np.int64)
        freq = _hist[idx]
        maxf = _hist[1:].max()
        if maxf > 0:
            reuse = np.where(valid, freq / maxf, 0.0) * 3.0

    # Small extra penalty for residuals just below the mean (dead capacity).
    near_full = (residual > 0) & (residual < m)
    waste = np.where(near_full, (1.0 - residual / m) * 1.0, 0.0)

    return tightness - penalty + exact + reuse - waste
# EVOLVE-BLOCK-END

