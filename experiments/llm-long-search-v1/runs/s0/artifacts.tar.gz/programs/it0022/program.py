# EVOLVE-BLOCK-START
"""Best fit with an online-distribution-aware residual scoring.

Primary rule: prefer the tightest fit (smallest post-placement remainder).
Tie-break / refinement: among bins whose post-placement remainder is small,
prefer those whose remainder is "fillable" by a typical future item -- i.e.
remainders that equal or nearly equal a common item size (so a later item can
exactly close the bin), estimated from an online histogram of seen items.
"""
import numpy as np

# ---- module-level state (persists across calls within an instance) ----
_HIST = np.zeros(101, dtype=np.float64)  # histogram of item sizes 1..100
_SEEN = 0


def priority(item, bins):
    global _HIST, _SEEN

    # update online histogram of item sizes
    _HIST[item] += 1.0
    _SEEN += 1

    # Build a "future item need" profile: probability-ish weight for each size.
    # We want remainders that a single future item can exactly fill.
    w = _HIST.copy()
    if _SEEN > 0:
        w = w / _SEEN
    # add a small prior so early calls behave like plain best fit
    w += 1.0 / 100.0

    # For each bin, post-placement remainder r.
    r = bins - item  # int64, >= 0 since bins only include fitting bins
    r_clip = np.clip(r, 0, 100)
    # "closability": how likely some typical item exactly equals the remainder
    closability = w[r_clip]
    # also reward small remainders (tight fit) strongly, as in best fit
    # primary: minimize remainder ; secondary: maximize closability
    # encode as: score = closability - lambda * remainder (higher better)
    lam = 0.02
    return closability - lam * r_clip
# EVOLVE-BLOCK-END
