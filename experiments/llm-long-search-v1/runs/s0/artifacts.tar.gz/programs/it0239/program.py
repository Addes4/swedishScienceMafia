# EVOLVE-BLOCK-START
"""Best fit with a smooth distribution-aware tie-break.

Pure best-fit (smallest residual) is the dominant ordering.  Ties (equal
residual) are broken by a smooth "reusability" preference: residuals closest
to the running mean item size are the ones most likely to be exactly filled by
a future item, so those bins are slightly preferred.  This keeps the provably
strong best-fit behaviour intact while nudging residual sizes toward the
distribution's typical size using only past information.
"""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority per bin; highest wins, ties go to the first bin."""
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = (bins - item).astype(np.float64)  # remaining capacity here

    # Dominant term: best-fit (prefer smallest non-negative residual).
    # Scale by a large constant so it strictly dominates the tie-break below.
    tightness = -residual * 1000.0

    # Smooth reusability tie-break: reward residuals near the running mean,
    # since they are the most likely to be exactly refillable later.
    # Bounded to at most ~1 in magnitude so it only distinguishes equal residuals.
    m = max(_mean, 1e-6)
    reusability = -np.abs(residual - m) / m

    return tightness + reusability
# EVOLVE-BLOCK-END

