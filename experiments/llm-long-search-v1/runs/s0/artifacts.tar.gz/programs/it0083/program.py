# EVOLVE-BLOCK-START
"""Best fit for large items, worst fit for small items (keeps large holes intact)."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state
    st["n"] += 1
    st["sum"] += item
    mean = st["sum"] / st["n"]

    rem = bins - item  # post-placement remainder (>= 0 since these bins fit the item)

    # For items at or above the running mean, use classic best fit (tightest remainder).
    # For small items, prefer putting them into tighter bins too, but with a mild incentive
    # to avoid the currently emptiest bins (preserving big free spaces for future large items).
    if item >= mean:
        return -rem.astype(np.float64)

    # Small item: strong best-fit preference, tiny penalty for staying in very empty bins.
    score = -rem.astype(np.float64)
    # Discount bins whose current remaining capacity is large (still nearly empty).
    score -= 0.05 * (bins.astype(np.float64) - rem)
    return score
# EVOLVE-BLOCK-END
