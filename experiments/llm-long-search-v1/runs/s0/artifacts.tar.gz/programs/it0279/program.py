# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break driven by a smoothed empirical
distribution of previously seen item sizes (nonparametric reuse value)."""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)
# Smoothed per-residual "reusability" values (index 1..100), recomputed lazily.
_reuse = np.zeros(101, dtype=np.float64)
_last_n = -1


def _recompute_reuse():
    """Estimate, for each residual size r (1..100), how valuable a leftover of
    size r is: the empirical frequency of items that would fit-ish into r."""
    global _reuse
    h = _hist[1:]
    total = h.sum()
    if total <= 0:
        _reuse[:] = 0.0
        return
    p = h / total
    # Smoothed density: convolution with a small triangular kernel to avoid noise.
    kern = np.array([0.25, 1.0, 0.25])
    dens = np.convolve(p, kern, mode="same")
    # Value of residual r ~ expected fraction of future items <= r, weighted to
    # favor moderately large residuals (reusable) without rewarding huge ones.
    cum = np.cumsum(dens)
    r_vals = np.arange(1, 101)
    val = cum * (1.0 - 0.5 * (r_vals / 100.0))
    _reuse[1:] = val


def priority(item, bins):
    global _mean, _count, _hist, _last_n

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0
    if _count - _last_n >= 25:
        _recompute_reuse()
        _last_n = _count

    residual = bins - item
    tightness = -residual.astype(np.float64)

    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    exact = (residual == 0).astype(np.float64) * 5.0

    r = residual
    valid = r >= 1
    idx = np.clip(r, 0, 100)
    reuse = np.where(valid, _reuse[idx], 0.0)
    complement = reuse * 3.0

    near_full = (residual > 0) & (residual < m)
    waste = np.where(near_full, (1.0 - residual / m) * 1.0, 0.0)

    return tightness - penalty + exact + complement - waste
# EVOLVE-BLOCK-END
