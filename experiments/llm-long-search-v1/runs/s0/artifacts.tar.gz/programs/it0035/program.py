# EVOLVE-BLOCK-START
"""Best fit with a small bonus for leaving a canonical slice remainder."""
import numpy as np

_CANON = (25, 33, 50)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item
    # Primary: tightest fit (smallest remainder).
    score = -rem.astype(np.float64)
    # Small bonus for remainders equal to a canonical slice size.
    for c in _CANON:
        score += 0.25 * (rem == c)
    return score
# EVOLVE-BLOCK-END
