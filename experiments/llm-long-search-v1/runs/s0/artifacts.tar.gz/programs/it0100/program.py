# EVOLVE-BLOCK-START
"""Best fit with a light learned preference for exactly-fillable remainders."""
import numpy as np

# Online statistics of past item sizes (module-level state persists across calls).
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Rank bins: tightest fit, with a bonus when the remainder is a common size."""
    global _total
    # Update the running size histogram with the current item (seen before deciding).
    _hist[item] += 1.0
    _total += 1.0

    r = bins - item  # post-placement remaining capacity

    # Tightness: prefer small remainders (best fit).
    score = -(r.astype(np.float64))

    # Small bonus if the remainder matches a frequently seen item size,
    # making the bin more likely to be closed exactly later.
    freq = _hist[r.clip(0, 100)]
    bonus = (freq / _total) if _total > 0 else 0.0
    score = score + 0.5 * bonus

    return score
# EVOLVE-BLOCK-END
