# EVOLVE-BLOCK-START
"""Best fit with a mild consolidation (least-load) tie-break."""
import numpy as np


def priority(item, bins):
    """Rank bins: tightest fit first, then prefer emptier bins among near-ties.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    gap = bins - item          # post-placement leftover (smaller is tighter)
    # Primary: tightest fit. Secondary: among effectively equal fits, prefer the
    # bin with more remaining capacity (least loaded) to consolidate partial bins.
    return -(gap * 1000.0) + bins
# EVOLVE-BLOCK-END
