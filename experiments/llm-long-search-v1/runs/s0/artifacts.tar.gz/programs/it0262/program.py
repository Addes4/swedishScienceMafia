# EVOLVE-BLOCK-START
"""Best fit with a mild residual-reusability tie-break: prefer the tightest fit
(smallest useful residual), strongly reward exact fills, and give a small bonus
to leftovers large enough to host a typical future item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Base: best fit -> prefer the smallest residual.
    score = -residual.astype(np.float64)

    # Strongly prefer exact fills: they close a bin with zero waste.
    score += np.where(residual == 0, 5.0, 0.0)

    # Mild bonus when the leftover can still host a typical item (mean ~40),
    # making the residual genuinely reusable rather than dead slivers.
    score += np.where((residual > 0) & (residual >= 40), 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END

