# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus plus a smooth, parametric residual-
reusability term based on the survival function of the item-size distribution."""
import numpy as np

_mean = 40.0
_count = 0
# Running second moment for a rough scale estimate.
_m2 = 1600.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _m2

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _m2 = (_m2 * _count + item * item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Best-fit tightness: prefer smaller residual.
    tightness = -r

    # Strong bonus for exact fills.
    exact = (r == 0).astype(np.float64) * 5.0

    # Smooth residual-reusability: use an exponential-decay survival model with
    # scale ~ mean item size (matching the shape of the Weibull-like distribution).
    # A residual r is reusability-friendly when it's around the typical item size.
    scale = max(_mean, 1.0)
    # Reward residuals near the typical item magnitude (so one upcoming item can
    # fill the leftover well), peaking at scale.
    x = r / scale
    reuse = np.exp(-((x - 1.0) ** 2) / 2.0) * 2.0

    # Mild extra penalty for tiny unusable slivers.
    sliver = (r > 0) & (r < _mean * 0.5)
    penalty = np.where(sliver, (_mean * 0.5 - r) * 1.0, 0.0)

    return tightness + exact + reuse - penalty
# EVOLVE-BLOCK-END

