# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware tie-break on the residual."""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit, breaking near-ties toward useful residuals."""
    residual = bins - item
    # Primary: best fit (smaller residual is better). Negative so higher = better.
    primary = -residual * 8.0
    # Secondary: reward residuals near a useful future size (~40) or its complement (60).
    # This nudges packing to leave nicely fillable gaps without disturbing main order.
    d40 = np.abs(residual - 40)
    d60 = np.abs(residual - 60)
    bonus = np.maximum(0.0, 1.0 - d40 / 15.0) + np.maximum(0.0, 1.0 - d60 / 15.0)
    return primary + bonus
# EVOLVE-BLOCK-END
