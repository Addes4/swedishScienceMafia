# EVOLVE-BLOCK-START
"""Best fit with a large-item tight-packing bias."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # post-placement remaining capacity, >= 0
    if item >= 50:
        # For large items, prefer the fullest bin that still fits (smallest residual).
        return -residual.astype(np.float64)
    else:
        # For small items, best fit but with a mild preference for tighter bins.
        return -residual.astype(np.float64) - 0.25 * bins.astype(np.float64)
# EVOLVE-BLOCK-END
