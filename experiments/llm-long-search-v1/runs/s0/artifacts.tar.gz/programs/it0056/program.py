# EVOLVE-BLOCK-START
"""Harmonic best-fit: rank bins by best-fit, but bias toward remainders that
past items suggest are re-usable (learned from an online size histogram)."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)  # smoothed counts of past item sizes
_TOTAL = 0.0


def priority(item, bins):
    global _TOTAL
    # --- update an exponentially-decaying histogram of item sizes seen so far ---
    _HIST *= 0.999
    _HIST[item] += 1.0
    _TOTAL = _TOTAL * 0.999 + 1.0

    # probability mass in future of an item of size <= r, i.e. how fillable a gap r is
    # Use cumulative histogram: a remainder r is "useful" if some past item was close to it.
    resid = bins - item  # >= 0 for all shown bins
    # fraction of historical items smaller than or equal to the residual
    cum = np.cumsum(_HIST)
    tot = cum[100] if cum[100] > 0 else 1.0
    gap_useful = cum[np.clip(resid, 0, 100)] / tot

    # primary: best fit (smaller residual preferred)
    # secondary: reward remainders that are useful (fillable by small items)
    # tertiary: reward remainders that are near zero or large (avoid middle waste)
    score = -(resid) + 0.5 * gap_useful
    return score
# EVOLVE-BLOCK-END
