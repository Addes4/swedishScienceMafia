# EVOLVE-BLOCK-START
"""Residual-viability best fit: within the class of residuals that can still
accept a typical future item, prefer the tightest fit; treat sub-mean slivers
as low priority because they are effectively dead capacity."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    global _mean, _count

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item                    # capacity left after placing here
    r = residual.astype(np.float64)
    m = _mean

    # Primary driver: best fit (smaller residual first).
    score = -r

    # Strong bonus for exact fills.
    score += (r == 0).astype(np.float64) * 10.0

    # Class bonus: residuals that can still fit a typical future item are much
    # more valuable than dead slivers. Push viable bins ahead of slivers.
    viable = (r >= m).astype(np.float64)
    score += viable * 6.0

    return score
# EVOLVE-BLOCK-END
