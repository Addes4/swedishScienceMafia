# EVOLVE-BLOCK-START
"""Best fit with a deterministic tie-break toward earlier bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: tightest fit (smallest post-placement remainder).
    # Secondary: very small preference for earlier bins, breaking residual ties
    # deterministically without disturbing the best-fit ordering.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    return -bins.astype(np.float64) - 1e-6 * idx
# EVOLVE-BLOCK-END
