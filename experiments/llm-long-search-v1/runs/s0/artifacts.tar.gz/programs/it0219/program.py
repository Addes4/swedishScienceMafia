# EVOLVE-BLOCK-START
"""Best-fit with a strong exact-fill bonus and a mild sliver penalty."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    global _mean, _count

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here

    tightness = -residual.astype(np.float64)

    # Strongly prefer exact fills.
    exact = (residual == 0).astype(np.float64) * 8.0

    # Mild penalty for unusable slivers: positive residuals below the running
    # mean are likely never reused and effectively wasted.
    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 0.5, 0.0)

    return tightness + exact - penalty
# EVOLVE-BLOCK-END
