# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus and a mean-calibrated residual preference."""
import numpy as np

_mean = 40.0
_count = 0

# Weibull-ish distribution: many small items, few large ones.
# Cache a small grid of reusable residual preferences based on running mean.
_PREF_GRID = None
_PREF_FOR_MEAN = -1.0


def _build_pref(mean):
    """Return a 101-length array: score bonus for leaving residual r (0..100)."""
    pref = np.zeros(101, dtype=np.float64)
    r = np.arange(101, dtype=np.float64)
    # A residual r is reusable if a typical future item can fill it well.
    # Items below the mean are common; reward residuals that are exact multiples
    # of "typical small items" (mean/2) since those combine cleanly.
    small = max(1.0, mean * 0.5)
    # Match to nearest multiple of small: reward closeness.
    k = np.round(r / small)
    dist = np.abs(r - k * small)
    pref = np.exp(-(dist / (0.35 * small)) ** 2)
    # Residual 0 / full bins get no bonus here (exact handled separately).
    pref[0] = 0.0
    # Large residuals are essentially empty bins; mildly less attractive than
    # small reusable ones but still fine.
    pref *= 1.0
    return pref


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _mean, _count, _PREF_GRID, _PREF_FOR_MEAN

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = (bins - item).astype(np.float64)

    # Best-fit tightness.
    tightness = -residual

    # Strong exact-fill bonus.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Reusable-residual bonus, cached per mean value.
    m = _mean
    if _PREF_GRID is None or abs(m - _PREF_FOR_MEAN) > 0.5:
        _PREF_GRID = _build_pref(m)
        _PREF_FOR_MEAN = m

    r_int = np.clip(residual.astype(np.int64), 0, 100)
    reuse = _PREF_GRID[r_int]

    return tightness + exact + reuse * 2.0
# EVOLVE-BLOCK-END
