# EVOLVE-BLOCK-START
"""Best fit with a small data-driven tie-break: residual slack is broken in favor
of leftovers that match a frequently-seen item size (reusable complements)."""
import numpy as np

_count = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _count, _hist

    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Dominant term: best fit (prefer smaller residual).
    tightness = -residual.astype(np.float64)

    # Weak tie-break: reward residuals that match a frequently-seen item size.
    r_idx = np.where(residual >= 1, residual, 0).astype(np.int64)
    freq = _hist[r_idx] / _count
    freq = np.where(residual >= 1, freq, 0.0)

    return tightness + freq * 0.01
# EVOLVE-BLOCK-END
