# EVOLVE-BLOCK-START
"""Reserve-a-seed best fit: don't fill bins down to slivers that can't fit future items."""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = _state
    s["sum"] += item
    s["count"] += 1
    mean = s["sum"] / s["count"]

    remainder = bins - item  # remaining capacity after placing the item

    # Primary: prefer bins whose post-placement remainder can still hold a typical future item.
    # Use a soft preference so best-fit still dominates inside each group.
    can_fit_future = (remainder >= mean).astype(np.float64)

    # Best-fit tightness (larger for smaller remainder), scaled to stay below the primary bonus.
    tightness = -(remainder).astype(np.float64) / 100.0

    return can_fit_future * 2.0 + tightness
# EVOLVE-BLOCK-END
