# EVOLVE-BLOCK-START
"""Best fit with an exact-fill tie-break preference."""
import numpy as np


def priority(item, bins):
    """Rank bins; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin (copy).
    """
    residual = bins - item            # leftover space if placed here
    score = -residual.astype(np.float64)
    # Strong bonus for a perfect fit (residual == 0), keeps best-fit otherwise.
    score += (residual == 0) * 1e-3
    return score
# EVOLVE-BLOCK-END
