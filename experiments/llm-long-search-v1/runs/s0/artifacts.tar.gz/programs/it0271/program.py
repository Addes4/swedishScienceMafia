# EVOLVE-BLOCK-START
"""Pure best-fit with a negligible tie-break: among bins with equal residual,
prefer residuals that have appeared as an item size before (most reusable)."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist

    _hist[item] += 1.0

    residual = bins - item
    tightness = -residual.astype(np.float64)

    # Tiny tie-break: reward residuals equal to a previously seen item size.
    r = residual
    seen = (r >= 1) & (r <= 100)
    bonus = np.zeros_like(tightness)
    idx = np.clip(r, 0, 100).astype(np.int64)
    counts = np.where(seen, _hist[idx], 0.0)
    bonus = np.where(seen & (counts > 0), 1e-6, 0.0)

    return tightness + bonus
# EVOLVE-BLOCK-END
