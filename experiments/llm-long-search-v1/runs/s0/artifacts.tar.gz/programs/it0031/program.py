# EVOLVE-BLOCK-START
"""Adaptive best-fit: prefer tight fits but favor bin remainders that match common future sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # --- online histogram of past item sizes (persistent across calls) ---
    hist = priority.hist
    if hist is None:
        hist = np.zeros(101, dtype=np.float64)
        priority.hist = hist
    hist[item] += 1.0
    total = hist.sum()

    rem = bins - item  # post-placement remainders (>= 0)

    # Best-fit residual term: smaller remainder is better. Penalize awkward
    # small remainders (which tend to be hard to fill) by how common such sizes are.
    # Estimate probability that a future item size is <= remainder via histogram.
    # We want remainders that are either 0 (perfect) or large enough to accept
    # the typical item. Sizes that are "rarely matched" get a small penalty.
    if total > 0:
        # cumulative probability mass for sizes up to each remainder value
        cum = np.cumsum(hist[:101]) / total  # cum[s] = P(size <= s)
        # For each remainder r, median-ish future item that fits is ~ mean size (40).
        # Reward remainders that can fit the mean next item; penalize tiny leftovers.
        # p_fit = probability a random future item fits in remainder r
        p_fit = np.ones_like(rem, dtype=np.float64)
        # P(size <= r) computed at integer remainders
        idx = np.clip(rem, 0, 100).astype(np.int64)
        p_fit = cum[idx]
        # Secondary weighted term: prefer larger p_fit (remainder useful for future items)
        secondary = 4.0 * p_fit
    else:
        secondary = np.zeros_like(rem, dtype=np.float64)

    # Primary: best fit. Tight (small residual) strongly preferred.
    return -rem * 1000.0 + secondary
# EVOLVE-BLOCK-END
