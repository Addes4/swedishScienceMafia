# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break driven by a running histogram
of seen item sizes and an adaptive sliver threshold."""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100), used to reward residuals that match
# a common leftover size.
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    m = _mean

    # Adaptive sliver penalty: penalize residual r in (0, m) by how *unlikely* it
    # is that some item of size exactly r will arrive (i.e. the leftover would
    # stay usable). Rare/small leftovers are more likely to be dead weight.
    valid_r = residual >= 1
    r_idx = np.where(valid_r, residual, 0).astype(np.int64)
    if _count > 0:
        freq = _hist[r_idx] / _count
    else:
        freq = np.zeros_like(residual, dtype=np.float64)
    freq = np.where(valid_r, freq, 0.0)

    sliver = (residual > 0) & (residual < m)
    # Penalty grows when the leftover is small (relative to mean) and rare.
    rarity = 1.0 - np.minimum(freq * m, 1.0)
    scarcity = np.where(sliver, (m - residual) / m, 0.0)
    penalty = np.where(sliver, scarcity * rarity, 0.0) * 2.0

    # Bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Complement bonus: reward residuals that equal a frequently seen item size.
    complement = freq * m * 3.0

    return tightness - penalty + exact + complement
# EVOLVE-BLOCK-END
