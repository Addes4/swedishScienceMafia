# EVOLVE-BLOCK-START
"""Harmonic-style best fit: prefer bins where the item leaves a small residual,
with a strong boost for exact fits (residual 0)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item
    return 1.0 / (resid + 1.0)
# EVOLVE-BLOCK-END
