# EVOLVE-BLOCK-START
"""Worst/first-fit hybrid: prefer the fullest bin the item fits in (tight fit),
with a very small penalty pulling toward smaller post-placement residual to
break large-capacity ties toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: smallest remaining capacity (i.e. fullest bin) the item fits into.
    # This packs tightly like best-fit, but prefers already-used fuller bins.
    return -bins
# EVOLVE-BLOCK-END

