# EVOLVE-BLOCK-START
"""Best fit with a data-driven residual-usability tie-break.

The dominant term is best-fit tightness (minimize residual). As a tie-break,
we reward residuals that are likely to remain useful: using a histogram of
seen item sizes we compute the empirical probability that a future item fits
in the residual. This mildly nudges packing toward residuals that can still
accommodate common item sizes.
"""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest score."""
    global _mean, _count, _hist

    # Update running statistics with the current item (before scoring).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Dominant term: best-fit tightness (prefer smaller residual).
    tightness = -r * 100.0

    # Data-driven usability: probability that a common future item fits the residual.
    valid = residual >= 1
    r_idx = np.where(valid, residual, 0).astype(np.int64)
    cdf = np.cumsum(_hist) / max(_count, 1.0)
    fit_prob = np.where(valid, cdf[r_idx], 0.0)

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Usability tie-break (small relative to tightness bucket spacing of 100).
    return tightness + fit_prob * 3.0 + exact
# EVOLVE-BLOCK-END
