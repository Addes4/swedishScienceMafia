# EVOLVE-BLOCK-START
"""Best fit with a small residual-usability adjustment based on a running mean item size."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (include this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = (bins - item).astype(np.int64)  # remaining capacity after placing here

    # Dominant term: best fit prefers the smallest residual.
    tightness = -residual.astype(np.float64)

    # Strong preference for exact fills (never displaced by an equal residual).
    exact = (residual == 0).astype(np.float64) * 6.0

    # Mild penalty for wasting a sliver: a positive residual too small to hold
    # a typical item is nearly lost capacity. Keep this small so it only
    # breaks near-ties and does not override genuine best-fit savings.
    m = _mean
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 0.15, 0.0)

    return tightness - penalty + exact
# EVOLVE-BLOCK-END
