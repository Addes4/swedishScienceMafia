# EVOLVE-BLOCK-START
"""Best fit, with an online hedge that picks among a few waste-aware variants.

Idea: pure best-fit is a strong baseline. Rather than betting everything on one
hand-tuned perturbation (which the past attempts showed tends to tie best-fit),
we keep a small portfolio of scoring rules, each a different trade-off between
"tight fit" and "keep residual space fillable". At every call we evaluate how
each rule would have scored past items by replaying a shadow copy of the bin
remainders, and use the rule with the best shadow performance so far.

The replay is cheap: we only maintain a shadow remainder list per rule, and
replay the item against it each call. With a handful of rules this is O(k*n)
work over an instance, well within the time limit.
"""
import numpy as np


# Portfolio of scoring rules. Each takes (item, remaining_capacities) and
# returns a score per bin (higher = better). They are pure functions; the
# hedge below decides which one to trust.
def _best_fit(item, rem):
    # tightest fit (smallest post remainder)
    return -(rem - item)


def _best_fit_floor1(item, rem):
    # best fit, but never produce a remainder of exactly 1 if avoidable
    post = rem - item
    return -post - 1000.0 * (post == 1)


def _best_fit_floor_small(item, rem):
    # best fit, penalize tiny unusable remainders (1..3)
    post = rem - item
    small = (post >= 1) & (post <= 3)
    return -post - 5.0 * small


def _worst_among_open(item, rem):
    # prefer larger remainders among bins that already hold something
    post = rem - item
    opened = rem < 100
    score = np.where(opened, post.astype(float), -1e9)
    return score


_RULES = [
    _best_fit,
    _best_fit_floor1,
    _best_fit_floor_small,
    _worst_among_open,
]


class _RuleStats:
    __slots__ = ("rem", "bins_used", "waste", "calls")

    def __init__(self):
        self.rem = []          # shadow remaining capacities
        self.bins_used = 0
        self.waste = 0.0       # sum of leftover in closed bins
        self.calls = 0


_state = {"stats": None}


def _shadow_apply(rule_idx, item):
    """Replay `item` against the shadow bins of rule `rule_idx`; update shadow."""
    st = _state["stats"][rule_idx]
    rem = st.rem
    if not rem:
        rem.append(100)
    rem_arr = np.array(rem, dtype=np.int64)
    fits = np.nonzero(rem_arr >= item)[0]
    if fits.size == 0:
        rem.append(100 - item)
        st.bins_used += 1
        return
    sub = rem_arr[fits]
    scores = _RULES[rule_idx](int(item), sub)
    best = fits[int(np.argmax(scores))]
    rem[best] -= item
    if rem[best] == 0:
        st.bins_used += 1
    st.calls += 1


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first tie)."""
    if _state["stats"] is None:
        _state["stats"] = [_RuleStats() for _ in _RULES]

    # Update the shadow replay for every rule with this item.
    for i in range(len(_RULES)):
        _shadow_apply(i, item)

    # Pick the rule with the fewest bins used so far (ties: earlier rule).
    stats = _state["stats"]
    used = [s.bins_used for s in stats]
    best_rule = int(np.argmin(used))

    # But also require that the rule is plausible given current live bins:
    # if the item only fits in one live bin, best fit is effectively forced,
    # and all tight-fit rules agree there, so just go with the hedge.
    return _RULES[best_rule](item, bins)
# EVOLVE-BLOCK-END
