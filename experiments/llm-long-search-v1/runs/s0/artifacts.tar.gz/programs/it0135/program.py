# EVOLVE-BLOCK-START
"""Best fit with a soft bonus for residuals that match a typical item size."""
import numpy as np

# A small set of frequent integer item sizes to recognize exact-complement leftovers.
_common = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20, 25, 30, 40, 50], dtype=np.int64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit: prefer smaller residual (dominant term).
    tightness = -residual.astype(np.float64)

    # Soft, tiny bonus when the residual matches a common item size, meaning the
    # leftover could plausibly be filled exactly later. Kept small so it only
    # breaks near-ties and never overrides the best-fit ordering.
    complement = np.isin(residual, _common).astype(np.float64)
    exact = (residual == 0).astype(np.float64)

    return tightness + complement * 0.1 + exact * 0.1
# EVOLVE-BLOCK-END

