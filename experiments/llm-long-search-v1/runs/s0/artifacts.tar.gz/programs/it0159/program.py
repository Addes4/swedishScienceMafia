# EVOLVE-BLOCK-START
"""Best fit: prefer the bin leaving the smallest residual, with a tiny bonus
for an exact fill. Pure best-fit has proven strongest for this distribution;
extra heuristic terms only disturbed the ordering."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit: smaller residual => higher score.
    score = -residual.astype(np.float64)

    # Tiny bonus for exact fills, small enough not to disturb best-fit ordering.
    score += (residual == 0).astype(np.float64) * 0.01

    return score
# EVOLVE-BLOCK-END
