# EVOLVE-BLOCK-START
"""Best fit with a smooth, empirically-grounded reusable-residual bonus.

The strongest prior rule was close to pure best-fit plus an exact-fill bonus.
Rather than rewarding a single modal leftover size (noisy), we reward each
candidate residual r by the empirical probability that a typical future item
(drawn from the same distribution as past items) is small enough to fit into r,
i.e. the fraction of seen items with size <= r. This directly targets residuals
that are actually reusable.
"""
import numpy as np

_count = 0
# Empirical CDF of seen item sizes (1..100).
_cdf = np.zeros(101, dtype=np.float64)  # counts below/at size


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _count, _cdf

    # Update empirical distribution of past items (before scoring this one).
    _cdf[item] += 1.0
    _count += 1

    residual = bins - item  # remaining capacity after placing item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    # Exact fill: strong bonus.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Smooth reusable-residual bonus: empirical probability that a future item
    # fits into this residual. Built from the counts of past items.
    total = _count
    if total > 0:
        # cumulative counts up to each size -> fraction of items <= r
        cum = np.cumsum(_cdf[1:])  # index 0 -> size 1, etc.
        r = residual
        valid = r >= 1
        idx = np.clip(r - 1, 0, 99)
        frac_le = np.where(valid, cum[idx] / total, 0.0)
        # Penalize slivers that are positive but tiny (rarely fillable).
        sliver = (residual > 0) & (residual < 10)
        penalty = np.where(sliver, (10.0 - residual) * 0.5, 0.0)
        reuse = frac_le * 3.0
    else:
        reuse = np.zeros_like(residual, dtype=np.float64)
        penalty = np.zeros_like(residual, dtype=np.float64)

    return tightness + exact + reuse - penalty
# EVOLVE-BLOCK-END
