# EVOLVE-BLOCK-START
"""Best fit with a tiny exact-fill tie-breaker."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: best fit (smallest post-placement remainder) -> larger score.
    primary = -(bins - item)
    # Tiny tie-breaker: reward exact fits (remainder 0) so ties go to closeable bins.
    rem = bins - item
    bonus = (rem == 0).astype(np.float64) * 1e-3
    return primary + bonus
# EVOLVE-BLOCK-END
