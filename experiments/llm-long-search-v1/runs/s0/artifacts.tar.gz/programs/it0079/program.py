# EVOLVE-BLOCK-START
"""Modified best-fit: prefer tight fits, with a bounded linear correction on remainder."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item
    # Best fit: smallest remainder is best.  Add a small linear penalty on the
    # remainder so ties/near-ties are broken toward tighter packing.
    return -(rem.astype(np.float64) + 0.001 * rem)
# EVOLVE-BLOCK-END
