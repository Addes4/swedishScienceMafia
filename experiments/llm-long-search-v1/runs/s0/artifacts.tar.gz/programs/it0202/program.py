# EVOLVE-BLOCK-START
"""Best fit with a residual-reusability tie-break: prefer tight fits, penalize
slivers, reward exact fills, and give a smooth bounded bonus based on the
empirical chance a leftover can still be filled by a typical future item."""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)  # counts of seen item sizes 1..100


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _mean, _count, _hist

    # Update running stats of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -r

    # Penalize positive residuals smaller than the mean: slivers are wasted.
    m = _mean
    sliver = (r > 0) & (r < m)
    penalty = np.where(sliver, (m - r) * 2.0, 0.0)

    # Strong bonus for exact fills.
    exact = (r == 0).astype(np.float64) * 5.0

    # Smooth bounded reuse bonus: fraction of past items that fit in residual r.
    # A leftover worth r is reusable with probability ~ P(item <= r).
    if _count > 1:
        cdf = np.cumsum(_hist[1:]) / _count  # cdf[k-1] = P(item <= k)
        idx = np.clip(r.astype(np.int64), 0, 100)
        reuse = np.where(r >= 1, cdf[idx - 1], 0.0)
    else:
        reuse = np.zeros_like(r)
    complement = reuse * 3.0

    return tightness - penalty + exact + complement
# EVOLVE-BLOCK-END
