# EVOLVE-BLOCK-START
"""Best fit with a deterministic perfect-pairing tie-break.

Tightness (smallest residual) dominates; a strictly sub-1 bonus rewards
residuals that exactly equal the current item size so identical items pair
up into full bins. A mild sliver penalty avoids dead small residuals, and
exact fills get the strongest sub-tightness bonus.
"""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _mean, _count

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Dominant term: best-fit (prefer smallest residual). Scale so that any
    # residual difference of >=1 outranks all sub-1 tie-breaks below.
    tightness = -r * 2.0

    # Sub-1 tie-breakers (all strictly less than the 2.0 tightness step):
    # exact fill is best.
    exact = (residual == 0).astype(np.float64) * 0.9

    # Perfect pairing: residual equals this item size (lets an identical item
    # fill this bin completely later).
    pair = (residual == item).astype(np.float64) * 0.5

    # Mild sliver penalty: residuals smaller than ~mean are likely dead.
    m = _mean
    sliver = (residual > 0) & (r < m)
    penalty = np.where(sliver, (m - r) / (m * 100.0), 0.0)

    return tightness + exact + pair - penalty
# EVOLVE-BLOCK-END
