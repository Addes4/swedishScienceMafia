# EVOLVE-BLOCK-START
"""Best fit with residual-usability tie-breaks driven by the empirical size
histogram of past items (frequency-weighted complement matching)."""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)
# Precomputed frequency weights for reuse-likely residuals.
_reuse = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _mean, _count, _hist, _reuse

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing here

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -residual.astype(np.float64)

    m = _mean
    # Penalize small positive residuals ("slivers") that are hard to reuse.
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Frequency-weighted complement bonus: reward residuals whose value has
    # been seen often as an item size, since such a leftover is most likely
    # to be exactly reusable by a future item.
    r = residual
    valid = r >= 1
    if _count > 1:
        total = _hist[1:].sum()
        if total > 0:
            _reuse[1:] = _hist[1:] / total
        idx = np.clip(r, 0, 100).astype(np.int64)
        freq = _reuse[idx]
        complement = np.where(valid, freq * 3.0 * np.sqrt(total), 0.0)
        complement = np.minimum(complement, 3.0)
    else:
        complement = np.zeros_like(r, dtype=np.float64)

    # Waste-aware extra penalty near the mean.
    near_full = (residual > 0) & (residual < m)
    waste = np.where(near_full, (1.0 - residual / m) * 1.0, 0.0)

    return tightness - penalty + exact + complement - waste
# EVOLVE-BLOCK-END
