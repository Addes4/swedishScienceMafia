# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break based on a running mean."""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1

    residual = bins - item  # remaining capacity after placing the item here.

    # Best-fit core: prefer smaller residual. Dominant term, scaled large so it
    # always governs the ordering except for explicit exact-fill preference.
    tightness = -residual.astype(np.float64)

    # Strong bonus for exact fills: residual 0 frees a bin completely and is
    # always strictly better than a positive residual.
    exact = (residual == 0).astype(np.float64) * 50.0

    m = _mean
    # Mild penalty for dead slivers: positive residuals well below a typical
    # future item are nearly unreusable, so slightly discourage them -- but less
    # than one unit of residual so smaller residual still wins overall.
    sliver = (residual > 0) & (residual < 0.5 * m)
    penalty = np.where(sliver, 0.9, 0.0)

    return tightness + exact - penalty
# EVOLVE-BLOCK-END
