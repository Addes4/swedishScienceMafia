# EVOLVE-BLOCK-START
"""Online histogram-based "closability" scoring with best-fit fallback.

For each fitting bin we compute the post-placement remainder r = bins - item.
We reward remainders that are likely to be exactly filled by some future item,
estimated online from a running histogram of observed item sizes. This turns
best-fit's myopic tightest-fit into a slightly more forward-looking rule that
avoids stranding small unusable gaps, without needing to see future items.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in,
          including unused bins (capacity 100), in bin order.
    """
    # Lazily-initialized per-process histogram over item sizes 1..100.
    hist = priority.hist
    total = priority.total
    if hist is None:
        hist = np.ones(101, dtype=np.float64)  # Laplace smoothing
        total = 101.0
        priority.hist = hist
        priority.total = total

    # Current probability estimate for each possible remainder value.
    p = hist / total  # index 0 unused; p[r] ~ P(next item == r)

    r = bins - item  # post-placement remainder per fitting bin

    # Closability bonus: how likely the remainder is to be exactly matched.
    # Scale so it can override tiny residual differences but not larger ones.
    close = p[np.clip(r, 0, 100)]

    # Primary: prefer tightest fit (smallest positive remainder) -> -r.
    # Secondary: prefer remainders likely to be closed later.
    score = -r.astype(np.float64) + 5.0 * close

    # Update the running histogram with the current item.
    hist[item] += 1.0
    priority.total = total + 1.0

    return score
# EVOLVE-BLOCK-END
