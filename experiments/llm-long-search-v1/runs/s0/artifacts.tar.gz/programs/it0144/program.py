# EVOLVE-BLOCK-START
"""Best fit with exact-fill priority and a data-driven sliver penalty based on
the smallest item size observed so far, plus a frequent-complement nudge."""
import numpy as np

_mean = 40.0
_count = 0
_hist = np.zeros(101, dtype=np.float64)
_min_item = 100


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties)."""
    global _mean, _count, _hist, _min_item

    # Update running statistics with the current item before scoring.
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0
    if item < _min_item:
        _min_item = item

    residual = bins - item  # remaining capacity after placing item here

    tightness = -residual.astype(np.float64)

    # Penalize residuals that are positive but smaller than the smallest item
    # seen so far: such slivers can never be filled exactly, wasting capacity.
    m = float(_min_item)
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual), 0.0)

    # Strongly prefer exact fills (residual 0).
    exact = (residual == 0).astype(np.float64) * 10.0

    # Data-driven complement bonus: reward residuals equal to a frequently seen
    # item size, so the leftover is likely reusable.
    r = residual
    valid = r >= 1
    r_idx = np.where(valid, r, 0).astype(np.int64)
    if _count > 0:
        freq = _hist[r_idx] / _count
    else:
        freq = np.zeros_like(r, dtype=np.float64)
    freq = np.where(valid, freq, 0.0)
    complement = freq * 2.0

    return tightness - penalty + exact + complement
# EVOLVE-BLOCK-END


