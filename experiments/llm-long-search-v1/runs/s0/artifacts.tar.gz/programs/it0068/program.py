# EVOLVE-BLOCK-START
"""Best fit with a decreasing-style reservation of largish gaps."""
import numpy as np

# Online running estimates of the item-size distribution.
_mean = 40.0
_max_seen = 40.0
_alpha = 0.02


def priority(item, bins):
    """Rank bins: tightest fit, but avoid wasting capacity that future large items need."""
    global _mean, _max_seen

    remainder = (bins - item).astype(np.float64)

    # Primary: tightest fit wins (smallest nonnegative remainder).
    score = -remainder

    # Reservation term: penalize leaving a remainder that is strictly between 0 and
    # the typical (mean-sized) item, since such a gap is too small for a typical item
    # but wastes a whole bin. Bonus for exact close.
    typical = _mean
    small_gap = (remainder > 0) & (remainder < typical)
    score -= 0.5 * small_gap

    # Encourage exact closure.
    score += 1.0 * (remainder == 0)

    # Update statistics.
    _mean += _alpha * (item - _mean)

    return score
# EVOLVE-BLOCK-END
