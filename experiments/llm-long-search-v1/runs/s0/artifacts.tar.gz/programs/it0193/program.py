# EVOLVE-BLOCK-START
"""Best-fit with an exact-fill bonus and a self-tuned residual-reuse bonus.

Pure best-fit (smallest residual) is empirically strong. To break ties among
equally tight fits toward residuals that are likely reusable, reward residuals
that match the current item size (perfect pairing) and residuals that have
historically been reusable. All auxiliary terms are kept small so they never
override a genuine residual difference.
"""
import numpy as np

_mean = 40.0
_count = 0
# Raw counts of seen item sizes (1..100). A residual equal to a frequently
# seen item size is likely to be filled later (reusable leftover).
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _mean, _count, _hist

    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: strictly dominant term. Scale so auxiliary ties
    # cannot flip a genuine residual difference (integer residuals => gaps >=1).
    tightness = -residual.astype(np.float64) * 100.0

    # Strong bonus for exact fills (residual 0); within the same residual it
    # makes no difference, but across near-ties it strongly prefers perfect fits.
    exact = (residual == 0).astype(np.float64) * 60.0

    # Bonus for residuals that pair with the current item size (perfect reuse).
    same = (residual == item).astype(np.float64) * 25.0

    # Data-driven reuse bonus: reward residuals whose size has been seen often,
    # so the leftover is likely to be refillable. Kept small (<= 30).
    r = residual
    valid = r >= 1
    r_idx = np.where(valid, r, 0).astype(np.int64)
    freq = _hist[r_idx]
    maxf = _hist.max()
    if maxf > 0:
        reuse = (freq / maxf) * 30.0
    else:
        reuse = np.zeros_like(r, dtype=np.float64)
    reuse = np.where(valid, reuse, 0.0)

    return tightness + exact + same + reuse
# EVOLVE-BLOCK-END
