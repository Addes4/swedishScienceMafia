# EVOLVE-BLOCK-START
"""Best fit with a smooth, data-driven 'reusable residual value' term.

The dominant rule is best-fit tightness (prefer the smallest positive residual).
On top of that, we reward residuals that are likely to be reusable by future
items, estimated from a running histogram of the item sizes seen so far.
"""
import numpy as np

_count = 0
# Histogram of seen item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _count, _hist

    # Update histogram of past items (before scoring this one).
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual (dominant term).
    tightness = -residual.astype(np.float64)

    # Small bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Data-driven reusable-residual value.
    # Estimate the probability that a residual r is usefully filled by some
    # typical future item: sum over item sizes s <= r of P(s) * s/r
    # (utilization-weighted), which peaks when r matches common sizes.
    r = np.clip(residual, 0, 100).astype(np.int64)
    total = _hist.sum()
    if total > 0:
        p = _hist / total  # probability mass per size s (index 1..100)
        s = np.arange(101, dtype=np.float64)
        # contribution of size s to a residual r: fills it well if s <= r,
        # weighted by utilization s/r.
        s_weighted = p * s  # p[s] * s
        cum = np.concatenate(([0.0], np.cumsum(s_weighted[1:])))  # cum[k] = sum_{s<=k} p[s]*s
        s_sum = np.concatenate(([0.0], np.cumsum(p[1:])))        # sum_{s<=k} p[s]
        # For r>0: value = (1/r) * sum_{s<=r} p[s]*s, but only count sizes that
        # actually fit (s<=r). Also include small chance term P(s==r).
        safe_r = np.where(r > 0, r, 1)
        reuse = cum[r] / safe_r
        # Bonus if the residual exactly equals the modal (most likely reusable) size.
        modal = int(np.argmax(_hist[1:])) + 1
        match = (r == modal).astype(np.float64) * s_sum[min(modal, 100)]
    else:
        reuse = np.zeros_like(r, dtype=np.float64)
        match = np.zeros_like(r, dtype=np.float64)

    # Scale complement value so it only breaks ties within tightness.
    complement = reuse * 0.5 + match * 3.0

    # Mild penalty for tiny positive slivers below the mean item size: such
    # leftovers are rarely reusable.
    m = max(1.0, (_hist * np.arange(101)).sum() / total if total > 0 else 40.0)
    sliver = ((residual > 0) & (residual < m)).astype(np.float64)
    sliver_penalty = sliver * (1.0 - residual / m) * 1.0

    return tightness + exact + complement - sliver_penalty
# EVOLVE-BLOCK-END
