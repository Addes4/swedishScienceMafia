# EVOLVE-BLOCK-START
"""Harmonic-style best fit: weight tight fits by item class and reward exact closures."""
import numpy as np


def priority(item, bins):
    """Score bins: prefer tightest fits, with harmonic weighting and closure bonus."""
    # residual gap after placing item
    gap = bins - item
    # Harmonic-style weighting: bins whose remaining capacity falls in the same
    # "class" as the item get a boost, reducing fragmentation for small items.
    # Score = -(gap) is best fit; add a bonus when gap is small relative to item,
    # which encourages closing bins tightly (harmonic packing).
    base = -gap.astype(np.float64)
    # bonus for near-exact closures
    closure = np.where(gap == 0, 1.0, 0.0)
    # mild preference for gaps that are small relative to the item size
    tight = item / (gap + item + 1.0)
    return base + 0.5 * closure + 0.25 * tight
# EVOLVE-BLOCK-END
