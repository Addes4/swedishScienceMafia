# EVOLVE-BLOCK-START
"""Hybrid best-fit with a future-fit bonus on post-placement remainder."""
import numpy as np


def priority(item, bins):
    """Rank bins: primary best-fit tightness, secondary bonus for reusable remainder.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities of fitting bins, in bin order.
    """
    rem = bins - item  # remainder after placing the item

    # Primary: tightest fit (smallest remainder) gets highest score.
    tight = -rem.astype(np.float64)

    # Secondary: bonus when remainder is "reusable" — either close to the
    # typical item size (~40) so a single future item may fit, or near-zero
    # so the bin closes cleanly. Reward proximity to useful remainder values.
    r = rem.astype(np.float64)
    near_full = 1.0 / (1.0 + np.abs(r - 40.0))   # remainder ~ one more item
    near_zero = 1.0 / (1.0 + np.abs(r - 0.0))    # cleanly closed bin
    reuse = np.maximum(near_full, near_zero)

    return tight + 0.5 * reuse
# EVOLVE-BLOCK-END
