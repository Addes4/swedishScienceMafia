# EVOLVE-BLOCK-START
"""Best fit with a remainder-aware secondary term.

Primary rule: tightest fit (smallest post-placement residual).
Secondary: among bins with a similar residual, prefer the residual that is
either very small (near-perfect fit) or large (leaves a roomy bin usable by
big future items), penalizing mid-size stranded gaps.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # post-placement remaining capacity, >= 0

    # Primary: tightest fit. Use a sharp increasing transform of residual.
    # Smaller residual -> higher score.
    primary = -residual.astype(np.float64)

    # Secondary: penalize mid-size residuals (roughly around item..2*item)
    # so that near-perfect fits and roomy bins are preferred over stranded gaps.
    # A residual close to 0 is best; a residual >= 2*item is also fine.
    mid = (residual > 0) & (residual < 2 * item)
    penalty = mid.astype(np.float64) * 0.01

    return primary - penalty
# EVOLVE-BLOCK-END
