# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus and a reusability bonus for residuals that
are integer multiples of common small item sizes (the leftovers most likely to
be filled exactly by future items)."""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100), used to reward residuals that match
# a common leftover size.
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual.
    tightness = -residual.astype(np.float64)

    m = _mean

    # Penalize residuals that are positive but smaller than a typical item:
    # such slivers are effectively wasted capacity.
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Strong bonus for exact fills (residual 0): closing a bin is very valuable.
    exact = (residual == 0).astype(np.float64) * 8.0

    # Reusability bonus: reward residuals that are integer multiples of small
    # common item sizes, since such leftovers can be exactly filled later.
    # Estimate a "nice" size from the histogram: the smallest size with a
    # reasonable frequency.
    r = residual
    valid = r >= 1
    if _count > 0:
        modal = int(np.argmax(_hist[1:])) + 1
    else:
        modal = 10
    if modal < 1:
        modal = 1
    # Reward residuals that are multiples of the modal size (exact reusability).
    mult = np.zeros_like(r, dtype=np.float64)
    if modal >= 2:
        is_mult = valid & (r % modal == 0)
        mult = is_mult.astype(np.float64)
    elif modal == 1:
        mult = valid.astype(np.float64)
    complement = mult * 2.0

    return tightness - penalty + exact + complement
# EVOLVE-BLOCK-END

