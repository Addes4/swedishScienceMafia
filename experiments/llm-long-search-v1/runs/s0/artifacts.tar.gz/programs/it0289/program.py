# EVOLVE-BLOCK-START
"""Best fit with a smooth, self-scaling residual-reusability correction.

Pure best-fit is the dominant term. A small correction penalizes residuals that
are positive but too small to be plausibly reused by a single future item, and
rewards exact fills. The correction is monotone in the residual and scaled by
the empirical item-size mean, computed from a running estimate (no histogram
noise), so it refines ordering without overriding tightness.
"""
import numpy as np

_mean = 40.0
_count = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count

    # Update running mean of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    m = _mean

    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Best-fit tightness dominates: prefer smaller residual.
    tightness = -r

    # Strongly prefer exact fills (residual 0): recovers full bin.
    exact = (residual == 0).astype(np.float64) * 5.0

    # Smooth dead-zone penalty: positive residuals below ~half the typical item
    # size are effectively unreusable slivers. Penalty grows as residual shrinks
    # toward 0, is monotone, and is bounded by the mean.
    half = 0.5 * m
    dead = (residual > 0) & (r < half)
    penalty = np.where(dead, (half - r) * (1.0 / max(m, 1.0)) * 4.0, 0.0)

    return tightness + exact - penalty
# EVOLVE-BLOCK-END

