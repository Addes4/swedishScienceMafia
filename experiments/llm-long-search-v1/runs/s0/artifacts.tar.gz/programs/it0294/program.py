# EVOLVE-BLOCK-START
"""Best fit with a smooth expected-reuse tie-break.

The core is best fit (prefer the smallest residual). The tie-break rewards
residuals that are likely to be reusable later, estimated from the empirical
histogram of seen item sizes and a running mean. This keeps the rule stable
across instances instead of relying on a single modal size.
"""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: strongly prefer smaller residual.
    tightness = -residual.astype(np.float64) * 3.0

    r = residual
    valid = r >= 1
    # Empirical, normalized probability that a future item exactly fills the
    # residual: p(r) = hist(r) / count.  Smooth and self-scaling.
    if _count > 1:
        total = _hist[1:].sum()
        prob = _hist / total  # normalized over sizes 1..100
        # Clip residuals to valid index range.
        idx = np.clip(r, 0, 100)
        reuse = np.where(valid, prob[idx], 0.0) * 8.0
    else:
        reuse = np.zeros_like(r, dtype=np.float64)

    # Light bonus for residuals near the running mean (a typically reusable size).
    m = _mean
    near_mean = valid & (np.abs(r - m) <= 2.0)
    mean_bonus = np.where(near_mean, 1.0, 0.0)

    # Strong bonus for exact fills.
    exact = (r == 0).astype(np.float64) * 5.0

    return tightness + reuse + mean_bonus + exact
# EVOLVE-BLOCK-END

