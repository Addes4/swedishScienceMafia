# EVOLVE-BLOCK-START
"""Best fit with a strictly dominant tightness scale, plus a small exact-pairing
tie-break (reward residuals equal to the arriving item size)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual. Scale large so it dominates.
    tightness = -residual.astype(np.float64) * 1000.0

    # Tiny tie-break: prefer a residual exactly equal to the item size, so the
    # leftover can be perfectly reused by a future identical item.
    pair = (residual == item).astype(np.float64)

    return tightness + pair
# EVOLVE-BLOCK-END
