# EVOLVE-BLOCK-START
"""Best fit with a wasted-space penalty keyed to observed item sizes."""
import numpy as np

_state = {"sum": 0.0, "count": 0, "mean": 40.0}


def priority(item, bins):
    # Update running mean of item sizes (cheap, pure Python).
    _state["sum"] += item
    _state["count"] += 1
    mean = _state["sum"] / _state["count"]
    _state["mean"] = mean

    rem = bins - item                      # residual capacity after placing item
    score = -rem.astype(np.float64)        # primary: tightest fit

    # Penalize bins that would leave a tiny, likely-unusable sliver.
    threshold = max(1.0, 0.5 * mean)
    waste = (rem < threshold) & (rem > 0)
    score -= waste.astype(np.float64) * (threshold - rem) * 0.1

    return score
# EVOLVE-BLOCK-END
