# EVOLVE-BLOCK-START
"""Best fit with a data-driven residual-usability correction.

The dominant term is best-fit (smaller residual wins). On top of that we
penalize "dead slivers": residuals that are positive but smaller than a typical
item will likely never be reused, so they represent wasted capacity. We also
reward residuals that exactly match a frequently seen item size, since such a
leftover is the most likely to be reusable. Terms are kept small so that
genuine best-fit decisions are only broken on near-ties.
"""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist

    # Update running stats from past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here
    res = residual.astype(np.float64)

    # Dominant: best-fit tightness.
    tightness = -res

    # Dead-sliver penalty: residuals in (0, mean) are unlikely to be reusable.
    # Bounded and smooth: full penalty near 0, fading to 0 at the mean.
    m = _mean
    in_sliver = (res > 0) & (res < m)
    sliver_pen = np.where(in_sliver, (1.0 - res / m), 0.0) * 1.5

    # Exact-fill bonus: strong preference for leaving zero residual.
    exact = (res == 0).astype(np.float64) * 3.0

    # Complement bonus: reward residuals matching a common item size so far,
    # since those leftovers are the most likely to be reusable later.
    if _count >= 20:
        modal = float(np.argmax(_hist[1:]) + 1)
        match = ((res >= 1) & (res == modal)).astype(np.float64)
    else:
        match = np.zeros_like(res)
    complement = match * 2.0

    return tightness - sliver_pen + exact + complement
# EVOLVE-BLOCK-END

