# EVOLVE-BLOCK-START
"""Best fit with a smooth, histogram-based "reuse value" tie-break: residuals
that are likely to be exactly refillable by a single future item get a bonus,
on top of a dominant best-fit (smallest residual) tightness term."""
import numpy as np

_mean = 40.0
_count = 0
# Histogram of seen item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)
# Normalized histogram (probability over seen items), recomputed lazily.
_hist_norm = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _mean, _count, _hist, _hist_norm

    # Update running mean and histogram of past items (before scoring this one).
    _mean = (_mean * _count + item) / (_count + 1)
    _count += 1
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit tightness: prefer smaller residual. Dominant term.
    tightness = -residual.astype(np.float64)

    m = _mean
    # Penalize residuals that are positive but smaller than a typical item:
    # such slivers are effectively wasted capacity.
    sliver = (residual > 0) & (residual < m)
    penalty = np.where(sliver, (m - residual) * 2.0, 0.0)

    # Strong bonus for exact fills.
    exact = (residual == 0).astype(np.float64) * 6.0

    # Data-driven reuse value: reward residuals that equal a frequently seen
    # item size, since such a leftover is most likely to be reusable exactly by
    # a future item.  Bounded and smooth via the normalized histogram.
    if _count > 0:
        _hist_norm[:] = _hist / _count
        r = residual
        valid = (r >= 1) & (r <= 100)
        idx = np.clip(r, 0, 100)
        reuse = np.where(valid, _hist_norm[idx] * m, 0.0)  # scale into tightness units
    else:
        reuse = np.zeros_like(residual, dtype=np.float64)

    return tightness - penalty + exact + reuse
# EVOLVE-BLOCK-END

