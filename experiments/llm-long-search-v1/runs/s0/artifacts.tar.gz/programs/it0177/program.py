# EVOLVE-BLOCK-START
"""Best fit with a strictly sub-1 tie-break preferring residuals equal to the
current item size (perfect complementary pairing) plus an exact-fill bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here
    r = residual.astype(np.float64)

    # Dominant term: best fit = prefer smallest residual.
    tightness = -r

    # Strictly sub-1 tie-break: prefer leaving a residual exactly equal to the
    # current item, so an identical next item can fill the bin perfectly.
    pair = (residual == item).astype(np.float64) * 0.5

    # Slightly stronger tie-break: exact fills (residual 0) are best.
    exact = (residual == 0).astype(np.float64) * 0.75

    return tightness + pair + exact
# EVOLVE-BLOCK-END
