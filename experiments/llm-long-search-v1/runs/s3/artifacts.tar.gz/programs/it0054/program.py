# EVOLVE-BLOCK-START
"""Hybrid best-fit: tightest residual, with a tiebreak toward fuller bins and
residuals just below common small item sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Primary key: tightest residual (best fit).  Smaller residual => better.
    # Secondary key: among near-equal fits, prefer leaving a residual that is
    # just below a small item size, so the leftover still fits small items.
    # Use a small fractional penalty so the primary term dominates.
    # Penalize residuals that sit in a "dead zone" (too small for a common
    # item but larger than 0): map residual through a gentle cost.
    # Cost is bounded in [0,1] and only used as a fine tiebreak.
    r = residual.astype(np.float64)
    # dead-zone penalty: residuals in (0, ~10) waste space unlikely to be reused
    dead = np.where((r > 0) & (r < 10), 1.0 - r / 10.0, 0.0)
    # prefer fuller bins on exact ties: smaller pre-placement capacity is better
    fuller = bins.astype(np.float64) / 100.0  # 0 for nearly full, 1 for empty

    return -(residual.astype(np.float64)) - 0.001 * dead - 0.0005 * fuller
# EVOLVE-BLOCK-END
