# EVOLVE-BLOCK-START
"""Best fit with a light stateful residual-quality nudge."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Primary: best fit (smallest residual is best -> most negative).
    base = -residual.astype(np.float64)

    # Stateful nudge: encourage residuals that are at least ~mean but not too large.
    # Use a global running mean kept on the function object.
    s = getattr(priority, "_sum", 0.0) + item
    n = getattr(priority, "_n", 0) + 1
    priority._sum = s
    priority._n = n
    mean = s / n

    # Continuous penalty for residuals far from a "useful" zone.
    # We prefer residual around mean (can absorb a typical item soon) but
    # still heavily favor small residuals via the base term.
    # Scale is small so best-fit remains dominant.
    target = mean
    nudge = -0.02 * np.abs(residual.astype(np.float64) - target)

    return base + nudge
# EVOLVE-BLOCK-END
