# EVOLVE-BLOCK-START
"""Distribution-aware best fit: score each placement by how close the leftover lands to a
typical *small* future item (so the bin can still be reused productively), with a strong
seal bonus for near-exact fills and for residuals matching common item sizes. Uses a running
estimate of item sizes to decide which residuals are genuinely useful rather than wasted
slivers."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "small_hist": np.zeros(101, dtype=np.float64),
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0,
          "full_hist": np.zeros(101, dtype=np.float64),
          "mode_cache": None, "mode_when": -1}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["small_hist"][item] += 1
    st["full_hist"][item] += 1

    # Rolling window of recent items for a local small-quantile estimate.
    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    # Estimate a typical "small but common" item size as the ~35th percentile of recent items.
    if st["filled"] >= 32:
        window = r[:st["filled"]]
        q = np.percentile(window, 35)
    else:
        q = 0.5 * item

    mean = st["sum"] / st["n"]
    target = max(q, 1.0)

    residual = bins - item

    # Base: prefer residuals near the small-item target (usable leftovers).
    score = -np.abs(residual - target)

    # Reuse signal: residuals matching frequent item sizes are likely to be consumed by a
    # single future item. Recompute the prototype set only occasionally (it changes slowly).
    total = float(st["n"])
    if st["mode_when"] != st["n"] // 64 or st["mode_cache"] is None:
        frac = st["full_hist"] / total
        kern = np.array([0.25, 0.5, 0.25])
        smoothed = np.convolve(frac, kern, mode="same")
        st["mode_cache"] = smoothed
        st["mode_when"] = st["n"] // 64
    smoothed = st["mode_cache"]

    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse_val = smoothed[rr] * in_range

    # Local peak of the smoothed histogram at the residual value: distinguishes "on a mode"
    # from simply "near mass".
    peak = np.zeros_like(residual, dtype=np.float64)
    if in_range.any():
        idx = rr[in_range]
        lo = np.maximum(idx - 1, 0)
        hi = np.minimum(idx + 1, 100)
        is_peak = (smoothed[idx] >= smoothed[lo]) & (smoothed[idx] >= smoothed[hi])
        peak[in_range] = is_peak.astype(np.float64)

    # Anti-sliver: penalty grows continuously as the residual falls below the usable target,
    # but residuals that sit exactly on a common item size are useful and escape the penalty.
    sliver = np.clip(target - residual, 0.0, None)
    protected = reuse_val > 1.5e-3
    sliver = np.where(protected, 0.0, sliver)
    score = score - 0.4 * sliver

    # Slight preference against very large residuals (keeps bins concentrated / best-fit-like).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Seal: strong monotone preference toward exact fill. Residual 0 strictly dominates.
    score = score + 50.0 * np.clip(3.0 - residual, 0.0, None)
    score = np.where(residual == 0, score + 100000.0, score)

    score = score + 8.0 * reuse_val
    score = score + 2.0 * peak

    return score
# EVOLVE-BLOCK-END
