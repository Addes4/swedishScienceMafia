# EVOLVE-BLOCK-START
"""Best fit with a tiny bias against opening fresh bins on near-ties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize residual (best fit). Secondary tie-break: prefer non-fresh bins
    # by penalizing larger remaining capacity very slightly, so that on equal residual
    # a used bin beats a fresh bin, and among fresh bins the first is still chosen.
    return -(residual) - 1e-6 * bins
# EVOLVE-BLOCK-END
