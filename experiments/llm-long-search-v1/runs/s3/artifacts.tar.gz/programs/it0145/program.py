# EVOLVE-BLOCK-START
"""Best-fit with a learned small-item refill bonus.

Large items use plain best-fit (tightest residual). Small items are steered,
among the tightest candidates, to bins whose resulting residual matches a
frequent recent item size, making those bins exactly refillable soon.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)   # recent item-size histogram
_TOTAL = 0.0


def priority(item, bins):
    global _HIST, _TOTAL

    # Update running histogram with the arriving item's size (before scoring).
    _HIST[item] += 1.0
    _TOTAL += 1.0

    # Resulting residual if the item goes into each bin.
    res = bins - item  # >= 0 for all bins shown

    if item >= 34:
        # Large items: pure best-fit (minimize resulting residual).
        return -res

    # Small items: among bins whose resulting residual is small (tight fit),
    # prefer bins whose residual is likely refillable by a frequent item size.
    order = np.argsort(res, kind="stable")  # tightest first
    n = len(res)
    k = max(1, n // 8)  # consider the tightest eighth of bins
    candidates = order[:k]

    # Frequency-weighted "matchability" of a residual r: sum of recent
    # histogram mass at sizes <= r that can plausibly fill it.
    # Score = -res (primary tier) with a sub-unit bonus for matchable residuals.
    best = None
    best_key = None
    for idx in candidates:
        r = int(res[idx])
        # bonus in [0,1): higher for residuals near frequent sizes
        bonus = 0.0
        if r >= 1:
            # mass of a single recent size equal to r
            bonus = _HIST[r] / (_TOTAL + 1.0)
            if bonus > 1.0:
                bonus = 1.0
        # combine: primary is -r, bonus strictly sub-unit so it only breaks
        # ties (or near-ties) within the tightest group
        key = -(r) + bonus
        if best_key is None or key > best_key:
            best_key = key
            best = idx

    # Assign score = -(resulting residual) so min-res wins, plus tiny bonus
    out = -res.astype(np.float64)
    if best is not None:
        out[best] += 1.0  # exact tie-break bonus for chosen candidate
    return out
# EVOLVE-BLOCK-END
