# EVOLVE-BLOCK-START
"""Best fit with a residual-usefulness bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item
    # Dominant term: prefer smallest residual (best fit).
    # Tiny bonus: prefer residuals that leave a gap near a "typical" size so the
    # gap can later be filled by another item rather than wasted.
    # Use a fixed, order-free heuristic: gaps that are exactly 0 are best; then
    # gaps that are multiples of 10 (common quantized sizes) are slightly favored.
    bonus = (resid % 10 == 0).astype(np.float64) * 1e-3
    # Also slightly favor leaving a zero gap (perfect fill).
    bonus += (resid == 0).astype(np.float64) * 1e-3
    return -resid + bonus
# EVOLVE-BLOCK-END

