# EVOLVE-BLOCK-START
"""Reserve-aware best fit with data-driven reusable-gap threshold.

Idea: exact/near-exact fills should "seal" a bin, but for all other placements the
quality of a leftover should be judged by whether it can still hold a reasonably
sized future item, not by a fixed constant. We track a running estimate of the
typical small-item size actually seen, and reward leftovers near that value or
clearly below it (unusable sliver) accordingly.
"""
import numpy as np

_state = {"n": 0, "small": 0, "small_sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    if item <= 10:
        _state["small"] += 1
        _state["small_sum"] += item

    residual = bins - item

    # Estimate a typical "small filler" size; default to a modest 10 until we have data.
    if _state["small"] > 0:
        small_mean = _state["small_sum"] / _state["small"]
    else:
        small_mean = 10.0
    small_mean = min(max(small_mean, 4.0), 14.0)

    # Preferred leftover: about half the typical small filler, so a typical next
    # small item can slot in and we avoid leaving unusable slivers.
    target = 0.5 * small_mean

    score = -np.abs(residual - target)

    # Penalize leaving a sliver smaller than a typical small item can use, but only
    # when the arriving item isn't itself small (small items naturally consume gaps).
    if item > 10:
        sliver = small_mean
        score = np.where((residual > 0) & (residual < sliver), score - 5.0, score)

    # Strongly reward placements that leave a very small residual: these effectively
    # seal a bin and stop it accumulating unusable slivers of capacity.
    score = np.where(residual <= 2, 1000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END
