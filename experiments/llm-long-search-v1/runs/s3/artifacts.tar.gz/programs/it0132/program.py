# EVOLVE-BLOCK-START
"""Best fit with a harmonic-style tie-break using a running item-size histogram."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_CLASSES = np.array([5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 60, 70, 80, 90, 100],
                    dtype=np.float64)
_LAST_TARGET = 40.0


def priority(item, bins):
    global _TOTAL, _LAST_TARGET
    # Update running histogram of seen item sizes (decayed).
    if _TOTAL > 0.0:
        _HIST *= 0.999
    _HIST[item] += 1.0
    _TOTAL += 1.0

    # Estimate the typical residual that future items can fill: pick the
    # size class with the largest probability mass.
    idx = int(np.argmax(_HIST[_CLASSES.astype(np.int64)]))
    target = _CLASSES[idx]
    _LAST_TARGET = target

    residual = bins - item  # resulting residual per bin
    score = -residual.astype(np.float64)
    # Tiny bonus: prefer resulting residuals close to the typical item class.
    score += 1e-3 * (np.abs(residual - target) < 0.5)
    return score
# EVOLVE-BLOCK-END
