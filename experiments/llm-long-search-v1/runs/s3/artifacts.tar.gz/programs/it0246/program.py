# EVOLVE-BLOCK-START
"""Calibrated waste model: for each candidate bin, estimate the expected wasted capacity
over a short future horizon using the running histogram of item sizes. Placing an item to
leave a residual that is likely to be *filled snugly* by upcoming items is rewarded; leaving
a residual that future items will only partly use is penalized. Exact fills get a strong seal.
This optimizes the true objective (bins used) instead of a residual-target proxy."""

import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),   # decayed full-history counts of item sizes
    "n": 0.0,
    "recent": np.zeros(512, dtype=np.int64),
    "filled": 0,
    "ptr": 0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: remaining capacities (int64) of bins the item fits in, including empty bins (100).
    """
    st = _state
    st["n"] += 1.0
    st["hist"] *= 0.999
    st["hist"][item] += 1.0

    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    residual = bins - item
    resid0 = np.where(residual == 0, 1.0, 0.0)

    # Use recent window to estimate the distribution of *near-future* items.
    if st["filled"] >= 64:
        win = r[:st["filled"]]
        counts = np.bincount(win, minlength=101).astype(np.float64)
        w = counts / counts.sum()
    else:
        h = st["hist"]
        w = h / max(h.sum(), 1.0)

    # Expected waste for a residual s given future single-item sizes:
    # the leftover after filling with one item j is s-j; small leftovers are pure waste.
    # Approximate expected wasted capacity as E[ min(s, |? ) ]... simpler: estimate how
    # much of s is *unfillable*, using the fact that an item fills s well if s-j is small.
    # We approximate: waste(s) = E_j[ s - j ] over j<=s  (the unfilled part), 0 if s fits none.
    sizes = np.arange(101)
    wsum = w
    # cumulative probability that a future item <= s and the exact match mass
    cdf = np.concatenate([[0.0], np.cumsum(wsum[1:])])  # cdf[s] = P(size <= s)
    exact = wsum

    # For each bin residual s, expected waste = E over j of max(s - j, 0) weighted by w_j
    # = sum_{j<=s} (s-j) w_j  = s*cdf[s] - sum_{j<=s} j w_j
    jw = sizes * wsum
    cum_jw = np.concatenate([[0.0], np.cumsum(jw[1:])])
    ss = np.clip(residual, 0, 100).astype(np.int64)
    cdf_s = cdf[ss]
    cumjw_s = cum_jw[ss]
    exp_waste = ss * cdf_s - cumjw_s  # expected leftover after best single next item (approx)

    # Reward = negative expected waste (want small waste). Plus a bonus for exact residual
    # matching a frequent item size (can be filled perfectly soon).
    score = -exp_waste

    # Bonus when residual exactly equals a likely future item size (snug single-item fill).
    freq_resid = exact[ss]
    score = score + 6.0 * freq_resid

    # Strong seal on exact fill.
    score = score + 1000.0 * resid0

    return score
# EVOLVE-BLOCK-END
