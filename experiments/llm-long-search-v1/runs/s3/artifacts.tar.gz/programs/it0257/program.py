# EVOLVE-BLOCK-START
"""Distribution-aware best fit: score each placement by how close the leftover lands to a
typical *small* future item (so the bin can still be reused productively), with a strong
seal bonus for near-exact fills and for residuals matching common item sizes. Uses a stable,
whole-history estimate of item sizes to decide which residuals are genuinely useful rather
than wasted slivers."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "full_hist": np.zeros(101, dtype=np.float64),
          "sorted_cache": None, "cache_n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["full_hist"][item] += 1

    mean = st["sum"] / st["n"]

    # Stable whole-history low quantile: recompute the sorted support only occasionally.
    total = float(st["n"])
    if st["sorted_cache"] is None or st["n"] - st["cache_n"] >= 250:
        hist = st["full_hist"]
        support = np.nonzero(hist)[0]
        counts = hist[support]
        # Expand a downsampled view for quantile estimation (cap work).
        reps = np.maximum((counts / max(total, 1.0) * 2000).astype(np.int64), 1)
        expanded = np.repeat(support, reps)
        if expanded.size >= 16:
            q = float(np.percentile(expanded, 35))
        else:
            q = 0.5 * item
        st["sorted_cache"] = q
        st["cache_n"] = st["n"]
    else:
        q = st["sorted_cache"]

    if q <= 0:
        q = 0.5 * item
    target = max(q, 1.0)

    residual = bins - item

    # Base: prefer residuals near the small-item target (usable leftovers).
    score = -np.abs(residual - target)

    # Anti-sliver: penalty grows continuously as the residual falls below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.4 * sliver

    # Slight preference against very large residuals (keeps bins concentrated / best-fit-like).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Seal: strong monotone preference toward exact fill. Residual 0 strictly dominates.
    score = score + 50.0 * np.clip(3.0 - residual, 0.0, None)
    score = np.where(residual == 0, score + 100000.0, score)

    # Reusability bonus: reward residuals whose value sits on / near a frequently-seen item
    # size in the FULL running history, smoothed over a small window so the signal is stable.
    frac = st["full_hist"] / total
    kern = np.array([0.25, 0.5, 0.25])
    smoothed = np.convolve(frac, kern, mode="same")
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse = smoothed[rr] * in_range
    score = score + 8.0 * reuse

    return score
# EVOLVE-BLOCK-END
