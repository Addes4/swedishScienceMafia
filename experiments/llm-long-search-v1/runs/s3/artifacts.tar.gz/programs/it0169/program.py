# EVOLVE-BLOCK-START
"""Best fit with a small tie-break nudging toward residuals that leave a mean-sized hole."""
import numpy as np


def priority(item, bins):
    """Rank bins: tightest fit first, with a tiny bonus for leaving a useful residual.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of all fitting bins, in bin order.
    """
    residual = bins - item
    # Prefer tight fit broadly; among similar residual, slightly favor a residual that
    # leaves a gap no larger than needed for another item (avoids over-fragmenting).
    score = -residual.astype(np.float64)
    # tiny bonus for the very tightest fits (residual 0) so perfect fits are preferred
    score += 1e-6 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
