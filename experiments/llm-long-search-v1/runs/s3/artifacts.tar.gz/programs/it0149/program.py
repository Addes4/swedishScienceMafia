# EVOLVE-BLOCK-START
"""Best fit with a tiny stateful bonus for residues matching likely future item sizes."""
import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),
    "count": 0.0,
    "last_item": 0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update histogram of observed item sizes (bounded influence via decay).
    hist = _state["hist"]
    hist *= 0.999
    hist[item] += 1.0
    _state["count"] = _state["count"] * 0.999 + 1.0

    # Base: best fit (minimize residual), so primary ordering is exact best-fit.
    residual = bins - item  # >= 0 for shown bins

    # Compute a small, strictly sub-unit bonus that prefers residues likely to be
    # exactly refillable by a common future item size. Normalized to [0, 0.5).
    total = hist.sum()
    if total > 0:
        prob = hist / total
    else:
        prob = hist

    # For each bin, the resulting residual r (0..100). Score = -r + eps * p(r).
    # Since p <= 1 and eps = 0.49, bonus stays in [0, 0.49), never flipping a
    # strict best-fit ordering (differences in r are integers >= 1).
    eps = 0.49
    ridx = np.clip(residual, 0, 100).astype(np.int64)
    bonus = prob[ridx]

    return -(residual.astype(np.float64)) + eps * bonus
# EVOLVE-BLOCK-END
