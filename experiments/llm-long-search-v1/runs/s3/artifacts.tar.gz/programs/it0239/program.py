# EVOLVE-BLOCK-START
"""Distribution-aware best fit: score each placement by how close the leftover lands to a
typical *small* future item (so the bin can still be reused productively), with a strong
seal bonus for near-exact fills and for residuals matching common item sizes. Uses a running
estimate of item sizes to decide which residuals are genuinely useful rather than wasted
slivers. Adds graded credit for residuals matching the top few common recent small sizes."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "small_hist": np.zeros(101, dtype=np.float64),
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["small_hist"][item] += 1

    # Rolling window of recent items for a local small-quantile estimate.
    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    # Estimate a typical "small but common" item size as the ~35th percentile of recent items.
    if st["filled"] >= 32:
        window = r[:st["filled"]]
        q = np.percentile(window, 35)
        # Most common small item size in the window (mode of the lower half).
        counts = np.bincount(window, minlength=101)
        small_counts = counts.copy()
        small_counts[int(q) + 1:] = 0
        mode_small = int(np.argmax(small_counts))
    else:
        q = 0.5 * item
        mode_small = int(round(q))

    mean = st["sum"] / st["n"]
    # Useful residual target: something a small item can still fill well.
    target = max(q, 1.0)

    residual = bins - item

    # Base: prefer residuals near the small-item target (usable leftovers).
    score = -np.abs(residual - target)

    # Anti-sliver: penalty grows continuously as the residual falls below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.4 * sliver

    # Slight preference against very large residuals (keeps bins concentrated / best-fit-like).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Seal bonus: strongly prefer placements that leave a near-exact fill, and give an
    # extra nudge when the residual matches the most common recent small item size.
    score = np.where(residual <= 3, 1000.0 - residual, score)
    if mode_small > 0:
        score = np.where(residual == mode_small, score + 5.0, score)

    # Reusability bonus: reward residuals that exactly match a commonly-seen item size,
    # since such a leftover can be tightly filled later. Additionally give graded credit
    # to residuals that match any of the top few most common recent small sizes.
    if st["filled"] >= 32:
        window = r[:st["filled"]]
        total = float(st["filled"])
        win_counts = np.bincount(window, minlength=101).astype(np.float64)
        frac = win_counts / total
        in_range = (residual >= 0) & (residual <= 100)
        rr = np.where(in_range, residual, 0).astype(np.int64)
        score = score + 8.0 * frac[rr] * in_range

        # Graded credit for the top few common small sizes (distinct from the exact-match term).
        # Consider only sizes <= target+2 to keep the focus on reusable leftovers.
        small_mask = np.zeros(101, dtype=bool)
        limit = int(target) + 2
        if limit >= 1:
            small_mask[1:min(limit, 100) + 1] = True
        cand = win_counts * small_mask
        if cand.sum() > 0:
            top_idx = np.argpartition(cand, -4)[-4:]
            # Emphasize the top sizes proportionally by their counts.
            for sz in top_idx:
                if sz > 0 and win_counts[sz] > 0:
                    w = 2.0 * (win_counts[sz] / total)
                    score = np.where(residual == sz, score + w, score)

    return score
# EVOLVE-BLOCK-END
