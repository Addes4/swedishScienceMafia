# EVOLVE-BLOCK-START
"""Distribution-aware best fit: score each placement by how reusable its leftover is.

Maintains a running histogram of item sizes. For each candidate bin, the leftover residual
is evaluated by the empirical probability that a future item fits in it and by how tightly
it tends to be filled -- this approximates the expected usefulness of the residual rather
than comparing to one fixed target. A strong seal bonus still rewards near-exact fills.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0, "hist": np.zeros(101, dtype=np.float64),
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["hist"][item] += 1

    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    residual = bins - item

    # Empirical size distribution (recent window preferred once warm, else global).
    if st["filled"] >= 64:
        counts = np.bincount(r[:st["filled"]], minlength=101).astype(np.float64)
    else:
        counts = st["hist"]
    total = counts.sum()
    if total <= 0:
        return -np.abs(residual - 1.0)
    probs = counts / total

    # Empirical CDF for "does an item fit in residual".
    cdf = np.cumsum(probs)
    # Probability a future item fits in the residual (cap index at 100).
    idx = np.clip(residual, 0, 100).astype(np.int64)
    fit_prob = cdf[idx]

    # For residuals that fit at least one common item, estimate the expected amount the
    # residual will absorb: average over items that fit, of min(item, residual).
    sizes = np.arange(101, dtype=np.float64)
    # weighted average fill for each residual value
    # fill_avg(res) = sum_{s<=res} p(s)*s / sum_{s<=res} p(s)
    wsum = np.cumsum(probs * sizes)      # cumulative sum of p(s)*s up to index
    csum = cdf
    fill_avg = np.zeros(101, dtype=np.float64)
    nz = csum > 0
    fill_avg[nz] = wsum[nz] / csum[nz]

    avg_fill = fill_avg[idx]             # expected size of the item that consumes residual

    # Value of the residual: it should be usable (fit_prob high) and consumed well
    # (avg_fill close to residual means good match). We reward a high fill ratio when
    # the residual can be reused, penalizing residuals that usually stay as slivers.
    with np.errstate(divide="ignore", invalid="ignore"):
        fill_ratio = np.where(residual > 0, avg_fill / np.maximum(residual, 1.0), 0.0)
    usefulness = fit_prob * (0.5 + 0.5 * fill_ratio)

    # Base score: prefer tight leftover (best-fit) plus a bonus for reusable residuals.
    score = -residual + 40.0 * usefulness

    # Anti-sliver: residuals too small to fit a typical item are mildly devalued.
    score = score - 8.0 * np.clip(1.0 - fit_prob, 0.0, 1.0) * np.clip(3.0 - residual, 0.0, None) / 3.0

    # Seal bonus: strongly prefer placements that leave a near-exact fill.
    score = np.where(residual <= 2, 1000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END

