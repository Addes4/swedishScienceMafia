# EVOLVE-BLOCK-START
"""Hybrid best-fit packing with distribution-aware reuse bonuses.

Base choice is best-fit (smaller residual is better), which is the strongest known online
heuristic for this item-size distribution. To avoid the classic best-fit failure of leaving
unusable slivers, we add:
  * a mild sliver penalty for residuals that are too small to be usefully refilled,
  * a seal bonus for near-exact fills,
  * a reuse bonus that rewards residuals equal to a commonly-seen item size,
so tight fits are preferred but productive leftovers are valued.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0, "freq": np.zeros(101, dtype=np.float64),
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["freq"][item] += 1.0

    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    mean = st["sum"] / st["n"]

    # Useful-residual target: a typical small item the leftover bin could still hold well.
    if st["filled"] >= 32:
        win = r[:st["filled"]]
        target = float(np.percentile(win, 30))
        if target < 1.0:
            target = 1.0
    else:
        target = max(0.3 * mean, 1.0)

    residual = bins - item

    # Best-fit base: strictly prefer smaller residual (tighter fit).
    score = -residual.astype(np.float64)

    # Sliver penalty: gently discourage residuals below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.35 * sliver

    # Slight preference against very large residuals (keeps bins concentrated).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Seal bonus: strongly prefer near-exact fills.
    score = np.where(residual <= 3, 1000.0 - residual, score)

    # Reuse bonus: reward residuals that exactly match a commonly-seen item size so the
    # leftover bin can be tightly filled later.
    frac = st["freq"] / max(st["n"], 1)
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    score = score + 8.0 * frac[rr] * in_range

    return score
# EVOLVE-BLOCK-END

