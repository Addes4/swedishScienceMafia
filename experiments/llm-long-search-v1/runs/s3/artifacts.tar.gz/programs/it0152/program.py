# EVOLVE-BLOCK-START
"""Hybrid best-fit / residual-preserving rule using a running item-size estimate."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Running mean estimate stored on the function object.
    mean = getattr(priority, "mean", None)
    if mean is None:
        mean = 40.0
    else:
        # Exponentially weighted average, slow adaptation.
        mean = 0.999 * mean + 0.001 * item
    priority.mean = mean

    residual = bins - item  # new remaining capacity if placed here

    # Best-fit score: prefer smallest residual.
    base = -residual.astype(np.float64)

    # For small items, avoid stuffing them into bins that have little
    # residual left in a way that "wastes" a nearly-full bin. Give a tiny
    # bonus to bins whose residual after placement is >= mean (can still
    # accept a typical item) but not already huge, encouraging consolidation
    # of small items.
    if item <= 0.5 * mean:
        can_fit_typical = residual >= mean
        # small extra preference; kept strictly below 1.0 so it only breaks ties
        bonus = np.where(can_fit_typical, 0.5, 0.0)
        base = base + bonus

    return base
# EVOLVE-BLOCK-END
