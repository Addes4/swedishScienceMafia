# EVOLVE-BLOCK-START
"""Distribution-aware best fit with a stable, exponentially-updated estimate of a useful
"small residual" target. Instead of recomputing a noisy percentile/mode every call, we
maintain an EMA of small (below-median) item sizes, which gives a stable sense of what
leftover is genuinely reusable. Combines a near-exact seal bonus, a reuse bonus for
residuals matching common item sizes, and a smooth sliver penalty."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "small_hist": np.zeros(101, dtype=np.float64),
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0,
          "small_ema": 0.0, "small_seen": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["small_hist"][item] += 1

    # Rolling window of recent items.
    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    mean = st["sum"] / st["n"]

    # Stable, exponentially-updated estimate of a typical small item size.
    if item < mean:
        if st["small_seen"] == 0:
            st["small_ema"] = float(item)
        else:
            st["small_ema"] = 0.95 * st["small_ema"] + 0.05 * item
        st["small_seen"] += 1

    if st["small_seen"] >= 8:
        target = max(st["small_ema"], 1.0)
    else:
        target = max(0.5 * mean, 1.0)

    residual = bins - item

    # Base: prefer residuals near the useful small-item target.
    score = -np.abs(residual - target)

    # Smooth, monotone anti-sliver penalty below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.4 * sliver

    # Mild preference against very large residuals (keeps bins concentrated).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Near-exact seal bonus (graded, exact fill most rewarded).
    score = np.where(residual <= 3, 1000.0 - 3.0 * residual, score)

    # Reuse bonus: reward residuals matching commonly-seen item sizes.
    if st["filled"] >= 32:
        total = float(st["filled"])
        win_counts = np.bincount(r[:st["filled"]], minlength=101).astype(np.float64)
        frac = win_counts / total
        mode_small = int(np.argmax(frac[:max(int(target) + 1, 1)])) if target >= 1 else 0
        in_range = (residual >= 0) & (residual <= 100)
        rr = np.where(in_range, residual, 0).astype(np.int64)
        score = score + 8.0 * frac[rr] * in_range
        if mode_small > 0:
            score = np.where(residual == mode_small, score + 5.0, score)

    return score
# EVOLVE-BLOCK-END
