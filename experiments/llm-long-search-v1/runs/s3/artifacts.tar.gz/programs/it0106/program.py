# EVOLVE-BLOCK-START
"""Hybrid rule: best fit normally, but for large items avoid tiny unusable residuals.

The item goes into the bin with the highest score; ties go to the first such bin.
"""
import numpy as np

# Running statistics of observed item sizes (across calls).
_hist = np.zeros(101, dtype=np.float64)   # histogram of item sizes 1..100
_count = 0
_last = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _count, _last

    # Update running histogram of observed items.
    if 1 <= item <= 100:
        _hist[item] += 1.0
        _count += 1
    _last = item

    # Residual remaining if placed in each bin.
    residual = bins - item  # bins already only contains fitting bins, so residual >= 0

    # Estimate a "common residual" threshold from observed small-item mass.
    # Use a moderate quantile of observed item sizes as the fillable-size threshold.
    if _count >= 5:
        cum = np.cumsum(_hist)
        total = cum[100]
        # threshold = size below which 25% of items fall (a plausible future fill size)
        idx = np.searchsorted(cum, 0.25 * total)
        thr = int(idx) + 1
        if thr < 1:
            thr = 1
        if thr > 100:
            thr = 100
    else:
        thr = 20

    # Tightness: prefer small residual (classic best fit).
    tight = -residual.astype(np.float64)

    if item >= 30:
        # For larger items, penalize residuals that are positive but below the
        # threshold (likely to become unusable dead space), and reward exact fits
        # and residuals at/above the threshold.
        exact = (residual == 0).astype(np.float64)
        dead = ((residual > 0) & (residual < thr)).astype(np.float64)
        score = tight + 0.6 * exact - 0.6 * dead
    else:
        score = tight

    return score
# EVOLVE-BLOCK-END
