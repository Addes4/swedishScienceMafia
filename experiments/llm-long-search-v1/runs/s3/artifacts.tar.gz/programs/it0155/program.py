# EVOLVE-BLOCK-START
"""Bounded best fit: tightest fit, but among near-ties prefer the fuller bin's residual spread."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties).

    Ties near the minimal residual are broken toward the bin with more remaining capacity
    before placement, which tends to clear large holes.
    """
    residual = bins - item
    mn = residual.min()
    tol = 3
    is_tight = residual <= mn + tol
    # best-fit dominates: negative residual, plus a bounded bonus for near-tight large bins
    score = -residual.astype(np.float64)
    score += is_tight.astype(np.float64) * (bins.astype(np.float64) * 1e-3)
    return score
# EVOLVE-BLOCK-END
