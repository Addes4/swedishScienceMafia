# EVOLVE-BLOCK-START
"""Best fit with a soft lower bound on the residual left behind."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best-fit is the dominant key: smaller residual (post placement) is better.
    # Add a tiny penalty when the residual is positive but very small, since such
    # bins become hard to reuse. Penalty is scaled below one residual unit so it
    # only breaks ties / near-ties.
    small = (residual > 0) & (residual < 25)
    penalty = small.astype(np.float64) * 0.5
    return -(residual.astype(np.float64) + penalty)
# EVOLVE-BLOCK-END
