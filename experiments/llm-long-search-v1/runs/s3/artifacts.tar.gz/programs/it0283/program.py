# EVOLVE-BLOCK-START
"""Distribution-aware best fit: prefer placements that either nearly seal the bin or leave a
leftover matching a common upcoming item size, so the bin stays reusable. Uses a running
lifetime estimate of the item distribution plus a complement-pairing term that rewards
residuals equal to the sum of the two most common small item sizes (the dominant closing
pattern for a Weibull-shaped size distribution)."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "hist": np.zeros(101, dtype=np.float64),
          "small_hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["hist"][item] += 1

    mean_all = st["sum"] / st["n"]

    residual = bins - item

    # Base best-fit gradient: gently prefer smaller usable leftovers.
    score = -0.08 * residual

    # Seal: strong monotone preference toward exact fill; residual 0 dominates.
    score = score + 2.0 * np.clip(4.0 - residual, 0.0, None)
    score = np.where(residual == 0, score + 100000.0, score)

    # Reusability target: leftover close to a typical item size keeps the bin productive.
    target = max(mean_all, 1.0)
    score = score - 0.6 * np.abs(residual - target)

    # Anti-sliver: continuous penalty as residual falls below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.5 * sliver

    # Reusability bonus from a lifetime histogram, smoothed for stability.
    total = float(max(st["n"], 1))
    frac = st["hist"] / total
    kern = np.array([0.15, 0.7, 0.15])
    smoothed = np.convolve(frac, kern, mode="same")
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse = smoothed[rr] * in_range
    score = score + 18.0 * reuse

    # Complement pairing: reward residuals equal to the sum of two frequent small sizes,
    # the dominant way a bin gets closed in this distribution.
    if st["n"] >= 64:
        small = np.where(st["hist"] > 0, st["hist"], 0.0)
        small = small / total
        small[:8] = 0.0  # ignore the tiniest items for pairing realism
        top = np.argsort(small)[-6:]
        pair_mass = np.zeros(201, dtype=np.float64)
        for a in top:
            pair_mass[a:a + 101] += small[a] * small
        rp = np.where((residual >= 0) & (residual <= 200), residual, 0).astype(np.int64)
        pair = pair_mass[rp] * ((residual >= 0) & (residual <= 200))
        score = score + 6.0 * pair

    # Fine tiebreaker: residual exactly equal to a frequent item size.
    peak = frac[rr] * in_range
    score = score + 4.0 * peak

    return score
# EVOLVE-BLOCK-END
