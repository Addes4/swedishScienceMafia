# EVOLVE-BLOCK-START
"""Harmonic-style bucketed best-fit: round the item up to a size class before
computing the residual, so bins are packed into class-aligned residuals and
future items of the same class tend to fit exactly."""
import numpy as np

# size classes (upper bounds); item is rounded up to its class
_BOUNDS = np.array([10, 20, 30, 40, 50, 60, 70, 80, 90, 100], dtype=np.int64)


def _class_size(item):
    # smallest bound >= item
    return int(_BOUNDS[np.searchsorted(_BOUNDS, item)])


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    # Best-fit on the true item size as primary key (negated residual).
    primary = -(bins - item)

    # Sub-unit bonus: prefer residuals that are exact multiples of the item's
    # size class, i.e. bins whose new residual is still "harmonically aligned".
    cs = _class_size(item)
    new_res = bins - item
    aligned = (new_res % cs) == 0
    # Bonus is < 1 so it never changes the best-fit ordering except among
    # residuals differing by < 1 (i.e. ties only). This keeps us safe.
    bonus = aligned.astype(np.float64) * 0.5

    return primary.astype(np.float64) + bonus
# EVOLVE-BLOCK-END
