# EVOLVE-BLOCK-START
"""Best fit plus a tiny residual-quality tie-break."""
import numpy as np


_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    # Track a running mean of item sizes (cheap, stateful).
    _state["sum"] += item
    _state["n"] += 1

    residual = bins - item  # numpy int64 array

    # Best-fit score: larger for smaller residual.
    score = -residual.astype(np.float64)

    # Tiny tie-break: prefer residuals that are near the running mean
    # (a good "hole" size for future typical items), and mildly prefer
    # leaving a smaller hole than a larger one beyond pure best fit.
    mu = _state["sum"] / _state["n"]
    quality = -np.abs(residual - mu) * 1e-6
    score = score + quality

    return score
# EVOLVE-BLOCK-END
