# EVOLVE-BLOCK-START
"""Best fit with a mild age/consolidation tie-break."""
import numpy as np

_state = {"counts": None}


def priority(item, bins):
    n = len(bins)
    counts = _state["counts"]
    if counts is None or len(counts) != n:
        counts = np.zeros(n, dtype=np.float64)
        _state["counts"] = counts

    residual = bins - item
    # Primary: best fit (largest score = smallest residual). Residual is integer 0..99,
    # so scale it up so the tie-break term can only break exact ties.
    score = -(residual.astype(np.float64)) * 1000.0

    # Tie-break: prefer bins already used more (consolidate) -> smaller count favored.
    score -= counts

    best = int(np.argmax(score))
    counts[best] += 1.0

    # Reset stale counts occasionally to avoid unbounded growth (kept tiny).
    if counts[best] > 1e6:
        counts *= 1e-3

    return score
# EVOLVE-BLOCK-END

