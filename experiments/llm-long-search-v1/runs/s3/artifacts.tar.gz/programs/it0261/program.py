# EVOLVE-BLOCK-START
"""Distribution-aware best fit: place each item into the fullest bin it fits in (strong
best-fit gradient), with a firm anti-sliver reserve so tiny unusable leftovers are avoided,
and a strong monotone seal toward exact fills. A running item histogram mildly rewards
residuals that match a common future item size."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "full_hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["full_hist"][item] += 1

    residual = bins - item

    # Base: strong best-fit gradient -- prefer the fullest fitting bin (smallest non-negative
    # residual), which concentrates items and tends to reduce bin count.
    score = -2.0 * np.clip(residual, 0.0, None)

    # Anti-sliver: penalize residuals that are too small to be useful for a future item.
    target = 8.0
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.6 * sliver

    # Seal: strong monotone preference toward exact fill.
    score = score + 50.0 * np.clip(4.0 - residual, 0.0, None)
    score = np.where(residual == 0, score + 1e9, score)

    # Reusability: mildly reward residuals whose value is a common item size.
    total = float(st["n"])
    frac = st["full_hist"] / total
    kern = np.array([0.25, 0.5, 0.25])
    smoothed = np.convolve(frac, kern, mode="same")
    in_range = (residual >= 1) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse = smoothed[rr] * in_range
    score = score + 4.0 * reuse

    return score
# EVOLVE-BLOCK-END
