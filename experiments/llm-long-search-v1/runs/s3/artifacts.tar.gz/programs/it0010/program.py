# EVOLVE-BLOCK-START
"""Best fit with a light, self-adapting residual-usability bonus.

Primary rule: best fit (tightest remaining capacity after placement, i.e. most
negative residual).  Secondary rule: a small bonus when the residual capacity
left in a bin matches a size that has recently been seen as an item, so that
leftover space is likely to be reusable by future items.
"""
import numpy as np

# Rolling statistics of recently seen items. Kept as a simple frequency tally
# over the 1..100 size range so it can be maintained cheaply across calls.
_recent = np.zeros(101, dtype=np.float64)
_seen = 0.0

# Weight of the residual-usability bonus relative to the best-fit term.
_BONUS = 0.15


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, in bin order (unused bins have capacity 100).
    """
    global _recent, _seen

    residual = bins - item  # remaining capacity if we place the item here

    # Best-fit term: prefer the smallest residual (most negative).
    score = -residual.astype(np.float64)

    # Light bonus: reward residuals that are frequently encountered item sizes,
    # using a decayed tally of past items.  Normalized to a bounded range.
    if _seen > 0.0:
        freq = _recent[residual].copy()
        maxfreq = _recent.max()
        if maxfreq > 0.0:
            score += _BONUS * (freq / maxfreq)

    # Update the rolling tally with the current item (decay keeps it recent).
    _recent *= 0.999
    _recent[item] += 1.0
    _seen += 1.0

    return score
# EVOLVE-BLOCK-END
