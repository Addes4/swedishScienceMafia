# EVOLVE-BLOCK-START
"""Best-fit with empirical reuse: strongly prefer the smallest residual (tightest fit),
boost residuals that exactly match a commonly-seen item size so leftovers can be refilled,
and give a graded seal for near-exact fills. Maintains a stable exponentially-updated
histogram of item sizes instead of noisy per-call percentiles."""
import numpy as np

_state = {"n": 0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    # Exponentially decayed histogram: recent items weigh more, stable over time.
    st["hist"] *= 0.997
    st["hist"][item] += 1.0
    hist = st["hist"]
    total = hist.sum()

    residual = bins - item  # remaining capacity left after placing

    # Core: monotone best-fit — smaller usable residual is better.
    score = -residual.astype(np.float64)

    # Reuse bonus: residual that exactly matches a frequently-seen item size can be tightly
    # refilled later, so reward it proportionally to empirical frequency.
    if total > 0:
        in_range = (residual >= 0) & (residual <= 100)
        rr = np.where(in_range, residual, 0).astype(np.int64)
        frac = hist / total
        score = score + 60.0 * frac[rr] * in_range

    # Graded seal: reward near-exact fills, growing sharply toward an exact fill.
    score = score + np.where(residual <= 4, 500.0 - 100.0 * residual, 0.0)

    return score
# EVOLVE-BLOCK-END
