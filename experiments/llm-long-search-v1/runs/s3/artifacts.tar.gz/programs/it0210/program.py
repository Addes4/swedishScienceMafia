# EVOLVE-BLOCK-START
"""Distribution-aware best fit with cheap streaming estimates.

Instead of recomputing percentiles/histograms over a window on every call, we maintain
exponential moving estimates of (a) a typical "small but common" item size used as the
useful-residual target, and (b) the frequency of each item size for reuse weighting.
The base term blends a best-fit (tightness) preference with closeness to the target so
the rule concentrates packing while still avoiding unusable slivers; near-exact fills get
a decisive seal bonus and residuals matching common future items get a reuse bonus."""
import numpy as np

_state = {"n": 0, "sum": 0.0,
          "ema_small": 0.0,        # EMA estimate of a small-item target
          "ema_mean": 0.0,         # EMA estimate of the mean item size
          "freq": np.zeros(101, dtype=np.float64),  # decayed item-size frequencies
          "decay": 0.999}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    mean = st["sum"] / st["n"]

    # --- Cheap streaming estimates -------------------------------------------------
    # Decayed frequency of item sizes (for reuse weighting of residuals).
    st["freq"] *= st["decay"]
    st["freq"][item] += 1.0

    if st["n"] <= 4:
        st["ema_mean"] = mean
    else:
        st["ema_mean"] += 0.01 * (item - st["ema_mean"])

    # Track a small-item target: gradually track items below the running mean,
    # i.e. an estimate of a "small but common" size.
    if st["n"] <= 4:
        st["ema_small"] = 0.6 * item
    else:
        if item < st["ema_mean"]:
            st["ema_small"] += 0.05 * (item - st["ema_small"])

    target = max(st["ema_small"], 1.0)
    emean = max(st["ema_mean"], 1.0)

    residual = bins - item  # >= 0 for all shown bins

    # --- Base scoring --------------------------------------------------------------
    # Best-fit tightness: strongly prefer the smallest residual so bins get packed tight.
    score = -1.0 * residual

    # Usable-leftover shaping: gently pull residuals toward the small-item target so we
    # don't leave an unusable sliver that no future item can fill well.
    score = score - 0.6 * np.abs(residual - target)

    # Anti-sliver: penalize residuals below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.5 * sliver

    # Mild preference against huge residuals (keep packing concentrated).
    score = score - 0.05 * np.clip(residual - emean, 0.0, None)

    # --- Seal bonus: near-exact fills are decisive ---------------------------------
    score = np.where(residual <= 3, 1000.0 - residual, score)

    # --- Reuse bonus: reward residuals that exactly match common future item sizes --
    # Normalize decayed frequencies into a probability-like weight.
    freq = st["freq"]
    total = freq.sum()
    if total > 0.0:
        frac = freq / total
        in_range = (residual >= 0) & (residual <= 100)
        rr = np.where(in_range, residual, 0).astype(np.int64)
        score = score + 12.0 * frac[rr] * in_range

    return score
# EVOLVE-BLOCK-END

