# EVOLVE-BLOCK-START
"""Best fit with a mild anti-fragmentation dead-zone penalty."""
import numpy as np

# Typical item sizes for a Weibull-shaped distribution with mean ~40.
# Residuals that cannot accommodate any likely future item are wasteful; we
# mildly penalize leaving a bin in such a dead zone so fewer gaps are stranded.
_DEAD_LOW = 1
_DEAD_HIGH = 12


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (smallest residual after placement).
    score = -residual.astype(np.float64)
    # Mild penalty when the residual would be stranded in a dead zone that no
    # typical item can fill, so we slightly prefer bins leaving a useful/greater gap.
    dead = (residual >= _DEAD_LOW) & (residual < _DEAD_HIGH)
    score = score - 0.35 * dead
    return score
# EVOLVE-BLOCK-END

