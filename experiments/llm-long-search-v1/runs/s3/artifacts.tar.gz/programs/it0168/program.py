# EVOLVE-BLOCK-START
"""Best fit with exact-fit priority and an emergency-pin reserve for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: remaining capacities of fitting bins, in index order.
    """
    residual = bins - item  # capacity left after placing the item in each bin

    # Base score: prefer the tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Strong bonus for a perfect fit (residual 0): such bins should be closed now.
    score += 1000.0 * (residual == 0)

    # Among equally tight fits, prefer the bin with the larger current capacity,
    # i.e. leave fuller bins available and consolidate into less-filled ones.
    # Implemented as a tiny tie-break proportional to current residual.
    score += 1e-3 * bins.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
