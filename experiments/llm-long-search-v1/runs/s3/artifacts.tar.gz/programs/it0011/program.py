# EVOLVE-BLOCK-START
"""Best fit with a mild preference for already-fuller bins and exact fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: tightest fit (smallest residual after placing).
    residual = bins - item
    # Favor bins that are already fuller (smaller remaining capacity before placement),
    # which consolidates packing and leaves larger contiguous residual gaps.
    fullness_bonus = (100 - bins) * 0.01
    # Small exact-fit bonus.
    exact_bonus = np.where(residual == 0, 0.5, 0.0)
    return -residual + fullness_bonus + exact_bonus
# EVOLVE-BLOCK-END
