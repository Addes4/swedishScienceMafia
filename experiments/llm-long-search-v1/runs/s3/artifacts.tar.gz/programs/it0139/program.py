# EVOLVE-BLOCK-START
"""Best fit (tightest residual) with a tiny stateful residual shaping tiebreak."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Primary: minimize residual (tightest fit). Add a strictly sub-unit bonus
    # that breaks exact-residual ties by preferring the bin that would be left
    # with a residual closest to (but at least) the item size, encouraging
    # future exact fits. All bonuses are kept well below 1 so primary stays dominant.
    bonus = -(np.abs(residual - item)) * 1e-3
    return -(residual.astype(np.float64)) + bonus
# EVOLVE-BLOCK-END

