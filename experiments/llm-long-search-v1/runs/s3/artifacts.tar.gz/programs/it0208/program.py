# EVOLVE-BLOCK-START
"""Best-fit with reusable-residual shaping: the base score is monotone best-fit (smaller
residual always at least as good), so packing stays concentrated and never prefers a looser
bin unnecessarily. On top of that we add (a) a strong seal bonus for near-exact fills and
(b) a reuse bonus when the leftover exactly matches a commonly-seen item size, so a bin that
can be tightly filled later is valued over a wasted sliver. Distributions are estimated from
a rolling window of recent items."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "recent": np.zeros(256, dtype=np.int64),
          "ptr": 0, "filled": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item

    # Rolling window of recent items for distribution estimates.
    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    residual = bins - item

    # Base: monotone best-fit. Smaller residual is always weakly better.
    score = -residual.astype(np.float64)

    # Near-exact seal: strongly prefer placing into a bin that fills almost perfectly.
    score = np.where(residual <= 3, 1000.0 - residual, score)

    # Reuse bonus: reward residuals that exactly match a commonly-seen item size, since
    # such a leftover can be tightly filled by a later item.
    if st["filled"] >= 32:
        window = r[:st["filled"]]
        counts = np.bincount(window, minlength=101).astype(np.float64)
        frac = counts / float(st["filled"])
        in_range = (residual >= 0) & (residual <= 100)
        rr = np.where(in_range, residual, 0).astype(np.int64)
        score = score + 20.0 * frac[rr] * in_range

    return score
# EVOLVE-BLOCK-END

