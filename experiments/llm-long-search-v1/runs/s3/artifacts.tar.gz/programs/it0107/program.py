# EVOLVE-BLOCK-START
"""Best fit with a dead-zone penalty: avoid leaving tiny unusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Exact fit is always best.
    # Otherwise, avoid leaving a small positive residual (likely unfillable dead zone).
    # Threshold: small items are the most likely future fills, so a residual in
    # [1, K) is risky.  Use K = 8 as a conservative dead-zone size.
    K = 8

    # score: exact fit highest, then residuals >= K, then smaller residuals
    score = np.where(
        residual == 0, 2.0,
        np.where(residual >= K, 1.0 - residual * 1e-6,
                 -residual * 1e-3)
    )
    return score
# EVOLVE-BLOCK-END
