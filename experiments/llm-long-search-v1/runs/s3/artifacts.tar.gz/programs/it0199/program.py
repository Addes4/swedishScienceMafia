# EVOLVE-BLOCK-START
"""Best-fit with distribution-aware sliver awareness.

Core idea: prefer the bin whose leftover residual is smallest (pure best-fit packs well),
but add a continuous reward when that residual is a size that future items commonly take
(so the leftover is reusable), and gently penalize unusable slivers. A strong bounded seal
bonus rewards near-exact fills. All terms are computed vectorized over the bins array.
"""
import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # running item-size counts
    "recent": np.zeros(512, dtype=np.int64),   # rolling window of recent items
    "ptr": 0,
    "filled": 0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["hist"][item] += 1

    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    # Frequency-based reusability: how often recent items exactly match a residual.
    if st["filled"] >= 32:
        counts = np.bincount(r[:st["filled"]], minlength=101).astype(np.float64)
    else:
        counts = st["hist"]
    total = counts.sum()
    freq = counts / total  # probability mass per size 0..100

    residual = bins - item  # leftover capacity after placing this item

    # Base: strongly prefer the smallest residual (best-fit packing).
    score = -residual.astype(np.float64)

    # Reusability bonus: residuals that are common future item sizes are good.
    ri = np.clip(residual, 0, 100)
    score = score + 3.0 * freq[ri]

    # Sliver penalty: residual too small to fit a common small item is wasteful.
    score = score - 0.4 * np.clip(5.0 - residual, 0.0, None)

    # Seal bonus: reward near-exact fills (bounded, keeps ordering meaningful).
    score = score + np.where(residual <= 2, 20.0 - residual, 0.0)

    return score
# EVOLVE-BLOCK-END
