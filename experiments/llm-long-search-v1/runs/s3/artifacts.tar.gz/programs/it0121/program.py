# EVOLVE-BLOCK-START
"""Best-fit with residual-quality scoring driven by a running item-size histogram.

Items arrive online. We keep a coarse histogram of sizes seen so far (state between
calls). For each candidate bin we consider the residual after placing the item, and
score residuals by how likely they are to be useful for future items: a residual is
"good" if many observed item sizes fit into it, weighted by their frequency, and a
residual of 0 (exact fit) is always best. Ties in residual quality fall back to
best-fit (smaller residual). This keeps bins open at residuals that future items
can pack into, instead of blindly closing them.
"""
import numpy as np

# 101 buckets for sizes 1..100; bucket s = count of items of size s seen.
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    global _HIST, _TOTAL

    # Record the arriving item into the histogram (used for this decision too).
    _HIST[item] += 1.0
    _TOTAL += 1.0

    # Probability mass of a future item fitting into a residual r, weighted so that
    # larger items (which are harder to place) count more. Use observed frequencies.
    # pfit[r] = sum_{s<=r} freq(s) / total  (fraction of items that would fit).
    hist = _HIST
    total = _TOTAL
    # cumulative fraction of items with size <= r, for r = 0..100
    cum = np.cumsum(hist)  # cum[r] = count of sizes <= r (index r is size r)
    pfit = cum / total if total > 0.0 else np.zeros(101)

    # Residuals after placing the item in each shown bin.
    res = bins - item  # nonnegative: only fitting bins are shown

    # Quality of a residual: higher is better.
    # - exact fit (res == 0) is maximal quality.
    # - otherwise, prefer residuals that are "well-utilizable": ones for which a
    #   large fraction of future items fit, but not so small that only tiny items fit.
    #   Combine fit-probability with the residual size to avoid leaving huge holes
    #   that we can't fill and to avoid tiny residuals future items can't use.
    res_idx = res.astype(np.int64)
    fit_prob = pfit[res_idx]  # in [0,1]

    # Utilization proxy: expected fraction of the residual that a random fitting item
    # consumes, i.e. E[size | size <= res]. Larger residual -> more room.
    # Approximate with the mean size among fitting items capped nicely.
    # mean_fit(r) = sum_{s<=r} s*freq(s) / sum_{s<=r} freq(s)
    weighted = np.cumsum(hist * np.arange(101))
    with np.errstate(divide='ignore', invalid='ignore'):
        mean_fit = np.where(cum > 0, weighted / np.maximum(cum, 1e-12), 0.0)
    mean_fit_r = mean_fit[res_idx]
    # utilization = how full this residual is expected to get on the next fitting item.
    util = np.where(res_idx > 0, mean_fit_r / np.maximum(res_idx, 1), 1.0)

    # Quality: exact fits dominate; otherwise balance fit probability with utilizing
    # the residual well (avoid leaving residuals far larger than typical items, which
    # waste capacity, and avoid residuals too small to be reused).
    exact = (res_idx == 0).astype(np.float64)
    quality = fit_prob * util + 10.0 * exact

    # Primary: quality (higher better). Tie-break: best-fit -> smaller residual.
    score = quality * 1000.0 - res
    return score
# EVOLVE-BLOCK-END
