# EVOLVE-BLOCK-START
"""Hybrid best-fit that avoids leaving dead leftovers."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Rank bins: prefer tight fits, but avoid residuals too small to reuse.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    s = _state
    s["sum"] += item
    s["n"] += 1
    mean_item = s["sum"] / s["n"]

    # residual after placing item in each bin
    resid = bins - item

    # A "dead" leftover is a residual smaller than a substantial fraction of a
    # typical item: such a bin can rarely be refilled well.  Tight fits are good
    # unless they create such a leftover AND a slightly looser bin exists.
    dead = mean_item * 0.35

    score = -resid.astype(np.float64)

    # Penalize dead leftovers mildly; keep best-fit dominant otherwise.
    bad = resid < dead
    score = np.where(bad, score - (dead - resid) * 0.5, score)

    return score
# EVOLVE-BLOCK-END
