# EVOLVE-BLOCK-START
"""Best fit: choose the bin with the least remaining capacity that still fits the item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    return -(bins - item)
# EVOLVE-BLOCK-END
