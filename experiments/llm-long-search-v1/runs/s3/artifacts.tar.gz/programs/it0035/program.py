# EVOLVE-BLOCK-START
"""Best fit with a small bonus for residuals that are near-sealed."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit (prefer smallest residual).
    score = -residual.astype(np.float64)
    # Small bonus for very tight residuals (1..10): nudge toward sealing such bins.
    tight = (residual >= 1) & (residual <= 10)
    score += tight * (0.5 - 0.05 * residual)
    return score
# EVOLVE-BLOCK-END
