# EVOLVE-BLOCK-START
"""Best fit with a tiny reusable-residual bonus driven by a running item histogram."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0


def priority(item, bins):
    global _count
    # Running histogram of observed item sizes (laplace-ish smoothing).
    if 1 <= item <= 100:
        _hist[item] += 1.0
    _count += 1

    resid = bins - item  # remaining capacity after placing item

    # Best fit primary: smaller residual is better.
    score = -resid.astype(np.float64)

    # Bonus for residuals that look like commonly seen item sizes (reusable slack).
    # Normalized, capped, and tiny so it only breaks near-ties.
    tot = _hist.sum()
    if tot > 0:
        freq = _hist[resid.clip(0, 100)]
        score += 0.05 * (freq / tot)

    return score
# EVOLVE-BLOCK-END
