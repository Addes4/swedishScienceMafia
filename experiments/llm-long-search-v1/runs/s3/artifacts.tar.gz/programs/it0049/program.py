# EVOLVE-BLOCK-START
"""Best fit with a mild preference for residuals near the typical item size."""
import numpy as np

_TARGET = 40.0  # mean item size of the distribution (approx)


def priority(item, bins):
    """Return a priority for every bin; highest wins, first on ties.

    Primary signal is tightness (small residual after placement).  A very small
    secondary term nudges us to leave leftovers near the typical item size so the
    leftover is more likely to be filled by a future item rather than wasted.
    """
    # residual after placing the item
    residual = bins - item
    # prefer smallest residual; secondary term is tiny so it only breaks near ties
    # in residual while not disturbing the strong best-fit ordering.
    return -residual.astype(np.float64) - 1e-6 * np.abs(residual - _TARGET)
# EVOLVE-BLOCK-END

