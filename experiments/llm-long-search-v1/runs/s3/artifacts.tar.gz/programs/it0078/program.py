# EVOLVE-BLOCK-START
"""Best fit with a tiny stateful tie-break that favors 'wasted' small residuals."""
import numpy as np

_state = {"mean": 40.0, "n": 0.0}


def priority(item, bins):
    s = _state
    # running mean item size (smoothed)
    s["n"] += 1.0
    s["mean"] += (item - s["mean"]) / s["n"]

    resid = bins - item  # remaining capacity after placing the item
    # primary: tightest fit (smallest residual), higher score = better
    base = -resid.astype(np.float64)

    # tie-break: reward residuals just below the running mean (would be wasted)
    m = s["mean"]
    # small bonus when residual is small but positive and below mean
    bonus = np.where((resid >= 0) & (resid < m), (m - resid) * 1e-3, 0.0)

    return base + bonus
# EVOLVE-BLOCK-END
