# EVOLVE-BLOCK-START
"""Best fit, with a light preference for residuals that remain useful."""
import numpy as np

# Coarse cumulative histogram of the Weibull-shaped item distribution (mean ~40),
# used as a fixed prior so we do not tune to individual instances.
# Approximate sizes: P(item >= x) for x = 1..100, monotonically decreasing.
_USEFUL = np.array([
    1.000, 0.999, 0.997, 0.995, 0.992, 0.988, 0.983, 0.977, 0.970, 0.962,
    0.953, 0.942, 0.930, 0.917, 0.903, 0.887, 0.870, 0.852, 0.833, 0.813,
    0.792, 0.771, 0.749, 0.727, 0.705, 0.682, 0.660, 0.637, 0.615, 0.593,
    0.571, 0.550, 0.529, 0.509, 0.489, 0.470, 0.451, 0.433, 0.415, 0.398,
    0.382, 0.366, 0.351, 0.336, 0.322, 0.308, 0.295, 0.283, 0.271, 0.259,
    0.248, 0.238, 0.228, 0.218, 0.209, 0.200, 0.191, 0.183, 0.175, 0.167,
    0.160, 0.153, 0.146, 0.140, 0.134, 0.128, 0.122, 0.117, 0.112, 0.107,
    0.102, 0.097, 0.093, 0.089, 0.085, 0.081, 0.077, 0.074, 0.070, 0.067,
    0.064, 0.061, 0.058, 0.055, 0.053, 0.050, 0.048, 0.046, 0.043, 0.041,
    0.039, 0.037, 0.035, 0.034, 0.032, 0.031, 0.029, 0.028, 0.026, 0.025,
], dtype=np.float64)


def priority(item, bins):
    """Best fit, lightly preferring residuals that can still hold common items."""
    residual = bins - item
    residual = np.where(residual < 0, 1 << 20, residual)
    # Primary: tightest fit. Secondary (tiny): reward residuals that stay useful.
    usefulness = np.zeros_like(residual, dtype=np.float64)
    small = residual <= 100
    r = residual[small].astype(np.int64)
    r = np.clip(r, 0, 100)
    usefulness[small] = _USEFUL[r]
    return -residual * 1.0 + usefulness * 1e-3
# EVOLVE-BLOCK-END
