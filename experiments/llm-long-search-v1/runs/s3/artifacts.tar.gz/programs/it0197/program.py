# EVOLVE-BLOCK-START
"""Distribution-aware best fit with an empirical item-size distribution.

The rule maintains a histogram of observed item sizes. For each candidate bin it
scores the placement by (a) a strong bonus for near-exact fills, and (b) a
value estimate of the leftover residual: the residual is worth more if a typical
future item is likely to fit into it and leave small waste, estimated from the
empirical distribution seen so far.
"""
import numpy as np

_SIZES = 100
_state = {
    "n": 0,
    "sum": 0.0,
    "counts": np.zeros(_SIZES + 1, dtype=np.float64),
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _state["n"] += 1
    _state["sum"] += item
    if item <= _SIZES:
        _state["counts"][item] += 1.0

    n = _state["n"]
    counts = _state["counts"]
    total = counts.sum()
    if total > 0:
        cdf = np.cumsum(counts) / total          # P(size <= s)
    else:
        cdf = np.arange(_SIZES + 1) / _SIZES

    residual = (bins - item).astype(np.float64)

    # Probability that some future item fits in the residual, estimated empirically.
    r = np.clip(residual.astype(np.int64), 0, _SIZES)
    p_fit = cdf[r]

    # Expected waste if we store this residual: average unused space after a
    # typical item is packed, discounted by the chance an item fits at all.
    # Use a coarse estimate: expected size of a fitting item relative to residual.
    mean = _state["sum"] / n
    expected_next = np.minimum(mean, residual)
    fit_value = residual - expected_next            # leftover after typical next item

    # Base value: reward residuals that leave useful room, keep it bounded.
    score = 2.0 * p_fit * residual - fit_value

    # Mild anti-sliver: residuals too small to ever be useful are penalized.
    score = score - 0.5 * np.clip(0.5 * mean - residual, 0.0, None)

    # Seal bonus: strongly prefer placements leaving a near-exact fill.
    score = np.where(residual <= 2, 1000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END

