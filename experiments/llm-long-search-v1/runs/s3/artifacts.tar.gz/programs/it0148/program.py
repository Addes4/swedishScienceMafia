# EVOLVE-BLOCK-START
"""Stateful best fit with a sub-unit bonus for refillable residuals.

Primary key is the exact best-fit residual (bins - item), so the item still goes into the
tightest fitting bin. A strictly sub-unit bonus (in [0, 1)) is added to prefer bins whose
resulting residual matches a recent large item size, making them exactly refillable later.
"""
import numpy as np

# decayed counts of recent item sizes, size 1..100 (index 0 unused)
_HIST = np.zeros(101, dtype=np.float64)
_DECAY = 0.995
_TOTAL = 0.0
_LARGE = 30.0  # threshold above which a residual is a "large item" target


def priority(item, bins):
    global _TOTAL
    # update running histogram of arriving items
    _TOTAL = _TOTAL * _DECAY + 1.0
    _HIST *= _DECAY
    _HIST[item] += 1.0

    resid = bins - item

    # frequency of each possible residual as a recent item size, normalized to [0,1)
    # only residual sizes that are >= LARGE contribute (small residuals fill easily anyway)
    freq = _HIST / (_TOTAL if _TOTAL > 1e-9 else 1.0)

    # sub-unit bonus: prefer residuals that are frequent recent sizes
    score = -resid.astype(np.float64)
    # add bonus in (0,1) without ever changing which residual is minimal
    bonus = freq[np.clip(resid, 0, 100)]
    # zero out bonus for tiny residuals to keep tight fits strictly best
    bonus = np.where(resid >= _LARGE, bonus, 0.0)
    score += bonus * 0.5
    return score
# EVOLVE-BLOCK-END

