# EVOLVE-BLOCK-START
"""Best-fit-plus-reserve: a dominant monotone tight-fill gradient strictly orders placements
like best-fit (smaller residual is better), with exact fill strictly dominating. Secondary
terms use the *full* running item histogram (stable, low variance) to slightly favor residuals
that match common future item sizes, so leftovers are likely to be consumed later."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["hist"][item] += 1
    total = float(st["n"])

    residual = bins - item  # >= 0 for all offered bins

    # Dominant monotone best-fit gradient: smaller residual is strictly better.
    # Using a smooth function of residual keeps strict ordering on distinct residuals.
    score = -residual.astype(np.float64)

    # Exact fill strictly dominates everything.
    score = np.where(residual == 0, score + 100000.0, score)

    # Secondary: mild preference for residuals likely consumable by a single future item,
    # based on the stable full-history histogram.
    frac = st["hist"] / total
    rr = np.clip(residual, 0, 100).astype(np.int64)
    score = score + 3.0 * frac[rr]

    return score
# EVOLVE-BLOCK-END
