# EVOLVE-BLOCK-START
"""Best-fit with a stateful refillability tie-break.

Primary decision: exact best fit (minimize residual bins-item), matching the strong
baseline.  Secondary, strictly sub-unit bonus: among bins whose resulting residual is
close to the best residual, prefer the one whose resulting residual equals a frequent
recent item size, making that bin exactly refillable by a likely future item.
"""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.int64)
        self.n = 0


_st = _State()


def priority(item, bins):
    st = _st
    # update running histogram of item sizes
    if 1 <= item <= 100:
        st.hist[item] += 1
    st.n += 1

    residual = bins - item  # >= 0 for all bins shown
    best = residual.min()

    # build a small bonus: residual equal to a frequent recent size is good.
    # strictly sub-unit so it never overrides the exact best-fit ordering
    # (ties in `residual` are decided by this bonus, and a bin with residual
    #  best+1 must not beat one with residual best).
    #
    # bonus in [0, 1): fraction of the recent mass sitting exactly on `residual`.
    total = st.n if st.n > 0 else 1
    freq = st.hist / total  # prob estimate per size, small
    # bonus for a bin = freq[residual] scaled into [0,1)
    bonus = freq * 0.9  # max freq <=1 -> bonus < 0.9

    # score: higher residual -> lower score; use -residual as primary via large
    # multiplier, plus sub-unit bonus favoring refillable residuals.
    score = -residual.astype(np.float64) * 2.0 + bonus[np.clip(residual, 0, 100)]
    return score
# EVOLVE-BLOCK-END
