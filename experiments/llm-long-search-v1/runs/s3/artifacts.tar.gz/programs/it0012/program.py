# EVOLVE-BLOCK-START
"""Best fit plus a bonus for leaving a residual capacity that is a likely future item size."""
import numpy as np

_counts = np.ones(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    global _total
    resid = bins - item
    # bonus weight: probability that this residual capacity matches a future item size
    probs = _counts / _total if _total > 0 else np.zeros(101)
    bonus = np.zeros(bins.shape, dtype=np.float64)
    mask = (resid >= 1) & (resid <= 100)
    bonus[mask] = probs[resid[mask]]
    score = -(resid.astype(np.float64)) + bonus
    # update histogram with the arriving item
    _counts[item] += 1.0
    _total += 1.0
    return score
# EVOLVE-BLOCK-END
