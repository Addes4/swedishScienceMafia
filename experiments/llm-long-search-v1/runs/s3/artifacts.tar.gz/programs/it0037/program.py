# EVOLVE-BLOCK-START
"""Best fit with a residual-reusability bonus.

Pure best fit is near-optimal for this distribution, so the remaining
inefficiency comes from tiny near-dead residuals: placing an item to leave
a residual of 1..5 essentially seals the bin, whereas leaving a slightly
larger residual still allows future items to fit.  We keep the strong
best-fit preference (tight fits first) but add a mild bonus to residuals
that are more "reusable" for the item sizes we have actually observed.
"""
import numpy as np

# Histogram of observed item sizes (1..100).
_size_hist = np.ones(101, dtype=np.float64)
_size_hist[0] = 0.0
_obs_count = 0.0


def priority(item, bins):
    """Score each bin; higher score wins (ties go to the earliest bin)."""
    global _obs_count
    # Update running histogram of item sizes.
    _size_hist[item] += 1.0
    _obs_count += 1.0

    residual = bins - item  # >= 0 for every bin we are shown

    # For each possible residual r, estimate how useful it is as free space:
    # the probability (weighted by observed frequency) that some item size
    # can fit into r.  Residuals that can still host common items are worth
    # more than residuals that are effectively dead.
    total = _obs_count + 100.0
    weights = _size_hist / total  # probability of each size
    # Cumulative mass of sizes <= r, for r = 0..100.
    cum = np.cumsum(weights)  # cum[r] = P(size <= r)
    useful = cum  # higher for larger, more reusable residuals

    # Map each bin's residual to its reusability bonus.
    idx = np.clip(residual, 0, 100).astype(np.int64)
    bonus = useful[idx]

    # Strong best-fit term dominates; bonus only breaks near-ties.
    return -residual + 0.05 * bonus
# EVOLVE-BLOCK-END
