# EVOLVE-BLOCK-START
"""Best fit with a residual-usability bias from a running size histogram."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    residual = bins - item

    # Best-fit primary criterion: smaller residual is better.
    score = -residual.astype(np.float64)

    # Strongly prefer exact fills and near-exact fills.
    score += 0.5 / (1.0 + residual)

    # Prefer bins that leave room for a typical remaining item.
    # Favor residuals around a mid-size "complement" rather than tiny dead zones.
    # A residual near 0 is ideal; a residual too small for most items is wasteful.
    small_penalty = np.where((residual > 0) & (residual < 20), -0.05, 0.0)
    score += small_penalty

    return score
# EVOLVE-BLOCK-END
