# EVOLVE-BLOCK-START
"""Best fit with a tiny monotone quadratic shaping on the residual.

The item goes to the bin with the smallest residual after placement. A very
small quadratic term on the residual (coefficient << 1) keeps the ordering
essentially identical to pure best fit but can nudge decisions among bins
whose residuals are extremely close, breaking systematic fragmentation
patterns without sacrificing the near-optimal best-fit behavior.
"""
import numpy as np

# Tiny shaping coefficient. Kept well below 1 so it never overrides the
# dominant -residual ordering (which is scaled by 1 per unit of residual).
_C = 1e-4


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest."""
    residual = bins - item
    # Primary term: prefer the tightest (smallest) residual.
    # Secondary term: a tiny convex shaping that only matters near ties.
    return -(residual.astype(np.float64) + _C * residual.astype(np.float64) ** 2)
# EVOLVE-BLOCK-END
