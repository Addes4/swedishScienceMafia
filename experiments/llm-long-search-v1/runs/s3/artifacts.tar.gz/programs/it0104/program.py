# EVOLVE-BLOCK-START
"""Best fit with a small look-ahead: prefer residuals that can likely be filled."""
import numpy as np

_calls = 0
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _calls, _hist, _total

    # Update running histogram of observed item sizes.
    _hist[item] += 1.0
    _total += 1.0
    _calls += 1

    # Most recently seen distribution -> common future sizes estimate.
    # Use empirical counts; a size s is "likely" if its relative frequency is high.
    # Build a normalized frequency array.
    freq = _hist

    # For each bin, residual after placing item.
    resid = bins - item  # >= 0 by contract

    # Score: primary best-fit (smaller residual better),
    # but penalize residuals that are "hard" to fill:
    # a residual r>0 is hard if no common item size <= r can fit tightly,
    # i.e. it's small relative to typical items.
    # We estimate fillability: for residual r, look for an item size s in [1, r]
    # weighted by frequency; reward high expected fill probability.
    # Simple proxy: reward residuals matching common item sizes (exact-pair bonus),
    # and otherwise fall back to best-fit ordering.

    # Compute a fillability bonus using the histogram over sizes <= r.
    # (Vectorized per bin using cumulative frequency.)
    # Cumulative frequency of observed sizes.
    cum = np.cumsum(freq)  # cum[s] = count of items with size <= s
    denom = _total if _total > 0 else 1.0

    n = resid.shape[0]
    bonus = np.zeros(n, dtype=np.float64)

    # Only compute for bins where residual is nonzero (nonzero residual could still be useful).
    # Use exact-pair bonus: if resid matches a size with meaningful frequency, reward it.
    nonzero = resid > 0
    if np.any(nonzero):
        r = resid[nonzero]
        # Probability that a future item fits entirely into residual r:
        # roughly cum[r]/total (probability a random item <= r),
        # but tightness matters more than mere fit. We use a mild bonus.
        fit_prob = cum[np.clip(r, 0, 100)] / denom
        # Also prefer residuals that are themselves common sizes (good pairing).
        common_size = freq[np.clip(r, 0, 100)] / denom
        bonus[nonzero] = 0.5 * fit_prob + 0.5 * common_size

    # Exact zero residual: perfect, strong bonus.
    perfect = (resid == 0)
    bonus[perfect] = 1.0

    # Primary score: best-fit tightness. Combine with bonus as secondary.
    # Larger score = better. Best fit -> -resid.
    # Blend: keep best-fit dominant, bonus as tie-breaker via small weight,
    # but scale resid by 101 so bonus can break near-ties meaningfully.
    score = -(resid.astype(np.float64)) + 0.02 * bonus
    return score
# EVOLVE-BLOCK-END
