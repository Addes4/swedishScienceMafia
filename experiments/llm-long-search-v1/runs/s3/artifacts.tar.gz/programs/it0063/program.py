# EVOLVE-BLOCK-START
"""Best fit with a soft dead-zone penalty on awkward residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tighter fit is better. residual is in [0, item-1] here.
    primary = -residual.astype(np.float64)
    # Soft penalty for residuals in a middle band: small enough to be "wasteful"
    # but too big to be reliably filled by a tiny item. Scaled below 1 so it
    # only breaks near-ties in the primary key.
    band = np.minimum(residual, 12) / 12.0
    penalty = 0.5 * band * (1.0 - band) * 4.0  # peaks at residual ~6
    return primary - penalty
# EVOLVE-BLOCK-END
