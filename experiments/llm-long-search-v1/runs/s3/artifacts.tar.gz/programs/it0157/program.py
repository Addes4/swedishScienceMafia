# EVOLVE-BLOCK-START
"""Best fit with harmonic residual-class refinement using an online item histogram."""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0}


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    hist = _state["hist"]
    n = _state["n"]
    hist[item] += 1.0
    _state["n"] = n + 1

    # Best-fit base priority: negative residual after placement.
    resid = bins - item
    base = -resid.astype(np.float64)

    # Harmonic residual-class bonus: reward small, "useful" residuals.
    # Frequent size classes give residuals we'd like to leave fillable exactly.
    if n >= 200:
        w = hist / (n + 1.0)
        # For each bin, look up how likely the residual size is to arrive next.
        ridx = np.clip(resid, 0, 100).astype(np.int64)
        bonus = w[ridx]
        # Scale bonus to stay strictly below 1 (sub-unit tie-breaker).
        return base + 0.99 * bonus

    return base
# EVOLVE-BLOCK-END
