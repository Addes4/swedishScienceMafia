# EVOLVE-BLOCK-START
"""Distribution-aware best fit: score each placement by how close the leftover lands to a
typical *small* future item (so the bin can still be reused productively), with a strong
seal bonus for near-exact fills and for residuals matching common item sizes. Uses a running
estimate of item sizes to decide which residuals are genuinely useful rather than wasted slivers."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "small_hist": np.zeros(101, dtype=np.float64),
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["small_hist"][item] += 1

    # Rolling window of recent items for a local small-quantile estimate.
    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    # Estimate a typical "small but common" item size as the ~35th percentile of recent items.
    if st["filled"] >= 32:
        window = r[:st["filled"]]
        q = np.percentile(window, 35)
        # Most common small item size in the window (mode of the lower half).
        counts = np.bincount(window, minlength=101)
        small_counts = counts.copy()
        small_counts[int(q) + 1:] = 0
        mode_small = int(np.argmax(small_counts))
    else:
        q = 0.5 * item
        mode_small = int(round(q))

    mean = st["sum"] / st["n"]
    # Useful residual target: something a small item can still fill well.
    target = max(q, 1.0)

    residual = bins - item

    # Dominant tight-fill gradient: strictly prefer smaller residuals across the whole
    # near-exact regime, so the rule behaves like best-fit when it matters most.
    score = -1.5 * residual

    # Base: prefer residuals near the small-item target (usable leftovers).
    score = score - np.abs(residual - target)

    # Anti-sliver: penalty grows continuously as the residual falls below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.4 * sliver

    # Slight preference against very large residuals (keeps bins concentrated / best-fit-like).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Seal: strong monotone preference toward exact fill. Residual 0 strictly dominates,
    # with residuals 1..3 getting graded (decreasing) bonuses beneath the reuse/seal tiers.
    score = score + 50.0 * np.clip(3.0 - residual, 0.0, None)
    score = np.where(residual == 0, score + 100000.0, score)

    # Reusability bonus: reward residuals that exactly match a commonly-seen item size,
    # since such a leftover can be tightly filled later.
    if st["filled"] >= 32:
        total = float(st["filled"])
        win_counts = np.bincount(r[:st["filled"]], minlength=101).astype(np.float64)
        frac = win_counts / total
        in_range = (residual >= 0) & (residual <= 100)
        rr = np.where(in_range, residual, 0).astype(np.int64)
        score = score + 8.0 * frac[rr] * in_range

    return score
# EVOLVE-BLOCK-END
