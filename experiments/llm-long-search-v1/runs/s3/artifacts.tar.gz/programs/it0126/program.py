# EVOLVE-BLOCK-START
"""Best fit with exact-fit priority: place items so residuals shrink tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit (smallest resulting residual has the highest score).
    score = -residual.astype(np.float64)
    # Strongly prefer exact fills (residual 0), which is always optimal.
    score += (residual == 0) * 1e6
    return score
# EVOLVE-BLOCK-END
