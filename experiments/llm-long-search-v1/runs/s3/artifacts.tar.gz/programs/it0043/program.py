# EVOLVE-BLOCK-START
"""Best fit with a quadratic-residual tie-break (Hochbaum-Shmoys style)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest residual (best fit). Secondary: among equal residuals the
    # choice is the same, so add a tiny perturbation to prefer placements whose
    # residual is itself a "hard to reuse" size (small residual is easier to fill),
    # realized by minimizing residual^2 scaled below the integer residual gap.
    return -(residual.astype(np.float64) + 0.001 * residual.astype(np.float64) ** 2)
# EVOLVE-BLOCK-END
