# EVOLVE-BLOCK-START
"""Reserve-aware best fit: close bins that can be filled almost exactly (avoid tiny
unusable slivers), otherwise target a moderate residual so bins stay packable, and
discourage leaving slivers that only very small future items could use. Large items
preferentially top off already-used bins to avoid opening many shallow bins."""
import numpy as np

_state = {"n": 0, "small": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    if item <= 10:
        _state["small"] += 1

    residual = bins - item

    # Preferred leftover after placing: roughly half the mean item size, so a typical
    # next item can still slot in without leaving a tiny unusable sliver.
    target = 20.0

    # Base preference: residuals close to the target leftover.
    score = -np.abs(residual - target)

    # Discourage leaving a sliver that only small items could fill, but only when the
    # arriving item isn't itself small (small items naturally use these gaps).
    if item > 10:
        score = np.where((residual > 0) & (residual < 8), score - 5.0, score)

    # Strongly reward placements that leave a very small residual: these effectively
    # seal a bin and stop it from accumulating unusable slivers of capacity.
    score = np.where(residual <= 2, 1000.0 - residual, score)

    # Large items: mildly prefer already-used bins (lower remaining capacity) so they
    # top off partially-filled bins rather than opening many shallow ones.
    if item > 40:
        score = score + 0.05 * (100 - bins)

    return score
# EVOLVE-BLOCK-END

