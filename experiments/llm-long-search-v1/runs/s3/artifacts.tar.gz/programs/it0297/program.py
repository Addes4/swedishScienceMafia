# EVOLVE-BLOCK-START
"""Distribution-aware best fit driven entirely by the stable lifetime item histogram.
Rewards placements whose residual is a likely future seal: either a common item size
(one-item seal) or a sum of two common item sizes (two-item seal). Removes noisy
recent-window terms for lower variance."""
import numpy as np

_state = {"n": 0, "hist": np.zeros(201, dtype=np.float64)}

# Precompute pair-sum histogram backing later; small enough to build incrementally.
_pair = np.zeros(201, dtype=np.float64)
_pair_dirty = True


def priority(item, bins):
    st = _state
    st["n"] += 1
    st["hist"][item] += 1

    total = float(st["n"])

    residual = bins - item

    # Base best-fit gradient: gently prefer smaller usable leftovers.
    score = -0.08 * residual

    # Strong monotone preference toward exact fill.
    score = score + 2.0 * np.clip(4.0 - residual, 0.0, None)
    score = np.where(residual == 0, score + 100000.0, score)

    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)

    # Lifetime histogram, smoothed by a narrow kernel for stability.
    frac = st["hist"] / total
    kern = np.array([0.15, 0.7, 0.15])
    smoothed = np.convolve(frac, kern, mode="same")

    # One-item seal: residual is a common item size.
    one_seal = smoothed[rr] * in_range
    score = score + 24.0 * one_seal

    # Two-item seal probability: residual can be formed as a sum of two frequent
    # item sizes. Estimate via a convolution of the (smoothed) histogram.
    global _pair, _pair_dirty
    if _pair_dirty:
        # Convolve smoothed histogram with itself to get pair-sum distribution.
        c = np.convolve(smoothed, smoothed)
        _pair = c[:201]
        _pair_dirty = False

    two_seal = _pair[rr] * in_range
    score = score + 12.0 * two_seal

    return score
# EVOLVE-BLOCK-END
