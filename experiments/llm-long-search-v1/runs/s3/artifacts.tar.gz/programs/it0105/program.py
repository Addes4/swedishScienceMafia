# EVOLVE-BLOCK-START
"""Threshold-aware best fit.

Plain best fit picks the bin with the smallest residual. The main inefficiency is
leaving a tiny positive residual that no future item can exactly fill, wasting
that space. We keep a running histogram of item sizes to estimate a small-item
threshold; when the best fit would leave a positive residual below that
threshold, we instead prefer the tightest placement whose residual is 0 or at
least the threshold.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.int64)
_COUNT = 0


def priority(item, bins):
    global _COUNT
    # Update running histogram of observed item sizes.
    _HIST[item] += 1
    _COUNT += 1

    # Small-item threshold: once we have enough samples, use a low percentile of
    # observed sizes as the "too small to be reusable" cutoff.
    if _COUNT >= 50:
        cum = np.cumsum(_HIST)
        total = cum[-1]
        # 10th percentile of observed sizes.
        idx = np.searchsorted(cum, max(1, int(0.10 * total)))
        t = int(idx)
        if t < 1:
            t = 1
    else:
        t = 0

    residual = bins - item  # >= 0 for all shown bins
    # Base score: tighter fit is better (larger negative residual).
    best = -residual

    if t > 1:
        # A residual is "bad" if it is positive but below t (hard to reuse).
        bad = (residual > 0) & (residual < t)
        if np.any(bad):
            # Preferred: residual == 0, else residual >= t, tightest among those.
            good = ~bad
            if np.any(good):
                # Among good bins, choose tightest residual (smallest residual).
                # Encode: good bins get a large bonus minus residual; bad bins
                # get a strong penalty.
                score = np.where(good, 1000.0 - residual, -1000.0 - residual)
                best = score
    return best
# EVOLVE-BLOCK-END
