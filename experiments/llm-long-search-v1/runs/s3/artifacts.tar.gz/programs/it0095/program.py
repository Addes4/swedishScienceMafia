# EVOLVE-BLOCK-START
"""Best fit with a small distribution-aware residual-usability tie-breaker."""
import numpy as np

# Running histogram of item sizes seen so far (bins of size 1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary rule is best fit (smallest residual after placement).  A mild
    tie-breaker discourages residuals that are in a "dead zone": too small to
    fit typical future items but not zero.
    """
    global _COUNT
    n = bins.shape[0]
    residual = bins - item  # residual after placing item in each bin

    # Update running histogram with the arriving item.
    _HIST[item] += 1.0
    _COUNT += 1.0
    if _COUNT < 40.0:
        return -residual.astype(np.float64)

    # Probability that a future item fits into a bin with a given residual.
    # Cumulative tail of the observed size distribution.
    total = _COUNT
    # tail[r] = P(next item <= r)
    tail = np.cumsum(_HIST) / total  # tail[r-1] corresponds to <= r-1

    # For each bin, estimate the usefulness of the resulting residual:
    # we want residuals that are more likely to accept future items.
    r = residual
    r_clipped = np.clip(r, 0, 100)
    usefulness = tail[r_clipped.astype(np.int64)]  # in [0,1]

    # Emphasize exact fills strongly, otherwise use best fit with a small
    # preference for more "fillable" residuals.
    score = -(r.astype(np.float64)) + 0.5 * usefulness
    # Exact fills should be strictly best.
    score = np.where(r == 0, 1e9, score)
    return score
# EVOLVE-BLOCK-END
