# EVOLVE-BLOCK-START
"""Best-fit with a mild preference for sealable residuals over dead mid-size leftovers."""
import numpy as np


def priority(item, bins):
    """Score = tightest fit, nudged to avoid leaving wasteful mid-size residuals."""
    residual = bins - item
    # Base: prefer the tightest fit (smallest residual).
    score = -residual.astype(np.float64)
    # Small bonus for nearly-full bins (sealable leftovers).
    score += np.where(residual < 15, 0.25, 0.0)
    # Small penalty for awkward mid-size leftovers.
    score -= np.where((residual >= 20) & (residual <= 45), 0.15, 0.0)
    return score
# EVOLVE-BLOCK-END
