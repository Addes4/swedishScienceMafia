# EVOLVE-BLOCK-START
"""Best fit with a dead-zone-aware fresh-bin preference for large items."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0

    def update(self, item):
        self.n += 1
        self.mean += (item - self.mean) / min(self.n, 1000)


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state.update(item)
    residual = bins - item

    # Base score: best fit (prefer small post-placement residual).
    score = -residual.astype(np.float64)

    if item >= 25:
        mu = _state.mean
        # "Dead zone": residual positive but too small to fit a typical future item.
        dead_lo = 1
        dead_hi = max(2.0, 0.5 * mu)
        dead = (residual > 0) & (residual < dead_hi)

        # Prefer freshly-opened / near-empty bins when the best fit lands in a dead zone.
        fresh = bins >= item + max(2.0, 0.5 * mu)
        # Slightly boost fresh bins so they win over dead-zone placements.
        score = np.where(dead, score - 0.5, score)
        score = np.where(fresh & dead.any(), score + 0.25, score)

    return score
# EVOLVE-BLOCK-END
