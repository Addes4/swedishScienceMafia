# EVOLVE-BLOCK-START
"""Best-fit with a mild preference for useful residual sizes."""
import numpy as np


def priority(item, bins):
    """Score bins: tightest fit first, with a small bonus for medium residuals."""
    residual = bins - item
    # primary: tighter fit (smaller residual) is better
    base = -residual.astype(np.float64)
    # small smooth bonus peaking near a residual of ~30, keeps behavior close to best-fit
    bonus = np.exp(-((residual - 30.0) ** 2) / (2.0 * 15.0 ** 2))
    return base + 0.5 * bonus
# EVOLVE-BLOCK-END

