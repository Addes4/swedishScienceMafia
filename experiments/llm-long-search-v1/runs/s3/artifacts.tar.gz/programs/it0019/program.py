# EVOLVE-BLOCK-START
"""Sum-of-squares style rule: choose the placement that most reduces total squared residual."""
import numpy as np


def priority(item, bins):
    """Score bins by the decrease in sum-of-squares of residuals (convex potential).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    r = bins - item                      # residual after placing
    # Cost after placement: r^2 ; before placement: bins^2. Benefit = bins^2 - r^2.
    # Maximizing benefit = picking the tightest fit is exact for this cost; instead use
    # a convex potential that rewards filling fuller bins smoothly.
    return -(r.astype(np.float64) ** 2)
# EVOLVE-BLOCK-END

