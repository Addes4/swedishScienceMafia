# EVOLVE-BLOCK-START
"""Online bin packing via size-class bucketing plus best-fit within a class.

Items are grouped into capacity-based size classes. For each arriving item we
pick the smallest class whose upper bound can hold it, and then place it into
the tightest-fitting bin belonging to that class (best fit restricted to a
size-consistent group). This is the classic Harmonic-style online rule and
avoids mixing very different item sizes inside the same bin, which reduces
fragmentation compared to plain best-fit.
"""
import numpy as np

# Size classes (upper bounds) over item sizes 1..100.
# Standard harmonic-style boundaries give good worst-case ratios.
_CLASS_BOUNDS = np.array([10, 20, 30, 40, 50, 60, 70, 80, 100], dtype=np.int64)


def _class_of(item):
    idx = 0
    while idx < len(_CLASS_BOUNDS) - 1 and item > _CLASS_BOUNDS[idx]:
        idx += 1
    return idx


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    k = _class_of(item)
    upper = _CLASS_BOUNDS[k]
    lower = 0 if k == 0 else _CLASS_BOUNDS[k - 1]

    residual = bins - item  # leftover capacity if item placed here

    # Bins whose leftover stays inside [0, upper-lower] region are "in class";
    # i.e. after placing, remaining capacity is below the class upper bound.
    in_class = residual < upper

    # Score: prefer in-class bins with the tightest fit (smallest residual).
    # Out-of-class bins get a large negative offset so they are used last.
    score = -residual.astype(np.float64)
    score = np.where(in_class, score, score - 1000.0)
    return score
# EVOLVE-BLOCK-END
