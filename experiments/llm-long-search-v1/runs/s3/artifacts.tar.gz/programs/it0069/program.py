# EVOLVE-BLOCK-START
"""Stateful best-fit with a smooth residual-shape preference."""
import numpy as np

_MEAN = None
_COUNT = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _MEAN, _COUNT
    s = float(item)
    # running mean of item sizes (online)
    if _MEAN is None:
        _MEAN = s
        _COUNT = 1
    else:
        _COUNT += 1
        _MEAN += (s - _MEAN) / _COUNT

    b = bins.astype(np.float64)
    resid = b - s  # post-placement residual

    # primary key: tightest fit (smallest residual)
    # secondary: prefer residuals that are close to a typical item size multiple,
    # i.e. leave a gap that can still be filled well.
    m = _MEAN if _MEAN > 1.0 else 1.0
    # distance of residual to nearest positive multiple of m (how "fillable" the gap is)
    r = np.maximum(resid, 0.0)
    k = np.round(r / m)
    gapfit = np.abs(r - k * m)
    # prefer small gapfit (residual near a multiple of typical size),
    # and large residual (keeps options open) as a mild tie-breaker
    return -(resid * 1000.0) - gapfit + 0.01 * r
# EVOLVE-BLOCK-END
