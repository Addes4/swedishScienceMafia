# EVOLVE-BLOCK-START
"""Best fit with a mild fragmentation-aware tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary key: minimize residual (best fit). Exact fills (residual 0) get a huge bonus
    # so they are always strictly preferred over any positive residual.
    # Secondary key: among bins with equal residual, prefer the one whose residual is
    # less "fragmentable": use residual*(residual+1)/2 as a proxy for the number of
    # distinct future item sizes that could still be packed, i.e. slightly prefer smaller
    # residuals that are less likely to waste space on large items.
    score = -1000.0 * residual
    # tie-break: penalize residuals that look like they will strand space.
    # 0 -> 0, 1 -> 1, 2 -> 3, ... grows slowly so it only breaks ties.
    score = score - (residual * (residual + 1)) / 200000.0
    return score
# EVOLVE-BLOCK-END
