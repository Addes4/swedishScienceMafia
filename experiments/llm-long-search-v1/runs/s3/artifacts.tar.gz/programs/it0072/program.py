# EVOLVE-BLOCK-START
"""Harmonic-style online bin packing.

Items are classified into size bands. Instead of pure best fit we bias each
item toward a bin whose current residual belongs to a band compatible with the
item's size band, which keeps bins "clean" (few distinct large items) and
reduces the wasted tail capacity that plagues best fit.
"""
import numpy as np


def _band(s):
    # size bands with breakpoints increasing toward 1.0 (capacity 100)
    if s > 50:
        return 5
    if s > 33:
        return 4
    if s > 25:
        return 3
    if s > 20:
        return 2
    if s > 16:
        return 1
    return 0


def priority(item, bins):
    b = _band(item)
    residual = bins - item  # >= 0 for feasible bins
    # base: prefer tight fit (best fit)
    score = -residual.astype(np.float64)
    # Secondary nudge: for medium/large items prefer bins that end up with a
    # residual that is itself a "clean" band value (helps subsequent matching).
    # Small items (band 0) always use pure best fit.
    if b >= 1:
        # reward residual landing near a multiple boundary of ~item size
        ideal = residual - item
        score += 0.001 * np.abs(ideal)  # discourage deep stacking of two large items
    return score
# EVOLVE-BLOCK-END
