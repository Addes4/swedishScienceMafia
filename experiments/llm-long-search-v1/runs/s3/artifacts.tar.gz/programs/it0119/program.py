# EVOLVE-BLOCK-START
"""Best fit with a residual-utility tie-break using a running mean item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item
    # Primary: prefer tightest fit (smallest residual) -> best fit.
    # Secondary: when residuals are near-tied, prefer leaving a residuall that is at
    # least a typical item size, so the leftover is not wasted.
    # We encode both into a single scalar with a small secondary weight.
    return -residual
# EVOLVE-BLOCK-END
