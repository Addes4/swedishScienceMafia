# EVOLVE-BLOCK-START
"""Best-fit with harmonic-style boundary tie-breaking."""
import numpy as np

# Precompute harmonic thresholds for capacity 100 (classes 1/2..1/8).
# An item of size s "belongs" to class k where 100/(k+1) < s <= 100/k.
_THRESH = [100.0 / k for k in range(1, 9)]  # 100, 50, 33.3, 25, 20, 16.6, 14.3, 12.5


def _item_class(s):
    for k, t in enumerate(_THRESH):
        if s <= t:
            return k
    return len(_THRESH) - 1


def priority(item, bins):
    """Score bins: best fit, with a bonus for residuals crossing harmonic boundaries."""
    cap = bins.astype(np.float64)
    residual = cap - item
    # Base score: tighter fit is better.
    score = -residual

    # Bonus if placing here makes the bin cross into a "full enough" harmonic class,
    # i.e. the bin is nearly full after placement.
    # Boundaries at 100/k for k=2..8: residuals below these are increasingly good.
    for k in range(2, 9):
        b = 100.0 / k
        # If residual < b, small bonus scaled by how small.
        score = np.where(residual < b, score + 0.01 * (b - residual), score)

    return score
# EVOLVE-BLOCK-END
