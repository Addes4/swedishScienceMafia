# EVOLVE-BLOCK-START
"""Best-fit via convex potential reduction over residual capacities."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    r = bins.astype(np.float64) / 100.0
    new = (bins - item).astype(np.float64) / 100.0
    # Reduction in convex potential f(r) = r^2 (strictly decreasing in residual -> best fit).
    return r * r - new * new
# EVOLVE-BLOCK-END
