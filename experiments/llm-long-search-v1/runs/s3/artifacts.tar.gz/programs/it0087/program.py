# EVOLVE-BLOCK-START
"""Best fit with exact-fill priority and a dead-zone penalty for unusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Exact fill: strongly preferred.
    full_bonus = 1000.0 * (residual == 0)

    # Dead zone: residual that is too small to be useful (can't hold a typical item).
    # Small residuals (1..3) tend to be wasted; penalize them slightly.
    dead = (residual > 0) & (residual < 5)
    dead_penalty = 5.0 * dead

    # Primary key: minimize residual (best fit) -> higher score for smaller residual.
    score = -residual + full_bonus - dead_penalty
    return score
# EVOLVE-BLOCK-END

