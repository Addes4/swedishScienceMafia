# EVOLVE-BLOCK-START
"""Hybrid: best fit, but avoid closing tiny residuals that waste a bin."""
import numpy as np

# Running histogram of observed item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Score per bin: highest wins (first on ties).

    Normally best-fit (tightest residual). But exact fits are strongly preferred,
    and bins leaving a useless tiny residual are slightly penalized so that the
    residual can potentially be used by a later item.
    """
    global _hist, _total
    _hist[item] += 1.0
    _total += 1.0

    residual = bins - item  # >= 0 since only fitting bins are shown

    # Estimate typical smallest item sizes from the running histogram.
    # Use cumulative mass: find size s such that a good chunk of future items are <= s.
    cum = np.cumsum(_hist[1:101])
    if _total > 0:
        # median item size as a scale for "tiny residual"
        half = 0.5 * _total
        med = int(np.searchsorted(cum, half)) if half <= cum[-1] else 100
    else:
        med = 20
    # tiny residual threshold: a residual smaller than the typical small item
    tiny = max(1, med // 2)

    # Base best-fit score.
    score = -residual.astype(np.float64)

    # Strongly prefer exact fits.
    score[residual == 0] += 1000.0

    # Penalize leaving a small-but-nonzero useless residual.
    small = (residual > 0) & (residual < tiny)
    score[small] -= 2.0

    return score
# EVOLVE-BLOCK-END
