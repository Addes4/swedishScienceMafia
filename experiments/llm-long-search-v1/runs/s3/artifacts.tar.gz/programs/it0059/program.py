# EVOLVE-BLOCK-START
"""Best fit plus an adaptive reserve that avoids creating useless tiny residuals."""
import numpy as np

_state = {"seen": 0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    # Update online mean estimate of item sizes.
    s = _state
    s["seen"] += 1
    s["mean"] += (item - s["mean"]) / s["seen"]
    mean = s["mean"]

    # Best fit: prefer the smallest post-placement residual (tightest fit).
    residual = bins - item

    # Reserve threshold: residuals below ~half the mean item size are unlikely to be
    # filled well, so mildly prefer bins leaving a residual at/above it.
    reserve = max(1.0, 0.4 * mean)

    score = -residual.astype(np.float64)
    # Small penalty (less than one residual unit) for residuals below the reserve.
    below = residual < reserve
    score -= below.astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END
