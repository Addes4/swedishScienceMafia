# EVOLVE-BLOCK-START
"""Distribution-aware best fit with a stable, exponentially-smoothed small-item target.

The rule prefers residuals that can be productively refilled by typical *small* future items,
while keeping a smooth preference for tighter fits. A near-exact-fill seal bonus plus a bonus
for residuals that exactly match a common item size round out the shaping. All estimates are
exponentially updated so they don't jitter call-to-call.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0,
          "small_hist": np.zeros(101, dtype=np.float64),
          "q_small": 0.0, "init": False,
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["small_hist"][item] += 1

    # Rolling window of recent items for a local small-quantile estimate.
    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    # Stable small-item target: exponentially-smoothed ~35th percentile of recent items.
    if st["filled"] >= 32:
        window = r[:st["filled"]]
        q_now = float(np.percentile(window, 35))
        if not st["init"]:
            st["q_small"] = q_now
            st["init"] = True
        else:
            st["q_small"] = 0.9 * st["q_small"] + 0.1 * q_now
        # Most common small item size in the window (mode of the lower half).
        counts = np.bincount(window, minlength=101)
        small_counts = counts.copy()
        small_counts[int(q_now) + 1:] = 0
        mode_small = int(np.argmax(small_counts))
    else:
        st["q_small"] = 0.5 * item if not st["init"] else st["q_small"]
        st["init"] = True
        q_now = max(st["q_small"], 1.0)
        mode_small = int(round(q_now))

    mean = st["sum"] / st["n"]
    target = max(st["q_small"], 1.0)

    residual = bins - item

    # Base: prefer the tightest fit, but remain tolerant once residual is at/above target.
    score = -np.abs(residual - target)

    # Anti-sliver: penalty grows continuously as the residual falls below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.4 * sliver

    # Slight preference against very large residuals (keeps bins concentrated / best-fit-like).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Seal bonus: strongly prefer placements that leave a near-exact fill.
    score = np.where(residual <= 3, 1000.0 - residual, score)
    if mode_small > 0:
        score = np.where(residual == mode_small, score + 5.0, score)

    # Reusability bonus: reward residuals that exactly match a commonly-seen item size.
    if st["filled"] >= 32:
        total = float(st["filled"])
        win_counts = np.bincount(r[:st["filled"]], minlength=101).astype(np.float64)
        frac = win_counts / total
        in_range = (residual >= 0) & (residual <= 100)
        rr = np.where(in_range, residual, 0).astype(np.int64)
        score = score + 8.0 * frac[rr] * in_range

    return score
# EVOLVE-BLOCK-END
