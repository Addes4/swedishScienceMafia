# EVOLVE-BLOCK-START
"""Best-fit-first with a seal: strongly prefer placing the item into the fullest bin it fits
in (smallest residual), dominate exact fills, and lightly reward residuals whose value is a
common item size (so a later item can exactly close the bin). The base monotone best-fit
gradient is what actually reduces the number of bins, so it dominates the ranking."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "full_hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["full_hist"][item] += 1

    residual = bins - item

    # Base: pure best-fit — prefer the fullest bin that still fits (smallest non-negative residual).
    score = -2.0 * residual.astype(np.float64)

    # Strong monotone seal toward near-exact fills; residual 0 strictly dominates.
    score = score + 60.0 * np.clip(4.0 - residual, 0.0, None)
    score = np.where(residual == 0, score + 100000.0, score)

    # Reusability bonus: reward residuals whose value is a frequently-seen item size, so a
    # later item can exactly complete this bin.
    total = float(st["n"])
    frac = st["full_hist"] / total
    kern = np.array([0.25, 0.5, 0.25])
    smoothed = np.convolve(frac, kern, mode="same")
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse = smoothed[rr] * in_range
    score = score + 6.0 * reuse

    return score
# EVOLVE-BLOCK-END

