# EVOLVE-BLOCK-START
"""Best fit with a tiny usability-aware tie-break on the residual."""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item  # >= 0 for all shown bins

    # Primary: tightest fit (smallest residual -> largest score via negation).
    score = -residual.astype(np.float64)

    # Tiny nudge: reward residuals that can still hold a typical small item,
    # penalize residuals too small to be useful again.
    small = _state["min_item"]
    usable = residual >= small
    bonus = np.where(usable, 0.0, -1e-6)
    score += bonus

    return score
# EVOLVE-BLOCK-END

