# EVOLVE-BLOCK-START
"""Stateful blended best-fit / best-loaded rule for online bin packing."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.total = 0.0

    def update(self, item):
        self.n += 1
        self.total += item


_state = _State()


def priority(item, bins):
    """Rank bins; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state.update(item)

    residual = bins - item  # remaining capacity after placing the item

    # Primary: best-fit (prefer smallest residual). Use a strong negative weight.
    # Secondary: slight preference for bins that are already more loaded
    # (smaller pre-placement remaining capacity), i.e. larger (100 - bins).
    # Blend so best-fit dominates but near-ties can be resolved.
    score = -(residual.astype(np.float64)) - 0.05 * bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
