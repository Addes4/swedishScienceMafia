# EVOLVE-BLOCK-START
"""Best fit with a consolidation tie-break: prefer non-empty bins on residual ties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize residual (best fit).
    # Secondary: prefer already-occupied bins (residual < 100 - item) over fresh ones,
    # i.e. consolidate instead of spreading. Scale small so it only breaks ties.
    is_empty = bins >= 100
    return -residual.astype(np.float64) - 0.0 * is_empty - 0.001 * is_empty
# EVOLVE-BLOCK-END
