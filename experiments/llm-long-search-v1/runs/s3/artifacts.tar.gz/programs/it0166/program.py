# EVOLVE-BLOCK-START
"""Hybrid best-fit: tight packing plus residual-compatibility tie-breaks."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Best-fit core: prefer the smallest residual (tightest fit).
    score = -residual.astype(np.float64)

    # Tie-break for equal residuals: prefer bins whose post-placement residual is
    # "compatible" with a typical item size (near 40) so the bin can be completed
    # later with one more item, reducing slack that would open new bins.
    # Add a tiny, distinct bonus that grows as residual approaches ~40.
    compat = -np.abs(residual - 40.0)
    score += 1e-3 * compat

    # Second tie-break: among equal (residual, compat), prefer the fuller bin
    # (smaller residual already dominates; here favor larger residual only on
    # exact ties in the core terms via a minuscule index-ordering shim).
    score -= 1e-9 * bins.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
