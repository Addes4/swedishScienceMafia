# EVOLVE-BLOCK-START
"""Harmonic-style bin choice: classify items by size and steer placement.

For "large" items (> capacity/2) we use best-fit since they must occupy a bin
mostly alone anyway. For smaller items we use a harmonic-style rule: items in
class k (capacity/(k+1), capacity/k] are steered toward bins whose current
load pattern leaves residuals compatible with same-class packing, by using a
scored best-fit that mildly prefers bins already holding similar-sized gaps.
"""
import numpy as np

CAP = 100


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, ties go first."""
    bins = np.asarray(bins)

    if item * 2 > CAP:
        # Large item: best fit (tightest residual), prefer a bin it nearly fills.
        return -(bins - item)

    # Small/medium item: harmonic-style class-based best fit.
    # Class k means item in (CAP/(k+1), CAP/k].
    # Steer items to bins where the residual after placement is large enough
    # to still accept another item of the same class, i.e. leave residual >= item
    # but avoid huge residuals (spread packing of same class together).
    residual = bins - item  # >= 0 for feasible bins
    # prefer tightest fit first (best-fit ordering)
    primary = -residual.astype(float)
    # secondary: among similar fits, prefer residuals that are near a multiple
    # of the item size (so the bin can be filled with same-class items)
    ratio = residual.astype(float) / item
    frac = ratio - np.floor(ratio)
    # reward residual close to being a multiple of item (frac near 0 or 1)
    align = -np.minimum(frac, 1.0 - frac)
    return primary + 0.25 * align
# EVOLVE-BLOCK-END
