# EVOLVE-BLOCK-START
"""Distribution-aware best fit: strongly seal bins that can be filled exactly, otherwise
prefer the smallest usable leftover (best fit), with a light bonus for leftovers matching
common recent item sizes so bins stay reusable. Adaptive via a rolling recent-item window."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "full_hist": np.zeros(101, dtype=np.float64),
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0,
          "recent_hist": np.zeros(101, dtype=np.float64)}

_kern = np.array([0.25, 0.5, 0.25])


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["full_hist"][item] += 1

    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        old = r[st["ptr"]]
        st["recent_hist"][old] -= 1
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size
    st["recent_hist"][item] += 1

    residual = bins - item

    # Base best-fit gradient: prefer the smallest usable leftover.
    score = -1.0 * residual

    # Exact-fill seal: residual 0 dominates everything else.
    score = np.where(residual == 0, score + 100000.0, score)

    # Reusability bonus: reward leftovers that are themselves common recent item sizes.
    total_recent = float(max(st["filled"], 1))
    frac = st["recent_hist"] / total_recent
    smoothed = np.convolve(frac, _kern, mode="same")
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse = smoothed[rr] * in_range
    score = score + 30.0 * reuse

    return score
# EVOLVE-BLOCK-END
