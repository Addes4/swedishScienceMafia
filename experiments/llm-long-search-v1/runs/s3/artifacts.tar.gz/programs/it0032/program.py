# EVOLVE-BLOCK-START
"""Best fit with a size-aware residual preference.

Large items: pure best fit (tighten bins aggressively).
Small items: mildly prefer leaving a bit more room, so bins with small
residuals stay useful for the many small items arriving later.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # post-placement leftover in each candidate bin

    if item <= 30:
        # Small item: prefer a moderately roomy bin over an extremely tight one.
        # Penalize very small residuals so we don't waste a bin prematurely,
        # while still preferring fuller bins over nearly-empty ones.
        score = -(residual.astype(np.float64))
        score += 0.15 * np.minimum(residual, 30)
    else:
        score = -(residual.astype(np.float64))

    return score
# EVOLVE-BLOCK-END
