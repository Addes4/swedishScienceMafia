# EVOLVE-BLOCK-START
"""Harmonic best fit: best-fit plus a stateful residual-alignment bonus."""
import numpy as np


# Persistent online statistics of item sizes seen so far.
_state = {"n": 0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    # Update running mean of item sizes (Welford-ish, simple incremental).
    n = _state["n"]
    mean = _state["mean"]
    n += 1
    mean += (item - mean) / n
    _state["n"] = n
    _state["mean"] = mean

    leftover = (bins - item).astype(np.float64)

    # Primary key: tightest fit (smallest feasible residual).
    base = -leftover

    # Bonus: reward residuals that are close to a whole multiple of the typical item size,
    # i.e. capacity that can be fully consumed by future items rather than wasted.
    m = max(mean, 1.0)
    phase = np.mod(leftover, m)
    dist = np.minimum(phase, m - phase)          # distance to nearest multiple of m
    alignment = dist / m                          # 0 at perfect multiple, ~0.5 worst
    bonus = 0.05 * (0.5 - alignment)              # in [0, 0.025], tiny tie-breaker

    return base + bonus
# EVOLVE-BLOCK-END
