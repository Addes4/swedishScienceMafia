# EVOLVE-BLOCK-START
"""Best-fit with randomized tie-breaking among the tightest residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best-fit base priority (higher = tighter fit).
    base = -residual.astype(np.float64)
    # Add a tiny random jitter so ties among equal residuals are broken randomly,
    # avoiding systematic fragmentation while keeping best-fit dominant.
    jitter = np.random.random(bins.shape[0]) * 0.5
    return base + jitter
# EVOLVE-BLOCK-END

