# EVOLVE-BLOCK-START
"""Best-fit with a running size estimate used to avoid uselessly small residuals."""
import numpy as np

_state = {"sizes": [], "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state
    st["sizes"].append(item)
    st["n"] += 1
    if len(st["sizes"]) > 200:
        st["sizes"].pop(0)

    # Running estimate of a "typical usable" residual: median of recent item sizes.
    if st["n"] < 20:
        target = 0.0
    else:
        target = float(np.median(np.asarray(st["sizes"], dtype=np.float64)))

    residual = bins - item  # remaining capacity after placement (bins already fit the item)

    # Prefer residuals that are at least `target` (so a typical future item still fits),
    # and among those prefer the smallest such residual (tightest packing that stays useful).
    # Otherwise fall back to plain best-fit (smallest residual).
    big_enough = residual >= target
    score = np.where(big_enough, -(residual - target) - 1e-6, -1e6 - residual.astype(np.float64))
    return score
# EVOLVE-BLOCK-END
