# EVOLVE-BLOCK-START
"""Best fit, but among very tight fits prefer the least tight to delay sealing bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Among bins that would be left nearly-full (residual <= 15, soon unusable),
    # prefer the largest residual (least tight) to avoid premature sealing.
    # Otherwise strongly prefer the tightest fit.
    return -(residual + np.where(residual <= 15, 200 - residual, 0))
# EVOLVE-BLOCK-END
