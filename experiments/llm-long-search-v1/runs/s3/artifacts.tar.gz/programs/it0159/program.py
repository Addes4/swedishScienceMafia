# EVOLVE-BLOCK-START
"""Dual-fit: best fit for small items, slack-aware scoring for large items."""
import numpy as np


def priority(item, bins):
    """Score bins; item goes to the highest-scoring bin (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    residual = bins - item  # >= 0

    if item < 25:
        # Tight packing of small items: pure best fit.
        return -residual

    # For larger items, best fit dominates, but mildly prefer residuals that
    # are not tiny stranded gaps (which small items likely can't fill).
    # A stranded gap below the typical small-item size is wasteful; larger
    # residuals are more likely to be reused by upcoming small items.
    # Add a sub-unit tie-breaker that never overrides best-fit ordering.
    smallest_common = 1.0  # conservative floor for usable residual
    stranded = (residual < smallest_common).astype(np.float64)
    # bonus in [0, 0.5): prefer non-stranded residuals, then fall to size ordering
    return -residual - 0.5 * stranded
# EVOLVE-BLOCK-END
