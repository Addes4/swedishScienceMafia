# EVOLVE-BLOCK-START
"""Distribution-aware placement: prefer bins whose leftover lands in a "usable" range
(near a typical small item size) so the bin can be reused productively, with a strong
seal bonus for near-exact fills and a reuse bonus for residuals matching common item sizes.
Uses a stable running histogram of past items to judge which residuals are genuinely useful."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "hist": np.zeros(101, dtype=np.float64),
          "recent": np.zeros(512, dtype=np.int64), "ptr": 0, "filled": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["hist"][item] += 1.0

    # Rolling window of recent items for a local small-quantile estimate.
    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    mean = st["sum"] / st["n"]

    # Stable small-item target: exponentially-weighted mode of common small sizes.
    if st["n"] >= 64:
        frac = st["hist"] / st["n"]
        # small-item target = most common size below ~0.6*mean
        low = st["hist"].copy()
        low[int(0.6 * mean) + 1:] = 0.0
        mode_small = int(np.argmax(low))
        frac_small = float(frac[mode_small])
    else:
        mode_small = max(1, int(round(0.4 * item)))
        frac_small = 0.1

    target = max(float(mode_small), 1.0)

    residual = bins - item

    # Base: monotone best-fit preference for tighter usable residuals.
    score = -0.15 * np.clip(residual, 0.0, None)

    # Reward residuals near the usable small-item target (smooth), weak symmetric shaping.
    score = score - 0.20 * np.abs(residual - target)

    # Anti-sliver: penalize residuals falling below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.5 * sliver

    # Discourage very large residuals (keep bins concentrated).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Strong seal bonus: prefer placements leaving a near-exact fill.
    score = np.where(residual <= 2, 1000.0 - residual, score)

    # Reuse bonus: residual matching a very common small size.
    if st["n"] >= 64 and mode_small > 0:
        score = np.where(residual == mode_small, score + 6.0 * min(1.0, 10.0 * frac_small), score)

    return score
# EVOLVE-BLOCK-END
