# EVOLVE-BLOCK-START
"""Best fit, but avoid creating unusably small residuals by choosing the next-best fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary key: prefer tightest fit (smallest residual). We invert sign for "highest wins".
    score = -residual * 1000.0
    # Secondary nudge: among near-tied residuals, slightly deprioritize residuals in the
    # low "dead zone" (1..12) where few items from the distribution fit, to reduce waste.
    dead = (residual >= 1) & (residual <= 12)
    offset = (residual - 12.0) * 1.0
    nudge = np.where(dead, offset * 0.001, 0.0)
    return score + nudge
# EVOLVE-BLOCK-END

