# EVOLVE-BLOCK-START
"""Best fit with a filler tiebreak toward already-fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: tightest fit (minimal post-placement residual) => maximize -(bins - item)
    # Secondary: among equal residuals, prefer the bin that is already fullest
    # (smallest remaining capacity) to reduce fragmentation.
    return -(bins - item) * 101 - bins
# EVOLVE-BLOCK-END
