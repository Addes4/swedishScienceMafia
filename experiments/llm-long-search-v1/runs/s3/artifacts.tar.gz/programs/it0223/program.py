# EVOLVE-BLOCK-START
"""Distribution-aware best fit: score each placement by how close the leftover lands to a
typical *small* future item (so the bin can still be reused productively), with a strong
seal bonus for near-exact fills and a smoothed reuse bonus for residuals matching common
item sizes. Statistics are updated exponentially (no per-call percentile/mode) so targets
stay stable across the 5,000 calls."""
import numpy as np

_state = {
    "n": 0, "sum": 0.0,
    "hist": np.zeros(101, dtype=np.float64),   # exponential decayed histogram
    "init": False,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item

    # Exponentially-updated histogram (stable, cheap, no per-call sort/percentile).
    if not st["init"]:
        st["hist"][1:] = 1.0 / 100.0
        st["init"] = True
    decay = 0.999
    st["hist"] *= decay
    st["hist"][item] += 1.0
    # normalise occasionally implicitly by dividing by n when needed
    tot = st["hist"].sum()
    frac = st["hist"] / (tot if tot > 0 else 1.0)

    # Small-item target: lower-quantile-ish via histogram, stable across calls.
    # Find the size where cumulative probability reaches ~0.35.
    cum = np.cumsum(frac)
    q = int(np.searchsorted(cum, 0.35))
    if q < 1:
        q = 1
    target = float(q)

    # Modal small item size (mode of lower half of distribution).
    lower = frac[: q + 1].copy()
    mode_small = int(np.argmax(lower)) if lower.size > 0 else 0

    mean = st["sum"] / st["n"]

    residual = bins - item

    # Base: prefer residuals near the small-item target (usable leftovers).
    score = -np.abs(residual - target)

    # Anti-sliver: penalty grows continuously as the residual falls below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.4 * sliver

    # Slight preference against very large residuals (keeps bins concentrated).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Seal bonus: strongly prefer placements that leave a near-exact fill.
    score = np.where(residual <= 3, 1000.0 - residual, score)

    # Smoothed reuse bonus: reward residuals near a commonly-seen item size.
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    score = score + 8.0 * frac[rr] * in_range

    return score
# EVOLVE-BLOCK-END
