# EVOLVE-BLOCK-START
"""Best fit with a harmonic residual preference: prefer tight fits, but among
near-tight fits prefer residuals that match a common observed item size."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Dominant term: best fit (smaller residual after placement = higher score).
    score = -residual.astype(np.float64)
    # Sub-unit bonus: prefer residuals that are "usable" leftovers (>= item-ish
    # granularity), penalize tiny unusable slivers (1..3) which waste capacity.
    # Bonus magnitude < 1 so it never overrides a strictly better fit.
    small = np.clip(residual, 0, 3)
    # reward residuals that are not tiny slivers
    bonus = np.where((residual >= item) | (residual == 0), 0.5, 0.0)
    # discourage 1..2 slivers
    bonus -= np.where((residual > 0) & (residual < 3), 0.25, 0.0)
    return score + bonus
# EVOLVE-BLOCK-END
