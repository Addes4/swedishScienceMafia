# EVOLVE-BLOCK-START
"""Best fit with new-bin gating: prefer existing bins unless the residual is too small."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Resulting residual if the item were placed in each bin.
    residual = bins - item

    # Best-fit primary key: smaller residual is better -> higher score.
    score = -residual.astype(np.float64)

    # Small deterministic bonus for bins whose residual is at least ~30%
    # of capacity, so we don't leave tiny unusable slivers behind.
    score += 0.5 * (residual >= 30)

    return score
# EVOLVE-BLOCK-END

