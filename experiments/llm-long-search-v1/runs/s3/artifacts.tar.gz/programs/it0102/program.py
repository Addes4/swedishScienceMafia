# EVOLVE-BLOCK-START
"""Best fit with a mild preference for putting items into existing (already used) bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer smallest residual. Add a very small term that favors
    # non-empty bins (residual < 100) to reduce opening new bins, without
    # disturbing the best-fit ordering much.
    residual = bins - item
    # Penalize empty bins slightly so the tightest-fit non-empty bin wins over
    # an equally-tight empty bin; this reduces unnecessary bin openings.
    empty_penalty = (bins == 100).astype(np.float64) * 0.01
    return -residual.astype(np.float64) - empty_penalty
# EVOLVE-BLOCK-END
