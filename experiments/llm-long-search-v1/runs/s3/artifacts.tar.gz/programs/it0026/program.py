# EVOLVE-BLOCK-START
"""Harmonic-class best fit: prefer placing the item where the resulting residual
falls into a harmonic interval that is most easily completed, strongly favoring
very small residuals (sealed bins) while still preferring tight fits within a band.
"""
import numpy as np

# Precompute harmonic interval boundaries (in fractional capacity).
# For item of size s, its class is k = max(1, floor(1/s)) ... we approximate with
# fixed bands over residual ranges.
_BOUNDS = np.array([0, 1, 2, 4, 6, 9, 13, 18, 25, 33, 45, 60, 80, 100], dtype=np.float64)


def _band_score(residual):
    """Lower residual is better, but broken into bands to prefer sealing bins."""
    # bins that become nearly full get a strong bonus (residual in [0,4])
    return -residual


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    res = bins - item  # remaining capacity after placing
    # Strong bonus for residuals that leave a bin essentially full (sealed).
    # Use small positive class weights for low residuals, decaying with residual.
    # Weight = (101 - residual)/100 scaled, plus an extra bump for tiny residuals.
    score = -(res.astype(np.float64))
    # Extra reward for sealing a bin: residual below a threshold gets a big push.
    tiny = res <= 4
    score = score + tiny * 50.0
    return score
# EVOLVE-BLOCK-END
