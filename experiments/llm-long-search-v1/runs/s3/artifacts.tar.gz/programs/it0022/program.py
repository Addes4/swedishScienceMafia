# EVOLVE-BLOCK-START
"""Best fit with a waste-aware tie-break: avoid leaving unusably small residuals."""
import numpy as np

# Typical item sizes are Weibull-shaped with mean ~40; residuals below this are
# often too small to be reusable by another item.
SMALL = 5.0
W = 0.25


def priority(item, bins):
    """Score each fitting bin; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    residual = bins - item
    # Pure best fit: minimize residual (larger score = smaller residual).
    score = -residual.astype(np.float64)
    # Penalize residuals that are non-negative but too small to be reused.
    waste = (residual < SMALL).astype(np.float64)
    score -= W * waste
    return score
# EVOLVE-BLOCK-END
