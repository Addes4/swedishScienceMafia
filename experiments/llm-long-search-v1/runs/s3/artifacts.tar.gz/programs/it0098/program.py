# EVOLVE-BLOCK-START
"""Best fit with a dead-zone-aware reassignment of nearly-full near-misses."""
import numpy as np


class _State:
    def __init__(self):
        # running reservoir-ish histogram of recent item sizes (bucket by size 1..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0

    def update(self, item):
        self.hist[item] += 1.0
        self.count += 1.0


_state = _State()


def _recent_quantile(state, q):
    if state.count < 20.0:
        return 5.0
    c = np.cumsum(state.hist)
    total = c[100]
    if total <= 0:
        return 5.0
    target = q * total
    idx = int(np.searchsorted(c, target))
    if idx < 1:
        idx = 1
    if idx > 100:
        idx = 100
    return float(idx)


def priority(item, bins):
    """Best fit, but avoid leaving a tiny unusable residual (dead zone).

    Primary key: smaller residual (bins - item) is better -> plain best fit.
    Secondary: if best fit would leave a residual below a recent-item-size
    quantile (likely too small to be filled usefully), penalize that bin and
    favor a larger residual that keeps the bin open for future items, while
    still preferring occupied bins over fresh empty ones to consolidate.
    """
    residual = bins - item  # >= 0 by contract

    # recent small-item threshold (dead zone lower edge)
    dz = _recent_quantile(_state, 0.20)  # ~20th percentile of recent item sizes

    # base score: prefer smallest residual (best fit)
    score = -residual.astype(np.float64)

    # penalize residuals that fall in a likely "dead zone": >0 but < dz
    dead = (residual > 0) & (residual < dz)
    # penalize, but small enough not to override a strictly better best-fit
    # by more than 1 unit of residual ordering
    score = score - dead.astype(np.float64) * 0.5

    # prefer occupied bins (residual < 100) over empty ones on close calls,
    # i.e. small bonus for non-empty bins to consolidate into partially filled bins
    nonempty = (residual < 100)
    score = score + nonempty.astype(np.float64) * 0.001

    return score
# EVOLVE-BLOCK-END
