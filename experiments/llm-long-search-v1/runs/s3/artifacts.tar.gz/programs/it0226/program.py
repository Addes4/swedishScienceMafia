# EVOLVE-BLOCK-START
"""Distribution-aware best fit: strongly prefer the tightest usable leftover (true best-fit),
with a large seal bonus for near-exact fills and a reuse bonus rewarding residuals whose size
is commonly seen (so the leftover can be tightly filled later). A stable, exponentially-updated
histogram of past item sizes provides the reuse weights, avoiding per-call noise."""
import numpy as np

_state = {"n": 0, "sum": 0.0,
          "hist": np.zeros(101, dtype=np.float64)}

# Decay for the exponentially-updated item-size histogram.
_DECAY = 0.999


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item

    hist = st["hist"]
    # Stable exponential update: decay old mass, add this item.
    hist *= _DECAY
    hist[item] += 1.0

    mean = st["sum"] / st["n"]

    residual = bins - item  # remaining capacity after placing, always >= 0 here

    # Base: true best-fit -> monotonically prefer the smallest non-negative residual.
    # Scale down so the additive reuse/seal bonuses can dominate when relevant.
    score = -residual.astype(np.float64) * 0.2

    # Seal bonus: strongly prefer near-exact fills (residual 0 is best).
    score = np.where(residual <= 3, 1000.0 - residual, score)

    # Reuse bonus: reward residuals that exactly match a commonly-seen item size, since such
    # a leftover can be tightly filled later. Use the stable histogram (normalized).
    total = hist.sum()
    if total > 1e-9:
        frac = hist / total
        in_range = (residual >= 0) & (residual <= 100)
        rr = np.where(in_range, residual, 0).astype(np.int64)
        score = score + 30.0 * frac[rr] * in_range

    # Mild preference against very large residuals (keeps bins concentrated).
    score = score - 0.02 * np.clip(residual.astype(np.float64) - mean, 0.0, None)

    return score
# EVOLVE-BLOCK-END
