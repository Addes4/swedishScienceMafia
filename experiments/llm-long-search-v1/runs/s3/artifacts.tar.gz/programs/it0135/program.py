# EVOLVE-BLOCK-START
"""Best-fit with a sliver-avoiding tie break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score gets the item (first on ties)."""
    bins = np.asarray(bins)
    residual = bins - item
    # Primary: best fit (smallest residual) -> score = -residual
    # Tie/near-tie break: among residuals within a tiny window of the best,
    # prefer leaving a usable residual (not a tiny sliver) by preferring
    # the smaller residual only if it stays above a small threshold.
    best = residual.min()
    # near-best window
    near = residual <= best + 1
    # penalize slivers slightly: residual 0 (perfect) is best, small residuals fine,
    # but we want to avoid making tiny unusable residuals when an equivalent choice exists.
    # Use -residual as main score; small additive bonus for exact fits.
    score = -residual.astype(np.float64)
    score += (residual == 0).astype(np.float64) * 1e-6
    return score
# EVOLVE-BLOCK-END
