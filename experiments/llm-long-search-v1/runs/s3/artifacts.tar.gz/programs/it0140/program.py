# EVOLVE-BLOCK-START
"""Best fit plus a size-class tie-break: prefer residuals matching common past item sizes."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    res = bins - item

    freq = priority.freq
    freq[item] += 1.0
    total = freq.sum()

    # Bonus strictly in [0, 1): prefers residuals that equal common past item sizes,
    # a strong signal that the bin can later be filled exactly. Never overrides the
    # exact best-fit ordering since it is added with weight < 1.
    bonus = freq[res] / (total + 1.0)

    return -res + 0.5 * bonus


if not hasattr(priority, "freq"):
    priority.freq = np.zeros(101, dtype=np.float64)
# EVOLVE-BLOCK-END
