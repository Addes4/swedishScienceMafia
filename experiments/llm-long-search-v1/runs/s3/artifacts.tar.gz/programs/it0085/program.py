# EVOLVE-BLOCK-START
"""Distribution-aware best fit.

Items are drawn from a fixed Weibull-shaped distribution with mean about 40.
Rather than pure myopic best fit, score each candidate bin by how well its
post-placement residual can still absorb future random items, while still
strongly preferring tight fits to limit immediate waste.
"""
import numpy as np

# Approximate CDF of the item-size distribution (Weibull-ish, mean ~40).
# We build a piecewise-linear survival function over integer sizes 1..100.
_SIZES = np.arange(0, 101, dtype=np.float64)

# A rough Weibull(k=1.5, lambda=44) pmf sampled on integers 1..100, normalized.
def _build_pmf():
    k = 1.5
    lam = 44.0
    s = np.arange(1, 101, dtype=np.float64)
    pdf = (k / lam) * (s / lam) ** (k - 1.0) * np.exp(-(s / lam) ** k)
    pdf = pdf / pdf.sum()
    return pdf

_PMF = _build_pmf()
# P(item >= t) for t = 0..100
_GE = np.concatenate([[1.0], np.cumsum(_PMF[::-1])[::-1]])
# probability an item fits in residual r: P(item <= r)
_LE = 1.0 - _GE  # _LE[r] = P(item <= r), index r from 0..100

# Expected "value" of a residual r: how many typical future items it can hold on
# average plus a bonus if it is at least the mean size. Use a smooth sigmoid on
# r relative to the mean to reflect remaining packable capacity.
_MEAN = float((_PMF * np.arange(1, 101)).sum())


def priority(item, bins):
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # remaining capacity after placing the item
    # Tighter fit => smaller residual; primary driver of the score.
    tight = -(residual)

    # Secondary: reward residuals that are large enough to matter but not so
    # large we are wasting space. A residual close to the mean item size can
    # typically fit one more average item, so prefer it slightly.
    r = np.clip(residual, 0, 100)
    usable = _LE[np.clip(r.astype(np.int64), 0, 100)]
    # Smooth preference for residuals near the mean item size.
    near_mean = np.exp(-((r - _MEAN) ** 2) / (2.0 * (0.6 * _MEAN) ** 2))

    return tight + 0.05 * usable + 0.02 * near_mean
# EVOLVE-BLOCK-END
