# EVOLVE-BLOCK-START
"""Best fit with a tie-break that avoids leaving unusable tiny residuals."""
import numpy as np

# Small penalty applied when the leftover after placing the item is in a range
# that is hard to reuse (too small for a typical small item), pushing the rule
# to instead close the bin more tightly or leave a bigger reusable gap.
_TINY = 6  # residuals strictly below this are considered hard to reuse


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual -> larger score since we negate).
    score = -residual.astype(np.float64)
    # Penalize residuals that are small but nonzero: such leftover space is
    # often too small to hold future items, effectively wasted capacity.
    wasted = (residual > 0) & (residual < _TINY)
    score -= 0.5 * wasted.astype(np.float64)
    # Tiny bonus for fuller bins to consolidate and avoid fragmentation.
    score += 1e-4 * (100 - residual)
    return score
# EVOLVE-BLOCK-END
