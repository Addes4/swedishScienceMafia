# EVOLVE-BLOCK-START
"""Best-fit-ish rule with a light distribution-aware anti-sliver nudge.

Classic best-fit (smallest feasible leftover) is a strong online packing rule; pure
best-fit can create unusable slivers though. Here we primarily reward small residuals
(tight fits), then add a gentle penalty only for slivers that are too small to ever
usefully hold a typical next item, plus a strong seal bonus for near-exact fills.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    residual = bins - item

    # Base: tight fits are best (small residual preferred). Scale into a bounded term.
    score = -residual.astype(np.float64)

    # Gentle anti-sliver: penalize leftovers smaller than a typical item that likely
    # cannot be reused productively.
    sliver_thresh = 0.5 * mean
    small = np.clip(sliver_thresh - residual, 0.0, None)
    score = score - 0.3 * small

    # Seal bonus: strongly prefer placements leaving a near-exact fill.
    score = np.where(residual <= 2, 1000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END

