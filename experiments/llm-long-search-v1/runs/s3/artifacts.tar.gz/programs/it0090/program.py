# EVOLVE-BLOCK-START
"""Best fit with a preference for filling bins nearly full."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # residual capacity after placing the item into each bin
    res = bins - item

    # Base: best fit -> minimize residual (higher score for smaller residual)
    score = -res.astype(np.float64)

    # Strongly prefer exact fills and near-exact fills.
    # A residual of 0 is best; small residuals that can't fit typical items are also good
    # because they effectively close the bin without wasting usable space.
    # We add a bonus that grows as residual shrinks below a threshold.
    bonus = np.where(res <= 10, (11.0 - res) * 0.5, 0.0)
    score = score + bonus

    return score
# EVOLVE-BLOCK-END
