# EVOLVE-BLOCK-START
"""Best fit with a gap-quality adjustment: prefer tight fits, but value residuals that
are either 0 (perfectly sealed) or large enough to be useful, penalizing tiny wasteful gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item

    # Primary: tighter fit is better (negative residual).
    score = -residual.astype(np.float64)

    # Reward a perfectly sealed bin (residual 0) so it can't waste future capacity.
    score += 0.05 * (residual == 0)

    # Mildly penalize very small nonzero residuals (wasted slivers) that are too small
    # to fit most future items, gently steering away from creating dead space.
    small = (residual > 0) & (residual < 5)
    score -= 0.02 * small

    return score
# EVOLVE-BLOCK-END
