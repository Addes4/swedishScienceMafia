# EVOLVE-BLOCK-START
"""Distribution-aware best fit: prefer tight fits, weighted by how often a residual can be reused."""
import numpy as np


class _State:
    def __init__(self):
        # Histogram over item sizes 1..100 of items seen so far (smoothed).
        self.hist = np.ones(101, dtype=np.float64)
        self.count = 101.0


_state = _State()


def priority(item, bins):
    """Return a priority per bin. Primary: tightest fit. Secondary: residual reusability."""
    st = _state

    # Update the running item-size histogram with the current item.
    st.hist[item] += 1.0
    st.count += 1.0
    p = st.hist / st.count  # probability of each size 1..100

    residual = bins - item  # remaining capacity after placing (>=0 since bins only shown if fit)

    # Expected number of future items that can fit in each residual:
    # sum_{s=1..100} p[s] * (s <= residual)  == cumulative mass up to residual.
    cdf = np.cumsum(p)  # cdf[r] = P(next item size <= r)
    reuse = cdf[np.clip(residual, 0, 100)]

    # Primary: tightest fit (smaller residual better -> larger -(bins-item)).
    # Secondary: prefer residuals with high expected reuse (keeps bins productive).
    return -(residual.astype(np.float64)) + 0.5 * reuse
# EVOLVE-BLOCK-END
