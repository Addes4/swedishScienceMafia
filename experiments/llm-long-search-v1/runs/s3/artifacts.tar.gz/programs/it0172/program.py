# EVOLVE-BLOCK-START
"""Best fit with a preference for perfect or near-perfect completion of bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing item (>= 0)
    # Primary: prefer smaller residual (classic best fit), expressed as a strong negative.
    # Secondary: among near-ties, favor bins whose residual is at or below a small target,
    # which encourages closing bins tightly. The target scales mildly with item size.
    target = 5 if item >= 50 else 3
    near = np.minimum(residual, target)
    return -(residual * 100) - near
# EVOLVE-BLOCK-END
