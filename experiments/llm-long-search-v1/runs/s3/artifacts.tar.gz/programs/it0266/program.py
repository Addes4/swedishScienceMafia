# EVOLVE-BLOCK-START
"""Best-fit-dominant placement: prefer the fullest fitting bin (smallest residual), with a
very strong exact-fill seal and a modest reusability bonus rewarding residuals that sit on
frequently-seen item sizes (so a later item can near-perfectly close the bin). Avoids the
earlier "target residual" preference, which kept too many half-empty bins alive."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "full_hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["full_hist"][item] += 1

    mean = st["sum"] / st["n"]

    residual = bins - item

    # Base: monotone best-fit gradient (smaller residual -> higher score).
    score = -residual.astype(np.float64)

    # Mild anti-sliver reserve: punish leaving a tiny but nonzero leftover.
    score = score - 0.5 * ((residual > 0) & (residual < 6))

    # Slight preference against very large residuals (keep bins concentrated).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Strong monotone seal toward exact fill.
    score = score + 30.0 * np.clip(2.0 - residual, 0.0, None)
    score = np.where(residual == 0, score + 100000.0, score)

    # Reusability bonus: residual near a frequently-seen item size.
    total = float(st["n"])
    frac = st["full_hist"] / total
    kern = np.array([0.25, 0.5, 0.25])
    smoothed = np.convolve(frac, kern, mode="same")
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse = smoothed[rr] * in_range
    score = score + 4.0 * reuse

    return score
# EVOLVE-BLOCK-END
