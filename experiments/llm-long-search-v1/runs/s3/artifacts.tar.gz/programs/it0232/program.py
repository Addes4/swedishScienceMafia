# EVOLVE-BLOCK-START
"""Distribution-aware best fit: score each placement by how close the leftover lands to a
typical *small* future item (so the bin can still be reused productively), with a strong
seal bonus for near-exact fills and for residuals matching common item sizes. Uses a stable
exponentially-updated histogram of item sizes to decide which residuals are genuinely useful
rather than wasted slivers."""
import numpy as np

_state = {"n": 0, "sum": 0.0,
          "hist": np.zeros(101, dtype=np.float64),
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item

    # Stable exponentially-updated histogram of item sizes (decay keeps it adaptive).
    h = st["hist"]
    h *= 0.999
    h[item] += 1.0

    # Rolling window of recent items for a local small-quantile estimate.
    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    # Estimate a typical "small but common" item size as the ~35th percentile of recent items.
    if st["filled"] >= 32:
        window = r[:st["filled"]]
        q = np.percentile(window, 35)
        counts = np.bincount(window, minlength=101)
        small_counts = counts.copy()
        small_counts[int(q) + 1:] = 0
        mode_small = int(np.argmax(small_counts))
    else:
        q = 0.5 * item
        mode_small = int(round(q))

    mean = st["sum"] / st["n"]
    target = max(q, 1.0)

    residual = bins - item

    # Base: prefer residuals near the small-item target (usable leftovers).
    score = -np.abs(residual - target)

    # Anti-sliver: penalty grows continuously as the residual falls below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.4 * sliver

    # Slight preference against very large residuals (keeps bins concentrated / best-fit-like).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Seal bonus: strongly prefer placements that leave a near-exact fill.
    score = np.where(residual <= 3, 1000.0 - residual, score)
    if mode_small > 0:
        score = np.where(residual == mode_small, score + 5.0, score)

    # Reusability bonus: reward residuals that match commonly-seen item sizes, using a
    # stable decaying histogram so the signal is smooth across calls.
    hsum = h.sum()
    if hsum > 0:
        frac = h / hsum
        in_range = (residual >= 0) & (residual <= 100)
        rr = np.where(in_range, residual, 0).astype(np.int64)
        score = score + 8.0 * frac[rr] * in_range

    return score
# EVOLVE-BLOCK-END

