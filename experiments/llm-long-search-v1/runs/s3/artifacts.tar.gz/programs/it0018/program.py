# EVOLVE-BLOCK-START
"""Bin choice: best-fit with a mild fullness bonus (consolidate into used bins)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties go to first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of fitting bins, in bin order.
    """
    residual = bins - item                    # remaining capacity after placement
    tight = -residual.astype(np.float64)      # best-fit primary term
    fullness = (100.0 - bins)                 # how used the bin already is
    return tight + 0.02 * fullness
# EVOLVE-BLOCK-END
