# EVOLVE-BLOCK-START
"""Best fit with a mild preference for leaving a medium-sized residual open."""
import numpy as np

_state = {"target": 30}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    target = _state["target"]
    # Primary: best fit (smallest residual). Secondary: prefer residuals near the target
    # leftover so a medium bin stays open and can absorb future smaller items.
    return -(residual * 100.0 + np.abs(residual - target))
# EVOLVE-BLOCK-END
