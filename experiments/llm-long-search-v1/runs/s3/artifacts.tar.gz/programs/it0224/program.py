# EVOLVE-BLOCK-START
"""Best-fit with seal bonus: prefer the tightest usable leftover (monotone in residual),
keep a strong bonus for near-exact fills, and add a mild bonus when the leftover exactly
matches a frequently-seen item size so the bin can be reused productively. Statistics are
kept in a slowly-adapting histogram to avoid per-call noise."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "hist": np.zeros(101, dtype=np.float64), "decay": 0.999}


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    st = _state
    st["n"] += 1
    st["sum"] += item
    hist = st["hist"]
    hist *= st["decay"]
    hist[item] += 1.0

    # Normalized frequency of item sizes seen so far (smooth, stable).
    frac = hist / max(hist.sum(), 1.0)

    residual = bins - item  # remaining capacity after placing item here

    # Base: strong preference for the tightest fit (smallest non-negative residual).
    score = -residual.astype(np.float64)

    # Seal bonus: near-exact fills are strongly favored (avoid wasting near-full bins).
    score = np.where(residual <= 3, 1000.0 - residual, score)

    # Reuse bonus: reward leftovers that match common recent item sizes.
    rr = np.clip(residual, 0, 100).astype(np.int64)
    score = score + 6.0 * frac[rr]

    return score
# EVOLVE-BLOCK-END
