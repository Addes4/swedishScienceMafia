# EVOLVE-BLOCK-START
"""Two-term online bin-choice rule: an exact-fill seal plus a reusability score equal to the
probability (estimated from a rolling recent-item histogram) that a single upcoming item can
exactly fill the residual, mildly tie-broken toward smaller leftovers."""
import numpy as np

_state = {"n": 0, "sum": 0.0,
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0,
          "recent_hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state
    st["n"] += 1
    st["sum"] += item

    # Rolling window of recent items for a responsive local distribution estimate.
    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        old = r[st["ptr"]]
        st["recent_hist"][old] -= 1
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size
    st["recent_hist"][item] += 1

    residual = bins - item

    # Base best-fit gradient: gently prefer smaller usable leftovers.
    score = -0.08 * residual

    # Seal: strong monotone preference toward exact fill; residual 0 dominates.
    score = score + 2.0 * np.clip(4.0 - residual, 0.0, None)
    score = np.where(residual == 0, score + 100000.0, score)

    # Reusability: probability that a single upcoming item exactly fills the leftover.
    total_recent = float(max(st["filled"], 1))
    prob = st["recent_hist"] / total_recent
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse = prob[rr] * in_range
    score = score + 40.0 * reuse

    return score
# EVOLVE-BLOCK-END
