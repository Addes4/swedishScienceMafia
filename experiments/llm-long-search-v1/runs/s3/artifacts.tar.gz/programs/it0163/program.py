# EVOLVE-BLOCK-START
"""Best fit with a tiny consolidation bonus for already-filling bins."""
import numpy as np


def priority(item, bins):
    bins = bins.astype(np.float64)
    residual = bins - item
    # Best fit: smaller residual is better.
    score = -residual
    # Tiny bonus for bins that are already nearly full (small remaining capacity),
    # so residual holes get reused instead of leaving many medium-filled bins.
    filled = 100.0 - bins
    score += 1e-3 * (filled / 100.0)
    return score
# EVOLVE-BLOCK-END
