# EVOLVE-BLOCK-START
"""Best-fit with an exact-fill seal plus a reusability bonus. Placing an item so the bin
becomes exactly full is strongly preferred (a bin retired for free). Otherwise we prefer
the tightest fit (smallest usable residual), but nudge slightly toward residuals that
coincide with commonly-seen item sizes, since such leftovers can be filled tightly later.
Keeps a running histogram of item sizes to drive the reuse bonus."""
import numpy as np

_state = {"n": 0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["hist"][item] += 1

    residual = bins - item
    n = st["n"]

    # Base: monotone best-fit preference for the smallest usable residual.
    score = -residual.astype(np.float64)

    # Exact-fill seal: strongly prefer placements that make the bin exactly full.
    score = np.where(residual == 0, 100000.0, score)

    # Reusability bonus: reward residuals matching a commonly-seen item size, so the
    # leftover can be tightly filled later. Weighted by empirical frequency.
    if n >= 64:
        frac = st["hist"] / n
        in_range = (residual >= 0) & (residual <= 100)
        rr = np.where(in_range, residual, 0).astype(np.int64)
        score = score + 50.0 * frac[rr] * in_range

    return score
# EVOLVE-BLOCK-END

