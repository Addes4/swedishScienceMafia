# EVOLVE-BLOCK-START
"""Best fit with a tiny stateful anti-waste tie-break.

Primary rule remains myopic best fit (minimize resulting residual), which is
essentially optimal for this distribution. A strictly sub-unit bonus breaks
near-ties in favor of residuals that are less likely to become permanently
wasted: a residual that is smaller than the smallest plausible future item
(roughly the low end of the Weibull item sizes) is slightly penalized, while
residuals near common recent item sizes are slightly favored so that the bin
stays refillable.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in, in bin order.
    """
    res = bins - item  # resulting residual for each candidate bin

    # Primary key: best fit -> prefer smallest residual. Negate so higher is better.
    score = -res.astype(np.float64)

    # Strictly sub-unit tie-break. Residuals below a small threshold are nearly
    # useless (the item can never come back), so penalize them slightly.
    tiny = res <= 3
    score -= 0.5 * tiny

    return score
# EVOLVE-BLOCK-END
