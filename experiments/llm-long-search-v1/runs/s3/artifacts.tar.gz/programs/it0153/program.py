# EVOLVE-BLOCK-START
"""Best-fit with a sub-unit tie-breaker that favors reassembling common size classes."""
import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),
    "total": 0.0,
}


def priority(item, bins):
    """Rank bins: primary best-fit, secondary a smooth bonus for refillable residuals."""
    hist = _state["hist"]
    hist[item] += 1.0
    _state["total"] += 1.0

    # Smooth, sub-unit secondary score based on how likely the resulting residual
    # is to be exactly consumed by a common future item size.  It is scaled to
    # stay strictly below 1.0 so it never overrides the best-fit residual order.
    residual = bins - item  # >= 0 for all bins given to us

    tot = _state["total"]
    # Frequency mass near each residual value (sizes are integers 1..100).
    r = np.clip(residual, 0, 100).astype(np.int64)
    low = np.maximum(r - 2, 0)
    high = np.minimum(r + 2, 100)
    freq = np.zeros(residual.shape, dtype=np.float64)
    # Sum neighboring histogram buckets (3-wide window) as a cheap density proxy.
    for d in (-2, -1, 0, 1, 2):
        idx = np.clip(r + d, 0, 100)
        freq += hist[idx]
    freq /= max(tot, 1.0)

    # Primary: prefer tightest fit (smallest residual).  Secondary: freq bonus < 1.
    return -residual.astype(np.float64) + 0.5 * freq
# EVOLVE-BLOCK-END
