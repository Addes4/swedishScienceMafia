# EVOLVE-BLOCK-START
"""Stable distribution-aware best fit. Maintains an exponentially-decayed item-size
histogram to get a smooth estimate of the popular small item size (a good residual
target), then scores bins by how tightly they constrain the leftover toward useful
sizes: monotone preference for the smallest non-negative residual, with a strong seal
bonus for near-exact fills and a mild reuse bonus when the residual matches a common
upcoming item size."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "hist": np.zeros(101, dtype=np.float64), "decay": 0.995}


def priority(item, bins):
    st = _state
    st["n"] += 1
    st["sum"] += item

    # Exponentially decayed histogram over item sizes (smooth, stable estimate).
    st["hist"] *= st["decay"]
    st["hist"][item] += 1.0
    hist = st["hist"]
    total = hist.sum()

    if total > 0:
        # Popular small item size: weighted mode restricted to the lower part of the
        # distribution (typical small items that reuse leftovers well).
        cum = np.cumsum(hist)
        q35 = int(np.searchsorted(cum, 0.35 * total))
        small = hist.copy()
        small[q35 + 1:] = 0.0
        mode_small = float(np.argmax(small))
        mean = st["sum"] / st["n"]
        frac = hist / total
    else:
        q35 = item
        mode_small = float(item)
        mean = float(item)
        frac = hist

    residual = bins - item

    # Base: best-fit-like, prefer smallest non-negative residual.
    score = -residual.astype(np.float64)

    # Anti-sliver: penalize residuals much smaller than a typical small item.
    target = max(mode_small, 1.0)
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.6 * sliver

    # Seal bonus: strongly prefer near-exact fills.
    score = np.where(residual <= 3, 1000.0 - residual, score)

    # Reuse bonus: residual exactly matches a common upcoming item size.
    if total > 0:
        in_range = (residual >= 0) & (residual <= 100)
        rr = np.where(in_range, residual, 0).astype(np.int64)
        score = score + 6.0 * frac[rr] * in_range

    return score
# EVOLVE-BLOCK-END
