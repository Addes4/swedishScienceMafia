# EVOLVE-BLOCK-START
"""Tightness-shaped best fit: rank bins mainly by how small the residual is (best-fit), but
apply a smooth saturating transform so that over-tight residuals that no typical future item
can fit are devalued relative to residuals that are still productively reusable. Uses a
running quantile of recent item sizes to define the "usable" scale, plus a strong seal bonus
for near-exact fills."""
import numpy as np

_state = {"n": 0, "sum": 0.0,
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item

    # Rolling window of recent items for a local small-quantile estimate.
    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    # Typical "small but common" item size (~25th percentile of recent items).
    if st["filled"] >= 32:
        q = float(np.percentile(r[:st["filled"]], 25))
    else:
        q = 0.5 * item

    target = max(q, 1.0)
    mean = st["sum"] / st["n"]

    residual = bins - item  # >= 0 since item fits

    # Base: prefer tight fits (small residual). Negate for "higher is better".
    score = -residual.astype(np.float64)

    # Smoothly devalue residuals far below the usable target (slivers no future item fits).
    # Concave shape: penalty only bites for small residuals, small everywhere else.
    deficit = np.clip(target - residual, 0.0, None)
    score -= 0.35 * deficit

    # Mild dislike of very large residuals to keep bins concentrated (best-fit tendency).
    excess = np.clip(residual - mean, 0.0, None)
    score -= 0.03 * excess

    # Seal bonus: strongly prefer placements leaving a near-exact fill.
    score = np.where(residual <= 2, 1000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END
