# EVOLVE-BLOCK-START
"""Best fit with a stable anti-sliver reserve: prefer tight fills but firmly avoid creating
small unusable slivers, using a running estimate of a typical small future item."""
import numpy as np

_state = {"n": 0, "sum": 0.0,
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0,
          "full_hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["full_hist"][item] += 1

    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    if st["filled"] >= 64:
        window = r[:st["filled"]]
        q = np.percentile(window, 25)
    else:
        q = 0.5 * item

    mean = st["sum"] / st["n"]
    target = max(q, 1.0)

    residual = bins - item

    # Base: prefer residuals near the small-item target (usable leftovers).
    score = -np.abs(residual - target)

    # Anti-sliver: penalty grows as the residual falls below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.6 * sliver

    # Slight preference against very large residuals (keeps bins concentrated / best-fit-like).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Seal: softer monotone preference toward tight fills; residual 0 strictly dominates.
    score = score + 6.0 * np.clip(3.0 - residual, 0.0, None)
    score = np.where(residual == 0, score + 100000.0, score)

    # Reusability bonus: reward residuals whose value is a frequent item size.
    total = float(st["n"])
    frac = st["full_hist"] / total
    kern = np.array([0.25, 0.5, 0.25])
    smoothed = np.convolve(frac, kern, mode="same")
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse = smoothed[rr] * in_range
    score = score + 8.0 * reuse

    return score
# EVOLVE-BLOCK-END
