# EVOLVE-BLOCK-START
"""Best-fit with a stateful residual-target nudge toward the running mean item size."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Score each bin; highest score wins (first on ties).

    item: integer size 1..100
    bins: remaining capacities of bins the item fits in (includes empty bins).
    """
    s = _state
    s["n"] += 1
    s["sum"] += item
    mean = s["sum"] / s["n"]

    residual = bins - item

    # Primary: prefer smallest residual (tightest fit).
    # Secondary: for residuals that are "wasted" (too small to fit a typical item),
    # prefer to use them up now rather than leaving them stranded.
    # Build a smooth score: reward small residual, extra reward if residual < mean.
    score = -residual.astype(np.float64)

    # Bins whose residual is below the typical item size are effectively dead space;
    # placing the item there "consumes" them, so give a small bonus proportional
    # to how close that residual is to zero.
    dead = residual < mean
    score += np.where(dead, 0.5 * (mean - residual), 0.0)

    return score
# EVOLVE-BLOCK-END
