# EVOLVE-BLOCK-START
"""Best fit with adaptive residual targeting to improve packing efficiency."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Pure best fit: prefer the tightest residual, but nudge toward leaving
    # gaps near the mean item size so later mid/large items can fill them.
    target = 20.0
    diff = np.abs(residual - target)
    score = -residual - 0.05 * diff
    # Strongly prefer tight fits (small residual) as primary factor.
    return score - 0.5 * (residual > item)
# EVOLVE-BLOCK-END

