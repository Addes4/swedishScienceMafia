# EVOLVE-BLOCK-START
"""Distribution-aware best fit: prefer placements that either nearly seal the bin (residual
close to 0) or leave a leftover matching a common upcoming item size, and additionally reward
residuals that can be closed by a short sequence of common items (pairing)."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "full_hist": np.zeros(101, dtype=np.float64),
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0,
          "recent_hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["full_hist"][item] += 1

    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        old = r[st["ptr"]]
        st["recent_hist"][old] -= 1
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size
    st["recent_hist"][item] += 1

    mean_all = st["sum"] / st["n"]

    if st["filled"] >= 32:
        window = r[:st["filled"]]
        mean_recent = float(window.mean())
    else:
        mean_recent = mean_all

    residual = bins - item

    # Base best-fit gradient.
    score = -0.08 * residual

    # Seal: strong monotone preference toward exact fill.
    score = score + 2.0 * np.clip(4.0 - residual, 0.0, None)
    score = np.where(residual == 0, score + 100000.0, score)

    # Reusability target.
    target = max(mean_recent, 1.0)
    score = score - 0.6 * np.abs(residual - target)
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.5 * sliver

    # Smoothed recent histogram.
    total_recent = float(max(st["filled"], 1))
    frac = st["recent_hist"] / total_recent
    kern = np.array([0.15, 0.7, 0.15])
    smoothed = np.convolve(frac, kern, mode="same")

    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse = smoothed[rr] * in_range
    score = score + 18.0 * reuse

    peak = frac[rr] * in_range
    score = score + 4.0 * peak

    # Pairing: probability a residual can be sealed by a single common item OR by a common
    # pair whose first member leaves a residual that a common item still fits exactly.
    pair_bonus = np.zeros_like(residual, dtype=np.float64)
    if st["filled"] >= 64:
        # common sizes: those with non-negligible recent frequency
        idx = np.nonzero(frac > 0.004)[0]
        if idx.size > 0:
            f = frac[idx]
            # single-item seal
            single = np.zeros_like(residual, dtype=np.float64)
            for x, fx in zip(idx, f):
                single += np.where(np.abs(residual - x) < 0.5, fx, 0.0)
            # two-item seal: exists x such that residual - x is another common size y
            two = np.zeros_like(residual, dtype=np.float64)
            for x, fx in zip(idx, f):
                rem = residual - x
                mask = (rem >= 0) & (rem <= 100)
                rr2 = np.where(mask, rem, 0).astype(np.int64)
                two += fx * smoothed[rr2] * mask
            pair_bonus = single + 0.5 * two
    score = score + 6.0 * pair_bonus * in_range

    return score
# EVOLVE-BLOCK-END

