# EVOLVE-BLOCK-START
"""Distribution-aware best fit: primary tightness, secondary expected-size fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties).

    Primary key: tightest fit (most negative residual) as in best-fit.
    Secondary key: closeness of post-placement residual to the mean item size (~40),
    so that when the tightest fits are comparably loose we keep bins reusable.
    """
    residual = bins - item
    primary = -residual.astype(np.float64)
    # Secondary: prefer residual near typical item size (~40). Ties on primary are
    # broken toward residuals closer to 40, which maximizes future packing flexibility.
    secondary = -np.abs(residual - 40).astype(np.float64)
    # Combine: primary dominates, secondary only breaks near-ties.
    return primary * 1000.0 + secondary
# EVOLVE-BLOCK-END
