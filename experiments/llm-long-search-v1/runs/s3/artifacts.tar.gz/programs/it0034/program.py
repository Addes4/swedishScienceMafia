# EVOLVE-BLOCK-START
"""Best fit with a mild concave reweighting of the post-placement residual.

Pure best fit minimizes the residual r = bins - item.  This variant keeps
that ordering intact but reshapes the preference slightly so that residuals
which match a common future item size are marginally favoured over
essentially-equal residuals that do not, which tends to make a bin
sealable later without ever breaking the tight-fit dominance.
"""
import numpy as np

# Lookup: value of the score for each possible residual 0..100.
# Start from -r (best fit) and add a tiny, bounded bonus that peaks when
# the residual equals a typical item size (mean ~40) and at small sizes
# that a single future item can finish off.
_RES = np.arange(101, dtype=np.float64)

# Tiny periodic ripple in [-1, 1], zero-mean over residuals, scaled down so
# it can only break near-ties and never override a genuine tightness gap.
_RIPPLE = 0.5 * (1.0 - np.cos(2.0 * np.pi * _RES / 40.0))  # in [0, 1]

# Bonus is largest for residuals that are either very small (quickly
# sealable) or close to a typical item size (likely to be filled exactly).
_BONUS = 0.02 * _RIPPLE + 0.01 * np.exp(-_RES / 8.0)

_SCORE = -_RES + _BONUS


def priority(item, bins):
    """Return a priority for every bin; highest wins, ties to first bin."""
    residual = bins - item
    np.clip(residual, 0, 100, out=residual)
    return _SCORE[residual]
# EVOLVE-BLOCK-END
