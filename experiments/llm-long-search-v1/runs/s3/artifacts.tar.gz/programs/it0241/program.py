# EVOLVE-BLOCK-START
"""Distribution-aware best fit: score each placement by how close the leftover lands to a
typical *small* future item (so the bin can still be reused productively), with a strong
seal bonus for near-exact fills and for residuals matching common item sizes. Uses a stable
exponentially-decayed histogram of item sizes to decide which residuals are genuinely useful
rather than wasted slivers."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "decay_hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item

    # Stable exponentially-decayed histogram of item sizes (weight ~1/decay_scale events).
    dh = st["decay_hist"]
    dh *= 0.995
    dh[item] += 1.0

    total_dh = dh.sum()
    mean = st["sum"] / st["n"]

    residual = bins - item

    if total_dh >= 8.0:
        # Normalized frequency of each item size seen so far.
        frac = dh / total_dh
        # "Small usable" target: the weighted-median-ish lower quantile of item sizes.
        cum = np.cumsum(frac)
        # index of the ~35th percentile of the decaying histogram
        target_idx = int(np.searchsorted(cum, 0.35))
        target = float(max(target_idx, 1))
        # Most common small size in the histogram (rough mode of the lower half).
        small_counts = frac.copy()
        small_counts[int(target) + 1:] = 0.0
        mode_small = int(np.argmax(small_counts))
    else:
        target = max(0.5 * item, 1.0)
        frac = None
        mode_small = int(round(target))

    # Base: prefer residuals near the small usable target.
    score = -np.abs(residual - target)

    # Anti-sliver: penalty as the residual falls below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.4 * sliver

    # Slight preference against very large residuals (best-fit-like concentration).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Seal bonus: strongly prefer near-exact fills.
    score = np.where(residual <= 3, 1000.0 - residual, score)

    # Nudge when residual matches the most common small size.
    if mode_small > 0:
        score = np.where(residual == mode_small, score + 5.0, score)

    # Reusability bonus: reward residuals that exactly match a commonly-seen item size.
    if frac is not None:
        in_range = (residual >= 0) & (residual <= 100)
        rr = np.where(in_range, residual, 0).astype(np.int64)
        score = score + 8.0 * frac[rr] * in_range

    return score
# EVOLVE-BLOCK-END
