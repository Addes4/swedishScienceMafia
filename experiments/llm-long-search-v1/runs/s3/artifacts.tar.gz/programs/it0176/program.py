# EVOLVE-BLOCK-START
"""Adaptive reserve-aware best fit: tight fits for near-perfect placements, otherwise
target a residual chosen from the observed item-size distribution so leftover space
stays usable for future items."""
import numpy as np

_state = {"n": 0, "sizes": np.zeros(101, dtype=np.float64), "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1

    # Update running size statistics.
    _state["sizes"][item] += 1.0
    _state["count"] += 1

    residual = bins - item

    # Estimate a target leftover: the residual that best matches a typical future item.
    # Use the running mean of past item sizes, clamped to a sensible range.
    if _state["count"] > 0:
        mean_item = float(np.dot(np.arange(101, dtype=np.float64), _state["sizes"]) / _state["count"])
    else:
        mean_item = 40.0
    target = min(50.0, max(8.0, 0.5 * mean_item))

    # Reward residuals near the target leftover.
    score = -np.abs(residual - target)

    # Strongly reward near-perfect fills (residual 0) -- they close bins cleanly.
    score = np.where(residual == 0, 1000.0, score)

    # Mildly prefer the fullest bin among near-equal residuals to reduce fragmentation.
    score += 0.01 * (100 - residual)

    return score
# EVOLVE-BLOCK-END

