# EVOLVE-BLOCK-START
"""Best-fit with a light stateful bonus for leaving a usable residual."""
import numpy as np


def priority(item, bins):
    """Rank bins: primarily tightest fit, with a small bonus for a usable residual.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Estimate a small "usable" threshold from this item (proxy for future small items).
    # Prefer residuals that are not so tiny they can never be used again.
    residual = bins - item
    # Tightest fit primary: negative residual means smaller residual is better.
    return -residual
# EVOLVE-BLOCK-END

