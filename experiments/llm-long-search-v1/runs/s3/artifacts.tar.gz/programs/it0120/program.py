# EVOLVE-BLOCK-START
"""Best-fit, except prefer leaving a usable (larger) residual when one is available."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity if placed here
    # Threshold: a residual this large or larger is considered "still usable".
    # Mean item size ~40, but many small items exist; use a modest threshold.
    thresh = max(1, item // 4)

    # Bins that (a) are not exact fits, and (b) leave a usable residual.
    # Prefer the largest such residual to keep bins flexible.
    usable = residual >= thresh

    if np.any(usable):
        # Among usable bins, prefer the largest residual (worst-fit within usable).
        # Add a tiny best-fit nudge so near-ties break toward tighter packing.
        score = np.where(usable, residual.astype(float), -np.inf)
        return score

    # Otherwise, fall back to pure best-fit.
    return -(bins - item)
# EVOLVE-BLOCK-END
