# EVOLVE-BLOCK-START
"""Best fit with a small penalty for creating unusable residuals."""
import numpy as np


class _State:
    min_size = 100
    seen = 0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Track a running estimate of the smallest item size seen so far.
    if item < _state.min_size:
        _state.min_size = item
    _state.seen += 1

    res = bins - item  # resulting residual
    # Primary: best fit (smallest resulting residual) -> negative residual.
    score = -res.astype(np.float64)

    # Penalize residuals that are too small to be usable by future items.
    # A residual < min_size is likely dead space; avoid creating it.
    small = res < _state.min_size
    score[small] -= 0.5

    return score
# EVOLVE-BLOCK-END
