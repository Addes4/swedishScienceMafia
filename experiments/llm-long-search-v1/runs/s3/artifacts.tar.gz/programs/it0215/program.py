# EVOLVE-BLOCK-START
"""Distribution-aware best fit with stable online estimates.

Keeps the useful ingredients (seal for near-exact fills, reuse bonus for residuals that
match common item sizes, gentle sliver penalty) but replaces the noisy per-call
percentile/mode recomputation with cheap exponentially-updated estimates of a small-item
target and of common-size frequencies, and leans the base term toward tightest fit."""
import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "target": 20.0,          # EWMA small-item target
    "hist": np.zeros(101, dtype=np.float64),  # EWMA item-size frequency
    "init": False,
}


def priority(item, bins):
    st = _state
    st["n"] += 1
    st["sum"] += item

    # Exponentially-updated item-size frequency estimate (decay then add).
    alpha = 0.01
    st["hist"] *= (1.0 - alpha)
    st["hist"][item] += alpha

    # EWMA small-item target: blend current item with a running small-quantile proxy.
    # Use a modest rate so the target stabilizes quickly.
    if not st["init"]:
        st["target"] = float(item)
        st["init"] = True
    else:
        st["target"] += 0.02 * (float(item) - st["target"])
    target = max(st["target"], 1.0)

    mean = st["sum"] / st["n"]

    residual = bins - item

    # Base: prefer tighter fits (smaller residual), scaled modestly.
    score = -0.15 * residual

    # Anti-sliver: continuous penalty as residual falls below the usable small-item target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.5 * sliver

    # Discourage excessively large residuals to keep bins concentrated.
    score = score - 0.02 * np.clip(residual - mean, 0.0, None)

    # Seal bonus for near-exact fills.
    score = np.where(residual <= 3, 1000.0 - residual, score)

    # Reusability bonus: reward residuals matching a commonly-seen item size.
    frac = st["hist"]
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    score = score + 6.0 * frac[rr] * in_range

    return score
# EVOLVE-BLOCK-END

