# EVOLVE-BLOCK-START
"""Reserve-aware best fit: close bins that can be filled almost exactly (avoid tiny
unusable slivers), otherwise target a moderate residual so bins stay packable, and
penalize residuals that are too small for a typical future item. Thresholds adapt
to the observed distribution of item sizes."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "small_sum": 0.0, "small_cnt": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    if item <= 25:
        _state["small_sum"] += item
        _state["small_cnt"] += 1

    residual = bins - item

    mean_item = _state["sum"] / _state["n"]

    # Preferred leftover: roughly half of a typical item, so a next item can still
    # fit without stranding a tiny sliver.
    target = float(np.clip(mean_item * 0.5, 8.0, 25.0))

    score = -np.abs(residual - target)

    # Estimate a typical small-item size for the sliver threshold.
    if _state["small_cnt"] > 0:
        small_mean = _state["small_sum"] / _state["small_cnt"]
        thr = float(np.clip(small_mean * 0.8, 5.0, 15.0))
    else:
        thr = 8.0

    # Penalize leaving a sliver that only very small future items could use.
    if item > 10:
        score = np.where((residual > 0) & (residual < thr), score - 8.0, score)

    # Strongly reward placements that leave a very small residual: seal the bin.
    score = np.where(residual <= 2, 1000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END

