# EVOLVE-BLOCK-START
"""Best-fit-driven rule with sliver awareness: primary preference for the smallest usable
residual (classic Best-Fit, which packs tightly in practice), softened by a penalty for
leftovers that fall below a typical small future item (wasted slivers), plus a strong seal
bonus for near-exact fills. A running estimate of a low quantile of recent item sizes
determines which residuals are genuinely reusable."""
import numpy as np

_state = {"n": 0, "sum": 0.0,
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item

    # Rolling window of recent items for a local small-quantile estimate.
    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    # Typical "small but common" item size: ~30th percentile of recent items.
    if st["filled"] >= 32:
        target = max(float(np.percentile(r[:st["filled"]], 30)), 1.0)
    else:
        target = max(0.5 * item, 1.0)

    mean = st["sum"] / st["n"]

    residual = bins - item

    # Primary term: classic Best-Fit -> prefer the smallest residual (tightest pack).
    score = -residual.astype(np.float64)

    # Anti-sliver: penalize leftovers below the usable target more than tight-but-usable ones.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.6 * sliver

    # Slight preference against very large residuals (keeps bins concentrated).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Seal bonus: strongly prefer placements that leave a near-exact fill.
    score = np.where(residual <= 3, 1000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END

