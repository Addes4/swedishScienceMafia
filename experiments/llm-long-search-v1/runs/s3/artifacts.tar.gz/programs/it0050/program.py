# EVOLVE-BLOCK-START
"""Distribution-aware best fit: prefer tight fits, but avoid sealing bins with
residuals in a "dead zone" that few future items can fill."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placement (>= 0)

    # Base: tight fit (small residual) is good.
    score = -residual.astype(np.float64)

    # Dead-zone penalty: leaving a small, hard-to-reuse residual is wasteful.
    # Sizes are integers 1..100 from a Weibull-ish distribution (mean ~40);
    # gaps below ~20 are rarely completable, so mildly penalize them.
    dead = (residual > 0) & (residual < 20)
    score[dead] -= 0.5

    # Reward residuals close to a typical item size (~40) so bins stay receptive.
    score -= 0.02 * np.abs(residual.astype(np.float64) - 40.0)

    return score
# EVOLVE-BLOCK-END
