# EVOLVE-BLOCK-START
"""Best-fit with a lookahead informed by a running histogram of item sizes.

Idea: pure best-fit is near-optimal myopically but wastes capacity by leaving tiny
residuals that no future item can use. We keep a cumulative histogram (counts) of the
item sizes seen so far. For each bin, the resulting residual r = remaining - item is
scored both by tightness (we still like small r) and by how likely that residual is to
be reusable by a typical future item. Residuals that are too small to fit many items
are penalized relative to residuals that match common item sizes.
"""
import numpy as np

# running histogram of observed item sizes (index 0..100), module-level state
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0


def _usable(r):
    """Estimate how well a residual r can be reused, from the running histogram.

    We approximate the chance that some future item will fit into r by summing the
    mass of item sizes <= r, weighted so that leaving a residual that exactly matches
    a common item size is rewarded. Small residuals (<=1) are nearly useless.
    """
    if r <= 0:
        return 0.0
    if _TOTAL == 0:
        # no history yet: fall back to a mild prior favoring usable residuals
        return min(r, 40) / 40.0
    # mass of items that could still fit into a bin of residual r
    return float(_HIST[1:r + 1].sum())


def priority(item, bins):
    """Rank bins: prefer usable residuals, breaking ties by tightest fit."""
    global _TOTAL

    # update running histogram with the arriving item (reflects observed distribution)
    if 1 <= item <= 100:
        _HIST[item] += 1.0
    _TOTAL += 1

    residual = bins - item  # what the bin would hold after placing the item (>=0)

    # Usability of each resulting residual (higher is better).
    usable = np.array([_usable(int(r)) for r in residual], dtype=np.float64)

    # Primary: usability. Secondary: tighter fit (smaller residual is better).
    # Combine into one score; tie-break by bin order happens naturally at equal score.
    return usable - 0.001 * residual
# EVOLVE-BLOCK-END
