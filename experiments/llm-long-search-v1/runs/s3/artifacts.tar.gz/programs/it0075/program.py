# EVOLVE-BLOCK-START
"""Best fit with a small stateful nudge toward residuals just below the running mean."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (ties to first bin).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of feasible bins, in bin order.
    """
    rem_after = bins - item
    # state: running mean item size (initialized lazily)
    global _mean, _n
    try:
        _mean, _n
    except NameError:
        _mean, _n = 40.0, 0.0
    _mean = (_mean * _n + item) / (_n + 1.0)
    _n += 1.0

    # Primary: tightest fit (most negative residual). Small bonus for residuals
    # that sit just below the running mean (too small to fit a typical item) so
    # those otherwise-wasted gaps are consumed first.
    target = _mean
    # distance below target, only rewarding residuals in [0, target)
    below = (rem_after >= 0) & (rem_after < target)
    bonus = np.where(below, 1.0 - (target - rem_after) / target, 0.0)
    return -rem_after * 100.0 + bonus
# EVOLVE-BLOCK-END
