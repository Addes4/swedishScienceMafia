# EVOLVE-BLOCK-START
"""Best fit, with ties broken toward the fuller (smaller remaining capacity) bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize residual (best fit) -> negative residual.
    # Tie-break: prefer the bin whose residual is smaller less... i.e. fuller bin.
    # Encode as a single integer score: main term dominates, small term breaks ties.
    return -(residual * 101 + bins)
# EVOLVE-BLOCK-END
