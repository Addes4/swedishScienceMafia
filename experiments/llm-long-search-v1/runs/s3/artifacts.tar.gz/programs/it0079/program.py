# EVOLVE-BLOCK-START
"""Best-fit with a dead-zone-aware tie-break on post-placement residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = np.asarray(bins)
    post = rem - item

    # Smooth running estimate of the typical item size (initialised near the mean ~40).
    state = getattr(priority, "_state", None)
    if state is None:
        state = {"mean": 40.0}
        priority._state = state
    mean = state["mean"]
    state["mean"] = mean + 0.02 * (item - mean)

    # Dead zone: residuals strictly below the typical item size cannot fit a typical item.
    dead = max(1.0, mean)

    # Primary key: tightest fit (smallest post-placement residual) -> larger score better.
    tight = -post

    # Secondary key: among residuals in the dead zone, prefer the largest one so we
    # don't create a useless tiny gap; otherwise neutral.
    in_dead = (post >= 0) & (post < dead)
    bonus = np.where(in_dead, post * 0.5, 0.0)

    return tight + bonus
# EVOLVE-BLOCK-END
