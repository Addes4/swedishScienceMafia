# EVOLVE-BLOCK-START
"""Best fit with a light bonus for avoiding ultra-tight seals."""
import numpy as np


def priority(item, bins):
    """Score bins for best fit, with a mild nudge away from near-zero residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities of fitting bins, in bin order.
    """
    residual = bins - item
    # Base: pure best fit (highest score for smallest residual).
    score = -residual.astype(np.float64)
    # Light bonus for residuals in the small-but-not-dead range, so we do not
    # prematurely seal bins into near-zero leftover that blocks future items.
    bonus = np.where((residual > 0) & (residual < 10), residual * 0.1, 0.0)
    return score + bonus
# EVOLVE-BLOCK-END
