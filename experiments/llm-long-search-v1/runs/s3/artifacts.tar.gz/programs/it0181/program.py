# EVOLVE-BLOCK-START
"""Reserve-aware best fit with an adaptive leftover target: prefer post-placement
residuals close to half the running mean item size (so typical next items still
fit without leaving tiny unusable slivers), and strongly seal bins that end up
nearly full."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    residual = bins - item

    # Preferred leftover after placing: half the running mean item size, so a typical
    # next item can still slot in without leaving a tiny unusable sliver.
    target = min(30.0, max(10.0, 0.5 * mean_item))

    # Base preference: residuals close to the adaptive target leftover.
    score = -np.abs(residual - target)

    # Strongly reward placements that leave a very small residual: these effectively
    # seal a bin and stop it from accumulating unusable slivers of capacity.
    score = np.where(residual <= 2, 1000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END
