# EVOLVE-BLOCK-START
"""Best fit with a near-tie preference for emptier bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base ordering: prefer tightest fit (smallest residual).
    # Secondary: on near-ties (residual within 1 of the best), prefer emptier bins.
    best = residual.min()
    near = residual <= best + 1
    # Score: primary dominates; secondary only breaks near-ties.
    score = -residual.astype(np.float64)
    score += np.where(near, bins.astype(np.float64) * 1e-6, 0.0)
    return score
# EVOLVE-BLOCK-END
