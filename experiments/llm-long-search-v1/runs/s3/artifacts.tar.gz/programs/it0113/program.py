# EVOLVE-BLOCK-START
"""Stateful best-fit with a lookahead bonus based on the observed item-size distribution."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0
_DECAY = 0.9995


def priority(item, bins):
    global _COUNT
    # Update running histogram (decayed to adapt to distribution shifts / early bias).
    if _COUNT > 0:
        _HIST *= _DECAY
        _COUNT *= _DECAY
    _HIST[item] += 1.0
    _COUNT += 1.0

    residual = bins - item  # bins seen here already fit the item (residual >= 0)

    # Probability that the next item exactly fills this residual.
    if _COUNT > 0:
        probs = _HIST / _COUNT
    else:
        probs = np.zeros(101, dtype=np.float64)

    # Exact-fit future probability: P(next size == residual)
    exact = probs[np.clip(residual, 0, 100)]

    # Bonus for residuals that can be filled exactly by some single item size with
    # meaningful mass (i.e., residual is a "friendly" leftover). We approximate by
    # checking whether residual has accumulated notable item mass at that value.
    friendly = probs[np.clip(residual, 0, 100)]

    # Primary: best fit (smallest residual). Secondary: prefer residuals likely to be
    # exactly filled later (avoid tiny unusable leftovers).
    score = -residual.astype(np.float64) + 0.5 * exact + 0.5 * friendly
    return score
# EVOLVE-BLOCK-END
