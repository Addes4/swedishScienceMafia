# EVOLVE-BLOCK-START
"""Distribution-aware best fit with stable target estimation.

Structure that scored well: a strong "seal" bonus for placements leaving a residual <= 3,
plus a reuse bonus rewarding residuals matching commonly-seen item sizes, plus a base
score that prefers residuals near a useful small-item target.

Change: the per-call percentile/mode estimates are noisy and cause jitter. Replace them
with stable exponentially-updated statistics (EWMA of small quantile and a smoothed
histogram), so the target and reuse bonus evolve smoothly. This keeps the reuse behavior
that distinguishes this rule from plain best-fit while removing decision noise.
"""
import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "sm_hist": np.zeros(101, dtype=np.float64),   # exponentially-decayed histogram
    "q_est": 0.0,                                  # EWMA estimate of small-item target
    "init": False,
    "decay": 0.999,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          in bin order (unused bins have remaining capacity 100).
    """
    st = _state
    st["n"] += 1
    st["sum"] += item

    # Stable exponentially-decayed histogram of seen item sizes.
    st["sm_hist"] *= st["decay"]
    st["sm_hist"][item] += 1.0

    # Stable EWMA estimate of a typical "small but common" item size.
    if not st["init"]:
        st["q_est"] = float(item)
        st["init"] = True
    else:
        # slowly drift toward the current item if it is small-ish
        st["q_est"] = 0.998 * st["q_est"] + 0.002 * float(item)

    mean = st["sum"] / st["n"]

    # Target residual: a small item that could still fill it. Use EWMA of small items,
    # floored so it doesn't collapse.
    target = max(st["q_est"], 1.0)

    residual = bins - item

    # Base: prefer residuals near the usable small-item target (monotone-ish, smooth).
    score = -np.abs(residual - target)

    # Anti-sliver: penalize residuals below the usable target (wasted slivers).
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.4 * sliver

    # Mild preference against very large residuals (keeps bins concentrated).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Strong seal bonus: prefer placements leaving a near-exact fill.
    score = np.where(residual <= 3, 1000.0 - residual, score)

    # Reusability bonus: reward residuals that match commonly-seen item sizes.
    hist = st["sm_hist"]
    tot = hist.sum()
    if tot > 0:
        frac = hist / tot
        in_range = (residual >= 0) & (residual <= 100)
        rr = np.where(in_range, residual, 0).astype(np.int64)
        score = score + 8.0 * frac[rr] * in_range

    return score
# EVOLVE-BLOCK-END

