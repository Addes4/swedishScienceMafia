# EVOLVE-BLOCK-START
"""Best fit with a running-statistics tie-break to reduce future fragmentation."""
import numpy as np


class _State:
    def __init__(self):
        # counts of item sizes seen so far (1..100)
        self.sizes = np.zeros(101, dtype=np.int64)
        self.total = 0

    def update(self, item):
        self.sizes[item] += 1
        self.total += 1


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state.update(item)

    residual = bins - item  # >= 0 by construction

    # Tiny tie-break: prefer residuals that are less "useful" for future items.
    # Expected usefulness of a residual r is the expected number of future items of
    # size <= r, i.e. sum_{s<=r} p(s). A smaller usefulness means a better seal.
    s = _state.sizes
    total = _state.total
    if total > 0:
        # cumulative probability that an item fits in residual r
        cum = np.cumsum(s).astype(np.float64) / float(total)
        # For each bin, usefulness = cum[residual] (0 for residual 0, up to ~1 for large)
        r_clipped = np.clip(residual, 0, 100)
        usefulness = cum[r_clipped]
    else:
        usefulness = residual.astype(np.float64) / 100.0

    # Primary: tightest fit (most negative residual is best => score = -residual).
    # Secondary: prefer the least useful residual (small usefulness).
    score = -(residual.astype(np.float64)) - 1e-3 * usefulness
    return score
# EVOLVE-BLOCK-END
