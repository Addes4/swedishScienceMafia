# EVOLVE-BLOCK-START
"""Tight-fill-dominant rule: a dominant monotone best-fit gradient (larger bonus the smaller
the residual) orders placements, with residual 0 dominating outright. Secondary, lightly
scaled terms (usable-leftover target, anti-sliver, and a common-item-size reuse bonus) only
break near-ties among placements with similar residuals, avoiding histogram-noise flips.
A running histogram of item sizes supplies the reuse target."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "hist": np.zeros(101, dtype=np.float64),
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["hist"][item] += 1

    # Rolling window of recent items for a local small-quantile estimate.
    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    if st["filled"] >= 32:
        window = r[:st["filled"]]
        q = np.percentile(window, 35)
    else:
        q = 0.5 * item

    mean = st["sum"] / st["n"]
    target = max(q, 1.0)

    residual = bins - item

    # Dominant monotone best-fit gradient: strongly prefer the smallest residual,
    # smooth in residual so nearby placements stay ordered and stable.
    score = -12.0 * np.abs(residual)

    # Secondary: mildly prefer residuals near the usable small-item target.
    score = score - 1.2 * np.abs(residual - target)

    # Anti-sliver: gently penalize residuals below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.5 * sliver

    # Slight preference against very large residuals.
    score = score - 0.08 * np.clip(residual - mean, 0.0, None)

    # Seal: graded bonus for small residuals, exact fill dominates outright.
    score = score + 2.5 * np.clip(4.0 - residual, 0.0, None)
    score = np.where(residual == 0, score + 100000.0, score)

    # Light reusability bonus for residuals matching common item sizes.
    if st["filled"] >= 32:
        total = float(st["filled"])
        win_counts = np.bincount(r[:st["filled"]], minlength=101).astype(np.float64)
        frac = win_counts / total
        in_range = (residual >= 0) & (residual <= 100)
        rr = np.where(in_range, residual, 0).astype(np.int64)
        score = score + 4.0 * frac[rr] * in_range

    return score
# EVOLVE-BLOCK-END


