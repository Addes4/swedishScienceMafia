# EVOLVE-BLOCK-START
"""Reserve-aware best fit: close bins that can be filled almost exactly (avoid tiny
unusable slivers), otherwise target a moderate residual (about half the running mean
item size) so bins stay packable, and discourage leaving slivers that only very small
future items could use. The anti-sliver threshold adapts to the observed small-item
distribution."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "small": 0, "small_sum": 0.0, "small_cnt": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    # Track statistics of "small" items (<=25) to estimate a typical sliver fill size.
    if item <= 25:
        _state["small"] += 1
        _state["small_sum"] += item
        _state["small_cnt"] += 1

    residual = bins - item

    # Preferred leftover after placing: roughly half the running mean item size, so a
    # typical next item can still slot in without leaving a tiny unusable sliver.
    mean_item = _state["sum"] / _state["n"]
    target = float(np.clip(mean_item * 0.5, 12.0, 25.0))

    # Base preference: residuals close to the target leftover.
    score = -np.abs(residual - target)

    # Anti-sliver penalty: discourage leaving a residual below a threshold that only
    # very small future items could use. Threshold adapts to the observed small-item
    # mean, clamped sensibly; only applied when the arriving item isn't itself small.
    if _state["small_cnt"] > 0:
        small_mean = _state["small_sum"] / _state["small_cnt"]
        thr = float(np.clip(small_mean * 0.8, 5.0, 15.0))
    else:
        thr = 8.0

    if item > 10:
        score = np.where((residual > 0) & (residual < thr), score - 6.0, score)

    # Strongly reward placements that leave a very small residual: these effectively
    # seal a bin and stop it from accumulating unusable slivers of capacity.
    score = np.where(residual <= 2, 1000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END
