# EVOLVE-BLOCK-START
"""Best fit with a learned "reusable residual" target band.

Pure best fit is hard to beat, but it leaves many bins with tiny unusable
residuals.  Here we keep best fit as the primary key (smallest residual after
placing) but, among bins whose resulting residual falls inside a band around
the running mean item size, we slightly prefer the one leaving a residual
closest to that mean.  The correction is strictly below one capacity unit so
an exact best-fit match always wins.
"""
import numpy as np


def priority(item, bins):
    """Rank bins: best fit first, with a sub-unit nudge toward a reusable residual."""
    # running statistics over past items (state kept on the function object)
    st = priority.st
    if st is None:
        st = priority.st = [0.0, 0]  # [sum of sizes, count]
        priority.tgt = None
    st[0] += item
    st[1] += 1
    mean = st[0] / st[1]
    target = mean  # residual we'd like to leave behind

    residual = bins - item            # >= 0 for every bin shown
    base = -residual.astype(np.float64)  # best fit: maximize -residual

    # small bonus for bins whose residual is close to the target band
    bonus = -0.5 * np.minimum(np.abs(residual - target), 1.0) / max(target, 1.0)
    return base + bonus


priority.st = None
# EVOLVE-BLOCK-END
