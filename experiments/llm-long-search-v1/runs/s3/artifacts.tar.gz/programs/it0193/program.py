# EVOLVE-BLOCK-START
"""Distribution-adaptive best fit using an expected-waste model.

For each candidate bin we estimate how much capacity is likely to be wasted after the
current placement.  A leftover is "good" if a typical future item can land in it with
little residual waste.  We approximate this with the running mean item size: reward
residuals that are close to a small multiple of the mean (reusable) and penalize
leftovers that are too small to hold a typical item.  Nearly-exact fills are sealed
strongly so bins get closed out instead of accumulating slivers."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    residual = bins - item

    # Ideal leftover: roughly half a mean item, so the next item tends to close the bin.
    target = 0.5 * mean

    # Base preference: residuals near the target are best (graded, bounded).
    score = -np.abs(residual - target)

    # Anti-sliver: leftovers below a typical item are likely to be wasted.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.5 * sliver

    # Seal bonus: strongly prefer placements that leave a near-exact fill.
    score = np.where(residual <= 2, 1000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END
