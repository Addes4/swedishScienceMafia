# EVOLVE-BLOCK-START
"""Bounded worst-fit / best-fit hybrid for online bin packing."""
import numpy as np


def priority(item, bins):
    """Score each fitting bin; item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    r = bins.astype(np.float64)
    after = r - item  # residual capacity if item placed here

    # Worst-fit tendency: prefer the emptiest fitting bin (largest residual after
    # placement), but weight it so we don't globally abandon tight packing.
    # A mild quadratic tilt keeps behavior close to worst-fit without extremes.
    score = after

    # Guard: strongly discourage leaving a very small residual (wasted bin),
    # i.e. penalize near-dead leftovers slightly less than they'd otherwise rank.
    small = after < 5.0
    score = np.where(small, after - 2.0, score)

    return score
# EVOLVE-BLOCK-END
