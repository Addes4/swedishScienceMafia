# EVOLVE-BLOCK-START
"""Distribution-aware best fit: prefer placements that either nearly seal the bin (residual
close to 0) or leave a leftover matching a common upcoming item size (so the bin stays
reusable). Uses a stable lifetime histogram (with mild forgetting) as the distribution
estimate, avoiding the variance of a short rolling window."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "hist": np.zeros(101, dtype=np.float64),
          "decay_sum": 0.0}

_DECAY = 0.9995  # mild exponential forgetting of old items


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state
    st["n"] += 1
    st["sum"] += item

    # Lifetime histogram with mild exponential forgetting for stability + adaptivity.
    st["hist"] *= _DECAY
    st["hist"][item] += 1.0
    st["decay_sum"] = st["decay_sum"] * _DECAY + 1.0

    mean_all = st["sum"] / st["n"]

    frac = st["hist"] / max(st["decay_sum"], 1.0)

    # Smoothed density for stability (kernel [0.15, 0.7, 0.15]).
    kern = np.array([0.15, 0.7, 0.15])
    smoothed = np.convolve(frac, kern, mode="same")
    smoothed = np.clip(smoothed, 0.0, None)

    # Reusability target from the smoothed distribution (mean of distribution).
    idx = np.arange(101, dtype=np.float64)
    total = float(smoothed.sum())
    if total > 0:
        target = float((smoothed * idx).sum() / total)
    else:
        target = mean_all
    target = max(target, 1.0)

    residual = bins - item

    # Base best-fit gradient: gently prefer smaller usable leftovers.
    score = -0.08 * residual

    # Seal: strong monotone preference toward exact fill; residual 0 dominates.
    score = score + 2.0 * np.clip(4.0 - residual, 0.0, None)
    score = np.where(residual == 0, score + 100000.0, score)

    # Reusability target: leftover close to a typical item size keeps the bin productive.
    score = score - 0.6 * np.abs(residual - target)

    # Anti-sliver: continuous penalty as residual falls below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.5 * sliver

    # Reusability bonus from the stable smoothed histogram.
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse = smoothed[rr] * in_range
    score = score + 18.0 * reuse

    # Extra small peak-match bonus for exact frequent residuals.
    score = score + 4.0 * (frac[rr] * in_range)

    return score
# EVOLVE-BLOCK-END
