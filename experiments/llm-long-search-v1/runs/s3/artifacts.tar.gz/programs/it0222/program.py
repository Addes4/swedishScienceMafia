# EVOLVE-BLOCK-START
"""Best-fit with reuse shaping: prefer the tightest residual (classic best-fit, which is
strong for this Weibull-shaped item distribution), add a bonus when the leftover exactly
matches a commonly-seen item size (so the bin can be tightly refilled later), keep a strong
near-exact seal bonus, and prefer non-empty bins over fresh empty ones."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    # Exponentially decayed histogram keeps recent item sizes relevant without jitter.
    st["hist"] *= 0.999
    st["hist"][item] += 1.0

    residual = bins - item
    in_range = residual >= 0

    # Base: monotone preference for tightest fit (smaller residual is better), like best-fit.
    score = -residual.astype(np.float64)

    # Reuse bonus: reward residuals matching a commonly-seen item size so the bin can be
    # tightly filled later.
    total = st["hist"].sum()
    if total > 0:
        frac = st["hist"] / total
        rr = np.where(in_range, residual, 0).astype(np.int64)
        score = score + 8.0 * frac[rr] * in_range

    # Seal bonus: strongly prefer placements that leave a near-exact fill.
    score = np.where((residual >= 0) & (residual <= 3), 1000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END
