# EVOLVE-BLOCK-START
"""Best fit with an online "just-right pocket" bonus based on recent item sizes."""
import numpy as np

_state = {"n": 0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Online estimate of the typical item size (exponential-ish running mean).
    n = _state["n"]
    m = _state["mean"]
    m = m + (item - m) / (n + 1.0) if n < 200 else 0.995 * m + 0.005 * item
    _state["n"] = n + 1
    _state["mean"] = m

    resid = bins - item  # post-placement residual, >= 0 for fitting bins
    mu = m

    # Primary: prefer tightest fit (smallest residual).
    score = -resid.astype(np.float64)

    # Bonus: pockets whose residual sits near the typical item size are valuable
    # (they will likely be filled well by the next items).
    bonus = np.exp(-((resid - mu) ** 2) / (2.0 * (0.6 * mu + 1.0) ** 2))
    score += 4.0 * bonus

    # Mild penalty for tiny residuals too small to hold a typical item.
    small = resid < mu
    score -= 3.0 * small * (mu - resid) / (mu + 1.0)

    return score
# EVOLVE-BLOCK-END
