# EVOLVE-BLOCK-START
"""Adaptive best-fit variant: tightly fit, but steer toward residuals that match
the empirical leftover distribution, and keep an adaptive mixing weight that
rewards consolidating into already-used bins."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sum = 0.0
        self.alpha = 0.15
        self.hist = np.zeros(101, dtype=np.float64)
        self.last_new = 0

    def update(self, item):
        self.n += 1
        self.sum += item
        self.hist[item] += 1.0
        # adapt alpha slowly toward a value that favors tight residual matching
        mean = self.sum / self.n
        self.alpha = 0.5 * mean / 100.0


_S = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _S.update(item)
    residual = bins - item  # >= 0 for all shown bins

    # Primary: smaller residual is better -> negative residual.
    score = -residual.astype(np.float64)

    # Secondary: reward residuals that are close to typical leftover sizes after
    # placing a mean-sized item, so bins are more likely to be finished cleanly.
    # Typical leftover target is derived from the running mean item size.
    mean = _S.sum / _S.n
    target = mean  # leftover near a mean item size is good (can fit another typical item)
    # penalty grows with distance from target, scaled by alpha
    score -= _S.alpha * np.abs(residual - target)

    return score
# EVOLVE-BLOCK-END
