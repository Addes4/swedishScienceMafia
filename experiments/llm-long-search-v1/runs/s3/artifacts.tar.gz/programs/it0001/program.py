# EVOLVE-BLOCK-START
"""Hybrid: best fit for small items, balanced-fit for larger ones."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: the bin it fits most tightly (smallest remaining capacity).
    best_fit = -(bins - item)

    # Balanced fit for larger items: prefer bins whose remaining capacity after
    # placement is close to a target leftover, reducing waste from mixed sizes.
    target = 100 - item
    balanced = -np.abs(bins - item - target)

    if item >= 30:
        # Blend: strongly prefer tight fits but discourage leaving large gaps.
        return best_fit + 0.15 * balanced
    return best_fit
# EVOLVE-BLOCK-END
