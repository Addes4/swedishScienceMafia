# EVOLVE-BLOCK-START
"""Best-fit-style bin choice with a strong exact-fill seal and a reusability bonus.

Core idea: prefer the tightest fit (smallest leftover) so bins get closed off, but keep
a residual magnitude that still matches common small item sizes productive. A running
estimate of the recent item distribution supplies the reusability signal, and an exact
fill is strictly dominant.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0,
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0,
          "recent_hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item

    # Rolling window of recent items for a local size-distribution estimate.
    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        old = r[st["ptr"]]
        st["recent_hist"][old] -= 1
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size
    st["recent_hist"][item] += 1

    mean = st["sum"] / st["n"]

    residual = bins - item

    # Best-fit core: strongly prefer the smallest leftover (tightest fit).
    score = -2.0 * residual

    # Anti-sliver: discourage tiny unusable leftovers a bit, so we don't waste bins
    # that could still absorb a small item. Sliver threshold ~ the running mean's scale.
    sliver = np.clip(4.0 - residual, 0.0, None)
    score = score - 0.6 * sliver

    # Exact-fill seal: residual 0 strictly dominates everything else.
    score = np.where(residual == 0, score + 100000.0, score)

    # Reusability bonus: reward residuals whose value is a common recent item size,
    # smoothed so the signal is stable.
    total_recent = float(max(st["filled"], 1))
    frac = st["recent_hist"] / total_recent
    kern = np.array([0.25, 0.5, 0.25])
    smoothed = np.convolve(frac, kern, mode="same")
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse = smoothed[rr] * in_range
    score = score + 8.0 * reuse

    return score
# EVOLVE-BLOCK-END
