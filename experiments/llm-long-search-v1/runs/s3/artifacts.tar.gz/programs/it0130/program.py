# EVOLVE-BLOCK-START
"""Best fit with a stateful tie-break that reduces unusably small residuals."""
import numpy as np

_state = {"count": 0, "sum": 0.0, "median": 40.0, "sizes": []}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Stateful running estimate of the typical item size (approx median via sample).
    s = _state
    s["count"] += 1
    s["sum"] += item
    sizes = s["sizes"]
    sizes.append(item)
    if len(sizes) > 200:
        del sizes[0]
    if len(sizes) >= 8:
        med = float(np.median(sizes))
    else:
        med = s["sum"] / s["count"]
    s["median"] = med

    # Primary: best fit (smallest residual).
    score = -residual.astype(np.float64)

    # Tiny tie-break: prefer residuals close to a typical item size, so leftover
    # space stays usable rather than fragmenting into tiny slivers.
    target = med
    score += 0.01 * (-np.abs(residual - target))

    return score
# EVOLVE-BLOCK-END
