# EVOLVE-BLOCK-START
"""Best fit with a dead-zone penalty: avoid sealing bins with tiny residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # leftover after placing the item

    score = -residual.astype(np.float64)

    # Penalize residuals so small that few items can ever fill them,
    # making the bin effectively dead. This nudges items toward bins
    # whose leftover can still host a typical (~40) future item.
    dead = residual < 10
    score -= 5.0 * dead

    # Very mild pull of residuals toward a typical item size.
    score -= 0.05 * np.abs(residual - 40)

    return score
# EVOLVE-BLOCK-END
