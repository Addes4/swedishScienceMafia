# EVOLVE-BLOCK-START
"""Distribution-aware best fit: score each placement by how close the leftover lands to a
typical *small* future item (so the bin can still be reused productively), with a strong
seal bonus for near-exact fills and for residuals matching common item sizes. Uses a stable
exponentially-decayed estimate of small item sizes to decide which residuals are genuinely
useful rather than wasted slivers."""
import numpy as np

_state = {"n": 0, "sum": 0.0,
          "decay_hist": np.zeros(101, dtype=np.float64),
          "decay_frac": np.zeros(101, dtype=np.float64),
          "weight": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item

    # Stable exponentially-decayed frequency estimate of item sizes.
    alpha = 0.999
    dh = st["decay_hist"]
    dh *= alpha
    dh[item] += 1.0
    st["weight"] = st["weight"] * alpha + 1.0

    frac = st["decay_frac"]
    frac[:] = dh / st["weight"]

    # Estimate a typical "small but common" item size as the median of the lower portion
    # of the decayed distribution (quantile via cumulative mass).
    cum = np.cumsum(frac)
    q = int(np.searchsorted(cum, 0.35))
    if q < 1:
        q = 1
    mean = st["sum"] / st["n"]

    target = max(float(q), 1.0)

    residual = bins - item

    # Base: prefer residuals near the small-item target (usable leftovers).
    score = -np.abs(residual - target)

    # Anti-sliver: penalty grows continuously as the residual falls below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.4 * sliver

    # Slight preference against very large residuals (keeps bins concentrated / best-fit-like).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Seal bonus: strongly prefer placements that leave a near-exact fill.
    score = np.where(residual <= 3, 1000.0 - residual, score)

    # Reusability bonus: reward residuals that exactly match a commonly-seen item size,
    # since such a leftover can be tightly filled later. Use graded decayed frequency.
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    score = score + 12.0 * frac[rr] * in_range

    return score
# EVOLVE-BLOCK-END

