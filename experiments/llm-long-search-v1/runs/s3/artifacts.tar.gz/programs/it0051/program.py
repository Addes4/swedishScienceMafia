import numpy as np


def priority(item, bins):
    # Histogram of item sizes seen so far (1..100). Laplace-smoothed.
    hist = getattr(priority, "_hist", None)
    if hist is None:
        hist = np.ones(101, dtype=np.float64)
    total = hist.sum()

    # Score each bin: prefer tight fits (like best-fit), but give a bonus for
    # residuals that the size distribution is likely to fill later.
    resid = bins - item  # remaining capacity after placing item here

    # Probability that a future item fits into the resulting residual, weighted
    # by how much probability mass sits at or below that residual.
    cdf = np.cumsum(hist) / total  # cdf[r] ~ P(next item <= r)

    # Tight fit dominates; bonus nudges ties toward "fillable" residuals.
    # Deduct a penalty for residuals in a low-occupancy gap region.
    fill_prob = cdf[np.clip(resid, 0, 100)]

    score = -(resid) + 4.0 * fill_prob

    # Update histogram with the observed item.
    hist[item] += 1
    priority._hist = hist

    return score
