# EVOLVE-BLOCK-START
"""Adaptive gap-aware best fit.

Plain best fit leaves residuals scattered across many bins, which wastes space when
future items do not exactly fit those residuals.  We bias the choice toward
placements whose leftover residual is close to a running estimate of a typical
arriving item size, so that residuals stay usable.  Tightest-fit remains the
dominant term so we never trail plain best fit much.
"""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    # Running mean of observed item sizes (adaptive typical item).
    _state["sum"] += float(item)
    _state["count"] += 1
    mean = _state["sum"] / _state["count"]

    # Post-placement residual for each candidate bin.
    residual = bins - item  # >= 0 since harness only shows fitting bins

    # Base tightest fit: prefer small residual (larger -(residual)).
    primary = -(residual.astype(np.float64))

    # Target leftover: ideally leave a residual near the typical mean item size,
    # so the bin remains "primed" for a future average item.
    tgt = max(1.0, mean)
    # Penalty grows with distance of residual from the target; weight kept small
    # so tightest fit dominates.
    secondary = -np.abs(residual.astype(np.float64) - tgt) * 0.01

    return primary + secondary
# EVOLVE-BLOCK-END
