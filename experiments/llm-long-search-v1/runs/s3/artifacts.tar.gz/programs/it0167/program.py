# EVOLVE-BLOCK-START
"""Best fit with tolerance-based ordering: prefer tight fits, break near-ties by fill level."""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for bins the item fits in
    # Prefer exactly-fitting residuals; then prefer bins with the smallest residual
    # but with a coarse tie-break granularity so that near-equal fits consolidate.
    # Score: primarily tight residual, with a small secondary bonus for fuller bins.
    score = -residual.astype(np.float64)
    # Secondary term: slight preference for bins that are already more filled
    # (smaller pre-existing residual => larger remaining after placement is bad,
    #  so we add a tiny bonus to the tightest bins via small epsilon on residual).
    score = score - 1e-3 * bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END

