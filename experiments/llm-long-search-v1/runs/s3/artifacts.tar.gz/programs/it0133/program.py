# EVOLVE-BLOCK-START
"""Best fit with a stateful tie-breaker that protects usable residuals.

The primary key is classic best-fit: place the item in the bin leaving the smallest
residual.  Ties (and near-ties) are broken using a running histogram of the item sizes
seen so far: among bins whose residual is essentially tied, we prefer the bin whose
resulting residual corresponds to a rare upcoming item size, keeping bins that a common
future item could still fill intact.  The state is only ever used for tie-breaking, so
the rule degenerates to pure best-fit on decisive placements.
"""
import numpy as np

# running histogram state over item sizes 1..100
_counts = np.zeros(101, dtype=np.float64)
_total = 0.0
_median = 40.0

# epsilon: how close residuals must be to count as "tied"
_EPS = 2.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (ties to first)."""
    global _total, _median

    # --- update running statistics with the arriving item ---
    if 1 <= item <= 100:
        _counts[item] += 1.0
    _total += 1.0

    # --- primary key: negative residual (best-fit) ---
    resid = bins - item

    # rarity of a residual r: how (un)likely a future item of size r is.
    # Small count -> rare -> we prefer not to "waste" the bin on it?  No: we prefer
    # to keep bins whose residual matches a *common* future item, so we place into
    # bins whose resulting residual is *rare* (hard to fill later).
    idx = np.clip(resid, 0, 100).astype(np.int64)
    prob = _counts[idx]

    best = resid.min()
    # near-tie mask around the best residual
    near = (resid <= best + _EPS)

    # among near-ties, lower future-fill probability is better (rarer) -> give a bonus
    rare_bonus = np.where(near, -prob, 0.0)

    # score: best-fit dominates, rarity only perturbs within the tie band
    return -resid.astype(np.float64) + rare_bonus
# EVOLVE-BLOCK-END

