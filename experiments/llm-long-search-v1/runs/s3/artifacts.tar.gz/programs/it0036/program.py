# EVOLVE-BLOCK-START
"""Best fit with a bonus for sealing a bin exactly full."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    score = -residual.astype(np.float64)
    # Strong bonus for placements that leave the bin exactly full: no wasted
    # fragment, and the bin can never accept another item anyway.
    score += (residual == 0) * 0.5
    return score
# EVOLVE-BLOCK-END
