# EVOLVE-BLOCK-START
"""Best fit with a mild bias toward keeping open bins usable."""
import numpy as np


def priority(item, bins):
    """Return a priority per bin; highest score wins (first on ties)."""
    # primary: tightest fit (best fit)
    score = -(bins - item)
    return score
# EVOLVE-BLOCK-END
