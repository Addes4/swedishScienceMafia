# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and lower-index tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties go to first.

    Primary key: minimize post-placement residual after the item is placed
    (best fit). Exact fills get a large extra bonus so they are always chosen.
    """
    residual = bins - item
    # Most negative residual (tightest fit) should score highest -> negate.
    score = -residual.astype(np.float64)
    # Bonus for exact fill.
    score += (residual == 0) * 1000.0
    return score
# EVOLVE-BLOCK-END
