# EVOLVE-BLOCK-START
"""Best fit with a mild anti-fragmentation tie-break on residual capacity."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary goal: leave as little room as possible (best fit).
    # Secondary: mildly reward residuals near the item size so that the leftover
    # space tends to be usable by a similarly sized item later (less fragmentation).
    secondary = -np.abs(residual - item) * 0.001
    return -residual + secondary
# EVOLVE-BLOCK-END
