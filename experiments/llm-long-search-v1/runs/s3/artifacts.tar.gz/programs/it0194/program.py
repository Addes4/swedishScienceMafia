# EVOLVE-BLOCK-START
"""Distribution-adaptive best fit with two-sided residual quality.

We grade each placement by how useful the leftover capacity will be for the next
arriving item. A leftover is ideal when it is close to a typical item size (so the
next item nearly seals the bin). Leftovers that are too small to ever fit another
item are penalized (wasted capacity), and moderately large leftovers are gently
preferred over tiny slivers. We also strongly reward near-exact fills.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0, "small_sum": 0.0, "small_n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    # Track a rough "small item" scale: items below the mean feed a separate average.
    if item < mean:
        _state["small_sum"] += item
        _state["small_n"] += 1
    small = _state["small_sum"] / _state["small_n"] if _state["small_n"] else 0.5 * mean

    residual = bins - item

    # Ideal leftover: roughly a small-to-moderate item, so the next item can nearly fill it.
    target = max(1.0, small)

    # Base preference: residuals near the target are best (tight and usable).
    score = -np.abs(residual - target)

    # Penalize tiny slivers: leftover too small to fit a typical small item is wasted.
    waste = np.clip(small - residual, 0.0, None)
    score = score - 0.6 * waste

    # Gently penalize leftovers much larger than a typical item (they stay half-empty):
    # this nudges toward tighter placements than the target.
    excess = np.clip(residual - mean, 0.0, None)
    score = score - 0.15 * excess

    # Seal bonus: strongly prefer placements that leave a near-exact fill, and also
    # reward a residual that the smallest likely next item can no longer use.
    seal = np.where(residual <= 2, 1000.0 - residual,
                    np.where(residual < small, 2.0 * (small - residual), 0.0))
    score = score + seal

    return score
# EVOLVE-BLOCK-END
