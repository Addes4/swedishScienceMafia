# EVOLVE-BLOCK-START
"""Randomized best-fit: pick uniformly among near-tightest bins."""
import numpy as np


_rng = np.random.default_rng(123456789)
_MARGIN = 2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    rmin = residual.min()
    # Near-tightest bins get a random preference; others ranked strictly by residual.
    near = residual <= rmin + _MARGIN
    keys = _rng.random(bins.shape[0])
    # For near bins: score in (0, 1) random. For others: strongly negative based on residual.
    score = np.where(near, keys, -1.0 - residual)
    return score
# EVOLVE-BLOCK-END
