# EVOLVE-BLOCK-START
"""Best fit with a stateful tie-break: among equally tight fits, fill the fullest bin first."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best fit dominates: smaller residual after placement is better.
    # Secondary: among equal residuals, prefer the bin with larger current residual
    # (less filled), which keeps tightly-packed bins available for large future items.
    return -residual * 1000.0 + bins
# EVOLVE-BLOCK-END

