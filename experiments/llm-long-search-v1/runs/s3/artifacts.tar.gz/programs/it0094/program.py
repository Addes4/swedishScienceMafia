# EVOLVE-BLOCK-START
"""Best fit with a stateful, distribution-aware tie-break on near-minimal residuals."""
import numpy as np

# State kept between calls: running histogram of item sizes (last ~16 seen).
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    global _hist, _count
    # Update a light exponential moving histogram of observed sizes.
    _hist *= 0.98
    _hist[item] += 1.0
    _count = _count * 0.98 + 1.0

    h = _hist / max(_count, 1e-9)  # normalized size distribution estimate

    residuals = bins - item  # new residual after placing item in each bin
    best = residuals.min()
    # Bins whose residual is at/near the minimum are the real candidates.
    tol = 0.0
    mask = residuals <= best + tol

    # Prefer exact fills above all.
    exact = residuals == 0
    if exact.any():
        scores = np.where(exact, 1.0, -1e9) - 1e-6 * residuals
        return scores

    # Among near-minimal residuals, prefer the residual whose expected
    # usefulness is high: residual r accepts future items of size <= r.
    # Usefulness ~ probability that a future item fits (i.e. is <= r).
    # Build cumulative distribution of observed sizes.
    cdf = np.cumsum(h)  # cdf[r] ~ P(size <= r)
    useful = cdf[np.clip(residuals, 0, 100).astype(np.int64)]

    # Base best-fit as primary key; small usefulness bonus for tie-breaking.
    # Dominant term: smaller residual better. Secondary: higher usefulness.
    scores = -residuals * 1.0 + useful * 0.5
    return scores
# EVOLVE-BLOCK-END
