# EVOLVE-BLOCK-START
"""Best fit with a small "useful residual" tie-break.

Place the item in the bin that leaves the smallest residual (best fit).  When two
bins leave nearly the same residual, prefer the one whose residual after this
placement is close to a typical incoming item size, since such a residual is more
likely to be fully used by a future item than an awkward in-between value.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all shown bins

    # Running estimate of a typical item size.  Tracked in module state.
    state = priority.state
    n = state["n"]
    s = state["sum"]
    # Weibull-ish mean ~40; blend observed mean with a prior.
    typical = (s + 40.0 * 50.0) / (n + 50.0)

    # Best-fit term dominates: smaller residual -> higher score.
    base = -residual.astype(np.float64)

    # Tiny secondary term: reward residuals close to `typical`.
    near = -np.abs(residual - typical) * 0.02

    # Update running stats.
    state["n"] = n + 1
    state["sum"] = s + item

    return base + near


priority.state = {"n": 0, "sum": 0.0}
# EVOLVE-BLOCK-END

