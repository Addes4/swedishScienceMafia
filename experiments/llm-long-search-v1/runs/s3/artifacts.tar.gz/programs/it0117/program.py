# EVOLVE-BLOCK-START
"""Best fit with an exact-fit-first priority."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Exact fits (residual == 0) get an overwhelmingly high score;
    # otherwise fall back to standard best fit (smallest residual).
    return -(residual) + 1e6 * (residual == 0)
# EVOLVE-BLOCK-END

