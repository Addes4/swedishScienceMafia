# EVOLVE-BLOCK-START
"""Harmonic-style bin scoring: penalize residuals that cross the classic
Harmonic capacity thresholds less than residuals that leave "dead" space."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    Uses a harmonic (harmonic-bin-packing style) penalty on the resulting
    remaining capacity. Residual capacities that fall just below a harmonic
    threshold (100/k) are penalized heavily, since such leftovers can only
    hold relatively few future item sizes.
    """
    rem = bins - item  # resulting remaining capacity after placing
    # Harmonic thresholds: 100/1, 100/2, ..., 100/8
    # We rank placements so that a smaller "waste class" is preferred.
    # Score: primary best-fit tie, but strongly avoid crossing into a
    # strictly worse harmonic class unless the fit is much tighter.
    score = -rem.astype(np.float64)
    # Add a small harmonic-class bonus: residuals that stay >= 100/k for
    # larger k are more flexible; approximate via log of remainder.
    # Prefer residuals that are "large-ish" within their class.
    score += 0.5 * np.log1p(rem)
    return score
# EVOLVE-BLOCK-END

