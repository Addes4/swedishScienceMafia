# EVOLVE-BLOCK-START
"""Best fit with a small stateful bonus favoring residuals that are near a
multiple of the running mean item size (reduces residual fragmentation)."""
import numpy as np


def priority(item, bins):
    # --- state ---
    if not hasattr(priority, "n"):
        priority.n = 0
        priority.total = 0.0

    priority.n += 1
    priority.total += item
    mean = priority.total / priority.n

    residual = bins - item

    # Primary key: tightest fit (min residual). Secondary: sub-unit bonus if
    # residual is close to a multiple of the running mean item size.
    if mean > 0:
        frac = np.mod(residual, mean)
        dist = np.minimum(frac, mean - frac)  # distance to nearest multiple
        bonus = 1.0 - dist / mean             # in [0, 1]
    else:
        bonus = np.zeros_like(residual, dtype=float)

    return -residual + 0.01 * bonus
# EVOLVE-BLOCK-END
