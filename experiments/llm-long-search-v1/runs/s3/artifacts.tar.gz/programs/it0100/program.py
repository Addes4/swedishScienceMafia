# EVOLVE-BLOCK-START
"""Best fit with a stateful dead-zone-aware tie-break.

Primary rule: best fit (place item in the bin it fits most tightly, i.e. the smallest
non-negative residual after placement). This is a strong, robust rule for this problem.

Secondary refinement: maintain a running estimate of the smallest "common" item size
observed so far (a low quantile of the item-size histogram). If the best-fit placement
would leave a residual in a "dead zone" (strictly positive but smaller than the smallest
common item size, hence unlikely ever to be filled again), penalize that bin slightly and
prefer the candidate whose resulting residual is either zero (perfect fill) or at least the
smallest common item size. This nudges the rule away from creating tiny unusable gaps
without giving up the strong best-fit baseline.
"""
import numpy as np

# Running histogram of past item sizes (1..100). Kept across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def _small_common_size():
    """Estimate the smallest item size that occurs with meaningful frequency."""
    total = _HIST.sum()
    if total < 50:
        return 1.0
    # Find the 8th-percentile-ish size: the smallest size whose cumulative
    # share reaches ~8% of items, but at least the minimum seen with count > 0.
    cum = np.cumsum(_HIST)
    target = 0.08 * total
    idx = int(np.searchsorted(cum, target))
    idx = min(max(idx, 1), 100)
    # never below the actual observed minimum "common" size
    nz = np.nonzero(_HIST)[0]
    if nz.size:
        idx = max(idx, int(nz[0]))
    return float(idx)


def priority(item, bins):
    """Return a priority per bin; highest wins, ties to first."""
    global _COUNT
    _HIST[item] += 1.0
    _COUNT += 1

    # Best-fit base score: tighter fit (smaller residual) is better.
    residual = bins - item  # all >= 0 since bins only include fitting bins
    base = -residual.astype(np.float64)

    if _COUNT < 50:
        return base

    small = _small_common_size()
    # Dead zone: positive residual that is too small to accept a common item.
    dead = (residual > 0) & (residual < small)
    # Perfect fill bonus and fillable-residual bonus.
    perfect = residual == 0
    fillable = residual >= small

    score = base.copy()
    # Penalize dead-zone placements so a fillable alternative can win.
    score[dead] -= 0.5
    # Small bonus for perfect fills (keeps best-fit priority intact).
    score[perfect] += 0.25
    score[fillable] += 0.01
    return score
# EVOLVE-BLOCK-END
