# EVOLVE-BLOCK-START
"""Distribution-aware best fit: score each placement by how close the leftover lands to a
typical *small* future item (so the bin can still be reused productively), with a strong
seal bonus for near-exact fills and for residuals matching common item sizes. The target is
a stable exponentially-updated estimate (rather than a per-call percentile) so decisions do
not jitter, and the reuse bonus uses a smoothed histogram."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "hist": np.zeros(101, dtype=np.float64),
          "target": 0.0, "init": False}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item

    # Exponentially-updated histogram of item sizes (fast, stable).
    h = st["hist"]
    h *= 0.995
    h[item] += 1.0
    hsum = h.sum()

    # Stable estimate of a "small but common" item size: weighted mean of sizes below the
    # overall mean, i.e. the typical leftover that a smaller future item can fill exactly.
    mean = st["sum"] / st["n"]
    small_h = h.copy()
    small_h[int(mean) + 1:] = 0.0
    shsum = small_h.sum()
    if shsum > 1e-9:
        sizes = np.arange(101, dtype=np.float64)
        q_target = float((sizes * small_h).sum() / shsum)
    else:
        q_target = 0.5 * mean

    # Smooth adaptation of the target toward q_target.
    if not st["init"]:
        st["target"] = q_target
        st["init"] = True
    else:
        st["target"] = 0.97 * st["target"] + 0.03 * q_target
    target = max(st["target"], 1.0)

    residual = bins - item

    # Base: prefer residuals near the small-item target (usable leftovers).
    score = -np.abs(residual - target)

    # Anti-sliver: penalty grows continuously as the residual falls below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.4 * sliver

    # Slight preference against very large residuals (keeps bins concentrated / best-fit-like).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Seal bonus: strongly prefer placements that leave a near-exact fill.
    score = np.where(residual <= 3, 1000.0 - residual, score)

    # Reusability bonus: reward residuals that match a commonly-seen item size (smoothed),
    # since such a leftover can be tightly filled later.
    if hsum > 1e-9:
        frac = h / hsum
        in_range = (residual >= 0) & (residual <= 100)
        rr = np.where(in_range, residual, 0).astype(np.int64)
        # smooth with neighbors to reduce jitter
        smooth = frac.copy()
        smooth[1:] += 0.5 * frac[:-1]
        smooth[:-1] += 0.5 * frac[1:]
        score = score + 8.0 * smooth[rr] * in_range

    return score
# EVOLVE-BLOCK-END
