# EVOLVE-BLOCK-START
"""Distribution-aware best fit: score each placement by how close the leftover lands to a
typical *small* future item (so the bin can still be reused productively), with a strong
seal bonus for near-exact fills and for residuals matching common item sizes. Uses a running
estimate of item sizes to decide which residuals are genuinely useful rather than wasted
slivers, plus a complement-pairing term so a leftover closely matches likely future items."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "small_hist": np.zeros(101, dtype=np.float64),
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0,
          "full_hist": np.zeros(101, dtype=np.float64),
          "recent_hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["small_hist"][item] += 1
    st["full_hist"][item] += 1

    # Rolling window of recent items for a local small-quantile estimate.
    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        old = r[st["ptr"]]
        st["recent_hist"][old] -= 1
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size
    st["recent_hist"][item] += 1

    # Estimate a typical "small but common" item size as the ~35th percentile of recent items.
    if st["filled"] >= 32:
        window = r[:st["filled"]]
        q = np.percentile(window, 35)
        counts = np.bincount(window, minlength=101)
        small_counts = counts.copy()
        small_counts[int(q) + 1:] = 0
        mode_small = int(np.argmax(small_counts))
    else:
        q = 0.5 * item
        mode_small = int(round(q))

    mean = st["sum"] / st["n"]
    target = max(q, 1.0)

    residual = bins - item

    # Base: prefer residuals near the small-item target (usable leftovers).
    score = -np.abs(residual - target)

    # Anti-sliver: penalty grows continuously as the residual falls below the usable target.
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.4 * sliver

    # Slight preference against very large residuals (keeps bins concentrated / best-fit-like).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Seal: strong monotone preference toward exact fill. Residual 0 strictly dominates.
    score = score + 50.0 * np.clip(3.0 - residual, 0.0, None)
    score = np.where(residual == 0, score + 100000.0, score)

    # Reusability bonus: reward residuals whose value sits on / near a frequently-seen item
    # size in the RECENT window history, smoothed over a small window so the signal is stable.
    total_recent = float(max(st["filled"], 1))
    frac = st["recent_hist"] / total_recent
    kern = np.array([0.2, 0.35, 0.5, 0.35, 0.2])
    kern = kern / kern.sum()
    smoothed = np.convolve(frac, kern, mode="same")
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse = smoothed[rr] * in_range
    score = score + 16.0 * reuse

    # Complement pairing: reward residuals that are close to a value that, combined with
    # the current item size, would neatly close a bin (residual ~ a future partner size).
    # Also give a gentle bonus for residuals equal to (100 - item) region so pairs seal.
    L = 100
    # small extra term: prefer residual matching a plausible next partner derived from item
    partner = np.clip(L - item, 0, 100)
    score = score + 6.0 * smoothed[np.clip(residual.astype(np.int64), 0, 100)] * in_range

    return score
# EVOLVE-BLOCK-END

