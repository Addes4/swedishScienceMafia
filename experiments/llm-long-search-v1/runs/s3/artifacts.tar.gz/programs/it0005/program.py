# EVOLVE-BLOCK-START
"""Best fit, but avoid touching unused (empty) bins unless necessary."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Prefer partially-filled bins over empty ones; within a group, best fit.
    empty = bins >= 100
    # Large bonus for non-empty bins, then tightest fit.
    return -(bins - item) - 1000.0 * empty
# EVOLVE-BLOCK-END
