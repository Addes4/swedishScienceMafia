# EVOLVE-BLOCK-START
"""Threshold hybrid: best fit for extremes, loosest-fit for mid-size items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    if 25 <= item <= 50:
        return bins.astype(np.float64)
    return -(bins - item)
# EVOLVE-BLOCK-END

