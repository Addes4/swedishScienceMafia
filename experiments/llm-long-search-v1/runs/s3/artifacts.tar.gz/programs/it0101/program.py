# EVOLVE-BLOCK-START
"""Best-fit with a dead-zone-aware tie-break using a running item-size estimate."""
import numpy as np

_state = {"sizes": None, "count": 0}


def _typical():
    s = _state["sizes"]
    if s is None or _state["count"] < 50:
        return 40
    # running median via sampling to stay cheap
    arr = np.asarray(s, dtype=np.int64)
    if arr.size > 256:
        step = arr.size // 256
        arr = arr[::step]
    return int(np.median(arr))


def priority(item, bins):
    """Best fit, but prefer bins whose residual after placement is 0 or large enough
    to accept a typical future item (avoid tiny dead-zone residuals)."""
    # record observed item size
    if _state["sizes"] is None:
        _state["sizes"] = []
    if len(_state["sizes"]) < 1000:
        _state["sizes"].append(item)
    _state["count"] += 1

    residual = bins - item  # how much would remain after placing item here
    # primary: minimize residual (best fit)
    best = -(residual.astype(np.float64))
    # dead zone: residual in (0, typical) is bad -> small penalty; 0 is ideal
    t = _typical()
    # normalize penalty so it only breaks ties within equal-residual groups
    dead = (residual > 0) & (residual < t)
    penalty = np.where(dead, 0.5, 0.0)
    # also mildly favor residual >= t over residual == 0? No: exact fill is best.
    return best - penalty
# EVOLVE-BLOCK-END
