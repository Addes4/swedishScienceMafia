# EVOLVE-BLOCK-START
"""Best-fit with a small worst-fit component to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best-fit: prefer smallest residual. Small bonus for emptier bins (worst-fit flavor)
    # to keep some bins nearly empty for future large items.
    return -(residual) + 0.15 * bins
# EVOLVE-BLOCK-END
