# EVOLVE-BLOCK-START
"""Best fit with a mildly convex residual penalty (still tightest-fit dominated)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since only fitting bins are shown
    # Primary: tightest residual. Secondary: gently penalize large residuals
    # (empty bins) so items naturally consolidate into already-used bins,
    # while preserving the exact ordering that best-fit produces for the
    # decisive small residuals.
    return -residual - 0.02 * residual * residual
# EVOLVE-BLOCK-END
