# EVOLVE-BLOCK-START
"""Best-fit core with reuse-aware tie-breaking.

The dominant signal for this distribution is pure best-fit (smallest residual), which has
near-optimal behavior. On top of that we add a small bonus for residuals that match common
item sizes (so the leftover can be tightly refilled later), and a strong seal bonus for
near-exact fills. All shaping is deliberately small relative to the best-fit ordering so it
only breaks near-ties rather than overriding tightest-fit.
"""
import numpy as np

_state = {"counts": np.zeros(101, dtype=np.float64), "seen": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["seen"] += 1
    st["counts"][item] += 1.0

    residual = bins - item  # >= 0 for all bins shown

    # Base: best-fit — the smaller the residual, the higher the score.
    # Use a strictly decreasing function so tightest fit always dominates when residuals differ.
    score = -residual.astype(np.float64)

    # Reuse bonus: reward residuals matching common item sizes, so the leftover can be
    # refilled tightly later. Kept small so it only breaks near-ties, never overrides best-fit.
    if st["seen"] >= 64:
        frac = st["counts"] / st["seen"]
        rr = np.clip(residual, 0, 100).astype(np.int64)
        score = score + 0.05 * frac[rr]

    # Seal bonus: strongly prefer placements leaving a near-exact fill.
    score = np.where(residual <= 2, 500.0 - residual.astype(np.float64), score)

    return score
# EVOLVE-BLOCK-END
