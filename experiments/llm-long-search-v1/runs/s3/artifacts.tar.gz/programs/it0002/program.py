# EVOLVE-BLOCK-START
"""Best fit with a residual-capacity preference to avoid bad gaps."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # leftover capacity if placed here
    # Primary: tighter fit (smaller residual). Secondary: prefer leaving room near mean item size (~40).
    return -(residual * 1000.0) - np.abs(residual - 40) * 0.001
# EVOLVE-BLOCK-END
