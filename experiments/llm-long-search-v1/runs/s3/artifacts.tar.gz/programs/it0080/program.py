# EVOLVE-BLOCK-START
"""Worst-fit-discouraging best-fit with bin-filling pressure.

Primary key: tightest fit (smallest post-placement residual), which is a strong
online heuristic. Secondary key: among bins with similar residuals, prefer the
bin that was already the fullest (largest item placed, i.e. smallest remaining
capacity before placement) so that partially filled bins get completed before
fresh bins are opened. This fights the fragmentation that pure best-fit leaves
behind, without abandoning its tight packing.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    # Post-placement residual: smaller is a tighter fit.
    residual = bins - item
    # bins before placement: smaller remaining capacity => bin already fuller.
    # Secondary objective: prefer already-fuller bins in near-tie situations.
    # Combine: tightest fit dominates; being already-fuller acts as tiebreak.
    return -(residual * 1000 + bins)
# EVOLVE-BLOCK-END
