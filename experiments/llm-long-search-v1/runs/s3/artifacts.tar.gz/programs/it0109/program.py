# EVOLVE-BLOCK-START
"""Best-fit with a tie-break that avoids leaving unusable tiny residuals."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sum = 0.0
        # running threshold for "small" items, ~10th percentile estimate
        self.thresh = 12.0

    def update(self, item):
        self.n += 1
        self.sum += item
        if self.n % 25 == 0:
            mean = self.sum / self.n
            # rough small-item threshold as a fraction of mean
            self.thresh = max(6.0, min(20.0, 0.30 * mean))


_state = _State()


def priority(item, bins):
    """Rank bins: best-fit tightness first, but prefer residuals that stay usable."""
    _state.update(item)
    rem = bins - item  # remaining capacity after placing the item here
    thresh = _state.thresh

    # exact fit gets top priority
    exact = (rem == 0)

    # residual is "usable" if it is 0 or at least the small-item threshold
    usable = (rem == 0) | (rem >= thresh)

    # Primary: usable beats unusable. Secondary: tighter fit (smaller rem) within group.
    # Score: large bonus for usable, then best-fit (-rem).
    score = -rem.astype(np.float64)
    score += np.where(usable, 1000.0, 0.0)
    score += np.where(exact, 5000.0, 0.0)
    return score
# EVOLVE-BLOCK-END
