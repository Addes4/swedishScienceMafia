# EVOLVE-BLOCK-START
"""Distribution-aware best fit: prefer the tightest usable leftover (best-fit-like), with a
strong seal for near-exact fills and a scale-stable reusability bonus that rewards residuals
matching common recent item sizes (so a future item can close the bin exactly)."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "small_hist": np.zeros(101, dtype=np.float64),
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0,
          "full_hist": np.zeros(101, dtype=np.float64),
          "recent_hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["small_hist"][item] += 1
    st["full_hist"][item] += 1

    # Rolling window of recent items.
    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        old = r[st["ptr"]]
        st["recent_hist"][old] -= 1
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size
    st["recent_hist"][item] += 1

    # Typical small-but-common item size from the recent window.
    if st["filled"] >= 32:
        window = r[:st["filled"]]
        q = np.percentile(window, 35)
    else:
        q = 0.5 * item

    target = max(q, 1.0)
    mean = st["sum"] / st["n"]

    residual = bins - item

    # Best-fit gradient: strongly prefer the tightest nonzero usable leftover.
    score = -np.abs(residual - target)
    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.4 * sliver
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Seal: monotone preference toward exact fill.
    score = score + 50.0 * np.clip(3.0 - residual, 0.0, None)
    score = np.where(residual == 0, score + 100000.0, score)

    # Reusability bonus: residuals matching common recent item sizes, scale-normalized by peak.
    frac = st["recent_hist"]
    peak = float(frac.max()) if frac.max() > 0 else 1.0
    kern = np.array([0.25, 0.5, 0.25])
    smoothed = np.convolve(frac, kern, mode="same") / peak
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse = smoothed[rr] * in_range
    score = score + 6.0 * reuse

    return score
# EVOLVE-BLOCK-END
