# EVOLVE-BLOCK-START
"""Best fit with a sub-unit tie-breaker on near-optimal residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for bins the item fits in
    # Strict best-fit ordering: smaller residual is better.
    base = -residual.astype(np.float64)
    # Sub-unit tie-breaker (bounded strictly below 1.0): prefer residuals that are
    # "round" (multiples of 5), which tend to be more reusable by later items.
    r = residual
    bonus = np.where(r % 5 == 0, 0.5, 0.0)
    return base + bonus
# EVOLVE-BLOCK-END
