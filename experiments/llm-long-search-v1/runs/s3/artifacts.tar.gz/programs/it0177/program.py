# EVOLVE-BLOCK-START
"""Reserve-aware best fit: strong perfect-fit bonus, otherwise target a small
adaptive residual derived from the running mean item size (clamped)."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities for fitting bins (unused = 100).
    """
    _state["n"] += 1
    _state["sum"] += item

    mean = _state["sum"] / _state["n"]

    # Small leftover target: a fraction of the running mean, clamped to a modest range.
    target = 0.5 * mean
    if target < 8.0:
        target = 8.0
    elif target > 25.0:
        target = 25.0

    residual = bins - item

    # Reward residuals close to the target leftover.
    score = -np.abs(residual - target)

    # Perfect fills dominate: closes a bin cleanly.
    score = np.where(residual == 0, 1000.0, score)

    return score
# EVOLVE-BLOCK-END
