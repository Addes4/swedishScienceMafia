# EVOLVE-BLOCK-START
"""Worst-fit toward the typical item size: keep residuals near the running mean."""
import numpy as np

_state = {"count": 0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running mean of item sizes.
    c = _state["count"]
    m = _state["mean"]
    m = (m * c + float(item)) / (c + 1)
    _state["count"] = c + 1
    _state["mean"] = m

    residual = bins - item  # >= 0 for all bins shown (item fits in each)

    # Target residual: leave roughly one typical item's worth of room so a
    # future average-sized item can still use this bin.
    target = m

    # Prefer residuals closest to the target; break ties toward the tightest
    # fit (smaller residual) so we don't waste large bins.
    score = -np.abs(residual - target) * 1000.0 - residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
