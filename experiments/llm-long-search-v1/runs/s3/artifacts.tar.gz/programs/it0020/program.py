# EVOLVE-BLOCK-START
"""Almost-best-fit: tightest fit, but avoid leaving tiny unusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: tightest fit (smallest residual is best).
    score = -residual.astype(np.float64)
    # Penalize residuals that are too small to be useful but larger than zero,
    # i.e. wasted slack in the 1..6 range. This nudges placements away from
    # producing dead leftovers while keeping best-fit dominant.
    waste = (residual > 0) & (residual < 7)
    score = score - 0.25 * waste
    return score
# EVOLVE-BLOCK-END
