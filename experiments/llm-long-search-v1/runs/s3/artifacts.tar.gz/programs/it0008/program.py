# EVOLVE-BLOCK-START
"""Best fit enhanced with a reusable-gap tie-break based on an online size histogram."""
import numpy as np

# Global state: histogram of observed item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first.

    Primary objective: best fit (smallest residual after placement).
    Tie-break: prefer residuals that are common future item sizes
    (by an exponentially-updated histogram of seen items), so leftover
    space is more likely to be reusable and fragmentation is reduced.
    """
    global _hist, _total

    # Update histogram with the arriving item (before scoring).
    _hist[item] += 1.0
    _total += 1.0

    # Normalized histogram gives probability mass of each size.
    # A tiny epsilon keeps unused bins slightly preferred only on exact ties.
    p = _hist / _total

    residual = bins - item            # >= 0 for fitting bins
    # Primary: best fit -> smaller residual is better, so negate.
    prim = -(residual.astype(np.float64))

    # Secondary: how reusable is the leftover capacity.
    # Reward residuals that are likely to be filled by a future item.
    reuse = p[np.clip(residual, 0, 100)]

    # Combine: primary dominates; reuse only breaks near-ties.
    return prim + 0.01 * reuse
# EVOLVE-BLOCK-END
