# EVOLVE-BLOCK-START
"""Best fit with a weak reusable-leftover bonus from a running item-size histogram."""
import numpy as np

_SIZE = 101
_hist = np.zeros(_SIZE, dtype=np.float64)
_seen = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _seen
    # decay old statistics so the histogram tracks the distribution without being static
    if _seen > 0:
        _hist *= 0.999
    _hist[item] += 1.0
    _seen += 1.0

    resid = bins - item  # capacity left after placing item

    # best-fit primary term: strongly prefer tightest fit
    score = -resid.astype(np.float64)

    # weak bonus for residual capacities that have historically been common item sizes,
    # so the leftover space is likely to be usable by a future item
    bonus = _hist[np.clip(resid, 0, 100)]
    score = score + 1e-3 * bonus

    return score
# EVOLVE-BLOCK-END
