# EVOLVE-BLOCK-START
"""Best fit with a small preference among near-ties for higher remaining capacity."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tighter fit (smaller residual). Secondary: among bins within a small
    # window of the best residual, prefer the one with the most remaining capacity
    # (i.e. least loaded), which keeps bins flexible and reduces fragmentation.
    best = residual.min()
    score = -(residual) * 1000.0
    # small bonus to bins whose residual is within window of the best
    window = 4
    near = residual <= best + window
    score = score + near * bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
