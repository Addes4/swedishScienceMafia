# EVOLVE-BLOCK-START
"""Best fit with harmonic-style small-residual avoidance."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since item fits
    # Base: minimize residual (best fit).
    base = -residual.astype(np.float64)
    # Slight preference to keep a fully empty bin empty when fits elsewhere,
    # but best fit already avoids empty bins. Add a tiny bias: among equal
    # residuals, prefer the bin that was already fuller (smaller original bins).
    # Use a minuscule secondary term so primary best-fit ordering is preserved.
    secondary = -0.001 * bins.astype(np.float64)
    return base + secondary
# EVOLVE-BLOCK-END
