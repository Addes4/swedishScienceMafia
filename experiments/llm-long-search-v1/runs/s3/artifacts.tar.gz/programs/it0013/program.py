# EVOLVE-BLOCK-START
"""Best fit with an exact-fit bonus and a small-sliver avoidance term."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item  # leftover capacity after placing the item
    score = -resid.astype(np.float64)  # primary: tightest fit (smallest residual)

    # Strongly prefer an exact fit (residual 0).
    score += (resid == 0) * 1000.0

    # Mildly avoid leaving tiny unusable slivers (1..2) when other options exist.
    score -= ((resid >= 1) & (resid <= 2)) * 0.5

    return score
# EVOLVE-BLOCK-END
