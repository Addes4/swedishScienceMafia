# EVOLVE-BLOCK-START
"""Stateful best-fit with a residual gate: avoid leaving tiny unusable gaps."""
import numpy as np

_state = {"sizes": [], "sum": 0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running statistics of observed items.
    _state["sizes"].append(item)
    _state["sum"] += item
    _state["n"] += 1
    mean_item = _state["sum"] / _state["n"]
    # Expected number of items fit into a bin of capacity 100.
    items_per_bin = 100.0 / mean_item
    # A residual below this threshold is considered "wasted" (too small to be useful).
    gate = mean_item / items_per_bin  # = mean_item^2 / 100, small residual threshold

    residual = bins - item  # resulting remaining capacity if placed here

    # Best-fit score: strongly prefer small non-negative residual.
    score = -residual.astype(np.float64)

    # Identify the best-fit bin residual.
    best_res = residual.min()

    # If the tightest bin would leave a residual below the gate, try to avoid it:
    # prefer the *most full* bin whose residual is still >= gate (i.e. still reusable),
    # which tends to preserve larger usable gaps.
    if best_res < gate:
        good = residual >= gate
        if good.any():
            # Among "good" bins, prefer smallest residual (best fit among them).
            scores_good = np.where(good, -residual.astype(np.float64), -1e18)
            return scores_good

    return score
# EVOLVE-BLOCK-END

