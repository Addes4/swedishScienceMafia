# EVOLVE-BLOCK-START
"""Stateful best-fit with residual-usefulness tie-breaking derived from observed item sizes."""
import numpy as np


class _State:
    counts = np.zeros(101, dtype=np.int64)  # histogram of item sizes seen
    total = 0

    # cache of "useful" residuals: values likely fillable by future items
    useful = None
    useful_version = -1


def _update_useful(state):
    """Recompute the set of useful residuals from the observed size distribution."""
    if state.total < 50:
        state.useful = None
        return
    counts = state.counts
    total = state.total
    # common item sizes: those with decent frequency
    thresh = max(1, total // 200)
    common = np.nonzero(counts >= thresh)[0]
    common = common[common >= 1]
    if common.size == 0:
        state.useful = None
        return
    common = np.sort(common)
    # reachable subset-sums up to 100 using common sizes (bounded knapsack)
    reachable = np.zeros(101, dtype=bool)
    reachable[0] = True
    for s in common:
        if s > 100:
            continue
        # unbounded-ish: allow many copies (cap at 100//s)
        for _ in range(100 // s):
            shifted = reachable.copy()
            if s < 101:
                reachable[s:] |= shifted[:-s]
        if reachable.all():
            break
    state.useful = reachable
    state.useful_version = total


def priority(item, bins):
    state = _State
    state.counts[item] += 1
    state.total += 1
    if state.useful is None or state.total - state.useful_version >= 25:
        _update_useful(state)

    residual = bins - item  # what remains after placing the item (>= 0 for shown bins)
    # primary: best fit = smallest residual
    # secondary: prefer residual 0, then residual that is "useful" (fillable), then larger residual
    is_zero = (residual == 0)
    if state.useful is not None:
        is_useful = state.useful[np.clip(residual, 0, 100)]
    else:
        is_useful = np.zeros(residual.shape, dtype=bool)

    # score: we want to MAXIMIZE. Build lexicographic-ish score.
    # base: -residual (best fit: smaller residual -> higher)
    score = -residual.astype(np.float64)
    # reward exact fit strongly
    score += is_zero * 0.4
    # reward leaving a fillable residual (avoid dead-zone residuals)
    score += is_useful * 0.2
    return score
# EVOLVE-BLOCK-END
