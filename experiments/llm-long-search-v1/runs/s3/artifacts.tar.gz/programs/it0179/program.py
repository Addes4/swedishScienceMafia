# EVOLVE-BLOCK-START
"""Reserve-aware best fit: close bins whose residual is tiny (near-perfect fills),
otherwise fall back to tight best-fit so bins are packed densely and small residuals
accumulate as little wasted capacity."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Fallback: tight best-fit, slightly favoring smaller residuals but with a gentle
    # slope so it stays distinct from the strong bonus below.
    score = -residual.astype(np.float64) * 1.0

    # Strongly reward placements leaving a very small residual: these effectively
    # seal a bin and stop it from accumulating unusable slivers.
    score = np.where(residual <= 2, 100000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END

