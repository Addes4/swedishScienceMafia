# EVOLVE-BLOCK-START
"""Best-fit with a reusable-residual dead zone.

The base rule is essentially best-fit: among bins the item fits in, prefer the tightest
residual. Two shapings make it distribution-aware: a "dead zone" around common small item
sizes (so a leftover that a typical item can fill exactly is not penalized as if it were a
tightest fit), and a strong seal bonus for near-exact fills. Reuse frequency of each residual
value is tracked with a cheap exponentially-updated histogram, avoiding per-call sorts.
"""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.float64),
          "seen": 0.0}


def priority(item, bins):
    st = _state

    # Exponentially-updated histogram of item sizes (decay keeps it local, cheap to update).
    st["hist"] *= 0.995
    st["hist"][item] += 1.0
    st["seen"] = st["seen"] * 0.995 + 1.0

    hist = st["hist"]
    total = st["seen"]
    if total > 1e-9:
        frac = hist / total
    else:
        frac = np.zeros(101, dtype=np.float64)

    mean = float(np.dot(np.arange(101), hist)) / max(total, 1e-9)

    residual = bins - item

    # Base: best fit — smaller residual is better.
    score = -residual.astype(np.float64)

    # Dead zone: residuals close to a common item size are effectively as good as a
    # tightest fit (they can be exactly refilled later), so pull their score up.
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse = frac[rr]
    score = score + 3.0 * reuse

    # Anti-sliver: don't leave a tiny unusable leftover when a bigger, reusable one is
    # available — but only mildly, so best-fit dominance is preserved.
    sliver = np.clip(2.0 - residual, 0.0, None)
    score = score - 1.5 * sliver

    # Avoid very large residuals (keeps bins concentrated rather than scattering).
    score = score - 0.15 * np.clip(residual - 2.0 * mean, 0.0, None)

    # Strong seal: near-exact fills dominate everything else.
    score = np.where(residual <= 3, 1000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END
