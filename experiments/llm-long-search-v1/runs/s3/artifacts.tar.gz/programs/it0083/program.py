# EVOLVE-BLOCK-START
"""Best fit with a stateful tie-break that keeps residuals usable."""
import numpy as np


class _State:
    def __init__(self):
        self.sizes = []


_state = _State()


def priority(item, bins):
    """Rank bins: tightest fit first, then prefer residuals that stay usable.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin that fits the item, in bin order.
    """
    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item

    # Track observed item sizes for a lightweight percentile estimate.
    sizes = _state.sizes
    sizes.append(int(item))
    n = len(sizes)
    if n > 256:
        # Keep a bounded window.
        del sizes[:n - 256]
        n = 256
    # 10th percentile of recent items (lower bound on "typical small" items).
    small_cut = int(np.percentile(sizes, 10)) if n >= 8 else 1

    # Primary: tightest fit (smallest non-negative residual).
    # Secondary: prefer residuals that are either 0 or at least small_cut,
    # avoiding a "dead zone" of tiny unusable gaps.
    dead = (residual > 0) & (residual < small_cut)
    # Score: highest is best. Encode tightness then dead-zone avoidance.
    score = -residual.astype(np.float64) * 100.0 - dead.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
