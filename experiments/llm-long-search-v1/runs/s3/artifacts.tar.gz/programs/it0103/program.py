# EVOLVE-BLOCK-START
"""Best fit with a tiny histogram-based tie-break among near-equal residuals."""
import numpy as np


def _hist_update(hist, item):
    hist[item] += 1


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    Primary: tightest fit (smallest remaining capacity after placing item).
    Tie-break (within 1 unit of the best residual): prefer residual that is
    more likely to accept a future common item size, estimated from a running
    histogram of observed item sizes.
    """
    if not hasattr(priority, "hist"):
        priority.hist = np.zeros(101, dtype=np.float64)
        priority.total = 0

    hist = priority.hist

    residual = bins - item  # remaining capacity after placing here
    # primary score: prefer smaller residual (more negative -> higher)
    score = -residual.astype(np.float64)

    # estimate fill probability for a residual r: P(next common item <= r)
    # i.e. warm fuzz of the residual to be fillable.
    total = priority.total
    if total > 0:
        cum = np.cumsum(hist) / total  # cum[r] = prob item <= r
        cum = np.concatenate(([0.0], cum))  # index by residual 0..100
        r = residual
        r_clipped = np.clip(r, 0, 100)
        fill_prob = cum[r_clipped]
        # tiny weight so it only breaks near-ties (residuals within ~1)
        score += 1e-3 * fill_prob

    _hist_update(hist, item)
    priority.total += 1

    return score
# EVOLVE-BLOCK-END
