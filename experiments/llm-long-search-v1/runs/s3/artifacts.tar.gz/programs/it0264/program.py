# EVOLVE-BLOCK-START
"""Best-fit core blended with a distribution-aware complementary-fit reserve.

The base rule prefers the fullest bin the item fits into (pure best-fit, which minimizes
open bins). On top of that we reward residuals that match a *frequently seen* item size,
so the leftover is likely to be exactly closed later by a single item. A mild penalty
discourages rare "orphan" residuals that are unlikely to be reusable."""
import numpy as np

_state = {"n": 0, "hist": np.zeros(101, dtype=np.float64),
          "kern": np.array([0.25, 0.5, 0.25])}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    st = _state
    st["n"] += 1
    st["hist"][item] += 1

    residual = bins - item

    # Base: best-fit gradient -- strongly prefer the fullest bin that still fits.
    # (smaller residual => higher score)
    score = -1.0 * residual

    # Exact fill strictly dominates everything else.
    score = np.where(residual == 0, score + 100000.0, score)

    # Complementary-fit: reward residuals equal to (or near) a common item size, since a
    # later item of that size can perfectly close this bin.
    total = float(st["n"])
    frac = st["hist"] / total
    smoothed = np.convolve(frac, st["kern"], mode="same")

    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    match = smoothed[rr] * in_range
    # Normalize to keep this term on a comparable scale to the best-fit gradient.
    maxf = smoothed.max()
    if maxf > 0:
        match = match / maxf
    score = score + 6.0 * match

    # Mild anti-orphan: penalize small residuals that are rarely seen as item sizes
    # (likely permanent slivers).
    orphan = np.where(in_range, np.maximum(0.0, 4.0 - residual), 0.0)
    score = score - 0.3 * orphan * (1.0 - match)

    return score
# EVOLVE-BLOCK-END
