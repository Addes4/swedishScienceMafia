# EVOLVE-BLOCK-START
"""Best fit with a mild preference against leaving very small residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary key: tightest fit (smallest residual).  Shifted so all values are positive,
    # then we add a sub-unit bonus that prefers avoiding tiny unusable leftovers.
    primary = (100 - residual)  # larger = tighter fit
    # Penalize residuals in the "dead zone" 1..20 (too small for most items to be reused).
    dead = (residual >= 1) & (residual <= 20)
    bonus = np.where(dead, 0.0, 0.5 * (residual >= 0))
    return primary + bonus
# EVOLVE-BLOCK-END
