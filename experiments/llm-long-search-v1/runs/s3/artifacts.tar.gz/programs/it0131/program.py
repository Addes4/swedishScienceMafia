# EVOLVE-BLOCK-START
"""Best fit with a small reserve-aware tie-break bonus."""
import numpy as np


class _State:
    n = 0
    s = 0.0


def priority(item, bins):
    st = _State
    # running mean of item sizes (adaptive target reserve)
    st.n += 1
    st.s += item
    mean = st.s / st.n

    residual = bins - item  # capacity left after placing item here
    # Primary: best fit (smallest residual). Secondary: prefer residual near mean.
    # Scale secondary tiny so it only breaks near-ties.
    bonus = -np.abs(residual - mean) * 1e-3
    return -(residual) + bonus
# EVOLVE-BLOCK-END
