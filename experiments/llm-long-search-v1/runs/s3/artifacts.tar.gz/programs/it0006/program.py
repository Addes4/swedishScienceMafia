# EVOLVE-BLOCK-START
"""Best fit with a soft penalty for unusable small residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by tightest fit, softly penalizing residuals too small for small items."""
    residual = bins - item
    # Penalize residuals that are smaller than a small item threshold (e.g., 1..10),
    # but only mildly, so tight fits are still strongly preferred.
    small = (residual > 0) & (residual < 10)
    penalty = np.where(small, (10 - residual) * 0.05, 0.0)
    # Prefer the smallest residual (most negative residual -> highest score), with penalty.
    return -(residual + penalty)
# EVOLVE-BLOCK-END
