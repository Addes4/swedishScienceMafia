# EVOLVE-BLOCK-START
"""Best fit with residual-fillability scoring driven by an online item-size histogram."""
import numpy as np

# Running histogram over item sizes 1..100, shared across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0
# Also track total to form probabilities lazily.

def priority(item, bins):
    global _HIST, _COUNT
    # Update the running histogram (probability that a future item <= size).
    _HIST[item] += 1.0
    _COUNT += 1.0

    res = bins - item  # resulting residual capacity for each bin

    # Probability that a uniformly drawn past item size is <= r, i.e. an item can fit
    # in residual r (approximately). Bigger r => more of the distribution fits.
    # Compute via cumulative sums over the histogram.
    csum = np.cumsum(_HIST)  # csum[r] = count of items with size <= r
    if _COUNT > 0:
        probs = csum / _COUNT
    else:
        probs = np.zeros_like(csum)

    r = res.astype(np.int64)
    np.clip(r, 0, 100, out=r)
    fill = probs[r]  # prob a random future item fits in the residual

    # Also add small value for actually reducing residual (finish bins off).
    # Primary: prefer high fill probability of resulting residual; tie-break by tightest fit.
    return fill * 1e6 - res
# EVOLVE-BLOCK-END
