# EVOLVE-BLOCK-START
"""Best-fit with sliver awareness.

Base rule is monotone best-fit: the smallest residual gets the highest score, which is
the classic strong greedy for bin packing. A continuous anti-sliver term mildly devalues
residuals too small to fit a typical future item, and a large seal bonus rewards
near-exact fills. A running low-quantile estimate of recent item sizes defines "usable".
"""
import numpy as np

_state = {"n": 0, "sum": 0.0, "small_hist": np.zeros(101, dtype=np.float64),
          "recent": np.zeros(256, dtype=np.int64), "ptr": 0, "filled": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["small_hist"][item] += 1

    # Rolling window of recent items for a local small-quantile estimate.
    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    # Estimate a typical "small but common" item size as the ~25th percentile of recent items.
    if st["filled"] >= 32:
        q = np.percentile(r[:st["filled"]], 25)
    else:
        q = 0.5 * item

    # Smallest item size we plausibly expect to still fit into a leftover.
    usable = max(q, 1.0)

    residual = bins - item

    # Pure best-fit: smaller residual is better.
    score = -residual.astype(np.float64)

    # Anti-sliver: mildly devalue residuals that cannot hold a typically small future item.
    sliver = np.clip(usable - residual, 0.0, None)
    score = score - 0.5 * sliver

    # Seal bonus: strongly prefer placements that leave a near-exact fill.
    score = np.where(residual <= 2, 1000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END
