# EVOLVE-BLOCK-START
"""Best-fit tuned by reuse potential: keep the symmetric distance-to-a-small-target base
(which empirically beats pure best-fit for this distribution), but replace noisy windowed
histogram bonuses with a smoothly-decaying reuse bonus keyed to a couple of running estimates
of dominant item sizes, plus a tapered near-exact seal."""
import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "recent": np.zeros(256, dtype=np.int64),
    "ptr": 0,
    "filled": 0,
    "atom1": 0.0,   # running estimate of dominant small item size
    "atom2": 0.0,   # running estimate of dominant larger item size
    "w": 0.0,       # weight ramp
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _state
    st["n"] += 1
    st["sum"] += item

    r = st["recent"]
    if st["filled"] < r.size:
        r[st["filled"]] = item
        st["filled"] += 1
    else:
        r[st["ptr"]] = item
        st["ptr"] = (st["ptr"] + 1) % r.size

    # Decayed running estimates of dominant item sizes via two independent EMAs that are
    # nudged toward items on opposite sides of the middle, approximating the two modes.
    a = 0.02
    if item <= 45:
        st["atom1"] = (1.0 - a) * st["atom1"] + a * item
    else:
        st["atom2"] = (1.0 - a) * st["atom2"] + a * item

    if st["filled"] >= 32:
        window = r[:st["filled"]]
        q = float(np.percentile(window, 35))
    else:
        q = 0.5 * item
    target = max(q, 1.0)
    mean = st["sum"] / st["n"]

    residual = bins - item

    # Base: prefer residuals near the small-item target (usable leftovers).
    score = -np.abs(residual - target)

    # Anti-sliver: penalty grows continuously as the residual falls below the usable target.
    score = score - 0.4 * np.clip(target - residual, 0.0, None)

    # Slight preference against very large residuals (keeps bins concentrated).
    score = score - 0.05 * np.clip(residual - mean, 0.0, None)

    # Seal bonus: strongly prefer placements that leave a near-exact fill, tapered by residual.
    score = np.where(residual <= 3, 1000.0 - residual, score)

    # Smooth reuse bonus: reward residuals that match a dominant item size, with a Gaussian
    # taper so nearby residuals also benefit slightly (no hard cliffs).
    if st["filled"] >= 32:
        w = st["w"] = st["w"] + 1.0
        if st["atom1"] > 0.5:
            score = score + 8.0 * np.exp(-0.5 * ((residual - st["atom1"]) / 1.5) ** 2)
        if st["atom2"] > 0.5:
            score = score + 4.0 * np.exp(-0.5 * ((residual - st["atom2"]) / 2.0) ** 2)

    return score
# EVOLVE-BLOCK-END
