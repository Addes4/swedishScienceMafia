# EVOLVE-BLOCK-START
"""Best fit with a small adaptive reserve: prefer tight fits, but avoid
leaving very small, likely-unusable residuals when a bin is nearly full.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in order.
    """
    # Post-placement residual for each bin.
    resid = bins - item

    # Primary key: prefer the tightest fit (smallest residual).
    score = -resid.astype(np.float64)

    # Secondary structural nudge: when the tightest fit leaves a small residual,
    # bins with a slightly larger residual are nearly as good and may avoid
    # stranding an unusable gap. Penalize very small residuals relative to the
    # item size modestly, staying well below one residual unit.
    tiny = (resid >= 0) & (resid < item)
    # Fraction of item size the residual represents; smaller residual -> more
    # likely unusable, so subtract a tiny amount to prefer the next best fit.
    frac = np.where(tiny, resid.astype(np.float64) / max(item, 1), 1.0)
    score -= 0.05 * (1.0 - frac) * tiny

    return score
# EVOLVE-BLOCK-END
