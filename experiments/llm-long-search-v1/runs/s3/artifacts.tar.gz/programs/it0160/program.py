# EVOLVE-BLOCK-START
"""Best fit with a tie-break that prefers residuals exactly completable by common future items."""
import numpy as np

_HIST = None
_SIZES = None
_BONUS = None
_CALL = 0


def _rebuild(hist):
    """Build a sorted list of item sizes with nonzero observed counts and small knapsack tables."""
    global _SIZES, _BONUS
    _SIZES = [s for s in range(1, 101) if hist[s] > 0]
    # Precompute, for each residual 0..100, whether it can be formed as a subset sum of
    # the observed sizes (unbounded small multiset, capped at a modest depth).
    reach = [False] * 101
    reach[0] = True
    for _ in range(3):  # up to 3 items combine (enough for meaningful completions)
        nr = reach[:]
        for r in range(101):
            if reach[r]:
                for s in _SIZES:
                    v = r + s
                    if v <= 100:
                        nr[v] = True
        reach = nr
    _BONUS = [1.0 if reach[r] else 0.0 for r in range(101)]


def priority(item, bins):
    """Best fit, with a tiny bonus for bins whose residual is exactly completable."""
    global _HIST, _CALL
    if _HIST is None:
        _HIST = [0] * 101
        _rebuild(_HIST)
    else:
        _CALL += 1
        if _CALL % 25 == 0:
            _rebuild(_HIST)
    _HIST[item] += 1

    residual = bins - item
    # dominant term: smaller residual after placement is better (best fit)
    score = -residual.astype(np.float64)
    # tiny tie-breaker: prefer residuals that are exactly completable by common sizes
    bonus = np.array([_BONUS[int(r)] for r in residual], dtype=np.float64)
    return score + 1e-3 * bonus
# EVOLVE-BLOCK-END
