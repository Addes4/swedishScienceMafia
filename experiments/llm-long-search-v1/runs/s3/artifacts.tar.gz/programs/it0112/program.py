# EVOLVE-BLOCK-START
"""Best-fit with a mild convex reshaping that rewards exact fits and avoids tiny unusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Base: prefer tightest fit.
    score = -residual.astype(np.float64)
    # Reward exact fits strongly.
    score += np.where(residual == 0, 1000.0, 0.0)
    # Mild convex lift so that awkward tiny residuals lose to larger useful residuals,
    # while still keeping the tightest-fit ordering among "reasonable" residuals.
    score += 0.5 * np.log1p(residual.astype(np.float64))
    return score
# EVOLVE-BLOCK-END
