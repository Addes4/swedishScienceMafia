# EVOLVE-BLOCK-START
"""Stable best-fit-decreasing-like online rule.

The distribution is Weibull-shaped with mean ~40, so a robust way to pack well online is
"best fit": always drop an item into the fullest bin it still fits in (minimum non-negative
residual). Pure best-fit leaks capacity via untouchable slivers, so we add a smooth
dead-zone: residuals that equal a typical *future small item* size are treated as nearly as
good as a perfect fill, because they can be reused tightly later. All statistics are kept
with cheap exponentially-updated counters (no per-call percentile/bincount)."""
import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    # Exponentially decayed histogram of item sizes, kept as a float array of length 101.
    "hist": np.zeros(101, dtype=np.float64),
    "decay": 0.995,
    "w": 0.0,
}


def priority(item, bins):
    """Return a priority per bin; highest wins, ties to first.

    item: integer size 1..100.
    bins: numpy int64 remaining capacities (item fits) in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item

    # Exponentially-updated item histogram.
    hist = st["hist"] * st["decay"]
    hist[item] += 1.0
    st["hist"] = hist
    st["w"] = st["w"] * st["decay"] + 1.0

    mean = st["sum"] / st["n"]

    residual = bins - item  # >= 0 for all bins shown

    # Core best-fit: prefer the smallest usable residual. Symmetric, smooth.
    # Use a negative magnitude so smaller residual -> higher score.
    score = -residual.astype(np.float64)

    # Dead-zone smoothing: a residual near the expected next-item size (mean) can be
    # filled tightly later, so nudge those bins up relative to their neighbors. This
    # reduces the harm of leaving mid-size slivers under strict best-fit.
    gap = np.abs(residual - mean)
    score = score + 6.0 * np.exp(-gap / 8.0)

    # Seal bonus: near-exact fills are very valuable.
    score = np.where(residual <= 3, 1000.0 - residual, score)

    # Reuse bonus: residuals that exactly match a commonly-seen item size are highly
    # reusable; scale by the (normalized) frequency of that size in the running histogram.
    if st["w"] > 1.0:
        freq = st["hist"] / st["w"]
        rr = np.where((residual >= 1) & (residual <= 100), residual, 0).astype(np.int64)
        in_range = (residual >= 1) & (residual <= 100)
        score = score + 5.0 * freq[rr] * in_range

    return score
# EVOLVE-BLOCK-END
