# EVOLVE-BLOCK-START
"""Hybrid best-fit / worst-fit driven by a running estimate of the item size."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Rank bins by fit; item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    s = _state
    s["n"] += 1
    s["sum"] += item
    mu = s["sum"] / s["n"]

    residual = bins - item  # remaining capacity after placing the item here

    # Small items relative to the running mean: prefer to leave big holes intact,
    # so we favor the fullest bin among those that still fit well (worst-fit-ish),
    # which avoids opening new bins and keeps large free spaces available.
    if item < mu:
        # primary: minimize residual (best fit), secondary: prefer larger pre-capacity
        # among near-tight candidates via a small additive term on bins capacity.
        return -(residual).astype(np.float64) + 1e-3 * bins
    else:
        return -(residual).astype(np.float64)
# EVOLVE-BLOCK-END

