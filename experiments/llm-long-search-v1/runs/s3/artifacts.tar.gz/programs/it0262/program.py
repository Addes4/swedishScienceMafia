# EVOLVE-BLOCK-START
"""Best-fit with anti-sliver reserve: prefer placing the item into the fullest bin that can
take it (smallest residual), which concentrates packing and minimizes the number of open
bins. Exact fills dominate; a mild penalty discourages leaving unusably tiny slivers, and a
weak reusability bonus rewards residuals whose size is a common future item size."""
import numpy as np

_state = {"n": 0, "full_hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["full_hist"][item] += 1

    residual = bins - item
    n = float(st["n"])

    # Core: best-fit. Smaller residual => higher score. This concentrates packing.
    score = -residual.astype(np.float64)

    # Mild anti-sliver: discourage leaving a tiny unusable leftover (residual 1..3).
    score = score - 0.3 * np.clip(4.0 - residual, 0.0, None)

    # Exact fill strictly dominates.
    score = np.where(residual == 0, score + 100000.0, score)

    # Weak reusability bonus: reward residuals matching frequent past item sizes, so the
    # leftover is likely to be consumed exactly by a single future item.
    frac = st["full_hist"] / n
    kern = np.array([0.25, 0.5, 0.25])
    smoothed = np.convolve(frac, kern, mode="same")
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse = smoothed[rr] * in_range
    score = score + 1.5 * reuse

    return score
# EVOLVE-BLOCK-END

