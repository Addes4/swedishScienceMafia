# EVOLVE-BLOCK-START
"""Distance-to-full best fit with a mild residual-usability adjustment."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (smallest residual). Secondary: slight preference for residuals
    # that are not extremely small (avoid dead zones that waste the last bit of space).
    # Keep the secondary term tiny so exact fills remain strongly preferred.
    # bonus is 0 when residual <= 1, and grows with residual up to a small cap.
    bonus = np.minimum(residual, 20) * 0.001
    return -(residual.astype(np.float64)) + bonus
# EVOLVE-BLOCK-END

