# EVOLVE-BLOCK-START
"""Best-fit with a tiny stateful tie-break toward the running mean remaining capacity."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = _state
    s["n"] += 1
    s["sum"] += item
    s["mean"] = s["sum"] / s["n"]

    residual = bins - item
    # Primary: minimize residual (best fit). Secondary: tie-break toward the running mean
    # of item sizes, expressed as a strictly sub-unit bonus so it never overrides best fit.
    target = s["mean"]
    tie = -np.abs(bins - target) / (bins.size + 1.0)
    return -residual.astype(np.float64) + tie
# EVOLVE-BLOCK-END
