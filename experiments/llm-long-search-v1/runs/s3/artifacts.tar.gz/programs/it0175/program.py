# EVOLVE-BLOCK-START
"""Reserve-aware best fit: tight fits for near-perfect placements, otherwise target a
moderate residual so bins stay packable for the mean item size (~40)."""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1

    residual = bins - item

    # Preferred leftover after placing: roughly half the mean item size, so a typical
    # next item can still slot in without leaving a tiny unusable sliver.
    target = 20.0

    # Strongly reward near-perfect fills (residual 0) and otherwise prefer residuals
    # close to the target leftover.
    score = -np.abs(residual - target)

    # Perfect / near-perfect placements dominate.
    score = np.where(residual == 0, 1000.0, score)

    # Slightly prefer fuller bins among otherwise-equal choices (first-bin bias is fine).
    return score
# EVOLVE-BLOCK-END

