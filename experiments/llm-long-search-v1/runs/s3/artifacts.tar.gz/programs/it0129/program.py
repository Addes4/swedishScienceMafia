# EVOLVE-BLOCK-START
"""Best fit with a "don't waste tiny residuals" tie-break.

Primary key: minimize the residual left after placing the item (classic best fit).
Secondary key: when the residual would be below a running estimate of the
smallest item size seen so far (an effectively dead bin), we instead prefer the
candidate whose residual is as large as possible among equally good fits, so we
do not burn bins whose leftover can never be filled again.
"""
import numpy as np


class _State:
    min_seen = 101  # running estimate of the smallest item size observed


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing item here

    # Update running estimate of smallest item size (excluding free bins).
    used = bins < 100
    if used.any():
        # smallest residual we could leave in a used bin
        pass
    if item < _State.min_seen:
        _State.min_seen = item

    # Primary ordering: best fit -> smallest resulting residual gets highest score.
    # We build a score so that smaller residual => higher score.
    # Secondary: avoid producing a dead residual (< min_seen) if possible.
    dead_threshold = _State.min_seen  # residual strictly below this is useless

    # Score: primary is -residual. Shifting by whether residual is dead lets the
    # secondary term break near-ties without overriding decisively better fits.
    alive = residual >= dead_threshold
    # Base score: prefer smaller residual (negate). Add a large bonus for alive
    # bins ONLY among those tied on the primary key, implemented via a small
    # epsilon so it breaks ties but never inverts a strictly better fit.
    score = -residual.astype(np.float64)
    # tie-break: among equal residuals prefer an alive (larger) residual
    # Use a monotone secondary that is smaller than the primary gap of 1.
    score = score + 0.5 * alive.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
