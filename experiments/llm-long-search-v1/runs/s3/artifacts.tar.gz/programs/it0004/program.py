# EVOLVE-BLOCK-START
"""Bucketed best-fit: round remaining capacities to a coarse grid, then best-fit inside the bucket."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Coarse bucket key: floor(remain / 10). Smaller bucket = tighter fit = better.
    bucket = -(bins // 10)
    # Within a bucket, prefer the bin with the smallest remaining capacity (best fit).
    tiebreak = -(bins - item)
    # Scale the bucket term so it dominates the tiebreak.
    return bucket * 1000.0 + tiebreak
# EVOLVE-BLOCK-END
