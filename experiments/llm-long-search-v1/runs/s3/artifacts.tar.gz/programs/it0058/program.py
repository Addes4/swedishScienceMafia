# EVOLVE-BLOCK-START
"""Best fit with a preference, among equal residuals, for the most-filled bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # primary: tightest fit (smallest residual). tie-break: smaller remaining capacity
    # before placement (i.e. more-filled bin), which also prefers later bin indices
    # among bins that already contain items, before falling back to empty bins.
    return -(residual * 1000 + bins)
# EVOLVE-BLOCK-END

