# EVOLVE-BLOCK-START
"""Best-fit with a nudge toward leaving a residual near the typical item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer tight fits (small residual), but mildly prefer residuals near ~40,
    # the typical item size, so a later item can complete the bin.
    return -residual - 0.15 * np.abs(residual - 40)
# EVOLVE-BLOCK-END
