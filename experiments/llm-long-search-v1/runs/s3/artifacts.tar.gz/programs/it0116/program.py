# EVOLVE-BLOCK-START
"""Best-fit with history-aware tie-breaking on the resulting residual."""
import numpy as np

# Running histogram of item sizes seen so far (index 1..100).
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _TOTAL

    # Primary: best fit (tightest residual).
    residual = bins - item

    # Secondary: history-aware penalty for residuals that are likely wasted.
    # Probability mass of items <= residual gives a usefulness bonus; we prefer
    # bins whose residual can still accommodate many common item sizes.
    if _TOTAL > 0:
        cdf = np.cumsum(_HIST) / _TOTAL
        # clamp residual indices to [0,100]
        idx = np.clip(residual, 0, 100)
        usefulness = cdf[idx]
    else:
        usefulness = np.zeros_like(residual, dtype=np.float64)

    score = -residual.astype(np.float64) + 1e-3 * usefulness

    # Update histogram with the current item.
    _HIST[item] += 1.0
    _TOTAL += 1.0

    return score
# EVOLVE-BLOCK-END
