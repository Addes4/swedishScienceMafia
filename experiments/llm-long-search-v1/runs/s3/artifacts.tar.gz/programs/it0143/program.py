# EVOLVE-BLOCK-START
"""Best fit with a stateful fill-gate: pack tightly, but prefer draining
well-filled bins over creating many near-full-and-then-stuck bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize residual (best fit).
    score = -residual.astype(np.float64)
    # Secondary (strictly sub-unit): among bins that would be left poorly filled
    # (large residual), pull toward fuller bins (smaller remaining capacity) so
    # that partially-used bins get drained rather than left stranded.
    frac = 0.25 * bins.max() if bins.size else 0.0
    poor = residual > frac
    score = score + np.where(poor, -(bins.astype(np.float64)) * 1e-3, 0.0)
    return score
# EVOLVE-BLOCK-END
