# EVOLVE-BLOCK-START
"""Best fit with a residual-reuse tie-break toward the distribution's typical item size."""
import numpy as np


def priority(item, bins):
    """Rank bins: tightest fit first, but nudge residuals that stay reusable.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacities of bins the item fits in (bin order),
          including empty bins (capacity 100).
    """
    residual = bins - item
    # Primary: best fit -> highest score for smallest residual.
    score = -residual.astype(np.float64)
    # Secondary: slight bonus when the leftover can still hold a typical item (~40),
    # i.e. penalize leaving a residual that is too small to be useful but nonzero.
    useful = (residual >= 38) & (residual < 100)
    score += 0.01 * useful
    return score
# EVOLVE-BLOCK-END
