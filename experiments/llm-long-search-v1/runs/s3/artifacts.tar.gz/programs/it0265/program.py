# EVOLVE-BLOCK-START
"""Best-fit style rule with a stable, distribution-derived target residual.

The key idea: placing an item into the fullest bin it fits (smallest residual) keeps the
number of open bins low. On top of that pure best-fit gradient we add a strong seal for exact
fills and a reuse bonus when the leftover lands exactly on a frequently-seen item size, so
bins can still be closed productively by a later item. All distribution statistics use the
full running history, avoiding the noise of a short rolling window.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0,
          "full_hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["full_hist"][item] += 1

    residual = bins - item

    # Pure best-fit gradient: prefer the smallest non-negative residual (fullest fitting bin).
    score = -residual.astype(np.float64)

    # Anti-sliver: penalize leaving a tiny unusable leftover rather than fully packing.
    sliver = np.clip(1.0 - residual, 0.0, None)
    score = score - 0.5 * sliver

    # Seal: strong monotone preference toward exact fill (residual 0 dominates).
    score = score + 50.0 * np.clip(3.0 - residual, 0.0, None)
    score = np.where(residual == 0, score + 100000.0, score)

    # Reusability bonus: reward residuals equal (near) a frequent item size in the full
    # running history, smoothed over a small window for stability.
    total = float(st["n"])
    frac = st["full_hist"] / total
    kern = np.array([0.25, 0.5, 0.25])
    smoothed = np.convolve(frac, kern, mode="same")
    in_range = (residual >= 0) & (residual <= 100)
    rr = np.where(in_range, residual, 0).astype(np.int64)
    reuse = smoothed[rr] * in_range
    score = score + 8.0 * reuse

    return score
# EVOLVE-BLOCK-END

