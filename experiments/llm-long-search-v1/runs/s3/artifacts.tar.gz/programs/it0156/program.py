# EVOLVE-BLOCK-START
"""Best fit with a small stateful residual-class bonus.

Rank bins primarily by how tightly the item fits (best fit), and add a strictly
sub-unit bonus that favors leaving a post-placement residual which matches a
frequent recently-seen item size (so a future item can fill it exactly).
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)   # running counts of item sizes
_TOTAL = 0.0


class _State:
    pass


_STATE = _State()
_STATE.ready = False
_STATE.freq = np.zeros(101, dtype=np.float64)
_STATE.total = 0.0


def priority(item, bins):
    st = _STATE

    # update running histogram lazily (exclude nothing; distribution is stationary)
    if st.total > 0:
        # score candidates
        bins = np.asarray(bins)
        residual = bins - item
        base = -residual.astype(np.float64)

        # bonus: residual equals a frequent class (excluding the just-arrived size)
        freq = st.freq
        tot = st.total
        # normalize frequencies to [0,1]
        p = freq / tot

        # bonus value strictly below 1.0 so it cannot override best-fit gaps of >=1
        # keep it small: max ~0.49
        bonus = 0.49 * p[residual]

        return base + bonus

    # first call: pure best fit
    return -(np.asarray(bins) - item).astype(np.float64)


# We need to record sizes; do it in a wrapper so priority stays as required signature.
_orig_priority = priority


def priority(item, bins):  # noqa: F811
    st = _STATE
    if st.total > 0:
        bins = np.asarray(bins)
        residual = bins - item
        base = -residual.astype(np.float64)
        p = st.freq / st.total
        bonus = 0.49 * p[residual]
        out = base + bonus
    else:
        out = -(np.asarray(bins) - item).astype(np.float64)

    # record after scoring (so current item doesn't influence its own decision)
    if 1 <= item <= 100:
        st.freq[item] += 1.0
        st.total += 1.0
    return out
# EVOLVE-BLOCK-END

