# EVOLVE-BLOCK-START
"""Best fit with a penalty for leaving residuals that cannot hold a typical item."""
import numpy as np

_state = {"mean": 40.0, "n": 0}


def priority(item, bins):
    # Online estimate of typical item size (running mean, seeded at 40).
    s = _state
    s["n"] += 1
    a = min(0.002, 1.0 / s["n"])
    s["mean"] = (1 - a) * s["mean"] + a * item
    typical = s["mean"]

    residual = bins - item  # post-placement remaining capacity

    # Primary: tightest fit (smallest residual).  Penalize residuals that are
    # small but too big to be filled by a typical item (stranded gaps).
    # Useless if residual > 0 and residual < typical; scale penalty smoothly.
    gap_pen = np.where((residual > 0) & (residual < typical),
                       (1.0 - residual / typical), 0.0)

    # Score: prefer small residual, but heavily discount stranded gaps.
    score = -residual.astype(np.float64) - 5.0 * gap_pen
    return score
# EVOLVE-BLOCK-END
