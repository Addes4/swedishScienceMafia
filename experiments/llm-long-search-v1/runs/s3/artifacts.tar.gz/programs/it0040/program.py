# EVOLVE-BLOCK-START
"""Best fit with a residual-threshold preference.

The distribution has mean about 40 (many items in the 20-60 range).  Pure best fit
sometimes seals a bin with a small residual (say 5..25) that then can never accept a
typical mid-size item, while another slightly larger residual would still absorb such
an item.  We keep best fit as the base ordering but explicitly penalise residuals that
are too small to fit a typical item, so those bins are reserved for the small items
that can still use them.
"""
import numpy as np

# Residuals below this cannot take a "typical" mid-size item.
SMALL_RESIDUAL = 24.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins."""
    residual = bins - item
    # Base: tightest fit (best fit).
    score = -residual.astype(np.float64)
    # Penalise sealing a bin at a residual that a common item could not reuse.
    tiny = (residual >= 0) & (residual < SMALL_RESIDUAL)
    score -= tiny * (SMALL_RESIDUAL - residual) * 0.5
    return score
# EVOLVE-BLOCK-END
