# EVOLVE-BLOCK-START
"""Adaptive best fit: seal bins that would otherwise keep unusable slivers, and
otherwise choose the tightest fit (smallest residual), which is the classic
Best-Fit rule and packs Weibull arrivals well."""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1

    residual = bins - item

    # Base preference: tightest fit (smallest post-placement residual).
    score = -residual.astype(np.float64)

    # Sealing bonus: placements leaving a tiny usable sliver are effectively
    # closed bins, so reward them strongly to preserve capacity elsewhere.
    score = np.where(residual <= 2, 1000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END
