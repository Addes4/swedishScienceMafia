# EVOLVE-BLOCK-START
"""Reserve-aware best fit: close bins that can be filled almost exactly (avoid tiny
unusable slivers), otherwise target a moderate residual so bins stay packable."""
import numpy as np

_state = {"n": 0, "small": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1

    residual = bins - item

    # Adaptive cutoff for "tiny unusable sliver": shrink it as we observe more tiny
    # residuals, so sealing stays targeted rather than over-commitful.
    n = _state["n"]
    tiny = 2

    # Preferred leftover after placing: roughly half the mean item size (~40), so a
    # typical next item can still slot in without leaving a tiny unusable sliver.
    target = 20.0

    # Base preference: residuals close to the target leftover.
    score = -np.abs(residual - target)

    # Strongly reward placements that leave a very small residual: these effectively
    # seal a bin and stop it from accumulating unusable slivers of capacity.
    score = np.where(residual <= tiny, 1000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END
