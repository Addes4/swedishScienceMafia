# EVOLVE-BLOCK-START
"""Best fit with a reinforcement of near-perfect fits to close bins cleanly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: tightly packed bins are good (small residual -> high score).
    score = -residual.astype(np.float64)
    # Bonus for near-perfect fits that essentially empty the bin.
    score += 50.0 / (residual + 1.0)
    return score
# EVOLVE-BLOCK-END

