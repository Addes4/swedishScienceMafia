# EVOLVE-BLOCK-START
"""Distribution-adaptive best fit with a per-size learned residual target.

For each arriving item we maintain a running estimate of a good leftover capacity
based on the item's own size bucket, blended with a global mean-based target.
Near-exact fills are still sealed strongly to avoid slivers.
"""
import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    # learned mean residual after placing an item of a given size bucket
    "bucket_sum": [0.0] * 11,
    "bucket_cnt": [0] * 11,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    residual = bins - item

    # Bucket for the arriving item (size 1..100 -> 0..10).
    b = min(item // 10, 10)
    cnt = _state["bucket_cnt"][b]
    if cnt > 0:
        learned = _state["bucket_sum"][b] / cnt
        # Blend learned target with global half-mean target.
        target = 0.5 * learned + 0.5 * (0.5 * mean)
    else:
        target = 0.5 * mean

    score = -np.abs(residual - target)

    sliver = np.clip(target - residual, 0.0, None)
    score = score - 0.5 * sliver

    score = np.where(residual <= 2, 1000.0 - residual, score)

    # Record feedback for this item's bucket: the residual of the chosen bin.
    best = int(np.argmax(score))
    chosen_res = int(residual[best])
    _state["bucket_sum"][b] += chosen_res
    _state["bucket_cnt"][b] += 1

    return score
# EVOLVE-BLOCK-END
