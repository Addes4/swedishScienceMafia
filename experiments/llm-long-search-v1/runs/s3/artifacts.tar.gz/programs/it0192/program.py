# EVOLVE-BLOCK-START
"""Distribution-adaptive best fit: grade each placement by how usable the leftover
capacity is given the running mean item size. Seal nearly-exact fills strongly, prefer
residuals that a typical next item can still use, and penalize leftovers too small to be
useful. The target for good leftovers tracks the running mean item size."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    residual = bins - item

    # Ideal leftover: about half a typical item, so the next item tends to fill it.
    target = 0.5 * mean

    # Base preference: residuals near the target are best.
    score = -np.abs(residual - target)

    # Continuous anti-sliver penalty: leftover below ~one mean item is likely wasted
    # capacity; penalize proportionally, strongest for tiny slivers.
    sliver = np.clip(target - residual, 0.0, None)  # how far below target
    score = score - 0.5 * sliver

    # Seal bonus: strongly prefer placements that leave a near-exact fill.
    score = np.where(residual <= 3, 1000.0 - residual, score)

    return score
# EVOLVE-BLOCK-END
