# EVOLVE-BLOCK-START
"""Band-aware best fit.

Classic Best-Fit packs tightly, but on a heavy-tailed (Weibull) distribution it tends
to leave many tiny unusable slivers. We keep exact fills at top priority and otherwise
prefer tight fits, except we penalize residuals that fall in a "waste band" (too small
to be refilled by a typical item) when a slightly looser bin lands in a more useful band.
"""
import numpy as np

# Item sizes are 1..100; the distribution has mean ~40 and is heavy-tailed.
# Residuals below this are hard to ever refill exactly.
_WASTE = 6


def priority(item, bins):
    """Return a priority per bin; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacities of every bin the item fits in.
    """
    residual = bins - item  # >= 0 since only fitting bins are shown

    # Primary: prefer tighter fits (smaller residual).
    score = -residual.astype(np.float64)

    # Penalize residuals that land in the tiny "waste band" (but not exact fills).
    waste = (residual > 0) & (residual < _WASTE)
    score = np.where(waste, score - 3.0, score)

    # Exact completion always wins.
    score = np.where(residual == 0, score + 1000.0, score)

    return score
# EVOLVE-BLOCK-END
