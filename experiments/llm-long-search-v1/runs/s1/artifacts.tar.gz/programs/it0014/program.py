# EVOLVE-BLOCK-START
"""Best fit with adaptive residual target: prefer tight fits, but nudge toward a
residual close to the current average "usable" leftover, learned online."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0          # items seen
        self.sum = 0.0      # sum of item sizes
        self.target = 40.0  # running estimate of a typical residual worth keeping

    def update(self, item):
        self.n += 1
        self.sum += item
        mean = self.sum / self.n
        # target residual ~ half the mean item, but at least 1
        self.target = max(1.0, 0.5 * mean)


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _state.update(item)
    residual = bins - item
    # Primary: tightest fit (smallest residual).  Secondary: residual near target.
    tight = -residual
    bonus = -np.abs(residual - _state.target)
    return tight * 1000.0 + bonus
# EVOLVE-BLOCK-END
