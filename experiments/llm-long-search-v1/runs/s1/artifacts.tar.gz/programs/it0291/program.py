# EVOLVE-BLOCK-START
"""Distribution-aware best fit.

Strongly prefer exact fills. Otherwise rank residuals by their expected
reusability under the running empirical item-size distribution (probability
that a near-future item exactly completes the residual), blended with a
best-fit term so ties break toward tighter packing.
"""
import numpy as np

# Smoothed empirical distribution over item sizes 1..100.
_hist = np.ones(101, dtype=np.float64)  # Laplace smoothing
_count = 100.0

# Cache of reuse values indexed by residual 0..100.
_reuse = np.zeros(101, dtype=np.float64)
_reuse_dirty = True


def _rebuild_reuse():
    """Expected value of leaving residual r: weight of item sizes near r."""
    global _reuse, _reuse_dirty
    p = _hist / _count
    vals = np.arange(101, dtype=np.float64)
    # Weight probability mass at sizes within a small window of each residual.
    # Exact match dominates; nearby sizes give partial credit.
    diff = np.abs(vals[:, None] - vals[None, :])  # (101,101) |r - s|
    w = np.where(diff == 0.0, 1.0, np.where(diff <= 2.0, 0.25, 0.0))
    _reuse = w @ p
    _reuse_dirty = False


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    global _hist, _count, _reuse_dirty
    _hist[item] += 1.0
    _count += 1.0
    _reuse_dirty = True

    residual = (bins - item).astype(np.int64)
    res = residual.astype(np.float64)

    _rebuild_reuse()
    reuse_score = _reuse[residual]

    # Best-fit fallback: prefer smaller residual (scale ~1/100).
    best_fit = -res * 0.01

    score = reuse_score + best_fit
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
