# EVOLVE-BLOCK-START
"""Reuse-oriented bin choice using the observed item distribution.

The best residual for the current item is the one that, together with a
likely next item, completes a bin exactly, or that pairs with an already
started partial bin of complementary size.  We estimate this from a
recency-weighted, lightly smoothed histogram of observed item sizes and
combine it with exact-fill dominance and a weak best-fit fallback.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Smoothed recency-weighted histogram over 0..100.
    w = _seen + 0.5 * _hist
    # light neighbor smoothing
    sm = w.copy()
    sm[:-1] += 0.5 * w[1:]
    sm[1:] += 0.5 * w[:-1]
    tot = sm.sum()
    if tot <= 0.0:
        prob = np.full(101, 1.0 / 101.0)
    else:
        prob = sm / tot

    r = residual.astype(np.int64)

    # Value of leaving residual r: probability the next item exactly fills it
    # plus probability an existing complementary partial (100-r) gets filled.
    p_fill = prob[r]
    comp = np.clip(100 - r, 0, 100)
    p_comp = prob[comp]

    score = p_fill + 0.7 * p_comp

    # Prefer already-started partial bins of the right complementary size.
    score += 0.3 * np.where((res > 0) & (res < 100) & (comp > 0) & (comp < 100), prob[r] + prob[comp], 0.0)

    # Weak best-fit fallback.
    score += -0.001 * res

    # Strong preference for exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

