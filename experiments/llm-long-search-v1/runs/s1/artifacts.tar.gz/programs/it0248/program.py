# EVOLVE-BLOCK-START
"""Best fit with a probability-weighted "reusable residual" objective.

Exact fills are strongly preferred. Otherwise we choose the residual r that is
most likely to be consumed by a *future* item, weighting all reachable future
item sizes s <= r by their recency-decayed probability and preferring the
residual whose consumed fraction is largest (equivalently: the tightest fit
among likely future items), with a small fallback toward the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# cached reusable-residual value table, recomputed lazily
_last_count = -1.0
_value = np.zeros(101, dtype=np.float64)


def _update_table():
    global _last_count, _value
    if _last_count == _count:
        return
    _last_count = _count
    total = _hist.sum()
    if total <= 0.0:
        _value[:] = 0.0
        return
    p = _hist / total  # probability of each future item size s (1..100)
    # For each residual r (0..100), expected "consumption quality":
    # sum over s<=r of p[s] * (r - s)  (how much space the item would leave unfilled),
    # we want the residual that a future item fills most completely -> minimize leftover.
    # We instead track, for each r, the probable leftover after placing the best future item:
    # weighted average leftover = sum_{s<=r} p[s]*(r-s) / sum_{s<=r} p[s]  (or +inf if none).
    sizes = np.arange(101, dtype=np.float64)
    # cumulative probability of s <= r
    cum_p = np.cumsum(p)  # index r = sum_{s<=r} p[s]
    # weighted sum of p[s]*s for s<=r
    wsum_s = np.cumsum(p * sizes)  # but p has length 101 (index 0..100), sizes 0..100
    avg_leftover = np.empty(101, dtype=np.float64)
    for r in range(101):
        if cum_p[r] <= 0.0:
            avg_leftover[r] = r  # nothing fits; leftover = full residual
        else:
            avg_leftover[r] = (r * cum_p[r] - wsum_s[r]) / cum_p[r]
    _value[:] = -avg_leftover  # smaller average leftover is better


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    _update_table()

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)
    ri = residual.astype(np.int64)

    mean_item = _sum / _count if _count > 0 else 40.0

    # Reuse-quality signal indexed by residual.
    score = _value[ri].copy()

    # Small fallback preference for residuals near the running mean.
    score += -0.02 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

