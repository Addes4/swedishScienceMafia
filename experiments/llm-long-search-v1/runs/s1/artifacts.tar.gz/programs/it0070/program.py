# EVOLVE-BLOCK-START
"""Best fit with residual-quality shaping plus pair-fill lookahead."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_pair_targets = np.zeros(201, dtype=np.float64)  # sums of two frequent sizes, cached


def _rebuild_pair_targets():
    global _pair_targets
    _pair_targets[:] = 0.0
    if _count <= 0:
        return
    p = _hist / _count
    # Weight each possible pair-sum by probability of the pair appearing.
    sums = np.zeros(201, dtype=np.float64)
    for a in range(1, 101):
        pa = p[a]
        if pa <= 0.0:
            continue
        # b from 1..100; sum a+b in [2,200]
        sums[a + 1:a + 101] += pa * p[1:101]
    # Normalize so max target weight is 1, keep a smooth profile.
    m = sums.max()
    if m > 0:
        _pair_targets[:] = sums / m


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _pair_targets
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item
    res = residual.astype(np.float64)

    score = -res
    score += np.where(residual == 0, 1000.0, 0.0)

    small = (residual > 0) & (residual < item)
    score -= np.where(small, res, 0.0)

    if _count > 0:
        mean_item = float(np.dot(np.arange(101), _hist) / _count)
    else:
        mean_item = 40.0
    bonus = np.minimum(res, mean_item) * 0.1
    score += bonus

    # Pair-fill lookahead: reward residuals that match a likely two-item sum.
    if _count >= 8:
        _rebuild_pair_targets()
        idx = residual.astype(np.int64)
        idx = np.clip(idx, 0, 200)
        score += _pair_targets[idx] * 5.0

    return score
# EVOLVE-BLOCK-END
