# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective using a sliding window.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (within a sliding window of the last K items),
so the next few arrivals can fill it exactly, with a mild fallback toward the
running mean.
"""
import numpy as np

_K = 200
_win = np.zeros(_K, dtype=np.int64)
_pos = 0
_filled = 0
_count = 0.0
_sum = 0.0
# Precomputed 101x101 distance table (max residual is 100)
_vals = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _win, _pos, _filled, _count, _sum
    _win[_pos] = item
    _pos += 1
    if _pos >= _K:
        _pos = 0
    if _filled < _K:
        _filled += 1
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Distinct sizes currently in the sliding window.
    present = np.zeros(101, dtype=bool)
    present[_win[:_filled]] = True
    idx = np.nonzero(present)[0]

    if idx.size > 0:
        # For each residual value 0..100, min distance to a size in the window.
        d = np.abs(_vals[:, None] - idx[None, :].astype(np.float64))
        nearest = d.min(axis=1)  # shape (101,)
    else:
        nearest = np.abs(_vals - mean_item)

    # Score: closer to a reusable residual is better; exact fills dominant.
    score = -nearest[residual.astype(np.int64)]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

