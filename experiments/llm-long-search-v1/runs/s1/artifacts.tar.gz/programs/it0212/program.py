# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (so the next few arrivals can fill it exactly),
falling back toward a mild preference for residuals near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Cached recency-weighted presence of item sizes
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    idx = np.nonzero(_seen > 0.0)[0]
    vals = np.arange(101, dtype=np.float64)
    if idx.size > 0:
        # Weighted distance-to-nearest-seen-size, scaled smoothly by recency mass.
        d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
        # nearest integer distance (per residual value 0..100)
        nearest = d.min(axis=1)
        # a smoother reuse score: recency mass within distance 1 (exact + neighbors)
        mass = _seen[idx]
        wpos = mass.sum()
        # exact-mass for each value
        exact = np.zeros(101, dtype=np.float64)
        exact[idx] = mass
        # neighbor mass (distance 1)
        nb = np.zeros(101, dtype=np.float64)
        for off in (-1, 1):
            j = idx + off
            ok = (j >= 0) & (j <= 100)
            nb[j[ok]] += mass[ok]
        reuse = (exact + 0.5 * nb) / max(wpos, 1e-9)
    else:
        nearest = np.abs(vals - mean_item)
        reuse = np.zeros(101, dtype=np.float64)

    ri = residual.astype(np.int64)

    # Score: reuse value for this residual, exact fill dominant.
    score = 2.0 * reuse[ri]
    score += -0.10 * nearest[ri]
    score += -0.02 * np.abs(res - mean_item)
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
