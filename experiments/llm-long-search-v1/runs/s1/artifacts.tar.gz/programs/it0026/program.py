# EVOLVE-BLOCK-START
"""Best fit biased by an online-learned item-size histogram.

Primary criterion: smallest residual after placement (classic best fit).
Secondary (tie-break within a small window): prefer residuals that are likely to be
exactly filled by a future item, estimated from a recency-weighted histogram of the
item sizes seen so far.
"""
import numpy as np

# Estimated hazard/priority table of residual sizes: larger == more likely a future
# item exactly matches this residual. Updated online, recency-weighted.
_FREQ = np.ones(101, dtype=np.float64)
_DECAY = 0.999


def _update(item):
    global _FREQ
    _FREQ *= _DECAY
    _FREQ[item] += 1.0


def priority(item, bins):
    _update(item)
    res = bins - item  # residual left if the item is placed here (>= 0)
    # Base: prefer tightest fit (small residual).
    score = -res.astype(np.float64)
    # Bonus: residual is a plausible future item size -> enables a later exact fill.
    # Normalize the frequency so the bonus is a mild tie-breaker, not a primary term.
    bonus = _FREQ[res]
    bonus = bonus / (1.0 + bonus)  # in [0, 1)
    score += 0.75 * bonus
    # Extra reward for exact completion.
    score += np.where(res == 0, 2.0, 0.0)
    return score
# EVOLVE-BLOCK-END
