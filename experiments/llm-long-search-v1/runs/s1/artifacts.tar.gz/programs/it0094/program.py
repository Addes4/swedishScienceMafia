# EVOLVE-BLOCK-START
"""Best fit with exact-fit preference plus histogram-match residual bonus.

Dominant term: best fit (smallest residual). Exact fills get a large bonus.
Secondary: small bonus for residuals that exactly equal an item size observed
often enough, since those leftovers can be filled perfectly by a future item of
that size.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest goes first, ties to first bin."""
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0
    res = residual.astype(np.float64)

    # Dominant: best fit.
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Bonus: residual exactly equals a frequently-seen item size -> reusable.
    if _count > 20:
        freq = _hist / _count
        # probability-weighted bonus, capped, for residuals in 1..100
        idx = np.clip(residual, 0, 100).astype(np.int64)
        match_prob = freq[idx]
        score += match_prob * 50.0

    return score
# EVOLVE-BLOCK-END
