# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer a residual whose value is
itself likely to be fillable exactly by a near-future item (recency-weighted,
smoothed histogram mass at the residual), with a weak Best-Fit tie-break toward
the smallest residual.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)

# smoothing kernel over residual values
_KERNEL = np.array([1.0, 2.0, 3.0, 2.0, 1.0], dtype=np.float64)
_KERNEL /= _KERNEL.sum()


def _smooth(v):
    # v: length-101 array indexed by value 0..100
    out = np.zeros_like(v)
    n = v.shape[0]
    k = _KERNEL.shape[0]
    half = k // 2
    for i in range(n):
        lo = i - half
        hi = i + half
        acc = 0.0
        for j in range(k):
            idx = lo + j
            if 0 <= idx < n:
                acc += _KERNEL[j] * v[idx]
        out[i] = acc
    return out


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item
    res = residual.astype(np.float64)

    seen_present = _seen > 0.0
    if seen_present.any():
        reuse_mass = _smooth(_seen)  # mass at each residual value (smoothed)
    else:
        reuse_mass = np.zeros(101, dtype=np.float64)

    # Reuse bonus: residual value that has recency mass -> likely exact-fillable soon.
    score = reuse_mass[residual.astype(np.int64)]

    # Exact fills dominant.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Weak Best-Fit tie-break: prefer smaller residual.
    score += -0.001 * res

    return score
# EVOLVE-BLOCK-END

