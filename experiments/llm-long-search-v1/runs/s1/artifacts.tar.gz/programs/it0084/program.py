# EVOLVE-BLOCK-START
"""Best fit with a strong exact-fit bonus and a mild usable-residual tie-break."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_min_item = 101.0


def priority(item, bins):
    """Rank bins for the arriving item; highest score wins (first on ties)."""
    global _hist, _count, _min_item
    _hist[item] += 1.0
    _count += 1.0
    if item < _min_item:
        _min_item = item

    residual = bins - item
    res = residual.astype(np.float64)

    # Base: prefer tightest fit (best-fit).
    score = -res
    # Dominant preference for exact fills.
    score += np.where(residual == 0, 10000.0, 0.0)
    # Mild bonus if the leftover is still usable (>= smallest item seen).
    usable = residual >= _min_item
    score += np.where(usable, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
