# EVOLVE-BLOCK-START
"""Strict best-fit with a dominant exact-fit bonus.

Bins are ranked mainly by smallest residual (best fit); exact fills get a
large bonus. A small secondary term prefers residuals that are still large
enough to potentially be reused, without overriding the best-fit ordering.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown

    # Dominant term: strict best fit (smallest residual).
    score = -residual.astype(np.float64) * 1000.0
    # Exact fills strongly preferred.
    score += np.where(residual == 0, 1.0e7, 0.0)
    # Secondary: small nudge toward residuals that remain reusable
    # (i.e., not tiny leftovers that no future item can use).
    score += (residual > 0).astype(np.float64)

    return score
# EVOLVE-BLOCK-END
