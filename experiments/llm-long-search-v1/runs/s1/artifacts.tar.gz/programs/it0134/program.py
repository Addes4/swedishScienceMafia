# EVOLVE-BLOCK-START
"""Best-fit with a recency-weighted exact-reuse bonus.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
exactly equals a recently-seen item size (so it can be filled by a later item),
with a best-fit fallback toward small residuals.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)
    resi = residual.astype(np.int64)

    # Recency-weighted probability mass that a future item exactly fills this residual.
    total = _seen.sum()
    if total > 0.0:
        p_seen = _seen / total
    else:
        p_seen = np.zeros(101, dtype=np.float64)

    # Exact-reuse bonus: how likely is this specific residual to be filled exactly.
    reuse = p_seen[resi]

    # Best-fit fallback: smaller residual is preferred (well-behaved, low variance).
    best_fit = 1.0 / (1.0 + res)

    score = 3.0 * reuse + 1.0 * best_fit

    # Strongly prefer exact fills.
    score += np.where(resi == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

