# EVOLVE-BLOCK-START
"""Best fit with exact-fill dominance and a light reuse tie-break.

Classic Best-Fit (smallest residual) is the strongest practical online rule for
random arrivals. Exact fills are strongly rewarded. A small recency-weighted
reuse bonus breaks remaining ties toward residuals that match recent item sizes,
without saturating.
"""
import numpy as np

_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum, _seen
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Best fit: smallest residual is best.
    score = -residual.astype(np.float64)

    # Light reuse bonus: reward residuals matching recent items.
    reuse = _seen[residual]
    score += 0.2 * reuse

    # Very light pull toward the running mean residual.
    score += -0.001 * np.abs(residual.astype(np.float64) - mean_item)

    # Exact fills dominate.
    score += np.where(residual == 0, 1e6, 0.0)

    return score
# EVOLVE-BLOCK-END
