# EVOLVE-BLOCK-START
"""Best fit with a sharp "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer residuals that equal or
nearly equal a recently-seen item size, and break remaining ties by best fit
(smallest residual).
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted presence of item sizes.
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    mean_item = _sum / _count if _count > 0 else 40.0

    # Normalize recency-weighted presence of sizes to [0,1].
    max_seen = _seen.max()
    if max_seen > 0.0:
        pres = _seen / max_seen
    else:
        pres = np.zeros(101, dtype=np.float64)

    # For each possible residual r (0..100), a "reuse value": full presence mass
    # at r, decaying for near matches. Sharp so it doesn't over-reward loose fits.
    r_idx = np.arange(101)
    reuse = pres.copy()
    # add half weight for neighbors within 1, quarter within 2 (wrapped via roll)
    reuse = reuse + 0.5 * (np.roll(pres, 1) + np.roll(pres, -1))
    reuse = reuse + 0.25 * (np.roll(pres, 2) + np.roll(pres, -2))

    score = reuse[residual.astype(np.int64)]

    # Best-fit secondary: prefer smallest residual (mild so it only breaks ties).
    score += -0.02 * res

    # Mild fallback preference for residuals near the running mean.
    score += -0.01 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

