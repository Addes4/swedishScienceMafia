# EVOLVE-BLOCK-START
"""Best fit with a small bias toward residuals that match typical item sizes (~40)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item            # remaining capacity after placing the item
    # Best fit: prefer smallest residual.
    score = -residual.astype(np.float64)
    # Small bonus when the residual can plausibly fit another typical item (~40),
    # i.e. residual is comfortably large but not much larger than a typical item.
    typical = 40.0
    # reward residuals near a "useful" leftover: residual >= typical but close to it
    useful = np.clip(typical - np.abs(residual - typical), 0.0, None)
    score += 0.05 * useful
    return score
# EVOLVE-BLOCK-END
