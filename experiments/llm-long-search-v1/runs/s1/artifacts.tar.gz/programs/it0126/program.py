# EVOLVE-BLOCK-START
"""Best fit with a probabilistic "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
has high probability of being exactly filled by a future item (based on the
running recency-weighted histogram), blended with a mild best-fit fallback.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Probability-like weight of each residual value being exactly fillable soon.
    total = _seen.sum()
    if total > 0.0:
        prob = _seen / total  # shape (101,)
    else:
        prob = np.zeros(101, dtype=np.float64)

    ridx = residual.astype(np.int64)
    # Exact-fill probability of the residual.
    match = prob[ridx]

    # Score: reusability (prob matching a seen size) plus mild best-fit fallback.
    score = 3000.0 * match
    score += -0.02 * res
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills of the current item.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
