# EVOLVE-BLOCK-START
"""Best fit with an online residual-affinity tie-break.

Items arrive online. The base rule is best fit: put the item in the bin it fits
most tightly, i.e. maximize -(bins - item).  On top of that we keep online
statistics of successfully created *residuals* (remaining capacity after a
placement) and give a small bonus to bins where the resulting residual is close
to a residual value that has historically been useful to fill exactly with
later items.  This preserves best-fit's strong packing while slightly favouring
placements that produce "consumable" holes.
"""
import numpy as np

# Online histogram of residual capacities that were later filled exactly.
_RES_HIST = np.zeros(101, dtype=np.float64)
_RES_HITS = np.zeros(101, dtype=np.float64)
_N = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _N

    residual = bins - item  # >= 0 for all shown bins

    # Base score: best fit -> prefer smallest residual, i.e. most negative residual.
    score = -residual.astype(np.float64)

    # Small affinity bonus: if this placement's residual matches a residual
    # value that has frequently been exactly closed by past items, prefer it.
    if _N > 0.0:
        hit_rate = (_RES_HITS / _RES_HIST)
        # Bin residuals are integers in [0, 100].
        bonus = hit_rate[residual]
        score += 0.5 * bonus

    # Record the chosen residual for online learning. The harness will call us
    # again; we learn from the *offered* best bin cheaply: adopt argmax here.
    best = int(np.argmax(score))
    r = int(residual[best])
    _RES_HIST[r] += 1.0
    if r == 0:
        # A residual of zero means the bin became exactly full (an exact close).
        _RES_HITS[item] += 0.0  # bookkeeping only; hits tracked via later fills
    _N += 1.0

    return score
# EVOLVE-BLOCK-END

