# EVOLVE-BLOCK-START
"""Complement-aware best fit: tightest fit, with a bonus for residuals near the mean."""
import numpy as np

_TARGET = 40.0
_W = 0.6


def priority(item, bins):
    residual = bins - item
    # tightest fit is primary; small bonus if residual near typical future item size
    bonus = -_W * np.abs(residual - _TARGET)
    return -residual + bonus
# EVOLVE-BLOCK-END
