# EVOLVE-BLOCK-START
"""Best fit with a reusable-residual objective driven by a smoothed size histogram.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual r such
that some plausible future item size exactly equals r (high "perfect completion
potential"), estimated from a recency-weighted histogram of past items. A mild
pull toward the running mean breaks remaining ties.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist *= 0.999  # recency decay
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    total = _hist.sum()
    if total > 0.0:
        prob = _hist / total          # probability weight per size
        mean_item = _sum / _count
    else:
        prob = np.zeros(101, dtype=np.float64)
        mean_item = 40.0

    # Perfect-completion potential: for residual r, how likely is a future item
    # of exactly size r? Use prob[r]. This rewards leaving reusable gaps.
    r_idx = residual.astype(np.int64)
    completion = prob[r_idx]

    score = completion

    # Mild pull toward the running mean for non-reusable leftovers.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
