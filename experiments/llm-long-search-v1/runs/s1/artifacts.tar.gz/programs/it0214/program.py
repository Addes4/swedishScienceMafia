# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware reuse objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that is
likely to be matched by some future item (so capacity gets reused exactly),
estimated from the recency-weighted empirical item distribution, blended with a
mild best-fit preference for tightly-packed bins.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)     # cumulative histogram
_recent = np.zeros(101, dtype=np.float64)   # recency-weighted histogram
_count = 0.0
_sum = 0.0


def priority(item, bins):
    global _hist, _recent, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # recency weighting with decay so recent arrivals matter more
    _recent *= 0.998
    _recent[item] += 1.0

    residual = bins - item
    res = residual.astype(np.float64)

    # empirical item probabilities from recency-weighted histogram
    tot = _recent.sum()
    if tot > 0:
        prob = _recent / tot
    else:
        prob = _hist / max(_hist.sum(), 1.0)

    mean_item = _sum / _count if _count > 0 else 40.0

    # For each residual value r (0..100), estimate the "reuse value":
    # probability that some future item equals r exactly (perfect fill),
    # plus a small term for residuals that a future item can neatly leave.
    reuse = np.zeros(101, dtype=np.float64)
    # exact-match probability for residual == future item size
    reuse += prob
    # prefer residuals that are themselves common item sizes
    # (a residual r can be filled by an item of size r, so reuse[r] already encodes that)

    score = reuse[residual.astype(np.int64)]

    # Mild preference for residuals near the mean item size (easy to fill)
    score += -0.05 * np.abs(res - mean_item)

    # Small best-fit tie-break: tightly-packed bins preferred
    score += -0.001 * res

    # Strong exact-fill dominance
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
