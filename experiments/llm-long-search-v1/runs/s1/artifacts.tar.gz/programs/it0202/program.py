# EVOLVE-BLOCK-START
"""Best-Fit bin packing rule.

Place the item into the bin that leaves the smallest residual capacity
(i.e. the tightest fit). Exact fills are naturally preferred since they
leave residual 0, which is the smallest possible residual.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown
    # Prefer smaller residual => higher score.
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

