# EVOLVE-BLOCK-START
"""Best fit with an expected-reuse tie-break from the empirical histogram."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item
    res = residual.astype(np.float64)

    exact = (residual == 0)
    score = -res
    score += np.where(exact, 1000.0, 0.0)

    if _count > 0:
        counts = _hist[1:]
        total = _count
        # Probability a future single item fits in a residual of size r.
        cum = np.cumsum(counts) / total  # P(size <= r) for r>=1
        # Expected count of future items fitting into residual (crude scale).
        idx = np.clip(residual - 1, 0, 99)
        p_fit = np.where(residual >= 1, cum[idx], 0.0)
        # Reward residuals that can be reused; limited influence.
        score += p_fit * 0.5

    return score
# EVOLVE-BLOCK-END
