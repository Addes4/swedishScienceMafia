# EVOLVE-BLOCK-START
"""Exact-fill dominant rule with a stationary "reusable residual" potential.

We keep strong preference for exact fills (residual == 0). Otherwise we rank
bins by the running-histogram probability that the resulting residual will be
exactly matched by a single future item (P(item == residual)), which is a
stationary, low-noise surrogate for "reusable residual". A gentle best-fit
term (smaller residual slightly preferred) breaks ties.
"""
import numpy as np

_cap = 101
_hist = np.zeros(_cap, dtype=np.float64)
_count = 0.0
# Cached potential per residual value; recomputed occasionally.
_pot = np.zeros(_cap, dtype=np.float64)
_last_rebuild = -1


def _rebuild_potential():
    global _pot, _last_rebuild
    tot = _count if _count > 0.0 else 1.0
    # Stationary probability that a future item equals each residual value.
    _pot = _hist / tot
    _last_rebuild = int(_count)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (ties -> first)."""
    global _hist, _count

    _hist[item] += 1.0
    _count += 1.0

    # Rebuild the potential lookup cheaply every 16 items (or on first call).
    if _last_rebuild < 0 or (_count - _last_rebuild) >= 16.0:
        _rebuild_potential()

    residual = bins - item  # >= 0 for all bins shown (harness guarantees fit)
    res = residual.astype(np.int64)

    # Reuse probability of a residual (stationary histogram estimate).
    score = _pot[res]

    # Gentle best-fit tie-break: prefer the smaller residual.
    score += -1e-4 * residual

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 10.0, 0.0)

    return score
# EVOLVE-BLOCK-END
