# EVOLVE-BLOCK-START
"""Best fit with distribution-aware residual reuse shaping.

Best-fit (smallest residual) stays dominant, exact fills get the strongest
bonus, and among near-tied residuals we prefer one that a future item is
likely to fill exactly, using the empirical item histogram.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _total
    _hist[item] += 1.0
    _count += 1.0
    _total += item

    residual = bins - item  # >= 0
    res = residual.astype(np.float64)

    # Dominant term: best fit.
    score = -res
    # Strongest: exact fills.
    score += np.where(residual == 0, 10000.0, 0.0)

    # Reuse bonus: how likely is this residual to be filled exactly later?
    # freq[r] = observed fraction of items of size r.
    freq = _hist / _count if _count > 0 else np.zeros(101)
    r = np.clip(residual, 0, 100).astype(np.int64)
    reuse = freq[r]  # probability a future item equals this residual
    score += reuse * 200.0

    return score
# EVOLVE-BLOCK-END
