# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
the item distribution is likely to reproduce (so a future item fills it
exactly), falling back toward a mild preference for residuals near the mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_decay = 0.9995


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist *= _decay
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown (int64)
    res = residual.astype(np.float64)

    total = _hist.sum()
    if total > 0.0:
        p = _hist / total  # probability mass on each item size
        mean_item = _sum / _count
    else:
        p = np.zeros(101, dtype=np.float64)
        mean_item = 40.0

    # Usability: probability that a future item exactly fills residual r (i.e. item==r).
    usable = p[residual.astype(np.int64)]

    # Also reward leaving a residual that a small item can top off reasonably often:
    # cumulative probability of an item fitting inside the residual.
    cdf = np.cumsum(p)  # cdf[v] = P(item <= v)
    fit_prob = cdf[residual.astype(np.int64)]

    score = 4.0 * usable + 0.5 * fit_prob

    # Mild fallback toward the running mean.
    score += -0.02 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
