# EVOLVE-BLOCK-START
"""Hybrid: worst-fit for small items, best-fit for larger items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item < 25:
        # worst fit: prefer the emptiest bins for small items
        return bins.astype(np.float64)
    # best fit: prefer the tightest fit for larger items
    return -(bins - item).astype(np.float64)
# EVOLVE-BLOCK-END

