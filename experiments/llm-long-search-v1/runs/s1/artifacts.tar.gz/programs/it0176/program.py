# EVOLVE-BLOCK-START
"""Best fit augmented with a reusable-residual bonus.

Exact fills are strongly preferred. Otherwise the primary criterion is classic
best fit (smallest residual), and a moderate bonus rewards residuals that match
a likely future item size (from a stationarized running histogram).
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 integer array
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
        prob = _hist / _count  # P(item == r)
    else:
        mean_item = 40.0
        prob = np.zeros(101, dtype=np.float64)

    # Primary: best fit (prefer smallest residual).
    score = -res

    # Secondary: bonus for residuals that a future item is likely to fill exactly.
    match_bonus = prob[residual.astype(np.int64)] * 200.0
    score += match_bonus

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
