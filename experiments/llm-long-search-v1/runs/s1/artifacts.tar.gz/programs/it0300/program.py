# EVOLVE-BLOCK-START
"""Best fit with an explicit exact-fill bonus.

Items must be placed immediately. The empirically strong and robust rule for
this Weibull-like stream is best fit: put the item into the bin that leaves the
smallest residual capacity. Exact fills are already the smallest residual, but
we also add an explicit dominant bonus so a zero residual always wins clearly.
"""
import numpy as np

_mean_item = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item            # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Best fit: smaller residual is better.
    score = -res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
