# EVOLVE-BLOCK-START
"""Best fit with a strong exact-fill bonus.

Exact fills are strongly preferred. Otherwise, use classic best fit: choose the
bin with the smallest remaining residual (tightest fit), which is a robust and
near-optimal online heuristic that avoids noise from running statistics.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Best fit: prefer the smallest residual.
    score = -res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
