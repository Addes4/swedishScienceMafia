# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (so the next few arrivals can fill it exactly),
falling back toward a mild preference for residuals near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Cached array of item sizes seen recently (weighted by recency via decay)
_seen = np.zeros(101, dtype=np.float64)
# Precomputed reuse weights for each residual value 0..100
_reuse_cache = None
_reuse_dirty = True


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen, _reuse_cache, _reuse_dirty
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0
    _reuse_dirty = True

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Smooth reusability for each residual value 0..100:
    # sum of recency-weighted mass of seen sizes at distance 0 (full), 1 (half), 2 (quarter).
    if _reuse_dirty or _reuse_cache is None:
        vals = np.arange(101, dtype=np.float64)
        # d[r, s] = |r - s|
        d = np.abs(vals[:, None] - vals[None, :])
        w = np.where(d == 0.0, 1.0, np.where(d == 1.0, 0.5, np.where(d == 2.0, 0.25, 0.0)))
        _reuse_cache = w @ _seen
        _reuse_dirty = False

    reuse = _reuse_cache[residual.astype(np.int64)]

    # Score: higher reuse is better; exact fills dominant.
    score = reuse

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
