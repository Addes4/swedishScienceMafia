# EVOLVE-BLOCK-START
"""Best fit with a smooth, histogram-weighted reusability objective.

Exact fills are strongly preferred. Otherwise, score each candidate residual by
the recency-weighted histogram mass of seen item sizes that could fill it, with
exact matches dominant and near matches slightly less, plus a Best-Fit term
(prefer the smallest residual) as a tie-break / fallback.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted presence of item sizes.
_seen = np.zeros(101, dtype=np.float64)
# Precomputed residual-index -> reusability map (rebuilt when histogram shifts).
_vals = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Smooth reusability: for each candidate residual r, accumulate seen-size
    # mass weighted by closeness |s - r| (exact match weight 1, +-1 weight 0.5, ...).
    seen_present = _seen > 0.0
    if np.any(seen_present):
        sizes = _vals[seen_present]
        weights = _seen[seen_present]
        # distance matrix (101 x K) -> weighted closeness
        d = np.abs(_vals[:, None] - sizes[None, :])
        closeness = 1.0 / (1.0 + d)
        reuse_map = (closeness * weights[None, :]).sum(axis=1)
    else:
        reuse_map = 1.0 / (1.0 + np.abs(_vals - mean_item))

    # Normalize reuse map to a comparable scale with the best-fit term.
    m = reuse_map.max()
    if m > 0.0:
        reuse_map = reuse_map / m

    score = reuse_map[residual.astype(np.int64)]

    # Best-fit tie-break: prefer the smallest residual (pack tight).
    score += -0.5 * (res / 100.0)

    # Mild pull toward the running mean as a fallback.
    score += -0.02 * np.abs(res - mean_item) / 100.0

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
