# EVOLVE-BLOCK-START
"""Exact-fill first, then a pair-completion reuse signal.

Exact fills are strongly preferred. Otherwise, score each residual by how easily
it can be completed exactly by a future item (single item or a pair whose sum
matches the residual), estimated from a recency-weighted histogram of item sizes.
Falling back, prefer smaller residuals (best fit).
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Probability-like weights of item sizes from the decayed recent histogram.
    w = _seen
    tot = w.sum()
    if tot > 0:
        p = w / tot
    else:
        p = np.zeros(101, dtype=np.float64)

    # For each residual value r in 0..100, estimate probability of completing exactly:
    #  - single item of size r
    #  - a pair (a, b) with a + b == r, summing p[a]*p[b]
    r_vals = np.arange(101)
    single = p  # single[r]
    # pair contribution via convolution of p with itself
    conv = np.convolve(p, p)  # length 201, index = a+b
    pair = np.zeros(101, dtype=np.float64)
    n = min(101, conv.shape[0])
    pair[:n] = conv[:n]

    complete = single + pair  # value for residual 0..100

    score = complete[residual.astype(np.int64)]

    # Mild best-fit fallback: prefer smaller residuals.
    score += -0.001 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
