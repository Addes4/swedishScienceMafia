# EVOLVE-BLOCK-START
"""Best fit with residual-quality shaping: exact fits strongly preferred,
tiny leftover residuals penalized in proportion to item scale."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    rf = residual.astype(np.float64)
    # Base: prefer tight fits.
    score = -rf
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)
    # Penalize tiny nonzero residuals, scaled by how small they are relative to item.
    small = (residual > 0) & (residual < item)
    # stronger penalty the smaller the leftover (relative to item size)
    score -= np.where(small, (item - residual) / float(item) * 3.0, 0.0)
    return score
# EVOLVE-BLOCK-END

