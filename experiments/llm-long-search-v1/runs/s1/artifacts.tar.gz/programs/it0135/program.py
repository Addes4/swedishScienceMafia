# EVOLVE-BLOCK-START
"""Best fit enhanced by a "future fillability" objective.

The core rule is best-fit (smallest residual wins, exact fills strongly
preferred), but a residual is boosted when the running item-size distribution
suggests it is likely to be exactly filled by a single upcoming item.  This is
estimated from a recency-weighted histogram of seen item sizes.  A small
best-fit term breaks ties among equally fillable residuals.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)   # cumulative counts
_seen = np.zeros(101, dtype=np.float64)   # recency-weighted counts
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen, _count
    _count += 1.0
    _hist[item] += 1.0
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)
    ri = residual.astype(np.int64)

    # Probability mass that a single upcoming item exactly equals this residual.
    if _count > 0:
        mass = _seen / _seen.sum()
    else:
        mass = np.zeros(101, dtype=np.float64)

    # fillability of a residual value r in 0..100
    fill = mass[ri]

    # Best-fit flavor: smaller residual slightly preferred (breaks ties).
    score = -0.01 * res

    # Prefer residuals likely to be exactly filled by a future single item.
    score += 5.0 * fill

    # Exact fills dominate.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
