# EVOLVE-BLOCK-START
"""Best fit, with a mild preference for residuals that are easy to reuse."""
import numpy as np

_GOOD = 40.0  # typical item size (distribution mean ~40)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties).

    Primary: prefer tightest fit (smallest residual after placing).
    Tie/secondary: among comparable residuals, prefer a residual close to the
    typical item size so the leftover bin stays reusable.
    """
    residual = bins - item
    # tightness: higher for smaller residual
    tight = -residual.astype(np.float64)
    # bonus for residuals near typical item size (reusable leftover)
    near = -np.abs(residual.astype(np.float64) - _GOOD)
    return tight + 1e-3 * near
# EVOLVE-BLOCK-END
