# EVOLVE-BLOCK-START
"""Best fit with exact-fit priority and minimal-fragment avoidance.

The dominant term is pure best-fit (tightest residual). Exact fills get a large
bonus. A mild penalty is applied to residuals that remain positive but are
smaller than the smallest item observed so far, since such leftovers can never
be reused and represent permanent waste.
"""
import numpy as np

_min_item = 101


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    global _min_item
    if item < _min_item:
        _min_item = item

    residual = bins - item  # >= 0
    res = residual.astype(np.float64)

    # Base: best-fit — prefer the tightest residual.
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Mild penalty for residuals that can never be reused (smaller than the
    # smallest item seen so far), avoiding permanent fragmentation.
    dead = (residual > 0) & (residual < _min_item)
    score -= np.where(dead, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
