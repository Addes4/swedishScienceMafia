# EVOLVE-BLOCK-START
"""Enhanced best-fit: prefer exact fits, then prefer bins whose residual is
likely to be exactly refilled by future items (estimated from a running size
histogram), avoiding leftover waste."""
import numpy as np


class _State:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    st = _state

    # Update histogram with the current item before scoring.
    if 1 <= item <= 100:
        st.counts[item] += 1.0
        st.total += 1.0

    residual = bins - item  # >= 0

    # Probability that a future item exactly equals a given residual r.
    # Use empirical distribution over residuals 0..100.
    if st.total > 0:
        p = st.counts / st.total
    else:
        p = np.full(101, 1.0 / 100.0)

    # "Fillability": for residual r, how easily can it be exactly finished?
    # r==0 is a perfect fill (best). For r>0, we look at whether some item size
    # <= r can lead to r becoming 0 next time; approx by p[r] plus chance that
    # r is a common small item size.
    r_clipped = np.clip(residual, 0, 100).astype(np.int64)

    # Expected future exact-fill probability for residual = p[r].
    fill_prob = p[r_clipped]

    # Also reward residuals that themselves are common item sizes (easy to fill
    # exactly on a later item), and residuals near 0 are bad if unusable.
    score = -residual.astype(np.float64)          # prefer tight fits overall
    score += np.where(residual == 0, 1000.0, 0.0)  # exact fill dominant
    score += 5.0 * fill_prob                       # likely to be refilled exactly
    # Penalize small nonzero residuals (fragments unlikely to be used).
    small = (residual > 0) & (residual < 20)
    score -= np.where(small, (20.0 - residual.astype(np.float64)), 0.0)

    return score
# EVOLVE-BLOCK-END
