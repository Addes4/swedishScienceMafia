# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective + best-fit tie-break.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (so the next few arrivals can fill it exactly),
falling back toward a mild preference for residuals near the running mean.
Among equally-good residuals, prefer the tightest fit (smallest residual).
"""
import numpy as np

# Recency-weighted count of item sizes (higher weight => more recent).
_seen = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Expected weight of a single new item observation; used to decay _seen.
_DECAY = 0.995
# Total weight we want the histogram to converge to (keeps _seen comparable to counts).
_MAXW = 1.0 / (1.0 - _DECAY)

# Cached distance-to-nearest-seen-size vector for residuals 0..100.
_cache = None
_cache_dirty = True

_vals = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _seen, _count, _sum, _cache, _cache_dirty
    _seen *= _DECAY
    _seen[item] += 1.0
    _cache_dirty = True
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Distance to the closest recently-seen item size: 0 if residual is an
    # observed size, growing with distance to the nearest observed size.
    if _cache_dirty:
        idx = np.nonzero(_seen >= 0.5)[0]
        if idx.size > 0:
            d = np.abs(_vals[:, None] - idx[None, :].astype(np.float64))
            _cache = d.min(axis=1)
        else:
            _cache = np.abs(_vals - mean_item)
        _cache_dirty = False

    # Score: closer to a reusable residual is better; exact fills dominant.
    score = -_cache[residual.astype(np.int64)]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Best-fit tie-break: among similar residuals prefer the tightest fit.
    score += -0.001 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
