# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
exactly matches a recently-seen item size (so the next few arrivals can fill it
exactly), tie-broken toward smaller residuals and toward residuals near the
running mean.
"""
import numpy as np

_seen = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _seen, _count, _sum
    _seen *= 0.999
    _seen[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    mean_item = _sum / _count if _count > 0 else 40.0

    # Exact-match indicator against recently-seen sizes.
    seen_here = _seen[residual.astype(np.int64)]
    exact_seen = seen_here > 0.0

    # Distance to the nearest recently-seen size (0 if residual is an observed size).
    idx = np.nonzero(_seen > 0.0)[0]
    if idx.size > 0:
        d = np.abs(res[:, None] - idx[None, :].astype(np.float64))
        nearest = d.min(axis=1)
    else:
        nearest = np.abs(res - mean_item)

    # Base: closer to a reusable residual is better.
    score = -nearest

    # Extra, frequency-weighted bonus for exact matches to a seen size (reuse signal).
    # Normalize so the bonus is bounded and doesn't overwhelm the distance term.
    max_seen = _seen.max()
    if max_seen > 0.0:
        score += np.where(exact_seen, 2.0 * (seen_here / max_seen), 0.0)

    # Mild best-fit tiebreaker: prefer smaller residuals among equal reuse distance.
    score += -0.02 * current = res  # placeholder replaced below

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
