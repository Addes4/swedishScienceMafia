# EVOLVE-BLOCK-START
"""Best fit with exact-fit preference and self-residual reuse bonus.

Best fit (minimize leftover) is the strongest reliable signal here. Exact fills
get a large bonus. Additionally, a leftover equal to the current item size is
slightly favored because a future copy of this item would fill it exactly.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item              # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: prefer tight fits (smaller resulting residual is better).
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)
    # Small bonus when leftover equals the current item size (likely reusable).
    score += np.where(residual == item, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
