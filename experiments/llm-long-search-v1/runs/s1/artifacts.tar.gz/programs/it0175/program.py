# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a common item size (so a future arrival can fill it exactly), falling
back toward a mild preference for residuals near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_cached_count = -1
_nearest = np.zeros(101, dtype=np.float64)
_vals = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _cached_count, _nearest

    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    mean_item = _sum / _count

    # Rebuild distance-to-nearest-common-size vector only when histogram changed
    # meaningfully (every call, but computed once per call, not per bin).
    # Consider only sizes that have appeared at least a reasonable number of times.
    threshold = max(1.0, 0.001 * _count)
    idx = np.nonzero(_hist >= threshold)[0]
    if idx.size > 0:
        d = np.abs(_vals[:, None] - idx[None, :].astype(np.float64))
        _nearest = d.min(axis=1)
    else:
        _nearest = np.abs(_vals - mean_item)

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Score: closer to a reusable residual is better; exact fills dominant.
    score = -_nearest[residual.astype(np.int64)]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
