# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
is likely to be exactly reusable soon (recency-weighted histogram mass at that
residual), with a mild best-fit fallback toward smaller residuals.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted presence of item sizes seen so far.
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Probability mass that this exact residual value is an upcoming item size,
    # using the recency-weighted histogram.
    total_seen = _seen.sum()
    if total_seen > 0:
        prob = _seen / total_seen
    else:
        prob = np.zeros(101, dtype=np.float64)

    # Exact-reusability score (higher residual mass is better).
    reuse = prob[residual.astype(np.int64)]

    # Score: exact fits dominant, later exact reusability, then best-fit fallback.
    score = 1000.0 * (residual == 0).astype(np.float64)
    score += 20.0 * reuse
    score += -0.01 * res

    return score
# EVOLVE-BLOCK-END
