# EVOLVE-BLOCK-START
"""Best fit with mean-capped residual shaping.

Exact fills are strongly preferred. Among non-exact fits we prefer tight
residuals, but give a small bonus only for residuals that are small enough
to plausibly be filled by a typical future item (residual <= mean item size).
Large residuals get no bonus, discouraging the accumulation of unusable slack.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    # Update histogram of seen item sizes.
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: prefer tight fits.
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Lookahead: only reward residuals small enough to be reused by a typical
    # future item. Larger residuals get no bonus (discourage slack buildup).
    if _count > 0:
        mean_item = float(np.dot(np.arange(101), _hist) / _count)
    else:
        mean_item = 40.0

    reusable = (residual > 0) & (res <= mean_item)
    # Concave bonus: smaller residuals slightly favored within the reusable range.
    bonus = np.where(reusable, (mean_item - res) / max(mean_item, 1.0), 0.0)
    score += bonus * 5.0

    return score
# EVOLVE-BLOCK-END
