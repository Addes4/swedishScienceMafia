# EVOLVE-BLOCK-START
"""Best fit with a stationary "reusable residual" objective.

Under the fixed Weibull-shaped item distribution (mean ~40), a residual r is
valuable when it can be exactly completed by future items.  Specifically, if we
place the item and leave residual r, that bin can be reused well when a future
item of size r (or close) arrives.  We therefore score each residual by the
running histogram's smoothed probability mass at that residual, add a strong
exact-fill bonus, and use a mild best-fit tie-breaker.

State is a stable full running histogram, which converges to the stationary
distribution and avoids the noise of a short recency window.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0

# Precompute a smoothing kernel once.
_offsets = np.arange(-3, 4, dtype=np.float64)
_kernel_weights = np.array([1.0, 2.0, 3.0, 4.0, 3.0, 2.0, 1.0], dtype=np.float64)
_kernel_weights /= _kernel_weights.sum()

# Static best-fit slope for residuals (subtle).
_RES_SLOPE = 0.01
_EXACT = 1000.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    if _count > 1.0:
        # Smoothed probability mass assigned to each residual value 0..100.
        counts = _hist.copy()
        prob = counts / _count

        # Smooth via convolution with a small triangular kernel, clipped to [0,100].
        padded = np.concatenate([
            np.zeros(3, dtype=np.float64),
            prob,
            np.zeros(3, dtype=np.float64),
        ])
        smoothed = np.zeros(101, dtype=np.float64)
        for k in range(7):
            smoothed += _kernel_weights[k] * padded[k:k + 101]
    else:
        mean_item = _sum / _count if _count > 0 else 40.0
        smoothed = np.exp(-0.5 * ((np.arange(101, dtype=np.float64) - mean_item) / 15.0) ** 2)
        smoothed /= smoothed.sum()

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.int64)
    resf = residual.astype(np.float64)

    # Reusability: probability that a future item exactly fills this residual.
    score = smoothed[res]

    # Strong exact-fill preference.
    score += np.where(res == 0, _EXACT, 0.0)

    # Mild best-fit tie-breaker: prefer the smaller residual.
    score -= _RES_SLOPE * resf

    return score
# EVOLVE-BLOCK-END

