# EVOLVE-BLOCK-START
"""Best fit with a distributional "fillable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that is
likely to be exactly matched by a future item, estimated from the running
(recency-weighted) histogram of observed item sizes. A mild best-fit term breaks
ties toward smaller residuals.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)   # recency-weighted histogram
_seen = np.zeros(101, dtype=np.float64)   # recency-weighted mass per size
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _seen, _count, _sum
    _hist[item] += 1.0
    _seen *= 0.999
    _seen[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.int64)
    resf = res.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Probability mass that an upcoming item exactly equals residual r.
    # Normalize the recency-weighted histogram.
    total = _seen.sum()
    if total > 0:
        p = _seen / total
    else:
        p = np.zeros(101, dtype=np.float64)

    # Expected exact-fill value of leaving residual r.
    fill_prob = p[res]

    score = fill_prob

    # Mild best-fit preference: smaller residuals are easier to complete.
    score += -0.01 * resf

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.02 * np.abs(resf - mean_item)

    # Strongly prefer exact fills.
    score += np.where(res == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
