# EVOLVE-BLOCK-START
"""Best fit with a stationary "future fillability" objective.

Exact fills are strongly preferred. Otherwise, score a residual by how likely it
is to be exactly filled by future items, estimated from the running histogram:
reward residuals r with high P(item == r), plus a soft term capturing the chance
that the current item combined with common sizes leaves such a residual.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.int64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Smoothed probability that a future item exactly equals a value 0..100.
    # Laplace-style smoothing to avoid zeros and use the stationary distribution.
    total = _hist.sum() + 101.0
    prob = (_hist + 1.0) / total  # shape (101,)

    # Primary reusable-residual term: probability the residual will be exactly filled.
    score = 50.0 * prob[res]

    # Secondary: expected two-item fillability proxy. For residual r, a good sign is
    # that r correlates with common item sizes: reward residuals equal to a size that
    # is itself a common item, weighted by how common it is.
    score += 5.0 * (prob[res] * prob[res])

    # Mild preference for residuals near the running mean (fallback packing).
    score += -0.05 * np.abs(res.astype(np.float64) - mean_item)

    # Strongly prefer exact fills.
    score += np.where(res == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
