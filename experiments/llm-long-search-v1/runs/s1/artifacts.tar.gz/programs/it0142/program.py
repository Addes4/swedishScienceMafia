# EVOLVE-BLOCK-START
"""Best-fit with a recency/distribution-aware reusable-residual bonus.

Exact fills are strongly preferred. Otherwise, prefer the smallest residual
(best fit), with a bonus when the residual matches a size that has been seen
recently and frequently, so it is likely to be filled soon.
"""
import numpy as np

# Recency-weighted histogram over item sizes 1..100.
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_DECAY = 0.9995


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _count += 1.0
    _sum += item
    _hist *= _DECAY
    _hist[item] += 1.0

    residual = bins - item
    res = residual.astype(np.float64)

    # Running mean of item sizes (fallback before enough data).
    mean_item = _sum / _count if _count > 0 else 40.0

    # Probability mass that the exact residual size is a likely upcoming item.
    # Normalize recency-weighted histogram to a per-size probability.
    total = _hist.sum()
    if total > 0.0:
        prob = _hist / total
    else:
        prob = np.zeros(101, dtype=np.float64)

    # Best-fit term: prefer smaller residual (leaves less fragmented space).
    # Scale to be comparable to the probability bonus.
    score = -0.01 * res

    # Reusable-residual bonus: reward residuals that are likely upcoming item sizes.
    res_int = residual.astype(np.int64)
    res_int = np.clip(res_int, 0, 100)
    score += 50.0 * prob[res_int]

    # Mild fallback preference toward the running mean residual (waste ~ mean-like gaps).
    score += -0.05 * np.abs(res - mean_item)

    # Dominant preference for exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

