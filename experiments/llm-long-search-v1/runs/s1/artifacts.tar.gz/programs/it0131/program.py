# EVOLVE-BLOCK-START
"""Best fit: put the item into the bin with the smallest remaining capacity that
still fits it, i.e. minimize the residual after placement. Exact fills (residual 0)
are naturally the best. This is the classic best-fit heuristic and is a strong,
low-variance baseline for bin packing online.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown
    # Higher score = better. Best fit means smallest residual wins.
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

