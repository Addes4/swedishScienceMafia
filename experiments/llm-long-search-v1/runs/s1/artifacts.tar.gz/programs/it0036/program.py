# EVOLVE-BLOCK-START
"""Adaptive: best fit biased by residual utility estimated online from past items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Primary: prefer tight fits (small residual). Add a mild bonus for residuals that
    # are likely reusable, estimated as proximity to the mean item size (~40), and a
    # strong reward for exact fits.
    bonus = np.exp(-((residual - 40.0) ** 2) / (2.0 * 20.0 * 20.0))
    exact = (residual == 0).astype(np.float64)
    return -residual + 0.25 * bonus + 2.0 * exact
# EVOLVE-BLOCK-END
