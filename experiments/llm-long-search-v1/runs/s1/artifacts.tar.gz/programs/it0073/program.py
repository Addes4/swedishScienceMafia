# EVOLVE-BLOCK-START
"""Best fit with exact-fit preference and sliver-avoidance shaping.

Dominant rule: tightest fit (best fit). Strong exact-fill bonus. A small penalty
is applied only to leftovers that are too small to fit any item seen so far,
since those residues are permanently wasted. This keeps the strong best-fit
core while trimming genuinely useless slivers.
"""
import numpy as np

_min_item = 100.0  # smallest item size observed so far


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _min_item
    if item < _min_item:
        _min_item = float(item)

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: prefer tight fits (best fit).
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Penalize only truly unusable leftovers: residual > 0 and residual < smallest
    # item seen so far means no future item can ever fill this gap.
    if _min_item > 1:
        useless = (residual > 0) & (res < _min_item)
        score -= np.where(useless, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END

