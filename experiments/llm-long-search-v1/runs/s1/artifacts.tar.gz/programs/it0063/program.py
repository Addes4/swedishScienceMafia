# EVOLVE-BLOCK-START
"""Best fit with exact-fit preference and empirical residual-reuse shaping.

The core rule is best-fit (tightest fit wins) with a very strong bonus for
exact fills. Layered on top is a small, scale-aware reusability bonus derived
from the empirical distribution of item sizes seen so far: residuals that
look like typical future items are slightly preferred, since they can be
filled exactly by a later item.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities of all fitting bins,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0
    res = residual.astype(np.float64)

    # Dominant best-fit term (prefer tightest fit).
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)
    # Mildly penalize tiny nonzero residuals that are hard to reuse.
    tiny = (residual > 0) & (residual < 5)
    score -= np.where(tiny, res, 0.0)

    # Scale-aware reusability bonus: reward residuals close to typical item sizes.
    if _count > 0:
        p = _hist / _count  # empirical item-size distribution
    else:
        p = np.zeros(101, dtype=np.float64)
        p[40] = 1.0
    # For each residual r, expected "matchability" ~ probability mass near r.
    # Compute a smoothed version of p to allow near matches.
    kernel = np.array([0.25, 0.5, 0.25], dtype=np.float64)
    ps = np.convolve(p, kernel, mode="same")  # length 101
    # Map residual (clipped to 100) to matchability.
    idx = np.clip(residual, 0, 100).astype(np.int64)
    match = ps[idx]
    bonus = match * 20.0
    score += bonus

    return score
# EVOLVE-BLOCK-END
