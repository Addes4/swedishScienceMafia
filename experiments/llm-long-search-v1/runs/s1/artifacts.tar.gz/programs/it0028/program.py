# EVOLVE-BLOCK-START
"""Best fit with a small penalty for creating tiny unusable slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: prefer tightest fit (small residual).
    score = -residual.astype(np.float64)
    # Penalize residuals that are too small to be reused by most future items,
    # but not exact fits (residual == 0), which are ideal.
    tiny = (residual > 0) & (residual < 6)
    score -= 0.5 * tiny
    return score
# EVOLVE-BLOCK-END

