# EVOLVE-BLOCK-START
"""Best fit with a gentle worst-fit tiebreak to limit fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smaller residual (best fit). Tiny secondary: prefer larger original
    # remaining capacity (emptier bin) to avoid shattering already-tight bins.
    return -residual.astype(np.float64) - 1e-3 * (100 - bins)
# EVOLVE-BLOCK-END

