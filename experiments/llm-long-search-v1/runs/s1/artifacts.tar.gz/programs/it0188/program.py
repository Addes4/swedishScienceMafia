# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, rank primarily by smallest
residual (best-fit) but add a strong bonus when the residual exactly equals a
recently-seen item size (so a future arrival can fill it exactly). A mild
preference toward residuals near the running mean serves as a fallback.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted presence of item sizes.
_seen = np.zeros(101, dtype=np.float64)
# Normalized recency weights per residual value (probability mass).
_seen_prob = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen, _seen_prob
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0
    total_seen = _seen.sum()
    if total_seen > 0.0:
        np.divide(_seen, total_seen, out=_seen_prob)
    else:
        _seen_prob[:] = 0.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Base: best-fit -- smaller residual is better.
    score = -res

    # Bonus: residual exactly equals a (recently seen, weighted) item size,
    # i.e. the bin can be exactly filled by a likely future arrival.
    prob = _seen_prob[residual.astype(np.int64)]
    score += 50.0 * prob

    # Mild preference toward residuals near the running mean (fallback).
    score += -0.02 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

