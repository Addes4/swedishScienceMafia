# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference.

Exact fills are strongly preferred. Otherwise, choose the bin with the smallest
remaining capacity that still fits the item (classic Best Fit), which is a very
strong online heuristic for this distribution and avoids the saturating ties
introduced by earlier reuse signals.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Best fit: prefer the smallest residual (tightest fit that still fits).
    score = -res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
