# EVOLVE-BLOCK-START
"""Strong best-fit with exact-fit dominance.

The empirical distribution is Weibull-shaped with mean ~40; for such online
packing, a clean best-fit (smallest residual, exact fits first) is a very
strong and low-variance rule. Histogram-based bonuses were tried repeatedly
and did not help, so we drop them and rely on a robust deterministic core.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of fitting bins, in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown

    # Pure best-fit: smaller residual is better.
    # Add overwhelming dominance for exact fills to be safe against ties.
    score = -residual.astype(np.float64)
    score += np.where(residual == 0, 1e6, 0.0)

    return score
# EVOLVE-BLOCK-END
