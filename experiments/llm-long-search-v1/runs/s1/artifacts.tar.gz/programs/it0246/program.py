# EVOLVE-BLOCK-START
"""Best fit with a probabilistic "fillability" objective.

Exact fills dominate. Otherwise, prefer a residual that is likely to be usefully
consumed by future arrivals: we maintain a recency-decayed histogram of item
sizes and score a residual by the decayed mass of sizes that fit inside it,
plus a small preference for residuals near the running mean.
"""
import numpy as np

# Recency-decayed histogram of observed item sizes (index 0..100).
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0

# Precomputed per-residual fillability table, rebuilt lazily.
_fill_table = None
_fill_dirty = True


def _build_fill_table():
    """fill_table[r] = decayed mass of sizes s (1..r) that fit within residual r."""
    global _fill_table, _fill_dirty
    h = _hist
    # cumulative mass of sizes <= r
    cum = np.cumsum(h)
    cum = np.concatenate(([0.0], cum))  # shift so index r -> mass of sizes <= r
    # fill_table[r] = mass of sizes s with 1 <= s <= r
    _fill_table = cum[:101].astype(np.float64)
    _fill_dirty = False


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _fill_dirty

    _hist *= 0.999
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _fill_dirty = True

    residual = bins - item
    res = residual.astype(np.float64)
    resi = residual.astype(np.int64)

    mean_item = _sum / _count if _count > 0 else 40.0

    if _fill_dirty:
        _build_fill_table()

    # Fillability of the leftover space: decayed mass of sizes that fit in it,
    # normalized so it behaves like a probability of being consumed.
    total = _hist.sum()
    if total > 0.0:
        fill = _fill_table[resi] / total
    else:
        fill = np.zeros_like(res)

    score = 2.0 * fill

    # Mild fallback preference: residuals near the running mean are "typical".
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
