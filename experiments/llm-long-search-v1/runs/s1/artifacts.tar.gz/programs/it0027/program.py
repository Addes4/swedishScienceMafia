# EVOLVE-BLOCK-START
"""Best fit restricted to bins whose residual stays usable (harmonic-style).

Idea: pure best fit tends to stuff the tightest bin, which repeatedly creates
tiny unusable slivers on a heavy-tailed distribution.  Instead we group bins
into classes by how full they are relative to the arriving item and prefer the
tightest class whose resulting residual is still a "useful" leftover (at least
some fraction of the item size).  A short exact-fit shortcut is kept, since
filling a bin completely is always optimal.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since the item fits

    # Exact fit: always best.
    score = -residual.astype(np.float64)

    # Down-weight bins that would leave a sliver smaller than a useful chunk of
    # the item (these residuals are unlikely to be exactly refilled later and
    # mostly waste space).  Push them behind bins that leave a usable residual.
    useful = np.maximum(1, item // 4)  # a quarter of the item size
    sliver = residual < useful
    # Give slivers a large constant penalty so usable residuals rank first, but
    # still prefer tighter slivers among themselves (score stays monotone).
    score[sliver] -= 1000.0

    return score
# EVOLVE-BLOCK-END

