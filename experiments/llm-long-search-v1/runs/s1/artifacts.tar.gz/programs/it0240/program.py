# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective extended to two-item combos.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size OR a recently-seen sum of two item sizes (so
the residual can be cleared by upcoming arrivals), falling back toward a mild
preference for residuals near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted presence of single item sizes.
_seen = np.zeros(101, dtype=np.float64)
# Recency-weighted presence of pairwise sums (quantized to integer in 0..100).
_seen2 = np.zeros(101, dtype=np.float64)
# Decayed list of recent items for pairwise sums.
_recent = []


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen, _seen2, _recent
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0

    # Maintain a short window of recent items and a decayed pairwise-sum signal.
    _seen2 *= 0.997
    _recent.append(item)
    if len(_recent) > 60:
        _recent.pop(0)
    for s in _recent:
        v = item + s
        if 0 <= v <= 100:
            _seen2[v] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Distance to the closest recently-seen single item size.
    idx = np.nonzero(_seen > 0.0)[0]
    if idx.size > 0:
        vals = np.arange(101, dtype=np.float64)
        d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
        nearest = d.min(axis=1)  # shape (101,)
    else:
        nearest = np.abs(np.arange(101, dtype=np.float64) - mean_item)

    # Score: closer to a reusable residual is better; exact fills dominant.
    score = -nearest[residual.astype(np.int64)]

    # Bonus for residuals that are themselves a recently-seen single size
    # (weighted by recency frequency) -- these can be cleared exactly.
    seen_single = _seen[residual.astype(np.int64)] / (_seen.max() + 1e-9)
    score += 0.5 * seen_single

    # Bonus for residuals that match a recently-seen pairwise sum.
    seen_pair = _seen2[residual.astype(np.int64)] / (_seen2.max() + 1e-9)
    score += 0.3 * seen_pair

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
