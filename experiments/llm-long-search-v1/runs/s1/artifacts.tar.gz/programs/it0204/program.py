# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (so the next few arrivals can fill it exactly),
weighted by how frequently/recently that size has been seen, falling back toward
a mild preference for residuals near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Cached array of item sizes seen recently (weighted by recency via decay)
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)
    ridx = residual.astype(np.int64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Build, for each possible residual r (0..100), a reusability mass:
    # dominant weight for seen sizes exactly equal to r, decreasing credit
    # for sizes within 1 and 2 (so near-matches still help a little).
    mass = _seen.copy()
    mass[:-1] += 0.5 * _seen[1:]
    mass[1:] += 0.5 * _seen[:-1]
    if mass.max() <= 0.0:
        mass = np.zeros(101, dtype=np.float64)
    reuse = mass / (mass.max() + 1e-12)

    # Score from reusability of the residual, dominated by exact-fill.
    score = 2.0 * reuse[ridx]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
