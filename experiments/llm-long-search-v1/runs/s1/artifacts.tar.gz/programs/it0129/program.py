# EVOLVE-BLOCK-START
"""Best fit with a probabilistic "reusable residual" objective.

Exact fills are absolutely preferred. Otherwise, prefer residuals r that are
likely to be exactly filled by a future item, i.e. residuals whose size has high
recently-observed frequency. A mild best-fit term breaks ties toward smaller
residuals.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted histogram of seen item sizes for reusability lookup.
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)
    r_idx = residual.astype(np.int64)

    # Probability mass that a future item exactly equals the residual r.
    reuse = _seen / _count if _count > 0 else np.zeros(101, dtype=np.float64)

    # Score: exact reusability dominates.
    score = 50.0 * reuse[r_idx]

    # Mild best-fit tie-breaker toward smaller residuals.
    score += 1.0 / (1.0 + res)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
