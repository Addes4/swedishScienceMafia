# EVOLVE-BLOCK-START
"""Best fit with exact-fit preference and reusable-leftover shaping.

Core ordering is best fit (prefer the smallest residual). Exact fills are
strongly preferred. Leaving a tiny positive residual is penalized because it
is unlikely to be reused. Medium/large residuals get a small bonus so the
packing keeps some reusable space instead of fragmenting.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all shown bins
    res = residual.astype(np.float64)

    # Base: best fit, prefer tight fits.
    score = -res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Penalize tiny positive residuals (hard to reuse, become waste).
    tiny = (residual > 0) & (res < item)
    score -= np.where(tiny, res, 0.0)

    # Mild bonus for medium-plus residuals that future items can reuse.
    if _count > 0:
        mean_item = float(np.dot(np.arange(101), _hist) / _count)
    else:
        mean_item = 40.0
    half_mean = 0.5 * mean_item
    usable = res >= half_mean
    score += np.where(usable, np.minimum(res, mean_item) * 0.05, 0.0)

    return score
# EVOLVE-BLOCK-END
