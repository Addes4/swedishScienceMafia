# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (so the next few arrivals can fill it exactly),
falling back toward a mild preference for residuals near the running mean.
A residual larger than any observed item size cannot be exactly completed by a
single future item, so it is slightly penalized.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Cached array of item sizes seen recently (weighted by recency via decay)
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Largest item size observed so far (a residual beyond this can't be exactly
    # filled by a single future item).
    max_seen = np.nonzero(_hist > 0.0)[0]
    if max_seen.size > 0:
        max_obs = float(max_seen[-1])
    else:
        max_obs = 100.0

    # Distance to the closest recently-seen item size (0 if residual is an observed size).
    idx = np.nonzero(_seen > 0.0)[0]
    if idx.size > 0:
        vals = np.arange(101, dtype=np.float64)
        d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
        nearest = d.min(axis=1)  # shape (101,)
    else:
        nearest = np.abs(np.arange(101, dtype=np.float64) - mean_item)

    # Score: closer to a reusable residual is better; exact fills dominant.
    score = -nearest[residual.astype(np.int64)]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Penalize residuals that are too large to be exactly completed by a single
    # future item (beyond the largest size observed so far).
    score += -0.5 * np.maximum(res - max_obs, 0.0)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
