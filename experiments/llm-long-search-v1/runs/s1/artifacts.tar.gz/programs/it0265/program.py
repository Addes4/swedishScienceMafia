# EVOLVE-BLOCK-START
"""Reuse-aware best fit.

Exact fills win. Otherwise, prefer a residual that exactly matches a
recently-seen item size (so it can be filled exactly soon); tie-break by
smallest residual (classic best fit). Fall back to best fit generally.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item
    res = residual.astype(np.float64)

    mean_item = _sum / _count if _count > 0 else 40.0

    # residual is reusable if it equals a recently-seen item size
    seen_present = _seen > 0.0
    is_reuse = seen_present[residual.astype(np.int64)]

    score = np.zeros(res.shape, dtype=np.float64)

    # Exact fill dominates
    score += np.where(residual == 0, 1000.0, 0.0)

    # Reuse bonus: residual matches a recent item size (exact future fill)
    score += np.where(is_reuse, 500.0, 0.0)

    # Best-fit fallback: prefer smaller residual
    score += -res

    # Mild preference for residual near running mean among non-reuse bins
    score += -0.05 * np.abs(res - mean_item)

    return score
# EVOLVE-BLOCK-END
