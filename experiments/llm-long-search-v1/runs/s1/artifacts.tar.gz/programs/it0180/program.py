# EVOLVE-BLOCK-START
"""Best fit with a soft "matchability" bonus.

Base rule: best fit (smallest residual preferred) — the strongest known online
heuristic here. On top of that, add a strong exact-fill bonus and a soft bonus
for residuals that are close to a common item size (so they can likely be filled
later), using a stable running histogram.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0

# cache for the residual-value index vector
_vals = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Matchability: how likely is a residual r to be exactly fillable by a future item?
    # soft kernel over the running histogram (probability of an item near r).
    p = _hist / _count
    # score(r) = sum_s p[s] * exp(-(r-s)^2 / (2*sigma^2))
    sigma = 3.0
    idx = np.nonzero(_hist > 0.0)[0]
    if idx.size > 0:
        w = p[idx]
        diff = _vals[:, None] - idx[None, :].astype(np.float64)
        K = np.exp(-(diff * diff) / (2.0 * sigma * sigma))
        match = K.dot(w)  # shape (101,)
    else:
        match = np.zeros(101, dtype=np.float64)

    # Base: best fit (smaller residual is better).
    score = -res

    # Soft matchability bonus: residuals likely to be exactly filled rank higher.
    score += 8.0 * match[residual.astype(np.int64)]

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
