# EVOLVE-BLOCK-START
"""Best fit via sum-of-squares residual objective.

Choosing the bin that minimizes the residual after placement is equivalent to
minimizing the sum of squared residuals (Sum-of-Squares heuristic), a strong
online bin-packing rule. Exact fills get a dominant bonus so perfect fits win.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item
    res = residual.astype(np.float64)

    # Sum-of-Squares-style objective: minimizing the new residual, made sharper
    # by a mild squared term. Smaller residual -> higher score.
    score = -res - 0.02 * res * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

