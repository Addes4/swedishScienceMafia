# EVOLVE-BLOCK-START
"""Best fit with a dominant exact-fill bonus.

Items arrive online. Exact fills are strongly preferred (a residual of 0 means
the bin becomes perfectly full). Otherwise use classic Best Fit: choose the bin
with the smallest remaining capacity that still fits the item, i.e. the smallest
nonnegative residual, packing tightly and leaving the largest holes free.
"""
import numpy as np

_count = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum, _mean
    _count += 1.0
    _sum += item
    _mean = _sum / _count

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: best fit -> smallest positive residual is best.
    score = -res

    # Dominant preference for exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
