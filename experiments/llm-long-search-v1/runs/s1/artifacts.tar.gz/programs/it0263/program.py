# EVOLVE-BLOCK-START
"""Exact fill first, then maximize reuse probability of the residual.

The dominant rule is the exact-fill bonus. Among the remaining bins we score
each residual by the recency-decayed probability that some future item (or a
small number of items) will exactly consume that residual, which is a smoother
and far less noisy reuse signal than a nearest-seen-size distance table. A mild
best-fit tiebreaker breaks remaining ambiguity toward smaller residuals.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)   # recency-decayed counts of item sizes
_total = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _total, _sum
    _hist *= 0.999
    _hist[item] += 1.0
    _total = _total * 0.999 + 1.0
    _sum += item

    if _total > 0.0:
        mean_item = _sum / (1.0 + _total / 0.999 - 1.0) if False else 40.0
    # Use running mean of raw items (cheap and stable).
    # (kept simple; the reuse signal is what matters)
    mean_item = 40.0

    residual = bins - item
    res = residual.astype(np.float64)

    # Probability mass function over item sizes 1..100.
    p = _hist[1:]  # sizes 1..100
    ssum = p.sum()
    if ssum > 0.0:
        p = p / ssum
    else:
        p = np.full(100, 1.0 / 100.0)

    # For each possible residual value 1..100 compute the probability that a
    # single future item exactly matches it (index residual-1).
    idx = residual.astype(np.int64)

    # exact single-item match probability
    single = np.where(idx >= 1, p[np.clip(idx, 1, 100) - 1], 0.0)

    # two-item match probability: residual r can be split into a+b=r with
    # probability p[a]*p[b]; compute convolution once per call (cheap, size 100).
    conv = np.convolve(p, p)  # convolution of two size distributions
    two = np.where((idx >= 2) & (idx <= 200), conv[np.clip(idx, 2, 200) - 2], 0.0)

    # reuse score: strongly weight exact single + two-item matches
    reuse = single + 0.5 * two

    score = reuse
    # Mild best-fit preference (smaller residual better) as tiebreaker.
    score += -0.001 * res
    # Dominant exact fill.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

