# EVOLVE-BLOCK-START
"""Histogram-driven "fillable residual" best fit.

Exact fills dominate. Otherwise, prefer leaving a residual whose value has the
highest chance of being matched by a near-future item, estimated from a stable
running histogram of item sizes (Laplace-smoothed), with a mild fallback toward
the running mean. This avoids the noise of short recency windows.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    mean_item = _sum / _count if _count > 0 else 40.0

    # Estimated probability that the next item equals residual value r, for r in 0..100.
    # Laplace-smoothed histogram gives a stable ("fillable residual") signal.
    probs = (_hist + 1.0) / (_count + 101.0)  # shape (101,)

    # Reward residuals that are themselves likely item sizes (high chance of exact future fill).
    score = probs[residual.astype(np.int64)]

    # Mild fallback: residuals near the running mean keep broad fit potential.
    score += -0.01 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
