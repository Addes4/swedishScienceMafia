# EVOLVE-BLOCK-START
"""Exact-fill first, then a frequency-weighted "reusable residual" signal.

Exact fills get a dominant bonus. Among other bins we prefer residuals that
exactly match a recently-seen item size, weighted by how often that size was
seen (recency-decayed), so the most reusable residuals win. A mild distance
penalty to the modal seen size smooths ties, and a tiny best-fit term breaks
remaining ties toward smaller residuals.
"""
import numpy as np

_count = 0.0
_sum = 0.0
# Recency-decayed, frequency-weighted presence of each item size.
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum, _seen
    _count += 1.0
    _sum += item
    # Slower decay keeps more information (less noisy) than 0.999.
    _seen *= 0.997
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Frequency-weighted reuse value for each possible residual 0..100.
    reuse = _seen.copy()
    total_seen = reuse.sum()
    if total_seen <= 0.0:
        reuse[:] = 0.0
        modal = mean_item
    else:
        # normalize so magnitudes are comparable across time
        reuse = reuse / total_seen
        modal = float(np.argmax(_seen))

    # Exact-fillable residuals get a bonus proportional to how often that size appears.
    reuse_score = reuse[residual.astype(np.int64)]

    # Smooth tiebreaker: closeness to the modal seen size.
    modal_dist = np.abs(res - modal)

    score = reuse_score
    score += -0.02 * modal_dist
    # Tiny best-fit term: among otherwise-equal bins, prefer smaller residuals.
    score += -0.001 * res
    # Dominant preference for exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
