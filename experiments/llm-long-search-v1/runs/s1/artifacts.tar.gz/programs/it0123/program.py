# EVOLVE-BLOCK-START
"""Best fit with a target-residual objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual close
to a target slightly above the typical item size: residuals a bit larger than
the mean are the most reusable by future items (one large item can still fit,
and mid-size items pair well).
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Target residual slightly above the mean item size: roomier bins are safer
    # and still reusable, but not wastefully empty.
    target = mean_item + 20.0

    # Distance from the target residual: smaller is better.
    score = -np.abs(res - target)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

