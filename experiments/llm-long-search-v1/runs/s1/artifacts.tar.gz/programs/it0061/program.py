# EVOLVE-BLOCK-START
"""Best fit with a reusable-leftover guard.

Score = best fit (most negative residual), strong bonus for exact fills, and a
penalty for leaving a residual so small that no future item is likely to reuse
it. The threshold scales with the running mean item size.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: best fit (prefer tight fits).
    score = -res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Penalize residuals too small to be reused by future items.
    if _count > 1.0:
        mean_item = float(np.dot(np.arange(101), _hist) / _count)
    else:
        mean_item = 40.0
    thresh = 0.5 * mean_item
    too_small = (residual > 0) & (res < thresh)
    score -= np.where(too_small, (thresh - res) * 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
