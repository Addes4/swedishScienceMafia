# EVOLVE-BLOCK-START
"""Best fit with an expected-fill reuse bonus.

Exact fills dominate. For non-exact candidates, prefer leaving a residual that
the running empirical item distribution is likely to be able to fill soon
(smoothed probability of an exact match), with a mild best-fit (smaller
residual) tiebreak.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_alpha = 2.0  # Laplace-ish smoothing

# Precomputed residual value table (depends on the histogram, cheap to recompute
# incrementally; we keep it simple and recompute when needed).


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count

    # Update running histogram.
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Smoothed probability that an item equals residual value r (0..100).
    total = _count + _alpha * 101.0
    probs = (_hist + _alpha) / total  # shape (101,)

    # Expected immediate-fill value of leaving residual r: likelihood that the
    # next item exactly fills it (capped implicitly as a probability).
    fill_val = probs  # shape (101,), value ~[0,1]

    score = fill_val[residual.astype(np.int64)]

    # Mild best-fit preference: prefer smaller residuals to avoid fragmentation.
    score += -0.01 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
