# EVOLVE-BLOCK-START
"""Best fit with a residual-usefulness bonus tuned to the item distribution."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer tight fits (small residual), but give a bonus when the residual is close
    # to the typical item size (~40), so leftover space in a bin is likely to be reusable.
    tightness = -residual.astype(np.float64)
    usefulness = -np.abs(residual - 40).astype(np.float64) * 0.25
    return tightness + usefulness
# EVOLVE-BLOCK-END
