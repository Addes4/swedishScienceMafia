# EVOLVE-BLOCK-START
"""Best fit with a mild bonus for residuals near the distribution mean."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    score = -residual.astype(np.float64)
    # Mild bonus to break ties toward residuals near the mean item size (~40).
    score += 0.01 * (residual == 40)
    return score
# EVOLVE-BLOCK-END
