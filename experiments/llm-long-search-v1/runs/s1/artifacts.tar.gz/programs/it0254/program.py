# EVOLVE-BLOCK-START
"""Best fit with a dominant exact-fill rule, strengthened by a "fillability" signal.

Exact fills are strongly preferred. Among the rest, prefer the smallest residual
(best-fit, which packs tightly and is the classic strong online rule), with a
mild bonus for residuals that are likely to be exactly filled by a future item
size estimated from a recency-decayed histogram of past items.
"""
import numpy as np

# Recency-decayed histogram of observed item sizes (index 0..100).
_seen = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _seen, _count
    _seen *= 0.999
    _seen[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)
    ri = residual.astype(np.int64)

    # Normalized recency histogram: probability a random future item size equals s.
    if _count > 1.0:
        p = _seen / _seen.sum()
    else:
        p = None

    # Best-fit: prefer smaller residual (tighter packing), scaled mildly.
    score = -0.6 * res

    # Mild bonus: probability that the residual is exactly fillable by a likely item.
    if p is not None:
        score += 3.0 * p[ri]

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
