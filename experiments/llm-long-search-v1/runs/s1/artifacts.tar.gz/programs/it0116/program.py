# EVOLVE-BLOCK-START
"""Best fit with a histogram-based exact-match probability bonus.

Exact fits dominate; otherwise we minimize residual (best fit), and we add a
bonus proportional to the empirical probability that the resulting residual will
be exactly matched by a future item, using a smoothed running histogram.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_alpha = 1.0  # Laplace smoothing


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    # Update histogram of seen item sizes.
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: prefer tight fits (minimize residual).
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Probability that a future single item exactly equals this residual.
    # Smoothed empirical distribution over item sizes 1..100.
    total = _count + _alpha * 100.0
    # p[r] = P(next item size == r), for r in 0..100 (r=0 handled above).
    p = (_hist + _alpha) / total  # length 101, index 0 unused
    # Map residuals to probabilities (residual in 0..100).
    prob = p[np.clip(residual, 0, 100)]
    score += prob * 200.0

    return score
# EVOLVE-BLOCK-END

