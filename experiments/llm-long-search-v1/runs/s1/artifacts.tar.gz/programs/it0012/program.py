# EVOLVE-BLOCK-START
"""Best fit with an amortized sliver-avoidance penalty.

Pure best fit minimizes the immediate residual, which often leaves tiny unusable
slivers.  We keep the tightest-fit ordering but add a small penalty for residuals
that are smaller than the arriving item (those gaps are unlikely to ever be
filled by a future item), nudging the choice toward fits whose leftover space is
comparable to a typical item size.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item
    # Base: prefer tightest fit (smallest residual).
    base = -residual
    # Penalize tiny slivers that are smaller than the current item.
    sliver = np.maximum(0, item - residual)
    return base - 0.15 * sliver
# EVOLVE-BLOCK-END

