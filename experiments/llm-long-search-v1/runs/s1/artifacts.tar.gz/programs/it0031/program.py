# EVOLVE-BLOCK-START
"""Best fit with a slight preference for reusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    return -1.05 * residual + 0.05 * np.minimum(residual, 100 - item)
# EVOLVE-BLOCK-END
