# EVOLVE-BLOCK-START
"""Best fit guided by exact-fill potential from a smoothed item-size histogram.

For each candidate residual r = bin_capacity - item, we estimate the chance that a
future item will exactly fill that residual (using a heavily-smoothed histogram of
past item sizes). Exact fills get a large bonus, and a mild pull toward smaller
residuals discourages fragmentation.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0

# Precomputed smoothing helpers reused each call.
_vals = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Smoothed fill-probability per residual value (0..100).
    # Blend the empirical histogram with a broad kernel so unseen sizes still score.
    dens = _hist + 0.5
    kernel = np.exp(-0.5 * ((_vals[:, None] - _vals[None, :]) / 6.0) ** 2)
    smooth = kernel @ dens
    if smooth.max() > 0:
        smooth = smooth / smooth.max()
    fill_score = smooth[residual.astype(np.int64)]

    score = 3.0 * fill_score

    # Mild preference for smaller residuals (best-fit-ish) to limit fragmentation.
    score += -0.02 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
