# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, among the remaining bins we use a
best-fit (smaller residual first) preference, lightly nudged toward residuals
that can still be exactly completed by likely future item sizes.
"""
import numpy as np

_count = 0.0
_sum = 0.0
# Recency-weighted histogram of item sizes (decayed each call).
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum, _seen
    _count += 1.0
    _sum += item
    _seen *= 0.997
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    mean_item = _sum / _count if _count > 0 else 40.0

    # Best-fit: prefer smaller residuals (packs tightly).
    score = -res

    # Mild preference for residuals near the running mean.
    score += -0.02 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
