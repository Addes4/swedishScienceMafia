# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective, computed cheaply.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
is likely to be matched by a future item size. We estimate that likelihood from
a recency-weighted histogram of past item sizes, but with a smooth two-sided
kernel so that near-matches still differentiate bins (avoiding discrete ties).
A mild best-fit component breaks remaining ties.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)   # recency-weighted histogram
_count = 0.0
_sum = 0.0

# Smooth two-sided reuse kernel: for each residual r, reusability[r] is a
# sliding weighted sum of histogram mass within a small window.
_KERN = np.array([0.0, 1.0, 2.0, 1.0, 0.0], dtype=np.float64)  # offsets -2..2
_VALS = np.arange(101, dtype=np.float64)


def priority(item, bins):
    global _hist, _count, _sum
    _count += 1.0
    _sum += item
    # Decay histogram, then boost this item (recency weighting).
    _hist *= 0.999
    _hist[item] += 1.0

    residual = bins - item
    res = residual.astype(np.float64)

    # Reusability of each possible residual in [0,100]: weighted histogram mass
    # near it. Conv of histogram with a small symmetric kernel.
    reus = np.convolve(_hist, _KERN, mode="same")

    # Score: likelihood of future exact reuse of this residual.
    score = reus[residual.astype(np.int64)]

    # Mild best-fit tiebreaker: slightly prefer smaller positive residual.
    score += -0.001 * res

    # Dominant exact-fill bonus.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
