# EVOLVE-BLOCK-START
"""Best fit with an early-bin tiebreaker to consolidate into already-used bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize residual (best fit). Secondary: prefer earlier bins (more used).
    # Small epsilon on index ensures it only breaks exact ties in residual.
    idx = np.arange(bins.shape[0])
    return -residual.astype(np.float64) - 1e-6 * idx
# EVOLVE-BLOCK-END
