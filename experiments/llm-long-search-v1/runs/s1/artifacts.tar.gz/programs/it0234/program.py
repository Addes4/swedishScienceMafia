# EVOLVE-BLOCK-START
"""Best fit with a mean-residual (fit-potential) objective.

Exact fills are strongly preferred. Otherwise, keep bins at a residual that
maximizes future fit potential: a residual near the running mean item size is
best, since it is most likely to be fillable by the next arrival. This is a
cheap closed-form objective with no per-call distance tables.
"""
import numpy as np

_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    mean_item = _sum / _count if _count > 0 else 40.0

    # Prefer residuals near the running mean item size (best future fill potential).
    score = -np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
