# EVOLVE-BLOCK-START
"""Expected-fill bin-choice rule.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that a
plausibly-arriving next item will fit exactly, weighted by the smoothed recency
histogram of item sizes. Fallback pulls residuals toward the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_decay_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _decay_hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted histogram of item sizes.
    _decay_hist *= 0.999
    _decay_hist[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Expected number of future items that exactly fill a residual of value r:
    # proportional to the (decayed) empirical frequency of item size r.
    freq = _decay_hist
    total = freq.sum()
    if total > 0.0:
        p = freq / total
    else:
        p = np.zeros(101, dtype=np.float64)

    # Build lookup: expected immediate reuse value for residual value 0..100.
    # Also blend in probability of a near-exact fill (item slightly smaller than residual).
    vals = np.arange(101, dtype=np.float64)
    # exact-fill probability for residual r
    exact_p = p.copy()
    # near fill: probability mass of sizes within a small window below r (leaves small waste,
    # which is fine and keeps reuse flexible)
    kernel = np.array([0.0, 0.06, 0.14, 0.24, 0.16, 0.06], dtype=np.float64)
    near_p = np.zeros(101, dtype=np.float64)
    for off, w in enumerate(kernel):
        if off == 0:
            continue
        shifted = np.zeros(101, dtype=np.float64)
        if off < 101:
            shifted[:-off] = p[off:]
        near_p += w * shifted
    reuse_value = exact_p + near_p

    score = reuse_value[residual.astype(np.int64)]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
