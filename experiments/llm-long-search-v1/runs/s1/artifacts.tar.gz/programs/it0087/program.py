# EVOLVE-BLOCK-START
"""Best fit with residual-reuse awareness.

Dominant rule is best-fit (tightest residual) with a strong exact-fit bonus.
A residual gets a modest bonus based on how likely it can still accommodate a
future item, estimated from the running empirical item-size histogram.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_cum = np.zeros(102, dtype=np.float64)  # cumulative counts, _cum[s] = #items <= s


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _hist, _count, _cum
    _hist[item] += 1.0
    _count += 1.0
    _cum[:] = np.cumsum(_hist)

    residual = bins - item
    res = residual.astype(np.float64)

    # Dominant: best-fit (tightest residual).
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 10000.0, 0.0)

    # Bonus for residuals likely reusable by a future item, from the empirical
    # histogram: probability that an item fits is _cum[res]/_count.
    if _count > 0:
        idx = np.clip(residual, 0, 101).astype(np.int64)
        p_fit = _cum[idx] / _count
        # Scale small enough not to overturn best-fit ordering significantly,
        # but large enough to prefer more-reusable leftovers among close fits.
        score += p_fit * 0.05

    return score
# EVOLVE-BLOCK-END
