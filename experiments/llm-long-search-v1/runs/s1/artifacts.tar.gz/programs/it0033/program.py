# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware residual bonus.

Primary rule is still tight fit (largest residual that is <= item -> closest residual).
Among bins whose residual is close to the item, prefer residuals that are more likely
to be useful for future items, estimated online from the observed item-size histogram.
"""
import numpy as np


class _State:
    def __init__(self):
        # recency-weighted histogram over sizes 1..100
        self.hist = np.zeros(101, dtype=np.float64)
        self.decay = 0.995
        self.n = 0

    def update(self, item):
        self.hist *= self.decay
        self.hist[item] += 1.0
        self.n += 1


_state = _State()


def priority(item, bins):
    _state.update(item)

    # Empirical probability mass of each residual (normalized)
    h = _state.hist
    total = h.sum()
    if total > 0:
        p = h / total
    else:
        p = h

    # Primary: tight fit. bins residual >= item always (harness filters), residual r.
    # Closeness: smaller (r - item) is better.
    slack = bins - item

    # Bonus: expected usefulness of the leftover r' = r - item.
    # Sum of probabilities of future item sizes <= r' (chance the residual is fillable),
    # weighted by how close to fully used. Use cumulative distribution up to r'.
    cdf = np.cumsum(p)  # cdf[s] = P(size <= s)
    # vectorized gather of cdf[slack]
    usb = cdf[np.clip(slack, 0, 100)]

    # Slight preference for smaller leftover (= less wasted capacity), plus reuse bonus.
    # Scale so that a one-unit difference in slack dominates reuse differences.
    return -slack.astype(np.float64) + 2.0 * usb
# EVOLVE-BLOCK-END
