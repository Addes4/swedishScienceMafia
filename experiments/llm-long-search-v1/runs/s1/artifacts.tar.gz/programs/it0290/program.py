# EVOLVE-BLOCK-START
"""Worst-fit with a strong exact-fill bonus.

Items are Weibull-shaped (mean ~40). Exact fills are strongly preferred. Otherwise
prefer the largest residual, which keeps bins open and avoids prematurely fragmenting
bins for the large items that still arrive, a robust choice under the heavy tail.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Prefer larger residuals (worst fit): keep the most room available.
    score = res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
