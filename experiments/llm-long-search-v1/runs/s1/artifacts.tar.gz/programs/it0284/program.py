# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (so the next few arrivals can fill it exactly),
with a mild preference for larger residuals (more room for future items).
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Cached array of item sizes seen recently (weighted by recency via decay)
_seen = np.zeros(101, dtype=np.float64)

# Precomputed distance-to-nearest-seen-size table, refreshed lazily.
_nearest = None
_dirty = True


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen, _nearest, _dirty
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0
    _dirty = True

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Distance to the closest recently-seen item size (0 if residual is an observed size).
    if _dirty:
        idx = np.nonzero(_seen > 0.0)[0]
        if idx.size > 0:
            vals = np.arange(101, dtype=np.float64)
            d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
            _nearest = d.min(axis=1)  # shape (101,)
        else:
            _nearest = np.abs(np.arange(101, dtype=np.float64) - mean_item)
        _dirty = False

    # Score: closer to a reusable residual is better; exact fills dominant.
    score = -_nearest[residual.astype(np.int64)]

    # Mild preference for larger residuals (more future room) as a fallback.
    score += 0.05 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

