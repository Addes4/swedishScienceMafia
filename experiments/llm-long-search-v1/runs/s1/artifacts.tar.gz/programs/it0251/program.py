# EVOLVE-BLOCK-START
"""Best fit with a probability-weighted fillability tie-break.

Exact fills dominate. Otherwise, among fitting bins, prefer the residual that is
most likely to be "completable" by a single future item, estimated from a
recency-decayed histogram of observed item sizes. Falls back to a mild best-fit
(smallest residual) preference.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_decay = 0.999


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist
    # Update recency-weighted histogram of observed item sizes.
    _hist *= _decay
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.int64)

    # Exact fill: dominant.
    score = np.where(residual == 0, 1000.0, 0.0)

    # Fillability: probability that a future item s exactly matches residual r,
    # weighted toward "smaller residual is better" as a fallback.
    total = _hist.sum()
    if total > 0:
        prob = _hist / total
    else:
        prob = np.full(101, 1.0 / 101.0)

    # value[r] = probability of an exact future fill of residual r
    value = prob.copy()

    # Small best-fit fallback: prefer smaller residual (tighter packing).
    score += value[res] * 100.0
    score += -0.01 * res

    return score
# EVOLVE-BLOCK-END
