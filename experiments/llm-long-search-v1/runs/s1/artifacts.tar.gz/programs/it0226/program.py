# EVOLVE-BLOCK-START
"""Worst-fit-ish anti-fragmentation rule.

Prefer to keep bins in the "large residual" regime: a residual of 67+ can still
hold another big item, 34+ a medium one, etc. Score bins by a step function of
their residual minus the incoming item, rewarding residuals near those
thresholds, topped with a dominant exact-fill bonus.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Anti-fragmentation: reward being in a coarse residual bucket.
    # Buckets keyed on thresholds {100, 67, 34, 1, 0}.
    bucket = np.zeros_like(res)
    np.add(bucket, 4.0, out=bucket, where=res >= 67)
    np.add(bucket, 3.0, out=bucket, where=(res >= 34) & (res < 67))
    np.add(bucket, 2.0, out=bucket, where=(res >= 1) & (res < 34))

    # Strongly prefer exact fills.
    exact = (residual == 0).astype(np.float64) * 1000.0

    return bucket + exact
# EVOLVE-BLOCK-END
