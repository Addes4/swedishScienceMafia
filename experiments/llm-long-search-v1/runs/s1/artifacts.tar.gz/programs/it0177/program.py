# EVOLVE-BLOCK-START
"""Best fit with a probability-weighted reusable residual objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that is
a likely future item size (weighted by its running probability), so the bin can
be filled exactly later. Among equally good residuals, prefer smaller ones
(best fit) to avoid stranding capacity.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.int64).clip(0, 100)
    resf = residual.astype(np.float64)

    # Probability that a future item equals each possible residual value.
    if _count > 1.0:
        prob = _hist / _count
    else:
        prob = _hist

    # Reuse potential: how likely is this residual to be filled exactly next?
    reuse = prob[res]

    score = reuse * 1.0

    # Mild best-fit preference: smaller residual is slightly better.
    score += -0.02 * resf

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

