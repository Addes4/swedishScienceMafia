# EVOLVE-BLOCK-START
"""Best fit with a smooth "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
is close to a recently-seen item size (so upcoming arrivals can fill it), using
a smooth Gaussian kernel over the recency-weighted item histogram to avoid the
discrete-tie collapse, with a mild fallback toward residuals near the mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)

# Precompute residual value axis once.
_VALS = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = (bins - item).astype(np.int64)
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Smooth reuse signal: Gaussian kernel over recency-weighted histogram.
    # Weighted mass near each residual r.
    sigma = 4.0
    diff = _VALS[:, None] - _VALS[None, :]  # (101,101)
    kernel = np.exp(-0.5 * (diff / sigma) ** 2)
    reuse = kernel @ _seen  # shape (101,)

    # Score: higher reuse for the residual is better.
    score = reuse[residual]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
