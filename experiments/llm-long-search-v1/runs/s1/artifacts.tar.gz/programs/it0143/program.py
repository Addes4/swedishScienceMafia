# EVOLVE-BLOCK-START
"""Best fit with a stable "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a frequently-seen item size (so upcoming arrivals can fill it exactly),
with a mild fallback toward residuals near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Stable, recency-weighted presence set.
    seen_present = _seen > 0.0
    idx = np.nonzero(seen_present)[0]
    if idx.size > 0:
        vals = np.arange(101, dtype=np.float64)
        d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
        nearest = d.min(axis=1)
    else:
        nearest = np.abs(np.arange(101, dtype=np.float64) - mean_item)

    # Base: closer to a reusable residual is better.
    # Cap the distance so far-off residuals don't get wildly different scores.
    score = -np.minimum(nearest[residual.astype(np.int64)], 20.0)

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
