# EVOLVE-BLOCK-START
"""Best fit with a small deterministic dithering of near-ties.

Pure best fit can lock into leaving many small unusable slivers.  We keep the
tightest-fit ordering as the primary criterion but perturb the score slightly
with a deterministic pseudo-random term derived from (item, residual, bin
capacity).  Because bin capacities are uniquely determined per call and the
perturbation is tiny, well-separated fits are unaffected while near-ties are
broken in a way that reduces pathological sliver accumulation.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, first on ties."""
    residual = bins - item            # capacity left after placing the item
    # Primary: tightest fit (smallest residual is best).
    score = -residual.astype(np.float64)
    # Tiny deterministic jitter to break exact/near ties, magnitude < 0.5 so it
    # cannot reorder bins whose residual differs by >= 1.
    # Hash-like mix of item size, bin capacity and residual, kept in [0, 0.4).
    h = (residual * 2654435761 + bins * 40503 + item * 97) & 1023
    score += (h.astype(np.float64)) * (0.4 / 1024.0)
    return score
# EVOLVE-BLOCK-END
