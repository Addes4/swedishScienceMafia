# EVOLVE-BLOCK-START
"""Best-fit with a soft "keep room for a mean-sized item" preference.

Exact fills are strongly preferred. Otherwise we use best-fit (smaller residual),
but slightly reward leaving a residual that is at least the running mean item
size, so that a typical future item can still be placed without overflow.
"""
import numpy as np

_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Best-fit base: prefer smaller residual (tighter packing).
    score = -res

    # Mildly reward leaving enough room to fit a mean-sized future item.
    # (band just at/above the mean is best; too large wastes; too small blocks).
    score += 0.5 * np.where(res >= mean_item, 1.0, 0.0)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

