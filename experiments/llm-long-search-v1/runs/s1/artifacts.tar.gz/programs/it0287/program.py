# EVOLVE-BLOCK-START
"""Exact-fill priority with a distribution-aware expected-reuse score.

For each candidate bin residual r we estimate the probability p(r) that some
future item exactly equals r (from a running empirical distribution of item
sizes).  Exact fills get a large bonus; among the rest we prefer residuals with
the highest estimated exact-reuse probability, breaking ties toward smaller
residuals (best fit) to keep bins tight.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.int64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Smoothed probability that a future item exactly equals each residual value.
    # Use the empirical histogram with Laplace-style smoothing so unseen sizes
    # still get a small positive mass based on the overall shape.
    p = _hist.copy()
    # light smoothing with neighbors to reduce noise
    sm = p.copy()
    sm[1:] += p[:-1]
    sm[:-1] += p[1:]
    total = sm.sum()
    if total > 0:
        prob = sm / total
    else:
        prob = np.full(101, 1.0 / 101.0)

    score = prob[res]

    # Exact fills strongly preferred.
    score += np.where(res == 0, 1000.0, 0.0)

    # Mild best-fit pull: among similar reuse potentials prefer smaller residual.
    score += -0.001 * res

    # tiny fallback toward residuals near the running mean
    score += -0.0005 * np.abs(res.astype(np.float64) - mean_item)

    _count += 1.0
    _sum += item

    return score
# EVOLVE-BLOCK-END

