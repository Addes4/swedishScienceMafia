# EVOLVE-BLOCK-START
"""Best fit with a minimum-useful-leftover threshold.

Put the item in the bin it fits most tightly, but never create a sliver
whose leftover is in (0, T) if a bin leaving leftover == 0 or leftover >= T
exists. This prevents bins from being filled up to almost-capacity and then
abandoned with a useless residual.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since bins only contains bins the item fits in
    T = 10

    # 0) exact fit -> best
    exact = residual == 0
    # 1) leftover at least T -> acceptable
    big = residual >= T
    # 2) sub-threshold sliver -> penalized
    small = ~exact & ~big

    # Base score: prefer tightest fit.
    score = -residual.astype(np.float64)
    # Penalize sub-threshold slivers strongly so any exact or big-leftover bin wins.
    score[small] -= 1e6
    return score
# EVOLVE-BLOCK-END
