# EVOLVE-BLOCK-START
"""Best fit with distribution-aware leftover scoring.

Exact fills dominate. Among non-exact placements the base is best-fit, but we
add a bonus proportional to how likely the leftover residual is to be exactly
consumed by a future item, estimated from the empirical size histogram.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    # Update histogram of seen item sizes.
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: prefer tight fits.
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)
    # Penalize tiny nonzero residuals (likely useless leftovers).
    small = (residual > 0) & (residual < item)
    score -= np.where(small, res, 0.0)

    # Distribution-aware reusability: reward residuals that match frequently
    # seen item sizes, so leftovers are more likely to be exactly refilled.
    if _count > 0:
        prob = _hist / _count
        # residual indexes into histogram; clip to valid range.
        idx = np.clip(residual, 0, 100)
        reuse = prob[idx]
    else:
        reuse = np.zeros_like(res)
    score += reuse * 100.0

    return score
# EVOLVE-BLOCK-END

