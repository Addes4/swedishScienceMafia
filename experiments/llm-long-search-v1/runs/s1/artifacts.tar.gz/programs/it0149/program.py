# EVOLVE-BLOCK-START
"""Best fit with a stable histogram-based "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual r that
is a likely upcoming item size, measured by the smoothed running histogram of
item sizes (a stable estimate of the stationary distribution), with a mild
best-fit tie-breaker toward smaller residuals.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0

# Precompute a small smoothing kernel once.
_kernel = None


def _get_kernel():
    global _kernel
    if _kernel is None:
        # Gaussian-ish smoothing over residual values 0..100
        x = np.arange(101, dtype=np.float64)
        sigma = 2.0
        k = np.exp(-0.5 * ((x[:, None] - x[None, :]) / sigma) ** 2)
        k /= k.sum(axis=1, keepdims=True)
        _kernel = k
    return _kernel


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Smoothed probability mass at each residual value 0..100.
    h = _hist.copy()
    if h.sum() > 0:
        h /= h.sum()
    k = _get_kernel()
    smoothed = k @ h  # shape (101,), probability-like value per residual

    # Higher mass => residual is a likely upcoming item size => reusable.
    score = smoothed[residual.astype(np.int64)]

    # Mild preference for residuals near the running mean as a fallback / tie-break.
    score += -0.02 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
