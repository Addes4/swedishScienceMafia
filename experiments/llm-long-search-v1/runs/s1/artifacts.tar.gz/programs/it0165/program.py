# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer residuals that the
running item-size distribution says are likely to be exactly filled by a
single future item (high P(item == residual)), with a secondary term that
rewards residuals reachable by a sum of two typical items (so multi-step
fills remain possible). A mild best-fit tie-break breaks near-ties.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0

# Precomputed convolution of the histogram with itself (sum of two items),
# maintained lazily to avoid recomputation every call.
_conv = None
_conv_dirty = True
_last_count = -1.0


def _rebuild_conv():
    global _conv, _last_count
    p = _hist / max(_count, 1.0)
    _conv = np.convolve(p, p)  # length 201, index s means P(a+b == s)
    _last_count = _count


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    global _hist, _count, _sum, _conv_dirty

    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _conv_dirty = True

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)
    ri = residual.astype(np.int64)

    # Rebuild the two-item convolution only occasionally (cheap relative to
    # total work); every 25 arrivals is plenty given the stationary dist.
    if _conv is None or (_conv_dirty and int(_count) % 25 == 0):
        _rebuild_conv()
        _conv_dirty = False

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    if _conv is not None:
        p = _hist / max(_count, 1.0)
        # Probability that a single future item exactly equals the residual.
        p_single = p[ri]
        # Probability that a pair of future items sums to the residual.
        p_pair = _conv[ri] if _conv.shape[0] > ri.max() else np.zeros_like(res)
    else:
        p_single = np.zeros_like(res)
        p_pair = np.zeros_like(res)

    # Exact fills dominate.
    exact = np.where(ri == 0, 1000.0, 0.0)

    # Reward residuals likely to be exactly filled by a single future item,
    # with a smaller weight on the two-item fillability.
    reuse = 50.0 * p_single + 10.0 * p_pair

    # Mild best-fit fallback: prefer smaller residuals when all else equal.
    bestfit = -0.02 * res

    return exact + reuse + bestfit
# EVOLVE-BLOCK-END

