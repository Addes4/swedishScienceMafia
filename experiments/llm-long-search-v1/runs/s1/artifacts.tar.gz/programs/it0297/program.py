# EVOLVE-BLOCK-START
"""Sharpened best-fit with a mild mean-residual pull.

Exact fills dominate. For non-exact candidates we use a smooth, convex penalty on
the residual (sharp best-fit) plus a small tilt toward the running mean residual,
which historically tracks the optimal open-bin profile on Weibull-like streams.
"""
import numpy as np

_count = 0.0
_sum = 0.0
_EXACT = 1e6


def priority(item, bins):
    global _count, _sum
    _count += 1.0
    _sum += item
    mean_item = _sum / _count if _count > 0 else 40.0

    residual = (bins - item).astype(np.float64)

    # Sharp best-fit: strongly penalize larger residuals (convex in residual).
    score = -(residual * residual) * 1e-3

    # Very mild tilt toward residuals near the running mean.
    score += -1e-3 * np.abs(residual - mean_item)

    # Strong exact-fill preference.
    score += np.where(residual == 0.0, _EXACT, 0.0)

    return score
# EVOLVE-BLOCK-END
