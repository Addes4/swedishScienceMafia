# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and a running-mean reuse bonus."""
import numpy as np

_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum
    _count += 1.0
    _sum += item

    residual = bins - item              # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 1:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Best-fit: prefer smaller residual (tighter packing).
    score = -res

    # Mild reuse bonus: residual near running-mean item size is likely refillable.
    score += -0.1 * np.abs(res - mean_item)

    # Dominant exact-fill preference.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
