# EVOLVE-BLOCK-START
"""Best fit with a lightweight forward-looking reuse estimate.

Best-fit ordering stays dominant; among residuals that are nearly as tight as
the tightest fit, prefer the one whose leftover capacity can still absorb the
most expected future item mass under the empirical size distribution.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_value_cache = np.zeros(101, dtype=np.float64)
_cache_ver = -1
_ver = 0


def _reuse_value(mean_item):
    """Estimate how reusable a residual r is (larger is better)."""
    global _value_cache, _cache_ver, _ver
    if _cache_ver == _ver:
        return _value_cache
    # Simple greedy expected-packing value: number of mean-sized items that
    # could fit plus a bonus for matching common exact sizes directly.
    r = np.arange(101, dtype=np.float64)
    val = r / max(mean_item, 1.0)
    # Bonus for residuals that frequently correspond to arriving item sizes.
    val += _hist / max(_count, 1.0) * 5.0
    _value_cache = val
    _cache_ver = _ver
    return val


def priority(item, bins):
    """Rank bins; item goes to the highest score (first on ties)."""
    global _hist, _count, _ver

    _hist[item] += 1.0
    _count += 1.0
    _ver += 1

    residual = bins - item
    res = residual.astype(np.float64)

    mean_item = float(np.dot(np.arange(101), _hist) / _count) if _count > 0 else 40.0
    val = _reuse_value(mean_item)

    # Dominant best-fit term.
    score = -res
    # Strong preference for exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)
    # Break near-ties toward reusable leftovers, scaled small so best-fit dominates.
    score += 0.05 * val[bins]

    return score
# EVOLVE-BLOCK-END
