# EVOLVE-BLOCK-START
"""Best fit with residual-quality shaping.

Exact fits are strongly preferred, tiny nonzero residuals are penalized (such
leftovers are almost never reusable), medium residuals get a small reuse bonus,
and above all the rule prefers to leave a residual at least as large as the
item, so equal-sized items can pair up.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    # Update histogram of seen item sizes.
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: prefer tight fits (best fit).
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)
    # Penalize tiny nonzero residuals (likely useless leftovers); a residual
    # smaller than the current item can never host another item this large.
    small = (residual > 0) & (residual < item)
    score -= np.where(small, res, 0.0)

    # Extra: residuals below ~10 are near-dead for this distribution (items that
    # small are rare), so strongly avoid leaving them.
    tiny = (residual > 0) & (residual < 10)
    score -= np.where(tiny, 8.0, 0.0)

    # Lookahead: bonus for residuals large enough to be reused by future items.
    # Use the empirical mean item size seen so far as the target scale.
    if _count > 0:
        mean_item = float(np.dot(np.arange(101), _hist) / _count)
    else:
        mean_item = 40.0
    # Concave bonus peaking near mean_item: larger residuals are more reusable.
    bonus = np.minimum(res, mean_item) * 0.1
    score += bonus

    return score
# EVOLVE-BLOCK-END
