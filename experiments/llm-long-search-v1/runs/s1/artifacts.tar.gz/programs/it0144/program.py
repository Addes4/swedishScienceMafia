# EVOLVE-BLOCK-START
"""Best fit with a smooth "residual reuse likelihood" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
is itself a likely upcoming item size, estimated from a recency-weighted
histogram of past items (smoothed), with a tiny best-fit tie-breaker.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_pdf = np.zeros(101, dtype=np.float64)  # smoothed, recency-weighted residual score table

_DECAY = 0.999


def _rebuild():
    """Build a smooth table: score[r] = likelihood an upcoming item equals r."""
    global _pdf
    h = _hist
    total = h.sum()
    if total <= 0.0:
        _pdf = np.ones(101, dtype=np.float64)
        return
    p = h / total
    # Smooth with a small triangular kernel (size 2) to avoid brittle spikes.
    k = np.array([0.25, 0.5, 0.25], dtype=np.float64)
    # convolve p with kernel, keep length 101 (pad edges)
    pp = np.concatenate(([p[0]], p, [p[-1]]))
    sm = np.convolve(pp, k, mode="same")[1:-1]
    # combine sharp probability with mild smoothing
    _pdf = 0.7 * p + 0.3 * sm
    # zero out residual 0 (exact fill handled separately)
    _pdf[0] = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist *= _DECAY
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)
    ri = residual.astype(np.int64)

    _rebuild()

    # Score: residuals that are likely upcoming item sizes are good to leave.
    score = _pdf[ri]

    # Strongly prefer exact fills.
    score = score + np.where(residual == 0, 1000.0, 0.0)

    # Tiny best-fit tie-breaker: prefer smaller residual (less waste).
    score = score - 1e-4 * res

    return score
# EVOLVE-BLOCK-END
