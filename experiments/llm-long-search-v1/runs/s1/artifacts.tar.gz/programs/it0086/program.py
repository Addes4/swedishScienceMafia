# EVOLVE-BLOCK-START
"""Best fit with a small reusable-residual bonus.

Prefer the tightest fit and strongly prefer exact fills. Additionally give a
mild bonus to residuals large enough to still accept the smallest item seen so
far, since those leftovers are genuinely reusable rather than wasted.
"""
import numpy as np

_min_item = 101.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _min_item
    if item < _min_item:
        _min_item = float(item)

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: prefer tight fits.
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)
    # Mild bonus for residuals that can still accept the smallest item seen.
    usable = res >= _min_item
    score += np.where(usable, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
