# EVOLVE-BLOCK-START
"""Best fit with a history-learned perfect-residual bonus."""
import numpy as np

# Online histogram of item sizes (1..100). Shared across calls for one instance.
_hist = None


def priority(item, bins):
    global _hist
    if _hist is None:
        _hist = np.zeros(101, dtype=np.float64)

    # residual after placing item in each bin
    resid = bins - item

    # frequency weight of each possible residual (how likely a future item equals it)
    # normalize histogram into a probability
    total = _hist.sum()
    if total > 0:
        freq = _hist / total
    else:
        freq = _hist

    base = -resid.astype(np.float64)
    # bonus for residuals that are common item sizes (likely filled exactly later)
    bonus = freq[resid.astype(np.int64)]

    score = base + 50.0 * bonus

    # record this item after scoring
    _hist[item] += 1.0

    return score
# EVOLVE-BLOCK-END
