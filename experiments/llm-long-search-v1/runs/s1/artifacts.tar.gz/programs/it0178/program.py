# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
is likely to be exactly filled by some future item, estimated from the running
histogram of item sizes, falling back toward a mild preference near the mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
        p = _hist / _count  # empirical distribution over item sizes 0..100
    else:
        mean_item = 40.0
        p = np.zeros(101, dtype=np.float64)

    # Probability that the residual r equals a future item size exactly.
    # This directly estimates the chance of a future perfect fill.
    match_prob = p[residual.astype(np.int64)]  # shape (bins,)

    score = match_prob.copy()

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.005 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
