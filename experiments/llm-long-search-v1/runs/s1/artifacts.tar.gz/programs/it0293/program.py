# EVOLVE-BLOCK-START
"""Best fit with a frequency-weighted "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
is a *common* recently-seen item size (weighted by its running frequency), so
the next few arrivals can fill it exactly. Fallback is a mild best-fit
preference (smallest residual) plus a weak pull toward the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)

def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Frequency-weighted reuse value of each possible residual 0..100.
    total = _seen.sum()
    if total > 0.0:
        reuse = _seen / total  # prob-like weight per residual value
    else:
        reuse = np.zeros(101, dtype=np.float64)

    # Reward residuals that are common recent item sizes (bounded so it never
    # dominates the exact-fill term).
    reuse_bonus = 6.0 * reuse[residual.astype(np.int64)]

    # Mild best-fit preference (smaller residual is slightly better).
    best_fit = -0.02 * res

    # Weak fallback pull toward the running mean.
    mean_pull = -0.02 * np.abs(res - mean_item)

    score = reuse_bonus + best_fit + mean_pull

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
