# EVOLVE-BLOCK-START
"""Best fit with mode-targeted residual shaping.

Exact fills are strongly preferred. Among non-exact fits, prefer residuals that
match the most common future item size (histogram mode above a threshold),
which is more reusable than merely large residuals.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item
    res = residual.astype(np.float64)

    # Dominant rule: prefer tightest fit (best-fit).
    score = -res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Mode-targeted reuse bonus: reward residuals near the most common item
    # size that is still small enough to be likely reused.
    if _count >= 20:
        # restrict to sizes in a reasonable range for reuse
        counts = _hist[1:101]
        idx = np.arange(1, 101)
        mask = (idx >= 15) & (idx <= 60)
        if mask.any():
            sub = np.where(mask, counts, 0.0)
            mode_size = float(idx[np.argmax(sub)])
        else:
            mode_size = 40.0
    else:
        mode_size = 40.0

    # Concave, bounded bonus peaked at the mode size.
    diff = np.abs(res - mode_size)
    reuse = np.maximum(0.0, 1.0 - diff / max(mode_size, 1.0))
    score += 0.5 * reuse

    return score
# EVOLVE-BLOCK-END
