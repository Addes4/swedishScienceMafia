# EVOLVE-BLOCK-START
"""Two-step reuse: prefer exact fills, then residuals likely to be filled soon.

For each candidate residual r we estimate, from a smoothed recency-weighted item
histogram, the probability that the next arrival exactly fills the bin (mass at r),
plus a term rewarding residuals whose complement (100-r) is itself a recently seen
item size (so two partials can combine). Exact fills stay dominant; a tiny best-fit
term breaks ties toward tighter bins.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted histogram of item sizes.
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.995
    _seen[item] += 1.0

    residual = np.asarray(bins, dtype=np.int64) - item
    res = residual.astype(np.float64)

    total = _seen.sum()
    if total <= 0.0:
        p = np.full(101, 1.0 / 101.0)
    else:
        p = _seen / total

    # Smooth the size probability over neighbors to reduce noise.
    kernel = np.array([0.25, 0.5, 0.25])
    ps = np.convolve(p, kernel, mode="same")

    r = np.clip(residual, 0, 100)

    # Immediate reuse: chance the next item exactly fills this bin.
    immediate = ps[r]

    # Pairwise reuse: chance some item equals the complement leftover (100 - r),
    # letting a future arrival combine with this bin's leftover.
    comp = np.clip(100 - residual, 0, 100)
    pairing = ps[comp]

    score = 1.0 * immediate + 0.35 * pairing

    # Tiny best-fit tie-break: prefer smaller residuals among otherwise-equal bins.
    score += -0.001 * res

    # Strong preference for exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

