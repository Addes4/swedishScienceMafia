# EVOLVE-BLOCK-START
"""Best fit with mode-residual bonus.

Primary: smallest residual (best fit). Exact fills get a large bonus.
Secondary: reward residuals that exactly match a likely future item size
(the empirical mode), since such leftovers can be reused efficiently.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    # Update histogram of seen item sizes.
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: prefer tight fits.
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Distribution-aware bonus: find the most common item size seen so far.
    if _count > 0:
        mode_item = int(np.argmax(_hist))
    else:
        mode_item = 40

    # Reward residuals that exactly equal the mode (reusable by a single item).
    if mode_item > 0:
        score += np.where(residual == mode_item, 50.0, 0.0)

    return score
# EVOLVE-BLOCK-END
