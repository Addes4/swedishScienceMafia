# EVOLVE-BLOCK-START
"""Best-fit with exact-fill priority and a median-residual tie-break."""
import numpy as np

_state = {"sizes": []}
_MAX_HIST = 4000


def priority(item, bins):
    """Score every candidate bin; highest score wins (ties -> first bin).

    item: integer item size 1..100.
    bins: remaining capacities of bins the item fits in, in bin order.
    """
    # Track recent item sizes to estimate a typical future item size.
    hist = _state["sizes"]
    hist.append(int(item))
    if len(hist) > _MAX_HIST:
        del hist[:len(hist) - _MAX_HIST]
    if len(hist) >= 50:
        typical = float(np.median(hist))
    else:
        typical = 40.0

    residual = bins - item  # >= 0 since bins only contains fitting bins

    # Primary: prefer exact fills (residual 0). Secondary: small residual penalty
    # blended with a mild preference for residuals near a typical item size,
    # which keeps bins attractive for future packing rather than leaving slivers.
    score = -residual.astype(np.float64)
    # Small bonus for residual close to a typical item size (helps later fills).
    score -= 0.02 * np.abs(residual - typical)
    return score
# EVOLVE-BLOCK-END
