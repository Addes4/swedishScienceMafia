# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (so the next few arrivals can fill it exactly),
falling back toward a mild preference for residuals near the running mean.
A small recency-mass bonus breaks ties toward residuals that are frequently seen.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Cached array of item sizes seen recently (weighted by recency via decay)
_seen = np.zeros(101, dtype=np.float64)
# Smoothed reuse mass per residual value (updated periodically)
_reuse = np.zeros(101, dtype=np.float64)
_last_update = 0


def _rebuild_reuse():
    global _reuse
    idx = np.nonzero(_seen > 0.0)[0]
    if idx.size == 0:
        _reuse = np.zeros(101, dtype=np.float64)
        return
    vals = np.arange(101, dtype=np.float64)
    m = _seen[idx]
    # kernel smoothing: each seen size contributes to residual values within 2
    d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
    weights = np.maximum(0.0, 1.0 - d / 3.0) * m[None, :]
    _reuse = weights.sum(axis=1)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen, _reuse, _last_update
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0
    if int(_count) - _last_update >= 25:
        _rebuild_reuse()
        _last_update = int(_count)

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Distance to the closest recently-seen item size.
    seen_present = _seen > 0.0
    idx = np.nonzero(seen_present)[0]
    if idx.size > 0:
        vals = np.arange(101, dtype=np.float64)
        d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
        nearest = d.min(axis=1)  # shape (101,)
    else:
        nearest = np.abs(np.arange(101, dtype=np.float64) - mean_item)

    # Score: closer to a reusable residual is better; exact fills dominant.
    score = -nearest[residual.astype(np.int64)]

    # Tie-break: residuals with high recent reuse mass are better.
    score += 0.01 * _reuse[residual.astype(np.int64)]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
