# EVOLVE-BLOCK-START
"""Best fit with online-learned residual reuse bonus.

Core rule is best-fit (prefer tight fits) with a strong exact-fill bonus.
On top, we maintain an online estimate of how often a given residual value
gets exactly consumed by a later item, and give a small bonus to residuals
that historically tend to be reusable.  This adapts to the real item stream
instead of assuming a fixed geometric shape.
"""
import numpy as np

# Empirical item-size histogram (sizes 0..100).
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0

# For each residual value r (0..100), count how many open "bins" with that
# residual have been exactly filled later.  We approximate reuse potential by
# tracking arrivals: when an item of size s arrives, residual s would be filled
# exactly by this item, so bump _reuse[s].
_reuse = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _hist, _count, _reuse

    # Learn: this arrival would exactly fill any bin whose residual equals item.
    _reuse[item] += 1.0
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Dominant best-fit core.
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Online residual-reuse bonus: residuals that arriving items tend to match
    # exactly are more valuable to keep available.
    if _count > 0:
        reuse_prob = _reuse / _count  # empirical P(next item size == r)
        # Normalize so the bonus stays a gentle tie-breaker.
        max_p = reuse_prob.max()
        if max_p > 0:
            bonus = reuse_prob[residual] / max_p
            score += bonus

    return score
# EVOLVE-BLOCK-END
