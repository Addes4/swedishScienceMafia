# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus and a distribution-aware residual bonus.

Primary rule: exact fills are strongly preferred. Otherwise, use best fit
(smallest residual) which is a strong greedy baseline for bin packing. A mild
bonus is added for residuals equal to common item sizes, so leftovers are more
likely to be exactly filled later.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Best fit: smaller residual is better (dominant signal among non-exact bins).
    score = -res

    # Exact fills strongly preferred.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Mild distribution-aware bonus: residuals that are common item sizes may
    # be exactly filled by a future item, letting us close bins nicely.
    if _count > 0:
        freq = _hist / _count
        # count of items seen at each residual size (only where residual is a valid size)
        bonus = freq[residual.astype(np.int64)]
    else:
        bonus = np.zeros_like(res)

    score += 5.0 * bonus

    return score
# EVOLVE-BLOCK-END
