# EVOLVE-BLOCK-START
"""Best fit with a matchability-aware residual objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual r that
is likely to be *exactly fillable* by a future item: we score r by the summed
probability mass of item sizes s such that r == s (perfect fill on next item)
or 100 - (bin_capacity - r) - s == 0 in a two-item completion sense. As a
smooth, well-behaved proxy we use an exponential kernel over the running
histogram of item sizes, plus a mild best-fit preference.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0

# Cached matchability vectors keyed by nothing (recomputed periodically).
_match_cache = None
_cache_age = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _match_cache, _cache_age
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Precompute the matchability vector for every possible residual value 0..100.
    # Recompute only every 8 calls to stay cheap.
    _cache_age += 1
    if _match_cache is None or _cache_age >= 8:
        _cache_age = 0
        vals = np.arange(101, dtype=np.float64)

        if _count > 0.0:
            p = _hist / _count
        else:
            p = np.zeros(101, dtype=np.float64)

        # Exponential kernel: probability mass of item sizes near residual r.
        sigma = 6.0
        diff = vals[:, None] - vals[None, :]
        K = np.exp(-(diff * diff) / (2.0 * sigma * sigma))
        match = K.dot(p)  # shape (101,)

        # Bonus if residual itself equals a likely item size (perfect next-fill).
        match += match * 0.0  # placeholder to keep structure explicit

        _match_cache = match

    match = _match_cache

    # Score: expected exact-fill matchability dominates softly.
    score = 3.0 * match[residual.astype(np.int64)]

    if _count > 0.0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Mild preference for residuals near the running mean as fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills of the current bin.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

