# EVOLVE-BLOCK-START
"""Best-fit with a mild mean-residual tiebreak.

Exact fills dominate. Otherwise prefer the smallest residual that stays >= 1
(classic best-fit, which packs the Weibull-shaped sizes near optimally), with a
small secondary pull toward residuals close to the running mean item size so
that near-ties favor reusability.
"""
import numpy as np

_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum
    _count += 1.0
    _sum += item
    mean_item = _sum / _count if _count > 0 else 40.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Best-fit: prefer the smallest residual (tighter packing).
    score = -res
    # Mild preference for residuals near the running mean item size as a tiebreak.
    score += -0.02 * np.abs(res - mean_item)
    # Dominant exact-fill reward.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

