# EVOLVE-BLOCK-START
"""Best fit with one-step expected-reuse lookahead.

For each bin we simulate placing the most probable future item that fits the
resulting residual.  A residual that can be filled tightly by a likely item is
good; a residual too small for any likely item is bad.  Exact fits dominate.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sizes = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0
    res = residual.astype(np.float64)

    # Empirical distribution over item sizes 1..100.
    total = _count
    prob = _hist / total if total > 0.0 else None

    # For each possible residual r (0..100), find the most likely future item s<=r
    # and compute expected leftover after placing it.  For r==0 leftover is 0.
    best_next = np.zeros(101, dtype=np.float64)   # best future item size for each r
    best_score = np.full(101, -1.0, dtype=np.float64)
    if prob is not None:
        for r in range(1, 101):
            # items s in 1..r
            s_range = np.arange(1, r + 1)
            p = prob[1:r + 1]
            # expected leftover if we place item s: r - s; weight by p.
            exp_left = np.dot(p, (r - s_range))
            psum = p.sum()
            # score = how much of r gets filled (r - exp_left) / r, times prob mass
            if psum > 0:
                fill = (r - exp_left)  # = sum p*s  (expected filled amount)
                best_score[r] = fill  # expected filled amount
    # For small r with no observed items, fallback handled below.

    # Reward residuals that can be tightly filled by a likely future item.
    # Higher "expected filled" and lower leftover variance => better.
    # Build a value per bin residual.
    if prob is not None:
        exp_fill = np.zeros(101, dtype=np.float64)
        psum_r = np.zeros(101, dtype=np.float64)
        for r in range(1, 101):
            p = prob[1:r + 1]
            exp_fill[r] = np.dot(p, np.arange(1, r + 1))
            psum_r[r] = p.sum()
        # value of a residual: expected filled amount, but scaled by coverage prob
        value = np.where(psum_r > 0, exp_fill, 0.0)
    else:
        value = np.minimum(_sizes, 40.0)

    ridx = residual.astype(np.int64)
    v = value[ridx]

    # Base: strict best fit (prefer small residual).
    score = -res
    # Reward productive residuals.
    score += 0.05 * v
    # Strongly prefer exact fits.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
