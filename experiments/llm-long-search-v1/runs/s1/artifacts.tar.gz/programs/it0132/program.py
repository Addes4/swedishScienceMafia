# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective (frequency-weighted).

Exact fills are strongly preferred. Otherwise, prefer leaving a residual whose
nearest recently-seen item size is common (so the residual is likely to be
exactly filled soon), falling back toward a mild preference for smaller residuals.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted presence of item sizes.
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    idx = np.nonzero(_seen > 0.0)[0]
    if idx.size > 0:
        vals = np.arange(101, dtype=np.float64)
        # Distance to each seen size; for each residual, pick nearest seen size
        # and pull its frequency to weight the closeness.
        seervals = idx.astype(np.float64)
        freq = _seen[idx]
        freq_norm = freq / freq.max()
        d = np.abs(vals[:, None] - seervals[None, :])          # (101, n_seen)
        # Prefer small distance AND high frequency of the matched size.
        weighted = d - 2.0 * freq_norm[None, :]
        best = weighted.min(axis=1)  # shape (101,)
    else:
        best = np.abs(np.arange(101, dtype=np.float64) - mean_item)

    score = -best[residual.astype(np.int64)]

    # Mild fallback: prefer smaller residuals (tighter packing).
    score += -0.05 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
