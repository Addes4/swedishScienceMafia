# EVOLVE-BLOCK-START
"""Best fit with a light harmonic-class bias on the residual gap."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    gap = bins - item  # remaining capacity after placing item
    # Best fit: strongly prefer small gap.
    base = -gap.astype(np.float64)
    # Harmonic-class bonus: reward residuals that are close to a useful leftover size.
    # Useful leftovers are near multiples/parts of the mean item (~40).
    useful = np.array([0.0, 1.0, 20.0, 40.0, 60.0, 100.0])
    d = np.abs(gap[:, None] - useful[None, :]).min(axis=1)
    bonus = 0.5 * np.exp(-d / 8.0)
    return base + bonus
# EVOLVE-BLOCK-END
