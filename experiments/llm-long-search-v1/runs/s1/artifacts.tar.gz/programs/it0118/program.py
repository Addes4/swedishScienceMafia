# EVOLVE-BLOCK-START
"""Strict best fit with exact-fit dominance.

Pure best fit (tightest residual) is the proven strong rule; exact fills get a
large constant bonus so a perfect fit always wins. No histogram/state noise.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown

    # Base: prefer tight fits (smaller residual is better).
    score = -residual.astype(np.float64)
    # Exact fills are strongly preferred.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
