# EVOLVE-BLOCK-START
"""Best fit with probability-weighted leftover reuse.

Core rule: strong exact-fit bonus, then minimize residual (best fit).
Small extra term: reward the resulting residual when it is itself a likely
future item size, estimated from a normalized running histogram of item sizes.
This favors leftovers that a single future item can fill exactly.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Dominant: prefer tight fits.
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Probability that a future single item exactly equals this residual.
    if _count > 0:
        prob = _hist / _count
    else:
        prob = np.zeros(101, dtype=np.float64)
    # prob indexed by residual value (0..100); residual could be up to 100.
    idx = residual.astype(np.int64)
    np.clip(idx, 0, 100, out=idx)
    match_bonus = prob[idx] * 20.0

    score += match_bonus

    return score
# EVOLVE-BLOCK-END

