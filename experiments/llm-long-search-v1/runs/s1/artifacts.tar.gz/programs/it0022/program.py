# EVOLVE-BLOCK-START
"""Best fit with adaptive tie-break toward refillable residuals."""
import numpy as np

# Running histogram of item sizes (1..100) to know common future item sizes.
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _count
    _count += 1.0
    _hist[item] += 1.0

    # Residual each bin would have after placing the item.
    resid = bins - item  # already only bins that fit are passed

    # Base: best fit -- tightest residual is best => score = -resid.
    base = -resid.astype(np.float64)

    # Probability that a future item exactly fills the residual (residual is a common size).
    total = _hist.sum()
    freq = np.zeros(101, dtype=np.float64)
    if total > 0:
        freq = _hist / total
    # weight of each residual as a refill opportunity
    idx = resid.astype(np.int64)
    idx = np.clip(idx, 0, 100)
    refill = freq[idx]

    # Scale the tie-break by a small amount so it never overrides a clearly better fit.
    # Use the histogram mean to set a natural scale.
    return base + 0.01 * refill
# EVOLVE-BLOCK-END
