# EVOLVE-BLOCK-START
"""Best fit with an epsilon tie-breaker that rewards reusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all shown bins
    # Primary: tightest fit (smallest residual). Exact fits (residual 0) are best.
    # Tie-breaker: among near-equal residuals, prefer those that leave a
    # usable residual (>= a small threshold) over tiny slivers, since on a
    # heavy-tailed distribution a 1..4 sliver is nearly useless.
    tiny = (residual > 0) & (residual < 5)
    score = -residual.astype(np.float64) - tiny.astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END
