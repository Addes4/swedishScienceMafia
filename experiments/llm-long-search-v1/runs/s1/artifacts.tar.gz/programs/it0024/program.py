# EVOLVE-BLOCK-START
"""Best-fit with sliver penalty and exact-fill priority.

Observation: with heavy-tailed (Weibull, mean ~40) items, plain best fit often
creates tiny unusable residuals (slivers of size < a few units) that can never
be filled again, whereas a slightly looser fit leaves a usable gap. This rule
keeps tightest-fit as the main driver but heavily penalizes residuals too small
to accept any future item and rewards exact completion.
"""
import numpy as np


def priority(item, bins):
    """Rank bins: exact fill best, then usable tight fit, slivers penalized."""
    residual = bins - item  # remaining capacity after this item

    # Base: tighter fit is better (negative residual).
    score = -(residual.astype(np.float64))

    # Strongly reward exact completion of a bin.
    exact = (residual == 0)
    score[exact] += 1000.0

    # Penalize slivers: residuals in 1..(some small threshold) that cannot be
    # used by any item we are likely to see (roughly below the typical minimum
    # usable size). Such bins are effectively wasted.
    sliver = (residual > 0) & (residual < 8)
    score[sliver] -= 50.0

    # Soft reward for residuals that are plausible item sizes (common medium
    # gaps ~20..60) so future items can exactly complete the bin.
    usable = (residual >= 20) & (residual <= 60)
    score[usable] += 0.5

    return score
# EVOLVE-BLOCK-END
