# EVOLVE-BLOCK-START
"""Best fit with exact-fit bonus.

Prefer the tightest fit (smallest resulting residual) and strongly prefer bins
that are filled exactly. Distribution-based lookahead has not helped, so this
keeps the scoring simple and robust.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    score = -residual.astype(np.float64)
    score += np.where(residual == 0, 1000.0, 0.0)
    return score
# EVOLVE-BLOCK-END
