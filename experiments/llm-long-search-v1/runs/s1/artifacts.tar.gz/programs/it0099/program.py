# EVOLVE-BLOCK-START
"""Best fit with exact-fit bonus and small-residual waste penalty."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item
    res = residual.astype(np.float64)

    # Base: prefer tight fits (best fit).
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Penalize nonzero residuals smaller than the current item: these
    # leftovers are too small to be reused by many future items (wasted).
    score -= np.where((residual > 0) & (residual < item), res * 1.5, 0.0)

    return score
# EVOLVE-BLOCK-END
