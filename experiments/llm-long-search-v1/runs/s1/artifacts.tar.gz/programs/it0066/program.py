# EVOLVE-BLOCK-START
"""Best fit with an exact-fit preference and a reusability guard.

Core idea: prefer the tightest fit (smallest residual). Among non-exact fits,
slightly prefer residuals that are at least as large as the current item (so
the leftover can still host a full future item), and strongly prefer exact fits.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    residual = bins - item  # >= 0 for all bins shown

    # Dominant term: best fit (smallest residual wins).
    score = -residual.astype(np.float64)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Reusability guard: among non-exact fits, mildly prefer a leftover that can
    # still hold a full item of the current size (residual >= item).
    good = (residual > 0) & (residual >= item)
    score += np.where(good, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
