# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (so the next few arrivals can fill it exactly),
with a graded distance penalty, plus a mild best-fit tie-break.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted presence of item sizes.
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Build a graded reuse signal over residuals 0..100.
    seen = _seen.copy()
    total = seen.sum()
    if total > 0.0:
        seen = seen / total
    idx = np.nonzero(seen > 0.0)[0]

    if idx.size > 0:
        vals = np.arange(101, dtype=np.float64)
        d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
        w = seen[idx]
        # graded reward: recency-weighted mass decaying with distance
        # (a residual that exactly matches a seen size gets its mass; farther decays).
        decay = 1.0 / (1.0 + d)
        reuse = (decay * w[None, :]).sum(axis=1)  # shape (101,)
    else:
        reuse = 1.0 / (1.0 + np.abs(np.arange(101, dtype=np.float64) - mean_item))

    # Score: larger reuse is better.
    score = reuse[residual.astype(np.int64)] * 10.0

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Gentle best-fit tie-break: smaller residual slightly preferred.
    score += -0.01 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
