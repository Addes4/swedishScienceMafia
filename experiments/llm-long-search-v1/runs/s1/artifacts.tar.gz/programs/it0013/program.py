# EVOLVE-BLOCK-START
"""Best fit with a small residual-anchor bonus based on typical item sizes."""
import numpy as np

_ANCHORS = np.array([20.0, 40.0, 60.0, 80.0])


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item
    base = -residual.astype(np.float64)
    # Bonus when the resulting residual is close to a typical item size (in [-6, 0] sense),
    # so the leftover space is likely to be consumed by a later item rather than wasted.
    dist = np.min(np.abs(residual[:, None] - _ANCHORS[None, :]), axis=1)
    bonus = np.where(dist <= 3.0, 4.0 - dist, 0.0)
    return base + bonus
# EVOLVE-BLOCK-END
