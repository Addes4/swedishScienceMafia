# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a commonly-seen item size (so the next few arrivals can fill it exactly),
falling back toward a mild preference for residuals near the running mean.
The reusable-residual signal uses a stationary running histogram rather than a
noisy recency-decay array, and a small best-fit tie-break sharpens packing.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)
    res_int = residual.astype(np.int64)

    mean_item = _sum / _count if _count > 0 else 40.0

    # Reusable-residual distance: for each possible residual 0..100, min distance
    # to a size that actually appears in the running histogram.
    idx = np.nonzero(_hist > 0.0)[0]
    if idx.size > 0:
        vals = np.arange(101, dtype=np.float64)
        d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
        nearest = d.min(axis=1)  # shape (101,)
    else:
        nearest = np.abs(np.arange(101, dtype=np.float64) - mean_item)

    # Score: closer to a reusable residual is better; exact fills dominant.
    score = -nearest[res_int]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Small best-fit tie-break: prefer smaller non-negative residual.
    score += -0.001 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

