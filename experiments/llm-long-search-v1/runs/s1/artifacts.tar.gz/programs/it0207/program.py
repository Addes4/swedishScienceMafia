# EVOLVE-BLOCK-START
"""Best-Fit primary rule with a light recency-weighted reuse nudge.

Classic Best-Fit (smallest usable residual) is the strongest practical online
rule for random arrivals. We keep exact fills dominant, order primarily by
smallest residual, and add only a tiny recency-weighted reuse bonus (based on
the observed item-size histogram) that can only break near-ties toward bins
whose residual matches a recently-seen item size.
"""
import numpy as np

_step = 0.0
_hist = np.zeros(101, dtype=np.float64)   # recency-weighted item histogram
_seen = np.zeros(101, dtype=np.float64)   # recency-weighted seen sizes


def priority(item, bins):
    global _step, _hist, _seen
    _step += 1.0
    _hist *= 0.999
    _hist[item] += 1.0

    residual = (bins - item).astype(np.int64)
    res = residual.astype(np.float64)

    # Reuse value of each residual r: recency-weighted mass of seen sizes that
    # would exactly fill r, with small partial credit for near matches.
    seen_norm = _seen / (_seen.sum() + 1.0)
    reuse_r = 0.0
    # score residuals 0..100 by histogram mass
    reuse_scores = np.zeros(101, dtype=np.float64)
    idx = np.nonzero(_seen > 0.0)[0]
    if idx.size > 0:
        w = seen_norm[idx]
        for r in idx:
            reuse_scores[r] += seen_norm[r]
        # near-match partial credit
        vals = np.arange(101, dtype=np.float64)
        # weight by inverse distance to nearest seen size (within 3)
        for k, s in enumerate(idx):
            d = np.abs(vals - float(s))
            reuse_scores += w[k] * np.where(d <= 3.0, 1.0 / (1.0 + d), 0.0)
    reuse = reuse_scores[residual]

    # Primary: Best-Fit (smallest residual). Secondary: reuse nudge.
    score = -res + 0.02 * reuse
    # Exact fills dominant.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Record this item into the seen-size histogram (recency decayed).
    _seen *= 0.999
    _seen[item] += 1.0

    return score
# EVOLVE-BLOCK-END
