# EVOLVE-BLOCK-START
"""Best fit with adaptive residual-reuse shaping.

Core: best fit (prefer smallest residual), with a strong exact-fit bonus.
Refinement: bonus for residuals that are likely to be reused, estimated from
the empirical item-size distribution seen so far (probability a future item
equals the residual, plus probability a future item leaves it near-exact).
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item
    res = residual.astype(np.float64)

    # Dominant best-fit: prefer tight fits.
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Adaptive reuse bonus: probability mass of future items that could
    # consume this residual (exactly, or leaving a small usable remainder).
    if _count > 4.0:
        p = _hist / _count
        # Full reuse: probability a future item exactly equals the residual.
        exact_reuse = p[np.clip(residual, 0, 100)]
        # Partial reuse: probability some future item is < residual and leaves
        # a remainder that is itself a common size is hard; approximate by the
        # chance the residual is large enough for a typical item.
        score += 0.5 * exact_reuse
    else:
        # Cold start: mild concave bonus capped at 40.
        score += 0.1 * np.minimum(res, 40.0)

    return score
# EVOLVE-BLOCK-END
