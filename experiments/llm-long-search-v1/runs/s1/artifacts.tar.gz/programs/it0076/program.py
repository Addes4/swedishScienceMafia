# EVOLVE-BLOCK-START
"""Best fit augmented with an empirical expected-waste adjustment.

Core rule: best fit (smallest residual) is dominant.  On top of that we add a
small bonus proportional to the empirical probability that the resulting
residual can still be *exactly* filled by a future item, estimated online from
the running histogram of item sizes.  Exact fills get a large fixed bonus.
"""
import numpy as np

_hist = np.ones(101, dtype=np.float64)  # Laplace smoothing
_hist[0] = 1.0
_count = 101.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in (including unused bins at capacity 100), in bin order.
    """
    global _hist, _count

    # --- Update running histogram of item sizes. ---
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # --- Dominant best-fit term. ---
    score = -res

    # --- Strong exact-fill bonus. ---
    score += np.where(residual == 0, 1000.0, 0.0)

    # --- Empirical probability that a future item exactly fills this residual. ---
    # p_exact(r) ~ P(item == r)  for r >= 1; 0 for r == 0.
    probs = _hist / _count
    r_idx = np.clip(residual, 0, 100).astype(np.int64)
    p_exact = probs[r_idx]
    # Zero out residuals of 0 (already handled); keep this as reuse bonus for r>=1.
    score += np.where(residual > 0, p_exact * 500.0, 0.0)

    return score
# EVOLVE-BLOCK-END
