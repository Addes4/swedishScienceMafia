# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus and a mean-residual (fit-potential) objective.

Exact fills are strongly preferred. Otherwise, prefer residuals that are close to the
running mean item size (so leftover space is most likely to be fillable soon), with a
mild best-fit nudge toward smaller residuals to limit fragmentation.
"""
import numpy as np

_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    mean_item = _sum / _count if _count > 0 else 40.0

    # Prefer residuals close to the running mean item size (best reuse potential).
    score = -np.abs(res - mean_item)

    # Mild best-fit nudge: among equally-good reuse potential, smaller residual packs tighter.
    score += -0.02 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
