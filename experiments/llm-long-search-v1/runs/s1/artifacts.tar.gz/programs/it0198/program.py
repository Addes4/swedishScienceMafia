# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (so the next few arrivals can fill it exactly),
with a tie-break toward the most recent item size and then toward smaller residuals.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted presence of item sizes.
_seen = np.zeros(101, dtype=np.float64)
_last = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen, _last
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0
    _last = item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Distance to the closest recently-seen item size (0 if residual is an observed size).
    seen_present = _seen > 0.0
    idx = np.nonzero(seen_present)[0]
    vals = np.arange(101, dtype=np.float64)
    if idx.size > 0:
        d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
        nearest = d.min(axis=1)  # shape (101,)
    else:
        nearest = np.abs(vals - mean_item)

    # Score: closer to a reusable residual is better; exact fills dominant.
    residual_int = residual.astype(np.int64)
    score = -nearest[residual_int]

    # Tie-break: prefer residual equal to the most recent item size.
    score += np.where(residual_int == _last, 0.1, 0.0)

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.01 * np.abs(res - mean_item)

    # Break remaining ties toward best fit (smaller residual).
    score += -0.001 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

