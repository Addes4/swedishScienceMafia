# EVOLVE-BLOCK-START
"""Best fit with a complementary-pair preference.

Dominant rule is best fit (smallest residual), with a strong exact-fill bonus.
On top of that, prefer bins whose *current* remaining capacity is close to the
item size, which tends to create complementary pairs and leaves either exact
fills or very reusable residuals.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: best fit.
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Complementary pairing: prefer placing into a bin whose pre-placement
    # remaining capacity is close to the item's own size. Such a placement
    # consumes a bin partner and tends to yield small/exact residuals.
    cap_before = bins.astype(np.float64)
    pairing = -np.abs(cap_before - 2.0 * item) * 0.05
    score += pairing

    # Mild penalty for tiny nonzero residuals that are hard to reuse.
    small = (residual > 0) & (residual < item * 0.5)
    score -= np.where(small, res * 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END

