# EVOLVE-BLOCK-START
"""Score bins by best-fit gap, modulated by the probability that the residual
will be exactly filled soon (estimated from a recency-weighted item histogram).
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted histogram of item sizes (probabilities).
_prob = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _prob
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    # Update recency-weighted histogram.
    _prob *= 0.999
    _prob[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.int64)

    # Probability mass that a given residual r would be exactly matched by an item.
    # We compute the expected value over the decayed histogram, but favor the
    # exact probability p(r).  Use a smoothed combination with a best-fit fallback.
    total = _prob.sum()
    if total <= 0.0:
        p = np.zeros(101, dtype=np.float64)
    else:
        p = _prob / total

    # Exact-match probability for each residual.
    match = p[res]

    # Best-fit fallback: tighter fits are better.  Use reciprocal-ish scoring.
    tight = 1.0 / (1.0 + res.astype(np.float64))

    # Combine: exact match dominates; best-fit serves as tie-breaker.
    score = 20.0 * match + tight

    # Absolute preference for exact fills.
    score += np.where(res == 0, 1e6, 0.0)

    return score
# EVOLVE-BLOCK-END
