# EVOLVE-BLOCK-START
"""Best fit with a probability-weighted "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual r that
is likely to be exactly filled by a single future item, i.e. weight by the
running estimate of P(item == r). A tiny best-fit tie-break sharpens packing.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = (bins - item).astype(np.int64)  # >= 0 for all bins shown

    # Running probability that the next item exactly equals each possible residual.
    prob = _hist / _count if _count > 0 else np.zeros(101, dtype=np.float64)

    # Matchability: higher if residual is a likely future item size.
    score = prob[residual].astype(np.float64)

    # Tiny best-fit tie-break: among similar matchability, prefer tighter fits.
    score += -1e-6 * residual.astype(np.float64)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
