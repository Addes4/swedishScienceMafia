# EVOLVE-BLOCK-START
"""Distributional best-fit: score each bin by how likely the residual it leaves
can be exactly filled by upcoming items.

We estimate, from a recency-weighted histogram of past item sizes, a "fill value"
for each possible residual value r in 0..100: the probability that some single
upcoming item equals r, plus the probability that some pair of upcoming items
sums to r (approximated by the distribution's self-convolution mass at r).
Exact fills (r == 0) are strongly preferred. As a tie-breaker we still prefer
small residuals (least space wasted) via a tiny monotone term.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)   # recency-weighted size histogram
_sum = 0.0
_count = 0.0
# Precomputed fill-value table for residuals 0..100, refreshed periodically.
_fill = np.zeros(101, dtype=np.float64)
_refresh = 0


def _rebuild_fill():
    """Compute fill value per residual from current weighted histogram."""
    global _fill
    h = _hist
    tot = h.sum()
    if tot <= 0.0:
        _fill = np.zeros(101, dtype=np.float64)
        return
    p = h / tot
    # Probability a single upcoming item equals each residual size.
    single = p.copy()
    # Probability a pair sum equals each residual: self-convolution of p.
    # conv[k] = sum_{i+j=k} p[i] p[j]
    conv = np.convolve(p, p)
    pair = np.zeros(101, dtype=np.float64)
    m = min(101, conv.shape[0])
    pair[:m] = conv[:m]
    _fill = single + pair


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    global _hist, _sum, _count, _refresh
    _hist[item] += 1.0
    _sum += item
    _count += 1.0

    # Refresh the fill table occasionally (cheap, amortized).
    if _refresh <= 0:
        _rebuild_fill()
        _refresh = 25
    _refresh -= 1

    residual = (bins - item).astype(np.int64)
    res = residual.astype(np.float64)

    # Main objective: likelihood the residual can be exactly completed later.
    score = _fill[residual]

    # Strong dominance for exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Tiny monotone best-fit tie-breaker: prefer smaller residuals.
    score += -1e-6 * res

    return score
# EVOLVE-BLOCK-END

