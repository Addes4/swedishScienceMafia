# EVOLVE-BLOCK-START
"""Best fit with a stationary "reusable residual" objective.

Exact fills dominate. Otherwise, prefer leaving a residual whose value is a
likely future item size (from the running histogram), so the bin can be closed
soon, with a gentle best-fit tie-break toward smaller residuals.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.int64)

    # Stationary probability that a future item exactly equals a residual value.
    prob = _hist / _count

    # Matchability of each residual (probability mass at that exact size).
    score = 1.0 * prob[res]

    # Soft matchability: residual close to a common item size is also good.
    # Use a rough local density around the residual.
    lo = np.maximum(res - 1, 0)
    hi = np.minimum(res + 1, 100)
    score += 0.30 * (prob[lo] + prob[hi])

    # Prefer residuals that are exactly fillable.
    score += np.where(res == 0, 1000.0, 0.0)

    # Gentle best-fit tie-break: prefer smaller residual.
    score += -0.001 * res.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
