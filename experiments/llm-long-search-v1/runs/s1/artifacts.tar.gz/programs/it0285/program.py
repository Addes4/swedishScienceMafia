# EVOLVE-BLOCK-START
"""Best fit with a frequency-weighted "fillable residual" bonus.

Exact fills are strongly preferred. Otherwise we use best-fit (smallest residual)
as the main rule, but add a bonus when the leftover residual matches a common
item size, so bins become easy to top off later.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)   # long-run smoothed counts
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Smoothed frequency of item sizes (probability an item equals a given size),
    # blended with its neighbors to be robust to noise.
    h = _hist
    total = h.sum()
    if total > 0:
        p = h / total
    else:
        p = np.full(101, 1.0 / 101.0)
    # 3-wide smoothing
    ps = p.copy()
    ps[1:-1] = (p[:-2] + p[1:-1] + p[2:]) / 3.0

    # Best-fit pull: prefer the smallest usable residual.
    score = -res

    # Bonus: residual equals a common item size -> easy to fill exactly later.
    idx = residual.astype(np.int64)
    fill_bonus = ps[idx]

    # Strong exact fill preference.
    exact = np.where(residual == 0, 1.0, 0.0)

    # Combine: exact fills dominate; fillability mildly tilts ties among best-fit options.
    return score + 50.0 * fill_bonus + 500.0 * exact
# EVOLVE-BLOCK-END

