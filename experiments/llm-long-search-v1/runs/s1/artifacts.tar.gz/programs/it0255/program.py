# EVOLVE-BLOCK-START
"""Exact-fill first, then prefer leaving a residual most likely to be filled next.

Keeps a recency-weighted histogram of past item sizes. The dominant term is an
exact-fill bonus. Among non-exact bins, we reward leaving a residual equal to a
high-probability future item size, weighting larger (more fillable) residuals
positively, with a mild best-fit fallback.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)   # recency-weighted histogram of item sizes
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist *= 0.999
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    tot = _hist.sum()
    if tot > 0.0:
        prob = _hist / tot  # probability weight per item size
        # For each residual value r, value of leaving that residual =
        # probability that a future item exactly fills it.
        reuse_value = prob[residual.astype(np.int64)]
        mean_item = _sum / _count
    else:
        reuse_value = np.zeros_like(res)
        mean_item = 40.0

    # Primary: dominant exact-fill bonus.
    score = np.where(residual == 0, 1000.0, 0.0)

    # Secondary: reward residuals that a likely future item can exactly fill.
    # Scale to stay clearly below the exact-fill bonus but above noise.
    score += 200.0 * reuse_value

    # Tertiary: mild best-fit preference (smaller residual) and closeness to mean.
    score += -0.05 * res
    score += -0.02 * np.abs(res - mean_item)

    return score
# EVOLVE-BLOCK-END
