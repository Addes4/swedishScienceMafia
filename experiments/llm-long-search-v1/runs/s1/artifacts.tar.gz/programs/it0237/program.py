# EVOLVE-BLOCK-START
"""Best-fit with a residual preservation tiebreaker.

Exact fills are strongly preferred. Otherwise use best-fit (smallest positive
residual after placement) to keep bins dense, but break near-ties toward the
residual closest to the running mean item size so leftover space stays reusable.
"""
import numpy as np

_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Best-fit: prefer smaller positive residual.
    score = -res

    # Break near-ties toward residuals closest to the running mean.
    score += -0.001 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
