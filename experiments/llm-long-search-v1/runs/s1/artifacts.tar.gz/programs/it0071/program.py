# EVOLVE-BLOCK-START
"""Pure best fit with a strong exact-fit preference.

Best fit (smallest residual) is the dominant, robust online rule for this
distribution. The only addition is a large bonus for exact fills, which is
always beneficial because it wastes no capacity.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown

    # Base: prefer the tightest fit (smallest residual).
    score = -residual.astype(np.float64)
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
