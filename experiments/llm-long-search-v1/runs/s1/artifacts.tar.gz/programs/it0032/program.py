# EVOLVE-BLOCK-START
"""Best fit with a mild residual-utility bias learned online (no future info used)."""
import numpy as np

# Online estimate of the arrival distribution's mean (initialized near 40).
_state = {"n": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    item = int(item)

    # Update an online mean of observed item sizes (Weibull, mean ~40).
    n = _state["n"] + 1.0
    _state["mean"] += (item - _state["mean"]) / n
    _state["n"] = n
    mu = max(10.0, _state["mean"])

    resid = bins - item  # remaining capacity after placing the item here

    # Primary: prefer tight fits (small residual). Best fit.
    score = -resid.astype(np.float64)

    # Exact fit gets a strong bonus.
    score += (resid == 0) * 2.0

    # Among non-tight bins, mildly prefer residuals large enough to be reusable.
    # Scale so this only breaks near-ties, never overrides the tight-fit ordering.
    score += 0.02 * np.minimum(resid, mu)

    return score
# EVOLVE-BLOCK-END
