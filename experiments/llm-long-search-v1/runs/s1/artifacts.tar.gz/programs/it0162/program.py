# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
is likely to be matched exactly by a future item, using the running histogram
as a stable estimate of the item-size distribution. A mild best-fit tie-break
prefers the smallest usable residual.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0

# Precomputed values array (residuals 0..100)
_vals = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Probability mass that a future item exactly fills each possible residual.
    # Use histogram counts directly as a surrogate for the stationary size PMF.
    # (counts are unnormalized, but consistent across bins within a call)
    pmf = _hist  # index = item size = required residual for an exact fill
    exact_bonus = pmf[residual.astype(np.int64)]

    # Normalize magnitude so distribution term stays bounded relative to bonuses.
    scale = max(_count, 1.0)
    score = exact_bonus / scale * 500.0

    # Mild best-fit preference: smaller usable residual is slightly better.
    score += -0.05 * res

    # Mild preference for residuals near the running mean (fallback structure).
    score += -0.02 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
