# EVOLVE-BLOCK-START
"""Best fit with a stable reusable-residual objective.

Exact fills are strongly preferred. Otherwise, score each residual by the running
histogram's probability mass at that residual (so a residual equal to a common
item size, which a future item can exactly fill, is preferred), with a mild
best-fit tie-break toward smaller residuals.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)
    resi = residual.astype(np.int64)

    if _count > 0:
        mean_item = _sum / _count
        # Smoothed probability of an item of size r appearing (reusable residual).
        p = _hist / _count
    else:
        mean_item = 40.0
        p = _hist

    # Reusability of a residual r: how likely a future item exactly fills it.
    score = p[resi]

    # Mild fallback preference for residuals near the running mean.
    score += -0.001 * np.abs(res - mean_item)

    # Mild best-fit tie-break: prefer smaller residuals to pack tighter.
    score += -1e-5 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
