# EVOLVE-BLOCK-START
"""Best fit with a histogram-weighted future-reuse objective.

Exact fills are strongly preferred. Otherwise, prefer a residual that can be
exactly filled by a likely future item (high histogram probability at that
residual value), and reward residuals that, combined with a common item, leave
another common item size (generalized fill). A mild best-fit term breaks ties.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Cached lookup tables, recomputed occasionally.
_fill_score = np.zeros(101, dtype=np.float64)
_gen_score = np.zeros(101, dtype=np.float64)
_cache_tick = -1

_ALL = np.arange(101, dtype=np.float64)


def _rebuild_cache():
    global _fill_score, _gen_score
    if _count <= 0:
        _fill_score = np.zeros(101, dtype=np.float64)
        _gen_score = np.zeros(101, dtype=np.float64)
        return
    p = _hist / _sum_hist()  # probability of each item size
    # exact-fill probability for residual r
    _fill_score = p.copy()
    # generalized fill: prob mass of items s such that (r - s) is itself a common size.
    common = _hist > 0
    # conv of p with common-size indicator, restricted to r in 0..100
    gen = np.zeros(101, dtype=np.float64)
    common_idx = np.nonzero(common)[0]
    if common_idx.size > 0:
        for s in common_idx:
            if s > 100:
                continue
            # r = s + t where t is a common size
            ts = common_idx[common_idx + s <= 100]
            if ts.size > 0:
                gen[s + ts] += p[s]
    _gen_score = gen


def _sum_hist():
    return _hist.sum() if _hist.sum() > 0 else 1.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum, _cache_tick
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    # Rebuild lookup tables periodically (cheap, keeps signal fresh).
    tick = int(_count)
    if tick % 25 == 0 or tick < 3:
        _rebuild_cache()

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    ridx = residual.astype(np.int64)

    # Score: exact-fill probability of the residual (likely future reuse).
    score = 2.0 * _fill_score[ridx]
    # Generalized fill bonus.
    score += 0.3 * _gen_score[ridx]

    # Mild best-fit fallback: smaller residual preferred.
    score += -0.02 * res
    # Mild preference for residuals near the running mean.
    score += -0.01 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
