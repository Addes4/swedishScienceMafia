# EVOLVE-BLOCK-START
"""Best fit with residual-quality shaping.

Exact fits are strongly preferred, tiny nonzero residuals are penalized, and
medium residuals (which future items can actually reuse) get a small bonus.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    # Update histogram of seen item sizes.
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: prefer tight fits.
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)
    # Penalize tiny nonzero residuals (likely useless leftovers).
    small = (residual > 0) & (residual < item)
    score -= np.where(small, res, 0.0)

    # Lookahead: bonus for residuals large enough to be reused by future items.
    if _count > 0:
        mean_item = float(np.dot(np.arange(101), _hist) / _count)
    else:
        mean_item = 40.0

    # Concave bonus peaking near mean_item: larger residuals are more reusable.
    bonus = np.minimum(res, mean_item) * 0.1
    # Extra reward when the leftover matches the typical item size scale,
    # since those leftovers can still be filled effectively.
    bonus += 0.05 * np.where(res >= item, 1.0, 0.0) * np.minimum(res, mean_item)
    score += bonus

    return score
# EVOLVE-BLOCK-END
