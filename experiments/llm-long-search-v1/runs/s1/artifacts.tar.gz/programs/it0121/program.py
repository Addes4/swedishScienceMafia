# EVOLVE-BLOCK-START
"""Worst-fit (most residual) with exact-fit dominance.

The lower bound assumes near-perfect packing. With items ~Weibull(mean 40) and
capacity 100, best-fit tends to create many small, unusable residuals. Keeping
residuals large and balanced lets future items find a good home, so we prefer
the bin with the largest remaining capacity after placement, while always
taking an exact fit when one is available.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: prefer the largest residual (worst fit / keep bins balanced).
    score = res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
