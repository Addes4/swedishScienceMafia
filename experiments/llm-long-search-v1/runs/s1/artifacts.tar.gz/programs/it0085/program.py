# EVOLVE-BLOCK-START
"""Best fit, with a learned bonus for residuals likely to be reused.

The benchmark distribution has many small items, so best-fit (tightest
residual) is the dominant signal.  A very large exact-fit bonus captures free
wins.  Among non-exact residuals we add a small bonus proportional to the
empirical probability of a future item fitting the leftover, which nudges
choices toward reusable space without disturbing the best-fit ordering.
"""
import numpy as np

# Empirical histogram of item sizes seen so far (index = size).
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
# Cumulative distribution tables, rebuilt lazily.
_cdf = np.zeros(101, dtype=np.float64)   # P(item <= s)
_dirty = True


def _rebuild():
    global _cdf, _dirty
    if _count > 0:
        pmf = _hist / _count
    else:
        pmf = _hist.copy()
    _cdf = np.cumsum(pmf)
    _dirty = False


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    global _hist, _count, _dirty

    # Update empirical distribution.
    _hist[item] += 1.0
    _count += 1.0
    _dirty = True

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Rebuild CDF only periodically (cheap, avoids per-call O(101) work).
    if _dirty and (_count < 50 or (_count % 25) < 1.0):
        _rebuild()

    # Base: best fit.
    score = -res

    # Exact fills are essentially always worth taking.
    score += np.where(residual == 0, 1e6, 0.0)

    # Learned reuse bonus: probability that the residual can hold a future item.
    # P(item <= res) scales with reusability; scaled small so best-fit dominates.
    reuse = _cdf[np.clip(residual, 0, 100).astype(np.int64)]
    score += 0.05 * reuse * res

    return score
# EVOLVE-BLOCK-END
