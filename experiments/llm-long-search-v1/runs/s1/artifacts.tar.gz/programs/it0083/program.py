# EVOLVE-BLOCK-START
"""Best fit with exact-fit bonus and frequency-aware tie-breaking.

Best fit dominates: we minimize the residual. Exact fills get a large bonus.
Among bins with residuals that aren't exact fills, we give a mild bonus to
residuals that equal a frequently-seen item size, since such leftovers are
most likely to be exactly consumed by a future item.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    # Update histogram of seen item sizes.
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: prefer tight fits (best fit).
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Frequency-aware tie-breaker: bonus if this residual is a commonly seen
    # item size (so a future item is likely to fill it exactly).
    freq = _hist[residual.clip(0, 100).astype(np.int64)] / max(_count, 1.0)
    score += freq * 2.0 * np.where(residual > 0, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
