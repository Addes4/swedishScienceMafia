# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size, weighted by how common that size is, with a
sharp exponential preference for near-exact reusability, falling back toward a
mild preference for residuals near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted presence of item sizes (decayed each call).
_seen = np.zeros(101, dtype=np.float64)
_exact_bonus = 1000.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    idx = np.nonzero(_seen > 0.0)[0]
    if idx.size > 0:
        vals = np.arange(101, dtype=np.float64)
        d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
        nearest = d.min(axis=1)  # shape (101,)
        # Frequency weight of the nearest seen size for each residual value.
        nearest_idx = idx[d.argmin(axis=1)]
        weight = _seen[nearest_idx]  # shape (101,)
        weight = weight / weight.max() if weight.max() > 0 else weight
    else:
        nearest = np.abs(np.arange(101, dtype=np.float64) - mean_item)
        weight = np.ones(101, dtype=np.float64)

    r = residual.astype(np.int64)
    # Reusability bonus: sharp exponential decay, scaled by frequency weight.
    score = 0.5 * weight[r] * np.exp(-2.0 * nearest[r])

    # Mild best-fit fallback (small residual preferred) and mean proximity.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(r == 0, _exact_bonus, 0.0)

    return score
# EVOLVE-BLOCK-END
