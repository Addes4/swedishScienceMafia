# EVOLVE-BLOCK-START
"""Best fit with residual matching: prefer tight fits, but among similar residuals
favor ones close to the typical item size so leftover space stays fillable."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after insertion
    # Primary: tight fit (small residual). Secondary: residual close to a typical
    # leftover size (~40, roughly matching the item distribution's scale) so the
    # leftover space is likely to be fillable by a future item.
    tight = -residual
    close_to_typical = -np.abs(residual - 40)
    # Compress the secondary term so it only breaks near-ties in primary ranking.
    return tight.astype(np.float64) * 1.0 + close_to_typical.astype(np.float64) * 0.01
# EVOLVE-BLOCK-END
