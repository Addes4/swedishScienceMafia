# EVOLVE-BLOCK-START
"""Best fit with a convex residual-utility score (Sum-of-Squares style)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Post-placement residual for each bin.
    residual = bins - item

    # Convex (quadratic) penalty on residual: strongly favors tight fits and
    # heavily penalizes leaving large unused space, which encourages filling
    # the fullest bins first (a "Sum of Squares" / harmonic-flavored rule).
    return -(residual.astype(np.float64) ** 2)
# EVOLVE-BLOCK-END
