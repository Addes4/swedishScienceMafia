# EVOLVE-BLOCK-START
"""Best fit with empirical leftover-reusability shaping.

Prefer exact fills (dominant), then smaller residuals, but add a bonus for a
residual that matches a frequently observed item size: such a leftover is likely
to be exactly consumed by a future item, which is the strongest reuse signal.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    # Update histogram of seen item sizes.
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: prefer tight fits (smaller residual).
    score = -res
    # Dominant: strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Bonus: residual matching a frequently observed item size -> likely reusable.
    if _count > 0:
        probs = _hist / _count
    else:
        probs = np.zeros(101, dtype=np.float64)
    # For each candidate residual, look up frequency of that exact size.
    idx = np.clip(residual, 0, 100)
    match_bonus = probs[idx] * 100.0
    score += match_bonus

    return score
# EVOLVE-BLOCK-END
