# EVOLVE-BLOCK-START
"""Best fit with a recency-weighted "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
is itself a common recent item size (so a future arrival can fill it exactly),
using a precomputed per-residual payoff that is cheap to index every call.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted histogram of item sizes (decays each call, boost current item)
_seen = np.zeros(101, dtype=np.float64)
# Cached per-residual reuse payoff, recomputed lazily.
_reuse = np.zeros(101, dtype=np.float64)
_reuse_dirty = True


def _rebuild_reuse():
    """Reuse payoff for each residual value 0..100: mass of seen sizes near r."""
    global _reuse, _reuse_dirty
    idx = np.nonzero(_seen > 0.0)[0].astype(np.float64)
    if idx.size == 0:
        _reuse = np.zeros(101, dtype=np.float64)
    else:
        vals = np.arange(101, dtype=np.float64)
        w = _seen[idx.astype(np.int64)]
        d = np.abs(vals[:, None] - idx[None, :])
        # Gaussian-like closeness kernel, bandwidth 2, weighted by recency mass.
        _reuse = (w[None, :] * np.exp(-0.5 * (d / 2.0) ** 2)).sum(axis=1)
    _reuse_dirty = False


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen, _reuse_dirty
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0
    _reuse_dirty = True

    residual = bins - item
    res = residual.astype(np.float64)

    if _reuse_dirty:
        _rebuild_reuse()

    mean_item = _sum / _count if _count > 0 else 40.0

    score = _reuse[residual.astype(np.int64)].copy()

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Best-fit tie-break: mild preference for small residuals near the mean.
    score += -0.02 * np.abs(res - mean_item)

    return score
# EVOLVE-BLOCK-END

