# EVOLVE-BLOCK-START
"""Sum-of-Squares rule: penalize large residuals super-linearly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer the bin whose post-placement residual wastes the least space.
    # Convex penalty: large leftovers are much worse than small ones.
    return -(residual.astype(np.float64)) ** 2 * 0.01 - 0.5 * residual
# EVOLVE-BLOCK-END
