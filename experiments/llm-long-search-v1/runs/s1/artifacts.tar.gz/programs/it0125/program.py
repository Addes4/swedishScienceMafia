# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
is itself a likely future item size (weighted by how often/comonly it appears
recently), falling back toward a mild preference for residuals near the mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Cached recency-weighted histogram of item sizes seen (decayed each call)
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Likelihood that a residual value can be exactly reused soon: proportional to
    # the recency-weighted frequency of that size among observed items.
    total_seen = _seen.sum()
    if total_seen > 0.0:
        # normalize so typical probabilities are O(1)
        reusable = _seen / (total_seen / 100.0)
    else:
        reusable = np.zeros(101, dtype=np.float64)

    # Score: residuals that are common item sizes are strongly preferred.
    score = reusable[residual.astype(np.int64)]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Absolutely prefer exact fills.
    score += np.where(residual == 0, 1e9, 0.0)

    return score
# EVOLVE-BLOCK-END
