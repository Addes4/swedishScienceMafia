# EVOLVE-BLOCK-START
"""Best fit with a compact "reuse payoff" residual table.

Exact fills dominate. Otherwise we reward residuals that are likely to be
filled by the next arrival, using two cheap, robust signals: closeness to the
running mean item size, and closeness to the current histogram mode. The
score is a smooth function of the residual, so it degrades gracefully when no
exact fill exists.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-decayed histogram used only to compute the current mode cheaply.
_seen = np.zeros(101, dtype=np.float64)
_mode = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen, _mode
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.995
    _seen[item] += 1.0

    residual = bins - item
    res = residual.astype(np.float64)

    mean_item = _sum / _count if _count > 0.0 else 40.0

    # Update the (recency-weighted) mode of item sizes.
    best = int(np.argmax(_seen))
    if _seen[best] > 0.0:
        _mode = float(best)

    # Reuse payoff: prefer residuals close to the mean item size (most likely
    # next fill) and close to the histogram mode. Both are cheap scalar lookups.
    score = -np.abs(res - mean_item) * 0.15 - np.abs(res - _mode) * 0.10

    # Strong preference for residuals that are exactly fillable by a recent
    # item size (i.e. the residual itself was recently observed).
    score += np.where(_seen[residual.astype(np.int64)] > 0.0, 0.5, 0.0)

    # Exact fills dominate everything.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
