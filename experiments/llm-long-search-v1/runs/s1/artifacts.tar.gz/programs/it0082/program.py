# EVOLVE-BLOCK-START
"""Best fit with a learned residual-reusability tie-breaker.

Dominant rule: fill the tightest bin (best fit). A large exact-fit bonus
guarantees zero-residual fills win. Ties between nonzero residuals are broken
by a small bonus proportional to the empirical probability that the leftover
will be fillable by some future item, estimated from a running histogram of
observed item sizes.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
# Cached reuse-probability lookup keyed by residual 0..100.
_reuse = np.zeros(101, dtype=np.float64)
_dirty = True


def _update_reuse():
    """Estimate P(a future item fits into a bin with residual r)."""
    global _reuse, _dirty
    if _count <= 0:
        # Fallback: assume items roughly uniform in [1,100].
        _reuse = np.arange(101, dtype=np.float64) / 100.0
    else:
        cdf = np.cumsum(_hist) / _count
        # P(item <= r) for r = 0..100, with smoothing toward uniform.
        smooth = 5.0
        p = (np.cumsum(_hist) + smooth * (np.arange(101) / 100.0)) / (_count + smooth)
        _reuse = p
    _dirty = False


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count, _dirty

    # Update histogram of seen item sizes (before scoring this item is fine).
    _hist[item] += 1.0
    _count += 1.0
    _dirty = True

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Dominant: best fit (tightest residual).
    score = -res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Learned tie-breaker: bonus proportional to reuse probability of residual.
    if _dirty:
        _update_reuse()
    # Index safely (residual is in 0..100).
    reuse_bonus = _reuse[np.clip(residual, 0, 100)]
    score += 0.5 * reuse_bonus

    return score
# EVOLVE-BLOCK-END
