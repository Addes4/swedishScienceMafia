# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches the most probable next item size (the mode of a recency-weighted
histogram), so a subsequent arrival can complete the bin exactly.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Recency-weighted histogram (EMA over normalized counts) to estimate the
    # most probable next item size.
    total = _hist.sum()
    if total > 0:
        prob = _hist / total
    else:
        prob = np.zeros(101, dtype=np.float64)
        prob[int(round(mean_item))] = 1.0

    sizes = np.arange(101, dtype=np.float64)
    mode_size = float(sizes[np.argmax(prob)])

    # Score.
    # 1) Exactly filling the bin is best.
    score = np.where(residual == 0, 1000.0, 0.0)
    # 2) Otherwise, prefer residuals matching the most probable next item size
    #    (so a single future item completes the bin).
    score += -0.5 * np.abs(res - mode_size)
    # 3) Mild preference toward the running mean.
    score += -0.05 * np.abs(res - mean_item)
    # 4) Tiny best-fit tie-break: prefer smaller positive residuals.
    score += -0.001 * res

    return score
# EVOLVE-BLOCK-END

