# EVOLVE-BLOCK-START
"""Best-fit with a mild residual-shape tiebreak favoring reusable leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tighter fit (smaller residual) is better.
    # Tiebreak: among near-equal fits, prefer a residual around 20 (a common small item),
    # which keeps bins usable; subtract a tiny amount so it never overrides fit.
    bonus = -0.001 * np.abs(residual.astype(np.float64) - 20.0)
    return -residual.astype(np.float64) + bonus
# EVOLVE-BLOCK-END
