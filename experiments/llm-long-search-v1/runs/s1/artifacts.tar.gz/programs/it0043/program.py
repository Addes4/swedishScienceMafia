# EVOLVE-BLOCK-START
"""Best fit with a value function on the post-placement residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    r = bins - item  # residual after placing
    # Base: best fit (prefer smallest residual).
    score = -r.astype(np.float64)
    # Strong bonus for exact fill.
    score += 1000.0 * (r == 0)
    # Slight penalty for leaving a useless sliver (residual 1..4) so we avoid
    # creating bins that can almost never be reused.
    score -= 200.0 * ((r >= 1) & (r <= 4))
    return score
# EVOLVE-BLOCK-END

