# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware tie-break.

Primary rule: choose the bin with the smallest post-placement residual (best fit).
Tie-break: among bins whose residual is within a small window of the best, prefer the
bin that leaves a residual which is a commonly observed item size, since such a
residual is likely to be exactly filled by a future item.
"""
import numpy as np

# Running histogram of observed item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties)."""
    global _total

    # Update the running size histogram (before ranking, using past items only).
    _hist[item] += 1.0
    _total += 1.0

    # Probability mass of each residual size being exactly fillable soon.
    # Normalize to [0, 1]-ish for a mild tie-break bonus.
    prob = _hist / _total if _total > 0 else _hist

    # Post-placement residual for each bin.
    residual = bins - item

    # Primary: strongly prefer the tightest fit (smallest residual).
    score = -residual.astype(np.float64) * 1.0

    # Tie-break bonus: residual sizes that are common item sizes are more reusable.
    # Only add a small bonus so it never overrides a meaningfully better fit.
    # Clip index to valid range.
    idx = np.clip(residual, 0, 100).astype(np.int64)
    bonus = prob[idx]
    # Scale tiny so primary ordering dominates; break near-ties only.
    score += 0.001 * bonus

    return score
# EVOLVE-BLOCK-END
