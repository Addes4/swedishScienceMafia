# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and a light reuse bonus.

Exact fills dominate. Otherwise, prefer the smallest residual (classic best fit,
which packs tightly), with a mild bonus for residuals equal to the most common
recent item size (a likely future exact fill).
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Most common recently-seen item size (mode), cheap to get from the histogram.
    # Seed with the running mean to behave sensibly for the first few items.
    if _count > 0:
        mode_item = float(np.argmax(_hist))
        mean_item = _sum / _count
    else:
        mode_item = 40.0
        mean_item = 40.0

    # Classic best fit: smaller residual is better.
    score = -res

    # Mild bonus when the residual exactly matches the most likely future item,
    # allowing it to be filled exactly by a single subsequent item.
    score += np.where(residual == int(mode_item), 0.5, 0.0)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
