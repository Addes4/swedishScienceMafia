# EVOLVE-BLOCK-START
"""Best fit with a small bonus for leaving a residual near the item-size mode."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (small residual).
    # Secondary: prefer residual around a typical future item size (~40) so it can be
    # completed exactly later; penalty grows with distance from 40.
    return -(residual) - 0.02 * np.abs(residual - 40)
# EVOLVE-BLOCK-END

