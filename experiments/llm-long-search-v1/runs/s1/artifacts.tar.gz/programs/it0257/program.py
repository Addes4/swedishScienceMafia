# EVOLVE-BLOCK-START
"""Exact-fill-first, then best-fit with a residual-reusability bonus.

Exact fills are strongly preferred. Among the rest, prefer smaller residuals
(classic best fit) but add a modest bonus when the residual equals a size that
is exactly reachable by a single likely future item, using a recency-decayed
histogram of observed item sizes.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist *= 0.9995
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item
    res = residual.astype(np.float64)

    mean_item = (_sum / _count) if _count > 0 else 40.0

    # Recency-weighted probability that a future item equals residual r.
    tot = _hist.sum()
    if tot > 0.0:
        prob = _hist / tot
    else:
        prob = np.zeros(101, dtype=np.float64)

    r_int = residual.astype(np.int64)
    fill_prob = prob[r_int]  # P(next item exactly fills this residual)

    # Best-fit core: smaller residual is better.
    score = -res

    # Bonus for residuals that are likely exactly fillable.
    score += 5.0 * fill_prob

    # Mild preference toward the running mean as a fallback.
    score += -0.02 * np.abs(res - mean_item)

    # Dominant exact-fill preference.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
