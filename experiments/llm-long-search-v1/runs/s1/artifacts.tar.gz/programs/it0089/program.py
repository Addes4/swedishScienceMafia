# EVOLVE-BLOCK-START
"""Best fit with exact-fit preference and a reusable-leftover tie-break.

Plain best-fit (tightest residual) is the dominant rule. Exact fits get a
large bonus, and among non-exact fits we mildly prefer residuals that are
still large enough to be reusable by typical future items.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item          # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Dominant term: prefer the tightest fit.
    score = -res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Mild preference for leaving a residual that is not tiny relative to the
    # item (i.e. a leftover a future item may still use).
    usable = (residual > 0) & (residual < item)
    score += np.where(usable, res, 0.0) * 0.001

    return score
# EVOLVE-BLOCK-END
