# EVOLVE-BLOCK-START
"""Exact-fill dominance with a distribution-aware residual value.

Exact fills are strongly preferred. Otherwise, prefer a residual that the
running item-size distribution is likely to fill soon: reward residual r by the
probability that a future item equals r (histogram mass), plus a mild best-fit
tie-break toward small residuals and the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Probability mass of the running histogram, normalized (Laplace-smoothed).
    # Probability that a future item exactly equals residual r -> reusable residual.
    prob = _hist / _count if _count > 0 else _hist

    # Score each bin: probability that its residual will be exactly filled soon.
    score = prob[residual.astype(np.int64)].astype(np.float64)

    # Mild best-fit tie-break toward small residuals and near the running mean.
    score += -0.02 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
