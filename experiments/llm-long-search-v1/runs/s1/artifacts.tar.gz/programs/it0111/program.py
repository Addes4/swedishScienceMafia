# EVOLVE-BLOCK-START
"""Best fit with exact-fit dominance and matchable-leftover bonus.

Core: minimize residual (best fit) with a large exact-fill bonus.
Extra: reward residuals that equal a recently-seen item size, since such a
leftover has a real chance of being filled exactly by a future item.
"""
import numpy as np

# Decayed recency counter over item sizes 1..100.
_recent = np.zeros(101, dtype=np.float64)
_decay = 0.995
_count = 0.0
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    global _recent, _count, _hist

    # Decay then record the arriving item.
    _recent *= _decay
    _recent[item] += 1.0
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: best fit (prefer tight fits).
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Bonus: resulting residual is a recently-seen item size -> likely refillable.
    # Normalize the recency weight so it stays a mild tie-breaker.
    if _count > 20.0:
        matchable = _recent[residual.astype(np.int64)]  # weight per residual size
        w = matchable / (_recent.max() + 1e-9)
        score += np.where(residual > 0, w * 5.0, 0.0)

    return score
# EVOLVE-BLOCK-END
