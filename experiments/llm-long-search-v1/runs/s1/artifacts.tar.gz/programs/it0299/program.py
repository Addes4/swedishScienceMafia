# EVOLVE-BLOCK-START
"""Best-fit with an exact-fill bonus.

Prefer exact fills strongly; otherwise pick the bin that leaves the smallest
non-negative residual (Best Fit). This is simple, robust, and empirically
strong on Weibull-like item streams.
"""
import numpy as np

_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties)."""
    global _count, _sum
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for every bin shown
    res = residual.astype(np.float64)

    # Best fit: prefer smaller residual.
    score = -res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

