# EVOLVE-BLOCK-START
"""Best fit with residual-quality shaping plus a learned future-fit bonus.

Tracks a running histogram of observed item sizes. For each candidate bin,
the leftover residual r = bins - item is scored by best-fit (tightness),
a strong exact-fill bonus, a small-residual penalty, and a small bonus when
r is a value that has frequently been seen as an item size (so it is likely
to be fillable later).
"""
import numpy as np

# Running histogram of item sizes (1..100).
_size_counts = np.ones(101, dtype=np.float64)  # Laplace prior


def priority(item, bins):
    global _size_counts
    residual = bins - item  # >= 0
    r = residual.astype(np.float64)

    # Best-fit: prefer tight fits.
    score = -r

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Penalize tiny nonzero residuals (likely wasted leftovers).
    small = (residual > 0) & (residual < item)
    score -= np.where(small, r, 0.0)

    # Small bonus if the leftover is a commonly-seen item size (likely refillable).
    # Normalize counts to a modest weight so it does not override best-fit.
    total = _size_counts.sum()
    freq = _size_counts / total
    idx = np.clip(residual, 0, 100)
    score += 5.0 * freq[idx]

    # Update histogram with the current item (only after scoring).
    _size_counts[item] += 1.0

    return score
# EVOLVE-BLOCK-END
