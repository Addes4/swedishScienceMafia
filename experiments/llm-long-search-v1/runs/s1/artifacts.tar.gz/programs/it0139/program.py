# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective, refined by recency mass.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (so the next few arrivals can fill it exactly),
scaled by how frequently that size has appeared recently, plus a mild fallback
toward residuals near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Cached array of item sizes seen recently (weighted by recency via decay)
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    idx = np.nonzero(_seen > 0.0)[0]
    if idx.size > 0:
        vals = np.arange(101, dtype=np.float64)
        d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
        nearest_pos = d.argmin(axis=1)  # shape (101,)
    else:
        nearest_pos = None

    res_int = residual.astype(np.int64)

    if nearest_pos is not None:
        score = -d[np.arange(101), nearest_pos][res_int]
        # Favor residuals that match a recently-seen, frequent item size.
        matched_seen = _seen[idx][nearest_pos][res_int]
        score += 0.001 * np.log1p(matched_seen)
    else:
        score = -np.abs(res - mean_item)

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

