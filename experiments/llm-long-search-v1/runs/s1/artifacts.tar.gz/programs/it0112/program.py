# EVOLVE-BLOCK-START
"""Harmonic-style bin choice.

Instead of minimizing residual (best fit), reward bins by how many average-sized
items their leftover could still hold, using a harmonic weighting 1/(residual+1).
This favors leaving leftovers that future items can reuse productively, which
reduces total bins in the long run.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    # Update histogram of seen item sizes.
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Harmonic weighting: full bins (residual 0) get a large weight, and among
    # nonzero residuals, smaller residuals are strongly preferred because their
    # leftover is more likely to be reusable.
    score = 1.0 / (res + 1.0)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
