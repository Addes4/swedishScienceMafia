# EVOLVE-BLOCK-START
"""Best fit with a soft "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
has high probability mass of being exactly filled by future items, measured as
a Gaussian kernel over the running item-size histogram. Falls back toward a
mild preference for residuals near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0

# Precompute the 0..100 values and a kernel once.
_vals = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Running histogram as weights over item sizes.
    w = _hist
    total = _count
    # Gaussian matchability: for each residual r, expected closeness to a future item size.
    sigma = 6.0
    # Build matchability vector over r in 0..100 (cheap: 101x101).
    # Only sizes with nonzero weight matter.
    idx = np.nonzero(w > 0.0)[0]
    if idx.size > 0:
        wk = w[idx] / total
        d = _vals[:, None] - idx[None, :].astype(np.float64)
        kernel = np.exp(-(d * d) / (2.0 * sigma * sigma))
        match = kernel @ wk  # shape (101,)
    else:
        match = np.exp(-((_vals - mean_item) ** 2) / (2.0 * sigma * sigma))

    score = 10.0 * match[residual.astype(np.int64)]

    # Mild fallback preference for residuals near the running mean.
    score += -0.02 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

