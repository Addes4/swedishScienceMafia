# EVOLVE-BLOCK-START
"""Best fit with a targeted unusable-residual penalty.

Core rule is pure Best-Fit (smallest residual wins), which is the strongest
simple online rule. We add:
  * a dominant bonus for exact fills (residual == 0),
  * a penalty for residuals that are strictly smaller than the smallest item
    size observed so far (these leftovers can never be filled again, so they
    are pure waste).
This keeps the decision essentially Best-Fit while avoiding pixels of waste.
"""
import numpy as np

_min_seen = 101.0


def priority(item, bins):
    global _min_seen
    if item < _min_seen:
        _min_seen = float(item)

    residual = bins - item          # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Dominant best-fit preference: smaller residual is better.
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)
    # Penalize genuinely unusable leftovers (smaller than any item we might see).
    unusable = (residual > 0) & (residual < _min_seen)
    score -= np.where(unusable, res, 0.0) * 2.0

    return score
# EVOLVE-BLOCK-END
