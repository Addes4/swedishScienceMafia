# EVOLVE-BLOCK-START
"""Best fit with distribution-aware reuse lookahead.

The dominant rule is best fit: prefer the smallest residual, with a huge bonus
for exact fills.  A secondary term favors residuals that the empirical item
distribution is likely to fill efficiently in the near future, using a running
histogram of observed item sizes (available online, no future knowledge).
"""
import numpy as np

# Running empirical histogram of item sizes (online, no lookahead).
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
# Cached reusable quantities recomputed occasionally.
_reuse = np.zeros(101, dtype=np.float64)  # reuse value for residual r
_sorted_items = np.arange(1, 101, dtype=np.float64)
_cached_count = -1.0


def _recompute_reuse():
    """Estimate, for each residual r in 0..100, the expected residual after
    placing one likely future item that fits.  Lower expected residual means the
    bin is more likely to be packed tightly, so we return a score = r_after.
    """
    global _reuse, _cached_count
    total = _count if _count > 0 else 1.0
    p = _hist / total  # probability of each item size
    # For residual r, weight over items s <= r of the resulting residual (r - s).
    for r in range(0, 101):
        if r == 0:
            _reuse[r] = 0.0
            continue
        s = _sorted_items[_sorted_items <= r]
        if s.size == 0:
            _reuse[r] = float(r)
            continue
        ps = p[s.astype(np.int64)]
        w = ps.sum()
        if w <= 0.0:
            _reuse[r] = float(r)
            continue
        expected = float(np.dot(ps, r - s) / w)
        _reuse[r] = expected
    _cached_count = _count


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count, _cached_count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: strict best fit (prefer tight packs).
    score = -res
    # Dominant exact-fill bonus.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Distribution-aware reuse: recompute occasionally to stay cheap.
    if _cached_count < 0 or (_count - _cached_count) >= 25 or _cached_count > _count:
        _recompute_reuse()
    reuse = _reuse[residual]
    # Prefer bins whose residual can be reused efficiently (small expected leftover).
    score -= 0.05 * reuse

    return score
# EVOLVE-BLOCK-END
