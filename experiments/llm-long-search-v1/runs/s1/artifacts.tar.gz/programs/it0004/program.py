# EVOLVE-BLOCK-START
"""Best fit with a residual-usefulness bonus."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Prefer tight fits (small residual). Add a bonus when the residual is
    # exactly 0 (perfect fill) or a small typical size, so that the remaining
    # space stays easy to fill with future small items.
    score = -residual.astype(np.float64)
    score += 0.5 * (residual == 0).astype(np.float64)
    score += 0.1 * ((residual > 0) & (residual <= 10)).astype(np.float64)
    return score
# EVOLVE-BLOCK-END
