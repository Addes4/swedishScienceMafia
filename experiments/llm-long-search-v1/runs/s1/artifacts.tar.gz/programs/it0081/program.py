# EVOLVE-BLOCK-START
"""Best fit with exact-fit preference.

The dominant rule is best-fit: choose the bin with the smallest remaining
capacity that still fits the item. This is the strongest simple online rule.
An exact fit (residual 0) is strictly preferred, which is the one documented
improvement over plain best-fit.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown

    # Base: prefer tight fits (best-fit).
    score = -residual.astype(np.float64)
    # Dominant preference for exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
