# EVOLVE-BLOCK-START
"""Best fit with an exact-fill / common-residual bonus.

Exact fills are strongly preferred. Otherwise use best-fit (smallest residual),
with a small bonus for residuals that match a common item size so they can be
exactly filled by a likely future arrival.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.int64)
    resf = residual.astype(np.float64)

    if _count > 0.0:
        probs = _hist / _count
    else:
        probs = _hist

    score = -resf  # best-fit: prefer smallest residual

    # Bonus: residuals matching a common item size (likely to be exactly filled).
    score += 30.0 * probs[res]

    # Dominant preference for exact fills.
    score += np.where(res == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
