# EVOLVE-BLOCK-START
"""Distribution-aware "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual r that
is likely to be exactly matched by a future item, estimated from the running
histogram of item sizes (a stable, stationary surrogate for the true Weibull
distribution). This replaces the noisy recency-based nearest-seen-size lookup.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Smoothed probability mass of the running histogram at each residual value.
    total = _hist.sum()
    if total > 0:
        p = (_hist + 0.5) / (total + 0.5 * 101.0)
    else:
        p = np.full(101, 1.0 / 101.0)
    p_res = p[residual.astype(np.int64)]

    # Score: higher probability of being exactly completed by a future item,
    # plus a mild preference for residuals near the running mean as a fallback.
    score = 100.0 * p_res
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
