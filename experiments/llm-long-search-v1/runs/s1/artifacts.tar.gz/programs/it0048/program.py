# EVOLVE-BLOCK-START
"""Best fit with a small future-fit residual bonus to reduce stranded gaps."""
import numpy as np


def priority(item, bins):
    # Primary: tightest fit (smallest residual after placement).
    residual = bins - item
    # Perfect fill gets a strong boost.
    score = -residual.astype(np.float64)
    score[residual == 0] += 1000.0
    # Small bonus for residuals that are likely reusable (avoid tiny stranded gaps).
    # Residuals that are very small but nonzero are slightly penalized.
    small = (residual > 0) & (residual < 10)
    score[small] -= 5.0
    return score
# EVOLVE-BLOCK-END

