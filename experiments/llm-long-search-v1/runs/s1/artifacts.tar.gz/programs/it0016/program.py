# EVOLVE-BLOCK-START
"""Best fit with a small residual-usefulness correction learned online."""
import numpy as np


def priority(item, bins):
    """Rank bins: tightest fit first, with a mild bonus for useful residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Base: strongly prefer the tightest fit (smallest residual).
    score = residual.astype(np.float64)

    # Mild reward for residuals that a small/typical future item can still use,
    # and penalty for slivers that tend to be wasted. Weibull-like sizes are
    # mostly small, so residuals below ~ the small-item range are often dead space.
    small = np.where(residual < 10, residual * 0.05,
                     np.where(residual > 85, (100 - residual) * 0.05, 0.0))

    return -(score + small)
# EVOLVE-BLOCK-END
