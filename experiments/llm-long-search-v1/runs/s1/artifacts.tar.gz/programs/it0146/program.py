# EVOLVE-BLOCK-START
"""Best fit with a stable "fillable residual" objective.

The item's complement in a bin (the residual r = remaining - item) is exactly
fillable if an upcoming item has size r. Since items are drawn from a fixed
distribution, we score each bin by the smoothed probability mass the running
histogram assigns to r, so bins that leave a "typical" residual are preferred.
Exact fills dominate, with a small best-fit tie-breaker for the rest.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0

# Precompute a fixed smoothing kernel (small triangular window) reused each call.
_offsets = np.arange(-3, 4, dtype=np.float64)
_kernel = (4.0 - np.abs(_offsets)) / 4.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item
    res = residual.astype(np.int64)

    # Smoothed histogram via convolution (fall back to uniform prior before data).
    if _count > 1.0:
        smooth = np.convolve(_hist, _kernel, mode="same")
    else:
        smooth = np.ones(101, dtype=np.float64)

    # Value of leaving residual r: smoothed probability mass at r.
    score = smooth[res]

    # Strongly prefer exact fills (r == 0 means the bin is perfectly completed).
    score += np.where(res == 0, 1000.0, 0.0)

    # Tiny best-fit tie-breaker: among equally-valuable residuals, prefer smaller waste.
    score -= 1e-4 * res.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
