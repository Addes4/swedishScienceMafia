# EVOLVE-BLOCK-START
"""Best fit with a dominant exact-fit bonus and a mild reuse tie-break.

The core rule is pure best-fit: minimize the resulting residual (maximize used
capacity). Exact fills get a large bonus. A small, secondary term rewards
residuals that coincide with a common observed item size, since those leftovers
are likely to be consumed later by a single item.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (cap 100), in bin order.
    """
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item            # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Core: best-fit (prefer smaller residual = fuller bin).
    score = -res

    # Dominant bonus for exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Mild tie-break: reward residuals matching a frequently seen item size.
    # Weight kept small so it never overrides the best-fit ordering.
    idx = np.clip(residual, 0, 100).astype(np.int64)
    freq = _hist[idx] / _count if _count > 0 else np.zeros_like(res)
    score += freq * res * 0.5

    return score
# EVOLVE-BLOCK-END
