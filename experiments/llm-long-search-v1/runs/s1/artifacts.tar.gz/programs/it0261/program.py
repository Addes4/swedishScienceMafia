# EVOLVE-BLOCK-START
"""Exact-fill priority with a probability-weighted residual reuse signal.

Exact fills get a dominant bonus. Otherwise, prefer bins whose residual is a
likely future item size (weighted by a recency-decayed histogram), with a mild
best-fit tiebreaker toward smaller residuals.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)   # recency-decayed histogram of item sizes
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist *= 0.998
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item              # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Normalized probability that a future item exactly fills a residual of size r.
    total = _hist.sum()
    if total > 0.0:
        prob = _hist / total
    else:
        prob = np.ones(101, dtype=np.float64) / 101.0

    # Reuse signal: probability mass of the residual value (capped at 100).
    r_idx = residual.astype(np.int64)
    r_idx = np.clip(r_idx, 0, 100)
    reuse = prob[r_idx]

    # Score: prefer residuals that are likely future items, mild best-fit tiebreak.
    score = 3.0 * reuse - 0.02 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
