# EVOLVE-BLOCK-START
"""Best fit with a frequency-weighted "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a commonly-seen item size (so it is likely to be filled exactly soon),
falling back toward a mild preference for residuals near the running mean and
a slight preference for smaller residuals.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted presence histogram of item sizes seen so far.
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Frequency-weighted reuse signal: how "hot" is a residual, based on the
    # smoothed frequency of item sizes near it.
    seen_present = _seen > 0.0
    idx = np.nonzero(seen_present)[0]
    res_int = residual.astype(np.int64)
    if idx.size > 0:
        vals = np.arange(101, dtype=np.float64)
        # Gaussian-ish kernel weighting of seen sizes by proximity to each value.
        dist = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
        w = _seen[idx][None, :]
        # weight common sizes strongly, with tolerance ~2 units
        ker = np.exp(-(dist ** 2) / (2.0 * 2.0 ** 2))
        hot = (ker * w).sum(axis=1)  # shape (101,)
        # normalize to avoid scale blowup
        mx = hot.max()
        if mx > 0:
            hot = hot / mx
    else:
        hot = np.zeros(101, dtype=np.float64)

    # Score: hotter residuals are more reusable.
    score = hot[res_int]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Very slight best-fit pull to reduce fragmentation among equal signals.
    score += -0.001 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
