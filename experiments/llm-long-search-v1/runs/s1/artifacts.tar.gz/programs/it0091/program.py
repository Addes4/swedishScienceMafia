# EVOLVE-BLOCK-START
"""Best fit with distribution-aware one-step lookahead.

For each candidate bin we place the item, leaving a residual r. We then estimate
the expected value of that residual using the empirical histogram of item sizes
seen so far: if a future item of size s <= r arrives it can reuse this bin (good),
otherwise the residual tends to become waste. The bin that minimizes expected
waste gets the highest score, with exact fits strongly preferred.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_psmall = None  # cached cumulative distribution info


def _cum_probs():
    """Probability that a random future item has size <= r, for each r."""
    if _count <= 0:
        return None
    cum = np.cumsum(_hist) / _count
    return cum


def priority(item, bins):
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0
    res = residual.astype(np.float64)

    cum = _cum_probs()

    if cum is None:
        # Cold start: pure best fit.
        score = -res
    else:
        # Probability the residual is useful (some future item fits into it).
        # r ranges 0..100; cap index to 100.
        idx = np.clip(residual, 0, 100)
        p_use = cum[idx]
        # Expected useful capacity retained (scaled): residual that is likely to
        # be reused is good; residual unlikely to be reused is waste.
        score = p_use * res - (1.0 - p_use) * res * 0.5
        # Almost always: prefer tight fits, so subtract residual.
        score -= res * 0.5

    # Strong exact-fit preference.
    score = score + np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
