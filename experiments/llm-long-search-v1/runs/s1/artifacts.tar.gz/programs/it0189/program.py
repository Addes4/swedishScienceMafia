# EVOLVE-BLOCK-START
"""Best fit with a small bias toward residuals that are 'unusable small'.

Core rule: Best Fit (smallest residual that still fits). This minimizes the
number of leftover fragments. We add a weak bonus for residuals below the
smallest item size seen so far (those bins become effectively closed/full and
won't attract future small items), and a modest exact-fill bonus.
"""
import numpy as np

_min_item = 100.0


def priority(item, bins):
    global _min_item
    if item < _min_item:
        _min_item = float(item)

    residual = bins - item  # >= 0 everywhere since bins shown all fit
    res = residual.astype(np.float64)

    # Best fit: smaller residual is better.
    score = -res

    # Bonus: residual smaller than the smallest observed item => unusable,
    # so this bin won't be fragmented further by any future item.
    score += np.where(res < _min_item, 2.0, 0.0)

    # Exact fill is the ideal outcome.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
