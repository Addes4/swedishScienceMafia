# EVOLVE-BLOCK-START
"""Distribution-aware residual scoring.

Estimate, from the running item histogram, the probability that an arriving item
will exactly complete a bin whose residual is r. Reward bins whose residual is a
likely item size (so the bin can be closed soon), strongly reward exact fills,
and slightly prefer tighter packing.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Smoothed probability that an item equals each size 1..100.
_p = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _p
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    # Smoothed empirical distribution over item sizes.
    total = _hist.sum()
    if total > 0:
        # Laplace-ish smoothing to keep unseen sizes from being exactly zero.
        _p = (_hist + 0.5) / (total + 0.5 * 100.0)
    else:
        _p = np.full(101, 1.0 / 100.0, dtype=np.float64)

    residual = bins - item
    res = residual.astype(np.int64)

    # Probability that a future item exactly equals the residual: a direct
    # measure of how likely this bin can be closed by a single arrival.
    exact_prob = _p[res]

    # Exact fills dominate.
    score = np.where(res == 0, 1000.0, 0.0)

    # Reward residuals that are likely item sizes (reusable / closable).
    score += exact_prob

    # Mild preference for smaller positive residuals (tighter packing).
    score += -0.01 * res

    return score
# EVOLVE-BLOCK-END
