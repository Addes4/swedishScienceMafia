# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
has high recency-weighted probability mass (so a future item can fill it), plus
a pairing term rewarding residuals complementary to recent partial-bin sizes.
A mild best-fit tie-break (prefer smaller residual) resolves near-ties.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Normalized smoothed histogram (recency-weighted) as a proxy for P(next item = s).
    total_seen = _seen.sum()
    if total_seen > 0:
        p = _seen / total_seen
    else:
        p = np.zeros(101, dtype=np.float64)

    # Probability mass at residual r (future item exactly fills the bin).
    resid_idx = residual.astype(np.int64)
    mass_at_r = p[resid_idx]

    # Pairing term: probability that the next item equals (100 - residual),
    # i.e., complements a previous partial bin of the same size.
    comp_idx = (100 - resid_idx)
    comp_idx = np.clip(comp_idx, 0, 100)
    pair_mass = p[comp_idx]

    mean_item = (_sum / _count) if _count > 0 else 40.0

    score = 2.0 * mass_at_r + 0.5 * pair_mass

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Mild best-fit tie-break: prefer the smallest residual.
    score += -0.001 * res

    # Very mild fallback toward the running mean residual.
    score += -0.0005 * np.abs(res - mean_item)

    return score
# EVOLVE-BLOCK-END
