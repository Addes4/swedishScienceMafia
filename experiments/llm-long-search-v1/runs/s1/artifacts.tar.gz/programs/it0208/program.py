# EVOLVE-BLOCK-START
"""Best fit toward the expected next item size.

Prefer exact fills strongly. Otherwise, prefer leaving a residual close to the
running mean item size, so a typical future arrival tends to fit snugly.
This is smooth (no integer-distance tie saturation) and adapts online.
"""
import numpy as np

_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Prefer residuals near the expected next item size (snug future fill).
    score = -np.abs(res - mean_item)

    # Small Best-Fit tie-break: among near-equal residuals, pack tightly.
    score += -0.01 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
