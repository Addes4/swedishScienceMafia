# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual r that
is likely to be exactly fillable soon, measured by the histogram mass of item
sizes close to r (a smooth, weighted replacement for nearest-integer distance),
falling back toward a mild preference for residuals near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted presence of item sizes.
_seen = np.zeros(101, dtype=np.float64)

# Tolerance weights: a residual r is rewarded for item sizes s near r, with
# weight decreasing with |s - r|.
_OFFSETS = np.array([0, 1, 2, 3], dtype=np.float64)
_WEIGHTS = np.array([1.0, 0.6, 0.3, 0.1], dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    mean_item = _sum / _count

    # Smoothed histogram: score each residual value 0..100 by weighted mass of
    # nearby seen sizes. Build reuse[r] = sum over offsets.
    reuse = np.zeros(101, dtype=np.float64)
    for off, w in zip(_OFFSETS, _WEIGHTS):
        if off == 0:
            reuse += _seen * w
        else:
            # contribution from s = r + off  -> reuse[r] += seen[r+off]*w
            reuse[:101 - off] += _seen[off:101] * w
            # contribution from s = r - off  -> reuse[r] += seen[r-off]*w
            reuse[off:101] += _seen[:101 - off] * w

    # Normalize so the term is meaningful relative to distance units.
    total = _seen.sum()
    if total > 0:
        reuse = reuse / total

    score = 100.0 * reuse[residual.astype(np.int64)]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
