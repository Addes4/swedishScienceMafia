# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (so the next few arrivals can fill it exactly),
falling back toward a mild preference for residuals near the running mean.
The reuse bonus is small relative to Best-Fit so ties are broken properly.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted presence of item sizes.
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Recency-weighted reuse value of the residual: how much seen mass is at
    # this exact residual (with a bit of credit for near matches).
    seen_mass = _seen / max(1.0, _seen.sum())
    # Build value for each possible residual r in 0..100.
    idx = np.nonzero(seen_mass > 0.0)[0]
    if idx.size > 0:
        reuse = seen_mass.copy()
        # partial credit for residuals one away from a seen size
        reuse = np.maximum(reuse, 0.5 * np.roll(seen_mass, 1))
        reuse = np.maximum(reuse, 0.5 * np.roll(seen_mass, -1))
    else:
        reuse = np.zeros(101, dtype=np.float64)

    score = reuse[residual.astype(np.int64)]

    # Best-fit tie-break: prefer smaller residual (slightly dominates reuse).
    score += -1e-4 * res

    # Mild preference toward the running mean residual as fallback.
    score += -1e-6 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
