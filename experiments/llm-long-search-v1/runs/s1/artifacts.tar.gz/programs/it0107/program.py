# EVOLVE-BLOCK-START
"""Best fit with exact-fit bonus plus recent-reuse bonus.

Prefer tight fits (small residual), strongly prefer exact fills, and add a
small bonus when the resulting residual equals an item size seen recently,
since such leftovers are likely to be exactly usable soon.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_recent = np.zeros(101, dtype=np.float64)
_count = 0.0
_DECAY = 0.98


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    global _hist, _recent, _count
    _hist[item] += 1.0
    _recent *= _DECAY
    _recent[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0
    res = residual.astype(np.float64)

    # Base: prefer tight fits.
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)
    # Penalize tiny nonzero residuals (likely useless leftovers).
    small = (residual > 0) & (residual < item)
    score -= np.where(small, res, 0.0)

    # Bonus: residual equals a recently seen item size (likely reusable soon).
    safe_res = np.clip(residual, 0, 100)
    reuse = _recent[safe_res]
    score += 0.5 * reuse

    return score
# EVOLVE-BLOCK-END
