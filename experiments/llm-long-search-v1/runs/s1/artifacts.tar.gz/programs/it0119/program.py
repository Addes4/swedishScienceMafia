# EVOLVE-BLOCK-START
"""Best fit with expected-fill shaping.

Core idea: an arrival should go where it produces the best "leftover" for the
future. Pure best-fit leaves tight residuals that are often too small to reuse.
Instead we score each bin by best-fit quality, strongly reward exact fills, and
reward residuals that future items can likely revisit (a concave, distribution-
aware reuse term). Kept deliberately stable and low-variance.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0
    res = residual.astype(np.float64)

    # Base: prefer tight fits (best fit).
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Distribution-aware reuse term: a residual is more valuable if it is large
    # enough to be filled by plausible future items, but we damp very large
    # residuals so we don't just prefer empty bins.
    if _count > 0:
        mean_item = float(np.dot(np.arange(101), _hist) / _count)
    else:
        mean_item = 40.0
    mean_item = min(max(mean_item, 1.0), 100.0)

    # Concave reward saturating near the mean item size.
    reuse = np.minimum(res, mean_item) / mean_item  # in [0, 1]
    score += 0.5 * reuse

    return score
# EVOLVE-BLOCK-END
