# EVOLVE-BLOCK-START
"""Best fit with online-estimated reusable-residual bonus.

Primary rule: best fit (smallest residual wins). Secondary: a small bonus for
residuals that are likely to be exactly fillable by a single future item,
estimated from the empirical item-size distribution seen so far.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Dominant: best fit (prefer tight fits).
    score = -res

    # Strong exact-fit bonus.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Estimated probability that the resulting residual is exactly fillable
    # by one future item, based on the empirical size distribution.
    if _count > 0:
        probs = _hist / _count
    else:
        probs = np.full(101, 1.0 / 100.0)

    # For each residual value, look up probability of that exact size.
    idx = np.clip(residual, 0, 100).astype(np.int64)
    reuse_prob = probs[idx]
    score += reuse_prob * 5.0

    return score
# EVOLVE-BLOCK-END
