# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective plus two-item fill chains.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (so the next few arrivals can fill it exactly),
and additionally reward residuals that can be exactly consumed by TWO common
item sizes in sequence, which captures more of the "fill the bin soon" structure.
Falls back toward a mild preference for residuals near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Cached array of item sizes seen recently (weighted by recency via decay)
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Distance to the closest recently-seen item size (0 if residual is an observed size).
    seen_present = _seen > 0.0
    idx = np.nonzero(seen_present)[0]
    if idx.size > 0:
        vals = np.arange(101, dtype=np.float64)
        d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
        nearest = d.min(axis=1)  # shape (101,)
    else:
        nearest = np.abs(np.arange(101, dtype=np.float64) - mean_item)

    # Probability-weighted matchability using the histogram:
    # probability that a future single item has size exactly equal to the residual.
    hist_norm = _hist / _count if _count > 0 else np.ones(101) / 101.0
    single_match = hist_norm  # prob exact fill by one item

    # Two-item fill chain: prob that residual can be written as a + b with a,b >= 1,
    # weighted by the product of their probabilities (a rough joint mass).
    # Compute for all residual values 0..100 via a small convolution on sizes 1..100.
    p = hist_norm[1:101]  # sizes 1..100
    # convolution p * p gives mass for sums 2..200
    conv = np.convolve(p, p)  # index k -> sum k+2
    chain = np.zeros(101, dtype=np.float64)
    # residual r -> sums equal to r; conv index = r - 2
    for r in range(2, 101):
        chain[r] = conv[r - 2]

    score = -nearest[residual.astype(np.int64)]

    # Reward residuals likely to be exactly filled by one common item.
    score += 3.0 * single_match[residual.astype(np.int64)]

    # Reward residuals that can be exactly consumed by two common items.
    score += 1.5 * chain[residual.astype(np.int64)]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

