# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference and a cheap fillability tie-break.

Exact fills are strongly preferred. Among non-exact bins, prefer the smallest
residual (classic best fit) while giving a small bonus to residuals that a
recently-seen item size is likely to fill exactly.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)   # recency-decayed histogram of item sizes


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist
    _hist *= 0.995
    _hist[item] += 1.0

    residual = bins - item          # >= 0
    res = residual.astype(np.float64)

    # Probability-weighted fillability of a residual r: sum over sizes s of
    # hist[s] * (s == r) contributions are sharp; use a soft match so residual
    # values near probable item sizes get some credit.
    total = _hist.sum()
    if total > 0.0:
        p = _hist / total
    else:
        p = _hist

    # Soft fillability: expected closeness of a probable future size to residual.
    sizes = np.arange(101, dtype=np.float64)
    # fill[r] = sum_s p[s] * exp(-((s - r)^2) / (2 * sigma^2))
    sigma = 3.0
    diff = sizes[None, :] - res[:, None]          # (nbins, 101)
    w = np.exp(-(diff * diff) / (2.0 * sigma * sigma))
    fill = w @ p                                   # (nbins,)

    # Best fit: strongly prefer smaller residual.
    score = -res

    # Mild bonus for residuals likely to be exactly fillable soon.
    score += 0.5 * fill

    # Dominant exact-fill bonus.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
