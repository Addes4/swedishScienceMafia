# EVOLVE-BLOCK-START
"""Best fit with a tiny secondary preference for filling fuller bins first."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual). Secondary: prefer fuller bins
    # (smaller remaining capacity) so roomy bins stay available for large items.
    return -(residual * 1000 + bins)
# EVOLVE-BLOCK-END
