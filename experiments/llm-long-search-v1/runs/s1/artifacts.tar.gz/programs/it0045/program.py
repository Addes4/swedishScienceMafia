# EVOLVE-BLOCK-START
"""Best fit with a bonus for residuals that match a typical future item size."""
import numpy as np


def priority(item, bins):
    """Score bins by post-placement residual, with a bonus when the residual
    matches a likely future item size (making the bin easy to fill later)."""
    residual = bins - item
    # Primary: prefer small residual (best fit). Negative so smaller residual => higher score.
    score = -residual.astype(np.float64)
    # Bonus: residuals near the typical item size (~40) are attractive to fill later.
    # Small magnitude so it only breaks near-ties in favor of reusable leftovers.
    score += 1e-3 * (-(np.abs(residual - 40)))
    return score
# EVOLVE-BLOCK-END
