# EVOLVE-BLOCK-START
"""Best fit with a mild bias toward filling nearly-full bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins - item  # remaining capacity after placing the item
    # Best fit: prefer smallest residual.  Small additional bonus for bins that were
    # already fairly full (small original remaining), nudging toward finishing bins.
    return -rem + 0.01 * (100 - bins)
# EVOLVE-BLOCK-END
