# EVOLVE-BLOCK-START
"""Best fit with a 'make-room-for-common-items' residual preference."""
import numpy as np


def priority(item, bins):
    """Rank bins: exact fill first, else prefer residual that is a common item size."""
    residual = bins - item

    # bonus for making a bin exactly full
    exact = (residual == 0).astype(np.float64)

    # prefer residuals near typical item sizes (mean ~40 of a Weibull-ish dist)
    # use a smooth bump around 40 and around small slivers being bad
    r = residual.astype(np.float64)
    common = -np.abs(r - 40.0) * 0.01          # small pull toward ~40 leftover
    sliver = -(r < 8) * 0.5                    # avoid tiny unusable leftovers
    wide   = -(r > 70) * 0.3                   # avoid leaving huge holes

    return exact * 100.0 + common + sliver + wide
# EVOLVE-BLOCK-END
