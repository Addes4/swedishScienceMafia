# EVOLVE-BLOCK-START
"""Exact-fill preference plus frequency-weighted reusable-residual score.

Exact fills are strongly preferred. Otherwise, prefer a residual that equals a
frequent recent item size (so it is likely to be refilled soon), scaled by the
running frequency of that size. A mild best-fit tiebreak keeps bins compact.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence.
    _seen *= 0.9995
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    residual = residual.astype(np.int64)
    res = residual.astype(np.float64)

    # Frequency (recency-weighted) of each residual value as an item size,
    # normalized so common sizes give a bonus near 1.
    denom = _seen.sum()
    if denom > 0.0:
        freq = _seen[residual] / denom
    else:
        freq = np.zeros_like(res)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Reward residuals that are frequent recent item sizes (likely reused).
    score = 50.0 * freq * 100.0

    # Prefer best fit (smaller residual) as a mild tiebreak.
    score += -0.5 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

