# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
is likely to be matched exactly by a future item, using the running histogram
of item sizes. A mild preference for residuals near the running mean acts as a
fallback for residuals that the histogram has no support for.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0

# Precompute the fallback distance array once (residual 0..100 vs mean).
_vals = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum

    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)
    res_idx = residual.astype(np.int64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Probability that a future item exactly equals the residual, so the bin
    # can be filled perfectly. Normalize the running histogram.
    total = _hist.sum()
    if total > 0:
        prob = _hist / total
    else:
        prob = _hist

    # Matchability: histogram mass at this residual value (exact-fill chance).
    score = prob[res_idx]

    # Mild fallback: prefer residuals near the running mean item size.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills of the arriving item.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

