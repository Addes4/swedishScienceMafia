# EVOLVE-BLOCK-START
"""Best fit with exact-fill preference.

Exact fills are strongly preferred. Otherwise use classic best fit: choose the
bin with the smallest remaining capacity that still fits the item (smallest
positive residual), which reliably conserves capacity.
"""
import numpy as np

_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Best fit: prefer smaller residual (tighter packing).
    score = -res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
