# EVOLVE-BLOCK-START
"""Best fit with a learned exact-refill desirability bonus.

Best fit is dominant: among fitting bins the one with the smallest residual is
chosen, and exact fills get a strong fixed bonus.  As a tie-breaker/shaper we
add a small bonus proportional to the learned probability that the remaining
residual will be exactly filled by a single future item, estimated online from
the empirical item-size histogram.  This is a principled, distribution-aware
refinement that does not disturb the dominant best-fit ordering.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0

# Small fixed constants controlling term magnitudes.
_EXACT_BONUS = 1000.0
_DESIRE_SCALE = 0.5


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    # Update histogram of seen item sizes (state kept between calls).
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all shown bins
    res = residual.astype(np.float64)

    # Dominant term: prefer tight fits (smallest residual).
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, _EXACT_BONUS, 0.0)

    # Learned probability that a residual r can be exactly filled by one item.
    # p(r) = count of item sizes equal to r, normalized by total items seen.
    if _count > 0.0:
        prob = _hist / _count  # prob[r] = P(next item == r)
    else:
        prob = np.zeros(101, dtype=np.float64)

    # For each bin, its residual r; bonus = prob that r will be exactly filled.
    # residual values are 0..100 so we can index the histogram directly.
    idx = np.clip(residual, 0, 100)
    desire = prob[idx]
    score += _DESIRE_SCALE * desire

    return score
# EVOLVE-BLOCK-END
