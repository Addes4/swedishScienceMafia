# EVOLVE-BLOCK-START
"""Best fit with exact-fit bonus and histogram-weighted reusable-residual bonus."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0
    res = residual.astype(np.float64)

    # Base: prefer tight fits.
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Histogram-weighted reusable-residual bonus: reward residuals that are
    # themselves likely to be filled exactly by some future item.
    if _count > 0:
        freq = _hist / _count
    else:
        freq = np.zeros(101, dtype=np.float64)
    resid_idx = np.clip(residual, 0, 100).astype(np.int64)
    score += 20.0 * freq[resid_idx]

    return score
# EVOLVE-BLOCK-END
