# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a size likely to arrive soon (recency-weighted histogram mass near the
residual), so upcoming items can fill it exactly or nearly.
"""
import numpy as np

# Recency-weighted histogram of item sizes seen so far (index 1..100).
_seen = np.zeros(101, dtype=np.float64)
_count = 0.0

# Precompute the 0..100 value grid once.
_vals = np.arange(101, dtype=np.float64)
# Exponential closeness kernel between a residual r and an item size s:
# penalty = -weight(r,s), where weight decays with |r - s|.
_DECAY = 0.55  # per unit distance


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _seen, _count
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.9995
    _seen[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res_i = residual.astype(np.int64)
    res = res_i.astype(np.float64)

    # Reusability weight for each possible residual value 0..100:
    # sum over seen item sizes s of mass(s) * decay^|r - s|.
    # Build pairwise closeness matrix over 0..100.
    delta = np.abs(_vals[:, None] - _vals[None, :])          # (101,101)
    closeness = np.power(_DECAY, delta)                       # (101,101)
    reusable = closeness @ _seen                              # (101,)

    # Base score: how reusable the residual is.
    score = reusable[res_i]

    # Exact fills strongly preferred.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Tiny tie-break toward smaller residuals (best-fit flavor) so that among
    # equally reusable residuals we pack more tightly.
    score += -0.001 * res

    return score
# EVOLVE-BLOCK-END
