# EVOLVE-BLOCK-START
"""Best-fit with a strong exact-fill bonus.

Choose the bin with the smallest nonnegative residual (classic Best Fit), so
leftovers stay small and future items are more likely to fit. Exact fills are
dominated by a large additive bonus.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Smaller residual is better (Best Fit).
    score = -res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

