# EVOLVE-BLOCK-START
"""Best fit with a gentle worst-fit tie-break to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual). Secondary: slightly prefer larger residual
    # among near-ties, so leftover space stays useful rather than becoming tiny slivers.
    return -residual + 0.02 * bins
# EVOLVE-BLOCK-END
