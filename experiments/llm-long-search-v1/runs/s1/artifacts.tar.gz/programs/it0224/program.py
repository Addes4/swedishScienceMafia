# EVOLVE-BLOCK-START
"""Best Fit: pick the bin that leaves the smallest remaining capacity.

This is the classic Best-Fit online heuristic. Exact fills are handled
naturally (residual 0) and, among non-exact bins, the smallest residual wins.
A tiny running-mean-independent tie-break avoids index-order artifacts.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Best Fit: smaller residual is better.
    score = -res

    # Strongly prefer exact fills (already implied, but make it dominant/robust).
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

