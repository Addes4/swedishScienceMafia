# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
is likely to be filled exactly by a future item, using a long-run histogram of
observed item sizes as a stable estimate of the distribution. Fall back toward
a mild preference for residuals near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
        probs = _hist / _count
    else:
        mean_item = 40.0
        probs = np.zeros(101, dtype=np.float64)

    # Matchability of a residual r: probability mass of items that would exactly
    # fill a bin with that residual, plus a soft neighborhood of nearby sizes.
    # Build a smoothed probability vector over possible residual values 0..100.
    # Larger residuals are more valuable to fill exactly (they waste more if left).
    vals = np.arange(101, dtype=np.float64)
    # Gaussian smoothing kernel over item sizes to allow near-matches.
    sigma = 1.5
    # Build smoothed distribution via convolution-like accumulation.
    kernel_offsets = np.arange(-4, 5, dtype=np.float64)
    kernel = np.exp(-(kernel_offsets ** 2) / (2.0 * sigma * sigma))

    match = np.zeros(101, dtype=np.float64)
    for off, w in zip(kernel_offsets.astype(np.int64), kernel):
        # probability of an item of size s contributes to residual s
        # shift probs by off: item size = r + off -> r = s - off
        shifted = np.zeros(101, dtype=np.float64)
        src = np.arange(101)
        dst = src - off
        valid = (dst >= 0) & (dst <= 100)
        shifted[dst[valid]] += probs[src[valid]]
        match += w * shifted

    # Reward residuals likely to be exactly matched; scale by residual size so
    # that larger leftovers are preferred when matchability is comparable.
    score = match[residual.astype(np.int64)] * (1.0 + 0.01 * res)

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

