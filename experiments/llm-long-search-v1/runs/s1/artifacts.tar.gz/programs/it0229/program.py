# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (so the next few arrivals can fill it exactly),
falling back toward a mild preference for residuals near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Cached array of item sizes seen recently (weighted by recency via decay)
_seen = np.zeros(101, dtype=np.float64)

# Precomputed value grid and a smooth kernel over residual distances.
_vals = np.arange(101, dtype=np.float64)
_K = 6.0  # kernel width


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0

    residual = (bins - item).astype(np.int64)
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Smooth reuse signal: for each possible residual value r, a weighted sum over
    # seen item sizes s of exp(-((r - s)/K)^2) * seen_weight[s].
    idx = np.nonzero(_seen > 0.0)[0]
    if idx.size > 0:
        w = _seen[idx]
        d = (_vals[:, None] - idx[None, :].astype(np.float64)) / _K
        kern = np.exp(-d * d)
        reuse = kern @ w  # shape (101,)
        # Normalize so scale is comparable across time.
        reuse = reuse / (w.sum() + 1e-9)
    else:
        reuse = np.zeros(101, dtype=np.float64)

    reuse_at = reuse[residual]

    # Large residuals that can be reused are more valuable to fill exactly.
    scale = res / 100.0

    # Score: reward reusable residuals, mildly prefer near-mean residuals,
    # strongly prefer exact fills.
    score = 2.0 * reuse_at * (0.5 + scale)
    score += -0.05 * np.abs(res - mean_item)
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
