# EVOLVE-BLOCK-START
"""Best fit with probabilistic residual-reuse lookahead.

The dominant criterion is best-fit (smallest resulting residual), but among
bins whose residual is near the best, we break ties by maximizing the estimated
probability that the leftover can later be filled by a future item. This uses
the empirical item-size distribution built from past arrivals.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0
    res = residual.astype(np.float64)

    # Empirical size distribution (laplace-smoothed).
    total = _count + 101.0
    probs = (_hist + 1.0) / total  # probs[s] = P(item == s)

    # Estimate reuse value of a residual r: probability that a future item
    # exactly fills it (so it can be closed), plus a small reward for residuals
    # that are at least a plausible item size.
    r_int = residual.astype(np.int64)
    r_clip = np.clip(r_int, 0, 100)
    p_exact = probs[r_clip]
    # Zero-out residuals that cannot be filled exactly within 1..100.
    p_exact = np.where((r_int >= 1) & (r_int <= 100), p_exact, 0.0)

    # Dominant best-fit ordering.
    score = -res
    # Exact fill is always best.
    score += np.where(residual == 0, 1000.0, 0.0)
    # Among near-best fits, prefer reusable leftovers.
    score += 200.0 * p_exact

    return score
# EVOLVE-BLOCK-END
