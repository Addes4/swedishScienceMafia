# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (so the next few arrivals can fill it exactly),
falling back toward a mild preference for residuals near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Cached array of item sizes seen recently (weighted by recency via decay)
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.9995
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.int64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Reuse signal: how much decayed mass has been seen at exactly this residual.
    seen_score = _seen[res]

    # Normalize to a modest scale so it ranks above the tiebreaker but below exact fills.
    max_seen = _seen.max()
    if max_seen > 0:
        reuse = seen_score / max_seen
    else:
        reuse = np.zeros_like(seen_score)

    # Base score: reuse signal dominant among non-exact bins.
    score = reuse * 100.0

    # Best-fit tiebreaker: among equal reuse, prefer smaller non-zero residual.
    # Only applied weakly so it does not distort the reuse ranking.
    score += -0.001 * res.astype(np.float64)

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res.astype(np.float64) - mean_item) / 100.0

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

