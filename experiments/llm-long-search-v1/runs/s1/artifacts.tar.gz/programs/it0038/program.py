# EVOLVE-BLOCK-START
"""Sum-of-squares bin choice: penalize leaving large residuals super-linearly.

This is the classic "Sum of Squares" (SS) rule from bin-packing theory: assigning
an item to a bin with remaining capacity r changes the squared residual from r^2
to (r-item)^2, so the score delta is r^2 - (r-item)^2 = 2*r*item - item^2. Since
item is constant across bins, ranking by r (remaining capacity) is equivalent to
ranking by -(r^2 - (r-item)^2) reversed. But to also exploit the heavy tail, we
use the SS objective directly: prefer the bin minimizing the post-placement
squared residual, i.e. maximize (r^2 - (r-item)^2) which is monotone in r, meaning
SS coincides with best-fit here. To break the degeneracy we add a small, bounded
secondary term rewarding exact fills and very tight fits without overriding BF.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Primary: best fit (prefer smallest remaining capacity that still fits).
    # Score = -(residual after placement). Highest score => smallest residual.
    post = bins - item  # >= 0 since bins shown only include those that fit
    # Convex (sum-of-squares) penalty on the post-placement residual: penalize
    # large leftovers more than proportional, which keeps total waste low.
    score = -(post.astype(np.float64) ** 2)
    return score
# EVOLVE-BLOCK-END

