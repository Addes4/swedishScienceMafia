# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus for common residual sizes.

Leave the smallest residual (classic best fit), but give a strong bonus when
the residual exactly matches a frequently-seen item size, so upcoming items
can fill the bin exactly. Exact fills are preferred most of all.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Best fit: strongly prefer the smallest residual (less wasted space).
    score = -res

    # Bonus for residuals that exactly match a commonly-seen item size
    # (so a future item can complete the bin exactly).
    hist_mass = _hist[residual.astype(np.int64)] / max(_count, 1.0)
    score += 200.0 * hist_mass

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
