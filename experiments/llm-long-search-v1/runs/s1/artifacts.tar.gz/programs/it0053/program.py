# EVOLVE-BLOCK-START
"""Best fit with residual-quality shaping: exact fits strongly preferred,
tiny leftover residuals penalized, plus a small bonus for leftovers that match
a commonly-seen item size (so they are likely to be refilled later)."""
import numpy as np

# Persistent state across calls: running frequency of item sizes.
_counts = np.zeros(102, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _total

    residual = bins - item  # >= 0 for all bins shown

    # Update the running histogram of observed item sizes.
    _counts[item] += 1.0
    _total += 1.0

    # Base: prefer tight fits.
    score = -residual.astype(np.float64)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Penalize tiny nonzero residuals (likely useless leftovers).
    small = (residual > 0) & (residual < item)
    score -= np.where(small, residual.astype(np.float64), 0.0)

    # Small bonus if the leftover is 1..100 and matches a commonly-seen item size,
    # so the residual is more likely to be refillable by a future item.
    valid = (residual > 0) & (residual <= 100)
    freq = np.zeros_like(residual, dtype=np.float64)
    if _total > 0:
        r = residual.astype(np.int64)
        masked = np.where(valid, r, 0)
        freq = _counts[masked] / _total
    score += 5.0 * freq

    return score
# EVOLVE-BLOCK-END
