# EVOLVE-BLOCK-START
"""Best fit toward the running mean residual.

Exact fills dominate. Otherwise, prefer the bin whose residual after placement is
closest to the running mean item size, so a typical future item can fill it, with
a mild tilt toward smaller residuals (best-fit behavior).
"""
import numpy as np

_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    mean_item = _sum / _count if _count > 0 else 40.0

    # Prefer residuals close to the running mean item size (fillable by a typical item).
    score = -np.abs(res - mean_item)
    # Mild tilt toward smaller residuals (best-fit).
    score += -0.05 * res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

