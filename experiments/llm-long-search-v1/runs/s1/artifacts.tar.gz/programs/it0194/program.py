# EVOLVE-BLOCK-START
"""Best fit with a smoothly-weighted "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer a residual r by the total
recency-weighted mass of item sizes that could fill it (sizes s <= r, weighted
most for s == r), so upcoming items can complete the bin. A mild preference for
residuals near the running mean acts as a fallback.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # For each possible residual value r (0..100), reusability = sum over seen
    # item sizes s in [r-DELTA, r] with weight increasing towards s == r.
    # Weight for s contributing to r: how well an item of size s fits residual r.
    #   s == r  -> weight 1.0 (exact completion)
    #   s <  r  -> weight 0.5 * (s / r) if within DELTA below r
    vals = np.arange(101, dtype=np.float64)
    seen = _seen  # shape (101,)

    # Build the weight matrix W[s, r]: contribution of seen size s to residual r.
    # Only s <= r and (r - s) <= DELTA matter.
    DELTA = 15.0
    diff = vals[:, None] - vals[None, :]  # diff[s, r] = s - r
    within = (diff <= 0.0) & (diff >= -DELTA)
    ratio = np.where(vals[None, :] > 0.0, vals[:, None] / np.maximum(vals[None, :], 1.0), 1.0)
    W = within * (0.5 * ratio)
    # Exact completion s == r gets weight 1.0
    W = np.where(np.abs(diff) < 1e-9, 1.0, W)

    # reusability[r] = sum_s seen[s] * W[s, r]
    reusability = seen @ W  # shape (101,)

    score = reusability[residual.astype(np.int64)]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
