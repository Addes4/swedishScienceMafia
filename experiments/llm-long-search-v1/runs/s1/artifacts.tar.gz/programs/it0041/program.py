# EVOLVE-BLOCK-START
"""Residual-value bin choice: price the post-placement leftover with a
piecewise-linear value function and break ties toward the larger bin."""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for every bin shown (harness only passes feasible bins)
    # Piecewise-linear value of a residual:
    #   - residual 0: huge bonus (perfect fill)
    #   - small residuals: strongly preferred
    #   - large residuals: slight preference for bigger bins so large items
    #     don't get crammed into already-full-ish bins
    score = -residual.astype(np.float64)
    # reward exact fills
    score += (residual == 0) * 1000.0
    # mild preference for leaving large free space (use empty bins for big items)
    score += 0.05 * bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
