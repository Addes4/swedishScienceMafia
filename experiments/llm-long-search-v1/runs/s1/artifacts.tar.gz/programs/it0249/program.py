# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
a probable future item can fill, using a recency-weighted histogram of items.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)
# Cached residual-value table; recomputed lazily.
_value = None
_dirty = True


def _build_value(mean_item):
    """For each residual r in 0..100, value of leaving that residual.

    Reward exact-match residuals, and residuals that a probable upcoming item
    can fill closely. Combine a recency-weighted fillability term with a mild
    distance-to-mean term.
    """
    global _value, _dirty
    vals = np.arange(101, dtype=np.float64)

    # Recency-weighted histogram of item sizes; smoothed to avoid gaps.
    h = _seen.copy()
    if h.sum() > 0:
        h = h / h.sum()
    # Smooth so unseen nearby sizes still contribute.
    kern = np.exp(-0.5 * ((np.arange(-6, 7)) / 2.0) ** 2)
    kern = kern / kern.sum()
    hs = np.convolve(h, kern, mode="same")

    # reward[r] = probability mass of sizes <= r, weighted by closeness of the
    # resulting leftover to zero (exact fill best).
    exact = 0.0
    for r in range(101):
        # probability that item size s fills r exactly or leaves small leftover
        s = vals[: r + 1]
        leftover = r - s
        w = np.exp(-leftover / 4.0)
        exact += 0.0  # placeholder to keep structure simple
    # vectorized build
    reward = np.zeros(101, dtype=np.float64)
    for r in range(101):
        s = vals[: r + 1]
        leftover = r - s
        w = np.exp(-leftover / 4.0)
        reward[r] = np.sum(hs[: r + 1] * w)

    # Mild preference for residuals near the running mean.
    reward += 0.05 * np.exp(-np.abs(vals - mean_item) / 20.0)
    return reward


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    global _hist, _count, _sum, _seen, _value, _dirty
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0
    _dirty = True

    residual = bins - item
    res = residual.astype(np.float64)

    mean_item = _sum / _count if _count > 0 else 40.0

    # Rebuild value table occasionally (every call is cheap enough here).
    _value = _build_value(mean_item)

    score = _value[residual.astype(np.int64)]
    score += np.where(residual == 0, 1000.0, 0.0)
    return score
# EVOLVE-BLOCK-END
