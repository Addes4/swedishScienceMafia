# EVOLVE-BLOCK-START
"""Best fit with exact-fit bonus and reusable-residual tie-break.

The proven core is strict best fit (smallest resulting residual) with a dominant
reward for exact fills.  We add one narrow tie-break: a residual that stays large
enough to hold the smallest item seen so far is slightly preferred over one too
small to ever be reused, without disturbing the primary best-fit ordering.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_min_item = 100


def priority(item, bins):
    """Return a priority for every bin; highest score wins, earliest index on ties."""
    global _hist, _count, _min_item
    _hist[item] += 1.0
    _count += 1.0
    if item < _min_item:
        _min_item = item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Primary: strict best fit (prefer tight fits).
    score = -res
    # Dominant: exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Narrow tie-break: keep leftovers usable (>= smallest item seen so far).
    usable = residual >= _min_item
    score += np.where(usable, 0.001, 0.0)

    return score
# EVOLVE-BLOCK-END
