# EVOLVE-BLOCK-START
"""Best-fit with perfect-fill rescue and anti-waste guard.

The item distribution is Weibull-shaped with mean ~40. Pure best-fit does well;
the main recoverable waste is when a small item lands in a nearly-full bin and
strands a residual too small for most items, or when a placement leaves a
residual that cannot be refilled. We combine:

  * a large bonus for an exact fill (residual == 0),
  * best-fit distance as the primary criterion,
  * a mild guard: if the item is small (<= 20) and the bin's remaining capacity
    is large-ish, slightly prefer larger residuals (worst-fit flavor) so tiny
    items do not fragment nearly-full bins.

Scores are returned per bin; highest wins, ties to the first bin.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for feasible bins; bins shown all fit the item

    # Primary: best-fit distance (smaller residual -> higher score).
    score = -(residual.astype(np.float64))

    # Perfect-fill rescue: strongly reward exact fills.
    score += 1000.0 * (residual == 0)

    # Anti-waste guard for small items: discourage dumping them into bins that
    # are nearly full (small residual already handled by best-fit) OR leaving a
    # moderately-full bin more fragmented. Specifically, for small items avoid
    # stranding bins whose residual ends up below a "hard to reuse" threshold
    # by nudging toward larger residuals when both choices are otherwise close.
    if item <= 20:
        # prefer larger residual mildly (negative of residual already best-fit);
        # add a small worst-fit-flavored term that only matters for near ties.
        score += 0.05 * bins.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
