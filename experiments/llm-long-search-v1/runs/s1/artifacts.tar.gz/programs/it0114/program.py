# EVOLVE-BLOCK-START
"""Best fit with a small concave preference for near-full bins."""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Dominant: prefer the tightest fit (smallest residual).
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)
    # Slightly favor the very smallest nonzero residuals (most likely to be
    # usefully filled by the next small item), concavely.
    score += np.where(residual > 0, 1.0 / (1.0 + res), 0.0)

    return score
# EVOLVE-BLOCK-END
