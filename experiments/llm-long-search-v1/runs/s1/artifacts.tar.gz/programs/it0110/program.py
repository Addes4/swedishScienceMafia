# EVOLVE-BLOCK-START
"""Best fit with exact-fit preference plus a histogram-based reuse lookahead.

The core signal is minimizing the resulting residual (best fit), with a dominant
bonus for exact fills.  On top of that, a residual that equals a commonly seen
item size is rewarded, since such a leftover can likely be filled exactly by a
future item (which keeps bins well packed).
"""
import numpy as np

# Running histogram of item sizes seen so far.
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in,
          including unused bins (capacity 100), in bin order.
    """
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item          # >= 0 for all shown bins
    res = residual.astype(np.float64)

    # Base: best fit -> prefer the smallest resulting residual.
    score = -res

    # Dominant: exact fills are very valuable.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Lookahead bonus: reward residuals that are likely reusable, i.e. whose
    # value matches (or is close to) a frequently observed item size.
    # Prob of a future item of exactly size r, normalized by count.
    if _count > 0:
        freq = _hist / _count             # length 101
        # residual values are within 0..100
        match_prob = freq[np.clip(residual, 0, 100).astype(np.int64)]
        score += match_prob * 200.0

    # Mild concave bonus: larger residuals hold more future items.
    score += np.minimum(res, 40.0) * 0.1

    return score
# EVOLVE-BLOCK-END
