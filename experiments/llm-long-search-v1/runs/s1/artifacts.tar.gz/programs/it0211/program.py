# EVOLVE-BLOCK-START
"""Reuse-aware Best Fit.

Prefer placing the item so that the leftover residual is likely to be filled
exactly by a future item (weighted by a recency-decayed histogram of item
sizes, smoothed to a continuous score), with Best-Fit as a tie-breaker and a
dominant bonus for exact fills.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted histogram of item sizes.
_seen = np.zeros(101, dtype=np.float64)
# Cached smoothed reuse probability over residuals 0..100.
# Invalidate whenever _seen changes meaningfully.
_reuse_cache = None
_cache_tick = -1
_tick = 0


def _smooth(arr):
    """Light smoothing so nearby residuals get partial credit."""
    out = arr.copy()
    out[1:] += 0.5 * arr[:-1]
    out[:-1] += 0.5 * arr[1:]
    out[1:] += 0.25 * arr[:-2] if arr.size > 2 else 0.0
    return out


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen, _reuse_cache, _cache_tick, _tick
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.995
    _seen[item] += 1.0
    _tick += 1

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Rebuild the smoothed reuse-probability table occasionally (cheap, but
    # avoids recomputing every call).
    if _reuse_cache is None or (_tick - _cache_tick) >= 16:
        total = _seen.sum()
        if total > 0:
            prob = _seen / total
        else:
            prob = _seen
        table = _smooth(prob)
        # Normalize reuse score to a reasonable scale.
        mx = table.max()
        if mx > 0:
            table = table / mx
        _reuse_cache = table
        _cache_tick = _tick

    # Reuse value of the residual left behind (higher => more reusable).
    reuse = _reuse_cache[residual.astype(np.int64)]

    # Best-Fit preference: smaller residual is better (negative because higher
    # score wins). Scaled small so it only breaks ties/reuse-equivalent bins.
    score = 3.0 * reuse - 0.02 * res

    # Mild fallback toward residuals near the running mean.
    score += -0.01 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

