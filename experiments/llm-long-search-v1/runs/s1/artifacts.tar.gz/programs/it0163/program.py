# EVOLVE-BLOCK-START
"""Score bins by the probability their residual is "reusable" for a future item.

The exact fill is heavily preferred. Otherwise we prefer a residual value that
future items are likely to land on exactly (so the leftover space can be
recovered), using a smoothed estimate of the item-size distribution built from
the full running histogram. A mild best-fit tie-break avoids scattering.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0

# All possible residual values, precomputed once.
_vals = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    residual = residual.astype(np.int64)

    # Estimate the item-size distribution from the running histogram.
    if _count > 0:
        dist = _hist / _count
        mean_item = _sum / _count
    else:
        dist = np.zeros(101, dtype=np.float64)
        mean_item = 40.0

    # Smooth the distribution so the surrogate is stable early on and rewards
    # residuals that are *near* common sizes as well as exactly on them.
    # A short triangular kernel over sizes 0..100.
    kern_r = 3
    smooth = np.convolve(dist, np.ones(2 * kern_r + 1) / (2 * kern_r + 1), mode="same")
    # Probability mass within +/-kern_r of each residual value (reusable chance).
    reuse = np.convolve(smooth, np.ones(2 * kern_r + 1), mode="same")[0:101]

    # Reward residuals that future items are likely to fill exactly / nearly.
    score = reuse[residual]

    # Exact fill is dominant.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Mild best-fit tie-break: prefer smaller residuals to keep waste low.
    score += -0.01 * residual.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
