# EVOLVE-BLOCK-START
"""Best-Fit (tightest residual), with exact fills strongly preferred.

Best-Fit is a classic strong online bin-packing heuristic: place each item
into the bin with the smallest remaining capacity that still fits. Exact
fills are naturally chosen since residual 0 is the smallest. Ties go to the
first bin, as required by the harness.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)
    # Smaller residual -> higher score. Exact fills get an extra boost for safety.
    score = -res
    score += np.where(residual == 0, 1000.0, 0.0)
    return score
# EVOLVE-BLOCK-END

