# EVOLVE-BLOCK-START
"""Best fit with a strong exact-fill and a capped reuse bonus.

Exact fills dominate. Otherwise use best-fit (smallest residual) to keep bins
tight, with a small extra bonus for residuals that are frequent recent item
sizes so leftover space is more likely to be reused exactly.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Best-fit: prefer the smallest usable residual.
    score = -res

    # Small bonus: residual is a common recent item size (encourages reuse).
    # Normalize seen frequencies to a bounded [0, 1] scale.
    max_seen = _seen.max()
    if max_seen > 0.0:
        reuse = _seen[residual.astype(np.int64)] / max_seen
    else:
        reuse = np.zeros_like(res)
    score += 0.3 * reuse

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
