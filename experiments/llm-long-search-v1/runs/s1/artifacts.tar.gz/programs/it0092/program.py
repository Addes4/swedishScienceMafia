# EVOLVE-BLOCK-START
"""Best fit: pick the bin with the smallest remaining capacity that still fits.

Exact fits get a dominant bonus. No histogram or residual shaping.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown

    # Dominant term: prefer the tightest fit (smallest residual).
    score = -residual.astype(np.float64)
    # Strong preference for exact fills.
    score += np.where(residual == 0, 1000000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
