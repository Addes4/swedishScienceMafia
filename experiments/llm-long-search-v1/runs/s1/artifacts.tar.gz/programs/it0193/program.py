# EVOLVE-BLOCK-START
"""Reusability-weighted best fit.

Exact fills are strongly preferred. Otherwise, score each candidate residual by
how much recency-weighted item mass could exactly fill it (sizes <= residual),
which is a smooth, finer-grained signal than integer nearest-seen distance.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Smooth reusability: mass of recency-weighted sizes that could fill residual r
    # (an upcoming item of size s <= r can be placed here, ideally exactly filling).
    # Weight sizes that exactly match r most, but give credit to nearby sizes too.
    sizes = np.arange(101, dtype=np.float64)
    seen = _seen.copy()
    total_seen = seen.sum()
    if total_seen > 0:
        seen = seen / total_seen
    else:
        seen = np.zeros(101)
        seen[int(round(mean_item))] = 1.0

    # For each residual value r, sum seen[s] for s <= r (can it be filled at all),
    # with extra weight when s == r (exact fill by a single future item).
    cum = np.cumsum(seen)  # cum[r] = sum_{s<=r} seen[s]
    reusability = cum  # shape (101,)

    score = reusability[residual.astype(np.int64)]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
