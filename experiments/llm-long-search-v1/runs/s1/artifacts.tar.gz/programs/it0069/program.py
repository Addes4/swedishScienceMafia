# EVOLVE-BLOCK-START
"""Best fit with exact-fit preference and complementary-pair coordination.

Exact fills are strongly preferred; among near-best-fit candidates we favor
bins whose current load (capacity already used) is close to the arriving item's
size, so the item pairs with a complementary filler and leaves a small residual.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Dominant best-fit: prefer tight fits.
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Complementary pairing: pre-placement capacity used = 100 - (residual + item).
    used_before = 100.0 - (res + float(item))
    # Favor bins whose prior load closely matches the incoming item size.
    pair = -np.abs(used_before - float(item))
    # Small weight so it only breaks near-ties among best-fit choices.
    score += pair * 0.01

    # Penalize tiny nonzero residuals that are hard to reuse.
    small = (residual > 0) & (residual < item)
    score -= np.where(small, res, 0.0) * 0.05

    return score
# EVOLVE-BLOCK-END
