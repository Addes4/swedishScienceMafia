# EVOLVE-BLOCK-START
"""Online bin choice: value the resulting residual by how likely it is to be fillable.

We keep an empirical histogram of observed item sizes. For a candidate bin, the
placement leaves a residual r. We score the bin by an estimate of how many
future items can be packed into capacity r (a bounded knapsack value), so we
prefer residuals that are "useful" under the observed size distribution, while
also incorporating the tightness of the current fit.
"""
import numpy as np

# Global state (persists across calls)
_hist = np.zeros(101, dtype=np.float64)   # count of items seen with each size
_n = 0.0
_value_cache = {}
_SIZES = np.arange(1, 101, dtype=np.float64)

# Approximate bin-packing value of residual capacity r given size pmf.
_prev_pmf_id = None


def _value_of_capacity(r, pmf, max_r=100):
    """Estimate expected 'packable mass' achievable within capacity r.

    Uses a simple greedy/DP heuristic: expected number of items that fit if we
    repeatedly take the smallest size <= remaining capacity (good utilization),
    but we approximate with a fill-ratio expectation.
    """
    if r <= 0:
        return 0.0
    # expected utilization achievable in capacity r: continuous relaxation
    # Solve small bounded knapsack via DP over integer capacities 0..r.
    # cost proportional to r; cache by r within a call is fine since r<=100.
    dp = np.zeros(int(r) + 1, dtype=np.float64)
    for c in range(1, int(r) + 1):
        best = dp[c - 1]  # not using capacity c meaningfully -> same as c-1
        # try placing one item of each size s <= c and then value of remaining
        # value added = s plus value of (c - s)
        # To keep it fast we only consider common sizes
        for s in range(1, c + 1):
            p = pmf[s]
            if p <= 0.0:
                continue
            v = dp[c - s]
            cand = p * (s + v) + (1.0 - p) * dp[c - 1]
            if cand > best:
                best = cand
        dp[c] = best
    return float(dp[int(r)])


def priority(item, bins):
    global _hist, _n, _prev_pmf_id, _value_cache

    # Update histogram lazily using item (we learn online)
    # Note: we count the arriving item before choosing.
    _hist[item] += 1.0
    _n += 1.0

    pmf = _hist / _n  # probability of each size

    # Value of the residual after placing into each bin.
    residual = bins - item  # >= 0 since bins only include feasible ones

    # Compute value for each distinct residual
    vals = np.empty(len(bins), dtype=np.float64)
    # Use a local cache keyed by residual for this call
    cache = {}
    for i in range(len(bins)):
        r = int(residual[i])
        if r not in cache:
            cache[r] = _value_of_capacity(r, pmf)
        vals[i] = cache[r]

    # Score = value of residual (future packability). Prefer exact fills of
    # large value but also prefer leaving capacity that is highly packable.
    # Add a tiny tightness term to break ties toward tighter fits.
    score = vals * 100.0 - residual * 1e-3
    return score
# EVOLVE-BLOCK-END
