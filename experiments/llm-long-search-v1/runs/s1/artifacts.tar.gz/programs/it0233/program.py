# EVOLVE-BLOCK-START
"""Best fit with a smooth "reusable residual" objective.

Exact fills dominate. Otherwise, reward a residual by the recency-weighted
number of recently seen item sizes that fit inside it (a residual is valuable
if it can still be exactly filled by a likely future item), with a small
best-fit tiebreaker toward smaller leftover.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted histogram of seen item sizes.
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)
    ri = residual.astype(np.int64)

    mean_item = _sum / _count if _count > 0 else 40.0

    # Reuse value of a residual r: total recency-weighted mass of seen item
    # sizes s with s <= r (those items could exactly fill the leftover).
    # Cumulative sum over seen sizes gives this for all r in 0..100.
    cum = np.cumsum(_seen)  # cum[r] = mass of sizes <= r
    reuse = cum[ri]

    # Normalize roughly by total mass so magnitudes stay stable.
    total = _seen.sum()
    if total > 0:
        reuse = reuse / total

    # Score: more reusable leftover is better.
    score = 5.0 * reuse

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Best-fit tiebreaker: among equal reuse, prefer smaller positive leftover.
    score += -0.01 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

