# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (so the next few arrivals can fill it exactly),
falling back toward a mild preference for residuals near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted histogram of item sizes.
_seen = np.zeros(101, dtype=np.float64)
# Precompute value-per-residual lookup once (static).
_vals = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Reuse value: fraction of a typical future item that this residual can
    # exactly accommodate (residual that is a common seen size scores high).
    seen_present = _seen > 0.0
    idx = np.nonzero(seen_present)[0]
    if idx.size > 0:
        # Weighted "match quality" for each possible residual value 0..100:
        # sum of recency weights for seen sizes within a small window of r.
        weights = _seen[idx]
        # distance table shape (101, |idx|)
        d = np.abs(_vals[:, None] - idx[None, :].astype(np.float64))
        # Gaussian-like kernel: strong reward at exact match, decaying nearby.
        ker = np.exp(-(d * d) / (2.0 * 36.0))
        match = ker @ weights  # shape (101,)
    else:
        match = np.exp(-((_vals - mean_item) ** 2) / (2.0 * 400.0))

    match_norm = match / (match.max() + 1e-12)

    # Non-exact score: reuse quality dominates, mild best-fit (small residual).
    score = 1.0 * match_norm[residual.astype(np.int64)]

    # Mild preference for smaller residuals (best fit) and near mean.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
