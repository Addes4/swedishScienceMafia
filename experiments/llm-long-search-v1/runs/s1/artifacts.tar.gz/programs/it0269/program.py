# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
is close to recent item sizes (so future arrivals can fill it exactly), using a
smooth kernel over the recency-decayed histogram, falling back toward a mild
preference for residuals near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Cached array of item sizes seen recently (weighted by recency via decay)
_seen = np.zeros(101, dtype=np.float64)

_VALS = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Smooth "reuse" signal: for each residual value r, sum over seen sizes s of
    # seen_count[s] * exp(-(r-s)^2 / (2*sigma^2)).  This is large when r is close
    # to frequently seen item sizes, giving a graded version of the exact-match bonus.
    sigma = 2.0
    if _seen.sum() > 0.0:
        diff = _VALS[:, None] - _VALS[None, :]  # (101, 101)
        kern = np.exp(-(diff * diff) / (2.0 * sigma * sigma))
        reuse = kern @ _seen  # shape (101,)
    else:
        reuse = -np.abs(_VALS - mean_item)

    # Score: higher reuse is better; exact fills dominant.
    score = reuse[residual.astype(np.int64)]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
