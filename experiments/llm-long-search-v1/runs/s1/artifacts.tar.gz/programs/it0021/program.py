# EVOLVE-BLOCK-START
"""Best fit with a bonus for residuals that match common upcoming item sizes."""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing item
    score = -residual.astype(np.float64)
    # Reward residuals equal to a common item size (likely to be refilled exactly soon).
    # The distribution is Weibull-shaped, mean ~40; small-to-mid sizes are frequent.
    common = np.array([10, 15, 20, 25, 30, 35, 40, 45, 50, 60], dtype=np.float64)
    # bonus = closeness of residual to nearest common size, small weight
    dist = np.min(np.abs(residual[:, None] - common[None, :]), axis=1)
    score += 0.5 * np.exp(-dist / 3.0)
    # Strong reward for perfect fill (residual 0)
    score += 2.0 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
