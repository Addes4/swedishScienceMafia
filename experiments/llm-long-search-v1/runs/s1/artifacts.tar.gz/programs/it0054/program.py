# EVOLVE-BLOCK-START
"""Online distribution-aware best fit.

Maintain an empirical histogram of item sizes seen so far. For each candidate
bin, estimate the value of the resulting residual r = bins - item as the
expected amount of capacity we can still fill using future items drawn from the
observed distribution. Pick the bin whose residual has the highest expected
fill (ties broken toward tighter fits). This reduces to best fit but adapts to
the actual item distribution, choosing residuals that are more reusable.
"""
import numpy as np

# Size values 1..100 -> index 0..99. Kept module-level so it persists.
_HIST = np.zeros(100, dtype=np.float64)
_TOTAL = 0.0
# Precomputed size vector for vectorized expectation computations.
_SIZES = np.arange(1, 101, dtype=np.float64)


def _value_of_residual(r):
    """Estimate expected fill of a single residual capacity r (0..100) using
    the empirical item-size distribution. Expected number of items that fit."""
    if r <= 0:
        return 0.0
    # probability an arriving item fits in r
    p = float(_HIST[:int(r)].sum()) / _TOTAL if _TOTAL > 0 else 0.0
    # rough expected items that fit (geometric-ish proxy): p / (1 - p) is too big;
    # use p scaled by average usable fraction.
    mean_size = float((_HIST * _SIZES).sum()) / _TOTAL if _TOTAL > 0 else 40.0
    return p * (r / max(mean_size, 1.0))


def priority(item, bins):
    """Return a priority per bin; item goes to the highest-scoring bin."""
    global _TOTAL

    residual = bins - item  # >= 0 for all bins shown

    if _TOTAL < 50:
        # Not enough data yet: pure best fit with exact-fit preference.
        score = -residual.astype(np.float64)
        score += np.where(residual == 0, 1000.0, 0.0)
    else:
        # For each unique residual value, compute its expected future fill.
        uniq, inv = np.unique(residual, return_inverse=True)
        # cumulative probability that item size <= r
        cdf = np.cumsum(_HIST) / _TOTAL  # length 100, cdf[r-1] = P(size <= r)
        mean_size = float((_HIST * _SIZES).sum()) / _TOTAL
        mean_size = max(mean_size, 1.0)

        vals = np.zeros(uniq.shape[0], dtype=np.float64)
        for i, r in enumerate(uniq):
            if r <= 0:
                vals[i] = 0.0
                continue
            ri = int(r)
            if ri > 100:
                ri = 100
            p = float(cdf[ri - 1])
            vals[i] = p * (float(r) / mean_size)

        score = vals[inv]
        # Strong preference for exact fills and for tight fits as a tiebreak.
        score = score * 100.0
        score += np.where(residual == 0, 10000.0, 0.0)
        score -= residual.astype(np.float64) * 1e-3

    # Update histogram with the current item.
    _HIST[item - 1] += 1.0
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END
