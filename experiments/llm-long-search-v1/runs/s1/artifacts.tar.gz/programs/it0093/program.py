# EVOLVE-BLOCK-START
"""Strict best fit with dominant exact-fit bonus.

Empirically the strongest simple rule: prefer the smallest nonzero residual,
with an overwhelming bonus for exact fills. No additional shaping.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Dominant: best fit — smallest residual first.
    score = -res
    # Overwhelming preference for exact fills.
    score += np.where(residual == 0, 10000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
