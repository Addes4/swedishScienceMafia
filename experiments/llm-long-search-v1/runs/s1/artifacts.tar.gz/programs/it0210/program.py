# EVOLVE-BLOCK-START
"""Best fit with a reusable-residual objective (smoothed).

Exact fills dominate. Otherwise prefer residuals that have recently been
observed as item sizes (so they can be filled exactly soon), resolving ties
toward the smallest residual (mild best-fit tendency).
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)

# Precompute the nearest-seen-size distance table lazily and refresh it
# periodically, since it changes slowly.
_dist = None
_last_count = -1.0


def priority(item, bins):
    global _hist, _count, _sum, _seen, _dist, _last_count
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.995
    _seen[item] += 1.0

    res = (bins - item).astype(np.float64)
    ri = (bins - item).astype(np.int64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Refresh the nearest-seen-distance table every 25 arrivals.
    if _dist is None or _count - _last_count >= 25.0:
        idx = np.nonzero(_seen > 0.0)[0]
        vals = np.arange(101, dtype=np.float64)
        if idx.size > 0:
            d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
            nearest = d.min(axis=1)
        else:
            nearest = np.abs(vals - mean_item)
        _dist = nearest
        _last_count = _count

    # Primary: closeness to a recently seen size (reusable residual).
    score = -_dist[ri]

    # Secondary: recency-weighted mass exactly at this residual value.
    score += 0.001 * _seen[ri]

    # Fallback preference toward the running mean.
    score += -0.05 * np.abs(res - mean_item)

    # Mild best-fit tie-break: smaller residual slightly preferred.
    score += -0.0005 * res

    # Strong exact-fill dominance.
    score += np.where(ri == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
