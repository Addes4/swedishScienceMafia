# EVOLVE-BLOCK-START
"""Best-fit with exact-fit preference and a mild worst-fit (large-residual) bias.

Pure best-fit wastes space by producing many tiny, unusable leftovers. Adding a
small bonus proportional to the residual keeps slack available for reuse, while
exact fits are still strongly preferred.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Dominant: prefer tight fits (best-fit).
    score = -res
    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)
    # Mild worst-fit bias: favor bins whose leftover is larger and more reusable.
    score += res * 0.05

    return score
# EVOLVE-BLOCK-END
