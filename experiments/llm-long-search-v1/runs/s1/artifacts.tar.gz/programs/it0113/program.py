# EVOLVE-BLOCK-START
"""Best fit with empirical residual-reuse shaping.

Core: maximize exact fills and minimize residual. On top, reward leaving a
residual whose value is itself a likely future item size, since such leftovers
can later be exactly consumed. The reuse weight is a normalized probability from
the running item-size histogram, so it adapts to the distribution over the run.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist, _count
    # Update histogram of seen item sizes.
    _hist[item] += 1.0
    _count += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    # Base: prefer tight fits (minimize resulting residual).
    score = -res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Reuse bonus: probability that a future item exactly matches the residual,
    # derived from the empirical histogram (normalized). This favors leftovers
    # that are themselves common item sizes and therefore likely to be filled.
    if _count > 0:
        prob = _hist / _count
    else:
        prob = np.zeros(101, dtype=np.float64)

    # Gather the match-probability for each candidate residual (0..100).
    reuse = prob[np.clip(residual, 0, 100)]
    score += 20.0 * reuse

    return score
# EVOLVE-BLOCK-END

