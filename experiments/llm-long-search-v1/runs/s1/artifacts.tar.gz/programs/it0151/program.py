# EVOLVE-BLOCK-START
"""Best-fit variant with a stationary-distribution "residual value" objective.

We maintain a running histogram of item sizes. For each possible residual r we
estimate how valuable it is to leave that residual in a bin, using the idea that
a residual is good if a single upcoming item can exactly fill it (prob P(r)),
and additionally if it can be combined with one more item to fill exactly, we
get a small bonus. Exact fills are strongly preferred.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def _build_value():
    """Return array V[0..100]: value of leaving residual r in a bin."""
    if _count <= 0:
        return np.zeros(101, dtype=np.float64)
    # Smoothed probability of an item of size k.
    p = (_hist + 1.0) / (_hist.sum() + 101.0)
    # V1[r]: prob that an upcoming item exactly completes residual r.
    V1 = p.copy()
    # V2[r]: prob that the residual r can be split by some item then remainder
    # by another item later; approximate by convolution of p with itself at r.
    conv = np.convolve(p, p)  # length 201, index s = a+b
    V2 = np.zeros(101, dtype=np.float64)
    V2[:min(101, conv.size)] = conv[:min(101, conv.size)]
    # Residuals larger than the max observed item cannot be exactly completed.
    max_item = int(np.nonzero(_hist)[0].max()) if _hist.any() else 100
    V = V1 + 0.3 * V2
    # Penalize unreachable residuals somewhat.
    if max_item < 100:
        V[max_item + 1:] *= 0.5
    return V


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.int64)

    V = _build_value()
    score = V[res].astype(np.float64)

    # Strongly prefer exact fills.
    score += np.where(res == 0, 1000.0, 0.0)

    # Mild tie-breaker toward smaller residuals (best-fit behavior).
    score += -0.001 * res.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
