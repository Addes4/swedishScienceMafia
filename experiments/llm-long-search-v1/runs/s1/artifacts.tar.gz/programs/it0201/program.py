# EVOLVE-BLOCK-START
"""Best fit with a smooth "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
closely matches a recently-seen item size (so upcoming arrivals can fill it),
with a small Best-Fit tie-break preferring the smallest usable residual.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)

# Precompute distance of each residual value 0..100 to each possible size index.
_vals = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    mean_item = _sum / _count if _count > 0 else 40.0

    idx = np.nonzero(_seen > 0.0)[0]
    if idx.size > 0:
        d = np.abs(_vals[:, None] - idx[None, :].astype(np.float64))
        nearest = d.min(axis=1)  # distance from each residual value to nearest seen size
    else:
        nearest = np.abs(_vals - mean_item)

    gap = nearest[residual.astype(np.int64)]
    # Smooth reuse bonus: strong for exact matches, decaying over a few units.
    score = -0.5 * gap * gap

    # Mild fallback preference for residuals near the running mean.
    score += -0.02 * np.abs(res - mean_item)

    # Tiny Best-Fit tie-break: prefer the smallest usable residual.
    score += -0.001 * res

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
