# EVOLVE-BLOCK-START
"""Best fit with a stationary "exact-completion probability" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual r that
is likely to be exactly completed by some future item, estimated from the
running item-size histogram (smoothed). A tiny best-fit term breaks ties toward
tighter packing.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0

# Precomputed smoothed exact-completion probability per residual value.
_prob = np.zeros(101, dtype=np.float64)
_dirty = True


def _rebuild():
    global _prob, _dirty
    if _count <= 0.0:
        _prob = np.zeros(101, dtype=np.float64)
        _dirty = False
        return
    h = _hist.copy()
    # Light smoothing so nearby residual sizes share credit (avoids overfitting
    # to the exact integer histogram and helps generalize).
    kern = np.array([1.0, 2.0, 3.0, 2.0, 1.0], dtype=np.float64)
    kern /= kern.sum()
    # Convolve along size axis (only sizes 1..100 matter; residual 0 means exact fill).
    sm = np.convolve(h, kern, mode="same")
    total = sm.sum()
    if total <= 0.0:
        _prob = np.zeros(101, dtype=np.float64)
    else:
        p = sm / total
        # Higher residual values are rarer as item sizes; keep as-is.
        _prob = p
        _prob[0] = 0.0  # residual 0 handled separately by exact-fill bonus
    _dirty = False


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _dirty
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    # Rebuild probability table periodically (cheap) rather than every call.
    if _dirty or (_count % 25.0) == 0.0:
        _rebuild()

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    mean_item = _sum / _count if _count > 0 else 40.0

    # Dominant exact-fill preference.
    score = np.where(residual == 0, 1000.0, 0.0)

    # Stationary exact-completion probability of leaving this residual.
    score += 5.0 * _prob[residual.astype(np.int64)]

    # Mild fallback: prefer residuals near the running mean item size.
    score += -0.05 * np.abs(res - mean_item)

    # Tiny best-fit tie-breaker: prefer smaller positive residual, but never
    # override exact fills or strong completion-probability differences.
    score += np.where(residual > 0, -0.001 * res, 0.0)

    return score
# EVOLVE-BLOCK-END

