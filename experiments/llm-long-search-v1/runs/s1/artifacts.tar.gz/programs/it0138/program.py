# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective, mass-weighted.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size, with the match weighted by how much recency
mass that size carries (common sizes are more likely to recur and fill it).
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Recency-weighted presence: mass of each item size seen recently.
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    # Recency-weighted presence: decay all, then boost this item.
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    seen_present = _seen > 0.0
    idx = np.nonzero(seen_present)[0]
    if idx.size > 0:
        vals = np.arange(101, dtype=np.float64)
        d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
        nearest = d.min(axis=1)  # shape (101,)
    else:
        nearest = np.abs(np.arange(101, dtype=np.float64) - mean_item)

    # Score: closer to a reusable residual is better; exact fills dominant.
    score = -nearest[residual.astype(np.int64)]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Small bonus for residuals whose nearest seen size carries recency mass.
    seen_mass = _seen / (np.max(_seen) + 1e-12)
    score += 0.5 * seen_mass[residual.astype(np.int64)]

    return score
# EVOLVE-BLOCK-END

