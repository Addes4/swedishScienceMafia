# EVOLVE-BLOCK-START
"""Distribution-aware best fit with one-step expected-waste lookahead.

For each candidate bin we compute the resulting residual r.  Using the empirical
CDF of item sizes seen so far, we estimate how much of r is likely to be left
over after the next item that fits is placed into it.  Bins whose residual has
low expected waste (i.e. likely to be consumed cleanly) are preferred.  Exact
fills dominate, and best fit breaks the rest.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_cdf = None


def _update_stats(item):
    global _hist, _count, _cdf
    _hist[item] += 1.0
    _count += 1.0
    _cdf = np.cumsum(_hist) / _count


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _update_stats(item)

    residual = bins - item            # >= 0
    res = residual.astype(np.float64)

    # Base: best fit (tightest fit first).
    score = -res
    # Dominant: exact fills.
    score += np.where(residual == 0, 1.0e6, 0.0)

    if _cdf is not None:
        # Expected waste of residual r for the *next* item placed in the same bin:
        # E[max(0, r - X) | X <= r] weighted appropriately, using empirical dist.
        # We approximate by summing over possible future item sizes x <= r:
        #   waste(x) = r - x     (what's left after placing x)
        # and also account for the probability of no item fitting (x > r), in which
        # case the whole residual is eventually wasted at that step.  Smaller
        # expected waste is better.
        rmax = float(residual.max()) if residual.size else 0.0
        # Build a vector of item-size probabilities 1..100 (size 100).
        probs = _hist[1:101] / _count
        sizes = np.arange(1, 101, dtype=np.float64)

        # For each candidate residual (vectorized), compute expected waste.
        # expected_waste(r) = sum_{x<=r} p_x * (r - x)  +  P(X>r) * r_weight
        # where P(X>r) = 1 - CDF(r).  Using full residual as fallback waste keeps
        # the scale comparable.
        res_col = res.reshape(-1, 1)      # (B,1)
        size_row = sizes.reshape(1, -1)   # (1,100)
        fits = (size_row <= res_col)      # (B,100)
        # Waste when x fits: r - x
        waste_fit = (res_col - size_row) * fits
        exp_waste = waste_fit @ probs     # (B,)
        # Probability no item fits: those items simply can't reuse this bin now.
        # Penalize bins whose residual is below the smallest plausible item, since
        # they are likely pure waste.
        cdf_at_r = _cdf[np.clip(residual, 0, 100).astype(np.int64)]
        p_no_fit = 1.0 - cdf_at_r
        # Weight the "unusable fraction" of the residual.
        exp_waste = exp_waste + p_no_fit * res

        # Prefer low expected waste.
        score -= 0.5 * exp_waste

    return score
# EVOLVE-BLOCK-END
