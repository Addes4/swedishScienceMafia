# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective, blended with histogram mass.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a recently-seen item size (so the next few arrivals can fill it exactly),
further reinforced by how common that residual size is in the full running
histogram, with a mild fallback toward the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item
    res = residual.astype(np.float64)
    residual_i = residual.astype(np.int64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Distance to nearest recently-seen size (0 if residual is an observed size).
    seen_present = _seen > 0.0
    idx = np.nonzero(seen_present)[0]
    if idx.size > 0:
        vals = np.arange(101, dtype=np.float64)
        d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
        nearest = d.min(axis=1)
    else:
        nearest = np.abs(np.arange(101, dtype=np.float64) - mean_item)

    # Normalized histogram mass (full history), stable and low-noise.
    if _count > 0:
        mass = _hist / _count
    else:
        mass = np.zeros(101, dtype=np.float64)
    # Smooth the mass slightly so neighboring residuals share a bit of credit.
    smooth = np.convolve(mass, np.array([0.25, 0.5, 0.25]), mode="same")

    # Primary: closeness to a reusable residual.
    score = -nearest[residual_i]
    # Reinforce with how commonly this residual completes via a future item.
    score += 3.0 * smooth[residual_i]

    # Mild fallback preference for residuals near the running mean.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
