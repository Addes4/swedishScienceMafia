# EVOLVE-BLOCK-START
"""Best-fit with a residual-reuse tie-break.

Exact fills are dominant. Otherwise prefer the smallest residual (classic
best-fit), with a small bonus when the residual equals a recently-seen item
size so it can be filled exactly by an upcoming arrival. A tiny fallback term
pulls residuals toward the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
_seen = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _seen
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _seen *= 0.999
    _seen[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Primary: best-fit (prefer smallest residual).
    score = -res

    # Bonus when residual matches a recently-seen item size (reusable).
    seen_present = _seen > 0.0
    idx = np.nonzero(seen_present)[0]
    if idx.size > 0:
        # nearest-seen distance for residual values 0..100
        vals = np.arange(101, dtype=np.float64)
        d = np.abs(vals[:, None] - idx[None, :].astype(np.float64))
        nearest = d.min(axis=1)
    else:
        nearest = np.abs(np.arange(101, dtype=np.float64) - mean_item)

    score += -0.5 * nearest[residual.astype(np.int64)]

    # Mild fallback toward residuals near the running mean.
    score += -0.02 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
