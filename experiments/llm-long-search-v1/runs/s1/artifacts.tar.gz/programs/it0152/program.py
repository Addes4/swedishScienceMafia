# EVOLVE-BLOCK-START
"""Best fit with a stable, distribution-aware residual-reuse bonus.

Prefer filling bins to leave a residual equal to a common upcoming item size
(so it can be exactly completed soon), with a fallback that mildly prefers
smaller residuals (classic best fit). Uses the full running histogram for
stability rather than a noisy recency set.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown (item fits)
    res = residual.astype(np.float64)

    if _count > 1.0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    # Smoothed probability that an upcoming item exactly equals residual value r.
    # Build a smoothed histogram over possible residuals 0..100.
    total = _hist.sum()
    if total > 0.0:
        prob = _hist / total
    else:
        prob = _hist

    # Smoothed: mix histogram mass with a small uniform floor and a Gaussian kernel.
    vals = np.arange(101, dtype=np.float64)
    # kernel smoothing of the histogram mass
    kernel = np.exp(-0.5 * ((vals[:, None] - vals[None, :]) / 3.0) ** 2)
    kernel /= kernel.sum(axis=1, keepdims=True)
    smoothed = kernel @ prob  # shape (101,)
    # small floor and normalize so ordering is meaningful even early on
    reuse_value = smoothed + 0.001

    # Exact fill is dominant.
    score = np.where(residual == 0, 1e6, 0.0)

    # Reward leaving a residual that is a likely upcoming item (reusable).
    score += 100.0 * reuse_value[residual.astype(np.int64)]

    # Fallback: prefer smaller residuals (classic best fit), mild weight.
    score += -0.01 * res

    return score
# EVOLVE-BLOCK-END

