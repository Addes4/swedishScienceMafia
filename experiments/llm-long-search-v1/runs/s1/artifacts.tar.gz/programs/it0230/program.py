# EVOLVE-BLOCK-START
"""Best-fit with a pairing-friendly residual objective.

Exact fills dominate. Otherwise prefer residuals that are "tidy" leftovers:
either very small (keeps future large items packable) or near half the item
mean (likely to be exactly completed by a forthcoming item), while mildly
penalizing awkward medium residuals. All signals are simple functions of the
residual, avoiding discrete-tie collapse from nearest-seen tables.
"""
import numpy as np

_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _count, _sum
    _count += 1.0
    _sum += item

    residual = bins - item
    res = residual.astype(np.float64)

    mean_item = _sum / _count if _count > 0 else 40.0

    # Prefer small leftover (best-fit) so large future items still fit.
    score = -res

    # Reward residuals close to half the mean item: such a leftover is likely
    # to be exactly completed by a single forthcoming item.
    half = 0.5 * mean_item
    score += -0.3 * np.abs(res - half)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

