# EVOLVE-BLOCK-START
"""Best fit with a smooth, recency-weighted "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual r that
is either likely to be filled exactly by the next item (mass at r in the item
histogram) or is itself a size that appears often (so a later item can pair with
it), falling back to a best-fit tie-break toward the smallest residual.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)       # recency-weighted item histogram
_count = 0.0
_sum = 0.0
_mean = 40.0
_res_scores = np.zeros(101, dtype=np.float64)  # score per possible residual value

# Decay factor for the recency-weighted histogram.
_DECAY = 0.9985


def _rebuild():
    """Rebuild the per-residual score table from the current histogram."""
    global _res_scores
    h = _hist
    tot = h.sum()
    if tot <= 0.0:
        # No information yet: default to best-fit (small residual preferred).
        _res_scores[:] = -np.arange(101, dtype=np.float64)
        return

    p = h / tot  # smoothed probability of an item of each size

    # Pairing signal: for residual r, the probability that a future item of size
    # r (or 100-r) appears, letting the leftover be reused/matched soon. Combine
    # the "next item fills r exactly" mass (p[r]) with the "item equals 100-r"
    # mass that would create a fresh, matchable partial bin.
    vals = np.arange(101, dtype=np.float64)
    mass_at_r = p
    complement = p[100 - np.arange(101, dtype=np.int64)]  # p[100-r]
    coupling = mass_at_r + 0.5 * complement

    # Best-fit tie-break: mildly prefer the smallest residual (densest packing).
    bf = -0.02 * vals

    _res_scores = coupling + bf


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _mean, _res_scores
    _hist *= _DECAY
    _hist[item] += 1.0
    _count += 1.0
    _sum += item
    _mean = _sum / _count
    _rebuild()

    residual = bins - item  # >= 0 for all bins shown

    score = _res_scores[residual]

    # Strongly prefer exact fills.
    score = score + np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
