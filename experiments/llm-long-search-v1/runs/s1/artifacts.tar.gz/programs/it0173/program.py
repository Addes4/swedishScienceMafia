# EVOLVE-BLOCK-START
"""Best fit with a stable "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a common item size from the running histogram (so a future arrival can
fill it exactly), falling back toward a mild preference for a tight fit.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_sum = 0.0
# Cached "value potential": larger means residual is a more reusable leftover.
_potential = None
_potential_valid = False
_vals = np.arange(101, dtype=np.float64)


def _rebuild_potential():
    """Distance-to-nearest-common-size from the running histogram, cached once."""
    global _potential, _potential_valid
    # Smooth the histogram so it stays well-defined from the first item.
    h = _hist + 0.05
    total = h.sum()
    p = h / total
    mean_item = (_sum / _count) if _count > 0 else 40.0

    # Weight each size by its probability mass in the running distribution.
    # distance from every residual r (0..100) to every size s (0..100)
    d = np.abs(_vals[:, None] - _vals[None, :])  # (101,101)
    # For each residual, take the probability-weighted distance to sizes.
    weighted = (d * p[None, :]).sum(axis=1)  # (101,)
    # Score: lower weighted distance is better (closer to common sizes).
    _potential = -weighted
    # Mild fallback preference toward the running mean.
    _potential += -0.02 * np.abs(_vals - mean_item)
    # Exact fill handled separately (dominant bonus).
    _potential_valid = True


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum, _potential_valid
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    # Rebuild the potential infrequently to keep it stable and cheap.
    if not _potential_valid or (_count % 50 == 0):
        _rebuild_potential()
        _potential_valid = True

    residual = (bins - item).astype(np.int64)
    res = residual.astype(np.float64)

    score = _potential[residual]

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Gentle best-fit tie-break: prefer the tightest residual.
    score += -0.001 * res

    return score
# EVOLVE-BLOCK-END
