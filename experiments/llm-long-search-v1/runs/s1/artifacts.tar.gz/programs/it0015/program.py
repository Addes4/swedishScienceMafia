# EVOLVE-BLOCK-START
"""Best-fit with a gentle residual-quality bonus."""
import numpy as np


def priority(item, bins):
    """Rank bins: primarily tightest fit, with a mild bonus for useful residuals."""
    residual = bins - item
    # Prefer tightest fit determinedly; add a small term rewarding mid-size leftovers.
    # For residuals that are tiny slivers (unlikely to be filled), penalize slightly.
    # For residuals around a typical future item (~40), give a small bonus.
    # Scale kept small so best-fit ordering dominates.
    target = 40.0
    # bonus peaks near target and decreases away from it
    bonus = -np.abs(residual - target)
    return -residual + 0.001 * bonus
# EVOLVE-BLOCK-END
