# EVOLVE-BLOCK-START
"""Best fit with a smooth "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
is likely to be filled exactly by a future item, estimated from a recency-
weighted histogram of seen item sizes, with a mild best-fit fallback.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)      # recency-decayed item histogram
_count = 0.0
_sum = 0.0

_DECAY = 0.999


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist *= _DECAY
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item            # >= 0 for all bins shown
    res = residual.astype(np.float64)

    if _count > 0.0:
        mean_item = _sum / _count
    else:
        mean_item = 40.0

    total = _hist.sum()
    if total > 0.0:
        h = _hist / total
    else:
        h = np.zeros(101, dtype=np.float64)

    # Smooth reuse payoff: how often future items would exactly match residual r.
    reuse = h[residual.astype(np.int64)]

    score = 3.0 * reuse

    # Mild best-fit fallback: prefer residuals near the running mean item size.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

