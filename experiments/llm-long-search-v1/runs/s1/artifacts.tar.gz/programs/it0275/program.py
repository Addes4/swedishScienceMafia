# EVOLVE-BLOCK-START
"""Best fit with a "reusable residual" objective.

Exact fills are strongly preferred. Otherwise, prefer leaving a residual that
matches a frequently-seen item size (weighted by its decayed frequency), so the
next arrivals can fill it exactly. Fall back to a mild preference for residuals
near the running mean.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)   # decayed frequency of item sizes
_count = 0.0
_sum = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count, _sum
    _hist *= 0.999
    _hist[item] += 1.0
    _count += 1.0
    _sum += item

    residual = bins - item  # >= 0 for all bins shown
    res = residual.astype(np.float64)

    mean_item = _sum / _count if _count > 0 else 40.0

    # Weighted frequency table over residual values 0..100: residual r gets the
    # decayed frequency of item size r (how likely a future item equals r).
    w = _hist.copy()
    tot = w.sum()
    if tot > 0:
        w = w / tot
    else:
        w = np.zeros(101, dtype=np.float64)

    # Score: prefer residuals whose value is a frequently-seen item size.
    score = w[residual.astype(np.int64)]

    # Mild preference for residuals near the running mean as a fallback.
    score += -0.05 * np.abs(res - mean_item)

    # Strongly prefer exact fills.
    score += np.where(residual == 0, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END
