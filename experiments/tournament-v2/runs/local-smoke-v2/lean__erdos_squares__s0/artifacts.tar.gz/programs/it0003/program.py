# EVOLVE-BLOCK-START
"""Grid packing plus a partial extra row/column fit into the leftover strip."""
import math


def _grid_plus_strip(n):
    """Return list of (cx, cy, angle, side) placing a k*k grid and leftover squares
    in the leftover strip along one side."""
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    base = 1.0 / k
    squares = []
    # main k x k grid occupying [0, base*k] x [0, base*k] = unit square
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * base, (j + 0.5) * base, 0.0, base))

    r = n - k * k
    if r == 0:
        return squares

    # Try column layout: extra column of width w on the right, holding r squares.
    # Grid shrinks to width (1-w) so cells become (1-w)/k wide.
    # Column squares stacked vertically, each of height at most 1/r.
    # Choose w to maximize r * min(cell_side, 1/r) subject to 1-w >= w.
    # In column: squares side = min(w, 1/r).
    # In grid: side = min((1-w)/k, 1/k). Keep grid squares.
    # Balance: w = 1/(r+1) roughly gives column side = w if w<=1/r.
    w_col = 1.0 / (r + 1.0)
    col_side = min(w_col, 1.0 / r)
    grid_side_col = min((1.0 - w_col) / k, 1.0 / k)

    # Row layout: extra row of height h at the top holding r squares side by side.
    h_row = 1.0 / (r + 1.0)
    row_side = min(h_row, 1.0 / r)
    grid_side_row = min((1.0 - h_row) / k, 1.0 / k)

    # Also try sharing the strip: both grid and strip at base size base.
    # If (k+1)*base <= 1 then we can put a full extra column of size base.
    total_col = 0.0
    total_row = 0.0

    # Column variant
    squares_c = []
    for i in range(k):
        for j in range(k):
            gx = grid_side_col
            squares_c.append(((i + 0.5) * gx, (j + 0.5) * gx, 0.0, gx))
    for t in range(r):
        cy = (t + 0.5) * (1.0 / r)
        cx = (1.0 - w_col) + 0.5 * w_col
        squares_c.append((cx, cy, 0.0, col_side))
    total_col = k * k * grid_side_col + r * col_side

    # Row variant
    squares_r = []
    for i in range(k):
        for j in range(k):
            gy = grid_side_row
            squares_r.append(((i + 0.5) * gy, (j + 0.5) * gy, 0.0, gy))
    for t in range(r):
        cx = (t + 0.5) * (1.0 / r)
        cy = (1.0 - h_row) + 0.5 * h_row
        squares_r.append((cx, cy, 0.0, row_side))
    total_row = k * k * grid_side_row + r * row_side

    # Special case: n = k*k + r fits as (k)*(k+1) rectangle with leftover in a row.
    # If n <= k*(k+1): split into k+1 columns and ceil(n/(k+1)) rows.
    kk = k * (k + 1)
    if n <= kk:
        cols = k + 1
        rows = (n + cols - 1) // cols
        cellw = 1.0 / cols
        cellh = 1.0 / rows
        s = min(cellw, cellh)
        squares_rect = []
        cnt = 0
        for i in range(cols):
            for j in range(rows):
                if cnt < n:
                    squares_rect.append(((i + 0.5) * cellw, (j + 0.5) * cellh, 0.0, s))
                    cnt += 1
        total_rect = n * s
    else:
        total_rect = -1.0
        squares_rect = None

    best = squares
    best_total = k * k * base
    for total, sq in ((total_col, squares_c), (total_row, squares_r),
                      (total_rect, squares_rect)):
        if sq is not None and total > best_total:
            best_total = total
            best = sq
    return best


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    squares = _grid_plus_strip(n)
    # Clamp to be safe
    out = []
    for cx, cy, a, s in squares[:n]:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, a, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
# EVOLVE-BLOCK-END

