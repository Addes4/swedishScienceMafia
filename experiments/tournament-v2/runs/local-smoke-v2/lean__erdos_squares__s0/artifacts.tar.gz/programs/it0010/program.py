# EVOLVE-BLOCK-START
"""Grid packing plus leftover squares fit into the remaining strip using a
search over several candidate strip layouts, including rotated leftover
squares, refined by a scipy local optimizer for small leftover counts."""
import math


def _grid_squares(k, side, ox=0.0, oy=0.0):
    out = []
    for i in range(k):
        for j in range(k):
            out.append((ox + (i + 0.5) * side, oy + (j + 0.5) * side, 0.0, side))
    return out


def _sq_corners(cx, cy, a, s):
    h = s / 2.0
    ca = math.cos(a * 2 * math.pi)
    sa = math.sin(a * 2 * math.pi)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _overlap(p1, p2):
    """Separating axis test between two convex polygons."""
    for poly in (p1, p2):
        for i in range(len(poly)):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % len(poly)]
            ex, ey = x2 - x1, y2 - y1
            nx, ny = -ey, ex
            mn1 = mx1 = p1[0][0] * nx + p1[0][1] * ny
            for x, y in p1:
                d = x * nx + y * ny
                mn1 = min(mn1, d)
                mx1 = max(mx1, d)
            mn2 = mx2 = p2[0][0] * nx + p2[0][1] * ny
            for x, y in p2:
                d = x * nx + y * ny
                mn2 = min(mn2, d)
                mx2 = max(mx2, d)
            if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
                return False
    return True


def _valid_full(squares):
    polys = []
    for cx, cy, a, s in squares:
        if not (0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0 and 0.0 <= a <= 1.0):
            return False
        if s < 0 or s > 1:
            return False
        if s == 0:
            polys.append(None)
            continue
        pts = _sq_corners(cx, cy, a, s)
        for x, y in pts:
            if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
                return False
        polys.append(pts)
    for i in range(len(polys)):
        if polys[i] is None:
            continue
        for j in range(i + 1, len(polys)):
            if polys[j] is None:
                continue
            if _overlap(polys[i], polys[j]):
                return False
    return True


def _optimize_strip(k, r, seed, time_budget=2.0):
    """Jointly tune strip width w and the r leftover squares in the strip
    [1-w, 1] x [0,1]. The k x k grid occupies [0,1-w] x [0,1]. Leftover
    square i has params (across in [0,1] * w, along in [0,1], angle, side)."""
    try:
        import numpy as np
        from scipy.optimize import minimize
    except Exception:
        return None

    # initial: grid side base, strip width from seed
    # seed is a list of (cx, cy, a, s) for the leftover squares and w
    w0 = seed["w"]
    init_leaves = seed["leaves"]  # list of (across_frac, along_frac, angle, side)

    def unpack(x):
        w = x[0]
        leaves = []
        for i in range(r):
            base = 1 + i * 4
            af = x[base]
            al = x[base + 1]
            a = x[base + 2]
            s = x[base + 3]
            leaves.append((w, af, al, a, s))
        return w, leaves

    def build(x):
        w, leaves = unpack(x)
        w = max(0.0, min(1.0, w))
        grid_side = min((1.0 - w) / k, 1.0 / k)
        if grid_side < 0:
            grid_side = 0.0
        sq = _grid_squares(k, grid_side)
        for (w, af, al, a, s) in leaves:
            s = max(0.0, min(1.0, s))
            cx = (1.0 - w) + af * w
            cy = al
            sq.append((cx, cy, a, s))
        return sq

    def neg_total(x):
        w, leaves = unpack(x)
        w = max(0.0, min(1.0, w))
        grid_side = (1.0 - w) / k
        total = k * k * grid_side
        for (_, _, _, _, s) in leaves:
            total += max(0.0, s)
        return -total

    def constraint_penalty(x):
        w, leaves = unpack(x)
        w = max(0.0, min(1.0, w))
        sq = build(x)
        # penalty for out of bounds of leftover squares
        pen = 0.0
        for (cw, af, al, a, s) in leaves:
            if s <= 0:
                continue
            pts = _sq_corners((1.0 - cw) + af * cw, al, a, s)  # placeholder
        return 0.0

    def objective(x):
        # penalty method
        w, leaves = unpack(x)
        sq = build(x)
        pen = 0.0
        # bound penalties
        wc = max(0.0, min(1.0, x[0]))
        pen += (x[0] - wc) ** 2
        for i in range(r):
            base = 1 + i * 4
            af = x[base]
            al = x[base + 1]
            a = x[base + 2]
            s = max(0.0, x[base + 3])
            pen += 1e3 * max(0.0, af - 1.0) ** 2 + 1e3 * max(0.0, -af) ** 2
            pen += 1e3 * max(0.0, al - 1.0) ** 2 + 1e3 * max(0.0, -al) ** 2
            pen += 1e3 * max(0.0, s - 1.0) ** 2 + 1e3 * max(0.0, -x[base + 3]) ** 2
        # leftover squares must lie inside strip [1-w,1]x[0,1]
        for (cw, af, al, a, s) in leaves:
            if s <= 0:
                continue
            cx = (1.0 - cw) + af * cw
            cy = al
            pts = _sq_corners(cx, cy, a, s)
            for xp, yp in pts:
                pen += 1e3 * max(0.0, xp - 1.0) ** 2
                pen += 1e3 * max(0.0, -xp) ** 2
                pen += 1e3 * max(0.0, yp - 1.0) ** 2
                pen += 1e3 * max(0.0, -yp) ** 2
        # leftover squares must not collide with grid or each other
        # build polys for leftover
        lpolys = []
        for (cw, af, al, a, s) in leaves:
            if s <= 0:
                lpolys.append(None)
                continue
            cx = (1.0 - cw) + af * cw
            cy = al
            lpolys.append(_sq_corners(cx, cy, a, s))
        for i in range(r):
            for j in range(i + 1, r):
                if lpolys[i] is None or lpolys[j] is None:
                    continue
                if _overlap(lpolys[i], lpolys[j]):
                    pen += 1e2
        grid_side = max(0.0, (1.0 - wc) / k)
        # grid occupies [0,1-w]x[0,1]; check against leftover
        grid_poly = [(0.0, 0.0), (1.0 - wc, 0.0), (1.0 - wc, 1.0), (0.0, 1.0)]
        # actually use individual grid cells
        for i in range(k):
            for j in range(k):
                gx = (i + 0.5) * grid_side
                gy = (j + 0.5) * grid_side
                gpol = _sq_corners(gx, gy, 0.0, grid_side)
                for lp in lpolys:
                    if lp is None:
                        continue
                    if _overlap(gpol, lp):
                        pen += 1e2
        total = k * k * grid_side
        for (_, _, _, _, s) in leaves:
            total += max(0.0, s)
        return -total + pen

    # initial vector
    x0 = [w0]
    for (af, al, a, s) in init_leaves:
        x0.extend([af, al, a, s])
    x0 = np.array(x0, dtype=float)

    try:
        res = minimize(objective, x0, method="Nelder-Mead",
                       options={"maxiter": 4000, "xatol": 1e-4,
                                "fatol": 1e-6, "adaptive": True})
        xb = res.x
    except Exception:
        return None

    # refine with Powell
    try:
        res2 = minimize(objective, xb, method="Powell",
                        options={"maxiter": 2000, "xtol": 1e-5, "ftol": 1e-7})
        if res2.fun < res.fun:
            xb = res2.x
    except Exception:
        pass

    # check validity of resulting construction
    w, leaves = unpack(xb)
    w = max(0.0, min(1.0, w))
    sq = build(xb)
    if not _valid_full(sq):
        return None
    return sq


def _seed_from_squares(sq, total, best):
    if total > best["total"] and _valid_full(sq):
        best["total"] = total
        best["sq"] = sq
    return best


def _pack_leftover(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    base = 1.0 / k
    squares = _grid_squares(k, base)
    r = n - k * k
    if r == 0:
        return squares

    best = {"total": k * k * base, "sq": squares}

    # 1) Column layout: grid width (1-w), extra column of r squares.
    for w_num in range(1, 60):
        w = w_num / 60.0
        if w <= 0 or w >= 1:
            continue
        grid_side = min((1.0 - w) / k, base)
        col_side = min(w, 1.0 / r)
        if col_side <= 0:
            continue
        total = k * k * grid_side + r * col_side
        if total > best["total"]:
            sq = _grid_squares(k, grid_side)
            for t in range(r):
                cy = (t + 0.5) / r
                sq.append(((1.0 - w) + 0.5 * w, cy, 0.0, col_side))
            _seed_from_squares(sq, total, best)

    # 2) Row layout.
    for h_num in range(1, 60):
        h = h_num / 60.0
        if h <= 0 or h >= 1:
            continue
        grid_side = min((1.0 - h) / k, base)
        row_side = min(h, 1.0 / r)
        if row_side <= 0:
            continue
        total = k * k * grid_side + r * row_side
        if total > best["total"]:
            sq = _grid_squares(k, grid_side)
            for t in range(r):
                cx = (t + 0.5) / r
                sq.append((cx, (1.0 - h) + 0.5 * h, 0.0, row_side))
            _seed_from_squares(sq, total, best)

    # 3) Block layout in the corner.
    for cols in range(1, r + 1):
        rows = (r + cols - 1) // cols
        for g_num in range(1, 60):
            g = g_num / 60.0
            if g <= 0 or g >= 1:
                continue
            grid_side = min(g / k, base)
            cellw = (1.0 - g) / cols
            cellh = 1.0 / rows
            cell_side = min(cellw, cellh)
            if cell_side <= 0:
                continue
            total = k * k * grid_side + r * cell_side
            if total > best["total"]:
                sq = _grid_squares(k, grid_side)
                cnt = 0
                ox = g
                for i in range(cols):
                    for j in range(rows):
                        if cnt < r:
                            sq.append((ox + (i + 0.5) * cellw,
                                       (j + 0.5) * cellh, 0.0, cell_side))
                            cnt += 1
                _seed_from_squares(sq, total, best)

    # 4) Rectangle grid (k+1) columns.
    kk = k * (k + 1)
    if n <= kk:
        cols = k + 1
        rows = (n + cols - 1) // cols
        cellw = 1.0 / cols
        cellh = 1.0 / rows
        s = min(cellw, cellh)
        sq = []
        cnt = 0
        for i in range(cols):
            for j in range(rows):
                if cnt < n:
                    sq.append(((i + 0.5) * cellw, (j + 0.5) * cellh, 0.0, s))
                    cnt += 1
        total = n * s
        _seed_from_squares(sq, total, best)

    # 5) Rotated leftover squares in the strip via scipy local search.
    if 1 <= r <= 4:
        # Try both a column-strip and a row-strip orientation as seeds.
        for orient in ("col", "row"):
            for w_num in range(4, 60):
                w = w_num / 60.0
                if orient == "col":
                    grid_side = min((1.0 - w) / k, base)
                    leaves = []
                    for t in range(r):
                        leaves.append((0.5, (t + 0.5) / r, 0.0,
                                       min(w, 1.0 / r)))
                else:
                    grid_side = min((1.0 - w) / k, base)
                    leaves = []
                    for t in range(r):
                        leaves.append(((t + 0.5) / r, 0.5, 0.0,
                                       min(w, 1.0 / r)))
                seed = {"w": w, "leaves": leaves}
                sq = _optimize_strip(k, r, seed, time_budget=1.0)
                if sq is not None:
                    total = k * k * grid_side + sum(s for (_, _, _, s) in sq[len(sq) - r:])
                    if total > best["total"]:
                        best["total"] = total
                        best["sq"] = sq

    return best["sq"]


def solve(n):
    if n <= 0:
        return []
    squares = _pack_leftover(n)
    out = []
    for cx, cy, a, s in squares[:n]:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = min(max(a, 0.0), 1.0)
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, a, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
# EVOLVE-BLOCK-END
