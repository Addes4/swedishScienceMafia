# EVOLVE-BLOCK-START
"""Packing squares in the unit square to maximise total side length.

Strategy:
  * For each n, build a set of candidate starting layouts using grid heuristics
    (k x k grid, rectangle grids, grid + leftover strip in several orientations).
  * Then run a continuous local optimizer (scipy SLSQP) on the full configuration
    of n squares parameterized by (cx, cy, angle, side), maximising sum of sides
    subject to wall constraints and pairwise non-overlap (separating axis).
  * Keep the best feasible configuration found.
"""
import math

try:
    import numpy as np
    from scipy.optimize import minimize
    _HAVE_SCIPY = True
except Exception:
    _HAVE_SCIPY = False


def _grid_squares(k, side, ox=0.0, oy=0.0):
    out = []
    for i in range(k):
        for j in range(k):
            out.append((ox + (i + 0.5) * side, oy + (j + 0.5) * side, 0.0, side))
    return out


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def _corners(cx, cy, a, s):
    """Return 4 corners of a square, angle a as a fraction of a full turn."""
    t = a * 2.0 * math.pi
    ct = math.cos(t)
    st = math.sin(t)
    h = s * 0.5
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for (x, y) in pts:
        out.append((cx + x * ct - y * st, cy + x * st + y * ct))
    return out


def _overlap_area(sq1, sq2, tol=1e-9):
    """Approximate max-dot (SAT) penetration measure; returns >0 if overlapping."""
    c1 = _corners(*sq1)
    c2 = _corners(*sq2)
    axes = []
    for c in (c1, c2):
        for i in range(4):
            x0, y0 = c[i]
            x1, y1 = c[(i + 1) % 4]
            ex, ey = x1 - x0, y1 - y0
            L = math.hypot(ex, ey)
            if L > 1e-12:
                axes.append((-ey / L, ex / L))
    best_pen = float("inf")
    for (nx, ny) in axes:
        p1 = [x * nx + y * ny for (x, y) in c1]
        p2 = [x * nx + y * ny for (x, y) in c2]
        min1, max1 = min(p1), max(p1)
        min2, max2 = min(p2), max(p2)
        pen = min(max1, max2) - max(min1, min2)
        if pen < best_pen:
            best_pen = pen
        if best_pen <= tol:
            return 0.0
    return best_pen


def _wall_violation(sq):
    """Return total amount by which the square exceeds the unit box."""
    c = _corners(*sq)
    v = 0.0
    for (x, y) in c:
        if x < 0.0:
            v += -x
        if x > 1.0:
            v += x - 1.0
        if y < 0.0:
            v += -y
        if y > 1.0:
            v += y - 1.0
    return v


def _total_violation(sqs):
    n = len(sqs)
    v = 0.0
    for i in range(n):
        v += _wall_violation(sqs[i])
        for j in range(i + 1, n):
            v += _overlap_area(sqs[i], sqs[j])
    return v


# ---------------------------------------------------------------------------
# Candidate constructions
# ---------------------------------------------------------------------------

def _cand_grid_plus_strip(n, vertical=True):
    """k*k grid shrunk to leave a strip; leftover squares placed in strip."""
    k = math.isqrt(n)
    if k == 0:
        return None
    r = n - k * k
    if r == 0:
        base = 1.0 / k
        return _grid_squares(k, base)
    base = 1.0 / k
    best = _grid_squares(k, base)
    best_total = k * k * base
    steps = 60
    for w_num in range(1, steps):
        w = w_num / steps
        grid_side = min((1.0 - w) / k, base)
        if vertical:
            col_side = min(w, 1.0 / r)
        else:
            col_side = min(w, 1.0 / r)
        total = k * k * grid_side + r * col_side
        if total > best_total:
            best_total = total
            sq = _grid_squares(k, grid_side)
            for t in range(r):
                if vertical:
                    cy = (t + 0.5) / r
                    sq.append(((1.0 - w) + 0.5 * w, cy, 0.0, col_side))
                else:
                    cx = (t + 0.5) / r
                    sq.append((cx, (1.0 - w) + 0.5 * w, 0.0, col_side))
            best = sq
    return best


def _cand_rect_grid(n):
    """cols x rows rectangular grid of equal squares."""
    best = None
    best_total = 0.0
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        s = min(1.0 / cols, 1.0 / rows)
        total = n * s
        if total > best_total:
            best_total = total
            cw = 1.0 / cols
            ch = 1.0 / rows
            sq = []
            cnt = 0
            for i in range(cols):
                for j in range(rows):
                    if cnt < n:
                        sq.append(((i + 0.5) * cw, (j + 0.5) * ch, 0.0, s))
                        cnt += 1
            best = sq
    return best


def _cand_corner_block(n):
    """k*k grid plus leftover block in a corner of the remaining strip."""
    k = math.isqrt(n)
    if k == 0:
        return None
    r = n - k * k
    if r == 0:
        return _grid_squares(k, 1.0 / k)
    base = 1.0 / k
    best = _grid_squares(k, base)
    best_total = k * k * base
    for cols in range(1, r + 1):
        rows = (r + cols - 1) // cols
        for g_num in range(1, 60):
            g = g_num / 60.0
            if g <= 0 or g >= 1:
                continue
            grid_side = min(g / k, base)
            cellw = (1.0 - g) / cols
            cellh = 1.0 / rows
            cell_side = min(cellw, cellh)
            if cell_side <= 0:
                continue
            total = k * k * grid_side + r * cell_side
            if total > best_total:
                best_total = total
                sq = _grid_squares(k, grid_side)
                cnt = 0
                for i in range(cols):
                    for j in range(rows):
                        if cnt < r:
                            sq.append((g + (i + 0.5) * cellw,
                                       (j + 0.5) * cellh, 0.0, cell_side))
                            cnt += 1
                best = sq
    return best


def _candidates(n):
    cands = []
    for f in (_cand_rect_grid, _cand_corner_block):
        c = f(n)
        if c:
            cands.append(c)
    c = _cand_grid_plus_strip(n, vertical=True)
    if c:
        cands.append(c)
    c = _cand_grid_plus_strip(n, vertical=False)
    if c:
        cands.append(c)
    return cands


# ---------------------------------------------------------------------------
# Local optimizer
# ---------------------------------------------------------------------------

def _pack_vector_to_squares(x, n):
    sq = []
    for i in range(n):
        cx = x[4 * i]
        cy = x[4 * i + 1]
        a = x[4 * i + 2]
        s = x[4 * i + 3]
        sq.append((cx, cy, a, s))
    return sq


def _violation_vec(x, n):
    sq = _pack_vector_to_squares(x, n)
    v = 0.0
    for i in range(n):
        v += _wall_violation(sq[i])
        for j in range(i + 1, n):
            v += _overlap_area(sq[i], sq[j])
    return v


def _optimize(n, x0, maxiter=200):
    if not _HAVE_SCIPY:
        return None
    x0 = np.array(x0, dtype=float)
    # bounds: cx,cy in [0,1]; angle in [0,0.5]; side in [0,1]
    bounds = []
    for _ in range(n):
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 0.5))
        bounds.append((0.0, 1.0))

    def obj(x):
        s = 0.0
        for i in range(n):
            s -= x[4 * i + 3]
        return s

    def cons(x):
        # return scalar constraint >= 0 : tolerance - violation
        return -_violation_vec(x, n)

    try:
        res = minimize(obj, x0, method="SLSQP", bounds=bounds,
                       constraints=[{"type": "ineq", "fun": cons}],
                       options={"maxiter": maxiter, "ftol": 1e-10})
    except Exception:
        return None

    xr = res.x
    sq = _pack_vector_to_squares(xr, n)
    if _violation_vec(xr, n) > 1e-4:
        return None
    return sq


def _feasible_shrink(sq, tol=1e-9):
    """Greedily shrink squares that violate constraints."""
    sq = [list(s) for s in sq]
    for _ in range(50):
        v = _total_violation([tuple(s) for s in sq])
        if v < 1e-9:
            break
        worst = -1
        worst_v = 0.0
        for i in range(len(sq)):
            vi = _wall_violation(tuple(sq[i]))
            for j in range(len(sq)):
                if i != j:
                    vi += _overlap_area(tuple(sq[i]), tuple(sq[j]))
            if vi > worst_v:
                worst_v = vi
                worst = i
        if worst < 0:
            break
        sq[worst][3] = max(0.0, sq[worst][3] - 0.5 * worst_v)
    return [tuple(s) for s in sq]


def _score(sq):
    return sum(s[3] for s in sq)


def solve(n):
    if n <= 0:
        return []

    best = None
    best_total = -1.0

    # deterministic seed
    seeds = []
    cands = _candidates(n)
    for c in cands:
        if len(c) >= n:
            seeds.append(c[:n])

    # also include a few perturbed seeds
    base_seeds = list(seeds)
    for s0 in base_seeds:
        seeds.append(list(s0))

    for s0 in seeds:
        if len(s0) < n:
            s0 = list(s0) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(s0))
        # project into bounds
        s0 = [(min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0),
               min(max(a, 0.0), 0.5), min(max(s, 0.0), 1.0))
              for (cx, cy, a, s) in s0]
        # shrink to be feasible
        s0 = _feasible_shrink(s0)
        tot = _score(s0)
        if tot > best_total and _total_violation(s0) < 1e-6:
            best_total = tot
            best = s0

    # try local optimization from each seed (limit count for time)
    if _HAVE_SCIPY and n <= 40:
        tried = 0
        seed_list = list(seeds)
        if len(seed_list) > 12:
            seed_list = seed_list[:12]
        for s0 in seed_list:
            if tried >= 10:
                break
            tried += 1
            s0 = list(s0) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(s0))
            x0 = []
            for (cx, cy, a, s) in s0[:n]:
                x0.extend([cx, cy, a, s])
            opt = _optimize(n, x0)
            if opt is None:
                continue
            opt = _feasible_shrink(opt)
            tot = _score(opt)
            if tot > best_total + 1e-7 and _total_violation(opt) < 1e-6:
                best_total = tot
                best = opt

    if best is None:
        # fall back to a plain grid
        k = math.isqrt(n)
        best = _grid_squares(max(k, 1), 1.0 / max(k, 1))
        while len(best) < n:
            best.append((0.5, 0.5, 0.0, 0.0))

    out = []
    for cx, cy, a, s in best[:n]:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = min(max(a, 0.0), 0.5)
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, a, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
# EVOLVE-BLOCK-END
