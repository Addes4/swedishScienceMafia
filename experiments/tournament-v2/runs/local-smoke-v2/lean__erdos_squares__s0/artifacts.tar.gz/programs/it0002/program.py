# EVOLVE-BLOCK-START
"""Almost-square grid packing: full m x m grid plus a partial extra row and column."""


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Choose grid dimensions (rows x cols) with rows*cols <= n, then distribute the
    # leftover squares along the top row and right column, which lets each grid cell
    # keep a larger side than a naive k x k grid would allow.
    best = None
    for rows in range(1, n + 1):
        for cols in range(1, n + 1):
            if rows * cols > n:
                continue
            leftover = n - rows * cols
            # Cannot exceed one extra full row or one extra full column.
            if leftover > max(rows, cols):
                continue

            # Place the leftover squares in a partial extra column (or row).
            # Full grid occupies a x b region; the extra squares squeeze into the
            # remaining strip and are allowed to be smaller.
            a = cols
            b = rows
            if leftover == 0:
                # Simple uniform grid.
                sx = 1.0 / a
                sy = 1.0 / b
                s = min(sx, sy)
                squares = [
                    ((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                    for i in range(a)
                    for j in range(b)
                ]
                score = n * s
            else:
                # Grid of a x b squares of side s plus `leftover` smaller squares
                # stacked in an extra column on the right, of side t.
                # Width: a*s + t <= 1, Height for extra column: leftover*t <= 1.
                # Also t <= s to stay inside the grid strip; keep them disjoint.
                s = 1.0 / a
                t = min(s, 1.0 / leftover)
                if a * s > 1.0:
                    s = 1.0 / a
                squares = [
                    ((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                    for i in range(a)
                    for j in range(b)
                ]
                # Stack leftover squares of side t in the right strip.
                for k in range(leftover):
                    cx = a * s + t * 0.5
                    cy = (k + 0.5) * t
                    if cy <= 1.0 and cx <= 1.0:
                        squares.append((cx, cy, 0.0, t))
                score = a * b * s + leftover * t

            if best is None or score > best[0]:
                best = (score, squares)

    squares = best[1]
    squares = squares[:n]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares
# EVOLVE-BLOCK-END
