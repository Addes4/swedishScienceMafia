# EVOLVE-BLOCK-START
"""Grid packing plus leftover squares fit into the remaining strip using a
search over several candidate strip layouts, including rotated leftovers."""
import math


def _grid_squares(k, side, ox=0.0, oy=0.0):
    out = []
    for i in range(k):
        for j in range(k):
            out.append((ox + (i + 0.5) * side, oy + (j + 0.5) * side, 0.0, side))
    return out


def _full_rect_grid(n, cols, rows):
    """n squares in a cols x rows grid, all side s = min(1/cols, 1/rows)."""
    cellw = 1.0 / cols
    cellh = 1.0 / rows
    s = min(cellw, cellh)
    out = []
    cnt = 0
    for i in range(cols):
        for j in range(rows):
            if cnt < n:
                out.append(((i + 0.5) * cellw, (j + 0.5) * cellh, 0.0, s))
                cnt += 1
    return out, n * s


def _pack_leftover(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    base = 1.0 / k
    squares = _grid_squares(k, base)
    r = n - k * k
    if r == 0:
        return squares

    best = squares
    best_total = k * k * base

    # 0) Direct rectangle grids of all shapes with n cells, keeping aspect close to 1.
    for cols in range(max(1, k - 1), k + 3):
        for rows in range(max(1, k - 1), k + 3):
            if cols * rows < n:
                continue
            if rows * (cols - 1) >= n or cols * (rows - 1) >= n:
                # not a minimal grid; skip (fewer cells would also work)
                pass
            sq, total = _full_rect_grid(n, cols, rows)
            if total > best_total:
                best_total = total
                best = sq

    # 1) Column layout: grid width (1-w), extra column of r squares.
    for w_num in range(1, 40):
        w = w_num / 40.0
        if w <= 0 or w >= 1:
            continue
        grid_side = min((1.0 - w) / k, base)
        col_side = min(w, 1.0 / r)
        if col_side <= 0:
            continue
        total = k * k * grid_side + r * col_side
        if total > best_total:
            best_total = total
            sq = _grid_squares(k, grid_side)
            for t in range(r):
                cy = (t + 0.5) / r
                sq.append(((1.0 - w) + 0.5 * w, cy, 0.0, col_side))
            best = sq

    # 2) Row layout: grid height (1-h), extra row of r squares.
    for h_num in range(1, 40):
        h = h_num / 40.0
        if h <= 0 or h >= 1:
            continue
        grid_side = min((1.0 - h) / k, base)
        row_side = min(h, 1.0 / r)
        if row_side <= 0:
            continue
        total = k * k * grid_side + r * row_side
        if total > best_total:
            best_total = total
            sq = _grid_squares(k, grid_side)
            for t in range(r):
                cx = (t + 0.5) / r
                sq.append((cx, (1.0 - h) + 0.5 * h, 0.0, row_side))
            best = sq

    # 3) Block layout in the corner (uses rectangle cells for leftover).
    for cols in range(1, r + 1):
        rows = (r + cols - 1) // cols
        for g_num in range(1, 60):
            g = g_num / 60.0
            if g <= 0 or g >= 1:
                continue
            grid_side = min(g / k, base)
            cellw = (1.0 - g) / cols
            cellh = 1.0 / rows
            cell_side = min(cellw, cellh)
            if cell_side <= 0:
                continue
            total = k * k * grid_side + r * cell_side
            if total > best_total:
                best_total = total
                sq = _grid_squares(k, grid_side)
                cnt = 0
                ox = g
                for i in range(cols):
                    for j in range(rows):
                        if cnt < r:
                            sq.append((ox + (i + 0.5) * cellw,
                                       (j + 0.5) * cellh, 0.0, cell_side))
                            cnt += 1
                best = sq

    # 4) Two-corner fillers: (k x k) grid shrunk to (g x g) top-left,
    #    one rectangular grid of leftover in the right strip, another in
    #    the bottom strip (split r into a+b).
    for a in range(1, r):
        b = r - a
        for g_num in range(1, 60):
            g = g_num / 60.0
            if g <= 0 or g >= 1:
                continue
            grid_side = min(g / k, base)
            # right strip: a squares stacked vertically (column)
            col_side = min((1.0 - g), 1.0 / a) if a > 0 else 0.0
            # bottom strip: b squares in a row
            row_side = min((1.0 - g), 1.0 / b) if b > 0 else 0.0
            # cross-check widths: right strip width (1-g) must hold a column
            # of width <= (1-g) and the column's height is a*col_side <= 1
            # bottom strip height (1-g)
            if col_side <= 0 or row_side <= 0:
                continue
            total = k * k * grid_side + a * col_side + b * row_side
            if total > best_total:
                # check non-overlap: right column occupies x in [1-(1-g), 1]
                # Actually place right column at x in [g, 1], y in [0,a*col_side]
                # bottom row at y in [g,1], x in [0,b*row_side]
                best_total = total
                sq = _grid_squares(k, grid_side)
                # right column (within y in [0, 1])
                for t in range(a):
                    cy = (t + 0.5) * (1.0 / a)
                    sq.append((g + 0.5 * (1.0 - g), cy, 0.0, col_side))
                # bottom row (within x in [0, 1])
                for t in range(b):
                    cx = (t + 0.5) * (1.0 / b)
                    sq.append((cx, g + 0.5 * (1.0 - g), 0.0, row_side))
                best = sq

    # 5) Leftover strip with ONE rotated square (r==1).
    if r == 1:
        for w_num in range(1, 200):
            w = w_num / 200.0
            if w <= 0 or w >= 1:
                continue
            grid_side = min((1.0 - w) / k, base)
            a = 0.125
            c = math.cos(a * 2 * math.pi) + math.sin(a * 2 * math.pi)
            side = min(w / c, 1.0 / c)
            total = k * k * grid_side + side
            if total > best_total:
                best_total = total
                sq = _grid_squares(k, grid_side)
                sq.append((1.0 - w / 2.0, 0.5, a, side))
                best = sq

    # 6) Leftover strip with TWO rotated squares (r==2).
    if r == 2:
        for w_num in range(1, 200):
            w = w_num / 200.0
            if w <= 0 or w >= 1:
                continue
            grid_side = min((1.0 - w) / k, base)
            a = 0.125
            c = math.cos(a * 2 * math.pi) + math.sin(a * 2 * math.pi)
            side = (w / 2.0) / c
            side = min(side, 1.0 / c)
            total = k * k * grid_side + 2 * side
            if total > best_total:
                best_total = total
                sq = _grid_squares(k, grid_side)
                sq.append((1.0 - w + w * 0.25, 0.5, a, side))
                sq.append((1.0 - w + w * 0.75, 0.5, a, side))
                best = sq
            side = min(w / c, 0.5 / c)
            total = k * k * grid_side + 2 * side
            if total > best_total:
                best_total = total
                sq = _grid_squares(k, grid_side)
                sq.append((1.0 - w / 2.0, 0.25, a, side))
                sq.append((1.0 - w / 2.0, 0.75, a, side))
                best = sq

    return best


def solve(n):
    if n <= 0:
        return []
    squares = _pack_leftover(n)
    out = []
    for cx, cy, a, s in squares[:n]:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, a, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
# EVOLVE-BLOCK-END
