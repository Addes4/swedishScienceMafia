# EVOLVE-BLOCK-START
"""Greedy packing: place squares one at a time, maximizing each side."""
import math
import random
from scipy.optimize import minimize


def _overlap_ok(cx, cy, ang, side, placed):
    """Check if square with these params fits in unit square and avoids placed ones."""
    if side <= 0:
        return True
    c = math.cos(ang * 2 * math.pi)
    s = math.sin(ang * 2 * math.pi)
    # half-extent along x and y
    hx = (abs(c) + abs(s)) * side * 0.5
    hy = (abs(c) + abs(s)) * side * 0.5
    if cx - hx < -1e-9 or cx + hx > 1 + 1e-9:
        return False
    if cy - hy < -1e-9 or cy + hy > 1 + 1e-9:
        return False
    # SAT against placed axis-rotated squares
    for (ox, oy, oa, osd) in placed:
        if osd <= 0:
            continue
        if _sat_ok(cx, cy, ang, side, ox, oy, oa, osd):
            continue
        return False
    return True


def _sat_ok(cx, cy, ang, side, ox, oy, oa, osd):
    """Return True if the two rotated squares have disjoint interiors."""
    axes = []
    for a, in ((ang,), (oa,)):
        t = a * 2 * math.pi
        axes.append((math.cos(t), math.sin(t)))
        axes.append((-math.sin(t), math.cos(t)))
    for (ax, ay) in axes:
        def project(x, y, a, sd):
            t = a * 2 * math.pi
            ux, uy = math.cos(t), math.sin(t)
            vx, vy = -math.sin(t), math.cos(t)
            h = sd * 0.5
            corners = [
                (x + ux * h + vx * h, y + uy * h + vy * h),
                (x + ux * h - vx * h, y + uy * h - vy * h),
                (x - ux * h + vx * h, y - uy * h + vy * h),
                (x - ux * h - vx * h, y - uy * h - vy * h),
            ]
            vals = [cxp * ax + cyp * ay for (cxp, cyp) in corners]
            return min(vals), max(vals)
        a1, b1 = project(cx, cy, ang, side)
        a2, b2 = project(ox, oy, oa, osd)
        if b1 <= a2 + 1e-9 or b2 <= a1 + 1e-9:
            return True
    return False


def _max_side_at(cx, cy, ang, placed):
    """Binary search the largest side fit at given centre/angle."""
    lo, hi = 0.0, 1.0
    for _ in range(30):
        mid = (lo + hi) * 0.5
        if _overlap_ok(cx, cy, ang, mid, placed):
            lo = mid
        else:
            hi = mid
    return lo


def _greedy(n):
    placed = []
    for _ in range(n):
        best = (0.0, 0.5, 0.5, 0.0)
        # sample candidate centres
        for _ in range(400):
            cx = random.random()
            cy = random.random()
            ang = random.choice([0.0, 0.25, 0.125, 0.375, random.random()])
            sd = _max_side_at(cx, cy, ang, placed)
            if sd > best[0]:
                best = (sd, cx, cy, ang)
        # refine with local search on cx, cy, ang
        if best[0] > 0:
            sd0, cx0, cy0, ang0 = best

            def neg(p):
                return -_max_side_at(p[0], p[1], p[2], placed)

            try:
                res = minimize(neg, [cx0, cy0, ang0], method='Nelder-Mead',
                               options={'xatol': 1e-4, 'fatol': 1e-5, 'maxiter': 300})
                if -res.fun > best[0]:
                    sd1 = -res.fun
                    cx1, cy1, ang1 = res.x
                    if _overlap_ok(cx1, cy1, ang1, sd1 - 1e-7, placed):
                        best = (sd1, cx1, cy1, ang1)
            except Exception:
                pass
        placed.append((best[1], best[2], best[3], best[0]))
    return placed


def solve(n):
    if n <= 0:
        return []
    random.seed(12345 + n)
    best = None
    best_sum = -1.0
    trials = 3 if n <= 20 else 1
    for _ in range(trials):
        res = _greedy(n)
        s = sum(r[3] for r in res)
        if s > best_sum:
            best_sum = s
            best = res
    # clean up tiny negatives / clip
    out = []
    for (cx, cy, ang, sd) in best:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 1.0
        sd = max(sd, 0.0)
        out.append((cx, cy, ang, sd))
    return out
# EVOLVE-BLOCK-END
