# EVOLVE-BLOCK-START
"""Grid packing plus leftover squares packed into a strip via a continuous
scipy search over the strip width and the leftover squares' geometry."""
import math


def _grid_squares(k, side, ox=0.0, oy=0.0):
    out = []
    for i in range(k):
        for j in range(k):
            out.append((ox + (i + 0.5) * side, oy + (j + 0.5) * side, 0.0, side))
    return out


def _strip_block(r, w, h):
    """Pack r equal axis-aligned squares into a w x h strip; return (side, list)."""
    # choose cols x rows
    best = (0.0, [])
    for cols in range(1, r + 1):
        rows = (r + cols - 1) // cols
        s = min(w / cols, h / rows)
        if s > best[0]:
            best = (s, (cols, rows, s))
    s = best[0]
    cols, rows, _ = best[1]
    side_list = []
    cnt = 0
    for i in range(cols):
        for j in range(rows):
            if cnt < r:
                side_list.append((w * cols and (i + 0.5) * (w / cols),
                                  (j + 0.5) * (h / rows), 0.0, s))
                cnt += 1
    return s, side_list


def _pack_leftover(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    base = 1.0 / k
    squares = _grid_squares(k, base)
    r = n - k * k
    if r == 0:
        return squares

    best = squares
    best_total = k * k * base

    # Column layout: grid width (1-w), extra column of r squares.
    for w_num in range(1, 400):
        w = w_num / 400.0
        if w <= 0 or w >= 1:
            continue
        grid_side = min((1.0 - w) / k, base)
        col_side = min(w, 1.0 / r)
        total = k * k * grid_side + r * col_side
        if total > best_total:
            best_total = total
            sq = _grid_squares(k, grid_side)
            for t in range(r):
                cy = (t + 0.5) / r
                sq.append(((1.0 - w) + 0.5 * w, cy, 0.0, col_side))
            best = sq

    # Row layout.
    for h_num in range(1, 400):
        h = h_num / 400.0
        if h <= 0 or h >= 1:
            continue
        grid_side = min((1.0 - h) / k, base)
        row_side = min(h, 1.0 / r)
        total = k * k * grid_side + r * row_side
        if total > best_total:
            best_total = total
            sq = _grid_squares(k, grid_side)
            for t in range(r):
                cx = (t + 0.5) / r
                sq.append((cx, (1.0 - h) + 0.5 * h, 0.0, row_side))
            best = sq

    # Block layout: k×k grid in a g x g corner, leftover block in remaining L.
    for cols in range(1, r + 1):
        rows = (r + cols - 1) // cols
        for g_num in range(1, 600):
            g = g_num / 600.0
            if g <= 0 or g >= 1:
                continue
            grid_side = min(g / k, base)
            # leftover region: right strip (1-g) x 1 plus maybe top strip
            # Try two orientations of the leftover region.
            # (a) leftover in vertical strip of width (1-g)
            s1 = min((1.0 - g) / cols, 1.0 / rows)
            # (b) leftover in horizontal strip of height (1-g)
            s2 = min(1.0 / cols, (1.0 - g) / rows)
            for s, vert in ((s1, True), (s2, False)):
                total = k * k * grid_side + r * s
                if total > best_total:
                    best_total = total
                    sq = _grid_squares(k, grid_side)
                    cnt = 0
                    if vert:
                        cw = (1.0 - g) / cols
                        ch = 1.0 / rows
                        for i in range(cols):
                            for j in range(rows):
                                if cnt < r:
                                    sq.append((g + (i + 0.5) * cw,
                                               (j + 0.5) * ch, 0.0, s))
                                    cnt += 1
                    else:
                        cw = 1.0 / cols
                        ch = (1.0 - g) / rows
                        for i in range(cols):
                            for j in range(rows):
                                if cnt < r:
                                    sq.append(((i + 0.5) * cw,
                                               g + (j + 0.5) * ch, 0.0, s))
                                    cnt += 1
                    best = sq

    # Rectangle grid fallback.
    kk = k * (k + 1)
    if n <= kk:
        cols = k + 1
        rows = (n + cols - 1) // cols
        cellw = 1.0 / cols
        cellh = 1.0 / rows
        s = min(cellw, cellh)
        sq = []
        cnt = 0
        for i in range(cols):
            for j in range(rows):
                if cnt < n:
                    sq.append(((i + 0.5) * cellw, (j + 0.5) * cellh, 0.0, s))
                    cnt += 1
        total = n * s
        if total > best_total:
            best_total = total
            best = sq

    # Strip with rotated leftover squares (small r).
    if r <= 3:
        c45 = math.cos(0.25 * math.pi) + math.sin(0.25 * math.pi)  # 1.4142
        a = 0.125
        for w_num in range(1, 800):
            w = w_num / 800.0
            if w <= 0 or w >= 1:
                continue
            grid_side = min((1.0 - w) / k, base)
            # r squares each in a sub-strip of width w/r, full height 1
            sub = w / r
            side = min(sub, 1.0) / c45
            total = k * k * grid_side + r * side
            if total > best_total:
                best_total = total
                sq = _grid_squares(k, grid_side)
                for t in range(r):
                    sq.append((1.0 - w + sub * (t + 0.5), 0.5, a, side))
                best = sq
            # stacked vertically
            subh = 1.0 / r
            side = min(w, subh) / c45
            total = k * k * grid_side + r * side
            if total > best_total:
                best_total = total
                sq = _grid_squares(k, grid_side)
                for t in range(r):
                    sq.append((1.0 - w / 2.0, subh * (t + 0.5), a, side))
                best = sq

    return best


def solve(n):
    if n <= 0:
        return []
    squares = _pack_leftover(n)
    out = []
    for cx, cy, a, s in squares[:n]:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, a, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
# EVOLVE-BLOCK-END
