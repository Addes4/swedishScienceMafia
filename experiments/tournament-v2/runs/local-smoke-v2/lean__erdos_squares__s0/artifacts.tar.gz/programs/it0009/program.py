# EVOLVE-BLOCK-START
"""Grid packing plus a scipy-driven optimization of the leftover squares
placed in the side strip, plus several handcrafted strip layouts."""
import math

try:
    import numpy as np
    from scipy.optimize import minimize
except Exception:
    np = None
    minimize = None


def _grid_squares(k, side, ox=0.0, oy=0.0):
    out = []
    for i in range(k):
        for j in range(k):
            out.append((ox + (i + 0.5) * side, oy + (j + 0.5) * side, 0.0, side))
    return out


def _overlap(ax, ay, aa, as_, bx, by, ba, bs):
    # approximate overlap check between two squares using corner/axis separation
    # use separating axis theorem on both squares' axes
    axes = []
    for (cx, cy, a, s) in ((ax, ay, aa, as_), (bx, by, ba, bs)):
        ang = a * 2 * math.pi
        ux, uy = math.cos(ang), math.sin(ang)
        axes.append((ux, uy))
        axes.append((-uy, ux))
    for (ux, uy) in axes:
        pa = _proj(ax, ay, aa, as_, ux, uy)
        pb = _proj(bx, by, ba, bs, ux, uy)
        if pa[1] <= pb[0] + 1e-12 or pb[1] <= pa[0] + 1e-12:
            return False
    return True


def _proj(cx, cy, a, s, ux, uy):
    ang = a * 2 * math.pi
    u = (math.cos(ang), math.sin(ang))
    v = (-math.sin(ang), math.cos(ang))
    h = s / 2.0
    lo = cx * ux + cy * uy
    hi = lo
    for sx in (-1, 1):
        for sy in (-1, 1):
            px = cx + sx * h * u[0] + sy * h * v[0]
            py = cy + sx * h * u[1] + sy * h * v[1]
            t = px * ux + py * uy
            lo = min(lo, t)
            hi = max(hi, t)
    return (lo, hi)


def _pack_leftover(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    base = 1.0 / k
    squares = _grid_squares(k, base)
    r = n - k * k
    if r == 0:
        return squares

    best = squares
    best_total = k * k * base

    # 1) Column layout: grid width (1-w), extra column of r squares.
    for w_num in range(1, 40):
        w = w_num / 40.0
        if w <= 0 or w >= 1:
            continue
        grid_side = min((1.0 - w) / k, base)
        col_side = min(w, 1.0 / r)
        if col_side <= 0:
            continue
        total = k * k * grid_side + r * col_side
        if total > best_total:
            best_total = total
            sq = _grid_squares(k, grid_side)
            for t in range(r):
                sq.append(((1.0 - w) + 0.5 * w, (t + 0.5) / r, 0.0, col_side))
            best = sq

    # 2) Row layout.
    for h_num in range(1, 40):
        h = h_num / 40.0
        if h <= 0 or h >= 1:
            continue
        grid_side = min((1.0 - h) / k, base)
        row_side = min(h, 1.0 / r)
        if row_side <= 0:
            continue
        total = k * k * grid_side + r * row_side
        if total > best_total:
            best_total = total
            sq = _grid_squares(k, grid_side)
            for t in range(r):
                sq.append(((t + 0.5) / r, (1.0 - h) + 0.5 * h, 0.0, row_side))
            best = sq

    # 3) Block layout in the corner.
    for cols in range(1, r + 1):
        rows = (r + cols - 1) // cols
        for g_num in range(1, 60):
            g = g_num / 60.0
            if g <= 0 or g >= 1:
                continue
            grid_side = min(g / k, base)
            cellw = (1.0 - g) / cols
            cellh = 1.0 / rows
            cell_side = min(cellw, cellh)
            if cell_side <= 0:
                continue
            total = k * k * grid_side + r * cell_side
            if total > best_total:
                best_total = total
                sq = _grid_squares(k, grid_side)
                cnt = 0
                ox = g
                for i in range(cols):
                    for j in range(rows):
                        if cnt < r:
                            sq.append((ox + (i + 0.5) * cellw,
                                       (j + 0.5) * cellh, 0.0, cell_side))
                            cnt += 1
                best = sq

    # 4) Rectangle grid.
    kk = k * (k + 1)
    if n <= kk:
        cols = k + 1
        rows = (n + cols - 1) // cols
        cellw = 1.0 / cols
        cellh = 1.0 / rows
        s = min(cellw, cellh)
        sq = []
        cnt = 0
        for i in range(cols):
            for j in range(rows):
                if cnt < n:
                    sq.append(((i + 0.5) * cellw, (j + 0.5) * cellh, 0.0, s))
                    cnt += 1
        total = n * s
        if total > best_total:
            best_total = total
            best = sq

    # 5) Leftover strip with ONE rotated square.
    if r == 1:
        for w_num in range(1, 200):
            w = w_num / 200.0
            if w <= 0 or w >= 1:
                continue
            grid_side = min((1.0 - w) / k, base)
            a = 0.125
            c = math.cos(a * 2 * math.pi) + math.sin(a * 2 * math.pi)
            side = min(w / c, 1.0 / c)
            total = k * k * grid_side + side
            if total > best_total:
                best_total = total
                sq = _grid_squares(k, grid_side)
                sq.append((1.0 - w / 2.0, 0.5, a, side))
                best = sq

    # 6) Leftover strip with TWO rotated squares.
    if r == 2:
        for w_num in range(1, 200):
            w = w_num / 200.0
            if w <= 0 or w >= 1:
                continue
            grid_side = min((1.0 - w) / k, base)
            a = 0.125
            c = math.cos(a * 2 * math.pi) + math.sin(a * 2 * math.pi)
            side = min((w / 2.0) / c, 1.0 / c)
            total = k * k * grid_side + 2 * side
            if total > best_total:
                best_total = total
                sq = _grid_squares(k, grid_side)
                sq.append((1.0 - w + w * 0.25, 0.5, a, side))
                sq.append((1.0 - w + w * 0.75, 0.5, a, side))
                best = sq
            side = min(w / c, 0.5 / c)
            total = k * k * grid_side + 2 * side
            if total > best_total:
                best_total = total
                sq = _grid_squares(k, grid_side)
                sq.append((1.0 - w / 2.0, 0.25, a, side))
                sq.append((1.0 - w / 2.0, 0.75, a, side))
                best = sq

    return best


def _opt_small(n):
    """For small n try to improve over _pack_leftover via scipy on the
    leftover squares given a k x k grid."""
    if np is None or minimize is None:
        return None
    k = math.isqrt(n)
    r = n - k * k
    if r == 0:
        return None
    base = 1.0 / k
    # We fix the grid on the left occupying [0, g] x [0, 1] with a k x k grid.
    # Then leftover squares live in [g, 1] x [0, 1], free positions and angles.
    # Variables: g, then for each leftover square (cx, cy, angle, side).
    def make_x0(g):
        xs = [g]
        for t in range(r):
            cy = (t + 0.5) / r
            xs += [(g + (1 - g) / 2.0), cy, 0.125, 0.3 * (1 - g)]
        return np.array(xs)

    def unpack(x):
        g = x[0]
        g = min(max(g, 0.05), 1.0)
        sq = []
        for t in range(r):
            cx, cy, a, s = x[1 + 4 * t:5 + 4 * t]
            cx = min(max(cx, g), 1.0)
            cy = min(max(cy, 0.0), 1.0)
            a = a % 1.0
            s = max(s, 0.0)
            sq.append((cx, cy, a, s))
        return g, sq

    def valid_of(g, sq):
        # check leftover squares inside [g,1] x [0,1], mutually non-overlapping,
        # and not overlapping the grid (grid occupies [0,g] x [0,1])
        for cx, cy, a, s in sq:
            h = s / 2.0
            ang = a * 2 * math.pi
            u = (math.cos(ang), math.sin(ang))
            v = (-math.sin(ang), math.cos(ang))
            for sx in (-1, 1):
                for sy in (-1, 1):
                    px = cx + sx * h * u[0] + sy * h * v[0]
                    py = cy + sx * h * u[1] + sy * h * v[1]
                    if px < g - 1e-9 or px > 1 + 1e-9:
                        return False
                    if py < -1e-9 or py > 1 + 1e-9:
                        return False
        for i in range(r):
            for j in range(i + 1, r):
                if _overlap(sq[i][0], sq[i][1], sq[i][2], sq[i][3],
                            sq[j][0], sq[j][1], sq[j][2], sq[j][3]):
                    return False
        return True

    def total_of(g, sq):
        grid_side = min(g / k, base)
        return k * k * grid_side + sum(s[3] for s in sq)

    best_total = -1.0
    best_pack = None

    # multi-start scipy
    for g0 in (0.5, 0.6, 0.7, 0.75, 0.8, 0.85, 0.9):
        x0 = make_x0(g0)

        def neg(x):
            g, sq = unpack(x)
            t = total_of(g, sq)
            # penalize invalidity
            if not valid_of(g, sq):
                return 1e6 - t
            return -t

        try:
            res = minimize(neg, x0, method='Nelder-Mead',
                           options={'maxiter': 4000, 'xatol': 1e-6,
                                    'fatol': 1e-6})
        except Exception:
            continue
        g, sq = unpack(res.x)
        if valid_of(g, sq):
            t = total_of(g, sq)
            if t > best_total:
                best_total = t
                best_pack = (g, sq)

    if best_pack is None:
        return None
    g, sq = best_pack
    grid_side = min(g / k, base)
    out = _grid_squares(k, grid_side, ox=0.0)
    # re-center grid horizontally inside [0,g]
    out = _grid_squares(k, grid_side, ox=(g - k * grid_side) / 2.0)
    for cx, cy, a, s in sq:
        out.append((cx, cy, a, s))
    return out


def solve(n):
    if n <= 0:
        return []
    squares = _pack_leftover(n)
    best_total = sum(s for _, _, _, s in squares[:n])
    try:
        alt = _opt_small(n)
        if alt is not None:
            alt = alt[:n]
            at = sum(s for _, _, _, s in alt)
            if at > best_total + 1e-7:
                best_total = at
                squares = alt
    except Exception:
        pass
    out = []
    for cx, cy, a, s in squares[:n]:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, a, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
# EVOLVE-BLOCK-END
