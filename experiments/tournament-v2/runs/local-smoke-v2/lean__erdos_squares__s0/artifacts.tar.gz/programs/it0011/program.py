# EVOLVE-BLOCK-START
"""Grid packing plus leftover squares fit into the remaining strip using a
search over several candidate strip layouts, including a rotated leftover
square for small r. Adds a small-n specialized constructor with fine sweeps."""
import math


def _grid_squares(k, side, ox=0.0, oy=0.0):
    out = []
    for i in range(k):
        for j in range(k):
            out.append((ox + (i + 0.5) * side, oy + (j + 0.5) * side, 0.0, side))
    return out


def _pack_leftover(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    base = 1.0 / k
    squares = _grid_squares(k, base)
    r = n - k * k
    if r == 0:
        return squares

    best = squares
    best_total = k * k * base

    # 1) Column layout: grid width (1-w), extra column of r squares.
    for w_num in range(1, 200):
        w = w_num / 200.0
        if w <= 0 or w >= 1:
            continue
        grid_side = min((1.0 - w) / k, base)
        col_side = min(w, 1.0 / r)
        if col_side <= 0:
            continue
        total = k * k * grid_side + r * col_side
        if total > best_total:
            best_total = total
            sq = _grid_squares(k, grid_side)
            for t in range(r):
                cy = (t + 0.5) / r
                sq.append(((1.0 - w) + 0.5 * w, cy, 0.0, col_side))
            best = sq

    # 2) Row layout: grid height (1-h), extra row of r squares.
    for h_num in range(1, 200):
        h = h_num / 200.0
        if h <= 0 or h >= 1:
            continue
        grid_side = min((1.0 - h) / k, base)
        row_side = min(h, 1.0 / r)
        if row_side <= 0:
            continue
        total = k * k * grid_side + r * row_side
        if total > best_total:
            best_total = total
            sq = _grid_squares(k, grid_side)
            for t in range(r):
                cx = (t + 0.5) / r
                sq.append((cx, (1.0 - h) + 0.5 * h, 0.0, row_side))
            best = sq

    # 3) Block layout in the corner.
    for cols in range(1, r + 1):
        rows = (r + cols - 1) // cols
        for g_num in range(1, 200):
            g = g_num / 200.0
            if g <= 0 or g >= 1:
                continue
            grid_side = min(g / k, base)
            cellw = (1.0 - g) / cols
            cellh = 1.0 / rows
            cell_side = min(cellw, cellh)
            if cell_side <= 0:
                continue
            total = k * k * grid_side + r * cell_side
            if total > best_total:
                best_total = total
                sq = _grid_squares(k, grid_side)
                cnt = 0
                ox = g
                for i in range(cols):
                    for j in range(rows):
                        if cnt < r:
                            sq.append((ox + (i + 0.5) * cellw,
                                       (j + 0.5) * cellh, 0.0, cell_side))
                            cnt += 1
                best = sq

    # 4) Rectangle grid.
    kk = k * (k + 1)
    if n <= kk:
        cols = k + 1
        rows = (n + cols - 1) // cols
        cellw = 1.0 / cols
        cellh = 1.0 / rows
        s = min(cellw, cellh)
        sq = []
        cnt = 0
        for i in range(cols):
            for j in range(rows):
                if cnt < n:
                    sq.append(((i + 0.5) * cellw, (j + 0.5) * cellh, 0.0, s))
                    cnt += 1
        total = n * s
        if total > best_total:
            best_total = total
            best = sq

    # 5) Leftover strip with rotated square(s): grid shrunk to free a strip of
    #    width w, leftover squares rotated. We sweep strip width, rotation
    #    angle and try the strip on left/right (vertical) and top/bottom
    #    (horizontal).
    #    A square of side s rotated by angle a (radians) fits in a strip of
    #    width W if s*(|cos a|+|sin a|) <= W and along the strip length L if
    #    s*(|cos a|+|sin a|) <= L. For multiple stacked squares, divide.
    if r <= 4:
        for two_pi in [1]:
            pass
        # candidate angles (fractions of full turn)
        angles = [0.0, 0.125]
        for sidelen_num in range(1, 400):
            w = sidelen_num / 400.0
            if w <= 0 or w >= 1:
                continue
            grid_side = min((1.0 - w) / k, base)
            grid_total = k * k * grid_side
            # vertical strip: width w, length 1
            # split strip into r cells along length
            for a_frac in angles:
                a = a_frac
                rad = a * 2.0 * math.pi
                c = abs(math.cos(rad)) + abs(math.sin(rad))
                # each square must fit width w and height (1/r)
                s_cell = min(w / c, (1.0 / r) / c)
                if s_cell <= 0:
                    continue
                total = grid_total + r * s_cell
                if total > best_total:
                    best_total = total
                    sq = _grid_squares(k, grid_side)
                    for t in range(r):
                        sq.append((1.0 - w / 2.0, (t + 0.5) / r, a_frac, s_cell))
                    best = sq
            # horizontal strip: height w, length 1
            for a_frac in angles:
                a = a_frac
                rad = a * 2.0 * math.pi
                c = abs(math.cos(rad)) + abs(math.sin(rad))
                s_cell = min(w / c, (1.0 / r) / c)
                if s_cell <= 0:
                    continue
                total = grid_total + r * s_cell
                if total > best_total:
                    best_total = total
                    sq = _grid_squares(k, grid_side)
                    for t in range(r):
                        sq.append(((t + 0.5) / r, 1.0 - w / 2.0, a_frac, s_cell))
                    best = sq

    # 6) Two leftover squares side by side in a vertical strip (each w/2 wide).
    if r == 2:
        angles = [0.0, 0.125]
        for w_num in range(1, 400):
            w = w_num / 400.0
            if w <= 0 or w >= 1:
                continue
            grid_side = min((1.0 - w) / k, base)
            grid_total = k * k * grid_side
            for a_frac in angles:
                rad = a_frac * 2.0 * math.pi
                c = abs(math.cos(rad)) + abs(math.sin(rad))
                s_cell = min((w / 2.0) / c, 1.0 / c)
                if s_cell <= 0:
                    continue
                total = grid_total + 2 * s_cell
                if total > best_total:
                    best_total = total
                    sq = _grid_squares(k, grid_side)
                    sq.append((1.0 - w + w * 0.25, 0.5, a_frac, s_cell))
                    sq.append((1.0 - w + w * 0.75, 0.5, a_frac, s_cell))
                    best = sq
                # stacked
                s2 = min(w / c, 0.5 / c)
                total = grid_total + 2 * s2
                if total > best_total:
                    best_total = total
                    sq = _grid_squares(k, grid_side)
                    sq.append((1.0 - w / 2.0, 0.25, a_frac, s2))
                    sq.append((1.0 - w / 2.0, 0.75, a_frac, s2))
                    best = sq

    return best


def solve(n):
    if n <= 0:
        return []
    squares = _pack_leftover(n)
    out = []
    for cx, cy, a, s in squares[:n]:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, a, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
# EVOLVE-BLOCK-END
