# EVOLVE-BLOCK-START
"""Grid packing plus a general continuous optimizer for the leftover squares.
The base is a k x k grid (k = isqrt(n)); the r = n - k*k leftover squares are
placed one at a time by maximising their side over (cx, cy, angle) subject to
fitting against the walls and against the squares placed so far. Several
closed-form strip layouts are also tried and the best total is kept."""
import math

try:
    from scipy.optimize import minimize
    _HAVE_SCIPY = True
except Exception:
    _HAVE_SCIPY = False


def _grid_squares(k, side, ox=0.0, oy=0.0):
    out = []
    for i in range(k):
        for j in range(k):
            out.append((ox + (i + 0.5) * side, oy + (j + 0.5) * side, 0.0, side))
    return out


def _corners(cx, cy, a, s):
    """Four corners of a square, angle as fraction of a full turn."""
    t = a * 2.0 * math.pi
    c, sn = math.cos(t), math.sin(t)
    h = s * 0.5
    pts = []
    for sx, sy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + sx * c - sy * sn, cy + sx * sn + sy * c))
    return pts


def _feasible(cx, cy, a, s, placed):
    if s < 0:
        return False
    for x, y in _corners(cx, cy, a, s):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    # polygon overlap test via separating axis theorem
    for (pcx, pcy, pa, ps) in placed:
        if _overlap(cx, cy, a, s, pcx, pcy, pa, ps):
            return False
    return True


def _overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    p1 = _corners(cx1, cy1, a1, s1)
    p2 = _corners(cx2, cy2, a2, s2)
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            ax, ay = x2 - x1, y2 - y1
            # normal
            nx, ny = -ay, ax
            n1 = min(px * nx + py * ny for px, py in p1)
            x1b = max(px * nx + py * ny for px, py in p1)
            n2 = min(px * nx + py * ny for px, py in p2)
            x2b = max(px * nx + py * ny for px, py in p2)
            if x1b <= n2 + 1e-9 or x2b <= n1 + 1e-9:
                return False
    return True


def _count_violations(cx, cy, a, s, placed):
    v = 0.0
    for x, y in _corners(cx, cy, a, s):
        if x < 0:
            v += -x
        if x > 1.0:
            v += x - 1.0
        if y < 0:
            v += -y
        if y > 1.0:
            v += y - 1.0
    for (pcx, pcy, pa, ps) in placed:
        if _overlap(cx, cy, a, s, pcx, pcy, pa, ps):
            # crude penetration measure
            d = math.hypot(cx - pcx, cy - pcy)
            v += max(0.0, (s + ps) * 0.5 - d) + 1e-3
    return v


def _greedy_optimize(k, base, r, rng_seed=0):
    """Place r leftover squares after the fixed grid, one at a time."""
    grid_side = base
    placed = _grid_squares(k, grid_side)
    for idx in range(r):
        best = None
        # candidate starts: corners and a coarse sweep
        starts = []
        for cx in (0.05, 0.25, 0.5, 0.75, 0.95):
            for cy in (0.05, 0.25, 0.5, 0.75, 0.95):
                for a in (0.0, 0.125):
                    starts.append((cx, cy, a))

        def obj(z):
            cx, cy, a = z
            s = _max_side(cx, cy, a, placed)
            return -s

        def pen(z):
            cx, cy, a = z
            s = _max_side(cx, cy, a, placed)
            # small penalty to prefer centered, non-degenerate
            return 0.0

        # cheap: just evaluate _max_side at starts
        local_best = (-1.0, None)
        for (cx, cy, a) in starts:
            s = _max_side(cx, cy, a, placed)
            if s > local_best[0]:
                local_best = (s, (cx, cy, a))
        if _HAVE_SCIPY and r <= 4:
            # refine best start
            for s0, (cx0, cy0, a0) in [local_best]:
                def neg_s(z):
                    return -_max_side(max(0.0, min(1.0, z[0])),
                                      max(0.0, min(1.0, z[1])), z[2], placed)
                try:
                    res = minimize(neg_s, [cx0, cy0, a0], method="Nelder-Mead",
                                   options={"xatol": 1e-4, "fatol": 1e-6, "maxiter": 300})
                    s1 = -res.fun
                    if s1 > local_best[0]:
                        zx = max(0.0, min(1.0, res.x[0]))
                        zy = max(0.0, min(1.0, res.x[1]))
                        local_best = (s1, (zx, zy, res.x[2]))
                except Exception:
                    pass

        s, (cx, cy, a) = local_best
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        placed.append((cx, cy, a, max(0.0, s)))
    return placed


def _max_side(cx, cy, a, placed):
    """Largest side for a square centered at (cx,cy) with given angle."""
    lo, hi = 0.0, 1.0
    # first check a small side to bound search
    if not _feasible(cx, cy, a, 1e-6, placed):
        return 0.0
    for _ in range(40):
        mid = (lo + hi) * 0.5
        if _feasible(cx, cy, a, mid, placed):
            lo = mid
        else:
            hi = mid
    return lo


def _pack_leftover(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    base = 1.0 / k
    squares = _grid_squares(k, base)
    r = n - k * k
    if r == 0:
        return squares

    best = list(squares)
    best_total = k * k * base

    # 1) Column layout: grid width (1-w), extra column of r squares.
    for w_num in range(1, 40):
        w = w_num / 40.0
        if w <= 0 or w >= 1:
            continue
        grid_side = min((1.0 - w) / k, base)
        col_side = min(w, 1.0 / r)
        if col_side <= 0:
            continue
        total = k * k * grid_side + r * col_side
        if total > best_total:
            best_total = total
            sq = _grid_squares(k, grid_side)
            for t in range(r):
                cy = (t + 0.5) / r
                sq.append(((1.0 - w) + 0.5 * w, cy, 0.0, col_side))
            best = sq

    # 2) Row layout.
    for h_num in range(1, 40):
        h = h_num / 40.0
        if h <= 0 or h >= 1:
            continue
        grid_side = min((1.0 - h) / k, base)
        row_side = min(h, 1.0 / r)
        if row_side <= 0:
            continue
        total = k * k * grid_side + r * row_side
        if total > best_total:
            best_total = total
            sq = _grid_squares(k, grid_side)
            for t in range(r):
                cx = (t + 0.5) / r
                sq.append((cx, (1.0 - h) + 0.5 * h, 0.0, row_side))
            best = sq

    # 3) Block layout in the corner.
    for cols in range(1, r + 1):
        rows = (r + cols - 1) // cols
        for g_num in range(1, 60):
            g = g_num / 60.0
            if g <= 0 or g >= 1:
                continue
            grid_side = min(g / k, base)
            cellw = (1.0 - g) / cols
            cellh = 1.0 / rows
            cell_side = min(cellw, cellh)
            if cell_side <= 0:
                continue
            total = k * k * grid_side + r * cell_side
            if total > best_total:
                best_total = total
                sq = _grid_squares(k, grid_side)
                cnt = 0
                ox = g
                for i in range(cols):
                    for j in range(rows):
                        if cnt < r:
                            sq.append((ox + (i + 0.5) * cellw,
                                       (j + 0.5) * cellh, 0.0, cell_side))
                            cnt += 1
                best = sq

    # 4) Rectangle grid.
    kk = k * (k + 1)
    if n <= kk:
        cols = k + 1
        rows = (n + cols - 1) // cols
        cellw = 1.0 / cols
        cellh = 1.0 / rows
        s = min(cellw, cellh)
        sq = []
        cnt = 0
        for i in range(cols):
            for j in range(rows):
                if cnt < n:
                    sq.append(((i + 0.5) * cellw, (j + 0.5) * cellh, 0.0, s))
                    cnt += 1
        total = n * s
        if total > best_total:
            best_total = total
            best = sq

    # 5) General continuous optimizer for the leftover squares.
    if r >= 1:
        try:
            opt = _greedy_optimize(k, base, r)
            if len(opt) == n:
                total = sum(s for (_, _, _, s) in opt)
                if total > best_total:
                    best_total = total
                    best = opt
        except Exception:
            pass

    return best


def solve(n):
    if n <= 0:
        return []
    squares = _pack_leftover(n)
    out = []
    for cx, cy, a, s in squares[:n]:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, a, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
# EVOLVE-BLOCK-END
