# EVOLVE-BLOCK-START
"""Distribution-aware hybrid of best-fit and worst-fit.

Pure best-fit strands small unusable residuals.  A good packing keeps most
bins able to accept at least one more typical item.  We therefore split the
candidate bins into two groups based on the running average item size:

  * "tight" bins whose post-placement residual is below the current mean item
    size are near-useless; among them we still use best fit (smallest residual).
  * "loose" bins that would keep a residual of at least the mean item size are
    genuinely reusable; among them we prefer the *largest* residual (worst fit)
    to keep future large items placeable and avoid creating more slivers.

The running mean is a cheap, stable estimate of the item distribution.
"""
import numpy as np

_MEAN = 40.0
_COUNT = 0


def priority(item, bins):
    global _MEAN, _COUNT
    # Update running estimate of the item-size distribution.
    _COUNT += 1
    _MEAN += (item - _MEAN) / _COUNT

    residual = bins - item                     # >= 0 for every bin shown
    threshold = _MEAN

    score = np.empty(residual.shape, dtype=np.float64)

    loose = residual >= threshold              # residual keeps room for a typical item
    # Loose bins: prefer larger residual (worst fit).
    score[loose] = residual[loose].astype(np.float64)
    # Tight bins: prefer smaller residual (best fit).
    score[~loose] = -residual[~loose].astype(np.float64)

    return score
# EVOLVE-BLOCK-END

