# EVOLVE-BLOCK-START
"""Best-fit with a narrow waste surcharge and online fillability tie-break.

Pure best-fit creates bins whose leftover (say 1..15) is too small to be
used again, wasting capacity.  We keep strict tight-fit ordering (score by
residual) and add:

1. A narrow, modest surcharge for tiny unusable residuals (1..15).
2. A tiny near-tie bonus preferring the bin whose resulting residual is a
   common future item size, learned online from the observed item stream so
   it adapts to the true distribution without hand-tuning.
"""
import numpy as np

_SURCHARGE = 4.0
_WASTE_LIMIT = 15
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

# Online empirical histogram over residuals 0..100, updated as items arrive.
_hist = np.zeros(101, dtype=np.float64)
_state = {"count": 0}


def priority(item, bins):
    # Update the empirical histogram with the newly observed item size.
    _state["count"] += 1
    if 1 <= item <= 100:
        _hist[item] += 1.0

    residual = bins - item
    score = -residual.astype(np.float64)

    # Narrow penalty for tiny unusable slack.
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0 and _state["count"] > 0:
        # Fillability: how often a residual r was an observed item size.
        fill = _hist / _state["count"]
        rc = np.clip(residual, 0, 100).astype(np.int64)
        f = fill[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * f * is_near

    return score
# EVOLVE-BLOCK-END
