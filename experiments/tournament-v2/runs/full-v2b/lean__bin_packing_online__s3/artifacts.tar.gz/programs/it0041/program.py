# EVOLVE-BLOCK-START
"""Threshold-aware best fit: avoid stranding unusable residuals.

Pure best-fit often creates a bin with a small leftover that no future item
can use, wasting capacity.  Items are drawn from a Weibull-shaped
distribution with mean ~40, so sizes below ~20 are rare.  We pick the bin
that minimises residual-after-placement, but add a surcharge to residuals
that fall in a "waste" band just above 0, pushing the algorithm to either
fully fill a bin (residual 0) or leave a genuinely reusable gap.
"""
import numpy as np

# Residuals strictly between 0 and this value are treated as likely-wasted slack.
_WASTE_LIMIT = 28.0
_SURCHARGE = 10.0
# A milder penalty extends further out toward the typical item size.
_WIDE_LIMIT = 40.0
_WIDE_SURCHARGE = 2.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise residuals that are small but non-zero (likely unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste
    # Smaller nudge for the wider, borderline band.
    wide = (residual >= _WASTE_LIMIT) & (residual < _WIDE_LIMIT)
    score -= _WIDE_SURCHARGE * wide
    return score
# EVOLVE-BLOCK-END
