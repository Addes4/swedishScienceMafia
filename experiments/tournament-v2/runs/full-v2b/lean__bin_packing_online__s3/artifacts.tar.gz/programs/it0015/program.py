# EVOLVE-BLOCK-START
"""Threshold-aware best fit with a smooth waste penalty.

Pure best-fit often leaves a bin with a small-to-medium leftover that few
future items can use.  We rank bins by the residual after placement, but
subtract a penalty for residuals that fall in a "waste band" just above 0.
The penalty decays smoothly with the residual so that tiny leftovers are
avoided aggressively while genuinely reusable gaps (large residual) and
perfect fills (residual 0) are preferred.
"""
import numpy as np

# Residuals strictly between 0 and this value carry a waste penalty.
_WASTE_LIMIT = 40.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    r = residual.astype(np.float64)
    score = -r                                 # base: tightest fit wins
    # Weight grows as the residual shrinks toward 0 (excluding exact 0).
    # weight = (limit - r) / limit, clipped to [0, 1].
    w = np.clip((_WASTE_LIMIT - r) / _WASTE_LIMIT, 0.0, 1.0)
    w = np.where(r > 0, w, 0.0)                # no penalty when exactly full
    score -= 8.0 * w
    return score
# EVOLVE-BLOCK-END
