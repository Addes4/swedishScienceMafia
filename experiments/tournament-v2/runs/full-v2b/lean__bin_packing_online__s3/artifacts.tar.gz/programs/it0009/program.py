# EVOLVE-BLOCK-START
"""Best fit with a small preference to consolidate near-full bins."""
import numpy as np


def priority(item, bins):
    """Score each bin: primary = tightness (small residual), with a mild bonus
    for bins that are already partially used (remaining < 100), so we consolidate
    into existing bins rather than opening fresh ones.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    residual = bins - item
    # primary: smaller residual is better
    score = -residual.astype(np.float64)
    # small bonus for already-used bins (residual would be < 100 - item means bin already had items)
    used = (bins < 100)
    score += 1e-3 * used
    return score
# EVOLVE-BLOCK-END
