# EVOLVE-BLOCK-START
"""Best-fit with exact-fill bonus.

Pure best-fit (place into the bin with the smallest residual that still
fits) is a strong baseline.  The one clearly-optimal event is an exact
fill (residual 0), so we make that strictly dominant.  Among near-ties
in residual we prefer the *larger* residual, which leaves a bin that is
more likely to be reusable by a future item rather than leaving tiny
unusable slack.
"""
import numpy as np

_TIE_EPS = 1.0
_TIE_WEIGHT = 0.5


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Exact fill is strictly best: give it an overwhelming bonus.
    score = score + 1e6 * (residual == 0)

    if _TIE_EPS > 0.0:
        # Near-ties: among nearly-equal residuals, prefer the larger one
        # (less likely to leave unusable slack).
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * residual * is_near
    return score
# EVOLVE-BLOCK-END

