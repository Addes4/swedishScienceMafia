# EVOLVE-BLOCK-START
"""Dynamic best fit: penalty scaled by observed minimum item size.

Best fit minimises residual, but residuals smaller than the smallest
item we've actually seen cannot be reused, so they are effectively waste.
We track the running minimum item size and apply a graded penalty to
residuals below that threshold, with exact fills always strongly preferred.
"""
import numpy as np

_MIN_ITEM = 100.0  # running minimum item size seen so far


def priority(item, bins):
    global _MIN_ITEM
    if item < _MIN_ITEM:
        _MIN_ITEM = float(item)

    residual = bins - item                      # >= 0 for every bin shown
    res = residual.astype(np.float64)
    score = -res                                # base: best fit

    # Penalise residuals smaller than the smallest observed item: those
    # gaps cannot hold any future item and are pure waste. Graded: the
    # smaller the gap, the larger the penalty.
    thr = _MIN_ITEM
    small = (residual > 0) & (res < thr)
    score -= 4.0 * (thr - res) / thr * small

    return score
# EVOLVE-BLOCK-END
