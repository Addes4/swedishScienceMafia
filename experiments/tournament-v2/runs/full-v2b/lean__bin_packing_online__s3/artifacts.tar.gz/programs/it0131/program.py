# EVOLVE-BLOCK-START
"""Best-fit with an exact-fill bonus.

The item fits into any bin whose remaining capacity is >= item.  Among
those, the classic Best-Fit rule picks the bin with the smallest residual
(bins - item).  Empirically the extra waste-band surcharges and histogram
tie-breaks tried previously added noise and hurt.  We keep pure best-fit
(order by residual) and add a large bonus when the residual would be 0,
so an item that exactly fills a bin is always chosen, which strengthens
tight packing without disturbing the rest of the ordering.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item                 # >= 0 for bins shown
    score = -residual.astype(np.float64)   # tightest fit wins
    # Strong preference for exact fills.
    score += 1000.0 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
