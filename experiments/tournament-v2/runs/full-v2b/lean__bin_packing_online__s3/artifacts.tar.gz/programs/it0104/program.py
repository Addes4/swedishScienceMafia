# EVOLVE-BLOCK-START
"""Online-adaptive best fit.

Primary rule: tightest residual (best fit).  We add two light,
data-driven adjustments so we do not routinely strand tiny unusable
slack:

* We learn the running minimum and the empirical histogram of observed
  item sizes.  A residual below the smallest size seen so far is very
  unlikely to ever be filled, so we penalise it.
* Among near-ties we mildly prefer a residual equal to a frequently
  seen item size (so it can be exactly filled later) and reward exact
  fits (residual == item leaves neither slack nor overflow risk).

All parameters are lightly weighted so the strong best-fit ordering is
preserved; the scheme adapts to the actual item stream.
"""
import numpy as np

_SURCHARGE = 5.0        # penalty for strandable tiny residual
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.06
_MIN_FLOOR = 4.0

# Running empirical statistics over item sizes 1..100.
_size_hist = np.zeros(101, dtype=np.float64)
_count = 0
_min_seen = 100.0


def priority(item, bins):
    global _count, _min_seen

    residual = bins - item
    score = -residual.astype(np.float64)

    # Update online statistics (item size known before choosing bin).
    _count += 1
    _size_hist[item] += 1.0
    if item < _min_seen:
        _min_seen = float(item)

    # Penalise residuals that are too small to be filled by any item
    # likely to appear, using the running minimum (with a small floor to
    # avoid over-penalising when one tiny item has been seen).
    strand = _min_seen if _min_seen > _MIN_FLOOR else _MIN_FLOOR
    waste = (residual > 0) & (residual < strand)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0 and _count > 0:
        # Near-ties: prefer a residual that is a commonly seen item size.
        rc = np.clip(residual, 0, 100).astype(np.int64)
        freq = _size_hist[rc] / _count
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * freq * is_near

    return score
# EVOLVE-BLOCK-END

