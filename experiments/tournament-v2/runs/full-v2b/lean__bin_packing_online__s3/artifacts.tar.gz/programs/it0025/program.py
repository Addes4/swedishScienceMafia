# EVOLVE-BLOCK-START
"""Best fit with a squared thin-slack surcharge.

Pure best-fit is near optimal for this distribution. The residual waste
from best-fit comes from leaving small positive residuals no future item
can use.  We minimise post-placement residual (best fit), penalise small
nonzero residuals quadratically so exact fits dominate, and add a tiny
tiebreaker that prefers the bin which is already the fullest.
"""
import numpy as np

_WASTE_LIMIT = 20.0
_SURCHARGE = 0.03
_FULL_BIAS = 1e-3


def priority(item, bins):
    residual = (bins - item).astype(np.float64)      # >= 0 for all shown bins
    score = -residual
    # Quadratic penalty ramp for small unusable slack.
    waste = np.clip((_WASTE_LIMIT - residual) / _WASTE_LIMIT, 0.0, 1.0)
    score -= _SURCHARGE * waste * waste
    # Tiny tiebreaker: prefer bins that are currently more filled.
    score += _FULL_BIAS * (100.0 - bins.astype(np.float64)) * 1e-3
    return score
# EVOLVE-BLOCK-END

