# EVOLVE-BLOCK-START
"""Best fit with a fillability-aware residual penalty and rotating tie-break.

Pure best-fit leaves small leftovers that no future item can exactly fill,
wasting capacity.  Rather than a flat "waste band", we penalise each
candidate residual r by how hard it would be to fill later: the leftover
after placing the item equals bins_residual - item, and a bin whose leftover
is small relative to typical item sizes is rarely reusable.  We approximate
the probability that a future item exactly matches a leftover res by a simple
monotone model (smaller res or res close to a typical size is more useful),
keeping the tight-fit ordering dominant.  A slow rotating perturbation breaks
near-ties across bin indices.
"""
import numpy as np

_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05
_PENALTY_SCALE = 3.0
_BAND = 22.0

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Fillability penalty: leftovers strictly below _BAND are hard to reuse,
    # with the very smallest (but nonzero) the hardest.  Scale down for big
    # items, which are themselves rare, so the ordering stays best-fit-like.
    r = residual.astype(np.float64)
    small = (r > 0) & (r < _BAND)
    # quadratic-ish shape: worst near 0, easing out toward _BAND
    shape = (1.0 - r / _BAND) ** 2
    scale = _PENALTY_SCALE * (1.0 - 0.4 * (item - 40.0) / 60.0)
    score -= scale * shape * small

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        idx = np.arange(residual.shape[0], dtype=np.float64)
        perturb = ((idx * 2654435761.0 + _state["tick"] * 40503.0) % 1000.0) / 1000.0
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score - _TIE_WEIGHT * perturb * is_near
    return score
# EVOLVE-BLOCK-END
