# EVOLVE-BLOCK-START
"""Best-fit base with a distribution-weighted near-tie break.

Pure best-fit (tightest residual first) is the strongest simple rule
here.  The only deviation allowed is among bins whose residuals are
nearly tied: there we prefer the bin whose leftover residual is most
likely to be exactly filled by a future item, per the known
Weibull-shaped size distribution.
"""
import numpy as np

_TIE_EPS = 1.5
_TIE_WEIGHT = 0.25

_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.max()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100


def priority(item, bins):
    residual = bins - item
    score = -residual.astype(np.float64)

    rc = np.clip(residual, 0, 100).astype(np.int64)
    fill = _FILL[rc]
    is_near = np.abs(score - score.max()) <= _TIE_EPS
    score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END

