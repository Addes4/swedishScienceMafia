# EVOLVE-BLOCK-START
"""Best fit with a decaying waste penalty and exact-fill bonus.

Pure best-fit minimizes the residual after placement. Its failure mode is
stranding a small non-zero residual that few future items can reuse.  We
keep best-fit as the core (score = -residual) but add a penalty that is
largest for residuals just above 0 and decays to 0 as the residual grows
toward a reusable gap size, plus a tiny bonus for an exact fill.
"""
import numpy as np

_REUSE = 20.0        # residuals at/above this are considered reusable
_WEIGHT = 5.0        # strength of the waste penalty
_FILL_BONUS = 0.5    # reward for exactly filling a bin


def priority(item, bins):
    residual = bins - item                    # >= 0 for every bin shown
    r = residual.astype(np.float64)
    score = -r                                # base: tightest fit wins
    # Decaying penalty for stranding a small (hard-to-reuse) residual.
    small = (r > 0.0) & (r < _REUSE)
    score -= _WEIGHT * small * (1.0 - r / _REUSE)
    # Bonus for exactly filling a bin.
    score += _FILL_BONUS * (r == 0.0)
    return score
# EVOLVE-BLOCK-END

