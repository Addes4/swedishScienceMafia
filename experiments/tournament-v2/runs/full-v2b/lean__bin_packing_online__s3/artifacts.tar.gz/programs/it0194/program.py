# EVOLVE-BLOCK-START
"""Best-fit backbone with an online adaptive fillability tie-break.

The residual-minimizing (best-fit) rule is a strong backbone for this
distribution.  The only hope for improvement is smarter tie-breaking
when several residuals are close.  Rather than assuming a fixed Weibull
shape, we track the empirically observed item sizes online with an
exponentially decaying histogram, then use its value at a candidate
post-placement residual as a tiny bonus so that leftovers that future
items are *actually* likely to fit are preferred.
"""
import numpy as np

_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05
_DECAY = 0.995

# Online decaying histogram of observed item sizes (index 1..100).
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0

# Fallback static prior (smooth Weibull-like) so early decisions are sane.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PRIOR = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PRIOR = np.concatenate(([0.0], _PRIOR))
_PRIOR = _PRIOR / max(_PRIOR.mean(), 1e-12)

_state = {"tick": 0}


def priority(item, bins):
    global _hist, _count
    # Update the online size histogram (decay then add current item).
    _hist *= _DECAY
    _hist[item] += 1.0
    _count = _count * _DECAY + 1.0

    residual = bins - item
    score = -residual.astype(np.float64)
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0:
        # Fillability: blend the online histogram (normalized) with the prior.
        denom = max(_hist.sum(), 1e-12)
        emp = _hist / denom * 100.0  # scale roughly like a count over sizes
        fill = (emp + 0.5 * _PRIOR) / 1.5
        rc = np.clip(residual, 0, 100).astype(np.int64)
        f = fill[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * f * is_near
    return score
# EVOLVE-BLOCK-END
