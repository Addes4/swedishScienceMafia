# EVOLVE-BLOCK-START
"""Best-fit with exact-perfect-fit preference and dead-slack penalty.

Pure best-fit (tightest residual) is a strong online rule.  Two small,
robust refinements:
 - prefer a bin whose residual exactly equals the arriving item size, so
   the bin can be perfectly filled (avoiding a stranded leftover);
 - mildly penalise residuals of 1..3, which are too small to ever be
   filled by a future item under the given size distribution.
No reliance on a fragile PDF histogram or near-tie windows.
"""
import numpy as np

_DEAD_LIMIT = 3       # residuals in 1.._DEAD_LIMIT are effectively wasted
_DEAD_PENALTY = 2.0
_PERFECT_BONUS = 1.0  # tiny bonus so exact-perfect-fit wins ties


def priority(item, bins):
    residual = bins - item                      # >= 0 for all shown bins
    score = -residual.astype(np.float64)        # base: tightest fit wins

    dead = (residual > 0) & (residual <= _DEAD_LIMIT)
    score -= _DEAD_PENALTY * dead

    perfect = residual == 0
    score += _PERFECT_BONUS * perfect

    return score
# EVOLVE-BLOCK-END
