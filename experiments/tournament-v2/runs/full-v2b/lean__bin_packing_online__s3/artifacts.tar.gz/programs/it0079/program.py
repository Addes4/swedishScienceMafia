# EVOLVE-BLOCK-START
"""Threshold-aware best fit without noisy tie-breaking.

Best-fit tends to create tiny unusable leftovers.  We rank bins primarily by
residual, apply a mild surcharge to residuals in a small waste band, and add
a flat reward for exact fits.  We keep the ranking deterministic (no random
perturbation): near-ties are broken by what best serves the future, namely
the smaller residual, so we simply order by residual with a fixed tie rule.
"""
import numpy as np

_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_EXACT_BONUS = 2.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise residuals that are small but non-zero (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste
    # Reward exact fits a little extra.
    score += _EXACT_BONUS * (residual == 0)
    return score
# EVOLVE-BLOCK-END

