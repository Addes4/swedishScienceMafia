# EVOLVE-BLOCK-START
"""Best-fit backbone with a mid-residual preference for near-ties.

Pure best fit (score = -residual) is a strong baseline.  Many bins end up
with tiny leftovers (1..20) that no future item can exactly fill, wasting
capacity.  Among bins whose residual is *not* extremely tight, prefer the
one whose leftover is nearest a typical item size (~40): such a leftover
is more likely to be absorbed by a future mid-sized item, reducing the
number of stranded small gaps.  Exact fills (residual 0) still dominate.
"""
import numpy as np

_TARGET = 40.0      # typical item size from the Weibull-shaped distribution
_TIE_EPS = 2.0      # residual window considered a near-tie
_TIE_WEIGHT = 0.35  # weight on the mid-residual preference

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Strong bonus for an exact fill (leftover becomes 0).
    score += 1000.0 * (residual == 0)

    if _TIE_EPS > 0.0:
        # Among near-ties, prefer leftovers near a typical item size,
        # which are more likely to be usable by future items.
        _state["tick"] += 1
        near = residual <= (residual.min() + _TIE_EPS)
        pref = -np.abs(residual.astype(np.float64) - _TARGET) / 100.0
        score = score + _TIE_WEIGHT * pref * near

    return score
# EVOLVE-BLOCK-END
