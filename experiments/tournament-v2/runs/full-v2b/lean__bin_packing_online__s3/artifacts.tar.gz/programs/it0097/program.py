# EVOLVE-BLOCK-START
"""Best-fit with a waste-band surcharge that scales with the residual.

Pure best fit minimizes residual, which is usually near-optimal for this
distribution, but it sometimes leaves a small unusable slack.  We keep the
tight-fit ordering by residual and add a mild surcharge for residuals in a
"waste" band just above zero, scaled by the residual size so that tiny
slacks are penalized least and nearly-wasted bins are avoided.  A small
near-tie fillability bonus (static Weibull prior) is kept to break ties in
favor of a residual a future item can exactly fill.
"""
import numpy as np

_WASTE_LIMIT = 20.0
_SURCHARGE = 0.5   # per unit of residual inside the waste band
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item
    score = -residual.astype(np.float64)
    # Scale surcharge by residual: penalize larger slacks more within the band.
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * residual * waste

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _FILL[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
