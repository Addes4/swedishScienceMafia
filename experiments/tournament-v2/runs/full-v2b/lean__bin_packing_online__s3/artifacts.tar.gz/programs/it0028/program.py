# EVOLVE-BLOCK-START
"""Best-fit with a reserved-space term based on the item distribution.

Pure best-fit strands bins with residuals too small for future items.
Here we keep best-fit as the core (minimize residual), but add a small
bonus to bins whose post-placement residual stays at or above the mean
item size (~40), so mid-sized future items can still use them, while
exact fills (residual 0) also get a bonus.
"""
import numpy as np

_MEAN_ITEM = 40.0
_RESERVE_BONUS = 0.5
_FULL_BONUS = 1.0


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    score = -residual.astype(np.float64)        # base: tightest fit wins
    # Bonus for keeping a reusable residual at/above typical item size.
    usable = residual >= _MEAN_ITEM
    score += _RESERVE_BONUS * usable
    # Bonus for exactly filling a bin.
    score += _FULL_BONUS * (residual == 0)
    return score
# EVOLVE-BLOCK-END

