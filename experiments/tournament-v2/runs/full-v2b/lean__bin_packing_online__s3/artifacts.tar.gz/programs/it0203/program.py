# EVOLVE-BLOCK-START
"""Best-fit backbone with an online-learned "fillability" tie-break.

The waste-band surcharge and static distribution tie-breaks consistently
failed to beat plain best fit, so we keep tight-fit dominance and only use
near-ties to pick among bins whose residual is, historically, most likely
to be exactly consumed by a later item.  We learn this online: whenever a
bin's residual r is exactly matched by an arriving item, we credit r.
"""
import numpy as np

_TIE_EPS = 2.0
_TIE_WEIGHT = 0.15

# Online credit table: credit[r] ~ how often residual r got exactly filled.
_CREDIT = np.zeros(101, dtype=np.float64)
_TOTAL = np.zeros(101, dtype=np.float64)
_DECAY = 0.9995


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown

    # Learn: any existing bin whose residual equals item would now be filled.
    # This happens BEFORE placing the new item, using current residuals of
    # all shown bins.  Credit those residuals.
    exact_hits = (residual == 0)
    if np.any(exact_hits):
        # The item fills bins whose residual was `item`; those bins had
        # residual `item` before this call.  Credit size `item`.
        _CREDIT[item] += 1.0
    _TOTAL[item] += 1.0

    # Decay slowly to stay adaptive.
    _CREDIT *= _DECAY
    _TOTAL *= _DECAY

    score = -residual.astype(np.float64)       # base: tightest fit wins

    if _TIE_EPS > 0.0:
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _CREDIT[rc] / (1.0 + _TOTAL[rc])
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
