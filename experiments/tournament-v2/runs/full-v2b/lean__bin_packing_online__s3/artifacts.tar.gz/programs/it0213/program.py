# EVOLVE-BLOCK-START
"""Best-fit backbone with a smooth residual-utility term.

Best fit (tightest residual) is a strong online rule, but it can leave
slivers too small for any future item.  We keep tight-fit as the dominant
term and add a bounded, continuous utility for the *new* residual:

  - residuals that are 0 are slightly penalised against being "wasted"
    is avoided: exact fills are always good, so no penalty.
  - residuals below the minimum usable size are penalised (unusable).
  - residuals that can host a typical item (large) get a mild bonus.

The term is smooth (no hard bands), scaled well below the residual term
so it only re-ranks genuine near-ties.
"""
import numpy as np

# Dominant weight: 1 unit of residual outweighs any utility difference.
_RES_W = 1.0
# Utility magnitude (kept small so it only breaks near-ties).
_UTIL_W = 0.35

# Smallest item size we ever expect (items are >= 1, but useful slivers
# must be at least this to host a typical small item).
_MIN_USABLE = 8.0
# Characteristic scale for the "reusable" bonus.
_SCALE = 30.0


def priority(item, bins):
    residual = bins - item
    r = residual.astype(np.float64)          # >= 0 for every bin shown
    score = -_RES_W * r                      # tight fit dominates

    # Smooth penalty for tiny unusable slivers (0 is fine: exact fill).
    # sigmoid-like barrier that is ~1 at r=0+ and fades out near _MIN_USABLE.
    tiny = np.exp(-r / _MIN_USABLE)          # 1 at r=0, ~0.37 at r=_MIN_USABLE
    sliver = (r > 0.0) * tiny                # penalise non-zero slivers only
    # Mild bonus for having plenty of reusable room (favours keeping bins open).
    reusable = r / (r + _SCALE)

    score = score - _UTIL_W * sliver + _UTIL_W * reusable
    return score
# EVOLVE-BLOCK-END
