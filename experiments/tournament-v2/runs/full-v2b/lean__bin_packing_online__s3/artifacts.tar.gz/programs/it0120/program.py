# EVOLVE-BLOCK-START
"""Best fit with online tracked minimum item size.

Base rule is pure best-fit (smallest residual after placement).  On top of
that, we add a small penalty for leaving a positive residual that is
strictly smaller than the smallest item size seen so far, because such a
residual cannot be filled by any item observed yet.  The threshold is
learned online from the stream, so it adapts to the actual distribution
instead of a fixed waste band.
"""
import numpy as np

_PENALTY = 4.0

_state = {"min_item": 101}


def priority(item, bins):
    if item < _state["min_item"]:
        _state["min_item"] = item

    residual = bins - item
    score = -residual.astype(np.float64)   # pure best-fit base

    thr = _state["min_item"]
    if thr > 1:
        waste = (residual > 0) & (residual < thr)
        score -= _PENALTY * waste

    return score
# EVOLVE-BLOCK-END
