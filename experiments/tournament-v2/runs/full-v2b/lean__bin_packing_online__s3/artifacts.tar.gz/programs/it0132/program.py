# EVOLVE-BLOCK-START
"""Best fit with a targeted exact-fill reinforcement.

Prior experiments showed that extra surcharges and tie-breaks (static
PDF fillability, waste bands, least-load nudges) consistently hurt.
The one reliable signal is an exact fill: if some bin's residual equals
the incoming item size, placing it there loses nothing and frees a slot
that would otherwise be wasted.  We therefore rank primarily by tightest
residual (classic Best Fit) and boost only the exact-match bins.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Reinforce exact fills: residual == item means a perfect pack.
    score += (residual == item) * 5.0
    return score
# EVOLVE-BLOCK-END
