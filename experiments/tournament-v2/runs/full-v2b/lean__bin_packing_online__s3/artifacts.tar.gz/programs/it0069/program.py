# EVOLVE-BLOCK-START
"""Best fit with a dead-slack penalty.

Classic best fit (tightest residual) tends to leave small leftovers that no
future item can fit.  Rather than penalising a wide band (which biases away
from tight fits and hurts the score), we strongly penalise only residuals
that are truly "dead": below a small threshold where essentially no item from
the Weibull-shaped distribution (mean ~40) will land.  Everything else is
governed by pure tightness, preserving best-fit quality.
"""
import numpy as np

# Residuals strictly below this can rarely be filled by a future item.
_DEAD_LIMIT = 4.0
_DEAD_PENALTY = 8.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Strongly discourage leaving dead slack no future item can use.
    dead = (residual > 0) & (residual < _DEAD_LIMIT)
    score -= _DEAD_PENALTY * dead
    return score
# EVOLVE-BLOCK-END
