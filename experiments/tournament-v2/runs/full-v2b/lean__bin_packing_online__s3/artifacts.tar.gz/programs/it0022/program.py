# EVOLVE-BLOCK-START
"""Best fit with a small surcharge on unusable residuals.

Pure best-fit (minimize post-placement residual) is a strong online rule
for this distribution.  Its main weakness is stranding a tiny positive
residual (e.g. 1..13) that few or no remaining items can use.  We keep
best-fit as the core and add a modest penalty to residuals inside a
"hard to reuse" band, so bins that end exactly full or leave a
comfortably reusable gap are preferred.
"""
import numpy as np

# Residuals strictly between 0 and this value are treated as hard-to-reuse slack.
_WASTE_LIMIT = 14.0
_SURCHARGE = 4.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise residuals that are small but non-zero (hard-to-reuse slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste
    return score
# EVOLVE-BLOCK-END
