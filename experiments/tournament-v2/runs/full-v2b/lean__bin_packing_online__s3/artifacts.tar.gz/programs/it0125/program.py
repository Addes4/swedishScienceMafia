# EVOLVE-BLOCK-START
"""Best fit with load-aware near-tie break.

Pure best-fit picks the tightest residual, but when several bins leave
essentially the same residual, choosing the one with the most remaining
free space (after placement) tends to keep large bins available and
reduces fragmentation.  We keep the tight-fit ordering by residual and
break only near-ties by favoring the bin that ends up with the largest
post-placement residual among the tied candidates.
"""
import numpy as np

_TIE_EPS = 1.0

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    if _TIE_EPS > 0.0:
        # Near-ties in residual: prefer the bin that, after placement,
        # retains the largest residual (most free space).
        _state["tick"] += 1
        is_near = np.abs(residual - residual.min()) <= _TIE_EPS
        score = score - 0.01 * residual * is_near
    return score
# EVOLVE-BLOCK-END

