# EVOLVE-BLOCK-START
"""Best fit with a harmonic-inspired residual preference.

Best fit (tightest residual) is a strong backbone for online packing of
Weibull-shaped sizes.  Pure best fit, however, will happily fill a bin
until a tiny unusable sliver remains.  Harmonic packing groups residuals
into size classes and prefers to consume the smaller class before the
larger one so that bins are either mostly full or mostly empty.

We approximate that idea here with a strict best-fit backbone plus a
small bonus that rewards leaving a residual of exactly zero (perfect
fill) or a residual in the upper half of the capacity, which keeps bins
in useful states without a discontinuous waste band.
"""
import numpy as np

_TIE_EPS = 1.0
_FILL_BONUS = 0.30
_HALF_BONUS = 0.10


def priority(item, bins):
    residual = bins - item
    score = -residual.astype(np.float64)

    # Small bonus for a near-tie region only, to avoid disturbing the
    # strong best-fit ordering.
    if _TIE_EPS > 0.0:
        near = np.abs(residual - residual.min()) <= _TIE_EPS
        bonus = np.zeros_like(score)
        bonus += _FILL_BONUS * (residual == 0)
        bonus += _HALF_BONUS * (residual >= 50) * (residual > 0)
        score = score + bonus * near
    return score
# EVOLVE-BLOCK-END
