# EVOLVE-BLOCK-START
"""Best fit with an online-learned residual-fillability tie-break.

Base rule is tightest-fit (best fit).  Near-ties in residual are broken
by preferring a leftover residual that is likely to be exactly filled by
a future item, where "likely" is estimated online from the empirical
distribution of item sizes actually observed so far.  A separate small
bonus rewards exactly completing a bin (residual == item).
"""
import numpy as np

_TIE_EPS = 1.0
_TIE_WEIGHT = 0.6
_EXACT_BONUS = 0.4

_state = {"counts": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    residual = bins - item
    score = -residual.astype(np.float64)

    counts = _state["counts"]
    n = _state["n"]
    if n > 0:
        # empirical probability that a future item exactly equals residual r
        fill = counts / n
    else:
        fill = counts  # all zeros

    if _TIE_EPS > 0.0:
        rc = np.clip(residual, 0, 100).astype(np.int64)
        f = fill[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * f * is_near

    exact = residual == item
    score = score + _EXACT_BONUS * exact

    # update online histogram with the current item
    if 1 <= item <= 100:
        counts[item] += 1.0
        _state["n"] = n + 1.0

    return score
# EVOLVE-BLOCK-END
