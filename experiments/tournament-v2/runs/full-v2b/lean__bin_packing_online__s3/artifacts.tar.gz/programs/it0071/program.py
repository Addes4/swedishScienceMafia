# EVOLVE-BLOCK-START
"""Best fit with an exact/near-exact fit reward.

Pure best-fit orders bins by residual (smallest gap wins). The subtle loss
comes from the many near-ties around small residuals: filling a bin exactly
(residual 0) or leaving only a trivially small gap frees a bin from the pool,
which is strictly better than leaving a moderately usable gap.  We therefore
keep tightest-residual as the base ordering but add a strong, sharply-decaying
bonus for residuals near zero, so exact fits and tiny leftovers dominate.
"""
import numpy as np

_EXACT_BONUS = 8.0   # extra reward for residual == 0
_TINY_LIMIT = 4.0    # residuals below this are nearly as good as exact
_TINY_SLOPE = 2.0    # bonus decays linearly toward _TINY_LIMIT


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    r = residual.astype(np.float64)
    score = -r                                 # base: tightest fit wins

    # Strong bonus for exactly filling a bin.
    score += _EXACT_BONUS * (r == 0.0)

    # Linear bonus for tiny, effectively unusable gaps, tapering to 0.
    small = (r > 0.0) & (r < _TINY_LIMIT)
    score += _TINY_SLOPE * small * (_TINY_LIMIT - r)

    return score
# EVOLVE-BLOCK-END
