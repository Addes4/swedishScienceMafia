# EVOLVE-BLOCK-START
"""Almost-best-fit with large-item protection.

Large items (>= _SPLIT) are better packed by reserving bins with large
residuals for them; small items can go anywhere.  We implement this by
giving a bonus to bins whose residual is >= _SPLIT when the current item
is large, keeping tightest-fit as the primary criterion otherwise.
"""
import numpy as np

_SPLIT = 50
_LARGE_BONUS = 3.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    if item >= _SPLIT:
        # Encourage large items to use bins with large remaining space,
        # keeping tightest-fit as the dominant term but nudging upward.
        big = residual >= _SPLIT
        score += _LARGE_BONUS * big

    return score
# EVOLVE-BLOCK-END

