# EVOLVE-BLOCK-START
"""Best fit with a wide near-tie band broken by an online fillability model.

Best fit (tightest residual) is the strong backbone.  Small residuals
just above 0 can be wasted, so we apply a modest surcharge to the
unusable slack band.  Crucially, near-ties in residual are broken by
preferring residuals that a *recently observed* item size could fill
exactly, using an exponentially decaying histogram of past item sizes.
This adapts to the true item-size distribution instead of a guessed
parametric form.
"""
import numpy as np

_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_TIE_EPS = 2.0
_TIE_WEIGHT = 0.05
_DECAY = 0.999

_state = {
    "hist": np.zeros(101, dtype=np.float64),  # index by size 1..100
}

# Static smooth prior blended with the online histogram so early calls
# still have a sensible fillability signal.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_PRIOR = np.concatenate(([0.0], _PDF))  # index by residual/size 1..100
_PRIOR_WEIGHT = 200.0


def priority(item, bins):
    hist = _state["hist"]
    hist *= _DECAY
    hist[item] += 1.0

    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0:
        fill = _PRIOR + hist / _PRIOR_WEIGHT
        rc = np.clip(residual, 0, 100).astype(np.int64)
        f = fill[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * f * is_near
    return score
# EVOLVE-BLOCK-END
