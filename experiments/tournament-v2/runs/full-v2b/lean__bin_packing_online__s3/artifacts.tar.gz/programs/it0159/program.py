# EVOLVE-BLOCK-START
"""Best-fit flavored by expected future usability of leftover slack.

Pure best-fit leaves behind small residual gaps that later items can
rarely fill.  We keep a strong tightness term (tighter residual wins) so
we still behave like best-fit, but add a small bonus proportional to the
probability that the leftover residual can still fit a future item,
estimated from the known Weibull-shaped size distribution.  This nudges
near-ties toward bins whose slack is more likely to be usable, without
overriding genuine fit-quality differences.
"""
import numpy as np

# Weibull-shaped size distribution over item sizes 1..100 (mean ~40).
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_CDF = 1.0 - np.exp(-(_SIZE / _SCALE) ** _LAMBDA)   # P(item <= r)
# Probability that a future item fits in residual r is P(item <= r).
# (items larger than r cannot fit; approximate, monotone increasing)
_FITPROB = np.concatenate(([0.0], _CDF))             # index by residual 1..100

_TIGHT_WEIGHT = 1.0
_USABLE_WEIGHT = 3.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -_TIGHT_WEIGHT * residual.astype(np.float64)  # tightest fit wins
    # Bonus: how likely the leftover slack can still accept a future item.
    rc = np.clip(residual, 0, 100).astype(np.int64)
    score += _USABLE_WEIGHT * _FITPROB[rc]
    return score
# EVOLVE-BLOCK-END

