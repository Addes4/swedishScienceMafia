# EVOLVE-BLOCK-START
"""Best fit with an adaptive unusable-slack penalty.

Pure best-fit (smallest residual) is a strong online rule.  Its main
weakness is creating small non-zero residuals that no future item can
fill.  We keep tightest-residual as the base ordering, but add a
penalty for residuals that are small relative to the *current* item
size and to the observed item-size distribution.  The penalty grows as
the residual shrinks toward 0 and is capped, so true exact fits (0) and
clearly-usable residuals are unaffected.  All statistics are learned
online; nothing is tuned to a single instance.
"""
import numpy as np

_state = {"n": 0, "sizes": np.zeros(5000, dtype=np.int64), "min_recent": 100}


def priority(item, bins):
    residual = bins - item                       # >= 0 for bins shown
    score = -residual.astype(np.float64)         # base: tightest fit wins

    # Track observed item sizes to estimate a practical unusable-slack
    # threshold.  Use a running minimum of recent small items as a proxy
    # for the smallest item likely to appear again.
    n = _state["n"]
    if n < 5000:
        _state["sizes"][n] = item
    _state["n"] = n + 1
    if item < _state["min_recent"] and item > 0:
        _state["min_recent"] = item

    # Threshold scales with the current item: bigger items tolerate bigger
    # residuals, but residuals below the learned minimum usable size are
    # pure waste regardless.
    thr = max(float(item) * 0.35, float(_state["min_recent"]))

    # Smooth penalty: highest at residual just above 0, fading to 0 at thr.
    # Exact fits (residual 0) get no penalty.  Weight is modest so it only
    # overrides near-ties in the tight-fit ordering.
    r = residual.astype(np.float64)
    mask = (r > 0) & (r < thr)
    if mask.any():
        frac = 1.0 - (r[mask] / thr)             # 1 near 0, 0 at thr
        score[mask] -= 3.0 * frac

    return score
# EVOLVE-BLOCK-END
