# EVOLVE-BLOCK-START
"""Adaptive waste-aware best fit with hashed near-tie break.

Best-fit tends to leave small slivers (residual 1..K) that no future item
can reuse.  We keep the tight-fit ordering, add a surcharge on residuals in
a waste band, and additionally scale that surcharge by the item size so the
penalty for creating a sliver is larger when placing bigger items (a big
item committing to a bin is more consequential).  Exact fits are never
penalized.  A stateful hashed tie-break avoids always resolving near-ties
to the lowest bin index.
"""
import numpy as np

_WASTE_LIMIT = 22.0
_SURCHARGE = 6.0
_SIZE_SCALE = 0.04
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise residuals that are small but non-zero (unusable slack),
    # scaled up for larger items.
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= (_SURCHARGE + _SIZE_SCALE * item) * waste

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        idx = np.arange(residual.shape[0], dtype=np.float64)
        perturb = ((idx * 2654435761.0 + _state["tick"] * 40503.0) % 1000.0) / 1000.0
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score - _TIE_WEIGHT * perturb * is_near
    return score
# EVOLVE-BLOCK-END
