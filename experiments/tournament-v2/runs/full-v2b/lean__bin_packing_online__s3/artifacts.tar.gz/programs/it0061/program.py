# EVOLVE-BLOCK-START
"""Pure best-fit with an exact-fill bonus and a stable tie-break.

Classic best-fit (smallest residual that still fits) is the strongest simple
baseline here.  The only refinements: strongly prefer bins that this item
closes exactly (residual 0), and resolve remaining exact ties by a stable
per-bin hash instead of always taking the lowest index, without any random
perturbation that could disturb the tight-fit ordering.
"""
import numpy as np

_TIE_EPS = 1e-9


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    score = -residual.astype(np.float64)        # base: tightest fit wins
    # Strong bonus for exact fills (closing a bin cleanly).
    score += 2.0 * (residual == 0)
    # Stable, state-free tie-break: tiny deterministic hash of bin index so
    # equal-scoring bins do not always resolve to the lowest index.
    idx = np.arange(residual.shape[0], dtype=np.float64)
    tie = ((idx * 2654435761.0) % 1000.0) / 1000.0
    is_near = np.abs(score - score.max()) <= _TIE_EPS
    score = score - 0.01 * tie * is_near
    return score
# EVOLVE-BLOCK-END

