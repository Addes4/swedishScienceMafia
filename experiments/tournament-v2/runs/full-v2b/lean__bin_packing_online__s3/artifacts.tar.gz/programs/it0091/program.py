# EVOLVE-BLOCK-START
"""Threshold-aware best fit with histogram-guided near-tie break.

Pure best-fit often creates a bin whose small leftover (say 3..18) no
future item can use, wasting capacity.  We keep the tight-fit ordering
by residual, but instead of a hard flat surcharge over a fixed waste
band we use a smooth penalty curve over the residual derived from the
Weibull-shaped item-size distribution: residuals that are unlikely to
be exactly fillable are penalized, residuals that match common item
sizes are lightly favored.  Near-ties in residual are additionally
broken by preferring the bin whose leftover residual is a likely future
item size.
"""
import numpy as np

_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05
_PENALTY_WEIGHT = 3.0

# Static histogram over item sizes 1..100 (mean ~40, Weibull-shaped).
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()

# Smooth penalty curve over residuals 0..100: high where the residual is
# unlikely to be exactly fillable, low at common item sizes.
# Use a smoothed (convolved) version of the PDF as "fillability".
_k = np.array([0.25, 0.5, 0.25])
_fill = np.convolve(_PDF, _k, mode="same")
_fill = _fill / _fill.max()
# penalty = 1 - fillability, but fade out for very large residuals which
# are still useful (they can host many future items).
_PEN = np.concatenate(([0.0], 1.0 - _fill))  # index by residual 1..100
# Taper the penalty to zero as residual grows past ~50.
_taper = np.linspace(1.0, 0.0, 101)
_taper = np.clip((50.0 - np.arange(0, 101)) / 50.0, 0.0, 1.0)
_PEN = _PEN * _taper

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    rc = np.clip(residual, 0, 100).astype(np.int64)
    score -= _PENALTY_WEIGHT * _PEN[rc]        # smooth waste penalty

    if _TIE_EPS > 0.0:
        # Near-ties: prefer a leftover residual that is likely to be
        # exactly fillable by a future item.
        _state["tick"] += 1
        fill = np.concatenate(([0.0], _fill))[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END

