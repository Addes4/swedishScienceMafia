# EVOLVE-BLOCK-START
"""Best fit with a graded waste surcharge.

Pure best fit creates leftover gaps that are too small for future items.
Rather than a flat surcharge over a fixed band, we penalize residuals that
fall in a "hard to fill" region with a weight that decreases as the
residual grows: a residual of 1-2 is essentially pure waste, while a
residual near 15-25 is still potentially usable.  This keeps the strong
tight-fit ordering (best fit) while gently discouraging truly wasteful
placements.
"""
import numpy as np

# Residuals at or below this are considered too small to be useful.
_WASTE_LIMIT = 25.0
_SURCHARGE = 8.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

# Static histogram over item sizes 1..100 (mean ~40, Weibull-shaped),
# used only as a relative "fillability" weight for residuals.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Graded penalty: full near 0, fading to 0 at _WASTE_LIMIT.
    r = residual.astype(np.float64)
    in_band = (r > 0) & (r < _WASTE_LIMIT)
    # weight 1 at r=0+ down to 0 at r=_WASTE_LIMIT
    weight = np.where(in_band, 1.0 - r / _WASTE_LIMIT, 0.0)
    score -= _SURCHARGE * weight

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _FILL[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END

