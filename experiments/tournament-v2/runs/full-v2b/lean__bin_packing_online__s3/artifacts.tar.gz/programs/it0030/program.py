# EVOLVE-BLOCK-START
"""Best-fit with a soft penalty for stranding unusable residuals.

Pure best-fit minimizes the leftover after placement. But a leftover in a
"dead band" (small but nonzero, e.g. 1..25 on this capacity-100 / mean-40
distribution) is almost never reusable, whereas leaving a residual of 0
(exact fill) or a fairly large gap is much better.  We use best-fit as the
core rule but add:
  * a large bonus when the placement makes the bin exactly full, and
  * a mild penalty when the resulting residual lands in the small dead band,
scaled/swept to be strong enough to matter without overriding the primary
tightness ordering.
"""
import numpy as np

_THRESHOLD = 25.0    # residuals below this are deemed mostly unusable
_MAXPEN = 4.0        # penalty at residual just above 0, decays to 0 at threshold


def priority(item, bins):
    residual = bins - item                       # >= 0 for bins shown
    r = residual.astype(np.float64)
    # Primary: tightest fit (best fit).
    score = -r
    # Dead-band penalty: strongest near 0, fading out at the threshold.
    band = (r > 0) & (r < _THRESHOLD)
    score -= _MAXPEN * (1.0 - r / _THRESHOLD) * band
    # Reward exact fills so they strictly dominate near-ties.
    score += 1.0 * (r == 0)
    return score
# EVOLVE-BLOCK-END

