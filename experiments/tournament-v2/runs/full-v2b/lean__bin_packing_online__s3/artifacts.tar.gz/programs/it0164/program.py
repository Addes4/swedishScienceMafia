# EVOLVE-BLOCK-START
"""Adaptive best-fit with running-mean-guided waste surcharge.

Pure best-fit creates bins whose small leftover slack can never be used.
The size of "useless" slack depends on the item-size scale, so instead of
a fixed band we adapt the surcharge to the running mean of observed item
sizes.  Near-ties are broken by preferring a leftover residual that is a
likely future item size (around the running mean), so the bin can still be
completed by a single average item.
"""
import numpy as np

# Adaptivity state.
_state = {"count": 0.0, "sum": 0.0}

# Surcharge strength relative to the adaptive scale.
_SURCHARGE = 6.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05


def priority(item, bins):
    s = _state
    s["count"] += 1.0
    s["sum"] += float(item)
    mean = s["sum"] / s["count"]

    # Adaptive waste band: anything below ~0.45 * mean is hard to reuse.
    waste_limit = max(4.0, 0.45 * mean)
    # Typical target residual we'd like to leave: roughly one mean item.
    target = mean

    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    waste = (residual > 0) & (residual < waste_limit)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0:
        # Near-ties: prefer a residual close to a typical future item size.
        near = np.abs(score - score.max()) <= _TIE_EPS
        # Gaussian-shaped fillability around the running mean.
        fill = np.exp(-((residual - target) ** 2) / (2.0 * (0.5 * mean) ** 2))
        score = score + _TIE_WEIGHT * fill * near

    return score
# EVOLVE-BLOCK-END
