# EVOLVE-BLOCK-START
"""Best-fit backbone with a smooth residual-utility bonus.

Pure best-fit is a strong baseline (tight fit minimises current waste),
but among residuals it can leave a leftover that no future item can fill.
We add a small, smoothly-varying bonus proportional to the probability
that a leftover residual r matches a future item size, using the known
Weibull-shaped item distribution.  The bonus is small relative to the
unit step in residual, so tight-fit dominance is preserved while
near-equal choices favour fillable leftovers.
"""
import numpy as np

# Static histogram over item sizes 1..100 (mean ~40, Weibull-shaped).
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
# index residual 0..100 -> fillability weight
_FILL = np.concatenate(([0.0], _PDF))

# Bonus magnitude: below 1.0 so it only breaks near-ties in residual.
_BONUS = 0.30

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                       # >= 0 for every bin shown
    score = -residual.astype(np.float64)         # base: tightest fit wins
    if _BONUS > 0.0:
        rc = np.clip(residual, 0, 100).astype(np.int64)
        score = score + _BONUS * _FILL[rc]
    return score
# EVOLVE-BLOCK-END
