# EVOLVE-BLOCK-START
"""Best fit with a legibility-utility residual score.

For a bin with residual r = remaining - item, the marginal cost of leaving
slack r is roughly the number of future items that will *not* fit.  Classic
best-fit minimizes r, which is optimal-ish when items are tiny, but for
Weibull(mean~40) items a leftover r only matters if r is large enough to
still host a typical future item; small nonzero r is pure waste.  So we score
by -g(r) where g(r) is a utility that equals the residual cost:

    g(r) = r                for r >= mean_item   (usable gap)
    g(r) = r  but penalised for 0 < r < mean     (partly wasted slack)
    g(r) = 0                for r == 0            (perfect fit)

Concretely we use g(r) = r - C * (r>0) * (r < MEAN) * (1 - r/MEAN),
which keeps tight-fit ordering, rewards exact fits, and softly pushes the
binary rule toward residuals that are either 0 or big enough to matter.
Ties are broken by a slow rotating hash so no bin index dominates.
"""
import numpy as np

_MEAN = 40.0
_C = 8.0          # strength of the small-slack penalty
_TIE_EPS = 1e-9
_TIE_WEIGHT = 0.02

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                          # >= 0
    r = residual.astype(np.float64)

    score = -r                                      # tightest fit dominant

    # Penalise "partly wasted" slack: small but nonzero residuals.
    mid = (r > 0.0) & (r < _MEAN)
    score -= _C * (1.0 - r / _MEAN) * mid

    # Exact fits get a decisive bonus (closing the bin is always good).
    score += 1000.0 * (r == 0.0)

    # Deterministic rotating tie-break among exact ties only.
    if _TIE_WEIGHT > 0.0:
        _state["tick"] += 1
        idx = np.arange(r.shape[0], dtype=np.float64)
        perturb = ((idx * 2654435761.0 + _state["tick"] * 40503.0) % 1024.0) / 1024.0
        is_tie = np.abs(score - score.max()) <= _TIE_EPS
        score = score - _TIE_WEIGHT * perturb * is_tie
    return score
# EVOLVE-BLOCK-END
