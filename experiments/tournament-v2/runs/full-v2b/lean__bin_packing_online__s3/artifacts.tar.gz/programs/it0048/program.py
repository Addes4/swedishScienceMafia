# EVOLVE-BLOCK-START
"""Best fit with strong exact-fit preference and unusable-slack penalty.

Items are integers in 1..100.  Pure best-fit minimises residual, but often
strands a tiny residual (say 1..19) that no future item can use, wasting the
bin.  We keep the tightest-fit base ordering, then:
  * give a large bonus for an exact fit (residual 0), and
  * penalise small non-zero residuals that are unlikely to be reusable.
Ties fall back to the earliest bin, matching the harness rule.
"""
import numpy as np

# Residuals strictly between 0 and this are treated as near-useless slack.
_WASTE_LIMIT = 16.0
_SURCHARGE = 8.0
_EXACT_BONUS = 4.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise small non-zero residuals (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste
    # Reward exact fits so a perfectly filled bin beats a sliver leftover.
    score += _EXACT_BONUS * (residual == 0)
    return score
# EVOLVE-BLOCK-END
