# EVOLVE-BLOCK-START
"""Adaptive waste-band best fit.

Future items are unknown, but the smallest item seen so far gives a lower
bound on what can still fit.  A residual strictly below the smallest item
observed so far can never be filled again (assuming sizes don't go below
the running min), so it is treated as lost capacity and penalized hard.
A milder penalty applies just above it because small-but-usable gaps are
still less useful than large ones.
"""
import numpy as np

# Running minimum item size seen so far (lower bound for future items).
_min_item = [100.0]
_SURCHARGE = 8.0
_NEAR = 1.5


def priority(item, bins):
    if item < _min_item[0]:
        _min_item[0] = float(item)
    lo = _min_item[0]
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Residuals below the smallest possible future item are permanently wasted.
    waste = (residual > 0) & (residual < lo)
    score -= _SURCHARGE * waste
    return score
# EVOLVE-BLOCK-END
