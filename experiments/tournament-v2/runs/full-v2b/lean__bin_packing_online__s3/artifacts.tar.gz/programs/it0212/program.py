# EVOLVE-BLOCK-START
"""Self-completing best fit.

Pure best fit minimizes the immediate leftover, but often leaves a small
sliver (residual < item sizes commonly seen) that no future item can use,
wasting a bin.  Observation: if after placing item `x` the leftover is
exactly `x` (or some other likely item size), then a future item equal to
that leftover fills the bin completely.  So among near-ties in residual
we prefer "self-completing" leftovers, i.e. a residual close to the item
size just placed.  Exact fits (residual 0) still dominate.
"""
import numpy as np

_TIE_EPS = 4.0
_SELF_BONUS = 1.5


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Near-ties in residual: prefer the bin whose new leftover is close to
    # the item just placed (residual ~= item), so a later equal item can
    # complete the bin exactly.  square keeps this a mild local bias.
    bonus = -(residual - item).astype(np.float64) ** 2
    is_near = np.abs(score - score.max()) <= _TIE_EPS
    score = score + _SELF_BONUS * bonus * is_near
    return score
# EVOLVE-BLOCK-END

