# EVOLVE-BLOCK-START
"""Best fit with online exact-fill bonus.

Ranking is pure best-fit (tightest residual wins).  Among near-ties, the
tie is broken by whether the leftover residual equals a frequently seen
item size: such a bin can be exactly refilled later, which is the strongest
possible packing signal.  The frequency table is learned online from the
items seen so far, so no distribution assumptions are hard-coded.
"""
import numpy as np

_TIE_EPS = 1.0
_TIE_WEIGHT = 1.0

# Online counts of observed item sizes (index 1..100).
_counts = np.zeros(101, dtype=np.float64)
_state = {"n": 0.0}


def priority(item, bins):
    # Record the current item before ranking (it is a valid future size).
    if 1 <= item <= 100:
        _counts[item] += 1.0
    _state["n"] += 1.0

    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Normalised fillability weight: how often this residual size shows up
    # as an actual item size.  Scale to roughly [0, 1].
    total = _state["n"]
    fill = _counts[np.clip(residual, 0, 100).astype(np.int64)] / total

    top = score.max()
    is_near = (top - score) <= _TIE_EPS
    score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
