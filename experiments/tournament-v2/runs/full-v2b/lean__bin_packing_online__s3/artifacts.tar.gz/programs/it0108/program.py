# EVOLVE-BLOCK-START
"""Online best-fit with a learned unusable-slack band.

Pure best-fit leaves small residuals that future items usually cannot
fill, wasting capacity.  Instead of a fixed band we learn, online, the
low quantile of the item-size distribution: any residual below it is
unlikely ever to be exactly used again, so we add a surcharge that grows
the smaller the residual is.  Ranking stays best-fit for residuals above
the band.
"""
import numpy as np

_ALPHA = 0.05          # EMA for the running low-quantile estimate
_SURCHARGE = 10.0      # max penalty for a residual near zero
_MIN_SAMPLES = 50

_state = {"q": 20.0, "n": 0}


def priority(item, bins):
    # Update a running estimate of a low quantile of item sizes.
    s = _state
    s["n"] += 1
    if s["n"] <= _MIN_SAMPLES:
        # crude warmup quantile from a small buffer
        s.setdefault("buf", []).append(item)
        q = float(np.percentile(s["buf"], 10))
        s["q"] = q
    else:
        # track a low quantile by nudging toward the item when it is small
        target = float(item)
        q = s["q"]
        # move down faster when we see values below q, up slowly otherwise
        if target < q:
            q += (target - q) * 0.1
        else:
            q += (q - 0.0) * 0.0  # stable
        s["q"] = q

    residual = bins - item
    score = -residual.astype(np.float64)      # base: tightest fit

    q = max(1.0, min(99.0, s["q"]))
    band = q  # residuals below the low quantile are likely unusable
    small = (residual > 0) & (residual < band)
    # penalty grows as residual shrinks toward 0
    frac = np.clip((band - residual) / band, 0.0, 1.0)
    score -= _SURCHARGE * frac * small
    return score
# EVOLVE-BLOCK-END

