# EVOLVE-BLOCK-START
"""Adaptive-waste best fit.

Pure best-fit leaves small residuals that no future item can close.  The
right threshold is the smallest item size that actually occurs in the
stream, which we learn online.  A bin whose residual is positive but
smaller than the smallest item seen so far is "dead" - it can never be
closed - so we penalise such bins softly.  When we have not yet seen a
tiny item the penalty band shrinks automatically, avoiding the harm the
fixed 20-unit band did early in the run.
"""
import numpy as np

_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05
_PENALTY = 3.0

_state = {"tick": 0, "min_item": 101}


def priority(item, bins):
    if item < _state["min_item"]:
        _state["min_item"] = int(item)
    thr = _state["min_item"]

    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Penalise residuals that are positive but below the smallest item seen
    # (such bins can never be closed by any observed future item).
    dead = (residual > 0) & (residual < thr)
    score -= _PENALTY * dead

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        idx = np.arange(residual.shape[0], dtype=np.float64)
        perturb = ((idx * 2654435761.0 + _state["tick"] * 40503.0) % 1000.0) / 1000.0
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score - _TIE_WEIGHT * perturb * is_near
    return score
# EVOLVE-BLOCK-END
