# EVOLVE-BLOCK-START
"""Scale-aware best fit with a soft unusable-residual surcharge.

Best fit minimizes the residual after placement, but residuals in a small
band above zero are often unusable: no future item may fit, so the bin is
effectively closed with wasted space.  We use best fit as the base rule and
subtract a smooth penalty that is largest for tiny residuals, decaying to
zero by a threshold derived from the item sizes seen so far (which tracks the
scale of the Weibull distribution).  This keeps tightest-fit behavior for
genuinely reusable gaps while discouraging the creation of stranded slivers.
"""
import numpy as np

# Running scale estimate: the largest residual we still consider "at risk".
# We adapt it from the largest item seen, since residuals below that size are
# more likely to strand capacity.
_MAX_SEEN = 40.0     # init near distribution mean
_SURCHARGE = 7.0


def priority(item, bins):
    global _MAX_SEEN
    if item > _MAX_SEEN:
        _MAX_SEEN = float(item)

    residual = bins - item                      # >= 0 for every bin shown
    rf = residual.astype(np.float64)
    score = -rf                                 # base: tightest fit wins

    # Smooth penalty: strongest at residual 0+ and decaying to zero by
    # threshold t = _MAX_SEEN.  Exact fits (residual 0) get a small bonus
    # rather than a penalty.
    t = _MAX_SEEN
    at_risk = (residual > 0) & (rf < t)
    score -= _SURCHARGE * (1.0 - rf / t) * at_risk

    # Mild preference for fully filling a bin.
    score += 0.5 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
