# EVOLVE-BLOCK-START
"""Best-fit with exact-fill bonus and small-slack penalty.

Core rule: choose the bin with the smallest residual after placement
(tightest fit).  Two refinements that only help:

1. Exact fill: if some bin's residual equals the item size exactly, the
   leftover becomes 0 -- strictly better than any positive leftover, so
   give those placements a large bonus.

2. Small non-zero residuals (unusable slack) get a mild penalty, since
   they tend to waste capacity.  The band is based on the known item
   distribution (mean ~40), so it is not tuned to any single instance.
"""
import numpy as np

_EXACT_BONUS = 1000.0        # reward for leaving residual exactly 0
_WASTE_LIMIT = 15.0          # residuals below this are near-unusable
_SURCHARGE = 4.0             # penalty per unit for those small residuals


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    score = -residual.astype(np.float64)        # base: tightest fit wins

    # Exact-fill bonus: residual 0 after placement.
    exact = (residual == 0)
    score += _EXACT_BONUS * exact

    # Penalise tiny non-zero leftovers that no future item can use.
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    return score
# EVOLVE-BLOCK-END
