# EVOLVE-BLOCK-START
"""Quadratic slack penalty on best fit.

Items arrive online; we need a bin-choice rule. Standard best-fit (smallest
residual) tends to leave tiny unusable leftovers. Since future sizes come
from a Weibull-shaped distribution with mean ~40, a leftover of a few units
is almost never exactly fillable, whereas a larger leftover can still host
a future item. So we score by -residual, but subtract an extra surcharge
proportional to residual^2 for residuals below a cutoff -- convex, so exact
fits (0) and large reusable gaps are both preferred over mid-sized waste.
"""
import numpy as np

# Only residuals below this behave like waste given mean item ~40.
_WASTE_LIMIT = 30.0
# Coefficient on residual^2 within the waste band.
_QUAD = 0.35

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    r = residual.astype(np.float64)
    score = -r                                  # base: tightest fit wins
    # Convex penalty: violates smallest-residual preference only mildly for
    # tiny residuals, but strongly discourages leftovers near the cutoff.
    waste = (r > 0.0) & (r < _WASTE_LIMIT)
    score -= _QUAD * (r * r) * waste
    return score
# EVOLVE-BLOCK-END
