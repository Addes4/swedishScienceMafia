# EVOLVE-BLOCK-START
"""Adaptive best fit: penalise only residuals that are provably unusable.

Best fit with a fixed waste band hurt because the optimal band depends on
the size distribution.  Instead we track the smallest item size seen so far
(a good proxy for what future items may need) and only surcharge residuals
below that threshold -- i.e. gaps that no observed item could ever fill.
Exact fills get a modest dominance bonus so we consolidate fully when possible.
"""
import numpy as np

# Bonus so that exact fills strictly dominate any non-zero residual.
_EXACT_BONUS = 4.0
# Surcharge for residuals smaller than our best estimate of the smallest item.
_SURCHARGE = 3.0

_state = {"min_seen": 100}


def priority(item, bins):
    global _state
    if item < _state["min_seen"]:
        _state["min_seen"] = item
    # Smooth the threshold upward slightly: assume items can be a bit smaller.
    eps = max(1.0, _state["min_seen"] * 0.5)

    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: best fit
    # Penalise gaps too small for any plausible future item.
    waste = (residual > 0) & (residual < eps)
    score -= _SURCHARGE * waste
    # Reward exact fills.
    score += _EXACT_BONUS * (residual == 0)
    return score
# EVOLVE-BLOCK-END
