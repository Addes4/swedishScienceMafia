# EVOLVE-BLOCK-START
"""Threshold-aware best fit with online size-frequency waste estimate.

Best-fit picks the tightest residual, but it can chase residuals that no
future item will ever exactly fill (unusable small slack).  We keep the
best-fit ordering, apply a mild surcharge to residuals in a small waste
band just above 0, and add a learned penalty proportional to the estimated
chance that a given residual will *never* be exactly fillable by a future
item.  A slow rotating perturbation breaks near-ties so no single bin index
absorbs all slack.
"""
import numpy as np

_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05
_HIST_WEIGHT = 4.0          # strength of the "unfillable residual" penalty
_HIST_DECAY = 0.995         # slow decay so old items fade out
_MIN_PROB = 0.002           # floor on per-size probability

_state = {"tick": 0}
_hist = np.zeros(101, dtype=np.float64)   # observed counts by size 1..100
_hist_total = 0.0


def priority(item, bins):
    global _hist_total
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Penalise small non-zero residuals (likely unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    # Learned penalty: residual that no plausible future size can fill exactly.
    if _hist_total > 0.0:
        probs = _hist[1:101] / _hist_total
        probs = np.maximum(probs, _MIN_PROB)
        # probability that no future item size equals this residual
        exact = np.where((residual >= 1) & (residual <= 100),
                         probs[np.clip(residual.astype(np.int64), 1, 100) - 1],
                         _MIN_PROB)
        score -= _HIST_WEIGHT * (1.0 - exact)

    # Update histogram after scoring (so current item does not bias itself).
    if 1 <= item <= 100:
        _hist *= _HIST_DECAY
        _hist_total *= _HIST_DECAY
        _hist[item] += 1.0
        _hist_total += 1.0

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        idx = np.arange(residual.shape[0], dtype=np.float64)
        perturb = ((idx * 2654435761.0 + _state["tick"] * 40503.0) % 1000.0) / 1000.0
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score - _TIE_WEIGHT * perturb * is_near
    return score
# EVOLVE-BLOCK-END
