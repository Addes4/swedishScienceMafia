# EVOLVE-BLOCK-START
"""Best fit with a probabilistic "future-fillable" tie-break.

Pure best-fit (smallest residual) is near-optimal for this distribution.
Small adjustments help at the margins: we add a small bonus when the
resulting residual is itself a likely item size (so a later item can
fill the bin exactly), and a stronger bonus for exact fills (residual 0).
The bonus magnitude stays well below 1 so it can never override a genuine
improvement in residual, only break near-ties.
"""
import numpy as np

_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.max()          # in [0,1]
# probability (relative) a residual can be exactly matched by a future item
_FILL = np.concatenate(([1.0], _PDF))   # index by residual 0..100

_BONUS_WEIGHT = 0.30
_EXACT_BONUS = 0.60


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # tightest fit dominates
    rc = np.clip(residual, 0, 100).astype(np.int64)
    fill = _FILL[rc]
    score = score + _BONUS_WEIGHT * fill
    exact = residual == 0
    score = score + _EXACT_BONUS * exact
    return score
# EVOLVE-BLOCK-END

