# EVOLVE-BLOCK-START
"""Best fit with exact-fit bonus and unusable-slack penalty.

Pure best-fit ranks by residual. Two refinements help on this distribution:
- an exact fill (residual 0) is far more valuable than any leftover, so give
  it a solid bonus;
- small non-zero residuals in a band no future item is likely to exactly use
  are wasted, so apply a mild surcharge there.
No stateful tie-break: deterministic and noise-free.
"""
import numpy as np

_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_EXACT_BONUS = 4.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Small but non-zero residuals are likely unusable slack.
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste
    # Exact fills are especially valuable.
    score += _EXACT_BONUS * (residual == 0)
    return score
# EVOLVE-BLOCK-END
