# EVOLVE-BLOCK-START
"""Best-fit with Weibull-aware residual value.

Pure best fit is strong but leaves small slivers.  Here we score each bin by
the residual it would leave for this item, ordering primarily by tightness
(-residual) but adding a mild bonus for residuals that are likely to be
reusable by future items.  The item distribution is assumed Weibull-shaped
with mean ~40, so we estimate, for a residual r, the expected number of
future items that could still fit into that residual (a smooth reuse value).
This keeps tight packing while discouraging dead slivers.
"""
import numpy as np

_MEAN = 40.0
_SHAPE = 1.5  # Weibull shape giving mean ~40 with small minimum items
_SCALE = _MEAN / 0.9028  # gamma(1+1/shape) ~ 0.9028 for shape 1.5
_REUSE_WEIGHT = 0.6
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

_state = {"tick": 0}

# Precompute a smooth "reuse value" for integer residuals 0..100.
_ITEMS = np.arange(1, 101, dtype=np.float64)
# Weibull pdf (normalized approximation of the item distribution).
_pdf = (_SHAPE / _SCALE) * (_ITEMS / _SCALE) ** (_SHAPE - 1.0) * np.exp(
    -(_ITEMS / _SCALE) ** _SHAPE
)


def _reuse_value(r):
    # Expected number of future items (of size <= r) weighted by presence.
    # r = residual after placing; items must fit strictly (size <= r).
    ri = np.floor(r).astype(np.int64)
    ri = np.clip(ri, 0, 100)
    # Number of distinct sizes <= ri weighted by probability mass.
    cdf_cum = np.cumsum(_pdf)
    val = cdf_cum[ri] if ri.ndim else cdf_cum[int(ri)]
    # Weight by the count of usable sizes (log scale) to favor reusable gaps.
    return val


def priority(item, bins):
    residual = bins - item                       # >= 0 for every bin shown
    score = -residual.astype(np.float64)         # base: tightest fit wins

    # Reuse bonus: rewards residuals that future items can actually use.
    rv = _reuse_value(residual)
    score = score + _REUSE_WEIGHT * rv

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        idx = np.arange(residual.shape[0], dtype=np.float64)
        perturb = ((idx * 2654435761.0 + _state["tick"] * 40503.0) % 1000.0) / 1000.0
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score - _TIE_WEIGHT * perturb * is_near
    return score
# EVOLVE-BLOCK-END
