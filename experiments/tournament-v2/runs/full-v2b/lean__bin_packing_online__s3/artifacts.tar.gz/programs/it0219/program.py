# EVOLVE-BLOCK-START
"""Best fit with continuous residual-fillability shaping.

Backbone: tightest fit wins (score = -residual).  Two refinements are
applied to *every* bin continuously (not only near-ties):

1. A penalty on unusable slivers: residuals strictly between 0 and a
   small limit get a surcharge, since such leftovers are hard to reuse.

2. A mild fillability bonus: residuals that are likely future item sizes
   (per a smooth Weibull-shaped histogram) are slightly preferred, so the
   leftover is more likely to be exactly consumed later.

An extra strong bonus is given when the residual exactly equals the item
(a perfect fit), which dominates ordinary best-fit choices.
"""
import numpy as np

_WASTE_LIMIT = 18.0
_SURCHARGE = 3.0
_FILL_WEIGHT = 3.0
_PERFECT_BONUS = 20.0

# Smooth Weibull-shaped histogram over sizes 1..100 (mean ~40).
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    rc = np.clip(residual, 0, 100).astype(np.int64)

    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Penalise small but non-zero slack (unusable slivers).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    # Mild continuous bonus for residuals that are likely future item sizes.
    score += _FILL_WEIGHT * _FILL[rc]

    # Strong bonus for a perfect fit (residual exactly equals the item).
    perfect = (residual == 0)
    score += _PERFECT_BONUS * perfect

    return score
# EVOLVE-BLOCK-END
