# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware "unfillable leftover" penalty.

Pure best-fit leaves small residuals that future items may never exactly
match, wasting capacity.  We score each bin by -residual (tightest fits
first) plus a reward proportional to the probability that some future
item exactly equals the residual, estimated from a static histogram of
the item-size distribution.  Residuals that are common item sizes are
attractive; residuals that no item can fill are penalised.  A small
stateful rotation breaks exact ties across bin indices over time.
"""
import numpy as np

# Static histogram of integer item sizes 1..100 for the Weibull-shaped
# distribution (mean ~40).  Built once, smoothed, and normalised.
def _build_hist():
    rng = np.random.default_rng(12345)
    # Weibull shape fitted to give mean ~40 on 1..100; sample and clip.
    samples = rng.weibull(2.0, 400000) * 45.0
    samples = np.clip(np.round(samples), 1, 100).astype(np.int64)
    counts = np.bincount(samples, minlength=101).astype(np.float64)
    counts[0] = 0.0
    # Smooth so unseen sizes still get a small positive weight.
    counts = counts + 0.3
    counts /= counts.sum()
    return counts

_HIST = _build_hist()
_MISS_WEIGHT = 8.0          # strength of the unfillable-leftover penalty
_TIE_EPS = 0.5
_TIE_WEIGHT = 0.02

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                      # >= 0 for bins shown
    score = -residual.astype(np.float64)        # base: tightest fit wins
    # Probability the leftover residual can be exactly filled later.
    res_int = np.clip(residual, 0, 100).astype(np.int64)
    fillable = _HIST[res_int]
    # Penalise unlikely-to-be-filled residuals (scaled by 1e3 so it
    # doesn't dominate the tight-fit ordering).
    score -= _MISS_WEIGHT * (1.0 - fillable) * 1.0

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        idx = np.arange(residual.shape[0], dtype=np.float64)
        perturb = ((idx * 2654435761.0 + _state["tick"] * 40503.0) % 1000.0) / 1000.0
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score - _TIE_WEIGHT * perturb * is_near
    return score
# EVOLVE-BLOCK-END
