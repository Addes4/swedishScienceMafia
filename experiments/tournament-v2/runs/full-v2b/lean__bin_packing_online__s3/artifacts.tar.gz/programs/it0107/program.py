# EVOLVE-BLOCK-START
"""Threshold-aware best fit with a smooth small-residual penalty.

Pure best-fit packs tightly but can leave small unusable leftovers.  We
keep tightest-residual (best fit) as the base score and add a smooth
penalty for residuals that fall into the "small slack" band just above
zero, growing as the residual shrinks.  Exact fits (residual 0) are
rewarded, so bins get topped off whenever a perfect match exists.
"""
import numpy as np

# Residuals strictly between 0 and this value get a penalty.
_WASTE_LIMIT = 25.0
_SURCHARGE = 5.0
_EXACT_BONUS = 3.0

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    r = residual.astype(np.float64)
    score = -r                                 # base: tightest fit wins

    # Smooth penalty for small non-zero slack, strongest near zero.
    # weight = (limit - r)/limit in (0,1] for 0 < r < limit, else 0.
    w = np.clip((_WASTE_LIMIT - r) / _WASTE_LIMIT, 0.0, 1.0)
    w = np.where(r > 0.0, w, 0.0)
    score = score - _SURCHARGE * w

    # Reward exact fits so perfect matches are seized immediately.
    score = score + _EXACT_BONUS * (r == 0.0)

    _state["tick"] += 1
    return score
# EVOLVE-BLOCK-END
