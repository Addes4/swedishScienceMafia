# EVOLVE-BLOCK-START
"""Clean best-fit with a mild exact-fill bonus.

Earlier experiments showed the waste-band surcharge and aggressive
fillability tie-breaks consistently hurt.  The most robust online rule
here is tightest-fit (minimize leftover residual), with only a small
nudge toward perfectly filling a bin (residual 0), which can only help
since it never wastes a reachable slot.
"""
import numpy as np

_EXACT_BONUS = 0.5

_FILL = None  # placeholder to keep signature simple


def priority(item, bins):
    residual = bins - item                     # >= 0
    score = -residual.astype(np.float64)       # tightest fit wins
    # Small bonus for leaving the bin exactly full.
    score += _EXACT_BONUS * (residual == 0)
    return score
# EVOLVE-BLOCK-END

