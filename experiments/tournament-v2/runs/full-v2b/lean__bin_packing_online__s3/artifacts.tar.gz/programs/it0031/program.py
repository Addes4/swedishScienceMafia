# EVOLVE-BLOCK-START
"""Best-fit with a squared-residual refinement.

Pure best-fit minimizes the residual after placement.  A known improvement
on Weibull-like size distributions is to mildly distort this ordering so
that tiny residuals (which are essentially wasted) are slightly less
attractive than marginally larger ones, while still strongly favouring
exact fills.

We score bins by -residual + eps * (residual^2 term only for tiny residual),
which is a curvature that discourages stranding 1..8 capacity slivers.
"""
import numpy as np

_TINY = 9.0
_CURVE = 1.5


def priority(item, bins):
    residual = (bins - item).astype(np.float64)   # >= 0 for every bin shown
    score = -residual                             # base best-fit ordering
    # Discourage leaving a tiny sliver that no future item can use.
    tiny = (residual > 0) & (residual < _TINY)
    score -= _CURVE * tiny
    return score
# EVOLVE-BLOCK-END
