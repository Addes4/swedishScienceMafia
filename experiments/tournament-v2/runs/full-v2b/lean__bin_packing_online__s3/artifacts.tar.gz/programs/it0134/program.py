# EVOLVE-BLOCK-START
"""Best fit with an adaptive unusable-slack penalty.

Pure best-fit minimizes residual greedily, but can leave tiny leftovers
(e.g. 1..k) that no future item will ever fit into, wasting capacity.
We track the smallest item size seen so far as a conservative estimate of
the smallest future item.  Any residual in [1, min_seen) is effectively
unusable slack, so we penalize it.  We also strongly reward exact fills.
"""
import numpy as np

_state = {"min_seen": 101}


def priority(item, bins):
    if item < _state["min_seen"]:
        _state["min_seen"] = item

    residual = bins - item                      # >= 0 for every bin shown
    score = -residual.astype(np.float64)        # base: tightest fit wins

    # Penalize stranded slack smaller than any item seen so far.
    threshold = _state["min_seen"]
    if threshold > 1:
        unusable = (residual > 0) & (residual < threshold)
        score -= 50.0 * unusable

    # Strongly reward exact fills.
    score += 1000.0 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
