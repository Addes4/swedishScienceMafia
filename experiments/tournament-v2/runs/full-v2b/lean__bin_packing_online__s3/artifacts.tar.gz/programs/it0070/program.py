# EVOLVE-BLOCK-START
"""Distribution-calibrated best fit.

Pure best-fit leaves small unusable residuals (dead gaps) that waste
capacity.  Rather than a hard "waste band", we penalise each candidate
bin by how unlikely its leftover is to be exactly closed by a future
item, estimated from the known Weibull-shaped item distribution (mean
~40, sizes 1..100).  Exact and clearly-reusable residuals are favoured;
tiny unfillable slivers are pushed away.  A tiny rotating perturbation
breaks near-ties across bin indices.
"""
import numpy as np

# Approximate item distribution: Weibull(k~1.5, scale~44) truncated to 1..100.
_rng = np.linspace(1.0, 100.0, 200)
_k = 1.5
_lam = 44.0
# Weibull pdf (unnormalised) over the grid.
_z = _rng / _lam
_pdf = (_k / _lam) * (_z ** (_k - 1.0)) * np.exp(-(_z ** _k))
_pdf = _pdf / _pdf.sum()


def _fill_prob(r):
    """Probability mass of items with size exactly r (interpolated)."""
    if r <= 0:
        return 1.0
    return float(np.interp(r, _rng, _pdf))


# Precompute a waste surcharge table indexed by integer residual 0..100.
_WASTE = np.zeros(101, dtype=np.float64)
for _r in range(101):
    if _r == 0:
        _WASTE[_r] = 0.0
    else:
        # Larger surcharge when an item of exactly this size is unlikely.
        p = float(np.interp(_r, _rng, _pdf))
        # Normalise against the peak of the pdf.
        _WASTE[_r] = 1.0 - p / _pdf.max()

_SCALE = 6.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise residuals that a future item is unlikely to exactly close.
    r_clip = np.clip(residual, 0, 100).astype(np.int64)
    score -= _SCALE * _WASTE[r_clip]

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        idx = np.arange(residual.shape[0], dtype=np.float64)
        perturb = ((idx * 2654435761.0 + _state["tick"] * 40503.0) % 1000.0) / 1000.0
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score - _TIE_WEIGHT * perturb * is_near
    return score
# EVOLVE-BLOCK-END
