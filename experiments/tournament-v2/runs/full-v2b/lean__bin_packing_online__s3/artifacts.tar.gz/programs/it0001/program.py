# EVOLVE-BLOCK-START
"""Best fit with a tiny stable jitter to break ties and smooth packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer smallest remaining capacity that still fits.
    score = -(bins - item)
    # Small deterministic jitter based on bin index to vary tie choices.
    n = len(bins)
    idx = np.arange(n)
    jitter = ((idx * 2654435761) % 1000) / 1000000.0
    score = score.astype(np.float64) + jitter
    return score
# EVOLVE-BLOCK-END

