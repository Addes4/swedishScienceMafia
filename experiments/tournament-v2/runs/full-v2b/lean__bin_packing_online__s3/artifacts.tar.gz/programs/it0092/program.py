# EVOLVE-BLOCK-START
"""Threshold-aware best fit with histogram-guided near-tie break.

Pure best-fit often creates a bin whose small leftover (say 3..18) no
future item can use, wasting capacity.  We keep the tight-fit ordering
by residual and apply a surcharge to residuals in a "waste" band just
above 0.  Additionally, near-ties in residual are broken by preferring
the bin whose leftover residual is a *likely* future item size (so it
can be exactly filled later), using a static histogram of the known
Weibull-shaped item-size distribution.

The surcharge is scaled by item size: tiny items can plausibly fill a
small residual exactly, so for them the waste penalty is softened and
the fillability bonus is amplified.  For large items the strong penalty
is retained, preserving near-pure best fit.
"""
import numpy as np

# Residuals strictly between 0 and this value are treated as wasted slack.
_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

# Static histogram over item sizes 1..100 (mean ~40, Weibull-shaped),
# used only as a relative "fillability" weight for residuals.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Scale surcharge and tie bonus by item size.  Small items -> softer
    # waste penalty (they can fill small residuals later) and stronger
    # fillability bonus.  Large items -> near-pure best fit.
    smallness = 1.0 - min(item, 100.0) / 100.0          # in [0, 1)
    surcharge = _SURCHARGE * (0.5 + 0.5 * (1.0 - smallness))
    tie_weight = _TIE_WEIGHT * (1.0 + 3.0 * smallness)

    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= surcharge * waste

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _FILL[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + tie_weight * fill * is_near
    return score
# EVOLVE-BLOCK-END

