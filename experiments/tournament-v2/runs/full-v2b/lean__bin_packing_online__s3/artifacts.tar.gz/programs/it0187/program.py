# EVOLVE-BLOCK-START
"""Best fit with a lightweight, principled near-tie breaker.

The dominant rule is classic best fit: put the item in the bin that leaves
the smallest non-negative residual.  Near-ties (residuals within a small
epsilon) are broken by preferring the bin whose leftover residual is a
*likely* future item size, so the leftover can later be exactly filled.
The fillability weight is derived from the known Weibull-shaped size
distribution and kept small so the tightest-fit ordering dominates.
"""
import numpy as np

# Near-tie handling: only residuals within _TIE_EPS of the best decide ties.
_TIE_EPS = 0.5
_TIE_WEIGHT = 0.02

# Static, smooth approximation of the item-size pmf over 1..100
# (mean ~40, Weibull-shaped).  Used only as a relative fillability weight.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100


def priority(item, bins):
    residual = bins - item                 # >= 0 for every bin shown
    score = -residual.astype(np.float64)   # base: tightest fit wins

    if _TIE_EPS > 0.0:
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _FILL[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
