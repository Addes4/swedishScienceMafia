# EVOLVE-BLOCK-START
"""Best-fit with an online-learned "usable residual" adjustment.

Base rule is pure best-fit (smallest residual wins), which empirically
dominates here.  The only refinement: a small bonus for a residual that
can be exactly filled by some recently-seen item size, and a small
penalty for a residual smaller than the smallest item seen so far (which
is almost surely unusable slack).  Both signals are learned online so
they track the actual distribution rather than a fixed guess.
"""
import numpy as np

_SIZE = 101
_MIN_ITEM = 100          # smallest item size observed (init high)
_SEEN = np.zeros(_SIZE, dtype=np.float64)  # counts of item sizes seen

# weights
_PENALTY = 1.5           # for leaving sub-min slack
_FILL_BONUS = 0.4        # for leaving a residual that is a seen size
_MIN_BONUS = 0.05

_state = {"seen": np.zeros(_SIZE, dtype=np.float64),
          "min_item": 101,
          "small_count": {}}  # sizes in [1, min_item) with nonzero history


def priority(item, bins):
    global _MIN_ITEM
    st = _state
    # update online stats
    st["seen"][item] += 1.0
    if item < st["min_item"]:
        st["min_item"] = item

    residual = bins - item                    # >= 0
    score = -residual.astype(np.float64)      # base: best fit

    # Penalize residuals that are positive but below the smallest item
    # seen so far: those can essentially never be filled.
    low = st["min_item"]
    slack = (residual > 0) & (residual < low)
    score -= _PENALTY * slack

    # Bonus for residuals that exactly match a previously seen item size
    # (they may be exactly fillable later), graded by how often seen.
    rc = np.clip(residual, 0, 100).astype(np.int64)
    seen_freq = st["seen"][rc]
    has_seen = seen_freq > 0
    score += _FILL_BONUS * has_seen
    return score
# EVOLVE-BLOCK-END
