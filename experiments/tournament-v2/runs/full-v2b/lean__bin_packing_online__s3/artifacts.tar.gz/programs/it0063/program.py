# EVOLVE-BLOCK-START
"""Best fit plus future-closing reward.

The dominant term is best-fit (tightest residual).  In addition, a bin whose
residual equals a plausible future item size (per the known Weibull-shaped
item distribution, mean ~40) is one we can likely close exactly, so it gets a
small bonus.  Residuals that are too small to ever host a realistic item (a
tiny unusable slack) get a mild penalty.  Ties are broken by a stable hash of
the bin index to avoid a fixed index always absorbing slack.
"""
import numpy as np

# Cached, sorted "plausible future item sizes" sampled from the distribution.
_SIZE_SAMPLES = None


def _get_samples():
    global _SIZE_SAMPLES
    if _SIZE_SAMPLES is None:
        rng = np.random.default_rng(12345)
        # Weibull-shaped sizes with mean ~40, clipped to valid integer range.
        k = 2.0
        lam = 40.0 / 0.8862269254527580  # Gamma(1+1/k) for k=2 is sqrt(pi)/2
        s = lam * (-np.log(1.0 - rng.random(4096))) ** (1.0 / k)
        s = np.clip(np.rint(s), 1, 100).astype(np.int64)
        _SIZE_SAMPLES = np.unique(s)
    return _SIZE_SAMPLES


def priority(item, bins):
    residual = bins - item                      # >= 0 for shown bins
    score = -residual.astype(np.float64)        # best-fit dominant term

    samples = _get_samples()
    # Reward residuals that a plausible item could close exactly.
    reachable = np.isin(residual, samples)
    score += 0.3 * reachable

    # Mild penalty for hopeless tiny slack that no realistic item fits.
    useless = (residual > 0) & (residual < 5)
    score -= 0.2 * useless

    # Stable, deterministic tie-break by bin index (tiny).
    idx = np.arange(residual.shape[0], dtype=np.float64)
    score -= 0.001 * (((idx * 2654435761.0) % 1024.0) / 1024.0)
    return score
# EVOLVE-BLOCK-END
