# EVOLVE-BLOCK-START
"""Best fit with mild small-slop avoidance scaled by item size.

Pure best fit (maximize remaining capacity minus item, i.e. minimize
residual) is a strong baseline.  The one weakness is that it sometimes
leaves a tiny unusable residual.  We keep best fit as the dominant rule
but add a small penalty for leaving a non-zero residual below a size
scale, with the penalty magnitude proportional to the item so large
items consolidate fully while small items remain flexible.
"""
import numpy as np

_SLOP = 25.0


def priority(item, bins):
    residual = bins - item                       # >= 0 for every bin shown
    score = -residual.astype(np.float64)         # dominant: best fit
    # Discourage leaving a tiny non-reusable gap.
    small = (residual > 0) & (residual < _SLOP)
    score -= (0.15 * item) * small
    return score
# EVOLVE-BLOCK-END

