# EVOLVE-BLOCK-START
"""Pure best fit.

Place each item into the bin where it fits most tightly, i.e. with the
smallest nonnegative remaining capacity after insertion.  Ties go to the
earliest bin (handled by the harness).  This simple rule is a strong
online heuristic for the Weibull-shaped item distribution and avoids the
fragile waste-band penalties that degraded earlier variants.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # tightest fit wins
    return score
# EVOLVE-BLOCK-END
