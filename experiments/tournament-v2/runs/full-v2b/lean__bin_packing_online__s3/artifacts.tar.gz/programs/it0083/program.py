# EVOLVE-BLOCK-START
"""Threshold-aware best fit with a large-item empty-bin preference.

Pure best-fit often creates a bin with a small leftover (say 3..18) that
no future item can use, wasting capacity.  We keep the tight-fit ordering
by residual, apply a surcharge to residuals in a "waste" band just above 0
(so exact fits or clearly reusable gaps are preferred), and we add a tiny
stateful rotating perturbation to break near-ties in favour of different
bins over time, avoiding a fixed bin index always absorbing slack.

Additionally, when the arriving item is large, we mildly boost unused
bins (remaining capacity 100) so a big item tends to open a fresh bin
rather than being crammed into a medium-residual bin.
"""
import numpy as np

# Residuals strictly between 0 and this value are treated as wasted slack.
_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

# Large-item empty-bin preference.
_LARGE_ITEM = 60
_EMPTY_BOOST = 4.0

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise residuals that are small but non-zero (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    if item >= _LARGE_ITEM:
        # Mildly prefer opening a fresh bin for large items.
        empty = (bins == 100)
        score += _EMPTY_BOOST * empty

    if _TIE_EPS > 0.0:
        # Near-ties get a deterministic rotating perturbation keyed on bin
        # index and a slow-moving tick, so equal-scoring bins are not always
        # resolved to the lowest index.
        _state["tick"] += 1
        idx = np.arange(residual.shape[0], dtype=np.float64)
        perturb = ((idx * 2654435761.0 + _state["tick"] * 40503.0) % 1000.0) / 1000.0
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score - _TIE_WEIGHT * perturb * is_near
    return score
# EVOLVE-BLOCK-END
