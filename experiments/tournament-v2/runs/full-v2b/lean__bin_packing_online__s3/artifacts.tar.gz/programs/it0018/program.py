# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware waste band.

Pure best-fit strands small residuals that later items cannot reuse.  The
Weibull-shaped item distribution has mean ~40, so a leftover much below the
typical item size is likely wasted.  We track a running mean/estimate of item
sizes seen so far and penalise any non-zero post-placement residual that is
smaller than that estimate, proportional to how unusable it is.
"""
import numpy as np

# Smallest item size (so residual 0 is always strictly best).
_EPS = 1e-6


class _State:
    __slots__ = ("n", "mean")

    def __init__(self):
        self.n = 0
        self.mean = 40.0  # prior guess matching the distribution mean


_state = _State()


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Running estimate of typical incoming item size.
    st = _state
    st.n += 1
    st.mean += (item - st.mean) / st.n

    # Band: residuals below the typical item size are "likely useless".
    band = st.mean if st.mean > 1.0 else 1.0
    useless = (residual > 0) & (residual < band)
    # Penalty proportional to unusability: strongest near 0, fading at band.
    weight = (band - residual) / band
    score -= 4.0 * weight * useless

    return score
# EVOLVE-BLOCK-END
