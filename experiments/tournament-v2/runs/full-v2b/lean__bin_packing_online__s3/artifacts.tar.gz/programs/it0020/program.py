# EVOLVE-BLOCK-START
"""Modified best fit with a fallback to gap-consolidation.

Best fit is near-optimal, but on Weibull-shaped sizes it tends to
fragment capacity into many bins with medium unusable residuals.  The
classic complementary rule is "worst fit", which keeps bins uniformly
loaded and tends to use fewer bins on such distributions.  A pure switch
would regress, so we blend: prefer the tightest fit unless the tightest
fit would strand a small sliver; in that case fall back to the bin that
leaves the largest residual, keeping remaining gaps consolidated.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    return score
# EVOLVE-BLOCK-END

