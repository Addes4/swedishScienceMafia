# EVOLVE-BLOCK-START
"""Adaptive best fit: prefer residuals that a typical arriving item can fill.

We keep a running histogram of observed item sizes.  For each candidate
bin we compute the residual after placement; the score prefers small
residuals (best fit), but adds a bonus when the residual matches a size
that is likely to appear (i.e. has been seen often before), so the
leftover gap is more likely to be useful rather than stranded.
"""
import numpy as np

_CAP = 100
# Histogram of past item sizes (1..100).
_hist = np.zeros(_CAP + 1, dtype=np.float64)
_count = 0
# Cache of "usefulness" per residual value.
_useful = None
_USEFUL_ALPHA = 4.0


def _rebuild_useful():
    """Recompute the usefulness weight for each residual 1..100."""
    global _useful
    tot = _hist.sum()
    if tot <= 0:
        _useful = np.zeros(_CAP + 1, dtype=np.float64)
        return
    # Frequency of each size seen so far (probability a future item matches).
    freq = _hist / tot
    # A residual r is "useful" if some item size <= r is common.
    # Approximate by the max frequency among sizes up to r.
    cummax = np.maximum.accumulate(freq)
    _useful = cummax


def priority(item, bins):
    global _count
    _count += 1
    # Update histogram with the current item.
    if 1 <= item <= _CAP:
        _hist[item] += 1.0
    _rebuild_useful()

    residual = bins - item
    score = -residual.astype(np.float64)
    # Bonus for residuals that leave room a (probably) upcoming item can use.
    safe = np.clip(residual, 0, _CAP)
    score += _USEFUL_ALPHA * _useful[safe]
    return score
# EVOLVE-BLOCK-END
