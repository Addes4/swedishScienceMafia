# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware exact-fill bonus.

Pure best fit (tightest residual wins) is a strong backbone.  The only
change that reliably helps online packing is to avoid stranding a bin
with a residual that no future item can exactly fill.  We keep residual
as the dominant term, and add a *small* bonus when the new leftover is
itself a size that has been observed often (empirically fillable).  The
bonus magnitude is kept below 1 residual unit so it only breaks
near-ties and never overrides a genuinely tighter fit.
"""
import numpy as np

# Live histogram of observed item sizes (1..100).  Used only as a
# relative weight for how "fillable" a leftover residual is.
_count = np.zeros(101, dtype=np.float64)
_total = 0.0
_BONUS = 0.9  # strictly less than 1 so residual (=tight-fit) dominates


def priority(item, bins):
    global _total
    residual = bins - item                      # >= 0 for every bin shown
    score = -residual.astype(np.float64)        # tight-fit backbone

    # Update running histogram with the current item.
    _count[item] += 1.0
    _total += 1.0

    # Fillability weight for a leftover residual r: how often we've seen
    # an item of that exact size (smoothed).  Larger means more likely to
    # be exactly filled later.
    prob = (_count + 1.0) / (_total + 100.0)    # Laplace-smoothed freq
    rc = np.clip(residual, 0, 100).astype(np.int64)
    fill = prob[rc]
    fill = fill / fill.max() if fill.size and fill.max() > 0 else fill

    # Small additive bonus: only shifts near-ties in residual.
    score = score + _BONUS * fill
    return score
# EVOLVE-BLOCK-END

