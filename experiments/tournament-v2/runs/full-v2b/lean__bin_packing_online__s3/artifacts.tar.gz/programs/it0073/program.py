# EVOLVE-BLOCK-START
"""Threshold-aware best fit with strong near-exact reward.

Pure best-fit often creates a bin with a small leftover (say 3..18) that
no future item can use, wasting capacity.  We keep the tight-fit ordering
by residual, but give a meaningful bonus to residuals small enough that a
future item is very likely to fill the bin exactly, and penalise the
adjacent "dead slack" band just above that.
"""
import numpy as np

# Residuals at or below this are treated as (near-)exact fits: strongly good.
_EXACT_LIMIT = 4.0
_EXACT_BONUS = 8.0

# Residuals strictly between _EXACT_LIMIT and this are "dead slack": too big
# to be filled by the typical smallest items but too small to be reusable.
_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0

_TIE_EPS = 1.0
_TIE_WEIGHT = 0.02

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Reward (near-)exact fits: leaving ~0 slack is the best outcome.
    exact = residual <= _EXACT_LIMIT
    score += _EXACT_BONUS * exact

    # Penalise residuals that are small but too large to be reusable.
    waste = (residual > _EXACT_LIMIT) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0:
        # Very small deterministic perturbation to spread near-ties over
        # different bins rather than always the lowest index.
        _state["tick"] += 1
        idx = np.arange(residual.shape[0], dtype=np.float64)
        perturb = ((idx * 2654435761.0 + _state["tick"] * 40503.0) % 1000.0) / 1000.0
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score - _TIE_WEIGHT * perturb * is_near
    return score
# EVOLVE-BLOCK-END
