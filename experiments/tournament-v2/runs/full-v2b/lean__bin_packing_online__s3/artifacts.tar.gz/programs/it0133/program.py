# EVOLVE-BLOCK-START
"""Best Fit with exact-fill reinforcement.

Items arrive online; placing an item that exactly fills a bin's remaining
capacity is always optimal (it frees the bin at no future cost), so give
such bins a dominant bonus.  Otherwise use pure best fit (tightest
residual wins), which is a strong baseline for Weibull-shaped sizes.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item                    # >= 0 for every bin shown
    score = -residual.astype(np.float64)      # tightest fit wins
    # Dominant bonus for exact fill (residual == 0).
    score += 1e6 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
