# EVOLVE-BLOCK-START
"""Best fit with a small closure bonus to prefer bins nearly filled by the item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (smallest residual). Secondary: tiny bonus for small residual.
    return -residual.astype(np.float64) + 1.0 / (1.0 + residual.astype(np.float64))
# EVOLVE-BLOCK-END
