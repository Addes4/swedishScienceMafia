# EVOLVE-BLOCK-START
"""Threshold-aware best fit with a graded small-slack penalty.

Tightest-fit (best-fit) is the backbone because it empirically wins on
this Weibull workload.  The failure mode of pure best-fit is leaving a
tiny sliver (residual 1..k) that no future item can use.  A flat penalty
over a fixed band is crude: residual 1 is much worse than residual 18.
We therefore apply a *graded* surcharge that decreases with the residual,
peaking for the smallest non-zero slack, plus a small exact-fit bonus.
"""
import numpy as np

# Residuals strictly between 0 and this value count as (partly) wasted.
_WASTE_LIMIT = 24.0
# Maximum surcharge, applied to the tiniest slivers (residual near 0).
_SURCHARGE = 9.0
# Bonus for a perfect fit (residual becomes exactly 0).
_EXACT_BONUS = 1.0

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Graded waste penalty: strongest for tiny slivers, fading to zero
    # as the residual grows to _WASTE_LIMIT.
    small = (residual > 0) & (residual < _WASTE_LIMIT)
    if _WASTE_LIMIT > 0.0:
        frac = 1.0 - (residual.astype(np.float64) / _WASTE_LIMIT)
        score -= _SURCHARGE * frac * small

    # Small bonus for an exact fill (residual 0), within the waste band's
    # magnitude so it does not perturb the best-fit ordering elsewhere.
    exact = (residual == 0)
    score += _EXACT_BONUS * exact

    _state["tick"] += 1
    return score
# EVOLVE-BLOCK-END
