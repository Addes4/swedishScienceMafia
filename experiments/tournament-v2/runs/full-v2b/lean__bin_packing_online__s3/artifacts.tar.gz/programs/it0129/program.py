# EVOLVE-BLOCK-START
"""Best fit with a residual-utility tie-break driven by the item-size PDF.

Best fit (tightest residual) is strong for bin packing.  The main loss is
that it may leave a leftover that no future item will ever match.  We keep
tightest-fit as the base ordering and add a small bonus for the residual
being a value that is likely to appear as a future item size, using a
Weibull-shaped PDF over sizes 1..100.  Exact fits (residual 0) get the
largest base score automatically.
"""
import numpy as np

_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.max()
_FILL = np.concatenate(([1.0], _PDF))  # index by residual 0..100

_WEIGHT = 4.0


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    score = -residual.astype(np.float64)        # base: tightest fit wins
    rc = np.clip(residual, 0, 100).astype(np.int64)
    score += _WEIGHT * _FILL[rc]
    return score
# EVOLVE-BLOCK-END
