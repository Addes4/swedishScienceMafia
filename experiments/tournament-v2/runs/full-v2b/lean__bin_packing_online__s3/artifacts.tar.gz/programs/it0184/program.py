# EVOLVE-BLOCK-START
"""Best-fit backbone plus a continuous, distribution-based waste penalty.

Pure best-fit minimizes residual but can strand small unusable slack.
Instead of a hard "waste band + fixed surcharge", we score each bin by
the tightest-fit residual (dominant) and subtract a small penalty equal
to the probability that the residual can never be fully refilled, i.e.
the CDF of item sizes evaluated at the residual (mass of items strictly
smaller than the residual).  A residual of 0 incurs no penalty; larger
residuals that are likely reachable by future items incur little penalty.
A delicate near-tie bonus still prefers residuals that are exact common
item sizes.
"""
import numpy as np

# Static histogram over item sizes 1..100 (mean ~40, Weibull-shaped).
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.sum()
_CDF = np.cumsum(_PDF)
# Fallibility index by residual 1..100: mass of items strictly below r.
_UNREACH = np.concatenate(([0.0], _CDF))  # index by residual; _UNREACH[r] = P(item<r)
_FILL = np.concatenate(([0.0], _PDF))     # P(item == r)

_WASTE_WEIGHT = 8.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    rc = np.clip(residual, 0, 100).astype(np.int64)
    # Continuous, smooth waste penalty proportional to unrefillability.
    score -= _WASTE_WEIGHT * _UNREACH[rc]

    if _TIE_EPS > 0.0:
        # Near-ties: prefer a residual that is an exact common item size.
        _state["tick"] += 1
        fill = _FILL[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
