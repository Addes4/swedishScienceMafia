# EVOLVE-BLOCK-START
"""Threshold-aware best fit: avoid stranding tiny unusable residuals.

Pure best-fit often creates a bin with a small leftover (say 3..18) that
no future item can use, wasting capacity.  Here we pick the bin that
minimises residual-after-placement, but we add a surcharge to residuals
that fall in a "waste" band just above 0, pushing the algorithm to either
fully fill a bin (residual 0) or leave a genuinely reusable gap.

Item sizes are Weibull-shaped with mean ~40.  A residual is only really
reusable if it can host a sizeable fraction of a typical item.  We use a
smooth, distance-weighted penalty so that residuals which are large
enough to be reusable are not penalised, while slivers are strongly
penalised.
"""
import numpy as np

# Residuals below this are "slivers" that waste capacity.
_WASTE_LIMIT = 25.0
_SURCHARGE = 8.0


def priority(item, bins):
    r = (bins - item).astype(np.float64)       # residual >= 0
    score = -r                                 # base: tightest fit wins
    # Smooth penalty for unusable slivers: strongest near 0, fading to 0
    # at the waste limit.  Combine with a hard band penalty so that
    # residuals in (0, limit) are always worse than a large residual.
    in_band = (r > 0) & (r < _WASTE_LIMIT)
    frac = np.where(_WASTE_LIMIT > 0, r / _WASTE_LIMIT, 0.0)
    frac = np.clip(frac, 0.0, 1.0)
    taper = (1.0 - frac) ** 2
    score -= _SURCHARGE * taper * in_band
    # Extra strong preference for a perfect fill.
    score += 100.0 * (r == 0)
    return score
# EVOLVE-BLOCK-END
