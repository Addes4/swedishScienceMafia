# EVOLVE-BLOCK-START
"""Load-balancing rule: put the item into the emptiest bin it fits in.

With item sizes averaging ~40 out of capacity 100, tight best-fit tends
to strand many small unusable residuals.  Instead we spread the load:
choose the bin with the largest remaining capacity (worst fit), which
keeps many bins open with big reusable gaps.  A perfect fill (residual 0)
is always taken when available, since it costs nothing.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = residual.astype(np.float64)        # worst-fit: prefer large residual
    # Exact fits are always optimal: give them a dominating bonus.
    score += 1000.0 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
