# EVOLVE-BLOCK-START
"""Size-conditional bin choice: best-fit for small items, worst-fit for large.

The waste problem comes from small items filling a bin down to a tiny sliver:
a subsequent small item can't use it and the space is lost.  Best-fit makes
this sliver problem worse because it drops each small item into the tightest
gap it fits.  Large items (>= 50) rarely combine two-to-a-bin anyway, so the
residual after placing one is only usable by a still-smaller item; for those
it is better to spread them across bins (worst-fit) to keep the leftover
gaps large and reusable.  So we branch on the item size.
"""
import numpy as np

_LARGE = 50.0


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    if item >= _LARGE:
        # worst fit: leave the largest reusable residual
        return residual.astype(np.float64)
    # small items: tightest fit is best
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

