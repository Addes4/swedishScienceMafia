# EVOLVE-BLOCK-START
"""Threshold-aware best fit with item-relative waste penalty.

Pure best-fit often creates a bin whose leftover small/medium residual no
future item can use, wasting capacity.  We keep tight-fit ordering by
residual, penalise small non-zero residuals (unusable slack), and add an
item-relative term: when placing a large item, avoid leaving medium slack
below the item's size, which is unlikely to be filled by the rarer large
items.  A static Weibull histogram breaks near-ties by favouring residuals
that are likely future item sizes.
"""
import numpy as np

_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05
_REL_LIMIT = 0.5     # relative-to-item slack band fraction
_REL_WEIGHT = 3.0

_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item
    score = -residual.astype(np.float64)

    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    # item-relative: penalise medium slack below the item's own size
    rel_band = (residual > _WASTE_LIMIT) & (residual < _REL_LIMIT * item)
    score -= _REL_WEIGHT * rel_band

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _FILL[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
