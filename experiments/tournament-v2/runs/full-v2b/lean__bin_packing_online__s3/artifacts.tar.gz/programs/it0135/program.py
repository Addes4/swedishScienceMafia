# EVOLVE-BLOCK-START
"""Best-fit with graded small-slack penalty and exact-fill preference.

Pure best-fit minimizes leftover, but can strand a tiny residual that no
future item can use.  We keep tight-fit ordering by residual and add a
graded penalty to residuals in a "waste" band just above 0, smooth rather
than a flat surcharge.  Exact fills (residual == 0) always dominate.
"""
import numpy as np

# Residuals strictly between 0 and this value risk being unusable slack.
_WASTE_LIMIT = 25.0
_SURCHARGE = 0.55          # max penalty applied near residual ~1
_EXACT_BONUS = 1e6


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    score = -residual.astype(np.float64)        # base: tightest fit wins

    # Graded penalty: strongest for the smallest non-zero residuals,
    # fading linearly to zero at _WASTE_LIMIT.
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    if waste.any():
        rf = residual.astype(np.float64)
        pen = _SURCHARGE * (1.0 - rf / _WASTE_LIMIT)
        score -= np.where(waste, pen, 0.0)

    # Exact fills always preferred.
    score += _EXACT_BONUS * (residual == 0)
    return score
# EVOLVE-BLOCK-END
