# EVOLVE-BLOCK-START
"""Adaptive best fit: penalise residuals below the typical future item size.

Pure best-fit minimises immediate leftover, but frequently leaves a small
residual (say 3..25) that no later item can fill, wasting that capacity.
Since future item sizes are unknown but drawn from a fixed distribution,
we estimate the distribution online from past items and penalise residuals
that are smaller than a typical upcoming item.

Rule: score = -residual, minus a surcharge for residuals in (0, band),
where the band adapts to a running quantile of observed item sizes, and
plus a bonus for exactly filling a bin.
"""
import numpy as np

# Keep the last N item sizes to estimate the distribution cheaply.
_WINDOW = 512
_state = {"sizes": np.zeros(_WINDOW, dtype=np.float64),
          "count": 0,
          "pos": 0}


def _typical_size():
    n = _state["count"]
    if n == 0:
        return 30.0
    m = min(n, _WINDOW)
    arr = _state["sizes"][:m]
    # ~25th percentile of seen sizes: residuals below this are likely unusable.
    return float(np.percentile(arr, 25))


def priority(item, bins):
    s = _state
    s["sizes"][s["pos"]] = item
    s["pos"] = (s["pos"] + 1) % _WINDOW
    s["count"] += 1

    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    band = _typical_size()
    if band < 1.0:
        band = 1.0
    # Penalise residuals that are non-zero but below the typical future item.
    small = (residual > 0) & (residual < band)
    score -= 0.5 * band * small

    # Prefer an exact fill.
    score[residual == 0] += 1.0
    return score
# EVOLVE-BLOCK-END
