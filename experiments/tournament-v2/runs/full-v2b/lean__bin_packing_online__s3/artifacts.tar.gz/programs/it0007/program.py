# EVOLVE-BLOCK-START
"""Best-fit with a mild harmonic-consolidation bias."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins
    # Primary: prefer tight fits (small residual).
    # Secondary: mildly prefer bins that were already fuller (smaller bins),
    # which consolidates partial bins without breaking best-fit ordering.
    return -(residual) - 0.02 * bins
# EVOLVE-BLOCK-END
