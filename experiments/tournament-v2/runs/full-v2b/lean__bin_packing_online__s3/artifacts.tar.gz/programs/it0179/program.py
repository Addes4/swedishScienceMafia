# EVOLVE-BLOCK-START
"""Best fit with a small residual-viability adjustment.

Pure best fit minimizes the leftover after each placement, but some
leftovers (1..19) are so small that no future item from the Weibull-shaped
distribution (mean ~40) is likely to fill them, so they become wasted
slack.  We keep tightest-fit ordering and only gently reorder near-ties:
penalise leaving tiny unusable leftovers, and reward leaving a residual
that is exactly a plausible future item size (so it can be filled later).
"""
import numpy as np

_SMALL = 20.0        # residuals below this are likely wasted
_SMALL_PEN = 4.0     # penalty for leaving such slack
_TIE_EPS = 1.0       # only nudge scores within this band
_TIE_WEIGHT = 0.06   # strength of the fillability nudge

# Smooth, static fillability weight by residual value 1..100.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                  # >= 0 for every bin shown
    score = -residual.astype(np.float64)    # base: tightest fit wins
    waste = (residual > 0) & (residual < _SMALL)
    score -= _SMALL_PEN * waste

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _FILL[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END

