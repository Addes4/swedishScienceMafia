# EVOLVE-BLOCK-START
"""Best fit with a mild preference among near-ties to reduce gap fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority per bin; highest wins, ties to the first bin.

    Primary: minimize residual (best fit). Secondary: among near-equal residuals,
    slightly prefer bins with more remaining capacity, so we don't strand gaps
    that a future item of similar size could have used.
    """
    residual = bins - item
    # Small bonus proportional to pre-placement remaining capacity.
    return -residual.astype(np.float64) + 0.02 * bins
# EVOLVE-BLOCK-END
