# EVOLVE-BLOCK-START
"""Best fit with adaptive residual-fillability tie-break.

We maintain an online histogram of observed item sizes.  The primary
ordering is pure best fit (smallest residual).  Near-ties in residual are
broken by preferring a leftover residual r that is likely to be exactly
filled by a future item, using the adaptive histogram of sizes seen so
far (with a smooth prior).  This keeps tightest-fit ordering intact while
gently steering slack toward useful residual sizes.
"""
import numpy as np

_SIZE_MAX = 100
# Smooth prior PDF over sizes 1..100 (Weibull-shaped, mean ~40).
_S = np.arange(1, _SIZE_MAX + 1, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PRIOR = (_LAMBDA / _SCALE) * (_S / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_S / _SCALE) ** _LAMBDA)
_PRIOR = _PRIOR / _PRIOR.sum()

_PRIOR_W = 30.0          # pseudo-count weight of the prior
_TIE_EPS = 1.5           # residual near-tie window
_TIE_WEIGHT = 0.03       # strength of the fillability bonus

_state = {
    "hist": np.zeros(_SIZE_MAX + 1, dtype=np.float64),  # counts by size
    "total": 0.0,
    "fill": np.concatenate(([0.0], _PRIOR)),            # index by residual
}


def priority(item, bins):
    st = _state
    # Update adaptive histogram with the current item.
    st["hist"][item] += 1.0
    st["total"] += 1.0
    counts = st["hist"][1:] + _PRIOR_W * _PRIOR
    st["fill"][1:] = counts / counts.sum()

    residual = bins - item
    score = -residual.astype(np.float64)

    if _TIE_EPS > 0.0:
        rc = np.clip(residual, 0, _SIZE_MAX).astype(np.int64)
        fill = st["fill"][rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
