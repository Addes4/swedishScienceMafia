# EVOLVE-BLOCK-START
"""Best fit with an online exact-fit bonus.

Pure best-fit (choose the bin with the smallest remaining capacity that
still fits) is a strong, robust baseline for this distribution.  We keep
that base but add a strong bonus whenever the placement creates a
residual that exactly equals an item size observed so far, since such a
leftover is likely to be fillable by a future item, turning wasted slack
into a usable gap.  The bonus is large enough to override best-fit only
in near-ties, so the tight-fit ordering is otherwise preserved.
"""
import numpy as np

_BONUS = 1.5

_state = {"seen": None}


def priority(item, bins):
    residual = bins - item
    score = -residual.astype(np.float64)

    # Strong bonus for residuals that exactly match a previously seen
    # item size (likely fillable later).  Only affects near-ties.
    seen = _state["seen"]
    if seen is None:
        seen = np.zeros(101, dtype=bool)
    else:
        seen = seen.copy()
    # record current and past item sizes (current is the most certain)
    seen[item] = True
    fill = seen[np.clip(residual, 0, 100).astype(np.int64)]
    score = score + _BONUS * fill
    _state["seen"] = seen

    return score
# EVOLVE-BLOCK-END
