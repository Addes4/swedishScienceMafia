# EVOLVE-BLOCK-START
"""Best-fit with an online-histogram fillability tie-break.

Base rule is best-fit: the tightest residual wins.  A small surcharge
discourages leaving tiny unusable slack.  Near-ties are broken by a
dynamic histogram of the item sizes seen so far: a leftover residual is
more attractive if its value has been a common item size, so it is more
likely to be exactly filled later.  The histogram is built online, so it
adapts to whatever Weibull-shaped stream is presented without being
tuned to any single instance.
"""
import numpy as np

_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 8.0

# Online histogram over item sizes 1..100, smoothed for relative weights.
_hist = np.ones(101, dtype=np.float64)   # index 1..100 used; 0 ignored
_hist[0] = 0.0
_seen = 0

_state = {"tick": 0}


def priority(item, bins):
    global _seen
    # Update online histogram of observed item sizes (exponential forgetting
    # keeps it responsive to the actual distribution).
    _hist *= 0.999
    _hist[item] += 1.0
    _seen += 1

    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Penalise small non-zero residuals (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0:
        # Normalised fillability of the leftover residual.
        w = _hist / _hist.sum()
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = w[rc]
        # Zero residual is a perfect fill: best possible.
        fill = np.where(rc == 0, fill.max() * 2.0, fill)
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END

