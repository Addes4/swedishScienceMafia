# EVOLVE-BLOCK-START
"""Best-fit with a penalty for leaving an unusable residual (slack below the
smallest item size observed so far). This nudges the packer to avoid stranding
tiny gaps that can never be filled, which slightly improves packing density."""
import numpy as np

_MIN_ITEM = 100
_COUNT = 0


def priority(item, bins):
    global _MIN_ITEM, _COUNT
    if item < _MIN_ITEM:
        _MIN_ITEM = item
    _COUNT += 1

    residual = bins - item
    # Penalize residual values that are positive but smaller than the smallest
    # item we've seen: that slack is (likely) unusable, so treat it as loss.
    # Waste is measured as min(residual, threshold) portion that is "lost".
    thr = _MIN_ITEM
    waste = np.minimum(residual, thr)  # 0 <= waste <= thr
    # Base best-fit score (minimize residual), plus a strong penalty for waste.
    return -residual - 2.0 * waste
# EVOLVE-BLOCK-END
