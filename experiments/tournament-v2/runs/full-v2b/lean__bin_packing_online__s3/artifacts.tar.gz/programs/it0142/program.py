# EVOLVE-BLOCK-START
"""Tightest-fit base with a graded, item-size-relative waste penalty.

Best-fit (tightest residual) is near-optimal for this distribution.
The only systematic loss is leaving residuals too small to be useful,
so we apply a smooth surcharge that grows as the residual shrinks,
normalized by the current item size.  This keeps the tight-fit
ordering for large residuals while nudging ties toward usable slack.
"""
import numpy as np

_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item
    score = -residual.astype(np.float64)

    # Graded penalty: strongest for tiny residuals, fading to zero at
    # _WASTE_LIMIT.  Scaling by item size keeps it gentle for big items.
    r = residual.astype(np.float64)
    waste = (r > 0) & (r < _WASTE_LIMIT)
    grad = np.where(waste, (_WASTE_LIMIT - r) / _WASTE_LIMIT, 0.0)
    scale = min(item, _WASTE_LIMIT) / _WASTE_LIMIT
    score -= _SURCHARGE * grad * scale
    return score
# EVOLVE-BLOCK-END
