# EVOLVE-BLOCK-START
"""Best-fit with reusable-gap tie-break.

The dominant term is pure best-fit: prefer the tightest residual, which is the
strongest known online rule for Weibull(mean~40) items on capacity 100.  The
main failure mode of best-fit is leaving a sliver; a residual close to a
typical item size (~40) is highly reusable, while residuals just below a
typical item size are near-useless.  We only modulate near-ties (within 2
units) so the tight-fit ordering is never overridden, steering equal-cost
choices toward more reusable gaps.  Tie-breaking is a fixed hash of the bin
index, so it is stable and not tuned to any instance.
"""
import numpy as np

_TIE_EPS = 2.0
_REUSE_TARGET = 40.0
_REUSE_WEIGHT = 1.5
_TIE_WEIGHT = 0.01


def priority(item, bins):
    residual = bins - item                       # >= 0 for every bin shown
    score = -residual.astype(np.float64)         # pure best-fit ordering

    if _TIE_EPS > 0.0:
        # Among near-best candidates only: reward residuals close to a
        # reusable item size, penalise unusable slivers just below it.
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        idx = np.arange(residual.shape[0], dtype=np.float64)
        # stable deterministic pseudo-random tie-break keyed on bin index
        perturb = ((idx * 2654435761.0 + 12345.0) % 1000.0) / 1000.0
        # how reusable the resulting gap is (closer to a full item is better)
        gap = residual.astype(np.float64)
        reuse = -np.abs(gap - _REUSE_TARGET) / _REUSE_TARGET
        score = score + is_near * (_REUSE_WEIGHT * reuse - _TIE_WEIGHT * perturb)
    return score
# EVOLVE-BLOCK-END
