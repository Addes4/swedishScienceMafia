# EVOLVE-BLOCK-START
"""Threshold-aware best fit with histogram-guided near-tie break.

Pure best-fit often creates a bin whose small leftover (say 1..18) no
future item can use, wasting capacity.  We keep the tight-fit ordering
by residual but:
  * give a strong bonus to exact fills (residual 0) so bins get sealed,
  * apply a surcharge only to residuals in a narrow "dead slack" band
    just above 0 (too small for the lower tail of the distribution),
  * break near-ties by residual "fillability" from a static histogram
    of the known Weibull-shaped item-size distribution.
"""
import numpy as np

# Residuals strictly between 0 and this value are dead slack.
_WASTE_LIMIT = 14.0
_SURCHARGE = 7.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

# Static histogram over item sizes 1..100 (mean ~40, Weibull-shaped),
# used only as a relative "fillability" weight for residuals.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Penalise residuals that are small but non-zero (dead slack too small
    # for the lower tail of the item-size distribution to fill).
    dead = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * dead

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _FILL[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
