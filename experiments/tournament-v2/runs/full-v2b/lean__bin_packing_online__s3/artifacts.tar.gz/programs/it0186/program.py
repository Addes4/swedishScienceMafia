# EVOLVE-BLOCK-START
"""Next-fit-flavoured best fit with a residual-quality objective.

Idea: for a bin with post-placement residual r, the "value" of that
leftover is the chance a future single item can fill it *well*.  A
residual that is exactly a common item size is excellent; a tiny
residual in the gap below the typical item size is nearly worthless.

We build residual quality q(r):
  - high when r is exactly 0 (perfect fill, but rare),
  - shaped like the item-size density for positive r (so residuals
    matching likely item sizes are preferred),
  - reduced for r below the bulk of the item-size mass (unrefillable).

The final score is tightness (=-r) plus a small multiple of q(r), so
the tightest fit wins unless residuals are close, in which case the
more refillable residual is chosen.  Distribution parameters come from
the stated Weibull shape (mean ~40).
"""
import numpy as np

# --- static residual-quality table over residuals 0..100 -----------------
_R = np.arange(0, 101, dtype=np.float64)

# Weibull-shaped item-size density approximated as a smooth bump centred
# near the mean (~40); width chosen so mass spans roughly 5..90.
_MU = 40.0
_SIG = 18.0
_DENS = np.exp(-0.5 * ((_R - _MU) / _SIG) ** 2)
_DENS = _DENS / _DENS.max()

# Unrefillable small residuals: taper quality to ~0 for r well below mu.
_TAPER = np.clip((_R - 2.0) / (_MU - 2.0), 0.0, 1.0)
_Q = _DENS * _TAPER
# Perfect fill gets the top quality.
_Q[0] = 1.0
_Q = _Q / _Q.max()

_W_Q = 2.5  # weight of residual-quality term relative to tightness


def priority(item, bins):
    residual = (bins - item).astype(np.float64)   # >= 0 for shown bins
    rc = np.clip(residual, 0, 100).astype(np.int64)
    score = -residual + _W_Q * _Q[rc]
    return score
# EVOLVE-BLOCK-END
