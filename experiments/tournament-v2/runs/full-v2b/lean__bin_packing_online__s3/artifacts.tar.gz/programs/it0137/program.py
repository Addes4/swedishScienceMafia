# EVOLVE-BLOCK-START
"""Best-fit with an adaptive exact-fill bonus.

Base rule: tightest residual wins (best fit).  We add two light
corrections that exploit only information available online:

1. A strong but bounded bonus for residuals equal to a plausible future
   item size (approximated by a Weibull-shaped reference distribution).
   Filling a bin exactly removes all leftover slack later.

2. A graded penalty for residuals that are so small that few future items
   could fit, scaled by how central the residual is in the "waste" zone.

Both terms are small relative to the residual gap (which is integer), so
best-fit ordering dominates for clearly different residuals.
"""
import numpy as np

_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.max()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100

_EXACT_BONUS = 0.35      # < 1 so best-fit still dominates residual ordering
_WASTE_CENTER = 10.0     # residual band that is hardest to reuse
_WASTE_SIGMA = 12.0
_WASTE_PENALTY = 0.30


def priority(item, bins):
    residual = bins - item                      # >= 0
    rf = residual.astype(np.float64)
    score = -rf                                 # base: tightest fit

    # Graded penalty for hard-to-reuse small residuals.
    waste = (residual > 0) & (residual < 40)
    pen = _WASTE_PENALTY * np.exp(-((rf - _WASTE_CENTER) / _WASTE_SIGMA) ** 2)
    score -= pen * waste

    # Exact-fill bonus weighted by how likely that residual is a real
    # item size (single global distribution reference).
    rc = np.clip(residual, 0, 100).astype(np.int64)
    exact = residual == 0
    score += _EXACT_BONUS * exact
    score += 0.25 * _FILL[rc]
    return score
# EVOLVE-BLOCK-END
