# EVOLVE-BLOCK-START
"""Best-fit with a minimal-deviation tie-break toward fillable residuals.

The core rule is classic best fit: place the item so the resulting
residual is as small as possible (tightest fit).  This is a strong online
heuristic for the Weibull-shaped size distribution.  Prior attempts that
added large surcharges or wide near-tie bands over-corrected and hurt the
score.  Here we keep the base residual ordering exact and only perturb
bins whose residual is essentially tied with the best one, nudging the
choice toward a residual that a future item can still fill rather than a
tiny unfillable sliver.
"""
import numpy as np

# Only bins whose residual is within this of the tightest are considered
# for re-ranking.  Kept tiny so we almost always behave as pure best fit.
_TIE_EPS = 0.5
# Residuals up to this value are the hardest to reuse later (tiny slivers).
_SLIVER = 12.0
# Nudge applied when the tie-break changes which bin is chosen.
_NUDGE = 0.3

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    score = -residual.astype(np.float64)        # base: tightest fit wins

    # Among near-ties, prefer a residual that is NOT a tiny sliver, so we
    # don't lock up a bin with an unusable leftover when an equally tight
    # alternative leaves something a future item could still match.
    _state["tick"] += 1
    is_near = np.abs(score - score.max()) <= _TIE_EPS
    if is_near.any():
        sliver = (residual > 0) & (residual <= _SLIVER)
        score = score - _NUDGE * sliver * is_near
    return score
# EVOLVE-BLOCK-END
