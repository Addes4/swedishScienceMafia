# EVOLVE-BLOCK-START
"""Asymmetric residual shaping on top of best fit.

Pure best-fit creates bins whose leftover (say 3..18) is too small to be
worth reusing, wasting capacity.  We keep tight-fit ordering by residual
and apply a mild penalty only to the smallest dead-end residuals (1..11),
while giving a small bonus to slightly larger residuals that a future
item could plausibly use.  Near-ties are broken by preferring residuals
that are common item sizes (most likely to be exactly filled later).
"""
import numpy as np

_SMALL_DEAD = 11                 # residuals 1..11 are mostly wasted slack
_DEAD_PENALTY = 3.0
_BONUS_LO = 12
_BONUS_HI = 45
_BONUS = 1.2
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

# Static surrogate histogram over item sizes 1..100 (mean ~40, Weibull),
# used only as a relative "fillability" weight for residuals.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    dead = (residual > 0) & (residual <= _SMALL_DEAD)
    score -= _DEAD_PENALTY * dead

    bonus = (residual >= _BONUS_LO) & (residual <= _BONUS_HI)
    score += _BONUS * bonus

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _FILL[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END

