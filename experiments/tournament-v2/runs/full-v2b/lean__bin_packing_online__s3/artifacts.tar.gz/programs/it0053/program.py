# EVOLVE-BLOCK-START
"""Best fit with a smooth, near-zero-concentrated waste penalty.

The main failure of pure best fit on a Weibull(~40) item stream is that it
keeps choosing bins that leave tiny, unusable slivers (1..k) behind.  Instead
of a flat surcharge over a wide band, we penalise any non-zero residual with
a penalty that decays smoothly, so exact fits dominate but a residual that is
clearly large enough to host a future item is barely penalised relative to a
sliver.  Residuals are integers, so the penalty is graded by residual value.
"""
import numpy as np

# Any residual below this is considered "slack that a future item may fail to
# use"; the penalty decays as residual grows toward this value.
_REUSE = 40.0
_SCALE = 8.0          # strength of the sliver penalty


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    # Base: tightest fit wins.
    score = -residual.astype(np.float64)
    # Smooth penalty concentrated near residual 0 but extending to _REUSE.
    # Exact fits (residual == 0) get no penalty; small positives get a lot.
    frac = np.clip(residual / _REUSE, 0.0, 1.0)
    # f = 1 at residual 0, decays to 0 at residual >= _REUSE
    f = (1.0 - frac) ** 2
    # zero out the penalty for exact fits
    f = np.where(residual <= 0, 0.0, f)
    score -= _SCALE * f
    return score
# EVOLVE-BLOCK-END
