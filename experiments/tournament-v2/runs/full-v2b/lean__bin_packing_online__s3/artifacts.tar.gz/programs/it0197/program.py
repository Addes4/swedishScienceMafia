# EVOLVE-BLOCK-START
"""Adaptive best fit.

Pure best-fit is strong here, so keep residual-minimization as the
backbone.  Add two refinements:
  1. A small bonus for a perfect fit (residual 0).
  2. Within a very tight residual tie band, prefer the bin whose
     leftover residual is most likely to be exactly fillable by a
     future item, using an online exponential-decay histogram of
     observed item sizes (so it adapts to the true distribution).
"""
import numpy as np

_WASTE_LIMIT = 12.0     # truly unusable slack above 0
_SURCHARGE = 3.0        # mild penalty for that slack
_TIE_EPS = 1.0          # very tight near-tie band
_TIE_WEIGHT = 0.6       # weight of fillability within the band
_PERFECT_BONUS = 0.05   # nudge toward exact fills

# Online exponential-decay histogram over residual sizes 0..100.
_HIST = np.zeros(101, dtype=np.float64)
_DECAY = 0.995
_HIST[0] = 1.0


def priority(item, bins):
    residual = bins - item
    r = residual.astype(np.float64)

    score = -r                                  # best-fit backbone
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste
    score += _PERFECT_BONUS * (residual == 0)

    # Update online histogram of observed item sizes (sizes 1..100).
    global _HIST
    _HIST *= _DECAY
    if 1 <= item <= 100:
        _HIST[item] += 1.0

    if _TIE_EPS > 0.0:
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _HIST[rc]
        m = fill.max()
        fill = fill / m if m > 0 else fill
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
