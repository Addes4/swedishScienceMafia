# EVOLVE-BLOCK-START
"""Threshold-aware best fit with a large-item fresh-bin preference.

Pure best-fit sometimes packs a large item into a bin where it nearly
fills it, leaving a small, unusable leftover.  We keep the tightest-fit
ordering by residual, apply a surcharge to residuals in a "waste" band
just above 0, and additionally give a mild bonus to completely unused
bins (remaining capacity 100) when the current item is large, so that
big items tend to start fresh bins whose slack is more likely to be
reusable than the tiny leftover of a nearly-full bin.
"""
import numpy as np

# Residuals strictly between 0 and this value are treated as wasted slack.
_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
# Items at least this large prefer a fresh (unused) bin slightly.
_LARGE_ITEM = 60.0
_FRESH_BONUS = 3.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise residuals that are small but non-zero (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    if item >= _LARGE_ITEM:
        # Prefer a fresh bin for large items unless a fit is nearly exact.
        fresh = (bins == 100)
        score += _FRESH_BONUS * fresh

    return score
# EVOLVE-BLOCK-END
