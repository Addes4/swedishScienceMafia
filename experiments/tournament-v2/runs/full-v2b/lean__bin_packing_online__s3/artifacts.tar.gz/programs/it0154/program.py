# EVOLVE-BLOCK-START
"""Best-fit with an expected-utility correction for stranded slack.

Base rule is tightest-fit (best-fit), which is near-optimal online.
The only correction: a nonzero residual r is valuable only if some future
item can still fit in it.  Using the known Weibull-shaped size
distribution, the probability that a future item fits in r is CDF(r),
and the expected usable space is r * CDF(r).  We subtract the *lost*
expected utility (r * (1 - CDF(r))) as a mild penalty, so bins whose
leftover would become stranded slack are slightly disfavored while true
tight fits still win.  This is smooth and monotone, no hard cutoff.
"""
import numpy as np

# Static Weibull-shaped CDF over item sizes 1..100 (mean ~40).
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_CDF = 1.0 - np.exp(-(_SIZE / _SCALE) ** _LAMBDA)
# index by residual 0..100
_CDF_TABLE = np.concatenate(([0.0], _CDF))

_UTIL_WEIGHT = 1.0


def priority(item, bins):
    residual = bins - item                       # >= 0 for every bin shown
    r = residual.astype(np.float64)
    # Base best-fit ordering (tighter wins), higher score = better.
    score = -r
    # Mild correction: punish stranded slack (residual unlikely to be reused).
    rc = np.clip(residual, 0, 100).astype(np.int64)
    p_fit = _CDF_TABLE[rc]
    lost = r * (1.0 - p_fit)                      # expected unusable space
    score -= _UTIL_WEIGHT * lost
    return score
# EVOLVE-BLOCK-END
