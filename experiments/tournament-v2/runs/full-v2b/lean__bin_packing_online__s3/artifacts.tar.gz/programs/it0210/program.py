# EVOLVE-BLOCK-START
"""Best-fit backbone with an online-learned residual reusability tie-break.

Pure best-fit is hard to beat, but among bins whose leftover residual is
nearly identical we can prefer the one that historically was more often
reused (i.e., received another item later).  We track, per residual value
1..100, how many bins with that leftover survived long enough to be reused,
giving a dynamic "reusability" weight that adapts to the actual instance.
"""
import numpy as np

_TIE_EPS = 1.5
_TIE_WEIGHT = 0.4
_LR = 0.02  # exponential update rate for reusability estimates

# reuse[ r ] ~ fraction of bins with residual r that later got another item.
_reuse = np.ones(101, dtype=np.float64) * 0.5
# count of times we've seen a bin at residual r
_seen = np.zeros(101, dtype=np.float64)
# track last chosen bin residual to credit reuse
_last = {"r": -1}


def priority(item, bins):
    residual = bins - item
    r = int(residual.min())

    # credit the previously chosen bin: if it now appears at a smaller
    # residual than before, it was reused (placed another item).
    prev = _last["r"]
    if prev > 0:
        reuse_signal = 1.0 if r != prev else 0.0
        _reuse[prev] += _LR * (reuse_signal - _reuse[prev])
        _seen[prev] += 1.0

    score = -residual.astype(np.float64)
    if _TIE_EPS > 0.0:
        rc = np.clip(residual, 0, 100).astype(np.int64)
        weight = _reuse[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * weight * is_near

    # remember chosen bin's resulting residual
    chosen = int(np.argmax(score))
    _last["r"] = int(residual[chosen])
    return score
# EVOLVE-BLOCK-END
