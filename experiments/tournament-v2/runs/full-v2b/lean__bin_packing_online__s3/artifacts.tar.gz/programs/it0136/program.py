# EVOLVE-BLOCK-START
"""Best fit with a narrow graded waste penalty and exact-fill bonus.

Pure best-fit (tightest residual wins) is the strongest simple rule for
this Weibull-shaped distribution.  The only refinement that tends to help
is discouraging leftovers that are too small to ever be filled: residuals
just above 0 (roughly below the typical minimum item size) are almost
certainly permanent waste, so we add a small graded surcharge that grows as
the residual shrinks toward 1.  Exact fills (residual == item, giving 0)
are rewarded so they are chosen whenever available.
"""
import numpy as np

# Leftovers in (0, _WASTE_BAND) are likely never fillable -> mild penalty,
# graded so that a leftover of 1 is worst and near-band residuals least bad.
_WASTE_BAND = 16.0
_WASTE_PENALTY = 2.0
_EXACT_BONUS = 3.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Graded penalty for tiny unusable leftovers.
    waste = (residual > 0) & (residual < _WASTE_BAND)
    if waste.any():
        grad = (_WASTE_BAND - residual) / _WASTE_BAND   # in (0, 1]
        score -= _WASTE_PENALTY * grad * waste

    # Strongly prefer a bin that is exactly filled by this item.
    exact = residual == 0
    if exact.any():
        score += _EXACT_BONUS * exact

    return score
# EVOLVE-BLOCK-END

