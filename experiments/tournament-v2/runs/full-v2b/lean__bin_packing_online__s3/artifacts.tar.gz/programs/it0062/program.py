# EVOLVE-BLOCK-START
"""Best fit with history-driven residual reusability bonus.

Classic best fit (tightest residual) is the strong baseline; its weakness is
that tiny leftovers often sit forever unused.  We keep -residual dominant and
add a small stateful bonus for residuals that past items have shown to be
"closable" sizes: if many past items were near the residual value, then a
future item may fill that gap exactly, so the bin is slightly more valuable.
A tiny rotating tie-break avoids always resolving ties to the lowest index.
"""
import numpy as np

_BIN = 5000  # 5000 items per instance
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.03
_BONUS_SCALE = 0.35   # weight of the reusability bonus

# State across calls: running histogram of item sizes (1..100).
_state = {"tick": 0, "hist": np.zeros(101, dtype=np.float64), "total": 0.0}


def priority(item, bins):
    st = _state
    # Update running item-size histogram (with mild decay for adaptivity).
    st["hist"] *= 0.999
    st["hist"][item] += 1.0
    st["total"] = st["total"] * 0.999 + 1.0

    residual = bins - item                      # >= 0 for every bin shown
    score = -residual.astype(np.float64)

    # Reusability bonus: probability that residual is close to a common size.
    hist = st["hist"]
    tot = max(st["total"], 1.0)
    r = residual.astype(np.int64)
    r = np.clip(r, 0, 100)
    # Mass within +/- 2 of residual (past items that could fit/close this gap).
    lo = np.maximum(r - 2, 1)
    hi = np.minimum(r + 2, 100)
    # build cumulative sums once
    csum = np.concatenate(([0.0], np.cumsum(hist)))
    mass = csum[hi] - csum[lo - 1]
    prob = mass / tot
    score += _BONUS_SCALE * prob * (residual > 0)

    # Small rotating tie-break to avoid fixed index bias on near-ties.
    st["tick"] += 1
    idx = np.arange(residual.shape[0], dtype=np.float64)
    perturb = ((idx * 2654435761.0 + st["tick"] * 40503.0) % 1000.0) / 1000.0
    is_near = np.abs(score - score.max()) <= _TIE_EPS
    score = score - _TIE_WEIGHT * perturb * is_near
    return score
# EVOLVE-BLOCK-END
