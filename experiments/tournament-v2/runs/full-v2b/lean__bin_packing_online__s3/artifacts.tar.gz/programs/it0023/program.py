# EVOLVE-BLOCK-START
"""Best-fit with a tiny consolidation tiebreaker.

Core rule: minimize residual-after-placement (best fit).  Because items
are integers, residuals are integers, so many bins tie at the same
residual.  When such ties occur, packing into the bin that is already
more filled tends to consolidate load and avoids spreading items across
many partially-used bins, which can leave more bins effectively idle.
The tiebreaker weight is < 1 so it never overrides the primary
residual minimization; it only decides among equal-residual bins.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item                      # integer, >= 0 for shown bins
    # Pre-placement fill (higher -> more loaded bin).
    fill = 100 - bins                           # 0..99
    # Primary: tightest fit (smallest residual).  Secondary: prefer the
    # more-filled bin, scaled below 1 so it is only a tiebreaker.
    score = -residual.astype(np.float64) + 0.001 * fill.astype(np.float64)
    return score
# EVOLVE-BLOCK-END

