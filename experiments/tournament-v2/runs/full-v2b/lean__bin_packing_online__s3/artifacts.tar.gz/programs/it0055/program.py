# EVOLVE-BLOCK-START
"""Frequency-aware best-fit.

Best-fit-by-residual wastes capacity when it creates slivers too small for
future items.  Instead of a flat waste band we value each residual by how
much of the remaining item distribution it can still absorb: a gap that can
host many typical items is worth more than a tight sliver.  We combine that
"expected reuse value" with the usual tightness preference, plus a light
stateful tie-break so equal choices rotate over bin indices.
"""
import numpy as np

# Precomputed tail mass of the (mean ~40 Weibull-like) item distribution:
# fraction of future items with size >= s.  Monotone decreasing in s.
# Values are a smooth approximation: P(size >= s) ~ exp(-(s/lambda)^k) with
# lambda ~ 45, k ~ 1.2 calibrated to mean 40.
_LAM = 45.0
_K = 1.2
_REUSE_WEIGHT = 0.6
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item
    r = residual.astype(np.float64)

    # Expected number of future items this gap can still absorb, using the
    # tail distribution of item sizes: integral / sum of P(size <= r).
    # P(size <= r) = 1 - exp(-(r/_LAM)^_K) for r >= 0.
    p_fit = 1.0 - np.exp(-np.power(np.maximum(r, 0.0) / _LAM, _K))
    reuse = r * p_fit  # capacity usable by a likely-size next item

    # Base tightness preference (best fit) plus reuse bonus; exact fit is best.
    score = -r + _REUSE_WEIGHT * reuse

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        idx = np.arange(r.shape[0], dtype=np.float64)
        perturb = ((idx * 2654435761.0 + _state["tick"] * 40503.0) % 1000.0) / 1000.0
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score - _TIE_WEIGHT * perturb * is_near
    return score
# EVOLVE-BLOCK-END
