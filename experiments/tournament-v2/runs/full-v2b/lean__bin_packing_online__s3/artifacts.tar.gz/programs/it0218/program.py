# EVOLVE-BLOCK-START
"""Penalised best fit with smooth residual utility.

Base ordering is tight-fit (smallest residual first).  On top of that we
add a smooth, always-active utility of the resulting residual:

  * residual 0 (exact fill) gets the biggest bonus;
  * residuals that are likely future item sizes (Weibull shape, mean ~40)
    get a mild bonus so the leftover stays fillable;
  * tiny residuals (1..~12) that no future item will fit get a penalty.

All terms are small relative to the dominant -residual ordering so the rule
degrades gracefully to best-fit when little is gained.
"""
import numpy as np

# Weibull-like static distribution of item sizes 1..100 (mean about 40).
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()

_SLIVER = 12                 # residuals <= this are effectively dead
_SLIVER_PENALTY = 4.0
_FILL_BONUS = 1.2
_EXACT_BONUS = 1.5

# Precompute per-residual utility for residuals 0..100.
_UTIL = np.zeros(101, dtype=np.float64)
_UTIL[1:_SLIVER + 1] = -_SLIVER_PENALTY
_UTIL[1:101] += _FILL_BONUS * _PDF  # fillability bonus for r>=1
_UTIL[0] = _EXACT_BONUS              # exact fill is best


def priority(item, bins):
    residual = bins - item               # >= 0 for every bin shown
    score = -residual.astype(np.float64)
    rc = np.clip(residual, 0, 100).astype(np.int64)
    score += _UTIL[rc]
    return score
# EVOLVE-BLOCK-END

