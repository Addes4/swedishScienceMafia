# EVOLVE-BLOCK-START
"""Threshold-aware best fit with online histogram-guided near-tie break.

Pure best-fit often creates a bin whose small leftover (say 3..18) no
future item can use, wasting capacity.  We keep the tight-fit ordering
by residual and apply a surcharge to residuals in a "waste" band just
above 0.  Additionally, near-ties in residual are broken by preferring
the bin whose leftover residual is a *likely* future item size (so it
can be exactly filled later), using an ONLINE histogram of item sizes
observed so far.  This adapts to the actual instance distribution.
"""
import numpy as np

# Residuals strictly between 0 and this value are treated as wasted slack.
_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

# Online histogram over item sizes 1..100, with a smoothing prior so it is
# well-defined on the very first items.
_PRIOR = 1.0
_HIST = np.zeros(101, dtype=np.float64)  # index 1..100

_state = {"n": 0}


def priority(item, bins):
    # Update the online histogram with the current item.
    if 1 <= item <= 100:
        _HIST[item] += 1.0
    _state["n"] += 1

    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise residuals that are small but non-zero (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0:
        # Near-ties: prefer a leftover residual that is likely to be
        # exactly fillable by a future item, per the online histogram.
        rc = np.clip(residual, 0, 100).astype(np.int64)
        # Fillability weight: smoothed frequency of size == residual.
        fill = (_HIST[rc] + _PRIOR) / (_state["n"] + 100.0 * _PRIOR)
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
