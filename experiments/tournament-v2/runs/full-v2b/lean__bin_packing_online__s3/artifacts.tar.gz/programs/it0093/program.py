# EVOLVE-BLOCK-START
"""Threshold-aware best fit with online-histogram near-tie break.

Pure best-fit often creates a bin whose small leftover (say 3..18) no
future item can use, wasting capacity.  We keep the tight-fit ordering
by residual and apply a surcharge to residuals in a "waste" band just
above 0.  Additionally, near-ties in residual are broken by preferring
the bin whose leftover residual is a *likely* future item size (so it
can be exactly filled later), using an online histogram of observed item
sizes rather than a fixed surrogate.
"""
import numpy as np

# Residuals strictly between 0 and this value are treated as wasted slack.
_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.6

# Online histogram over item sizes 1..100, updated as items arrive.
_counts = np.ones(101, dtype=np.float64)   # Laplace-smoothed counts (idx 0 unused)
_totals = 101.0


def priority(item, bins):
    global _totals
    # Update empirical distribution with the newest item.
    if 1 <= item <= 100:
        _counts[item] += 1.0
        _totals += 1.0
    fill = _counts / _totals               # empirical probability per size

    residual = bins - item                 # >= 0 for every bin shown
    score = -residual.astype(np.float64)   # base: tightest fit wins
    # Penalise residuals that are small but non-zero (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0:
        # Near-ties: prefer a leftover residual likely to be exactly
        # fillable by a future item, per the learned histogram.
        rc = np.clip(residual, 0, 100).astype(np.int64)
        f = fill[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * f * is_near
    return score
# EVOLVE-BLOCK-END
