# EVOLVE-BLOCK-START
"""Best-fit with a graded penalty for small unusable slack.

The dominant ordering is tightest fit (largest residual below item wins,
i.e. score = -residual).  On top of that we apply a *graded* penalty to
residuals that are small but nonzero: the smaller the leftover, the less
likely any future item can exactly fill it, so waste bands near 0 are the
most harmful.  A residual equal to the current item is impossible here
(item always fits, so residual>=0 and residual==0 means exact fit), so we
give a bonus to exact fills (residual 0).
"""
import numpy as np

_EXACT_BONUS = 8.0        # reward putting item into a bin it fully fills
_WASTE_START = 25.0       # residuals below this risk becoming dead slack
_WASTE_MAX = 4.0          # max penalty at residual == 1
_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    r = residual.astype(np.float64)
    score = -r                                 # base: tightest fit wins

    # Exact fill (residual 0) is strictly the best outcome.
    score = score + _EXACT_BONUS * (r == 0.0)

    # Graded waste penalty: worst for tiny positive leftovers, fading to
    # zero at _WASTE_START.  Penalty = _WASTE_MAX * (1 - (r-1)/span).
    span = _WASTE_START - 1.0
    waste = (r > 0.0) & (r < _WASTE_START)
    grad = _WASTE_MAX * (1.0 - (r - 1.0) / span)
    score = score - np.where(waste, grad, 0.0)

    return score
# EVOLVE-BLOCK-END
