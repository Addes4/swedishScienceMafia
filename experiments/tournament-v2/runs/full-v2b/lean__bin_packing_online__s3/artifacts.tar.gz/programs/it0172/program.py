# EVOLVE-BLOCK-START
"""Best fit with an adaptive "fillable residual" tie-break.

Pure best-fit creates bins with tiny leftovers no future item can use.
We keep tightest-fit ordering (smallest residual) but break near-ties by
preferring a leftover residual large enough to host a future item of at
least the smallest size seen recently.  The threshold is tracked online
from observed items, so it adapts to the distribution without tuning.
"""
import numpy as np

_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

# Running statistics of observed items, updated each call.
_state = {"n": 0, "min_seen": 100.0}


def priority(item, bins):
    # Update running minimum size of items seen so far.
    _state["n"] += 1
    if item < _state["min_seen"]:
        _state["min_seen"] = float(item)

    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Penalise residuals that are small but non-zero (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0:
        # Near-ties: prefer a residual that is at least the smallest item
        # seen so far, i.e. a leftover a future item could still fit into.
        threshold = _state["min_seen"]
        fillable = (residual >= threshold) | (residual == 0)
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fillable * is_near

    return score
# EVOLVE-BLOCK-END
