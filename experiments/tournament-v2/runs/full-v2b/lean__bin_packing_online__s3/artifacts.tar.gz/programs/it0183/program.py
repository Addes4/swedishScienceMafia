# EVOLVE-BLOCK-START
"""Adaptive best-fit with self-learning fillability tie-break.

Backbone: pure tightest-fit (smallest residual after placement wins).
Tie-break: among bins whose residuals are within a tiny band, prefer the
one whose leftover residual is most likely to be exactly refilled later.
The "likelihood" is not assumed: it is a running histogram of item sizes
seen so far, so the rule adapts to the real (unknown) distribution.
"""
import numpy as np

_TIE_EPS = 1.0
_TIE_WEIGHT = 0.5

_state = {"counts": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    counts = _state["counts"]
    counts[item] += 1.0
    # Normalize by total so far to get an empirical PMF over sizes 1..100.
    total = counts.sum()
    pmf = counts / total

    residual = bins - item
    score = -residual.astype(np.float64)

    if _TIE_EPS > 0.0:
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = pmf[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
