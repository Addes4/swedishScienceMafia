# EVOLVE-BLOCK-START
"""Distribution-ranked best fit.

Use pure best fit (tightest post-placement residual) as the backbone, but
reshape the score with a concave "value" function over the residual so that
exact fills and likely-refillable leftovers are preferred, while truly tiny
unusable leftovers are discouraged.  The value function is derived from the
known Weibull-shaped item-size distribution (mean ~40).

value(r) is high at r = 0 (perfect fill) and where the density of future
item sizes is large, and drops for residuals that are unlikely to be
matched exactly. Because value is added to -r, best fit stays dominant and
the reshaping only arbitrates near-ties in residual.
"""
import numpy as np

# Static distribution over item sizes 1..100 (Weibull-shaped, mean ~40).
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.max()

# Fillability of a residual r: density of a future item exactly matching r.
# Index 0 is the perfect-fill slot; give it the top value.
_FILL = np.concatenate(([1.0], _PDF))  # residual 0..100

# Penalty for residuals too small to be exactly matched by common items.
_TINY = 6.0
_TINY_PEN = 1.5

# Weight of the reshaping relative to the raw residual term (which is -r).
_W = 3.0


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    r = residual.astype(np.float64)
    score = -r                                  # best-fit backbone

    rc = np.clip(residual, 0, 100).astype(np.int64)
    score += _W * _FILL[rc]

    tiny = (residual > 0) & (residual < _TINY)
    score -= _TINY_PEN * tiny
    return score
# EVOLVE-BLOCK-END
