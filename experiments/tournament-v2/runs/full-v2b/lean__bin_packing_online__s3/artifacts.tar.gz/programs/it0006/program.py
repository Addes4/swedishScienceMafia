# EVOLVE-BLOCK-START
"""Best fit with a tiny consolidation bias toward already-used bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual).
    # Tiny tie-break: among near-equal residuals, prefer the bin that is
    # currently more full (smaller remaining capacity) to close it off.
    return -residual - 1e-3 * bins
# EVOLVE-BLOCK-END
