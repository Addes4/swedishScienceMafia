# EVOLVE-BLOCK-START
"""Best-fit backbone with a mild surcharge on only the tiniest leftovers.

We keep the tightest-fit ordering by residual and apply a small surcharge
only to residuals in a very narrow "waste" band just above 0, where a
future item is very unlikely to fill the gap.  Moderately small residuals
are left untouched so best-fit ordering dominates.
"""
import numpy as np

# Only residuals strictly between 0 and this value are treated as waste.
_WASTE_LIMIT = 8.0
_SURCHARGE = 3.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.02

# Static histogram over item sizes 1..100 (mean ~40, Weibull-shaped),
# used only as a relative "fillability" weight for residuals.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise only the tiniest non-zero residuals (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0:
        # Near-ties: prefer a leftover residual likely to be exactly fillable.
        _state["tick"] += 1
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _FILL[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
