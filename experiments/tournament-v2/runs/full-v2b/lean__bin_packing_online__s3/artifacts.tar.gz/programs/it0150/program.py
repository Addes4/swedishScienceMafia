# EVOLVE-BLOCK-START
"""Tightest-fit base with a smooth fillability bonus.

Pure best-fit (rank by smallest residual) is near-optimal for this
distribution.  The only reliable edge comes from breaking near-ties in
residual by preferring the leftover that a future item is most likely
to fill *exactly*, using a smooth static histogram of the item-size
distribution.  No hard waste cutoffs, no per-item state.
"""
import numpy as np

# Static histogram over item sizes 1..100 (mean ~40, Weibull-shaped),
# used only as a relative "fillability" weight for residuals.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))          # index by residual 1..100
_FILL = _FILL / _FILL.max()                    # scale to [0, 1]

_TIE_EPS = 1.0
_TIE_WEIGHT = 0.10


def priority(item, bins):
    residual = bins - item                       # >= 0 for every bin shown
    score = -residual.astype(np.float64)         # base: tightest fit wins

    # Near-ties in residual: prefer a leftover that is likely to be
    # exactly fillable by a future item (a reusable, non-stranded slack).
    rc = np.clip(residual, 0, 100).astype(np.int64)
    fill = _FILL[rc]
    is_near = np.abs(residual - residual.min()) <= _TIE_EPS
    score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
