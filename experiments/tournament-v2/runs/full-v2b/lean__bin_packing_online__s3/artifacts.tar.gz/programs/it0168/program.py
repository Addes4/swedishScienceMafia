# EVOLVE-BLOCK-START
"""Best-fit with soft avoidance of tiny unusable leftovers.

Pure best-fit is strong for this distribution.  Its main failure mode is
choosing a bin that leaves a tiny residual (say 1..9) no future item can
use.  We keep the tight-fit ordering (score = -residual) but add a mild
penalty only for residuals in that genuinely unusable tiny band, so the
algorithm prefers a slightly looser fit that leaves usable room.
"""
import numpy as np

# Residuals strictly between 0 and this value are too small to be filled
# by almost any future item and are effectively wasted slack.
_TINY = 10.0
_PENALTY = 3.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Mildly penalise tiny, unusable leftovers (but not an exact fill).
    tiny = (residual > 0) & (residual < _TINY)
    score -= _PENALTY * tiny
    return score
# EVOLVE-BLOCK-END
