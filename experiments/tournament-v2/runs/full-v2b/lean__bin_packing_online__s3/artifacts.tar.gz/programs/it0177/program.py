# EVOLVE-BLOCK-START
"""Tightest-fit (best-fit) with a light preference for not consuming fresh bins.

Pure best fit minimizes the resulting residual, which is a strong baseline.
When several bins yield the same residual, picking an already-used bin keeps
a full (capacity 100) bin available for a future large item, which tends to
reduce wasted slack.  Full unused bins are exactly those with capacity 100,
so we add a tiny bonus to bins whose current capacity is less than 100 to
break ties in favor of partially-filled bins.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item                       # >= 0 for every bin shown
    score = -residual.astype(np.float64)         # base: tightest fit wins
    # Tiny tie-break: prefer partially-used bins over full unused bins so a
    # fresh bin is preserved for a possible future large item.
    fresh = bins >= 100
    score -= 1e-3 * fresh
    return score
# EVOLVE-BLOCK-END

