# EVOLVE-BLOCK-START
"""Best fit with a tiny unusable-slack penalty.

Pure best-fit (smallest residual) is the strongest simple online rule for
this Weibull-like size distribution.  The one systematic loss is a residual
that is small but nonzero: future items are mostly large, so a leftover of a
few units is rarely reusable.  We therefore subtract a small surcharge for
residuals in (0, _WASTE_LIMIT), preferring either exact fits or clearly
reusable gaps.  Small residuals are ranked essentially by residual, so the
ordering stays deterministic (smallest residual first, ties to lowest index).
"""
import numpy as np

_WASTE_LIMIT = 12.0
_SURCHARGE = 4.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise residuals that are small but non-zero (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste
    return score
# EVOLVE-BLOCK-END
