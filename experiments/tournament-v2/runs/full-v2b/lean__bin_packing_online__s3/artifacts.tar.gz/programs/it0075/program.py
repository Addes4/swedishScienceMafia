# EVOLVE-BLOCK-START
"""Best-fit with an online-learned residual penalty.

The core rule is best-fit (tightest residual wins), which is known to be
strong for this class of distributions.  The improvement over a purely
static waste band is that the "how bad is this leftover?" judgement is
learned online from the histogram of item sizes actually observed:

  * a residual r is *good* if some observed item size is <= r (it might be
    filled later), and especially good if r is itself a common item size;
  * a residual r is *bad* (wasted) if it is smaller than the smallest item
    we have seen so far -- no future item of that size class can use it.

We also keep a tiny rotating perturbation to break near-ties across
different bin indices instead of always absorbing slack in bin 0.
"""
import numpy as np

_HIST_SIZE = 101                      # item sizes are 1..100
_MIN_SAMPLES = 200                    # before that, fall back to static band

_STATE = {
    "hist": np.zeros(_HIST_SIZE, dtype=np.float64),
    "count": 0.0,
    "tick": 0,
}

# Fallback constants used until enough items have been observed.
_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0

_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05
_PENALTY_SCALE = 6.0


def priority(item, bins):
    st = _STATE
    hist = st["hist"]
    st["tick"] += 1

    residual = bins - item                       # >= 0 for bins shown
    score = -residual.astype(np.float64)         # base: best fit

    if st["count"] >= _MIN_SAMPLES:
        # Empirical item-size distribution from everything seen so far.
        total = st["count"]
        # probability that some observed size can fill a gap of r:
        # use the largest observed size <= r as a proxy for fillability,
        # and weight by how common sizes near r are.
        # Cumulative count of sizes <= r:
        cum = np.cumsum(hist)                    # cum[r] = #items <= r
        # Smallest observed size (first positive bin in hist):
        nz = np.nonzero(hist)[0]
        min_size = nz[0] if nz.size else 1
        max_size = nz[-1] if nz.size else 100

        r_int = np.clip(residual.astype(np.int64), 0, _HIST_SIZE - 1)
        # Probability that a future item exactly fits the residual:
        p_exact = hist[r_int] / total
        # Fraction of observed items that are <= r (i.e. could be used):
        p_usable = cum[r_int] / total

        # Penalty: high when the leftover is unusable (below min_size) or
        # hard to fill exactly (low p_exact / low p_usable), zero when it is
        # a strong candidate to be completed.  Residuals above the largest
        # observed size are still fine (room for anything we've seen).
        bad = (r_int > 0) & (r_int < min_size)
        hard = (r_int > 0) & (r_int <= max_size)

        penalty = np.where(bad, 1.0,
                  np.where(hard,
                           np.clip(0.5 * (1.0 - p_usable)
                                   + 0.5 * (1.0 - p_exact) * 3.0, 0.0, 1.0),
                           0.0))
        score -= _PENALTY_SCALE * penalty
    else:
        waste = (residual > 0) & (residual < _WASTE_LIMIT)
        score -= _SURCHARGE * waste

    # Record this item for future calls.
    if 1 <= item < _HIST_SIZE:
        hist[item] += 1.0
    st["count"] += 1.0

    # Small rotating perturbation to break near-ties across bin indices.
    idx = np.arange(residual.shape[0], dtype=np.float64)
    perturb = ((idx * 2654435761.0 + st["tick"] * 40503.0) % 1000.0) / 1000.0
    is_near = np.abs(score - score.max()) <= _TIE_EPS
    score = score - _TIE_WEIGHT * perturb * is_near
    return score
# EVOLVE-BLOCK-END
