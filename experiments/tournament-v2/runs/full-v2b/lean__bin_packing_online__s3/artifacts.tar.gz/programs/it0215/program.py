# EVOLVE-BLOCK-START
"""Best fit with online-learned residual fillability bonus.

The base rule is classic best-fit: tightest fitting bin wins.  Pure
best-fit is strong but can leave occasional unusable slivers.  To mitigate
that we add a small, bounded bonus to every bin whose *new* leftover
residual is likely to be exactly matched by a future item, using an online
histogram of observed item sizes (with a light fallback prior).  The bonus
is kept small so the tight-fit ordering dominates and the rule degrades
gracefully to best-fit.
"""
import numpy as np

_MAXSIZE = 100

# Online histogram of observed item sizes (1..100), with smoothing prior.
_prior = np.ones(_MAXSIZE + 1, dtype=np.float64)  # index 0 unused
_counts = _prior.copy()
_alpha = 0.95  # decay for non-stationarity robustness

# Bonus weight kept small relative to the residual gap (which is >=1).
_BONUS = 0.08


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown

    # Update online item-size histogram (cheap, once per item).
    _counts *= _alpha
    if 1 <= item <= _MAXSIZE:
        _counts[item] += 1.0

    total = _counts[1:].sum()
    if total > 0:
        pdf = _counts[1:] / total
    else:
        pdf = _prior[1:] / _prior[1:].sum()

    # Base: tightest fit wins.
    score = -residual.astype(np.float64)

    # Bonus: prefer leftovers that are likely future item sizes, so the
    # bin can be exactly filled again instead of stranding slack.
    rc = np.clip(residual, 0, _MAXSIZE).astype(np.int64)
    fill = pdf[np.maximum(rc - 1, 0)]
    fill = np.where(rc > 0, fill, 0.0)
    score = score + _BONUS * fill

    return score
# EVOLVE-BLOCK-END
