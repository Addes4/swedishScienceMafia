# EVOLVE-BLOCK-START
"""Threshold-aware best fit with a consolidation bias.

Pure best-fit minimises residual-after-placement, which is nearly optimal
greedy, but it can spread items across many partially-filled bins.  Here we
keep the tight-fit rule and add two small corrections:

1. A surcharge on tiny unusable residuals (0 < residual < _WASTE_LIMIT), to
   avoid stranding slack that no future item can reuse.
2. A small bonus proportional to the bin's existing fill level, which biases
   toward consolidating items into already-well-filled bins.

These are cheap and only reorder near-ties, so the tight-fit core dominates.
"""
import numpy as np

# Residuals strictly between 0 and this value are treated as wasted slack.
_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
# Weight for the consolidation bonus on pre-placement fill.
_FILL_BONUS = 0.02


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    score = -residual.astype(np.float64)        # base: tightest fit wins
    # Penalise residuals that are small but non-zero (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste
    # Mild preference for more-filled bins (lower remaining capacity).
    score -= _FILL_BONUS * bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
