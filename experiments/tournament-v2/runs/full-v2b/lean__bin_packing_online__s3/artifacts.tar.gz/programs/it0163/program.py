# EVOLVE-BLOCK-START
"""Threshold-aware best fit with a dynamic slack penalty.

Pure best-fit occasionally leaves a small residual that few future items
can use.  Rather than a fixed band, we penalize slack that is too small
to hold a typical item: for each bin we compute its leftover after
placing the item and charge a mild surcharge proportional to how
"useless" that slack is, measured by the current average item size seen
so far.  This keeps the tight-fit ordering but avoids dead leftovers.
"""
import numpy as np

_state = {"sum": 0.0, "count": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Track mean item size seen so far (cheap online estimate).
    s = _state["sum"] + item
    c = _state["count"] + 1
    _state["sum"] = s
    _state["count"] = c
    mean_item = s / c

    # A leftover (after placing) is "dead" when it is positive but smaller
    # than the mean item size: another typical item can't fit there.
    # Charge a surcharge that grows as slack shrinks toward zero, so we
    # prefer to consume bins fully or leave useful slack.
    dead = (residual > 0) & (residual < mean_item)
    # scale up to ~4 points of surcharge for the most useless slack
    frac = np.where(dead, 1.0 - residual / mean_item, 0.0)
    score -= 4.0 * frac

    return score
# EVOLVE-BLOCK-END
