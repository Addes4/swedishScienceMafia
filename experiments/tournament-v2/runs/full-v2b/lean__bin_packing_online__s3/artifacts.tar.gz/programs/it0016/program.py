# EVOLVE-BLOCK-START
"""Best fit with a smooth waste-band penalty.

Pure best-fit often leaves a small residual that no future item can use.
We rank bins by residual-after-placement, but penalise residuals that fall
into a "waste band" and reward exact fits, so the algorithm prefers either
filling a bin completely or leaving a reusable gap.
"""
import numpy as np

_WASTE_LIMIT = 24.0     # residuals below this are considered risky slack
_SURCHARGE = 10.0       # strength of the waste penalty
_EXACT_BONUS = 4.0      # extra pull toward perfectly filling a bin


def priority(item, bins):
    residual = bins - item                      # >= 0 for all shown bins
    score = -residual.astype(np.float64)        # base: tightest fit wins

    # Smoothly penalise residuals inside the waste band, strongest near 0
    # where the leftover is most likely to be unusable by future items.
    in_band = (residual > 0) & (residual < _WASTE_LIMIT)
    if np.any(in_band):
        r = residual[in_band].astype(np.float64)
        weight = 1.0 - (r / _WASTE_LIMIT)       # decays from 1 down to 0
        score[in_band] -= _SURCHARGE * weight

    # Reward exactly filling a bin.
    score -= _EXACT_BONUS * (residual == 0)

    return score
# EVOLVE-BLOCK-END
