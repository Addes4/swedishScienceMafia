# EVOLVE-BLOCK-START
"""Threshold-aware best fit with near-tie break preferring reusable residuals.

Pure best-fit can leave small residuals that later items cannot use.
Among bins whose fit is nearly equally tight, we prefer residuals that
are large enough to be plausibly reused by future items, using only
information available at call time (no static distribution constants).
"""
import numpy as np

_TIE_EPS = 1.0

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Among near-ties, prefer a residual that could plausibly hold a
    # future item.  We use a smooth increasing preference for larger
    # residuals so that we do not strand tiny unusable slack.
    is_near = np.abs(score - score.max()) <= _TIE_EPS
    # preference weight grows with residual but stays small relative to fit
    pref = residual.astype(np.float64) / 100.0
    score = score + 0.5 * pref * is_near
    return score
# EVOLVE-BLOCK-END

