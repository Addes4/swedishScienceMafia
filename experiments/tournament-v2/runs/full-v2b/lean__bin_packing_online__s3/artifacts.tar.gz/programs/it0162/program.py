# EVOLVE-BLOCK-START
"""Threshold-aware best fit with a room-preserving near-tie break.

Pure best-fit sometimes picks a bin whose leftover is a tiny, unusable
slack when a nearly-as-tight bin would leave far more usable room.  We
keep the tight-fit ordering by residual and apply a surcharge to
residuals in a "waste" band just above 0.  Near-ties in residual are
broken by preferring the bin that leaves more usable room, so we avoid
manufacturing dead leftovers while otherwise staying pure best-fit.
"""
import numpy as np

# Residuals strictly between 0 and this value are treated as wasted slack.
_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise residuals that are small but non-zero (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0:
        # Near-ties: prefer the bin that leaves more usable room so we do
        # not create tiny dead leftovers, without changing the base order.
        _state["tick"] += 1
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * residual * is_near
    return score
# EVOLVE-BLOCK-END
