# EVOLVE-BLOCK-START
"""Best fit with a low-slack guard.

Pure best fit (smallest feasible residual) is a strong online rule here.
The main failure mode is creating bins with tiny leftovers that no future
item can use.  We keep best fit as the base ordering, but apply a small
surcharge to residuals in a narrow "unusable" band just above zero, and
give a bonus when the placement exactly fills the bin (residual 0).  A
near-tie break prefers leaving a residual equal to the current item size
so the bin can be filled by a later copy of the same item.
"""
import numpy as np

# Residuals strictly between 0 and this value are treated as wasted slack.
_WASTE_LIMIT = 3.0
_SURCHARGE = 1.5
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.2


def priority(item, bins):
    residual = (bins - item).astype(np.float64)   # >= 0 for every bin shown
    score = -residual                              # base: tightest fit wins

    # Small surcharge for unusable tiny leftovers.
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0:
        # Near-ties: mildly prefer residuals equal to the item size,
        # so the bin can be exactly filled by a later identical item.
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        match = (residual == float(item))
        score = score + _TIE_WEIGHT * match * is_near
    return score
# EVOLVE-BLOCK-END
