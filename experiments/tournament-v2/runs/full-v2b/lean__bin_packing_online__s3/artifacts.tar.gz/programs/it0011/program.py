# EVOLVE-BLOCK-START
"""Best fit with a convex residual penalty and slight preference for used bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Convex penalty: emphasize small residuals more strongly than linear best-fit.
    # exponent 1.15 keeps it near best-fit but slightly prefers tighter packing.
    score = -(residual.astype(np.float64) ** 1.15)
    # Mild bonus for already-used bins (remaining < 100) to consolidate.
    score += 0.002 * (bins < 100)
    return score
# EVOLVE-BLOCK-END

