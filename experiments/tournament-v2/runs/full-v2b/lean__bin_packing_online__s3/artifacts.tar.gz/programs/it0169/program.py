# EVOLVE-BLOCK-START
"""Best-fit with a smooth, item-relative slack penalty.

Pure best-fit leaves tiny unusable gaps.  Instead of an arbitrary
"waste band" with a hard cutoff, we penalise a positive residual that is
smaller than the current item size (a bin that could not even take
another item of the same size), scaling the penalty smoothly so that
slightly larger residuals are penalised less.  Exact fills (residual 0)
remain the top choice.
"""
import numpy as np

# Scale of the slack penalty relative to the current item size.
_PENALTY_SCALE = 0.35

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    score = -residual.astype(np.float64)        # base: tightest fit wins

    # Penalise unusable slack: a positive residual below the current item
    # size cannot hold another same-sized item. The penalty grows as the
    # gap gets smaller relative to the item (a nearly-full bin that can't
    # take a same-size item is the worst waste).
    positive = residual > 0
    gap_ratio = np.where(positive,
                         (item - residual).astype(np.float64),
                         0.0)
    gap_ratio = np.clip(gap_ratio / max(item, 1), 0.0, 1.0)
    score -= _PENALTY_SCALE * item * gap_ratio

    return score
# EVOLVE-BLOCK-END

