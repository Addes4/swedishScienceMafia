# EVOLVE-BLOCK-START
"""Best fit with a small threshold band that prefers less-full bins.

Classic best fit minimizes residual.  But filling the now-tightest bin
too eagerly can leave many small unusable slacks.  Here we keep best fit
as the backbone, but when the tightest available residual is large
(meaning many bins are still relatively empty), we instead prefer a bin
whose residual is comfortably large so that it can still absorb several
future items.  Concretely: apply a small bonus proportional to residual
for residuals above a mild threshold, so among "loose" bins we drift
toward the less-full ones, while tight fits (small residual) still win
outright.
"""
import numpy as np

_LOOSE = 30.0      # residual above this counts as "roomy"
_LOOSE_W = 0.35    # per-unit reward for keeping roomy bins roomier


def priority(item, bins):
    residual = (bins - item).astype(np.float64)   # >= 0
    score = -residual                              # best-fit backbone
    # Mildly prefer roomier bins among the loose ones, so that bins with
    # small residuals are left as-is and can take small future items.
    roomy = residual > _LOOSE
    score = score + _LOOSE_W * np.where(roomy, residual - _LOOSE, 0.0)
    return score
# EVOLVE-BLOCK-END
