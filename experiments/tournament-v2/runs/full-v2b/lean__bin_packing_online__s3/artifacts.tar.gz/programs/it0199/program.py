# EVOLVE-BLOCK-START
"""Tight best-fit with a small penalty for unusably small residuals.

Pure best-fit (choose the bin with the smallest post-placement residual)
is a strong online rule.  Its main failure mode is creating a bin whose
tiny leftover (1..m) can rarely be refilled by any future item, wasting
capacity.  We keep the tightest-fit ordering and subtract a gentle
surcharge only for residuals in that narrow unusable band, plus a small
bonus for exact fills (residual 0).
"""
import numpy as np

# Residuals in [1, _MIN_USEFUL] are rarely fillable by a future item;
# penalise them gently so best-fit prefers a slightly looser but more
# reusable bin when the choice is otherwise close.
_MIN_USEFUL = 18.0
_SURCHARGE = 4.0
_FULL_BONUS = 0.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    r = residual.astype(np.float64)
    score = -r                                 # base: tightest fit wins

    waste = (r > 0.0) & (r < _MIN_USEFUL)
    score -= _SURCHARGE * waste

    if _FULL_BONUS > 0.0:
        score += _FULL_BONUS * (r == 0.0)

    return score
# EVOLVE-BLOCK-END
