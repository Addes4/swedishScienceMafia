# EVOLVE-BLOCK-START
"""Best fit with a smooth near-tie bonus for exactly-refillable residuals.

Base rule is tightest fit: the smallest resulting residual wins.  On top
of that, among residuals that are nearly tied, we prefer the bin whose
new residual is exactly equal to the current item size, because that
residual can be perfectly consumed by a later item of this same size,
recovering the full bin.  The bonus is small enough not to override a
genuinely tighter fit.
"""
import numpy as np

_TIE_EPS = 1.0
_TIE_WEIGHT = 0.9

_state = {"last_item": 40}


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    score = -residual.astype(np.float64)        # tightest fit wins

    if _TIE_EPS > 0.0:
        _state["last_item"] = int(item)
        # Prefer a residual that exactly matches the current item size
        # (perfectly refillable later); keep it a near-tie breaker only.
        exact = (residual == item)
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * exact * is_near
    return score
# EVOLVE-BLOCK-END
