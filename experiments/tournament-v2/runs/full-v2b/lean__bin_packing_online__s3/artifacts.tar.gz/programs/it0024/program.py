# EVOLVE-BLOCK-START
"""Best-fit with a sliver penalty.

Pure best-fit leaves small unusable residuals. We keep minimizing residual
but add a mild penalty for residuals in (0, T), weighted so that very small
residuals are penalized less than residuals near the top of the band?  No --
experience shows best-fit is strong; the main lever is only slight. We add a
small constant surcharge to nonzero residuals below a threshold, tuned mildly.
"""
import numpy as np

_T = 12.0
_W = 3.0


def priority(item, bins):
    residual = bins - item                 # >= 0 for every bin shown
    score = -residual.astype(np.float64)   # tightest fit wins
    sliver = (residual > 0) & (residual < _T)
    score -= _W * sliver
    return score
# EVOLVE-BLOCK-END
