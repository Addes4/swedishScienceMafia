# EVOLVE-BLOCK-START
"""Best fit with an online large-item aware slack penalty.

Pure best-fit (tightest residual) is hard to beat, so we keep it as the
base ordering.  Bin packing waste mainly comes from creating small/medium
slack that no future item can exactly use.  We track the largest item size
seen so far and mildly penalize placements that leave a residual greater
than zero but smaller than the current item size -- such slack is hard for
items of similar or larger size to use.  The penalty is small enough not to
disturb the tight-fit ordering among genuinely good placements.
"""
import numpy as np

_PENALTY = 3.0

# Static histogram over item sizes 1..100 (mean ~40, Weibull-shaped).
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100

_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

_state = {"max_item": 1}


def priority(item, bins):
    if item > _state["max_item"]:
        _state["max_item"] = item
    max_item = _state["max_item"]

    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Penalize creating slack that is positive but below the current item
    # size (and below the largest seen item), i.e. hard-to-reuse leftovers.
    gap = max(item, max_item)
    waste = (residual > 0) & (residual < gap)
    score -= _PENALTY * waste

    if _TIE_EPS > 0.0:
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _FILL[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
