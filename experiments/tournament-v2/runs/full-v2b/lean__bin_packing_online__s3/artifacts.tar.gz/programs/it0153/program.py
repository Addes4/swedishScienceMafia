# EVOLVE-BLOCK-START
"""Fit-ordered bin choice with a smooth leftover-valuation surcharge.

Base rule: tightest fit (best-fit) on remaining capacity.  Over it we add a
mild, smooth penalty for leaving unused slack after placing the item.  The
penalty is the *expected amount of leftover capacity that will never be
usable*, estimated from the known Weibull-shaped item-size distribution.
Unlike a hard waste band, this is graded: tiny leftovers are penalised most,
larger leftovers less, because a larger remaining gap is more likely to be
filled by some future item.
"""
import numpy as np

# Static model of the item-size distribution (mean ~40, Weibull-shaped).
# Only relative fillability of a residual is needed, not exact tuning.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.sum()

# Probability that a single future item fits in a residual of size r
# (i.e. item size <= r), for r = 0..100.  Index by residual.
_CDF = np.concatenate(([0.0], np.cumsum(_PDF)))  # length 101

# Penalty weight for stranded slack; small so true tightness still dominates.
_WASTE_WEIGHT = 4.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Smooth leftover penalty: penalise slack that is unlikely to be reused.
    # Expected usable fraction of the leftover is CDF(residual); the
    # un-usable fraction ~ (1 - CDF) is what we surcharge.
    rc = np.clip(residual, 0, 100).astype(np.int64)
    unusable = 1.0 - _CDF[rc]
    score -= _WASTE_WEIGHT * unusable

    return score
# EVOLVE-BLOCK-END
