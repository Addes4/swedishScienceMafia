# EVOLVE-BLOCK-START
"""Pure best fit with exact-fit emphasis.

Best fit (smallest residual that still fits) is the strongest simple online
rule for independent, identically distributed item sizes.  We rank by residual
so the tightest bin wins, with an extra bonus for a perfect fill (residual 0)
and a mild concave preference that keeps the ordering monotone in residual.
No state, no hand-tuned waste band.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item                       # >= 0 for every bin shown
    score = -residual.astype(np.float64)         # tightest fit wins
    # Strong bonus for a perfect fill: closing a bin completely is valuable.
    score += 1000.0 * (residual == 0)
    return score
# EVOLVE-BLOCK-END

