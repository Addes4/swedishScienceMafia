# EVOLVE-BLOCK-START
"""Best fit with concave residual ranking and exact-fit emphasis.

Two principles for this unknown-ahead stream:
 1) Tightest fit (smallest residual) is the dominant signal: it conserves
    the large gaps for large items.
 2) Nonzero residuals that are too small to be filled by a plausible future
    item are wasted; exact fits (residual 0) are ideal.  We express this as a
    concave increasing cost on residual plus a small extra penalty for the
    very-small unusable band, and we strongly reward exact fits.

No stateful tie-break: equal scores resolve to the lowest bin index, which is
the classic deterministic best-fit and empirically the strongest rule here.
"""
import numpy as np

# Residuals in [1, _SMALL_BAND] are treated as wasted slack.
_SMALL_BAND = 8.0
_SMALL_PEN = 4.0
_EXACT_BONUS = 2.0
_CONCAVE = 0.02


def priority(item, bins):
    residual = bins - item                          # >= 0 for every bin shown
    r = residual.astype(np.float64)
    # Concave increasing cost on residual: small residuals favored, and the
    # marginal cost of a large residual tapers (large gaps are still useful).
    score = -np.sqrt(r)
    score -= _CONCAVE * r
    # Extra penalty only for residuals too small to be reusable.
    small = (residual > 0) & (residual <= _SMALL_BAND)
    score -= _SMALL_PEN * small
    # Strong reward for exact fits.
    score += _EXACT_BONUS * (residual == 0)
    return score
# EVOLVE-BLOCK-END
