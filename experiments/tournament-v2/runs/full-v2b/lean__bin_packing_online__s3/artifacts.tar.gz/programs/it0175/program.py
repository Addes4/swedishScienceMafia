# EVOLVE-BLOCK-START
"""Best fit with a smooth, adaptive residual-quality bonus.

Pure best-fit (smallest residual) is the strongest simple online rule.
The only weakness is that best-fit sometimes leaves a tiny residual
(< some small item) that is hard to reuse.  We keep tightest-fit as the
dominant ordering and add a *small, smooth* bonus that favours residuals
which are more likely to be reusable, using an adaptive estimate of the
recent item-size scale instead of a hard-coded band.
"""
import numpy as np

_BONUS_WEIGHT = 0.4      # small: only breaks near-ties in residual
_SMOOTH = 8.0            # scale of the smooth quality ramp

_state = {"count": 0.0, "sum": 0.0}


def priority(item, bins):
    _state["count"] += 1.0
    _state["sum"] += float(item)
    mean_item = _state["sum"] / _state["count"]

    residual = bins - item                        # >= 0 for shown bins
    score = -residual.astype(np.float64)          # dominant: tightest fit

    # Smooth, concave quality ramp: residuals near 0 are penalised most,
    # larger residuals get progressively less penalty; never positive
    # enough to override a full unit of residual.
    r = residual.astype(np.float64)
    quality = r / (r + _SMOOTH)                    # in [0,1), concave
    # normalise so bonus stays well under 1.0 so tightest-fit dominates
    score = score + _BONUS_WEIGHT * quality
    return score
# EVOLVE-BLOCK-END
