# EVOLVE-BLOCK-START
"""Threshold-aware best fit with histogram-guided fillability bonus.

Pure best-fit often leaves an unusable small slack.  We keep the tight-fit
ordering by residual, apply a surcharge to residuals in a "waste" band just
above 0, strongly reward exact fills (residual 0), and always add a small
fillability bonus proportional to the probability that the resulting residual
can be exactly matched by a future item of the known Weibull-shaped size
distribution.
"""
import numpy as np

# Residuals strictly between 0 and this value are treated as wasted slack.
_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0

# Reward for exactly filling a bin (residual becomes 0).
_EXACT_BONUS = 4.0
_FILL_WEIGHT = 0.30

# Static histogram over item sizes 1..100 (mean ~40, Weibull-shaped),
# used only as a relative "fillability" weight for residuals.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise residuals that are small but non-zero (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste
    # Reward exact fills: a perfectly packed bin is ideal.
    score += _EXACT_BONUS * (residual == 0)
    # Fillability: prefer a leftover residual likely to be exactly fillable
    # by some future item of the known size distribution.
    rc = np.clip(residual, 0, 100).astype(np.int64)
    score = score + _FILL_WEIGHT * _FILL[rc]
    return score
# EVOLVE-BLOCK-END
