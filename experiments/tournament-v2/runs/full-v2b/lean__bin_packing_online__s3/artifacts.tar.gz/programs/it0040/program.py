# EVOLVE-BLOCK-START
"""Best fit with exact-fill dominance.

Classic best fit: place the item into the bin leaving the smallest
residual.  Because leaving residual 0 is strictly better than any positive
residual (it loses no capacity at all), we add a small constant bonus for
exact fills.  This is a smooth, parameter-light rule that avoids the
fragile hand-tuned waste bands tried earlier.
"""
import numpy as np

_EXACT_BONUS = 1e-6


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # tightest fit wins
    score += _EXACT_BONUS * (residual == 0)
    return score
# EVOLVE-BLOCK-END
