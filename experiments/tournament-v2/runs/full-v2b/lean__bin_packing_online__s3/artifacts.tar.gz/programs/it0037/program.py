# EVOLVE-BLOCK-START
"""Best fit with an opportunity-cost penalty for unusable residuals.

Base rule: minimize residual-after-placement (best fit).  But a leftover
gap that is smaller than a typical upcoming item is wasted capacity, so
we add a penalty proportional to how far below a "useful" gap size the
residual falls, using the observed mean item size as the natural scale.
Exact fits get a small extra bonus so they strictly dominate.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    score = -residual.astype(np.float64)        # base: tightest fit wins

    # Scale: items average ~40; gap below ~half a mean item is likely wasted.
    useful = 20.0
    waste = residual < useful
    # Penalty grows linearly as the residual shrinks toward 0, but exact
    # fits (residual 0) are rewarded rather than punished.
    pen = np.where(waste, (useful - residual) * 0.35, 0.0)
    score -= pen
    score += 3.0 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
