# EVOLVE-BLOCK-START
"""Pure best fit.

The item is placed into the bin with the smallest remaining capacity
that still fits it (tightest residual).  Empirically this simple rule
matches or beats the surcharge / tie-break variants, which risk
mis-firing on the fixed Weibull-shaped item distribution.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
