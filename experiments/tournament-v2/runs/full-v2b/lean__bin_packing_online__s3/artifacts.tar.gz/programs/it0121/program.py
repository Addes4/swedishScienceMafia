# EVOLVE-BLOCK-START
"""Distribution-weighted best fit.

Base rule is best fit (smallest residual wins).  On top we penalise
"wasteful" placements: leaving a positive residual r that future items
are unlikely to fill.  The penalty is high when r sits in the dense part
of the item-size distribution (so many items could have fit there) and
low in the sparse tails.  Exact fills get a bonus.
"""
import numpy as np

# Static histogram over item sizes 1..100 (Weibull-shaped, mean ~40).
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.max()
# index by residual 0..100; residual 0 is a perfect fill (no waste)
_WASTE = np.concatenate(([0.0], _PDF))   # higher = more painful to waste

_WASTE_WEIGHT = 4.0       # scale of the waste penalty
_PERFECT_BONUS = 1.5      # bonus for leaving residual 0

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    rc = np.clip(residual, 0, 100).astype(np.int64)
    # Penalise leaving slack that is likely fillable by a future item.
    score -= _WASTE_WEIGHT * _WASTE[rc]
    # Strongly reward exact fills.
    score += _PERFECT_BONUS * (residual == 0)
    return score
# EVOLVE-BLOCK-END
