# EVOLVE-BLOCK-START
"""Smooth residual-utility best fit.

The dominant rule is best fit: the tightest residual wins.  Instead of a
binary "waste band" surcharge (which was fragile), we add a smooth, bounded
bonus to bins whose residual is large enough to still accommodate a typical
item (mean item size ~40).  The bonus grows with residual up to ~the mean
item size and then flattens, so we gently prefer leaving gaps that future
items can actually use, without ever overriding a genuinely tighter fit.
A weak rotating near-tie perturbation avoids fixed-index bias.
"""
import numpy as np

_UTIL_SCALE = 0.15        # strength of the usability bonus
_UTIL_CAP = 40.0          # residual size at which the bonus saturates
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.03

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    r = residual.astype(np.float64)
    score = -r                                 # base: tightest fit wins

    # Smooth usability bonus: larger usable gaps get a bounded reward.
    util = np.minimum(r, _UTIL_CAP) / _UTIL_CAP
    score += _UTIL_SCALE * util

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        idx = np.arange(r.shape[0], dtype=np.float64)
        perturb = ((idx * 2654435761.0 + _state["tick"] * 40503.0) % 1000.0) / 1000.0
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score - _TIE_WEIGHT * perturb * is_near
    return score
# EVOLVE-BLOCK-END
