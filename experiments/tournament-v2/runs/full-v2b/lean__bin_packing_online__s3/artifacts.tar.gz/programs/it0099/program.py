# EVOLVE-BLOCK-START
"""Best fit with a robust near-tie break on residual usability.

Base rule is pure best-fit: pick the bin with the smallest nonnegative
residual (tightest fit), which is the strongest simple online rule for
this Weibull-shaped distribution (mean ~40).

To squeeze a little more, when two residuals are nearly equal we break
the tie by preferring the bin whose post-placement residual is *usable*
(clearly nonzero, avoiding the tiny wasted-slack band), and failing that
we prefer the bin that would be left emptier, preserving room for large
items.  This is a small, robust adjustment that never disturbs the strong
best-fit ordering.
"""
import numpy as np

_TIE_EPS = 1.5        # residuals within this band are considered tied
_TINY = 12.0          # residuals 1.._TINY are likely unusable slack


def priority(item, bins):
    residual = bins - item                       # >= 0 for every bin shown
    score = -residual.astype(np.float64)         # base: tightest fit wins

    if _TIE_EPS > 0.0:
        near = np.abs(residual - residual.min()) <= _TIE_EPS
        if near.sum() > 1:
            # Preferred residual band: avoid tiny unusable slack.
            usable = (residual > _TINY).astype(np.float64)
            # Among usable ones, leaving a larger residual preserves room
            # for future large items.
            bonus = 0.01 * usable + 1e-6 * residual.astype(np.float64)
            score = score + bonus * near
    return score
# EVOLVE-BLOCK-END

