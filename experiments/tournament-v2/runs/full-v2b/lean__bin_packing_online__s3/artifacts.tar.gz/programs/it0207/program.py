# EVOLVE-BLOCK-START
"""Best-fit with a sharper, monotone residual-utility term.

Plain best-fit (tightest residual) is the strongest backbone observed.
The tweak that survives: penalise only residuals too small to ever be
exactly reused (1..small) *hard*, and reward residuals that equal a
common future item size with a bonus strong enough to flip a moderate
residual gap -- not just near-exact ties.  This turns "waste a little
slack" into "leave a fillable leftover" without letting the bonus
override large fit differences.
"""
import numpy as np

# Residuals 1.._MIN_USABLE are effectively unusable (no future item that
# small is likely) -> strong penalty so we prefer clean large leftovers.
_MIN_USABLE = 5
_SMALL_PENALTY = 12.0

# Bonus for residuals that match a likely future item size, capped so it
# only influences choices within a moderate residual gap (~a few units).
_BONUS = 4.0

_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.max()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    r = residual.astype(np.float64)
    score = -r                                  # tightest fit wins

    # Hard-penalise residuals too small to be exactly reused later.
    small = (residual > 0) & (residual <= _MIN_USABLE)
    score -= _SMALL_PENALTY * small

    # Reward leftovers that are a likely future item size.
    rc = np.clip(residual, 0, 100).astype(np.int64)
    score += _BONUS * _FILL[rc]
    return score
# EVOLVE-BLOCK-END

