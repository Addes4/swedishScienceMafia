# EVOLVE-BLOCK-START
"""Data-driven best fit with exact-fill bonus.

We keep the classic tightest-fit ordering (small residual preferred), but
instead of a hardcoded "waste band" we accumulate an online histogram of the
item sizes we have actually seen.  The key insight: a residual r is only
"waste" if no future item is likely to hit it exactly.  So we reward bins
whose residual equals a commonly-seen item size (a likely future exact fill)
and mildly reward the smallest residuals, while penalising residuals that no
observed item size can fill.
"""
import numpy as np

_MAX_SIZE = 100
# Discounted count of items seen per size (size 1..100).
_state = {"counts": np.zeros(_MAX_SIZE + 1, dtype=np.float64), "total": 0.0}

_BONUS = 3.0          # weight for "this residual is a likely future item"
_PENALTY = 2.0        # weight for "this residual is unlikely to ever be filled"


def priority(item, bins):
    counts = _state["counts"]
    _state["total"] = _state["total"] * 0.999 + 1.0
    counts[item] += 1.0

    residual = bins - item                          # >= 0
    score = -residual.astype(np.float64)            # base: tightest fit wins

    total = _state["total"] + 1.0
    # Probability that a future item exactly fills a residual of this value.
    # Sizes above what we've seen get a small floor so unseen-but-possible
    # fits aren't punished wrongfully.
    prob = (counts + 0.5) / (total + 50.0)          # Laplace-style smoothing

    # Map each bin's residual to a "fillability" measure.
    resid_idx = np.clip(residual, 0, _MAX_SIZE).astype(np.int64)
    fill_prob = prob[resid_idx]

    # Reward likely-fillable residuals; strongly reward residual 0 (exact fit
    # of the current item completes a bin, achieving immediate tightness).
    score += _BONUS * fill_prob
    score += _PENALTY * (residual == 0)

    return score
# EVOLVE-BLOCK-END
