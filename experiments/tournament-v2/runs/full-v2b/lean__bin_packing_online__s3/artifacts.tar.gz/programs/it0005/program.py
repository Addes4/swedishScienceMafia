# EVOLVE-BLOCK-START
"""Hybrid best-fit: primary tightness, with a small bias toward bins that are already nearly full."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: prefer smallest residual (best fit).
    # Secondary: mildly prefer bins that are currently fuller (smaller `bins`)
    # so that near-empty bins are preserved for items that need them.
    return -(residual.astype(np.float64) + 0.01 * bins)
# EVOLVE-BLOCK-END

