# EVOLVE-BLOCK-START
"""Best fit with a smooth small-residual penalty.

Pure best-fit minimizes the leftover residual, but residuals just above 0
(say 1..15) can rarely be refilled, so they waste capacity.  Instead of a
hard "waste band", subtract a smooth convex penalty proportional to
1/(residual+1): tiny residuals are strongly discouraged while larger
residuals are barely affected, keeping tightest-fit as the backbone.
"""
import numpy as np

_ALPHA = 14.0


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    r = residual.astype(np.float64)
    # Base: tightest fit wins (-r).  Add a convex penalty 1/(r+1) so that
    # leaving a tiny leftover is worse than leaving a comfortably usable one.
    score = -r - _ALPHA / (r + 1.0)
    return score
# EVOLVE-BLOCK-END

