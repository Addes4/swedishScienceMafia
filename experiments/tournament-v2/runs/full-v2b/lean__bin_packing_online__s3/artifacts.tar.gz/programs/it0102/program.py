# EVOLVE-BLOCK-START
"""Best fit with a strong penalty for creating unusable small slack.

The item sizes are Weibull-shaped with mean ~40, so a leftover residual
of roughly 1..11 is very unlikely to be exactly fillable and mostly
wastes capacity.  Pure best-fit occasionally produces such residuals.
We keep tightest-fit as the base ordering but subtract a substantial
penalty for residuals in that unusable small band, so the packer avoids
creating dead slack even at some cost in tightness.
"""
import numpy as np

# Residuals strictly between 0 and this are treated as unusable slack.
_WASTE_LIMIT = 12.0
_SURCHARGE = 15.0

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Strongly penalise small non-zero residuals (dead slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste
    return score
# EVOLVE-BLOCK-END

