# EVOLVE-BLOCK-START
"""Best fit with a graduated small-residual surcharge and a fillability
tie-break restricted to genuine near-ties of the tightest-fit bin.

Rationale: pure best-fit is strong; the main loss comes from placing an
item into a bin that leaves a tiny, hard-to-fill residual when a slightly
looser residual would be exactly fillable by a likely future item.  We
therefore keep tightest-fit as the dominant term, add a *small* surcharge
for residuals in 1..19 (unusable slack), and among bins whose residual is
within a tight epsilon of the smallest residual, prefer residuals with
high Weibull pdf (likely future item sizes).  The tie-break is only
applied to the near-optimal group, so it cannot disturb the base rule.
"""
import numpy as np

_WASTE_LIMIT = 18.0
_SURCHARGE = 3.0
_TIE_EPS = 1.5
_TIE_WEIGHT = 1.5

# Static Weibull-shaped density over item sizes 1..100 (mean ~40).
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.max()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100


def priority(item, bins):
    residual = bins - item                       # >= 0 for bins shown
    r = residual.astype(np.float64)
    score = -r                                   # base: tightest fit wins

    # Gentle surcharge on tiny unusable slack.
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    # Near-tie fillability bonus only for the tightest-fit group.
    best = r.min()
    is_near = r <= (best + _TIE_EPS)
    rc = np.clip(residual, 0, 100).astype(np.int64)
    score = score + _TIE_WEIGHT * _FILL[rc] * is_near
    return score
# EVOLVE-BLOCK-END
