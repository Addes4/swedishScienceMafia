# EVOLVE-BLOCK-START
"""Threshold-aware best fit with a sharp near-zero waste penalty.

Best fit places the item in the bin with the smallest residual.  That is
usually good, but it can leave a tiny non-zero sliver (say 1..10) that no
future item can ever fill, wasting capacity.  Here we keep the tightest-fit
ordering but apply a penalty that grows sharply as the residual rises from
0, encouraging the algorithm to prefer an exact fill (residual 0) over a
useless sliver, while leaving larger reusable gaps essentially untouched.
"""
import numpy as np

# Residuals strictly between 0 and this value get a penalty.
_WASTE_LIMIT = 12.0
# Peak magnitude of the penalty (at residual just below _WASTE_LIMIT).
_PEAK = 5.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise small but non-zero residuals; penalty grows from 0 (at
    # residual 0) toward _PEAK as the residual approaches _WASTE_LIMIT,
    # so exact fits are strongly favored and useless slivers avoided.
    r = residual.astype(np.float64)
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    if waste.any():
        frac = r / _WASTE_LIMIT
        score -= _PEAK * frac * waste
    return score
# EVOLVE-BLOCK-END
