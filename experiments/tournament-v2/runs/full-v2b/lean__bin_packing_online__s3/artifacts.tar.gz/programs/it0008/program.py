# EVOLVE-BLOCK-START
"""Best fit with a tie-break that prefers partially-filled bins over fresh bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: prefer tightest fit (smallest residual after placement).
    # Secondary: slightly prefer bins that are already in use (remaining < 100),
    # so we consolidate rather than spread the item across fresh bins.
    residual = bins - item
    in_use_bonus = np.where(bins < 100, 1e-3, 0.0)
    return -residual + in_use_bonus
# EVOLVE-BLOCK-END
