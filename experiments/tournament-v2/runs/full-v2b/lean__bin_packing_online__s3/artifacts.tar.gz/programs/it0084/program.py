# EVOLVE-BLOCK-START
"""Threshold-aware best fit with mid-band residual penalty.

Best-fit by residual already performs well on this distribution.  We retain
the tiny-residual waste surcharge but additionally apply a mild concave
penalty to residuals in a mid band (roughly 20..45) that the Weibull item
distribution rarely fills exactly, so the choice shifts toward tighter fits
or clearly reusable gaps.  The change is conservative to preserve the strong
best-fit ordering.
"""
import numpy as np

_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_MID_LOW = 21.0
_MID_HIGH = 44.0
_MID_WEIGHT = 0.35

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    rf = residual.astype(np.float64)
    score = -rf                                # base: tightest fit wins

    # Penalise small but non-zero residuals (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    # Mildly penalise residuals in the rarely-matchable mid band, scaled by
    # how central they are (concave: strongest in the middle of the band).
    in_mid = (rf >= _MID_LOW) & (rf <= _MID_HIGH)
    if np.any(in_mid):
        mid_center = 0.5 * (_MID_LOW + _MID_HIGH)
        half = 0.5 * (_MID_HIGH - _MID_LOW)
        shape = 1.0 - np.abs(rf - mid_center) / (half + 1e-9)
        score -= _MID_WEIGHT * np.clip(shape, 0.0, 1.0) * in_mid

    return score
# EVOLVE-BLOCK-END

