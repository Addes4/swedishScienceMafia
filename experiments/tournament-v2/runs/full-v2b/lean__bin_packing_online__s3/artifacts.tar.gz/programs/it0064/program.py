# EVOLVE-BLOCK-START
"""Stateful best-fit with short-term avoidance of recently used bins.

Classic best-fit (tightest residual) is the strongest simple rule here, so we
keep it dominant. Its weakness is that a sequence of small items can keep
landing in the same partially-filled bin, shaving a usable gap down into
unusable dust. We add a small, decaying penalty for bins chosen very recently
so the algorithm prefers to consolidate small items into a fresh/different bin
instead of nibbling one gap away. The penalty is tiny so it never overrides a
clearly tighter fit.
"""
import numpy as np

_RECENT_PENALTY = 1.5
_RECENT_DECAY = 0.5
_RECENT_HORIZON = 3

_state = {"tick": 0, "recent": {}}


def priority(item, bins):
    residual = bins - item
    score = -residual.astype(np.float64)

    # Decay / expire the recent-usage penalties.
    _state["tick"] += 1
    t = _state["tick"]
    recent = _state["recent"]
    if recent:
        for k in list(recent.keys()):
            recent[k] -= 1
            if recent[k] <= 0:
                del recent[k]

    n = residual.shape[0]
    if recent:
        idxs = np.fromiter(recent.keys(), dtype=np.int64, count=len(recent))
        pens = np.fromiter(recent.values(), dtype=np.float64, count=len(recent))
        mask = np.zeros(n, dtype=np.float64)
        mask[idxs] = pens
        score -= _RECENT_PENALTY * _RECENT_DECAY * mask

    return score


def _after_choice(chosen):
    _state["recent"][chosen] = _RECENT_HORIZON
# EVOLVE-BLOCK-END
