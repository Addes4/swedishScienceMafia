# EVOLVE-BLOCK-START
"""Best-fit with a graded penalty on unusable tiny residuals.

Pure best-fit (place the item in the bin with the smallest remaining
capacity that still fits) is the strongest known simple rule for this
Weibull-shaped item distribution.  Its only systematic loss is leaving
residual slack so small that no future item can ever use it.  We apply a
small, graded surcharge to residuals of 1 and 2 (the values that almost
always waste capacity), keeping the tightest-fit ordering otherwise
intact.  No histogram tie-break, which earlier experiments showed added
noise.
"""
import numpy as np

# Penalty applied to tiny residual slack that no future item can fill.
_TINY = np.array([0.0, 3.0, 1.5], dtype=np.float64)  # index r=0,1,2


def priority(item, bins):
    residual = bins - item                       # >= 0 for every bin shown
    score = -residual.astype(np.float64)         # base: tightest fit wins
    # Graded penalty for tiny unusable leftovers (r = 1 or 2).
    small = residual <= 2
    score -= np.where(small, _TINY[np.clip(residual, 0, 2)], 0.0)
    return score
# EVOLVE-BLOCK-END
