# EVOLVE-BLOCK-START
"""Adaptive best-fit with online-histogram near-tie break.

Best-fit (tightest residual) is a strong online packing rule.  Leftover
slack just above zero is the main source of waste, so we apply a surcharge
to residuals in a "waste band".  The band width and the tie-break signal
are derived from an online histogram of observed item sizes, so the rule
adapts to the actual distribution instead of a static guess.
"""
import numpy as np

_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

# Online histogram over item sizes 1..100 (index 1..100 used).
_HIST = np.zeros(101, dtype=np.float64)
_ALPHA = 0.999
_seen = 0.0


def priority(item, bins):
    global _HIST, _seen
    residual = bins - item
    score = -residual.astype(np.float64)

    # Surcharge on small nonzero residuals: they are the usual waste.
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    # Near-ties: prefer leaving a residual that matches a common item
    # size observed so far, so future items can fill it exactly.
    _seen += 1.0
    _HIST *= _ALPHA
    _HIST[min(int(item), 100)] += 1.0
    if _TIE_EPS > 0.0:
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _HIST[rc] / (_seen + 1.0)
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
