# EVOLVE-BLOCK-START
"""Best fit with an online-learned "fillability" tie-break.

Pure best-fit (smallest nonnegative residual) is the strongest simple
online rule, so we keep it as the base ordering.  The only refinement is
a tie-break among bins whose residual is within a tiny epsilon of the
tightest: instead of an arbitrary pick we prefer the bin whose resulting
leftover residual is a size that has actually been observed often, so it
is likely to be exactly filled by a future item.  The fillability table
is learned online from observed item sizes, so it adapts to the true
distribution without tuning to any instance.
"""
import numpy as np

_TIE_EPS = 1.5
_TIE_WEIGHT = 0.4

# Online histogram of observed item sizes 1..100, used only as a
# relative "fillability" weight for leftover residuals near a tie.
_FREQ = np.zeros(101, dtype=np.float64)
_FREQ[1:] = 1.0  # Laplacian-style smoothing: every size starts usable.
_OBS = 0.0
_DECAY = 0.0  # 0 => plain cumulative counts


def priority(item, bins):
    global _OBS
    # Update the online histogram with the current item.
    _OBS = _OBS * _DECAY + 1.0 if _DECAY > 0 else _OBS + 1.0
    if _DECAY > 0:
        _FREQ *= _DECAY
    _FREQ[item] += 1.0

    residual = bins - item                    # >= 0 for every bin shown
    score = -residual.astype(np.float64)      # base: tightest fit wins

    # Near-ties: prefer a leftover residual that is a common observed
    # size, i.e. one a future item is likely to fill exactly.
    rc = np.clip(residual, 0, 100).astype(np.int64)
    fill = _FREQ[rc]
    # Normalise fill into a small, bounded nudge.
    fmax = fill.max()
    if fmax > 0:
        fill = fill / fmax
    is_near = np.abs(score - score.max()) <= _TIE_EPS
    score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
