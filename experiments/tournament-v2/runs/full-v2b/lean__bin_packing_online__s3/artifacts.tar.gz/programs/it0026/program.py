# EVOLVE-BLOCK-START
"""Two-tier best fit: strongly reward exact fills, sharply punish tiny slack.

Pure best-fit is the core ordering (lower residual is better).  We overlay
two strong signals:
  * a large bonus for a residual of exactly 0 (a perfectly packed bin),
  * a sharp penalty for residuals in a narrow band that is almost always
    wasted (a few units that no future item can realistically use).
Outside those cases we simply keep best-fit ordering.
"""
import numpy as np

_TINY_LIMIT = 5.0      # residuals in (0, 5) are almost always wasted
_TINY_PENALTY = 10.0   # strong demotion for that wasted slack
_FULL_BONUS = 30.0     # dominating reward for a perfectly full bin


def priority(item, bins):
    residual = (bins - item).astype(np.float64)   # >= 0 for every bin shown
    score = -residual                              # base: tightest fit wins
    score -= _TINY_PENALTY * ((residual > 0) & (residual < _TINY_LIMIT))
    score += _FULL_BONUS * (residual == 0)
    return score
# EVOLVE-BLOCK-END
