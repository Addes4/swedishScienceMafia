# EVOLVE-BLOCK-START
"""Best fit with a smooth, item-size-aware dead-slack penalty.

The classic best-fit rule (smallest positive residual) is hard to beat
online, but it happily leaves tiny unusable gaps.  We keep tightest-fit
as the dominant ordering and add a small penalty only for residuals that
are positive and smaller than the current item size, since such gaps
cannot absorb another item as large as the one just placed and are the
most likely to be stranded.  A concave (sqrt-scaled) penalty avoids
over-penalizing moderate residuals.  Larger residuals that can still host
future items are effectively untouched, preserving best-fit behaviour.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item                     # >= 0 for bins shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Dead slack: positive but can't fit an item as large as this one.
    small = (residual > 0) & (residual < item)
    score -= 0.9 * np.sqrt(residual.astype(np.float64)) * small
    return score
# EVOLVE-BLOCK-END
