# EVOLVE-BLOCK-START
"""Best-fit backbone with exact-fill bonus and near-tie slack preference.

Pure best-fit places each item into the bin with the tightest residual.
This is hard to beat, but two refinements help at the margins:

1. An exact fill (residual 0) is strictly optimal: the bin is closed with
   zero waste.  Give it a strong bonus so it always wins.
2. Among near-ties in residual, prefer the *larger* residual so we keep a
   bin with plenty of room reusable rather than shaving a bin down to a
   tiny unusable leftover.
"""
import numpy as np

_EXACT_BONUS = 100.0     # dominates any residual difference
_TIE_EPS = 1.0           # near-tie band in residual units
_TIE_WEIGHT = 0.5        # preference weight for larger residual


def priority(item, bins):
    residual = bins - item
    score = -residual.astype(np.float64)

    # Exact fill: bin becomes completely full.
    score += _EXACT_BONUS * (residual == 0)

    if _TIE_EPS > 0.0:
        # Among near-ties in residual, prefer the larger residual.
        base = -residual.astype(np.float64)
        m = base.max()
        is_near = (base >= m - _TIE_EPS)
        score += _TIE_WEIGHT * residual * is_near

    return score
# EVOLVE-BLOCK-END

