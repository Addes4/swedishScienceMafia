# EVOLVE-BLOCK-START
"""Adaptive best-fit with leftover-usability shaping.

Classic best-fit (tightest residual) minimizes immediate waste but often
finishes bins with a sliver too small for any future item.  We keep the
tight-fit ordering as the backbone but add a small continuous term that
shapes the *new leftover*: residuals near the running mean item size are
slightly preferred (likely to be filled later), while tiny unusable
slivers get a mild penalty and exact fits get a small bonus.
"""
import numpy as np

# Dominant tight-fit weight; the shaping term stays well below 1 so it
# only breaks near-ties and gently biases slack distribution.
_FIT_W = 1.0
_SHAPE_W = 0.25    # scale of leftover-usability shaping
_SLIVER = 8.0      # residuals in (0, _SLIVER) are treated as unusable
_SLIVER_PEN = 0.35
_EXACT_BONUS = 0.20

_state = {"sum": 0.0, "n": 0, "mean": 40.0}


def priority(item, bins):
    # Online estimate of mean item size (only used as a soft target).
    _state["sum"] += item
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]
    _state["mean"] = mean

    residual = bins - item                      # >= 0 for shown bins
    new_left = residual.astype(np.float64)      # leftover after placing

    # Backbone: prefer tightest fit (smallest new leftover).
    score = -_FIT_W * new_left

    # Shaping: how far the leftover is from a likely future item size.
    # Prefer leftovers near `mean` (fillable soon) over unusable slivers.
    shape = -np.abs(new_left - mean) / 100.0
    score += _SHAPE_W * shape

    # Extra penalty for unusable slivers, bonus for a clean exact fit.
    sliver = (new_left > 0.0) & (new_left < _SLIVER)
    score -= _SLIVER_PEN * sliver
    score += _EXACT_BONUS * (new_left == 0.0)

    return score
# EVOLVE-BLOCK-END
