# EVOLVE-BLOCK-START
"""Best fit with a continuous residual-utility bias.

Pure best-fit minimizes the immediate leftover but can leave a bin with
a tiny unusable sliver.  We keep tight-fit ordering (large negative
weight on residual) and add a small continuous utility term based on the
known Weibull-shaped item-size distribution: exact fill and residuals
equal to likely future item sizes are mildly preferred, while tiny
slivers (1..8) are mildly penalized.  The bias is small enough not to
override the nearest-fit choice except when residuals are very close.
"""
import numpy as np

# Static histogram over item sizes 1..100 (mean ~40, Weibull-shaped).
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
# Utility for a leftover residual r (1..100): how fillable it is.
_UTIL = np.concatenate(([0.0], _PDF))  # index by residual 1..100

# Tiny slivers are hard to reuse.
_SLIVER = 8.0
_SLIVER_PENALTY = 0.6

_UTIL_WEIGHT = 0.35
_EXACT_BONUS = 0.4

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    rf = residual.astype(np.float64)
    score = -rf                                # base: tightest fit wins

    # Continuous utility: prefer leftovers that future items can fill.
    rc = np.clip(residual, 0, 100).astype(np.int64)
    score += _UTIL_WEIGHT * _UTIL[rc]

    # Mild penalty for unusable tiny slivers.
    score -= _SLIVER_PENALTY * ((residual > 0) & (residual < _SLIVER))

    # Small bonus when the item exactly fills the bin.
    score += _EXACT_BONUS * (residual == 0)

    return score
# EVOLVE-BLOCK-END
