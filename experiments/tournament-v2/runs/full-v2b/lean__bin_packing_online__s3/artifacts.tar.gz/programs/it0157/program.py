# EVOLVE-BLOCK-START
"""Threshold-aware best fit with exact-fill and reusable-slack tie-break.

Pure best-fit often creates a bin whose small leftover (say 1..19) no
future item can use, wasting capacity.  We keep the tight-fit ordering
by residual and apply a surcharge to residuals in this "waste" band.
For near-ties we additionally prefer residuals that can still accept at
least the current item size (reusable slack) and reward exact fills.
"""
import numpy as np

# Residuals strictly between 0 and this value are treated as wasted slack.
_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.3

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise residuals that are small but non-zero (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0:
        # Near-ties: prefer leftover slack that is at least the size of the
        # current item (so it can plausibly hold a similar future item),
        # and slightly reward exact fills (residual == 0).
        _state["tick"] += 1
        reusable = (residual >= item).astype(np.float64)
        exact = (residual == 0).astype(np.float64)
        bonus = reuse_weight_scale() * reusable + exact
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * bonus * is_near
    return score


def reuse_weight_scale():
    return 0.5
# EVOLVE-BLOCK-END
