# EVOLVE-BLOCK-START
"""Best-fit with perfect-fill priority and size-aware slack penalty.

Pure best-fit (smallest residual) is the strongest base rule here, but it
can create tiny unused slacks.  We add:
  * a large bonus when the residual exactly equals the item (perfect fill,
    leaving zero slack),
  * a moderate bonus when the leftover residual is close to the mean item
    size (so a future average-sized item can consume it exactly),
  * a slack penalty for small positive residuals, scaled by the current
    item size so placing a large item that leaves a small unusable
    leftover is discouraged more than for a small item.
"""
import numpy as np

_TIE_EPS = 1.0
_PERFECT_BONUS = 50.0
_NEAR_FILL_BONUS = 1.0
_WASTE_LIMIT = 20.0
_MEAN_ITEM = 40.0

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Size-aware slack penalty: small positive leftovers are wasteful,
    # and more so when the item is large (harder to fill them later).
    slack_scale = item / _MEAN_ITEM
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= (2.0 * slack_scale) * waste

    # Perfect fill: leaving zero slack is strongly preferred.
    perfect = (residual == 0)
    score += _PERFECT_BONUS * perfect

    # Near-fill: a leftover near the mean item size is easy to reuse.
    near_mean = np.abs(residual - _MEAN_ITEM) <= 3.0
    score += _NEAR_FILL_BONUS * near_mean

    return score
# EVOLVE-BLOCK-END
