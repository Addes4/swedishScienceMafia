# EVOLVE-BLOCK-START
"""Canonical Best Fit (with a deterministic tie-break).

Theoretical and empirical work on online bin packing shows that plain
Best Fit -- placing the item into the bin where the leftover residual is
smallest -- is a strong, robust rule for Weibull-ish sizes.  The earlier
waste-band surcharge and histogram tie-breaks only perturbed the tightest
fit ordering and hurt the score, so they are removed here.

Tie-break: among bins with identical residual, prefer the one that is
currently *least* full (larger remaining capacity before placement),
i.e. leave the fuller bins untouched.  This is a mild, symmetric rule
that never overrides the primary tightest-fit decision.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item                    # >= 0 for every bin shown
    # Primary criterion: smallest residual after placement (tightest fit).
    # Secondary criterion: larger pre-placement capacity (less full bin).
    score = -residual.astype(np.float64) * 1024.0 + bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
