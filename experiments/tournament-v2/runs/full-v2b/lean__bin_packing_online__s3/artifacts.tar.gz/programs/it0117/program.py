# EVOLVE-BLOCK-START
"""Threshold-aware best fit with histogram-guided near-tie break."""
import numpy as np

_WASTE_LIMIT = 18.0
_SURCHARGE = 3.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.03

_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item
    score = -residual.astype(np.float64)
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _FILL[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
