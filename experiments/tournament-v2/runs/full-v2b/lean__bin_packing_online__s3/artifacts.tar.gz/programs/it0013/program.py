# EVOLVE-BLOCK-START
"""Threshold-aware best fit: avoid stranding tiny unusable residuals.

Pure best-fit often creates a bin with a small leftover (say 3..18) that
no future item can use, wasting capacity.  Here we pick the bin that
minimises residual-after-placement, but we add a surcharge to residuals
that fall in a "waste" band just above 0, pushing the algorithm to either
fully fill a bin (residual 0) or leave a genuinely reusable gap.
"""
import numpy as np

# Residuals strictly between 0 and this value are treated as wasted slack.
_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise residuals that are small but non-zero (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste
    return score
# EVOLVE-BLOCK-END
