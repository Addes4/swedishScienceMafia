# EVOLVE-BLOCK-START
"""Best fit with a mild small-residual penalty and a fillability tie-break.

Tightest fit (smallest residual) is the base rule.  A small flat penalty
on residuals in 1..15 discourages leaving tiny unusable slack, but it is
kept mild so it does not override genuinely better tight fits.  Near-ties
in score are then broken by preferring the bin whose resulting residual is
a *likely* future item size, using a static histogram of the known
Weibull-shaped item-size distribution, so the leftover can be filled later.
"""
import numpy as np

_WASTE_LIMIT = 15.0
_SURCHARGE = 4.0
_TIE_EPS = 1.5
_TIE_WEIGHT = 0.08

# Static histogram over item sizes 1..100 (mean ~40, Weibull-shaped),
# used only as a relative "fillability" weight for residuals.  Values are
# smooth approximations, not tuned to any single instance.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
# For a residual r (1..100) we score fillability as the PDF at r.
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Mildly penalise residuals that are small but non-zero (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0:
        # Near-ties: prefer a leftover residual that is likely to be
        # exactly fillable by a future item.
        _state["tick"] += 1
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _FILL[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
