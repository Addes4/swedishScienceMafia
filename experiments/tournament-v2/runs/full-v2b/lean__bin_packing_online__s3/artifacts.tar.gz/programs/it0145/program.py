# EVOLVE-BLOCK-START
"""Tightest-fit (best-fit) is near-optimal for this online bin packing
distribution.  The only safe refinement is to leave the primary ordering
untouched and apply a *tiny* deterministic bonus that can only break exact
residual ties toward a residual that is a likely future item size,
computed from the known Weibull-shaped item-size distribution.
"""
import numpy as np

# Static histogram over item sizes 1..100 (mean ~40, Weibull-shaped),
# used only as a relative "fillability" weight for residuals.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100

# Bonus kept far below 1.0 so it never reorders distinct residuals.
_TIE_BONUS = 0.25


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Only affect exact residual ties: add a small positive bonus that
    # depends on how likely the leftover residual is to be filled later.
    rc = np.clip(residual, 0, 100).astype(np.int64)
    fill = _FILL[rc]
    is_tie = (score == score.max())
    score = score + _TIE_BONUS * fill * is_tie
    return score
# EVOLVE-BLOCK-END
