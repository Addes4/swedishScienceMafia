# EVOLVE-BLOCK-START
"""Best fit with size-aware sliver penalty and deterministic consistent hash tie-break.

Pure best fit minimizes residual but can leave tiny unusable slivers.  We keep
the tight-fit (residual) ordering as the dominant term, mildly penalize small
non-zero residuals (the penalty grows with item size, since large items make
slivers more costly), and break exact ties deterministically using a fixed hash
of the bin index so slack is spread across bins without random cycling.
"""
import numpy as np

_SLIVER_LIMIT = 30.0
_SLIVER_BASE = 0.10
_SLIVER_PER_SIZE = 0.0015
_TIE_WEIGHT = 0.05


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Penalise small non-zero residuals (unusable slack), scaled by item size.
    waste = (residual > 0) & (residual < _SLIVER_LIMIT)
    pen = (_SLIVER_BASE + _SLIVER_PER_SIZE * item) * waste
    score -= pen

    # Deterministic consistent-hash tie-break: stable per bin index, no cycling.
    idx = np.arange(residual.shape[0], dtype=np.float64)
    perturb = ((idx * 2654435761.0) % 1000.0) / 1000.0
    is_near = np.abs(score - score.max()) <= 1.0
    score = score - _TIE_WEIGHT * perturb * is_near
    return score
# EVOLVE-BLOCK-END
