# EVOLVE-BLOCK-START
"""Graded low-residual penalty with exact-fit bonus.

Best fit minimizes the leftover capacity after placement.  A leftover that
is small but nonzero tends to be unusable by any future item, so it is a
waste; a leftover that is zero (exact fill) is ideal; a leftover large
enough to fit a typical future item is genuinely reusable.  This rule keeps
best fit as the base but replaces the flat band surcharge with a smooth,
graded penalty that decays to zero as the residual grows toward a reusable
size, plus a small bonus for exact fills to make them win ties.
"""
import numpy as np

_REUSE = 40.0      # residual above this is treated as fully reusable
_WASTE_WEIGHT = 8.0
_EXACT_BONUS = 2.0


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    r = residual.astype(np.float64)
    score = -r                                  # base: best fit
    # Graded penalty for nonzero residuals below the reusable size: maximal
    # for tiny slivers, decaying linearly to 0 at _REUSE.
    small = (residual > 0) & (residual < _REUSE)
    score -= _WASTE_WEIGHT * small * (_REUSE - r) / _REUSE
    # Exact fills are the best possible outcome; give them a nudge.
    score += _EXACT_BONUS * (residual == 0)
    return score
# EVOLVE-BLOCK-END
