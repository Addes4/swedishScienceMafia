# EVOLVE-BLOCK-START
"""Best-fit with a small perfect-fill tie-break.

Best-fit (tightest residual) is a strong online rule.  Its main flaw is
stranding tiny leftovers that no future item can use.  We apply a mild
surcharge to only truly unusable residuals (1..3), and break near-ties by
preferring a leftover residual that can be exactly filled by a single
future item, using a smooth static histogram of the known item-size
distribution.
"""
import numpy as np

# Only residuals 1..3 are treated as essentially unusable slack.
_WASTE_LIMIT = 4.0
_SURCHARGE = 3.0
_TIE_EPS = 1.5
_TIE_WEIGHT = 0.6

# Static histogram over residuals 1..100 (relative fillability weight).
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.max()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Penalise only tiny, truly unusable residuals.
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    # Near-ties in residual: prefer a leftover that is likely to be
    # exactly fillable by a future item.
    rc = np.clip(residual, 0, 100).astype(np.int64)
    fill = _FILL[rc]
    is_near = np.abs(score - score.max()) <= _TIE_EPS
    score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
