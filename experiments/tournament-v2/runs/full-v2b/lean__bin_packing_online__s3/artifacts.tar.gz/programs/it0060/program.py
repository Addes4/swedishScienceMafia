# EVOLVE-BLOCK-START
"""Tight best fit with light near-tie rotation.

The strongest simple online rule is best fit: place each item into the bin
with the smallest remaining capacity that still fits it.  Earlier attempts
to penalise small "wasted" residuals generally hurt, so we keep the residual
ordering dominant and only add a very small stateful perturbation to break
near-ties across different bin indices instead of always choosing the lowest
index.
"""
import numpy as np

_TIE_EPS = 0.5
_TIE_WEIGHT = 0.01

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        idx = np.arange(residual.shape[0], dtype=np.float64)
        perturb = ((idx * 2654435761.0 + _state["tick"] * 40503.0) % 1000.0) / 1000.0
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score - _TIE_WEIGHT * perturb * is_near
    return score
# EVOLVE-BLOCK-END
