# EVOLVE-BLOCK-START
"""Best-fit with online-learned residual-fillability tie-break.

The primary rule is best fit: prefer the bin with the smallest nonnegative
residual (tightest fit).  This is strong on this distribution, but it can
create a leftover residual that later items never exactly fill.

To break near-ties (bins whose residual is within a small epsilon of the
tightest), we prefer the bin whose resulting residual matches a size that
has actually been observed coming in so far.  The frequency table is learned
online from the item stream itself, so it reflects the true distribution of
this instance without any assumed shape.  A light penalty is applied to
residuals in a small "unusable" band just above zero.
"""
import numpy as np

_EPS = 1.5          # residual window for near-ties
_WASTE_LIMIT = 18.0 # residuals in (0, limit) are treated as slack
_SURCHARGE = 3.0
_FILL_WEIGHT = 1.0

# Online histogram of observed item sizes, indexed 0..100.
_counts = np.zeros(101, dtype=np.float64)
_seen = 0


def priority(item, bins):
    global _seen
    # Update the learned histogram with the current item.
    _counts[item] += 1.0
    _seen += 1

    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Penalise small but non-zero residuals (likely unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    # Online fillability: how often each size r has been seen as an item.
    # Normalise so the bonus stays small relative to the residual ordering.
    total = _counts.sum()
    if total > 0:
        fill = _counts / total                # probability-like weight
    else:
        fill = _counts
    rc = np.clip(residual, 0, 100).astype(np.int64)
    fill_score = fill[rc] * 100.0             # scale ~0.1..1 range

    # Apply the fillability bonus only among near-ties in residual score.
    is_near = np.abs(score - score.max()) <= _EPS
    score = score + _FILL_WEIGHT * fill_score * is_near
    return score
# EVOLVE-BLOCK-END
