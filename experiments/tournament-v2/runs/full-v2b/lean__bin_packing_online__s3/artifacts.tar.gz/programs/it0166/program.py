# EVOLVE-BLOCK-START
"""Adaptive best fit: tightest-fit base with a self-scaled waste penalty.

Pure best-fit (rank by residual) is near-optimal on average, but it tends
to leave tiny, unusable slacks (e.g. 1..18) that no future item can fill.
We keep the tight-fit ordering and subtract a penalty for slacks that are
small relative to items we actually see.  Rather than a hard-coded band,
the penalty is scaled by the running mean item size, so it adapts to the
distribution instead of being tuned to one instance.
"""
import numpy as np

_state = {"tick": 0, "sum": 0.0, "n": 0}

# Exponential-ish prior for the mean item size (distribution mean ~40).
_PRIOR_N = 50.0
_PRIOR_MEAN = 40.0

# Fraction of the mean item size below which a slack is "likely wasted".
_WASTE_FRAC = 0.45
# Penalty weight, in units of the (negative) base score per residual unit.
_SURCHARGE = 4.0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown

    st = _state
    st["tick"] += 1
    st["sum"] += float(item)
    st["n"] += 1
    mean_item = (st["sum"] + _PRIOR_N * _PRIOR_MEAN) / (st["n"] + _PRIOR_N)

    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Slack too small for typical future items -> waste.  Scale smoothly:
    # full penalty just above 0, fading out near the threshold.
    limit = _WASTE_FRAC * mean_item
    waste = (residual > 0) & (residual < limit)
    if waste.any():
        # 1.0 at residual==0-ish, 0.0 at residual==limit
        strength = 1.0 - (residual.astype(np.float64) / limit)
        strength = np.clip(strength, 0.0, 1.0)
        score -= _SURCHARGE * strength * waste

    return score
# EVOLVE-BLOCK-END
