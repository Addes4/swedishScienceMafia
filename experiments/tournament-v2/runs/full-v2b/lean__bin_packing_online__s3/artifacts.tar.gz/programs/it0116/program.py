# EVOLVE-BLOCK-START
"""Best-fit with self-size slack avoidance.

Pure best fit minimizes the leftover, but it can leave a residual that is
smaller than the item just placed.  A residual below the current item's
size is often hard to reuse, whereas the item here might have fit into a
slightly larger residual elsewhere.  We keep best-fit ordering (smallest
residual) but add a modest penalty to any candidate whose resulting
residual is positive and less than the current item size.
"""
import numpy as np

_SELF_PENALTY = 8.0


def priority(item, bins):
    residual = bins - item                       # >= 0
    score = -residual.astype(np.float64)         # base: tightest fit wins
    # Penalise leaving slack smaller than the item we just placed.
    small_slack = (residual > 0) & (residual < item)
    score -= _SELF_PENALTY * small_slack
    return score
# EVOLVE-BLOCK-END
