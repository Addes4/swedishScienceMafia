# EVOLVE-BLOCK-START
"""Best-fit with a concave waste penalty and a perfect-fit bonus.

Pure best-fit can leave tiny unusable slacks.  We keep tightest-fit as
the backbone (score = -residual) and subtract a *concave* penalty
(sqrt of residual) over a modest waste band so tiny leftovers are
strongly discouraged while moderately small ones (which later items can
still fill) are only mildly penalized.  A static Weibull histogram gives
a very small near-tie bonus for fillable residuals, and exact fits get a
small explicit bonus.
"""
import numpy as np

# Residuals strictly between 0 and this value are treated as wasted slack.
_WASTE_LIMIT = 22.0
_SURCHARGE = 3.0
_PERFECT_BONUS = 1.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

# Static histogram over item sizes 1..100 (mean ~40, Weibull-shaped),
# used only as a relative "fillability" weight for residuals.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    r = residual.astype(np.float64)
    score = -r                                  # base: tightest fit wins

    # Concave penalty for small non-zero residuals (unusable slack).
    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * np.sqrt(r) * waste

    # Explicit bonus for an exact fit (leaves residual 0).
    score += _PERFECT_BONUS * (residual == 0)

    if _TIE_EPS > 0.0:
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _FILL[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
