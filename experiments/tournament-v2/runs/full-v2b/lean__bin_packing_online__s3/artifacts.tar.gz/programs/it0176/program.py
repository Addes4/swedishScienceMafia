# EVOLVE-BLOCK-START
"""Best-fit core with a mild exact-fill bonus and no waste surcharge.

Pure best-fit (smallest residual after placement) is a strong online
rule for this distribution.  Earlier surcharges and histogram tie-breaks
consistently hurt.  Here we keep strict tightest-fit ordering and add
only a tiny bonus for bins that become exactly full (residual 0), which
is always a good outcome and cannot fragment capacity.
"""
import numpy as np

_EXACT_BONUS = 1e-3


def priority(item, bins):
    residual = (bins - item).astype(np.float64)  # >= 0
    score = -residual
    score += _EXACT_BONUS * (residual == 0.0)
    return score
# EVOLVE-BLOCK-END
