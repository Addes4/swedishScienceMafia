# EVOLVE-BLOCK-START
"""Best-fit with a tiny consolidation tiebreak.

Pure best-fit minimizes residual-after-placement.  The only free choice
left is ties in residual, which happen often on this distribution (many
bins share the same remaining capacity).  Resolving those ties toward
the fullest bin (smallest pre-placement residual) packs existing bins
slightly harder before opening new space, without disturbing the
best-fit ordering on non-tied residuals.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item                      # >= 0 for all shown bins
    # Primary key: minimize residual (tightest fit).
    # Secondary key (tiny): prefer the bin that was fuller before placement,
    # i.e. smaller bins value.  Encode as -residual*K - bins, K large enough
    # that residual dominates but equal residuals are broken by bins.
    return -residual.astype(np.float64) * 1024.0 - bins.astype(np.float64)
# EVOLVE-BLOCK-END
