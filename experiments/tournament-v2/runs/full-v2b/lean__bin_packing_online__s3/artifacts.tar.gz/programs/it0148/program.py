# EVOLVE-BLOCK-START
"""Pure best-fit (tightest residual) bin choice.

Prior tuning of waste-band surcharges, graded penalties and PDF-based
near-tie bonuses all underperformed this simple rule on held-out
instances.  Best-fit keeps bins as full as possible, leaving the most
usable slack, and is robust across the Weibull-shaped item stream.
"""
import numpy as np


def priority(item, bins):
    # Rank by tightest fit: smallest remaining capacity that still fits.
    # Ties are broken by the harness (first index wins).
    return -(bins - item).astype(np.float64)
# EVOLVE-BLOCK-END
