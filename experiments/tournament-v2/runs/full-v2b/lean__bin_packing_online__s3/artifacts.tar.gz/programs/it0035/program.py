# EVOLVE-BLOCK-START
"""Graded waste-aware best fit.

Pure best-fit often strands a small leftover (say 1..18) that no future
item can use, wasting capacity silently.  Here we keep best-fit as the
base but add a graded surcharge on nonzero residuals, larger for smaller
residuals, so unusably tiny slivers are avoided while genuinely reusable
gaps are left alone.
"""
import numpy as np

_WASTE_LIMIT = 22.0   # residuals below this are considered risky slack
_SURCHARGE = 8.0      # maximum extra penalty applied near residual ~ 0


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins
    # Graded penalty: strongest for the smallest nonzero residuals.
    r = residual.astype(np.float64)
    frac = np.clip((_WASTE_LIMIT - r) / _WASTE_LIMIT, 0.0, 1.0)
    penalise = (residual > 0)
    score -= _SURCHARGE * frac * penalise
    return score
# EVOLVE-BLOCK-END
