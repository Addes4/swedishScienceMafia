# EVOLVE-BLOCK-START
"""Best fit with online histogram of observed item sizes for tie-breaks.

The primary rule is tightest-fit (smallest nonnegative residual).  Among
near-ties we prefer the bin whose resulting residual is a size we have
actually seen arrive often, so it is likely to be exactly fillable later.
A small surcharge discourages leaving a residual barely smaller than the
current item (a near-miss that this item itself could almost have filled).
"""
import numpy as np

_WASTE_LIMIT = 20.0
_SURCHARGE = 6.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

# Online count of observed item sizes (index 1..100).
_counts = np.zeros(101, dtype=np.float64)
_seen = 0

_state = {"tick": 0}


def priority(item, bins):
    global _seen
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    waste = (residual > 0) & (residual < _WASTE_LIMIT)
    score -= _SURCHARGE * waste

    # Online fillability: probability mass near each residual.
    if _seen > 0:
        weights = _counts / _seen
    else:
        weights = _counts

    if _TIE_EPS > 0.0 and _seen > 20:
        _state["tick"] += 1
        rc = np.clip(residual, 0, 100).astype(np.int64)
        # Smooth the mass slightly over neighbours for robustness.
        fill = weights[rc]
        fill = fill + 0.5 * weights[np.clip(rc - 1, 0, 100)] + \
            0.5 * weights[np.clip(rc + 1, 0, 100)]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near

    # Record the observed item for future calls.
    if 1 <= item <= 100:
        _counts[item] += 1.0
        _seen += 1

    return score
# EVOLVE-BLOCK-END
