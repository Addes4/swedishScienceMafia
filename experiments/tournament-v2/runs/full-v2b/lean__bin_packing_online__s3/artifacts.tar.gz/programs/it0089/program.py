# EVOLVE-BLOCK-START
"""Best fit with online-learned residual fillability.

Items arrive from a fixed but unknown distribution.  Pure best-fit
(narrowest residual) wastes capacity by leaving tiny residuals no future
item can fill.  Instead of a hand-tuned waste band, we learn the item
size distribution online from the stream itself and score each candidate
bin by the probability that its resulting residual will later be exactly
fillable by some arriving item.  Ties (equal residual) break toward the
more fillable leftover.
"""
import numpy as np

_CAP = 100
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05
_SMOOTH = 1.0  # Laplace smoothing for unseen sizes

# Online counts of observed item sizes 1..100.
_counts = np.full(_CAP + 1, _SMOOTH, dtype=np.float64)
_total = float(_counts[1:].sum())
_seen = 0


def _refresh():
    global _total
    _total = float(_counts[1:].sum())


def priority(item, bins):
    global _seen
    # Update learned distribution with the freshly observed item.
    if 1 <= item <= _CAP:
        _counts[item] += 1.0
        _seen += 1
        if (_seen & 15) == 0:
            _refresh()

    residual = bins - item                     # >= 0 everywhere shown
    rf = residual.astype(np.float64)
    score = -rf                                 # base: tightest fit wins

    if _TIE_EPS > 0.0:
        # Among near-ties, prefer residuals likely to be exactly filled.
        rc = np.clip(residual, 0, _CAP).astype(np.int64)
        fill = _counts[rc] / _total
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
