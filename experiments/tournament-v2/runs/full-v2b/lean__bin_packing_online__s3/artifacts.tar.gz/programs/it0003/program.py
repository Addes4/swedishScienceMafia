# EVOLVE-BLOCK-START
"""Best fit with an explicit exact-fit priority boost."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize residual (best fit). Exact fits (residual 0) get a strong boost.
    score = -residual.astype(np.float64)
    score += (residual == 0) * 0.5
    return score
# EVOLVE-BLOCK-END
