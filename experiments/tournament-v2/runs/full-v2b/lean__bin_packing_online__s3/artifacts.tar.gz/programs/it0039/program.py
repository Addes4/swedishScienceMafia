# EVOLVE-BLOCK-START
"""Distribution-aware best fit with unusable-residual suppression.

Items arrive online.  We keep a running estimate of the smallest item size
seen so far (and a low percentile) to know which residuals are genuinely
unusable slivers.  Scoring:

  * exact fills are strongly preferred (residual == 0),
  * otherwise smaller residual wins (best fit),
  * but a nonzero residual smaller than the smallest observed item size is
    heavily penalised because that slack can never be reused,
  * residuals above that threshold are mildly rewarded so that usable gaps
    survive rather than being fragmented into slivers.
"""
import numpy as np

_BIG = 1e6
_MIN_WASTE = 6.0          # never treat residuals below this as "usable"
_PENALTY = 8.0            # penalty for an unusable nonzero residual
_USABLE_BONUS = 0.5       # mild reward for leaving a usable gap


class _State:
    def __init__(self):
        self.min_item = 100.0
        self.ma = None
        self.ma_count = 0


_state = _State()


def _upd(item):
    s = _state
    if item < s.min_item:
        s.min_item = item
    s.ma_count += 1
    if s.ma is None:
        s.ma = float(item)
    else:
        s.ma += (item - s.ma) / s.ma_count


def priority(item, bins):
    _upd(item)
    residual = (bins - item).astype(np.float64)   # >= 0
    score = -residual                              # base best fit

    # threshold below which a residual is considered unusable
    thr = max(_MIN_WASTE, _state.min_item - 1.0)

    nonzero = residual > 0.0
    unusable = nonzero & (residual < thr)
    usable = residual >= thr

    # exact fills (residual 0) get a big boost
    exact = ~nonzero
    score = np.where(exact, _BIG, score)
    score = np.where(unusable, score - _PENALTY, score)
    score = np.where(usable & ~exact, score + _USABLE_BONUS, score)
    return score
# EVOLVE-BLOCK-END

