# EVOLVE-BLOCK-START
"""Mode-targeted best fit.

Tightest-fit (smallest residual) remains the backbone, since pure best-fit
is hard to beat.  Instead of penalising a fixed "waste band", we reward
residuals that sit near the mode of the known Weibull-shaped item-size
distribution: such a leftover is most likely to be exactly filled by a
future item, so bins stay productive.  The reward is applied only in a
small near-tie band, so it never overrides a clearly better tight fit.
"""
import numpy as np

_TIE_EPS = 2.0
_TIE_WEIGHT = 3.0

# Static histogram over item sizes 1..100 (mean ~40, Weibull-shaped).
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
# Fillability weight indexed by residual 1..100 (0 -> 0, exact full is best
# handled by the tight-fit backbone giving residual 0 the highest base score).
_FILL = np.concatenate(([0.0], _PDF))


def priority(item, bins):
    residual = bins - item                      # >= 0 for all shown bins
    score = -residual.astype(np.float64)        # base: tightest fit wins

    if _TIE_EPS > 0.0:
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _FILL[rc]
        # Bonus for residuals near the distribution mode among near-ties.
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END

