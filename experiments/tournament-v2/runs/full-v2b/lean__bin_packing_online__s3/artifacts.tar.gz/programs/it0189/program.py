# EVOLVE-BLOCK-START
"""Adaptive best-fit: strict tightest-fit backbone with a learned
exact-fill tie-break.

Pure best-fit (smallest residual) is the strongest simple online rule for
this distribution.  The only cheap improvement is to break *near-ties* in
residual by preferring a leftover residual that equals some item size we
have actually seen before, since such a residual can be exactly filled
later.  The histogram is learned online from arriving items, so it needs
no tuning to a specific instance.
"""
import numpy as np

_TIE_EPS = 1.0        # residuals within this of the best are near-ties
_TIE_WEIGHT = 0.02    # small weight so best-fit ordering dominates

# Running count of item sizes seen so far (index by size 1..100).
_seen = np.zeros(101, dtype=np.float64)
_ALPHA = 0.997  # exponential decay to track the (stationary) distribution
_state = {"init": False}


def priority(item, bins):
    global _seen
    if not _state["init"]:
        _state["init"] = True
    # Update learned item-size histogram before scoring.
    _seen *= _ALPHA
    _seen[item] += 1.0

    residual = bins - item                      # >= 0 for every shown bin
    score = -residual.astype(np.float64)        # tightest fit wins

    # Near-tie break: prefer a residual that matches a common past item
    # size, i.e. a leftover that is likely to be exactly fillable.
    rc = np.clip(residual, 0, 100).astype(np.int64)
    # "fillability" of residual r ~ how often size r was seen.
    fill = _seen[rc]
    # normalize so the bonus stays small and bounded
    fmax = fill.max()
    if fmax > 0.0:
        fill = fill / fmax

    is_near = np.abs(score - score.max()) <= _TIE_EPS
    score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
