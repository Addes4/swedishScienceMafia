# EVOLVE-BLOCK-START
"""Best-fit with an expected-usable-slack correction.

Pure best-fit sometimes leaves a residual that no future item can use,
wasting capacity.  Instead of a hard-coded "waste band", we value each
bin's leftover by the probability (from the known Weibull-shaped item-size
distribution) that a future item can still fit into it, combined with a
strong tight-fit base.  This is a smooth, monotone correction: tighter
fits still win, but among comparable fits we prefer bins whose slack is
likely to be consumed.
"""
import numpy as np

# Sample grid for the static item-size distribution.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.sum()

# For a residual r, value it by the probability that at least one future
# item (of the typical size distribution) fits in it.
#   value(r) = P(item <= r) weighted by the item size (bigger fills help more)
_COMPLETENESS = np.concatenate(([0.0], np.cumsum(_PDF)))  # CDF at 1..100
# Usable value: expected item size that can still fit, relative to residual.
_USABLE = np.concatenate(([0.0], _COMPLETENESS[1:] ))  # placeholder overwritten below

# value(r) = CDF(r): higher means the slack is more likely to be reusable.
_VALUE = np.concatenate(([0.0], _COMPLETENESS))

_BASE = 1.0
_LAMBDA_USABLE = 4.0
_FILL_BONUS = 0.5


def priority(item, bins):
    residual = bins - item                      # >= 0
    score = -_BASE * residual.astype(np.float64)

    # Smooth correction: prefer residuals likely to be reused by future items.
    rc = np.clip(residual, 0, 100).astype(np.int64)
    score += _LAMBDA_USABLE * _VALUE[rc]

    # Small bonus for exact fills (residual becomes 0).
    score += _FILL_BONUS * (residual == 0)
    return score
# EVOLVE-BLOCK-END

