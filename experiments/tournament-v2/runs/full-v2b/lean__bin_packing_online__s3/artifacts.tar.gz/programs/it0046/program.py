# EVOLVE-BLOCK-START
"""Adaptive best fit that prefers residuals matching likely future items.

Pure best-fit minimizes the residual after placement, but a residual is
only valuable if some future item can exactly fill it.  Items come from a
fixed Weibull-ish distribution with mean ~40, so residuals near 0 are
usually wasted while residuals equal to a common item size are "good
gaps".  We keep best-fit as the tie-breaker but add a small bonus to
residuals that experience says can be filled later.

We track the observed item sizes online (histogram) and reward the
residual that most closely matches a frequent item size, plus give a
bonus for an exact fill (residual 0).
"""
import numpy as np

_CAP = 100
# Histogram of item sizes seen so far (index = size).
_count = np.zeros(_CAP + 1, dtype=np.float64)
_total = 0.0


def _freq_score(residual):
    """How likely is this residual to be exactly fillable later?

    Returns a value in [0, 1]: 1 if the residual is a size we see often,
    0 if it is rare.  Residual 0 (exact fill) is treated as fully good.
    """
    res = np.asarray(residual)
    good = (res == 0).astype(np.float64)
    idx = res.astype(np.int64)
    valid = (idx >= 1) & (idx <= _CAP)
    if _total > 0:
        p = np.zeros_like(good)
        p[valid] = _count[idx[valid]] / _total
        # Normalize by the max frequency to keep the bonus bounded.
        mx = _count.max() / _total if _count.max() > 0 else 1.0
        if mx > 0:
            p = p / mx
        good = np.maximum(good, p)
    return good


def priority(item, bins):
    global _total
    # Record the item size for future frequency estimates.
    if 1 <= item <= _CAP:
        _count[item] += 1.0
        _total += 1.0

    residual = bins - item                    # >= 0 for every bin shown
    score = -residual.astype(np.float64)      # base: tightest fit wins
    # Small bonus for residuals likely to be fillable by a future item.
    score += 2.5 * _freq_score(residual)
    return score
# EVOLVE-BLOCK-END
