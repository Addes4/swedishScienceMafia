# EVOLVE-BLOCK-START
"""Near-pure best-fit with exact-fit bonus and rotating tie-break.

Experiments show pure tight-fit ordering (smallest usable residual wins) is
strong for this Weibull-shaped distribution.  We therefore stay very close to
best-fit: the base score is the negative residual, exact fits (residual 0)
get a small extra bonus so bins are closed rather than left with a sliver, and
near-ties are broken with a deterministic rotating perturbation so we do not
always pour into the lowest-index bin.
"""
import numpy as np

_EXACT_BONUS = 2.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.5

_state = {"tick": 0}


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    score = -residual.astype(np.float64)        # base: tightest fit wins

    # Prefer closing a bin exactly when possible.
    score += _EXACT_BONUS * (residual == 0)

    if _TIE_EPS > 0.0:
        _state["tick"] += 1
        idx = np.arange(residual.shape[0], dtype=np.float64)
        perturb = ((idx * 2654435761.0 + _state["tick"] * 40503.0) % 1000.0) / 1000.0
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score - _TIE_WEIGHT * perturb * is_near
    return score
# EVOLVE-BLOCK-END
