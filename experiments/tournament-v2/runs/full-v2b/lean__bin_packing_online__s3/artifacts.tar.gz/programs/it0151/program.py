# EVOLVE-BLOCK-START
"""Best-fit with a graded slack-aware tiebreak.

Pure best-fit (tightest residual) is the strongest simple rule here.
Its weakness is leaving unusably small non-zero slack.  Instead of a
hard waste band (which misfires for large items) we apply a smooth,
monotone penalty that grows as the residual shrinks toward 0 from
above, mildly steering away from stranding tiny slack without ever
overturning a genuinely tighter fit.  A small fillability bonus
rewards residuals equal to likely future item sizes.
"""
import numpy as np

# Smooth slack penalty: penalty(r) is largest for tiny r and decays.
# Keep it small so true tightness dominates the ordering.
_PENALTY_SCALE = 8.0
_PENALTY_DECAY = 0.06          # per unit of residual
_FILL_WEIGHT = 0.15

# Static histogram over residuals 1..100: probability-like fillability.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.max()
_FILL = np.concatenate(([0.0], _PDF))     # index by residual 1..100

_RES = np.arange(0, 101, dtype=np.float64)
# Penalty only meaningful for small positive residuals.
_PEN = _PENALTY_SCALE * np.exp(-_PENALTY_DECAY * _RES)
_PEN[0] = 0.0


def priority(item, bins):
    residual = bins - item
    rf = residual.astype(np.float64)
    rc = np.clip(residual, 0, 100).astype(np.int64)
    # Base: tightest fit wins.
    score = -rf
    # Smooth penalty on tiny non-zero slack (0 residual is a perfect fill).
    small = (residual > 0)
    score -= _PEN[rc] * small
    # Reward residuals that are likely exact future item sizes.
    score += _FILL_WEIGHT * _FILL[rc]
    return score
# EVOLVE-BLOCK-END
