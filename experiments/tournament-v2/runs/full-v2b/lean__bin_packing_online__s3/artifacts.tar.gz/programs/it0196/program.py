# EVOLVE-BLOCK-START
"""Threshold-aware best fit with graded tiny-residual penalty and
histogram-guided near-tie break.

Pure best-fit often creates a bin whose small leftover (say 1..8) no
future item can use, wasting capacity.  We keep the tight-fit ordering
by residual and apply a *graded* surcharge to very small non-zero
residuals (the truly useless ones), so leaving residual 1 is worse than
leaving residual 6.  Near-ties in residual are broken by preferring the
bin whose leftover residual is a likely future item size, using a static
histogram of the known Weibull-shaped item-size distribution.
"""
import numpy as np

# Graded penalty for very small non-zero residuals.
_TINY_LIMIT = 9.0
_TINY_SURCHARGE = 8.0
_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05

# Static histogram over item sizes 1..100 (mean ~40, Weibull-shaped),
# used only as a relative "fillability" weight for residuals.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / _PDF.mean()
_FILL = np.concatenate(([0.0], _PDF))  # index by residual 1..100


def priority(item, bins):
    residual = bins - item                     # >= 0 for every bin shown
    score = -residual.astype(np.float64)       # base: tightest fit wins

    # Graded penalty: tiny residuals are nearly useless.  The penalty is
    # strongest just above 0 and fades to 0 at _TINY_LIMIT.
    r = residual.astype(np.float64)
    tiny = (r > 0) & (r < _TINY_LIMIT)
    # (1 - r/_TINY_LIMIT) is 1 at r->0 and 0 at r=_TINY_LIMIT.
    score -= _TINY_SURCHARGE * tiny * (1.0 - r / _TINY_LIMIT)

    if _TIE_EPS > 0.0:
        # Near-ties: prefer a leftover residual that is likely to be
        # exactly fillable by a future item.
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fill = _FILL[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * fill * is_near
    return score
# EVOLVE-BLOCK-END
