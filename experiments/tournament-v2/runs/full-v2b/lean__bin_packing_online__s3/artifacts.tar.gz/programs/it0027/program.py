# EVOLVE-BLOCK-START
"""Best fit with a light fill-preferring tiebreak.

Pure best-fit (minimise residual after placement) is the strongest known
online rule for this Weibull-shaped distribution.  Attempts to add waste
surcharges consistently hurt, so we keep the tight-fit core and add only
a tiny secondary term that prefers already fuller bins.  Because the
secondary term is scaled far below 1 (the granularity of residuals, which
are integers), it can never overturn a genuine best-fit choice; it only
breaks ties among bins with equal residual toward the fuller bin.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item                      # >= 0 for every bin shown
    # Primary: minimise residual (tightest fit).  Secondary: nudge toward
    # bins with the smallest residual (i.e. already fuller) without ever
    # exceeding one unit of residual, so it stays a pure tiebreaker.
    score = -residual.astype(np.float64) * 1024.0 - bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
