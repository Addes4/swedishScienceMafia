# EVOLVE-BLOCK-START
"""Tightest-fit base with a smooth, item-independent fillability bonus.

Pure best-fit (tightest residual) is near-optimal for this distribution.
The remaining loss comes from leaving small unusable slacks.  Rather than
a hard waste band (fragile, since its cutoff and magnitude are tuned to
nothing) we apply a smooth bonus for residuals that are themselves
plausible future item sizes, peaked near the distribution mean (~40).
The bonus is small relative to the 1-unit granularity of residuals, so it
only breaks genuine near-ties and never overrides a tighter fit.
"""
import numpy as np

# Triangular fillability weight over residuals 0..100, peaking at the
# typical item size.  Deterministic, no instance tuning.
_PEAK = 40.0
_WIDTH = 40.0
_R = np.arange(0, 101, dtype=np.float64)
_FILL = np.clip(1.0 - np.abs(_R - _PEAK) / _WIDTH, 0.0, 1.0)

_BONUS = 0.30          # strictly below 1, so tightness dominates
_TIE_WINDOW = 2.0      # only apply to near-ties in residual


def priority(item, bins):
    residual = bins - item
    base = -residual.astype(np.float64)

    rc = np.clip(residual, 0, 100).astype(np.int64)
    fill = _FILL[rc]

    is_near = np.abs(base - base.max()) <= _TIE_WINDOW
    score = base + _BONUS * fill * is_near
    return score
# EVOLVE-BLOCK-END
