# EVOLVE-BLOCK-START
"""Adaptive best-fit with empirical fillability tie-break.

Base ordering: tightest fit by residual after placement.  Over this we add
a small, data-driven bonus for residuals likely to be exactly fillable by a
future item, using a decaying histogram of observed item sizes (cold start
from the known Weibull shape).  Near-ties only, so tightest-fit is preserved.
"""
import numpy as np

_TIE_EPS = 1.0
_TIE_WEIGHT = 0.05
_DECAY = 0.999

# Cold-start histogram (Weibull-shaped, mean ~40) over sizes 1..100.
_SIZE = np.arange(1, 101, dtype=np.float64)
_LAMBDA = 2.0
_SCALE = 45.0
_PDF = (_LAMBDA / _SCALE) * (_SIZE / _SCALE) ** (_LAMBDA - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _LAMBDA)
_PDF = _PDF / max(_PDF.mean(), 1e-9)

# Decaying count histogram indexed 1..100 (index 0 unused).
_hist = np.concatenate(([0.0], _PDF)).astype(np.float64)
_total = _hist.sum()

_state = {"tick": 0}


def priority(item, bins):
    global _hist, _total
    residual = bins - item
    score = -residual.astype(np.float64)

    if _TIE_EPS > 0.0:
        # Update empirical item-size histogram (decayed counts).
        _hist *= _DECAY
        _total *= _DECAY
        if 1 <= item <= 100:
            _hist[item] += 1.0
            _total += 1.0
        fill = _hist / max(_total, 1e-9)  # density over sizes 1..100

        rc = np.clip(residual, 0, 100).astype(np.int64)
        f = fill[rc]
        is_near = np.abs(score - score.max()) <= _TIE_EPS
        score = score + _TIE_WEIGHT * f * is_near
    return score
# EVOLVE-BLOCK-END

