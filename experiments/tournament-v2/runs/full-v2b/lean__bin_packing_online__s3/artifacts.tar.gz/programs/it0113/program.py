# EVOLVE-BLOCK-START
"""Pure best fit with a mild preference for residuals that can still hold a
typical item.

Best fit (smallest residual >= item) is the strongest simple online rule for
this distribution. Earlier attempts that added waste surcharges or
fillability bonuses were consistently worse. We therefore return to best fit
as the primary criterion and only add a tiny, monotone tie-break that
slightly favours larger residuals (more room for future items) so that
spurious near-ties resolve toward the fuller-room bin.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item                      # >= 0 where the item fits
    residual = residual.astype(np.float64)
    # Primary: tightest fit (smallest residual).  Tiny monotone nudge so that
    # among equal residuals the bin with more remaining room after placement
    # is preferred, which trivially favours a less-wasted bin.
    score = -residual + 1e-6 * residual
    return score
# EVOLVE-BLOCK-END
