# EVOLVE-BLOCK-START
"""Best fit with an adaptive small-slack penalty.

Pure best-fit minimizes residual at placement time, but can leave a bin
with a tiny leftover that few future items can use.  We keep the
tight-fit ordering by residual as the base, and apply a mild penalty to
residuals in a "small slack" band whose upper end adapts to the item
sizes actually seen: any leftover below the smallest item observed so
far is (by the observation) unlikely to be usable, so we bias away from
stranding such slack.  Values start conservatively and tighten online.
"""
import numpy as np

_SURCHARGE = 4.0
_TIE_EPS = 1.5
_TIE_WEIGHT = 0.06
_MIN_SLACK_FLOOR = 1

_state = {"min_seen": 100}


def priority(item, bins):
    # Update the observed minimum item size (conservative slack limit).
    if item < _state["min_seen"]:
        _state["min_seen"] = item
    slack_limit = max(_MIN_SLACK_FLOOR, _state["min_seen"] - 1)

    residual = bins - item
    rf = residual.astype(np.float64)
    score = -rf                              # base: tightest fit wins

    # Penalise stranding small-but-possibly-unusable slack.
    waste = (residual > 0) & (residual <= slack_limit)
    score -= _SURCHARGE * waste

    if _TIE_EPS > 0.0:
        # Near-ties: prefer leaving slightly more room (less fragmentation
        # pressure) by nudging toward the larger residual among near-ties.
        max_score = score.max()
        is_near = np.abs(score - max_score) <= _TIE_EPS
        score = score + _TIE_WEIGHT * rf * is_near
    return score
# EVOLVE-BLOCK-END
