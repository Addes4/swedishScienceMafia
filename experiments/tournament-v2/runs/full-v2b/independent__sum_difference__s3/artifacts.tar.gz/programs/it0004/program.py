import math
import random
import time


def _diff_sum_counts(a):
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums)


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return -1e9, 0
    d, s = _diff_sum_counts(a)
    if s <= 0:
        return -1e9, 0
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100, len(a)


def _greedy_extend(base, rng, tries=60):
    """Try adding one element from a candidate pool that maximizes score."""
    a = list(base)
    d0, s0 = _diff_sum_counts(a)
    best_add = None
    best_ratio = 0
    pool = set()
    for x in a:
        for delta in (-1, 1, 2, -2, 3, -3):
            pool.add(x + delta)
    for _ in range(tries):
        cand = rng.randint(-200, 200)
        pool.add(cand)
    for c in pool:
        if c in a:
            continue
        b = a + [c]
        d1, s1 = _diff_sum_counts(b)
        if s1 == 0:
            continue
        # marginal gain criterion
        gain = math.log(d1) / math.log(s1)
        if gain > best_ratio:
            best_ratio = gain
            best_add = c
    if best_add is not None:
        a.append(best_add)
    return a


def _local_search(a, deadline, rng):
    score, _ = _score(a)
    best = list(a)
    best_score = score
    cur = list(a)
    cur_score = score

    while time.time() < deadline:
        cand = list(cur)
        op = rng.random()
        if op < 0.45 and cand:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-5, 5)
        elif op < 0.7:
            cand.append(rng.randint(-300, 300))
        elif op < 0.85 and len(cand) > 3:
            i = rng.randrange(len(cand))
            cand.pop(i)
        else:
            i = rng.randrange(len(cand))
            cand[i] += rng.choice([-1, 1]) * rng.randint(50, 400)

        if len(set(cand)) != len(cand):
            continue
        if len(cand) > 4000:
            continue
        if any(abs(x) > 10**15 for x in cand):
            continue

        s, _ = _score(cand)
        if s > cur_score or rng.random() < 0.02:
            cur = cand
            cur_score = s
        if s > best_score:
            best = list(cand)
            best_score = s
        if rng.random() < 0.05:
            cur = list(best)
            cur_score = best_score

    return best, best_score


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110

    # Structured candidate: geometric scaled clusters.
    # Small base set with good ratio, replicated at large scales.
    candidates = []

    # Hand-picked base sets reminiscent of difference-rich sets.
    bases = [
        [0, 1, 3, 7, 12, 20],
        [2, -3, 7, 15, 18, 22, -2],
        [0, 1, 4, 9, 15, 22, 34],
        [1, 2, 4, 8, 16, 32, 64, 128],
        [0, 3, 8, 15, 24, 35, 48, 63, 80],
        [5, -7, 13, -21, 34, -55, 89, -144, 233, -377],
    ]

    # Build multi-scale unions: A = U_i (B + c_i) with very different c_i.
    scale_sets = []
    for B in bases:
        for nscale in (2, 3, 4, 5, 6):
            A = []
            step = 1
            for k in range(nscale):
                off = rng.randint(-10**14, 10**14)
                for b in B:
                    A.append(b + off)
                step *= 8
            A = list(set(A))
            if len(A) <= 4000:
                scale_sets.append(A)

    for c in scale_sets:
        s, _ = _score(c)
        candidates.append((s, c))

    # Greedy extension on a promising small seed.
    seed = [0, 1, 3, 7, 12, 20]
    ext = list(seed)
    for _ in range(30):
        before = len(ext)
        ext = _greedy_extend(ext, rng, tries=40)
        if len(ext) == before:
            break
    s, _ = _score(ext)
    candidates.append((s, ext))

    # Local search over best few.
    candidates.sort(reverse=True, key=lambda t: t[0])
    best_A = candidates[0][1] if candidates else [0, 1, 3, 7]
    best_score = candidates[0][0] if candidates else -1e9

    per_restart = max(1.0, (deadline - time.time()) / 4)
    for idx in range(min(4, len(candidates))):
        start = candidates[idx][1]
        t_end = min(deadline, time.time() + per_restart)
        A, s = _local_search(start, t_end, rng)
        if s > best_score:
            best_score = s
            best_A = A
        if time.time() > deadline:
            break

    # Final cleanup: distinct, sorted, in range.
    result = sorted(set(int(x) for x in best_A))
    if not result:
        result = [0, 1, 3, 7]
    return result
