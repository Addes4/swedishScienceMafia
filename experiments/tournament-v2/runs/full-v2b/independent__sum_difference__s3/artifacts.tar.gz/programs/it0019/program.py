import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            if j >= i:
                sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)


def solve():
    deadline = time.time() + 110

    # Construction idea:
    # Use a set A = G U B where G = {2^0, 2^1, ..., 2^(k-1)} gives huge difference set
    # and B is a small specially-chosen set with few sums.
    # The 2-powers give 2k-1 distinct differences among themselves,
    # and combined with B produce many distinct differences.
    # Sums of 2-powers are mostly distinct, which hurts, so we also try scaled versions
    # and verify by local search.

    candidates = []

    # Candidate 1: powers of 2 plus a Sidon-ish base set with small sums.
    for k in [12, 14, 16, 18, 20, 22, 24]:
        base = [0]
        # small Sidon-like set for sums (relatively small sum set growth)
        b = [0, 1, 4, 10, 18, 27, 38, 50, 63, 77]
        g = [1 << i for i in range(k)]
        # scale b large enough to not collide much with powers of 2
        scale = (1 << k) * 3
        a = g + [scale + x for x in b]
        candidates.append(a)

    # Candidate 2: geometric-ish with large ratio mixed with small random sparse set
    random.seed(12345)
    for k in [15, 18, 20, 22]:
        g = [1 << i for i in range(k)]
        # add a small set with very few sums (arithmetic-like but shifted)
        b = [0, 1, 5, 12, 22, 35]
        scale = (1 << k) * 5
        a = g + [scale + x for x in b]
        candidates.append(a)

    # Local search on top of best candidate, but careful: time limit.
    best = None
    best_score = -1.0
    for c in candidates:
        c = sorted(set(c))
        s, _, _ = _score(c)
        if s > best_score:
            best_score = s
            best = c

    # Greedy/local improvement: try replacing elements of the small part
    # with nearby integers to reduce sums while keeping diffs high.
    cur = best[:]
    n = len(cur)
    # Identify the "base" part (non-powers-of-2)
    pows = set()
    for x in cur:
        if x > 0 and (x & (x - 1)) == 0:
            pows.add(x)
    small_part = [x for x in cur if x not in pows]
    big_part = [x for x in cur if x in pows]

    cur_score, _, _ = _score(cur)
    best_cur = cur[:]
    best_cur_score = cur_score

    while time.time() < deadline:
        cand = best_cur[:]
        # mutate one element in the small part if exists, else any
        if small_part and random.random() < 0.7:
            idx = random.randrange(len(cand))
            cand[idx] += random.randint(-2, 2)
        else:
            idx = random.randrange(len(cand))
            # try bit flip on a power element
            old = cand[idx]
            if old > 0 and (old & (old - 1)) == 0:
                cand[idx] = old * 2 if random.random() < 0.5 else max(1, old // 2)
            else:
                cand[idx] += random.randint(-5, 5)

        cand = sorted(set(cand))
        if len(cand) > 4000:
            cand = cand[:4000]
        s, _, _ = _score(cand)
        if s > best_cur_score:
            best_cur = cand
            best_cur_score = s
            # update small_part
            pows = set(x for x in cand if x > 0 and (x & (x - 1)) == 0)
            small_part = [x for x in cand if x not in pows]
        elif random.random() < 0.01:
            best_cur = cand

    final = sorted(set(best_cur))
    return final
