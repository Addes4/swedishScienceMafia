import math
import random
import time
from collections import Counter


def _score_parts(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 1
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            sums.add(ai + aj)
            diffs.add(ai - aj)
            diffs.add(aj - ai)
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0, len(diffs), len(sums)


def _score(a):
    return _score_parts(a)[0]


def _canonicalize(a):
    a = sorted(set(a))
    if not a:
        return a
    shift = -a[0]
    return [x + shift for x in a]


def _construct_modular(n):
    # Powers of 2 mod a prime create a strong Sidon-like structure, but we want
    # many sums to coincide, so use a carefully clipped interval union instead.
    # Base: dense interval plus geometric tail, then optimize.
    m = n
    vals = []
    # dense block creates few sums but many differences if shifted copies overlap cleverly
    block = max(1, int(math.sqrt(m) * 1.7))
    for i in range(min(m, block)):
        vals.append(i)
    step = 1
    x = block
    while len(vals) < m:
        x += step
        vals.append(x)
        if len(vals) % 5 == 0:
            step += 1
    return _canonicalize(vals[:m])


def _fast_delta_effect(a_set, x):
    # heuristic gain estimate, not exact score
    s = 0
    for y in a_set:
        s += (x - y) ^ (y - x)
    return s


def solve():
    deadline = time.time() + 112.0
    rng = random.Random(1234567)

    best = None
    best_score = -1.0

    # Try several structured starting points.
    starts = []
    for n in (60, 120, 200, 300, 500, 800, 1200, 2000, 3000, 3900):
        starts.append(_construct_modular(n))
    starts.append([7, 15, 18, 22, -3, -2])
    starts.append([0, 1, 3, 7, 12, 20, 30, 44, 65, 80, 96, 115, 138, 160, 185, 210])

    for st in starts:
        st = _canonicalize(st)
        sc, _, _ = _score_parts(st)
        if sc > best_score:
            best_score = sc
            best = st[:]

    # Simulated-annealing / hill-climb on either a dense small set or a padded large one.
    cur = best[:]
    cur_score = best_score
    start_time = time.time()
    it = 0
    while time.time() < deadline:
        it += 1
        n = len(cur)
        if n < 2:
            cur = _construct_modular(200)
            cur_score = _score(cur)
            continue
        cand = cur[:]

        mode = rng.random()
        if mode < 0.45:
            # mutate one element
            i = rng.randrange(n)
            span = max(1, abs(cand[i]) // 10 + 5)
            cand[i] += rng.randint(-span, span)
        elif mode < 0.70:
            # add a new element
            if n < 3990:
                base = rng.choice(cand)
                cand.append(base + rng.randint(-200, 200))
        elif mode < 0.90:
            # remove one
            if n > 5:
                del cand[rng.randrange(n)]
        else:
            # shift whole set or combine two elements
            if rng.random() < 0.5:
                sh = rng.randint(-50, 50)
                cand = [x + sh for x in cand]
            else:
                i, j = rng.randrange(n), rng.randrange(n)
                s = cand[i] + cand[j]
                cand[rng.randrange(n)] = s // 2

        cand = _canonicalize(cand)
        if len(cand) < 2:
            continue
        # limit evaluation cost
        if len(cand) > 2500:
            # evaluate approximate by subsampling pairs is dangerous; instead keep
            # large sets only if they came from a good structured start
            if rng.random() < 0.9:
                continue
        sc, _, _ = _score_parts(cand)
        temp = max(0.0001, 0.02 * (1.0 - (time.time() - start_time) / 112.0))
        if sc >= cur_score or rng.random() < math.exp((sc - cur_score) / max(temp, 1e-9)):
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand[:], sc
        elif rng.random() < 0.03:
            cur = best[:]
            cur_score = best_score

        if it % 500 == 0 and time.time() > deadline - 20:
            break

    # Final polish on the best set if small enough.
    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    best = _canonicalize(best)

    if len(best) <= 1200 and time.time() < deadline:
        local_cur = best[:]
        local_score = _score(local_cur)
        limit = time.time() + min(25.0, max(0.0, deadline - time.time()))
        while time.time() < limit:
            cand = local_cur[:]
            n = len(cand)
            if n < 2:
                break
            i = rng.randrange(n)
            cand[i] += rng.choice([-1, 1]) * rng.randint(1, max(2, abs(cand[i]) // 20 + 2))
            cand = _canonicalize(cand)
            sc = _score(cand)
            if sc >= local_score:
                local_cur, local_score = cand, sc
                if sc > best_score:
                    best, best_score = cand[:], sc
        best = local_cur

    return best


if __name__ == "__main__":
    res = solve()
    print(len(res))
    print(res[:50])
    sc, nd, ns = _score_parts(res)
    print("score", sc, "diffs", nd, "sums", ns)
