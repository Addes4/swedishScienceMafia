import math
import random
import time


def _dx(a):
    return {x - y for x in a for y in a}


def _sx(a):
    return {x + y for x in a for y in a}


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1.0
    d = len(_dx(a))
    s = len(_sx(a))
    if s <= 0:
        return -1.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _greedy_build(n, seed):
    rnd = random.Random(seed)
    a = [0]
    # build a set maximizing difference/n ratio while keeping sums contained.
    # Use a Sidon-ish prefix plus dense block.
    while len(a) < n:
        best_c = None
        best_v = -1
        # candidate pool
        cands = set()
        for x in a:
            for d in range(1, 80):
                cands.add(x + d)
                cands.add(x - d)
        cands = list(cands)
        rnd.shuffle(cands)
        for c in cands[:300]:
            if c in a:
                continue
            trial = a + [c]
            d = len(_dx(trial))
            s = len(_sx(trial))
            if s == 0:
                continue
            val = math.log(d) / math.log(s)
            if val > best_v:
                best_v = val
                best_c = c
        if best_c is None:
            a.append(rnd.randint(-1000, 1000))
        else:
            a.append(best_c)
    return a


def _improve(a, deadline, rnd):
    a = list(set(a))
    best = a[:]
    bs = _score(best)
    cur = a[:]
    cs = bs
    span = 200
    while time.time() < deadline:
        cand = cur[:]
        op = rnd.random()
        if op < 0.5:
            i = rnd.randrange(len(cand))
            cand[i] += rnd.randint(-span, span)
        elif op < 0.75:
            cand.append(cand[rnd.randrange(len(cand))] + rnd.randint(-span, span))
        elif op < 0.9 and len(cand) > 2:
            cand.pop(rnd.randrange(len(cand)))
        else:
            cand = list(set(cand))
            if len(cand) >= 2:
                i, j = rnd.sample(range(len(cand)), 2)
                cand[i], cand[j] = cand[j], cand[i]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc = _score(cand)
        if sc >= cs:
            cur, cs = cand, sc
            if sc > bs:
                best, bs = cand[:], sc
        elif rnd.random() < 0.02:
            cur, cs = cand, sc
        if rnd.random() < 0.01:
            cur, cs = best[:], bs
        span = max(2, int(span * 0.9995))
    return best, bs


def solve():
    deadline = time.time() + 110
    rnd = random.Random(12345)
    best = None
    bs = -1

    # Handcrafted seed: interval [0..k] has sums of size 2k+1 but differences size 2k+1,
    # ratio ~1. Combining a Sidon prefix with a block can push differences higher.
    seeds = []
    for n in [64, 128, 200, 256, 300, 400, 512]:
        # Golomb-like: use powers/bases to boost differences
        s = [i * i for i in range(n)]
        seeds.append(s)
        s2 = [i * (i + 1) // 2 for i in range(n)]
        seeds.append(s2)
        s3 = list(range(n))
        seeds.append(s3)
        # mixed
        s4 = [i * i for i in range(n // 2)] + [10**6 + i for i in range(n // 2)]
        seeds.append(s4)

    for s in seeds:
        sc = _score(s)
        if sc > bs:
            bs = sc
            best = list(set(s))
        if time.time() > deadline:
            break

    # Greedy build
    while time.time() < deadline:
        n = rnd.choice([100, 150, 200, 250, 300, 350, 400])
        a = _greedy_build(n, rnd.randint(0, 10**9))
        sc = _score(a)
        if sc > bs:
            bs = sc
            best = list(set(a))
        break

    # Local improvement rounds
    it = 0
    while time.time() < deadline:
        it += 1
        base = best[:] if (it % 3) else _greedy_build(rnd.choice([120, 180, 240]), rnd.randint(0, 10**9))
        # jitter
        jittered = []
        for x in base:
            jittered.append(x + rnd.randint(-3, 3))
        a, sc = _improve(jittered, min(deadline, time.time() + 8), rnd)
        if sc > bs:
            bs = sc
            best = a[:]

    return sorted(set(int(x) for x in best))
