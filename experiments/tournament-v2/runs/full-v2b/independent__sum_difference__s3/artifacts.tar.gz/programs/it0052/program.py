import math
import random
import time


def _score_tuple(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            s = ai + a[j]
            sums.add(s)
            diffs.add(ai - a[j])
            if i != j:
                diffs.add(a[j] - ai)
    if not sums:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _fast_score(a):
    n = len(a)
    if n < 2:
        return 0.0
    sums = set()
    diffs = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
            diffs.add(ai - a[j])
            if i != j:
                diffs.add(a[j] - ai)
    if not sums:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _construct(n, base):
    # Geometric-ish construction with perturbations to break additive structure
    A = []
    for i in range(n):
        v = base ** i
        # add a perturbation to make sums collide more (arithmetic-like component)
        v += i * (base ** (i // 3 + 1)) if i >= 3 else i
        A.append(v)
    return A


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    deadline = time.time() + 110.0

    best = None
    best_score = -1.0

    # Phase 1: scan candidate geometric constructions with small sizes and bases.
    candidates = []
    for n in range(4, 13):
        for base in [2, 3, 4, 5, 6, 7, 8, 10, 12, 16, 20, 24, 30, 40, 50, 64, 100]:
            try:
                A = _construct(n, base)
            except (OverflowError, MemoryError):
                continue
            if max(abs(x) for x in A) > 10**15:
                continue
            candidates.append(A)

    # Also include small dense examples that often score well.
    candidates.extend([
        [0, 1, 2, 4, 8],
        [0, 1, 3, 4, 9],
        [0, 1, 2, 4, 8, 16],
        [0, 1, 2, 3, 5, 8],
        [0, 1, 2, 3, 5, 7, 11],
        [0, 1, 2, 4, 5, 8, 10],
    ])

    for A in candidates:
        A = sorted(set(A))
        if len(A) < 2 or len(A) > 4000:
            continue
        if max(abs(x) for x in A) > 10**15:
            continue
        s = _fast_score(A)
        if s > best_score:
            best_score = s
            best = A[:]

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _fast_score(best)

    # Phase 2: local search on the best candidate found.
    rng = random.Random(12345)
    cur = best[:]
    cur_score = best_score

    while time.time() < deadline:
        n = len(cur)
        cand = cur[:]
        op = rng.random()

        if op < 0.55:
            # perturb one element
            i = rng.randrange(n)
            span = max(1, abs(cand[i]) // 5 + 3)
            cand[i] += rng.randint(-span, span)
        elif op < 0.75 and n < 60:
            # try adding an element near existing ones
            base = rng.choice(cand)
            cand.append(base + rng.randint(-20, 20))
        elif op < 0.90 and n > 3:
            # try removing one element
            i = rng.randrange(n)
            cand.pop(i)
        else:
            # shift whole set slightly (helps symmetry/translation tuning)
            d = rng.randint(-5, 5)
            cand = [x + d for x in cand]

        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        if max(abs(x) for x in cand) > 10**15:
            continue

        s = _fast_score(cand)
        if s >= cur_score or rng.random() < 0.02:
            cur = cand
            cur_score = s
        if s > best_score:
            best = cand[:]
            best_score = s

    return sorted(set(best))
