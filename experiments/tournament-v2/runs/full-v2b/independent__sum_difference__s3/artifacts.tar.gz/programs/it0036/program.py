import math
import random
import time


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = set()
    sums = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _score_fast(a):
    # approximate / same exact but optimized with dict for small n
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 110

    best = None
    best_score = -1.0

    # ---- Phase 1: try geometric progressions with various bases/sizes ----
    bases = [
        2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 16, 20, 25, 30, 40, 50,
        64, 100, 128, 256, 512, 1000, 1024, 2048, 4096, 10000, 100000,
    ]
    sizes = list(range(3, 30)) + [30, 40, 50, 60, 80, 100, 128, 150, 200]

    for base in bases:
        for n in sizes:
            if n > 4000:
                continue
            a = []
            v = 1
            ok = True
            for i in range(n):
                a.append(v)
                if abs(v) > 10**15:
                    ok = False
                    break
                v *= base
                if abs(v) > 10**15:
                    # append last within range then stop
                    pass
            if not ok and len(a) < 2:
                continue
            a = [x for x in a if abs(x) <= 10**15]
            if len(a) < 2:
                continue
            s = _score_fast(a)
            if s > best_score:
                best_score = s
                best = a[:]
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # ---- Phase 2: random local search starting from best geometric ----
    if best is None:
        best = [1, 2, 4, 8, 16, 32]
        best_score = _score_fast(best)

    cur = best[:]
    cur_score = best_score

    # Some hand-tuned candidate starter values
    extra_starts = [
        [0, 1, 2, 4, 8, 16, 32, 64, 128, 256],
        [1, 3, 9, 27, 81, 243, 729],
        [1, 2, 4, 8, 16, 32, 64, 128],
        [1, 10, 100, 1000, 10000, 100000],
        [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024],
    ]
    for st in extra_starts:
        s = _score_fast(st)
        if s > best_score:
            best_score = s
            best = st[:]

    cur = best[:]
    cur_score = best_score

    while time.time() < deadline:
        cand = cur[:]
        op = random.random()

        if op < 0.5 and len(cand) >= 2:
            # tweak a random element
            i = random.randrange(len(cand))
            delta = random.randint(-5, 5)
            if delta == 0:
                delta = 1
            cand[i] += delta
        elif op < 0.8:
            # add an element derived from existing ones (sums / differences)
            if len(cand) >= 2:
                i = random.randrange(len(cand))
                j = random.randrange(len(cand))
                if i != j:
                    v = cand[i] + cand[j]
                    if random.random() < 0.5:
                        v = cand[i] - cand[j]
                    if abs(v) <= 10**15:
                        cand.append(v)
        else:
            # replace/remove or scale shift
            if len(cand) > 3 and random.random() < 0.5:
                idx = random.randrange(len(cand))
                cand.pop(idx)
            else:
                shift = random.choice([-2, -1, 0, 1, 2])
                cand = [x + shift for x in cand]

        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        if any(abs(x) > 10**15 for x in cand):
            continue

        s = _score_fast(cand)
        if s > cur_score:
            cur = cand[:]
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
        elif random.random() < 0.05:
            cur = cand[:]
            cur_score = s

        # occasionally restart from best
        if random.random() < 0.01:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
