import math
import random
import time


def _score(A):
    A = list(set(A))
    n = len(A)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i, x in enumerate(A):
        for j, y in enumerate(A):
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _golomb_like(n, seed=0, time_budget=1.0):
    # Greedy construction of a set with many distinct differences.
    rng = random.Random(seed)
    A = [0, 1]
    used_diffs = {0, 1, -1}
    deadline = time.time() + time_budget
    while len(A) < n and time.time() < deadline:
        max_try = 200
        found = None
        for _ in range(max_try):
            cand = A[-1] + rng.randint(1, max(3, n * 4))
            ok = True
            new_diffs = []
            for a in A:
                d = cand - a
                if d in used_diffs or -d in used_diffs:
                    ok = False
                    break
                new_diffs.append(d)
                new_diffs.append(-d)
            if ok:
                found = (cand, new_diffs)
                break
        if found is None:
            break
        cand, new_diffs = found
        A.append(cand)
        for d in new_diffs:
            used_diffs.add(d)
    return A


def _refine(A, seconds):
    A = list(set(A))
    best = A[:]
    best_score = _score(best)
    cur = best[:]
    deadline = time.time() + seconds
    rng = random.Random(12345)
    while time.time() < deadline:
        cand = cur[:]
        if len(cand) < 3:
            cand.append(rng.randint(1, 100))
        else:
            op = rng.random()
            if op < 0.6:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-20, 20)
            elif op < 0.85:
                i = rng.randrange(len(cand))
                cand[i] = rng.randint(-max(cand)-50, max(cand)+50)
            else:
                cand.append(rng.randint(-max(abs(x) for x in cand)-100,
                                         max(abs(x) for x in cand)+100))
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif rng.random() < 0.05:
            cur = best[:]
    return best


def solve():
    deadline = time.time() + 100
    best = [0, 1]
    best_score = _score(best)

    # Try several Golomb-like constructions and refine them.
    for n in [30, 40, 50, 60, 70, 80, 90, 100, 120, 150, 200, 250, 300]:
        if time.time() > deadline - 20:
            break
        A = _golomb_like(n, seed=n, time_budget=1.0)
        if len(A) < 2:
            continue
        s = _score(A)
        if s > best_score:
            best, best_score = A[:], s
        # refine a bit
        A2 = _refine(A, seconds=min(2.0, deadline - time.time() - 5))
        if len(A2) >= 2:
            s2 = _score(A2)
            if s2 > best_score:
                best, best_score = A2[:], s2

    # Final local refinement.
    remaining = deadline - time.time()
    if remaining > 1:
        A = _refine(best, seconds=remaining)
        if len(A) >= 2 and _score(A) > best_score:
            best = A

    # Normalise and return.
    best = sorted(set(best))
    if not best:
        return [0, 1]
    # Ensure distinctness and bounds.
    best = [int(x) for x in best if abs(x) <= 10**15]
    best = sorted(set(best))
    while len(best) > 4000:
        best.pop()
    return best
