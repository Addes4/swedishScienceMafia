import math


def _add_cost(a, x):
    # Count how many new sums x+a_i collide with existing sums,
    # and estimate difference uniqueness.
    sums = set()
    for i in range(len(a)):
        for j in range(i, len(a)):
            sums.add(a[i] + a[j])
    new_sums = len(sums)
    for y in a:
        if x + y in sums:
            pass
        else:
            new_sums += 1
    if x + x not in sums:
        new_sums += 1
    # Penalize sum collisions strongly.
    total_pairs = len(a) + 1
    possible_new = total_pairs
    collisions = possible_new - (new_sums - len(sums))
    return collisions


def _score(a):
    if len(a) < 2:
        return 0.0
    s = set(a)
    diffs = {x - y for x in s for y in s}
    sums = {x + y for x in s for y in s}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(s)) / 100


def solve():
    # Greedy Sidon-like construction.
    # Start from a few seeds then repeatedly add the integer minimizing
    # collisions in the sum set over a candidate window.
    best = None
    best_score = -1.0

    seeds = [
        [0],
        [0, 1],
        [0, 1, 4],
        [0, 1, 3],
        [1, 2, 5, 10],
    ]

    target_size = 60
    for seed in seeds:
        a = list(seed)
        while len(a) < target_size:
            lo = min(a) - 5 * len(a)
            hi = max(a) + 5 * len(a)
            best_x = None
            best_c = None
            # Sample candidate range with step to limit cost.
            step = max(1, (hi - lo) // 400)
            for x in range(lo, hi + 1, step):
                if x in a:
                    continue
                c = _add_cost(a, x)
                if best_c is None or c < best_c:
                    best_c = c
                    best_x = x
            if best_x is None:
                break
            a.append(best_x)
        sc = _score(a)
        if sc > best_score:
            best_score = sc
            best = a[:]

    # Local improvement: try swapping/removing elements.
    if best is not None:
        improved = True
        iters = 0
        a = best[:]
        cur_score = _score(a)
        while improved and iters < 5:
            improved = False
            iters += 1
            n = len(a)
            for i in range(n):
                orig = a[i]
                # Try moving a[i] to nearby values to improve score.
                for delta in (-3, -2, -1, 1, 2, 3):
                    a[i] = orig + delta
                    if len(set(a)) < len(a):
                        a[i] = orig
                        continue
                    s = _score(a)
                    if s > cur_score:
                        cur_score = s
                        improved = True
                        break
                    a[i] = orig
                if improved:
                    break

        best = a
        best_score = cur_score

    return sorted(set(best))
