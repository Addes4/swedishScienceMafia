import math
import random
import time

# ---------- efficient scoring ----------

def _score_stats(arr):
    """Return (len(diff_set), len(sum_set), n) for sorted list arr."""
    n = len(arr)
    if n < 2:
        return 0, 0, n
    # differences: all a_i - a_j, i != j plus 0
    diffs = set()
    for i in range(n):
        ai = arr[i]
        for j in range(n):
            if i != j:
                diffs.add(ai - arr[j])
    diffs.add(0)
    sums = set()
    for i in range(n):
        ai = arr[i]
        for j in range(n):
            sums.add(ai + arr[j])
    return len(diffs), len(sums), n


def _score(diffs, sums, n):
    if sums <= 1:
        return 0.0
    return math.log(diffs) / math.log(sums) + (1.0 - 1.0 / n) / 100.0


# ---------- construction ----------

def _geometric_like(k, base=2.0):
    """Create a set of roughly k integers with large difference set and small sum set.
    Use a Sidon-like / near-geometric structure.  We take a base and powers,
    then perturb to keep sums moderately collapsed."""
    vals = set()
    # powers of 2 give many differences but also many sums.
    # use a mixed radix construction: a_i = sum_{j<=i} c_j with rapidly growing c.
    # This is like a convex set: differences are all distinct => |A-A| ~ n^2,
    # but sums are also many.  We want small sum set, so use a geometric progression.
    x = 1
    for i in range(k):
        vals.add(x)
        x = x * 2 + random.randint(0, 1)
    return sorted(vals)


def _base_sets():
    """Return a few promising starting configurations."""
    sets = []
    # classic small set from baseline
    sets.append([7, 15, 18, 22, -3, -2])
    # geometric progression
    for b in (2, 3):
        arr = []
        x = 1
        for i in range(10):
            arr.append(x)
            x = x * b + 1
        sets.append(arr)
    # powers of 2 shifted
    sets.append([2 ** i for i in range(12)])
    # near-powers with additive offsets
    arr = []
    x = 1
    for i in range(14):
        arr.append(x)
        x = x * 2 + (i % 3)
    sets.append(arr)
    return [sorted(set(s)) for s in sets]


# ---------- local search ----------

def _try_improve(arr, deadline):
    """Fast stochastic local search on list arr (sorted)."""
    arr = sorted(set(arr))
    n = len(arr)
    if n < 2:
        return arr, 0.0

    best_d, best_s, _ = _score_stats(arr)
    best_sc = _score(best_d, best_s, n)
    best_arr = arr[:]

    cur = arr[:]
    cur_d, cur_s, _ = best_d, best_s, n
    cur_sc = best_sc

    # precompute for speed: we will do O(n^2) moves but check only changed pairs.
    # For simplicity and given n <= ~50, full recomputation is fine but we cache.

    while time.time() < deadline:
        op = random.random()
        cand = cur[:]
        if op < 0.55:
            # shift one element
            i = random.randrange(len(cand))
            delta = random.randint(-5, 5)
            if delta == 0:
                continue
            cand[i] += delta
        elif op < 0.8:
            # add an element near existing ones
            if len(cand) >= 4000:
                continue
            base = random.choice(cand)
            cand.append(base + random.randint(-3, 3) + random.choice([-1, 1]) * random.randint(1, 10))
        else:
            # remove an element
            if len(cand) <= 2:
                continue
            i = random.randrange(len(cand))
            cand.pop(i)

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        d, s, nn = _score_stats(cand)
        sc = _score(d, s, nn)
        if sc > cur_sc:
            cur, cur_d, cur_s, cur_sc = cand, d, s, sc
            if sc > best_sc:
                best_arr, best_sc = cand[:], sc
        elif random.random() < 0.05:
            cur, cur_d, cur_s, cur_sc = cand, d, s, sc

    return best_arr, best_sc


# ---------- main solve ----------

def solve():
    deadline = time.time() + 110.0
    best = None
    best_score = -1.0

    starters = _base_sets()

    # Try each starter briefly
    t_end = min(deadline, time.time() + 20.0)
    for s in starters:
        if time.time() > t_end:
            break
        arr, sc = _try_improve(s, min(deadline, time.time() + 3.0))
        if sc > best_score:
            best, best_score = arr, sc

    # Long search from best
    if best is not None:
        arr, sc = _try_improve(best, deadline)
        if sc > best_score:
            best, best_score = arr, sc

    # final fallback
    if best is None:
        best = [7, 15, 18, 22, -3, -2]

    return sorted(set(best))
