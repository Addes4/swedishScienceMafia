import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _score_fast(a):
    # fast exact score for moderate n
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return -1.0
    diffs = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _greedy_golomb(n, limit=None):
    # Greedy Sidon/Golomb-like set on nonnegative ints
    # A Sidon set has A+A mostly distinct, which is opposite; here we want small sums.
    # Instead build a dense-ish set with structured sums.
    return None


def _make_ap_with_holes(n, span):
    # Arithmetic progression has |A+A| = 2n-1 and |A-A| = 2n-1, ratio 1.
    # We need A-A large: introduce multiplicities via multiple residue classes.
    pass


def _build_candidate(k, mode, rng):
    # Build set of size about k with structure
    if mode == 0:
        # union of two APs with different gaps -> sums collide, diffs mostly distinct
        g1 = 1
        g2 = 2
        half = k // 2
        A = set()
        for i in range(half):
            A.add(i * g1)
        for i in range(k - half):
            A.add(i * g2 + 3)
        return sorted(A)
    if mode == 1:
        # AP plus a few shifted copies (dilation-ish)
        base = [i for i in range(k)]
        return base
    if mode == 2:
        # random subset of interval then dense
        span = max(k, int(k * 1.2))
        return sorted(rng.sample(range(span), min(k, span)))
    if mode == 3:
        # union of several APs with same span different offsets
        parts = rng.randint(2, 5)
        A = set()
        per = max(1, k // parts)
        for p in range(parts):
            step = rng.choice([1, 1, 1, 2, 2, 3])
            off = rng.randint(-5, 5) * p
            for i in range(per):
                A.add(off + i * step)
        return sorted(A)
    if mode == 4:
        # base interval with some removed/added near edges to reduce sums
        span = int(k * 1.1) + 2
        A = set(range(span))
        while len(A) > k:
            A.remove(rng.choice(list(A)))
        return sorted(A)
    if mode == 5:
        # concatenation of two intervals
        a = k // 2
        b = k - a
        s1 = [i for i in range(a)]
        s2 = [1000 + 2 * i for i in range(b)]
        return sorted(set(s1 + s2))
    if mode == 6:
        # interval with a smaller interval offset far
        main = [i for i in range(k)]
        return main
    return sorted(rng.sample(range(k * 2), k))


def _local_search(A, time_budget, rng):
    A = sorted(set(A))
    if len(A) < 2:
        return A
    best = A[:]
    best_s = _score_fast(best)
    cur = A[:]
    cur_s = best_s
    start = time.time()
    # neighborhood: modify one element by small amount or add/remove element keeping size
    while time.time() - start < time_budget:
        cand = cur[:]
        op = rng.random()
        if op < 0.60 and len(cand) >= 2:
            i = rng.randrange(len(cand))
            delta = rng.choice([-3, -2, -1, 1, 2, 3])
            cand[i] += delta
        elif op < 0.80:
            # add
            if len(cand) < 4000:
                cand.append(rng.randint(min(cand) - 5, max(cand) + 5))
        else:
            # remove then add to keep size similar
            if len(cand) > 2:
                cand.pop(rng.randrange(len(cand)))
            if len(cand) < 4000:
                cand.append(rng.randint(min(cand) - 5, max(cand) + 5))
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        # cap n for speed
        if len(cand) > 120:
            # still evaluate but could be slow; use subsample? no, must be exact
            pass
        s = _score_fast(cand)
        if s > cur_s or (s == cur_s and len(cand) > len(cur)):
            cur, cur_s = cand, s
            if s > best_s or (s == best_s and len(cand) > len(best)):
                best, best_s = cand[:], s
                cur = best[:]
                cur_s = best_s
        elif rng.random() < 0.05:
            cur, cur_s = best[:], best_s
    return best


def _hill_climb_small(A, time_budget, rng):
    # fine local search for small sets
    A = sorted(set(A))
    best = A[:]
    best_s = _score_fast(best)
    start = time.time()
    while time.time() - start < time_budget:
        cand = best[:]
        i = rng.randrange(len(cand))
        cand[i] += rng.choice([-2, -1, 1, 2])
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score_fast(cand)
        if s > best_s:
            best, best_s = cand, s
    return best


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 115

    best = None
    best_s = -1.0

    # Try many structured initial candidates of varying sizes
    sizes = [8, 10, 12, 16, 20, 24, 30, 40, 50, 64, 80, 100, 128, 160, 200, 256]
    modes = [0, 2, 3, 4, 5]

    # First, evaluate structured candidates
    init_pool = []
    for k in sizes:
        for mode in modes:
            try:
                A = _build_candidate(k, mode, rng)
            except Exception:
                continue
            A = sorted(set(A))
            if len(A) < 2:
                continue
            init_pool.append(A)

    # Also some fine candidates from a known good small structure
    # The standard example: {0,1,3,7,12,...} type sets.
    # Try random small sets.
    for _ in range(200):
        k = rng.randint(5, 30)
        A = sorted(rng.sample(range(-k * 3, k * 3 + 1), k))
        init_pool.append(A)

    # Evaluate pool
    for A in init_pool:
        if time.time() > deadline - 60:
            break
        s = _score_fast(A)
        if s > best_s:
            best, best_s = A[:], s

    if best is None:
        best = [0, 1, 3, 7, 12, 20]
        best_s = _score_fast(best)

    # Local search on the best small/medium candidates
    # For n <= ~60 exact scoring is fine.
    refined = []
    for A in init_pool:
        if len(A) <= 60:
            improved = _hill_climb_small(A, 0.05, rng)
            refined.append(improved)
        if time.time() > deadline - 40:
            break

    for A in refined:
        s = _score_fast(A)
        if s > best_s:
            best, best_s = A[:], s

    # Main local search on best
    remaining = deadline - time.time()
    if remaining > 1 and len(best) <= 60:
        cand = _local_search(best, max(0, remaining - 1), rng)
        s = _score_fast(cand)
        if s > best_s:
            best, best_s = cand, s

    # Try specifically to improve ratio by searching around sizes where
    # |A+A| can be kept small: union of intervals with structured offsets.
    # Additional heuristic: sets that are arithmetic progression with
    # several "layers" sharing sums.
    remaining = deadline - time.time()
    if remaining > 5:
        # construct sets as union of scaled copies
        for trial in range(500):
            if time.time() > deadline - 3:
                break
            k = rng.randint(6, 80)
            A = set()
            layers = rng.randint(2, 4)
            per = max(1, k // layers)
            span = per
            for L in range(layers):
                step = 1
                offset = rng.randint(-span, span) * L
                for i in range(per):
                    A.add(offset + i * step)
            A = sorted(A)
            if len(A) < 2:
                continue
            if len(A) <= 80:
                s = _score_fast(A)
                if s > best_s:
                    best, best_s = A[:], s
            else:
                # use subsampled score estimate
                pass

    # Refine the final best with a focused anneal
    remaining = deadline - time.time()
    if remaining > 1:
        A = best[:]
        s = best_s
        t_end = time.time() + remaining
        while time.time() < t_end:
            cand = A[:]
            op = rng.random()
            if op < 0.7 and len(cand) >= 2:
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-2, -1, 1, 2])
            elif op < 0.85 and len(cand) < 80:
                cand.append(rng.randint(min(cand) - 3, max(cand) + 3))
            elif len(cand) > 2:
                cand.pop(rng.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cs = _score_fast(cand)
            if cs > s:
                A, s = cand, cs
                if cs > best_s:
                    best, best_s = cand[:], cs

    return sorted(set(int(x) for x in best))
