import math
import random
import time


def _score_parts(a):
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls <= 1:
        return 0.0, ld, ls
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100, ld, ls


def _score(a):
    return _score_parts(a)[0]


def _dedup_sorted(a):
    return sorted(set(a))


# --- Structured constructions -------------------------------------------------

def build_ap(n, d=1, start=0):
    return [start + i * d for i in range(n)]


def build_geometric(n, base=2, start=1):
    a = []
    v = start
    for _ in range(n):
        a.append(v)
        v *= base
    return a


def build_two_scales(n):
    # half AP, half geometric-ish, scaled to be comparable magnitude
    k = n // 2
    a = [i for i in range(k)]
    v = 1
    for _ in range(n - k):
        a.append(v)
        v = v * 3 + 1
    return a


def build_freiman_like(n):
    # A = X with X having small doubling, plus a nearly-independent tail
    # Use a block: {0..k-1} * m  union  small filler
    a = set()
    k = max(2, n // 2)
    m = k + 1
    for i in range(k):
        a.add(i * m)
    # fill remaining with points that add few new sums
    rem = n - len(a)
    i = 0
    while rem > 0 and i < k:
        a.add(i * m + 1)
        rem -= 1
        i += 1
    return sorted(a)


def build_sidon_style(n, span_mult=6):
    # Greedy Sidon-like set: maximize distinct differences, small span.
    span = n * span_mult
    a = []
    used_diffs = set()
    # start with powers of 2 for guaranteed structure
    cands = list(range(0, span + 1))
    random.shuffle(cands)
    for c in cands:
        if len(a) >= n:
            break
        new_diffs = set()
        ok = True
        for x in a:
            for d in (c - x, x - c):
                if d in used_diffs or d in new_diffs:
                    ok = False
                    break
                new_diffs.add(d)
            if not ok:
                break
        if ok:
            a.append(c)
            used_diffs |= new_diffs
        # also add self-diff
        used_diffs.add(0)
    return sorted(a)


def build_progression_blocks(n, blocks=4):
    # union of translated blocks of APs sharing the same difference set
    a = set()
    base = max(1, n // blocks)
    step = 1
    pos = 0
    for b in range(blocks):
        for i in range(base):
            if len(a) >= n:
                return sorted(a)
            a.add(pos + i * step)
        pos += base * step + 1
    return sorted(a)


def build_python_known(n):
    # Hybrid: small AP around 0 plus scaled copy; keeps sums bounded while diffs manifold
    k = max(2, n // 2)
    a = set()
    for i in range(k):
        a.add(i)
    m = k + 2
    for i in range(n - k):
        a.add(i * m + m // 2)
    return sorted(a)


CONSTRUCTIONS = [
    lambda n: build_ap(n),
    lambda n: build_geometric(n, 2),
    lambda n: build_geometric(n, 3),
    lambda n: build_two_scales(n),
    lambda n: build_freiman_like(n),
    lambda n: build_progression_blocks(n),
    lambda n: build_python_known(n),
    lambda n: build_sidon_style(n, 4),
    lambda n: build_sidon_style(n, 8),
]


# --- Local search -------------------------------------------------------------

def local_search(start, deadline, rng):
    a = sorted(set(start))
    best = a[:]
    best_score = _score(best)
    cur = a[:]
    cur_score = best_score
    it = 0
    while time.time() < deadline:
        it += 1
        mode = rng.random()
        cand = cur[:]
        if mode < 0.55:
            # perturb an element
            i = rng.randrange(len(cand))
            delta = rng.choice([-3, -2, -1, 1, 2, 3, -5, 5])
            cand[i] += delta
        elif mode < 0.75:
            # shift element by a random small-to-medium amount
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-20, 20)
        elif mode < 0.88:
            # add a new element near an existing one
            if len(cand) < 4000:
                i = rng.randrange(len(cand))
                cand.append(cand[i] + rng.randint(-15, 15))
        else:
            # remove an element
            if len(cand) > 2:
                del cand[rng.randrange(len(cand))]
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= cur_score or rng.random() < 0.02:
            cur = cand
            cur_score = s
        if s > best_score:
            best = cand[:]
            best_score = s
        if it % 400 == 0 and cur_score < best_score * 0.999:
            cur = best[:]
            cur_score = best_score
    return best, best_score


def grow_best(base, deadline, rng):
    """Try to grow the set while improving the score."""
    best = sorted(set(base))
    best_score = _score(best)
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        # add a candidate element: try sums/differences of existing elements offset
        if rng.random() < 0.7 and len(cand) < 4000:
            i = rng.randrange(len(cand))
            j = rng.randrange(len(cand))
            v = cand[i] - cand[j]
            if rng.random() < 0.5:
                v = cand[i] + cand[j]
            cand.append(v + rng.randint(-2, 2))
        else:
            if len(cur) > 3:
                cand = cur[:-1]
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= cur_score:
            cur = cand
            cur_score = s
        if s > best_score:
            best = cand[:]
            best_score = s
    return best, best_score


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # phase 1: evaluate constructions
    for n in (6, 8, 10, 14, 20, 30, 50, 80, 120):
        for ctor in CONSTRUCTIONS:
            try:
                a = _dedup_sorted(ctor(n))
            except Exception:
                continue
            if len(a) < 2:
                continue
            s = _score(a)
            if s > best_score:
                best_score = s
                best = a[:]
        if time.time() > deadline:
            break

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    # phase 2: local search from the best construction and a few others
    seeds = [best[:]]
    # add a couple of diverse seeds
    for ctor in CONSTRUCTIONS[:5]:
        try:
            a = _dedup_sorted(ctor(10))
            if len(a) >= 2:
                seeds.append(a)
        except Exception:
            pass

    t_end_ls = time.time() + (deadline - time.time()) * 0.6
    for seed in seeds:
        if time.time() > t_end_ls:
            break
        a, s = local_search(seed, t_end_ls, rng)
        if s > best_score:
            best, best_score = a[:], s

    # phase 3: growth attempts
    t_end_g = time.time() + (deadline - time.time()) * 0.5
    for _ in range(4):
        if time.time() > t_end_g:
            break
        a, s = grow_best(best, t_end_g, rng)
        if s > best_score:
            best, best_score = a[:], s

    # phase 4: final local polish
    a, s = local_search(best, deadline, rng)
    if s > best_score:
        best, best_score = a[:], s

    # clamp to bounds
    best = [int(x) for x in sorted(set(best))]
    LIM = 10**15
    best = [max(-LIM, min(LIM, x)) for x in best]
    # ensure distinctness after clamp
    seen = set()
    out = []
    for x in best:
        if x not in seen:
            seen.add(x)
            out.append(x)
    if len(out) < 2:
        out = [-1, 1]
    if len(out) > 4000:
        out = out[:4000]
    return out
