import math
import random
import time

def _diffs_sums(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0, 0
    ds = set()
    ss = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            ds.add(ai - aj)
            ss.add(ai + aj)
    return len(ds), len(ss)

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _diffs_sums(a)
    if ns <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100

def _greedy_extend(base, max_check_vals, time_limit):
    """Greedy: try adding integers from candidate pool, keep if score improves."""
    cur = list(set(base))
    cur_score = _score(cur)
    deadline = time.time() + time_limit
    improved = True
    while improved and time.time() < deadline:
        improved = False
        # candidate values around the current elements
        lo = min(cur)
        hi = max(cur)
        span = hi - lo
        cands = set()
        for c in cur:
            for d in range(-3, 4):
                cands.add(c + d)
        # also some random larger values
        for _ in range(50):
            cands.add(random.randint(lo - span, hi + span))
        cands -= set(cur)
        # evaluate each candidate addition
        best_add = None
        best_add_score = cur_score
        for v in cands:
            if time.time() > deadline:
                break
            trial = cur + [v]
            s = _score(trial)
            if s > best_add_score:
                best_add_score = s
                best_add = v
        if best_add is not None:
            cur.append(best_add)
            cur_score = best_add_score
            improved = True
    return cur, cur_score

def _optimize_once(base, time_limit):
    """Local search: perturb elements, accept improvements."""
    cur = list(set(base))
    cur_score = _score(cur)
    deadline = time.time() + time_limit
    best = cur[:]
    best_score = cur_score
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        # random modification
        r = random.random()
        if r < 0.5 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-3,-2,-1,1,2,3])
        elif r < 0.75:
            lo = min(cand); hi = max(cand)
            span = max(1, hi - lo)
            cand.append(random.randint(lo - span, hi + span))
        elif len(cand) > 3:
            i = random.randrange(len(cand))
            del cand[i]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= cur_score or random.random() < 0.02:
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
    return best, best_score

def _try_ap(n, start, step, extras=0, extra_amp=1):
    a = [start + i * step for i in range(n)]
    for _ in range(extras):
        a.append(start + random.randint(0, n * step) + random.randint(-extra_amp, extra_amp))
    return a

def solve():
    end = time.time() + 100
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Try several structured families quickly
    candidates = []
    # Pure arithmetic progressions of various lengths
    for n in range(2, 31):
        candidates.append(list(range(n)))
        candidates.append([i*2 for i in range(n)])
        candidates.append([i*3 for i in range(n)])
    # AP with one extra element
    for n in range(3, 25):
        base = list(range(n))
        for v in range(-n, 2*n):
            if v not in base:
                candidates.append(base + [v])
    # Random small sets
    for _ in range(200):
        n = random.randint(3, 15)
        candidates.append([random.randint(-20, 20) for _ in range(n)])
    # Baseline-like
    candidates.append([7, 15, 18, 22, -3, -2])

    for c in candidates:
        if time.time() > end - 60:
            break
        c = list(set(c))
        if len(c) < 2:
            continue
        s = _score(c)
        if s > best_score:
            best = c[:]
            best_score = s

    # Greedy extension from the best found so far (and a few starts)
    starts = [best]
    # add some AP starts
    for n in [5, 8, 12, 16, 20]:
        starts.append(list(range(n)))
    # add random small starts
    for _ in range(5):
        starts.append([random.randint(-10, 10) for _ in range(random.randint(3, 8))])

    for st in starts:
        if time.time() > end - 40:
            break
        cur, cur_s = _greedy_extend(st, None, min(10, end - time.time()))
        if cur_s > best_score:
            best = cur[:]
            best_score = cur_s

    # Local search / optimization from the best
    remaining = end - time.time()
    if remaining > 0:
        cur, cur_s = _optimize_once(best, remaining)
        if cur_s > best_score:
            best = cur[:]
            best_score = cur_s
    # More optimization rounds if time
    while time.time() < end - 5:
        cur, cur_s = _optimize_once(best, min(15, end - time.time()))
        if cur_s > best_score:
            best = cur[:]
            best_score = cur_s

    best = list(set(best))
    best.sort()
    return best
