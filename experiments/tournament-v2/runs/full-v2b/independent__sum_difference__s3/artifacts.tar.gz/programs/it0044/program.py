import math
import random
import time

def _score_components(A):
    A = list(set(A))
    n = len(A)
    if n < 2:
        return 0, 0, 0.0
    diffs = set()
    for x in A:
        for y in A:
            diffs.add(x - y)
    sums = set()
    for x in A:
        for y in A:
            sums.add(x + y)
    ld = len(diffs)
    ls = len(sums)
    if ls < 2 or ld < 2:
        return ld, ls, 0.0
    return ld, ls, math.log(ld) / math.log(ls)


def _score(A):
    ld, ls, r = _score_components(A)
    n = len(set(A))
    if n < 2:
        return 0.0
    return r + (1 - 1 / n) / 100


def _make_sidon_scaled(n, M):
    # Simple Sidon-like set: greedy construction in [0, R)
    # Use quadratic residues style set: {2*i*M + (i*i) mod (M*K)} but tune.
    # Simpler: pick B_h set via greedy over a bounded range, then scale.
    # We'll build a Sidon set modulo a prime-ish range using greedy.
    R = max(4 * n * n, 100)
    s = [0]
    used_diffs = {0}
    x = 0
    while len(s) < n:
        x += 1
        if x > 50 * n * n:
            break
        ok = True
        new_diffs = set()
        for y in s:
            d = x - y
            if d in used_diffs or -d in used_diffs and False:
                pass
        # check
        for y in s:
            if (x - y) in used_diffs:
                ok = False
                break
            new_diffs.add(x - y)
            new_diffs.add(y - x)
        if ok:
            for d in new_diffs:
                used_diffs.add(d)
            s.append(x)
    return s


def _random_seed_set(n, span):
    vals = random.sample(range(0, span), min(n, span))
    return vals


def solve():
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    n_limit = 4000

    # Phase 1: try structured constructions that make sums sparse and diffs dense.
    # Idea: A = {i*M + b_i} where b_i small. Sums collapse many collisions if
    # b_i chosen from a structured Sidon-like set; diffs stay large.
    candidates = []

    # candidate family: geometric-ish with random
    for _ in range(200):
        n = random.randint(50, 400)
        M = random.choice([1, 2, 3, 5, 10, 100, 1000, 10**6])
        base = sorted(random.sample(range(-n * 3, n * 3), n))
        A = [base[i] * M + random.randint(-2, 2) for i in range(n)]
        candidates.append(A)

    # arithmetic progression scaled (diffs = multiples, sums = multiples -> ratio near 1 if perfect)
    # instead block construction: A = intervals to collapse sums
    # Mixed: take a Sidon set, scale, then add small perturbation
    for _ in range(200):
        n = random.randint(30, 300)
        sid = _make_sidon_scaled(n, 1)
        M = random.choice([1, 2, 5, 10, 100, 1000])
        A = [x * M for x in sid]
        candidates.append(A)

    for A in candidates:
        if time.time() > deadline:
            break
        s = _score(A)
        if s > best_score:
            best, best_score = A[:], s

    # Phase 2: local search / random restarts on small sets with big coordinate freedom.
    cur = best[:]
    cur_score = best_score
    since_improve = 0
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.4 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5) if random.random() < 0.7 else random.randint(-1000, 1000)
        elif r < 0.6:
            cand.append(random.randint(-100, 100))
        elif r < 0.75 and len(cand) > 3:
            i = random.randrange(len(cand))
            del cand[i]
        elif r < 0.9:
            # add near-duplicate structure to reduce sums
            k = random.randrange(len(cand))
            base = cand[k]
            cand.append(base + random.randint(-3, 3))
        else:
            # scale-shift whole set
            sh = random.randint(-50, 50)
            sc = random.choice([1, 1, 1, 2])
            cand = [x * sc + sh for x in cand]

        cand = list(set(cand))
        if len(cand) < 2:
            cur = best[:]
            continue
        s = _score(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            since_improve = 0
            if s > best_score:
                best, best_score = cand[:], s
        else:
            since_improve += 1
            if since_improve > 200:
                # restart
                if random.random() < 0.5:
                    cur = best[:]
                else:
                    n = random.randint(10, 60)
                    cur = sorted(set(random.randint(-200, 200) for _ in range(n)))
                cur_score = _score(cur)
                since_improve = 0

    return sorted(set(best))
