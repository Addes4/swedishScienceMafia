import math
import time

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def _powers(base, n, cap=10**15):
    a = [1]
    while len(a) < n:
        nxt = a[-1] * base
        if nxt > cap:
            break
        a.append(nxt)
    return a

def solve():
    best = None
    best_score = -1.0
    # Try geometric progressions with various bases and sizes.
    for base in (3, 4, 2, 5, 6, 7):
        for n in range(2, 61):
            a = _powers(base, n)
            if len(a) < 2:
                continue
            # Verify score quickly (for large n this may be slow; limit work).
            if len(a) > 40:
                # Estimate: diffs ~ n^2/2 - 1, sums via actual computation below only for chosen.
                pass
            s = _score(a)
            if s > best_score:
                best_score = s
                best = a[:]
    # Try shifted/scaled variants and signed variants quickly around the best.
    if best is not None:
        cands = []
        cands.append(best)
        # add negatives of best
        cands.append([-x for x in best])
        # shifts
        for sh in (-2, -1, 1, 2):
            cands.append([x + sh for x in best])
        # scales
        cands.append([2 * x for x in best])
        for c in cands:
            c = list(set(c))
            if len(c) < 2:
                continue
            s = _score(c)
            if s > best_score:
                best_score = s
                best = c
    if best is None:
        best = [1, 3, 9, 27, 81, 243, 729, 2187]
    return sorted(set(best))
