import math
import random
import time


def _score_parts(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    ld = len(diffs)
    ls = len(sums)
    if ls < 2 or ld < 1:
        return 0.0, ld, ls
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100, ld, ls


def _score(a):
    return _score_parts(a)[0]


def _make_initial():
    # A dense sum-poor core: an arithmetic-like block with gaps.
    # Use a set whose pairwise sums collide a lot (interval) but differences spread.
    core = list(range(0, 40))
    # dilate parts to spread differences while keeping sums clustered
    A = []
    for x in core:
        A.append(x)
    # add a shifted/scaled copy to grow differences without growing sums too much
    base = list(range(0, 25))
    A2 = [1000 + 2 * x for x in base]  # sums fall in narrow band per copy
    return list(set(A + A2))


def _smart_candidates():
    # Powerset-ish sum-poor constructions.
    # 1) interval: sums have 2*range values, diffs have 2*range values -> ratio ~1
    # 2) To make ratio > 1, need |diffs| > |sums|.
    # A = {i * M + f(i)} can give more distinct diffs than sums.
    cands = []
    # Sidon-ish via greedy for differences, but keep range small for sums
    cands.append(list(range(1, 60)))
    cands.append([i * i for i in range(1, 20)])
    cands.append([i * i * i for i in range(1, 15)])
    return cands


def solve():
    deadline = time.time() + 110.0

    best = None
    best_score = -1.0

    # try structured candidates
    for c in _smart_candidates():
        s = _score(c)
        if s > best_score:
            best_score = s
            best = c[:]

    # Greedy construction: build set where differences are mostly unique
    # and sums collide. Use a "Sidon set plus dense tail".
    # Start from a dense interval (many sum collisions) of even numbers:
    # even numbers: sums are even, differences even -> both halved but structure differs.
    for M in [1, 2, 3, 4, 5]:
        A = [M * i for i in range(1, 81)]
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A[:]

    # Try quadratic spacing with small leading values mixed in for sum collisions.
    for k in range(1, 6):
        A = list(range(0, 10)) + [10 + k * i * i for i in range(1, 30)]
        A = sorted(set(A))
        if len(A) > 4000:
            A = A[:4000]
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A[:]

    # Local search / simulated annealing on a working set.
    def build_start():
        if best is not None:
            return best[:]
        return list(range(1, 50))

    cur = build_start()
    cur_score = _score(cur)
    best_local = cur[:]
    best_local_score = cur_score

    # Precompute nothing; just use set-based score inside loop but it's O(n^2).
    # Keep n moderate during search.
    while len(cur) > 200:
        cur.pop(random.randrange(len(cur)))
    cur_score = _score(cur)

    step = 3
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        r = random.random()
        if r < 0.45:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-step, step)
        elif r < 0.80:
            cand.append(random.randint(-500, 500))
        elif r < 0.92 and len(cand) > 3:
            del cand[random.randrange(len(cand))]
        else:
            # shift a whole block (rescaling to spread diffs)
            i = random.randrange(max(1, len(cand) - 1))
            cand[i] += random.randint(-50, 50)

        cand = list(set(cand))
        if len(cand) > 300:
            cand = cand[:300]
        if len(cand) < 2:
            continue
        sc = _score(cand)
        if sc >= cur_score or random.random() < 0.02:
            cur, cur_score = cand, sc
        if sc > best_local_score:
            best_local, best_local_score = cand[:], sc
        if it % 2000 == 0:
            step = max(1, step - 1) if step > 1 else 1

    if best_local_score > best_score:
        best, best_score = best_local[:], best_local_score

    # Final focused search around best with smaller perturbations.
    cur = best[:]
    cur_score = best_score
    end2 = min(deadline + 5, time.time() + 8)
    while time.time() < end2:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-2, 2)
        cand = list(set(cand))
        sc = _score(cand)
        if sc >= cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand[:], sc

    return sorted(set(best))
