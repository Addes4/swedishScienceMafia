import math
import random
import time

def _stats(a):
    n = len(a)
    if n < 2:
        return 0.0, 1, 1
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)

def _score(a):
    s, _, _ = _stats(a)
    return s

def _full_score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return -1e9
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
            diffs.add(ai - a[j])
            diffs.add(a[j] - ai)
    if len(sums) <= 1:
        return -1e9
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def _greedy_sidon(limit, maxn):
    # Build a modular Sidon-ish set greedily with small additions
    A = [0, 1]
    candidates = list(range(2, limit))
    while len(A) < maxn:
        best_c = None
        best_val = -1
        # evaluate a few candidates quickly by sum-set growth
        random.shuffle(candidates)
        for c in candidates[:40]:
            newA = A + [c]
            sums = set()
            for x in newA:
                for y in newA:
                    sums.add(x + y)
            # prefer small sum set and large diffs
            diffs = set()
            for x in newA:
                for y in newA:
                    diffs.add(x - y)
            val = len(diffs) / max(1, len(sums))
            if val > best_val:
                best_val = val
                best_c = c
        if best_c is None:
            break
        A.append(best_c)
        candidates.remove(best_c)
    return A

def solve():
    deadline = time.time() + 110
    random.seed(12345)

    # Strategy: A = {i*B + i^2 : i} type constructions often give small sum sets.
    # Try known good construction: A = {i : i in [0,m)} union scaled copies tuned.
    # We'll do randomized hill-climbing with restarts, scoring exact.

    bestA = [0, 1]
    bestS = -1e9

    # seed with a geometric-ish / Sidon construction
    seeds = []

    # quadratic construction: a_i = i*i for i=0..n-1 -> differences and sums both structured
    for n in (30, 60, 120, 250, 500, 900, 1500, 2200, 3000):
        seeds.append([i * i for i in range(n)])

    # powers of 2 (Sidon-like diffs, huge sums) - bad but try
    for n in (10, 15, 20):
        seeds.append([1 << i for i in range(n)])

    # Beatty / Sidon greedy mod
    try:
        seeds.append(_greedy_sidon(400, 60))
    except Exception:
        pass

    for s in seeds:
        sc = _full_score(s)
        if sc > bestS:
            bestS = sc
            bestA = s[:]

    # Local search: perturb by bumping elements, keep if score improves.
    # Use a probability-based incremental since full score is O(n^2).
    while time.time() < deadline:
        cur = bestA[:]
        curS = bestS
        # increase size occasionally
        steps = 0
        stall = 0
        while time.time() < deadline and stall < 400:
            steps += 1
            cand = cur[:]
            r = random.random()
            if r < 0.7 and len(cand) >= 2:
                i = random.randrange(len(cand))
                cand[i] += random.choice([-2, -1, 1, 2, 3, -3])
                if abs(cand[i]) > 10**15:
                    continue
                if len(set(cand)) != len(cand):
                    continue
            elif r < 0.9:
                # add a new element spread out
                base = max(abs(x) for x in cand) if cand else 1
                cand.append(random.randint(-base, base) + random.choice([-1, 1]) * random.randint(1, base // 2 + 1))
                if len(set(cand)) != len(cand) or len(cand) > 4000:
                    continue
            else:
                if len(cand) > 3:
                    del cand[random.randrange(len(cand))]

            cs = _full_score(cand)
            if cs >= curS:
                cur, curS = cand, cs
                if cs > bestS:
                    bestS, bestA = cs, cand[:]
                stall = 0
            else:
                stall += 1
        if time.time() >= deadline:
            break

    return sorted(set(bestA))
