"""Sets with many differences and few sums: geometric-progression (Sidon) construction."""
import math
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100.0


def _make_geo(n, base):
    """Powers of base; all pairwise differences distinct (Sidon-like) -> max |A-A|."""
    vals = []
    p = 1
    for _ in range(n):
        vals.append(p)
        p *= base
        if abs(p) > 10**15:
            break
    return vals


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    # Try various geometric progressions with different bases and sizes.
    # Powers of an integer base b give a Sidon set: differences mostly distinct.
    # Larger base => fewer sum collisions but limited n by the 1e15 bound.
    candidates = []
    for base in range(2, 60):
        # max n such that base^(n-1) <= 1e15
        n = 1
        p = 1
        while p * base <= 10**15:
            p *= base
            n += 1
        candidates.append((n, base))

    # also some huge-base small sets and stretched ones
    for base in [100, 1000, 10000, 100000, 10**6, 10**7]:
        n = 1
        p = 1
        while p * base <= 10**15:
            p *= base
            n += 1
        candidates.append((n, base))

    # Scale: also try odd-only powers (base 3 starting at 1) with a shift
    for n, base in candidates:
        if n < 2:
            continue
        a = _make_geo(n, base)
        if len(a) > 4000 or any(abs(x) > 10**15 for x in a):
            continue
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a[:]

    # Local refinement: perturb a few elements to try to reduce sum set while
    # keeping differences large, and to grow |A| a bit.
    if best is not None:
        cur = best[:]
        import random
        random.seed(12345)
        it = 0
        while time.time() < deadline:
            it += 1
            cand = cur[:]
            # perturb one element by a small multiple of a near-element gap
            i = random.randrange(len(cand))
            scale = max(1, abs(cand[i]) // (len(cand) + 1))
            cand[i] += random.choice([-scale, -1, 1, scale, 0])
            cand = list(set(cand))
            if len(cand) < 2 or any(abs(x) > 10**15 for x in cand):
                continue
            s = _score(cand)
            if s >= best_score:
                best_score = s
                best = cand[:]
                cur = cand
            elif random.random() < 0.05:
                cur = best[:]

    return sorted(set(best))
