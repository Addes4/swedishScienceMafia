import math
import time


def _score(A):
    if len(A) < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in A:
        for y in A:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(A)) / 100


def _bose_chowla(p):
    """Bose-Chowla Sidon set modulo p^2-1, standard construction."""
    q = p
    m = q * q - 1
    A = []
    for x in range(q):
        val = (2 * q * x + (x * x) % m) % m if False else (x * (q + 1) + (x * x) % m) % m
        A.append(val % m)
    return A


def _bose_chowla2(p):
    """Bose's construction: for q prime power, {2q*i + (i^2 mod (q^2-1))} mod q^2-1."""
    m = p * p - 1
    A = []
    for i in range(p):
        v = (2 * p * i + (i * i) % m) % m
        A.append(v)
    return A


def _shift_dedup(A):
    A = sorted(set(A))
    return A


def _score_fast(A):
    n = len(A)
    if n < 2:
        return 0.0
    diffs = set()
    for i in range(n):
        ai = A[i]
        for j in range(n):
            diffs.add(ai - A[j])
    sums = set()
    for i in range(n):
        ai = A[i]
        for j in range(i, n):
            sums.add(ai + A[j])
    if not sums:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _make_sidon_singer(p):
    """Singer/Bose: Sidon set of size p in Z_{p^2-1} via quadratic residues mod p^2-1."""
    m = p * p - 1
    if m <= 0:
        return [0]
    A = []
    seen = set()
    for i in range(p):
        v = (2 * p * i + (i * i) % m) % m
        if v not in seen:
            seen.add(v)
            A.append(v)
    return A


def _distinct_differences(A):
    s = set()
    n = len(A)
    for i in range(n):
        ai = A[i]
        for j in range(n):
            s.add(ai - A[j])
    return len(s)


def solve():
    target_n = 3900
    best = None
    best_score = -1.0

    def consider(A):
        nonlocal best, best_score
        A = sorted(set(A))
        if len(A) < 2:
            return
        s = _score_fast(A)
        if s > best_score:
            best_score = s
            best = A[:]

    # Prime p near sqrt(n)
    p = int(math.isqrt(target_n))
    while p * p - 1 < target_n:
        p += 1

    # Try a range of primes p, keep best Sidon set
    def is_prime(x):
        if x < 2:
            return False
        if x % 2 == 0:
            return x == 2
        i = 3
        while i * i <= x:
            if x % i == 0:
                return False
            i += 2
        return True

    # Build Sidon sets for various primes, then scale up to make differences more distinct.
    candidates = []
    pp = p
    while pp > 2 and len(candidates) < 8:
        if is_prime(pp):
            candidates.append(pp)
        pp -= 1
    pp = p + 1
    cnt = 0
    while cnt < 4:
        if is_prime(pp):
            candidates.append(pp)
            cnt += 1
        pp += 1

    # Deduplicate candidates
    candidates = sorted(set(candidates))

    # Prefer large primes close to sqrt(target_n) with p <= target_n.
    for pp in candidates:
        A0 = _bose_chowla2(pp)
        A0 = sorted(set(A0))
        if len(A0) < 2:
            continue
        # Try scaling to break differences: multiply modulo m = p^2-1 by a random-ish invertible shift
        m = pp * pp - 1
        n = len(A0)
        # Use several multipliers
        for mult in (1, 3, 7, 13, 31, 127, pp):
            if math.gcd(mult, m) != 1:
                continue
            A = [(v * mult) % m for v in A0]
            A = sorted(set(A))
            if len(A) < 2:
                continue
            consider(A)

    # Local improvement on best: nudge values to try to increase ratio slightly
    if best is None:
        best = list(range(1, 8))
        best_score = _score_fast(best)

    # Try adding elements if we're below target to get bonus
    deadline = time.time() + 90.0

    cur = best[:]
    cur_score = _score_fast(cur)

    # Quick greedy tweak: try to improve score by small perturbations.
    while time.time() < deadline:
        improved = False
        A = best[:]
        n = len(A)
        # Random local move
        import random
        rng = random.Random(12345)
        # Do a bounded number of improvement sweeps
        for _ in range(200):
            if time.time() > deadline:
                break
            B = A[:]
            i = rng.randrange(len(B))
            delta = rng.choice([-2, -1, 1, 2, 3, -3, 5, -5, 10, -10])
            B[i] += delta
            B = sorted(set(B))
            if len(B) < 2:
                continue
            sB = _score_fast(B)
            if sB > _score_fast(A):
                A = B
                improved = True
        if improved:
            if _score_fast(A) > cur_score:
                best = A
                cur_score = _score_fast(A)
        else:
            break

    return sorted(set(best))
