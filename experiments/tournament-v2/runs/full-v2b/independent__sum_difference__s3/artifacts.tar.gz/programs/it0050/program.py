import math
import random
import time
from itertools import combinations


def _stats(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0, 0, 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls <= 1:
        return ld, ls, 1e9
    score = math.log(ld) / math.log(ls) + (1 - 1.0 / n) / 100.0
    return ld, ls, score


def _score_fast_via_sets(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) <= 1:
        return 1e9
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1.0 / n) / 100.0


def _construct_blocks():
    candidates = []

    # Basic dense block: many sums collide, differences stay many if skew is used.
    # Try several block shapes.
    for n in [18, 24, 30, 36, 42, 48, 54, 60, 72, 84, 96]:
        # A "two-sided" dense block around zero with a gap-free center and sparse tails.
        half = n // 2
        base = list(range(-half, half + 1))
        if len(base) > n:
            base = base[:n]
        candidates.append(base)

        # Shifted all-positive dense block.
        candidates.append(list(range(1, n + 1)))

        # Three sub-blocks with controlled spacing.
        m = max(3, n // 3)
        block = list(range(0, m))
        block += [x + 3 * m for x in range(0, m)]
        block += [x + 7 * m for x in range(0, m)]
        candidates.append(block[:n])

        # Union of two arithmetic progressions with different steps.
        m = n // 2
        b = [2 * i for i in range(m)] + [3 * i + 1 for i in range(n - m)]
        candidates.append(b)

    # Sparse outlier additions produce extra differences while adding few sums.
    refined = []
    for c in candidates:
        c = sorted(set(c))
        if len(c) < 5:
            continue
        refined.append(c)

        # Add a few remote points.
        for extra in [
            [1000], [10000], [-1000], [-10000], [10**6], [-10**6],
            [1000, 10000], [-1000, -10000],
            [1, 1000], [-1, -1000],
            [500, 5000, 50000], [-500, -5000, -50000],
            [10**6, 10**7], [-10**6, -10**7],
        ]:
            d = sorted(set(c + extra))
            if len(d) <= 4000:
                refined.append(d)

    return refined


def _greedy_add(a, tries=200, rng=None):
    if rng is None:
        rng = random
    a = sorted(set(a))
    best = a[:]
    best_score = _score_fast_via_sets(best)

    # Try adding one point at a time from a candidate pool designed to increase differences
    # without creating too many new sums.
    pool = []
    for x in range(-200, 201):
        pool.append(x)
    for x in [300, 400, 500, 750, 1000, 1500, 2000, 3000, 5000, 10000, 20000, 50000,
              100000, 250000, 500000, 1000000, 2000000, 5000000, 10000000,
              -300, -400, -500, -750, -1000, -1500, -2000, -3000, -5000, -10000]:
        pool.append(x)

    # Also add points derived from current set differences.
    for _ in range(min(tries, 40)):
        x = rng.choice(best)
        y = rng.choice(best)
        pool.append(x - y)
        pool.append(x + y)

    pool = list(set(pool))

    improved = True
    while improved and len(best) < 4000:
        improved = False
        # Evaluate a random subset of pool to avoid quadratic blowup.
        cand_pool = pool[:]
        rng.shuffle(cand_pool)
        for x in cand_pool[:max(120, tries)]:
            if x in best:
                continue
            cand = sorted(set(best + [x]))
            s = _score_fast_via_sets(cand)
            if s > best_score + 1e-15:
                best = cand
                best_score = s
                improved = True
                break
    return best, best_score


def _local_perturb(a, rng, steps=60):
    a = sorted(set(a))
    best = a[:]
    best_score = _score_fast_via_sets(best)

    cur = a[:]
    cur_score = best_score
    deadline = time.time() + steps * 0.02

    # Local moves: shift, remove, replace, add.
    for _ in range(steps):
        if time.time() > deadline:
            break
        cand = cur[:]
        move = rng.randrange(5)
        if move == 0 and len(cand) > 2:
            i = rng.randrange(len(cand))
            cand[i] += rng.choice([-5, -4, -3, -2, -1, 1, 2, 3, 4, 5])
        elif move == 1 and len(cand) > 3:
            i = rng.randrange(len(cand))
            cand.pop(i)
        elif move == 2:
            cand.append(rng.randint(-100, 100))
        elif move == 3 and len(cand) > 3:
            i = rng.randrange(len(cand))
            cand[i] = rng.randint(-200, 200)
        else:
            if len(cand) < 4000:
                x = rng.choice(cand)
                y = rng.choice(cand)
                cand.append(x - y + rng.choice([-1, 0, 1]))

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score_fast_via_sets(cand)
        if s >= cur_score or rng.random() < 0.08:
            cur = cand
            cur_score = s
        if s > best_score:
            best = cand
            best_score = s
    return best, best_score


def solve():
    """Return A maximizing log|A-A| / log|A+A| with a size bonus."""
    rng = random.Random(1234567)
    start = time.time()
    deadline = start + 110.0

    best = None
    best_score = -1.0

    # Seed candidates.
    seeds = _construct_blocks()
    # Also add known good starting sets from the baseline style.
    seeds.append([7, 15, 18, 22, -3, -2])
    seeds.append([-3, -2, 1, 5, 8, 12, 17, 23, 30])
    seeds.append(list(range(-30, 31)))
    seeds.append(list(range(1, 61)))
    seeds.append([x * x for x in range(1, 16)])
    seeds.append([2 ** i for i in range(1, 15)])
    seeds.append([3 ** i for i in range(1, 10)])

    # Evaluate seeds quickly.
    for s in seeds:
        s = sorted(set(s))
        if len(s) < 2:
            continue
        sc = _score_fast_via_sets(s)
        if sc > best_score:
            best = s[:]
            best_score = sc

    # Greedy expansion from the best few seeds.
    seeds_sorted = sorted(seeds, key=lambda x: _score_fast_via_sets(sorted(set(x))), reverse=True)
    for s in seeds_sorted[:12]:
        if time.time() > deadline - 20:
            break
        g, gs = _greedy_add(s, tries=160, rng=rng)
        if gs > best_score:
            best, best_score = g[:], gs

    # Local search / simulated annealing.
    cur = best[:]
    cur_score = best_score
    it = 0
    while time.time() < deadline:
        it += 1
        if it % 200 == 0:
            # Restart from current best occasionally.
            if rng.random() < 0.2:
                cur = best[:]
                cur_score = best_score

        cand = cur[:]
        r = rng.random()

        if r < 0.35 and len(cand) > 2:
            i = rng.randrange(len(cand))
            cand[i] += rng.choice([-10, -7, -5, -3, -2, -1, 1, 2, 3, 5, 7, 10])
        elif r < 0.50 and len(cand) > 3:
            i = rng.randrange(len(cand))
            cand.pop(i)
        elif r < 0.65 and len(cand) < 4000:
            cand.append(rng.randint(-300, 300))
        elif r < 0.78 and len(cand) > 2:
            i = rng.randrange(len(cand))
            cand[i] = rng.randint(-500, 500)
        elif r < 0.90:
            if len(cand) < 4000:
                x = rng.choice(cand)
                y = rng.choice(cand)
                cand.append(x - y)
        else:
            if len(cand) < 4000:
                x = rng.choice(cand)
                cand.append(x + rng.choice([-2, -1, 1, 2]))

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue

        # For speed, only full-score occasionally; use cheap proxy often.
        if len(cand) <= 120 or rng.random() < 0.25:
            s = _score_fast_via_sets(cand)
        else:
            # sample-based proxy (same formula, approximate counts)
            aa = cand
            n = len(aa)
            diffs = set()
            sums = set()
            sample = 120
            for _ in range(sample):
                x = rng.choice(aa)
                y = rng.choice(aa)
                sums.add(x + y)
                diffs.add(x - y)
            if len(sums) <= 1:
                s = 1e9
            else:
                s = math.log(max(1, len(diffs))) / math.log(len(sums)) + (1 - 1.0 / n) / 100.0

        temp = max(0.001, 0.05 * (deadline - time.time()) / 110.0)
        if s >= cur_score or rng.random() < math.exp((s - cur_score) / max(temp, 1e-9)):
            cur = cand
            cur_score = s

        if s > best_score:
            # Verify with exact score before accepting as best.
            exact = _score_fast_via_sets(cand)
            if exact > best_score:
                best, best_score = cand[:], exact

    # Final polish on best.
    for _ in range(3):
        if time.time() > deadline - 2:
            break
        b2, s2 = _local_perturb(best, rng, steps=200)
        if s2 > best_score:
            best, best_score = b2, s2

    # Ensure validity: distinct ints, bounded size and magnitude.
    best = sorted(set(int(x) for x in best))
    if len(best) > 4000:
        best = best[:4000]
    best = [x for x in best if abs(x) <= 10**15]
    if not best:
        best = [1, 2]
    return best
