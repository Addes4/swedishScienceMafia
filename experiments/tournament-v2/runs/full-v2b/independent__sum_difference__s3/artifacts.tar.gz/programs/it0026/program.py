import math
import random
import time

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def _score_fast(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    sums = set()
    diffs = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
        for j in range(n):
            diffs.add(ai - a[j])
    return math.log(len(diffs)) / math.log(max(2, len(sums))) + (1 - 1 / n) / 100

def build(r, k):
    # union of r copies: copy t shifted by t*k. Base set S in [0, k).
    # A = {s + t*k : s in S, t in 0..r-1}
    # Use S = {0,1,3,7,12,...} type small Sidon-ish / difference-rich base.
    return r, k

# We search over base sets S (small), then replicate.
# Difference set: for two elements s+t k and s'+t' k, diff = (s-s') + (t-t')k.
# If k large enough relative to base span, distinct (t-t') give distinct blocks.

def construct(base, r, k):
    A = []
    for t in range(r):
        for s in base:
            A.append(s + t * k)
    return sorted(set(A))

def optimize_base(deadline, max_base=40):
    # Good base: a set with large difference set relative to sum set in small range.
    # Start from known good small sets and hill-climb.
    best_base = [0, 1, 3, 7, 12, 20]
    best_val = _base_quality(best_base)
    cur = best_base[:]
    while time.time() < deadline * 0.35:
        cand = cur[:]
        op = random.random()
        if op < 0.5 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2,-1,1,2])
        elif op < 0.8:
            cand.append(random.randint(0, max_base))
        elif len(cand) > 3:
            cand.pop(random.randrange(len(cand)))
        cand = sorted(set(cand))
        if len(cand) < 3 or len(cand) > 15:
            continue
        v = _base_quality(cand)
        if v >= best_val or random.random() < 0.05:
            best_base, best_val, cur = cand[:], v, cand
    return best_base

def _base_quality(base):
    n = len(base)
    if n < 3:
        return -1
    d = set()
    s = set()
    for i in range(n):
        for j in range(n):
            d.add(base[i]-base[j])
            s.add(base[i]+base[j])
    if len(s) < 2:
        return -1
    return math.log(len(d))/math.log(len(s))

def solve():
    start = time.time()
    deadline = start + 100.0

    # Try several (base, r, k) configurations, evaluate actual score, keep best.
    best_A = [7, 15, 18, 22, -3, -2]
    best_sc = _score(best_A)

    # candidate bases (difference-rich small sets)
    bases = []
    bases.append([0,1,3,7,12,20])
    bases.append([0,1,3,7,12])
    bases.append([0,1,3,7])
    bases.append([0,1,3,6,10])
    bases.append([0,1,2,5,10,15])
    bases.append([0,1,4,6,13])
    bases.append([0,1,3,7,12,18,25])
    bases.append([0, 1, 5, 11, 16, 22, 34])
    bases.append([0, 1, 6, 13, 21, 30, 42])
    bases.append([0, 2, 5, 11, 20, 31])

    opt = optimize_base(deadline, 45)
    bases.append(opt)

    # also random difference-rich bases searched during time
    t0 = time.time()
    while t0 < start + 20:
        n = random.randint(5, 9)
        b = sorted(random.sample(range(0, 50), n))
        v = _base_quality(b)
        if v > 1.35:
            bases.append(b)
        t0 = time.time()

    for base in bases:
        span = max(base) - min(base)
        if span == 0:
            continue
        # shift base to nonnegative
        b = [x - min(base) for x in base]
        maxb = max(b)
        for r in range(2, 30):
            for kmul in [1, 2, 3, 5, 8, 13, 21, 34, 55, 100, 1000, 10**6]:
                k = (maxb + 1) * kmul
                if k == 0:
                    continue
                A = construct(b, r, k)
                if len(A) > 4000 or len(A) < 4:
                    continue
                mx = max(abs(x) for x in A)
                if mx > 10**15:
                    continue
                # evaluate but limit cost
                if len(A) > 800:
                    continue
                sc = _score(A)
                if sc > best_sc:
                    best_sc = sc
                    best_A = A
            if time.time() > deadline - 40:
                break
        if time.time() > deadline - 30:
            break

    # Final local refinement on best_A using coordinate moves (small budget).
    if len(best_A) <= 400:
        cur = best_A[:]
        cur_sc = best_sc
        t_end = min(deadline, time.time() + 25)
        while time.time() < t_end:
            cand = cur[:]
            i = random.randrange(len(cand))
            cand[i] += random.choice([-3,-2,-1,1,2,3, 10, 100])
            cand = list(set(cand))
            if len(cand) < 4 or len(cand) > 4000:
                continue
            if max(abs(x) for x in cand) > 10**15:
                continue
            sc = _score(cand)
            if sc > cur_sc:
                cur, cur_sc = cand, sc
        if cur_sc > best_sc:
            best_sc = cur_sc
            best_A = cur

    return sorted(set(best_A))
