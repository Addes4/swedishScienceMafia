import math
import random
import time

def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    # use sorted list, compute differences and sums as sets via dict for speed
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            sums.add(ai + aj)
            diffs.add(ai - aj)
            diffs.add(aj - ai)
    ld = len(diffs)
    ls = len(sums)
    if ls < 2:
        return 0.0, ld, ls
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100, ld, ls

def _fast_score(a):
    a = list(a)
    n = len(a)
    if n < 2:
        return -1e9
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            s = ai + aj
            sums.add(s)
            diffs.add(ai - aj)
            diffs.add(aj - ai)
    ls = len(sums)
    if ls < 2:
        return -1e9
    return math.log(len(diffs)) / math.log(ls) + (1 - 1 / n) / 100

def _score_vals(diffs, sums, n):
    ls = len(sums)
    if ls < 2:
        return -1e9
    return math.log(len(diffs)) / math.log(ls) + (1 - 1 / n) / 100

def construct_base3(k):
    # numbers with base-3 digits all 0/1: gives B_2-ish set with small sums
    res = []
    for i in range(2 ** k):
        x = 0
        p = 1
        for b in range(k):
            if (i >> b) & 1:
                x += p
            p *= 3
        res.append(x)
    return res

def construct_ap_stretched(n, step, seed):
    rng = random.Random(seed)
    a = []
    x = 0
    for i in range(n):
        x += step
        a.append(x + rng.randint(-step // 2, step // 2))
    return sorted(set(a))

def local_search(a, deadline, best_score_holder):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return a, best_score_holder[0]
    # incremental-ish: keep score
    def compute(a):
        return _fast_score(a)
    cur_score = compute(a)
    best = a[:]
    best_score = cur_score
    if best_score > best_score_holder[0]:
        best_score_holder[0] = best_score
        best_score_holder[1] = best[:]
    # move types: shift element, add random, remove, swap
    while time.time() < deadline:
        cand = a[:]
        r = random.random()
        if r < 0.5:
            i = random.randrange(len(cand))
            delta = random.choice([-3,-2,-1,1,2,3,5,8,13])
            cand[i] += delta
        elif r < 0.75:
            v = random.randint(- (len(a)*len(a)), len(a)*len(a))
            cand.append(v)
        elif r < 0.9:
            if len(cand) > 3:
                i = random.randrange(len(cand))
                cand.pop(i)
        else:
            if len(cand) > 2:
                i, j = random.sample(range(len(cand)), 2)
                cand[i], cand[j] = cand[j], cand[i]
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = compute(cand)
        if s >= cur_score:
            a = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best = cand[:]
                if s > best_score_holder[0]:
                    best_score_holder[0] = s
                    best_score_holder[1] = cand[:]
        else:
            # occasional accept worse (annealing-like)
            if random.random() < 0.001 * math.exp(-(cur_score - s) * 10):
                a = cand
                cur_score = s
    return best, best_score

def solve():
    deadline = time.time() + 115
    best_holder = [-1e9, None]
    # Candidate seeds
    seeds = []
    # base-3 constructions of various sizes
    for k in range(3, 8):
        seeds.append(construct_base3(k))
    # arithmetic progressions stretched
    for n in [50, 100, 200, 300, 500, 800, 1000]:
        for step in [1, 3, 7]:
            for sd in range(2):
                seeds.append(construct_ap_stretched(n, step, sd * 1000 + n))
    # special small seeds
    seeds.append([7, 15, 18, 22, -3, -2])
    seeds.append([0, 1, 3, 7, 12, 20, 30, 44, 65])
    # powers of 2 style (sums have overlaps)
    seeds.append([2**i for i in range(15)])
    # powers of 3 scaled
    seeds.append([3**i for i in range(12)])

    # evaluate seeds
    for s in seeds:
        if not s:
            continue
        sc = _fast_score(s)
        if sc > best_holder[0]:
            best_holder[0] = sc
            best_holder[1] = sorted(set(s))

    # run local search on best seeds with restarts
    idx = 0
    while time.time() < deadline:
        seed = random.choice(seeds)[:]
        if random.random() < 0.5 and best_holder[1]:
            # perturb best so far
            seed = best_holder[1][:]
            # random mutations
            for _ in range(random.randint(1, 5)):
                if not seed:
                    break
                i = random.randrange(len(seed))
                seed[i] += random.randint(-10, 10)
        local_deadline = min(deadline, time.time() + random.uniform(2, 8))
        res, sc = local_search(seed, local_deadline, best_holder)
        if sc > best_holder[0]:
            best_holder[0] = sc
            best_holder[1] = res[:]

    res = sorted(set(best_holder[1]))
    if len(res) < 2:
        res = [0, 1]
    return res
