import math
import random
import time

def _diffs_sums(a):
    s = set(a)
    n = len(s)
    diffs = set()
    sums = set()
    lst = list(s)
    for i in range(n):
        xi = lst[i]
        for j in range(n):
            diffs.add(xi - lst[j])
            sums.add(xi + lst[j])
    return len(diffs), len(sums)

def _score_fast(a):
    a = list(set(a))
    if len(a) < 2:
        return -1e18, 0.0
    nd, ns = _diffs_sums(a)
    if ns == 0:
        return -1e18, 0.0
    ratio = math.log(nd) / math.log(ns)
    bonus = (1 - 1 / len(a)) / 100
    return ratio + bonus, ratio

def solve():
    deadline = time.time() + 110

    best = None
    best_score = -1e18

    def try_set(s):
        nonlocal best, best_score
        s = sorted(set(int(x) for x in s))
        if len(s) < 2 or len(s) > 4000:
            return
        sc, _ = _score_fast(s)
        if sc > best_score:
            best_score = sc
            best = s[:]

    # Try many structured constructions
    # Powers of 2
    for k in range(2, 20):
        try_set([2 ** i for i in range(k)])

    # Powers of 3
    for k in range(2, 12):
        try_set([3 ** i for i in range(k)])

    # geometric with ratio 2 and negative
    for k in range(2, 18):
        try_set([-(2 ** i) for i in range(k)])

    # mixed powers of 2 near origin
    for k in range(2, 22):
        v = [0]
        for i in range(k - 1):
            v.append(2 ** i)
        try_set(v)

    # Sidon-ish random starts with structure: small dense region + sparse tails
    random.seed(12345)

    def random_structured(n):
        # half near zero, half exponential
        s = set()
        half = n // 2
        for _ in range(half):
            s.add(random.randint(-10, 10))
        base = 20
        for _ in range(n - len(s)):
            s.add(base)
            base = base * 2 + random.randint(-2, 2)
            if base > 10**15:
                base = random.randint(50, 200)
        return list(s)

    for n in [20, 40, 60, 80, 100, 150, 200]:
        for _ in range(20):
            try_set(random_structured(n))

    # local search / simulated annealing
    if best is None:
        best = [0, 1, 2, 4, 8]

    cur = best[:]
    cur_score = best_score
    temp = 0.5
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        r = random.random()
        if r < 0.4:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-3, 3)
        elif r < 0.6:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-50, -20, -10, 10, 20, 50, 100])
        elif r < 0.8 and len(cand) < 4000:
            # add a point near existing
            x = random.choice(cand)
            cand.append(x + random.randint(-10, 10))
        elif len(cand) > 3:
            cand.pop(random.randrange(len(cand)))

        cand = [int(x) for x in set(cand)]
        if not cand:
            continue
        if any(abs(x) > 10**15 for x in cand):
            continue
        sc, _ = _score_fast(cand)
        # use score; accept better or with prob
        if sc >= cur_score or random.random() < math.exp((sc - cur_score) / max(temp, 1e-9)):
            cur = cand
            cur_score = sc
            if sc > best_score:
                best_score = sc
                best = cand[:]
                temp = max(temp * 0.99, 1e-4)
        temp *= 0.99999
        if it % 5000 == 0:
            temp = max(temp, 0.01)

    # final polish: try local moves on best
    end_polish = time.time() + 2
    cur = best[:]
    cur_score = best_score
    while time.time() < end_polish:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-2, 2)
        cand = [int(x) for x in set(cand)]
        if not cand:
            continue
        sc, _ = _score_fast(cand)
        if sc > cur_score:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best_score = sc
                best = cand[:]

    return sorted(set(int(x) for x in best))
