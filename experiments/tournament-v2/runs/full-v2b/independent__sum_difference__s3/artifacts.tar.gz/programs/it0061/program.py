import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _fast_score(a):
    # Faster exact evaluation using sorted array and set comprehension over sums only,
    # with difference count computed via convolution-free counting trick:
    # |A-A| is large usually; to save time we compute it directly but with early grouping.
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    sa = sorted(a)
    sums = {x + y for x in sa for y in sa}
    diffs = {x - y for x in sa for y in sa}
    if len(sums) <= 1:
        return 0.0, len(diffs), len(sums)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)


def _initial_candidates():
    cands = []
    # Small known good examples.
    cands.append([7, 15, 18, 22, -3, -2])
    cands.append([1, 2, 4, 8, 16, -1, -2, -4])
    cands.append([0, 1, 3, 7, 12, 20, -5, -11])

    # Product/AP-style constructions: union of arithmetic progressions.
    # This tends to keep sums structured while differences become numerous.
    for _ in range(30):
        sets = []
        base = 0
        for _ in range(random.randint(2, 5)):
            step = random.randint(1, 8)
            length = random.randint(3, 30)
            start = base + random.randint(-20, 20)
            sets.extend(start + step * i for i in range(length))
            base += step * length + random.randint(1, 20)
        cands.append(sets)

    # Random dense/sparse mixes within moderate ranges.
    for _ in range(30):
        n = random.randint(5, 60)
        rng = random.randint(n, 5 * n)
        cands.append([random.randint(-rng, rng) for _ in range(n)])

    return cands


def _normalize(cand, limit=4000):
    s = sorted(set(int(x) for x in cand))
    if len(s) > limit:
        # Keep the most "spread" subset by keeping first/last and thinning middle.
        s = s[:limit]
    # Clamp values to allowed range.
    M = 10 ** 15
    s = [x for x in s if -M <= x <= M]
    return s


def _neighbors(cand, rng):
    n = len(cand)
    if n == 0:
        return []

    res = []

    # Single-element perturbation.
    for _ in range(6):
        c = cand[:]
        i = rng.randrange(n)
        delta = rng.choice([-1, 1, -2, 2, -3, 3, -5, 5, -10, 10,
                            -20, 20, -50, 50])
        c[i] += delta
        res.append(c)

    # Add a new element near existing ones or globally.
    for _ in range(3):
        c = cand[:]
        if rng.random() < 0.7 and n > 0:
            anchor = rng.choice(cand)
            c.append(anchor + rng.randint(-50, 50))
        else:
            c.append(rng.randint(-200, 200))
        res.append(c)

    # Remove an element.
    if n > 4:
        for _ in range(2):
            c = cand[:]
            del c[rng.randrange(n)]
            res.append(c)

    # Swap/translate an element to a nearby value.
    if n >= 2:
        c = cand[:]
        i = rng.randrange(n)
        j = rng.randrange(n)
        if c[i] != c[j]:
            c[i] = c[j] + rng.choice([-20, -10, -5, -3, -2, -1, 1, 2, 3, 5, 10, 20])
        res.append(c)

    # Occasionally insert a small cluster to boost difference count.
    if rng.random() < 0.3:
        c = cand[:]
        center = rng.choice(cand) if cand else 0
        for _ in range(rng.randint(1, 4)):
            c.append(center + rng.randint(-30, 30))
        res.append(c)

    return res


def solve():
    deadline = time.time() + 110.0
    rng = random.Random(123456789)

    best = None
    best_score = -1e18

    # Evaluate initial candidates.
    for cand in _initial_candidates():
        cand = _normalize(cand)
        if len(cand) < 2:
            continue
        sc, nd, ns = _fast_score(cand)
        if sc > best_score:
            best_score = sc
            best = cand[:]

    # Also seed with a couple of carefully structured sets.
    structured = []
    # Union of a few APs with co-prime steps.
    for steps in [(1, 3, 7), (1, 4, 9), (1, 5, 11), (2, 3, 5), (1, 2, 5, 10)]:
        s = []
        off = 0
        for st in steps:
            ln = max(3, 60 // st)
            s.extend(off + st * i for i in range(ln))
            off += st * ln + 3
        structured.append(s)

    # Balanced ternary / powers-like sets (small sums, many differences).
    s = []
    for i in range(12):
        s.append(3 ** i)
        s.append(-3 ** i)
    structured.append(s)

    s = []
    v = 1
    for i in range(15):
        s.append(v)
        s.append(-v)
        v *= 2
    structured.append(s)

    for cand in structured:
        cand = _normalize(cand)
        if len(cand) < 2:
            continue
        sc, nd, ns = _fast_score(cand)
        if sc > best_score:
            best_score = sc
            best = cand[:]

    # Local search / simulated annealing over several restarts.
    while time.time() < deadline and best is not None:
        cur = best[:]

        # Sometimes restart from a perturbation of best.
        if rng.random() < 0.15:
            cur = best[:]
            for _ in range(rng.randint(1, 5)):
                if cur:
                    i = rng.randrange(len(cur))
                    cur[i] += rng.randint(-100, 100)

        cur = _normalize(cur)
        cur_score, _, _ = _fast_score(cur)

        temp = 0.02
        steps = 0
        last_improve = 0

        while time.time() < deadline:
            steps += 1
            neigh = _neighbors(cur, rng)
            if not neigh:
                break

            improved = False
            for cand in neigh:
                cand = _normalize(cand)
                if len(cand) < 2:
                    continue
                sc, _, _ = _fast_score(cand)
                if sc > cur_score:
                    cur, cur_score = cand, sc
                    improved = True
                    last_improve = steps
                    if sc > best_score:
                        best_score = sc
                        best = cand[:]
                    break

            if not improved:
                # Random restart move: accept a slight worsening occasionally.
                cand = neigh[rng.randrange(len(neigh))]
                cand = _normalize(cand)
                if len(cand) >= 2:
                    sc, _, _ = _fast_score(cand)
                    # Accept with small probability to escape local optima.
                    if sc >= cur_score or rng.random() < 0.05:
                        cur, cur_score = cand, sc
                        if sc > best_score:
                            best_score = sc
                            best = cand[:]

            # Periodically shrink/extend the set to explore sizes.
            if steps % 50 == 0:
                if rng.random() < 0.5 and len(cur) > 5:
                    cur = cur[:-1]
                elif rng.random() < 0.5:
                    cur.append(rng.randint(-300, 300))
                cur = _normalize(cur)
                cur_score, _, _ = _fast_score(cur)

            # Break inner loop occasionally to restart.
            if steps - last_improve > 300:
                break

            if time.time() >= deadline:
                break

    if best is None:
        return [7, 15, 18, 22, -3, -2]

    # Final polish: greedy single-element updates.
    improved = True
    while improved and time.time() < deadline:
        improved = False
        best = _normalize(best)
        sc, _, _ = _fast_score(best)
        idxs = list(range(len(best)))
        rng.shuffle(idxs)
        for i in idxs:
            old = best[i]
            base = best[:]
            for delta in [1, -1, 2, -2, 3, -3, 5, -5, 10, -10, 20, -20, 50, -50]:
                trial = base[:]
                trial[i] = old + delta
                trial = _normalize(trial)
                tsc, _, _ = _fast_score(trial)
                if tsc > sc:
                    best = trial
                    sc = tsc
                    improved = True
                    break
            if improved:
                break

        # Try adding/removing in polish too.
        if not improved and time.time() < deadline:
            trial = best[:]
            trial.append(rng.randint(-500, 500))
            trial = _normalize(trial)
            tsc, _, _ = _fast_score(trial)
            if tsc > sc:
                best = trial
                sc = tsc
                improved = True

    best = _normalize(best)
    if len(best) < 2:
        return [7, 15, 18, 22, -3, -2]
    return best
