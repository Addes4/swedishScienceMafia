import math
import random
import time

def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1/len(a)) / 100

def build_geometric(n, base=2):
    # Elements: base^0, base^1, ..., base^(n-1) shifted to avoid 0 issues
    # This gives |A+A| ~ 2n-1 (since sums of powers are mostly unique via base representation)
    # and |A-A| ~ n^2 (since differences of distinct powers are mostly unique)
    a = [base**i for i in range(n)]
    return a

def build_geometric_neg(n, base=2):
    # Alternate signs to increase difference set while keeping sum set small
    a = []
    for i in range(n):
        if i % 2 == 0:
            a.append(base**i)
        else:
            a.append(-base**i)
    return a

def build_near_sidon(n, base=2):
    # Try shifted geometric with slight perturbation
    a = [base**i + i for i in range(n)]
    return a

def local_search(best, deadline):
    best_score = _score(best)
    cur = best[:]
    while time.time() < deadline:
        cand = cur[:]
        # small mutation
        i = random.randrange(len(cand))
        delta = random.choice([-2, -1, 1, 2])
        cand[i] += delta
        # occasionally swap two elements
        if random.random() < 0.1:
            j = random.randrange(len(cand))
            cand[i], cand[j] = cand[j], cand[i]
        # dedupe
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.05:
            cur = cand[:]
        # restart occasionally
        if random.random() < 0.01:
            cur = best[:]
    return best, best_score

def solve():
    deadline = time.time() + 110
    candidates = []
    
    # Build geometric sets of various sizes and bases
    for n in [20, 30, 50, 80, 100, 150, 200, 300, 500, 800, 1200, 2000, 3000, 4000]:
        for base in [2, 3, 4, 5, 6, 7, 8, 10]:
            # base 2 with n=4000 would overflow 1e15
            if base**min(n-1, 50) > 1e14 and base > 2:
                continue
            if base == 2 and n > 50:
                # 2^49 ~ 5e14, 2^50 ~ 1e15
                a = build_geometric(min(n, 50), base)
            else:
                a = build_geometric(n, base)
            if max(abs(x) for x in a) <= 1e15:
                candidates.append(a)
    
    # Negative alternating sets
    for n in [20, 30, 50, 80, 100]:
        for base in [2, 3, 4, 5, 6, 7, 8]:
            if base**(n-1) <= 1e15:
                a = build_geometric_neg(n, base)
                candidates.append(a)
    
    # Near-Sidon
    for n in [10, 15, 20, 30, 50]:
        for base in [2, 3, 4, 5]:
            if base**(n-1) <= 1e14:
                a = build_near_sidon(n, base)
                candidates.append(a)
    
    # Evaluate all candidates
    best = None
    best_score = -1
    for a in candidates:
        a = sorted(set(a))
        if len(a) < 2:
            continue
        if max(abs(x) for x in a) > 1e15:
            continue
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a
    
    if best is None:
        best = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072, 262144, 524288, 1048576, 2097152, 4194304, 8388608, 16777216, 33554432, 67108864, 134217728, 268435456, 536870912]
        best = [x for x in best if abs(x) <= 1e15][:4000]
        best_score = _score(best)
    
    # Local search improvement
    remaining = deadline - time.time()
    if remaining > 0:
        best, best_score = local_search(best, deadline)
    
    return sorted(set(best))
