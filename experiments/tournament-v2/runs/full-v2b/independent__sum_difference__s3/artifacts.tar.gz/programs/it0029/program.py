import math
import random
import time

def _sets(a):
    a = sorted(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    # also negative differences (i>j handled bc ai-aj covers all ordered via sign symmetry? ensure all)
    for i in range(n):
        ai = a[i]
        for j in range(i):
            diffs.add(ai - a[j])
    return diffs, sums

def _score(a):
    a = sorted(set(a))
    if len(a) < 2:
        return 0.0, 0, 0
    diffs, sums = _sets(a)
    if len(sums) < 2:
        return 0.0, len(diffs), len(sums)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100, len(diffs), len(sums)

def _cand_families():
    fams = []

    # Family 1: intervals + geometric blocks
    for base in (2, 3):
        for m in (6, 7, 8, 9, 10, 11, 12):
            A = list(range(m))
            v = 1
            for _ in range(20):
                v *= base
                A.append(v)
                if v > 10**14:
                    break
            fams.append(A)

    # Family 2: Sidon-ish B_h construction: i + k*C(i,2)?
    # use quadratic residues style: {i + t*i^2}
    for t in (1, 2, 3):
        for n in (12, 16, 20, 24, 28):
            A = [i + t*i*i for i in range(n)]
            fams.append(A)

    # Family 3: powers of two scaled plus small offsets (difference-rich)
    for n in (10, 12, 14, 16, 18):
        A = [1 << i for i in range(n)]
        fams.append(A)

    # Family 4: {0} union AP with step and a few big
    for step in (1, 2, 3):
        for m in (10, 14, 18, 22):
            A = [step*i for i in range(m)]
            A += [10**6 * (2**j) for j in range(2, 10)]
            fams.append(A)

    # Family 5: near-Sidon small optimal from research: base triplets
    base_known = [
        [0,1,3,7],
        [0,1,3,7,12],
        [0,1,3,7,12,20],
        [0,1,4,9,15,22],
        [0,1,3,9,13,20,26],
        [0,1,4,10,18,25,31],
    ]
    for b in base_known:
        fams.append(b[:])

    # Family 6: geometric with random exponents
    random.seed(12345)
    for _ in range(30):
        n = random.randint(8, 18)
        base = random.choice([2, 3, 4])
        A = []
        v = 1
        for i in range(n):
            A.append(v)
            v = v * base + random.randint(0, 2)
            if v > 10**14:
                break
        fams.append(A)

    # Family 7: difference-dominant: union of two APs with coprime steps
    for p in (2, 3, 4, 5):
        for q in (3, 5, 7, 11):
            if math.gcd(p, q) != 1:
                continue
            A = [p*i for i in range(12)] + [q*j for j in range(12)]
            A = sorted(set(A))
            fams.append(A)

    return fams

def _local_search(best, best_score, deadline, max_iter=200000):
    cur = best[:]
    cur_score = best_score
    n_neighbors = 0
    while time.time() < deadline:
        n_neighbors += 1
        cand = cur[:]
        op = random.random()
        if op < 0.55 and len(cand) >= 2:
            i = random.randrange(len(cand))
            delta = random.choice([-2,-1,1,2,3,-3])
            cand[i] += delta
        elif op < 0.8:
            i = random.randrange(len(cand))
            cand[i] = random.randint(-50, 50)
        elif op < 0.9 and len(cand) < 60:
            cand.append(random.randint(-100, 100))
        elif len(cand) > 4:
            i = random.randrange(len(cand))
            del cand[i]
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s, _, _ = _score(cand)
        if s > cur_score or (s == cur_score and len(cand) > len(cur)):
            cur = cand
            cur_score = s
            if s > best_score or (s == best_score and len(cand) > len(best)):
                best = cand[:]
                best_score = s
        elif random.random() < 0.02:
            cur = best[:]
            cur_score = best_score
    return best, best_score

def solve():
    start = time.time()
    deadline = start + 115.0

    best = [7, 15, 18, 22, -3, -2]
    best_score, _, _ = _score(best)

    for cand in _cand_families():
        s, _, _ = _score(cand)
        if s > best_score or (s == best_score and len(cand) > len(best)):
            best = sorted(set(cand))
            best_score = s
        if time.time() > deadline - 10:
            break

    random.seed(int(start * 1000) % (2**31))
    best, best_score = _local_search(best, best_score, deadline - 2)

    return sorted(set(best))
# EVOLVE-BLOCK-END
