import math
import random
import time

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    # direct computation is O(n^2); keep n <= 4000 and optimize only when needed
    for i, x in enumerate(a):
        for y in a[i:]:
            sums.add(x + y)
            diffs.add(x - y) if x >= y else diffs.add(y - x)
    if len(sums) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0

def solve():
    deadline = time.time() + 115.0

    # Construction 1: numbers with exactly two 1-bits in a window.
    # Size is about k(k-1)/2, sums have restricted form, differences are numerous.
    best = None
    best_sc = -1.0

    # Try a range of window sizes and offsets.
    for k in range(40, 91):
        if k * (k - 1) // 2 > 4000:
            break
        base = [1 << i for i in range(k)]
        A = []
        for i in range(k):
            for j in range(i + 1, k):
                A.append(base[i] + base[j])
        if len(A) < 2:
            continue
        sc = _score(A)
        if sc > best_sc:
            best_sc = sc
            best = A[:]

    # Construction 2: include 0 to increase differences while keeping sums compact.
    for k in range(40, 91):
        if k * (k - 1) // 2 + 1 > 4000:
            break
        base = [1 << i for i in range(k)]
        A = [0]
        for i in range(k):
            for j in range(i + 1, k):
                A.append(base[i] + base[j])
        if len(A) < 2:
            continue
        sc = _score(A)
        if sc > best_sc:
            best_sc = sc
            best = A[:]

    # Local improvement: randomly perturb elements while preserving distinctness.
    if best is None:
        best = [0, 1, 3, 7, 15, 31]
        best_sc = _score(best)

    cur = best[:]
    cur_sc = best_sc
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        n = len(cand)
        # pick a random element and tweak
        idx = random.randrange(n)
        delta = random.randint(-3, 3)
        cand[idx] += delta
        if len(set(cand)) != n:
            continue
        sc = _score(cand)
        if sc > cur_sc or random.random() < 0.002:
            cur = cand
            cur_sc = sc
            if sc > best_sc:
                best_sc = sc
                best = cand[:]
        # Occasionally try shrinking: drop an element if ratio improves.
        if random.random() < 0.05 and len(cur) > 100:
            j = random.randrange(len(cur))
            cand2 = cur[:j] + cur[j+1:]
            sc2 = _score(cand2)
            if sc2 > cur_sc:
                cur = cand2
                cur_sc = sc2
                if sc2 > best_sc:
                    best_sc = sc2
                    best = cand2[:]

    return sorted(set(best))
