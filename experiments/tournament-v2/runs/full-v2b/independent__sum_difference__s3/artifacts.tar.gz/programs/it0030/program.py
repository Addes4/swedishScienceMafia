import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _construct_base(t):
    # Base-B digit construction: choose elements with constrained digit patterns.
    # t = number of "positions". Use small digit sets to enlarge diffs, shrink sums.
    B = 2
    elems = set()
    # Use elements from a geometric-ish pattern with a perturbed sum set.
    # A classic trick: A = { 2^i } gives |A-A| huge, |A+A| small-ish (2n^2 but structured).
    # Improve by using sums that heavily collapse: choose A with A+A small via additive combinatorics.
    A = [0]
    for i in range(t):
        # append shifted copies to control sum set size
        A = A + [x + (3 ** i) for x in A] if i % 2 == 0 else [x for x in A] + [x + 2 * (3 ** i) for x in A]
    return A


def _smart_construct(n):
    # Build a set with many differences and few sums using a base representation.
    # Use digits in {0,1} across independent prime-like bases, but only 2-digit sums come from few carries.
    # A good family: A = { i * M + small } forms a near-arithmetic progression block union.
    # Sidon-like: powers of 2 maximize |A-A| relative to |A+A|.
    A = []
    x = 1
    for _ in range(n):
        A.append(x)
        x = x * 2 + 1  # gaps grow, differences stay distinct (Sidon-ish)
    return A


def _greedy_sidon(n, limit=1 << 60):
    # Greedy: pick numbers so that all pairwise sums are distinct where possible,
    # and differences dense.
    S = []
    used_sums = set()
    cand = 0
    cap = n * 8
    while len(S) < n and cand < limit:
        cand += 1
        ok = True
        new_sums = set()
        for y in S:
            s = cand + y
            if s in used_sums or s in new_sums:
                ok = False
                break
            new_sums.add(s)
        if ok:
            for y in S:
                used_sums.add(cand + y)
            used_sums.add(2 * cand)
            S.append(cand)
    return S


def _greedy_diffheavy(n):
    # Pick so that differences are unique as much as possible: Sidon set (all sums distinct)
    # tends to give all differences distinct too (Sidon => distinct differences).
    # But we want sums SMALL, so instead make many equal sums while differences unique:
    # use a set symmetric-ish / complement structure.
    # Construction: A = B union (-B)? Then sums collapse but differences stay large.
    half = max(1, n // 2)
    B = _greedy_sidon(half)
    off = 1 << 50
    A = [x - off for x in B] + [x + off for x in B]
    A = list(dict.fromkeys(A))
    return A


def _local_search(a, deadline, base_score):
    a = sorted(set(a))
    if len(a) < 2:
        return a, base_score
    best = a[:]
    best_score = base_score
    cur = a[:]
    cur_score = best_score
    iters = 0
    while time.time() < deadline:
        iters += 1
        cand = cur[:]
        r = random.random()
        if r < 0.6 and len(cand) >= 2:
            i = random.randrange(len(cand))
            span = max(1, (max(cand) - min(cand)) // max(len(cand), 2))
            delta = random.randint(-3, 3) * random.choice([1, 1, 2, span, span])
            cand[i] += delta if delta != 0 else 1
        elif r < 0.75:
            cand.append(random.randint(-(1 << 40), (1 << 40)))
        elif r < 0.9 and len(cand) > 3:
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            # merge / shift
            cand = [x + random.randint(-2, 2) for x in cand]

        cs = set(cand)
        if len(cs) != len(cand):
            cand = list(cs)
        if len(cand) < 2:
            continue
        try:
            s = _score(cand)
        except (ValueError, ZeroDivisionError):
            continue
        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.15:
            cur, cur_score = best[:], best_score
    return best, best_score


def solve():
    deadline = time.time() + 115
    best = None
    best_score = -1.0

    # Candidate constructions with varying sizes.
    for n in [4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128, 200, 300, 512, 1000, 2000, 3999]:
        candidates = []
        try:
            candidates.append(_smart_construct(n))
        except Exception:
            pass
        try:
            candidates.append(_greedy_sidon(min(n, 400)))
        except Exception:
            pass
        try:
            candidates.append(_greedy_diffheavy(n))
        except Exception:
            pass
        for c in candidates:
            c = sorted(set(c))
            if len(c) < 2 or len(c) > 4000:
                continue
            if max(abs(x) for x in c) > 10**15:
                # rescale/downshift
                m = max(abs(x) for x in c)
                c = [int(round(x * (10**15) / (m + 1))) for x in c]
                c = sorted(set(c))
            try:
                s = _score(c)
            except Exception:
                continue
            if s > best_score:
                best, best_score = c[:], s

    if best is None:
        best = [1, 2, 4, 8]
        best_score = _score(best)

    # Refine the best few constructions with local search.
    pool = [best]
    # Also take smaller promising ones.
    for n in [8, 16, 32, 64]:
        try:
            c = sorted(set(_smart_construct(n)))
            if len(c) >= 2 and len(c) <= 4000 and max(abs(x) for x in c) <= 10**15:
                pool.append(c)
        except Exception:
            pass
    for c in pool:
        remaining = deadline - time.time()
        if remaining <= 1:
            break
        cand, sc = _local_search(c, time.time() + remaining / max(1, len(pool)) * 0.9, _score(c))
        if sc > best_score:
            best, best_score = cand, sc

    # Ensure output validity.
    best = sorted(set(int(x) for x in best))
    if len(best) < 2:
        best = [1, 2]
    if len(best) > 4000:
        best = best[:4000]
    if max(abs(x) for x in best) > 10**15:
        m = max(abs(x) for x in best)
        best = sorted(set(int(round(x * (10**15) / (m + 1))) for x in best))
    return best
