import math
import random
import time


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return -1e9
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls <= 1:
        return -1e9
    return math.log(ld) / math.log(ls) + (1.0 - 1.0 / n) / 100.0


def _score_fast(a):
    """Faster scoring using arrays; still exact."""
    if len(a) < 2:
        return -1e9
    s = set(a)
    # compute sets via Python set comprehension for speed at moderate n
    diffs = {x - y for x in s for y in s}
    sums = {x + y for x in s for y in s}
    ld = len(diffs)
    ls = len(sums)
    if ls <= 1:
        return -1e9
    n = len(s)
    return math.log(ld) / math.log(ls) + (1.0 - 1.0 / n) / 100.0


def _move(cand, rng, max_val=10**9):
    cand = cand[:]
    r = rng.random()
    if r < 0.55 and len(cand) >= 2:
        i = rng.randrange(len(cand))
        scale = max(1, int(abs(cand[i]) * 0.05) + 1)
        cand[i] += rng.randint(-scale, scale)
    elif r < 0.8:
        cand.append(rng.randint(-max_val, max_val))
    elif r < 0.95 and len(cand) > 3:
        i = rng.randrange(len(cand))
        del cand[i]
    else:
        # perturb multiple elements
        for _ in range(rng.randint(1, 3)):
            if cand and rng.random() < 0.7:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-5, 5)
            else:
                cand.append(rng.randint(-max_val, max_val))
    # deduplicate
    return list(set(cand))


def _make_sidon_like(n, shift=1):
    """Construct a set with many differences: Sidon-like via quadratic residues mod large prime."""
    # Use a simple greedy Sidon set modulo a big prime, then map to integers.
    if n <= 1:
        return [0] * n
    # pick prime p
    p = max(10 * n * n, 101)
    while True:
        is_p = True
        d = 2
        while d * d <= p:
            if p % d == 0:
                is_p = False
                break
            d += 1
        if is_p:
            break
        p += 1
    # Singer/Bose style: quadratic residues modulo p can be Sidon mod p for some p
    # Simpler: greedy Sidon set in [0, p)
    sidon = []
    used_diffs = set()
    x = 0
    while len(sidon) < n:
        ok = True
        for y in sidon:
            diff = (x - y) % p
            neg = (y - x) % p
            if diff in used_diffs or neg in used_diffs:
                ok = False
                break
        if ok:
            for y in sidon:
                used_diffs.add((x - y) % p)
                used_diffs.add((y - x) % p)
            used_diffs.add(0)
            sidon.append(x)
        x += 1
        if x > p * 10:
            break
    return sidon


def _greedy_golomb(n):
    """Greedy Golomb ruler (moderate n): many distinct differences."""
    marks = [0]
    used = set()
    x = 1
    while len(marks) < n:
        ok = True
        new_diffs = set()
        for m in marks:
            d = abs(x - m)
            if d in used or d in new_diffs:
                ok = False
                break
            new_diffs.add(d)
        if ok:
            for d in new_diffs:
                used.add(d)
            marks.append(x)
        x += 1
    return marks


def solve():
    rng = random.Random(123456789)
    deadline = time.time() + 110
    best = []
    best_score = -1e9

    candidates = []

    # Construction 1: set of powers of 2 plus negatives: differences huge, sums relatively sparse
    n1 = 12
    c1 = [2**i for i in range(n1)]
    candidates.append(c1)

    # Construction 2: C = powers of 2 with negative half: B - B large, B+B small.
    c2 = []
    for i in range(14):
        c2.append(2**i)
        c2.append(-(2**i))
    candidates.append(c2)

    # Construction 3: shifted geometric with mixed signs
    c3 = [3**i for i in range(9)] + [-(3**j) for j in range(9)]
    candidates.append(c3)

    # Construction 4: Golomb ruler
    try:
        g = _greedy_golomb(40)
        candidates.append(g)
    except Exception:
        pass

    # Construction 5: Sidon-like modulo construction mapped to ints
    try:
        s = _make_sidon_like(60)
        candidates.append(s)
    except Exception:
        pass

    # Construction 6: random sparse set
    for _ in range(5):
        m = rng.randint(8, 30)
        candidates.append([rng.randint(-100, 100) for _ in range(m)])

    # Construction 7: exponential separated clusters
    c7 = []
    for i in range(20):
        base = 10**i
        c7.append(base)
        c7.append(-base)
    candidates.append(c7)

    for cand in candidates:
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc = _score_fast(cand)
        if sc > best_score:
            best = cand[:]
            best_score = sc

    # Local search on best
    cur = best[:]
    cur_score = best_score
    n_iter = 0
    while time.time() < deadline:
        n_iter += 1
        cand = _move(cur, rng, max_val=10**12)
        if len(cand) < 2 or len(cand) > 4000:
            continue
        sc = _score_fast(cand)
        if sc > cur_score or (sc == cur_score and len(cand) > len(cur)):
            cur = cand
            cur_score = sc
            if sc > best_score or (sc == best_score and len(cand) > len(best)):
                best = cand[:]
                best_score = sc
        elif rng.random() < 0.05:
            cur = cand
            cur_score = sc
        if rng.random() < 0.01:
            cur = best[:]
            cur_score = best_score

    # Try to improve best by refining small perturbations around it
    cur = best[:]
    cur_score = best_score
    local_deadline = time.time() + 5
    while time.time() < local_deadline:
        cand = cur[:]
        if cand and rng.random() < 0.8:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-2, 2)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc = _score_fast(cand)
        if sc >= cur_score:
            cur = cand
            cur_score = sc
            if sc > best_score or (sc == best_score and len(cand) > len(best)):
                best = cand[:]
                best_score = sc

    return sorted(set(best))[:4000]
