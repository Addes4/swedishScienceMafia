import math
import random
import time

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
    sums = set()
    for x in a:
        for y in a:
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100.0


def _build_bh(k, m):
    # B_h set: {sum of i-th powers of base m digits}, h=2 -> Sidon-like
    # Use simple Sidon construction: x_i = i + m*i*i for i in 0..k-1
    s = []
    for i in range(k):
        s.append(i + m * i * i)
    return s


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1e18

    # Try several structured constructions, then local-search refine.
    candidates = []

    # Perfect difference sets / Singer-like via quadratic residues scaled.
    # Build B_2 set with many elements, small doubling via sums clustered.
    for k in [30, 50, 80, 120, 200, 300, 500]:
        if k > 4000:
            continue
        m = 2 * k + 1
        s = _build_bh(k, m)
        candidates.append(s)

    # Intervals centered: sums range small but diffs large only if non-uniform.
    # Random Sidon greedy
    def greedy_sidon(n, bound):
        a = [0]
        used = {0}
        cand = 1
        while len(a) < n and cand < bound:
            ok = True
            for x in a:
                d = cand - x
                if d in used or d == 0:
                    ok = False
                    break
            if ok:
                for x in a:
                    used.add(cand - x)
                used.add(cand)
                a.append(cand)
            cand += 1
        return a

    s = greedy_sidon(300, 200000)
    if len(s) >= 20:
        candidates.append(s)

    # Set with arithmetic-like small sums: use A = B + B where B small? sums of A = 2B+2B larger.
    # Instead use concentration: A subset of small interval -> sums small range.
    for width in [50, 100, 200]:
        for n in [30, 60, 100]:
            if n > width:
                continue
            random.seed(width * 1000 + n)
            s = random.sample(range(width), n)
            candidates.append(s)

    for c in candidates:
        sc = _score(c)
        if sc > best_score:
            best_score = sc
            best = list(c)

    # local search refine
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.6 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-20, 20)
        elif op < 0.85:
            cand.append(random.randint(-500, 500))
        else:
            if len(cand) > 3:
                i = random.randrange(len(cand))
                cand.pop(i)
        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        sc = _score(cand)
        if sc > cur_score:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best_score = sc
                best = cand[:]
        elif random.random() < 0.02:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
