import math
import random
import time

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls < 2 or ld < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100

def solve():
    deadline = time.time() + 110
    
    best = None
    best_score = -1
    
    # Strategy 1: start from known good structured sets and do local search
    def local_search(start, time_limit):
        cur = list(set(start))
        cur_score = _score(cur)
        local_best = cur[:]
        local_best_score = cur_score
        end = time.time() + time_limit
        while time.time() < end:
            cand = cur[:]
            op = random.random()
            if op < 0.6 and len(cand) > 0:
                i = random.randrange(len(cand))
                delta = random.choice([-5,-4,-3,-2,-1,1,2,3,4,5])
                cand[i] += delta
            elif op < 0.8:
                # add a new element
                if len(cand) < 4000:
                    if cand:
                        base = random.choice(cand)
                    else:
                        base = 0
                    cand.append(base + random.randint(-30, 30))
            else:
                if len(cand) > 2:
                    i = random.randrange(len(cand))
                    cand.pop(i)
            cand = list(set(cand))
            s = _score(cand)
            if s >= cur_score:
                cur = cand
                cur_score = s
                if s > local_best_score:
                    local_best = cand[:]
                    local_best_score = s
            elif random.random() < 0.05:
                cur = local_best[:]
                cur_score = local_best_score
        return local_best, local_best_score
    
    # Try various starting points
    starts = []
    
    # Known good small set
    starts.append([7, 15, 18, 22, -3, -2])
    # random sets of various sizes
    for _ in range(5):
        n = random.randint(4, 10)
        starts.append([random.randint(-20, 20) for _ in range(n)])
    
    # Sets derived from restricting sums: use symmetric sets around 0
    # If A is symmetric (A = -A), then A+A is symmetric and |A+A| <= (|A|^2)/2+... 
    # Actually for symmetric sets, sums come in pairs, reducing size.
    # Try sets that are almost symmetric
    for _ in range(5):
        n = random.randint(4, 8)
        half = n // 2
        pos = random.sample(range(1, 50), half)
        s = pos + [-x for x in pos]
        if n % 2 == 1:
            s.append(0)
        starts.append(s)
    
    # A key idea: sets with a "small doubling" structure.
    # Bruijn / Sidon type. Try sets of form {a_i} where differences are unique -> |A-A|=n(n-1)+1 but sums also large.
    # For small sum, consider A = B U C with specific structure.
    
    # Main search loop
    while time.time() < deadline:
        remaining = deadline - time.time()
        if remaining <= 0:
            break
        if starts:
            st = starts.pop(0)
            tl = min(remaining, 15)
        else:
            # random start of random size
            n = random.randint(3, 12)
            st = [random.randint(-100, 100) for _ in range(n)]
            tl = min(remaining, 8)
        
        res, sc = local_search(st, tl)
        if sc > best_score:
            best_score = sc
            best = res[:]
        
        # Also try to expand best set
        if best is not None and len(best) < 4000 and time.time() < deadline:
            expanded = best[:]
            tl = min(deadline - time.time(), 10)
            if tl > 0:
                res2, sc2 = local_search(expanded, tl)
                if sc2 > best_score:
                    best_score = sc2
                    best = res2[:]
    
    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    
    return sorted(set(best))
