import math
import random
import time


def _stats(a):
    a = list(dict.fromkeys(a))
    n = len(a)
    if n < 2:
        return 0, 0, 0.0
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for y in a[i:]:
            diffs.add(x - y)
            diffs.add(y - x)
            sums.add(x + y)
    m = len(diffs)
    s = len(sums)
    if s <= 1 or m <= 0:
        return m, s, 0.0
    score = math.log(m) / math.log(s) + (1 - 1 / n) / 100
    return m, s, score


def _greedy_small_sum(rng, n, vals):
    # build set with as few distinct sums as possible by random greedy
    A = [rng.choice(vals)]
    seen_sums = {2 * A[0]}
    seen_diffs = {0}
    for _ in range(n - 1):
        best = None
        candidates = rng.sample(vals, min(len(vals), 40))
        for x in candidates:
            news = {x + y for y in A} | {2 * x}
            add = len(news - seen_sums)
            # prefer small sum growth, break ties by diff growth
            nd = len({x - y for y in A} | {y - x for y in A})
            key = (add, -nd)
            if best is None or key < best[0]:
                best = (key, x, news, nd)
        if best is None:
            break
        _, x, news, nd = best
        A.append(x)
        seen_sums |= news
        seen_diffs.add(nd)
    return A


def _sidon_like(rng, n, scale):
    # Sidon / B_2-ish via random greedy with mod constraint
    p = max(4 * n * n, 100)
    A = []
    used = set()
    tries = 0
    while len(A) < n and tries < 200000:
        tries += 1
        x = rng.randrange(p)
        if x in used:
            continue
        ok = True
        for a in A:
            d = (x - a) % p
            if d in used:
                ok = False
                break
        if ok:
            A.append(x)
            used.add(x)
    rng.shuffle(A)
    return A[:n]


def _dissociated(rng, n, maxv):
    # greedy dissociated: ensure all subset sums distinct (approx)
    A = []
    sums = {0}
    for _ in range(n):
        tries = 0
        while tries < 200:
            tries += 1
            x = rng.randint(-maxv, maxv)
            if x in A or x == 0:
                continue
            new = {s + x for s in sums} | sums
            if len(new) == len(sums) + len(sums):
                A.append(x)
                sums = new
                break
    return A


def _popcount_scaled(k, shift, offset):
    # bits of integers: powers-of-two-ish scaled
    return [(i + offset) * (1 << shift) for i in range(k)]


def _mixed(rng, n):
    A = set()
    maxv = 10 ** 15
    # powers of two plus random offsets
    for i in range(n // 3 + 1):
        A.add((1 << i) * (1 + rng.randint(0, 3)))
    while len(A) < n:
        A.add(rng.randint(-maxv, maxv))
    return list(A)


def _improve(A, deadline, best_score, best):
    rng = random.Random(987654321)
    n = len(A)
    # compute current
    m, s, sc = _stats(A)
    if sc > best_score:
        best_score, best = sc, A[:]
    cur = A[:]
    cur_score = sc
    cur_m, cur_s = m, s
    while time.time() < deadline:
        cand = cur[:]
        op = rng.random()
        if op < 0.6:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-2, 2) * max(1, abs(cand[i]) // 1000 or 1)
        elif op < 0.85:
            i = rng.randrange(len(cand))
            cand[i] = rng.randint(-10 ** 15, 10 ** 15)
        else:
            if len(cand) < 4000:
                cand.append(rng.randint(-10 ** 15, 10 ** 15))
        s = _score(cand)
        if s >= cur_score:
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best = cand[:]
        elif rng.random() < 0.05:
            cur = best[:]
            cur_score = best_score
    return best, best_score


def _score(a):
    _, _, sc = _stats(a)
    return sc


def solve():
    rng = random.Random(20240517)
    deadline = time.time() + 115
    best = None
    best_score = -1.0

    candidates = []

    # 1) dissociated-ish small sets
    for n in [8, 16, 32, 64, 128, 256]:
        for _ in range(3):
            A = _dissociated(rng, n, 200)
            candidates.append(A)

    # 2) sidon-like mod constructions
    for n in [16, 32, 64, 128]:
        for s in [1, 10, 100]:
            A = _sidon_like(rng, n, s)
            candidates.append(A)

    # 3) powers of two
    for k in [8, 16, 32, 64, 128]:
        candidates.append([(1 << i) for i in range(k)])

    # 4) scaled bitsets
    for k in [16, 32, 64]:
        for shift in [1, 2, 4, 8]:
            candidates.append(_popcount_scaled(k, shift, 0))

    # 5) mixed large
    for n in [16, 32, 64, 128, 256, 512, 1000, 2000]:
        candidates.append(_mixed(rng, n))

    # Evaluate
    best = [0, 1]
    best_score = _score(best)
    for A in candidates:
        if time.time() > deadline:
            break
        A = sorted(set(A))
        if len(A) < 2:
            continue
        sc = _score(A)
        if sc > best_score:
            best_score = sc
            best = A[:]

    # Local improvement on the best so far
    improved, iscore = _improve(best[:], min(deadline, time.time() + 60), best_score, best)
    if iscore > best_score:
        best_score = iscore
        best = improved

    # If time remains, try a hill-climb on a few random starts
    while time.time() < deadline:
        if rng.random() < 0.5:
            n = rng.randint(8, 300)
            A = _dissociated(rng, n, rng.randint(100, 1000))
        else:
            n = rng.randint(8, 300)
            A = _mixed(rng, n)
        A = sorted(set(A))
        sc = _score(A)
        if sc > best_score:
            best_score = sc
            best = A[:]

    result = sorted(set(int(x) for x in best))
    result = [x for x in result if abs(x) <= 10 ** 15]
    if len(result) < 2:
        result = [0, 1]
    if len(result) > 4000:
        result = result[:4000]
    return result
