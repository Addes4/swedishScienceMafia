import math
import random
import time


def _score_full(a):
    s = set(a)
    n = len(s)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in s:
        for y in s:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 110

    # ---- Candidate 1: Sidon-like greedy maximum difference growth ----
    # Build a set where differences are mostly unique (Sidon), and sums are few.
    # Classic trick: A = {2^i} gives |A+A| ~ n^2/2 and |A-A| ~ n^2 -> ratio ~ 1.
    # Better: use a near-arithmetic progression with controlled structure.
    #
    # Practical strong approach: A = interval union of a few shifts.

    best = None
    best_score = -1.0

    def try_set(a):
        nonlocal best, best_score
        a = sorted(set(int(x) for x in a))
        if len(a) < 2:
            return
        if abs(a[0]) > 10**15 or abs(a[-1]) > 10**15:
            return
        sc = _score_full(a)
        if sc > best_score:
            best_score = sc
            best = a[:]

    # Candidate: full interval [0, n-1] -> diffs ~ 2n-1, sums ~ 2n-1, ratio ~1
    # Need sparse but difference-rich.

    # Try intervals of form: {0..m-1} plus a few large offsets
    for m in [50, 100, 200, 400, 800, 1500, 2000]:
        for k, step in [(1, m), (2, m), (3, 2*m), (4, 3*m)]:
            base = list(range(m))
            for j in range(1, k+1):
                base += [j*step + i for i in range(min(m, max(1, m//2)))]
            try_set(base[:4000])

    # Candidate: Sidon set via greedy on [0, N]
    # Greedy: build set so all pairwise sums distinct -> |A+A| = n(n+1)/2, then |A-A|<= n^2.
    # But we want few sums. Opposite: build set so differences are distinct (Sidon is sum-distinct).
    # For few sums, want arithmetic-like structure.

    # Try: A = {i*B + i^2} -- tests
    for n in [100, 300, 600, 1000, 1500]:
        for B in [1, 3, 7, 15, 31, 100]:
            a = [i*B + i*i for i in range(n)]
            if len(a) <= 4000:
                try_set(a)

    # Try: prefix sums of distinct small values to create structure
    for n in [100, 300, 800, 1500, 2500]:
        for c in [0, 1, 2]:
            a = []
            cur = 0
            for i in range(n):
                a.append(cur)
                cur += i + 1 + c
            try_set(a)

    # Candidate: {i : i in [0,n)} union {i*K + random}
    # Direct search: start from interval and perturb

    if best is None:
        best = [0, 1, 2, 3]
        best_score = _score_full(best)

    # ---- Local search refinement ----
    random.seed(12345)
    cur = best[:]
    cur_score = best_score

    def rescore(a):
        return _score_full(a)

    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.4 and len(cand) > 2:
            # mutate an element
            i = random.randrange(len(cand))
            delta = random.choice([-2, -1, 1, 2, -5, 5, -10, 10])
            cand[i] += delta
        elif op < 0.6:
            # shift a contiguous block
            if len(cand) > 4:
                i = random.randrange(len(cand)-1)
                cand[i] += random.choice([-1, 1, -3, 3])
        elif op < 0.8 and len(cand) < 4000:
            # insert
            v = random.choice(cand) + random.randint(1, 20)
            cand.append(v)
        elif len(cand) > 3:
            # remove
            i = random.randrange(len(cand))
            cand.pop(i)

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        sc = rescore(cand)
        if sc > cur_score:
            cur_score = sc
            cur = cand
            if sc > best_score:
                best_score = sc
                best = cand[:]
        elif random.random() < 0.05:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
