import math
import random
import time


def _stats(a):
    n = len(a)
    if n < 2:
        return 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score(a):
    n = len(a)
    if n < 2:
        return -1e9
    d, s = _stats(a)
    if s <= 1:
        return -1e9
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0


def _candidate_ap(k, step=1, start=0):
    return [start + i * step for i in range(k)]


def _candidate_sidon_like(k):
    # Simple greedy Sidon-ish / B_2-like growth with large spread
    A = [0]
    step = 1
    while len(A) < k:
        A.append(A[-1] + step)
        step = step * 2 + 1
    return A


def _candidate_small_doubling(k):
    # Try intervals with holes to reduce sum-set size
    A = list(range(k))
    return A


def _candidate_gp(k, r=2):
    A = []
    x = 1
    for _ in range(k):
        A.append(x)
        x *= r
    return A


def _random_pool(n, lo, hi):
    return [random.randint(lo, hi) for _ in range(n)]


def _local_search(A, deadline, rng):
    A = list(dict.fromkeys(A))
    if len(A) < 2:
        A = [0, 1]
    best = A[:]
    best_score = _score(best)
    cur = best[:]
    cur_score = best_score

    while time.time() < deadline:
        mode = rng.random()
        cand = cur[:]

        if mode < 0.45 and cand:
            # perturb one element
            i = rng.randrange(len(cand))
            span = max(1, abs(cand[i]) // 4 + 3)
            cand[i] += rng.randint(-span, span)
        elif mode < 0.65 and len(cand) < 120:
            # add element
            if cand:
                base = rng.choice(cand)
                cand.append(base + rng.randint(-100, 100))
            else:
                cand.append(rng.randint(-100, 100))
        elif mode < 0.8 and len(cand) > 4:
            # remove element
            i = rng.randrange(len(cand))
            del cand[i]
        elif mode < 0.9:
            # shift whole set
            shift = rng.randint(-50, 50)
            cand = [x + shift for x in cand]
        else:
            # swap/add structured value
            if len(cand) < 200:
                cand.append(rng.randint(-1000, 1000))

        cand = list(dict.fromkeys(cand))
        if len(cand) < 2:
            continue

        s = _score(cand)
        if s > cur_score or (len(cand) <= 30 and rng.random() < 0.02):
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
        elif rng.random() < 0.15:
            cur = best[:]
            cur_score = best_score

    return best, best_score


def solve():
    rng = random.Random(123456789)
    deadline = time.time() + 110

    candidates = []
    for k in [6, 8, 10, 12, 16, 20, 24, 30, 40, 50, 64]:
        candidates.append(_candidate_ap(k, 1, 0))
        candidates.append(_candidate_ap(k, 2, 0))
        candidates.append(_candidate_ap(k, 3, 0))
        candidates.append(_candidate_small_doubling(k))
        candidates.append(_candidate_sidon_like(k))
        if k <= 20:
            candidates.append(_candidate_gp(k, 2))
            candidates.append(_candidate_gp(k, 3))
        for _ in range(5):
            candidates.append(_random_pool(k, -k * 3, k * 3))

    best_A = [0, 1]
    best_s = _score(best_A)

    for A in candidates:
        s = _score(A)
        if s > best_s:
            best_s = s
            best_A = A[:]

    # Run several local searches from strong seeds
    seeds = sorted(candidates, key=_score, reverse=True)[:12]
    for idx, seed in enumerate(seeds):
        if time.time() >= deadline:
            break
        local_deadline = min(deadline, time.time() + (deadline - time.time()) / max(1, len(seeds) - idx))
        A, s = _local_search(seed, local_deadline, rng)
        if s > best_s:
            best_s = s
            best_A = A[:]

    # Final polishing from the best set
    if time.time() < deadline:
        A, s = _local_search(best_A, deadline, rng)
        if s > best_s:
            best_s = s
            best_A = A[:]

    return sorted(dict.fromkeys(int(x) for x in best_A))
