import math
import random
import time

def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = set()
    sums = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def _score_parts(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    val = math.log(ld) / math.log(ls) + (1 - 1 / n) / 100
    return val, ld, ls

def solve():
    deadline = time.time() + 115

    def sidon_set(p):
        # Singer / modular Sidon set: {2*p*k + (k^2 mod p) : k in 0..p-1} scaled
        s = []
        for k in range(p):
            s.append(2 * p * k + (k * k) % p)
        return s

    best = None
    best_score = -1.0

    primes = [101, 211, 307, 401, 503, 601, 701, 809, 907, 1009, 1103, 1201, 1301, 1409, 1511, 1601, 1709, 1801, 1901, 2003]

    for p in primes:
        if time.time() > deadline:
            break
        A = sidon_set(p)
        A = A[:p]
        val, ld, ls = _score_parts(A)
        if val > best_score:
            best_score = val
            best = A[:]

    # Local search refinement on best so far
    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    cur = best[:]
    cur_score = best_score

    # Use smaller working sets after discovering good structure: try trimming
    def try_trim(A, target_n):
        A = sorted(set(A))
        if len(A) <= target_n:
            return A
        # greedy removal by keeping spread
        random.shuffle(A)
        A = sorted(A[:target_n])
        return A

    step = 0
    while time.time() < deadline:
        step += 1
        cand = cur[:]
        op = random.random()
        if op < 0.6:
            i = random.randrange(len(cand))
            shift = random.randint(-50, 50)
            cand[i] += shift
        elif op < 0.8:
            cand.append(random.randint(-1000, 1000))
        else:
            if len(cand) > 3:
                j = random.randrange(len(cand))
                cand.pop(j)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= cur_score:
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
        elif random.random() < 0.05:
            cur = best[:]
            cur_score = best_score

        # occasionally do a large restart from a sidon set with perturbation
        if step % 3000 == 0:
            p = random.choice(primes)
            A = sidon_set(p)
            random.shuffle(A)
            A = A[:random.randint(200, min(p, 2000))]
            for _ in range(5):
                if A:
                    k = random.randrange(len(A))
                    A[k] += random.randint(-100, 100)
            A = list(set(A))
            if len(A) >= 2:
                s = _score(A)
                if s > best_score:
                    best = A[:]
                    best_score = s
                if s > cur_score or random.random() < 0.3:
                    cur = A[:]
                    cur_score = s

    return sorted(set(best))
