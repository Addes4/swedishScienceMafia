import math
import random
import time


def _stats(a):
    s = sorted(set(a))
    n = len(s)
    if n < 2:
        return 0.0, 1, 1
    diffs = set()
    sums = set()
    for x in s:
        for y in s:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)


def _score(a):
    return _stats(a)[0]


def sidon_set(m):
    # Greedy Sidon set: no x+y = u+v nontrivially (all pair sums distinct)
    # Delivers |B+B| ~ n(n+1)/2, |B-B| = n(n-1)+1
    B = [0]
    used_sums = {0}
    used_diffs = {0}
    cand = 1
    while len(B) < m:
        ok = True
        for b in B:
            if (cand + b) in used_sums or (cand - b) in used_diffs or (b - cand) in used_diffs:
                ok = False
                break
        if ok:
            for b in B:
                used_sums.add(cand + b)
                used_diffs.add(cand - b)
                used_diffs.add(b - cand)
            used_sums.add(cand + cand)
            used_diffs.add(cand - cand)
            B.append(cand)
        cand += 1
    return B


def build_sidon(n):
    # Build a Sidon set of size ~n/2, then create A = B + c*B (doubling via Cantor-like)
    # Simpler: use Singer-like construction via greedy on scaled values.
    m = max(2, n // 2)
    B = sidon_set(m)
    # scale to reduce collisions when adding a second translated copy
    scale = 10 ** 6
    B = [b * scale for b in B]
    # A = B union (B + K) where K chosen so cross sums mostly distinct but sum count bounded
    K = B[-1] + scale
    A = B + [x + K for x in B]
    return A[:n]


def improve(a, deadline):
    a = sorted(set(a))
    best = a[:]
    best_s, _, _ = _stats(best)
    cur = best[:]
    step = 1
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.6 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * random.randint(1, 3) * step
        elif r < 0.8 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-100, 100)
        elif r < 0.9:
            cand.append(random.randint(-10**6, 10**6))
        else:
            if len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
        cand = sorted(set(cand))
        s, _, _ = _stats(cand)
        if s >= best_s:
            best, best_s, cur = cand[:], s, cand
        elif random.random() < 0.05:
            cur = best[:]
    return best


def solve():
    deadline = time.time() + 110
    n_var = 800
    a = build_sidon(n_var)
    a = improve(a, deadline - 5)
    # Also try a few different base sizes with remaining time
    while time.time() < deadline - 1:
        for trial_n in (200, 500, 1200, 2000):
            if time.time() >= deadline - 1:
                break
            b = build_sidon(trial_n)
            b = improve(b, min(deadline - 1, time.time() + 8))
            if _score(b) > _score(a):
                a = b
        if time.time() < deadline - 10:
            # small local polish around best
            a = improve(a, min(deadline - 1, time.time() + 15))
        else:
            break
    return a
