import math
import random
import time

def _score(a):
    if len(a) < 2:
        return -1e9
    aa = set(a)
    diffs = {x - y for x in aa for y in aa}
    sums = {x + y for x in aa for y in aa}
    if len(sums) <= 1:
        return -1e9
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(aa)) / 100.0

def _fast_score_components(a):
    # a: iterable of ints
    n = len(a)
    if n < 2:
        return 0, 0
    # For n <= 4000, direct sets are okay but we can optimize a bit.
    aa = list(set(a))
    diffs = set()
    sums = set()
    m = len(aa)
    for i in range(m):
        xi = aa[i]
        for j in range(i, m):
            xj = aa[j]
            diffs.add(xi - xj)
            diffs.add(xj - xi)
            sums.add(xi + xj)
    return len(diffs), len(sums)

def _score_fast(a):
    d, s = _fast_score_components(a)
    if s <= 1 or len(a) < 2:
        return -1e9
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100.0

def solve():
    random.seed(123456789)
    deadline = time.time() + 110.0

    # Candidate 1: arithmetic progression length ~1500 with large step.
    # Useful baseline: A = {c + k*d} gives |A-A| ~ 2n-1 and |A+A| ~ 2n-1.
    # Ratio ~ 1, not great. Need more differences than sums.

    # Candidate 2: union of two APs with incommensurate steps often gives larger difference set.
    # Let's build several structured seeds and refine.
    seeds = []

    # A classic trick: A = [0, n) union [n, large) etc? But sums can blow up.
    # Try "sum-free-ish" sets: A = {powers?} gives huge differences but also huge sums.
    # For ratio, we want |A-A| / |A+A| large. |A+A| >= 2n-1 always.
    # Max |A-A| <= n(n-1)+1. For n=1000, upper ratio log(1e6)/log(1999) ~ 6/3.3 ~ 1.8.
    # So aim near 1.8.

    # Build a "Sidon-like" set minimizes sum set? Actually Sidon sets have all sums distinct,
    # so |A+A| = n(n+1)/2 ~ n^2/2, bad. We want sums to collide.
    # AP gives max sum collisions but also max difference collisions.
    # Need asymmetric: differences all distinct, sums many collisions.
    # A set with all differences distinct is a Golomb ruler; |A-A| = n(n-1)+1.
    # If we can keep sums small, great. A Golomb ruler's sum set is typically also huge.
    # But maybe a "Golomb ruler" plus a translate can have many equal sums if symmetric.

    # Symmetric sets: if A is symmetric about 0, then a+b = c+d has many solutions.
    # A = {±1, ±2, ..., ±m} is AP both ways: differences 2m, sums 2m. Bad.
    # A = {± powers of 2}: differences are all signed differences of powers of 2.
    # Number of distinct differences: 2*(2^m-1)*? Actually differences of powers of two:
    # |2^i - 2^j| has 2^j(2^{i-j}-1), many collisions but many distinct too.
    # Sums of powers of 2: 2^i+2^j. If i≠j, sum is not a power of 2 generally,
    # and number of distinct sums is at most m(m+1)/2. Differences count might be similar.
    # Let's test small powers of 2.

    # Let's build candidate A = {0, 1, 3, 7, 15, ..., 2^k-1} ? Differences?
    # Differences of Mersenne numbers 2^i-1 minus 2^j-1 = 2^i-2^j.
    # So same as powers of 2 differences. Sums: 2^i+2^j-2.
    # Distinct sums count: for i<=j, 2^i+2^j-2. For i<j, many distinct (binary representation has two 1s).
    # For i=j, 2^{i+1}-2. So sums count ~ m(m-1)/2 + m.
    # Differences of powers of 2: |2^i-2^j| = 2^j(2^{i-j}-1).
    # For fixed gap k=i-j, values are 2^j(2^k-1) for j=0..m-1-k. These are distinct for different j
    # if 2^k-1 is odd, multiplication by 2^j shifts binary, so all distinct across (j,k).
    # Also sign. So number of nonzero differences = 2 * sum_{k=1}^{m-1} (m-k) = m(m-1).
    # Plus zero -> m(m-1)+1. So differences count = m(m-1)+1.
    # Sums count: sums of two powers of 2 (including equal): if i<j, 2^i+2^j has binary 1s at i,j,
    # so distinct for each pair. Count = C(m,2) + m = m(m+1)/2.
    # Ratio: log(m(m-1)+1) / log(m(m+1)/2). For large m, this tends to 1. Not good.

    # Need differences larger than sums. Differences of a set can be up to n(n-1)+1.
    # Sums are at least 2n-1. So we want differences near max, sums near min.
    # Can we have both? Differences near max means Golomb ruler.
    # Sums near min means many additive relations. That's contradictory but maybe partially.

    # A known construction: A = {a_i} where a_i are chosen so that differences are unique
    # but sums collide often. One idea: take A = B ∪ (B + t) where B is a Golomb ruler.
    # Then differences include differences within B (unique), within B+t (same), and cross differences.
    # Sums: b1+b2, (b1+t)+(b2+t) = b1+b2+2t, b1+(b2+t) = b1+b2+t.
    # If t is large, these three sum sets are disjoint. So sums ~ 3 * |B+B|.
    # Differences: within B: |B-B|; cross: (B+t)-B = t + (B-B), size |B-B|. Total ~ 3|B-B|? Actually union.
    # Differences size at most 3|B-B| but could be close to that. Ratio ~ 1 again.

    # Another: A = {0,1,...,n-1} ∪ {M, M+1, ..., M+n-1} with M large. Then |A+A| ~ 4n, |A-A| ~ 4n. Ratio 1.

    # Need a fundamentally different approach. Perhaps use computer search.
    # Let's do a heuristic: start with arithmetic progression, and perturb to increase differences
    # without increasing sums too much.

    # Actually known results: sets with |A+A| small relative to |A-A| exist, e.g., sets with
    # |A+A| = O(n) and |A-A| = Omega(n^2). Such sets exist (e.g., based on Freiman models).
    # But explicit small construction? We can search heuristically.

    # Try: A = {x_i} where x_i = i^2 mod p? Or quadratic residues.

    # Let's try random sets with many small elements to encourage sum collisions,
    # but spread out enough to have unique differences.
    # e.g., A = {0,1,2,...,k} ∪ {large values}.

    # Approach: use simulated annealing with incremental scoring.
    # But n=4000 and full recompute is O(n^2)=16M ops per score, too slow.
    # Use n smaller maybe 500-1000 for search, then maybe extend.

    # Let's start with n=200, search for high ratio.

    def full_score(a):
        aa = list(set(a))
        n = len(aa)
        if n < 2:
            return -1e9
        diffs = set()
        sums = set()
        for i in range(n):
            for j in range(i, n):
                diffs.add(aa[i]-aa[j])
                diffs.add(aa[j]-aa[i])
                sums.add(aa[i]+aa[j])
        if len(sums) <= 1:
            return -1e9
        return math.log(len(diffs))/math.log(len(sums)) + (1-1/n)/100.0

    # Heuristic: build set that is union of an arithmetic progression of small numbers
    # and a Golomb ruler of large numbers? Let's test small examples.
    # Actually, let's just do local search on n=100 with random restarts.

    best_A = None
    best_sc = -1e9

    # Initialize with arithmetic progression
    def init_ap(n, step=1):
        return [i*step for i in range(n)]

    # Try known good construction: A = {i*t : i=0..n-1} ∪ {i*t + 1 : ...}?
    # Let's try "two APs with different steps".
    # A = {i*a : i=0..n-1} ∪ {j*b : j=0..n-1}?
    # sums: i*a + j*a = (i+j)*a, many collisions; i*a+j*b etc.
    # differences: i*a - j*a = (i-j)*a, few. Bad.

    # Let me try a specific known construction: "Mian-Chowla sequence" (Golomb ruler) has large differences.
    # But sums?

    # Let's test small sets programmatically in this environment? We can't run external, but we can write code.

    # Let's just do a hill climb on n up to maybe 300 with time budget.

    n_target = 300
    # Random seed with small numbers to encourage sum collisions
    cur = sorted(random.sample(range(-500, 501), n_target))
    cur_sc = full_score(cur)
    if cur_sc > best_sc:
        best_sc = cur_sc
        best_A = cur[:]

    # Also try AP
    ap = init_ap(n_target, 1)
    ap_sc = full_score(ap)
    if ap_sc > best_sc:
        best_sc = ap_sc
        best_A = ap[:]

    # Also try powers of 2
    pow2 = [2**i for i in range(15)]  # n=15
    pow2_sc = full_score(pow2)
    if pow2_sc > best_sc:
        best_sc = pow2_sc
        best_A = pow2[:]

    # Local search
    start_time = time.time()
    iter_count = 0
    while time.time() < deadline * 0.8:
        iter_count += 1
        cand = cur[:]
        # mutate: change one element
        idx = random.randrange(len(cand))
        delta = random.randint(-20, 20)
        cand[idx] += delta
        if len(set(cand)) < len(cand):
            continue
        cand_sc = full_score(cand)
        if cand_sc > cur_sc or random.random() < 0.01:
            cur = cand
            cur_sc = cand_sc
        if cand_sc > best_sc:
            best_sc = cand_sc
            best_A = cand[:]

    # Now try to grow the best set.
    # Take best_A and add elements that don't increase sum set too much but increase difference set.
    if best_A is None:
        best_A = init_ap(100, 1)
        best_sc = full_score(best_A)

    # Try to extend by adding new elements from a large pool
    pool = list(range(-10000, 10001))
    random.shuffle(pool)

    current = sorted(set(best_A))
    current_sc = full_score(current)

    # Greedy add
    for candidate in pool:
        if len(current) >= 4000:
            break
        if candidate in current:
            continue
        new_set = current + [candidate]
        new_sc = full_score(new_set)
        if new_sc > current_sc:
            current = new_set
            current_sc = new_sc

    # Prune elements that don't help
    improved = True
    while improved and time.time() < deadline:
        improved = False
        i = 0
        while i < len(current):
            test = current[:i] + current[i+1:]
            if len(test) < 2:
                i += 1
                continue
            test_sc = full_score(test)
            if test_sc >= current_sc:
                current = test
                current_sc = test_sc
                improved = True
            else:
                i += 1

    # Final: if current has more elements and similar score, keep it.
    if len(current) >= 2:
        final_sc = full_score(current)
        if final_sc >= current_sc:
            best_A = current
        else:
            best_A = current

    return sorted(set(best_A))
