import math
import random
import time

# ---------------------------------------------------------------
# Scoring
# ---------------------------------------------------------------

def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls <= 0 or ld <= 0:
        return 0.0
    return math.log(ld) / math.log(ls) + (1.0 - 1.0 / n) / 100.0


# ---------------------------------------------------------------
# Candidate generator: digits of powers of a base.
# A = { sum d_i * B^i : digit vector in D }
# Differences: B^i*(d_i - e_i) dominated by highest nonzero index
#              -> number of distinct differences is around
#                 |D|^2 * something, but sums collide more.
# Actually we want FEW sums and MANY differences; a useful family is
# "all subsets" style / Moser-type.  We use random digit sets and
# local search, seeding with a good structured configuration.
# ---------------------------------------------------------------

def _build(base, digits_lists):
    # digits_lists: list over positions i of list of allowed digits (small ints)
    vals = [0]
    for i, ds in enumerate(digits_lists):
        p = base ** i
        nv = []
        for v in vals:
            for d in ds:
                nv.append(v + d * p)
        vals = nv
    return vals


def _random_search(deadline):
    best = None
    best_score = -1.0

    # seed: B = 2^k-like Sidon-ish set, gives ~2n-1 sums and ~n^2 diffs
    # powers of two: sums collide (2^i+2^j = 2^j+2^i) => n(n+1)/2 sums,
    # diffs also.  Better: use base larger than 2.
    # Try several bases & digit sets.
    trails = []

    # Structured: A = { sum_{i<m} d_i * B^i : d_i in {0..k-1} } random subsets
    n_target_choices = [6, 8, 10, 12, 14, 16, 20, 24, 30, 40, 60, 80,
                        120, 160, 220, 300, 400, 550, 700, 900]
    for nt in n_target_choices:
        trails.append(nt)

    idx = 0
    while time.time() < deadline:
        nt = random.choice(trails)
        # choose number of "digits" m and base B so that B^m ~ around nt values
        # We want |A| ~ nt.  Simple: build A as union of two constructions.
        m = random.randint(2, 7)
        B = random.randint(2, 9)
        # each position has a random small digit set
        dl = []
        cur_size = 1
        for i in range(m):
            k = random.randint(2, 5)
            ds = list(range(k))
            random.shuffle(ds)
            dl.append(ds)
            cur_size *= k
            if cur_size > 4 * nt:
                break
        A = _build(B, dl)
        if len(A) < 2:
            continue
        if len(A) > 800:
            # sample/subsample to nt
            A = random.sample(A, min(nt, len(A)))
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A[:]
            print("new best", best_score, "n=", len(best))

    return best, best_score


def _polish(A, deadline):
    A = sorted(set(A))
    if len(A) < 2:
        return A, _score(A)
    best = A[:]
    bs = _score(best)
    n = len(best)
    # discrete local search: try shifting elements
    while time.time() < deadline:
        improved = False
        # scale of movement based on spread
        spread = max(best) - min(best) if len(best) > 1 else 1
        step = max(1, spread // max(4, n))
        order = list(range(n))
        random.shuffle(order)
        for i in order:
            if time.time() > deadline:
                break
            cur = best[i]
            for delta in (step, -step, step // 2 + 1, -(step // 2 + 1), 1, -1):
                cand = best[:]
                cand[i] = cur + delta
                if len(set(cand)) < n:
                    continue
                s = _score(cand)
                if s > bs:
                    bs = s
                    best = cand
                    improved = True
                    break
            if improved:
                break
    return best, bs


def solve():
    deadline = time.time() + 110
    random.seed(12345)

    # Phase 1: structured random search
    A, s = _random_search(deadline - 25)

    # Phase 2: polish with local search
    if A is not None:
        A, s = _polish(A, deadline)

    if A is None:
        A = [7, 15, 18, 22, -3, -2]

    A = sorted(set(A))

    # enforce constraints
    if len(A) > 4000:
        A = A[:4000]
    A = [x for x in A if abs(x) <= 10**15]
    if len(set(A)) < 2:
        A = [7, 15, 18, 22, -3, -2]
    return sorted(set(A))


if __name__ == "__main__":
    print(solve())
