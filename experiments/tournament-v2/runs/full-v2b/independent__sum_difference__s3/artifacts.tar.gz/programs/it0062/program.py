import math
import random
import time

def _diffs_sums(a):
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return diffs, sums

def _score(a):
    if len(a) < 2:
        return 0.0
    diffs, sums = _diffs_sums(a)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def _score_fast(a):
    # fast incremental-ish score used during search with caching of sets
    if len(a) < 2:
        return 0.0
    diffs, sums = _diffs_sums(a)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def _greedy_sidon_style(n, scale=10**9):
    """Construct a set aiming to maximize differences while limiting sums:
    use a greedy construction on a Sidon-like sequence (distinct pairwise sums),
    which also tends to give near-maximal differences."""
    A = [0]
    used_sums = {0}
    # use candidate pool from a Sidon sequence generator (Mian-Chowla-like)
    # but here we want large differences too, so scan candidates.
    cand = 1
    while len(A) < n:
        ok = True
        # check distinct sums with existing
        for x in A:
            if x + cand in used_sums:
                ok = False
                break
        if ok:
            for x in A:
                used_sums.add(x + cand)
            used_sums.add(2 * cand)
            A.append(cand)
        cand += 1
        if cand > scale:
            break
    return A

def _random_sidon_like(n, limit, tries, rng):
    best = None
    best_score = -1
    for _ in range(tries):
        A = [0]
        used_sums = {0}
        cands = list(range(1, limit))
        rng.shuffle(cands)
        for c in cands:
            if len(A) >= n:
                break
            ok = True
            for x in A:
                if x + c in used_sums:
                    ok = False
                    break
            if ok:
                for x in A:
                    used_sums.add(x + c)
                used_sums.add(2 * c)
                A.append(c)
        if len(A) == n:
            s = _score(A)
            if s > best_score:
                best_score = s
                best = A[:]
    return best, best_score

def _local_search(A, deadline, rng):
    best = A[:]
    best_score = _score(best)
    cur = best[:]
    cur_score = best_score
    scale = max(1, max(abs(x) for x in cur)) if cur else 1
    while time.time() < deadline:
        cand = cur[:]
        op = rng.random()
        if op < 0.6 and len(cand) > 0:
            i = rng.randrange(len(cand))
            delta = rng.randint(-max(1, scale // 1000), max(1, scale // 1000))
            cand[i] += delta
            if cand[i] in cand[:i] + cand[i+1:]:
                continue
        elif op < 0.85:
            if len(cand) < 4000:
                cand.append(rng.randint(-scale, scale))
                if cand[-1] in cand[:-1]:
                    continue
        else:
            if len(cand) > 2:
                i = rng.randrange(len(cand))
                cand.pop(i)
        try:
            s = _score(cand)
        except Exception:
            continue
        if s > cur_score or (s == cur_score and rng.random() < 0.5):
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
        elif rng.random() < 0.02:
            cur = best[:]
            cur_score = best_score
    return best, best_score

def solve():
    rng = random.Random(12345)
    deadline = time.time() + 100
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Try several structured constructions of various sizes
    for n in [6, 8, 10, 12, 16, 20, 24, 30, 40, 50, 70, 100]:
        if time.time() > deadline - 10:
            break
        # Mian-Chowla style
        A = _greedy_sidon_style(n, scale=200000)
        if len(A) == n:
            s = _score(A)
            if s > best_score:
                best, best_score = A[:], s

    # Try random Sidon-like
    for n in [6, 8, 10, 12, 16, 20]:
        if time.time() > deadline - 10:
            break
        A, s = _random_sidon_like(n, limit=max(100, n*n*5), tries=2000, rng=rng)
        if A and s > best_score:
            best, best_score = A[:], s

    # Refine with local search
    cur_best, cur_score = best[:], best_score
    while time.time() < deadline:
        block_deadline = min(deadline, time.time() + 8)
        cand, sc = _local_search(cur_best, block_deadline, rng)
        if sc > cur_score:
            cur_best, cur_score = cand, sc
        else:
            # diversify by restarting from a new structured set
            n = rng.randint(6, 40)
            A, s = _random_sidon_like(n, limit=max(100, n*n*5), tries=200, rng=rng)
            if A and s > cur_score:
                cur_best, cur_score = A, s

    if cur_score > best_score:
        best, best_score = cur_best, cur_score

    # normalize distinct
    result = sorted(set(best))
    return result
