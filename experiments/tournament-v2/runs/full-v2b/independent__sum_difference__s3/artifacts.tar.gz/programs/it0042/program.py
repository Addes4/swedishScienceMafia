"""Sets with many differences and few sums.

Idea: sums of elements of a set A concentrate when A is close to a union of
arithmetic progressions with a common difference structure, while differences
stay numerous when the translations are spread out (a Sidon-like flavour).
We build A as M + d*{0..k-1} for a base set M (a "comb"), which makes sums
collapse heavily (since 0..k-1 has a small sum set but full difference set),
while keeping overall range bounded so |A-A| stays large. We then locally
optimize the base translations.
"""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    lst = list(a)
    diffs = set()
    sums = set()
    for i in range(n):
        xi = lst[i]
        for j in range(n):
            diffs.add(xi - lst[j])
            sums.add(xi + lst[j])
    base = math.log(len(diffs)) / math.log(len(sums))
    return base + (1 - 1 / n) / 100


def _full_score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    lst = list(a)
    diffs = set()
    sums = set()
    for i in range(n):
        xi = lst[i]
        for j in range(n):
            diffs.add(xi - lst[j])
            sums.add(xi + lst[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(translations, d, k):
    a = []
    for t in translations:
        for i in range(k):
            a.append(t + d * i)
    return sorted(set(a))


def _local_search(A, deadline, best_score_holder):
    cur = A[:]
    cur_score = _full_score(cur)
    if cur_score > best_score_holder[0]:
        best_score_holder[0] = cur_score
        best_score_holder[1] = cur[:]
    step = 1
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.6 and len(cand) > 0:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * random.randint(1, step)
        elif op < 0.75:
            cand.append(random.randint(-200, 200))
        elif op < 0.9 and len(cand) > 4:
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            if len(cand) >= 2:
                cand.sort()
                i = random.randrange(len(cand))
                cand[i] += random.randint(-step, step)
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 300:
            continue
        s = _full_score(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score_holder[0]:
                best_score_holder[0] = s
                best_score_holder[1] = cand[:]
        elif random.random() < 0.02:
            cur, cur_score = cand, s
        if random.random() < 0.01:
            step = 1 + (step % 8)
    return best_score_holder


def solve():
    deadline = time.time() + 110
    best = [0, 0]
    # Try several structured combs: translations spread out, APs with small d.
    for trial in range(60):
        if time.time() > deadline:
            break
        k = random.choice([2, 3, 4, 5, 6, 8, 10, 12, 16, 20])
        d = random.choice([1, 2, 3, 4, 5])
        m = random.randint(4, 40)
        span = random.choice([30, 60, 120, 250])
        translations = sorted(set(random.randint(-span, span) for _ in range(m)))
        if not translations:
            translations = [0]
        A = _build(translations, d, k)
        if len(A) < 2:
            continue
        holder = [0.0, A]
        _local_search(A, min(deadline, time.time() + 2.0), holder)
        if holder[0] > best[0]:
            best = holder
    # final polish on the best found
    holder = best[:]
    _local_search(best[1], deadline, holder)
    res = sorted(set(holder[1]))
    if len(res) < 2:
        res = [0, 1]
    return res
