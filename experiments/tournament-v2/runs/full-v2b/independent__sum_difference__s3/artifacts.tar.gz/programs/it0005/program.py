import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if not sums:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    random.seed(12345)
    deadline = time.time() + 110

    # --- good starting seeds ---
    seeds = []

    # 1) powers of 2 minus 1 (Mersenne-like)
    s = [0]
    for i in range(10):
        s.append((1 << i) - 1)
    seeds.append(sorted(set(s)))

    # 2) union of two arithmetic progressions
    for n in range(5, 25):
        a1 = list(range(n))
        M = n * n + 10
        a2 = [M + i for i in range(n)]
        seeds.append(a1 + a2)

    # 3) Stanley sequence S(0,1) prefix
    stan = [0, 1, 3, 4, 9, 10, 12, 13, 27, 28, 30, 31, 36, 37, 39, 40]
    seeds.append(stan[:])

    # 4) random sets
    for _ in range(20):
        n = random.randint(5, 30)
        seeds.append([random.randint(-100, 100) for _ in range(n)])

    # 5) arithmetic progressions with varying lengths and steps
    for n in range(5, 40):
        for step in [1, 2, 3, 5]:
            seeds.append([i * step for i in range(n)])

    best = None
    best_score = -1.0

    for seed in seeds:
        # deduplicate & sort
        cur = sorted(set(seed))
        if len(cur) < 2:
            continue
        cur_score = _score(cur)

        # --- simulated annealing ---
        T = 1.0
        cooling = 0.99995
        local_best = cur[:]
        local_best_score = cur_score
        # try to expand/shrink occasionally
        while time.time() < deadline and T > 1e-6:
            cand = local_best[:]
            r = random.random()
            # mutation types
            if r < 0.45:
                # move a random element
                if not cand:
                    continue
                i = random.randrange(len(cand))
                cand[i] += random.choice([-5, -3, -2, -1, 1, 2, 3, 5]) * random.randint(1, 10)
            elif r < 0.65:
                # add a random element
                cand.append(random.randint(-10000, 10000))
            elif r < 0.80:
                # remove an element
                if len(cand) > 2:
                    i = random.randrange(len(cand))
                    cand.pop(i)
            elif r < 0.92:
                # swap two elements' values
                if len(cand) >= 2:
                    i, j = random.sample(range(len(cand)), 2)
                    cand[i], cand[j] = cand[j], cand[i]
            else:
                # shift a whole block? just perturb a few elements
                for _ in range(random.randint(1, 3)):
                    if cand:
                        i = random.randrange(len(cand))
                        cand[i] += random.randint(-100, 100)

            # enforce distinctness and reasonable bounds
            cand = sorted(set(cand))
            if len(cand) < 2 or len(cand) > 4000:
                continue
            if max(abs(x) for x in cand) > 10**15:
                continue

            s = _score(cand)
            delta = s - local_best_score
            if delta > 0 or random.random() < math.exp(delta / T):
                local_best = cand[:]
                local_best_score = s

            T *= cooling

            # occasionally restart from best
            if T < 0.001:
                T = 1.0

        if local_best_score > best_score:
            best_score = local_best_score
            best = local_best[:]

    if best is None:
        best = [0, 1, 3, 7, 15, 31]

    # final polish: try a few small perturbations
    final = best[:]
    final_score = _score(final)
    for _ in range(2000):
        if time.time() > deadline:
            break
        cand = final[:]
        # small local move
        if random.random() < 0.5 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2, -1, 1, 2])
        else:
            cand.append(random.randint(-5000, 5000))
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        if max(abs(x) for x in cand) > 10**15:
            continue
        s = _score(cand)
        if s > final_score:
            final = cand[:]
            final_score = s

    return sorted(set(final))
