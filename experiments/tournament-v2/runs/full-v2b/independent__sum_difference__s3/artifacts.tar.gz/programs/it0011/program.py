import math
import random
import time


def _score_parts(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    r = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return r, len(diffs), len(sums)


def _score(a):
    return _score_parts(a)[0]


def solve():
    # Strategy: build A = { i*M + c_i } designed so that i+j collisions are common
    # while i-j are sparse. Use A = union of short blocks along a line is bad.
    # Better: use a "Sidon-like" set for differences but few sums via symmetry:
    # take A = { x : 0<=x<n } shifted? no, that's interval.
    #
    # Key idea: A = { i * B + r_i } with r_i small and B chosen so sums are confined.
    # If all a in [0, N), |A+A| ~ 2N and |A-A| ~ 2N too.
    #
    # To inflate |A-A| relative to |A+A|, want A convex-ish (differences spread)
    # but sums clustered. Sums cluster when A is symmetric around a point:
    # if A = c + S with S symmetric, sums are c*2 + (S+S) which is same size as S+S.
    # Differences |A-A| = |S-S|. So symmetric set gives same sizes in general.
    #
    # Alternative: A = B + x where B has small sumset (arithmetic prog) but we
    # perturb to blow up differences via Sidon-ish gaps.
    #
    # Practical best: use a set whose differences are nearly all distinct
    # (Sidon set) while making sums collide by choosing A as a finite union
    # of arithmetic progressions with same common difference d.
    # Union of APs with same d: sums also stay in a grid with diff d, so sumset
    # within a scaled integer grid; this can reduce |A+A| while |A-A| grows.
    #
    # Concretely: A = { i + d*j : i in I, j in J } (Minkowski sum of two small sets)
    # Then |A| = |I||J| but A+A = 2I + d*2J (product), A-A = (I-I) + d*(J-J).
    # So |A+A| <= |2I||2J| = (2|I|-1)(2|J|-1), |A-A| = (2|I|-1)(2|J|-1) too.
    # Same ratio ~ 2. Not great.
    #
    # We want |A| large but |A+A| small and |A-A| large: this is like a
    # "sum-collapsing" set. By Freiman-type reasoning, if |A+A| <= K|A| then A is
    # in a generalized AP, which limits |A-A|. But log-ratio can still exceed 1.
    # Known constructions: A = set of integers with small doubling have small
    # difference too roughly. But maximizing log|A-A|/log|A+A| can favor
    # sets where sums coincide in many ways.

    # Empirical approach: exhaustive/greedy randomized search with good score.
    # We'll try a structured multi-scale construction then hill-climb.

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    deadline = time.time() + 110

    # Try several structured starts.
    def make_candidates():
        cands = []

        # 1) Interval-ish with one hole
        for n in (30, 60, 100, 200, 400, 800, 1500, 2500, 3900):
            cands.append(list(range(n)))

        # 2) Arithmetic progression with common diff
        for n in (100, 400, 1000, 2000, 3900):
            for d in (2, 3, 5):
                cands.append([i * d for i in range(n)])

        # 3) Union of two intervals: [0,x) union [y, y+z)
        for x in (50, 200, 800):
            for y in (x, x + 1, x + 3, 2 * x):
                for z in (50, 200, 800):
                    cands.append(list(range(x)) + list(range(y, y + z)))

        # 4) B = I + d*J Minkowski
        for I in (list(range(40)), list(range(20))):
            for d in (10, 50, 200):
                for J in (list(range(30)), list(range(60))):
                    cands.append([i + d * j for i in I for j in J])

        # 5) Random small
        for _ in range(20):
            n = random.randint(50, 500)
            cands.append(sorted(random.sample(range(-2000, 2000), n)))

        return cands

    def score_fast(a):
        a = sorted(set(a))
        n = len(a)
        if n < 2:
            return 0.0
        diffs = set()
        sums = set()
        for x in a:
            for y in a:
                diffs.add(x - y)
                sums.add(x + y)
        if len(sums) < 2:
            return 0.0
        return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)

    # Evaluate candidates
    for cand in make_candidates():
        if len(cand) > 4000:
            continue
        try:
            s = _score(cand)
        except Exception:
            continue
        if s > best_score:
            best_score = s
            best = sorted(set(cand))

    # Local search with swap/move/insert/delete on best
    random.seed(12345)
    cur = best[:]
    cur_score = _score(cur)

    # Efficient-ish score for local moves: recompute fully (small enough)
    iters = 0
    while time.time() < deadline:
        iters += 1
        cand = cur[:]
        op = random.random()
        n = len(cand)
        if n == 0:
            cand = [random.randint(-1000, 1000)]
        elif op < 0.45:
            # move one element
            i = random.randrange(n)
            cand[i] += random.choice([-2, -1, 1, 2, -5, 5, -20, 20, -100, 100])
        elif op < 0.7:
            # swap two
            if n >= 2:
                i, j = random.sample(range(n), 2)
                cand[i], cand[j] = cand[j], cand[i]
        elif op < 0.85:
            # insert random
            if n < 3900:
                cand.append(random.randint(-5000, 5000))
        else:
            # delete
            if n > 2:
                cand.pop(random.randrange(n))

        # dedupe
        cand = sorted(set(cand))
        if not cand:
            continue
        if len(cand) > 3900:
            continue
        try:
            s = _score(cand)
        except Exception:
            continue
        if s >= cur_score or random.random() < 0.02:
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best = cand[:]

        # occasional restart from best
        if iters % 5000 == 0:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
