import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls < 2 or ld < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def _full(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums)


def _delta_score_insert(a, x):
    """Score change approximation when inserting x into set a (as sorted list)."""
    # exact incremental computation of |A-A| and |A+A|
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        diffs.add(ai - x)
        diffs.add(x - ai)
        sums.add(ai + x)
    # A-A and A+A of a alone
    da = set()
    sa = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            da.add(ai - a[j])
            sa.add(ai + a[j])
    st = a + [x]
    n2 = n + 1
    newd = set()
    news = set()
    for i in range(n2):
        for j in range(n2):
            newd.add(st[i] - st[j])
            news.add(st[i] + st[j])
    return len(newd), len(news)


def solve():
    random.seed(12345)
    deadline = time.time() + 110

    best = None
    best_score = -1.0

    # Try several structured seeds
    seeds = []

    # Sidon-ish: powers-ish small set
    seeds.append([0, 1, 3, 7, 12, 20, 30, 44, 65, 80])

    # Golomb ruler (optimal-ish) values
    seeds.append([0, 1, 4, 10, 18, 23, 25])

    # near AP with perturbation for small sum set
    n = 30
    seeds.append(list(range(n)))

    # B_2 set: numbers base representation
    seeds.append([2 * i for i in range(50)] + [1])

    def local_search(start, t_end):
        cur = sorted(set(start))
        cur_score = _score(cur)
        nonlocal best, best_score
        if cur_score > best_score:
            best, best_score = cur[:], cur_score

        step = 0
        while time.time() < t_end:
            step += 1
            mode = random.random()
            cand = cur[:]
            n = len(cand)
            if mode < 0.5 and n > 1:
                # move an element
                i = random.randrange(n)
                cand[i] += random.choice([-2, -1, 1, 2, -3, 3, -5, 5, -8, 8, -13, 13])
                if abs(cand[i]) > 10**15:
                    continue
            elif mode < 0.75 and n < 4000:
                # insert a new element
                base = random.choice(cand) if cand else 0
                cand.append(base + random.choice([-1, 1, 2, 3, -2, -3, 5, -5, 8, -8, 13, -13]))
                if abs(cand[-1]) > 10**15:
                    continue
            elif n > 3:
                # delete
                cand.pop(random.randrange(n))
            cand = sorted(set(cand))
            if not cand:
                continue
            s = _score(cand)
            if s >= cur_score:
                cur, cur_score = cand, s
                if s > best_score:
                    best, best_score = cand[:], s
            else:
                # anneal
                T = max(0.0001, 0.01 * (1 - step / 1000000.0))
                if random.random() < math.exp((s - cur_score) / T):
                    cur, cur_score = cand, s

    # First: quick evaluate seeds
    for sd in seeds:
        s = _score(sd)
        if s > best_score:
            best, best_score = sorted(set(sd)), s

    # Run local search repeatedly from best seeds
    while time.time() < deadline:
        start = best[:] if best else [0, 1, 2]
        # random perturbation restart
        start = [x + random.randint(-2, 2) for x in start]
        t_end = min(deadline, time.time() + 15)
        local_search(start, t_end)

    return sorted(set(best)) if best else [0, 1]
