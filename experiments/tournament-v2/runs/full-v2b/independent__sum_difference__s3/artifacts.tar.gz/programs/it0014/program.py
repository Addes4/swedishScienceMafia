import math
import random
import time


def _score_stats(a):
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    sums = set()
    diffs = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            sums.add(ai + aj)
            diffs.add(ai - aj)
    ls = len(sums)
    ld = len(diffs)
    sc = math.log(ld) / math.log(ls) + (1 - 1 / n) / 100
    return sc, ld, ls


def solve():
    deadline = time.time() + 110

    # Strong seed: powers of 2 -> all pair sums mostly distinct (small sum set),
    # differences also large. Add 0 to ensure self-differences and variety.
    seeds = []
    base = [0]
    for k in range(1, 13):
        base.append(2 ** k)
    seeds.append(base)

    # Another seed: powers of 3 (larger differences spread)
    b3 = [0]
    for k in range(1, 9):
        b3.append(3 ** k)
    seeds.append(b3)

    # Random small seed
    seeds.append(sorted(random.sample(range(-30, 30), 10)))

    best = None
    best_score = -1.0

    for s in seeds:
        sc, ld, ls = _score_stats(s)
        if sc > best_score:
            best_score = sc
            best = s[:]

    # Local search: try many candidate perturbations.
    cur = best[:]
    cur_score = best_score

    while time.time() < deadline:
        cand = cur[:]
        op = random.random()

        if op < 0.45 or len(cand) < 3:
            # mutate one element
            i = random.randrange(len(cand))
            # choose new value: either small step or random fresh value
            if random.random() < 0.7:
                cand[i] += random.randint(-5, 5)
            else:
                cand[i] = random.randint(-200, 200)
        elif op < 0.70:
            # add an element
            if len(cand) < 4000:
                cand.append(random.randint(-300, 300))
        elif op < 0.90:
            # remove an element
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        else:
            # shift all by constant (doesn't change score but moves search basin)
            shift = random.randint(-10, 10)
            cand = [x + shift for x in cand]

        # dedupe
        cand = list(set(cand))
        if len(cand) < 2:
            continue

        sc, ld, ls = _score_stats(cand)

        if sc >= cur_score or random.random() < 0.02:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best = cand[:]
                best_score = sc

        # occasional restart from best
        if random.random() < 0.005:
            cur = best[:]
            cur_score = best_score

    # Final prune: try removing elements that don't help ratio.
    improved = True
    while improved and time.time() < deadline:
        improved = False
        # Test removals only when set is small enough (keeps runtime bounded).
        if len(best) <= 200:
            base_sc = best_score
            i = 0
            n = len(best)
            while i < n and time.time() < deadline:
                trial = best[:i] + best[i + 1:]
                if len(trial) >= 2:
                    sc, _, _ = _score_stats(trial)
                    if sc >= base_sc:
                        best = trial
                        best_score = sc
                        improved = True
                        n -= 1
                        continue
                i += 1

    return sorted(set(best))
