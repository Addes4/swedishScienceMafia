import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _stats(a):
    a = set(a)
    if len(a) < 2:
        return 0, 0
    diffs = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
    sums = set()
    for x in a:
        for y in a:
            sums.add(x + y)
    return len(diffs), len(sums)


def _fast_score(a):
    n = len(a)
    if n < 2:
        return -1.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    nd = len(diffs)
    ns = len(sums)
    if ns <= 1:
        return -1.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns


def _greedy_ap_union(nblocks, blocklen, spacing_choices):
    """Try to build a union of APs where sums collapse a lot."""
    blocks = []
    used = set()
    for _ in range(nblocks):
        start = random.choice(spacing_choices)
        d = random.randint(1, 3)
        if random.random() < 0.5:
            d = 1
            start = random.randint(-50, 50)
        blk = [start + d * k for k in range(blocklen)]
        blocks.append(blk)
    a = []
    for b in blocks:
        a.extend(b)
    return sorted(set(a))


def _hill_climb(a, deadline):
    a = sorted(set(a))
    best = a[:]
    bs, _, _ = _fast_score(best)
    cur = best[:]
    cs = bs
    n = len(cur)
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.35 and len(cand) > 2:
            # shift an element
            i = random.randrange(len(cand))
            cand[i] += random.randint(-4, 4)
            cand = sorted(set(cand))
        elif r < 0.55:
            # add an element near existing
            base = random.choice(cand)
            cand.append(base + random.randint(-3, 3))
            cand = sorted(set(cand))
        elif r < 0.7 and len(cand) > 2:
            # remove
            i = random.randrange(len(cand))
            del cand[i]
        elif r < 0.85:
            # swap
            i = random.randrange(len(cand))
            cand[i] += random.choice([-5, -3, -1, 1, 3, 5])
            cand = sorted(set(cand))
        else:
            # compactify: move element toward mean
            i = random.randrange(len(cand))
            cand[i] = (cand[i] + random.choice(cand)) // 2
            cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s, _, _ = _fast_score(cand)
        if s >= cs or random.random() < 0.02:
            cur = cand
            cs = s
            if s > bs:
                best = cand[:]
                bs = s
        elif random.random() < 0.05:
            cur = best[:]
            cs = bs
    return best, bs


def _structured_all_equal_sums(pattern):
    """Build set from binary-ish pattern so many pairs collide in sums."""
    return sorted(set(pattern))


def solve():
    random.seed(12345)
    deadline = time.time() + 115

    best = None
    bs = -1.0

    # seed pool of constructions
    seeds = []

    # seed 1: original baseline
    seeds.append([7, 15, 18, 22, -3, -2])

    # seed 2: arithmetic progression (sums small -> many collisions)
    seeds.append(list(range(0, 12)))

    # seed 3: two APs
    seeds.append(list(range(0, 8)) + list(range(100, 108)))

    # seed 4: near-Golomb (large difference set)
    seeds.append([0, 1, 4, 10, 18, 23, 25])

    # seed 5: small random
    seeds.append(sorted(random.sample(range(-30, 30), 8)))

    # seed 6: symmetric around 0
    seeds.append([-9, -7, -3, -1, 1, 3, 7, 9])

    # seed 7: union of APs with step 1 - compact
    seeds.append(list(range(-20, 20, 1))[:15])

    # seed 8:multiset-like small differences
    seeds.append([0, 1, 2, 3, 4, 5, 100, 101, 102, 103])

    for sd in seeds:
        s, _, _ = _fast_score(sorted(set(sd)))
        if s > bs:
            bs = s
            best = sorted(set(sd))

    # Run hill climbing on many restart points
    attempts = 0
    while time.time() < deadline - 2:
        attempts += 1
        # pick a seed type
        typ = random.random()
        if typ < 0.25:
            base = list(range(random.randint(-20, 0), random.randint(3, 15)))
            if random.random() < 0.5:
                base = base + list(range(random.randint(50, 80), random.randint(85, 110)))
        elif typ < 0.5:
            n = random.randint(5, 25)
            base = sorted(random.sample(range(-100, 100), min(n, 199)))
        elif typ < 0.7:
            nb = random.randint(2, 5)
            bl = random.randint(3, 8)
            base = _greedy_ap_union(nb, bl, list(range(-30, 31, 3)))
        elif typ < 0.85:
            base = sorted(random.sample(range(-10, 10), random.randint(4, 12)))
        else:
            base = best[:] if best else [0, 1, 3]

        remaining = deadline - time.time()
        if remaining <= 1:
            break
        sub_deadline = time.time() + max(1, min(8, remaining))
        cand, cs = _hill_climb(base, sub_deadline)
        if cs > bs:
            bs = cs
            best = cand[:]

    if best is None:
        best = [0, 1]

    # final polish with full remaining time
    if time.time() < deadline:
        cand, cs = _hill_climb(best, deadline)
        if cs > bs:
            bs = cs
            best = cand

    return sorted(set(best))
