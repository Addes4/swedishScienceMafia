import math
import random
import time


def _metrics(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0, 0, 0.0
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for j, y in enumerate(a):
            diffs.add(x - y)
            sums.add(x + y)
    ld = len(diffs)
    ls = len(sums)
    if ls <= 0:
        return ld, ls, 0.0
    score = math.log(ld) / math.log(ls) + (1 - 1 / n) / 100
    return ld, ls, score


def _score(a):
    return _metrics(a)[2]


def _make_structured(n):
    """
    Heuristic construction:
    Use two blocks with very different scales.
    Small block controls sum set through its small span.
    Large block contributes many differences.
    """
    if n < 6:
        return [0, 1, 3, 7, 12, 20][:n]

    # Split sizes: sums benefit from one small dense block, differences from one large sparse block.
    n2 = max(2, n // 4)
    n1 = max(2, n // 3)
    n3 = max(0, n - n1 - n2)

    A = []

    # Block 1: dense small interval around 0. Keeps sums tight.
    start = -n1 // 2
    A.extend(range(start, start + n1))

    # Block 2: Sidon-like / Golomb-like moderate block using greedy differences.
    used_diffs = set()
    b2 = []
    # seed
    seed = 100
    b2.append(seed)
    cand = seed + 1
    limit = 200000
    while len(b2) < n2 and cand <= limit:
        ok = True
        for x in b2:
            d = abs(cand - x)
            if d in used_diffs:
                ok = False
                break
        if ok:
            for x in b2:
                used_diffs.add(abs(cand - x))
            b2.append(cand)
        cand += 1
    A.extend(b2)

    # Block 3: far separated block, multiples of a large step.
    if n3 > 0:
        base = 1000000
        step = 97
        A.extend(base + step * i for i in range(n3))

    return sorted(set(A))


def _local_improve(a, deadline):
    a = list(set(a))
    best = a[:]
    _, _, best_score = _metrics(best)

    # Precompute interval for mutation scale based on current diameter.
    cur = best[:]
    cur_score = best_score

    while time.time() < deadline:
        cand = cur[:]

        op = random.random()
        if op < 0.45:
            # shift one element by a modest amount
            i = random.randrange(len(cand))
            span = max(1, max(cand) - min(cand))
            scale = max(1, span // max(10, len(cand) * 2))
            cand[i] += random.randint(-scale, scale)
        elif op < 0.75:
            # add a new element near existing structure or in a useful gap
            if len(cand) < 4000:
                if random.random() < 0.7:
                    x = random.choice(cand)
                    span = max(1, max(cand) - min(cand))
                    cand.append(x + random.randint(-max(2, span // 20), max(2, span // 20)))
                else:
                    cand.append(random.randint(-2000, 2000))
        elif op < 0.9:
            # remove an element
            if len(cand) > 5:
                i = random.randrange(len(cand))
                cand.pop(i)
        else:
            # swap: remove and add
            if len(cand) > 5:
                cand.pop(random.randrange(len(cand)))
            cand.append(random.randint(-5000, 5000))

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue

        _, _, sc = _metrics(cand)

        if sc >= cur_score:
            cur = cand[:]
            cur_score = sc
            if sc > best_score:
                best = cand[:]
                best_score = sc
        elif random.random() < 0.05:
            cur = cand[:]
            cur_score = sc

    return best, best_score


def solve():
    """Return A maximizing log|A-A|/log|A+A| with a small size bonus."""
    random.seed(1234567)
    deadline = time.time() + 112

    candidates = []

    # Good known-ish small/special sets.
    candidates.append([3, 5, 9, 16, 22, 31])  # Golomb-ish
    candidates.append([0, 1, 4, 9, 15, 22, 34])
    candidates.append([0, 1, 3, 7, 12, 20, 30, 44])

    # Structured candidates of several sizes.
    for n in [8, 10, 12, 16, 20, 24, 30, 40, 50, 64, 80, 100]:
        candidates.append(_make_structured(n))

    best = None
    best_score = -1.0

    for c in candidates:
        c = sorted(set(c))
        if len(c) >= 2:
            sc = _score(c)
            if sc > best_score:
                best = c[:]
                best_score = sc

    # Focus local search; restart from current best and a few structured variants.
    attempts = 0
    while time.time() < deadline:
        attempts += 1
        if best is None:
            cur = _make_structured(random.choice([10, 16, 24, 32, 48, 64]))
        else:
            cur = best[:]
            # Occasionally perturb strongly to escape local optima.
            if attempts % 4 == 0:
                for _ in range(random.randint(1, 5)):
                    if len(cur) < 4000:
                        cur.append(random.randint(-10000, 10000))
                cur = sorted(set(cur))
            else:
                # minor perturbation
                if cur:
                    i = random.randrange(len(cur))
                    cur[i] += random.randint(-10, 10)
                cur = sorted(set(cur))

        improved, sc = _local_improve(cur, min(deadline, time.time() + 8))
        if sc > best_score:
            best = improved[:]
            best_score = sc

    if best is None:
        best = [7, 15, 18, 22, -3, -2]

    # Final cleanup.
    best = sorted(set(best))
    if len(best) < 2:
        best = [0, 1]

    return best
