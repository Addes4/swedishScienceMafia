import math
import random
import time

MAXN = 4000
ABS_LIMIT = 10**15


def _bits_to_list(bits):
    # bits is a Python int with bit i set meaning value i present (after shifting)
    return bits


def _score_from_counts_bf(counts):
    """Given dict mapping shift -> count, return log(|A-A|)/log(|A+A|)."""
    if not counts:
        return 0.0
    n = sum(counts.values())
    if n < 2:
        return 0.0
    # difference set size
    diff_sizes = {}
    keys = list(counts.keys())
    for i in range(len(keys)):
        k1 = keys[i]
        c1 = counts[k1]
        # self pairs handled below
        for j in range(i, len(keys)):
            k2 = keys[j]
            c2 = counts[k2]
            if i == j:
                if c1 >= 2:
                    d = 0
                    diff_sizes[d] = diff_sizes.get(d, 0) + 1
            else:
                diff_sizes[k1 - k2] = 1
    # sum set size
    sum_keys = {}
    for i in range(len(keys)):
        for j in range(i, len(keys)):
            s = keys[i] + keys[j]
            sum_keys[s] = 1
    ds = len(diff_sizes)
    ss = len(sum_keys)
    if ss <= 1 or ds <= 1:
        return 0.0
    return math.log(ds) / math.log(ss) + (1 - 1 / n) / 100


def _score_exact(A):
    A = set(A)
    n = len(A)
    if n < 2:
        return 0.0
    diffs = {x - y for x in A for y in A}
    sums = {x + y for x in A for y in A}
    if len(sums) <= 1 or len(diffs) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _eval_set(A):
    if not A:
        return 0.0
    n = len(A)
    if n < 2:
        return 0.0
    # Use sets for exactness
    diffs = set()
    sums = set()
    for x in A:
        for y in A:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) <= 1 or len(diffs) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _make_golomb_like(n, seed=0, spread=None):
    """Sidon-ish random set - large differences."""
    rng = random.Random(seed)
    A = set()
    if spread is None:
        spread = 4 * n * n
    tries = 0
    while len(A) < n and tries < 20 * n * n:
        tries += 1
        x = rng.randint(-spread, spread)
        # check Sidon condition loosely
        ok = True
        for a in A:
            if x - a in A or a - x in A:
                ok = False
                break
        if ok:
            A.add(x)
    return A


def _construct_freiman(n):
    """Freiman-style: union of short arithmetic progressions sharing a common difference.
    A = { i*d + r_j : i in [0,k-1], j in [0,m-1] } with careful r_j so sums collapse."""
    # choose m clusters of size k, m*k ≈ n
    best = None
    best_s = -1.0
    for k in [2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 32, 40, 50, 60, 80, 100]:
        m = max(1, n // k)
        if m * k > n:
            m = n // k
        if m < 2:
            continue
        # Build clusters with offsets r_j forming a Sidon set themselves (so sums are distinct
        # enough while diffs between clusters give many distinct differences)
        # Try several random offset sets
        for trial in range(30):
            rng = random.Random(k * 1000 + trial)
            rs = []
            used = set()
            span = 6 * m * m
            attempts = 0
            while len(rs) < m and attempts < 200 * m:
                attempts += 1
                r = rng.randint(0, span)
                # Sidon-like condition on offsets
                ok = True
                for a in rs:
                    d = r - a
                    if d in used:
                        ok = False
                        break
                if ok:
                    rs.append(r)
                    for a in rs[:-1]:
                        used.add(r - a)
                        used.add(a - r)
            if len(rs) < m:
                continue
            base = max(rs) if rs else 0
            d = base + 1
            A = set()
            for r in rs:
                for i in range(k):
                    v = r + i * d
                    A.add(v)
            if len(A) < 2:
                continue
            s = _eval_set(A)
            if s > best_s:
                best_s = s
                best = A
    return best


def _local_search(A, deadline):
    A = set(A)
    best = set(A)
    best_s = _eval_set(A)
    n = len(A)
    if n < 2:
        return best
    rng = random.Random(12345)
    it = 0
    while time.time() < deadline:
        it += 1
        if it % 50 == 0:
            # re-evaluate current best occasionally
            pass
        cur = set(best)
        # mutate: shift one element
        op = rng.random()
        if op < 0.7:
            if not cur:
                continue
            e = rng.choice(list(cur))
            cur.discard(e)
            delta = rng.randint(-10, 10)
            ne = e + delta
            if abs(ne) <= ABS_LIMIT:
                cur.add(ne)
        elif op < 0.9:
            if not cur:
                continue
            e = rng.choice(list(cur))
            cur.discard(e)
            # snap to nearby gap
            if cur:
                cand = rng.choice(list(cur))
                for k in range(1, 8):
                    if rng.random() < 0.5:
                        ne = cand - k
                    else:
                        ne = cand + k
                    if ne not in cur and abs(ne) <= ABS_LIMIT:
                        cur.add(ne)
                        break
        else:
            # random new element near current span
            if cur:
                lo = min(cur)
                hi = max(cur)
                span = hi - lo + 1
                ne = rng.randint(lo - span // 2, hi + span // 2)
                if ne not in cur and abs(ne) <= ABS_LIMIT and len(cur) < MAXN:
                    cur.add(ne)
        if len(cur) < 2 or len(cur) > MAXN:
            continue
        s = _eval_set(cur)
        if s >= best_s:
            best_s = s
            best = cur
    return best


def solve():
    deadline = time.time() + 110
    candidates = []

    # Seed candidates
    # 1. Freiman-style constructions
    for n in [50, 100, 150, 200, 300, 400, 500, 600, 800, 1000]:
        if time.time() > deadline - 60:
            break
        for k in [3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 32, 40, 50, 64, 80, 100, 128]:
            m = n // k
            if m < 2:
                continue
            # offsets forming Sidon-like set, clusters of length k
            # Try a construction: r_j = j * k (so sums r_j + r_l = (j+l)*k, few values)
            # Actually that concentrates sums strongly.
            for mult in [1, 2, 3]:
                rs = [j * mult for j in range(m)]
                # choose step d big enough so clusters don't overlap
                d = (max(rs) + 1) * mult + 1
                A = set()
                for r in rs:
                    for i in range(k):
                        A.add(r * d + i)
                if len(A) >= 2:
                    candidates.append(A)
        # 2. random Sidon-ish
        A = _make_golomb_like(n, seed=n * 7 + 1, spread=3 * n * n)
        if len(A) >= 2:
            candidates.append(A)

    # Additional highly structured: A = S + {0..k-1} where S is Sidon set
    for n in [100, 200, 300, 500, 700, 1000, 1500, 2000]:
        if time.time() > deadline - 70:
            break
        for k in [2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 32, 40, 50, 64, 80, 100]:
            m = n // k
            if m < 2:
                continue
            # S: arithmetic progression with large step, then scale to prevent overlap
            # Use r_j = j * L with L large
            L = 1000003  # large prime-like
            A = set()
            for j in range(m):
                for i in range(k):
                    A.add(j * L + i)
            if len(A) >= 2:
                candidates.append(A)
        # another: S random small, scaled
        rng = random.Random(n)
        m = max(2, n // 4)
        S = set()
        while len(S) < m:
            S.add(rng.randint(0, 10 * m * m))
        k = 4
        L = max(S) * 10 + 1000
        A = set()
        for r in S:
            for i in range(k):
                A.add(r * L + i)
        if len(A) >= 2:
            candidates.append(A)

    # Evaluate and keep best
    best = None
    best_s = -1.0
    for A in candidates:
        if time.time() > deadline:
            break
        if len(A) < 2:
            continue
        s = _eval_set(A)
        if s > best_s:
            best_s = s
            best = set(A)

    if best is None:
        best = set([0, 1, 3, 7, 12])
        best_s = _eval_set(best)

    # Local search on the best few
    # Sort candidates by score approximately using smaller sample
    scored = []
    for A in candidates[:400]:
        if time.time() > deadline - 40:
            break
        if len(A) < 2:
            continue
        s = _eval_set(A)
        scored.append((s, A))
    scored.sort(key=lambda t: -t[0])
    for s, A in scored[:8]:
        if time.time() > deadline - 20:
            break
        improved = _local_search(A, min(deadline - 5, time.time() + 15))
        si = _eval_set(improved)
        if si > best_s:
            best_s = si
            best = improved

    # Final local search on best
    if time.time() < deadline:
        improved = _local_search(best, deadline - 2)
        si = _eval_set(improved)
        if si > best_s:
            best_s = si
            best = improved

    return sorted(best)
