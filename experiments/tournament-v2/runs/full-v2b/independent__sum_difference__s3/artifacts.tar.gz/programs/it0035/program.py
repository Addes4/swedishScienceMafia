import math
import random
import time


def _score(a, return_parts=False):
    a = list(set(a))
    if len(a) < 2:
        return (0.0, 0, 0) if return_parts else 0.0
    diffs = set()
    sums = set()
    for i in range(len(a)):
        ai = a[i]
        for j in range(len(a)):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    nd = len(diffs)
    ns = len(sums)
    if ns < 2:
        s = 0.0
    else:
        s = math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100
    return (s, nd, ns) if return_parts else s


# ---- Bose-Chowla construction of Sidon sets mod p^2-1 ----
def bose_chowla(p):
    """Return a Sidon set modulo q = p^2 - 1, where p is prime power.
    Uses Bose's construction in GF(p^2)."""
    q = p * p - 1
    # Represent GF(p^2) as GF(p)[x]/(x^2 - g) where g is a non-residue.
    # Find a primitive element of GF(p^2)* and use theta in GF(p^2) with
    # theta^2 = primitive element; then B = {t in [1,q] : theta^t - theta in GF(p)}
    # gives a Sidon set mod q.

    # Find non-residue g in GF(p)
    def is_prim_root_mod_p(a, p):
        # order of a mod p equals p-1
        if a % p == 0:
            return False
        order = p - 1
        # factor order
        n = order
        fac = []
        d = 2
        while d * d <= n:
            if n % d == 0:
                fac.append(d)
                while n % d == 0:
                    n //= d
            d += 1
        if n > 1:
            fac.append(n)
        for f in fac:
            if pow(a, order // f, p) == 1:
                return False
        return True

    g = 1
    while True:
        if not is_prim_root_mod_p(g, p):
            # check it's a non-residue
            if pow(g, (p - 1) // 2, p) == p - 1:
                break
        g += 1
    # g is a non-residue mod p, use GF(p^2) = GF(p)[x]/(x^2 - g)
    # Element represented as (a, b) meaning a + b*x

    def mul(u, v):
        a, b = u
        c, d = v
        # (a+bx)(c+dx) = ac + bd*x^2 + (ad+bc)x = ac + bd*g + (ad+bc)x
        return ((a * c + b * d * g) % p, (a * d + b * c) % p)

    def is_prim(u):
        order = p * p - 1
        n = order
        fac = set()
        d = 2
        while d * d <= n:
            if n % d == 0:
                fac.add(d)
                while n % d == 0:
                    n //= d
            d += 1
        if n > 1:
            fac.add(n)
        for f in fac:
            # u^(order/f) != 1 ?
            e = order // f
            r = (1, 0)
            base = u
            while e:
                if e & 1:
                    r = mul(r, base)
                base = mul(base, base)
                e >>= 1
            if r == (1, 0):
                return False
        return True

    # find primitive element theta
    theta = None
    for a in range(p):
        for b in range(p):
            if a == 0 and b == 0:
                continue
            if is_prim((a, b)):
                theta = (a, b)
                break
        if theta:
            break

    # theta^{-1}
    # compute powers theta^t for t=1..q, find those where theta^t - theta in GF(p)
    # In GF(p^2), theta^t - theta in GF(p) means the x-coefficient is 0.
    B = []
    cur = (1, 0)
    inv_theta = None
    # compute theta^{-1} via Fermat: theta^{q-1}
    e = q - 1
    inv_theta = (1, 0)
    base = theta
    while e:
        if e & 1:
            inv_theta = mul(inv_theta, base)
        base = mul(base, base)
        e >>= 1

    for t in range(1, q + 1):
        cur = mul(cur, theta)
        diff = ((cur[0] - theta[0]) % p, (cur[1] - theta[1]) % p)
        if diff[1] == 0:
            B.append(t % q)

    return B, q


def small_primes():
    ps = []
    for n in range(2, 200):
        ok = True
        for d in range(2, int(n ** 0.5) + 1):
            if n % d == 0:
                ok = False
                break
        if ok:
            ps.append(n)
    return ps


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Try Bose-Chowla Sidon sets of various sizes, searching over prime moduli.
    ps = small_primes()
    candidates = []
    for p in ps:
        if p < 3:
            continue
        q = p * p - 1
        if q > 3900:
            continue
        try:
            B, qq = bose_chowla(p)
        except Exception:
            continue
        candidates.append((p, q, B))

    # Evaluate each candidate as a regular integer set (all elements in [0, q-1])
    for p, q, B in candidates:
        A = sorted(set(B))
        if len(A) < 2:
            continue
        s, nd, ns = _score(A, return_parts=True)
        if s > best_score:
            best_score = s
            best = A[:]

    # Also try shifting/scaling Bose sets to see if we can improve ratio.
    # A Sidon set in Z_q: differences are mostly distinct mod q.
    # Lift to integers in [0,q-1]: differences may coincide as integers too.
    # Standard trick: use A = B (elements 0..q-1), ratio ~ log(q^2)/log(q^2/2) ~ 2.

    # Random search on top of best Bose set to tweak.
    if best is not None:
        cur = best[:]
        while time.time() < deadline:
            cand = cur[:]
            op = random.random()
            if op < 0.6 and cand:
                i = random.randrange(len(cand))
                cand[i] += random.randint(-2, 2)
            elif op < 0.8:
                cand.append(random.randint(0, max(cand) + 5 if cand else 5))
            else:
                if len(cand) > 2:
                    cand.pop(random.randrange(len(cand)))
            cand = list(set(cand))
            if len(cand) < 2:
                continue
            s, nd, ns = _score(cand, return_parts=True)
            if s > best_score:
                best_score = s
                best = cand[:]
                cur = cand[:]
            elif random.random() < 0.05:
                cur = best[:]

    # Final: also consider scaling/multiplying to spread the difference set while
    # keeping sums few is not possible easily. Return best found.
    if best is None:
        best = [0, 1, 3, 7, 12, 20]

    best = sorted(set(int(x) for x in best))
    # clamp to allowed magnitude
    lim = 10 ** 15
    best = [x for x in best if abs(x) <= lim]
    if len(best) > 4000:
        best = best[:4000]
    return best
