import math
from itertools import combinations


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _bose_chowla(p, k=None):
    """Sidon set in Z_{p^2-1} x Z_{p^2-1} lifted to integers.
    A = {(x, x^2 mod m)} with m = p^2 - 1 gives |A|=m and a Sidon-like
    structure: all differences distinct (mod m), hence large difference set."""
    m = p * p - 1
    pts = [(x, (x * x) % m) for x in range(m)]
    return pts


def _sidon_ap(m):
    """Sidon set of size m in Z_{m^2 - m} ... simpler: Singer/Bose construction:
    A = {2*m*i + (i*i mod m) : i in 0..m-1} embedded as integers.
    This is a Bose Sidon set in Z_{m(m-1)} scaled -> square grid."""
    # Bose-Chowla: take modulus q = m-1 prime power. Build Sidon in Z_{q^2-1}.
    # Use classic Bose set: {a in [0, q^2-2]} with a = i*(q-1)+... We'll just
    # use the 2D lift: pick points (i, i^2 mod q) -> Sidon in Z_q x Z_q.
    q = m
    pts = [(i, (i * i) % q) for i in range(q)]
    return pts


def _pack(pts, scale_y):
    """Embed 2D points into integers: x + y*scale where y range known."""
    return [x + y * scale_y for (x, y) in pts]


def _build_A(entries):
    """entries: list of (n_pts, sidon_mod). Build a Sidon-like integer set.
    Use Bose-Chowla over Z_m x Z_m: A = {(i, i^2 mod m)}, i=0..m-1.
    Embed with y-stride = m to separate cosets. Then translate to origin."""
    A = []
    for m in entries:
        m = int(m)
        if m < 2:
            continue
        stride = m + 1
        base = _sidon_ap(m)
        pts = _pack(base, stride)
        # keep as a block; combine blocks with large offsets
        A.extend(pts)
    return A


def _distinct_score_pick(candidates):
    best = None
    bs = -1.0
    for c in candidates:
        c = list(set(c))
        if len(c) < 2:
            continue
        s = _score(c)
        if s > bs:
            bs = s
            best = c
    return best, bs


def solve():
    cands = []

    # Candidate 1: pure Bose-Chowla square for several m values.
    for m in (10, 16, 20, 25, 30, 32, 40, 50, 64):
        try:
            pts = _sidon_ap(m)
            stride = m + 1
            A = _pack(pts, stride)
            cands.append(A)
        except Exception:
            pass

    # Candidate 2: Bose-Chowla compressed to AP form
    # A = { i*(2m-1) + (i^2 mod m) } : i in [0,m-1] is a Sidon set in Z.
    for m in (10, 16, 20, 25, 30, 32, 40, 50, 64, 80, 100):
        A = [i * (2 * m - 1) + (i * i) % m for i in range(m)]
        cands.append(A)

    # Candidate 3: same but with modulus q != m to break structure
    for q in (11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47):
        for mul in (1, 2, 3):
            m = q
            A = [i * (mul * m + 1) + (i * i) % m for i in range(m)]
            cands.append(A)

    # Candidate 4: union of two Bose sets at shifted scales (still keep sums tight
    # by staying in one AP direction). Keep one set only, prefer best.
    for m in (16, 24, 32, 48, 64):
        A = [i * (2 * m - 1) + ((i * i) % m) for i in range(m)]
        # slight perturbation to enlarge difference set
        B = [x * 2 for x in A]
        cands.append(sorted(set(A + B)))

    # Candidate 5: arithmetic progression with quadratic "twist"
    for m in (10, 20, 30, 40, 50, 60):
        A = [i * m + (i * i) % m for i in range(m)]
        cands.append(A)

    # Candidate 6: product construction: Sidon base * scale + small set
    for m in (12, 18, 24, 30, 36):
        base = [i * (2 * m - 1) + (i * i) % m for i in range(m)]
        A = [x * (m + 1) for x in base]
        cands.append(A)

    # Candidate 7: Bose sets packed densely
    for m in (20, 40, 60, 80):
        A = [i + ((i * i) % m) * m for i in range(m)]
        cands.append(A)

    best, bs = _distinct_score_pick(cands)
    if best is None:
        return [0, 1]

    # Local improvement: try translating / small scaling to enlarge |A-A|/|A+A|.
    # Translating doesn't change either set sizes; scaling preserves ratio.
    # Try adding a small "extra" element that maximizes difference growth.
    cur = best[:]
    cs = _score(cur)

    # Greedy: attempt to add one element at far offset to boost |A-A|.
    # For Sidon-like sets, adding element y contributes |A| new differences
    # and |A| new sums. Try a few candidates.
    tried = 0
    for delta in range(1, 200):
        if tried > 60:
            break
        cand = cur + [max(cur) + delta]
        s = _score(cand)
        if s > cs:
            cs = s
            cur = cand
            tried += 1
        if len(cur) > 200:
            break

    # Final cleanup: keep it bounded and distinct
    out = sorted(set(int(x) for x in cur))
    if len(out) > 4000:
        # keep the best sub-structure
        out = out[:4000]
    return out
