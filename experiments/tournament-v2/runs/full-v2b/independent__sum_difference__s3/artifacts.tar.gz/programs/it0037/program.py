import math
import random
import time

def _sets(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return set(), set()
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return diffs, sums

def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = set()
    sums = set()
    l = list(a)
    n = len(l)
    for i in range(n):
        ai = l[i]
        for j in range(n):
            diffs.add(ai - l[j])
            sums.add(ai + l[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def _score_parts(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    l = list(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = l[i]
        for j in range(n):
            diffs.add(ai - l[j])
            sums.add(ai + l[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)

def build_base(n):
    """Build a set with very small sum-set and large difference-set.
    Main structure: powers of two, plus offsets to create many sum collisions.
    """
    if n <= 0:
        return []
    if n <= 2:
        return list(range(n))
    
    # Start with powers of 2: differences are unique, but sums are also unique.
    # We add a constant offset to duplicate sums: A = c + B, where B is Sidon-like.
    # Better: use several shifted copies of powers of 2 with shared small offsets.
    
    # Construct A = C union (C + D) where D is a small set of shifts,
    # to create sum collisions while keeping differences mostly unique.
    
    # Approach: choose base powers of 2, then add shifted versions.
    res = set()
    # number of blocks
    blocks = max(1, min(12, int(math.sqrt(n))))
    per = max(1, n // blocks)
    
    # choose base powers
    base = []
    x = 1
    while len(base) < per:
        base.append(x)
        x *= 2
        if x > 10**14:
            x = 1
    # small shifts
    shifts = [0]
    for k in range(1, blocks):
        shifts.append(k)
    
    for s in shifts:
        for b in base:
            if len(res) < n:
                res.add(b + s * 1000003)
    # fill remaining with powers of 2
    x = 1
    while len(res) < n:
        if x not in res:
            res.add(x)
        x *= 2
    return list(res)

def local_improve(a, deadline):
    best = list(set(a))
    best_score, _, _ = _score_parts(best)
    # Try removing elements to reduce sum set more than difference set
    improved = True
    while improved and time.time() < deadline:
        improved = False
        n = len(best)
        if n > 4000:
            break
        # Try small adjustments
        for i in range(n):
            for delta in (-3, -2, -1, 1, 2, 3):
                if time.time() > deadline:
                    break
                cand = best[:]
                cand[i] += delta
                if len(set(cand)) < len(cand):
                    continue
                s, d, sm = _score_parts(cand)
                if s > best_score:
                    best = cand
                    best_score = s
                    improved = True
                    break
            if improved:
                break

    # Randomized local search: shift entire set by constant and tweak individual elements
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        if random.random() < 0.3:
            # shift half the elements
            for _ in range(random.randint(1, max(1, len(cand)//4))):
                i = random.randrange(len(cand))
                cand[i] += random.choice([-2, -1, 1, 2])
        else:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        if len(set(cand)) < len(cand):
            continue
        s, d, sm = _score_parts(cand)
        if s > cur_score:
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand
                best_score = s
        elif random.random() < 0.01:
            cur = best[:]
            cur_score = best_score
    return best, best_score

def solve():
    deadline = time.time() + 115.0
    
    # Try several base constructions
    best = None
    best_score = -1.0
    
    for n in [50, 100, 200, 400, 800, 1500, 2500, 4000]:
        a = build_base(n)
        s, _, _ = _score_parts(a)
        if s > best_score:
            best = a
            best_score = s
    
    # Also try simple powers of 2
    a = []
    x = 1
    while len(a) < 4000 and x < 10**15:
        a.append(x)
        x *= 2
    if len(a) > 1:
        s, _, _ = _score_parts(a)
        if s > best_score:
            best = a
            best_score = s
    
    # Local improvement
    best, best_score = local_improve(best, deadline)
    
    return sorted(set(best))
