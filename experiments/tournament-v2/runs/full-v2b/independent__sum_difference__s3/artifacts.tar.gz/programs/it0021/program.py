import math
import time

def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def solve():
    # A greedy modular difference-set style construction.
    # We pick a prime p near 4000, build a subset of Z_p with many distinct
    # differences, then embed as integers 0..p-1.  Differences in Z are mostly
    # distinct while sums modulo p collide more.
    import sympy

    def is_prime(n):
        if n < 2:
            return False
        if n % 2 == 0:
            return n == 2
        r = int(n**0.5)
        f = 3
        while f <= r:
            if n % f == 0:
                return False
            f += 2
        return True

    # find largest prime <= 4000
    p = 4000
    while not is_prime(p):
        p -= 1

    # Use the classic Singer difference set / quadratic residues style set:
    # A = { x : x^2 mod p } gives ~p/2 elements with many differences.
    # But sums are also many.  Instead, greedily build a subset maximizing
    # distinct differences while keeping sums paired.
    #
    # Strong known construction: take A = {0,1,...,m-1} plus a Sidon-like part.
    # Empirically the best ratio comes from a large arithmetic-progression-like
    # core combined with a Sidon set tail.
    #
    # We combine: a full interval [0, k-1] contributes huge sums collision
    # (only 2k-1 distinct sums) but differences range over [-(k-1), k-1],
    # i.e. only 2k-1 distinct differences too -- ratio 1.  So that's bad.
    #
    # Better: use a set whose sums are confined but differences spread.
    # A geometric-like set: powers of 2 have ALL distinct sums and ALL distinct
    # differences (ratio 1).  Bad.
    #
    # The right structure for high ratio: a Sidon set has all sums distinct
    # (bad for us); we want the opposite: many differences, few sums.
    # Take A = B union C where B is an interval (few sums) and C is a Sidon
    # set shifted far away; differences between B and C are many and distinct.

    # Construction: A = [0, m-1] union { m, m+s_1, ..., m+s_t }
    # where the second part is a Sidon set scaled by m.
    # Differences within interval: 2m-1 values.
    # Differences interval->tail: m*t values, mostly distinct since tail
    # offsets are chosen to make m + s - b all distinct.
    # Sums within interval: 2m-1 values.
    # Sums interval->tail: values in [m, 2m + max_s], only ~m + max_s values.
    # So |A+A| ~ 2m + max_s and |A-A| ~ 2m + m*t.

    # We'll set m around 800, t around 3000, offsets up to ~ 1e6.
    # Use greedy Sidon-like offsets.

    m = 700
    base = list(range(m))
    used_offsets = set()

    # Generate candidate offsets (positive, distinct modulo nothing)
    # Greedy: add offset s such that all new differences m+s-b stay distinct
    # among tail and from interval differences.
    tail = []
    seen_diffs = set()
    # interval self differences
    for x in base:
        for y in base:
            seen_diffs.add(x - y)
    # interval-to-base handled below as we add

    target_t = 3200
    max_off = 10**6
    # simple sieve of candidate offsets = multiples patterns
    candidates = []
    step = 1
    # use offsets congruent to distinct values mod something
    seen_local = set()
    val = 0
    # generate lots of candidates: all integers up to max_off co-prime-ish
    # but 1e6 candidates is fine
    cand_iter = iter(range(1, max_off))

    tail_offsets = []
    # We need m+s-b distinct for b in [0,m-1], i.e. the values (m+s-b)
    # distinct among themselves for fixed s (they are, spaced 1) and across
    # different s the sets shift, all distinct if gaps > m.
    prev = 0
    while len(tail_offsets) < target_t and prev + m + 1 < max_off:
        prev += m + 1
        tail_offsets.append(prev)

    if not tail_offsets:
        return base

    # Build A
    A = list(range(m))
    for s in tail_offsets:
        A.append(m + s)

    # check score quickly
    def quick_score(A):
        n = len(A)
        ds = set()
        ss = set()
        for i in range(n):
            ai = A[i]
            for j in range(i, n):
                ss.add(ai + A[j])
                ds.add(ai - A[j])
                ds.add(A[j] - ai)
        if len(ss) < 2:
            return 0.0
        return math.log(len(ds)) / math.log(len(ss)) + (1 - 1 / n) / 100

    A = sorted(set(A))
    # Truncate / refine with local search if time permits
    best = A
    best_score = quick_score(A)
    deadline = time.time() + 100

    # Local improvement: try adjusting tail offsets slightly
    import random
    random.seed(12345)
    n = len(best)
    while time.time() < deadline:
        cand = best[:]
        i = random.randrange(m, n)  # only adjust tail elements
        cand[i] += random.randint(-m, m)
        if cand[i] in range(m):
            continue
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        # cheap incremental estimate not available; use quick_score on smaller sample
        s = quick_score(cand)
        if s > best_score:
            best, best_score = cand, s
            # keep going

    return sorted(set(int(x) for x in best))
