import math
import random
import time

# ------------------------------------------------------------
# scoring
# ------------------------------------------------------------
def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            diffs.add(ai - a[j])
            diffs.add(a[j] - ai)
            s = ai + a[j]
            sums.add(s)
            if i != j:
                sums.add(s)
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0

# ------------------------------------------------------------
# build a good initial candidate
# ------------------------------------------------------------
def _initial_candidates():
    cands = []
    # A small classical-looking set
    cands.append([7, 15, 18, 22, -3, -2])

    # Arithmetic progression shifted so sums are few but differences many
    # AP has |A-A| about 2n-1 and |A+A| about 2n-1, ratio near 1;
    # not great, but useful as a seed.
    cands.append(list(range(-5, 6)))

    # Geometric-ish / convex set: differences mostly unique, sums collide
    # because of symmetry around 0.
    base = []
    x = 1
    for _ in range(12):
        base.append(x)
        x *= 2
    cands.append(base)

    # Symmetric set around 0: sums can collide more easily.
    sym = []
    step = 1
    v = 1
    for _ in range(15):
        sym.append(v)
        sym.append(-v)
        v += step
        step += 1
    cands.append(sym)

    # random sparse sets
    for _ in range(20):
        n = random.randint(5, 25)
        s = set()
        while len(s) < n:
            s.add(random.randint(-1000, 1000))
        cands.append(list(s))
    return cands

# ------------------------------------------------------------
# local search operators
# ------------------------------------------------------------
def _mutate(a, max_val=10**6):
    a = a[:]
    choice = random.random()
    if choice < 0.45:
        # change one element
        i = random.randrange(len(a))
        delta = random.choice([-1, 1]) * random.randint(1, max(2, abs(a[i]) // 3 + 1))
        a[i] += delta
    elif choice < 0.70:
        # add one element
        if len(a) < 60:
            # try near existing points or random
            if random.random() < 0.7 and a:
                j = random.randrange(len(a))
                a.append(a[j] + random.randint(-20, 20))
            else:
                a.append(random.randint(-max_val, max_val))
    elif choice < 0.90:
        # remove one element
        if len(a) > 5:
            del a[random.randrange(len(a))]
    else:
        # shift the whole set (doesn't change score but helps diversity)
        d = random.randint(-10, 10)
        a = [x + d for x in a]
    return a

# ------------------------------------------------------------
# efficient exact score for moderate n
# ------------------------------------------------------------
def _score_fast(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    if not sums:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0

# ------------------------------------------------------------
# main solve
# ------------------------------------------------------------
def solve():
    random.seed(12345)
    deadline = time.time() + 115.0

    best = None
    best_score = -1e100

    for seed_cand in _initial_candidates():
        cand = sorted(set(seed_cand))
        s = _score_fast(cand)
        if s > best_score:
            best_score = s
            best = cand[:]

    # refine with hill climbing / simulated annealing
    cur = best[:]
    cur_score = best_score
    T = 0.02
    step = 0

    while time.time() < deadline:
        step += 1
        cand = _mutate(cur, max_val=10**7)
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score_fast(cand)

        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        else:
            # occasional restart from best
            if random.random() < 0.002:
                cur, cur_score = best[:], best_score
            elif random.random() < 0.05:
                # small non-improving move
                cur, cur_score = cand, s

        # temperature cooling in a crude way
        if step % 2000 == 0:
            T *= 0.97

    # final cleanup: try to append a few points
    improved = True
    attempts = 0
    while improved and time.time() < deadline and attempts < 200:
        improved = False
        attempts += 1
        base = best[:]
        for trial in range(50):
            cand = base[:]
            if len(cand) < 4000:
                # append one more point chosen from a small pool
                if random.random() < 0.5:
                    cand.append(random.randint(-10000, 10000))
                else:
                    j = random.randrange(len(cand))
                    cand.append(cand[j] + random.randint(-100, 100))
            cand = sorted(set(cand))
            s = _score_fast(cand)
            if s > best_score:
                best, best_score = cand[:], s
                improved = True
                break

    return sorted(set(best))
