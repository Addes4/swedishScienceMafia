"""Sets with many differences and few sums.

Approach: use a union of scaled copies of a small "greedy Sidon-like" core.
Unions of scaled copies tend to keep A+A structured (few sums) while A-A
gains many cross-scale differences.  Then run a short local search to polish.
"""
import math
import random
import time


def _diffs_sums(a):
    a = list(a)
    diffs = set()
    sums = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return diffs, sums


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return -1e9
    diffs, sums = _diffs_sums(a)
    if len(sums) < 2:
        return -1e9
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / len(a)) / 100.0


def _greedy_sidon(size, bound, rng):
    """Greedy set with many distinct differences (Sidon-like) inside [0,bound]."""
    chosen = [0]
    used = {0}
    for _ in range(size - 1):
        best_c = None
        best_gain = -1
        for _try in range(60):
            c = rng.randrange(bound + 1)
            if c in used:
                continue
            gain = 0
            local = set()
            for x in chosen:
                d = abs(c - x)
                if d not in local:
                    local.add(d)
                    gain += 1
            if gain > best_gain:
                best_gain = gain
                best_c = c
        if best_c is None:
            break
        chosen.append(best_c)
        used.add(best_c)
    return chosen


def _build_union(base, scales, offsets):
    """Union of scaled+offset copies: s*base + o."""
    out = set()
    for s, o in zip(scales, offsets):
        for x in base:
            out.add(s * x + o)
    return sorted(out)


def _local_search(a, deadline, rng, max_steps=200000):
    a = sorted(set(a))
    best = a[:]
    best_score = _score(best)
    cur = a[:]
    cur_score = best_score
    steps = 0
    while time.time() < deadline and steps < max_steps:
        steps += 1
        cand = cur[:]
        op = rng.random()
        if op < 0.55 and cand:
            i = rng.randrange(len(cand))
            delta = rng.choice([-1, 1, -2, 2, -3, 3, -5, 5, -10, 10,
                                -30, 30, -100, 100, -1000, 1000])
            cand[i] += delta
        elif op < 0.8:
            cand.append(rng.choice([-1, 1]) * rng.randint(1, 200000))
        elif op < 0.9 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        else:
            # small shift of the whole set
            sh = rng.choice([-1, 1]) * rng.randint(1, 50)
            cand = [x + sh for x in cand]
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s = _score(cand)
        if s >= cur_score:
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
        elif rng.random() < 0.02:
            cur = best[:]
            cur_score = best_score
    return best, best_score


def solve():
    rng = random.Random(1234567)
    deadline = time.time() + 110

    candidates = []

    # Known good starting shapes.
    candidates.append([7, 15, 18, 22, -3, -2])
    candidates.append([0, 1, 3, 7, 12, 20, 30, 44, 65, 80])
    candidates.append([0, 1, 2, 4, 8, 13, 21, 31, 45, 66, 81, 97])

    # Try unions of scaled copies of small greedy-Sidon bases.
    for core_size in (6, 8, 10, 12):
        for bound in (40, 80, 150, 300):
            for _trial in range(2):
                base = _greedy_sidon(core_size, bound, rng)
                # scale bands: geometric-ish scales with disjoint-ish ranges
                for k in (3, 4, 5, 6):
                    scales = [1]
                    offs = [0]
                    cur_hi = bound
                    for j in range(1, k):
                        s = cur_hi + 1 + rng.randint(0, 5)
                        scales.append(s)
                        offs.append(rng.randint(-3, 3))
                        cur_hi = s * bound + offs[-1]
                        if cur_hi > 10**12:
                            break
                    A = _build_union(base, scales, offs)
                    if 2 <= len(A) <= 4000:
                        candidates.append(A)

    # Refine initial candidates quickly.
    scored = []
    for A in candidates:
        try:
            sc = _score(A)
        except Exception:
            continue
        scored.append((sc, A))
    scored.sort(key=lambda t: -t[0])

    best_A = scored[0][1] if scored else [7, 15, 18, 22, -3, -2]
    best_score = _score(best_A)

    # Spend remaining time doing local search from the top few seeds.
    seeds = [A for _, A in scored[:5]]
    if not seeds:
        seeds = [best_A]
    per_seed = max(1.0, (deadline - time.time()) / max(1, len(seeds)))
    for A in seeds:
        sub_deadline = min(deadline, time.time() + per_seed)
        cand, sc = _local_search(A, sub_deadline, rng)
        if sc > best_score:
            best_A, best_score = cand, sc
        if time.time() >= deadline:
            break

    # Final polish from current best if time remains.
    while time.time() < deadline:
        cand, sc = _local_search(best_A, min(deadline, time.time() + 5), rng,
                                 max_steps=20000)
        if sc > best_score:
            best_A, best_score = cand, sc

    # Clip size and value range; dedupe, sort.
    best_A = sorted(set(int(x) for x in best_A))
    if len(best_A) > 4000:
        best_A = best_A[:4000]
    best_A = [x for x in best_A if abs(x) <= 10**15]
    if len(best_A) < 2:
        best_A = [7, 15, 18, 22, -3, -2]
    return best_A
