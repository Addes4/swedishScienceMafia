import math
import random
import time

def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def solve():
    random.seed(12345)
    deadline = time.time() + 100

    best = None
    best_score = -1e9

    # Candidate seed sets: geometric-like with large ratio and signs
    seeds = []
    seeds.append([0, 1])
    seeds.append([0, 1, 3])
    seeds.append([0, 1, 3, 9])
    seeds.append([0, 1, 4, 16])
    seeds.append([0, 1, 3, 9, 27])
    seeds.append([0, 1, 5, 25, 125])
    seeds.append([0, -1, 3, -9])
    seeds.append([0, 1, -3, 9, -27])
    seeds.append([0, 1, 4, -16, 64])

    def greedy_add(a, max_add, tries=200, perturb=0.0):
        a = list(set(a))
        if perturb > 0:
            # slight random perturbation
            a = [x + random.randint(-1, 1) for x in a]
            a = list(set(a))
        sa = set(a)
        if len(sa) < 2:
            return a, -1e9
        diffs = {x - y for x in sa for y in sa}
        sums = {x + y for x in sa for y in sa}
        cur_d = len(diffs)
        cur_s = len(sums)
        cur_score = math.log(cur_d) / math.log(cur_s) + (1 - 1/len(sa))/100

        best_cand = a[:]
        best_sc = cur_score

        for _ in range(tries):
            # propose a new element
            # try to make differences large and sums collide
            # pick from exponential distribution to get large gaps
            if random.random() < 0.6:
                x = random.randint(-max_add, max_add)
            else:
                x = random.choice(a) + random.choice([-1,1]) * random.randint(1, max(1, max_add//10))
            if x in sa:
                continue
            new = sa | {x}
            nd = set()
            ns = set()
            for u in new:
                for v in new:
                    nd.add(u - v)
                    ns.add(u + v)
            # This is O(n^2) but n small
            if len(nd) <= 1 or len(ns) <= 1:
                continue
            sc = math.log(len(nd)) / math.log(len(ns)) + (1 - 1/len(new))/100
            if sc > best_sc or (sc == best_sc and len(new) > len(best_cand)):
                best_sc = sc
                best_cand = list(new)

        return best_cand, best_sc

    def local_search(a, time_limit):
        a = list(set(a))
        if len(a) < 2:
            return a, -1e9
        cur = a[:]
        cur_score = _score(cur)
        best_local = cur[:]
        best_local_score = cur_score

        end = time.time() + time_limit
        while time.time() < end:
            cand = cur[:]
            op = random.random()
            if op < 0.4:
                # change an element
                i = random.randrange(len(cand))
                cand[i] += random.randint(-20, 20)
                cand = list(set(cand))
                if len(cand) < 2:
                    continue
            elif op < 0.7:
                # add an element
                if len(cand) >= 400:
                    continue
                base = random.choice(cand) if cand else 0
                cand.append(base + random.choice([-1,1]) * random.randint(1, 500))
                cand = list(set(cand))
            else:
                # remove an element
                if len(cand) <= 2:
                    continue
                i = random.randrange(len(cand))
                del cand[i]
            s = _score(cand)
            if s >= cur_score or random.random() < 0.02:
                cur = cand
                cur_score = s
                if s > best_local_score:
                    best_local = cand[:]
                    best_local_score = s
            if random.random() < 0.01:
                cur = best_local[:]
                cur_score = best_local_score
        return best_local, best_local_score

    # Try seeds
    for seed in seeds:
        if time.time() > deadline - 5:
            break
        a = seed[:]
        # iterative greedy construction
        for scale in [3, 10, 30, 100, 300, 1000, 3000, 10000]:
            if time.time() > deadline - 10:
                break
            a, sc = greedy_add(a, scale, tries=100 if scale < 1000 else 50)
            if sc > best_score:
                best_score = sc
                best = a[:]
        # local search refine
        remaining = deadline - time.time()
        if remaining > 2:
            a2, sc2 = local_search(a, min(remaining - 1, 20))
            if sc2 > best_score:
                best_score = sc2
                best = a2[:]

    # Final intensive local search
    if best is not None and time.time() < deadline - 1:
        rem = deadline - time.time()
        a3, sc3 = local_search(best, rem - 0.5)
        if sc3 > best_score:
            best_score = sc3
            best = a3[:]

    if best is None:
        best = [0, 1, 3]

    # ensure distinct and limits
    best = list(set(best))[:4000]
    best = [x for x in best if abs(x) <= 10**15]
    if len(best) < 2:
        best = [0, 1]

    return sorted(best)
