import math
import random
import time

def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    d = len(diffs)
    s = len(sums)
    if s == 0:
        return 0.0, d, s
    sc = math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100
    return sc, d, s

def solve():
    random.seed(12345)
    best = [7, 15, 18, 22, -3, -2]
    best_score, _, _ = _score(best)
    # Try a scaled version of a set with small sumset: e.g., near powers of 2
    # Powers of 2 have max differences but huge sums ratio-wise small? Actually sums distinct too.
    # Try a known trick: take A = {0,1,2,...} concat something to reduce sum collisions
    # We'll do local search over larger sets.
    candidates = []
    # construct base: arithmetic progression has |sums|=2n-1, |diffs|=2n-1 => ratio 1
    # We want diffs large, sums small. Use a set where many pairs share sums.
    # A = {0,1,3,7,15,...}? 
    # Try: A = {i * c_i} with carefully chosen.
    # Let's build from scratch via simulated annealing on integer values.

    # Start with a sorted near-geometric-ish set
    n = 30
    base = []
    v = 0
    step = 1
    for i in range(n):
        base.append(v)
        v += step
        step = step * 2 if i % 2 == 0 else step
    base = sorted(set(base))

    def evaluate(a):
        return _score(a)[0]

    cur = base[:]
    cur_score, _, _ = _score(cur)
    if cur_score > best_score:
        best, best_score = cur[:], cur_score

    deadline = time.time() + 100
    # hill climbing with random restarts
    while time.time() < deadline:
        cand = cur[:]
        # mutations
        r = random.random()
        if r < 0.4 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-2, 2)
        elif r < 0.7:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-5, -3, -1, 1, 3, 5])
        elif r < 0.9 and len(cand) > 2:
            i = random.randrange(len(cand))
            del cand[i]
        else:
            cand.append(max(cand) + random.randint(1, 10))
        cand = list(set(cand))
        if len(cand) < 2:
            cur = base[:]
            continue
        s, _, _ = _score(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.02:
            cur, cur_score = cand, s

    # try larger structured set: if A has form {a_i} = {i} union large multiples
    # construct using difference-dominant: take A = {0,1,...,n-1} plus n, 2n, 4n, ...
    for n in [20, 40, 60, 100]:
        a = list(range(n))
        v = n
        for k in range(10):
            a.append(v)
            v *= 2
        a = list(set(a))
        s, _, _ = _score(a)
        if s > best_score:
            best, best_score = a[:], s

    return sorted(set(best))
