import math, random, time

def _stats(a):
    a = list(set(a))
    if len(a) < 2:
        return 0, 0
    diffs = set()
    sums = set()
    for i in range(len(a)):
        ai = a[i]
        for j in range(len(a)):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return len(diffs), len(sums)

def _score(a):
    a = set(a)
    if len(a) < 2:
        return -1e18
    diffs = set()
    sums = set()
    la = list(a)
    for x in la:
        for y in la:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1.0 / len(a)) / 100.0

def solve():
    random.seed(12345)
    deadline = time.time() + 115
    best = None
    best_score = -1e18

    # Structured starts: Sidon-like / powers of 2 / random sparse
    starts = []
    # powers of 2 scaled
    for k in (6, 7, 8, 9, 10, 11, 12):
        s = [1 << i for i in range(k)]
        starts.append(s)
        starts.append(sorted(random.sample(range(1, 1 << (k + 2)), k)))
    # small dense random sets
    for _ in range(50):
        n = random.randint(4, 12)
        starts.append(sorted(random.sample(range(-30, 31), n)))

    def local_opt(seed_set, tlimit):
        cur = list(seed_set)
        cur = list(set(cur))
        cs = _score(cur)
        # try removals then additions greedily
        improved = True
        while improved and time.time() < tlimit:
            improved = False
            # removal
            for i in range(len(cur)):
                cand = cur[:i] + cur[i+1:]
                if len(cand) >= 2:
                    s = _score(cand)
                    if s > cs + 1e-12:
                        cur, cs, improved = cand, s, True
                        break
            if improved:
                continue
            # addition
            base = set(cur)
            maxv = max(abs(v) for v in cur) + 1
            tried = set()
            for _ in range(30):
                v = random.randint(-maxv - 5, maxv + 5)
                if v in base or v in tried:
                    continue
                tried.add(v)
                cand = cur + [v]
                s = _score(cand)
                if s > cs + 1e-12:
                    cur, cs, improved = cand, s, True
                    break
        return cur, cs

    t_end = time.time() + 100
    for st in starts:
        if time.time() > t_end:
            break
        c, s = local_opt(st, time.time() + 5)
        if s > best_score:
            best_score, best = s, c[:]

    # Simulated annealing polish
    if best is None:
        best = [0]
    cur = best[:]
    cs = best_score
    t0 = time.time()
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.5 and len(cand) > 2:
            del cand[random.randrange(len(cand))]
        elif op < 0.85:
            maxv = max(abs(v) for v in cand) + 3 if cand else 10
            cand.append(random.randint(-maxv, maxv))
        else:
            maxv = max(abs(v) for v in cand) + 3 if cand else 10
            i = random.randrange(len(cand))
            cand[i] = random.randint(-maxv, maxv)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        T = max(1e-6, 0.05 * (deadline - time.time()) / max(1e-6, deadline - t0))
        if s > cs or random.random() < math.exp((s - cs) / max(T, 1e-9)):
            cur, cs = cand, s
            if s > best_score:
                best_score, best = s, cand[:]

    best = sorted(set(best))
    return best
