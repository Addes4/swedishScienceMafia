import math
import random
import time


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _score_fast(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
    if len(sums) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def solve():
    deadline = time.time() + 110.0

    # Base idea: use a geometric progression with ratio 2, clipped/scaled.
    # A = {2^i * c + offset} can sometimes reduce sum count via collisions.
    candidates = []

    # Candidate 1: powers of 2
    for k in [20, 25, 30, 40, 50, 60]:
        A = [1 << i for i in range(k)]
        candidates.append(A)

    # Candidate 2: powers of 3
    for k in [15, 18, 20, 22, 25]:
        A = [3 ** i for i in range(k)]
        candidates.append(A)

    # Candidate 3: mixed scale
    A = []
    v = 1
    for i in range(40):
        A.append(v)
        v *= 2
    candidates.append(A)

    # Candidate 4: {i * 2^k} union small perturbations
    for k in [10, 15, 20, 25]:
        A = [i * (1 << k) for i in range(1, 30)]
        candidates.append(A)

    best = None
    best_s = -1.0
    for c in candidates:
        s = _score_fast(c)
        if s > best_s:
            best_s = s
            best = c[:]

    # Local search on top of the best
    if best is not None:
        cur = best[:]
        cur_score = best_s
        it = 0
        while time.time() < deadline:
            it += 1
            cand = cur[:]
            # mutation modes
            r = random.random()
            if r < 0.5 and len(cand) >= 2:
                # shift one element
                i = random.randrange(len(cand))
                cand[i] += random.choice([-1, 1]) * random.randint(1, 5)
            elif r < 0.8:
                # add a new element
                if len(cand) < 200:
                    base = random.choice(cand) if cand else 1
                    cand.append(base + random.randint(-100, 100))
            else:
                # remove an element
                if len(cand) > 3:
                    del cand[random.randrange(len(cand))]
            cand = sorted(set(cand))
            if len(cand) < 3:
                cand = cur[:]
            s = _score_fast(cand)
            if s > cur_score or random.random() < 0.02:
                cur = cand
                cur_score = s
                if s > best_s:
                    best = cand[:]
                    best_s = s

    return sorted(set(best)) if best else [1, 2, 3]
