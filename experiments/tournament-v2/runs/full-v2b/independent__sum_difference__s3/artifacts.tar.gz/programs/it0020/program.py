import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return -1e18, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) <= 1:
        return -1e18, 0, 0
    s = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return s, len(diffs), len(sums)


def _full(a):
    a = set(a)
    if len(a) < 2:
        return -1e18
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) <= 1:
        return -1e18
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _seed_sidon_like(target_n, rng):
    """Greedy near-Sidon set: minimize collisions in A+A while spreading differences."""
    A = [0]
    sumset = {0}
    diffset = {0}
    # start
    A = [0, 1]
    sumset = {0, 1, 2}
    diffset = {-1, 0, 1}
    max_val = 1

    while len(A) < target_n:
        best = None
        best_val = None
        # candidate new elements near the top with some randomness
        cand_min = max_val + 1
        for _ in range(80):
            v = cand_min + rng.randrange(0, max(5, max_val // 2 + 5))
            new_sums = {v + x for x in A} | {2 * v}
            new_diffs = {v - x for x in A} | {x - v for x in A} | {0}
            ns = len(sumset | new_sums)
            nd = len(diffset | new_diffs)
            gain_s = ns - len(sumset)
            gain_d = nd - len(diffset)
            # prefer more new differences per new sum
            if gain_s <= 0:
                continue
            ratio = gain_d / gain_s
            score = (ratio, gain_d, -ns)
            if best is None or score > best:
                best = score
                best_val = v
        if best_val is None:
            # fallback
            best_val = max_val + 1 + rng.randrange(0, 5)
        v = best_val
        A.append(v)
        for x in A:
            sumset.add(v + x)
            diffset.add(v - x)
            diffset.add(x - v)
        sumset.add(2 * v)
        diffset.add(0)
        max_val = max(max_val, v)
    return sorted(A)


def _local_search(A, deadline, rng, scale=1):
    A = sorted(set(A))
    cur = A[:]
    cur_score = _full(cur)
    best = cur[:]
    best_score = cur_score

    while time.time() < deadline:
        cand = cur[:]
        op = rng.random()
        if op < 0.55:
            i = rng.randrange(len(cand))
            delta = rng.randint(-scale, scale)
            if delta == 0:
                delta = 1
            cand[i] += delta
        elif op < 0.80:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-scale * 3, scale * 3)
        elif op < 0.92:
            cand.append(rng.randint(-scale * 4, scale * 4))
        else:
            if len(cand) > 3:
                cand.pop(rng.randrange(len(cand)))
        # dedupe
        cand = sorted(set(cand))
        if len(cand) < 3:
            continue
        sc = _full(cand)
        if sc >= cur_score or rng.random() < 0.02:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best = cand[:]
                best_score = sc
        elif rng.random() < 0.05:
            # occasional restart from best
            cur = best[:]
            cur_score = best_score
    return best, best_score


def _normalize(A):
    m = min(A)
    return [x - m for x in A]


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 115
    best = None
    best_score = -1e18

    # 1) seed Sidon-like sets of various sizes
    seeds = []
    for n in (30, 60, 100, 140, 180, 220, 260, 300):
        s = _seed_sidon_like(n, rng)
        seeds.append(_normalize(s))

    # Also add small ad hoc candidates
    seeds.append([0, 1, 3, 7, 12, 20, 30])
    seeds.append(list(range(0, 20)))

    # quick evaluation
    for s in seeds:
        sc = _full(s)
        if sc > best_score:
            best_score = sc
            best = s[:]

    # 2) local search on seeds
    while time.time() < deadline * 0.98:
        seed = seeds[rng.randrange(len(seeds))]
        # random affine-ish perturb to create new starts
        start = seed[:]
        if rng.random() < 0.5:
            for _ in range(rng.randint(1, 8)):
                i = rng.randrange(len(start))
                start[i] += rng.randint(-5, 5)
            start = sorted(set(start))
        remaining = deadline - time.time()
        if remaining <= 0:
            break
        cand, sc = _local_search(start, time.time() + min(8.0, remaining), rng, scale=2)
        if sc > best_score:
            best_score = sc
            best = cand[:]
        # feed good ones back
        if sc > best_score - 0.15:
            seeds.append(cand)
            if len(seeds) > 40:
                seeds.pop(rng.randrange(len(seeds) // 2))

    # 3) final polish from best
    remaining = deadline - time.time()
    if remaining > 0:
        cand, sc = _local_search(best, deadline, rng, scale=1)
        if sc > best_score:
            best_score = sc
            best = cand[:]

    best = sorted(set(best))
    # safe limits
    best = [x for x in best if abs(x) <= 10**15]
    if len(best) < 2:
        best = [0, 1]
    if len(best) > 4000:
        best = best[:4000]
    return best
