import math
import random
import time

def _stats(a):
    if len(a) < 2:
        return 0, 0
    if len(a) > 1200:
        # exact would be too slow; but we only use this for moderate sizes
        pass
    diffs = set()
    adds = set(a)
    for x in a:
        for y in a:
            diffs.add(x - y)
            adds.add(x + y)
    return len(diffs), len(adds)

def _score(a):
    if len(a) < 2:
        return -1e9
    nd, ns = _stats(a)
    if ns <= 1:
        return -1e9
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / len(a)) / 100.0

def _build(base, shifts):
    A = list(base)
    cur = base[-1] if base else 1
    step = 0
    for s in shifts:
        cur = cur * s + 1
        A.append(cur)
    return A

def solve():
    random.seed(12345)
    deadline = time.time() + 115.0

    # Start with a known decent configuration from the baseline's promising region.
    best_base = [7, 15, 18, 22, -3, -2]
    best_shifts = [16, 80, 400]

    best = _build(best_base, best_shifts)
    best_score = _score(best)

    # Also consider the classic Sidon-like / B_2 set candidate
    seeds = [
        ([7, 15, 18, 22, -3, -2], [16, 80, 400]),
        ([0, 1, 4, 10, 18, 23, 25], [16, 80, 400]),
        ([1, 2, 5, 10, 16, 23, 31], [20, 100, 500]),
        ([0, 1, 3, 7, 12, 20, 30], [18, 90, 450]),
        ([1, 3, 7, 12, 20, 30, 44], [16, 90, 512]),
        ([0, 1, 4, 9, 15, 22, 26, 31], [20, 100, 500]),
        ([1, 2, 6, 10, 14, 19, 26, 34], [18, 90, 450]),
        ([0, 1, 4, 10, 18, 27, 38, 50], [16, 80, 400]),
    ]
    for base, shifts in seeds:
        cand = _build(base, shifts)
        s = _score(cand)
        if s > best_score:
            best, best_score = cand, s
            best_base, best_shifts = base[:], shifts[:]

    # Local search over base elements and shifts.
    cur_base = best_base[:]
    cur_shifts = best_shifts[:]
    cur_score = best_score

    def local_score(base, shifts):
        return _score(_build(base, shifts))

    iter_count = 0
    while time.time() < deadline:
        iter_count += 1
        base = cur_base[:]
        shifts = cur_shifts[:]

        # occasionally perturb base
        if random.random() < 0.6:
            i = random.randrange(len(base))
            delta = random.choice([-3, -2, -1, 0, 1, 2, 3, 4, 5, 7, 10])
            base[i] += delta
        else:
            # perturb a shift multiplicatively (or slightly mode)
            if random.random() < 0.5 and len(shifts) > 0:
                i = random.randrange(len(shifts))
                factor = random.choice([-2, -1, 0, 1, 2])
                shifts[i] = max(2, shifts[i] + factor * max(1, shifts[i] // 8))
            else:
                # add/remove shift
                if random.random() < 0.3 and len(shifts) < 5:
                    shifts.append(random.choice([8, 16, 32, 64, 80, 100, 128, 200, 256, 400, 512]))
                elif len(shifts) > 1:
                    shifts.pop(random.randrange(len(shifts)))
                else:
                    shifts[0] = max(2, shifts[0] + random.choice([-4, -2, -1, 1, 2, 4]))

        # deduplicate base
        base = sorted(set(base))
        if len(base) < 3:
            continue

        try:
            s = local_score(base, shifts)
        except Exception:
            continue

        if s > cur_score:
            cur_base, cur_shifts, cur_score = base, shifts, s
            if s > best_score:
                best_score = s
                best = _build(base, shifts)

                # Early exit if very strong
                if best_score > 1.95:
                    return sorted(set(best))
        else:
            # simulated-annealing-ish acceptance, mostly reset to best
            if random.random() < 0.02:
                cur_base, cur_shifts, cur_score = base, shifts, s

        # periodic restart from best
        if iter_count % 400 == 0:
            cur_base = best_base[:]
            cur_shifts = best_shifts[:]
            cur_score = best_score

    return sorted(set(best))
