import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1e18
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return -1e18
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _fast_score(a):
    # Optimized using arrays for speed
    n = len(a)
    if n < 2:
        return -1e18
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            s = ai + aj
            if s not in sums:
                sums.add(s)
            d = ai - aj
            if d not in diffs:
                diffs.add(d)
            d2 = aj - ai
            if d2 not in diffs:
                diffs.add(d2)
    if not sums:
        return -1e18
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    deadline = time.time() + 110

    # ---------- Construction 1: modified geometric progression ----------
    # Take a large base b.  The set {b^0, b^1, ..., b^{k-1}} has |A+A| about k(k+1)/2
    # but |A-A| also about k(k+1)/2.  By adding a small offset set we can break
    # differences into more classes while sums stay in few classes.
    # Better: use A = { t_i * M + r_i } where M is large.  Sums are determined by
    # (t_i+t_j, r_i+r_j).  Pick t_i so that sums t_i+t_j collide a lot, but
    # differences t_i-t_j are distinct.

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Try a few structured constructions
    candidates = []

    # Construction A: powers of 2 with small perturbations, shifted.
    # A = {2^i * M + small}
    for M in [10**6, 10**9, 10**12]:
        for k in [15, 20, 25, 30, 40, 50]:
            if k > 4000:
                continue
            A = []
            for i in range(k):
                A.append((1 << i) * M + (i * i))
            candidates.append(A)

    # Construction B: t_i from a Sidon-like set but with collisions in sums.
    # Pick t_i in arithmetic progression modulo something large.
    # Actually try: t_i = i * i, r_i = i, M large.
    for M in [10**6, 10**9, 10**12]:
        for k in [15, 20, 25, 30, 40, 50]:
            A = [(i * i) * M + i for i in range(k)]
            candidates.append(A)
            A = [(i * i * i) * M + i for i in range(k)]
            candidates.append(A)

    # Construction C: use base-M representation with t_i from a set with small sumset.
    # E.g. t_i in {0,1,2,...,k-1} -> sumset large though.
    # Instead t_i in {0,1,3,7,15,...} = 2^i-1 -> pairwise sums mostly distinct.
    # Not helpful. Try t_i from {0,1,2,4,8,...} sums: 2^i+2^j -> distinct mostly.

    # Construction D: random sets around the baseline size, then improve.
    for _ in range(20):
        k = random.randint(6, 15)
        A = [random.randint(-30, 30) for _ in range(k)]
        candidates.append(A)

    # Evaluate candidates
    for A in candidates:
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A[:]

    # ---------- Local search ----------
    cur = best[:]
    cur_score = best_score

    n_restarts = 0
    while time.time() < deadline:
        n_restarts += 1
        # Candidate move
        cand = cur[:]
        choice = random.random()
        if choice < 0.6:
            # perturb an element
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        elif choice < 0.8 and len(cand) < 60:
            # add an element
            cand.append(random.randint(-50, 50))
        elif choice < 0.9 and len(cand) > 3:
            # remove an element
            idx = random.randrange(len(cand))
            del cand[idx]
        else:
            # big jump: restart from best with perturbation
            cand = best[:]
            for _ in range(random.randint(1, 3)):
                if cand:
                    i = random.randrange(len(cand))
                    cand[i] += random.randint(-20, 20)

        cand = list(set(cand))
        if len(cand) < 2:
            continue
        cand_score = _score(cand)

        T = max(0.0001, 0.5 * (1.0 - (time.time() - (deadline - 110)) / 110.0))
        if cand_score > cur_score or random.random() < math.exp((cand_score - cur_score) / T):
            cur = cand
            cur_score = cand_score
            if cur_score > best_score:
                best = cur[:]
                best_score = cur_score

        # periodic restart
        if n_restarts % 3000 == 0:
            cur = best[:]
            cur_score = best_score

    # ---------- Final polish on best ----------
    improved = True
    while improved and time.time() < deadline:
        improved = False
        for i in range(len(best)):
            for delta in [-3, -2, -1, 1, 2, 3]:
                cand = best[:]
                cand[i] += delta
                cand = list(set(cand))
                if len(cand) < 2:
                    continue
                s = _score(cand)
                if s > best_score:
                    best_score = s
                    best = cand
                    improved = True

    return sorted(set(best))
