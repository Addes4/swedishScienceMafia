import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    ld = len(diffs)
    ls = len(sums)
    if ls < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def solve():
    best = [0]
    best_score = 0.0

    # Try multiple Sidon-style constructions with local search
    time_limit = 115.0
    deadline = time.time() + time_limit

    # Greedy Sidon set construction: B_2 set (all sums a_i + a_j distinct)
    # This makes |A+A| = n(n+1)/2, small.
    # To also maximize |A-A|, we want it close to n(n-1)+1.
    def greedy_sidon(n, limit, rng):
        s = [0]
        used_sums = {0}
        used_diffs = {0}
        for _ in range(n - 1):
            found = None
            for _ in range(limit):
                c = rng.randint(1, limit * 3)
                ok = True
                new_sums = {c + x for x in s} | {2 * c}
                if new_sums & used_sums:
                    ok = False
                if ok:
                    new_diffs = {c - x for x in s} | {x - c for x in s}
                    # prefer adding many new diffs
                    if new_diffs & used_diffs and rng.random() < 0.3:
                        ok = False
                if ok:
                    found = c
                    used_sums |= new_sums
                    used_diffs |= {c - x for x in s} | {x - c for x in s}
                    s.append(c)
                    break
            if found is None:
                # fallback
                c = s[-1] + rng.randint(1, 50)
                s.append(c)
                used_sums |= {c + x for x in s} | {2 * c}
                used_diffs |= {c - x for x in s} | {x - c for x in s}
        return s

    rng = random.Random(12345)

    def local_search(start, deadline):
        cur = list(set(start))
        cur_score = _score(cur)
        best_local = cur[:]
        best_local_score = cur_score
        it = 0
        while time.time() < deadline:
            it += 1
            cand = cur[:]
            # perturb
            op = rng.random()
            if op < 0.5:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-5, 5)
            elif op < 0.8:
                i = rng.randrange(len(cand))
                cand[i] = rng.randint(-200, 200)
            else:
                if rng.random() < 0.5:
                    cand.append(rng.randint(-100, 100))
                else:
                    if len(cand) > 3:
                        del cand[rng.randrange(len(cand))]
            cand = list(set(cand))
            if len(cand) < 3:
                continue
            s = _score(cand)
            if s > cur_score or (s == cur_score and rng.random() < 0.1):
                cur, cur_score = cand, s
                if s > best_local_score:
                    best_local = cand[:]
                    best_local_score = s
            if it % 2000 == 0 and rng.random() < 0.3:
                cur = best_local[:]
                cur_score = best_local_score
        return best_local, best_local_score

    # Try various sizes
    for n in range(5, 300, 7):
        if time.time() > deadline - 20:
            break
        for scale in [1, 5, 20]:
            s = greedy_sidon(n, 200 * scale, rng)
            sc = _score(s)
            if sc > best_score:
                best, best_score = s[:], sc
            # local search from it
            improved, isc = local_search(s, min(deadline, time.time() + 3))
            if isc > best_score:
                best, best_score = improved[:], isc

    # Final aggressive local search on best
    if time.time() < deadline:
        improved, isc = local_search(best, deadline)
        if isc > best_score:
            best, best_score = improved[:], isc

    # Normalize: shift so min is 0-ish, keep distinct
    best = list(set(best))
    best.sort()
    # small optimization: try translating and scaling
    return best

