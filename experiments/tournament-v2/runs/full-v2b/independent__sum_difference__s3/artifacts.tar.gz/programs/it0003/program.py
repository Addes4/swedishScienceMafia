import math
import random
import time


def _score(a, need_sets=False):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return (0.0, set(), set()) if need_sets else 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if min(sums) <= 0:
        pass
    if len(sums) < 2:
        return (-1e9, diffs, sums) if need_sets else -1e9
    val = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return (val, diffs, sums) if need_sets else val


def _score_from(a, diffs, sums):
    n = len(a)
    if n < 2 or len(sums) < 2:
        return -1e9
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build_bits(k, limit):
    """All numbers with exactly k bits set below 2^limit, sorted."""
    res = []
    for x in range(1, 1 << limit):
        if bin(x).count("1") == k:
            res.append(x)
    return res


def _greedy_sidon(pool, target):
    """Greedily build a set avoiding additive collisions among small sums."""
    A = []
    sums = set()
    used = set()
    random.shuffle(pool)
    for x in pool:
        if len(A) >= target:
            break
        ok = True
        new_sums = set()
        for a in A:
            s = a + x
            if s in sums:
                ok = False
                break
            new_sums.add(s)
        if ok:
            for a in A:
                new_sums.add(a + x)
            for s in new_sums:
                sums.add(s)
            A.append(x)
    return A


def _local_search(A, deadline, rng):
    cur = list(set(A))
    cur_d = set()
    cur_s = set()
    for x in cur:
        for y in cur:
            cur_d.add(x - y)
            cur_s.add(x + y)
    cur_score = _score_from(cur, cur_d, cur_s)
    best = cur[:]
    best_score = cur_score
    n = len(cur)
    step = max(1, (max(cur) - min(cur)) // max(4, n))

    iterations = 0
    while time.time() < deadline:
        iterations += 1
        temp = max(1e-6, 0.02 * (1.0 - iterations / 50000.0))
        # operate on integer values by scaling/shifting a compact representation
        mode = rng.random()
        if mode < 0.5 and n > 2:
            i = rng.randrange(n)
            delta = rng.randint(-step, step)
            if delta == 0:
                continue
            old = cur[i]
            new = old + delta
            if new in cur:
                continue
            cand = cur[:]
            cand[i] = new
        elif mode < 0.8:
            # perturb one element by an offset drawn from a sparse scale
            i = rng.randrange(n)
            delta = rng.choice([-step, step, -2 * step, 2 * step, -1, 1])
            old = cur[i]
            new = old + delta
            if new in cur:
                continue
            cand = cur[:]
            cand[i] = new
        else:
            # add a new element near the current range
            base = rng.choice(cur)
            cand = cur[:]
            new = base + rng.randint(1, step * 2)
            if new in cand:
                continue
            cand.append(new)
        cand = list(set(cand))
        d = set()
        s = set()
        for x in cand:
            for y in cand:
                d.add(x - y)
                s.add(x + y)
        sc = _score_from(cand, d, s)
        if sc > cur_score or (sc == cur_score and rng.random() < 0.5) or rng.random() < math.exp((sc - cur_score) / temp):
            cur = cand
            cur_d = d
            cur_s = s
            cur_score = sc
            if sc > best_score:
                best = cand[:]
                best_score = sc
                n = len(cand)
                if n > 2:
                    step = max(1, (max(cand) - min(cand)) // max(4, n))
        if iterations % 2000 == 0:
            cur = best[:]
            d = set()
            s = set()
            for x in cur:
                for y in cur:
                    s.add(x + y)
                    d.add(x - y)
            cur_d = d
            cur_s = s
            cur_score = _score_from(cur, d, s)
            n = len(cur)
    return best, best_score


def solve():
    end = time.time() + 118
    rng = random.Random(12345)

    candidates = []

    # Construction family: numbers with k ones in binary, scaled/shifted cleverly.
    # These have small additive doubling for some k.
    for k in [2, 3, 4, 5, 6, 7]:
        for limit in [12, 14, 16, 18, 20, 22]:
            if (1 << limit) > (1 << 20):
                continue
            arr = _build_bits(k, limit)
            if len(arr) >= 2:
                candidates.append(arr[:])
        if time.time() > end - 60:
            break

    # Multi-scale version: union of scaled copies to create a structured set
    for shift in [0, 1, 3, 5]:
        for k in [2, 3, 4]:
            arr = [x * (2 ** shift + 1) for x in _build_bits(k, 12)]
            if len(arr) >= 2:
                candidates.append(arr)

    # Greedy greedy
    pool = _build_bits(3, 13) + _build_bits(4, 11) + list(range(1, 60))
    for _ in range(5):
        tgt = rng.randint(8, 40)
        arr = _greedy_sidon(pool[:], tgt)
        if len(arr) >= 2:
            candidates.append(arr)

    # Direct random search baseline
    for _ in range(3):
        n = rng.randint(8, 25)
        arr = [rng.randint(-200, 200) for _ in range(n)]
        candidates.append(arr)

    best = None
    best_score = -1e9

    for arr in candidates:
        sc, _, _ = _score(arr, True)
        if sc > best_score:
            best = list(set(arr))
            best_score = sc

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    # Local search from the best, plus restarts from other promising candidates
    time_left = end - time.time()
    if time_left > 0:
        deadline = time.time() + max(5, time_left * 0.7)
        b, bs = _local_search(best, deadline, rng)
        if bs > best_score:
            best, best_score = b, bs

    # Additional restarts with greedy construction and local polish
    while time.time() < end - 2:
        pool = _build_bits(rng.choice([2, 3, 4, 5]), rng.choice([11, 12, 13, 14, 15]))
        pool += list(range(1, 100))
        tgt = rng.randint(8, 60)
        arr = _greedy_sidon(pool, tgt)
        if len(arr) < 2:
            continue
        deadline = time.time() + min(8, end - time.time() - 1)
        if deadline <= time.time():
            break
        b, bs = _local_search(arr, deadline, rng)
        if bs > best_score:
            best, best_score = b[:], bs

    return sorted(set(best))
