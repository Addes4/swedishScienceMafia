# EVOLVE-BLOCK-START
"""Expected-completion bin packing: score residuals by their probability of being
filled by future items, using an online empirical size histogram instead of
hand-tuned Gaussian bumps."""
import numpy as np

# ---- Online empirical distribution of item sizes -------------------------
# We keep a decayed histogram over sizes 1..100 plus running mean.
_HIST = np.zeros(101, dtype=np.float64)   # index 1..100
_MEAN = 40.0
_N = 0.0
_DECAY = 0.995          # mild recency weighting
_K = 8                  # number of representative sizes used for pair sums
_PAIR_CACHE = None      # cached pair-sum distribution
_PAIR_SIG = None        # signature of histogram state when cache was built


def _update(item):
    global _MEAN, _N
    _HIST[:] *= _DECAY
    _HIST[item] += 1.0
    _N = _N * _DECAY + 1.0
    # decayed mean update
    _MEAN = _MEAN * _DECAY + item
    _MEAN /= (_DECAY + 1.0) if _N < 1.0 else (_N / max(1e-9, _N))  # keep stable
    # simpler robust mean:
    total = _HIST.sum()
    if total > 0:
        idx = np.arange(101)
        _MEAN = float((_HIST * idx).sum() / total)


def _pair_distribution():
    """Return (sums, probs) for sums of two representative sizes, cached."""
    global _PAIR_CACHE, _PAIR_SIG
    total = _HIST.sum()
    if total <= 0:
        return None, None
    sig = (round(float(_HIST.sum()), 3), tuple(np.argsort(_HIST[1:])[-_K:]))
    if _PAIR_CACHE is not None and _PAIR_SIG == sig:
        return _PAIR_CACHE
    top = np.argsort(_HIST[1:])[-_K:] + 1          # representative sizes
    w = _HIST[top]
    w = w / w.sum()
    sums = {}
    for i, a in enumerate(top):
        for j, b in enumerate(top):
            s = int(a + b)
            if s <= 100:
                sums[s] = sums.get(s, 0.0) + w[i] * w[j]
    if not sums:
        _PAIR_CACHE = (np.array([], dtype=np.int64), np.array([], dtype=np.float64))
    else:
        ks = np.array(sorted(sums.keys()), dtype=np.int64)
        vs = np.array([sums[k] for k in ks], dtype=np.float64)
        _PAIR_CACHE = (ks, vs)
    _PAIR_SIG = sig
    return _PAIR_CACHE


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _update(int(item))

    residual = (bins - item).astype(np.float64)
    r = np.maximum(residual, 0.0)

    # --- Weak best-fit base (tie-breaker toward tighter fits) ---
    base = -0.10 * residual

    # --- p1: probability residual matches a typical single future item ---
    p1 = np.zeros_like(r)
    total = _HIST.sum()
    if total > 0:
        idx = np.clip(np.round(r).astype(np.int64), 0, 100)
        # Laplace-smoothed histogram lookup
        dens = (_HIST[idx] + 0.5) / (total + 50.0)
        p1 = dens

    # --- p2: probability residual is a sum of two typical future items ---
    p2 = np.zeros_like(r)
    ks, vs = _pair_distribution()
    if ks is not None and len(ks) > 0:
        # nearest-neighbor lookup in the pair-sum distribution
        ri = np.clip(np.round(r).astype(np.int64), 0, 100)
        # build a full lookup array 0..100
        lut = np.zeros(101, dtype=np.float64)
        lut[ks] = vs
        # smooth a touch so nearby residuals get credit
        kernel = np.array([0.15, 0.7, 0.15])
        lut = np.convolve(lut, kernel, mode="same")
        p2 = lut[ri]

    # --- fill: expected fraction of residual fillable by mean-sized items ---
    mu = max(1.0, _MEAN)
    # expected number of items to fill r, and how well it divides
    k = np.maximum(1.0, np.floor(r / mu))
    frac = r / (k * mu)                 # 1.0 means perfect division
    fill = np.where(r <= 0.5, 1.0, np.clip(frac, 0.0, 1.0))

    # --- sliver guard: penalize tiny unusable residuals (but only mildly) ---
    sliver = np.exp(-0.5 * ((r - 0.5) / 2.0) ** 2)

    # Perfect-fill term kept small and sharp; the histogram terms carry the load.
    perfect = np.exp(-0.5 * (residual / 1.5) ** 2)

    return (
        base
        + 6.0 * perfect
        + 3.5 * p1
        + 4.0 * p2
        + 2.0 * fill
        - 1.0 * sliver
    )
# EVOLVE-BLOCK-END