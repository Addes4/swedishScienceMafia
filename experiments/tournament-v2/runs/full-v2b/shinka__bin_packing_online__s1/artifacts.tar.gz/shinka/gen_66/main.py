# EVOLVE-BLOCK-START
"""Crossover online best-fit: tightest-fit primary rule with layered residual shaping.

Combines the strongest shaping terms from prior variants:
  * Best-fit base (score = -residual) as the dominant signal.
  * Perfect-fill bonus (+0.5) to strongly prefer closing a bin exactly.
  * Asymmetric Gaussian sliver penalty (centered at 0.15*item, width max(0.15*item,1),
    weight -3.0) applied only for r>0, effectively avoiding unusable tiny residuals.
  * Hard dead-zone penalty for residuals 1..4 (essentially unusable).
  * Item-dependent useful-target Gaussian (center blends 100-2*item for small items
    toward ~40 for large items), weight 0.3, encouraging residuals that pair with a
    typical future item.
  * Complementary-pair Gaussian reward near r = 100 - item (weight 3.0, width 0.35*item)
    so bins closable by a future mirror item are gently preferred.
  * Comparable-residual Gaussian reward near r = item (weight 1.5) so bins that can
    accept another item of similar size are preferred.

All shaping terms are smaller than the best-fit slope (1 per unit residual), so they
only break ties and nudge near-ties, preserving the proven best-fit behavior.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)

    # Primary: best-fit (tightest fit first).
    score = -r

    # Perfect fill -> strongly preferred (avoids opening a new bin).
    score += np.where(residual == 0, 0.5, 0.0)

    # Asymmetric sliver penalty: residuals that waste capacity are penalized more
    # steeply than large residuals. Gaussian centered at 0.15*item, width 0.15*item,
    # weighted -3.0. Evaluated only for r > 0 to leave the perfect-fill bonus intact.
    center_sliver = 0.15 * item
    width_sliver = max(0.15 * item, 1.0)
    sliver = np.exp(-((r - center_sliver) / width_sliver) ** 2)
    score += np.where(r > 0, -3.0 * sliver, 0.0)

    # Hard dead-zone: residuals 1..4 are essentially unusable.
    score += np.where((r > 0) & (r < 5), -0.5, 0.0)

    # Item-dependent useful-target Gaussian: for small items, two-item fills are
    # typical, so target ~ 100 - 2*item; for mid/large items, fall back toward the
    # distribution mean (~40).
    w = np.clip((item - 30.0) / 40.0, 0.0, 1.0)
    small_target = np.clip(100.0 - 2.0 * item, 20.0, 60.0)
    center = (1.0 - w) * small_target + w * 40.0
    score += 0.3 * np.exp(-((r - center) / 18.0) ** 2)

    # Soft complementary-pair shaping: residual that a future item of size
    # (100 - item) could close.
    width = 0.35 * float(item) + 1e-9
    score += 3.0 * np.exp(-0.5 * ((r - (100.0 - float(item))) / width) ** 2)

    # Comparable residual: fits another item of similar size.
    score += 1.5 * np.exp(-0.5 * ((r - float(item)) / width) ** 2)

    return score
# EVOLVE-BLOCK-END