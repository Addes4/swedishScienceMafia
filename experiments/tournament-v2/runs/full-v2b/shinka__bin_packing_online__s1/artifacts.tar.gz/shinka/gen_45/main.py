# EVOLVE-BLOCK-START
"""Relaxed asymmetric sliver-aware best fit.

Best-fit is a strong online rule, but pure best-fit over-packs tight residuals
that no future item can reclaim. Following the earlier finding that a relaxed
base (weight -0.15) combined with an asymmetric sliver penalty at weight -2.5
performs best, we use:

* a relaxed best-fit base (-0.15 * residual) so bin choice is not dominated by
  the tightest fit alone,
* a strong perfect-fill bonus,
* an asymmetric one-sided Gaussian sliver penalty centered at 0.12*item with
  width 0.14*item, weight -2.5 (only for r > 0),
* a small dead-zone penalty for residuals 1..4,
* a mild bonus for residuals large enough to fit a typical future item (~40).
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)

    # Relaxed best-fit base: prefer tight fits, but not overwhelmingly.
    score = -0.15 * r

    # Perfect fill: strongly preferred (avoids opening a new bin).
    score += np.where(residual == 0, 0.5, 0.0)

    # Asymmetric sliver penalty: one-sided Gaussian centered at 0.12*item,
    # width 0.14*item, weight -2.5. Only applied for r > 0 so the
    # perfect-fill bonus is untouched.
    center = 0.12 * item
    width = max(0.14 * item, 1.0)
    sliver = np.exp(-((r - center) / width) ** 2)
    score += np.where(r > 0, -2.5 * sliver, 0.0)

    # Hard dead-zone: residuals 1..4 are essentially unusable.
    score += np.where((r > 0) & (r < 5), -0.3, 0.0)

    # Useful bonus: residual big enough for a typical future item (~40).
    score += np.clip((r - 30.0) / 10.0, 0.0, 1.0) * 0.2

    return score
# EVOLVE-BLOCK-END
