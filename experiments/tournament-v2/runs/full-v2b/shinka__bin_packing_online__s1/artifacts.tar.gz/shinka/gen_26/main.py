# EVOLVE-BLOCK-START
"""Online best-fit with residual shaping to avoid unusable slivers.

Items are Weibull-shaped with mean ~40. Pure best-fit already works well, but
it sometimes creates tiny residuals (1..15) that cannot fit any future item,
effectively wasting that bin's remaining space. We keep best-fit as the primary
rule and add a bounded secondary preference for residuals that are either
perfect (0) or large enough (>= ~40) to hold a typical future item, while
slightly penalizing tiny residuals.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown

    # Primary: best-fit (tightest fit first).
    score = -residual.astype(np.float64)

    # Secondary: shape the residual preference with an item-dependent target.
    # For small items, two-item fills are typical, so we want the residual to
    # pair with a future item toward a full bin: target ~ 100 - 2*item.
    # For mid/large items, fall back toward the distribution mean (~40).
    r = residual.astype(np.float64)

    w = np.clip((item - 30.0) / 40.0, 0.0, 1.0)
    small_target = np.clip(100.0 - 2.0 * item, 20.0, 60.0)
    center = (1.0 - w) * small_target + w * 40.0

    # Gaussian preference for residuals near the item-dependent target.
    useful_bonus = 0.3 * np.exp(-((r - center) / 18.0) ** 2)

    # Perfect fill -> strongly preferred (avoids opening a new bin).
    perfect_bonus = np.where(r == 0, 0.5, 0.0)

    # Tiny residual (1..14) -> likely wasted, mildly penalized.
    sliver_penalty = np.where((r > 0) & (r < 15), -0.3, 0.0)

    score += perfect_bonus + useful_bonus + sliver_penalty
    return score
# EVOLVE-BLOCK-END