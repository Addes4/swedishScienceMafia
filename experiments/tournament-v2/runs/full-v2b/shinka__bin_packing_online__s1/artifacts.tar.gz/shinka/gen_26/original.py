# EVOLVE-BLOCK-START
"""Online best-fit with residual shaping to avoid unusable slivers.

Items are Weibull-shaped with mean ~40. Pure best-fit already works well, but
it sometimes creates tiny residuals (1..15) that cannot fit any future item,
effectively wasting that bin's remaining space. We keep best-fit as the primary
rule and add a bounded secondary preference for residuals that are either
perfect (0) or large enough (>= ~40) to hold a typical future item, while
slightly penalizing tiny residuals.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown

    # Primary: best-fit (tightest fit first).
    score = -residual.astype(np.float64)

    # Secondary: shape the residual preference.
    # Perfect fill -> strongly preferred (avoids opening a new bin).
    # Residual >= 40 -> room for a typical future item, mildly preferred.
    # Tiny residual (1..14) -> likely wasted, mildly penalized.
    # Smooth transition between 15 and 40.
    r = residual.astype(np.float64)
    # bonus: 0.5 at r==0, decaying to 0 by r==15
    perfect_bonus = np.where(r == 0, 0.5, 0.0)
    # useful bonus: 0 at r<=15, rising to 0.3 at r>=40
    useful_bonus = np.clip((r - 15.0) / 25.0, 0.0, 1.0) * 0.3
    # sliver penalty: -0.3 for r in (0, 15), 0 otherwise
    sliver_penalty = np.where((r > 0) & (r < 15), -0.3, 0.0)

    score += perfect_bonus + useful_bonus + sliver_penalty
    return score
# EVOLVE-BLOCK-END