# EVOLVE-BLOCK-START
"""Concave-utility bin packing: best-fit relaxed with distribution-aware residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)

    # Relaxed best-fit base: very small slope so distribution-aware bonuses
    # dominate the ranking and can freely reorder decisions.
    base = -0.15 * residual

    # (1) Bonus for near-perfect fills (residual ~ 0). Slightly sharper than
    # the reference to favor tight fits more strongly.
    perfect = np.exp(-0.5 * (residual / 1.5) ** 2)

    # (2) Broad bonus for residuals near the distribution mean (~40):
    #     leftover space of this size is likely to be filled by a future item.
    usable = np.exp(-0.5 * ((residual - 40.0) / 18.0) ** 2)

    # (3) Sharp complementary-pair bonus: prefer residuals close to the current
    #     item size, encouraging two items to fill a bin tightly together.
    pair = np.exp(-0.5 * ((residual - float(item)) / max(1.0, 0.40 * item)) ** 2)

    # (4) Asymmetric sliver penalty: penalize residuals that are too small to
    #     be useful, more steeply on the small side. Plus a hard dead-zone
    #     penalty for residuals in (0, 5).
    sliver_center = 0.15 * item
    sliver_width = max(1.0, 0.15 * item)
    sliver = np.where(residual < sliver_center,
                      np.exp(-0.5 * ((residual - sliver_center) / sliver_width) ** 2),
                      0.0)
    dead_zone = np.where((residual > 0) & (residual < 5), 1.0, 0.0)

    return base + 8.0 * perfect + 3.5 * usable + 6.0 * pair - 3.0 * sliver - 1.5 * dead_zone
# EVOLVE-BLOCK-END