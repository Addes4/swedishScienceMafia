# EVOLVE-BLOCK-START
"""Best-fit with asymmetric sliver penalty and perfect-fill reward.

Items are Weibull-shaped with mean ~40. Pure best-fit is a strong baseline, but
it sometimes leaves small residuals that no future item can use. We keep
best-fit as the primary rule and add:

* A strong perfect-fill Gaussian centered at residual 0 (weight 8.0, width 2.0).
* A one-sided asymmetric sliver penalty: a Gaussian centered at 0.15*item with
  width 0.15*item at weight -2.5. This is steeper on the small-residual side,
  discouraging unusable slivers just above the item size, without creating a
  hard dead-zone.
* A complementary-pair term that mildly rewards residuals near 100 - item,
  which a future complementary item could close.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)

    # Primary: best-fit (tightest fit first), moderate strength.
    score = -1.0 * r

    # Strongly reward perfect fills (explicit, sharp Gaussian).
    score += 8.0 * np.exp(-0.5 * (r / 2.0) ** 2)

    # Asymmetric sliver penalty: steeper on the small-residual side.
    # Center at 0.15*item, width 0.15*item, weight -2.5.
    sliver_center = 0.15 * float(item)
    sliver_width = 0.15 * float(item) + 1e-9
    score -= 2.5 * np.exp(-0.5 * ((r - sliver_center) / sliver_width) ** 2)

    # Complementary-pair shaping: residuals near 100 - item can be closed later.
    center = 100.0 - float(item)
    width = max(2.0, 0.2 * float(item))
    score += 2.0 * np.exp(-0.5 * ((r - center) / width) ** 2)

    return score
# EVOLVE-BLOCK-END