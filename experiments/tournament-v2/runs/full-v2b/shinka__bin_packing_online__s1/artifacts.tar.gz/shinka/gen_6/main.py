# EVOLVE-BLOCK-START
"""Adaptive residual banding: best-fit with a non-linear band bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Base best-fit score: tighter fits (smaller residual) get higher priority.
    residual = bins - item
    base = -residual.astype(np.float64)

    # Two-component residual bonus exploiting the known item-size distribution
    # (Weibull-shaped, mean ~40):
    #   (1) a sharp bonus for near-perfect fills (residual ~ 0), reinforcing
    #       best-fit and breaking ties in its favor;
    #   (2) a broad bonus for residuals near the distribution mean (~40), since
    #       such leftover space is likely to be filled by a future item.
    # The base best-fit term stays dominant; the bonuses are large enough
    # (a few units) to reorder only near-ties among similar residuals.
    perfect = np.exp(-0.5 * (residual / 2.0) ** 2)
    usable = np.exp(-0.5 * ((residual - 40.0) / 15.0) ** 2)

    return base + 4.0 * perfect + 3.0 * usable
# EVOLVE-BLOCK-END