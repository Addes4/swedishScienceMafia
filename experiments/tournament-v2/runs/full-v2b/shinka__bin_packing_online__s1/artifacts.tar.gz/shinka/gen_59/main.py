# EVOLVE-BLOCK-START
"""Distribution-driven residual-energy bin packing."""
import numpy as np


def priority(item, bins):
    """Rank bins by expected future fillability of the resulting residual.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of each fitting bin.
    """
    residual = (bins - item).astype(np.float64)
    it = float(item)

    # --- Empirical size distribution model (Weibull-ish, mean ~40) ---
    # Approximate density of item sizes peaking near 30-40 with a long tail.
    # Use a log-normal-like shape in log space for smoothness.
    def size_density(x):
        x = np.maximum(x, 0.5)
        mu = np.log(38.0)
        sigma = 0.75
        return np.exp(-0.5 * ((np.log(x) - mu) / sigma) ** 2) / x

    # --- Best-fit base with size-adaptive slope ---
    # Large items: strongly prefer tight fits (avoid wasting big capacity).
    # Small items: looser, since many small items can still fill the bin.
    slope = 0.35 + 0.30 * np.clip((it - 20.0) / 60.0, 0.0, 1.0)
    base = -slope * residual

    # --- Perfect-fill bonus (residual near 0) ---
    perfect = np.exp(-0.5 * (residual / 1.5) ** 2)

    # --- Fillability of the residual under the size distribution ---
    # A residual r is "good" if there is a high density of item sizes s <= r
    # that would leave a small residual (r - s) afterward. Integrate the
    # density of s weighted by (r - s) smallness, approximated by evaluating
    # density at a few representative sizes.
    fill = np.zeros_like(residual)
    for s in (10.0, 20.0, 30.0, 40.0, 55.0, 70.0):
        fits = (residual >= s).astype(np.float64)
        leftover = np.maximum(residual - s, 0.0)
        # Reward if leftover can itself be filled (recursive one-step lookahead)
        leftover_quality = np.exp(-0.5 * ((leftover - 30.0) / 20.0) ** 2)
        fill += fits * size_density(s) * (1.0 + 1.2 * leftover_quality)

    # --- Complementarity: residual matches a typical item size ---
    # If residual is close to a common item size, a future item likely fills
    # this bin well. Weight by density at the residual value.
    comp = size_density(residual) * np.exp(-0.5 * ((residual - it) / max(1.0, 0.4 * it)) ** 2)

    # --- Sliver penalty: avoid tiny unusable leftovers ---
    sliver = np.exp(-0.5 * ((residual - 0.25 * it) / max(1.0, 0.25 * it)) ** 2)

    # --- Broad usability: residual near distribution mean is broadly useful ---
    usable = np.exp(-0.5 * ((residual - 38.0) / 18.0) ** 2)

    return (base
            + 8.0 * perfect
            + 5.0 * fill
            + 4.0 * comp
            + 2.5 * usable
            - 2.0 * sliver)
# EVOLVE-BLOCK-END