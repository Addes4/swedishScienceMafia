# EVOLVE-BLOCK-START
"""Relaxed dual-band best-fit: weak best-fit base with distribution-aware bonuses dominating."""
import numpy as np

# Running statistics of past items (decayed Welford-style).
_state = {
    "n": 0.0,
    "mean": 40.0,
    "m2": 0.0,
    "decay": 0.999,
}


def _update_stats(item):
    d = _state["decay"]
    # Decay the effective count so recent items weigh slightly more.
    n = _state["n"] * d + 1.0
    delta = item - _state["mean"]
    mean = _state["mean"] + delta / n
    m2 = _state["m2"] * d + delta * (item - mean)
    _state["n"] = n
    _state["mean"] = mean
    _state["m2"] = m2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _update_stats(float(item))

    residual = (bins - item).astype(np.float64)

    # Very weak best-fit base: bonuses dominate the ranking.
    base = -0.12 * residual

    # (1) Sharp perfect-fill bonus.
    perfect = np.exp(-0.5 * (residual / 1.0) ** 2)

    # (2) Distribution-adaptive "usable residual" bump around the empirical mean.
    n = _state["n"]
    if n > 2.0:
        var = _state["m2"] / max(1.0, n - 1.0)
        std = max(5.0, float(np.sqrt(max(var, 0.0))))
        center = float(_state["mean"])
    else:
        std = 20.0
        center = 40.0
    width = max(6.0, 0.4 * std)
    usable = np.exp(-0.5 * ((residual - center) / width) ** 2)

    # (3) Complementary-pair bonus: residual close to current item size.
    pair = np.exp(-0.5 * ((residual - float(item)) / max(1.0, 0.5 * item)) ** 2)

    # (4) Mild penalty for unusable slivers just above the item.
    sliver = np.exp(-0.5 * ((residual - 3.0) / 3.0) ** 2)

    # (5) Small penalty for barely-above-zero residuals that aren't near-perfect,
    #     which tend to become unusable slivers later.
    near = np.exp(-0.5 * ((residual - 0.15 * item) / max(1.0, 0.12 * item)) ** 2)

    return (
        base
        + 10.0 * perfect
        + 4.5 * usable
        + 4.0 * pair
        - 1.5 * sliver
        - 0.8 * near
    )
# EVOLVE-BLOCK-END