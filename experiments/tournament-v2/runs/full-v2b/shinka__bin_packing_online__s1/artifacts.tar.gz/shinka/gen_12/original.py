# EVOLVE-BLOCK-START
"""Adaptive dual-band best-fit: strong best-fit base with distribution-aware bonuses."""
import numpy as np

# Running statistics of past items (exponential moving average).
_state = {
    "n": 0.0,
    "mean": 40.0,
    "m2": 0.0,   # for variance
}


def _update_stats(item):
    n = _state["n"] + 1.0
    delta = item - _state["mean"]
    mean = _state["mean"] + delta / n
    m2 = _state["m2"] + delta * (item - mean)
    _state["n"] = n
    _state["mean"] = mean
    _state["m2"] = m2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _update_stats(float(item))

    residual = (bins - item).astype(np.float64)

    # Strong-ish best-fit base: tighter fits strongly preferred.
    base = -0.6 * residual

    # (1) Sharp perfect-fill bonus.
    perfect = np.exp(-0.5 * (residual / 1.0) ** 2)

    # (2) Distribution-adaptive "usable residual" bump.
    n = _state["n"]
    if n > 1.0:
        var = _state["m2"] / (n - 1.0)
        std = max(5.0, float(np.sqrt(max(var, 0.0))))
        center = float(_state["mean"])
    else:
        std = 20.0
        center = 40.0
    width = max(8.0, 0.5 * std)
    usable = np.exp(-0.5 * ((residual - center) / width) ** 2)

    # (3) Complementary-pair bonus: residual close to current item size.
    pair = np.exp(-0.5 * ((residual - float(item)) / max(1.0, 0.5 * item)) ** 2)

    # (4) Tiny penalty for unusable slivers (too small to fit typical future items).
    sliver = np.exp(-0.5 * ((residual - 2.0) / 2.0) ** 2)

    return base + 10.0 * perfect + 4.0 * usable + 4.0 * pair - 1.0 * sliver
# EVOLVE-BLOCK-END