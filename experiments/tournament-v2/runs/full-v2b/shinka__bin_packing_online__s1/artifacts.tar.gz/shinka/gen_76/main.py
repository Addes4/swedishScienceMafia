# EVOLVE-BLOCK-START
"""Concave-utility bin packing: kernel-bank best-fit with a ladder of
distribution-aware complementary targets.

The scoring rule is factored into two parts:
  * a relaxed best-fit base slope that breaks near-ties toward tighter fits;
  * a small bank of Gaussian "kernels", each targeting a residual value that
    is likely to be completed by a future item drawn from the same
    Weibull-shaped distribution (mean ~ 40).

Each kernel is described by (center, width, weight, gate).  The gate is an
optional per-item scalar in [0, 1] that smoothly enables/disables the kernel
based on the arriving item's size.  This keeps the policy declarative and
easy to rebalance while the mechanism (Gaussian evaluation) stays fixed.
"""
import numpy as np


def _gauss(residual, center, width):
    """Unit-peak Gaussian kernel evaluated at every residual."""
    w = width if width > 1e-9 else 1e-9
    return np.exp(-0.5 * ((residual - center) / w) ** 2)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item : integer size of the arriving item, 1..100.
    bins : numpy int64 array of remaining capacities of every bin the item
           fits in (including unused bins with capacity 100), in bin order.

    Ties go to the first bin with the highest score.
    """
    residual = (bins - item).astype(np.float64)
    it = float(item)

    # --- Relaxed best-fit base ---------------------------------------------
    # Small negative slope: tighter fits are mildly preferred, but the
    # distribution-aware kernels below dominate the ranking.
    score = -0.16 * residual

    # --- (1) Perfect-fill bonus --------------------------------------------
    # Reward residuals very close to 0 (bin is filled almost exactly).
    score += 8.0 * _gauss(residual, 0.0, 2.0)

    # --- (2) Broad "usable leftover" bonus ---------------------------------
    # Leftover space near the distribution mean (~40) is likely to be filled
    # by a future item, so it is a productive residual to leave behind.
    score += 3.0 * _gauss(residual, 40.0, 18.0)

    # --- (3) Ladder of complementary exact-fill targets --------------------
    # Each rung targets a residual value that a future item (or pair of items)
    # could use to complete this bin exactly.  Widths scale with the item so
    # that the kernels stay sharp for small items and broad for large ones.
    width_pair = max(1.0, 0.35 * it)

    # (3a) pair: residual ~ item  -> a future same-size item completes the bin.
    score += 6.0 * _gauss(residual, it, width_pair)

    # (3b) comp: residual ~ 100 - item -> a future same-size item completes it.
    score += 2.5 * _gauss(residual, 100.0 - it, max(1.0, 0.20 * it))

    # (3c) comp2: residual ~ 100 - 2*item -> two future same-size items finish
    #      it.  Only plausible for small items, so gate it smoothly.
    comp2_gate = float(np.clip((35.0 - it) / 35.0, 0.0, 1.0))
    if comp2_gate > 0.0:
        score += 2.0 * comp2_gate * _gauss(
            residual, 100.0 - 2.0 * it, max(1.0, 0.20 * it)
        )

    # (3d) twin: residual ~ 2*item -> the current item is the smaller half of a
    #      complementary pair.  Gate to small/medium items where 2*item is a
    #      plausible leftover; disable for large items where it is unreachable.
    twin_gate = float(np.clip((50.0 - it) / 50.0, 0.0, 1.0))
    if twin_gate > 0.0:
        score += 1.5 * twin_gate * _gauss(
            residual, 2.0 * it, max(1.0, 0.25 * it)
        )

    # --- (4) Mild sliver penalty -------------------------------------------
    # Discourage leaving a tiny, hard-to-use gap just above the item size.
    score -= 2.0 * _gauss(residual, 0.25 * it, max(1.0, 0.25 * it))

    return score
# EVOLVE-BLOCK-END