# EVOLVE-BLOCK-START
"""Concave-utility bin packing: best-fit relaxed with distribution-aware residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)

    # Relaxed best-fit base: very small slope so distribution-aware bonuses
    # dominate the ranking and can freely reorder decisions. Slightly steeper
    # than -0.15 to reduce fragmentation given the added comp2 term.
    base = -0.18 * residual

    # (1) Bonus for near-perfect fills (residual ~ 0).
    perfect = np.exp(-0.5 * (residual / 2.0) ** 2)

    # (2) Broad bonus for residuals near the distribution mean (~40):
    #     leftover space of this size is likely to be filled by a future item.
    usable = np.exp(-0.5 * ((residual - 40.0) / 18.0) ** 2)

    # (3) Sharp complementary-pair bonus: prefer residuals close to the current
    #     item size, encouraging two items to fill a bin tightly together.
    pair = np.exp(-0.5 * ((residual - float(item)) / max(1.0, 0.35 * item)) ** 2)

    # (3b) Complementary-pair bonus at 100 - item: prefer residuals that would
    #      let a future item of the same size complete this bin exactly. This
    #      extends the strongest lever (pair bonus) rather than replacing it.
    comp = np.exp(-0.5 * ((residual - (100.0 - item)) / max(1.0, 0.2 * item)) ** 2)

    # (3c) Three-item completion bonus: prefer residuals near 100 - 2*item,
    #      where the current item plus two future items of the same size fill
    #      the bin exactly. For small/medium items this residual is frequently
    #      realizable and sharpens the broad `usable` peak toward exact fills.
    comp2 = np.exp(-0.5 * ((residual - (100.0 - 2.0 * item)) / max(1.0, 0.2 * item)) ** 2)

    # (4) Asymmetric penalty for tiny unusable slivers just above the item.
    #     Centered slightly below 0.25*item with a narrower width, so the
    #     penalty is steeper on the small-residual side (where space is truly
    #     wasted) and gentler on the larger-residual side.
    sliver = np.exp(-0.5 * ((residual - 0.15 * item) / max(1.0, 0.15 * item)) ** 2)

    return base + 8.0 * perfect + 3.0 * usable + 6.0 * pair + 2.0 * comp + 1.5 * comp2 - 2.5 * sliver
# EVOLVE-BLOCK-END