# EVOLVE-BLOCK-START
"""Adaptive best-fit with online size-frequency model for complementary fills."""
import numpy as np

# Running histogram of item sizes (1..100). Index 0 unused.
_size_hist = np.zeros(101, dtype=np.float64)
_total_items = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _size_hist, _total_items

    # Update online histogram (Laplace-smoothed probability of future sizes).
    _size_hist[item] += 1.0
    _total_items += 1.0
    # Smoothed probability mass for each possible size 1..100.
    # Use a small prior so early decisions aren't too noisy.
    prob = (_size_hist[1:] + 0.5) / (_total_items + 50.0)
    # prob[k-1] is probability of size k.

    residual = bins - item  # int64 array

    # Base: best fit (minimize leftover).
    score = -residual.astype(np.float64)

    # Reward residuals that match a likely future item size (complementary fill).
    # Clip residual to [1,100]; residual 0 is perfect and handled separately.
    res_clip = np.clip(residual, 1, 100).astype(np.int64)
    fill_prob = prob[res_clip - 1]  # probability that this residual is exactly filled next
    # Scale: a residual that is likely to be filled is almost as good as a perfect fill.
    score += 60.0 * fill_prob

    # Strong bonus for perfect fills.
    score += np.where(residual == 0, 2.0, 0.0)

    # Penalize tiny residuals that are unlikely to be filled (dead zone).
    # Use the learned minimum plausible size: if residual is below the 5th percentile
    # of observed sizes, it's likely wasted.
    if _total_items > 20:
        # approximate 5th percentile of observed sizes
        cum = np.cumsum(_size_hist[1:])
        cum /= cum[-1]
        idx = np.searchsorted(cum, 0.05)
        min_useful = idx + 1  # size at 5th percentile
    else:
        min_useful = 5
    dead = (residual > 0) & (residual < min_useful)
    score -= np.where(dead, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END