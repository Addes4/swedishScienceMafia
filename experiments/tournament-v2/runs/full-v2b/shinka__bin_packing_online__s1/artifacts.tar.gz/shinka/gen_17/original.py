# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize leftover (best fit). Secondary: avoid leaving tiny,
    # unusable gaps by slightly preferring perfect fills or comfortably large
    # residuals over small nonzero ones.
    threshold = max(20, item // 2)
    bonus = np.where((residual == 0) | (residual >= threshold), 0.5, 0.0)
    return -residual + bonus
# EVOLVE-BLOCK-END