# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best-fit base score: prefer the tightest fit.
    score = -residual.astype(np.float64)
    # Avoid creating dead-zone gaps that future (mean ~40) items cannot use.
    # Reward perfect fills and residuals large enough for a typical item;
    # penalize tiny nonzero residuals that are almost certainly wasted.
    score += np.where(residual == 0, 0.5,
             np.where(residual >= 30, 0.25,
             np.where(residual < 10, -0.25, 0.0)))
    return score
# EVOLVE-BLOCK-END