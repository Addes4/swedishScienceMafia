# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    r = residual.astype(np.float64)

    # Best-fit base score: prefer the tightest fit.
    score = -r

    # Perfect fill: strongly preferred (avoids opening a new bin).
    score += np.where(residual == 0, 0.5, 0.0)

    # Asymmetric sliver penalty: slivers waste capacity no future item can
    # reclaim, so penalize small residuals more steeply than large ones.
    # Gaussian centered at 0.15*item, width 0.15*item, weighted -3.0.
    # Evaluated only for r > 0 to leave the perfect-fill bonus intact.
    center = 0.15 * item
    width = max(0.15 * item, 1.0)
    sliver = np.exp(-((r - center) / width) ** 2)
    score += np.where(r > 0, -3.0 * sliver, 0.0)

    # Hard dead-zone: residuals 1..4 are essentially unusable.
    score += np.where((r > 0) & (r < 5), -0.5, 0.0)

    # Useful bonus: residual big enough for a typical future item (~40).
    score += np.clip((r - 30.0) / 10.0, 0.0, 1.0) * 0.3

    return score
# EVOLVE-BLOCK-END