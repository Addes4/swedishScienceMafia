# EVOLVE-BLOCK-START
"""Online best-fit with smooth residual shaping plus crisp threshold bonuses.

Combines the smooth, item-dependent Gaussian "useful residual" bonus with the
robust threshold-based shaping (perfect fill reward, large-residual reward,
tiny-residual penalty). Best-fit remains the primary rule; all secondary terms
are bounded and small so they only break near-ties.

Items are Weibull-shaped with mean ~40, so:
  * residual == 0        -> perfect fill, strongly preferred
  * residual >= 30       -> can hold a typical future item, mildly preferred
  * residual in 1..11    -> likely wasted sliver, mildly penalized
  * otherwise            -> smooth Gaussian centered at an item-dependent target
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)

    # Primary: best-fit (tightest fit first).
    score = -r

    # ---- Smooth, item-dependent useful-residual bonus ----
    # For small items, two-item fills are typical, so target ~ 100 - 2*item.
    # For mid/large items, fall back toward the distribution mean (~40).
    w = np.clip((item - 30.0) / 40.0, 0.0, 1.0)
    small_target = np.clip(100.0 - 2.0 * item, 20.0, 60.0)
    center = (1.0 - w) * small_target + w * 40.0
    score += 0.3 * np.exp(-((r - center) / 18.0) ** 2)

    # ---- Crisp threshold shaping (cheap, robust) ----
    # Perfect fill -> strongly preferred (avoids opening a new bin).
    score += np.where(r == 0.0, 0.6, 0.0)
    # Residual large enough for a typical future item -> mildly preferred.
    score += np.where((r >= 30.0) & (r > 0.0), 0.25, 0.0)
    # Tiny residual (1..11) -> likely wasted sliver, mildly penalized.
    score -= np.where((r > 0.0) & (r < 12.0), 0.3, 0.0)

    return score
# EVOLVE-BLOCK-END