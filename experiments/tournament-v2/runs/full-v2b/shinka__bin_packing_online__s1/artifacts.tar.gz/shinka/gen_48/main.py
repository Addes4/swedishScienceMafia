# EVOLVE-BLOCK-START
"""Online best-fit with an adaptive, empirically-learned residual-utility model.

Instead of a fixed hand-tuned residual shaping (Gaussian bumps, sliver
penalties, etc.), this policy learns online which residual capacities are
actually useful. It keeps a histogram of residuals observed after each
placement and a histogram of residuals that were subsequently "hit" (i.e. a
later item fit into that bin). The smoothed ratio gives an empirical hazard
rate: how likely a residual of size r is to be filled by a future item.

Each arriving item is placed to maximize a weak best-fit base plus a bonus
proportional to the learned hazard of the residual the item would leave.

Early in the instance, when statistics are thin, the policy falls back to
best-fit with a perfect-fill bonus, so it degrades gracefully.
"""
import numpy as np

# Capacity of the bins.
CAP = 100

# Histogram over residuals 0..CAP. Bucket r counts residual exactly r.
# State persists across calls (module-level), reset lazily per instance by
# detecting a fresh start (all bins full / no history yet is handled by the
# harness calling once per item; we simply accumulate).
_obs = np.zeros(CAP + 1, dtype=np.float64)      # residuals observed after placement
_hit = np.zeros(CAP + 1, dtype=np.float64)      # residuals later consumed by an item
_prev_residual = None                            # residual left in the chosen bin last call
_prev_bin_slot = None                            # not needed; we track via _last_choice
_last_choice_residual = None

# Smoothing and weighting.
_ALPHA = 2.0          # Laplace-style smoothing for hazard estimate
_HAZARD_W = 4.0       # weight on learned hazard
_BESTFIT_W = 0.15     # weak best-fit base
_PERFECT = 1.0        # perfect-fill bonus


def _hazard(residuals):
    """Smoothed empirical hazard rate for integer residuals (float array)."""
    # Smoothed ratio hit / obs for each integer residual bucket.
    h = (_hit + _ALPHA * 0.5) / (_obs + _ALPHA)
    # Gaussian smoothing across neighboring residual values so nearby residuals
    # share information (kernel radius ~5).
    k = np.arange(-5, 6, dtype=np.float64)
    kernel = np.exp(-0.5 * (k / 2.0) ** 2)
    kernel /= kernel.sum()
    hs = np.convolve(h, kernel, mode="same")
    idx = np.clip(residuals.astype(np.int64), 0, CAP)
    return hs[idx]


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _last_choice_residual

    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)

    # --- Account for the previous choice: did the item we just placed land in
    #     a bin whose residual we previously recorded? We update the "hit"
    #     count for the residual that existed before this item arrived.
    #     The harness gives us only the current bins, so we reconstruct: the
    #     residual before this item was (current residual + item) for the bin
    #     that changed. We approximate by crediting the residual we recorded
    #     last call if any bin now shows that residual reduced by exactly item.
    if _last_choice_residual is not None:
        # The bin we chose last time had residual R; after placing item it has
        # residual R - item. If such a bin exists now, its old residual R was
        # "hit" by this item.
        R = _last_choice_residual
        if 0 <= R <= CAP:
            # A bin now showing R - item (>=0) means our prior residual was used.
            if R - item >= 0:
                _hit[R] += 1.0

    # --- Base score: weak best-fit + perfect-fill bonus.
    score = -_BESTFIT_W * r
    score += np.where(r == 0, _PERFECT, 0.0)

    # --- Learned residual utility: reward residuals that historically get used.
    score += _HAZARD_W * _hazard(r)

    # --- Record this decision's residual (the chosen bin's residual after
    #     placement). We don't know the harness's choice yet, but the argmax
    #     of our score is what it will pick (ties -> first). Compute it here.
    best_idx = int(np.argmax(score))
    chosen_residual_after = int(r[best_idx])
    _last_choice_residual = chosen_residual_after + item  # residual before placement

    # Update observed-residual histogram for the residual we will leave behind,
    # but only if the chosen bin is not a brand-new (full) bin. New bins leave
    # a residual of 100 - item, which we still record.
    _obs[min(chosen_residual_after, CAP)] += 1.0

    return score
# EVOLVE-BLOCK-END