# EVOLVE-BLOCK-START
"""Adaptive residual banding: best-fit with a non-linear band bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Base best-fit score: tighter fits (smaller residual) get higher priority.
    residual = bins - item
    base = -residual.astype(np.float64)

    # Non-linear band bonus: prefer residuals that are a bit larger than the item
    # (i.e., leave some usable space) but not too large, to reduce fragmentation.
    # We use a smooth bump centered at residual = item (i.e., bin capacity ~ 2*item),
    # which for typical items (20-60) corresponds to residuals 20-60.
    # This is parameter-free and adapts to the current item size.
    center = float(item)
    width = max(1.0, 0.5 * item)
    band = np.exp(-0.5 * ((residual - center) / width) ** 2)

    # Small weight for the band bonus; the base best-fit dominates.
    # The weight is chosen small enough not to hurt tight fits much.
    return base + 2.0 * band
# EVOLVE-BLOCK-END
