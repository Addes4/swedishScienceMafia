# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Relaxed best-fit base: only a weak preference for the tightest fit, so the
    # distribution-aware shaping terms below can dominate more decisions.
    score = -0.15 * residual.astype(np.float64)
    # Strongly reward perfect fills.
    score += np.where(residual == 0, 1.0, 0.0)
    # Penalize dead-zone residuals that no typical future item can use.
    score -= np.where((residual > 0) & (residual < 30), 0.4, 0.0)
    # Reward residuals large enough to still accept a typical (~40) item.
    score += np.where(residual >= 35, 0.2, 0.0)
    return score
# EVOLVE-BLOCK-END