# EVOLVE-BLOCK-START
"""Concave-utility bin packing: best-fit relaxed with distribution-aware residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)

    # Relaxed best-fit base: very small slope so distribution-aware bonuses
    # dominate the ranking and can freely reorder decisions.
    base = -0.15 * residual

    # (1) Bonus for near-perfect fills (residual ~ 0).
    perfect = np.exp(-0.5 * (residual / 2.0) ** 2)

    # (2) Broad bonus for residuals near an item-dependent target: the leftover
    #     that a future item can actually fill depends on the current item's
    #     size. For small items a larger leftover (allowing a further pair) is
    #     valuable; for large items only a small leftover is realistic. Blend
    #     the pure pair target (100 - 2*item) with the distribution mean (~40)
    #     and clamp to a sensible range.
    center = np.clip(70.0 - float(item), 15.0, 65.0)
    usable = np.exp(-0.5 * ((residual - center) / 18.0) ** 2)

    # (3) Sharp complementary-pair bonus: prefer residuals close to the current
    #     item size, encouraging two items to fill a bin tightly together.
    pair = np.exp(-0.5 * ((residual - float(item)) / max(1.0, 0.35 * item)) ** 2)

    # (4) Mild penalty for tiny unusable slivers just above the item.
    sliver = np.exp(-0.5 * ((residual - 0.25 * item) / max(1.0, 0.25 * item)) ** 2)

    return base + 8.0 * perfect + 3.0 * usable + 6.0 * pair - 2.0 * sliver
# EVOLVE-BLOCK-END