# EVOLVE-BLOCK-START
"""Online bin packing via learned pair-matching.

Instead of hand-tuned Gaussian shaping around fixed residual centers, this
implementation learns the empirical item-size distribution online (a smoothed
histogram updated from every arriving item) and scores each candidate bin by
the *expected closure value* of its residual:

    score(bin) = -alpha * residual
                 + perfect_fill_bonus
                 + w_single * P(future item == residual)
                 + w_pair   * P(two future items sum to residual)

The closure probabilities are read off a running histogram of observed sizes,
so the rule adapts to the true (fixed but unknown) distribution instead of
assuming centers like 100-item or 40.  Early on, when the histogram is sparse,
the rule gracefully degrades toward best-fit.
"""
import numpy as np

# ---------------------------------------------------------------------------
# Module-level state: an online histogram of observed item sizes.
# Sizes are 1..100.  We keep integer counts and add Laplace smoothing when
# converting to probabilities.  State persists between calls (harness allows
# this) but is instance-local because a fresh process is used per instance.
# ---------------------------------------------------------------------------
_HIST = np.ones(101, dtype=np.float64)  # Laplace prior (index 0 unused)
_HIST[0] = 0.0
_N_SEEN = 0.0

# Precompute the index grid once.
_IDX = np.arange(101, dtype=np.float64)


def _pair_prob(r):
    """P(s1 + s2 == r) under the current smoothed empirical distribution.

    s1, s2 are independent draws from the learned distribution over 1..100.
    We compute this as a small dot product over the valid s1 range.
    """
    if r <= 1:
        return 0.0
    total = _HIST.sum()
    if total <= 0.0:
        return 0.0
    lo = max(1, int(r) - 100)
    hi = min(100, int(r) - 1)
    if lo > hi:
        return 0.0
    s1 = np.arange(lo, hi + 1, dtype=np.float64)
    s2 = r - s1
    # Both histogram entries are valid indices in [1, 100].
    p = (_HIST[s1.astype(np.int64)] * _HIST[s2.astype(np.int64)]).sum()
    return p / (total * total)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest
    (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    global _N_SEEN

    # --- Update the learned distribution with the arriving item. ---
    # Clip defensively (item is guaranteed 1..100).
    s = int(item)
    if 1 <= s <= 100:
        _HIST[s] += 1.0
        _N_SEEN += 1.0

    residual = bins - item
    r = residual.astype(np.float64)

    # --- Base term: tightest fit first (best-fit). ---
    # Relaxed so the closure terms can influence decisions, but still the
    # dominant signal when closure probabilities are flat.
    score = -0.35 * r

    # --- Perfect fill: strongly preferred (avoids opening a new bin). ---
    score += np.where(residual == 0, 1.5, 0.0)

    total = _HIST.sum()
    if total > 0.0:
        # Single-item closure probability for each residual.
        ri = np.clip(residual.astype(np.int64), 0, 100)
        p_single = _HIST[ri] / total  # P(future item == r)

        # Pair closure probability for each distinct residual value.
        # residuals are in [0, 100]; compute lazily over unique values.
        uniq = np.unique(residual)
        pair_map = {}
        for u in uniq:
            pair_map[int(u)] = _pair_prob(int(u))
        p_pair = np.array([pair_map[int(u)] for u in residual], dtype=np.float64)

        # Reward residuals that a *single* future item can exactly close.
        score += 6.0 * p_single
        # Reward residuals that a *pair* of future items can exactly close.
        score += 3.0 * p_pair

    # --- Sliver penalty: residuals too small for almost any future item. ---
    # Weibull-shaped sizes mean ~40, so tiny residuals are usually dead.
    score -= np.where((residual > 0) & (residual < 12), 0.3, 0.0)

    return score
# EVOLVE-BLOCK-END