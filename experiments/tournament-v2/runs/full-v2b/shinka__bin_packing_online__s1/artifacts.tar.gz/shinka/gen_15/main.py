# EVOLVE-BLOCK-START
"""Online bin packing: concave residual utility on top of best-fit.

Items are Weibull-shaped with mean ~40. Pure best-fit is already strong, but
its linear `-residual` slope makes near-ties between a tight fit and a slightly
looser fit too flat, and it wastes bins on tiny residuals (slivers).

This version replaces the linear base with a *concave* utility on the residual:

    base(r) = -sqrt(r)

Concavity means small residuals are penalized only slightly more than perfect
fills, while large residuals are penalized heavily -- exactly the ordering we
want for packing. On top of this base we layer three small, orthogonal shaping
terms (perfect fill bonus, sliver penalty, usable-residual reward) whose
threshold is derived from the arriving item size rather than a hard constant.

All operations are vectorized; no per-bin Python loops.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (ties -> first).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item            # >= 0 for every bin shown
    r = residual.astype(np.float64)

    # --- Base: concave residual utility (best-fit, softened) -------------
    # sqrt compresses the large-residual region, so a bin with residual 60
    # is not hugely preferred over one with residual 5; the tightest fit is
    # still ranked first, but the near-tie region is flatter than linear.
    score = -np.sqrt(r)

    # --- Shaping terms ---------------------------------------------------
    # Perfect fill: strongly preferred (closes a bin at zero waste).
    perfect = (r == 0.0)

    # Sliver penalty: a residual too small to accept any typical future item
    # is effectively dead space. Threshold scales with the arriving item so
    # the rule tracks the distribution without a fixed constant.
    sliver_thresh = 0.5 * item
    sliver = (r > 0.0) & (r < sliver_thresh)

    # Usable-residual reward: a residual that can still hold another item of
    # comparable size keeps the bin productive.
    usable = (r >= item)

    score = score + 1.0 * perfect - 0.4 * sliver + 0.25 * usable
    return score
# EVOLVE-BLOCK-END