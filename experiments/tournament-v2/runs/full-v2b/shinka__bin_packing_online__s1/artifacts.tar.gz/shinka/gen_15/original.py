# EVOLVE-BLOCK-START
"""Online best-fit with residual shaping to avoid unusable slivers.

Items are Weibull-shaped with mean ~40. Pure best-fit already works well, but
it sometimes creates tiny residuals (1..15) that cannot fit any future item,
effectively wasting that bin's remaining space. We keep best-fit as the primary
rule and add a bounded secondary preference for residuals that are either
perfect (0) or large enough (>= ~40) to hold a typical future item, while
slightly penalizing tiny residuals.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)

    # Primary: best-fit (tightest fit first).
    score = -r

    # Secondary: harmonic-class shaping.
    # Perfect fill: strongly preferred.
    # Residual that can hold another item of comparable size (>= item): mildly good.
    # Residual that is too small to hold a comparable item (0 < r < item/2): penalize,
    #   because it fragments the bin into a useless sliver.
    # Residual in [item/2, item): neutral-to-slightly-good (can fit a smaller item).
    perfect_bonus = np.where(r == 0.0, 1.0, 0.0)
    comparable = np.where(r >= item, 0.4, 0.0)
    sliver_penalty = np.where((r > 0.0) & (r < 0.5 * item), -0.5, 0.0)

    score += perfect_bonus + comparable + sliver_penalty
    return score
# EVOLVE-BLOCK-END