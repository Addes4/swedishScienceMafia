# EVOLVE-BLOCK-START
"""Hybrid online best-fit.

Combines the dominant best-fit slope with two complementary-pair Gaussian
bonuses (from the current program) and the bounded sliver / useful-residual
shaping from the inspiration program.  The primary best-fit signal keeps the
tightest-fit ordering, while the bounded secondary terms break near-ties in
favor of residuals that can still be usefully filled later.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)

    # Primary: best-fit (tightest fit first), strong slope so it dominates.
    score = -r

    # Perfect fill -> strongly preferred (avoids opening a new bin).
    score += np.where(r == 0, 1.0, 0.0)

    # Complementary-pair shaping (Gaussian windows).
    width = 0.35 * float(item) + 1e-9
    # Future item of the same size as the current one.
    score += 6.0 * np.exp(-0.5 * ((r - float(item)) / width) ** 2)
    # Exact complement that would fill the bin.
    score += 2.0 * np.exp(-0.5 * ((r - (100.0 - float(item))) / width) ** 2)

    # Bounded sliver / useful-residual shaping (from inspiration program).
    # Useful bonus as a Gaussian centered on a typical future item size (~40),
    # width 18.0, amplitude 0.3.  Smoother and more selective than the previous
    # linear ramp, rewarding residuals that can absorb one typical future item
    # without over-rewarding near-empty bins.
    score += 0.3 * np.exp(-0.5 * ((r - 40.0) / 18.0) ** 2)
    # Sliver penalty: -0.3 for r in (0, 15), 0 otherwise.
    score += np.where((r > 0) & (r < 15), -0.3, 0.0)

    return score
# EVOLVE-BLOCK-END