# EVOLVE-BLOCK-START
"""Layered-residual online best-fit.

The bin-choice rule is assembled from independent, named feature contributions
that are computed in one vectorized pass and combined through an explicit weight
table.  The dominant signal is a relaxed best-fit slope (tightest fit first);
bounded secondary terms break near-ties in favor of residuals that remain
useful for future items (perfect fills, complementary pairs, and usable
residuals rather than dead-zone slivers).
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)
    it = float(item)

    # Precompute masks once.
    is_perfect = residual == 0
    is_positive = residual > 0

    # ---- Feature contributions -------------------------------------------
    feats = {}

    # Base: relaxed best-fit slope (dominant but not absolute).
    feats["base"] = -0.15 * r

    # Perfect fill: strongly prefer closing a bin exactly.
    feats["perfect"] = np.where(is_perfect, 1.0, 0.0)

    # Residual quality: reward usable residuals, penalize dead-zone slivers.
    # Smooth bounded ramp: 0 at r<=15, rising to 1 at r>=45.
    usable = np.clip((r - 15.0) / 30.0, 0.0, 1.0)
    # Sliver penalty: -1 for tiny positive residuals, tapering off by r=15.
    sliver = np.where(is_positive & (r < 15.0), 1.0 - r / 15.0, 0.0)
    feats["quality"] = usable - sliver

    # Broad complementary-pair prior: residual near (100 - item) is closable
    # by a future complementary item.
    center = 100.0 - it
    feats["pair_broad"] = np.exp(-0.5 * ((r - center) / 18.0) ** 2)

    # Narrow exact-complement pull: width scales with item so small items
    # (many possible complements) get a wider window.
    width = max(1.0, 0.2 * it)
    feats["pair_narrow"] = np.exp(-0.5 * ((r - center) / width) ** 2)

    # Comparable-residual affinity: bin can accept another item of similar size.
    w2 = 0.35 * it + 1e-9
    feats["same_size"] = np.exp(-0.5 * ((r - it) / w2) ** 2)

    # Typical-future-item affinity: residual near the distribution mean (~40).
    feats["mean_target"] = np.exp(-0.5 * ((r - 40.0) / 15.0) ** 2)

    # ---- Weight table ----------------------------------------------------
    weights = {
        "base": 1.0,
        "perfect": 1.0,
        "quality": 0.5,
        "pair_broad": 0.5,
        "pair_narrow": 6.0,
        "same_size": 1.5,
        "mean_target": 0.3,
    }

    score = np.zeros_like(r)
    for name, w in weights.items():
        score += w * feats[name]

    return score
# EVOLVE-BLOCK-END