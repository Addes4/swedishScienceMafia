# EVOLVE-BLOCK-START
"""Distribution-aware completion shaping for online bin packing.

The item sizes are drawn from a fixed Weibull-like distribution with mean ~40.
Instead of hand-tuning Gaussian targets, we build a *residual desirability
profile* from the distribution of item sizes: a residual is desirable if it is
close to a value that common future items (or pairs of them) could close.

We keep best-fit as the primary rule (it is a strong baseline) and add:
  * a sharp perfect-fill spike,
  * a smooth completion profile that rewards residuals matching the most likely
    single-item complements and two-item completions,
  * a mild sliver penalty for residuals that are too small to be useful.

Everything is computed with cheap vectorized numpy and no per-instance state.
"""
import numpy as np

# Precompute a distribution-aware weighting over integer item sizes 1..100.
# Weibull-like, mean ~40: use a shape that places most mass in 25..55 and a
# tail toward 5..20 and 60..100. This is a static prior over the known
# distribution family; it does not tune to any individual instance.
_SIZES = np.arange(1, 101, dtype=np.float64)

# Approximate density: Weibull(k=2, lambda~45) shaped, clipped to [1,100].
_k = 2.0
_lambda = 45.0
_density = (_k / _lambda) * (_SIZES / _lambda) ** (_k - 1.0) * np.exp(
    -(_SIZES / _lambda) ** _k
)
# Add a small floor so no size is treated as impossible.
_density = _density + 1e-3
_density /= _density.sum()

# Precompute, for each possible residual r in 0..100, a "closeability" score:
# how likely is it that the bin can be finished by one future item, or by a
# pair of future items, given the distribution above.
_RES = np.arange(0, 101, dtype=np.float64)

# Single-item completion: residual r is closeable if r is a likely item size.
_single = np.zeros(101, dtype=np.float64)
_single[_RES.astype(int)] = _density  # density of exactly that size
# Smooth it slightly so near-misses still count.
_kernel = np.exp(-0.5 * (np.arange(-3, 4) / 1.5) ** 2)
_kernel /= _kernel.sum()
_single = np.convolve(_single, _kernel, mode="same")

# Two-item completion: residual r is closeable if it can be split into two
# likely item sizes. Approximate by convolution of the density with itself.
_two = np.convolve(_density, _density, mode="full")  # support 2..200
_two_scores = np.zeros(101, dtype=np.float64)
for r in range(101):
    if 2 <= r <= 200:
        _two_scores[r] = _two[r - 2]
# Normalize both profiles to [0, 1].
_single_n = _single / (_single.max() + 1e-12)
_two_n = _two_scores / (_two_scores.max() + 1e-12)

# Combined completion profile: single-item completion is more valuable than
# two-item completion (smaller residual is easier to finish), so weight it more.
_COMPLETION = 0.7 * _single_n + 0.3 * _two_n


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.int64)

    # Primary: best-fit (tightest fit first).
    score = -residual.astype(np.float64)

    # Perfect fill: strongly preferred (closes the bin exactly).
    score += np.where(residual == 0, 5.0, 0.0)

    # Sliver penalty: residuals too small to be usefully closed.
    score -= np.where((residual > 0) & (residual < 15), 0.5, 0.0)

    # Distribution-aware completion shaping: reward residuals whose value is a
    # likely completion of the bin by future items.
    # Clip to valid index range.
    idx = np.clip(r, 0, 100)
    score += 3.0 * _COMPLETION[idx]

    return score
# EVOLVE-BLOCK-END
