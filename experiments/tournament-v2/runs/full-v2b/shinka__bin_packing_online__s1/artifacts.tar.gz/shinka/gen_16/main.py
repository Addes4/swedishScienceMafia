# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best-fit base: prefer the tightest fit.
    score = -residual.astype(np.float64)
    # Strongly reward perfect fills.
    score += np.where(residual == 0, 1.0, 0.0)
    # Asymmetric sliver penalty: strongly discourage residuals that are just
    # above zero (wasted capacity no future item can use), while decaying
    # gently for larger residuals that could still accept small items.
    center = 0.25 * item
    sliver = residual.astype(np.float64) - center
    sigma = np.where(sliver < 0, 0.15 * item + 1.0, 0.5 * item + 1.0)
    score -= 3.0 * np.exp(-(sliver * sliver) / (2.0 * sigma * sigma))
    # Reward residuals large enough to still accept a typical (~40) item.
    score += np.where(residual >= 35, 0.2, 0.0)
    return score
# EVOLVE-BLOCK-END