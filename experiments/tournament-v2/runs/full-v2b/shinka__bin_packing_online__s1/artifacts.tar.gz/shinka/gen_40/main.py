# EVOLVE-BLOCK-START
"""Online bin packing: modular residual-utility scoring on top of best-fit.

Architecture
------------
The priority function is organized as a small pipeline of independent,
vectorized feature functions combined by a weight table:

    features(item, bins) -> dict of numpy arrays
    combine(features, weights) -> score

Features
--------
base(r)        : concave residual utility, -sqrt(r). Softens pure best-fit
                 so near-ties between tight and slightly-looser fits are
                 flatter, while large residuals are still penalized.
perfect(r)     : 1 where residual == 0 (closes the bin with zero waste).
sliver(r,item) : 1 where 0 < residual < 0.5*item (gap too small for a
                 typical future item -> dead space, penalize).
usable(r,item) : 1 where residual >= item (bin can still host another
                 item of comparable size -> keep productive).

The item goes into the bin with the highest combined score; ties go to the
first such bin. All operations are vectorized; no per-bin Python loops.
"""
import numpy as np


# --- Weight table (tunable) ---------------------------------------------
_W_BASE = 1.0
_W_PERFECT = 1.0
_W_SLIVER = -0.4
_W_USABLE = 0.25


def _base(residual):
    """Concave residual utility: -sqrt(r). Tightest fit still ranks first."""
    return -np.sqrt(residual.astype(np.float64))


def _perfect(residual):
    """Indicator: residual is exactly zero."""
    return (residual == 0.0).astype(np.float64)


def _sliver(residual, item):
    """Indicator: residual is a small nonzero gap (< 0.5 * item)."""
    return ((residual > 0.0) & (residual < 0.5 * item)).astype(np.float64)


def _usable(residual, item):
    """Indicator: residual can still hold another item of comparable size."""
    return (residual >= item).astype(np.float64)


def _features(item, residual):
    """Compute all shaping features for the current call."""
    return {
        "base": _base(residual),
        "perfect": _perfect(residual),
        "sliver": _sliver(residual, item),
        "usable": _usable(residual, item),
    }


def _combine(feats):
    """Weighted sum of features."""
    return (
        _W_BASE * feats["base"]
        + _W_PERFECT * feats["perfect"]
        + _W_SLIVER * feats["sliver"]
        + _W_USABLE * feats["usable"]
    )


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (ties -> first).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item            # >= 0 for every bin shown
    feats = _features(item, residual)
    return _combine(feats)
# EVOLVE-BLOCK-END