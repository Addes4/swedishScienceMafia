# EVOLVE-BLOCK-START
"""Hybrid sliver-aware + complementary-pair best fit.

Combines two complementary shaping mechanisms on top of best-fit:

  * Asymmetric sliver penalty (from the sliver-aware parent): penalize
    small residuals that future items cannot reclaim, strongly but not
    so strongly that productive pair targets are suppressed.

  * Complementary-pair / multi-target Gaussians (from the pair parent):
    reward residuals that equal a future item of the same size, the exact
    complement (100 - item), or 100 - 2*item, since these are the
    residuals that let a later item close the bin exactly.

Both are used together: the sliver term shapes the "no good option"
region while the pair terms steer toward exact closures.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)

    # ---- Best-fit base ----
    score = -r

    # ---- Perfect fill: strongly preferred ----
    score += np.where(residual == 0, 1.0, 0.0)

    # ---- Complementary-pair / multi-target shaping ----
    # Width tuned around 0.35*item for the primary pair target.
    width = 0.35 * float(item) + 1e-9

    # Future item of the same size as the current one.
    score += 6.0 * np.exp(-0.5 * ((r - float(item)) / width) ** 2)

    # Exact complement that would fill the bin.
    score += 2.0 * np.exp(-0.5 * ((r - (100.0 - float(item))) / width) ** 2)

    # Third complementary target: residual closeable by a future item of
    # size ~2*item. Gated smoothly to small items via a sigmoid so the term
    # fades out before comp2_center goes negative (item > 50), avoiding a
    # discontinuous dead-zone and spurious r~0 rewards for large items.
    comp2_center = 100.0 - 2.0 * float(item)
    comp2_width = max(1.0, 0.2 * float(item))
    comp2_gate = 1.0 / (1.0 + np.exp((float(item) - 37.0) / 7.0))
    score += 1.5 * comp2_gate * np.exp(-0.5 * ((r - comp2_center) / comp2_width) ** 2)

    # ---- Asymmetric sliver penalty (softened) ----
    # One-sided Gaussian centered at 0.3*item, width 0.25*item. Applied for
    # r > 0 so the perfect-fill bonus is untouched. Weight kept modest so
    # the pair targets above are not over-suppressed.
    center = 0.3 * float(item)
    swidth = max(0.25 * float(item), 1.0)
    sliver = np.exp(-((r - center) / swidth) ** 2)
    score += np.where(r > 0, -1.5 * sliver, 0.0)

    # ---- Hard dead-zone: residuals 1..4 are essentially unusable ----
    score += np.where((r > 0) & (r < 5), -0.5, 0.0)

    # ---- Soft bonus for large residuals useful for typical future items ----
    score += np.clip((r - 30.0) / 10.0, 0.0, 1.0) * 0.3

    return score
# EVOLVE-BLOCK-END