# EVOLVE-BLOCK-START
"""Adaptive residual banding: best-fit with a non-linear band bonus."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Base best-fit score: tighter fits (smaller residual) get higher priority.
    residual = bins - item
    base = -residual.astype(np.float64)

    # Harmonic-style tie-breaker: prefer residuals that are close to a multiple
    # of the item size (clean packing, little wasted leftover), and slightly
    # penalize residuals that leave a small awkward remainder. The base term
    # remains dominant so this only breaks near-ties among similar residuals.
    if item > 1:
        r = residual % item
        # closeness to a multiple: 0 at r=0, grows to item/2 in the middle
        dist_to_mult = np.minimum(r, item - r).astype(np.float64)
        # bonus highest when dist_to_mult == 0; scale small relative to base
        bonus = (1.0 - dist_to_mult / (item / 2.0))
    else:
        bonus = np.ones_like(base)

    return base + 0.5 * bonus
# EVOLVE-BLOCK-END