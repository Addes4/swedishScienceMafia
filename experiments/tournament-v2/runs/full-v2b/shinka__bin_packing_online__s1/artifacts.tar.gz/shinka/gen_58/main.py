# EVOLVE-BLOCK-START
"""Hybrid online best-fit: tightest-fit primary rule with residual shaping.

Combines:
  * Best-fit base (score = -residual), which is the dominant signal.
  * Perfect-fill bonus (+1.0).
  * Dead-zone penalty for tiny residuals (0 < r < 30), which the Weibull-shaped
    item distribution (mean ~40) cannot reuse.
  * Bonus for residuals large enough (>= 35) to accept another typical item.
  * Soft Gaussian reward centered on the exact complement (100 - item), so bins
    that can be closed by a future "mirror" item are mildly preferred.
  * Soft Gaussian reward centered on r = item, encouraging residuals that can
    still accept another item of comparable size.

The shaping terms are deliberately smaller than the best-fit slope so they only
break ties and nudge near-ties, preserving the proven best-fit behaviour.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)

    # Primary: best-fit (tightest fit first).
    score = -r

    # Perfect fill -> strongly preferred (avoids opening a new bin).
    score += np.where(r == 0.0, 1.0, 0.0)

    # Dead-zone penalty: residuals too small for the typical (~40) item are wasted.
    score -= np.where((r > 0.0) & (r < 30.0), 0.5, 0.0)

    # Reward residuals that can still accept a typical future item.
    score += np.where(r >= 35.0, 0.2, 0.0)

    # Soft complementary-pair shaping (from the Gaussian variant), kept gentle.
    width = 0.35 * float(item) + 1e-9
    # Exact complement: residual that a future item of size (100 - item) could close.
    score += 3.0 * np.exp(-0.5 * ((r - (100.0 - float(item))) / width) ** 2)
    # Comparable residual: fits another item of similar size.
    score += 1.5 * np.exp(-0.5 * ((r - float(item)) / width) ** 2)

    return score
# EVOLVE-BLOCK-END