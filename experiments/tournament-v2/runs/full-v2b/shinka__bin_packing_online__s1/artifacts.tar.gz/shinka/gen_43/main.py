# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)

    # Primary: best-fit (tightest fit first), strong slope so it dominates.
    score = -r

    # Perfect fill -> strongly preferred (avoids opening a new bin).
    score += np.where(r == 0, 1.0, 0.0)

    # Complementary-pair shaping.  The optimum sits in a narrow window around
    # weight 6.0 at width 0.35*item (weight 9.0 at width 0.28*item regressed).
    width = 0.35 * float(item) + 1e-9
    # Future item of the same size as the current one.
    score += 6.0 * np.exp(-0.5 * ((r - float(item)) / width) ** 2)
    # Exact complement that would fill the bin.
    score += 2.0 * np.exp(-0.5 * ((r - (100.0 - float(item))) / width) ** 2)
    # Third complementary target: residual that a future item of size ~2*item
    # could close (extending the multi-target pair lever).
    comp2_center = 100.0 - 2.0 * float(item)
    comp2_width = max(1.0, 0.2 * float(item))
    score += 1.5 * np.exp(-0.5 * ((r - comp2_center) / comp2_width) ** 2)

    return score
# EVOLVE-BLOCK-END