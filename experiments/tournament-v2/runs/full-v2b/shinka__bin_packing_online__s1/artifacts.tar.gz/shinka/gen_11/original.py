# EVOLVE-BLOCK-START
"""Concave-utility bin packing: best-fit relaxed with distribution-aware residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = (bins - item).astype(np.float64)

    # Relaxed best-fit base: much smaller slope than 1.0 so that the
    # distribution-aware bonuses below can actually reorder decisions,
    # not merely break exact ties.
    base = -0.25 * residual

    # (1) Sharp bonus for near-perfect fills (residual ~ 0).
    perfect = np.exp(-0.5 * (residual / 1.5) ** 2)

    # (2) Broad bonus for residuals near the distribution mean (~40):
    #     leftover space of this size is likely to be filled by a future item.
    usable = np.exp(-0.5 * ((residual - 40.0) / 18.0) ** 2)

    # (3) Complementary-pair bonus: prefer residuals close to the current item
    #     size, encouraging two items to fill a bin tightly together.
    pair = np.exp(-0.5 * ((residual - float(item)) / max(1.0, 0.6 * item)) ** 2)

    # (4) Mild penalty for tiny unusable slivers just above the item.
    sliver = np.exp(-0.5 * ((residual - 0.25 * item) / max(1.0, 0.25 * item)) ** 2)

    return base + 8.0 * perfect + 5.0 * usable + 3.0 * pair - 2.0 * sliver
# EVOLVE-BLOCK-END