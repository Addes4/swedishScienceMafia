# EVOLVE-BLOCK-START
"""Online bin packing via empirical-distribution expected-waste minimization.

Instead of hand-tuned Gaussian bonuses, we maintain an online histogram of
observed item sizes and score each feasible bin by the expected future waste
it would incur.  The bin minimizing expected waste (equivalently maximizing
the chance of being closed cheaply by a future item) is chosen.

This is a distribution-adaptive policy: the histogram learns the instance's
actual item-size distribution, so the shaping adapts to the data rather than
relying on fixed widths/centers.
"""
import numpy as np

# ---- Persistent online state (module-level, per process) ----
_NBUCKETS = 64
# Bucket edges over 1..100 (bin width ~1.56); index 0..63.
_EDGES = np.linspace(0.0, 100.0, _NBUCKETS + 1)
_CENTERS = 0.5 * (_EDGES[:-1] + _EDGES[1:])

# Weibull(shape~2, scale~45)-ish prior, clipped to 1..100, normalized.
_x = _CENTERS
_prior = (_x / 45.0) * np.exp(-0.5 * (_x / 45.0) ** 2)
_prior = np.clip(_prior, 1e-6, None)
_prior = _prior / _prior.sum()

_hist = _prior.copy() * 50.0   # pseudo-counts; decays in influence as data arrives
_total = float(_hist.sum())


def _bucket_index(item):
    idx = int(item * _NBUCKETS / 100.0)
    if idx >= _NBUCKETS:
        idx = _NBUCKETS - 1
    if idx < 0:
        idx = 0
    return idx


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every feasible bin.
    """
    global _hist, _total

    # Update empirical distribution with the arriving item.
    idx = _bucket_index(item)
    _hist[idx] += 1.0
    _total += 1.0
    # Mild decay of old mass so the estimate tracks a stationary distribution
    # but is not overly volatile.
    if _total > 4000.0:
        _hist *= 0.999
        _total *= 0.999

    p = _hist / _total  # probability mass per bucket

    residual = bins - item           # >= 0 for all shown bins
    r = residual.astype(np.float64)

    # ---- Expected-waste proxy for each candidate bin ----
    # For a residual r, consider a future single item drawn from p.
    #   - If s == r exactly: bin is perfectly closed -> waste 0.
    #   - If s < r: residual shrinks to r-s (still open) -> small waste now.
    #   - If s > r: item can't fit -> bin stays with waste r.
    # We compute a smooth, vectorized version:
    #   close_prob(r)   = P(s within +-0.5 of r)   (chance of near-perfect close)
    #   useful_mass(r)  = P(s <= r)                (chance residual is usable)
    # Score rewards high close_prob and high useful_mass, penalizes r itself.

    # close probability: mass in the bucket nearest r (plus neighbours).
    # Vectorize by mapping each r to its bucket index.
    ridx = np.clip((r * _NBUCKETS / 100.0).astype(np.int64), 0, _NBUCKETS - 1)
    left = np.clip(ridx - 1, 0, _NBUCKETS - 1)
    right = np.clip(ridx + 1, 0, _NBUCKETS - 1)
    close_prob = p[ridx] + 0.5 * p[left] + 0.5 * p[right]

    # useful mass: cumulative probability up to r (approx by bucket).
    cum = np.cumsum(p)  # length NBUCKETS
    # probability that a future item fits in residual r (s <= r)
    fits_mass = cum[ridx]

    # Expected waste if we place here, roughly:
    #   waste ~ r * (1 - fits_mass) * something - but we want to reward
    #   residuals that are likely to be closed.  Use a combined objective.
    #
    # Primary signal: prefer small residual (best-fit) but let close_prob and
    # fits_mass break ties toward residuals that future items can use.
    score = -r
    # Strongly reward near-perfect closes (this replaces the fixed Gaussian).
    score += 12.0 * close_prob
    # Reward residuals that still admit a typical future item.
    score += 3.0 * fits_mass
    # Perfect fill: huge bonus (bin closes with zero waste).
    score += np.where(r == 0.0, 2.0, 0.0)
    # Penalize tiny unusable slivers (r>0 but very unlikely to be hit).
    score -= np.where((r > 0.0) & (r < 8.0), 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END