# EVOLVE-BLOCK-START
"""Online best-fit with crisp complementary targets and a tightly-gated
fourth target for very small items.

Items are Weibull-shaped with mean ~40, so the dominant fill patterns are:
  * residual == 0           -> perfect fill (strongly preferred)
  * residual == 100 - item  -> a single complementary item closes the bin
  * residual == 100 - 2*item-> two more copies of the item close the bin
  * residual == 100 - 3*item-> three more copies close the bin (small items)

Best-fit remains the primary rule; all secondary terms are bounded and small,
so they only break near-ties.  The fourth target is gated to items <= 20 and
kept narrow/low-weight to avoid over-stacking.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest
    (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)

    # Primary: best-fit (tightest fit first).
    score = -r

    # ---- Crisp complementary targets ----
    # Target 1: residual that a single complementary item would exactly fill.
    center = 100.0 - item
    width = max(1.0, 0.25 * item)
    score += 2.5 * np.exp(-0.5 * ((r - center) / width) ** 2)

    # Target 2: residual that two further copies of the item would fill.
    comp2 = 100.0 - 2.0 * item
    score += 1.75 * np.exp(-0.5 * ((r - comp2) / width) ** 2)

    # Target 3 (new, tightly gated): residual that three further copies of the
    # item would fill.  Only active for very small items (<= 20), with a tight
    # width and low weight so it complements rather than overrides.
    gate = np.clip((20.0 - item) / 20.0, 0.0, 1.0)
    comp3 = 100.0 - 3.0 * item
    w3 = max(1.0, 0.2 * item)
    score += 0.8 * gate * np.exp(-0.5 * ((r - comp3) / w3) ** 2)

    # ---- Broad pair prior: keep a wide pull toward the complement center. ----
    score += 0.25 * np.exp(-0.5 * ((r - center) / 18.0) ** 2)

    # ---- Threshold shaping (cheap, robust) ----
    # Perfect fill -> strongly preferred (avoids opening a new bin).
    score += np.where(r == 0.0, 1.0, 0.0)
    # Tiny residual (1..11) -> likely wasted sliver, mildly penalized.
    score -= np.where((r > 0.0) & (r < 12.0), 0.3, 0.0)
    # Mild reward for residuals near a typical future item size (~40).
    score += 0.15 * np.exp(-0.5 * ((r - 40.0) / 15.0) ** 2)

    return score
# EVOLVE-BLOCK-END