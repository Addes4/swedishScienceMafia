# EVOLVE-BLOCK-START
"""Harmonic-interval bin packing: rank bins by proximity to discrete complementary targets."""
import numpy as np

# Online histogram of past item sizes (integer buckets 1..100).
_hist = np.zeros(101, dtype=np.float64)
_hist_decay = 0.995
_n = 0.0
_mean = 40.0


def _update(item):
    global _n, _mean
    _hist *= _hist_decay
    _hist[item] += 1.0
    _n = _n * _hist_decay + 1.0
    _mean += (item - _mean) / max(1.0, _n)


def _common_sizes():
    """Return a small sorted list of the most frequent past item sizes."""
    h = _hist.copy()
    # Zero out tiny buckets to avoid noise.
    total = h.sum()
    if total <= 0:
        return [40]
    # Pick the top few peaks.
    idx = np.argsort(h)[::-1]
    sizes = []
    for i in idx:
        if h[i] <= 0:
            break
        if h[i] / total < 0.01:
            break
        sizes.append(int(i))
        if len(sizes) >= 4:
            break
    if not sizes:
        sizes = [40]
    return sorted(sizes)


def priority(item, bins):
    """Return a priority score per bin; highest score wins (first on ties)."""
    _update(int(item))

    residual = (bins - item).astype(np.float64)

    common = _common_sizes()
    # Build discrete target residuals: exact complements and double complements.
    targets = []
    for s in common:
        targets.append(float(s))          # residual fits one typical item
        targets.append(float(2 * s))      # residual fits two typical items
    targets.append(0.0)                    # perfect fill
    targets.append(float(item))            # residual matches current item
    targets = sorted(set(t for t in targets if 0.0 <= t <= 100.0))
    if not targets:
        targets = [0.0]

    tarr = np.array(targets, dtype=np.float64)

    # Distance to nearest target.
    d = np.abs(residual[:, None] - tarr[None, :])
    nearest = d.min(axis=1)

    # Smallest target that is >= residual (i.e., the tightest fitting bucket).
    # Prefer placing item so that residual lands exactly on a target.
    # Score = -nearest + bonus for exact match + weak best-fit tie-break.
    exact = np.exp(-0.5 * (nearest / 0.5) ** 2)

    # Penalize slivers: residuals in (0, min_common) that aren't perfect.
    min_common = float(min(common)) if common else 1.0
    sliver = ((residual > 0.5) & (residual < min_common - 0.5)).astype(np.float64)

    # Very weak best-fit base to break ties among equal-target bins.
    base = -0.05 * residual

    return base - 1.0 * nearest + 3.0 * exact - 2.0 * sliver
# EVOLVE-BLOCK-END