# EVOLVE-BLOCK-START
"""Online best-fit with complementary-pair residual shaping.

Items are Weibull-shaped with mean ~40. Pure best-fit already works well, but
it sometimes creates residuals that no future item can use. We keep best-fit
as the primary rule and add two smooth Gaussian preferences:

* A Gaussian centered at `item` (weight 6.0, width 0.2*item) rewards residuals
  that can be closed by a future item of the same size as the current one.
* A Gaussian centered at `100 - item` (weight 2.0, width 0.2*item) rewards
  residuals that can be closed by the exact complement of the current item.

Both are frequently realizable under the Weibull-like size distribution.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    r = residual.astype(np.float64)

    # Primary: best-fit (tightest fit first).
    score = -r

    # Perfect fill -> strongly preferred (avoids opening a new bin).
    score += np.where(r == 0, 1.0, 0.0)

    # Sliver penalty: residuals that no typical future item can use.
    score -= np.where((r > 0) & (r < 30), 0.4, 0.0)

    # Complementary-pair shaping.
    width = 0.2 * float(item) + 1e-9
    # Future item of same size as current one.
    score += 6.0 * np.exp(-0.5 * ((r - float(item)) / width) ** 2)
    # Exact complement that would fill the bin.
    score += 2.0 * np.exp(-0.5 * ((r - (100.0 - float(item))) / width) ** 2)

    return score
# EVOLVE-BLOCK-END
