# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    r = residual.astype(np.float64)
    # Relaxed best-fit base: only a weak preference for the tightest fit, so the
    # distribution-aware shaping terms below can dominate more decisions.
    score = -0.15 * r
    # Strongly reward perfect fills.
    score += np.where(residual == 0, 1.0, 0.0)
    # Penalize dead-zone residuals that no typical future item can use.
    score -= np.where((residual > 0) & (residual < 30), 0.4, 0.0)
    # Broad pair prior: residuals near (100 - item) can later be closed by a
    # complementary item. Kept wide so it does not over-constrain choices.
    center = 100.0 - item
    score += 0.25 * np.exp(-0.5 * ((r - center) / 18.0) ** 2)
    # Narrow complementary-pair term: sharper pull toward the exact residual
    # that a single complementary item would fill. Width scales with item so
    # small items (many possible complements) get a wider window and large
    # items (few complements) get a tight one.
    width = max(1.0, 0.2 * item)
    score += 2.0 * np.exp(-0.5 * ((r - center) / width) ** 2)
    # Perfect-pair bonus: residual exactly equals the complement of the item.
    score += np.where(residual == center, 0.5, 0.0)
    # Mild reward for residuals near a typical future item size (~40), so the
    # bin stays productive for a single later item.
    score += 0.15 * np.exp(-0.5 * ((r - 40.0) / 15.0) ** 2)
    return score
# EVOLVE-BLOCK-END