# EVOLVE-BLOCK-START
"""Best-fit with subtle tie-breaking: prefer tight fits, avoid leaving
tiny unusable residuals, and mildly favor residuals near the typical item size."""
import numpy as np

# Online running mean and variance of observed item sizes, used to reward
# residuals that fall inside an empirical +/- 0.8 sigma band around the mean.
_state = {
    "n": 0.0,
    "sum": 0.0,
    "sumsq": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
    "res_sum": 0.0,
    "res_n": 0.0,
}

BAND_MULT = 0.8
BAND_LO_GUARD = 10.0
BAND_HI_GUARD = 90.0
BAND_BONUS = 1.5


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    # Update running statistics with the arriving item (O(1)).
    _state["n"] += 1.0
    _state["sum"] += float(item)
    _state["sumsq"] += float(item) * float(item)
    if 1 <= item <= 100:
        _state["hist"][item] += 1.0

    n = _state["n"]
    inv_n = 1.0 / n if n > 0.0 else 1.0
    if n > 1.0:
        mu = _state["sum"] / n
        var = _state["sumsq"] / n - mu * mu
        if var < 0.0:
            var = 0.0
        sigma = float(np.sqrt(var))
    else:
        mu = 40.0
        sigma = 15.0

    r = bins - item  # residual capacity after placing the item
    rf = r.astype(np.float64)

    # Base: best-fit (smaller residual is better). Dominates ordering.
    base = -rf

    # Small penalty for tiny nonzero residuals that are hard to reuse.
    TINY_MAX = 4
    TINY_PEN = 0.9
    tiny = np.where((r > 0) & (r <= TINY_MAX), -TINY_PEN, 0.0)

    # Small bonus for perfect fills (scaled small so it only breaks near-ties).
    perfect = np.where(r == 0, 1.5, 0.0)

    # Smooth variance-adaptive near-mean bonus: residuals near the running
    # mean are most likely to be filled by a future typical item. Use a
    # Gaussian centered on mu with half-width max(4, min(0.8*sigma, 20)).
    half = BAND_MULT * sigma
    if half < 4.0:
        half = 4.0
    if half > 20.0:
        half = 20.0
    # Blend a light 0.10 weight of the observed residual mean into the target
    # used by the near-mean bonus. This is a small systematic-bias correction
    # that pulls the soft target toward residuals that have actually filled
    # bins, while leaving best-fit and perfect-fill terms untouched.
    if _state["res_n"] > 0.0:
        mu_target = 0.90 * mu + 0.10 * (_state["res_sum"] / _state["res_n"])
    else:
        mu_target = mu
    if mu_target < 20.0:
        mu_target = 20.0
    if mu_target > 60.0:
        mu_target = 60.0

    near_mean = BAND_BONUS * np.exp(-((rf - mu_target) / half) ** 2)

    # Empirical future-fit bonus: reward residual sizes whose bucket has been
    # frequently observed among past items (likely to be filled exactly).
    rb = np.clip(r, 0, 100).astype(np.int64)
    prob = _state["hist"][rb] * inv_n if n > 0.0 else 0.0
    emp_bonus = 3.0 * prob

    # Tiny tiebreak: slightly prefer larger residuals to reduce fragmentation.
    tiebreak = -0.01 * rf

    scores = base + tiny + perfect + near_mean + emp_bonus + tiebreak

    # Update residual statistics for the bin that would actually be chosen
    # (harness picks the argmax; ties go to the first such bin).
    if bins.size > 0:
        idx = int(np.argmax(scores))
        _state["res_sum"] += float(rf[idx])
        _state["res_n"] += 1.0

    return scores
# EVOLVE-BLOCK-END