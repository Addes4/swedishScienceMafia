# EVOLVE-BLOCK-START
"""Smart best-fit with a variance-adaptive clamp on the target residual."""
import numpy as np


# Online estimate of the item-size mean and variance (state kept across calls).
_state = {"n": 0, "sum": 0.0, "sum_sq": 0.0, "min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Strategy: prefer the bin whose residual after placing this item is closest to
    the running mean item size, so a future typical item can fill it exactly.
    The target mean is clamped using an adaptive width derived from the observed
    standard deviation, which tracks the true distribution better than a fixed
    prior range. Exact fits are strongly preferred; ties among equidistant
    residuals go to the tighter bin (best-fit tiebreak).
    """
    # Update running mean / variance estimate of item sizes.
    _state["n"] += 1
    n = _state["n"]
    _state["sum"] += float(item)
    _state["sum_sq"] += float(item) * float(item)
    mu_raw = _state["sum"] / n

    # Adaptive width from observed variance; guard against early instability.
    var = _state["sum_sq"] / n - mu_raw * mu_raw
    if var < 0.0:
        var = 0.0
    sigma = var ** 0.5

    lo = mu_raw - 1.5 * sigma
    hi = mu_raw + 1.5 * sigma
    # Outer guard so early estimates stay in a sensible range.
    lo = min(max(lo, 10.0), 90.0)
    hi = min(max(hi, 10.0), 90.0)
    mu = min(max(mu_raw, lo), hi)

    # Track the smallest item seen so far (sentinel 100 initially).
    _state["min_item"] = min(_state["min_item"], int(item))

    residual = (bins - item).astype(np.float64)

    # Primary: prefer residual close to the expected next item size.
    score = -np.abs(residual - mu)

    # Secondary: among residuals equidistant from mu, prefer the tighter fit.
    score -= 0.05 * residual

    # Strong bonus for exact fits (perfectly packed bin).
    score += 500.0 * (residual == 0)

    # Penalize residuals that are positive but too small for any observed item
    # to fill: these are effectively wasted capacity (dead-end bins).
    score -= 0.5 * ((residual > 0) & (residual < _state["min_item"]))

    return score
# EVOLVE-BLOCK-END