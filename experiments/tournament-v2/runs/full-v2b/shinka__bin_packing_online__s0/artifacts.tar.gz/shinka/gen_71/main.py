# EVOLVE-BLOCK-START
"""Adaptive residual-band best-fit with residual-mean blend.

Pipeline: state.update(item) -> derive (mu, sigma, min_item) -> score(bins).

Score prefers residuals near the running mean item size, strongly rewards exact
fits, penalizes dead-end residuals (positive but below the smallest observed
item), and mildly prefers tighter fillable fits.

A small blend of the observed mean post-placement residual into the target
mean provides a systematic-bias correction toward bins that actually fill.
"""
import numpy as np


# ---------------------------------------------------------------------------
# State: running statistics of arriving items (persist across calls).
# ---------------------------------------------------------------------------
_state = {
    "n": 0,
    "sum": 0.0,
    "sum_sq": 0.0,
    "min_item": 100,
    "res_sum": 0.0,
    "res_n": 0,
}


def _update_state(item):
    """Incorporate a new item and return (mu, sigma, min_item)."""
    x = float(item)
    s = _state
    s["n"] += 1
    s["sum"] += x
    s["sum_sq"] += x * x
    if item < s["min_item"]:
        s["min_item"] = int(item)

    n = s["n"]
    mu_raw = s["sum"] / n
    var = s["sum_sq"] / n - mu_raw * mu_raw
    if var < 0.0:
        var = 0.0
    sigma = var ** 0.5

    # Clamp target to a sensible prior range (Weibull mean ~40).
    mu = min(max(mu_raw, 20.0), 60.0)

    # Light blend toward the observed mean residual (systematic-bias fix).
    if s["res_n"] > 0:
        res_mean = s["res_sum"] / s["res_n"]
        mu = 0.90 * mu + 0.10 * res_mean
        mu = min(max(mu, 20.0), 60.0)

    return mu, sigma, s["min_item"]


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    mu, sigma, min_item = _update_state(item)

    residual = (bins - item).astype(np.float64)

    # Primary: prefer residual close to the expected next item size.
    score = -np.abs(residual - mu)

    # Strong bonus for exact fits (perfectly packed bin).
    score += 100.0 * (residual == 0)

    # Dead-end penalty: positive residuals too small for any observed item.
    # Scale by how far below min_item the residual falls.
    if min_item > 0:
        dead = (residual > 0) & (residual < min_item)
        if dead.any():
            score -= 0.5 * np.where(dead, (min_item - residual) / float(min_item), 0.0)

    # Tiebreak: prefer tighter fits, but push dead-end near-zero residuals
    # behind fillable ones so they are not accidentally preferred.
    fillable = residual >= min_item
    tie = np.where(fillable, residual, residual + 100.0)
    score -= 0.01 * tie

    # Small bonus for residuals inside the fillable band around the target.
    half = max(4.0, min(1.0 * sigma, 20.0))
    in_band = (residual >= min_item) & (residual <= mu + half)
    score += 0.05 * in_band

    # Record the residual of the selected bin for future bias correction.
    chosen = int(np.argmax(score))
    s = _state
    s["res_sum"] += float(residual[chosen])
    s["res_n"] += 1

    return score
# EVOLVE-BLOCK-END