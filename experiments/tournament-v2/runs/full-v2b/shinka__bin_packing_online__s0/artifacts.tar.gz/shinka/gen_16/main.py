# EVOLVE-BLOCK-START
"""Best-fit with adaptive, distribution-aware tie-breaking.

Core ordering is still best-fit (smaller residual wins). Tie-breaks:
  * perfect-fill bonus,
  * penalty for tiny unusable residuals,
  * adaptive bonus for residuals whose size matches the *running* item
    distribution (mean/std tracked online, no fixed prior),
  * refined running histogram (20 buckets) used as a cheap density estimate.

All tie-break terms are bounded (< 1.0) so they never override best-fit.
"""
import numpy as np

# ---- Running statistics of item sizes (online, O(1) per call) ----
_state = {
    "n": 0.0,
    "mean": 0.0,
    "m2": 0.0,              # for Welford variance
    "hist": np.zeros(20, dtype=np.float64),
}

NBUCKETS = 20
BUCKET_W = 100.0 / NBUCKETS      # 5.0
HIST_BONUS = 0.5                 # bounded tie-break weight

# Adaptive-target parameters
K_SIGMA = 1.75                   # clamp width in std devs
MIN_SIGMA = 6.0                  # floor so early estimates are stable
MAX_SIGMA = 20.0                 # ceiling to avoid over-wide bonus
PEAK_BONUS = 1.1                 # max bonus at the target residual
WIDTH_FRAC = 0.55                # gaussian width = WIDTH_FRAC * sigma


def _bucket(x):
    b = int((x - 1) // BUCKET_W)
    if b < 0:
        b = 0
    elif b > NBUCKETS - 1:
        b = NBUCKETS - 1
    return b


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    # ---- Update running statistics with the arriving item ----
    n = _state["n"] + 1.0
    mean = _state["mean"]
    delta = item - mean
    mean_new = mean + delta / n
    m2 = _state["m2"] + delta * (item - mean_new)
    _state["n"] = n
    _state["mean"] = mean_new
    _state["m2"] = m2
    _state["hist"][_bucket(item)] += 1.0

    inv_n = 1.0 / n
    var = m2 / n if n > 1.0 else 0.0
    sigma = np.sqrt(var) if var > 0.0 else MIN_SIGMA
    sigma = min(max(sigma, MIN_SIGMA), MAX_SIGMA)

    # Adaptive target residual = running mean item size (clamped to sane range).
    target = min(max(mean_new, 5.0), 60.0)
    width = WIDTH_FRAC * sigma

    r = bins - item  # residual capacity after placing the item

    # ---- Dominant term: best-fit ----
    base = -r.astype(np.float64)

    # ---- Bounded tie-breaks ----
    # Penalize tiny nonzero residuals that are hard to reuse.
    TINY_MAX = 4
    TINY_PEN = 0.9
    tiny = np.where((r > 0) & (r <= TINY_MAX), -TINY_PEN, 0.0)

    # Reward perfect fills.
    perfect = np.where(r == 0, 1.5, 0.0)

    # Adaptive bonus: residuals near the running mean item size are likely reusable.
    near_mean = PEAK_BONUS * np.exp(-((r - target) / width) ** 2)

    # Refined histogram bonus: reward residuals in frequently-seen size buckets.
    rb = np.clip(((r - 1) // BUCKET_W).astype(np.int64), 0, NBUCKETS - 1)
    hist_bonus = HIST_BONUS * (np.asarray(_state["hist"])[rb] * inv_n)

    return base + tiny + perfect + near_mean + hist_bonus
# EVOLVE-BLOCK-END