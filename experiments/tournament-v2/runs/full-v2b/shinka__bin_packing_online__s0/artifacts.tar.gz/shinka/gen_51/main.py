# EVOLVE-BLOCK-START
"""Best-fit with a self-correcting residual target.

Structure:
  - _state holds online moments of item sizes plus a running mean of the
    residuals that our own placements have produced.
  - priority() updates state, then computes a score as the sum of four
    well-separated terms:
        base      : best-fit (smaller residual wins) -- dominates ordering
        perfect   : exact fills get a large bonus
        dead_end  : tiny nonzero residuals are penalized
        target    : graded attraction toward an adaptive residual center,
                    blended 0.85*raw_mean + 0.15*chosen_residual_mean.
  - A tiny tiebreak prefers larger residuals to reduce fragmentation.

The blend keeps the decisive raw mean dominant while letting the rule
correct systematic over/under-shooting in the residuals it creates.
"""
import numpy as np

_state = {
    "n": 0.0,
    "sum": 0.0,
    "sumsq": 0.0,
    "min_item": 100.0,
    "res_sum": 0.0,
    "res_n": 0.0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    # ---------- state update ----------
    _state["n"] += 1.0
    _state["sum"] += float(item)
    _state["sumsq"] += float(item) * float(item)
    if float(item) < _state["min_item"]:
        _state["min_item"] = float(item)

    n = _state["n"]
    if n > 1.0:
        mu_raw = _state["sum"] / n
        var = _state["sumsq"] / n - mu_raw * mu_raw
        if var < 0.0:
            var = 0.0
        sigma_raw = float(np.sqrt(var))
    else:
        mu_raw = 40.0
        sigma_raw = 15.0

    # ---------- adaptive residual target ----------
    if _state["res_n"] > 0.0:
        res_mean = _state["res_sum"] / _state["res_n"]
    else:
        res_mean = mu_raw
    # Conservative self-correction: raw mean stays decisive.
    mu_target = 0.85 * mu_raw + 0.15 * res_mean
    # Guard against drift from early/rare items.
    mu_target = min(90.0, max(10.0, mu_target))

    # ---------- scoring ----------
    r = bins - item
    rf = r.astype(np.float64)

    # Base: best-fit (smaller residual is better). Dominant ordering term.
    base = -rf

    # Exact fills always win.
    perfect = np.where(r == 0, 100.0, 0.0)

    # Penalize tiny nonzero residuals that are hard to reuse.
    min_item = _state["min_item"] if _state["min_item"] >= 1.0 else 1.0
    grad = np.minimum(1.0, (min_item - rf) / min_item)
    dead_end = -0.5 * grad * np.where(r > 0, 1.0, 0.0)

    # Graded attraction toward the adaptive residual center.
    # Reward residuals near mu_target; gently penalize those far from it.
    target = -0.02 * np.abs(rf - mu_target)

    # Tiny tiebreak: prefer larger residuals to consolidate small scraps.
    tiebreak = -0.01 * rf

    return base + perfect + dead_end + target + tiebreak
# EVOLVE-BLOCK-END