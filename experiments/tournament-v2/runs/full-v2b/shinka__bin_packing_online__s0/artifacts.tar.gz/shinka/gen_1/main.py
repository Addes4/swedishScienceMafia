# EVOLVE-BLOCK-START
"""Best fit with a usability floor: prefer tight fits, but avoid leaving
leftovers too small to hold a typical future item."""
import numpy as np

# Running statistics of past items (state kept across calls).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running mean estimate of item sizes.
    _state["n"] += 1
    _state["sum"] += float(item)
    mu = _state["sum"] / _state["n"]
    # Clamp to a sensible prior range so early estimates are not too extreme.
    mu = min(max(mu, 20.0), 60.0)

    r = bins - item  # leftover capacity after placing the item here

    # Primary: best fit (tightest fit => smallest leftover).
    score = -r.astype(np.float64)

    # Secondary: penalize tiny non-zero leftovers that cannot hold a typical item.
    # Exact fits (r == 0) are strongly rewarded; unusable small leftovers demoted.
    score += 5.0 * (r == 0)
    score -= 0.5 * ((r > 0) & (r < mu))

    return score
# EVOLVE-BLOCK-END