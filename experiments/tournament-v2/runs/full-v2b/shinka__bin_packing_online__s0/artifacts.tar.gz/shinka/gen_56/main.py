# EVOLVE-BLOCK-START
"""Smart best-fit with usability floor: target the residual toward the running
mean item size, strongly prefer exact fits, and penalize dead-end residuals
(too small to hold a typical future item)."""
import numpy as np


# Online estimate of the mean item size (state kept across calls).
# Also track the mean observed residual of chosen bins for a light
# self-correcting bias correction on the target.
_state = {"n": 0, "sum": 0.0, "res_sum": 0.0, "res_n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Strategy:
      - Primary: prefer the bin whose residual after placing this item is closest
        to the running mean item size, so a future typical item can fill it.
      - Exact fits (residual == 0) are strongly preferred.
      - Penalize dead-end residuals that are positive but too small to hold a
        typical item (below the running mean), since these waste capacity.
      - Among equidistant residuals, prefer the tighter fit (best-fit tiebreak).
    """
    # Update running mean estimate of item sizes.
    _state["n"] += 1
    _state["sum"] += float(item)
    mu = _state["sum"] / _state["n"]

    # Light self-correcting blend: pull the target toward the observed mean
    # residual of previously chosen bins. Small weight (0.10) so it corrects
    # slow bias without replacing the primary target.
    if _state["res_n"] >= 50:
        res_mean = _state["res_sum"] / _state["res_n"]
        mu = 0.90 * mu + 0.10 * res_mean

    # Clamp to a sensible prior range so early estimates are not too extreme.
    mu = min(max(mu, 20.0), 60.0)

    residual = (bins - item).astype(np.float64)

    # Primary: prefer residual close to the expected next item size.
    score = -np.abs(residual - mu)

    # Secondary: among residuals equidistant from mu, prefer the tighter fit.
    score -= 0.01 * residual

    # Strong bonus for exact fits (perfectly packed bin).
    score += 100.0 * (residual == 0)

    # Penalize residuals that are positive but too small to hold a typical
    # item (below the running mean): these are effectively wasted capacity.
    score -= 0.5 * ((residual > 0) & (residual < mu))

    # Record the residual of the bin we are about to select (highest score,
    # first on ties) to feed the residual-mean bias correction.
    chosen = int(np.argmax(score))
    _state["res_sum"] += float(residual[chosen])
    _state["res_n"] += 1

    return score
# EVOLVE-BLOCK-END