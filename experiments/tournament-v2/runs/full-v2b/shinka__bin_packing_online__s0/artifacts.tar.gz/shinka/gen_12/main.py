# EVOLVE-BLOCK-START
"""Dual-target residual best-fit with adaptive quantile targets."""
import numpy as np

# Online state across calls.
_state = {
    "n": 0,
    "sum": 0.0,
    "sum_sq": 0.0,
    "ema": 40.0,
    # Running histogram of item sizes (bins of width 5 over 1..100).
    "hist": np.zeros(20, dtype=np.float64),
    "hist_total": 0.0,
}


def _quantile_from_hist(hist, total, q):
    """Approximate the q-quantile (0..1) of item sizes from the running histogram."""
    if total <= 0.0:
        return 40.0
    target = q * total
    cum = 0.0
    for i in range(len(hist)):
        cum += hist[i]
        if cum >= target:
            # Center of bucket i: sizes 5*i+1 .. 5*i+5, midpoint 5*i+3.
            return 5.0 * i + 3.0
    return 100.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Strategy: maintain two residual targets (a small-item mode and a large-item mode)
    estimated from the running item-size distribution. A bin is rewarded for matching
    either mode, so we keep both nearly-full bins (ready for small items) and
    half-full bins (ready for large items). Exact fits get a size-scaled bonus.
    """
    # ---- Update online distribution estimates ----
    _state["n"] += 1
    _state["sum"] += float(item)
    _state["sum_sq"] += float(item) * float(item)
    _state["ema"] = 0.98 * _state["ema"] + 0.02 * float(item)

    n = _state["n"]
    cum_mean = _state["sum"] / n
    var = max(_state["sum_sq"] / n - cum_mean * cum_mean, 0.0)
    sigma = var ** 0.5

    # Update histogram (bucket width 5).
    b = int((item - 1) // 5)
    if b < 0:
        b = 0
    elif b > 19:
        b = 19
    _state["hist"][b] += 1.0
    _state["hist_total"] += 1.0

    # Blend cumulative mean and EMA for a stable center estimate.
    center = 0.5 * cum_mean + 0.5 * _state["ema"]

    # Variance-aware adaptive clamp: allow center to drift within mu +/- 2*sigma,
    # but never outside a safe absolute range.
    lo = min(max(center - 2.0 * sigma, 5.0), 45.0)
    hi = min(max(center + 2.0 * sigma, 55.0), 95.0)

    # Two quantile targets from the running histogram.
    if _state["hist_total"] >= 20:
        t_small = _quantile_from_hist(_state["hist"], _state["hist_total"], 0.30)
        t_large = _quantile_from_hist(_state["hist"], _state["hist_total"], 0.70)
    else:
        # Early fallback: use the blended center with symmetric spread.
        t_small = center * 0.6
        t_large = center * 1.4
    t_small = min(max(t_small, lo), hi)
    t_large = min(max(t_large, lo), hi)

    residual = (bins - item).astype(np.float64)

    # Primary: reward matching either target mode.
    d_small = np.abs(residual - t_small)
    d_large = np.abs(residual - t_large)
    score = -np.minimum(d_small, d_large)

    # Secondary: prefer the tighter fit among near-equal matches.
    score -= 0.01 * residual

    # Continuous usefulness reward: residuals in a productive band are good.
    # Productive means "a future item could plausibly fill this".
    useful = (residual >= t_small * 0.5) & (residual <= t_large)
    score += 0.5 * useful.astype(np.float64)

    # Penalize tiny nonzero residuals that are likely wasted space.
    tiny = (residual > 0) & (residual < 4)
    score -= 1.5 * tiny.astype(np.float64)

    # Exact-fit bonus, scaled by item size (bigger exact fits are more valuable).
    score += (50.0 + float(item)) * (residual == 0)

    return score
# EVOLVE-BLOCK-END
