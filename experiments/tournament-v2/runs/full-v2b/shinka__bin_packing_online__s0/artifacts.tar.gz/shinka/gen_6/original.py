# EVOLVE-BLOCK-START
"""Smart best-fit: best-fit with a small penalty for tiny residuals and a bonus for useful residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best-fit (higher score for tighter fit)
    score = -residual.astype(np.float64)
    # Penalty for tiny residuals (likely wasted space)
    tiny = np.maximum(0, 10 - residual)
    score -= 0.3 * tiny
    # Bonus for residuals near the typical item size (mean ~40)
    bonus = 0.1 * np.exp(-((residual - 40.0) ** 2) / 200.0)
    score += bonus
    return score
# EVOLVE-BLOCK-END