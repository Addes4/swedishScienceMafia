# EVOLVE-BLOCK-START
"""Soft residual target: score bins by expected future packing utility.

Instead of targeting the running mean with a symmetric penalty, we track a
coarse histogram of observed item sizes and score each candidate bin by how
likely its residual is to be usefully filled by a future item.  We use the
observed *mode* of the size distribution plus an asymmetric right-tail
allowance, since the Weibull-shaped item distribution is right-skewed.
"""
import numpy as np


# State kept across calls: running count, sum, min, and a coarse histogram.
_BUCKETS = 10  # 10-size buckets over 1..100
_state = {
    "n": 0,
    "sum": 0.0,
    "min_item": 100,
    "hist": np.zeros(_BUCKETS, dtype=np.float64),
}


def _bucket(i):
    # bucket index for item size i in 1..100
    b = int((i - 1) // 10)
    if b < 0:
        b = 0
    elif b >= _BUCKETS:
        b = _BUCKETS - 1
    return b


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    Strategy (novel vs. closest-to-mean):
      - Estimate the *mode* of the observed size distribution (not the mean),
        since packing is dominated by typical items.
      - Add an asymmetric right-tail allowance: residuals slightly above the
        mode are favored because the Weibull tail makes larger follow-ups
        plausible; residuals far below the mode are penalized less harshly
        than a hard dead-end rule would.
      - Soft exact-fit bonus when the residual matches a commonly observed
        item size (peak of the histogram), which tends to close bins cleanly.
      - Best-fit tiebreak.
    """
    # ---- update running statistics ----
    _state["n"] += 1
    _state["sum"] += float(item)
    if item < _state["min_item"]:
        _state["min_item"] = int(item)
    _state["hist"][_bucket(item)] += 1.0

    n = _state["n"]
    mu = _state["sum"] / n
    # Clamp the prior for very early calls.
    mu = min(max(mu, 20.0), 60.0)

    hist = _state["hist"]
    # Mode estimate: center of the most populated bucket (fallback to mu).
    if n >= 20 and hist.sum() > 0:
        mode_b = int(np.argmax(hist))
        mode = mode_b * 10 + 5.5  # center of bucket
        mode = min(max(mode, 15.0), 70.0)
    else:
        mode = mu

    # Blend mode and mean early on; trust mode more as data accumulates.
    w = min(1.0, n / 200.0)
    target = w * mode + (1.0 - w) * mu

    min_item = float(_state["min_item"])

    residual = (bins - item).astype(np.float64)

    # ---- asymmetric residual preference ----
    # Penalize distance to target asymmetrically: residuals above target are
    # cheaper (right tail can fill them), residuals below target cost more
    # once they drop below the smallest observed item.
    diff = residual - target
    score = -np.where(diff >= 0.0, 0.35 * diff, 1.0 * (-diff))

    # ---- soft exact-fit bonus ----
    # Exact fit is best; near-exact (within a couple units) also valuable.
    score += 6.0 * (residual == 0)
    score += 1.5 * ((residual > 0) & (residual <= 2))

    # ---- minimum-viable-residual floor ----
    # Residuals positive but below the smallest observed item can never be
    # closed by a single item; penalize gently (soft, not hard) and scale
    # by how small they are.
    dead = (residual > 0) & (residual < min_item)
    score -= 0.4 * dead * (1.0 - residual / max(min_item, 1.0))

    # ---- best-fit tiebreak: among near-equal scores prefer tighter bins ----
    score -= 0.01 * residual

    return score
# EVOLVE-BLOCK-END