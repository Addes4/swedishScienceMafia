# EVOLVE-BLOCK-START
"""Blended residual target: raw mean blended with mean of chosen residuals."""
import numpy as np


# Online state: raw item stats + stats of residuals we actually selected.
_state = {
    "n": 0,
    "sum": 0.0,
    "sum_sq": 0.0,
    "min_item": 100,
    "res_sum": 0.0,
    "res_n": 0,
    "last_score": None,
}


def _update_item_stats(item):
    s = _state
    x = float(item)
    s["n"] += 1
    s["sum"] += x
    s["sum_sq"] += x * x
    s["min_item"] = min(s["min_item"], int(item))


def _target_mu():
    s = _state
    n = s["n"]
    mu_raw = s["sum"] / n if n > 0 else 40.0

    # Blend raw mean with running mean of chosen residuals (self-correcting).
    if s["res_n"] > 0:
        res_mean = s["res_sum"] / s["res_n"]
        mu_target = 0.85 * mu_raw + 0.15 * res_mean
    else:
        mu_target = mu_raw

    # Clamp to sensible prior range (Weibull mean ~40).
    return min(max(mu_target, 20.0), 60.0)


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    _update_item_stats(item)
    mu = _target_mu()
    min_item = _state["min_item"]

    residual = (bins - item).astype(np.float64)

    # Primary: prefer residual close to the adaptive target.
    score = -np.abs(residual - mu)

    # Mild tiebreak: among equidistant residuals, prefer tighter fits.
    score -= 0.02 * residual

    # Strong bonus for exact fits.
    score += 200.0 * (residual == 0)

    # Small bonus for residuals large enough to still accept a typical item.
    score += 0.5 * (residual >= mu)

    # Dead-end penalty: positive residuals too small for any observed item.
    if min_item > 0:
        dead = (residual > 0) & (residual < min_item)
        if dead.any():
            score -= 0.3 * np.where(dead, (min_item - residual) / float(min_item), 0.0)

    # Record the residual of the bin that will actually be chosen (argmax, first on ties).
    idx = int(np.argmax(score))
    chosen_res = float(residual[idx])
    s = _state
    s["res_sum"] += chosen_res
    s["res_n"] += 1

    return score
# EVOLVE-BLOCK-END