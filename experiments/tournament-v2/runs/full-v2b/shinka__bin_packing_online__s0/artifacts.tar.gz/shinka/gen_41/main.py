# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    r = bins - item  # residual capacity after placing the item
    rf = r.astype(np.float64)
    base = -rf  # best-fit: smaller residual is better (integer gaps dominate)

    # Online running mean and variance of item sizes (mu ~ 40 for this distribution).
    # Track sum and sum_sq to derive sigma, which adapts the target band to the
    # actual instance distribution instead of a fixed clamp.
    global _mu, _sum, _sum_sq, _n
    try:
        _mu
    except NameError:
        _mu = 40.0
        _sum = 0.0
        _sum_sq = 0.0
        _n = 0.0
    _n += 1.0
    _sum += float(item)
    _sum_sq += float(item) * float(item)
    # EMA for stability early on
    _mu = 0.99 * _mu + 0.01 * float(item)
    mu_raw = _sum / _n
    var = _sum_sq / _n - mu_raw * mu_raw
    if var < 0.0:
        var = 0.0
    sigma = var ** 0.5
    # Variance-adaptive band centered on the running mean, with a guard range
    # so early iterations (unreliable sigma) don't destabilize the target.
    lo = mu_raw - 1.2 * sigma
    hi = mu_raw + 1.2 * sigma
    if lo < 10.0:
        lo = 10.0
    if hi > 90.0:
        hi = 90.0
    mu = 0.5 * (lo + hi)
    # Keep mu in a sane range as a safety net.
    if mu < 20.0:
        mu = 20.0
    elif mu > 60.0:
        mu = 60.0
=======

    # Strongly reward perfect fills (r == 0); r==0 is already best base so this
    # only reinforces it and cannot override a strictly better fit.
    perfect = np.where(r == 0, 5.0, 0.0)

    # Penalize tiny scraps (residual 1..3) that are nearly unusable for future
    # items; this breaks ties in favor of leaving reusable space.
    scrap = np.where((r >= 1) & (r <= 3), -0.5, 0.0)

    # Asymmetric residual-targeting: a bin is usually filled by several future
    # items, so a residual slightly BELOW mu is more useful than one at/above mu
    # (a residual below mu can still absorb a full typical item; one above mu
    # wastes capacity no single item can fully use). Reward residuals just under
    # mu and gently penalize those just above it.
    target = 0.9 * mu
    asym = -0.02 * np.abs(rf - target)
    asym += -0.02 * np.maximum(0.0, mu - rf)  # extra push toward slightly-under-mu

    # Tiny tiebreak: prefer larger residuals to consolidate small scraps.
    tiebreak = 0.001 * rf

    return base + perfect + scrap + asym + tiebreak
# EVOLVE-BLOCK-END