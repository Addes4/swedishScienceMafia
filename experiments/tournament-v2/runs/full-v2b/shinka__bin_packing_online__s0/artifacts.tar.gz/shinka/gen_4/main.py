# EVOLVE-BLOCK-START
"""Distribution-aware residual valuation.

Instead of greedily ranking bins by how tightly the current item fits (best-fit),
we score each candidate bin by how *useful* its resulting residual capacity is
under the empirically observed distribution of item sizes. A residual is useful
if future items are likely to fit into it (especially to close it exactly).

This is a fundamentally different paradigm: rather than minimizing immediate
waste, we maximize the expected future packing value of the leftover space.
"""
import numpy as np

# ---------------------------------------------------------------------------
# State kept across calls: an online histogram of observed item sizes.
# ---------------------------------------------------------------------------
_HIST = np.ones(101, dtype=np.float64)  # Laplace-smoothed counts for sizes 0..100
_HIST[0] = 0.0                          # items are 1..100, size 0 never occurs
_N = 1.0                                # total pseudo-count

# Cached usefulness table for residuals 0..100 (built lazily from _HIST).
_USEFUL = None
_USEFUL_N = -1.0  # total count when the table was last built


def _build_usefulness():
    """Build usefulness[r] = expected value of a bin whose residual is r.

    For residual r, consider each possible future item size s (1..100):
      - if s <= r, placing it leaves residual r - s; the immediate gain is
        a bonus for tight closure (s close to r) plus the value of the new
        residual, recursively approximated by a geometric discount.
      - if s > r, the bin cannot receive s, contributing 0.
    We approximate the recursive term with a single-step lookahead plus a
    global average continuation value, keeping O(100^2) work.
    """
    global _USEFUL, _USEFUL_N
    p = _HIST / _HIST.sum()  # probability of each size

    # Base value for a residual: how likely a future item closes it tightly.
    # tight_bonus[r] = sum_s p[s] * kernel(r - s), kernel peaks at r == s.
    sizes = np.arange(101)
    # Gaussian kernel over |r - s|: strongly rewards near-exact closure.
    sigma = 6.0
    # Precompute kernel matrix contributions in a vectorized way.
    diff = sizes[:, None] - sizes[None, :]          # diff[r, s] = r - s
    kernel = np.exp(-(diff.astype(np.float64) ** 2) / (2.0 * sigma * sigma))
    # Only s <= r are feasible (item must fit). Zero out infeasible entries.
    feasible = (sizes[None, :] <= sizes[:, None]) & (sizes[None, :] >= 1)
    kernel = kernel * feasible
    # Weight each column s by p[s].
    useful = kernel @ p  # useful[r] = sum_s p[s] * kernel(r, s)

    # Add a small continuation term: residuals that can themselves absorb
    # typical items are worth slightly more (encourages leaving usable space).
    typical = np.arange(1, 101)
    mean_s = float((p[1:] * typical).sum())
    # A residual near the mean is generically useful; small ones are not.
    cont = np.exp(-((sizes - mean_s) ** 2) / (2.0 * (mean_s * 0.6 + 1.0) ** 2))
    useful = useful + 0.15 * cont
    useful[0] = useful[0]  # exact closure already rewarded by kernel

    _USEFUL = useful
    _USEFUL_N = _HIST.sum()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _N
    # Update empirical histogram of item sizes.
    _HIST[item] += 1.0
    _N += 1.0

    # Rebuild usefulness table if the distribution estimate changed materially.
    # (Rebuild every call is cheap: 100x100 vectorized ops; but we throttle to
    # every 25 items to save time, plus on the first call.)
    if _USEFUL is None or (_N % 25 == 0):
        _build_usefulness()

    r = (bins - item).astype(np.int64)
    # Clip to valid range (bins shown always fit the item, so r >= 0).
    np.clip(r, 0, 100, out=r)

    # Primary score: usefulness of the resulting residual.
    score = _USEFUL[r].astype(np.float64)

    # Tiny tie-break toward tight fit so equal-usefulness bins prefer fuller ones.
    score += 1e-3 * (-r.astype(np.float64))

    return score
# EVOLVE-BLOCK-END