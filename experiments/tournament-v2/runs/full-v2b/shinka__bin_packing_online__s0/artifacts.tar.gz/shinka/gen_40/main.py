# EVOLVE-BLOCK-START
"""Adaptive best-fit with variance-aware residual targeting and an
empirical future-fit histogram. The bin-choice rule combines:

  - best-fit (smaller residual wins),
  - a strong bonus for exact fills,
  - a penalty for tiny unusable residuals,
  - an empirical bonus for residuals whose size matches frequently
    observed past item sizes (they are likely to be filled exactly),
  - a variance-adaptive bonus for residuals near the running mean,
    clamped to [mu - 1.2*sigma, mu + 1.2*sigma] with a [10, 90] guard,
  - a tiny tie-break favoring larger residuals.

State is kept in a module-level dict and updated once per call.
"""
import numpy as np

# Running statistics: count, sum, sum of squares, and a histogram of
# observed item sizes over buckets 1..100 (index 0 unused).
_state = {
    "n": 0.0,
    "sum": 0.0,
    "sum_sq": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
}

# Tunables for the adaptive band.
_SIGMA_K = 1.2          # half-width of the target band in sigmas
_GUARD_LO = 10.0        # floor for the target band (early iterations)
_GUARD_HI = 90.0        # ceiling for the target band (early iterations)

# Tunables for the scoring components.
_PERFECT_BONUS = 100.0
_TINY_MAX = 4
_TINY_PEN = 0.9
_EMP_SCALE = 3.0
_NEAR_MEAN_SCALE = 1.5
_NEAR_MEAN_WIDTH = 15.0
_TIEBREAK_SCALE = 0.01


def _update_state(item):
    """Update running statistics for the arriving item."""
    if 1 <= item <= 100:
        _state["hist"][item] += 1.0
    _state["n"] += 1.0
    _state["sum"] += item
    _state["sum_sq"] += float(item) * float(item)


def _target_band():
    """Return (target, width) for the near-mean bonus using a
    variance-adaptive band centered on the running mean."""
    n = _state["n"]
    if n < 2.0:
        return 40.0, _NEAR_MEAN_WIDTH
    mu = _state["sum"] / n
    var = _state["sum_sq"] / n - mu * mu
    if var < 0.0:
        var = 0.0
    sigma = var ** 0.5
    lo = mu - _SIGMA_K * sigma
    hi = mu + _SIGMA_K * sigma
    # Guard floor/ceiling to avoid over-commitment early on.
    if lo < _GUARD_LO:
        lo = _GUARD_LO
    if hi > _GUARD_HI:
        hi = _GUARD_HI
    # Center the band on the mean, but keep the width bounded.
    target = mu
    width = max(_NEAR_MEAN_WIDTH, 0.5 * (hi - lo))
    return target, width


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _update_state(item)
    n = _state["n"]
    inv_n = 1.0 / n

    r = bins - item                      # residual capacity after placing the item
    rf = r.astype(np.float64)

    # 1. Best-fit base: smaller residual is better.
    base = -rf

    # 2. Exact fills should always win.
    perfect = np.where(r == 0, _PERFECT_BONUS, 0.0)

    # 3. Penalize tiny nonzero residuals that are hard to reuse.
    tiny = np.where((r > 0) & (r <= _TINY_MAX), -_TINY_PEN, 0.0)

    # 4. Empirical future-fit bonus: reward residuals whose size has been
    #    frequently observed among past items.
    rb = np.clip(r, 0, 100).astype(np.int64)
    prob = _state["hist"][rb] * inv_n
    emp_bonus = _EMP_SCALE * prob

    # 5. Variance-adaptive near-mean bonus.
    target, width = _target_band()
    near_mean = _NEAR_MEAN_SCALE * np.exp(-((rf - target) / width) ** 2)

    # 6. Tiny tie-break favoring larger residuals (less fragmentation).
    tiebreak = _TIEBREAK_SCALE * rf

    return base + perfect + tiny + emp_bonus + near_mean + tiebreak
# EVOLVE-BLOCK-END