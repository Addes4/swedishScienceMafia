# EVOLVE-BLOCK-START
"""Smart best-fit: target the residual toward the running mean item size."""
import numpy as np


# Online estimate of the mean item size (state kept across calls).
_state = {"n": 0, "sum": 0.0, "sum_sq": 0.0, "min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Strategy: prefer the bin whose residual after placing this item is closest to
    the running mean item size, so a future typical item can fill it exactly.
    Exact fits (residual == 0) are strongly preferred; ties among equidistant
    residuals go to the tighter bin (best-fit tiebreak).
    """
    # Update running mean and variance estimates of item sizes.
    _state["n"] += 1
    _state["sum"] += float(item)
    _state["sum_sq"] += float(item) * float(item)
    mu_raw = _state["sum"] / _state["n"]
    # Variance-adaptive band: target tracks the running mean, width follows sigma.
    var = _state["sum_sq"] / _state["n"] - mu_raw * mu_raw
    if var < 0.0:
        var = 0.0
    sigma = var ** 0.5
    lo = max(10.0, mu_raw - 1.2 * sigma)
    hi = min(90.0, mu_raw + 1.2 * sigma)
    mu = min(max(mu_raw, lo), hi)

    # Track the smallest item seen so far (sentinel 100 initially).
    _state["min_item"] = min(_state["min_item"], int(item))

    residual = (bins - item).astype(np.float64)

    # Primary: aim the residual slightly below the expected next item size.
    # A bin is typically filled by several remaining items, so leaving a bit
    # less than mu makes it easier to close the bin with a future item while
    # still allowing a typical item to fit, reducing wasted capacity.
    target = 0.9 * mu
    score = -np.abs(residual - target)

    # Secondary: among residuals equidistant from mu, prefer the tighter fit.
    score -= 0.01 * residual

    # Strong bonus for exact fits (perfectly packed bin).
    score += 100.0 * (residual == 0)

    # Penalize residuals that are positive but too small for any observed item
    # to fill: these are effectively wasted capacity (dead-end bins).
    score -= 0.5 * ((residual > 0) & (residual < _state["min_item"]))

    return score
# EVOLVE-BLOCK-END