# EVOLVE-BLOCK-START
"""Adaptive residual-target best-fit for online bin packing."""
import numpy as np

# State kept across calls for an online estimate of the item-size distribution.
_state = {"n": 0, "sum": 0.0, "ema": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Strategy: prefer the bin whose residual after placing this item is closest to
    the expected next item size. This leaves a useful hole for a future item instead
    of a tiny wasted gap. Exact fits get a strong bonus; ties go to the tighter bin.
    """
    # Update running estimates of item size.
    _state["n"] += 1
    _state["sum"] += float(item)
    cum_mean = _state["sum"] / _state["n"]
    # Exponential moving average adapts faster to recent items.
    _state["ema"] = 0.98 * _state["ema"] + 0.02 * float(item)
    # Blend cumulative and recent estimates, then clamp to a safe prior range.
    mu = 0.5 * cum_mean + 0.5 * _state["ema"]
    mu = min(max(mu, 20.0), 60.0)

    residual = (bins - item).astype(np.float64)

    # Primary: prefer residual close to the expected next item size.
    score = -np.abs(residual - mu)

    # Secondary: among residuals equidistant from mu, prefer the tighter fit.
    score -= 0.01 * residual

    # Strong bonus for exact fits (perfectly packed bin).
    score += 100.0 * (residual == 0)

    # Small penalty for tiny nonzero residuals that are likely wasted.
    tiny = (residual > 0) & (residual < 5)
    score -= 2.0 * tiny

    return score
# EVOLVE-BLOCK-END
