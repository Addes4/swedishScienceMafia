# EVOLVE-BLOCK-START
"""Distribution-driven complement matching: value each bin by the expected
capacity recovered when the residual is filled by a future item drawn from
the empirically observed size distribution, plus an exact-complement bonus."""
import numpy as np

# Running empirical histogram of item sizes (buckets 1..100).
_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0.0}

# Precomputed size axis (reused for mean/CDF computations).
_SIZES = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a score per bin; highest wins (first on ties)."""
    hist = _state["hist"]
    if 1 <= item <= 100:
        hist[item] += 1.0
    _state["n"] += 1.0
    n = _state["n"]
    inv_n = 1.0 / n

    r = bins - item                 # residual after placing the item
    rf = r.astype(np.float64)

    # Base: best-fit -- smaller residual strictly better. Kept as the
    # dominant integer-gap term so we never lose the tightest fit.
    base = -rf

    # Exact fill: residual 0 is unbeatable and must always be chosen.
    perfect = np.where(r == 0, 100.0, 0.0)

    # --- Distribution-driven value of each residual --------------------
    # Expected capacity recovered by this residual: for residual rho, the
    # best future item is the largest observed size <= rho. Weight that
    # recovered amount by its empirical probability. This is the natural
    # "lookahead" value of leaving rho free.
    rb = np.clip(r, 0, 100).astype(np.int64)
    # Empirical probability mass of exactly matching rho (complement pairing).
    prob_exact = hist[rb] * inv_n

    # Empirical mean and a robust upper-usage estimate.
    mean_size = float(np.dot(hist, _SIZES) * inv_n) if n > 1 else 40.0

    # Bonus for residuals that equal a frequently-seen item size: the bin
    # "wants" a specific future item and will be closed exactly.
    complement_bonus = 6.0 * prob_exact

    # Complement-of-mean bonus: two-item bins that pack tightly are the
    # densest structures. Reward residuals whose sum with the mean is ~100.
    target = 100.0 - mean_size
    if target < 1.0:
        target = 1.0
    width = 12.0
    near_complement = 2.0 * np.exp(-((rf - target) / width) ** 2)

    # Penalize unusable scraps (rho in 1..3) that few items can fill.
    scrap = np.where((r >= 1) & (r <= 3), -0.75, 0.0)

    # Mild consolidation: among otherwise-equal bins, prefer larger residual
    # so tiny scraps merge instead of proliferating.
    tiebreak = 0.01 * rf

    return base + perfect + complement_bonus + near_complement + scrap + tiebreak
# EVOLVE-BLOCK-END