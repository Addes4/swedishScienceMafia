# EVOLVE-BLOCK-START
"""Smart best-fit: target the residual toward the running mean item size."""
import numpy as np


# Online estimate of the mean item size (state kept across calls).
# Also track the mean residual of the bin actually chosen, for a light
# self-correcting blend of the target residual.
_state = {"n": 0, "sum": 0.0, "res_sum": 0.0, "res_n": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Strategy: prefer the bin whose residual after placing this item is closest to
    the running mean item size, so a future typical item can fill it exactly.
    Exact fits (residual == 0) are strongly preferred; ties among equidistant
    residuals go to the tighter bin (best-fit tiebreak).
    """
    # Update running mean estimate of item sizes.
    _state["n"] += 1
    _state["sum"] += float(item)
    mu = _state["sum"] / _state["n"]

    # Light self-correcting blend: if we have observed residuals, nudge the
    # target toward the mean residual actually left by past placements.
    # Kept at weight 0.10 to avoid the collapse seen at heavier weights.
    if _state["res_n"] > 0:
        res_mean = _state["res_sum"] / _state["res_n"]
        mu = 0.90 * mu + 0.10 * res_mean

    # Clamp to a sensible prior range so early estimates are not too extreme.
    mu = min(max(mu, 20.0), 60.0)

    residual = (bins - item).astype(np.float64)

    # Primary: prefer residual close to the expected next item size.
    score = -np.abs(residual - mu)

    # Secondary: among residuals equidistant from mu, prefer the tighter fit.
    # Middle-ground tiebreak between the two source programs (0.01 and 0.05).
    score -= 0.03 * residual

    # Strong bonus for exact fits (perfectly packed bin).
    # Moderate bonus between the two source programs (100 and 500).
    score += 200.0 * (residual == 0)

    # Small bonus for residuals large enough to still accept a typical item,
    # which reduces fragmentation on harder instances.
    score += 0.5 * (residual >= mu)

    # Record the residual of the bin the harness will actually pick
    # (highest score, first on ties) to feed the self-correcting blend.
    chosen = int(np.argmax(score))
    _state["res_sum"] += float(residual[chosen])
    _state["res_n"] += 1

    return score
# EVOLVE-BLOCK-END