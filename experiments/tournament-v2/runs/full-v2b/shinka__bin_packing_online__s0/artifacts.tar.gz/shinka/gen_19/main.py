# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    r = bins - item  # residual capacity after placing the item
    rf = r.astype(np.float64)
    base = -rf  # best-fit: smaller residual is better (integer gaps dominate)

    # Strongly reward perfect fills (r == 0); r==0 is already best base so this
    # only reinforces it and cannot override a strictly better fit.
    perfect = np.where(r == 0, 5.0, 0.0)

    # Penalize tiny scraps (residual 1..3) that are nearly unusable for future
    # items; this breaks ties in favor of leaving reusable space.
    scrap = np.where((r >= 1) & (r <= 3), -0.5, 0.0)

    # Small bonus for residuals that can still absorb typical small items
    # (roughly 5..20), reducing fragmentation without disturbing best-fit.
    useful = np.where((r >= 5) & (r <= 20), 0.3, 0.0)

    # Tiny tiebreak: prefer larger residuals to consolidate small scraps.
    tiebreak = 0.001 * rf

    return base + perfect + scrap + useful + tiebreak
# EVOLVE-BLOCK-END