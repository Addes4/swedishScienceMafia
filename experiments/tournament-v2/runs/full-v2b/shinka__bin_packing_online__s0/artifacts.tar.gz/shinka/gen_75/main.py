# EVOLVE-BLOCK-START
"""Harmonic-residual best-fit with robust adaptive target.

Pipeline: state.update(item) -> derive (mu, sigma, min_item) -> score(bins).

Key differences from prior residual-band approaches:
  * Robust location: harmonic blend of global mean and a recent-window mean,
    which is far less sensitive to the Weibull right tail than arithmetic mean.
  * Soft sigmoid compression of the target toward the prior (no hard clamp).
  * Relative-distance primary term (scale-invariant) so bins near the target
    win decisively rather than marginally.
  * Reciprocal dead-end penalty that rises sharply near zero residual.
  * Smooth exact-fit peak via a harmonic weighting.
"""
import numpy as np


# ---------------------------------------------------------------------------
# State: robust running statistics (persist across calls).
# ---------------------------------------------------------------------------
_state = {
    "n": 0,
    "sum": 0.0,
    "sum_sq": 0.0,
    "min_item": 100,
    "prior_mean": 40.0,
    "prior_k": 30.0,
    "recent": [],          # small ring of recent items for window mean
    "window": 64,
}


def _update_state(item):
    """Incorporate a new item and return (mu, sigma, min_item)."""
    x = float(item)
    s = _state
    s["n"] += 1
    s["sum"] += x
    s["sum_sq"] += x * x
    if item < s["min_item"]:
        s["min_item"] = int(item)

    # Maintain a small recent-window buffer.
    rec = s["recent"]
    rec.append(x)
    if len(rec) > s["window"]:
        del rec[0]

    n = s["n"]
    mu_raw = s["sum"] / n
    var = s["sum_sq"] / n - mu_raw * mu_raw
    if var < 0.0:
        var = 0.0
    sigma = var ** 0.5

    # Recent-window mean (robust to tail when window is small).
    if len(rec) >= 8:
        mu_win = sum(rec) / len(rec)
    else:
        mu_win = mu_raw

    # Harmonic blend of global mean and recent mean: 2ab/(a+b).
    # Stable (both positive) and emphasizes the smaller of the two,
    # which effectively damps upward tail excursions.
    a = mu_raw
    b = mu_win
    denom = a + b
    if denom > 1e-9:
        mu_h = 2.0 * a * b / denom
    else:
        mu_h = s["prior_mean"]

    # James-Stein-style shrinkage toward the prior mean.
    k = s["prior_k"]
    mu_shrunk = (n * mu_h + k * s["prior_mean"]) / (n + k)

    # Soft sigmoid compression toward the prior (no hard clamp).
    # For mu near 40 the correction is ~0; for extreme values it damps
    # smoothly toward 40 instead of hitting a wall at 20 or 60.
    dev = mu_shrunk - 40.0
    comp = 1.0 / (1.0 + np.exp(-dev / 10.0))   # in (0,1)
    # comp=0.5 at dev=0 -> no change; as dev grows, comp->1 -> full dev.
    # We use a symmetric compression: mu = 40 + dev * (2*comp - 1) when
    # comp>0.5, else 40 + dev*(2*comp) * ...  Simpler: shrink magnitude
    # by a factor that is 1 for small dev and <1 for large |dev|.
    shrink = 1.0 / (1.0 + (abs(dev) / 25.0) ** 2)
    mu = 40.0 + dev * shrink

    return mu, sigma, s["min_item"]


# ---------------------------------------------------------------------------
# Target band: variance-adaptive half-width around the target residual.
# ---------------------------------------------------------------------------
def _target_band(mu, sigma):
    half = max(4.0, min(1.0 * sigma, 20.0))
    return mu, half


# ---------------------------------------------------------------------------
# Scoring: relative-distance primary + reciprocal dead-end penalty.
# ---------------------------------------------------------------------------
def _score(residual, mu_t, half, min_item):
    """Combine primary + refinement terms into a single score per bin."""
    # Primary: scale-invariant closeness to the adaptive target.
    scale = max(mu_t, 1.0)
    score = -np.abs(residual - mu_t) / scale

    # Smooth exact-fit peak: harmonic weighting gives a sharp but
    # continuous reward as residual -> 0.
    score += 50.0 / (1.0 + residual)

    # Reciprocal dead-end penalty: grows sharply as residual -> 0 but
    # only for residuals below the smallest observed item.
    mi = float(min_item) if min_item > 0 else 1.0
    dead = (residual > 0) & (residual < mi)
    if dead.any():
        # penalty ~ mi/(residual+1); subtract normalized so it's O(1).
        pen = mi / (residual + 1.0)
        score -= 0.5 * np.where(dead, pen, 0.0)

    # Refined tiebreak: prefer tighter fillable fits.
    fillable = residual >= mi
    tie = np.where(fillable, residual, residual + 100.0)
    score -= 0.005 * tie

    # Small bonus for residuals inside the fillable band.
    in_band = (residual >= mi) & (residual <= mu_t + half)
    score += 0.05 * in_band

    return score


# ---------------------------------------------------------------------------
# Public entry point.
# ---------------------------------------------------------------------------
def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    mu, sigma, min_item = _update_state(item)
    mu_t, half = _target_band(mu, sigma)

    residual = (bins - item).astype(np.float64)
    return _score(residual, mu_t, half, min_item)
# EVOLVE-BLOCK-END