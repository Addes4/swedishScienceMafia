# EVOLVE-BLOCK-START
"""Best-fit with subtle tie-breaking: prefer tight fits, avoid leaving
tiny unusable residuals, and mildly favor residuals near the typical item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    r = bins - item  # residual capacity after placing the item

    # Base: best-fit (smaller residual is better). Dominates ordering.
    base = -r.astype(np.float64)

    # Strong bonus for perfect fills: exact fits should always win.
    perfect = np.where(r == 0, 100.0, 0.0)

    # Small penalty for tiny nonzero residuals that are hard to reuse.
    TINY_MAX = 4
    TINY_PEN = 0.9
    tiny = np.where((r > 0) & (r <= TINY_MAX), -TINY_PEN, 0.0)

    # Mild bonus for residuals near the typical item size (~40), which are
    # most likely to be useful for future items.
    PEAK = 40.0
    WIDTH = 18.0
    PEAK_BONUS = 2.0
    near_mean = PEAK_BONUS * np.exp(-((r - PEAK) / WIDTH) ** 2)

    # Tiny tiebreak: slightly prefer larger residuals to reduce fragmentation.
    tiebreak = 0.01 * r.astype(np.float64)

    return base + perfect + tiny + near_mean + tiebreak
# EVOLVE-BLOCK-END