# EVOLVE-BLOCK-START
"""Dual-scale best-fit with empirical histogram matching of residuals."""
import numpy as np


# Online state: count, sum, sum of squares, and a size histogram.
_state = {
    "n": 0,
    "sum": 0.0,
    "sum_sq": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
}


def priority(item, bins):
    """Return a score per bin; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in,
          including unused bins (capacity 100), in bin order.

    Strategy:
      * Track mean mu and std sigma of past items.
      * Two target residuals: mu (typical) and mu + sigma (large-item slot).
      * Score each bin's residual r as the better of two closeness terms,
        plus a histogram bonus if r equals a commonly seen item size,
        plus a strong exact-fit bonus, minus a small best-fit tiebreak.
    """
    n = _state["n"] + 1
    _state["n"] = n
    _state["sum"] += float(item)
    _state["sum_sq"] += float(item) * float(item)
    if 1 <= item <= 100:
        _state["hist"][item] += 1.0

    mu_raw = _state["sum"] / n
    var = _state["sum_sq"] / n - mu_raw * mu_raw
    if var < 0.0:
        var = 0.0
    sigma = var ** 0.5

    # Clamp mean to a sensible prior range for early calls.
    mu = min(max(mu_raw, 25.0), 55.0)
    # Large-item target: shifted up by sigma, clamped.
    large = min(max(mu_raw + sigma, 30.0), 80.0)

    residual = (bins - item).astype(np.float64)

    # Two-scale closeness: best of typical and large-item targets.
    d_mu = np.abs(residual - mu)
    d_lg = np.abs(residual - large)
    closeness = -np.minimum(d_mu, d_lg)

    # Histogram match: how often we've seen an item exactly equal to residual.
    r_int = residual.astype(np.int64)
    valid = (r_int >= 1) & (r_int <= 100)
    hist_score = np.zeros_like(residual)
    if np.any(valid):
        # Normalize by count so far; scale modestly.
        hist_score[valid] = _state["hist"][r_int[valid]] / n
    hist_bonus = 8.0 * hist_score

    # Base score.
    score = closeness + hist_bonus

    # Best-fit tiebreak: prefer tighter residual among near-equal scores.
    score -= 0.02 * residual

    # Strong bonus for exact fits.
    score += 250.0 * (residual == 0.0)

    # Small penalty for residuals too small to ever be useful
    # (positive but smaller than the smallest item seen so far).
    # Track min item lazily from histogram.
    nz = np.nonzero(_state["hist"])[0]
    if nz.size > 0:
        min_item = int(nz[0])
        score -= 0.4 * ((residual > 0.0) & (residual < min_item))

    return score
# EVOLVE-BLOCK-END