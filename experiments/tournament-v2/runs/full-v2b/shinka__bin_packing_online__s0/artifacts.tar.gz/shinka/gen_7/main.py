# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    r = bins - item
    # Primary: best-fit (smaller residual is better).
    base = -r.astype(np.float64)
    # Secondary (tiny): prefer perfect fills and keep tiny residuals usable.
    # Magnitudes are small enough to never override the primary ordering.
    perfect = np.where(r == 0, 1e-3, 0.0)
    small = np.where((r >= 1) & (r <= 2), 5e-4, 0.0)
    return base + perfect + small
# EVOLVE-BLOCK-END