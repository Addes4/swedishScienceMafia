# EVOLVE-BLOCK-START
"""Best-fit with an empirical variance-band residual bonus.

Maintains a running histogram of observed item sizes to estimate the mean
(mu_raw) and standard deviation (sigma_raw) of the item distribution online.
Residuals falling inside a band of +/- 1.0 sigma around mu_raw (guarded to
[10, 90]) are rewarded, since a future item of typical size is likely to fill
them exactly. Exact fills get a large bonus, tiny dead-end residuals are
penalized, and a small tiebreak prefers larger residuals to reduce
fragmentation.
"""
import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),  # counts for sizes 1..100
    "n": 0.0,
    "sum": 0.0,
    "sumsq": 0.0,
    "min_item": 100.0,  # smallest item size observed so far
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    # --- Update running statistics with the arriving item ---
    if 1 <= item <= 100:
        _state["hist"][item] += 1.0
        if float(item) < _state["min_item"]:
            _state["min_item"] = float(item)
    _state["n"] += 1.0
    _state["sum"] += float(item)
    _state["sumsq"] += float(item) * float(item)

    n = _state["n"]
    if n > 1.0:
        mu_raw = _state["sum"] / n
        var = _state["sumsq"] / n - mu_raw * mu_raw
        if var < 0.0:
            var = 0.0
        sigma_raw = float(np.sqrt(var))
    else:
        mu_raw = 40.0
        sigma_raw = 15.0

    # --- Band around the mean, guarded to [10, 90] ---
    lo = max(10.0, mu_raw - 1.0 * sigma_raw)
    hi = min(90.0, mu_raw + 1.0 * sigma_raw)

    r = bins - item  # residual capacity after placing the item
    rf = r.astype(np.float64)

    # Base: best-fit (smaller residual is better); dominates ordering.
    base = -rf

    # Strong bonus for perfect fills: exact fits should always win.
    perfect = np.where(r == 0, 100.0, 0.0)

    # Graded penalty for tiny nonzero residuals: the further a residual falls
    # below the smallest observed item size, the more unfillable it is.
    min_item = _state["min_item"]
    if min_item < 1.0:
        min_item = 1.0
    grad = np.minimum(1.0, (min_item - rf) / min_item)
    dead_end = -0.5 * grad * np.where(r > 0, 1.0, 0.0)

    # Reward residuals inside the empirical variance band.
    in_band = np.where((rf >= lo) & (rf <= hi), 1.0, 0.0)

    # Tiny tiebreak: slightly prefer larger residuals to reduce fragmentation.
    tiebreak = -0.01 * rf

    return base + perfect + dead_end + in_band + tiebreak
# EVOLVE-BLOCK-END