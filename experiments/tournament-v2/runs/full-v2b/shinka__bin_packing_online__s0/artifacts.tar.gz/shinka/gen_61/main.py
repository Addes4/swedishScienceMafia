# EVOLVE-BLOCK-START
"""Hybrid best-fit + empirical histogram tie-breaker.

Combines the robust best-fit core (tightest fit first, exact-fill reward,
tiny-scrap penalty) with a lightweight adaptive histogram of past item
sizes. The histogram provides a small bonus to residuals whose size has
been frequently observed, helping break near-ties intelligently without
ever overriding the primary best-fit ordering.
"""
import numpy as np

# Running histogram of item sizes over 10 coarse buckets (1..100).
_state = {"hist": np.zeros(10, dtype=np.float64), "n": 0.0}

NBUCKETS = 10
BUCKET_W = 100.0 / NBUCKETS  # 10.0
HIST_BONUS = 0.6


def _bucket(x):
    b = int((x - 1) // BUCKET_W)
    if b < 0:
        b = 0
    elif b > NBUCKETS - 1:
        b = NBUCKETS - 1
    return b


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    # Update running histogram with the arriving item (O(1)).
    hist = _state["hist"]
    hist[_bucket(item)] += 1.0
    _state["n"] += 1.0
    inv_n = 1.0 / _state["n"]

    r = bins - item  # residual capacity after placing the item
    rf = r.astype(np.float64)

    # Base: best-fit (smaller residual is better). Dominates ordering.
    base = -rf

    # Reward perfect fills: any positive bonus guarantees exact-fit
    # selection since base is 0 for r==0 and negative otherwise.
    perfect = np.where(r == 0, 100.0, 0.0)

    # Graded penalty for tiny nonzero residuals that are hard to reuse.
    TINY_MAX = 4
    TINY_PEN = 0.5
    tiny_mask = (r > 0) & (r <= TINY_MAX)
    tiny_grade = np.minimum(1.0, (TINY_MAX - r).astype(np.float64) / TINY_MAX)
    tiny = np.where(tiny_mask, -TINY_PEN * tiny_grade, 0.0)

    # Adaptive future-fit bonus: reward residuals whose size falls in a
    # frequently observed bucket among past items. Bounded small so it
    # only breaks near-ties in the best-fit ordering.
    rb = np.clip(((r - 1) // BUCKET_W).astype(np.int64), 0, NBUCKETS - 1)
    hist_bonus = HIST_BONUS * (hist[rb] * inv_n)

    # Mild bonus for residuals near the typical item size (~40), which are
    # most likely to be useful for future items.
    near_mean = 0.8 * np.exp(-((rf - 40.0) / 18.0) ** 2)

    # Tiebreak: prefer larger residuals to consolidate small scraps.
    tiebreak = 0.05 * rf

    return base + perfect + tiny + hist_bonus + near_mean + tiebreak
# EVOLVE-BLOCK-END