# EVOLVE-BLOCK-START
"""Best-fit with empirical residual matching: use a running histogram of
observed item sizes to reward residuals that are likely to be filled exactly
by a future item, while penalizing tiny unusable residuals."""
import numpy as np

# Running histogram of item sizes over 101 buckets (sizes 1..100, plus index 0 unused).
_state = {"hist": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    # Update running histogram with the arriving item.
    hist = _state["hist"]
    if 1 <= item <= 100:
        hist[item] += 1.0
    _state["n"] += 1.0
    inv_n = 1.0 / _state["n"]

    r = bins - item  # residual capacity after placing the item
    rf = r.astype(np.float64)

    # Base: best-fit (smaller residual is better). Dominates ordering.
    base = -rf

    # Strong bonus for perfect fills: exact fits should always win.
    perfect = np.where(r == 0, 100.0, 0.0)

    # Penalty for tiny nonzero residuals (hard to reuse).
    TINY_MAX = 4
    TINY_PEN = 0.9
    tiny = np.where((r > 0) & (r <= TINY_MAX), -TINY_PEN, 0.0)

    # Empirical future-fit bonus: reward residuals whose size has been
    # frequently observed among past items (likely to be filled exactly).
    # Map residual to histogram bucket (residuals > 100 get zero bonus).
    rb = np.clip(r, 0, 100).astype(np.int64)
    # Normalize histogram to probability; scale bonus small so it only
    # breaks near-ties in the best-fit ordering.
    prob = hist[rb] * inv_n
    # Boost for residuals in the typical range; also add a mild preference
    # for residuals slightly below the mean to leave room for a full item.
    emp_bonus = 3.0 * prob

    # Additional: reward residuals close to the running mean item size,
    # but with a small downward shift to leave room for a typical item.
    if _state["n"] > 1:
        # Compute running mean item size from histogram.
        sizes = np.arange(101, dtype=np.float64)
        mean_size = float(np.dot(hist, sizes) * inv_n)
    else:
        mean_size = 40.0
    target = 0.9 * mean_size
    width = 15.0
    near_mean = 1.5 * np.exp(-((rf - target) / width) ** 2)

    # Tiny tiebreak: slightly prefer larger residuals to reduce fragmentation.
    tiebreak = 0.01 * rf

    return base + perfect + tiny + emp_bonus + near_mean + tiebreak
# EVOLVE-BLOCK-END