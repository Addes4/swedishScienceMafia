# EVOLVE-BLOCK-START
"""Hybrid best-fit: pure best-fit as the primary rule, with a small bonus for
residuals that match the running mean item size and a strong bonus for exact fits."""
import numpy as np


# Online estimate of the mean item size (state kept across calls).
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Strategy: primary rule is best-fit (tightest residual).  A secondary bonus
    nudges toward residuals close to the running mean item size, so a future
    typical item can fill the bin exactly.  Exact fits get a strong bonus.
    """
    # Update running mean estimate of item sizes.
    _state["n"] += 1
    _state["sum"] += float(item)
    mu = _state["sum"] / _state["n"]
    # Clamp to a sensible prior range so early estimates are not too extreme.
    mu = min(max(mu, 20.0), 60.0)

    residual = (bins - item).astype(np.float64)

    # Primary: best-fit -- prefer the tightest fit.
    score = -residual

    # Secondary: nudge toward residuals close to the expected next item size.
    # Small weight so it refines rather than overrides best-fit.
    score -= 0.02 * np.abs(residual - mu)

    # Strong bonus for exact fits (perfectly packed bin).
    score += 100.0 * (residual == 0)

    return score
# EVOLVE-BLOCK-END