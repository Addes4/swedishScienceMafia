# EVOLVE-BLOCK-START
"""Smart best-fit: target the residual toward the running mean item size."""
import numpy as np


# Online estimate of the mean item size (state kept across calls).
_state = {"n": 0, "sum": 0.0, "min_item": 100}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Strategy: prefer the bin whose residual after placing this item is closest to
    the running mean item size, so a future typical item can fill it exactly.
    Exact fits (residual == 0) are strongly preferred; ties among equidistant
    residuals go to the tighter bin (best-fit tiebreak).
    """
    # Update running mean estimate of item sizes.
    _state["n"] += 1
    _state["sum"] += float(item)
    mu = _state["sum"] / _state["n"]
    # Clamp to a sensible prior range so early estimates are not too extreme.
    mu = min(max(mu, 20.0), 60.0)

    # Track the smallest item seen so far (sentinel 100 initially).
    _state["min_item"] = min(_state["min_item"], int(item))

    residual = (bins - item).astype(np.float64)

    # Primary: prefer residual close to the expected next item size.
    score = -np.abs(residual - mu)

    # Secondary: among residuals equidistant from mu, prefer the tighter fit.
    score -= 0.01 * residual

    # Strong bonus for exact fits (perfectly packed bin).
    score += 100.0 * (residual == 0)

    # Penalize residuals that are positive but too small for any observed item
    # to fill: these are effectively wasted capacity (dead-end bins).
    score -= 0.5 * ((residual > 0) & (residual < _state["min_item"]))

    return score
# EVOLVE-BLOCK-END