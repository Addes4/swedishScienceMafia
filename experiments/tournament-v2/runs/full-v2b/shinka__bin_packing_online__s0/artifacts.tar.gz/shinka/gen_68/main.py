# EVOLVE-BLOCK-START
"""Smart best-fit: target the residual toward the running mean item size,
with an asymmetric penalty on overshooting the target band."""
import numpy as np


# Online statistics of item sizes (state kept across calls).
_state = {
    "n": 0,
    "sum": 0.0,
    "sum_sq": 0.0,
    "min_item": 100,
    "ema": 40.0,          # exponential moving average of item size
    "ema_alpha": 0.02,    # smoothing factor
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Strategy: prefer the bin whose residual after placing this item is closest to
    an adaptive target equal to the running mean item size. A variance-adaptive
    band around the target marks residuals that a typical future item can fill;
    exact fits are strongly preferred; dead-end residuals (positive but below the
    smallest observed item) are penalized; residuals that overshoot the target
    band are mildly penalized because recovering from an overshoot requires a
    larger-than-average future item; ties go to the tighter fillable bin.
    """
    x = float(item)
    s = _state
    s["n"] += 1
    s["sum"] += x
    s["sum_sq"] += x * x
    s["min_item"] = min(s["min_item"], int(item))
    s["ema"] = (1.0 - s["ema_alpha"]) * s["ema"] + s["ema_alpha"] * x

    n = s["n"]
    mu_raw = s["sum"] / n
    var = s["sum_sq"] / n - mu_raw * mu_raw
    if var < 0.0:
        var = 0.0
    sigma = var ** 0.5

    # Blend raw mean with EMA early on to damp startup noise.
    if n < 200:
        w = n / 200.0
        mu_raw = w * mu_raw + (1.0 - w) * s["ema"]

    # Clamp target to a sensible prior range (Weibull mean ~40).
    mu = min(max(mu_raw, 20.0), 60.0)

    # Variance-adaptive band around the target.
    half = max(4.0, min(1.0 * sigma, 20.0))

    min_item = s["min_item"]
    residual = (bins - item).astype(np.float64)

    # Primary: prefer residual close to the expected next item size.
    score = -np.abs(residual - mu)

    # Asymmetric overshoot penalty: residuals above mu + half require a
    # larger-than-average future item to fill, which is harder to recover
    # from than an undershoot inside [min_item, mu]. Small weight keeps
    # this a tiebreaker on top of the winning symmetric primary.
    score -= 0.02 * np.maximum(0.0, residual - (mu + half))

    # Strong bonus for exact fits (perfectly packed bin).
    score += 50.0 * (residual == 0)

    # Dead-end penalty: positive residuals too small for any observed item.
    dead = (residual > 0) & (residual < min_item)
    if dead.any():
        denom = float(min_item) if min_item > 0 else 1.0
        score -= 0.5 * np.where(dead, (min_item - residual) / denom, 0.0)

    # Mild tiebreak: prefer tighter fits, but push dead-end near-zero
    # residuals behind fillable ones so they are not accidentally preferred.
    fillable = residual >= min_item
    tie = np.where(fillable, residual, residual + 100.0)
    score -= 0.01 * tie

    # Small bonus for residuals inside the fillable band [min_item, mu+half].
    in_band = (residual >= min_item) & (residual <= mu + half)
    score += 0.05 * in_band

    return score
# EVOLVE-BLOCK-END