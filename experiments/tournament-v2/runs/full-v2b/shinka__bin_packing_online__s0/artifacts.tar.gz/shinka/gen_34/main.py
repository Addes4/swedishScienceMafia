# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np

# ---- Minimal running histogram of item sizes (online, O(1) per call) ----
_state = {
    "n": 0.0,
    "hist": np.zeros(10, dtype=np.float64),
}

NBUCKETS = 10
BUCKET_W = 100.0 / NBUCKETS      # 10.0
BUCKET_MID = np.array([5.0, 15.0, 25.0, 35.0, 45.0,
                       55.0, 65.0, 75.0, 85.0, 95.0])
HIST_BONUS = 0.2                 # bounded tie-break weight
MU_LO, MU_HI = 20.0, 60.0        # clamp for the target residual
TARGET_FRAC = 0.9                # aim slightly below mu
OVER_PEN = 0.02                  # extra penalty for residual above target


def _bucket(x):
    b = int((x - 1) // BUCKET_W)
    if b < 0:
        b = 0
    elif b > NBUCKETS - 1:
        b = NBUCKETS - 1
    return b


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # ---- Update running histogram with the arriving item ----
    _state["n"] += 1.0
    _state["hist"][_bucket(item)] += 1.0
    inv_n = 1.0 / _state["n"]

    # Running mean item size from the histogram (cheap online estimate).
    mu = float(np.dot(_state["hist"], BUCKET_MID) * inv_n)
    target = TARGET_FRAC * mu
    if target < MU_LO:
        target = MU_LO
    elif target > MU_HI:
        target = MU_HI

    r = bins - item  # residual capacity after placing the item
    rf = r.astype(np.float64)

    # Primary: asymmetric target — prefer residual close to (slightly below) mu,
    # so the bin is likely to be filled by one more typical item.
    base = -np.abs(rf - target)
    # Extra penalty when residual exceeds the target (item placed too loosely).
    over = -OVER_PEN * np.maximum(0.0, rf - target)

    # Strongly reward perfect fills (r == 0).
    perfect = np.where(r == 0, 10.0, 0.0)
    # Slightly penalize tiny nonzero residuals that are hard to reuse.
    tiny = np.where((r > 0) & (r <= 5), -0.5, 0.0)
    # Small tiebreak: prefer larger residuals to consolidate small scraps.
    tiebreak = -0.01 * rf
    # Minimal future-fit bonus: reward residuals in frequently-seen size buckets.
    rb = np.clip(((r - 1) // BUCKET_W).astype(np.int64), 0, NBUCKETS - 1)
    hist_bonus = HIST_BONUS * (np.asarray(_state["hist"])[rb] * inv_n)

    return base + over + perfect + tiny + tiebreak + hist_bonus
# EVOLVE-BLOCK-END