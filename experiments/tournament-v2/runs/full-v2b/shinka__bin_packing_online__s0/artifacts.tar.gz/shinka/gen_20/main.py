# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np

# ---- Minimal running histogram of item sizes (online, O(1) per call) ----
_state = {
    "n": 0.0,
    "hist": np.zeros(10, dtype=np.float64),
}

NBUCKETS = 10
BUCKET_W = 100.0 / NBUCKETS      # 10.0
HIST_BONUS = 0.5                 # bounded tie-break weight


def _bucket(x):
    b = int((x - 1) // BUCKET_W)
    if b < 0:
        b = 0
    elif b > NBUCKETS - 1:
        b = NBUCKETS - 1
    return b


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # ---- Update running histogram with the arriving item ----
    _state["n"] += 1.0
    _state["hist"][_bucket(item)] += 1.0
    inv_n = 1.0 / _state["n"]

    r = bins - item  # residual capacity after placing the item
    base = -r.astype(np.float64)  # best-fit: smaller residual is better
    # Strongly reward perfect fills (r == 0).
    perfect = np.where(r == 0, 10.0, 0.0)
    # Slightly penalize tiny nonzero residuals that are hard to reuse.
    tiny = np.where((r > 0) & (r <= 5), -0.5, 0.0)
    # Minimal future-fit bonus: reward residuals in frequently-seen size buckets.
    rb = np.clip(((r - 1) // BUCKET_W).astype(np.int64), 0, NBUCKETS - 1)
    hist_bonus = HIST_BONUS * (np.asarray(_state["hist"])[rb] * inv_n)
    return base + perfect + tiny + hist_bonus
# EVOLVE-BLOCK-END