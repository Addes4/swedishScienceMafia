# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    r = bins - item  # residual capacity after placing the item
    base = -r.astype(np.float64)  # best-fit: smaller residual is better
    # Strongly reward perfect fills (r == 0).
    perfect = np.where(r == 0, 10.0, 0.0)
    # Slightly penalize tiny nonzero residuals that are hard to reuse.
    tiny = np.where((r > 0) & (r <= 5), -0.5, 0.0)
    return base + perfect + tiny
# EVOLVE-BLOCK-END