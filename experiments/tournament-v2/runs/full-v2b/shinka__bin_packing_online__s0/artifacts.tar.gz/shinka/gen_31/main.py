# EVOLVE-BLOCK-START
"""Distribution-aware best-fit: score bins by how likely their residual can be filled."""
import numpy as np

# Online histogram of item sizes (1..100), plus counts.
_state = {
    "n": 0,
    "sum": 0.0,
    "hist": np.zeros(101, dtype=np.float64),  # hist[s] = count of items of size s
    "min_item": 100,
}


def _fill_potential(residual, hist, n):
    """Estimate probability that a residual gap can be exactly closed by future items.

    Uses the empirical item-size distribution: for a residual r, the chance that
    the *next* item is exactly r is hist[r]/n. For larger residuals, approximate
    the chance that some combination of 2 items closes it, using a convolution
    of the distribution. This gives a smooth "fillability" score.
    """
    if residual <= 0:
        return 0.0
    r = int(round(residual))
    if r < 1 or r > 100:
        return 0.0
    if n == 0:
        # Uniform prior over 1..100.
        p1 = 1.0 / 100.0
    else:
        p1 = hist[r] / n

    # Two-item fill probability: sum_s p(s) * p(r - s), approximated.
    if r >= 2:
        if n == 0:
            p2 = (r - 1) / (100.0 * 100.0)
        else:
            # Use histogram convolution restricted to valid sizes.
            lo = max(1, r - 100)
            hi = min(100, r - 1)
            if hi >= lo:
                p2 = np.sum(hist[lo:hi + 1] * hist[r - hi:r - lo][::-1]) / (n * n)
            else:
                p2 = 0.0
    else:
        p2 = 0.0

    # Weight next-item fill most strongly; two-item fills contribute less
    # (they require an extra item, so less certain).
    return p1 + 0.5 * p2


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Strategy: for each bin, look at the residual gap after placing this item.
    Score the bin by the estimated probability that this gap can later be closed
    exactly by one or two future items, using an online histogram of the item
    stream. Exact fits get a large bonus; among otherwise equal bins, prefer
    tighter fits (best-fit tiebreak).
    """
    # Update running statistics and histogram.
    _state["n"] += 1
    _state["sum"] += float(item)
    _state["hist"][item] += 1.0
    _state["min_item"] = min(_state["min_item"], int(item))

    n = _state["n"]
    hist = _state["hist"]

    residual = (bins - item).astype(np.float64)

    # Base: prefer residuals with high fillability.
    # Vectorize fill potential over all candidate residuals.
    # p1 part:
    r_idx = np.clip(np.round(residual).astype(np.int64), 0, 100)
    if n > 0:
        p1 = hist[r_idx] / n
    else:
        p1 = np.full_like(residual, 1.0 / 100.0)

    # p2 part: convolution-based two-item fill, computed per unique residual.
    p2 = np.zeros_like(residual)
    uniq = np.unique(r_idx)
    for r in uniq:
        if r < 2 or r > 100:
            continue
        lo = max(1, r - 100)
        hi = min(100, r - 1)
        if hi < lo:
            continue
        if n > 0:
            val = np.sum(hist[lo:hi + 1] * hist[r - hi:r - lo][::-1]) / (n * n)
        else:
            val = (r - 1) / (100.0 * 100.0)
        p2[r_idx == r] = val

    score = p1 + 0.5 * p2

    # Best-fit tiebreak: prefer tighter fits (smaller residual) among equal fillability.
    score -= 0.001 * residual

    # Strong bonus for exact fits.
    score += 10.0 * (residual == 0)

    # Penalize tiny residuals that no observed item can fill (dead-end bins).
    min_item = _state["min_item"]
    score -= 0.5 * ((residual > 0) & (residual < min_item))

    return score
# EVOLVE-BLOCK-END