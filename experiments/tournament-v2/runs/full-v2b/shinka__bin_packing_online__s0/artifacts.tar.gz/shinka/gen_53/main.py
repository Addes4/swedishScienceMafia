# EVOLVE-BLOCK-START
"""Adaptive best-fit with a tightened variance band around the running mean.

Bin-choice rule combines:
  - best-fit (smaller residual wins) as the dominant base term,
  - a strong bonus for exact fills (r == 0),
  - a small penalty for tiny unusable residuals (r in 1..4),
  - an empirical future-fit bonus: reward residuals whose size has been
    frequently observed among past items (likely to be filled exactly),
  - a variance-adaptive near-mean bonus centered on the running mean mu,
    with half-width max(4.0, min(0.8*sigma, 20.0)) -- the multiplier is
    swept down from 1.0 to 0.8 to tighten the band and reduce over-commitment,
  - a tiny tie-break favoring larger residuals (less fragmentation).

State is kept in a module-level dict and updated once per call.
"""
import numpy as np

# Running statistics: count, sum, sum of squares, and a histogram of
# observed item sizes over buckets 1..100 (index 0 unused).
_state = {
    "n": 0.0,
    "sum": 0.0,
    "sum_sq": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
}

# Tunables for the tightened adaptive band.
_SIGMA_K = 0.8          # half-width multiplier in sigmas (swept 1.0 -> 0.8)
_BAND_FLOOR = 4.0       # floor for the band half-width
_BAND_CEIL = 20.0       # ceiling for the band half-width
_MEAN_FALLBACK = 40.0   # fallback target before enough samples

# Tunables for the scoring components.
_PERFECT_BONUS = 100.0
_TINY_MAX = 4
_TINY_PEN = 0.9
_EMP_SCALE = 3.0
_NEAR_MEAN_SCALE = 1.5
_TIEBREAK_SCALE = 0.01


def _update_state(item):
    """Update running statistics for the arriving item."""
    if 1 <= item <= 100:
        _state["hist"][item] += 1.0
    _state["n"] += 1.0
    _state["sum"] += item
    _state["sum_sq"] += float(item) * float(item)


def _target_band():
    """Return (target, half_width) for the near-mean bonus using a
    variance-adaptive band centered on the running mean."""
    n = _state["n"]
    if n < 2.0:
        return _MEAN_FALLBACK, _BAND_FLOOR
    mu = _state["sum"] / n
    var = _state["sum_sq"] / n - mu * mu
    if var < 0.0:
        var = 0.0
    sigma = var ** 0.5
    half = _SIGMA_K * sigma
    if half < _BAND_FLOOR:
        half = _BAND_FLOOR
    if half > _BAND_CEIL:
        half = _BAND_CEIL
    return mu, half


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _update_state(item)
    n = _state["n"]
    inv_n = 1.0 / n

    r = bins - item                      # residual capacity after placing the item
    rf = r.astype(np.float64)

    # 1. Best-fit base: smaller residual is better.
    base = -rf

    # 2. Exact fills should always win.
    perfect = np.where(r == 0, _PERFECT_BONUS, 0.0)

    # 3. Penalize tiny nonzero residuals that are hard to reuse.
    tiny = np.where((r > 0) & (r <= _TINY_MAX), -_TINY_PEN, 0.0)

    # 4. Empirical future-fit bonus: reward residuals whose size has been
    #    frequently observed among past items.
    rb = np.clip(r, 0, 100).astype(np.int64)
    prob = _state["hist"][rb] * inv_n
    emp_bonus = _EMP_SCALE * prob

    # 5. Variance-adaptive near-mean bonus with tightened band.
    target, half = _target_band()
    near_mean = _NEAR_MEAN_SCALE * np.exp(-((rf - target) / half) ** 2)

    # 6. Tiny tie-break favoring larger residuals (less fragmentation).
    tiebreak = _TIEBREAK_SCALE * rf

    return base + perfect + tiny + emp_bonus + near_mean + tiebreak
# EVOLVE-BLOCK-END