# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    r = bins - item  # residual capacity after placing the item
    rf = r.astype(np.float64)
    base = -rf  # best-fit: smaller residual is better (integer gaps dominate)

    # Reward perfect fills (r == 0). Any positive bonus guarantees exact-fit
    # selection since base is 0 for r==0 and negative otherwise; a smaller
    # bonus reduces over-commitment and improves cross-instance balance.
    perfect = np.where(r == 0, 100.0, 0.0)

    # Mildly penalize tiny scraps (residual 1..3) that are nearly unusable;
    # kept small so it does not override the primary best-fit ordering.
    scrap = np.where((r >= 1) & (r <= 3), -0.05, 0.0)

    # Tiebreak: prefer larger residuals to consolidate small scraps.
    tiebreak = 0.05 * rf

    return base + perfect + scrap + tiebreak
# EVOLVE-BLOCK-END