# EVOLVE-BLOCK-START
"""Adaptive best-fit with variance-aware residual targeting and an
empirical future-fit histogram. The bin-choice rule combines:

  - best-fit (smaller residual wins),
  - a strong bonus for exact fills,
  - a penalty for tiny unusable residuals,
  - an empirical bonus for residuals whose size matches frequently
    observed past item sizes (they are likely to be filled exactly),
  - a variance-adaptive bonus for residuals near the running mean,
    clamped to [mu - 1.2*sigma, mu + 1.2*sigma] with a [10, 90] guard,
  - a tiny tie-break favoring larger residuals.

State is kept in a module-level dict and updated once per call.
"""
import numpy as np

# Running statistics: count, sum, sum of squares, and a histogram of
# observed item sizes over buckets 1..100 (index 0 unused).
_state = {
    "n": 0.0,
    "sum": 0.0,
    "sum_sq": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
    "res_sum": 0.0,
    "res_n": 0.0,
    "min_item": 100.0,   # smallest item size observed so far
}

# Tunables for the adaptive band.
_SIGMA_K = 0.8          # half-width of the target band in sigmas (swept 1.2 -> 0.8)
_GUARD_LO = 10.0        # floor for the target band (early iterations)
_GUARD_HI = 90.0        # ceiling for the target band (early iterations)

# Tunables for the scoring components.
_PERFECT_BONUS = 100.0
_TINY_MAX = 4
_TINY_PEN = 0.9
_EMP_SCALE = 3.0
_NEAR_MEAN_SCALE = 1.5
_NEAR_MEAN_WIDTH = 15.0
_TIEBREAK_SCALE = 0.01
# Asymmetric penalty for residuals landing above the target band. Overshooting
# requires a larger-than-average future item to recover, so it is costlier
# than undershooting; a mild one-sided penalty targets this without
# disturbing the dominant best-fit ordering.
_OVERSHOOT_PEN = 0.02


def _update_state(item):
    """Update running statistics for the arriving item."""
    if 1 <= item <= 100:
        _state["hist"][item] += 1.0
        if float(item) < _state["min_item"]:
            _state["min_item"] = float(item)
    _state["n"] += 1.0
    _state["sum"] += item
    _state["sum_sq"] += float(item) * float(item)


def _target_band():
    """Return (target, width) for the near-mean bonus using a
    variance-adaptive band centered on a self-correcting target."""
    n = _state["n"]
    if n < 2.0:
        return 40.0, _NEAR_MEAN_WIDTH
    mu = _state["sum"] / n
    var = _state["sum_sq"] / n - mu * mu
    if var < 0.0:
        var = 0.0
    sigma = var ** 0.5
    lo = mu - _SIGMA_K * sigma
    hi = mu + _SIGMA_K * sigma
    # Guard floor/ceiling to avoid over-commitment early on.
    if lo < _GUARD_LO:
        lo = _GUARD_LO
    if hi > _GUARD_HI:
        hi = _GUARD_HI
    # Self-correcting target: blend the raw item mean with the running
    # mean of best-fit residuals actually created by the policy.
    res_n = _state["res_n"]
    if res_n > 0.0:
        res_mean = _state["res_sum"] / res_n
        target = 0.85 * mu + 0.15 * res_mean
    else:
        target = mu
    # Keep the target inside the guarded band.
    if target < lo:
        target = lo
    if target > hi:
        target = hi
    # Center the band on the target, but keep the width bounded.
    width = max(_NEAR_MEAN_WIDTH, 0.5 * (hi - lo))
    return target, width


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _update_state(item)
    n = _state["n"]
    inv_n = 1.0 / n

    r = bins - item                      # residual capacity after placing the item
    rf = r.astype(np.float64)

    # Track the best-fit residual (the residual best-fit will tend to pick),
    # so the target band can self-correct against the residual distribution
    # the policy actually creates.
    pos = r[r > 0]
    if pos.size > 0:
        _state["res_sum"] += float(pos.min())
        _state["res_n"] += 1.0
    else:
        # All fitting bins are exact fills; residual is 0.
        _state["res_sum"] += 0.0
        _state["res_n"] += 1.0

    # 1. Best-fit base: smaller residual is better.
    base = -rf

    # 2. Exact fills should always win.
    perfect = np.where(r == 0, _PERFECT_BONUS, 0.0)

    # 3. Graded dead-end penalty: the further a nonzero residual falls below
    #    the smallest observed item, the more unfillable it is. Strengthen it
    #    when the observed spread is narrow (dead ends are truly dead) and
    #    relax it when spread is wide (a future outlier may rescue them).
    min_item = _state["min_item"]
    if min_item < 1.0:
        min_item = 1.0
    # Running sigma (reuse the same statistics as _target_band).
    if n > 1.0:
        mu_s = _state["sum"] / n
        var_s = _state["sum_sq"] / n - mu_s * mu_s
        if var_s < 0.0:
            var_s = 0.0
        sigma_s = var_s ** 0.5
    else:
        sigma_s = 15.0
    dead_mask = (r > 0).astype(np.float64)
    grad = np.clip((min_item - rf) / max(1.0, min_item), 0.0, 1.0)
    spread_w = 1.0 - sigma_s / 40.0
    tiny = (-0.5 * grad - 0.1 * spread_w) * dead_mask

    # 4. Empirical future-fit bonus: reward residuals whose size has been
    #    frequently observed among past items.
    rb = np.clip(r, 0, 100).astype(np.int64)
    prob = _state["hist"][rb] * inv_n
    emp_bonus = _EMP_SCALE * prob

    # 5. Variance-adaptive near-mean bonus.
    target, width = _target_band()
    near_mean = _NEAR_MEAN_SCALE * np.exp(-((rf - target) / width) ** 2)

    # 5b. Asymmetric overshoot penalty: residuals above the upper edge of the
    #     target band are harder to recover (need a larger-than-average future
    #     item), so apply a mild one-sided penalty. Kept small so it only
    #     breaks near-ties.
    overshoot = -_OVERSHOOT_PEN * np.maximum(0.0, rf - (target + width))

    # 6. Tiny tie-break favoring larger residuals (less fragmentation).
    tiebreak = _TIEBREAK_SCALE * rf

    return base + perfect + tiny + emp_bonus + near_mean + overshoot + tiebreak
# EVOLVE-BLOCK-END