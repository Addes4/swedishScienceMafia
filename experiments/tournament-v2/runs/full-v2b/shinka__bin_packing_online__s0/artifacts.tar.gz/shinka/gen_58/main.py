# EVOLVE-BLOCK-START
"""Best-fit with subtle tie-breaking: prefer tight fits, avoid leaving
tiny unusable residuals, and mildly favor residuals near the typical item size."""
import numpy as np

# Online running mean and variance of observed item sizes, used to reward
# residuals that fall inside an empirical +/- 0.8 sigma band around the mean.
_state = {"n": 0.0, "sum": 0.0, "sumsq": 0.0, "res_sum": 0.0, "res_n": 0.0}

BAND_MULT = 0.8
BAND_LO_GUARD = 10.0
BAND_HI_GUARD = 90.0
BAND_BONUS = 1.5


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    # Update running statistics with the arriving item (O(1)).
    _state["n"] += 1.0
    _state["sum"] += float(item)
    _state["sumsq"] += float(item) * float(item)

    n = _state["n"]
    if n > 1.0:
        mu = _state["sum"] / n
        var = _state["sumsq"] / n - mu * mu
        if var < 0.0:
            var = 0.0
        sigma = float(np.sqrt(var))
    else:
        mu = 40.0
        sigma = 15.0

    # Light self-correcting blend: fold in the observed mean residual of the
    # chosen bin (proxy for actual slack left behind) at a small weight.
    res_n = _state["res_n"]
    if res_n > 0.0:
        res_mu = _state["res_sum"] / res_n
        mu_target = 0.90 * mu + 0.10 * res_mu
    else:
        mu_target = mu
    # Clamp the target mean to a sane range.
    if mu_target < 20.0:
        mu_target = 20.0
    elif mu_target > 60.0:
        mu_target = 60.0

    r = bins - item  # residual capacity after placing the item
    rf = r.astype(np.float64)

    # Base: best-fit (smaller residual is better). Dominates ordering.
    base = -rf

    # Small penalty for tiny nonzero residuals that are hard to reuse.
    TINY_MAX = 4
    TINY_PEN = 0.9
    tiny = np.where((r > 0) & (r <= TINY_MAX), -TINY_PEN, 0.0)

    # Small bonus for perfect fills (scaled small so it only breaks near-ties).
    perfect = np.where(r == 0, 1.5, 0.0)

    # Empirical variance-band bonus: residuals within +/- 0.8 sigma of the
    # running mean are most likely to be filled by a future typical item.
    lo = max(BAND_LO_GUARD, mu_target - BAND_MULT * sigma)
    hi = min(BAND_HI_GUARD, mu_target + BAND_MULT * sigma)
    in_band = np.where((rf >= lo) & (rf <= hi), BAND_BONUS, 0.0)

    # Tiny tiebreak: slightly prefer larger residuals to reduce fragmentation.
    tiebreak = -0.01 * rf

    scores = base + tiny + perfect + in_band + tiebreak

    # Record the residual of the bin the harness will pick (argmax, first on ties)
    # so we can track the observed mean residual for the next call.
    try:
        chosen = int(np.argmax(scores))
        _state["res_sum"] += float(r[chosen])
        _state["res_n"] += 1.0
    except Exception:
        pass

    return scores
# EVOLVE-BLOCK-END