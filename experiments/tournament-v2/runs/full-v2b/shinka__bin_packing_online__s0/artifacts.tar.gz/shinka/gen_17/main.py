# EVOLVE-BLOCK-START
"""Best-fit with subtle tie-breaking: prefer tight fits, avoid leaving
tiny unusable residuals, and mildly favor residuals near the typical item size."""
import numpy as np

# Lightweight running histogram of item sizes (10 coarse buckets over 1..100).
# Used to reward residuals whose size matches likely future items.
# Also keep a short buffer of recently produced residuals so we can lightly
# penalize concentrating many residuals at the same value (diversity term).
_state = {
    "hist": np.zeros(10, dtype=np.float64),
    "n": 0.0,
    "recents": [],
}

NBUCKETS = 10
BUCKET_W = 100.0 / NBUCKETS  # 10.0
HIST_BONUS = 0.6

# Residual-diversity parameters: penalize residuals that duplicate the recent
# running median, to spread residuals around the mean instead of clustering.
RECENTS_MAX = 64
DUP_PEN = 0.4
DUP_SPREAD = 6.0
=======
</DIFF>

<DIFF>
<<<<<<< SEARCH
    # Mild bonus for residuals near the typical item size (~40), which are
    # most likely to be useful for future items.
    PEAK = 40.0
    WIDTH = 18.0
    PEAK_BONUS = 1.2
    near_mean = PEAK_BONUS * np.exp(-((r - PEAK) / WIDTH) ** 2)

    # Adaptive future-fit bonus: reward residuals whose size falls in a bucket
    # that has been frequently observed among past items. Bounded small so it
    # only breaks near-ties in the best-fit ordering.
    rb = np.clip(((r - 1) // BUCKET_W).astype(np.int64), 0, NBUCKETS - 1)
    hist_bonus = HIST_BONUS * (hist[rb] * inv_n)

    return base + tiny + perfect + near_mean + hist_bonus
=======
    # Mild bonus for residuals near the typical item size (~40), which are
    # most likely to be useful for future items.
    PEAK = 40.0
    WIDTH = 18.0
    PEAK_BONUS = 1.0
    near_mean = PEAK_BONUS * np.exp(-((r - PEAK) / WIDTH) ** 2)

    # Adaptive future-fit bonus: reward residuals whose size falls in a bucket
    # that has been frequently observed among past items. Bounded small so it
    # only breaks near-ties in the best-fit ordering.
    rb = np.clip(((r - 1) // BUCKET_W).astype(np.int64), 0, NBUCKETS - 1)
    hist_bonus = HIST_BONUS * (hist[rb] * inv_n)

    # Residual-diversity penalty: discourage producing residuals that duplicate
    # the recent running median of residuals, so residual sizes spread out
    # around the mean rather than clustering at one value.
    recents = _state["recents"]
    if len(recents) >= 4:
        med = float(np.median(np.asarray(recents, dtype=np.float64)))
        dup_pen = -DUP_PEN * np.exp(-((r - med) / DUP_SPREAD) ** 2)
    else:
        dup_pen = 0.0

    scores = base + tiny + perfect + near_mean + hist_bonus + dup_pen

    # Replicate the harness's selection (highest score, first on ties) to
    # record the residual actually produced, so the diversity term tracks the
    # true recent-residual distribution.
    idx = int(np.argmax(scores))
    recents.append(int(r[idx]))
    if len(recents) > RECENTS_MAX:
        del recents[0]

    return scores


def _bucket(x):
    b = int((x - 1) // BUCKET_W)
    if b < 0:
        b = 0
    elif b > NBUCKETS - 1:
        b = NBUCKETS - 1
    return b


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    # Update running histogram with the arriving item (O(1)).
    hist = _state["hist"]
    hist[_bucket(item)] += 1.0
    _state["n"] += 1.0
    inv_n = 1.0 / _state["n"]

    r = bins - item  # residual capacity after placing the item

    # Base: best-fit (smaller residual is better). Dominates ordering.
    base = -r.astype(np.float64)

    # Small penalty for tiny nonzero residuals that are hard to reuse.
    TINY_MAX = 4
    TINY_PEN = 0.9
    tiny = np.where((r > 0) & (r <= TINY_MAX), -TINY_PEN, 0.0)

    # Small bonus for perfect fills (scaled small so it only breaks near-ties).
    perfect = np.where(r == 0, 1.5, 0.0)

    # Mild bonus for residuals near the typical item size (~40), which are
    # most likely to be useful for future items.
    PEAK = 40.0
    WIDTH = 18.0
    PEAK_BONUS = 1.2
    near_mean = PEAK_BONUS * np.exp(-((r - PEAK) / WIDTH) ** 2)

    # Adaptive future-fit bonus: reward residuals whose size falls in a bucket
    # that has been frequently observed among past items. Bounded small so it
    # only breaks near-ties in the best-fit ordering.
    rb = np.clip(((r - 1) // BUCKET_W).astype(np.int64), 0, NBUCKETS - 1)
    hist_bonus = HIST_BONUS * (hist[rb] * inv_n)

    return base + tiny + perfect + near_mean + hist_bonus
# EVOLVE-BLOCK-END