# EVOLVE-BLOCK-START
"""Best-fit with subtle tie-breaking: prefer tight fits, avoid leaving
tiny unusable residuals, and mildly favor residuals near the typical item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    r = bins - item  # residual capacity after placing the item

    # Base: best-fit (smaller residual is better). Dominates ordering.
    base = -r.astype(np.float64)

    # Small penalty for tiny nonzero residuals that are hard to reuse.
    TINY_MAX = 4
    TINY_PEN = 0.9
    tiny = np.where((r > 0) & (r <= TINY_MAX), -TINY_PEN, 0.0)

    # Small bonus for perfect fills (scaled small so it only breaks near-ties).
    perfect = np.where(r == 0, 1.5, 0.0)

    # Mild bonus for residuals near the typical item size (~40), which are
    # most likely to be useful for future items.
    PEAK = 40.0
    WIDTH = 18.0
    PEAK_BONUS = 1.2
    near_mean = PEAK_BONUS * np.exp(-((r - PEAK) / WIDTH) ** 2)

    return base + tiny + perfect + near_mean
# EVOLVE-BLOCK-END
