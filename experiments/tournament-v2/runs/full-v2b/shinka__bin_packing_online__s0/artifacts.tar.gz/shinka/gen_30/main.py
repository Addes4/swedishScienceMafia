# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    r = bins - item  # residual capacity after placing the item
    rf = r.astype(np.float64)
    base = -rf  # best-fit: smaller residual is better (integer gaps dominate)

    # Online running estimate of the mean item size (mu ~ 40 for this distribution).
    # Clamped EMA so early calls and rare large/small items don't destabilize it.
    global _mu
    try:
        _mu
    except NameError:
        _mu = 40.0
    _mu = 0.99 * _mu + 0.01 * float(item)
    _mu = min(60.0, max(20.0, _mu))
    mu = _mu

    # Strongly reward perfect fills (r == 0); r==0 is already best base so this
    # only reinforces it and cannot override a strictly better fit.
    perfect = np.where(r == 0, 5.0, 0.0)

    # Penalize tiny scraps (residual 1..3) that are nearly unusable for future
    # items; this breaks ties in favor of leaving reusable space.
    scrap = np.where((r >= 1) & (r <= 3), -0.5, 0.0)

    # Asymmetric residual-targeting: a bin is usually filled by several future
    # items, so a residual slightly BELOW mu is more useful than one at/above mu
    # (a residual below mu can still absorb a full typical item; one above mu
    # wastes capacity no single item can fully use). Reward residuals just under
    # mu and gently penalize those just above it.
    target = 0.9 * mu
    asym = -0.02 * np.abs(rf - target)
    asym += -0.02 * np.maximum(0.0, mu - rf)  # extra push toward slightly-under-mu

    # Tiny tiebreak: prefer larger residuals to consolidate small scraps.
    tiebreak = 0.001 * rf

    return base + perfect + scrap + asym + tiebreak
# EVOLVE-BLOCK-END