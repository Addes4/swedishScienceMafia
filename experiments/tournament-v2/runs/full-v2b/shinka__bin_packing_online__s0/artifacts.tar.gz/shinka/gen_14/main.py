# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    r = bins - item  # residual capacity after placing the item
    base = -r.astype(np.float64)  # best-fit: smaller residual is better
    # Reward residuals near the mean item size (~40) since items are Weibull-shaped.
    near_mean = np.exp(-((r - 40.0) / 15.0) ** 2)
    # Strongly reward perfect fills (r == 0).
    perfect = np.where(r == 0, 5.0, 0.0)
    # Tiny tiebreak: slightly prefer larger residuals to reduce fragmentation.
    tiebreak = 0.01 * r.astype(np.float64)
    return base + 2.0 * near_mean + perfect + tiebreak
# EVOLVE-BLOCK-END