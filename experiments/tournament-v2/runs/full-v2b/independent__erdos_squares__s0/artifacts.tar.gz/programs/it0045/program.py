import math
import random

try:
    import numpy as np
    HAS_NUMPY = True
except Exception:
    HAS_NUMPY = False


def _overlap_amount(a, b):
    """Return approximate positive overlap measure between two rotated squares."""
    ax, ay, aa, as_ = a
    bx, by, ba, bs = b
    if as_ <= 0 or bs <= 0:
        return 0.0

    # quick circle pre-check
    ra = 0.7071067811865476 * as_
    rb = 0.7071067811865476 * bs
    dx = ax - bx
    dy = ay - by
    d = math.hypot(dx, dy)
    if d >= ra + rb:
        return 0.0

    # use separating axis theorem for rotated squares
    ca = math.cos(aa * 2.0 * math.pi)
    sa = math.sin(aa * 2.0 * math.pi)
    cb = math.cos(ba * 2.0 * math.pi)
    sb = math.sin(ba * 2.0 * math.pi)

    axes = (
        (ca, sa), (-sa, ca),
        (cb, sb), (-sb, cb),
    )

    ha = as_ * 0.5
    hb = bs * 0.5

    for ux, uy in axes:
        # project center difference
        proj_d = dx * ux + dy * uy
        # projection radius of square a onto axis
        pa = ha * (abs(ca * ux + sa * uy) + abs(-sa * ux + ca * uy))
        pb = hb * (abs(cb * ux + sb * uy) + abs(-sb * ux + cb * uy))
        if proj_d > pa + pb:
            return 0.0
        if -proj_d > pa + pb:
            return 0.0

    # overlapping according to SAT; estimate depth roughly
    penetration = min(ra + rb - d, 0.5 * (as_ + bs))
    if penetration < 0:
        penetration = 0.0
    return penetration * penetration


def _boundary_penalty(x, y, ang, s):
    """Penalty when square crosses unit square boundary."""
    if s <= 0:
        return 0.0
    c = math.cos(ang * 2.0 * math.pi)
    sn = math.sin(ang * 2.0 * math.pi)
    h = s * 0.5
    ex = h * (abs(c) + abs(sn))
    ey = h * (abs(sn) + abs(c))
    pen = 0.0
    if x - ex < 0:
        pen += (ex - x) ** 2
    if x + ex > 1:
        pen += (x + ex - 1) ** 2
    if y - ey < 0:
        pen += (ey - y) ** 2
    if y + ey > 1:
        pen += (y + ey - 1) ** 2
    return pen


def _total_energy(squares, w_over=200.0, w_bound=200.0):
    e = 0.0
    m = len(squares)
    for i in range(m):
        x, y, a, s = squares[i]
        e += w_bound * _boundary_penalty(x, y, a, s)
    for i in range(m):
        for j in range(i + 1, m):
            ov = _overlap_amount(squares[i], squares[j])
            if ov:
                e += w_over * ov
    return e


def _score(squares):
    total = 0.0
    penalty = 0.0
    m = len(squares)
    for i in range(m):
        x, y, a, s = squares[i]
        total += s
        penalty += _boundary_penalty(x, y, a, s)
    for i in range(m):
        for j in range(i + 1, m):
            penalty += _overlap_amount(squares[i], squares[j])
    return total - 50.0 * penalty, penalty


def _initial_layout(n, rng):
    """Generate an initial set of squares, roughly grid-like with randomness."""
    if n == 0:
        return []
    k = max(1, int(math.ceil(math.sqrt(n))))
    s = 1.0 / k
    squares = []
    for idx in range(n):
        i = idx % k
        j = idx // k
        x = (i + 0.5) * s
        y = (j + 0.5) * s
        # shrink a little and jitter
        ss = s * rng.uniform(0.75, 0.98)
        x += rng.uniform(-0.04, 0.04) * s
        y += rng.uniform(-0.04, 0.04) * s
        a = rng.choice([0.0, 0.25, 0.5, 0.75])
        squares.append([x, y, a, ss])
    return squares


def _grow_optimize(squares, iterations=2500, seed=0):
    rng = random.Random(seed)
    m = len(squares)

    # start with current sizes
    cur = [list(s) for s in squares]

    best = [list(s) for s in cur]
    best_score, best_pen = _score(cur)

    step = 0.08
    for it in range(iterations):
        # try to inflate a random subset
        i = rng.randrange(m)
        old_s = cur[i][3]
        if old_s <= 0:
            ns = rng.uniform(0.0, 0.05)
        else:
            ns = old_s * (1.0 + rng.uniform(0.0, step))
            if ns > 0.4:
                ns = 0.4
        cur[i][3] = ns

        # also jitter position/angle sometimes
        if rng.random() < 0.25:
            cur[i][0] += rng.uniform(-step, step) * 0.5
            cur[i][1] += rng.uniform(-step, step) * 0.5
            if rng.random() < 0.3:
                cur[i][2] += rng.uniform(-0.05, 0.05)

        # clamp positions
        cur[i][0] = min(1.0, max(0.0, cur[i][0]))
        cur[i][1] = min(1.0, max(0.0, cur[i][1]))

        sc, pen = _score(cur)
        if sc > best_score:
            best_score = sc
            best_pen = pen
            best = [list(s) for s in cur]
        elif pen > best_pen * 1.5 + 1e-9:
            # revert if much worse in feasibility
            cur[i] = list(best[i])

        # anneal step
        if it % 200 == 199:
            step *= 0.88
            if step < 0.005:
                step = 0.005

    return best


def _local_refine(squares, tries=6000, seed=1):
    rng = random.Random(seed)
    cur = [list(s) for s in squares]
    m = len(cur)
    if m == 0:
        return cur
    best = [list(s) for s in cur]
    best_score, _ = _score(cur)

    scale = 0.02
    for t in range(tries):
        i = rng.randrange(m)
        old = list(cur[i])
        # perturb
        cur[i][0] += rng.gauss(0, scale)
        cur[i][1] += rng.gauss(0, scale)
        cur[i][2] += rng.gauss(0, scale * 0.5)
        cur[i][3] += rng.gauss(0, scale * 0.4)
        if cur[i][3] < 0:
            cur[i][3] = 0.0
        if cur[i][3] > 0.5:
            cur[i][3] = 0.5
        cur[i][0] = min(1.0, max(0.0, cur[i][0]))
        cur[i][1] = min(1.0, max(0.0, cur[i][1]))

        sc, pen = _score(cur)
        if sc > best_score:
            best_score = sc
            best = [list(s) for s in cur]
        else:
            cur[i] = old

        if t % 1000 == 999:
            scale *= 0.75
            if scale < 0.001:
                scale = 0.001

    return best


def _normalize(squares):
    """Ensure all outputs in [0,1] and zero out tiny overlaps by shrinking."""
    out = []
    for x, y, a, s in squares:
        x = min(1.0, max(0.0, float(x)))
        y = min(1.0, max(0.0, float(y)))
        a = float(a % 1.0)
        s = max(0.0, min(1.0, float(s)))
        out.append((x, y, a, s))
    return out


def _repair(squares):
    """Shrink squares to remove boundary violations and overlaps."""
    m = len(squares)
    sq = [list(s) for s in squares]
    for _ in range(200):
        changed = False
        for i in range(m):
            x, y, a, s = sq[i]
            if s <= 0:
                continue
            c = math.cos(a * 2.0 * math.pi)
            sn = math.sin(a * 2.0 * math.pi)
            h = s * 0.5
            ex = h * (abs(c) + abs(sn))
            ey = h * (abs(sn) + abs(c))
            max_ex = min(x, 1.0 - x)
            max_ey = min(y, 1.0 - y)
            # reduce size if needed
            if ex > max_ex + 1e-12 or ey > max_ey + 1e-12:
                fac_x = max_ex / ex if ex > 0 else 1.0
                fac_y = max_ey / ey if ey > 0 else 1.0
                fac = min(1.0, fac_x, fac_y)
                ns = s * fac * 0.999
                if ns < s * 0.999:
                    sq[i][3] = max(0.0, ns)
                    changed = True
        # overlap repair
        for i in range(m):
            if sq[i][3] <= 0:
                continue
            for j in range(i + 1, m):
                if sq[j][3] <= 0:
                    continue
                ov = _overlap_amount(tuple(sq[i]), tuple(sq[j]))
                if ov > 1e-12:
                    # shrink the larger one
                    si = sq[i][3]
                    sj = sq[j][3]
                    target = i if si >= sj else j
                    sq[target][3] *= 0.97
                    changed = True
        if not changed:
            break
    return sq


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # For moderate n use optimization; for very large n fall back to grid
    if n > 120:
        k = math.isqrt(n)
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        return squares[:n]

    best_sol = None
    best_val = -1e9

    # Try several random starts
    num_starts = 3 if n <= 20 else 2
    for seed in range(num_starts):
        rng = random.Random(seed * 1000 + n)
        init = _initial_layout(n, rng)
        # repair initial overlaps/boundary
        init = _repair(init)
        grown = _grow_optimize(init, iterations=1800 + n * 20, seed=seed + 7)
        refined = _local_refine(grown, tries=2500 + n * 40, seed=seed + 11)
        repaired = _repair(refined)
        val, pen = _score(repaired)
        if val > best_val:
            best_val = val
            best_sol = repaired

    # final cleanup and return
    sol = _normalize(best_sol if best_sol else _initial_layout(n, random.Random(0)))
    # remove tiny negative angles etc already handled
    return [(float(x), float(y), float(a), float(s)) for (x, y, a, s) in sol[:n]]
