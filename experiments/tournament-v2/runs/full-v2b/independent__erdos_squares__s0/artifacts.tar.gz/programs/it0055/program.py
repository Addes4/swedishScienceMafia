import math
import random

def solve(n):
    if n <= 0:
        return []

    # ---------- geometry helpers ----------
    def corners(cx, cy, ang, s):
        h = s * 0.5
        ca = math.cos(ang)
        sa = math.sin(ang)
        # local square corners at (+-h, +-h)
        pts = []
        for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
            x = cx + dx * ca - dy * sa
            y = cy + dx * sa + dy * ca
            pts.append((x, y))
        return pts

    def orient(ax, ay, bx, by, cx, cy):
        v = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)
        if v > 1e-15:
            return 1
        if v < -1e-15:
            return -1
        return 0

    def overlap(sq1, sq2):
        # sq = (cx, cy, ang, s)
        if sq1[3] <= 1e-12 or sq2[3] <= 1e-12:
            return False
        p1 = corners(*sq1)
        p2 = corners(*sq2)
        # SAT: check all axes from both polygons
        for poly in (p1, p2):
            for i in range(4):
                x1, y1 = poly[i]
                x2, y2 = poly[(i + 1) & 3]
                nx, ny = -(y2 - y1), (x2 - x1)
                # project p1
                d1 = [nx * (px - x1) + ny * (py - y1) for px, py in p1]
                d2 = [nx * (px - x1) + ny * (py - y1) for px, py in p2]
                if max(d1) <= 1e-12 or max(d2) <= 1e-12:
                    return False
                if min(d1) >= -1e-12 or min(d2) >= -1e-12:
                    return False
                if min(max(d1), max(d2)) - max(min(d1), min(d2)) <= 1e-12:
                    return False
        return True

    def inside_unit(sq):
        cx, cy, ang, s = sq
        if s <= 1e-12:
            return True
        for x, y in corners(cx, cy, ang, s):
            if x < -1e-12 or x > 1 + 1e-12 or y < -1e-12 or y > 1 + 1e-12:
                return False
        return True

    def total_len(sqs):
        return sum(q[3] for q in sqs)

    def feasible(sqs):
        for q in sqs:
            if not inside_unit(q):
                return False
        m = len(sqs)
        for i in range(m):
            if sqs[i][3] <= 1e-12:
                continue
            for j in range(i + 1, m):
                if sqs[j][3] <= 1e-12:
                    continue
                if overlap(sqs[i], sqs[j]):
                    return False
        return True

    # ---------- initial construction ----------
    def initial_grid(k):
        s = 1.0 / k
        return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(k) for j in range(k)]

    k = max(1, int(math.isqrt(n)))
    if k * k > n:
        k -= 1
        if k < 1:
            k = 1
    base = initial_grid(k)
    # Add remaining as tiny squares placed inside existing empty spots if possible,
    # otherwise as zero-size points at centers of the grid.
    rem = n - k * k
    extra = []
    if rem > 0:
        # put at centers of cells, making them small squares that do not overlap
        # With side s from the grid cell of kxk, we can fit many tiny squares in the
        # gaps if we make them small enough. Use tiny epsilon squares at cell centers
        # of an offset subgrid to avoid overlap.
        eps = min(1e-6, 1.0 / (10.0 * n))
        # place them in the "holes" around grid centers, but simplest: point squares
        for i in range(rem):
            extra.append((0.5, 0.5, 0.0, 0.0))
    squares = base + extra
    if not feasible(squares):
        # fallback: k x k grid plus zeros
        squares = initial_grid(k) + [(0.5, 0.5, 0.0, 0.0)] * (n - k * k)
        squares = squares[:n]

    # ---------- optimization ----------
    # We'll perturb squares and accept improvements. Use random restarts and
    # simulated annealing-like moves.
    best = [list(q) for q in squares]
    best_val = total_len(best)

    rng = random.Random(12345)

    def make_move(sqs, rng, step_scale):
        m = len(sqs)
        # choose a square with nonzero side to alter
        nz = [i for i in range(m) if sqs[i][3] > 1e-12]
        if not nz:
            return False
        i = rng.choice(nz)
        cx, cy, ang, s = sqs[i]
        # try one of several mutations
        typ = rng.random()
        if typ < 0.4:
            # move center
            dx = (rng.random() - 0.5) * step_scale
            dy = (rng.random() - 0.5) * step_scale
            nc = (cx + dx, cy + dy)
            if 0 <= nc[0] <= 1 and 0 <= nc[1] <= 1:
                old = sqs[i]
                sqs[i] = (nc[0], nc[1], ang, s)
                if feasible(sqs):
                    return True
                sqs[i] = old
                return False
        elif typ < 0.7:
            # rotate slightly
            da = (rng.random() - 0.5) * step_scale
            old = sqs[i]
            sqs[i] = (cx, cy, ang + da, s)
            if feasible(sqs):
                return True
            sqs[i] = old
            return False
        else:
            # grow slightly
            ds = (rng.random() * 0.5 + 0.1) * step_scale
            old = sqs[i]
            sqs[i] = (cx, cy, ang, s + ds)
            if feasible(sqs):
                return True
            sqs[i] = old
            return False

    # Simple hill climbing with decreasing steps
    current = [list(q) for q in best]
    cur_val = best_val
    # Try to improve by repeated local search
    time_budget_iters = 2000
    step = 0.02
    for it in range(time_budget_iters):
        step = max(1e-5, 0.05 * (1.0 - it / time_budget_iters) ** 1.5)
        # make multiple attempts
        improved = False
        for _ in range(50):
            trial = [list(q) for q in current]
            if make_move(trial, rng, step):
                tv = total_len(trial)
                if tv > cur_val + 1e-12:
                    current = trial
                    cur_val = tv
                    improved = True
                    break
        if cur_val > best_val:
            best = [list(q) for q in current]
            best_val = cur_val
        if not improved and step < 1e-4:
            # small random restart around best
            current = [list(q) for q in best]
            cur_val = best_val

    # ---------- final polish ----------
    # Try to grow each square one by one in place
    for _ in range(5):
        for i in range(len(best)):
            if best[i][3] <= 1e-12:
                continue
            cx, cy, ang, s = best[i]
            lo, hi = s, min(1.0, s + 0.2)
            for _ in range(30):
                mid = (lo + hi) * 0.5
                trial = [list(q) for q in best]
                trial[i] = [cx, cy, ang, mid]
                if feasible(trial):
                    lo = mid
                else:
                    hi = mid
            best[i][3] = lo
        if not feasible(best):
            # if somehow infeasible, revert conservatively
            pass

    # If no feasible solution found, fall back to grid
    if not feasible(best):
        squares = initial_grid(k) + [(0.5, 0.5, 0.0, 0.0)] * (n - k * k)
        squares = squares[:n]
    else:
        squares = [(q[0], q[1], q[2], q[3]) for q in best]

    # ensure n items
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    # clamp into [0,1]
    out = []
    for cx, cy, ang, s in squares:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        s = max(0.0, min(1.0, s))
        out.append((cx, cy, ang, s))
    return out
