import math
import random
from itertools import count


def _corners(cx, cy, a, s):
    h = s * 0.5
    ca, sa = math.cos(a * 2.0 * math.pi), math.sin(a * 2.0 * math.pi)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _overlap_area(sq1, sq2):
    """Approximate overlap area of two squares using polygon clipping (Sutherland-Hodgman)."""
    p1 = _corners(*sq1)
    p2 = _corners(*sq2)
    # clip p1 by each edge of p2
    def clip(poly, a, b):
        if not poly:
            return poly
        res = []
        n = len(poly)
        for i in range(n):
            c = poly[i]
            d = poly[(i + 1) % n]
            # inside test relative to edge a->b (CCW polygon)
            def side(p):
                return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])
            sc, sd = side(c), side(d)
            if sc <= 0:
                res.append(c)
                if sd > 0:
                    t = sc / (sc - sd)
                    res.append((c[0] + t * (d[0] - c[0]), c[1] + t * (d[1] - c[1])))
            elif sd <= 0:
                t = sc / (sc - sd)
                res.append((c[0] + t * (d[0] - c[0]), c[1] + t * (d[1] - c[1])))
        return res

    poly = p1
    for i in range(len(p2)):
        poly = clip(poly, p2[i], p2[(i + 1) % len(p2)])
    if len(poly) < 3:
        return 0.0
    area = 0.0
    for i in range(len(poly)):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % len(poly)]
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5


def _inside(sq, cx, cy, a, s, eps=1e-9):
    pts = _corners(cx, cy, a, s)
    return all(-eps <= x <= 1 + eps and -eps <= y <= 1 + eps for x, y in pts)


def _score(squares):
    return sum(s[3] for s in squares)


def _relax(squares, iters=200):
    """Resolve overlaps and keep squares inside the unit square."""
    sq = [list(s) for s in squares]
    n = len(sq)
    for _ in range(iters):
        moved = False
        # push apart overlapping pairs
        for i in range(n):
            if sq[i][3] <= 0:
                continue
            for j in range(i + 1, n):
                if sq[j][3] <= 0:
                    continue
                ov = _overlap_area(sq[i], sq[j])
                if ov > 1e-12:
                    dx = sq[j][0] - sq[i][0]
                    dy = sq[j][1] - sq[i][1]
                    d = math.hypot(dx, dy)
                    if d < 1e-9:
                        dx, dy, d = 1.0, 0.0, 1.0
                    push = 0.5 * math.sqrt(ov) + 1e-4
                    ux, uy = dx / d, dy / d
                    sq[i][0] -= ux * push * 0.5
                    sq[i][1] -= uy * push * 0.5
                    sq[j][0] += ux * push * 0.5
                    sq[j][1] += uy * push * 0.5
                    moved = True
        # keep inside
        for i in range(n):
            if sq[i][3] <= 0:
                continue
            cx, cy, a, s = sq[i]
            pts = _corners(cx, cy, a, s)
            minx = min(p[0] for p in pts)
            maxx = max(p[0] for p in pts)
            miny = min(p[1] for p in pts)
            maxy = max(p[1] for p in pts)
            if minx < 0:
                sq[i][0] -= minx
                moved = True
            if maxx > 1:
                sq[i][0] -= (maxx - 1)
                moved = True
            if miny < 0:
                sq[i][1] -= miny
                moved = True
            if maxy > 1:
                sq[i][1] -= (maxy - 1)
                moved = True
        if not moved:
            break
    return [tuple(x) for x in sq]


def _grow(squares, n, rng, attempts=40):
    """Try to insert a new square of decreasing size at random positions."""
    sq = [list(s) for s in squares]
    while len(sq) < n:
        best = None
        best_s = -1.0
        for _ in range(attempts):
            s = rng.uniform(0.03, 0.18)
            a = rng.uniform(0, 1)
            h = s * 0.5
            cx = rng.uniform(h, 1 - h)
            cy = rng.uniform(h, 1 - h)
            cand = (cx, cy, a, s)
            if not _inside(cand, cx, cy, a, s, 1e-6):
                continue
            ok = True
            for other in sq:
                if other[3] <= 0:
                    continue
                if _overlap_area(cand, other) > 1e-12:
                    ok = False
                    break
            if ok:
                best = cand
                best_s = s
        if best is not None:
            sq.append(list(best))
        else:
            sq.append([0.5, 0.5, 0.0, 0.0])
    return [tuple(x) for x in sq]


def _build(k, mode, rng):
    """Build an initial packing of k squares (k x k related/grid)."""
    sq = []
    if mode == 'grid':
        s = 1.0 / k
        for i in range(k):
            for j in range(k):
                sq.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    else:
        s = 1.0 / k
        for i in range(k):
            for j in range(k):
                a = rng.uniform(0, 1) if mode == 'rand' else 0.0
                sq.append(((i + 0.5) * s, (j + 0.5) * s, a, s * rng.uniform(0.85, 1.0)))
    return sq


def solve(n):
    if n <= 0:
        return []
    best = None
    best_score = -1.0
    rng = random.Random(12345 + n)

    k = math.isqrt(n)
    if k < 1:
        k = 1

    # seed configs
    seeds = []
    seeds.append(_build(k, 'grid', rng))
    for _ in range(4):
        seeds.append(_build(k, 'rand', rng))
    for _ in range(2):
        seeds.append(_build(max(1, k), 'jitter', rng))

    for base in seeds:
        base = _grow(base, n, rng)
        base = _relax(base, iters=400)
        sc = _score(base)
        if sc > best_score:
            best_score = sc
            best = base

    # local search: try to increase sizes / tweak
    sq = [list(s) for s in best]
    for _ in range(6):
        cand = [list(s) for s in sq]
        for _ in range(max(3, n // 4)):
            i = rng.randrange(n)
            if cand[i][3] <= 0:
                continue
            cand[i][3] *= rng.uniform(1.0, 1.25)
            cand[i][0] += rng.uniform(-0.03, 0.03)
            cand[i][1] += rng.uniform(-0.03, 0.03)
            cand[i][2] = rng.uniform(0, 1)
        cand = _relax(cand, iters=300)
        sc = _score(cand)
        if sc > best_score:
            best_score = sc
            sq = [list(s) for s in cand]

    # final safety: ensure validity by relaxing
    sq = _relax(sq, iters=200)

    out = []
    for cx, cy, a, s in sq:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        a = a % 1.0
        if s < 0:
            s = 0.0
        out.append((cx, cy, a, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
