import math
import random
import numpy as np
from scipy.optimize import minimize

def _corners(cx, cy, angle, side):
    a = angle * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side * 0.5
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + ca * x - sa * y, cy + sa * x + ca * y) for x, y in pts]

def _overlap(c1, c2):
    # SAT for convex polygons
    for poly in (c1, c2):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            nx, ny = -ey, ex
            p1 = [nx * x + ny * y for x, y in c1]
            p2 = [nx * x + ny * y for x, y in c2]
            if max(p1) <= min(p2) + 1e-12 or max(p2) <= min(p1) + 1e-12:
                return False
    return True

def _penalty(squares):
    # squares: list of (cx, cy, angle, side)
    total = 0.0
    s = 0.0
    polys = []
    for cx, cy, angle, side in squares:
        s += side
        if side <= 0:
            polys.append(None)
            continue
        polys.append(_corners(cx, cy, angle, side))
    pen = 0.0
    m = len(squares)
    for i in range(m):
        if polys[i] is None:
            continue
        # boundary check (approximate by corners)
        for x, y in polys[i]:
            if x < -0.5: pen += (x + 0.5) ** 2 * 100
            if x > 0.5: pen += (x - 0.5) ** 2 * 100
            if y < -0.5: pen += (y + 0.5) ** 2 * 100
            if y > 0.5: pen += (y - 0.5) ** 2 * 100
        for j in range(i + 1, m):
            if polys[j] is None:
                continue
            if _overlap(polys[i], polys[j]):
                # estimate penetration: distance between centers vs sum of half diagonals
                dx = squares[i][0] - squares[j][0]
                dy = squares[i][1] - squares[j][1]
                dist = math.hypot(dx, dy)
                rs = (squares[i][3] + squares[j][3]) * 0.5 * math.sqrt(2)
                pen += (rs - dist) ** 2 * 100 + 1.0
    return s - pen, s, pen

def _feasible(squares):
    polys = []
    for cx, cy, angle, side in squares:
        if side <= 0:
            polys.append(None)
            continue
        p = _corners(cx, cy, angle, side)
        for x, y in p:
            if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
                return False
        polys.append(p)
    m = len(squares)
    for i in range(m):
        if polys[i] is None:
            continue
        for j in range(i + 1, m):
            if polys[j] is None:
                continue
            if _overlap(polys[i], polys[j]):
                return False
    return True

def _grid_initial(n):
    k = math.isqrt(n)
    if k < 1:
        k = 1
    side = 1.0 / k
    sq = []
    for i in range(k):
        for j in range(k):
            sq.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    return sq[:n]

def _random_initial(n, rng, k):
    side = 1.0 / max(1, k)
    sq = []
    for i in range(k):
        for j in range(k):
            sq.append(((i + 0.5) * side + rng.uniform(-0.02, 0.02),
                       (j + 0.5) * side + rng.uniform(-0.02, 0.02),
                       0.0, side * rng.uniform(0.9, 1.0)))
    # fill remaining with tiny squares near center
    while len(sq) < n:
        sq.append((rng.uniform(0.4, 0.6), rng.uniform(0.4, 0.6), rng.uniform(0, 1), 0.0))
    return sq[:n]

def _local_optimize(squares, maxiter=200):
    n = len(squares)
    x0 = np.array([v for s in squares for v in s])
    bounds = [(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)] * n

    def obj(x):
        sq = [(x[4*i], x[4*i+1], x[4*i+2], x[4*i+3]) for i in range(n)]
        val, _, _ = _penalty(sq)
        return -val

    try:
        res = minimize(obj, x0, method='L-BFGS-B', bounds=bounds,
                       options={'maxiter': maxiter, 'ftol': 1e-9})
        x = res.x
        sq = [(x[4*i], x[4*i+1], x[4*i+2], x[4*i+3]) for i in range(n)]
        return sq
    except Exception:
        return squares

def solve(n):
    if n <= 0:
        return []
    rng = random.Random(12345 + n)
    best = None
    best_score = -1e18

    # try several initial configurations
    inits = []
    inits.append(_grid_initial(n))
    k0 = math.isqrt(n)
    for k in range(max(1, k0 - 1), k0 + 2):
        if k < 1:
            continue
        inits.append(_random_initial(n, rng, k))

    for init in inits:
        cur = [list(s) for s in init]
        # iterative refinement: optimize a few times
        for _ in range(3):
            cur = _local_optimize([tuple(s) for s in cur], maxiter=150)
        score, s, pen = _penalty(cur)
        if score > best_score:
            best_score = score
            best = cur

    # cleanup: clip and ensure feasibility as much as possible
    if best is None:
        best = [tuple(s) for s in _grid_initial(n)]

    # clip to bounds and zero tiny negative sizes
    out = []
    for cx, cy, ang, side in best:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = min(max(ang, 0.0), 1.0)
        side = max(side, 0.0)
        out.append((cx, cy, ang, side))

    # small greedy repair: if infeasible, try to shrink overlapping squares a bit
    for _ in range(5):
        if _feasible(out):
            break
        out2 = []
        for i, (cx, cy, ang, side) in enumerate(out):
            if side > 0:
                # shrink slightly to try reducing overlap
                side *= 0.98
            out2.append((cx, cy, ang, side))
        out = out2

    # if still massively infeasible, fall back to grid with possible zero squares
    if not _feasible(out):
        k = math.isqrt(n)
        if k < 1:
            k = 1
        side = 1.0 / k
        g = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
        g += [(0.5, 0.5, 0.0, 0.0)] * (n - len(g))
        out = g[:n]

    return out
