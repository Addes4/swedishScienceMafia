import math
import random

SQRT2 = math.sqrt(2.0)


def _overlap(a, b):
    """Check if two squares overlap in interior using separating axis theorem."""
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0.0 or bsz <= 0.0:
        return False
    ha = asz * 0.5
    hb = bsz * 0.5
    # Local axes of a
    ca = math.cos(2.0 * math.pi * aa)
    sa = math.sin(2.0 * math.pi * aa)
    # axes of a: (ca, sa) and (-sa, ca)
    axes = [(ca, sa), (-sa, ca)]
    cb = math.cos(2.0 * math.pi * ba)
    sb = math.sin(2.0 * math.pi * ba)
    # axes of b
    axes.append((cb, sb))
    axes.append((-sb, cb))
    # distance
    dx = bx - ax
    dy = by - ay
    for ux, uy in axes:
        # projection radius of a
        ra = ha * (abs(ux * ca + uy * sa) + abs(-ux * sa + uy * ca))
        rb = hb * (abs(ux * cb + uy * sb) + abs(-ux * sb + uy * cb))
        d = abs(dx * ux + dy * uy)
        if d >= ra + rb - 1e-12:
            return False
    return True


def _inside(center_x, center_y, angle, size):
    """Check square inside [0,1]^2."""
    if size <= 0.0:
        return 0.0 <= center_x <= 1.0 and 0.0 <= center_y <= 1.0
    h = size * 0.5
    ca = math.cos(2.0 * math.pi * angle)
    sa = math.sin(2.0 * math.pi * angle)
    # half-extent in x and y
    ex = h * (abs(ca) + abs(sa))
    ey = h * (abs(sa) + abs(ca))
    return (center_x - ex >= -1e-12 and center_x + ex <= 1.0 + 1e-12 and
            center_y - ey >= -1e-12 and center_y + ey <= 1.0 + 1e-12)


def _valid(squares):
    """Check containment and non-overlap for all squares."""
    n = len(squares)
    for i in range(n):
        if not _inside(*squares[i]):
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _sum_sides(squares):
    return sum(s[3] for s in squares)


def _best_grid(n):
    """Best k x k grid plus some extra squares in gaps, or single large when n small."""
    # Try grids k x k with k^2 <= n
    best = None
    best_val = -1.0

    for k in range(1, n + 1):
        if k * k > n:
            break
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
        val = k * side
        if val > best_val:
            best_val = val
            best = squares[:]

    # config 1: k x (k+1) grid with smaller sides depending on n blocks
    # Instead, try filling row by row with squares of size based on count in row
    # Try: choose a rows, each row has c squares of equal size 1/max width
    for rows in range(1, n + 1):
        for cols in range(1, n + 1):
            if rows * cols > n:
                continue
            side = min(1.0 / rows, 1.0 / cols)
            squares = []
            for r in range(rows):
                for c in range(cols):
                    squares.append(((c + 0.5) / cols, (r + 0.5) / rows, 0.0, side))
            val = rows * cols * side
            if val > best_val:
                best_val = val
                best = squares[:]

    # For n not a perfect square, use k x k grid plus smaller squares in leftover
    # Try k = isqrt(n), add extra squares in remaining space as size 0 initially
    # Better: use smaller squares in a "bonus strip"
    k = math.isqrt(n)
    if k * k <= n and n > k * k:
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
        extra = n - k * k
        # put extra as zero size
        val = k * side
        if val > best_val:
            best_val = val
            best = squares[:]

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n

    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]


def _shrink_to_fit(squares):
    """Shrink squares if invalid."""
    n = len(squares)
    sq = list(squares)
    for _ in range(200):
        if _valid(sq):
            return sq
        # shrink all by tiny factor
        for i in range(n):
            x, y, a, s = sq[i]
            sq[i] = (x, y, a, s * 0.999)
    return sq


def _optimize(n, squares, time_budget=8.0, seed=0):
    """Local search: perturb and keep if better."""
    rnd = random.Random(seed)
    cur = list(squares)
    for _ in range(500):
        if _valid(cur):
            break
        for i in range(n):
            x, y, a, s = cur[i]
            cur[i] = (min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), a, s * 0.99)

    best = list(cur)
    best_val = _sum_sides(best)
    cur_val = best_val

    import time
    t0 = time.time()
    it = 0
    temp_like = 0.1

    while time.time() - t0 < time_budget:
        it += 1
        cand = [list(s) for s in best]

        # Pick random square(s) to perturb
        k = rnd.randint(1, max(1, n // 2))
        for _ in range(k):
            idx = rnd.randrange(n)
            x, y, a, s = cand[idx]
            # perturb
            mode = rnd.random()
            if mode < 0.35:
                # grow size
                ds = rnd.uniform(-0.1, 0.15) * max(0.001, s)
                s = s + ds
                if s < 0:
                    s = 0.0
            elif mode < 0.6:
                # move
                dx = rnd.uniform(-0.05, 0.05)
                dy = rnd.uniform(-0.05, 0.05)
                x = min(1.0, max(0.0, x + dx))
                y = min(1.0, max(0.0, y + dy))
            elif mode < 0.8:
                # rotate
                a = a + rnd.uniform(-0.1, 0.1)
                a = a % 1.0
            else:
                # random reinit of size and pos
                s = rnd.uniform(0, 0.3)
                x = rnd.uniform(s * 0.5, 1.0 - s * 0.5)
                y = rnd.uniform(s * 0.5, 1.0 - s * 0.5)
                a = rnd.uniform(0, 1.0)
            cand[idx] = [x, y, a, s]

        cand = [tuple(c) for c in cand]

        # fix validity by shrinking
        if not _valid(cand):
            # shrink invalid ones
            for _ in range(200):
                if _valid(cand):
                    break
                for i in range(n):
                    x, y, a, s = cand[i]
                    cand[i] = (x, y, a, s * 0.995)
            if not _valid(cand):
                continue

        new_val = _sum_sides(cand)
        if new_val > cur_val or rnd.random() < 0.02:
            cur = cand
            cur_val = new_val
            if new_val > best_val:
                best = list(cand)
                best_val = new_val
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Build initial guess
    best_sq = _best_grid(n)
    best_sq = _shrink_to_fit(best_sq)
    best_val = _sum_sides(best_sq)

    # Try a few starting points and optimize
    import time
    t_start = time.time()
    total_budget = 50.0

    # Multiple multistart with different seeds
    num_starts = max(1, min(6, n))
    for trial in range(num_starts):
        if time.time() - t_start > total_budget:
            break

        if trial == 0:
            start = list(best_sq)
        elif trial == 1:
            # uniform random valid
            start = []
            for i in range(n):
                s = min(0.5, 0.7 / math.sqrt(n))
                x = random.uniform(s * 0.5, 1.0 - s * 0.5)
                y = random.uniform(s * 0.5, 1.0 - s * 0.5)
                start.append((x, y, 0.0, s))
        else:
            start = []
            for i in range(n):
                s = random.uniform(0.0, 1.0 / math.sqrt(n) * 1.5)
                x = random.uniform(0.0, 1.0)
                y = random.uniform(0.0, 1.0)
                start.append((x, y, random.uniform(0, 1), s))
            start = _shrink_to_fit(start)
            # if invalid shrink more
            while not _valid(start):
                start = [(x, y, a, s * 0.98) for (x, y, a, s) in start]

        rem = total_budget - (time.time() - t_start)
        if rem <= 0.5:
            rem = 0.5
        local_budget = min(9.0, rem / max(1, (num_starts - trial)))
        res = _optimize(n, start, time_budget=local_budget, seed=trial * 17 + 3)
        val = _sum_sides(res)
        if val > best_val:
            best_val = val
            best_sq = res

    # Final polish
    rem = total_budget - (time.time() - t_start)
    if rem > 1.0:
        res = _optimize(n, best_sq, time_budget=min(rem, 10.0), seed=999)
        if _sum_sides(res) > best_val:
            best_sq = res

    # Ensure valid and correct count
    result = list(best_sq)
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    result = result[:n]

    if not _valid(result):
        # fallback to safe grid
        k = math.isqrt(n)
        side = 1.0 / k
        result = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                  for i in range(k) for j in range(k)]
        while len(result) < n:
            result.append((0.5, 0.5, 0.0, 0.0))
        result = result[:n]

    return result
