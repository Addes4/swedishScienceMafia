import math
import random
import numpy as np
from scipy.optimize import minimize


def _inside_and_overlap_penalty(x, n):
    # x: flattened [cx, cy, ang, s] * n
    P = x.reshape(n, 4)
    cx = P[:, 0]
    cy = P[:, 1]
    ang = P[:, 2]
    s = P[:, 3]
    s = np.maximum(s, 0.0)

    # containment penalty (allow touching)
    half = s * 0.5
    pen = 0.0

    # half extent of rotated square axis-aligned bounding box:
    # for angle t, half-diagonal extents =
    #  (s/2)*(|cos t|+|sin t|) in each axis if using axis-aligned bbox corners
    # but containment of rotated square in box requires max |x| along edges.
    # For a square centered at (cx,cy) with side s and angle t:
    # corners offsets:
    c = np.cos(2*np.pi*ang)
    si = np.sin(2*np.pi*ang)
    hx = 0.5*s*(np.abs(c) + np.abs(si))
    hy = 0.5*s*(np.abs(c) + np.abs(si))
    # Actually both axes have same max extent for square: (s/2)*(|cos|+|sin|)
    ext = 0.5*s*(np.abs(c) + np.abs(si))
    d = np.maximum(0.0, (cx - ext) * -1) + np.maximum(0.0, (cx + ext - 1.0))
    pen += np.sum(d)
    d = np.maximum(0.0, (cy - ext) * -1) + np.maximum(0.0, (cy + ext - 1.0))
    pen += np.sum(d)

    # pairwise separation penalty
    # use SAT for two rotated squares: project corners on 4 axes
    # vectorized over pairs (fine for n up to maybe 50)
    if n > 1:
        # precompute corners for each square
        # corner offsets local
        base = np.array([[-0.5, -0.5], [0.5, -0.5], [0.5, 0.5], [-0.5, 0.5]])  # 4x2
        corners = np.zeros((n, 4, 2))
        for i in range(n):
            t = 2*np.pi*ang[i]
            ct = math.cos(t)
            st = math.sin(t)
            R = np.array([[ct, -st], [st, ct]])
            corners[i] = (base * s[i]) @ R.T + np.array([cx[i], cy[i]])

        # for each pair compute overlap
        # SAT axes: normals of edges of both squares: 4 axes * 2 = up to 8
        # overlap amount = min overlap on all axes, if >0 then interpenetration
        # we only need penalty positive when overlap
        for i in range(n):
            for j in range(i+1, n):
                if s[i] < 1e-12 or s[j] < 1e-12:
                    continue
                ci = corners[i]
                cj = corners[j]
                # axes
                axes = []
                for poly, ss in ((ci, s[i]), (cj, s[j])):
                    # edge vectors
                    for k in range(4):
                        e = poly[(k+1)%4] - poly[k]
                        nrm = np.array([-e[1], e[0]])
                        ln = np.linalg.norm(nrm)
                        if ln > 1e-15:
                            axes.append(nrm/ln)
                # project
                # if any axis separates, no overlap
                overlap = True
                minov = 1e9
                for ax in axes:
                    pi = ci @ ax
                    pj = cj @ ax
                    if pi.max() <= pj.min() or pj.max() <= pi.min():
                        overlap = False
                        break
                    ov = min(pi.max() - pj.min(), pj.max() - pi.min())
                    if ov < minov:
                        minov = ov
                if overlap and minov > 0:
                    pen += minov * minov * 100.0
    return pen


def _objective_and_penalty(x, n, w):
    P = x.reshape(n, 4)
    s = np.maximum(P[:, 3], 0.0)
    total = -np.sum(s)  # minimize negative
    pen = _inside_and_overlap_penalty(x, n)
    return total + w * pen


def _pack_guillotine(n, depth=0):
    """Recursive guillotine split packing."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # choose split roughly balanced
    a = n // 2
    b = n - a
    # recurse returns squares in unit square
    A = _pack_guillotine(a, depth+1)
    B = _pack_guillotine(b, depth+1)
    # split horizontally: A in left half width wA proportional to sqrt(a), etc.
    wa = math.sqrt(a) / (math.sqrt(a) + math.sqrt(b))
    out = []
    for (cx, cy, ang, s) in A:
        out.append((cx * wa, cy, ang, s * wa))
    for (cx, cy, ang, s) in B:
        out.append((wa + cx * (1.0 - wa), cy, ang, s * (1.0 - wa)))
    return out


def _grid_pack(n):
    k = math.isqrt(n)
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
    rest = n - k*k
    # remaining: try slightly reducing a few to fit more as smaller squares
    # simple: replace some with smaller aligned in a row
    if rest > 0:
        # reduce size of all slightly to make room: try k rows and one extra row?
        # fallback: just zeros
        squares += [(0.5, 0.5, 0.0, 0.0)] * rest
    return squares[:n]


def _initial_candidates(n, rng):
    cands = []
    cands.append(_grid_pack(n))
    cands.append(_pack_guillotine(n))
    # random perturbations of guillotine
    for _ in range(3):
        base = _pack_guillotine(n)
        out = []
        for (cx, cy, ang, s) in base:
            out.append((min(max(cx + rng.uniform(-0.02, 0.02), 0), 1),
                        min(max(cy + rng.uniform(-0.02, 0.02), 0), 1),
                        ang + rng.uniform(-0.05, 0.05),
                        max(0.0, s + rng.uniform(-0.02, 0.02))))
        cands.append(out)
    return cands


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    rng = random.Random(12345)
    best = None
    best_score = -1e9

    cands = _initial_candidates(n, rng)
    # also try starts from scaled grid
    if n <= 25:
        k = math.isqrt(n)
        if k*k == n:
            side = 1.0/k
            cands = [[((i+0.5)*side, (j+0.5)*side, 0.0, side) for i in range(k) for j in range(k)]]

    # time budget heuristics
    max_iter = 200 if n <= 16 else (120 if n <= 36 else 60)

    for ci, init in enumerate(cands):
        if len(init) < n:
            init = init + [(0.5, 0.5, 0.0, 0.0)] * (n - len(init))
        x0 = np.array(init, dtype=float).flatten()
        # clamp
        x0[0::4] = np.clip(x0[0::4], 0, 1)
        x0[1::4] = np.clip(x0[1::4], 0, 1)
        x0[3::4] = np.clip(x0[3::4], 0, 1)
        # penalty weights
        w = 1.0
        x = x0.copy()
        for _ in range(3):
            res = minimize(_objective_and_penalty, x, args=(n, w),
                           method='Nelder-Mead' if n <= 8 else 'SLSQP',
                           options={'maxiter': max_iter, 'ftol': 1e-10})
            x = res.x
            w *= 10.0
        # final check
        pen = _inside_and_overlap_penalty(x, n)
        P = x.reshape(n, 4)
        s = np.maximum(P[:, 3], 0.0)
        # if penalty tiny, accept
        if pen < 1e-3:
            sc = np.sum(s)
            if sc > best_score:
                best_score = sc
                best = [(float(P[i,0]), float(P[i,1]), float(P[i,2] % 1.0), float(max(P[i,3], 0.0))) for i in range(n)]
        else:
            # try to repair by shrinking all squares until feasible
            shrink = 0.5
            for _ in range(20):
                Q = P.copy()
                Q[:, 3] = np.maximum(Q[:, 3] * shrink, 0.0)
                qx = Q.flatten()
                pen2 = _inside_and_overlap_penalty(qx, n)
                if pen2 < 1e-3:
                    sc = np.sum(Q[:,3])
                    if sc > best_score:
                        best_score = sc
                        best = [(float(Q[i,0]), float(Q[i,1]), float(Q[i,2] % 1.0), float(max(Q[i,3], 0.0))) for i in range(n)]
                    break
                shrink *= 0.95

    if best is None:
        # fallback grid
        best = _grid_pack(n)

    # ensure exactly n and values in bounds
    out = []
    for (cx, cy, ang, s) in best[:n]:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 1.0
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, ang, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
