import math

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Candidate layouts are guillotine partitions of the unit square into rectangles.
    # For each partition, fill rectangles greedily with axis-aligned squares.
    # Explore a family of partitions: recursive bisection with varying cut ratios.

    best = None
    best_score = -1.0

    def eval_layout(rects):
        # rects: list of (x0, y0, x1, y1)
        squares = []
        for (x0, y0, x1, y1) in rects:
            w = x1 - x0
            h = y1 - y0
            s = min(w, h)
            if s > 1e-12:
                cx = (x0 + x1) * 0.5
                cy = (y0 + y1) * 0.5
                squares.append((cx, cy, 0.0, s))
        # sort by size desc, keep n largest, pad with zero-size
        squares.sort(key=lambda t: -t[3])
        if len(squares) > n:
            squares = squares[:n]
        score = sum(t[3] for t in squares)
        while len(squares) < n:
            squares.append((0.5, 0.5, 0.0, 0.0))
        return score, squares

    # Generate a variety of partitions by recursive guillotine splits.
    # We try both uniform and slightly uneven cuts, and different split orders.
    import random

    def gen_partitions(depth, x0, y0, x1, y1, rng):
        w = x1 - x0
        h = y1 - y0
        if depth == 0:
            return [[(x0, y0, x1, y1)]]
        # split vertically or horizontally
        results = []
        for axis in (0, 1):
            for frac in (0.25, 1/3, 0.4, 0.5, 0.6, 2/3, 0.75):
                # add small random jitter
                f = frac + rng.uniform(-0.03, 0.03)
                f = min(max(f, 0.1), 0.9)
                if axis == 0:
                    xm = x0 + w * f
                    left = gen_partitions(depth - 1, x0, y0, xm, y1, rng)
                    right = gen_partitions(depth - 1, xm, y0, x1, y1, rng)
                else:
                    ym = y0 + h * f
                    left = gen_partitions(depth - 1, x0, y0, x1, ym, rng)
                    right = gen_partitions(depth - 1, x0, ym, x1, y1, rng)
                for L in left:
                    for R in right:
                        results.append(L + R)
        return results

    # Try depth based on n
    max_depth = 5 if n <= 64 else 4

    rng = random.Random(12345 + n)

    # Evaluate straightforward uniform grid layouts first (exact)
    for kx in range(1, min(n, 40) + 1):
        for ky in range(1, min(n, 40) + 1):
            if kx * ky < n:
                continue
            # place kx*ky squares of size min(1/kx, 1/ky) in grid
            s = min(1.0 / kx, 1.0 / ky)
            rects = []
            # actually fill only kx*ky rectangles but we need n squares
            # use the grid directly as rectangles
            rects = []
            for i in range(kx):
                for j in range(ky):
                    rects.append((i / kx, j / ky, (i + 1) / kx, (j + 1) / ky))
            score, sq = eval_layout(rects)
            if score > best_score:
                best_score = score
                best = sq

    # Also try simple guillotine recursion with a moderate number of iterations
    import sys
    iterations = 300 if n <= 100 else 100
    for _ in range(iterations):
        # random recursive split into roughly n rectangles
        rects = [(0.0, 0.0, 1.0, 1.0)]
        while len(rects) < n:
            # pick the largest rectangle to split
            rects.sort(key=lambda r: -( (r[2]-r[0])*(r[3]-r[1]) ))
            r = rects.pop(0)
            x0, y0, x1, y1 = r
            w = x1 - x0
            h = y1 - y0
            if w < 1e-9 or h < 1e-9:
                rects.append(r)
                break
            # choose split axis: prefer splitting longer dimension
            if w >= h:
                f = rng.uniform(0.35, 0.65)
                xm = x0 + w * f
                rects.append((x0, y0, xm, y1))
                rects.append((xm, y0, x1, y1))
            else:
                f = rng.uniform(0.35, 0.65)
                ym = y0 + h * f
                rects.append((x0, y0, x1, ym))
                rects.append((x0, ym, x1, y1))
        # sometimes we have more than n rects, keep the biggest n
        if len(rects) > n:
            rects.sort(key=lambda r: -min(r[2]-r[0], r[3]-r[1]))
            rects = rects[:n]
        score, sq = eval_layout(rects)
        if score > best_score:
            best_score = score
            best = sq

    if best is None:
        k = math.isqrt(n)
        side = 1.0 / k if k > 0 else 1.0
        best = [((i % k + 0.5) * side, (i // k + 0.5) * side, 0.0, side) for i in range(n)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]

    return best
