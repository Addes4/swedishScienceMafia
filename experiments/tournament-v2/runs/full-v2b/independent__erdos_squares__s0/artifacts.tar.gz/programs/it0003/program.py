import math
import random
from scipy.optimize import minimize

# ---------- geometry ----------
def corners(cx, cy, ang, s):
    # ang in turns
    th = ang * 2.0 * math.pi
    c, si = math.cos(th), math.sin(th)
    h = s * 0.5
    dx = c * h
    dy = si * h
    # four corners of rotated square
    return [
        (cx - dx + dy, cy - dy - dx),
        (cx + dx + dy, cy + dy - dx),
        (cx + dx - dy, cy + dy + dx),
        (cx - dx - dy, cy - dy + dx),
    ]

def overlap_area(ax, ay, aang, asid, bx, by, bang, bsid):
    # SAT based overlap area approx using polygon clipping (small n, fine)
    if asid <= 0 or bsid <= 0:
        return 0.0
    A = corners(ax, ay, aang, asid)
    B = corners(bx, by, bang, bsid)
    # Sutherland-Hodgman clip A by B
    def inside(p, p1, p2):
        return (p2[0]-p1[0])*(p[1]-p1[1]) - (p2[1]-p1[1])*(p[0]-p1[0]) >= -1e-15
    def intersect(p1, p2, p3, p4):
        x1,y1 = p1; x2,y2 = p2; x3,y3 = p3; x4,y4 = p4
        den = (x1-x2)*(y3-y4)-(y1-y2)*(x3-x4)
        if abs(den) < 1e-18:
            return p2
        px = ((x1*y2-y1*x2)*(x3-x4)-(x1-x2)*(x3*y4-y3*x4))/den
        py = ((x1*y2-y1*x2)*(y3-y4)-(y1-y2)*(x3*y4-y3*x4))/den
        return (px, py)
    output = A[:]
    for i in range(4):
        if not output:
            return 0.0
        p1 = B[i]; p2 = B[(i+1)%4]
        inp = output
        output = []
        S = inp[-1]
        for E in inp:
            if inside(E, p1, p2):
                if not inside(S, p1, p2):
                    output.append(intersect(S, E, p1, p2))
                output.append(E)
            elif inside(S, p1, p2):
                output.append(intersect(S, E, p1, p2))
            S = E
    if len(output) < 3:
        return 0.0
    area = 0.0
    for i in range(len(output)):
        x1,y1 = output[i]; x2,y2 = output[(i+1)%len(output)]
        area += x1*y2 - x2*y1
    return abs(area)*0.5

def inside_unit(cx, cy, ang, s):
    if s <= 0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    for (x,y) in corners(cx, cy, ang, s):
        if x < -1e-9 or x > 1+1e-9 or y < -1e-9 or y > 1+1e-9:
            return False
    return True

# ---------- base packings ----------
def grid_packing(n, k):
    if k <= 0:
        return []
    s = 1.0/k
    sq = []
    cnt = 0
    for i in range(k):
        for j in range(k):
            if cnt >= n: break
            sq.append([(i+0.5)*s, (j+0.5)*s, 0.0, s])
            cnt += 1
        if cnt >= n: break
    while len(sq) < n:
        sq.append([0.5,0.5,0.0,0.0])
    return sq

def candidate_inits(n):
    cands = []
    # several grid sizes
    for k in range(1, int(math.sqrt(n))+3):
        if k*k >= n:
            cands.append(grid_packing(n, k))
            break
    for k in range(1, int(math.sqrt(n))+3):
        if k*(k+1) >= n:
            # mix of two sizes: k columns with k, rest with k+1 style
            s1 = 1.0/k
            sq = []
            cols = k
            rows = (n + cols - 1)//cols
            # simpler: k full rows of k, plus remainder row
            cnt = 0
            for i in range(k):
                for j in range(k):
                    if cnt < n:
                        sq.append([(i+0.5)*s1, (j+0.5)*s1, 0.0, s1])
                        cnt += 1
            # remaining row
            rem = n - k*k
            if rem > 0:
                s2 = 1.0/max(rem,1) if rem<=k else 1.0/k
                s2 = min(s2, s1)
                # place remainder row above
                for j in range(rem):
                    sq.append([(j+0.5)*s2, k*s1 + 0.5*s2, 0.0, s2])
            while len(sq) < n:
                sq.append([0.5,0.5,0.0,0.0])
            cands.append(sq)
    return cands

# ---------- repair / project ----------
def compute_overlaps(sq):
    n = len(sq)
    ov = []
    for i in range(n):
        for j in range(i+1, n):
            a = overlap_area(sq[i][0],sq[i][1],sq[i][2],sq[i][3],
                             sq[j][0],sq[j][1],sq[j][2],sq[j][3])
            if a > 1e-12:
                ov.append((i,j,a))
    return ov

def total_side(sq):
    return sum(s[3] for s in sq)

def feasibility_penalty(sq, lam=200.0):
    pen = 0.0
    for i in range(len(sq)):
        cx,cy,ang,s = sq[i]
        if s <= 0: continue
        if not inside_unit(cx,cy,ang,s):
            # measure excess
            for (x,y) in corners(cx,cy,ang,s):
                if x < 0: pen += -x*lam
                if x > 1: pen += (x-1)*lam
                if y < 0: pen += -y*lam
                if y > 1: pen += (y-1)*lam
        if s > 1.0 + 1e-9:
            pen += (s-1.0)*lam
    ov = compute_overlaps(sq)
    for (_,_,a) in ov:
        pen += a * lam
    return pen

def project_back(sq, iters=60):
    """Push overlapping squares apart and rescale to fit into unit square."""
    n = len(sq)
    for it in range(iters):
        ov = compute_overlaps(sq)
        moved = False
        for (i,j,a) in ov:
            xi,yi,angi,si = sq[i]
            xj,yj,angj,sj = sq[j]
            dx = xj - xi
            dy = yj - yi
            d = math.hypot(dx,dy)
            if d < 1e-12:
                dx,dy = random.uniform(-1,1), random.uniform(-1,1)
                d = math.hypot(dx,dy)
            step = 0.5*a
            nx, ny = dx/d, dy/d
            sq[i][0] -= nx*step*0.5
            sq[i][1] -= ny*step*0.5
            sq[j][0] += nx*step*0.5
            sq[j][1] += ny*step*0.5
            moved = True
        # clamp within unit
        for s in sq:
            if s[3] > 0:
                cx,cy,ang,side = s
                cs = corners(cx,cy,ang,side)
                minx = min(p[0] for p in cs); maxx = max(p[0] for p in cs)
                miny = min(p[1] for p in cs); maxy = max(p[1] for p in cs)
                if minx < 0: s[0] += -minx
                if maxx > 1: s[0] -= (maxx-1)
                if miny < 0: s[1] += -miny
                if maxy > 1: s[1] -= (maxy-1)
        if not moved:
            break
    return sq

# ---------- local optimizer ----------
def objective_from_params(params, base):
    n = len(base)
    sq = []
    idx = 0
    for i in range(n):
        cx = params[idx]; cy = params[idx+1]; ang = params[idx+2]; s = params[idx+3]
        idx += 4
        sq.append([cx,cy,ang,s])
    # penalty for overlaps and containment
    pen = feasibility_penalty(sq, lam=1000.0)
    return -total_side(sq) + pen

def refine(sq, iters=150):
    n = len(sq)
    params = []
    for s in sq:
        params.extend(s)
    # bounds: cx,cy in [0,1], ang in [0,1), s in [0,1]
    bounds = []
    for _ in range(n):
        bounds.extend([(0.0,1.0),(0.0,1.0),(0.0,1.0),(0.0,1.0)])

    def obj(params):
        sq2 = []
        idx = 0
        for i in range(n):
            sq2.append([params[idx],params[idx+1],params[idx+2],params[idx+3]])
            idx += 4
        pen = feasibility_penalty(sq2, lam=5000.0)
        return -total_side(sq2) + pen

    try:
        res = minimize(obj, params, method='L-BFGS-B', bounds=bounds,
                       options={'maxiter': iters, 'ftol':1e-12, 'gtol':1e-10})
        params = res.x
    except Exception:
        pass
    sq2 = []
    idx = 0
    for i in range(n):
        sq2.append([params[idx],params[idx+1],params[idx+2],params[idx+3]])
        idx += 4
    sq2 = project_back(sq2, 30)
    return sq2

# ---------- global search ----------
def greedy_grow(sq, n, rounds=200):
    """Randomly try to increase one square's side, keeping feasibility."""
    best = [s[:] for s in sq]
    best_val = total_side(best)
    for r in range(rounds):
        cur = [s[:] for s in best]
        i = random.randrange(n)
        old = cur[i][3]
        inc = random.uniform(0.001, 0.05)
        cur[i][3] = min(1.0, old + inc)
        # try small positional jiggle
        cur[i][0] = min(1.0, max(0.0, cur[i][0] + random.uniform(-0.02,0.02)))
        cur[i][1] = min(1.0, max(0.0, cur[i][1] + random.uniform(-0.02,0.02)))
        cur[i][2] = random.uniform(0.0, 1.0) if random.random() < 0.1 else cur[i][2]
        cur = project_back(cur, 20)
        # shrink any square that no longer fits
        for s in cur:
            if not inside_unit(s[0],s[1],s[2],s[3]) and s[3] > 0:
                # shrink until fits
                lo, hi = 0.0, s[3]
                for _ in range(20):
                    mid = 0.5*(lo+hi)
                    if inside_unit(s[0],s[1],s[2],mid):
                        lo = mid
                    else:
                        hi = mid
                s[3] = lo
        val = total_side(cur)
        if val > best_val - 1e-12:
            best = cur
            best_val = val
    return best

def solve(n):
    if n <= 0:
        return []
    best = None
    best_val = -1.0
    cands = candidate_inits(n)
    # always include simple grid
    k = math.isqrt(n)
    cands.append(grid_packing(n,k))
    for init in cands:
        sq = [list(s) for s in init]
        sq = project_back(sq, 50)
        sq = refine(sq, 100)
        sq = greedy_grow(sq, n, rounds=80)
        v = total_side(sq)
        if v > best_val:
            best_val = v
            best = [s[:] for s in sq]
    # final polish
    if best is not None:
        best = refine(best, 200)
        best = project_back(best, 40)
    # sanitize
    result = []
    for s in best:
        cx = min(1.0, max(0.0, float(s[0])))
        cy = min(1.0, max(0.0, float(s[1])))
        ang = float(s[2]) % 1.0
        side = min(1.0, max(0.0, float(s[3])))
        result.append((cx, cy, ang, side))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
