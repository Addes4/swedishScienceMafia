import math
import random
import time

import numpy as np


def _overlap_area(s1, s2):
    # Fast SAT-based polygon overlap is expensive; instead approximate with rotated-inflated AABB tests.
    # For scoring and annealing we use exact polygon intersection via convex clipping only when needed.
    return 0.0


def _corners(cx, cy, ang, s):
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    dx = h * ca
    dy = h * sa
    ex = -h * sa
    ey = h * ca
    p0 = (cx - dx - ex, cy - dy - ey)
    p1 = (cx + dx - ex, cy + dy - ey)
    p2 = (cx + dx + ex, cy + dy + ey)
    p3 = (cx - dx + ex, cy - dy + ey)
    return (p0, p1, p2, p3)


def _poly_clip(poly, a, b):
    # clip convex polygon by half-plane a*x+b*y <= c  (c given as third arg via closure? use tuple)
    pass


def _sat_overlap(poly1, poly2):
    # Separating axis test for two convex quads (rotated squares)
    def edges(poly):
        return [(poly[(i + 1) % len(poly)][0] - poly[i][0],
                 poly[(i + 1) % len(poly)][1] - poly[i][1]) for i in range(len(poly))]

    for poly in (poly1, poly2):
        for ex, ey in edges(poly):
            # axis normal
            nx, ny = -ey, ex
            # project both
            mn1 = mx1 = poly1[0][0] * nx + poly1[0][1] * ny
            for x, y in poly1[1:]:
                v = x * nx + y * ny
                if v < mn1: mn1 = v
                if v > mx1: mx1 = v
            mn2 = mx2 = poly2[0][0] * nx + poly2[0][1] * ny
            for x, y in poly2[1:]:
                v = x * nx + y * ny
                if v < mn2: mn2 = v
                if v > mx2: mx2 = v
            if mx1 < mn2 - 1e-12 or mx2 < mn1 - 1e-12:
                return False
    return True


def _inside_unit(cx, cy, ang, s):
    p = _corners(cx, cy, ang, s)
    for x, y in p:
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def _violation(cx, cy, ang, s):
    p = _corners(cx, cy, ang, s)
    v = 0.0
    for x, y in p:
        if x < 0:
            v += -x
        elif x > 1:
            v += x - 1
        if y < 0:
            v += -y
        elif y > 1:
            v += y - 1
    return v


def _score(squares):
    return sum(s[3] for s in squares)


def _repair(squares, iters=200):
    n = len(squares)
    sq = [list(s) for s in squares]
    for _ in range(iters):
        # push out of bounds
        moved = False
        for i in range(n):
            cx, cy, ang, s = sq[i]
            if s <= 0:
                continue
            p = _corners(cx, cy, ang, s)
            dvx = dvy = 0.0
            for x, y in p:
                if x < 0:
                    dvx += -x
                elif x > 1:
                    dvx -= (x - 1)
                if y < 0:
                    dvy += -y
                elif y > 1:
                    dvy -= (y - 1)
            if dvx or dvy:
                sq[i][0] += 0.5 * dvx
                sq[i][1] += 0.5 * dvy
                sq[i][0] = min(1.0, max(0.0, sq[i][0]))
                sq[i][1] = min(1.0, max(0.0, sq[i][1]))
                moved = True
        # resolve pairwise overlaps approximately
        for i in range(n):
            if sq[i][3] <= 0:
                continue
            pi = _corners(sq[i][0], sq[i][1], sq[i][2], sq[i][3])
            for j in range(i + 1, n):
                if sq[j][3] <= 0:
                    continue
                pj = _corners(sq[j][0], sq[j][1], sq[j][2], sq[j][3])
                if _sat_overlap(pi, pj):
                    # push along center delta, shrink slightly
                    dx = sq[i][0] - sq[j][0]
                    dy = sq[i][1] - sq[j][1]
                    d = math.hypot(dx, dy) + 1e-12
                    # shrink both a bit
                    sq[i][3] *= 0.97
                    sq[j][3] *= 0.97
                    push = 0.03
                    sq[i][0] += dx / d * push
                    sq[i][1] += dy / d * push
                    sq[j][0] -= dx / d * push
                    sq[j][1] -= dy / d * push
                    for k in (i, j):
                        sq[k][0] = min(1.0, max(0.0, sq[k][0]))
                        sq[k][1] = min(1.0, max(0.0, sq[k][1]))
                    pi = _corners(sq[i][0], sq[i][1], sq[i][2], sq[i][3])
                    moved = True
        if not moved:
            break
    return [tuple(x) for x in sq]


def _grid_pack(n):
    k = math.isqrt(n)
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def _anneal(n, seconds=52.0):
    t0 = time.time()
    # start with grid but with all squares nonzero and slightly reduced to allow wiggle
    k = math.isqrt(n)
    if k * k == n:
        return _grid_pack(n)

    # initial: use k*k grid plus extra squares of tiny size, then expand greedily
    base = _grid_pack(n)
    # give leftover squares nonzero sizes
    total_extra = n - k * k
    # size leftover small but reasonable
    leftovers = []
    if total_extra > 0:
        ls = 0.5 / (k + 1)
        for _ in range(total_extra):
            leftovers.append((0.5, 0.5, 0.0, ls))
    base = base[:k * k] + leftovers
    base = _repair(base)

    sq = [list(s) for s in base]
    best = [s[:] for s in sq]
    best_score = _score(sq)

    rng = random.Random(12345 + n)

    it = 0
    while time.time() - t0 < seconds:
        it += 1
        # randomly perturb one square
        i = rng.randrange(n)
        old = sq[i][:]
        typ = rng.random()
        cx, cy, ang, s = sq[i]
        if typ < 0.35:
            cx += rng.uniform(-0.02, 0.02)
            cy += rng.uniform(-0.02, 0.02)
        elif typ < 0.6:
            ang += rng.uniform(-0.05, 0.05)
        elif typ < 0.9:
            s += rng.uniform(-0.02, 0.03)
        else:
            cx += rng.uniform(-0.01, 0.01)
            cy += rng.uniform(-0.01, 0.01)
            ang += rng.uniform(-0.03, 0.03)
            s += rng.uniform(-0.01, 0.02)
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        s = max(0.0, min(1.0, s))
        sq[i] = [cx, cy, ang, s]

        # repair and evaluate
        repaired = _repair(sq, iters=60)

        # check all overlaps and bounds strictly
        ok = True
        for a in range(n):
            if repaired[a][3] < 0:
                ok = False
                break
            if not _inside_unit(*repaired[a]):
                ok = False
                break
        if ok:
            for a in range(n):
                if repaired[a][3] <= 0:
                    continue
                pa = _corners(*repaired[a])
                for b in range(a + 1, n):
                    if repaired[b][3] <= 0:
                        continue
                    pb = _corners(*repaired[b])
                    if _sat_overlap(pa, pb):
                        ok = False
                        break
                if not ok:
                    break

        sc = _score(repaired) if ok else -1e9
        # annealed acceptance
        temp = max(1e-4, 0.05 * (1.0 - (time.time() - t0) / seconds))
        if sc > best_score or (ok and rng.random() < math.exp((sc - best_score) / temp)):
            sq = [r[:] for r in repaired]
            if ok and sc > best_score:
                best_score = sc
                best = [r[:] for r in repaired]

    # final repair of best
    best = _repair(best, iters=300)
    # fix any residual overlap by shrinking
    for _ in range(50):
        changed = False
        for a in range(n):
            if best[a][3] <= 0:
                continue
            pa = _corners(*best[a])
            for b in range(a + 1, n):
                if best[b][3] <= 0:
                    continue
                pb = _corners(*best[b])
                if _sat_overlap(pa, pb):
                    best[a] = list(best[a]) if isinstance(best[a], tuple) else best[a]
                    best[b] = list(best[b]) if isinstance(best[b], tuple) else best[b]
                    best[a] = (best[a][0], best[a][1], best[a][2], best[a][3] * 0.98)
                    best[b] = (best[b][0], best[b][1], best[b][2], best[b][3] * 0.98)
                    pa = _corners(*best[a])
                    changed = True
        if not changed:
            break
    # final bounds clamp by shifting center
    res = []
    for cx, cy, ang, s in best:
        if s <= 0:
            res.append((0.5, 0.5, 0.0, 0.0))
            continue
        # try to fit inside by moving center and shrinking if needed
        for _ in range(20):
            if _inside_unit(cx, cy, ang, s):
                break
            p = _corners(cx, cy, ang, s)
            xs = [q[0] for q in p]
            ys = [q[1] for q in p]
            mnx, mxx = min(xs), max(xs)
            mny, mxy = min(ys), max(ys)
            dx = 0.0
            if mnx < 0:
                dx += -mnx
            if mxx > 1:
                dx -= mxx - 1
            dy = 0.0
            if mny < 0:
                dy += -mny
            if mxy > 1:
                dy -= mxy - 1
            if abs(dx) > 1e-9 or abs(dy) > 1e-9:
                cx += 0.5 * dx
                cy += 0.5 * dy
            else:
                s *= 0.99
            cx = min(1.0, max(0.0, cx))
            cy = min(1.0, max(0.0, cy))
        if not _inside_unit(cx, cy, ang, s):
            # last resort shrink
            while s > 0 and not _inside_unit(cx, cy, ang, s):
                s *= 0.95
        res.append((float(cx), float(cy), float(ang), float(s)))
    return res


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    k = math.isqrt(n)
    if k * k == n:
        return _grid_pack(n)

    # quick decent heuristic for small n
    if n <= 9:
        # use anneal but short
        return _anneal(n, seconds=8.0)

    return _anneal(n, seconds=52.0)
