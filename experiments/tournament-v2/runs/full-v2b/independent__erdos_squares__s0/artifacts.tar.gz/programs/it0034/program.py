import math
import random
import numpy as np

# ---------- geometry helpers ----------

def square_corners(cx, cy, angle, side):
    """Return the 4 corners of a square given center, angle fraction of full turn, and side length."""
    a = angle * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side * 0.5
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        out.append((cx + x * ca - y * sa, cy + x * sa + y * ca))
    return out

def polygons_overlap(pts1, pts2):
    """Separating axis theorem for two convex polygons given as point lists."""
    for pts in (pts1, pts2):
        m = len(pts)
        for i in range(m):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % m]
            # edge normal
            nx = -(y2 - y1)
            ny = (x2 - x1)
            # project both polygons
            min1 = max1 = None
            for px, py in pts1:
                d = px * nx + py * ny
                if min1 is None or d < min1: min1 = d
                if max1 is None or d > max1: max1 = d
            min2 = max2 = None
            for px, py in pts2:
                d = px * nx + py * ny
                if min2 is None or d < min2: min2 = d
                if max2 is None or d > max2: max2 = d
            if max1 <= min2 or max2 <= min1:
                return False
    return True

def inside_unit(cx, cy, angle, side):
    """Check if square is inside [0,1]^2 (with tiny tolerance)."""
    eps = 1e-12
    pts = square_corners(cx, cy, angle, side)
    for x, y in pts:
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True

def clamp_square(cx, cy, angle, side):
    """Nudge center so that square fits inside unit square, return new (cx, cy) or None if impossible."""
    if side <= 0:
        return 0.5, 0.5
    a = angle * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side * 0.5
    # max extent in x and y from center
    ex = abs(ca) * h + abs(sa) * h
    ey = abs(sa) * h + abs(ca) * h
    if ex > 0.5 + 1e-12 or ey > 0.5 + 1e-12:
        return None
    ncx = min(max(cx, ex), 1.0 - ex)
    ncy = min(max(cy, ey), 1.0 - ey)
    return ncx, ncy

def all_disjoint(squares):
    """squares = list of (cx, cy, angle, side). Return True if all interiors disjoint and in unit square."""
    polys = []
    for cx, cy, ang, sd in squares:
        if not inside_unit(cx, cy, ang, sd):
            return False
        polys.append(square_corners(cx, cy, ang, sd))
    m = len(squares)
    for i in range(m):
        if squares[i][3] <= 1e-14:
            continue
        for j in range(i + 1, m):
            if squares[j][3] <= 1e-14:
                continue
            if polygons_overlap(polys[i], polys[j]):
                return False
    return True

def total_side(squares):
    return sum(s[3] for s in squares)

# ---------- initial placements ----------

def grid_initial(n):
    """Place n squares in a k x k grid, plus extra tiny squares."""
    k = int(math.isqrt(n))
    while k * k < n:
        k += 1
    # try best k that yields n squares: use largest k with k*k >= n? No, we want k*k <= n ideally.
    k = int(math.isqrt(n))
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # remaining as tiny squares at random positions (later optimized)
    for _ in range(n - len(squares)):
        squares.append((random.uniform(0.01, 0.99), random.uniform(0.01, 0.99), 0.0, 1e-6))
    return squares

def strip_initial(n):
    """Place n equal strips vertically (all angle 0), each of width 1/n, plus maybe fill."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # Try arrangement: some full-height vertical strips
    squares = []
    for i in range(n):
        squares.append(((i + 0.5) / n, 0.5, 0.0, 1.0 / n))
    return squares

def spiral_initial(n):
    """Place n squares in a spiral filling pattern."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    squares = []
    # Use simple grid but with varying sizes: recursive quadtree-style
    # Actually easiest: use grid with square side = 1/k for k = floor(sqrt(n))
    k = int(math.isqrt(n))
    if k < 1:
        k = 1
    side = 1.0 / k
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # Fill remaining by shrinking some to make room
    while len(squares) < n:
        # Split the largest square into 4 smaller ones
        idx = max(range(len(squares)), key=lambda i: squares[i][3])
        cx, cy, ang, sd = squares.pop(idx)
        h = sd / 2.0
        for dx, dy in [(-h/2, -h/2), (h/2, -h/2), (h/2, h/2), (-h/2, h/2)]:
            squares.append((cx + dx, cy + dy, ang, h))
    return squares[:n]

# ---------- local optimization ----------

def local_optimize(squares, time_limit_iters=5000, verbose=False):
    """Coordinate descent: try small perturbations to improve total side length."""
    n = len(squares)
    best = [list(s) for s in squares]
    best_score = total_side(best)
    
    # Precompute order of indices sorted by side length (optimize large ones more)
    order = list(range(n))
    
    step_sizes = [0.05, 0.02, 0.01, 0.005, 0.002, 0.001]
    
    for it in range(time_limit_iters):
        improved = False
        for idx in order:
            cx, cy, ang, sd = best[idx]
            # try perturbations
            for ds in step_sizes:
                for d in [-ds, ds]:
                    # try increasing side
                    new_sd = max(0.0, sd + d)
                    if new_sd <= sd + 1e-15 and d < 0:
                        # try decreasing
                        pass
                    # Try shift center
                    for dcx, dcy in [(0, 0), (d, 0), (-d, 0), (0, d), (0, -d)]:
                        ncx, ncy = cx + dcx, cy + dcy
                        clamped = clamp_square(ncx, ncy, ang, new_sd)
                        if clamped is None:
                            continue
                        ncx, ncy = clamped
                        candidate = (ncx, ncy, ang, new_sd)
                        # temporarily replace
                        old = best[idx]
                        best[idx] = list(candidate)
                        if all_disjoint(best):
                            sc = total_side(best)
                            if sc > best_score + 1e-12:
                                best_score = sc
                                improved = True
                                cx, cy, ang, sd = ncx, ncy, ang, new_sd
                                break
                            else:
                                best[idx] = old
                        else:
                            best[idx] = old
                    else:
                        continue
                    break
                else:
                    continue
                break
            # try angle perturbation
            if not improved:
                for da in [0.01, -0.01, 0.005, -0.005, 0.002, -0.002, 0.001, -0.001]:
                    new_ang = (ang + da) % 1.0
                    clamped = clamp_square(cx, cy, new_ang, sd)
                    if clamped is None:
                        continue
                    ncx, ncy = clamped
                    candidate = (ncx, ncy, new_ang, sd)
                    old = best[idx]
                    best[idx] = list(candidate)
                    if all_disjoint(best):
                        sc = total_side(best)
                        if sc > best_score + 1e-12:
                            best_score = sc
                            improved = True
                            ang = new_ang
                            cx, cy = ncx, ncy
                            break
                        else:
                            best[idx] = old
                    else:
                        best[idx] = old
        if not improved:
            # try random restarts / bigger perturbations
            for _ in range(10):
                idx = random.randrange(n)
                cx, cy, ang, sd = best[idx]
                new_sd = max(0.0, sd * (1 + random.uniform(-0.1, 0.1)))
                ncx = cx + random.uniform(-0.05, 0.05)
                ncy = cy + random.uniform(-0.05, 0.05)
                new_ang = (ang + random.uniform(-0.05, 0.05)) % 1.0
                clamped = clamp_square(ncx, ncy, new_ang, new_sd)
                if clamped is None:
                    continue
                ncx, ncy = clamped
                candidate = (ncx, ncy, new_ang, new_sd)
                old = best[idx]
                best[idx] = list(candidate)
                if all_disjoint(best):
                    sc = total_side(best)
                    if sc > best_score + 1e-12:
                        best_score = sc
                        improved = True
                else:
                    best[idx] = old
        if not improved:
            break
    
    return [tuple(s) for s in best]

# ---------- main solver ----------

def solve(n):
    """Return n squares inside unit square, disjoint interiors, maximising sum of sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    best_result = None
    best_score = -1.0
    
    # Try different initial configurations
    initial_configs = []
    
    # 1. Grid-based
    try:
        initial_configs.append(grid_initial(n))
    except Exception:
        pass
    
    # 2. Strips
    try:
        initial_configs.append(strip_initial(n))
    except Exception:
        pass
    
    # 3. Spiral / quadtree
    try:
        initial_configs.append(spiral_initial(n))
    except Exception:
        pass
    
    # 4. Mixed: grid but last row varying
    try:
        k = int(math.isqrt(n))
        if k > 1:
            side = 1.0 / k
            sq = []
            # first (k-1) rows full
            for i in range(k):
                for j in range(k):
                    if len(sq) < n:
                        sq.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
            # remaining in last column with varied sizes
            rem = n - len(sq)
            if rem > 0:
                # split last column cells
                pass
            initial_configs.append(sq[:n])
    except Exception:
        pass
    
    for init in initial_configs:
        if len(init) != n:
            continue
        # Ensure feasibility
        if not all_disjoint(init):
            # Try to fix: shrink all slightly
            init = [(cx, cy, ang, sd * 0.999) for cx, cy, ang, sd in init]
            if not all_disjoint(init):
                continue
        score = total_side(init)
        if score > best_score:
            best_score = score
            best_result = [tuple(s) for s in init]
    
    if best_result is None:
        # fallback: equal grid
        k = int(math.isqrt(n))
        side = 1.0 / k if k > 0 else 1.0
        best_result = [((i % k + 0.5) * side, (i // k + 0.5) * side, 0.0, side) for i in range(n)]
    
    # Optimize
    try:
        improved = local_optimize(best_result, time_limit_iters=3000)
        if all_disjoint(improved) and total_side(improved) >= best_score - 1e-9:
            best_result = improved
    except Exception:
        pass
    
    # Final safety: if infeasible, shrink slightly
    if not all_disjoint(best_result):
        for factor in [0.999, 0.99, 0.95, 0.9, 0.8]:
            test = [(cx, cy, ang, sd * factor) for cx, cy, ang, sd in best_result]
            if all_disjoint(test):
                best_result = test
                break
        else:
            # Last resort: zero out some
            best_result = [(0.5, 0.5, 0.0, 0.0)] * n
    
    # Ensure exactly n
    if len(best_result) < n:
        best_result += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_result))
    best_result = best_result[:n]
    
    # Clamp all inside
    final = []
    for cx, cy, ang, sd in best_result:
        if sd <= 0:
            final.append((0.5, 0.5, 0.0, 0.0))
            continue
        clamped = clamp_square(cx, cy, ang, sd)
        if clamped is None:
            sd = min(sd, 1e-6)
            clamped = (0.5, 0.5)
        ncx, ncy = clamped
        final.append((ncx, ncy, ang % 1.0, sd))
    
    return final
