# EVOLVE-BLOCK-START
"""Packing squares in a unit square to maximise the sum of side lengths."""
import math
import random
import numpy as np

try:
    from scipy.optimize import minimize
    _HAVE_SCIPY = True
except Exception:
    _HAVE_SCIPY = False


def _overlap(a, b, eps=1e-12):
    """Return True if two oriented squares overlap with positive area.

    A square is (cx, cy, angle_turns, side). angle is a fraction of a full turn.
    Two convex polygons overlap with positive area iff a separating axis
    (edge normal of either) separates them strictly.
    """
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 1e-15 or bsz <= 1e-15:
        return False

    # half extents and axes
    aa_rad = aa * 2.0 * math.pi
    ba_rad = ba * 2.0 * math.pi
    ca, sa = math.cos(aa_rad), math.sin(aa_rad)
    cb, sb = math.cos(ba_rad), math.sin(ba_rad)

    # corners of A
    ha = asz * 0.5
    A = [
        (ax + (-ha * ca - ha * sa), ay + (-ha * sa + ha * ca)),
        (ax + ( ha * ca - ha * sa), ay + ( ha * sa + ha * ca)),
        (ax + ( ha * ca + ha * sa), ay + ( ha * sa - ha * ca)),
        (ax + (-ha * ca + ha * sa), ay + (-ha * sa - ha * ca)),
    ]
    hb = bsz * 0.5
    B = [
        (bx + (-hb * cb - hb * sb), by + (-hb * sb + hb * cb)),
        (bx + ( hb * cb - hb * sb), by + ( hb * sb + hb * cb)),
        (bx + ( hb * cb + hb * sb), by + ( hb * sb - hb * cb)),
        (bx + (-hb * cb + hb * sb), by + (-hb * sb - hb * cb)),
    ]

    # separating axes: edge normals of both polygons
    def proj(poly, nx, ny):
        mn = mx = poly[0][0] * nx + poly[0][1] * ny
        for px, py in poly[1:]:
            v = px * nx + py * ny
            if v < mn: mn = v
            if v > mx: mx = v
        return mn, mx

    for poly in (A, B):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            nx, ny = -(y2 - y1), (x2 - x1)
            ln = math.hypot(nx, ny)
            if ln < 1e-15:
                continue
            nx /= ln; ny /= ln
            mna, mxa = proj(A, nx, ny)
            mnb, mxb = proj(B, nx, ny)
            if mxa <= mnb + eps or mxb <= mna + eps:
                return False
    return True


def _feasible(squares, eps=1e-12):
    n = len(squares)
    for i in range(n):
        if squares[i][3] <= 0:
            continue
        xi, yi, _, si = squares[i]
        h = si * 0.5
        # bounding circle inside unit square is sufficient, but we want a tighter test
        # check all four corners lie in [0,1]
        aa = squares[i][2] * 2.0 * math.pi
        c, s = math.cos(aa), math.sin(aa)
        for sx, sy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            px = xi + sx * c - sy * s
            py = yi + sx * s + sy * c
            if px < -1e-9 or px > 1.0 + 1e-9 or py < -1e-9 or py > 1.0 + 1e-9:
                return False
        for j in range(i + 1, n):
            if _overlap(squares[i], squares[j], eps):
                return False
    return True


def _total(squares):
    return sum(sq[3] for sq in squares)


def _clamp_square(cx, cy, angle, side):
    """Keep all four corners inside the unit square."""
    if side <= 0:
        return cx, cy, angle, 0.0
    aa = angle * 2.0 * math.pi
    c, s = math.cos(aa), math.sin(aa)
    h = side * 0.5
    xs = [cx + sx * c - sy * s for sx, sy in ((-h, -h), (h, -h), (h, h), (-h, h))]
    ys = [cy + sx * s + sy * c for sx, sy in ((-h, -h), (h, -h), (h, h), (-h, h))]
    xmin, xmax = min(xs), max(xs)
    ymin, ymax = min(ys), max(ys)
    if xmax - xmin > 1.0 + 1e-12:
        side *= 1.0 / (xmax - xmin) * 0.999999
        h = side * 0.5
    if ymax - ymin > 1.0 + 1e-12:
        side *= 1.0 / (ymax - ymin) * 0.999999
    aa = angle * 2.0 * math.pi
    c, s = math.cos(aa), math.sin(aa)
    h = side * 0.5
    xs = [cx + sx * c - sy * s for sx, sy in ((-h, -h), (h, -h), (h, h), (-h, h))]
    ys = [cy + sx * s + sy * c for sx, sy in ((-h, -h), (h, -h), (h, h), (-h, h))]
    xmin, xmax = min(xs), max(xs)
    ymin, ymax = min(ys), max(ys)
    dx = 0.0
    dy = 0.0
    if xmin < 0: dx = -xmin
    if xmax > 1: dx = 1 - xmax
    if ymin < 0: dy = -ymin
    if ymax > 1: dy = 1 - ymax
    return cx + dx, cy + dy, angle, side


def _grid_layout(n):
    """A k x k grid where k = isqrt(n); remaining become tiny/degenerate."""
    k = int(math.isqrt(n))
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    res = []
    for i in range(k):
        for j in range(k):
            res.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]


def _greedy_layout(n, tries=6):
    """Greedy: largest square first on a grid of candidate positions.

    Builds a non-overlapping set of axis-aligned squares using a binary-like
    subdivision / shelf approach and random restarts.
    """
    best = None
    best_sum = -1.0
    # candidate sizes to try for the first few squares (largest first)
    for t in range(tries):
        rnd = random.Random(12345 + t * 9871)
        squares = []
        # Start with a k x k grid which is always feasible.
        k = int(math.isqrt(n))
        base = []
        if k > 0:
            side = 1.0 / k
            for i in range(k):
                for j in range(k):
                    base.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        while len(base) < n:
            base.append((0.5, 0.5, 0.0, 0.0))
        base = base[:n]

        # Now improve by nudging squares. Use simple stochastic descent.
        cur = [list(x) for x in base]
        cur_sum = _total(cur)
        iters = 400 + 60 * n
        for it in range(iters):
            idx = rnd.randrange(n)
            cx, cy, ang, sz = cur[idx]
            # choose perturbation type
            r = rnd.random()
            if r < 0.55:
                # resize: sometimes grow, sometimes shrink
                if rnd.random() < 0.7:
                    nsz = sz + rnd.uniform(0.0, 0.06 * max(sz, 0.02) + 0.01)
                else:
                    nsz = max(0.0, sz - rnd.uniform(0.0, 0.04 * max(sz, 0.02) + 0.01))
                nang = ang
            elif r < 0.85:
                # move centre
                nsz = sz
                nang = ang
            else:
                # rotate
                nsz = sz
                nang = (ang + rnd.uniform(-0.08, 0.08)) % 1.0

            ncx = cx + rnd.uniform(-0.04, 0.04) if r < 0.85 else cx
            ncy = cy + rnd.uniform(-0.04, 0.04) if r < 0.85 else cy
            if r >= 0.85:
                ncx, ncy = cx, cy

            # keep corners inside
            ncx, ncy, nang, nsz = _clamp_square(ncx, ncy, nang, nsz)

            old = cur[idx][:]
            cur[idx] = [ncx, ncy, nang, nsz]
            if _feasible(cur):
                new_sum = _total(cur)
                if new_sum >= cur_sum - 1e-15:
                    cur_sum = new_sum
                else:
                    cur[idx] = old
            else:
                cur[idx] = old

        if cur_sum > best_sum:
            best_sum = cur_sum
            best = [tuple(x) for x in cur]
    return best, best_sum


def solve(n):
    """Return n squares (cx, cy, angle, side) inside [0,1]^2 with disjoint interiors."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best, best_sum = _greedy_layout(n, tries=8)

    # Final polish: for each square try to expand it while keeping feasibility.
    cur = [list(x) for x in best]
    improved = True
    rounds = 0
    while improved and rounds < 6:
        improved = False
        rounds += 1
        order = list(range(n))
        random.shuffle(order)
        for idx in order:
            cx, cy, ang, sz = cur[idx]
            # binary search for maximum side
            lo, hi = sz, min(1.0, sz + 0.5)
            # first ensure hi is infeasible or cap
            def try_side(s):
                nc = cur[idx][:]
                nc[3] = s
                # recenter inside
                ncx, ncy, nang, nsz = _clamp_square(nc[0], nc[1], nc[2], s)
                nc = [ncx, ncy, nang, nsz]
                old = cur[idx][:]
                cur[idx] = nc
                ok = _feasible(cur)
                cur[idx] = old
                return ok, nc

            ok_hi, _ = try_side(hi)
            if ok_hi:
                cur[idx] = try_side(hi)[1]
                improved = True
                continue
            for _ in range(30):
                mid = 0.5 * (lo + hi)
                ok, nc = try_side(mid)
                if ok:
                    lo = mid
                else:
                    hi = mid
            if lo > sz + 1e-9:
                _, nc = try_side(lo)
                cur[idx] = nc
                improved = True

    # ensure all outputs are in [0,1]
    out = []
    for cx, cy, ang, sz in cur:
        ncx, ncy, nang, nsz = _clamp_square(cx, cy, ang % 1.0, sz)
        out.append((min(max(ncx, 0.0), 1.0), min(max(ncy, 0.0), 1.0), nang % 1.0, max(0.0, nsz)))
    return out
# EVOLVE-BLOCK-END
