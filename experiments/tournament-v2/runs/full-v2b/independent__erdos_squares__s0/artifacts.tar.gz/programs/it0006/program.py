import math
import random

import numpy as np
from scipy.optimize import minimize


def _corners(cx, cy, angle, side):
    a = angle * 2.0 * math.pi
    c, s = math.cos(a), math.sin(a)
    h = side * 0.5
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + x * c - y * s, cy + x * s + y * c) for x, y in pts]


def _projection_axes(angle):
    a = angle * 2.0 * math.pi
    c, s = math.cos(a), math.sin(a)
    return [(c, s), (-s, c)]


def _overlap_penalty(sq1, sq2):
    """Return a positive penalty if interiors overlap, else 0.

    Uses SAT. Squares have disjoint interiors iff there is a separating axis
    among the 4 face normals.
    """
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= 1e-15 or s2 <= 1e-15:
        return 0.0

    axes = _projection_axes(a1) + _projection_axes(a2)
    p1 = _corners(cx1, cy1, a1, s1)
    p2 = _corners(cx2, cy2, a2, s2)

    min_gap = float("inf")
    for ax, ay in axes:
        v1 = [px * ax + py * ay for px, py in p1]
        v2 = [px * ax + py * ay for px, py in p2]
        gap = max(min(v1) - max(v2), min(v2) - max(v1))
        if gap > min_gap:
            min_gap = gap
        if gap >= 0.0:
            return 0.0
    return -min_gap


def _bounds_penalty(sq):
    cx, cy, angle, side = sq
    if side <= 1e-15:
        pen = 0.0
        for v in (cx, cy):
            if v < -1e-9:
                pen += -v
            if v > 1.0 + 1e-9:
                pen += v - 1.0
        return pen

    pts = _corners(cx, cy, angle, side)
    pen = 0.0
    for x, y in pts:
        if x < -1e-9:
            pen += -x
        if x > 1.0 + 1e-9:
            pen += x - 1.0
        if y < -1e-9:
            pen += -y
        if y > 1.0 + 1e-9:
            pen += y - 1.0
    return pen


def _clamp01(v):
    return max(0.0, min(1.0, float(v)))


def _clip_square(sq):
    cx, cy, angle, side = sq
    if side <= 1e-15:
        return [_clamp01(cx), _clamp01(cy), 0.0, 0.0]

    angle = angle % 1.0
    pts = _corners(cx, cy, angle, side)
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    lox, hix = min(xs), max(xs)
    loy, hiy = min(ys), max(ys)

    if lox < 0.0:
        cx -= lox
        hix -= lox
        lox = 0.0
    if hix > 1.0:
        d = hix - 1.0
        cx -= d
        lox -= d
        hix = 1.0
    if loy < 0.0:
        cy -= loy
        hiy -= loy
        loy = 0.0
    if hiy > 1.0:
        d = hiy - 1.0
        cy -= d
        loy -= d
        hiy = 1.0

    # If side too large for any placement, scale it down slightly.
    if hix - lox > 1.0 + 1e-12 or hiy - loy > 1.0 + 1e-12:
        side *= 0.999999
    return [_clamp01(cx), _clamp01(cy), angle % 1.0, max(0.0, min(1.0, side))]


def _initial_solution(n):
    """Start with a near-grid of the right count, with tiny random perturbations."""
    k = int(math.ceil(math.sqrt(n)))
    base = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            if len(squares) >= n:
                break
            sq = [
                (i + 0.5) * base,
                (j + 0.5) * base,
                0.0,
                base * 0.999,
            ]
            squares.append(sq)
        if len(squares) >= n:
            break
    rng = random.Random(12345 + n)
    for sq in squares:
        sq[0] += rng.uniform(-0.001, 0.001)
        sq[1] += rng.uniform(-0.001, 0.001)
        sq[2] += rng.uniform(-0.002, 0.002)
    return squares


def _packing_score(squares):
    return sum(max(0.0, s[3]) for s in squares)


def _total_penalty(squares):
    pen = 0.0
    for sq in squares:
        pen += _bounds_penalty(sq)
    for i in range(len(squares)):
        for j in range(i + 1, len(squares)):
            pen += _overlap_penalty(squares[i], squares[j])
    return pen


def _vector_to_squares(x, n):
    out = []
    for i in range(n):
        cx = x[4 * i]
        cy = x[4 * i + 1]
        ang = x[4 * i + 2]
        side = x[4 * i + 3]
        out.append([cx, cy, ang, side])
    return out


def _squares_to_vector(squares):
    x = []
    for sq in squares:
        x.extend(sq)
    return np.array(x, dtype=float)


def _objective(x, n, penalty_weight=250.0):
    squares = _vector_to_squares(x, n)
    score = 0.0
    pen = 0.0
    for sq in squares:
        side = sq[3]
        if side > 1e-12:
            score += min(side, 1.0)
        pen += _bounds_penalty(sq)
    for i in range(n):
        for j in range(i + 1, n):
            pen += _overlap_penalty(squares[i], squares[j])
    return -score + penalty_weight * pen


def _project_squares(squares):
    out = [_clip_square(sq) for sq in squares]
    # Push overlapped pairs apart a few times, then clip again.
    for _ in range(50):
        moved = False
        for i in range(len(out)):
            for j in range(i + 1, len(out)):
                p = _overlap_penalty(out[i], out[j])
                if p > 1e-12:
                    moved = True
                    xi, yi, ai, si = out[i]
                    xj, yj, aj, sj = out[j]
                    dx = xj - xi
                    dy = yj - yi
                    if abs(dx) + abs(dy) < 1e-9:
                        dx = 1e-4
                        dy = 1e-4
                    d = math.hypot(dx, dy)
                    ux, uy = dx / d, dy / d
                    push = min(0.03, p + 1e-4) * 0.5
                    out[i] = [xi - ux * push, yi - uy * push, ai, si]
                    out[j] = [xj + ux * push, yj + uy * push, aj, sj]
        for i in range(len(out)):
            out[i] = _clip_square(out[i])
        if not moved:
            break
    return out


def _refine(n, squares, maxiter=900):
    x0 = _squares_to_vector(squares)
    bounds = []
    for _ in range(n):
        bounds.extend([(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)])

    def fun(x):
        return _objective(x, n, penalty_weight=350.0)

    try:
        res = minimize(
            fun,
            x0,
            method="L-BFGS-B",
            bounds=bounds,
            options={"maxiter": maxiter, "ftol": 1e-12, "gtol": 1e-10, "disp": False},
        )
        x = res.x
    except Exception:
        x = x0

    squares = _vector_to_squares(x, n)
    squares = _project_squares(squares)
    return squares


def _feasible_fix(squares):
    """Ensure exact feasibility: shrink and/or move until no violations."""
    out = [list(sq) for sq in squares]

    # Scale down tiny amount to ensure all fit inside and satisfy SAT.
    for _ in range(80):
        bad = False
        for i in range(len(out)):
            if _bounds_penalty(out[i]) > 1e-12:
                bad = True
            for j in range(i + 1, len(out)):
                if _overlap_penalty(out[i], out[j]) > 1e-12:
                    bad = True
                    break
            if bad:
                break
        if not bad:
            break

        # First try moving.
        out = _project_squares(out)
        still_bad = False
        for i in range(len(out)):
            if _bounds_penalty(out[i]) > 1e-12:
                still_bad = True
                break
            for j in range(i + 1, len(out)):
                if _overlap_penalty(out[i], out[j]) > 1e-12:
                    still_bad = True
                    break
            if still_bad:
                break

        if still_bad:
            # Then shrink every square a bit.
            for sq in out:
                sq[3] *= 0.995
                if sq[3] < 1e-12:
                    sq[3] = 0.0
                    sq[0] = _clamp01(sq[0])
                    sq[1] = _clamp01(sq[1])
                    sq[2] = 0.0
            out = [_clip_square(sq) for sq in out]

    # Final clip, force tiny epsilon margin by shrinking if needed.
    out = [_clip_square(sq) for sq in out]
    for _ in range(50):
        bad = False
        for i in range(len(out)):
            if _bounds_penalty(out[i]) > 1e-11:
                bad = True
            for j in range(i + 1, len(out)):
                if _overlap_penalty(out[i], out[j]) > 1e-11:
                    bad = True
                    break
            if bad:
                break
        if not bad:
            break
        for sq in out:
            sq[3] *= 0.998
            if sq[3] < 1e-12:
                sq[3] = 0.0
                sq[2] = 0.0
        out = [_clip_square(sq) for sq in out]

    return out


def _candidate_from_sizes(n, sides):
    """Greedy place squares with given sides in a clipped sequential way."""
    squares = []
    for s in sides:
        if s <= 1e-15:
            squares.append([0.5, 0.5, 0.0, 0.0])
            continue
        best = None
        best_pen = None
        # Try a few random placements.
        rng = random.Random(int(1e6 * s) + len(squares) * 97)
        for _ in range(80):
            cx = rng.uniform(s / 2, 1 - s / 2)
            cy = rng.uniform(s / 2, 1 - s / 2)
            ang = rng.uniform(0, 1)
            sq = [cx, cy, ang, s]
            pen = _bounds_penalty(sq)
            for prev in squares:
                pen += _overlap_penalty(sq, prev)
            if best_pen is None or pen < best_pen:
                best_pen = pen
                best = sq
                if pen < 1e-12:
                    break
        squares.append(best if best is not None else [0.5, 0.5, 0.0, 0.0])
    return squares


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # For very small n, use conservative near-optimal grids.
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # Three equal squares in a row.
        s = 1.0 / 3.0
        return [(s / 2, 0.5, 0.0, s), (0.5, 0.5, 0.0, s), (1.0 - s / 2, 0.5, 0.0, s)]

    # Multi-start from a few structured seeds, then optimize.
    seeds = []

    # 1) grid-like equal squares
    seeds.append(_initial_solution(n))

    # 2) all equal halved-ish, random jitter
    rng = random.Random(999 + n)
    for _ in range(2):
        base = min(1.0 / math.sqrt(n) * 1.02, 1.0)
        arr = []
        for i in range(n):
            side = base * rng.uniform(0.85, 1.0)
            arr.append([rng.uniform(0.1, 0.9), rng.uniform(0.1, 0.9), rng.uniform(0, 1), side])
        seeds.append(_project_squares(arr))

    # 3) one big square plus remainder on the side
    big = 0.5
    rem = n - 1
    if rem > 0:
        small_side = (1.0 - big) / max(1, math.ceil(math.sqrt(rem)))
        arr = [[big / 2, 0.5, 0.0, big]]
        for i in range(rem):
            r = i % max(1, math.ceil(math.sqrt(rem)))
            c = i // max(1, math.ceil(math.sqrt(rem)))
            cx = big + (r + 0.5) * small_side
            cy = (c + 0.5) * small_side
            if cx <= 1.0 and cy <= 1.0:
                arr.append([cx, cy, 0.0, small_side * 0.98])
            else:
                arr.append([0.5, 0.5, 0.0, 0.0])
        seeds.append(_project_squares(arr))

    best = None
    best_score = -1.0

    for seed in seeds:
        sq = [list(s) for s in seed]
        sq = _feasible_fix(sq)
        sq = _refine(n, sq, maxiter=700)
        sq = _feasible_fix(sq)
        score = _packing_score(sq)
        if score > best_score:
            best_score = score
            best = sq

    # Extra randomized local search for larger n.
    if n >= 8:
        for _ in range(3):
            arr = []
            k = int(math.ceil(math.sqrt(n)))
            base = 1.0 / k
            for i in range(n):
                r = i // k
                c = i % k
                side = base * rng.uniform(0.8, 1.0)
                cx = min(1 - side / 2, max(side / 2, (c + 0.5) * base + rng.uniform(-0.03, 0.03)))
                cy = min(1 - side / 2, max(side / 2, (r + 0.5) * base + rng.uniform(-0.03, 0.03)))
                arr.append([cx, cy, rng.uniform(0, 1), side])
            arr = _feasible_fix(_project_squares(arr))
            arr = _refine(n, arr, maxiter=450)
            arr = _feasible_fix(arr)
            score = _packing_score(arr)
            if score > best_score:
                best_score = score
                best = arr

    if best is None:
        best = _feasible_fix(_initial_solution(n))

    # Final cleanup: ensure each tuple is in [0,1], side nonnegative.
    result = []
    for cx, cy, ang, side in best:
        cx = _clamp01(cx)
        cy = _clamp01(cy)
        ang = float(ang) % 1.0
        side = max(0.0, min(1.0, float(side)))
        result.append((cx, cy, ang, side))

    # If feasibility was somehow broken by clipping, fall back to grid.
    if _total_penalty(result) > 1e-7:
        k = math.isqrt(n)
        s = 1.0 / k if k > 0 else 0.0
        result = []
        for i in range(k):
            for j in range(k):
                result.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        while len(result) < n:
            result.append((0.5, 0.5, 0.0, 0.0))
        result = result[:n]

    return result[:n]
