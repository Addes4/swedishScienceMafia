import math
import random
import numpy as np
from scipy.optimize import minimize


# ---------- basic geometry ----------

def _corners(cx, cy, a, s):
    """corners of square centre (cx,cy), angle a (turn fraction), side s"""
    ang = 2.0 * math.pi * a
    ca, sa = math.cos(ang), math.sin(ang)
    h = 0.5 * s
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + dx * ca - dy * sa
        y = cy + dx * sa + dy * ca
        pts.append((x, y))
    return pts


def _inside(cx, cy, a, s, eps=1e-12):
    if s <= eps:
        return True
    for x, y in _corners(cx, cy, a, s):
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def _overlap(i, j, sq, eps=1e-12):
    """separating axis test for two convex squares (allowing touching)"""
    a = sq[i]
    b = sq[j]
    if a[3] <= eps or b[3] <= eps:
        return False
    pa = _corners(*a)
    pb = _corners(*b)
    for poly, other in ((pa, pb), (pb, pa)):
        for k in range(4):
            x1, y1 = poly[k]
            x2, y2 = poly[(k + 1) % 4]
            nx, ny = -(y2 - y1), (x2 - x1)
            ln = math.hypot(nx, ny)
            if ln < 1e-15:
                continue
            nx, ny = nx / ln, ny / ln
            da = [nx * p[0] + ny * p[1] for p in poly]
            db = [nx * p[0] + ny * p[1] for p in other]
            if max(da) <= min(db) + eps or max(db) <= min(da) + eps:
                return False
    return True


def _valid(sq, eps=1e-12):
    n = len(sq)
    for i in range(n):
        cx, cy, a, s = sq[i]
        if s < -eps or not _inside(cx, cy, a, s, eps):
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap(i, j, sq, eps):
                return False
    return True


# ---------- packing constructions ----------

def _grid(n):
    k = max(1, math.isqrt(n))
    s = 1.0 / k
    out = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out[:n]


def _grid_extra(n):
    """(k+1)*k-ish mixed grid; distribute extra squares into a row"""
    if n <= 1:
        return [(0.5, 0.5, 0.0, 1.0)] if n == 1 else []
    best = None
    bestval = -1.0
    for k in range(1, n + 2):
        # try rows arrangement: some rows k wide, some k+1
        for r in range(1, k + 2):
            c = k
            if r * c > n:
                continue
            rem = n - r * c
            # distribute rem into extra columns on some rows
            if rem > r:
                continue
            widths = [c] * r
            for i in range(rem):
                widths[i] += 1
            maxw = max(widths)
            s = 1.0 / maxw
            # heights may not match if number of distinct widths used
            # use full rows: each row height = s, total height must be <= 1
            total_h = r * s
            if total_h > 1.0 + 1e-12:
                continue
            # build squares with different sizes to fill heights
            sq = []
            y = 0.0
            for wi in widths:
                w = wi * s
                x = 0.0
                for _ in range(wi):
                    sq.append((x + 0.5 * s, y + 0.5 * s, 0.0, s))
                    x += s
                y += s
            # centre vertically
            shift = (1.0 - total_h) / 2.0
            sq = [(cx, cy + shift, a, s) for cx, cy, a, s in sq]
            val = sum(q[3] for q in sq)
            if val > bestval:
                bestval = val
                best = sq[:n]
                while len(best) < n:
                    best.append((0.5, 0.5, 0.0, 0.0))
    if best is None:
        best = _grid(n)
    return best


def _strips(n):
    """horizontal strips of equal-height squares of varying widths"""
    best = None
    bestval = -1.0
    for nrows in range(1, n + 1):
        s = 1.0 / nrows
        cap = 0
        rows = []
        for _ in range(nrows):
            w = int(math.floor(1.0 / s + 1e-9))
            rows.append(w)
            cap += w
        if cap < n:
            continue
        left = n
        sq = []
        y = 0.0
        for r in rows:
            take = min(r, left)
            left -= take
            x = 0.0
            for _ in range(take):
                sq.append((x + 0.5 * s, y + 0.5 * s, 0.0, s))
                x += s
            y += s
            if left == 0:
                break
        if len(sq) < n:
            continue
        val = n * s
        if val > bestval:
            bestval = val
            sq2 = sq[:n]
            while len(sq2) < n:
                sq2.append((0.5, 0.5, 0.0, 0.0))
            best = sq2
    if best is None:
        best = _grid(n)
    return best


def _pinwheel_blocks(n):
    """split unit square into 2x2 or 3x3 cells; put rotated pinwheels in cells"""
    best = None
    bestval = -1.0
    candidates = []

    # 2x2 pinwheel around a central hole (4 rotated squares)
    def pin4(size=1.0, ox=0.0, oy=0.0):
        # place 4 squares rotated by angle a inside an axis box size x size
        # classic pinwheel: side s = size/(cos a + sin a)
        bestp = None
        bp = -1.0
        for a in np.linspace(0.0, 0.5, 201):
            ca, sa = math.cos(math.pi * 2 * a), math.sin(math.pi * 2 * a)
            s = size / (abs(ca) + abs(sa))
            if s <= 0:
                continue
            # place 4 around
            h = s / 2.0
            # centres: along 4 sides of inner rotated square
            arr = []
            ok = True
            # positions: offsets relative to ox,oy
            offs = [(0.5 - h / size * 0, 0.5 - h / size * 0)]  # placeholder
            # easier: use fixed pinwheel layout with parameters
            # each square touches two outer sides
            cx1 = ox + size * 0.5 - h * ca - h * sa
            cy1 = oy + h * ca - h * sa + size * 0.5 - h * ca - h * sa  # messy
            arr = None
            break
        return None

    # Instead: try generic rotated grids (k rotated equal squares)
    for k in range(1, n + 2):
        for ang in np.linspace(0.0, 0.5, 51):
            if ang == 0.0:
                s = 1.0 / k
                ok = True
                sq = []
                for i in range(k):
                    for j in range(k):
                        sq.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                if len(sq) <= n and ok:
                    val = len(sq) * s
                    if val > bestval and len(sq) <= n:
                        bestval = val
                        best = sq
            else:
                # rotation by ang of a k x k grid centered
                ang_r = 2 * math.pi * ang
                ca, sa = math.cos(ang_r), math.sin(ang_r)
                # square side s chosen so rotated outer square fits in unit square
                s = 1.0 / (k * (abs(ca) + abs(sa)))
                # centres of k*k grid, then rotate around centre
                sq = []
                for i in range(k):
                    for j in range(k):
                        x = (i + 0.5) * s - 0.5 * k * s
                        y = (j + 0.5) * s - 0.5 * k * s
                        rx = x * ca - y * sa
                        ry = x * sa + y * ca
                        sq.append((0.5 + rx, 0.5 + ry, ang, s))
                if len(sq) <= n and _valid(sq):
                    val = len(sq) * s
                    if val > bestval:
                        bestval = val
                        best = sq[:]

    if best is None:
        best = _grid(n)
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]


# ---------- refinement ----------

def _score(sq):
    return sum(q[3] for q in sq)


def _refine(sq, n, time_budget=1.0, seed=0):
    """simple stochastic hill climbing on centres/angles/sizes"""
    rng = random.Random(seed)
    sq = [list(q) for q in sq]
    # pad to n
    while len(sq) < n:
        sq.append([0.5, 0.5, 0.0, 0.0])
    sq = sq[:n]

    # repair validity first: shrink overlapping squares
    for _ in range(50):
        bad = False
        for i in range(n):
            for j in range(i + 1, n):
                if _overlap(i, j, [tuple(q) for q in sq]):
                    # shrink both
                    si = sq[i][3]
                    sj = sq[j][3]
                    if si >= sj:
                        sq[i][3] *= 0.9
                    else:
                        sq[j][3] *= 0.9
                    bad = True
        if not bad:
            break

    best = [q[:] for q in sq]
    bestv = _score(best)

    # local random search
    steps = 0
    max_steps = 4000
    temp0 = 0.02
    for step in range(max_steps):
        i = rng.randrange(n)
        q = sq[i][:]
        mode = rng.randrange(3)
        if mode == 0:
            q[0] += rng.gauss(0, 0.005)
            q[1] += rng.gauss(0, 0.005)
        elif mode == 1:
            q[2] += rng.gauss(0, 0.005)
            q[2] %= 1.0
        else:
            q[3] += rng.gauss(0, 0.01)
            if q[3] < 0:
                q[3] = 0.0
        if q[3] > 1.0:
            q[3] = 1.0
        old = sq[i][:]
        sq[i] = q
        # validate affected pair
        good = _inside(q[0], q[1], q[2], q[3])
        if good:
            for j in range(n):
                if j != i and _overlap(i, j, [tuple(x) for x in sq]):
                    good = False
                    break
        if good:
            v = _score(sq)
            if v >= bestv - 1e-12 or rng.random() < 0.01:
                if v > bestv:
                    bestv = v
                    best = [x[:] for x in sq]
            else:
                sq[i] = old
        else:
            sq[i] = old

    return [tuple(q) for q in best]


# ---------- main solver ----------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    candidates = []
    # a few analytic/seeded constructions
    try:
        candidates.append(_grid(n))
    except Exception:
        pass
    try:
        candidates.append(_strips(n))
    except Exception:
        pass
    try:
        candidates.append(_grid_extra(n))
    except Exception:
        pass
    try:
        candidates.append(_pinwheel_blocks(n))
    except Exception:
        pass

    # relaxed rows / columns
    try:
        # try equal squares of slightly reduced size arranged in k columns
        for k in range(1, n + 2):
            s = 1.0 / k
            cols = int(1.0 / s + 1e-9)
            rows = max(1, math.ceil(n / cols))
            if rows * s > 1.0 + 1e-12:
                continue
            sq = []
            cnt = 0
            y = (1.0 - rows * s) / 2.0
            for r in range(rows):
                x = (1.0 - min(cols, n - cnt) * s) / 2.0
                for _ in range(min(cols, n - cnt)):
                    sq.append((x + 0.5 * s, y + 0.5 * s, 0.0, s))
                    x += s
                    cnt += 1
                y += s
                if cnt >= n:
                    break
            while len(sq) < n:
                sq.append((0.5, 0.5, 0.0, 0.0))
            if _valid(sq):
                candidates.append(sq[:n])
    except Exception:
        pass

    # refine each candidate a little
    best = None
    bestv = -1.0
    for idx, c in enumerate(candidates):
        if c is None:
            continue
        c = [tuple(x) for x in c]
        if len(c) < n:
            c += [(0.5, 0.5, 0.0, 0.0)] * (n - len(c))
        c = c[:n]
        if not _valid(c):
            # repair by shrinking all
            c = [(x[0], x[1], x[2], min(1.0 / max(1, math.isqrt(n)) * 1.5, max(0.0, x[3] * 0.98))) for x in c]
            for _ in range(20):
                if _valid(c):
                    break
                # shrink offending squares
                c2 = [list(x) for x in c]
                for i in range(n):
                    for j in range(i + 1, n):
                        if _overlap(i, j, [tuple(q) for q in c2]):
                            if c2[i][3] >= c2[j][3]:
                                c2[i][3] *= 0.9
                            else:
                                c2[j][3] *= 0.9
                c = [tuple(x) for x in c2]
            if not _valid(c):
                continue
        v = _score(c)
        if v > bestv:
            bestv = v
            best = c
        # local refinement
        rc = _refine(c, n, seed=idx)
        if _valid(rc):
            rv = _score(rc)
            if rv > bestv:
                bestv = rv
                best = rc

    if best is None:
        best = _grid(n)

    # final safety: ensure exactly n and valid
    best = [tuple(x) for x in best[:n]]
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    if not _valid(best):
        # fall back
        best = _grid(n)

    # clip tiny numerical issues
    out = []
    for cx, cy, a, s in best:
        cx = min(1.0, max(0.0, float(cx)))
        cy = min(1.0, max(0.0, float(cy)))
        a = float(a) % 1.0
        s = float(s)
        if s < 0:
            s = 0.0
        if not _inside(cx, cy, a, s):
            s = 0.0
        out.append((cx, cy, a, s))
    if not _valid(out):
        return _grid(n)
    return out
