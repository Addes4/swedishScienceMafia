import math
import random
import numpy as np
from scipy.optimize import minimize


def _square_corners(cx, cy, ang, s):
    """Corners of a square with center (cx, cy), angle as fraction of full turn, side s."""
    if s <= 0.0:
        return [(cx, cy)] * 4
    t = 2.0 * math.pi * ang
    c, sn = math.cos(t), math.sin(t)
    h = 0.5 * s
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _axes(pts):
    """Unit outward normals for the four edges of a convex quadrilateral."""
    axes = []
    for i in range(4):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % 4]
        ex, ey = x2 - x1, y2 - y1
        L = math.hypot(ex, ey)
        if L < 1e-15:
            continue
        # normal
        nx, ny = ey / L, -ex / L
        # make outward-ish: center of polygon
        cx = sum(p[0] for p in pts) / 4.0
        cy = sum(p[1] for p in pts) / 4.0
        mx = (x1 + x2) * 0.5
        my = (y1 + y2) * 0.5
        if nx * (mx - cx) + ny * (my - cy) < 0:
            nx, ny = -nx, -ny
        axes.append((nx, ny))
    return axes


def _overlap_constraints(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """Return list of scalar constraint values >=0 required for non-overlap (separating axis)."""
    if s1 <= 1e-14 or s2 <= 1e-14:
        return [1.0]
    p1 = _square_corners(cx1, cy1, a1, s1)
    p2 = _square_corners(cx2, cy2, a2, s2)
    axes = _axes(p1) + _axes(p2)
    cons = []
    for nx, ny in axes:
        # projections
        proj1 = [nx * x + ny * y for x, y in p1]
        proj2 = [nx * x + ny * y for x, y in p2]
        gap = max(min(proj1), min(proj2)) - max(max(proj1), max(proj2))
        # if gap>=0 separated. We'll use constraints maxproj1 <= minproj2 or vice versa
        # constraint: not overlapping along this axis => max1 <= min2 OR max2 <= min1
        # approximate with: max(min1,max2?) Hmm nonlinear OR. Use product <=0 form via min of two gaps.
        g1 = min(proj2) - max(proj1)  # >=0 means 1 left of 2
        g2 = min(proj1) - max(proj2)  # >=0 means 2 left of 1
        cons.append(max(g1, g2))
    # require at least one axis fully separated? Actually SAT needs one separating axis.
    # Using max over axes of per-axis OR gap is non-smooth; we instead require for each axis either side:
    # We'll build a smooth proxy: sum of all gaps positive is sufficient? No, necessary is one.
    # Better: return all per-axis max(g1,g2) and use smooth min? For SLSQP we need constraints c>=0.
    # A valid sufficient condition is: min over axes of max(g1,g2) >= 0? That's the SAT exact condition.
    return [min(cons)]


def _make_x(squares):
    x = []
    for cx, cy, a, s in squares:
        x.extend([cx, cy, a, s])
    return np.array(x, dtype=float)


def _decode(x):
    n = len(x) // 4
    return [(x[4 * i], x[4 * i + 1], x[4 * i + 2], x[4 * i + 3]) for i in range(n)]


def _objective(x):
    s = x[3::4]
    return -float(np.sum(s))


def _constraints_all(x_nodes):
    n = len(x_nodes) // 4
    cons = []

    # containment: center plus rotated half-extents stays in [0,1]
    # corners in unit square
    for i in range(n):
        cx, cy, a, s = x_nodes[4 * i:4 * i + 4]
        if s <= 0:
            continue
        pts = _square_corners(cx, cy, a, s)
        for px, py in pts:
            cons.append(px)
            cons.append(1.0 - px)
            cons.append(py)
            cons.append(1.0 - py)

    # non-overlap
    for i in range(n):
        cxi, cyi, ai, si = x_nodes[4 * i:4 * i + 4]
        for j in range(i + 1, n):
            cxj, cyj, aj, sj = x_nodes[4 * j:4 * j + 4]
            if si <= 1e-14 or sj <= 1e-14:
                continue
            g = _overlap_constraints(cxi, cyi, ai, si, cxj, cyj, aj, sj)[0]
            cons.append(g)
    return np.array(cons, dtype=float)


def _constraint_fun(x):
    # scipy wants c(x) >= 0
    return _constraints_all(x)


def _initial_grid(n):
    """Good initial packings for various n."""
    best = None
    best_score = -1.0

    # Try k x k grids with k from isqrt(n) down
    k0 = math.isqrt(n)
    for k in range(max(1, k0 - 1), k0 + 1):
        if k * k > n:
            continue
        side = 1.0 / k
        sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
              for i in range(k) for j in range(k)]
        # fill remaining with tiny squares greedily in gaps maybe zero
        rem = n - len(sq)
        if rem > 0:
            # add small squares in centers
            for t in range(rem):
                sq.append((0.5, 0.5, 0.0, 0.0))
        sc = sum(s[3] for s in sq)
        if sc > best_score:
            best_score = sc
            best = sq

    # Try grid of rows/cols that fit n with possibly larger cells
    # Use different aspect patterns: distribute into rows as evenly as possible
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        if rows * cols > n + cols + 1:
            continue
        # fit rows*cols grid using max cell that fits with rows and cols constraints
        # cell side <= 1/cols and <= 1/rows
        side = min(1.0 / cols, 1.0 / rows)
        if side <= 0:
            continue
        sq = []
        # center the rows x cols block
        total_w = cols * side
        total_h = rows * side
        ox = (1.0 - total_w) * 0.5
        oy = (1.0 - total_h) * 0.5
        for i in range(rows):
            for j in range(cols):
                if len(sq) >= n:
                    break
                sq.append((ox + (j + 0.5) * side, oy + (i + 0.5) * side, 0.0, side))
            if len(sq) >= n:
                break
        while len(sq) < n:
            sq.append((0.5, 0.5, 0.0, 0.0))
        sc = sum(s[3] for s in sq)
        if sc > best_score:
            best_score = sc
            best = sq

    return best


def _random_perturb(squares, mag):
    out = []
    for cx, cy, a, s in squares:
        ncx = min(1.0, max(0.0, cx + random.uniform(-mag, mag)))
        ncy = min(1.0, max(0.0, cy + random.uniform(-mag, mag)))
        na = a + random.uniform(-mag, mag)
        ns = max(0.0, min(1.0, s + random.uniform(-mag, mag) * s))
        out.append((ncx, ncy, na, ns))
    return out


def _optimize(squares, maxiter=80):
    x0 = _make_x(squares)
    bounds = []
    for i in range(len(squares)):
        bounds.append((0.0, 1.0))  # cx
        bounds.append((0.0, 1.0))  # cy
        bounds.append((-2.0, 2.0))  # angle
        bounds.append((0.0, 1.0))  # side

    try:
        res = minimize(
            _objective,
            x0,
            method='SLSQP',
            bounds=bounds,
            constraints={'type': 'ineq', 'fun': _constraint_fun},
            options={'maxiter': maxiter, 'ftol': 1e-9, 'disp': False},
        )
        xs = res.x
    except Exception:
        xs = x0

    # clean tiny negative sides
    out = _decode(xs)
    cleaned = []
    for cx, cy, a, s in out:
        if s < 0:
            s = 0.0
        cleaned.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), a % 1.0, s))

    # final repair: ensure no overlap via simple fallback
    return cleaned


def _sum(squares):
    return sum(s[3] for s in squares)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side 0.5 each
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    base = _initial_grid(n)

    # attempt optimization with multiple restarts, but keep runtime bounded
    best = base
    best_sc = _sum(base)

    # candidate: optimize base
    cand = _optimize(base, maxiter=120)
    sc = _sum(cand)
    if sc > best_sc:
        best = cand
        best_sc = sc

    # few restarts with perturbation
    tries = 3 if n <= 25 else 2
    for t in range(tries):
        mag = 0.18 if t == 0 else 0.08
        psq = _random_perturb(best if best_sc > 0 else base, mag)
        cand = _optimize(psq, maxiter=80)
        sc = _sum(cand)
        if sc > best_sc:
            best = cand
            best_sc = sc

    # verify/fix: simple greedy repair if overlaps happen (rare after optimizer)
    fixed = _repair(best)
    if _sum(fixed) > best_sc - 1e-9:
        # re-opt small
        fixed2 = _optimize(fixed, maxiter=40)
        if _sum(fixed2) > _sum(fixed):
            fixed = fixed2

    # ensure exactly n squares
    res = list(fixed)
    if len(res) > n:
        res = sorted(res, key=lambda t: -t[3])[:n]
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]


def _overlap_pair(sq1, sq2):
    s1 = sq1[3]
    s2 = sq2[3]
    if s1 <= 1e-12 or s2 <= 1e-12:
        return False
    return _overlap_constraints(sq1[0], sq1[1], sq1[2], s1, sq2[0], sq2[1], sq2[2], s2)[0] < 0


def _repair(squares):
    """Ensure feasibility: shrink overlapping squares slightly."""
    sq = [list(t) for t in squares]
    n = len(sq)
    for _ in range(20):
        any_over = False
        for i in range(n):
            for j in range(i + 1, n):
                if _overlap_pair(sq[i], sq[j]):
                    any_over = True
                    # shrink both
                    sq[i][3] *= 0.97
                    sq[j][3] *= 0.97
        if not any_over:
            break
        # also clamp containment
        for i in range(n):
            cx, cy, a, s = sq[i]
            sq[i][3] = min(s, 1.0 / math.sqrt(2) if s > 0 else 0)
    # clamp final
    out = []
    for cx, cy, a, s in sq:
        s = max(0.0, min(1.0, s))
        cx = max(s * 0.5, min(1.0 - s * 0.5, cx))
        cy = max(s * 0.5, min(1.0 - s * 0.5, cy))
        out.append((cx, cy, a, s))
    return out
