# EVOLVE-BLOCK-START
"""Packing n non-overlapping squares (possibly rotated) in the unit square,
maximising the sum of side lengths."""

import math
import numpy as np
from scipy.optimize import minimize


def _centers_for(n):
    """Generate an initial set of centers and sizes for n squares."""
    # Try a few structured layouts and pick the best initial guess.
    layouts = []

    # 1. Grid layout: k x k equal squares
    k = math.isqrt(n)
    if k * k > 0:
        side = 1.0 / k
        sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
              for i in range(k) for j in range(k)]
        # remaining squares as tiny ones placed in the corners of cells
        rem = n - k * k
        idx = 0
        for i in range(k):
            for j in range(k):
                if rem <= 0:
                    break
                # place small square in the cell corner
                cx = i * side + side * 0.25
                cy = j * side + side * 0.25
                s = side * 0.35
                sq.append((cx, cy, 0.0, s))
                rem -= 1
            if rem <= 0:
                break
        layouts.append(sq)

    # 2. One large square on the left, grid on the right
    if n >= 4:
        m = n - 1
        kk = math.isqrt(m)
        if kk * kk > 0:
            side = 1.0 / (kk + 1)
            big = side * kk  # big square side
            sq = [(big / 2, 0.5, 0.0, big)]
            for i in range(kk):
                for j in range(kk):
                    cx = big + (i + 0.5) * side
                    cy = (j + 0.5) * side
                    sq.append((cx, cy, 0.0, side))
            # extras
            rem = n - 1 - kk * kk
            if rem > 0:
                for r in range(rem):
                    sq.append((0.5, 0.5, 0.0, 0.0))
            layouts.append(sq[:n])

    # 3. Simple rows layout: k rows of roughly equal size
    k = max(1, int(round(math.sqrt(n))))
    side = 1.0 / k
    # place squares in rows, each row filled
    sq = []
    cnt = 0
    rows = k
    cols = math.ceil(n / rows)
    for j in range(rows):
        for i in range(cols):
            if cnt >= n:
                break
            cx = (i + 0.5) / cols
            cy = (j + 0.5) / rows
            s = min(1.0 / cols, 1.0 / rows)
            sq.append((cx, cy, 0.0, s))
            cnt += 1
    layouts.append(sq)

    # Pick the layout with highest sum of sides as starting point
    best = None
    best_sum = -1
    for sq in layouts:
        if len(sq) < n:
            sq = sq + [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
        sq = sq[:n]
        s = sum(x[3] for x in sq)
        if s > best_sum:
            best_sum = s
            best = sq
    return best


def _decode(x, n):
    """Decode flat parameter vector into list of (cx, cy, angle, side)."""
    arr = x.reshape(n, 4)
    return [(float(arr[i, 0]), float(arr[i, 1]), float(arr[i, 2]), float(arr[i, 3]))
            for i in range(n)]


def _corners(cx, cy, ang, s):
    """Return 4 corner points of a square."""
    # ang as fraction of full turn
    theta = 2 * math.pi * ang
    c = math.cos(theta)
    sn = math.sin(theta)
    h = s / 2
    # corners relative to center before rotation: (-h,-h), (h,-h), (h,h), (-h,h)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        rx = dx * c - dy * sn
        ry = dx * sn + dy * c
        pts.append((cx + rx, cy + ry))
    return pts


def _overlap_penalty(sq, n):
    """Compute total overlap penalty and boundary penalty."""
    total = 0.0
    # Precompute corners for each square
    all_corners = []
    for i in range(n):
        cx, cy, ang, s = sq[i]
        if s <= 1e-12:
            all_corners.append(None)
            continue
        all_corners.append(_corners(cx, cy, ang, s))

    # Boundary penalty: push inside [0,1]^2
    for i in range(n):
        cx, cy, ang, s = sq[i]
        if s <= 1e-12:
            continue
        cs = all_corners[i]
        for (px, py) in cs:
            if px < 0:
                total += 1000 * (0 - px) ** 2
            elif px > 1:
                total += 1000 * (px - 1) ** 2
            if py < 0:
                total += 1000 * (0 - py) ** 2
            elif py > 1:
                total += 1000 * (py - 1) ** 2

    # Overlap penalty between every pair using SAT-like approach for convex polygons
    # For two convex polygons, if no separating axis, they overlap.
    # Use approximate penalty: area of intersection of bounding boxes + corners inside.
    for i in range(n):
        if all_corners[i] is None:
            continue
        for j in range(i + 1, n):
            if all_corners[j] is None:
                continue
            # Use separating axis theorem to find penetration depth
            pen = _polygon_penetration(all_corners[i], all_corners[j])
            if pen > 0:
                total += 5000 * pen ** 2
    return total


def _polygon_penetration(polyA, polyB):
    """Approximate penetration depth between two convex polygons."""
    # If they are far apart (bounding circles), no penetration
    ax = sum(p[0] for p in polyA) / len(polyA)
    ay = sum(p[1] for p in polyA) / len(polyA)
    bx = sum(p[0] for p in polyB) / len(polyB)
    by = sum(p[1] for p in polyB) / len(polyB)
    # approximate radius
    ra = max(math.hypot(p[0]-ax, p[1]-ay) for p in polyA)
    rb = max(math.hypot(p[0]-bx, p[1]-by) for p in polyB)
    d = math.hypot(ax - bx, ay - by)
    if d > ra + rb + 1e-9:
        return 0.0

    # Check separating axes: edges of both polygons and their normals
    axes = []
    for poly in (polyA, polyB):
        m = len(poly)
        for k in range(m):
            p1 = poly[k]
            p2 = poly[(k + 1) % m]
            ex = p2[0] - p1[0]
            ey = p2[1] - p1[1]
            # normal
            nx = -ey
            ny = ex
            ln = math.hypot(nx, ny)
            if ln > 1e-12:
                axes.append((nx / ln, ny / ln))

    min_overlap = float('inf')
    for nx, ny in axes:
        # project both polygons
        pa = [(p[0]*nx + p[1]*ny) for p in polyA]
        pb = [(p[0]*nx + p[1]*ny) for p in polyB]
        amin, amax = min(pa), max(pa)
        bmin, bmax = min(pb), max(pb)
        # overlap on this axis
        overlap = min(amax, bmax) - max(amin, bmin)
        if overlap <= 0:
            return 0.0  # separating axis found
        if overlap < min_overlap:
            min_overlap = overlap
    return min_overlap if min_overlap != float('inf') else 0.0


def _objective(x, n, weight_sum=1.0):
    """Objective: maximise sum of sides - penalties."""
    sq = _decode(x, n)
    s = sum(q[3] for q in sq)
    pen = _overlap_penalty(sq, n)
    # Also keep angles in [0,1)
    ang_pen = 0.0
    for q in sq:
        a = q[2]
        if a < 0:
            ang_pen += 100 * (-a) ** 2
        elif a >= 1:
            ang_pen += 100 * (a - 1) ** 2
    return -s + pen + ang_pen


def _solve_inner(n, init_sq, maxiter=200):
    """Optimize starting from init_sq."""
    x0 = np.array([[q[0], q[1], q[2], q[3]] for q in init_sq], dtype=float).flatten()

    # Bounds: cx,cy in [0,1], angle in [0,1), side in [0,1]
    bounds = []
    for _ in range(n):
        bounds += [(0.0, 1.0), (0.0, 1.0), (0.0, 0.999999), (0.0, 1.0)]

    def func(x):
        return _objective(x, n)

    try:
        res = minimize(func, x0, method='Powell', bounds=bounds,
                       options={'maxiter': maxiter, 'ftol': 1e-8, 'xtol': 1e-8})
        x = res.x
    except Exception:
        x = x0

    return _decode(x, n)


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []

    # Handle small n exactly / near exactly
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # Two squares: best is 1/2 + 1/2 = 1.0 (side by side)
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # 1/2 + 1/2 + 1/2? No: three squares of side 1/2 can't fit (sum would be 1.5).
        # Best known: 1/2 + 1/2 + something? Actually two 1/2 squares fill the bottom half,
        # then top half can hold squares. Max sum for n=3 is ~1.5? Let's check:
        # Standard result: three equal squares max side = 1/3? No, can do 1/2, 1/2, 1/4: sum 1.25.
        # Actually can we do 1/2,1/2,1/2? No. Best is 1.5? No.
        # Known: n=3 max sum = 1.5? Let's try: 0.5+0.5+0.5=1.5 impossible.
        # Known optimal for 3 squares: sum = 1.5? Wait, 3 squares of side 0.5 each:
        # area = 3*0.25=0.75<1 so area allows it. But can they fit? Yes! Put two at bottom
        # (side 0.5) covering [0,0.5]x[0,0.5] and [0.5,1]x[0,0.5]. Remaining top strip is
        # 1 x 0.5, can hold a 0.5 square at center (0.25..0.75, 0.5..1.0). Yes!
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]

    # For larger n, use optimization
    init = _centers_for(n)

    # Multi-start: try the best initial and a few perturbations
    best_sq = init
    best_val = sum(q[3] for q in init if q[3] > 0)

    # First run
    sq_opt = _solve_inner(n, init, maxiter=300)
    val = sum(q[3] for q in sq_opt if q[3] > 0)
    if val > best_val:
        best_val = val
        best_sq = sq_opt

    # Try a few random perturbations of the initial layout for larger n
    import random
    random.seed(42)
    if n >= 4:
        tries = 8 if n <= 20 else 4
        for t in range(tries):
            perturbed = []
            for (cx, cy, ang, s) in init:
                ncx = min(1.0, max(0.0, cx + random.uniform(-0.15, 0.15)))
                ncy = min(1.0, max(0.0, cy + random.uniform(-0.15, 0.15)))
                nang = (ang + random.uniform(-0.1, 0.1)) % 1.0
                ns = min(1.0, max(0.0, s * random.uniform(0.85, 1.15)))
                perturbed.append((ncx, ncy, nang, ns))
            sq_opt = _solve_inner(n, perturbed, maxiter=200)
            val = sum(q[3] for q in sq_opt if q[3] > 0)
            if val > best_val:
                best_val = val
                best_sq = sq_opt

    # Post-process: shrink edges until no overlaps (safety)
    result = []
    for q in best_sq:
        cx, cy, ang, s = q
        # clamp
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = min(0.999999, max(0.0, ang))
        s = min(1.0, max(0.0, s))
        result.append((cx, cy, ang, s))

    # Final validation and minor shrink if needed
    result = _ensure_no_overlap(result, n)

    # ensure exactly n entries
    if len(result) < n:
        result += [(0.5, 0.5, 0.0, 0.0)] * (n - len(result))
    return result[:n]


def _ensure_no_overlap(sq, n):
    """Shrink overlapping squares slightly to guarantee no overlap."""
    sq = [list(q) for q in sq]
    # Iteratively shrink until no overlaps
    for _ in range(50):
        overlap_found = False
        corners = []
        for q in sq:
            cx, cy, ang, s = q
            if s <= 1e-12:
                corners.append(None)
            else:
                corners.append(_corners(cx, cy, ang, s))

        # Check boundary
        for i, q in enumerate(sq):
            if corners[i] is None:
                continue
            for (px, py) in corners[i]:
                if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
                    # shrink a bit and reposition center
                    q[3] *= 0.95
                    q[0] = min(1.0, max(0.0, q[0]))
                    q[1] = min(1.0, max(0.0, q[1]))
                    overlap_found = True
                    break

        # Check pairwise overlap
        for i in range(n):
            if corners[i] is None:
                continue
            for j in range(i + 1, n):
                if corners[j] is None:
                    continue
                pen = _polygon_penetration(corners[i], corners[j])
                if pen > 1e-7:
                    # shrink both
                    sq[i][3] *= 0.92
                    sq[j][3] *= 0.92
                    overlap_found = True
                    # recompute corners
                    if sq[i][3] > 1e-12:
                        corners[i] = _corners(sq[i][0], sq[i][1], sq[i][2], sq[i][3])
                    else:
                        corners[i] = None
                    if sq[j][3] > 1e-12:
                        corners[j] = _corners(sq[j][0], sq[j][1], sq[j][2], sq[j][3])
                    else:
                        corners[j] = None
        if not overlap_found:
            break

    # Final check: if still overlap, shrink to zero
    corners = []
    for q in sq:
        cx, cy, ang, s = q
        if s <= 1e-12:
            corners.append(None)
        else:
            corners.append(_corners(cx, cy, ang, s))
    for i in range(n):
        if corners[i] is None:
            continue
        for j in range(i + 1, n):
            if corners[j] is None:
                continue
            pen = _polygon_penetration(corners[i], corners[j])
            if pen > 1e-6:
                # shrink to zero as last resort
                sq[j][3] = 0.0

    return [(q[0], q[1], q[2], q[3]) for q in sq]
# EVOLVE-BLOCK-END
