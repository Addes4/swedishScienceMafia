import math
import random
from typing import List, Tuple

# ------------------------------------------------------------
# Geometry helpers
# ------------------------------------------------------------

def _corners(cx: float, cy: float, angle: float, side: float) -> List[Tuple[float, float]]:
    a = angle * 2.0 * math.pi
    c, s = math.cos(a), math.sin(a)
    h = side * 0.5
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + x * c - y * s, cy + x * s + y * c) for x, y in pts]


def _inside_unit(pts) -> bool:
    for x, y in pts:
        if x < -1e-10 or x > 1.0 + 1e-10 or y < -1e-10 or y > 1.0 + 1e-10:
            return False
    return True


def _poly_overlap(p1, p2, eps=1e-9) -> bool:
    """Separating axis test for two convex polygons."""
    for poly in (p1, p2):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            # outward normal
            nx, ny = ey, -ex
            # project both polygons
            min1 = min2 = 1e100
            max1 = max2 = -1e100
            for px, py in p1:
                d = px * nx + py * ny
                if d < min1: min1 = d
                if d > max1: max1 = d
            for px, py in p2:
                d = px * nx + py * ny
                if d < min2: min2 = d
                if d > max2: max2 = d
            if max1 < min2 + eps or max2 < min1 + eps:
                return False
    return True


def _valid(squares) -> bool:
    polys = []
    for cx, cy, ang, side in squares:
        if side <= 1e-12:
            polys.append(None)
            continue
        pts = _corners(cx, cy, ang, side)
        if not _inside_unit(pts):
            return False
        polys.append(pts)
    m = len(polys)
    for i in range(m):
        if polys[i] is None:
            continue
        for j in range(i + 1, m):
            if polys[j] is None:
                continue
            if _poly_overlap(polys[i], polys[j]):
                return False
    return True


def _score(squares) -> float:
    return sum(s[3] for s in squares)


# ------------------------------------------------------------
# Initial constructions
# ------------------------------------------------------------

def _grid_init(n: int):
    k = math.isqrt(n)
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
          for i in range(k) for j in range(k)]
    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
    return sq[:n]


def _greedy_place(n: int):
    """Place squares greedily from largest to smallest in free spots."""
    # a few candidate sizes including some rotated diagonal options
    squares = []
    # Start with one large and then recursively use available gaps is complex;
    # use a simple decreasing-size grid guess and repair later.
    return _grid_init(n)


# ------------------------------------------------------------
# Local search
# ------------------------------------------------------------

def _try_move(squares, idx, rng):
    cx, cy, ang, side = squares[idx]
    if side <= 1e-12:
        return False
    # symbolic random perturbation
    step = max(1e-4, side * 0.25) * rng.uniform(0.2, 1.0)
    ncx = cx + rng.uniform(-step, step)
    ncy = cy + rng.uniform(-step, step)
    nang = ang + rng.uniform(-0.15, 0.15)
    # keep inside
    ncx = min(1.0 - side * 0.5, max(side * 0.5, ncx))
    ncy = min(1.0 - side * 0.5, max(side * 0.5, ncy))
    cand = (ncx, ncy, nang, side)
    old = squares[idx]
    squares[idx] = cand
    if _valid(squares):
        return True
    squares[idx] = old
    return False


def _try_resize(squares, idx, rng, best_score):
    cx, cy, ang, side = squares[idx]
    if side <= 1e-12:
        return best_score
    delta = side * rng.uniform(-0.08, 0.18)
    nside = side + delta
    if nside <= 1e-12 or nside > 1.0:
        return best_score
    # reposition slightly so within bounds
    ncx = min(1.0 - nside * 0.5, max(nside * 0.5, cx))
    ncy = min(1.0 - nside * 0.5, max(nside * 0.5, cy))
    cand = (ncx, ncy, ang, nside)
    old = squares[idx]
    squares[idx] = cand
    if _valid(squares):
        ns = _score(squares)
        if ns > best_score + 1e-12:
            return ns
    squares[idx] = old
    return best_score


def _local_search(squares, seconds_limit=45.0, rng=None):
    if rng is None:
        rng = random.Random(12345)
    best = [list(s) for s in squares]
    best_score = _score(best)
    start = __import__('time').time()
    it = 0
    while __import__('time').time() - start < seconds_limit:
        it += 1
        cur = [list(s) for s in best]
        # choose random square
        idx = rng.randrange(len(cur))
        # try move
        _try_move(cur, idx, rng)
        # try resize
        sc = _try_resize(cur, idx, rng, _score(cur))
        if sc > best_score + 1e-12 and _valid(cur):
            best_score = sc
            best = [list(s) for s in cur]
    return [tuple(s) for s in best]


# ------------------------------------------------------------
# Main entry
# ------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # initial guess
    squares = _grid_init(n)
    rng = random.Random(987654321)
    # quick improvement: first make all non-zero squares larger if possible
    squares = _local_search(squares, seconds_limit=8.0, rng=rng)
    # longer search
    squares = _local_search(squares, seconds_limit=45.0, rng=rng)
    # final validity check, fallback to grid if broken
    if not _valid(squares):
        return _grid_init(n)
    return squares
