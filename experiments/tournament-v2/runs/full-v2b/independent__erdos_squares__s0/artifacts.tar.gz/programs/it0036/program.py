import math
import random
import time

def solve(n):
    # 60s limit per n, use adaptive budget
    budget = 5.0 if n <= 12 else 12.0 if n <= 30 else 25.0
    if n <= 1:
        return [(0.5, 0.5, 0.0, 1.0)] if n == 1 else []
    if n == 0:
        return []

    # Perfect square: exact grid is optimal for equal squares filling the unit square
    k = math.isqrt(n)
    if k * k == n:
        s = 1.0 / k
        return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]

    # Otherwise: optimize a row-based packing of axis-aligned squares
    best = _baseline_grid(n)
    best_val = _total(best)

    t0 = time.time()
    # Try several random restarts / configurations
    attempts = 0
    while time.time() - t0 < budget:
        attempts += 1
        cand = _random_row_packing(n)
        cand = _local_improve(cand, time.time() + max(0.2, (budget - (time.time() - t0)) / 8))
        v = _total(cand)
        if v > best_val:
            best_val = v
            best = cand
    return best


def _total(squares):
    return sum(s[3] for s in squares)


def _baseline_grid(n):
    # Grid for largest k*k then leftover as small squares in remaining strip
    k = math.isqrt(n)
    s = 1.0 / k
    res = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
    left = n - k * k
    if left:
        # place leftovers tiny - avoid overlap by making them 0
        res += [(0.5, 0.5, 0.0, 0.0)] * left
    return res[:n]


def _random_row_packing(n):
    # Partition n into rows, each row has squares of equal height
    # Choose number of rows r, then distribute squares among rows
    r = random.randint(1, min(n, max(1, int(math.sqrt(n)) + 2)))
    # random partition of n into r positive parts
    parts = _random_partition(n, r)
    # rows sorted to place tall rows at bottom
    heights = []
    for cnt in parts:
        # row with cnt squares: if squares side h, width each >= h => cnt*h <= 1, h <= 1/cnt
        # if equal squares h = 1/cnt (max)
        heights.append(1.0 / cnt)
    total_h = sum(heights)
    # normalize heights to fit in [0,1]
    if total_h > 1.0:
        scale = 1.0 / total_h
    else:
        scale = 1.0
    res = []
    y = 0.0
    for idx, cnt in enumerate(parts):
        h = heights[idx] * scale
        if h <= 0:
            for _ in range(cnt):
                res.append((0.5, 0.5, 0.0, 0.0))
            continue
        w = 1.0 / cnt if cnt > 0 else 1.0
        # squares of side min(h, w) placed evenly
        sz = min(h, 1.0 / cnt) if cnt > 0 else 0.0
        # maximize: side limited by row height and by width/cnt
        side_x = 1.0 / cnt
        side = min(h, side_x) if False else min(h, side_x)
        # Actually just place squares of side = min(h, side_x) centered in row
        # But we want to maximize sum: use side = min(h, 1/cnt) and span row width
        side = min(h, side_x)
        if side <= 0:
            for _ in range(cnt):
                res.append((0.5, 0.5, 0.0, 0.0))
            continue
        # If squares take full width: cnt*side could be < 1, then center them
        total_w = cnt * side
        x0 = (1.0 - total_w) / 2.0
        for i in range(cnt):
            cx = x0 + (i + 0.5) * side
            cy = y + h / 2.0
            res.append((cx, cy, 0.0, side))
        y += h
    # pad if needed
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]


def _random_partition(n, k):
    # random composition of n into k positive parts
    if k <= 0:
        return []
    if k == 1:
        return [n]
    # choose k-1 cut points
    cuts = sorted(random.sample(range(1, n), k - 1))
    parts = []
    prev = 0
    for c in cuts:
        parts.append(c - prev)
        prev = c
    parts.append(n - prev)
    return parts


def _local_improve(squares, deadline):
    # Iteratively try to increase each square's side while keeping disjoint interiors.
    # We use a greedy approach: sort by current side ascending, try to grow.
    n = len(squares)
    sq = [list(s) for s in squares]
    improved = True
    while time.time() < deadline:
        improved = False
        # try adjusting each square
        order = list(range(n))
        random.shuffle(order)
        for i in order:
            cx, cy, a, side = sq[i]
            if side <= 0:
                # try to find a spot for a tiny square
                spot = _find_spot(sq, i, cx, cy)
                if spot is not None:
                    sq[i] = [spot[0], spot[1], 0.0, spot[2]]
                    improved = True
                continue
            # try growing side
            for factor in (1.05, 1.02, 1.01):
                ns = side * factor
                if ns <= 1.0:
                    if _fits(sq, i, cx, cy, ns):
                        sq[i][3] = ns
                        improved = True
                        side = ns
                        # recenter toward middle opportunistically
                        break
            # try shifting to allow growth
            for _ in range(4):
                dx = random.uniform(-0.02, 0.02)
                dy = random.uniform(-0.02, 0.02)
                ncx = min(max(cx + dx, 0.0), 1.0)
                ncy = min(max(cy + dy, 0.0), 1.0)
                ns = sq[i][3] * 1.02
                if ns <= 1.0 and _fits(sq, i, ncx, ncy, ns):
                    sq[i] = [ncx, ncy, 0.0, ns]
                    cx, cy = ncx, ncy
                    improved = True
        if not improved:
            # random perturbation
            for _ in range(max(1, n // 3)):
                i = random.randrange(n)
                cx, cy, a, side = sq[i]
                if side > 0:
                    sq[i][3] = side * random.uniform(0.9, 0.99)
    return [tuple(s) for s in sq]


def _find_spot(sq, idx, cx, cy):
    # try grid positions to place a tiny square of side up to 0.05
    for _ in range(200):
        x = random.random()
        y = random.random()
        s = random.uniform(0.001, 0.05)
        if _fits(sq, idx, x, y, s):
            return (x, y, s)
    return None


def _fits(sq, idx, cx, cy, side):
    # axis-aligned squares only for this helper
    h = side / 2.0
    if cx - h < -1e-9 or cx + h > 1.0 + 1e-9 or cy - h < -1e-9 or cy + h > 1.0 + 1e-9:
        return False
    for j, s in enumerate(sq):
        if j == idx:
            continue
        ox, oy, oa, os_ = s
        if os_ <= 0:
            continue
        # overlap check for axis-aligned squares (approximate for rotated as bbox)
        oh = os_ / 2.0 * 1.0
        # treat as axis-aligned bounding box
        bbox = oh
        if abs(oa) > 1e-9:
            # rotated square bbox half-extent
            bbox = (abs(math.cos(2*math.pi*oa)) + abs(math.sin(2*math.pi*oa))) * oh
        if abs(cx - ox) < h + bbox - 1e-9 and abs(cy - oy) < h + bbox - 1e-9:
            return False
    return True
