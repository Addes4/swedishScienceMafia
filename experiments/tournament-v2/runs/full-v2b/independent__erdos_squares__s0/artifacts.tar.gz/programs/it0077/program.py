"""Squares in a unit square: greedy placement plus local optimisation."""
import math
import random
import numpy as np

# ---------------------------------------------------------------------------
# geometry helpers
# ---------------------------------------------------------------------------

def _corners(cx, cy, ang, s):
    """Return the four corners (x, y) of a square (fractional turns)."""
    t = 2.0 * math.pi * ang
    c, sn = math.cos(t), math.sin(t)
    h = 0.5 * s
    ux, uy = c * h, sn * h
    vx, vy = -sn * h, c * h
    return ((cx - ux - vx, cy - uy - vy),
            (cx + ux - vx, cy + uy - vy),
            (cx + ux + vx, cy + uy + vy),
            (cx - ux + vx, cy - uy + vy))


def _project(poly, ax, ay):
    """Min/max projection of polygon onto direction (ax, ay)."""
    d = [px * ax + py * ay for px, py in poly]
    return min(d), max(d)


def _overlap(p1, p2):
    """True if two convex polygons overlap in interior."""
    for a, b in ((p1, p2), (p2, p1)):
        n = len(a)
        for i in range(n):
            x1, y1 = a[i]
            x2, y2 = a[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            ax, ay = -ey, ex
            lo1, hi1 = _project(a, ax, ay)
            lo2, hi2 = _project(b, ax, ay)
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return False
    return True


def _inside_unit(poly):
    for x, y in poly:
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _fits(poly, others):
    if not _inside_unit(poly):
        return False
    for o in others:
        if _overlap(poly, o):
            return False
    return True


# ---------------------------------------------------------------------------
# greedy construction
# ---------------------------------------------------------------------------

def _place_one(others, s, rng, tries=48):
    """Try to place a square of side s somewhere.  Return (cx,cy,ang) or None."""
    if s <= 0:
        return (0.5, 0.5, 0.0)
    h = 0.5 * s
    # Candidate centres: uniform grid + random + corners of existing polygons
    cands = []
    g = 7
    for i in range(g + 1):
        for j in range(g + 1):
            cands.append((i / g, j / g))
    for _ in range(tries):
        cands.append((rng.random(), rng.random()))
    for o in others:
        for x, y in o:
            cands.append((x, y))
            cands.append((x + 1e-6, y + 1e-6))
    # clamp into feasible region
    cl = []
    for x, y in cands:
        cl.append((min(max(x, h), 1.0 - h), min(max(y, h), 1.0 - h)))
    # prefer candidates far from walls -- sort by distance to centre?  Just shuffle.
    rng.shuffle(cl)
    best = None
    for cx, cy in cl:
        for ang in (0.0, 0.25, rng.random()):
            poly = _corners(cx, cy, ang, s)
            if _fits(poly, others):
                return (cx, cy, ang)
    # relax size a bit
    for scale in (0.98, 0.95, 0.9, 0.85, 0.8):
        ss = s * scale
        hh = 0.5 * ss
        for _ in range(24):
            cx = rng.random() * (1 - 2 * hh) + hh
            cy = rng.random() * (1 - 2 * hh) + hh
            ang = rng.random()
            poly = _corners(cx, cy, ang, ss)
            if _fits(poly, others):
                return (cx, cy, ang)
    return None


def _greedy(n, rng):
    """Greedy by decreasing side length."""
    # initial side length guess
    s0 = 1.0
    polys = []
    params = []
    # first square nearly fills
    params.append((0.5, 0.5, 0.0, 1.0))
    polys.append(_corners(0.5, 0.5, 0.0, 1.0))
    for k in range(1, n):
        s = s0
        placed = None
        while s > 1e-4 and placed is None:
            placed = _place_one(polys, s, rng)
            if placed is None:
                s *= 0.85
        if placed is None:
            params.append((0.5, 0.5, 0.0, 0.0))
            polys.append(_corners(0.5, 0.5, 0.0, 0.0))
        else:
            cx, cy, ang = placed
            params.append((cx, cy, ang, s))
            polys.append(_corners(cx, cy, ang, s))
    return params, polys


# ---------------------------------------------------------------------------
# local optimisation
# ---------------------------------------------------------------------------

def _score(params):
    return sum(p[3] for p in params)


def _feasible(params):
    polys = [_corners(*p) for p in params]
    for i in range(len(polys)):
        if not _inside_unit(polys[i]):
            return False
        for j in range(i + 1, len(polys)):
            if _overlap(polys[i], polys[j]):
                return False
    return True


def _relax(params, rng, iters=400):
    """Coordinate descent on centres and angles (side lengths held or grown slowly)."""
    cur = [list(p) for p in params]
    if not _feasible([tuple(p) for p in cur]):
        # fall back: zeros
        cur = [[0.5, 0.5, 0.0, 0.0] for _ in params]
    best_score = _score([tuple(p) for p in cur])
    step = 0.08
    for it in range(iters):
        improved = False
        for i in range(len(cur)):
            for dim in range(3):
                for delta in (step, -step):
                    old = cur[i][dim]
                    cur[i][dim] = old + delta
                    if dim < 2:
                        cur[i][dim] = min(max(cur[i][dim], 0.0), 1.0)
                    if _feasible([tuple(p) for p in cur]):
                        improved = True
                        break
                    else:
                        cur[i][dim] = old
                if improved:
                    break
            # try to grow side a bit
            for ger in (0.02, -0.01):
                old = cur[i][3]
                cur[i][3] = max(0.0, old + ger)
                if _feasible([tuple(p) for p in cur]):
                    improved = True
                    break
                cur[i][3] = old
        if not improved:
            step *= 0.6
            if step < 1e-4:
                break
    return [tuple(p) for p in cur]


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    rng = random.Random(12345 + n)
    params, _ = _greedy(n, rng)
    params = _relax(params, rng, iters=250)

    # ensure exactly n, pad with zero-size squares
    while len(params) < n:
        params.append((0.5, 0.5, 0.0, 0.0))

    # final validation / repair: any infeasible -> set to zero, then try refill
    polys = [_corners(*p) for p in params]
    for i in range(n):
        ok = _inside_unit(polys[i])
        if ok:
            for j in range(i):
                if _overlap(polys[i], polys[j]):
                    ok = False
                    break
        if not ok:
            params[i] = (0.5, 0.5, 0.0, 0.0)
            polys[i] = _corners(0.5, 0.5, 0.0, 0.0)

    # refill zeros
    for i in range(n):
        if params[i][3] <= 0:
            others = [polys[j] for j in range(n) if j != i and params[j][3] > 0]
            s = 0.5
            got = None
            while s > 1e-5 and got is None:
                got = _place_one(others, s, rng, tries=8)
                if got is None:
                    s *= 0.8
            if got is not None:
                cx, cy, ang = got
                params[i] = (cx, cy, ang, s)
                polys[i] = _corners(cx, cy, ang, s)

    return [tuple(p) for p in params[:n]]
