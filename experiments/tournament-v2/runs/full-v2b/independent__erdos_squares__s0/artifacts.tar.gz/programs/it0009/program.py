import math
import numpy as np
from scipy.optimize import minimize


def _sep_axes(a):
    c, s = math.cos(2 * math.pi * a), math.sin(2 * math.pi * a)
    return [(c, s), (-s, c)]


def _projections(cx, cy, a, side):
    """Return (u_axis, v_axis, half_extent_u, half_extent_v) for a square."""
    axes = _sep_axes(a)
    (ux, uy), (vx, vy) = axes
    h = 0.5 * side
    return (ux, uy, h, h), (vx, vy, h, h)


def _inside_ok_simple(cx, cy, side, a):
    """Quick necessary check that square fits in [0,1]^2 (axis aligned bound)."""
    r = side * (abs(math.cos(2 * math.pi * a)) + abs(math.sin(2 * math.pi * a))) * 0.5
    return (cx - r >= -1e-9) and (cx + r <= 1 + 1e-9) and (cy - r >= -1e-9) and (cy + r <= 1 + 1e-9)


def _overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """True if interiors of two squares overlap (SAT). Uses 4 candidate axes."""
    for ax, ay in _sep_axes(a1) + _sep_axes(a2):
        p1 = 0.5 * s1 * (abs(ax * math.cos(2 * math.pi * a1) + ay * math.sin(2 * math.pi * a1)) +
                         abs(ax * -math.sin(2 * math.pi * a1) + ay * math.cos(2 * math.pi * a1)))
        p2 = 0.5 * s2 * (abs(ax * math.cos(2 * math.pi * a2) + ay * math.sin(2 * math.pi * a2)) +
                         abs(ax * -math.sin(2 * math.pi * a2) + ay * math.cos(2 * math.pi * a2)))
        d = abs((cx1 - cx2) * ax + (cy1 - cy2) * ay)
        if d >= p1 + p2 - 1e-12:
            return False
    return True


def _sat_penalty(x, n):
    """Penalty for overlap and out-of-bounds for variables x = [cx,cy,angle,side]*n (side >= 0)."""
    p = 0.0
    for i in range(n):
        xi = x[4 * i:4 * i + 4]
        cx, cy, a, s = xi[0], xi[1], xi[2], xi[3]
        if s < 0:
            p += 1e6 * s * s
        # bounding constraints: use corner extents
        ca, sa = math.cos(2 * math.pi * a), math.sin(2 * math.pi * a)
        ex = 0.5 * s * (abs(ca) + abs(sa))
        if cx - ex < 0:
            p += (ex - cx) ** 2 * 1000
        if cx + ex > 1:
            p += (cx + ex - 1) ** 2 * 1000
        if cy - ex < 0:
            p += (ex - cy) ** 2 * 1000
        if cy + ex > 1:
            p += (cy + ex - 1) ** 2 * 1000
    for i in range(n):
        cxi, cyi, ai, si = x[4 * i:4 * i + 4]
        if si <= 1e-12:
            continue
        for j in range(i + 1, n):
            cxj, cyj, aj, sj = x[4 * j:4 * j + 4]
            if sj <= 1e-12:
                continue
            # axis-aligned bound circles quick reject
            if abs(cxi - cxj) > 0.5 * (si + sj) + 1e-9 or abs(cyi - cyj) > 0.5 * (si + sj) + 1e-9:
                continue
            if _overlap(cxi, cyi, ai, si, cxj, cyj, aj, sj):
                # intersection depth approximation via axis-aligned overlap
                ox = 0.5 * (si + sj) - abs(cxi - cxj)
                oy = 0.5 * (si + sj) - abs(cyi - cyj)
                p += 1000 * max(0.0, ox) * max(0.0, oy)
                p += 10000 * max(0.0, ox) ** 2 + 10000 * max(0.0, oy) ** 2
    return p


def _guillotine_init(n):
    """Recursive guillotine subdivision, balancing area of squares."""
    squares = []

    def rec(x, y, w, h):
        nonlocal squares
        if len(squares) >= n:
            return
        # split along longer side roughly proportional to count
        pass

    return squares


def _grid_layout(n, rotate=0.0):
    k = int(math.isqrt(n))
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            out.append(((i + 0.5) * side, (j + 0.5) * side, rotate, side))
    return out[:n]


def _best_of_layouts(n):
    """Try a few structured initial layouts and return best by side-sum feasibility score."""
    cands = []
    # plain grid
    k = int(math.isqrt(n))
    if k >= 1:
        s = 1.0 / k
        out = []
        for i in range(k):
            for j in range(k):
                out.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        cands.append(out)
        # rotated grid
        for ang in (0.05, 0.1, 0.125, 0.2, 0.25):
            out2 = []
            for i in range(k):
                for j in range(k):
                    out2.append(((i + 0.5) * s, (j + 0.5) * s, ang, s))
            cands.append(out2)
    # vertical strips: n squares side by side in rows
    for rows in range(1, int(math.sqrt(n)) + 3):
        cols = (n + rows - 1) // rows
        if rows * cols < n:
            continue
        sw = 1.0 / cols
        sh = 1.0 / rows
        side = min(sw, sh)
        out = []
        for r in range(rows):
            for c in range(cols):
                if len(out) >= n:
                    break
                out.append((sw * (c + 0.5), sh * (r + 0.5), 0.0, side))
        if len(out) == n:
            cands.append(out)
    # guillotine 2-level: split into two rectangles with k1,k2 squares
    def rec_fill(x0, y0, w, h, count, out):
        if count <= 0:
            return
        if count == 1:
            side = min(w, h)
            out.append((x0 + 0.5 * w, y0 + 0.5 * h, 0.0, side))
            return
        # split vertical if w > h
        if w >= h:
            # allocate by area proportional
            c1 = max(1, min(count - 1, int(round(count * w / (w + h) + 0.0))))
            r1 = w * c1 / count
            rec_fill(x0, y0, r1, h, c1, out)
            rec_fill(x0 + r1, y0, w - r1, h, count - c1, out)
        else:
            c1 = max(1, min(count - 1, int(round(count * h / (w + h) + 0.0))))
            r1 = h * c1 / count
            rec_fill(x0, y0, w, r1, c1, out)
            rec_fill(x0, y0 + r1, w, h - r1, count - c1, out)

    from itertools import islice
    out = []
    rec_fill(0.0, 0.0, 1.0, 1.0, n, out)
    if len(out) == n:
        cands.append(out)

    # choose best candidate by side sum and feasibility
    best = None
    best_score = -1
    for c in cands:
        if len(c) != n:
            continue
        # fix non-fitting by shrinking
        fixed = []
        ok = True
        for (cx, cy, a, s) in c:
            while True:
                ca, sa = math.cos(2 * math.pi * a), math.sin(2 * math.pi * a)
                ex = 0.5 * s * (abs(ca) + abs(sa))
                if cx - ex >= -1e-12 and cx + ex <= 1 + 1e-12 and cy - ex >= -1e-12 and cy + ex <= 1 + 1e-12:
                    break
                s *= 0.9
                if s < 1e-14:
                    break
            fixed.append((cx, cy, a, s))
        c = fixed
        # resolve overlap by shrinking greedily
        for i in range(n):
            for j in range(i + 1, n):
                cxi, cyi, ai, si = c[i]
                cxj, cyj, aj, sj = c[j]
                if si <= 0 or sj <= 0:
                    continue
                if _overlap(cxi, cyi, ai, si, cxj, cyj, aj, sj):
                    # shrink both a bit
                    si2 = si * 0.92
                    sj2 = sj * 0.92
                    if si2 <= sj2:
                        c[i] = (cxi, cyi, ai, si2)
                    else:
                        c[j] = (cxj, cyj, aj, sj2)
        total = sum(s for (_, _, _, s) in c)
        if total > best_score:
            best_score = total
            best = c
    return best


def _pack_from_init(n, init):
    """Optimize starting from init using SLSQP on all coords and sides."""
    x0 = []
    for (cx, cy, a, s) in init:
        x0.extend([cx, cy, a, s])
    x0 = np.array(x0, dtype=float)

    def neg_obj(x):
        return -np.sum(x[3::4])

    # Constraints: non-overlap via pairwise SAT, bounds. Use inexact penalized SLSQP with bounds.
    def cons_fun(x):
        cons = []
        for i in range(n):
            cxi, cyi, ai, si = x[4 * i:4 * i + 4]
            ca, sa = math.cos(2 * math.pi * ai), math.sin(2 * math.pi * ai)
            ex = 0.5 * si * (abs(ca) + abs(sa))
            cons.append(cxi - ex)
            cons.append(1 - (cxi + ex))
            cons.append(cyi - ex)
            cons.append(1 - (cyi + ex))
            cons.append(si)
        for i in range(n):
            cxi, cyi, ai, si = x[4 * i:4 * i + 4]
            if si <= 0:
                continue
            for j in range(i + 1, n):
                cxj, cyj, aj, sj = x[4 * j:4 * j + 4]
                if sj <= 0:
                    continue
                # max overlap: 0 means disjoint
                over = 0.0
                for ax, ay in _sep_axes(ai) + _sep_axes(aj):
                    p1 = 0.5 * si * (abs(ax * math.cos(2 * math.pi * ai) + ay * math.sin(2 * math.pi * ai)) +
                                     abs(ax * -math.sin(2 * math.pi * ai) + ay * math.cos(2 * math.pi * ai)))
                    p2 = 0.5 * sj * (abs(ax * math.cos(2 * math.pi * aj) + ay * math.sin(2 * math.pi * aj)) +
                                     abs(ax * -math.sin(2 * math.pi * aj) + ay * math.cos(2 * math.pi * aj)))
                    d = (cxi - cxj) * ax + (cyi - cyj) * ay
                    over = max(over, p1 + p2 - abs(d))
                cons.append(-over)
        return np.array(cons)

    bounds = [(0.0, 1.0), (0.0, 1.0), (None, None), (0.0, 1.0)] * n
    # small bounds for angle: keep near init to preserve structure
    bounds = [(0.0, 1.0), (0.0, 1.0), (0.0, 0.5), (0.0, 1.0)] * n
    try:
        res = minimize(neg_obj, x0, method='SLSQP', bounds=bounds,
                       constraints={'type': 'ineq', 'fun': cons_fun},
                       options={'maxiter': 200, 'ftol': 1e-12})
    except Exception:
        res = None
    if res is not None and res.success:
        x = res.x
    else:
        # fall back: local penalty search
        best = x0.copy()
        bestp = _sat_penalty(x0, n)
        step = 0.05
        rng = np.random.default_rng(0)
        for it in range(200):
            cand = best + rng.normal(0, step, size=best.shape)
            cand[3::4] = np.clip(cand[3::4], 0, 1)
            cand[0::4] = np.clip(cand[0::4], 0, 1)
            cand[1::4] = np.clip(cand[1::4], 0, 1)
            cand[2::4] = np.clip(cand[2::4], 0, 0.5)
            candp = _sat_penalty(cand, n)
            if candp < bestp:
                best = cand
                bestp = candp
                step *= 1.05
            else:
                step *= 0.95
        x = best
    out = []
    for i in range(n):
        cx, cy, a, s = x[4 * i:4 * i + 4]
        out.append((float(cx), float(cy), float(a % 1.0), float(max(0.0, s))))
    return out


def _polish(sq, n):
    """Post-process: resolve any overlaps by shrinking sides of offenders."""
    sq = [list(t) for t in sq]
    for _ in range(50):
        changed = False
        for i in range(n):
            cxi, cyi, ai, si = sq[i]
            if si <= 0:
                continue
            for j in range(i + 1, n):
                cxj, cyj, aj, sj = sq[j]
                if sj <= 0:
                    continue
                if _overlap(cxi, cyi, ai, si, cxj, cyj, aj, sj):
                    # shrink the smaller of pair
                    if si <= sj:
                        sq[i][3] = si * 0.9
                        si = sq[i][3]
                    else:
                        sq[j][3] = sj * 0.9
                        sj = sq[j][3]
                    changed = True
        # bounds fix
        for i in range(n):
            cx, cy, a, s = sq[i]
            while True:
                ca, sa = math.cos(2 * math.pi * a), math.sin(2 * math.pi * a)
                ex = 0.5 * s * (abs(ca) + abs(sa))
                if cx - ex >= -1e-12 and cx + ex <= 1 + 1e-12 and cy - ex >= -1e-12 and cy + ex <= 1 + 1e-12:
                    break
                if s < 1e-15:
                    s = 0.0
                    break
                s *= 0.9
                sq[i][3] = s
        if not changed:
            break
    return [(float(cx), float(cy), float(a), float(max(0.0, s))) for (cx, cy, a, s) in sq]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    init = _best_of_layouts(n)
    if init is None or len(init) != n:
        k = int(math.isqrt(n))
        s = 1.0 / max(1, k)
        init = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
        init += [(0.5, 0.5, 0.0, 0.0)] * (n - len(init))
        init = init[:n]

    # For very large n, SLSQP is too slow; use structured + polish only
    if n <= 40:
        try:
            opt = _pack_from_init(n, init)
            polished = _polish(opt, n)
            # choose better of init-polished and opt-polished by total side
            pin = _polish(init, n)
            ti = sum(t[3] for t in pin)
            to = sum(t[3] for t in polished)
            return polished if to >= ti else pin
        except Exception:
            return _polish(init, n)
    else:
        return _polish(init, n)
