import math
import random
import numpy as np
from scipy.optimize import minimize


def _disjoint_ratio(squares, eps=1e-9):
    """Return True if interiors of all squares are disjoint."""
    a = []
    for cx, cy, ang, s in squares:
        if s <= 0:
            continue
        a.append((cx, cy, ang, s))
    n = len(a)
    for i in range(n):
        cx1, cy1, ag1, s1 = a[i]
        for j in range(i + 1, n):
            cx2, cy2, ag2, s2 = a[j]
            # conservative separating axis: use circle radius half diagonal
            r1 = s1 * 0.7071067811865476
            r2 = s2 * 0.7071067811865476
            if (cx1 - cx2) ** 2 + (cy1 - cy2) ** 2 >= (r1 + r2) ** 2 - eps:
                continue
            # check SAT for rotated squares
            corners1 = _corners(cx1, cy1, ag1, s1)
            corners2 = _corners(cx2, cy2, ag2, s2)
            if _sat_overlap(corners1, corners2, eps):
                return False
    return True


def _corners(cx, cy, ang, s):
    c = math.cos(ang * 2 * math.pi)
    si = math.sin(ang * 2 * math.pi)
    h = s * 0.5
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        out.append((cx + x * c - y * si, cy + x * si + y * c))
    return out


def _sat_overlap(p1, p2, eps):
    def proj(poly, axis):
        return [px * axis[0] + py * axis[1] for px, py in poly]

    for poly in (p1, p2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            axis = (y2 - y1, -(x2 - x1))
            ln = math.hypot(*axis)
            if ln < 1e-14:
                continue
            axis = (axis[0] / ln, axis[1] / ln)
            a = proj(p1, axis)
            b = proj(p2, axis)
            if max(a) <= min(b) + eps or max(b) <= min(a) + eps:
                return False
    return True


def _relax(squares, iters=800, seed=1):
    """Physical relaxation: push apart overlapping axis-aligned squares, maximize sizes."""
    rng = random.Random(seed)
    arr = [list(s) for s in squares]
    n = len(arr)
    if n == 0:
        return squares

    for step in range(iters):
        # compute forces from overlaps (approximate, axis-aligned)
        moved = False
        for i in range(n):
            for j in range(i + 1, n):
                cx1, cy1, a1, s1 = arr[i]
                cx2, cy2, a2, s2 = arr[j]
                if s1 <= 0 or s2 <= 0:
                    continue
                r1 = s1 * 0.7071067811865476
                r2 = s2 * 0.7071067811865476
                dx = cx1 - cx2
                dy = cy1 - cy2
                d2 = dx * dx + dy * dy
                rr = (r1 + r2)
                if d2 < rr * rr and d2 > 1e-18:
                    d = math.sqrt(d2)
                    overlap = rr - d
                    ux, uy = dx / d, dy / d
                    push = overlap * 0.25
                    arr[i][0] += ux * push
                    arr[i][1] += uy * push
                    arr[j][0] -= ux * push
                    arr[j][1] -= uy * push
                    moved = True
        # shrink any square that goes outside the box
        for i in range(n):
            cx, cy, a, s = arr[i]
            r = s * 0.7071067811865476
            if cx - r < 0:
                arr[i][0] = r
                moved = True
            if cx + r > 1:
                arr[i][0] = 1 - r
                moved = True
            if cy - r < 0:
                arr[i][1] = r
                moved = True
            if cy + r > 1:
                arr[i][1] = 1 - r
                moved = True
        # occasionally grow the smallest square if feasible
        if step % 40 == 0:
            o = list(range(n))
            o.sort(key=lambda k: arr[k][3])
            for idx in o[:max(1, n // 4)]:
                cx, cy, a, s = arr[idx]
                ns = s * 1.01 + 0.001
                r = ns * 0.7071067811865476
                if cx - r >= -1e-9 and cx + r <= 1 + 1e-9 and cy - r >= -1e-9 and cy + r <= 1 + 1e-9:
                    arr[idx][3] = ns
        if not moved and step > 50:
            break

    return [tuple(x) for x in arr]


def _grid_layout(n):
    """Best simple grid plus zero squares."""
    best = None
    best_score = -1
    # try a set of rectangular grids a x b with a*b <= n
    for a in range(1, n + 1):
        b = n // a
        if a * b == 0:
            continue
        # allow some squares to be zero
        for ra in range(1, a + 1):
            rb = n // ra
            if ra * rb <= n and ra * rb > 0:
                w = 1.0 / ra
                h = 1.0 / rb
                s = min(w, h)
                cnt = ra * rb
                score = s * cnt
                if score > best_score:
                    best_score = score
                    grid = []
                    for i in range(ra):
                        for j in range(rb):
                            cx = (i + 0.5) * w
                            cy = (j + 0.5) * h
                            side = min(w, h)
                            grid.append((cx, cy, 0.0, side))
                    while len(grid) < n:
                        grid.append((0.5, 0.5, 0.0, 0.0))
                    best = grid[:n]
    return best


def _heuristic_small(n):
    """Known good configurations for small n."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side 0.5 each
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # three squares: two 1/2 at bottom-ish, one top
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    if n == 5:
        # 4 grid + 1 tiny
        g = []
        for i in range(2):
            for j in range(2):
                g.append((0.25 + i * 0.5, 0.25 + j * 0.5, 0.0, 0.5))
        g.append((0.5, 0.5, 0.0, 0.0))
        return g
    return None


def _optimize_sizes(squares, n):
    """Local optimization of sizes and positions using scipy if available."""
    try:
        from scipy.optimize import minimize
    except ImportError:
        return squares

    base = [list(s) for s in squares]
    # choose decision variables: for simplicity optimize sizes and center coords for nonzero squares
    idx_nz = [i for i, s in enumerate(base) if s[3] > 0]
    m = len(idx_nz)
    if m == 0:
        return squares

    def unpack(x):
        arr = [list(s) for s in base]
        k = 0
        for i in idx_nz:
            arr[i][0] = x[k]
            arr[i][1] = x[k + 1]
            arr[i][3] = x[k + 2]
            k += 3
        return arr

    def obj(x):
        arr = unpack(x)
        return -sum(s[3] for s in arr)

    def cons_fun(x):
        arr = unpack(x)
        # all centers inside
        c = []
        for s in arr:
            if s[3] > 0:
                r = s[3] * 0.7071067811865476
                c.append(s[0] - r)
                c.append(1 - s[0] - r)
                c.append(s[1] - r)
                c.append(1 - s[1] - r)
        # pairwise disjointness (conservative circles)
        for i in range(len(arr)):
            for j in range(i + 1, len(arr)):
                if arr[i][3] > 0 and arr[j][3] > 0:
                    dx = arr[i][0] - arr[j][0]
                    dy = arr[i][1] - arr[j][1]
                    d = math.hypot(dx, dy)
                    rr = (arr[i][3] + arr[j][3]) * 0.7071067811865476
                    c.append(d - rr)
        return c

    x0 = []
    for i in idx_nz:
        x0.extend([base[i][0], base[i][1], base[i][3]])

    bounds = []
    for i in idx_nz:
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))

    cons = {'type': 'ineq', 'fun': cons_fun}
    try:
        res = minimize(obj, x0, method='SLSQP', bounds=bounds, constraints=cons,
                       options={'maxiter': 300, 'ftol': 1e-10})
        arr = unpack(res.x)
        # shrink to ensure feasibility
        arr = _relax([tuple(s) for s in arr], iters=300, seed=42)
        if _is_feasible(arr):
            score = sum(s[3] for s in arr)
            if score > sum(s[3] for s in squares):
                return arr
    except Exception:
        pass
    return squares


def _is_feasible(squares, eps=1e-7):
    for cx, cy, ang, s in squares:
        if s < 0:
            return False
        if s > 0:
            r = s * 0.7071067811865476
            if cx - r < -eps or cx + r > 1 + eps or cy - r < -eps or cy + r > 1 + eps:
                return False
    return _disjoint_ratio(squares, eps)


def solve(n):
    if n == 0:
        return []
    small = _heuristic_small(n)
    if small is not None:
        return small

    # Try grid layouts
    best = _grid_layout(n)
    best_score = sum(s[3] for s in best)

    # Try several random restarts with relaxation
    rng = random.Random(12345 + n)
    for trial in range(6):
        squares = []
        for i in range(n):
            s = 0.1
            cx = rng.uniform(0.05, 0.95)
            cy = rng.uniform(0.05, 0.95)
            squares.append((cx, cy, 0.0, s))
        relaxed = _relax(squares, iters=600, seed=trial + n)
        sc = sum(s[3] for s in relaxed)
        if sc > best_score and _is_feasible(relaxed):
            best_score = sc
            best = relaxed

    # also try a structured start: all squares at their grid positions
    if n <= 400:
        k = math.isqrt(n)
        if k > 0:
            for shift in range(k):
                squares = []
                for i in range(n):
                    row = i // k
                    col = i % k
                    cx = (col + 0.5) / k
                    cy = (row + 0.5) / k
                    squares.append((cx, cy, 0.0, 1.0 / k))
                relaxed = _relax(squares, iters=500, seed=100 + shift)
                sc = sum(s[3] for s in relaxed)
                if sc > best_score and _is_feasible(relaxed):
                    best_score = sc
                    best = relaxed

    # final optimization
    opt = _optimize_sizes(best, n)
    if opt is not None:
        sc = sum(s[3] for s in opt)
        if sc >= best_score and _is_feasible(opt):
            best = opt
            best_score = sc

    # ensure exactly n squares
    best = list(best[:n])
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))

    # validate and return
    if not _is_feasible(best):
        g = _grid_layout(n)
        best = g[:n]
        while len(best) < n:
            best.append((0.5, 0.5, 0.0, 0.0))
    return best
