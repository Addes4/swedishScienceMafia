import math
import random
import numpy as np
from scipy.optimize import minimize


def _overlap(ax, ay, aa, asz, bx, by, ba, bsz):
    """Return True if two axis-aligned or rotated squares overlap interiors."""
    if asz <= 0 or bsz <= 0:
        return False
    ca, sa = math.cos(math.tau * aa), math.sin(math.tau * aa)
    cb, sb = math.cos(math.tau * ba), math.sin(math.tau * ba)
    # half-extent vectors
    a_half = asz * 0.5
    b_half = bsz * 0.5
    # Separating axis theorem on 4 candidate axes
    axes = [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]
    dx = bx - ax
    dy = by - ay
    for ux, uy in axes:
        dist = abs(dx * ux + dy * uy)
        proj_a = a_half * (abs(ux * ca + uy * sa) + abs(ux * -sa + uy * ca))
        proj_b = b_half * (abs(ux * cb + uy * sb) + abs(ux * -sb + uy * cb))
        if dist >= proj_a + proj_b - 1e-12:
            return False
    return True


def _inside(cx, cy, angle, side):
    if side <= 0:
        return True
    c = math.cos(math.tau * angle)
    s = math.sin(math.tau * angle)
    h = side * 0.5
    # bounding box of rotated square
    ex = h * (abs(c) + abs(s))
    ey = h * (abs(c) + abs(s))
    return (cx - ex >= -1e-12 and cx + ex <= 1 + 1e-12 and
            cy - ey >= -1e-12 and cy + ey <= 1 + 1e-12)


def _cost(params, n):
    """Penalty: 0 if feasible, plus encourages large total side."""
    total = 0.0
    squares = []
    for i in range(n):
        cx, cy, an, sz = params[4 * i:4 * i + 4]
        squares.append((cx, cy, an, sz))
        total += sz
    pen = 0.0
    for i in range(n):
        cx, cy, an, sz = squares[i]
        if sz > 0:
            if not _inside(cx, cy, an, sz):
                # distance outside
                c = math.cos(math.tau * an)
                s = math.sin(math.tau * an)
                h = sz * 0.5
                ex = h * (abs(c) + abs(s))
                ey = ex
                out = max(0, ex - cx, cx + ex - 1, ey - cy, cy + ey - 1)
                pen += 1000.0 * out * out
    for i in range(n):
        ax, ay, aa, asz = squares[i]
        for j in range(i + 1, n):
            bx, by, ba, bsz = squares[j]
            if _overlap(ax, ay, aa, asz, bx, by, ba, bsz):
                # amount of overlap approximation
                ca, sa = math.cos(math.tau * aa), math.sin(math.tau * aa)
                cb, sb = math.cos(math.tau * ba), math.sin(math.tau * ba)
                # distance between centres projected
                dx = bx - ax
                dy = by - ay
                dist = math.hypot(dx, dy)
                req = (asz + bsz) * 0.5 * 0.9
                pen += 1000.0 * (req - dist) ** 2
    return pen - total


def _greedy(n, rng):
    """Greedy insertion of squares into an adaptive grid."""
    # start with coarse grid of candidate centres, use several orientations
    squares = []
    candidates = []
    g = max(2, int(math.sqrt(n)) + 2)
    for i in range(g):
        for j in range(g):
            for ang in (0.0, 0.125, 0.25, 0.375):
                candidates.append(((i + 0.5) / g, (j + 0.5) / g, ang))
    rng.shuffle(candidates)
    # estimate size by placing one by one
    for c in candidates:
        if len(squares) >= n:
            break
        cx, cy, ang = c
        # find max side that fits with existing
        lo, hi = 0.0, 1.0
        for _ in range(20):
            mid = (lo + hi) * 0.5
            ok = True
            for sx, sy, sa, ss in squares:
                if _overlap(cx, cy, ang, mid, sx, sy, sa, ss):
                    ok = False
                    break
            if ok and _inside(cx, cy, ang, mid):
                lo = mid
            else:
                hi = mid
        if lo > 1e-6:
            squares.append((cx, cy, ang, lo))
    # pad
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _refine(squares, n, iterations=3):
    """Coordinate descent on params."""
    params = []
    for cx, cy, an, sz in squares:
        params.extend([cx, cy, an, sz])
    params = np.array(params)
    best = params.copy()
    bestc = _cost(best, n)

    step_c = 0.02
    step_a = 0.05
    step_s = 0.02

    for it in range(iterations):
        improved = False
        order = list(range(4 * n))
        random.shuffle(order)
        for idx in order:
            for delta in (step_c, -step_c, step_a, -step_a, step_s, -step_s):
                trial = best.copy()
                trial[idx] += delta
                # clamp
                if idx % 4 == 0 or idx % 4 == 1:
                    trial[idx] = min(1.0, max(0.0, trial[idx]))
                elif idx % 4 == 2:
                    trial[idx] = trial[idx] % 1.0
                else:
                    trial[idx] = min(1.0, max(0.0, trial[idx]))
                c = _cost(trial, n)
                if c < bestc - 1e-9:
                    best = trial
                    bestc = c
                    improved = True
        if not improved:
            step_c *= 0.5
            step_a *= 0.5
            step_s *= 0.5
            if step_c < 1e-4:
                break
    return best


def _build_from_params(params, n):
    res = []
    for i in range(n):
        cx, cy, an, sz = params[4 * i:4 * i + 4]
        cx = min(1.0, max(0.0, float(cx)))
        cy = min(1.0, max(0.0, float(cy)))
        an = float(an) % 1.0
        sz = min(1.0, max(0.0, float(sz)))
        res.append((cx, cy, an, sz))
    return res


def solve(n):
    rng = random.Random(12345)
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_squares = None
    best_score = -1.0

    # Try multiple starting strategies
    strategies = []
    # Strategy 1: greedy adaptive
    strategies.append(lambda: _greedy(n, rng))
    # Strategy 2: grid with various k
    k = math.isqrt(n)
    side = 1.0 / k
    grid = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
            for i in range(k) for j in range(k)]
    while len(grid) < n:
        grid.append((0.5, 0.5, 0.0, 0.0))
    strategies.append(lambda: grid[:n])
    # Strategy 3: perturbed greedy

    def perturbed():
        base = _greedy(n, rng)
        out = []
        for cx, cy, an, sz in base:
            if sz > 0:
                cx += rng.uniform(-0.02, 0.02)
                cy += rng.uniform(-0.02, 0.02)
                an += rng.uniform(-0.05, 0.05)
                cx = min(0.98, max(0.02, cx))
                cy = min(0.98, max(0.02, cy))
                an %= 1.0
            out.append((cx, cy, an, sz))
        return out

    strategies.append(perturbed)

    for strat in strategies:
        try:
            sq = strat()
        except Exception:
            continue
        params = []
        for cx, cy, an, sz in sq:
            params.extend([cx, cy, an, sz])
        params = np.array(params)
        # refine
        refined = _refine(params, n, iterations=2)
        result = _build_from_params(refined, n)
        # validate and fix feasibility
        result = _repair(result, n)
        score = sum(s[3] for s in result)
        if score > best_score:
            best_score = score
            best_squares = result

    # Additional refinement with more iterations on best
    if best_squares is not None:
        params = []
        for cx, cy, an, sz in best_squares:
            params.extend([cx, cy, an, sz])
        params = np.array(params)
        refined = _refine(params, n, iterations=5)
        result = _build_from_params(refined, n)
        result = _repair(result, n)
        score = sum(s[3] for s in result)
        if score > best_score:
            best_score = score
            best_squares = result

    return best_squares


def _repair(squares, n):
    """Ensure feasibility: remove overlaps by shrinking."""
    result = list(squares)
    # iteratively shrink overlapping squares
    for _ in range(50):
        changed = False
        for i in range(n):
            cx, cy, an, sz = result[i]
            # ensure inside
            if sz > 0 and not _inside(cx, cy, an, sz):
                # shrink until inside
                while sz > 1e-9 and not _inside(cx, cy, an, sz):
                    sz *= 0.9
                result[i] = (cx, cy, an, sz)
                changed = True
            if i > 0:
                for j in range(i):
                    ax, ay, aa, asz = result[j]
                    if _overlap(cx, cy, an, sz, ax, ay, aa, asz):
                        # shrink the larger one
                        kk = 0.05
                        newsz = sz
                        for _ in range(200):
                            newsz *= (1 - kk)
                            if not _overlap(cx, cy, an, newsz, ax, ay, aa, asz):
                                break
                        sz = newsz
                        result[i] = (cx, cy, an, sz)
                        changed = True
        if not changed:
            break
    return result
