import math
import random
import numpy as np
from scipy.optimize import minimize


def _overlap_penalty(x1, y1, a1, s1, x2, y2, a2, s2):
    # Approximate overlap between two squares via separating axis theorem (SAT)
    # Returns positive value if they overlap in interior.
    # Square corners relative to center.
    def corners(x, y, a, s):
        c = math.cos(2 * math.pi * a)
        sn = math.sin(2 * math.pi * a)
        h = s / 2.0
        pts = []
        for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
            rx = dx * c - dy * sn
            ry = dx * sn + dy * c
            pts.append((x + rx, y + ry))
        return pts

    p1 = corners(x1, y1, a1, s1)
    p2 = corners(x2, y2, a2, s2)

    # Check all axes (normals of both squares' edges)
    def axes(pts):
        ax = []
        for i in range(4):
            x_a, y_a = pts[i]
            x_b, y_b = pts[(i + 1) % 4]
            ex, ey = x_b - x_a, y_b - y_a
            # normal
            nx, ny = -ey, ex
            ln = math.hypot(nx, ny)
            if ln > 1e-12:
                ax.append((nx / ln, ny / ln))
        return ax

    all_axes = axes(p1) + axes(p2)
    min_overlap = float('inf')
    for nx, ny in all_axes:
        proj1 = [px * nx + py * ny for px, py in p1]
        proj2 = [px * nx + py * ny for px, py in p2]
        mx1, mn1 = max(proj1), min(proj1)
        mx2, mn2 = max(proj2), min(proj2)
        ov = min(mx1, mx2) - max(mn1, mn2)
        if ov <= 0:
            return 0.0
        min_overlap = min(min_overlap, ov)
    return min_overlap


def _boundary_penalty(x, y, a, s):
    # penalty if square extends outside [0,1]^2
    c = math.cos(2 * math.pi * a)
    sn = math.sin(2 * math.pi * a)
    h = s / 2.0
    pen = 0.0
    for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
        rx = dx * c - dy * sn
        ry = dx * sn + dy * c
        px = x + rx
        py = y + ry
        if px < 0:
            pen += -px
        if px > 1:
            pen += px - 1
        if py < 0:
            pen += -py
        if py > 1:
            pen += py - 1
    return pen


def _build_grid(n):
    # Try various grid shapes to get a good starting configuration
    best = None
    best_sum = -1.0
    for k in range(1, n + 1):
        rem = n - k * k
        if rem < 0:
            break
        # base grid k x k plus remaining in a partial extra row
        # try different row/col splits
        for rows in range(1, n + 1):
            cols = (n + rows - 1) // rows
            if rows * cols < n:
                continue
            # square side limited by cell dimensions
            s = min(1.0 / cols, 1.0 / rows)
            total = s * n
            if total > best_sum:
                best_sum = total
                best = (rows, cols, s)
    rows, cols, s = best
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            x = (c + 0.5) / cols
            y = (r + 0.5) / rows
            squares.append((x, y, 0.0, s))
            idx += 1
        if idx >= n:
            break
    return squares


def _optimize(squares, time_budget=50.0):
    import time
    start = time.time()
    n = len(squares)
    if n == 0:
        return squares

    # Decide which squares can be nonzero: at most n
    # We will optimize only nonzero ones; zero-sized are fixed at a point.
    # Start: all nonzero with side given.
    x0 = []
    for (x, y, a, s) in squares:
        x0.extend([x, y, a, s])
    x0 = np.array(x0, dtype=float)

    def unpack(v):
        return [(v[4 * i], v[4 * i + 1], v[4 * i + 2], v[4 * i + 3]) for i in range(n)]

    def objective(v):
        # maximize sum of sides -> minimize negative
        return -np.sum(v[3::4])

    def constraint_fun(v):
        # inequality constraints >= 0
        sq = unpack(v)
        cons = []
        # boundary
        for (x, y, a, s) in sq:
            if s <= 1e-9:
                continue
            # clamp angle
            a_mod = a % 1.0
            c = math.cos(2 * math.pi * a_mod)
            sn = math.sin(2 * math.pi * a_mod)
            h = s / 2.0
            for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
                rx = dx * c - dy * sn
                ry = dx * sn + dy * c
                px = x + rx
                py = y + ry
                cons.append(px)          # px >= 0
                cons.append(1.0 - px)    # px <= 1
                cons.append(py)          # py >= 0
                cons.append(1.0 - py)    # py <= 1
        # non-overlap as soft penalty via constraints is hard; use penalty in objective instead
        return np.array(cons)

    # We'll add non-overlap as penalty to objective
    def penalized_objective(v):
        sq = unpack(v)
        obj = -np.sum(v[3::4])
        # boundary penalties
        pen = 0.0
        for (x, y, a, s) in sq:
            if s <= 1e-9:
                continue
            pen += 1000 * _boundary_penalty(x, y, a % 1.0, s)
        # overlap penalties
        for i in range(n):
            xi, yi, ai, si = sq[i]
            if si <= 1e-9:
                continue
            for j in range(i + 1, n):
                xj, yj, aj, sj = sq[j]
                if sj <= 1e-9:
                    continue
                ov = _overlap_penalty(xi, yi, ai % 1.0, si, xj, yj, aj % 1.0, sj)
                pen += 1000 * ov
        return obj + pen

    # Bounds: x,y in [0,1], angle in [0,1), side in [0,1]
    bounds = []
    for _ in range(n):
        bounds.extend([(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)])

    # Constraint: boundary only (use exact for safety)
    # Actually use penalty method with SLSQP on penalized objective + boundary constraints
    def ineq_constraint(v):
        sq = unpack(v)
        cons = []
        for (x, y, a, s) in sq:
            if s <= 1e-9:
                continue
            a_mod = a % 1.0
            c = math.cos(2 * math.pi * a_mod)
            sn = math.sin(2 * math.pi * a_mod)
            h = s / 2.0
            xs = []
            ys = []
            for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
                rx = dx * c - dy * sn
                ry = dx * sn + dy * c
                xs.append(x + rx)
                ys.append(y + ry)
            cons.append(min(xs))
            cons.append(1.0 - max(xs))
            cons.append(min(ys))
            cons.append(1.0 - max(ys))
        return np.array(cons)

    constraints = [{'type': 'ineq', 'fun': ineq_constraint}]

    # Try multiple starts: original grid, one with random perturbation
    best_v = x0.copy()
    best_obj = -penalized_objective(best_v)  # negative penalized -> want high
    methods = ['SLSQP']

    def run_opt(v_init, maxiter):
        try:
            res = minimize(penalized_objective, v_init, method='SLSQP',
                           bounds=bounds, constraints=constraints,
                           options={'maxiter': maxiter, 'ftol': 1e-9, 'disp': False})
            return res.x, res.fun
        except Exception:
            return v_init, penalized_objective(v_init)

    # First pass: SLSQP on original
    v_cur = x0.copy()
    for it in range(3):
        if time.time() - start > time_budget:
            break
        v_new, f_new = run_opt(v_cur, 200)
        # Clean up: if penalized objective is worse, revert
        if f_new < penalized_objective(v_cur):
            v_cur = v_new
        else:
            # slightly perturb to escape
            v_try = v_cur + np.random.normal(0, 0.01, size=len(v_cur))
            v_try = np.clip(v_try, 0, 1)
            v_new2, f_new2 = run_opt(v_try, 200)
            if f_new2 < penalized_objective(v_cur):
                v_cur = v_new2

    # Repair: if any overlaps remain, shrink the offending squares
    sq = unpack(v_cur)
    # iterative shrinking to remove overlaps
    for _ in range(200):
        fixed = False
        for i in range(n):
            xi, yi, ai, si = sq[i]
            if si <= 1e-9:
                continue
            for j in range(i + 1, n):
                xj, yj, aj, sj = sq[j]
                if sj <= 1e-9:
                    continue
                ov = _overlap_penalty(xi, yi, ai % 1.0, si, xj, yj, aj % 1.0, sj)
                if ov > 1e-6:
                    # shrink both
                    factor = max(0.0, 1.0 - 0.05)
                    new_si = si * factor
                    new_sj = sj * factor
                    sq[i] = (xi, yi, ai, new_si)
                    sq[j] = (xj, yj, aj, new_sj)
                    xi, yi, ai, si = sq[i]
                    xj, yj, aj, sj = sq[j]
                    fixed = True
        if not fixed:
            break

    # Final boundary check and clamp
    result = []
    for (x, y, a, s) in sq:
        s = max(0.0, min(1.0, s))
        # ensure inside
        if s > 0:
            c = math.cos(2 * math.pi * (a % 1.0))
            sn = math.sin(2 * math.pi * (a % 1.0))
            h = s / 2.0
            xs = []
            ys = []
            for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
                rx = dx * c - dy * sn
                ry = dx * sn + dy * c
                xs.append(x + rx)
                ys.append(y + ry)
            # shift to fit
            minx, maxx = min(xs), max(xs)
            miny, maxy = min(ys), max(ys)
            if minx < 0:
                x -= minx
            if maxx > 1:
                x -= (maxx - 1)
            if miny < 0:
                y -= miny
            if maxy > 1:
                y -= (maxy - 1)
            # if still too big, shrink
            if maxx - minx > 1 + 1e-9 or maxy - miny > 1 + 1e-9:
                s = min(1.0 / (maxx - minx), 1.0 / (maxy - miny)) * s * 0.999
        x = min(max(x, 0.0), 1.0)
        y = min(max(y, 0.0), 1.0)
        a = a % 1.0
        result.append((float(x), float(y), float(a), float(s)))
    return result


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        # best is one square of side 1
        return [(0.5, 0.5, 0.0, 1.0)]

    # Build initial grid
    squares = _build_grid(n)

    # For small n, do more careful optimization
    time_budget = 50.0 if n <= 20 else 40.0
    try:
        squares = _optimize(squares, time_budget=time_budget)
    except Exception:
        pass

    # Ensure we have exactly n squares
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]

    # Final safety: verify no interior overlap; if any, fall back to grid
    def _corners(x, y, a, s):
        c = math.cos(2 * math.pi * (a % 1.0))
        sn = math.sin(2 * math.pi * (a % 1.0))
        h = s / 2.0
        return [(x + dx * c - dy * sn, y + dx * sn + dy * c)
                for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h))]

    # Check and repair overlaps
    for _ in range(50):
        any_ov = False
        for i in range(n):
            xi, yi, ai, si = squares[i]
            if si <= 1e-12:
                continue
            for j in range(i + 1, n):
                xj, yj, aj, sj = squares[j]
                if sj <= 1e-12:
                    continue
                ov = _overlap_penalty(xi, yi, ai, si, xj, yj, aj, sj)
                if ov > 1e-8:
                    # shrink both
                    squares[i] = (xi, yi, ai, si * 0.95)
                    squares[j] = (xj, yj, aj, sj * 0.95)
                    any_ov = True
        if not any_ov:
            break

    # Final bound clamp
    result = []
    for (x, y, a, s) in squares:
        s = max(0.0, min(1.0, s))
        x = min(max(x, 0.0), 1.0)
        y = min(max(y, 0.0), 1.0)
        a = a % 1.0
        # if nonzero, verify inside bounding box
        if s > 1e-12:
            pts = _corners(x, y, a, s)
            minx = min(p[0] for p in pts)
            maxx = max(p[0] for p in pts)
            miny = min(p[1] for p in pts)
            maxy = max(p[1] for p in pts)
            if minx < 0 or maxx > 1 or miny < 0 or maxy > 1:
                # try shifting
                dx = 0.0
                dy = 0.0
                if minx < 0:
                    dx = -minx
                if maxx > 1:
                    dx = 1 - maxx if dx == 0 else dx  # prefer shift to fit
                if miny < 0:
                    dy = -miny
                if maxy > 1:
                    dy = 1 - maxy if dy == 0 else dy
                x += dx
                y += dy
                x = min(max(x, 0.0), 1.0)
                y = min(max(y, 0.0), 1.0)
                pts = _corners(x, y, a, s)
                minx = min(p[0] for p in pts)
                maxx = max(p[0] for p in pts)
                miny = min(p[1] for p in pts)
                maxy = max(p[1] for p in pts)
                if minx < -1e-9 or maxx > 1 + 1e-9 or miny < -1e-9 or maxy > 1 + 1e-9:
                    # shrink to fit
                    sx = (maxx - minx)
                    sy = (maxy - miny)
                    if sx > 1 or sy > 1:
                        s = s / max(sx, sy) * 0.999
        result.append((float(x), float(y), float(a), float(s)))
    return result
