import math
import random
import numpy as np
from scipy.optimize import minimize


def _grid(n):
    k = math.isqrt(n)
    s = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            out.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    return out, k, s


def _feasible(squares, eps=1e-9):
    n = len(squares)
    for i in range(n):
        x, y, a, s = squares[i]
        if s < -eps or x < -eps or x > 1 + eps or y < -eps or y > 1 + eps:
            return False
        if a < -eps or a > 1 + eps:
            return False
        if s == 0:
            continue
        c = math.cos(2 * math.pi * a)
        sn = math.sin(2 * math.pi * a)
        h = s * 0.5
        # axis-aligned bounding box check
        bb = h * (abs(c) + abs(sn))
        if x - bb < -eps or x + bb > 1 + eps or y - bb < -eps or y + bb > 1 + eps:
            return False
    return True


def _overlap(sq1, sq2, eps=1e-9):
    # separating axis test with eps shrink
    x1, y1, a1, s1 = sq1
    x2, y2, a2, s2 = sq2
    if s1 <= 0 or s2 <= 0:
        return False
    def corners(x, y, a, s):
        t = 2 * math.pi * a
        c, sn = math.cos(t), math.sin(t)
        h = s * 0.5
        pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
        return [(x + px * c - py * sn, y + px * sn + py * c) for px, py in pts]
    c1 = corners(x1, y1, a1, s1)
    c2 = corners(x2, y2, a2, s2)
    def axes(c):
        ax = []
        for i in range(4):
            x0, y0 = c[i]
            x1_, y1_ = c[(i + 1) % 4]
            ex, ey = x1_ - x0, y1_ - y0
            L = math.hypot(ex, ey)
            if L > 1e-15:
                ax.append((-ey / L, ex / L))
        return ax
    for ax in axes(c1) + axes(c2):
        p1 = [ax[0] * p[0] + ax[1] * p[1] for p in c1]
        p2 = [ax[0] * p[0] + ax[1] * p[1] for p in c2]
        if max(p1) <= min(p2) + eps or max(p2) <= min(p1) + eps:
            return False
    return True


def _all_ok(squares, eps=1e-9):
    if not _feasible(squares, eps):
        return False
    n = len(squares)
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap(squares[i], squares[j], eps):
                return False
    return True


def _pack_rotated(n, seed=0):
    # Try to pack n rotated squares: 2 alternating orientations in a grid pattern
    if n <= 1:
        if n == 1:
            return [(0.5, 0.5, 0.0, 1.0)]
        return []
    rng = random.Random(seed)
    best = None
    best_total = -1.0

    # Hypothesis: 45-degree tilings can pack better. Try patterns:
    # Pair rows of rotated squares around grid.
    # Approach: take k=isqrt(n), place squares in a grid but rotate alternate ones 45 deg
    # and shrink until feasible.
    k = math.isqrt(n)
    # We attempt a continuous optimization: choose side s, grid positions, alternate 45deg
    for trial in range(3):
        # variable per square: cx, cy, angle, side
        x0 = np.zeros(4 * n)
        for idx in range(n):
            i = idx % k
            j = idx // k
            x0[4 * idx] = (i + 0.5) / k
            x0[4 * idx + 1] = (j + 0.5) / k
            x0[4 * idx + 2] = 0.125 * ((i + j) % 2)
            x0[4 * idx + 3] = 0.9 / k
        def unpack(v):
            sq = []
            for idx in range(n):
                sq.append((v[4*idx], v[4*idx+1], v[4*idx+2], v[4*idx+3]))
            return sq
        def total_neg(v):
            return -sum(v[4*idx+3] for idx in range(n))
        def con_feas(v):
            # each square inside unit square
            con = []
            for idx in range(n):
                x, y, a, s = v[4*idx:4*idx+4]
                t = 2*math.pi*a
                c = math.cos(t); sn = math.sin(t)
                h = s*0.5
                bb = h*(abs(c)+abs(sn))
                con.append(x - bb)
                con.append(1 - x - bb)
                con.append(y - bb)
                con.append(1 - y - bb)
                con.append(s)
            return np.array(con)
        cons = [{'type': 'ineq', 'fun': con_feas}]
        # bounds
        bnds = []
        for idx in range(n):
            bnds.append((0.0, 1.0))
            bnds.append((0.0, 1.0))
            bnds.append((0.0, 0.5))
            bnds.append((0.0, 1.0))
        try:
            res = minimize(total_neg, x0, method='SLSQP', bounds=bnds, constraints=cons,
                           options={'maxiter': 200, 'ftol': 1e-9})
        except Exception:
            continue
        v = res.x
        sq = unpack(v)
        if _all_ok(sq, 1e-6):
            # shrink slightly for safety
            sq = [(x, y, a, max(0.0, s - 1e-6)) for (x, y, a, s) in sq]
            tot = sum(s for _,_,_,s in sq)
            if tot > best_total:
                best_total = tot
                best = sq
    return best


def _pack(n):
    # choose best between grid pack and optimized rotated pack
    grid, k, s = _grid(n)
    best = (sum(x[3] for x in grid), grid)
    if n <= 16:
        try:
            rp = _pack_rotated(n, seed=1)
        except Exception:
            rp = None
        if rp is not None:
            t = sum(x[3] for x in rp)
            if t > best[0]:
                best = (t, rp)
    else:
        # for larger n, grid is very good; add small rotated extras isn't easy
        pass
    return best[1]


def solve(n):
    if n <= 0:
        return []
    squares = _pack(n)
    # ensure exactly n
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    # verification and small fixup: clamp inside, fix overlaps by shrinking
    for i in range(n):
        x, y, a, s = squares[i]
        x = min(max(x, 0.0), 1.0)
        y = min(max(y, 0.0), 1.0)
        a = min(max(a, 0.0), 1.0)
        squares[i] = (x, y, a, s)
    # shrink any overlapping squares iteratively
    for _ in range(30):
        bad = False
        for i in range(n):
            for j in range(i+1, n):
                if _overlap(squares[i], squares[j], 1e-9):
                    x1,y1,a1,s1 = squares[i]
                    x2,y2,a2,s2 = squares[j]
                    # shrink both
                    squares[i] = (x1,y1,a1, max(0.0, s1*0.98))
                    squares[j] = (x2,y2,a2, max(0.0, s2*0.98))
                    bad = True
        if not bad:
            break
    return [tuple(map(float, sq)) for sq in squares]
