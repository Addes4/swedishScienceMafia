import math
import random
import time

# ---------------------------------------------------------------------------
# Geometry: rotated square overlap test
# ---------------------------------------------------------------------------

def square_corners(cx, cy, ang, side):
    """Return the 4 corners of a square centred at (cx,cy), rotated by ang turns."""
    h = side * 0.5
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        out.append((cx + x * ca - y * sa, cy + x * sa + y * ca))
    return out


def proj(poly, axis):
    d = [p[0] * axis[0] + p[1] * axis[1] for p in poly]
    return min(d), max(d)


def overlap_area_positive(c1, c2):
    """Return True if two convex polygons have positive-area intersection."""
    polys = [c1, c2]
    for poly in polys:
        for i in range(len(poly)):
            p1 = poly[i]
            p2 = poly[(i + 1) % len(poly)]
            ex, ey = p2[0] - p1[0], p2[1] - p1[1]
            axis = (-ey, ex)
            l = math.hypot(axis[0], axis[1])
            if l < 1e-15:
                continue
            axis = (axis[0] / l, axis[1] / l)
            mn1, mx1 = proj(c1, axis)
            mn2, mx2 = proj(c2, axis)
            if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
                return False
    return True


def build_corners(squares):
    return [square_corners(cx, cy, ang, side) for cx, cy, ang, side in squares]


def valid(squares, corners=None):
    """Check all squares lie inside unit square and don't overlap with positive area."""
    if corners is None:
        corners = build_corners(squares)
    EPS = 1e-9
    for cx, cy, ang, side in squares:
        if side <= 0.0:
            continue
        for (x, y) in corners[squares.index((cx,cy,ang,side))]:
            pass
    # bounds check via corners
    for sq, poly in zip(squares, corners):
        side = sq[3]
        if side <= 0:
            continue
        for (x, y) in poly:
            if x < -EPS or x > 1.0 + EPS or y < -EPS or y > 1.0 + EPS:
                return False
    n = len(squares)
    for i in range(n):
        if squares[i][3] <= 0:
            continue
        for j in range(i + 1, n):
            if squares[j][3] <= 0:
                continue
            if overlap_area_positive(corners[i], corners[j]):
                return False
    return True


def max_side_at(cx, cy, ang, squares, idx, lo, hi):
    """Binary search largest side keeping validity."""
    # find upper bound where invalid
    best = 0.0
    # Ensure lo valid (assumed)
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        old = squares[idx]
        squares[idx] = (cx, cy, ang, mid)
        corners = build_corners(squares)
        if valid(squares, corners):
            best = mid
            lo = mid
        else:
            hi = mid
    squares[idx] = (cx, cy, ang, best)
    return best


# ---------------------------------------------------------------------------
# Initial constructions
# ---------------------------------------------------------------------------

def grid_init(n, k):
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
    # leftover: place tiny squares in leftover strip
    leftover = n - k * k
    # put leftover squares in a row in remaining space; use zero side if no space
    # Actually try to enlarge: start zero and let optimization grow them.
    for _ in range(leftover):
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


# ---------------------------------------------------------------------------
# Local search
# ---------------------------------------------------------------------------

def objective(squares):
    return sum(s[3] for s in squares)


def perturb(squares, rng, scale=0.05):
    sq = [list(x) for x in squares]
    n = len(sq)
    i = rng.randrange(n)
    mode = rng.random()
    if mode < 0.5:
        # move centre
        sq[i][0] = min(1.0, max(0.0, sq[i][0] + rng.uniform(-scale, scale)))
        sq[i][1] = min(1.0, max(0.0, sq[i][1] + rng.uniform(-scale, scale)))
    elif mode < 0.8:
        # rotate
        sq[i][2] = (sq[i][2] + rng.uniform(-0.1, 0.1)) % 1.0
    else:
        # change size
        sq[i][3] = min(1.0, max(0.0, sq[i][3] + rng.uniform(-scale, scale)))
    return [tuple(x) for x in sq]


def repair(squares):
    """Shrink overlapping squares until valid."""
    sq = [list(x) for x in squares]
    n = len(sq)
    for _ in range(200):
        corners = build_corners([tuple(x) for x in sq])
        changed = False
        # bounds
        for i in range(n):
            if sq[i][3] <= 0:
                continue
            poly = corners[i]
            cx, cy = sq[i][0], sq[i][1]
            # push inside
            minx = min(p[0] for p in poly)
            maxx = max(p[0] for p in poly)
            miny = min(p[1] for p in poly)
            maxy = max(p[1] for p in poly)
            dx = 0.0
            dy = 0.0
            if minx < 0:
                dx += -minx
            if maxx > 1:
                dx -= (maxx - 1)
            if miny < 0:
                dy += -miny
            if maxy > 1:
                dy -= (maxy - 1)
            if abs(dx) > 1e-12 or abs(dy) > 1e-12:
                sq[i][0] += dx
                sq[i][1] += dy
                changed = True
                corners = build_corners([tuple(x) for x in sq])
        # overlaps
        for i in range(n):
            if sq[i][3] <= 0:
                continue
            for j in range(i + 1, n):
                if sq[j][3] <= 0:
                    continue
                if overlap_area_positive(corners[i], corners[j]):
                    # shrink both a bit
                    sq[i][3] *= 0.95
                    sq[j][3] *= 0.95
                    changed = True
                    corners = build_corners([tuple(x) for x in sq])
                    if sq[i][3] < 1e-6:
                        sq[i][3] = 0.0
                    if sq[j][3] < 1e-6:
                        sq[j][3] = 0.0
        if not changed:
            break
    return [tuple(x) for x in sq]


def optimize(n, time_limit, seed=12345):
    rng = random.Random(seed)
    start = time.time()

    # initial: largest grid
    k = math.isqrt(n)
    while k > 1 and k * k > n:
        k -= 1
    best = grid_init(n, k)
    best = repair(best)
    best_val = objective(best)

    # also try slightly different k
    configs = [best]
    for kk in range(max(1, k - 1), k + 2):
        if kk * kk <= n:
            c = grid_init(n, kk)
            c = repair(c)
            configs.append(c)
        # also n squares all equal as initial
    # try all-equal tiny
    c = [(0.5, 0.5, 0.0, 0.0) for _ in range(n)]
    configs.append(repair(c))

    for c in configs:
        v = objective(c)
        if v > best_val:
            best_val = v
            best = c

    # --- greedy growth phase: try to increase each square ---
    cur = [list(x) for x in best]
    improved = True
    while improved and time.time() - start < time_limit * 0.5:
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            old_side = cur[i][3]
            # try to grow by binary search
            cx, cy, ang, _ = cur[i]
            # upper bound 1
            lo = old_side
            hi = 1.0
            sq_tuples = [tuple(x) for x in cur]
            # use search overriding idx i
            test = [list(x) for x in cur]
            for _ in range(35):
                mid = 0.5 * (lo + hi)
                test[i] = [cx, cy, ang, mid]
                tup = [tuple(x) for x in test]
                if valid(tup):
                    lo = mid
                else:
                    hi = mid
            if lo > old_side + 1e-9:
                cur[i] = [cx, cy, ang, lo]
                improved = True
        if improved:
            v = objective([tuple(x) for x in cur])
            if v > best_val:
                best_val = v
                best = [tuple(x) for x in cur]

    # --- random local search ---
    cur = [list(x) for x in best]
    cur_val = objective([tuple(x) for x in cur])
    temp = 0.1
    it = 0
    while time.time() - start < time_limit:
        it += 1
        scale = 0.1 * (1.0 - min(1.0, (time.time() - start) / time_limit)) + 0.002
        cand = perturb([tuple(x) for x in cur], rng, scale)
        cand = repair(cand)
        cv = objective(cand)
        if cv > cur_val - temp * rng.random() * 0.01 * n:
            cur = [list(x) for x in cand]
            cur_val = cv
        if cv > best_val:
            best_val = cv
            best = cand
        # periodic greedy growth
        if it % 5 == 0:
            improved = True
            cur_list = [list(x) for x in cur]
            while improved:
                improved = False
                order = list(range(n))
                rng.shuffle(order)
                for i in order:
                    old_side = cur_list[i][3]
                    cx, cy, ang, _ = cur_list[i]
                    lo = old_side
                    hi = 1.0
                    test = [list(x) for x in cur_list]
                    for _ in range(30):
                        mid = 0.5 * (lo + hi)
                        test[i] = [cx, cy, ang, mid]
                        tup = [tuple(x) for x in test]
                        if valid(tup):
                            lo = mid
                        else:
                            hi = mid
                    if lo > old_side + 1e-9:
                        cur_list[i] = [cx, cy, ang, lo]
                        improved = True
                if improved:
                    v = objective([tuple(x) for x in cur_list])
                    if v > best_val:
                        best_val = v
                        best = [tuple(x) for x in cur_list]
            cur = cur_list
            cur_val = best_val

    # ensure valid
    best = repair(best)
    return best


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # choose time budget
    tl = 5.0
    best = None
    best_val = -1
    seeds = [1, 2, 3, 42, 100, 777]
    # split time among seeds if many
    per = tl / len(seeds)
    for s in seeds:
        cand = optimize(n, per, seed=s)
        v = sum(x[3] for x in cand)
        if v > best_val:
            best_val = v
            best = cand
    # clamp and clean
    out = []
    for (cx, cy, ang, side) in best[:n]:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        side = min(1.0, max(0.0, side))
        out.append((cx, cy, ang, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
