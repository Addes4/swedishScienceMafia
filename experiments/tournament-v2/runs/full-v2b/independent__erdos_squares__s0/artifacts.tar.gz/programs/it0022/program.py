import math
import random
from typing import List, Tuple

import numpy as np
from scipy.optimize import minimize


def _sep(a, b, ang_a, ang_b):
    """Approximate separating distance between two rotated squares."""
    c1, s1 = math.cos(2 * math.pi * ang_a), math.sin(2 * math.pi * ang_a)
    c2, s2 = math.cos(2 * math.pi * ang_b), math.sin(2 * math.pi * ang_b)

    # Half extents along the two axes of each square
    # Use corners of each square
    def corners(cx, cy, ang, side):
        c, s = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
        h = side * 0.5
        pts = []
        for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
            x = cx + sx * h * c - sy * h * s
            y = cy + sx * h * s + sy * h * c
            pts.append((x, y))
        return pts

    ca = corners(a[0], a[1], ang_a, a[3])
    cb = corners(b[0], b[1], ang_b, b[3])

    # SAT for two convex polygons
    def axes(pts):
        out = []
        m = len(pts)
        for i in range(m):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % m]
            ex, ey = x2 - x1, y2 - y1
            n = math.hypot(ex, ey)
            if n > 1e-12:
                out.append((-ey / n, ex / n))
        return out

    ax = axes(ca) + axes(cb)
    for nx, ny in ax:
        pa = [px * nx + py * ny for px, py in ca]
        pb = [px * nx + py * ny for px, py in cb]
        if max(pa) < min(pb) or max(pb) < min(pa):
            return 0.0
    return 1.0


def _penalty_and_grad(x, n, sides):
    """Return penalty for overlaps (and boundary violations) and finite-diff grad."""
    # x layout: for each square: cx, cy, angle, side
    squares = []
    for i in range(n):
        cx, cy, ang, side = x[4 * i], x[4 * i + 1], x[4 * i + 2], x[4 * i + 3]
        squares.append((cx, cy, ang, side))

    pen = 0.0
    # Boundary penalties: all four corners inside [0,1]^2
    for cx, cy, ang, side in squares:
        c, s = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
        h = side * 0.5
        for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
            px = cx + sx * h * c - sy * h * s
            py = cy + sx * h * s + sy * h * c
            if px < 0:
                pen += 1000.0 * (0 - px) ** 2
            if px > 1:
                pen += 1000.0 * (px - 1) ** 2
            if py < 0:
                pen += 1000.0 * (0 - py) ** 2
            if py > 1:
                pen += 1000.0 * (py - 1) ** 2

    # Pairwise overlap penalty
    for i in range(n):
        cx1, cy1, an1, s1 = squares[i]
        for j in range(i + 1, n):
            cx2, cy2, an2, s2 = squares[j]
            # quick distance check
            d = math.hypot(cx1 - cx2, cy1 - cy2)
            r = 0.5 * (s1 + s2) * 1.42
            if d > r + 1e-9:
                continue
            sep = _sep((cx1, cy1, an1, s1), (cx2, cy2, an2, s2), an1, an2)
            # We'll use a crude overlap amount: if sep < 1 then they overlap.
            # Better: compute penetration using center distance minus projections.
            if sep < 0.5:
                pen += 1000.0 * (0.5 - sep) ** 2

    return pen


def _objective(x, n):
    # negative sum of side lengths
    return -sum(x[4 * i + 3] for i in range(n))


def _pack_optimize(init, n, maxiter=200):
    """Local optimization of layout using SLSQP."""
    x0 = np.array(init, dtype=float).flatten()

    bounds = []
    for i in range(n):
        bounds += [(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)]

    # We'll do a projection loop: alternate maximizing sum and reducing penalty
    best_x = x0.copy()
    best_obj = _objective(x0, n)

    # Simple pattern search / SLSQP with penalty
    def f(x):
        return _objective(x, n) + 1000.0 * _penalty_and_grad(x, n, None)

    res = minimize(f, x0, method='SLSQP', bounds=bounds,
                   options={'maxiter': maxiter, 'ftol': 1e-9})
    if res.success:
        val = _objective(res.x, n)
        if val < best_obj:
            best_x = res.x
            best_obj = val

    # Refinement: random perturb and re-opt
    for _ in range(3):
        xp = best_x.copy()
        for i in range(n):
            for k in range(4):
                xp[4 * i + k] += random.uniform(-0.05, 0.05)
                xp[4 * i + k] = max(0.0, min(1.0, xp[4 * i + k]))
        res = minimize(f, xp, method='SLSQP', bounds=bounds,
                       options={'maxiter': maxiter // 2, 'ftol': 1e-9})
        if res.success:
            val = _objective(res.x, n)
            if val < best_obj:
                best_x = res.x
                best_obj = val

    return best_x.reshape(n, 4)


def _initial_grid(n):
    """Grid layout with largest k x k grid plus leftover in a strip."""
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    # Add leftover squares in remaining space? Actually leftover treated as zero.
    # Better: use all n with a slightly smaller k grid plus fractional rows.
    # Simple approach: use k x k grid and put extras as tiny squares in a row.
    extras = n - k * k
    if extras > 0:
        # shrink grid slightly to make room
        side2 = 1.0 / (1 + extras / k)  # heuristic
        # Keep it simple: just place extras below
        y0 = 0.0
        h = 0.05
        for e in range(extras):
            squares.append([(e + 0.5) * (1.0 / extras), y0 + h / 2, 0.0, h])

    # Ensure exactly n
    squares = squares[:n]
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    return squares


def _initial_recursive(n):
    """Recursive guillotine splitting with small random rotations."""
    squares = []

    def rec(x, y, w, h, cnt):
        if cnt == 0:
            return
        if cnt == 1:
            s = min(w, h)
            squares.append([x + w / 2, y + h / 2, 0.0, s])
            return
        # split along longer side
        if w >= h:
            # split into left and right
            left_cnt = cnt // 2
            right_cnt = cnt - left_cnt
            # proportional to area
            ratio = left_cnt / cnt
            wl = w * math.sqrt(ratio)
            rec(x, y, wl, h, left_cnt)
            rec(x + wl, y, w - wl, h, right_cnt)
        else:
            bottom_cnt = cnt // 2
            top_cnt = cnt - bottom_cnt
            ratio = bottom_cnt / cnt
            hb = h * math.sqrt(ratio)
            rec(x, y, w, hb, bottom_cnt)
            rec(x, y + hb, w, h - hb, top_cnt)

    rec(0.0, 0.0, 1.0, 1.0, n)
    return squares


def solve(n: int) -> List[Tuple[float, float, float, float]]:
    """Return n squares (centre_x, centre_y, angle, side) inside unit square."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    random.seed(12345 + n)

    best = None
    best_sum = -1.0

    # Try several initial configurations
    candidates = []

    # 1. Grid-based
    candidates.append(_initial_grid(n))

    # 2. Recursive binary splitting
    candidates.append(_initial_recursive(n))

    # 3. Slightly perturbed versions
    for _ in range(2):
        base = _initial_recursive(n)
        base = [[c[0] + random.uniform(-0.02, 0.02),
                 c[1] + random.uniform(-0.02, 0.02),
                 random.uniform(0.0, 0.05),
                 c[3] * random.uniform(0.9, 1.0)] for c in base]
        candidates.append(base)

    for init in candidates:
        # Ensure validity: clamp
        init = [[max(0.0, min(1.0, c[0])),
                 max(0.0, min(1.0, c[1])),
                 max(0.0, min(1.0, c[2])),
                 max(0.0, min(1.0, c[3]))] for c in init]
        try:
            result = _pack_optimize(init, n)
            total = sum(result[i][3] for i in range(n))
            if total > best_sum:
                best_sum = total
                best = result
        except Exception:
            # Fall back to simple grid
            k = math.isqrt(n)
            s = 1.0 / k
            fallback = [[(i + 0.5) * s, (j + 0.5) * s, 0.0, s]
                        for i in range(k) for j in range(k)]
            fallback += [[0.5, 0.5, 0.0, 0.0]] * (n - len(fallback))
            total = sum(c[3] for c in fallback[:n])
            if total > best_sum:
                best_sum = total
                best = fallback[:n]

    if best is None:
        # ultimate fallback
        k = math.isqrt(n)
        s = 1.0 / k
        best = [[(i + 0.5) * s, (j + 0.5) * s, 0.0, s]
                for i in range(k) for j in range(k)]
        best += [[0.5, 0.5, 0.0, 0.0]] * (n - len(best))
        best = best[:n]

    # Final cleanup: ensure bounds and non-negative
    out = []
    for c in best:
        cx = max(0.0, min(1.0, float(c[0])))
        cy = max(0.0, min(1.0, float(c[1])))
        ang = max(0.0, min(1.0, float(c[2])))
        side = max(0.0, min(1.0, float(c[3])))
        out.append((cx, cy, ang, side))

    return out
