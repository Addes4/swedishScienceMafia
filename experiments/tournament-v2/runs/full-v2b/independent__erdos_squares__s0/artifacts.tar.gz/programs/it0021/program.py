import math
import random
import time


def _corners(cx, cy, ang, s):
    h = s * 0.5
    ca = math.cos(ang * 2.0 * math.pi)
    sa = math.sin(ang * 2.0 * math.pi)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _overlap(a, b):
    ax, ay, aang, asz = a
    bx, by, bang, bsz = b
    if asz <= 0.0 or bsz <= 0.0:
        return 0.0
    if abs(ax - bx) >= (asz + bsz) * 0.7072 or abs(ay - by) >= (asz + bsz) * 0.7072:
        return 0.0
    pa = _corners(ax, ay, aang, asz)
    pb = _corners(bx, by, bang, bsz)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            nx, ny = -(y2 - y1), (x2 - x1)
            ln = math.hypot(nx, ny)
            if ln > 1e-14:
                axes.append((nx / ln, ny / ln))
    for nx, ny in axes:
        amn = amx = pa[0][0] * nx + pa[0][1] * ny
        for x, y in pa[1:]:
            v = x * nx + y * ny
            if v < amn:
                amn = v
            elif v > amx:
                amx = v
        bmn = bmx = pb[0][0] * nx + pb[0][1] * ny
        for x, y in pb[1:]:
            v = x * nx + y * ny
            if v < bmn:
                bmn = v
            elif v > bmx:
                bmx = v
        if amx <= bmn + 1e-12 or bmx <= amn + 1e-12:
            return 0.0
    return min(amx - bmn, bmx - amn)


def _inside(cx, cy, ang, s):
    if s <= 0.0:
        return 0.0
    mx = 0.0
    for x, y in _corners(cx, cy, ang, s):
        if x < 0.0:
            mx = max(mx, -x)
        elif x > 1.0:
            mx = max(mx, x - 1.0)
        if y < 0.0:
            mx = max(mx, -y)
        elif y > 1.0:
            mx = max(mx, y - 1.0)
    return mx


def _clamp(sq):
    cx, cy, ang, s = sq
    s = max(0.0, min(s, 1.0))
    if s <= 0.0:
        return (0.5, 0.5, 0.0, 0.0)
    pts = _corners(cx, cy, ang, s)
    minx = min(p[0] for p in pts)
    maxx = max(p[0] for p in pts)
    miny = min(p[1] for p in pts)
    maxy = max(p[1] for p in pts)
    if maxx - minx > 1.0:
        sc = 1.0 / (maxx - minx)
        s *= sc
        pts = _corners(cx, cy, ang, s)
        minx = min(p[0] for p in pts)
        maxx = max(p[0] for p in pts)
        miny = min(p[1] for p in pts)
        maxy = max(p[1] for p in pts)
    if maxy - miny > 1.0:
        sc = 1.0 / (maxy - miny)
        s *= sc
        pts = _corners(cx, cy, ang, s)
        minx = min(p[0] for p in pts)
        maxx = max(p[0] for p in pts)
        miny = min(p[1] for p in pts)
        maxy = max(p[1] for p in pts)
    if minx < 0.0:
        cx -= minx
    elif maxx > 1.0:
        cx -= maxx - 1.0
    if miny < 0.0:
        cy -= miny
    elif maxy > 1.0:
        cy -= maxy - 1.0
    ang = ang % 1.0
    cx = max(0.0, min(1.0, cx))
    cy = max(0.0, min(1.0, cy))
    return (cx, cy, ang, s)


def _score(sqs):
    tot = 0.0
    pen = 0.0
    m = len(sqs)
    for i in range(m):
        cx, cy, ang, s = sqs[i]
        if s > 0.0:
            tot += s
            pen += 50.0 * _inside(cx, cy, ang, s)
        for j in range(i + 1, m):
            ov = _overlap(sqs[i], sqs[j])
            if ov > 0.0:
                pen += 100.0 * ov * ov + 10.0 * ov
    return tot - pen


def _initial(n):
    if n <= 0:
        return []
    bestk = 1
    best = -1.0
    for k in range(1, n + 1):
        rem = n - k * k
        if rem < 0:
            break
        s = k * (1.0 / k) + rem * 0.0
        if s > best:
            best = s
            bestk = k
    k = bestk
    base = 1.0 / k
    sqs = []
    for i in range(k):
        for j in range(k):
            sqs.append(((i + 0.5) * base, (j + 0.5) * base, 0.0, base))
    rem = n - k * k
    if rem > 0:
        strip = 1.0 - k * base
        if strip > 1e-9:
            cnt = rem
            w = strip / cnt
            for t in range(cnt):
                sqs.append(((t + 0.5) * w, 0.5, 0.0, min(base, w)))
        else:
            for t in range(rem):
                sqs.append((0.5, 0.5, 0.0, 0.0))
    while len(sqs) < n:
        sqs.append((0.5, 0.5, 0.0, 0.0))
    return sqs[:n]


def _try_layouts(n):
    best = None
    bestsc = -1e18

    def consider(sqs):
        nonlocal best, bestsc
        sqs = [_clamp(s) for s in sqs]
        sc = _score(sqs)
        if sc > bestsc:
            bestsc = sc
            best = list(sqs)

    consider(_initial(n))

    if n >= 2:
        for k in range(1, n + 1):
            if k * k > n:
                break
            rem = n - k * k
            base = 1.0 / k
            sqs = []
            for i in range(k):
                for j in range(k):
                    sqs.append(((i + 0.5) * base, (j + 0.5) * base, 0.0, base))
            if rem > 0:
                strip = 1.0 - k * base
                if strip > 1e-9:
                    for t in range(rem):
                        w = strip / rem
                        sqs.append(((t + 0.5) * w, 0.5, 0.0, min(base, w)))
                else:
                    for t in range(rem):
                        sqs.append((0.5, 0.5, 0.0, 0.0))
            while len(sqs) < n:
                sqs.append((0.5, 0.5, 0.0, 0.0))
            consider(sqs[:n])

    if n >= 3:
        for k in range(1, n + 1):
            if k * k > n:
                break
            rem = n - k * k
            base = 1.0 / k
            ncol = k
            nrow = k
            if rem > 0:
                extra_rows = 1
                sqs = []
                for i in range(ncol):
                    for j in range(nrow):
                        sqs.append(((i + 0.5) * base, (j + 0.5) * base, 0.0, base))
                top = nrow * base
                h = max(0.0, 1.0 - top)
                if h > 1e-9 and rem > 0:
                    w = 1.0 / rem
                    s = min(h, w)
                    for t in range(rem):
                        sqs.append(((t + 0.5) * w, top + s * 0.5, 0.0, s))
                while len(sqs) < n:
                    sqs.append((0.5, 0.5, 0.0, 0.0))
                consider(sqs[:n])

    return best if best is not None else _initial(n)


def _anneal(n, sqs, deadline):
    rng = random.Random(12345 + n * 7919)
    cur = [_clamp(s) for s in sqs]
    cursc = _score(cur)
    best = list(cur)
    bestsc = cursc
    t0 = time.time()
    span = max(0.05, deadline - t0)
    it = 0
    while True:
        now = time.time()
        if now >= deadline:
            break
        it += 1
        temp = max(1e-6, 0.08 * (1.0 - min(1.0, (now - t0) / span)) ** 1.5 + 1e-5)
        i = rng.randrange(n)
        cand = list(cur)
        cx, cy, ang, s = cand[i]
        mode = rng.random()
        if mode < 0.4:
            s = max(0.0, s + rng.gauss(0.0, 0.04) * (0.5 + s))
        elif mode < 0.7:
            cx = max(0.0, min(1.0, cx + rng.gauss(0.0, 0.03)))
            cy = max(0.0, min(1.0, cy + rng.gauss(0.0, 0.03)))
        elif mode < 0.85:
            ang = (ang + rng.gauss(0.0, 0.05)) % 1.0
        else:
            s = max(0.0, s + rng.gauss(0.0, 0.10) * (0.5 + s))
            ang = (ang + rng.gauss(0.0, 0.08)) % 1.0
        cand[i] = _clamp((cx, cy, ang, s))
        if rng.random() < 0.35:
            j = rng.randrange(n)
            if j != i:
                jx, jy, ja, js = cand[j]
                cand[j] = _clamp((jx, jy, ja, max(0.0, js + rng.gauss(0.0, 0.02))))
        sc = _score(cand)
        if sc >= cursc or rng.random() < math.exp((sc - cursc) / max(temp, 1e-9)):
            cur = cand
            cursc = sc
            if sc > bestsc:
                bestsc = sc
                best = list(cand)
        if it % 4000 == 0:
            cur = list(best)
            cursc = bestsc
    return best


def solve(n):
    if n <= 0:
        return []
    deadline = time.time() + 55.0
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    start = _try_layouts(n)
    cur = [_clamp(s) for s in start]

    # Repair overlaps and boundaries greedily while growing.
    def repair(x):
        for _ in range(60):
            sc = _score(x)
            worst_i = -1
            worst_v = 0.0
            for i in range(n):
                cx, cy, ang, s = x[i]
                v = _inside(cx, cy, ang, s)
                for j in range(i + 1, n):
                    ov = _overlap(x[i], x[j])
                    if ov > 0.0:
                        v += ov * 3.0
                if v > worst_v:
                    worst_v = v
                    worst_i = i
            if worst_i < 0 or worst_v < 1e-10:
                break
            i = worst_i
            cx, cy, ang, s = x[i]
            x[i] = _clamp((cx, cy, ang, s * 0.94))
        return x

    cur = repair(cur)

    # Deterministic local growth: repeatedly try to enlarge the smallest useful square.
    for _ in range(8):
        improved = False
        for i in range(n):
            cx, cy, ang, s = cur[i]
            for ds in (0.01, 0.005, 0.02):
                ns = s + ds
                nc = list(cur)
                nc[i] = _clamp((cx, cy, ang, ns))
                nc = repair(nc)
                sc0 = _score(cur)
                sc1 = _score(nc)
                if sc1 > sc0 + 1e-9:
                    cur = nc
                    improved = True
                    break
        if not improved:
            break

    best = _anneal(n, cur, min(deadline, time.time() + 45.0))

    # Final cleanup: prefer feasible high-sum configurations.
    best = [_clamp(s) for s in best]
    for _ in range(30):
        sc = _score(best)
        changed = False
        for i in range(n):
            cx, cy, ang, s = best[i]
            if s > 0.0:
                nb = list(best)
                nb[i] = _clamp((cx, cy, ang, s * 0.97))
                if _score(nb) > _score(best) + 1e-12:
                    best = nb
                    changed = True
        if not changed:
            break

    out = []
    for cx, cy, ang, s in best[:n]:
        out.append((float(max(0.0, min(1.0, cx))),
                    float(max(0.0, min(1.0, cy))),
                    float(ang % 1.0),
                    float(max(0.0, min(1.0, s)))))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
