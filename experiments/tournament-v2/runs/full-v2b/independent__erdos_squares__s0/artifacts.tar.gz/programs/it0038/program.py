import math
import random
import time

# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------
# Represent a square by (cx, cy, angle_turns, side).
# angle is a fraction of a full turn (0.25 = 90 deg).
# Corners in local frame (before rotation) are (±h, ±h) with h = side/2.


def square_corners(cx, cy, ang, s):
    """Return the 4 corners of a square as (x, y) tuples."""
    h = 0.5 * s
    ca = math.cos(2.0 * math.pi * ang)
    sa = math.sin(2.0 * math.pi * ang)
    # local corners: (-h,-h), (h,-h), (h,h), (-h,h)
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for lx, ly in pts:
        x = cx + lx * ca - ly * sa
        y = cy + lx * sa + ly * ca
        out.append((x, y))
    return out


def _project(pts, ax, ay):
    mn = mx = pts[0][0] * ax + pts[0][1] * ay
    for x, y in pts[1:]:
        v = x * ax + y * ay
        if v < mn:
            mn = v
        elif v > mx:
            mx = v
    return mn, mx


def _axes(corners):
    """Return the two edge direction unit vectors from corner 0."""
    x0, y0 = corners[0]
    x1, y1 = corners[1]
    dx, dy = x1 - x0, y1 - y0
    L = math.hypot(dx, dy)
    if L == 0:
        return [(1.0, 0.0), (1.0, 0.0)]
    a1 = (dx / L, dy / L)
    a2 = (-a1[1], a1[0])
    return [a1, a2]


def overlap(c1, c2):
    """SAT test for two convex quads. Returns True if interiors overlap."""
    for ax in _axes(c1):
        a, b = _project(c1, *ax)
        c, d = _project(c2, *ax)
        if b <= c or d <= a:
            return False
    for ax in _axes(c2):
        a, b = _project(c1, *ax)
        c, d = _project(c2, *ax)
        if b <= c or d <= a:
            return False
    return True


def inside_unit(corr, eps=1e-12):
    """Check all corners are inside [0,1]^2."""
    for x, y in corr:
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def valid_distinct(sq):
    """sq is list of (cx,cy,ang,s). Check all non-zero squares inside unit,
    pairwise non-overlapping."""
    data = []
    for cx, cy, ang, s in sq:
        if s <= 0:
            continue
        corr = square_corners(cx, cy, ang, s)
        if not inside_unit(corr):
            return False
        data.append(corr)
    m = len(data)
    for i in range(m):
        ci = data[i]
        for j in range(i + 1, m):
            if overlap(ci, data[j]):
                return False
    return True


def local_ok(new_corr, others):
    """Check new square corners inside unit and no overlap with others
    (list of already-computed corner lists)."""
    if not inside_unit(new_corr):
        return False
    for oc in others:
        if overlap(new_corr, oc):
            return False
    return True


# ---------------------------------------------------------------------------
# Greedy construction: place squares one at a time, trying to be large.
# Random restarts + coordinate refinement.
# ---------------------------------------------------------------------------

def _candidate_positions(rng, m, count):
    """Generate candidate centres, biased to grid + jitter."""
    cands = []
    g = max(2, int(math.sqrt(m)) + 1)
    for _ in range(count):
        if rng.random() < 0.5:
            i = rng.randint(0, g)
            j = rng.randint(0, g)
            x = (i + 0.5) / g
            y = (j + 0.5) / g
            x += rng.uniform(-0.5 / g, 0.5 / g)
            y += rng.uniform(-0.5 / g, 0.5 / g)
        else:
            x = rng.random()
            y = rng.random()
        cands.append((x, y))
    return cands


def max_inscribed(pos, existing_corners):
    """Given a centre (x,y), find the largest axis-aligned square side that
    fits without overlapping existing squares. Also try a few rotations."""
    x, y = pos
    best_s = 0.0
    best_ang = 0.0
    # binary search over size for a set of angles
    angles = [0.0, 0.1, 0.2, 0.25, 0.3, 0.4, 0.5, 0.75, 0.125, 0.375, 0.625, 0.875]
    for ang in angles:
        lo, hi = 0.0, 1.0
        # quick upper bound: distance to border
        # use binary search on feasibility
        for _ in range(24):
            mid = 0.5 * (lo + hi)
            corr = square_corners(x, y, ang, mid)
            if local_ok(corr, existing_corners):
                lo = mid
            else:
                hi = mid
        if lo > best_s:
            best_s = lo
            best_ang = ang
    return best_s, best_ang


def greedy_fill(n, rng, time_limit):
    """Try to fill with n squares. Return list or None."""
    sq = []  # (cx,cy,ang,s)
    corners_list = []
    # generate candidate centres for each inserted square
    for k in range(n):
        # only do a limited number of candidates per square
        ncand = 18 if n <= 30 else (12 if n <= 120 else 8)
        cands = _candidate_positions(rng, k + 1, ncand)
        best = None
        best_s = -1.0
        for (x, y) in cands:
            s, ang = max_inscribed((x, y), corners_list)
            if s > best_s:
                best_s = s
                best = (x, y, ang, s)
        if best is None:
            best = (0.5, 0.5, 0.0, 0.0)
        cx, cy, ang, s = best
        sq.append((cx, cy, ang, s))
        corners_list.append(square_corners(cx, cy, ang, s))
        if time.time() > time_limit:
            return None
    return sq


# ---------------------------------------------------------------------------
# Refinement: coordinate descent on centres and sizes.
# ---------------------------------------------------------------------------

def refine(sq, time_limit, total_time):
    """Iteratively adjust centres/angles/sizes to increase sum(side)."""
    n = len(sq)
    # Work with mutable list of dicts: x,y,ang,s
    arr = [{'x': cx, 'y': cy, 'a': ang, 's': s} for (cx, cy, ang, s) in sq]
    for item in arr:
        if item['s'] <= 0:
            item['s'] = 0.0

    def all_corners_skip(idx):
        out = []
        for j, it in enumerate(arr):
            if j == idx or it['s'] <= 0:
                continue
            out.append(square_corners(it['x'], it['y'], it['a'], it['s']))
        return out

    def can_place(idx, x, y, a, s):
        if s <= 0:
            return True
        corr = square_corners(x, y, a, s)
        others = all_corners_skip(idx)
        return local_ok(corr, others)

    iterations = 0
    improved_any = True
    # schedule: increasing number of passes
    pass_idx = 0
    while time.time() < time_limit and (time.time() - (time_limit - total_time)) < total_time * 0.95:
        pass_idx += 1
        improved_any = False
        # choose a shuffled order
        order = list(range(n))
        random.shuffle(order)
        for idx in order:
            it = arr[idx]
            old_s = it['s']
            # Try to grow the square while keeping centre/angle
            # binary search max s
            lo, hi = old_s, 1.0
            for _ in range(18):
                mid = 0.5 * (lo + hi)
                if can_place(idx, it['x'], it['y'], it['a'], mid):
                    lo = mid
                else:
                    hi = mid
            new_s = lo
            if new_s > old_s + 1e-9:
                it['s'] = new_s
                improved_any = True

            # Try shifting centre to allow even bigger size
            # sample offsets
            step = max(0.002, 0.05 * (1.0 - it['s']))
            for _ in range(6):
                if time.time() > time_limit:
                    break
                nx = it['x'] + random.uniform(-step, step)
                ny = it['y'] + random.uniform(-step, step)
                nx = min(max(nx, 0.0), 1.0)
                ny = min(max(ny, 0.0), 1.0)
                # attempt bigger size with same angle
                cand_s = min(1.0, it['s'] + step * 1.5)
                lo2, hi2 = it['s'], cand_s
                # check candidate
                if can_place(idx, nx, ny, it['a'], cand_s):
                    lo2 = cand_s
                else:
                    for _ in range(12):
                        mid = 0.5 * (lo2 + hi2)
                        if can_place(idx, nx, ny, it['a'], mid):
                            lo2 = mid
                        else:
                            hi2 = mid
                if lo2 > it['s'] + 1e-9:
                    it['x'] = nx
                    it['y'] = ny
                    it['s'] = lo2
                    improved_any = True

            # Try angle change
            for _ in range(4):
                if time.time() > time_limit:
                    break
                na = (it['a'] + random.uniform(-0.15, 0.15)) % 1.0
                lo3, hi3 = it['s'], min(1.0, it['s'] * 1.4 + 0.02)
                if can_place(idx, it['x'], it['y'], na, hi3):
                    lo3 = hi3
                else:
                    for _ in range(12):
                        mid = 0.5 * (lo3 + hi3)
                        if can_place(idx, it['x'], it['y'], na, mid):
                            lo3 = mid
                        else:
                            hi3 = mid
                if lo3 > it['s'] + 1e-9:
                    it['a'] = na
                    it['s'] = lo3
                    improved_any = True

        if not improved_any:
            break
        # stop if time
        if time.time() > time_limit:
            break

    # Convert back
    out = [(it['x'], it['y'], it['a'], it['s']) for it in arr]
    return out


def total_side(sq):
    return sum(s for (_, _, _, s) in sq)


# ---------------------------------------------------------------------------
# Main solver
# ---------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    start = time.time()
    TIME_LIMIT = 58.0  # seconds wall clock (leave margin)
    deadline = start + TIME_LIMIT

    rng = random.Random(12345 + n)

    best = None
    best_val = -1.0

    # ----- initial grids depending on n -----
    def grid_solution(n_):
        # best k x k grid, and fill leftovers with small squares
        k = max(1, math.isqrt(n_))
        side = 1.0 / k
        sq = []
        cnt = 0
        for i in range(k):
            for j in range(k):
                if cnt >= n_:
                    break
                sq.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
                cnt += 1
            if cnt >= n_:
                break
        # fill rest tiny at (0.5,0.5)? better distribute
        while cnt < n_:
            sq.append((0.5, 0.5, 0.0, 0.0))
            cnt += 1
        return sq

    # Try grid first
    g = grid_solution(n)
    if valid_distinct(g):
        v = total_side(g)
        if v > best_val:
            best_val = v
            best = g

    # Try greedy construction several times
    attempts = 0
    max_attempts = 60
    while time.time() < deadline * 0.92 and attempts < max_attempts:
        attempts += 1
        # use different random seeds
        gg = greedy_fill(n, rng, deadline * 0.92)
        if gg is None:
            break
        if not valid_distinct(gg):
            # try to repair: shrink invalid squares
            for i, (cx, cy, ang, s) in enumerate(gg):
                pass
            # skip invalid
            continue
        v = total_side(gg)
        if v > best_val:
            best_val = v
            best = gg
            # refine this one
            r = refine(gg, min(deadline, time.time() + 5.0), 5.0)
            if valid_distinct(r):
                vr = total_side(r)
                if vr > best_val:
                    best_val = vr
                    best = r

    # Final refinement on best
    if best is not None:
        remaining = deadline - time.time()
        if remaining > 0.5:
            r = refine(best, deadline, min(remaining, TIME_LIMIT * 0.4))
            if valid_distinct(r):
                vr = total_side(r)
                if vr > best_val:
                    best_val = vr
                    best = r

    # Sanity fallback
    if best is None or not valid_distinct(best):
        best = grid_solution(n)

    # Ensure length exactly n, padded with zero squares
    if len(best) < n:
        best = list(best) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    best = best[:n]

    # final safety: clamp all values to [0,1]
    fixed = []
    for (x, y, a, s) in best:
        x = min(1.0, max(0.0, x))
        y = min(1.0, max(0.0, y))
        a = a % 1.0
        s = min(1.0, max(0.0, s))
        fixed.append((x, y, a, s))
    return fixed
