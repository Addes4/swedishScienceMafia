import math
import random

# ---------- helpers ----------

def rect_layout(n):
    """Best exact rectangle partition of n into a*b cells (a columns, b rows)
    by expected side sum = a*w + b*h where w=1/a, h=1/b -> sum = 2."""
    best = (0.0, 1, n)
    for a in range(1, n + 1):
        for b in range(1, n // a + 1):
            if a * b == n:
                s = a * (1.0 / a) + b * (1.0 / b)
                if s > best[0]:
                    best = (s, a, b)
    # if n not exactly factorable, use floor square
    if best[1] * best[2] != n:
        k = math.isqrt(n)
        return k, k, n
    return best[1], best[2], best[0]

def pack_in_rect(cx, cy, w, h, count, angle, out):
    """Place count squares in a w x h rectangle centered at (cx,cy), all same angle."""
    # choose grid a x b = count that best matches aspect ratio w/h
    best = None
    for a in range(1, count + 1):
        if count % a:
            continue
        b = count // a
        # cell dims
        cw = w / a
        ch = h / b
        # max inscribed square side with rotation angle inside cw x ch
        s = max_square_in_rect(cw, ch, angle)
        score = a * b * s
        if best is None or score > best[0]:
            best = (score, a, b, cw, ch, s)
    _, a, b, cw, ch, s = best
    for i in range(a):
        for j in range(b):
            px = cx - w / 2 + (i + 0.5) * cw
            py = cy - h / 2 + (j + 0.5) * ch
            out.append((px, py, angle, s))

def max_square_in_rect(cw, ch, angle):
    """Largest square of orientation angle (fraction of turn) fitting in cw x ch rect."""
    if cw <= 0 or ch <= 0:
        return 0.0
    t = angle * 2 * math.pi
    c = abs(math.cos(t))
    s = abs(math.sin(t))
    # bounding box of rotated square side L: L*(c+s) in both dims (for 0<=t<=pi/2 sum)
    # for arbitrary angle use |cos|+|sin|
    denom = c + s
    if denom < 1e-12:
        return min(cw, ch)
    return min(cw, ch) / denom * 1.0

def total_score(squares):
    return sum(x[3] for x in squares)

def is_valid(squares, eps=1e-9):
    n = len(squares)
    for i in range(n):
        x1, y1, a1, s1 = squares[i]
        if s1 <= 0:
            continue
        for j in range(i + 1, n):
            x2, y2, a2, s2 = squares[j]
            if s2 <= 0:
                continue
            if overlap_squares(x1, y1, a1, s1, x2, y2, a2, s2, eps):
                return False
    # bounds check
    for x, y, a, s in squares:
        if s <= 0:
            continue
        if not square_in_unit(x, y, a, s, eps):
            return False
    return True

def corners(x, y, a, s):
    t = a * 2 * math.pi
    c = math.cos(t) * s / 2
    sn = math.sin(t) * s / 2
    return [
        (x - c + sn, y - sn - c),
        (x + c + sn, y + sn - c),
        (x + c - sn, y + sn + c),
        (x - c - sn, y - sn + c),
    ]

def square_in_unit(x, y, a, s, eps):
    for px, py in corners(x, y, a, s):
        if px < -eps or px > 1 + eps or py < -eps or py > 1 + eps:
            return False
    return True

def overlap_squares(x1, y1, a1, s1, x2, y2, a2, s2, eps):
    c1 = corners(x1, y1, a1, s1)
    c2 = corners(x2, y2, a2, s2)
    # SAT: 4 axes each
    for pts in (c1, c2):
        for k in range(4):
            px, py = pts[k]
            qx, qy = pts[(k + 1) % 4]
            ax, ay = -(qy - py), (qx - px)
            L = math.hypot(ax, ay)
            if L < 1e-15:
                continue
            ax /= L
            ay /= L
            p1 = [p[0] * ax + p[1] * ay for p in c1]
            p2 = [p[0] * ax + p[1] * ay for p in c2]
            if max(p1) < min(p2) + eps or max(p2) < min(p1) + eps:
                return False
    return True

# ---------- main solver ----------

def try_grid(n, angle):
    """Layout n squares using complete grid with rotation angle."""
    k = math.isqrt(n)
    # try all factorisations grid a x b covering n
    best = None
    for a in range(1, n + 1):
        if n % a:
            continue
        b = n // a
        w = 1.0 / a
        h = 1.0 / b
        s = max_square_in_rect(w, h, angle)
        squares = []
        for i in range(a):
            for j in range(b):
                cx = (i + 0.5) * w
                cy = (j + 0.5) * h
                squares.append((cx, cy, angle, s))
        sc = total_score(squares)
        if best is None or sc > best[0]:
            best = (sc, squares)
    return best[1]

def try_rect_grid(n, angle):
    """Partition unit square into rectangles, each packed with same-angle squares."""
    # find best (a,b) such that a*b <= n but not necessarily equal, then extra go in
    # Actually: distribute n squares among rectangles. Simple approach: try all (A,B)
    # rectangles a columns, b rows of cells.
    best = None
    for A in range(1, n + 1):
        for B in range(1, n + 1):
            if A * B > n:
                continue
            # distribute n squares among A*B cells as evenly as possible
            cells = A * B
            base = n // cells
            extra = n % cells
            w = 1.0 / A
            h = 1.0 / B
            if base == 0:
                # not enough squares to make full grid; fall back to fewer
                continue
            s = max_square_in_rect(w, h, angle)
            sc = n * s  # approx
            if best is None or sc > best[0]:
                best = (sc, A, B, w, h, s, base, extra)
    if best is None:
        return try_grid(n, angle)
    _, A, B, w, h, s, base, extra = best
    squares = []
    idx = 0
    for i in range(A):
        for j in range(B):
            cx = (i + 0.5) * w
            cy = (j + 0.5) * h
            cnt = base + (1 if idx < extra else 0)
            idx += 1
            if cnt == 0:
                continue
            if cnt == 1:
                squares.append((cx, cy, angle, s))
            else:
                # subdivide cell further
                sub = try_grid(cnt, angle)
                # scale sub from [0,1]^2 to cell
                for (sx, sy, sa, ss) in sub:
                    squares.append((cx - w / 2 + sx * w, cy - h / 2 + sy * h, sa, ss * min(w, h)))
    return squares

def optimize(n, squares, iters=2000, seed=42):
    """Local search: jitter centres, angles, sides to improve sum while valid."""
    rng = random.Random(seed)
    squares = [list(s) for s in squares]
    best = [list(s) for s in squares]
    best_score = total_score(squares)

    for it in range(iters):
        i = rng.randrange(n)
        cand = [list(s) for s in best]
        # try increasing side slightly and jitter
        x, y, a, s = cand[i]
        if s <= 0:
            s = 1e-3
        ds = rng.uniform(-0.02, 0.05)
        new_s = max(1e-6, s + ds)
        da = rng.uniform(-0.02, 0.02)
        new_a = a + da
        dx = rng.uniform(-0.01, 0.01)
        dy = rng.uniform(-0.01, 0.01)
        new_x = min(1.0, max(0.0, x + dx))
        new_y = min(1.0, max(0.0, y + dy))
        cand[i] = [new_x, new_y, new_a, new_s]
        if not square_in_unit(new_x, new_y, new_a, new_s, 1e-9):
            continue
        # check overlap with all
        ok = True
        for j in range(n):
            if j == i:
                continue
            x2, y2, a2, s2 = cand[j]
            if s2 <= 0:
                continue
            if overlap_squares(new_x, new_y, new_a, new_s, x2, y2, a2, s2, 1e-10):
                ok = False
                break
        if ok:
            sc = total_score(cand)
            if sc > best_score:
                best_score = sc
                best = cand
    return [tuple(s) for s in best]

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side by side: each 0.5 wide, side 0.5
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # 1 big + 2 small: big takes half, small fill remaining strip
        # big square side 0.5 at (0.25,0.5); two squares 0.5 each stacked right
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    # generic: try several angles and layouts, keep best valid
    candidates = []
    angles = [0.0, 0.25, 0.125, 0.375, 0.05, 0.2]
    for ang in angles:
        try:
            g = try_grid(n, ang)
            if is_valid(g):
                candidates.append(g)
        except Exception:
            pass
        try:
            r = try_rect_grid(n, ang)
            if is_valid(r):
                candidates.append(r)
        except Exception:
            pass
    # also baseline grid
    k = math.isqrt(n)
    s = 1.0 / k
    base = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
    base += [(0.5, 0.5, 0.0, 0.0)] * (n - len(base))
    candidates.append(base[:n])

    if not candidates:
        return base[:n]

    # pick best initial
    best = max(candidates, key=total_score)

    # local optimize
    iters = 3000 if n <= 20 else (1500 if n <= 60 else 600)
    improved = optimize(n, best, iters=iters, seed=n)

    # final validity check
    if is_valid(improved):
        return improved
    # fallback to best valid candidate
    for c in sorted(candidates, key=total_score, reverse=True):
        if is_valid(c):
            return c
    return base[:n]
