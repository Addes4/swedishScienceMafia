import math, random
import numpy as np

# ---------- geometry ----------
def corners(cx, cy, a, s):
    c, sn = math.cos(a*2*math.pi), math.sin(a*2*math.pi)
    h = s*0.5
    ux, uy = c*h, sn*h
    vx, vy = -sn*h, c*h
    return [(cx+ux+vx, cy+uy+vy), (cx-ux+vx, cy-uy+vy),
            (cx-ux-vx, cy-uy-vy), (cx+ux-vx, cy+uy-vy)]

def overlap(sq1, sq2, eps=1e-10):
    # sq: (cx,cy,angle,side). SAT over 4 axes.
    if sq1[3] <= 0 or sq2[3] <= 0: return False
    c1 = corners(*sq1); c2 = corners(*sq2)
    axes = []
    for poly in (c1, c2):
        for i in range(4):
            x1,y1 = poly[i]; x2,y2 = poly[(i+1)%4]
            ex, ey = x2-x1, y2-y1
            L = math.hypot(ex,ey)
            if L < 1e-15: continue
            axes.append((-ey/L, ex/L))
    for ax,ay in axes:
        p1 = [x*ax+y*ay for x,y in c1]
        p2 = [x*ax+y*ay for x,y in c2]
        if min(p1) >= max(p2)-eps or min(p2) >= max(p1)-eps:
            return False
    return True

def inside_unit(sq, eps=1e-9):
    for x,y in corners(*sq):
        if x < -eps or x > 1+eps or y < -eps or y > 1+eps:
            return False
    return True

def feasible(sqs, idx=None):
    n = len(sqs)
    if idx is None:
        idx = range(n)
    for i in idx:
        if not inside_unit(sqs[i]): return False
    for i in range(n):
        for j in range(i+1,n):
            if overlap(sqs[i],sqs[j]):
                return False
    return True

# ---------- initial constructions ----------
def grid_packing(n):
    k = math.isqrt(n)
    side = 1.0/k
    squares = [((i+0.5)*side,(j+0.5)*side,0.0,side) for i in range(k) for j in range(k)]
    squares += [(0.5,0.5,0.0,0.0)]*(n-len(squares))
    return squares[:n]

def hex_packing(n):
    """Try rows of rotated squares. Each square rotated 45deg fits in 1/sqrt(2) box.
       Use 45 deg rotation -> squares become diamond of diagonal s*sqrt2. Place on grid
       with cell size = s*sqrt2, plus offset rows for hex."""
    if n == 0: return []
    best = None
    for rot in (0.0, 0.25, 0.125, 0.375):
        for rows in range(1, n+1):
            cols = math.ceil(n/rows)
            # cell must fit rotated square of side s inside 1x1 area with rows x cols.
            # For rot=0: s = 1/max(rows,cols)? simpler: assume grid
            # General: bounding box of square rotated by angle a is s(|cos|+|sin|).
            a = rot*2*math.pi
            k = abs(math.cos(a))+abs(math.sin(a))
            # we place rows rows and cols cols. width needed cols*k*s <=1, height rows*k*s<=1
            s = min(1.0/(cols*k), 1.0/(rows*k))
            if s<=0: continue
            total = s*min(n, rows*cols)
            if best is None or total>best[0]:
                best = (total, rows, cols, s, rot)
    _, rows, cols, s, rot = best
    a = rot*2*math.pi
    k = abs(math.cos(a))+abs(math.sin(a))
    sx = k*s; sy = k*s
    squares=[]
    idx=0
    for j in range(rows):
        for i in range(cols):
            if idx>=n: break
            cx = (i+0.5)*sx
            cy = (j+0.5)*sy
            # Offset alternate rows to hex
            if j%2==1:
                cx += sx*0.5
            if cx + k*s*0.5 > 1+1e-9:
                cx -= sx*0.5
            squares.append((cx,cy,rot,s))
            idx+=1
        if idx>=n: break
    return squares

def honeycomb(n):
    """Diamond packing: place axis-aligned diamonds (45deg rotated squares).
       Diamond of side s has bounding box s*sqrt2 wide/tall. Two adjacent rows
       offset by half can interleave if we push them closer than s*sqrt2 vertically.
       Actually optimised: rotated square side s, rotated 45: vertices at distance
       r = s/sqrt(2). Place at hex lattice with spacing 2r horizontally and sqrt(3)r vertically."""
    if n==0: return []
    # We want sum s = n*s max. Lattice: centers spaced so squares don't overlap.
    # For 45deg squares (diamonds), touching along edges: horizontal distance between
    # centers in same row: s*sqrt2? no. Let's just do a horizontal row packing:
    # Each diamond spans width sqrt2*s and height sqrt2*s. Rows offset by sqrt2*s/2
    # vertical spacing sqrt2*s/2 (so squares in adjacent rows have alternating ranges).
    # To avoid overlap: diamond is |x-cx|+|y-cy| <= s/sqrt2.
    # Two diamonds centers (0,0) and (dx,dy) do not overlap iff |dx|+|dy| >= s*sqrt2.
    # For hex-like: row of diamonds adjacent: dx = s*sqrt2, dy=0.
    # next row offset dx/2, dy = s*sqrt2*? if dy = s*sqrt2/2, |dx/2|+|dy| = s*sqrt2/2 + s*sqrt2/2 = s*sqrt2 => touching.
    best=None
    for rows in range(1,n+1):
        cols=math.ceil(n/rows)
        # width: cols * s*sqrt2 <=1 ; height: (rows-1)*s*sqrt2/2 + s*sqrt2 <=1
        s1 = 1.0/(cols*math.sqrt(2))
        s2 = 1.0/(((rows-1)*0.5+1)*math.sqrt(2))
        s = min(s1,s2)
        total = s*min(n, rows*cols)
        if best is None or total>best[0]:
            best=(total,rows,cols,s)
    _,rows,cols,s = best
    d = s*math.sqrt(2)
    squares=[]
    idx=0
    for j in range(rows):
        for i in range(cols):
            if idx>=n:break
            cx = (i+0.5)*d + (j%2)*d*0.5
            cy = (j+0.5)*d*0.5 + d*0.5*0  # start at d/2 top
            cy = d*0.5 + j*d*0.5
            # adjust cx if off
            if cx + d*0.5 > 1+1e-9:
                cx -= d*0.5
            squares.append((cx,cy,0.25,s))
            idx+=1
        if idx>=n: break
    return squares

def best_initial(n):
    cands = [grid_packing(n), hex_packing(n), honeycomb(n)]
    # also try mixed: grid for k*k plus smaller for remainder
    k = math.isqrt(n)
    if k>0:
        side = 1.0/k
        # grid k x k with side, then remaining inside leftover? skip
        pass
    best = None; bs = -1
    for c in cands:
        s = sum(x[3] for x in c)
        f = feasible(c)
        if f and s>bs:
            bs=s; best=c
    if best is None:
        best = cands[0]
    return best

# ---------- local search ----------
def score(sqs):
    return sum(x[3] for x in sqs)

def local_optimize(sqs, time_budget_iters=2000):
    n=len(sqs)
    sqs=[list(x) for x in sqs]
    best = [list(x) for x in sqs]; bs = score(sqs)
    cur = [list(x) for x in sqs]; cs = bs
    random.seed(12345)
    T0 = 0.05
    for it in range(time_budget_iters):
        T = T0*(1 - it/time_budget_iters) + 1e-4
        i = random.randrange(n)
        old = cur[i][:]
        # random move type
        r = random.random()
        if r < 0.5:
            cur[i][3] *= (1.0 + random.uniform(-0.05,0.05))
            if cur[i][3] < 0: cur[i][3] = 0
        elif r < 0.75:
            cur[i][0] += random.uniform(-0.02,0.02)
            cur[i][1] += random.uniform(-0.02,0.02)
            cur[i][0]=min(1,max(0,cur[i][0]))
            cur[i][1]=min(1,max(0,cur[i][1]))
        else:
            cur[i][2] += random.uniform(-0.05,0.05)
            cur[i][2] %= 1.0
        # check global feasibility only near i and bounds
        ok = inside_unit(cur[i])
        if ok:
            for j in range(n):
                if j==i: continue
                if overlap(cur[i],cur[j]):
                    ok=False; break
        if ok:
            ns = cs - old[3] + cur[i][3]
            d = ns-cs
            if d >= 0 or random.random() < math.exp(d/T):
                cs = ns
                if cs > bs:
                    bs = cs
                    best = [list(x) for x in cur]
            else:
                cur[i]=old
        else:
            cur[i]=old
    return [tuple(x) for x in best]

def solve(n):
    if n <= 0: return []
    if n == 1:
        return [(0.5,0.5,0.0,1.0)]
    init = best_initial(n)
    # quick improvement: fill tiny squares where possible
    sqs = [list(x) for x in init]
    improved = local_optimize(init, time_budget_iters=min(4000, 200+n*20))
    # verify
    if not feasible(improved):
        return init
    return improved
