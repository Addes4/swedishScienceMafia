import math
import random
from scipy.optimize import minimize

def solve(n):
    if n <= 0:
        return []
    # Start with an initial guess: k x k grid for the largest k, rest have zero size
    k = math.isqrt(n)
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    squares = squares[:n]

    # For small n, try a simple optimization: treat positions and sizes as variables
    # For larger n, just return the grid (which is already optimal for perfect squares)
    if n <= 4:
        # For n=1,2,3,4 the grid is optimal or near-optimal
        if n == 2:
            squares = [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
        elif n == 3:
            # 3 squares: 2 small squares at bottom, one large square on top
            # Try a better packing: one square of side 0.5 at bottom left, one at bottom right,
            # and one square of side 0.5 at top rotated? Actually for 3, best is 2x2 grid with one missing
            # Let's try: big square side 0.5 at (0.5,0.75), two smaller squares side 0.5 at (0.25,0.25) and (0.75,0.25)
            squares = [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
        elif n == 4:
            squares = [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                       (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
        return squares

    # For n up to some limit, try to improve using local search over sizes and positions
    # For larger n, use a heuristic based on rows/columns packing
    if n <= 100:
        # Use a greedy approach: try to pack squares in a grid but allow some to be larger
        # Simple heuristic: divide into rows and columns, each cell gets a square
        # Determine best grid dimensions: rows * cols >= n
        best_squares = squares[:]
        best_score = sum(s[3] for s in squares)

        # Try different grid configurations
        for rows in range(1, n + 1):
            cols = (n + rows - 1) // rows
            if rows * cols < n:
                continue
            # Try to optimize sizes: each row can have different height
            # Simple: uniform grid
            w = 1.0 / cols
            h = 1.0 / rows
            s = min(w, h)
            # Place squares in grid, last row may have fewer
            candidate = []
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= n:
                        break
                    cx = (c + 0.5) * w
                    cy = (r + 0.5) * h
                    candidate.append((cx, cy, 0.0, s))
                    idx += 1
            if len(candidate) < n:
                candidate += [(0.5, 0.5, 0.0, 0.0)] * (n - len(candidate))
            score = sum(s[3] for s in candidate)
            if score > best_score:
                best_score = score
                best_squares = candidate

        # Try non-uniform: first row smaller, last row larger etc.
        # For simplicity, also try random perturbations
        for _ in range(50):
            candidate = [list(s) for s in best_squares]
            # Randomly adjust sizes and positions slightly
            for i in range(n):
                # perturb size
                delta = random.uniform(-0.05, 0.05) * candidate[i][3]
                candidate[i][3] = max(0.0, candidate[i][3] + delta)
                # perturb position
                candidate[i][0] += random.uniform(-0.02, 0.02)
                candidate[i][1] += random.uniform(-0.02, 0.02)
                # clamp
                s = candidate[i][3]
                candidate[i][0] = max(s/2, min(1 - s/2, candidate[i][0]))
                candidate[i][1] = max(s/2, min(1 - s/2, candidate[i][1]))
            # Check overlap roughly (axis-aligned only for speed)
            valid = True
            for i in range(n):
                for j in range(i+1, n):
                    if candidate[i][3] == 0 or candidate[j][3] == 0:
                        continue
                    # axis-aligned bounding box overlap check
                    if abs(candidate[i][0] - candidate[j][0]) < (candidate[i][3] + candidate[j][3])/2 - 1e-9:
                        if abs(candidate[i][1] - candidate[j][1]) < (candidate[i][3] + candidate[j][3])/2 - 1e-9:
                            valid = False
                            break
                if not valid:
                    break
            if valid:
                score = sum(s[3] for s in candidate)
                if score > best_score:
                    best_score = score
                    best_squares = [(s[0], s[1], s[2], s[3]) for s in candidate]
        return best_squares

    # For large n, just return the grid (near optimal for many n)
    return squares

if __name__ == "__main__":
    for n in [1, 2, 3, 4, 5, 9, 10, 16, 25, 100]:
        sol = solve(n)
        total = sum(s[3] for s in sol)
        print(f"n={n}, sum={total:.4f}, squares={len(sol)}")
