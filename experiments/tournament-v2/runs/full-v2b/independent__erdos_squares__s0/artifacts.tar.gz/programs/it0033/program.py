import math
import random
import numpy as np

def solve(n):
    # Deterministic base: grid packing (fast, always valid)
    if n <= 0:
        return []
    k = math.isqrt(n)
    s = 1.0 / k
    base = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
    base += [(0.5, 0.5, 0.0, 0.0)] * (n - len(base))
    base = base[:n]
    
    # For very large n, grid is near optimal; return it
    if n > 400:
        return base
    
    best = [list(x) for x in base]
    best_score = sum(x[3] for x in best)
    
    # Try some simple strip variants
    # Try m x k grid with extra strips
    for m in range(1, int(math.sqrt(n)) + 3):
        if m <= 0: continue
        # m rows, each with varying counts summing to n
        # Use m rows, distribute n squares roughly evenly
        rows = m
        counts = [n // rows + (1 if i < n % rows else 0) for i in range(rows)]
        if min(counts) <= 0: continue
        # For each row, squares have height = 1/rows, width = 1/count
        total = 0.0
        cand = []
        y = 0.0
        h = 1.0 / rows
        for r, c in enumerate(counts):
            w = 1.0 / c
            side = min(h, w)
            # if h == w, perfect
            for i in range(c):
                x = (i + 0.5) * (1.0 / c)
                cy = y + h * 0.5
                cand.append((x, cy, 0.0, side))
            y += h
        sc = sum(x[3] for x in cand)
        if sc > best_score:
            best_score = sc
            best = [list(x) for x in cand]
    
    # Simple optimization: try to improve by making a grid with non-uniform sizes
    # Use column-based: each column has a fixed width, squares fill height
    for cols in range(1, min(n, 30) + 1):
        # cols columns, each with c_i squares summing to n
        counts = [n // cols + (1 if i < n % cols else 0) for i in range(cols)]
        if min(counts) <= 0: continue
        w = 1.0 / cols
        cand = []
        total = 0.0
        x = 0.0
        for c in counts:
            h = 1.0 / c
            side = min(w, h)
            for i in range(c):
                cy = (i + 0.5) * (1.0 / c)
                cx = x + w * 0.5
                cand.append((cx, cy, 0.0, side))
            x += w
        sc = sum(s[3] for s in cand)
        if sc > best_score:
            best_score = sc
            best = [list(s) for s in cand]
    
    # Try uniform grid with rotation (rotated packing can help)
    # For small n, try some rotated patterns
    # Most promising: squares tilted at 45 degrees in a grid
    if n <= 20:
        # Try various rotation angles on the best grid found
        for angle in [0.0, 0.25, 0.125, 0.375]:
            if angle == 0.0:
                cand = [list(x) for x in best]
                sc = best_score
            else:
                # Apply rotation to a grid
                k = math.isqrt(n)
                s = 1.0 / (k * (abs(math.cos(2*math.pi*angle)) + abs(math.sin(2*math.pi*angle))))
                # This is tricky, skip for now
                continue
    
    # For small n, try a better approach: all squares same size rotated
    if n <= 16:
        # Try to fit n equal squares with rotation
        # approximate: for angle theta, bounding box of rotated square side s is
        # s*(|cos|+|sin|)
        # For n squares arranged in grid with rotation, each cell needs
        # diamond space; this is complex. Try random sizes instead.
        pass
    
    # Random local search improvement
    # We'll try small perturbations of the best configuration
    rng = random.Random(42)
    best_arr = [list(x) for x in best]
    best_sc = best_score
    
    # For each square, try to slightly expand it if possible
    # This isn't trivial with overlaps, so just try random configs for small n
    if n <= 12:
        # For small n, try configurations with all equal size
        # Optimal for n=1 is 1.0, n=2 is 1.0 (two halves), n=3 is ~1.0?
        # Known: n=2: 1.0, n=3: 1.0 (one big + two small? no, 3 squares sum > 1?)
        # Actually 3 squares: 0.5,0.5,0.5 -> sum 1.5? No, can't fit 3 squares of side 0.5 in unit square.
        # 3 squares: two of side 0.5 on bottom, one of side 0.5 on top? That's 3 squares of 0.5, 
        # but 0.5*2=1.0 wide, 0.5*2=1.0 tall, so 4 fit. 3 squares: 0.5, 0.5, and one more 0.5 = sum 1.5.
        # Wait, 3 squares of side 0.5 fit in 2x2 grid easily (use 3 cells). Sum = 1.5.
        # Can we do better? One square of side 1.0 leaves no room. No.
        # Actually 3 squares: side 1.0, then 0, 0 -> sum 1.0. Or 0.5*3=1.5.
        # Better: two squares of 0.5, one of 1.0? No, 1.0 takes all space.
        # So 3: 0.5+0.5+0.5 = 1.5 is good. Can we get more? 0.6+0.6+0.4? 
        # sqrt: try grid search for small n with random search.
        
        # For n=3, we can do 0.5,0.5,0.5 easily.
        # For n=4, 0.5*4 = 2.0
        # For n=5: 4 of 0.5 + one 0? or 5 of 0.4 = 2.0? 
        # Actually 2x2 grid of 0.5 = 2.0, plus 1 zero -> 2.0. 
        # Or 5 squares: 0.5,0.5,0.5,0.5,0.25? sum=2.25? Can we fit?
        # 2x2 grid of 0.5 uses all space. So 5th must be zero, or reduce sizes.
        # 0.5,0.5,0.5,0.5 is max. 5th can't fit. So 2.0 for n=5? 
        # Actually we can do: two rows of 2.5 squares? Not integer.
        # Better: 5 squares of side 1/sqrt(5)? That's 0.447, sum = 2.236. 
        # But 5 squares of 0.447 in 2x3 grid? 2 rows of 3 = 6, use 5, side 0.5 -> wait 1/2=0.5 width, 1/3=0.333 height, min=0.333.
        # No, 5 squares: could be 3 in one row, 2 in another. Width 1/3 each = 0.333, heights 1/2=0.5 -> side 0.333, sum=1.667. Worse.
        # 5 squares: one column of 5 (side 0.2 each, sum 1.0), or 2x3 grid with 5 cells (side 0.5*0.333=0.333).
        # Actually known result: for n=5, optimal is 2.2071... (two distinct sizes)
        # Let's just do random search for small n.
        
        # Simple random search: generate random configs and keep best
        for _ in range(200):
            cand = []
            for _ in range(n):
                cand.append([rng.random(), rng.random(), rng.random(), rng.random() * 0.5])
            # Check validity and compute score - too expensive.
            pass
    
    # For n=1, return the full square
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    # For n=2: two squares of side 0.5 side by side -> sum 1.0
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    
    # For n=3: three squares of side 0.5 in 2x2 grid minus one cell -> 1.5
    if n == 3:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5)]
    
    # For n=4: four squares of 0.5 -> 2.0
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    
    # For n=5: try 4 squares of 0.5 (sum 2.0) + 1 of 0.0, or 5 squares of 1/sqrt(5)~0.447 in some pattern?
    # Actually 5 squares can be: 3 in bottom row (0.333 each), 2 in top row (0.5 each)? 
    # Bottom row 3 squares of side 1/3 = 0.333, height 1/3. Top row 2 squares of side 0.5, height 0.5.
    # Total height 1/3 + 0.5 = 0.833 < 1. But top row squares of 0.5 width each -> 2*0.5=1.0 wide. OK.
    # Sum = 3*(1/3) + 2*0.5 = 1 + 1 = 2.0. Same as before.
    # Better: bottom row 3 squares of side 1/3 (height 1/3), top row can have 2 squares of side 0.5 
    # but only use 2/3 of height -> side 0.5? no, need width 1/2 each.
    # Actually they can be taller: side = min(0.5, remaining height). Remaining height = 2/3, so side = 0.5.
    # So 5 squares: 3*(1/3) + 2*(0.5) = 1 + 1 = 2.0.
    # Can we do better? Use a square of side > 0.5? Then it takes more than half, limiting others.
    # Known: n=5 optimal is 2.2071 (from literature). Pattern: one square of side ~0.568, and 4 of side ~0.392?
    # Let's approximate. Actually let's use a simple heuristic.
    if n == 5:
        # One big square of side s in corner, others in L-shape
        # Try s = 0.5: remaining L-shape has area 0.75. 
        # 4 squares: can we fit 4 squares of side 0.5? No, only 3 fit (2x2 minus one).
        # Try s=0.6: remaining area 0.64, 4 squares of side up to 0.4? 
        # Two on bottom: width 0.6... complex. Just use 2.0 config.
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5),
                (0.5, 0.5, 0.0, 0.0)]
    
    # For general n, return the best found
    return [(x[0], x[1], x[2], x[3]) for x in best]
