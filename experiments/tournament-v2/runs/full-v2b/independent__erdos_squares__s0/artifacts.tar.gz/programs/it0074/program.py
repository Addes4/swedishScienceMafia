import math
import numpy as np
from scipy.optimize import minimize


def _corners(cx, cy, angle, side):
    """Return the four corners of a square."""
    c = math.cos(2 * math.pi * angle)
    s = math.sin(2 * math.pi * angle)
    h = side / 2.0
    corners = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        corners.append((cx + dx * c - dy * s, cy + dx * s + dy * c))
    return corners


def _overlap_area(sq1, sq2):
    """Compute the overlap area between two squares (convex polygons)."""
    c1 = _corners(*sq1)
    c2 = _corners(*sq2)

    def clip(poly, a, b):
        out = []
        n = len(poly)
        for i in range(n):
            p = poly[i]
            q = poly[(i + 1) % n]
            # signed distance to line a->b
            def side_func(pt):
                return (b[0] - a[0]) * (pt[1] - a[1]) - (b[1] - a[1]) * (pt[0] - a[0])
            sp = side_func(p)
            sq = side_func(q)
            if sp >= 0:
                out.append(p)
            if (sp > 0 and sq < 0) or (sp < 0 and sq > 0):
                t = sp / (sp - sq)
                out.append((p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])))
        return out

    # Sutherland-Hodgman clipping: clip c1 by c2
    poly = c1
    for i in range(4):
        a = c2[i]
        b = c2[(i + 1) % 4]
        # ensure counter-clockwise orientation for outward normal test
        # we want inside = left side of edge a->b for CCW polygon
        # check orientation of c2
        pass
    # Determine orientation of c2
    area2 = 0
    for i in range(4):
        x1, y1 = c2[i]
        x2, y2 = c2[(i + 1) % 4]
        area2 += x1 * y2 - x2 * y1
    if area2 < 0:
        c2 = c2[::-1]

    poly = c1
    for i in range(4):
        a = c2[i]
        b = c2[(i + 1) % 4]
        poly = clip(poly, a, b)
        if not poly:
            return 0.0
    # polygon area
    area = 0.0
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        area += x1 * y2 - x2 * y1
    return abs(area) / 2.0


def _total_overlap(params, n):
    """Sum of pairwise overlap areas."""
    total = 0.0
    squares = []
    for i in range(n):
        cx, cy, angle, side = params[4 * i:4 * i + 4]
        squares.append((cx, cy, angle, side))
    for i in range(n):
        for j in range(i + 1, n):
            total += _overlap_area(squares[i], squares[j])
    return total


def _neg_sum_sides(params, n):
    return -sum(params[4 * i + 3] for i in range(n))


def _penalty(params, n, lamb=1000.0):
    return _neg_sum_sides(params, n) + lamb * _total_overlap(params, n)


def _initial_grid(n):
    """Start with a grid of squares."""
    k = math.isqrt(n)
    side = 1.0 / k
    params = []
    count = 0
    for i in range(k):
        for j in range(k):
            if count >= n:
                break
            params.extend([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
            count += 1
        if count >= n:
            break
    while len(params) < 4 * n:
        params.extend([0.5, 0.5, 0.0, 0.0])
    return np.array(params[:4 * n])


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    x0 = _initial_grid(n)

    # bounds: centre in [0,1], angle in [0,1), side in [0,1]
    bounds = []
    for i in range(n):
        bounds.extend([(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)])

    # Use penalty method with decreasing lambda
    best_params = x0.copy()
    best_score = -_penalty(x0, n, lamb=1e6)

    for lamb in [1e6, 1e5, 1e4, 1e3, 1e2, 10.0, 1.0]:
        try:
            res = minimize(
                _penalty, best_params, args=(n, lamb),
                method='L-BFGS-B', bounds=bounds,
                options={'maxiter': 300, 'ftol': 1e-12, 'gtol': 1e-10}
            )
            if res.fun < _penalty(best_params, n, lamb):
                best_params = res.x
        except Exception:
            pass

    # Final refinement with very high penalty for overlaps
    try:
        res = minimize(
            _penalty, best_params, args=(n, 1e8),
            method='L-BFGS-B', bounds=bounds,
            options={'maxiter': 500, 'ftol': 1e-14, 'gtol': 1e-12}
        )
        if res.fun < _penalty(best_params, n, 1e8):
            best_params = res.x
    except Exception:
        pass

    # Extract and clean result
    result = []
    for i in range(n):
        cx, cy, angle, side = best_params[4 * i:4 * i + 4]
        # clamp
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        angle = angle % 1.0
        side = min(max(side, 0.0), 1.0)
        result.append((cx, cy, angle, side))

    # Greedy repair: shrink any square that overlaps another
    for _ in range(50):
        max_overlap = 0.0
        pair = None
        for i in range(n):
            for j in range(i + 1, n):
                a = _overlap_area(result[i], result[j])
                if a > max_overlap:
                    max_overlap = a
                    pair = (i, j)
        if max_overlap < 1e-10 or pair is None:
            break
        i, j = pair
        # shrink both slightly
        for idx in (i, j):
            cx, cy, angle, side = result[idx]
            result[idx] = (cx, cy, angle, max(0.0, side * 0.95))

    # ensure inside unit square (shrink if needed)
    for idx in range(n):
        cx, cy, angle, side = result[idx]
        corners = _corners(cx, cy, angle, side)
        minx = min(c[0] for c in corners)
        maxx = max(c[0] for c in corners)
        miny = min(c[1] for c in corners)
        maxy = max(c[1] for c in corners)
        # shift inside
        if minx < 0:
            cx -= minx
        if maxx > 1:
            cx -= (maxx - 1)
        if miny < 0:
            cy -= miny
        if maxy > 1:
            cy -= (maxy - 1)
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        result[idx] = (cx, cy, angle, side)

    return result
