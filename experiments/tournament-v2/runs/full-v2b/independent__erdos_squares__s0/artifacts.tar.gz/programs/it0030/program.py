import math
import random
import numpy as np
from scipy.optimize import minimize

EPS = 1e-12


def _rotate(x, y, a):
    ca = math.cos(2 * math.pi * a)
    sa = math.sin(2 * math.pi * a)
    return ca * x - sa * y, sa * x + ca * y


def _corners(cx, cy, a, s):
    h = s * 0.5
    pts = []
    for sx, sy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x, y = _rotate(sx, sy, a)
        pts.append((cx + x, cy + y))
    return pts


def _overlap_area_sat(c1, c2):
    # Separating Axis Theorem overlap area approximation via polygon clipping
    # Here we only need a penalty; use conservative center-distance based check
    # plus SAT axis separation for rotated square. Return approximate overlap area.
    # Simpler: compute polygon intersection area by clipping.
    def clip(poly, a, b):
        # keep points on left of directed line a->b
        out = []
        if not poly:
            return out
        n = len(poly)
        for i in range(n):
            p = poly[i]
            q = poly[(i + 1) % n]
            da = (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])
            db = (b[0] - a[0]) * (q[1] - a[1]) - (b[1] - a[1]) * (q[0] - a[0])
            if da >= -EPS:
                out.append(p)
            if (da > EPS and db < -EPS) or (da < -EPS and db > EPS):
                t = da / (da - db)
                out.append((p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])))
        return out

    def poly_area(poly):
        if len(poly) < 3:
            return 0.0
        s = 0.0
        for i in range(len(poly)):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % len(poly)]
            s += x1 * y2 - x2 * y1
        return abs(s) * 0.5

    poly = list(c1)
    for i in range(len(c2)):
        a = c2[i]
        b = c2[(i + 1) % len(c2)]
        poly = clip(poly, a, b)
        if not poly:
            return 0.0
    return poly_area(poly)


def _bounds_penalty(pts):
    pen = 0.0
    for x, y in pts:
        if x < 0:
            pen += x * x
        elif x > 1:
            pen += (x - 1) * (x - 1)
        if y < 0:
            pen += y * y
        elif y > 1:
            pen += (y - 1) * (y - 1)
    return pen


def _score(params, n):
    # params: cx,cy,a,s for each square
    total = 0.0
    corners = []
    for i in range(n):
        cx, cy, a, s = params[4 * i:4 * i + 4]
        total += s
        corners.append(_corners(cx, cy, a, s))
    return total, corners


def _objective(params, n, lam=200.0):
    total, corners = _score(params, n)
    pen = 0.0
    # boundary penalty
    allpts = [p for c in corners for p in c]
    pen += _bounds_penalty(allpts)
    # overlap penalty
    for i in range(n):
        for j in range(i + 1, n):
            ov = _overlap_area_sat(corners[i], corners[j])
            pen += ov
    return -total + lam * pen


def _pack_grid(n):
    # Try several grid sizes and choose best sum
    best = None
    best_sum = -1
    for k in range(1, n + 1):
        if k * k > n:
            continue
        # place k*k squares in grid, extra zero-size
        side = 1.0 / k
        sq = []
        for i in range(k):
            for j in range(k):
                sq.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        while len(sq) < n:
            sq.append((0.5, 0.5, 0.0, 0.0))
        total = k * k * side + (n - k * k) * 0.0
        if total > best_sum:
            best_sum = total
            best = sq
    return best


def _multi_start_opt(n, seeds, maxiter=400):
    best = None
    best_val = 1e18
    for s in seeds:
        params = np.array(s, dtype=float).copy()
        res = minimize(_objective, params, args=(n,),
                       method='L-BFGS-B',
                       bounds=[(0.0, 1.0)] * (4 * n),
                       options={'maxiter': maxiter, 'ftol': 1e-12, 'gtol': 1e-8})
        val = _objective(res.x, n, lam=0.0)
        if val < best_val:
            best_val = val
            best = res.x
    return best, -best_val


def _random_seed(n):
    sq = []
    for _ in range(n):
        sq.append((random.random(), random.random(), random.random(), random.random() * 0.3))
    return sq


def _structured_seeds(n):
    seeds = []
    # grid-based
    seeds.append(_pack_grid(n))
    # single big square + others
    single = [(0.5, 0.5, 0.0, 1.0)] + [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
    seeds.append(single)
    # a few random
    for _ in range(8):
        seeds.append(_random_seed(n))
    # strips
    if n >= 2:
        for k in range(1, n):
            if k > 0 and n - k > 0:
                s1 = 1.0 / max(k, 1)
                s2 = 1.0 / max(n - k, 1)
                sq = []
                # simple two-column layout
                side1 = 1.0 / k
                for i in range(k):
                    sq.append(((i + 0.5) * side1, 0.5, 0.0, side1))
                side2 = 1.0 / (n - k)
                for i in range(n - k):
                    sq.append((0.5, (i + 0.5) * side2, 0.0, side2))
                if len(sq) == n:
                    seeds.append(sq[:n])
    return seeds


def _pack_recursive(n, x0=0.0, y0=0.0, w=1.0, h=1.0, depth=0):
    # recursively split rectangle into cells, assign grid squares
    if n <= 0:
        return []
    if n == 1:
        s = min(w, h)
        return [(x0 + w * 0.5, y0 + h * 0.5, 0.0, s)]
    # try to make a roughly square grid
    k = int(math.sqrt(n))
    if k < 1:
        k = 1
    # split into k columns and ceil(n/k) rows
    rows = (n + k - 1) // k
    cw = w / k
    ch = h / rows
    side = min(cw, ch)
    sq = []
    cnt = 0
    for r in range(rows):
        for c in range(k):
            if cnt >= n:
                break
            cx = x0 + (c + 0.5) * cw
            cy = y0 + (r + 0.5) * ch
            sq.append((cx, cy, 0.0, side))
            cnt += 1
        if cnt >= n:
            break
    while len(sq) < n:
        sq.append((x0 + w * 0.5, y0 + h * 0.5, 0.0, 0.0))
    return sq


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # For large n, use a fast heuristic
    if n > 40:
        # Try recursive packing and grid, pick better
        candidates = []
        sq1 = _pack_grid(n)
        candidates.append(sq1)
        sq2 = _pack_recursive(n)
        candidates.append(sq2)
        best = None
        best_sum = -1
        for sq in candidates:
            total = sum(s[3] for s in sq)
            # check overlaps roughly
            ok = True
            for i in range(len(sq)):
                for j in range(i + 1, len(sq)):
                    cx1, cy1, a1, s1 = sq[i]
                    cx2, cy2, a2, s2 = sq[j]
                    if s1 < EPS or s2 < EPS:
                        continue
                    # bounding circle check
                    r1 = s1 * 0.5 * math.sqrt(2)
                    r2 = s2 * 0.5 * math.sqrt(2)
                    d = math.hypot(cx1 - cx2, cy1 - cy2)
                    if d < r1 + r2 - 1e-9:
                        # potential overlap; conservative: reject if centers too close
                        # use SAT exact
                        c1 = _corners(cx1, cy1, a1, s1)
                        c2 = _corners(cx2, cy2, a2, s2)
                        if _overlap_area_sat(c1, c2) > 1e-8:
                            ok = False
                            break
                if not ok:
                    break
            if ok and total > best_sum:
                best_sum = total
                best = sq
        if best is not None:
            return best[:n]
        return sq1[:n]

    # For small n, do numerical optimization with multiple starts
    seeds = _structured_seeds(n)
    # cap number of seeds for time
    if len(seeds) > 20:
        seeds = seeds[:20]
    best_params, best_val = _multi_start_opt(n, seeds, maxiter=300)
    # final refine
    if best_params is not None:
        res = minimize(_objective, best_params, args=(n,),
                       method='L-BFGS-B',
                       bounds=[(0.0, 1.0)] * (4 * n),
                       options={'maxiter': 1000, 'ftol': 1e-14, 'gtol': 1e-10})
        best_params = res.x
    if best_params is None:
        return _pack_grid(n)[:n]
    # Clean up: clamp and zero out tiny/overlapping squares
    result = []
    for i in range(n):
        cx, cy, a, s = best_params[4 * i:4 * i + 4]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = a % 1.0
        s = max(0.0, min(s, 1.0))
        result.append((cx, cy, a, s))
    # final overlap removal by shrinking
    for _ in range(3):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                cx1, cy1, a1, s1 = result[i]
                cx2, cy2, a2, s2 = result[j]
                if s1 < EPS or s2 < EPS:
                    continue
                c1 = _corners(cx1, cy1, a1, s1)
                c2 = _corners(cx2, cy2, a2, s2)
                ov = _overlap_area_sat(c1, c2)
                if ov > 1e-9:
                    # shrink both slightly
                    factor = 0.9
                    result[i] = (cx1, cy1, a1, s1 * factor)
                    result[j] = (cx2, cy2, a2, s2 * factor)
                    changed = True
        if not changed:
            break
    # ensure bounds
    for i in range(n):
        cx, cy, a, s = result[i]
        if s > 0:
            c = _corners(cx, cy, a, s)
            minx = min(p[0] for p in c)
            maxx = max(p[0] for p in c)
            miny = min(p[1] for p in c)
            maxy = max(p[1] for p in c)
            # scale down if outside
            scale = 1.0
            if minx < 0:
                scale = min(scale, (maxx - 0) / (maxx - minx + 1e-12))
            if maxx > 1:
                scale = min(scale, (1 - minx) / (maxx - minx + 1e-12))
            if miny < 0:
                scale = min(scale, (maxy - 0) / (maxy - miny + 1e-12))
            if maxy > 1:
                scale = min(scale, (1 - miny) / (maxy - miny + 1e-12))
            if scale < 1.0:
                result[i] = (cx, cy, a, s * scale)
    return result[:n]
