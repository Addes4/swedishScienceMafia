import math
import random
import numpy as np
from scipy.optimize import minimize

# ---------- geometry helpers ----------

def square_corners(cx, cy, angle, side):
    """Return the 4 corners of a square (center, angle in turns, side)."""
    a = angle * 2.0 * math.pi
    c, s = math.cos(a), math.sin(a)
    h = side * 0.5
    # local corners
    loc = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + x * c - y * s, cy + x * s + y * c) for x, y in loc]

def project_polygon(poly, axis):
    dots = [p[0] * axis[0] + p[1] * axis[1] for p in poly]
    return min(dots), max(dots)

def polygons_intersect(poly1, poly2):
    """Separating axis theorem: return True if interiors overlap."""
    for poly in (poly1, poly2):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            edge = (x2 - x1, y2 - y1)
            # perpendicular
            axis = (-edge[1], edge[0])
            length = math.hypot(axis[0], axis[1])
            if length < 1e-15:
                continue
            axis = (axis[0] / length, axis[1] / length)
            min1, max1 = project_polygon(poly1, axis)
            min2, max2 = project_polygon(poly2, axis)
            if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
                return False
    return True

def inside_unit(cx, cy, angle, side):
    """Check if square is fully inside [0,1]^2."""
    poly = square_corners(cx, cy, angle, side)
    for x, y in poly:
        if x < -1e-12 or x > 1 + 1e-12 or y < -1e-12 or y > 1 + 1e-12:
            return False
    return True

# ---------- penalty computation ----------

def penalty(squares):
    """Return a penalty measuring overlap and out-of-bounds violations."""
    n = len(squares)
    polys = [square_corners(cx, cy, ang, sd) for cx, cy, ang, sd in squares]
    pen = 0.0
    # bounds
    for i, poly in enumerate(polys):
        for x, y in poly:
            if x < 0:
                pen += (-x) ** 2
            elif x > 1:
                pen += (x - 1) ** 2
            if y < 0:
                pen += (-y) ** 2
            elif y > 1:
                pen += (y - 1) ** 2
    # overlaps
    for i in range(n):
        for j in range(i + 1, n):
            if squares[i][3] <= 1e-14 or squares[j][3] <= 1e-14:
                continue
            if polygons_intersect(polys[i], polys[j]):
                # approximate overlap depth via center distance to nearest corner? use penetration
                # Simple heavy penalty; exact depth not needed for gradient-free.
                pen += 1.0
    return pen

# ---------- initial layouts ----------

def grid_layout(n):
    """Largest integer grid plus leftovers as tiny squares."""
    k = math.isqrt(n)
    base = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([(i + 0.5) * base, (j + 0.5) * base, 0.0, base])
    # fill remaining with tiny squares, placed in a row at top
    rem = n - k * k
    for t in range(rem):
        x = (t + 0.5) / max(rem, 1) * 1.0
        squares.append([min(max(x, 0.01), 0.99), 0.99, 0.0, 0.0])
    return squares[:n]

def spiral_layout(n):
    """Spiral packing heuristic: place squares decreasing in size along a spiral."""
    # sizes: geometric-ish
    sizes = []
    if n == 1:
        sizes = [1.0]
    else:
        # start with 1/sqrt(n) and shrink slightly
        s = 1.0 / math.sqrt(n) * 1.05
        for i in range(n):
            sizes.append(s)
            s *= 0.98
    # positions: fill a grid but skip
    k = math.isqrt(n) + 1
    base = 1.0 / k
    squares = []
    idx = 0
    for i in range(k):
        for j in range(k):
            if idx >= n:
                break
            cx = (i + 0.5) * base
            cy = (j + 0.5) * base
            squares.append([min(max(cx, 0.01), 0.99), min(max(cy, 0.01), 0.99), 0.0, min(sizes[idx], base * 0.99)])
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    return squares[:n]

def random_layout(n, rng):
    """Random small squares with random rotations."""
    squares = []
    for _ in range(n):
        cx = rng.uniform(0.1, 0.9)
        cy = rng.uniform(0.1, 0.9)
        ang = rng.uniform(0, 1)
        side = rng.uniform(0.01, min(0.3, 1.0/math.sqrt(max(n,1))))
        squares.append([cx, cy, ang, side])
    return squares

# ---------- optimization ----------

def optimize_squares(squares, n, time_limit_iters=5000, rng=None):
    """Local search: random perturbations, accept if penalty decreases or with annealing."""
    if rng is None:
        rng = random.Random(12345)

    best = [list(s) for s in squares]
    best_pen = penalty(best)

    # Scale initial step sizes
    step = 0.05
    temp = 0.01
    for it in range(time_limit_iters):
        cand = [list(s) for s in best]
        # pick one square (or a few)
        i = rng.randrange(n)
        # perturb center, angle, side
        cand[i][0] += rng.gauss(0, step)
        cand[i][1] += rng.gauss(0, step)
        cand[i][2] = (cand[i][2] + rng.gauss(0, step)) % 1.0
        cand[i][3] = max(0.0, cand[i][3] + rng.gauss(0, step * 0.5))
        # clamp center to [0,1]
        cand[i][0] = min(max(cand[i][0], 0.0), 1.0)
        cand[i][1] = min(max(cand[i][1], 0.0), 1.0)

        p = penalty(cand)
        if p < best_pen or rng.random() < math.exp(-(p - best_pen) / max(temp, 1e-9)):
            best = cand
            best_pen = p
        # cooling
        if it % 500 == 0:
            temp *= 0.8
            step *= 0.9
            step = max(step, 0.0005)

        if best_pen < 1e-9 and it > 1000:
            # try growing sides a bit
            break

    # Phase 2: if feasible, try to increase side lengths greedily
    if best_pen < 1e-6:
        improved = True
        tries = 0
        while improved and tries < 3000:
            improved = False
            tries += 1
            for i in range(n):
                cand = [list(s) for s in best]
                cand[i][3] *= 1.02
                p = penalty(cand)
                if p < 1e-6:
                    best = cand
                    best_pen = p
                    improved = True
                else:
                    # try slight shrink
                    cand = [list(s) for s in best]
                    cand[i][3] *= 0.98
                    p = penalty(cand)
                    if p < 1e-6:
                        best = cand
                        best_pen = p
                        improved = True
    return best

# ---------- main solver ----------

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside unit square."""
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(1234 + n)

    best_result = None
    best_score = -1.0
    best_pen = float('inf')

    # Try multiple initial layouts
    candidates = []
    candidates.append(grid_layout(n))
    candidates.append(spiral_layout(n))
    for _ in range(5):
        candidates.append(random_layout(n, rng))

    # also try a greedy sequential placement
    # (place largest squares first at random positions)
    for trial in range(3):
        seq = []
        remaining = n
        # start with grid layout as base
        base = grid_layout(n)
        seq = base
        candidates.append(seq)

    for cand in candidates:
        # First, make it feasible by shrinking overlapping squares
        c = [list(s) for s in cand]
        for _ in range(500):
            p = penalty(c)
            if p < 1e-9:
                break
            # find worst overlapping square and shrink it
            worst_i = -1
            worst_pen = -1
            for i in range(n):
                if c[i][3] <= 1e-14:
                    continue
                # compute individual contribution: shrink and see penalty
                old = c[i][3]
                c[i][3] = old * 0.7
                newp = penalty(c)
                if p - newp > worst_pen:
                    worst_pen = p - newp
                    worst_i = i
                c[i][3] = old
            if worst_i >= 0:
                c[worst_i][3] *= 0.7
                # also try moving it
                c[worst_i][0] = min(max(c[worst_i][0] + rng.gauss(0, 0.05), 0.0), 1.0)
                c[worst_i][1] = min(max(c[worst_i][1] + rng.gauss(0, 0.05), 0.0), 1.0)
            else:
                break

        # optimize
        iter_count = 3000
        opt = optimize_squares(c, n, iter_count, rng)

        # evaluate
        p = penalty(opt)
        score = sum(s[3] for s in opt) if p < 1e-6 else -p
        if p < 1e-6 and score > best_score:
            best_score = score
            best_result = opt
            best_pen = p

    if best_result is None:
        # fallback: return feasible by shrinking all to near zero
        best_result = grid_layout(n)
        for i in range(n):
            best_result[i][3] = 0.0

    # Ensure feasibility: if still infeasible, shrink all sides
    attempts = 0
    while penalty(best_result) > 1e-6 and attempts < 20:
        for s in best_result:
            s[3] *= 0.9
        attempts += 1

    # final safety: if not feasible, return zeros
    if penalty(best_result) > 1e-6:
        for s in best_result:
            s[0] = min(max(s[0], 0.0), 1.0)
            s[1] = min(max(s[1], 0.0), 1.0)
            s[2] = 0.0
            s[3] = 0.0

    # clamp angles and centers
    for s in best_result:
        s[0] = min(max(s[0], 0.0), 1.0)
        s[1] = min(max(s[1], 0.0), 1.0)
        s[2] = s[2] % 1.0
        s[3] = max(0.0, min(s[3], 1.0))

    return [tuple(s) for s in best_result[:n]]
