import math
import random
import numpy as np
from scipy.optimize import minimize


def _square_corners(cx, cy, angle, side):
    """Return the four corners of a square as a 4x2 array."""
    a = 2.0 * math.pi * angle
    c, s = math.cos(a), math.sin(a)
    h = side * 0.5
    pts = np.array([[-h, -h], [h, -h], [h, h], [-h, h]], dtype=float)
    R = np.array([[c, -s], [s, c]])
    return pts @ R.T + np.array([cx, cy])


def _overlap_sat(p, q):
    """Separating-axis overlap depth between two convex polygons."""
    # returns positive if interiors overlap, 0 otherwise
    for poly in (p, q):
        m = len(poly)
        for i in range(m):
            j = (i + 1) % m
            edge = poly[j] - poly[i]
            axis = np.array([-edge[1], edge[0]])
            nrm = np.hypot(axis[0], axis[1])
            if nrm < 1e-15:
                continue
            axis = axis / nrm
            pp = p @ axis
            qq = q @ axis
            if pp.min() >= qq.max() - 1e-12 or qq.min() >= pp.max() - 1e-12:
                return 0.0
    # simple depth estimate: minimal translation along any axis
    best = 1e9
    for poly in (p, q):
        m = len(poly)
        for i in range(m):
            j = (i + 1) % m
            edge = poly[j] - poly[i]
            axis = np.array([-edge[1], edge[0]])
            nrm = np.hypot(axis[0], axis[1])
            if nrm < 1e-15:
                continue
            axis = axis / nrm
            pp = p @ axis
            qq = q @ axis
            ov1 = min(pp.max(), qq.max()) - max(pp.min(), qq.min())
            if ov1 < best:
                best = ov1
    return max(0.0, best)


def _penalty(params, n):
    """Objective: negative sum of sides + big penalty for overlaps and boundary violations."""
    squares = params.reshape(n, 4)
    corners = []
    for i in range(n):
        cx, cy, ang, side = squares[i]
        corners.append(_square_corners(cx, cy, ang, side))

    total = 0.0
    pen = 0.0
    for i in range(n):
        total -= squares[i][3]

        # boundary: all corners must be in [0,1]
        c = corners[i]
        lo = c.min(axis=0)
        hi = c.max(axis=0)
        if lo[0] < 0:
            pen += (0 - lo[0]) ** 2 * 1e5
        if lo[1] < 0:
            pen += (0 - lo[1]) ** 2 * 1e5
        if hi[0] > 1:
            pen += (hi[0] - 1) ** 2 * 1e5
        if hi[1] > 1:
            pen += (hi[1] - 1) ** 2 * 1e5

        if squares[i][3] < 0:
            pen += squares[i][3] ** 2 * 1e6

    for i in range(n):
        for j in range(i + 1, n):
            ov = _overlap_sat(corners[i], corners[j])
            if ov > 0:
                pen += ov * ov * 1e6

    return total + pen


def _make_grid(n):
    """Largest k x k grid plus small zero squares."""
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    return squares


def _initial_solutions(n, rng):
    """Yield several starting configurations."""
    sols = []

    # pure grid
    sols.append(_make_grid(n))

    # grid with slight random rotations and perturbations
    for trial in range(8):
        k = math.isqrt(n)
        side = 1.0 / k
        sq = []
        for i in range(k):
            for j in range(k):
                cx = (i + 0.5) * side + rng.uniform(-0.02, 0.02) * side
                cy = (j + 0.5) * side + rng.uniform(-0.02, 0.02) * side
                ang = rng.uniform(-0.05, 0.05) if trial > 2 else 0.0
                s = side * rng.uniform(0.9, 1.0)
                sq.append([cx, cy, ang, s])
        while len(sq) < n:
            sq.append([rng.uniform(0.3, 0.7), rng.uniform(0.3, 0.7),
                       rng.uniform(-0.05, 0.05), rng.uniform(0.0, 0.05)])
        sols.append(sq)

    return sols


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    best_val = 1e18
    best_sol = None

    for init in _initial_solutions(n, rng):
        x0 = np.array(init, dtype=float).ravel()
        try:
            res = minimize(
                _penalty, x0, args=(n,), method='L-BFGS-B',
                options={'maxiter': 300, 'ftol': 1e-12, 'gtol': 1e-8}
            )
            val = _penalty(res.x, n)
            if val < best_val:
                best_val = val
                best_sol = res.x
        except Exception:
            continue

    if best_sol is None:
        best_sol = np.array(_make_grid(n), dtype=float).ravel()

    squares = best_sol.reshape(n, 4)
    result = []
    for i in range(n):
        cx, cy, ang, side = squares[i]
        # clamp to valid range and fix tiny numerical issues
        side = max(0.0, side)
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        result.append((float(cx), float(cy), float(ang), float(side)))
    return result
