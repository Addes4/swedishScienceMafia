import math
import random

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _grid_packing(n, k, m):
    """k rows of height 1/k; row i contains m_i squares of side m_i * (1/k)? """
    # not used directly
    pass


def _overlap(sq1, sq2):
    """True if two axis-aligned/rotated squares overlap (SAT). Return True if positive area overlap."""
    x1, y1, a1, s1 = sq1
    x2, y2, a2, s2 = sq2
    if s1 <= 0 or s2 <= 0:
        return False
    t1 = a1 * 2 * math.pi
    t2 = a2 * 2 * math.pi
    # approximate by bounding circles first
    r1 = s1 * math.sqrt(2) / 2
    r2 = s2 * math.sqrt(2) / 2
    d = math.hypot(x1 - x2, y1 - y2)
    if d > r1 + r2:
        return False
    if d < abs(r1 - r2) - 1e-12:
        return True
    # SAT for two convex polygons
    def axes(a, s):
        c = math.cos(a)
        sn = math.sin(a)
        h = s / 2
        # corners relative to centre
        pts = [(c * h - sn * h, sn * h + c * h),
               (c * h + sn * h, sn * h - c * h),
               (-c * h + sn * h, -sn * h - c * h),
               (-c * h - sn * h, -sn * h + c * h)]
        # axes are perpendicular to edges -> same as square axes
        return [(c, sn), (-sn, c)], pts
    ax1, p1 = axes(t1, s1)
    ax2, p2 = axes(t2, s2)
    all_axes = ax1 + ax2
    for ax, ay in all_axes:
        # project both
        for (px, py) in p1:
            pass
        min1 = min(px * ax + py * ay for px, py in p1)
        max1 = max(px * ax + py * ay for px, py in p1)
        min2 = min(px * ax + py * ay for px, py in p2)
        max2 = max(px * ax + py * ay for px, py in p2)
        if max1 <= min2 + 1e-9 or max2 <= min1 + 1e-9:
            return False
    return True


def _inside(sq):
    """Return True if square lies entirely inside the unit square."""
    x, y, a, s = sq
    if s <= 0:
        return 0 <= x <= 1 and 0 <= y <= 1
    t = a * 2 * math.pi
    c = math.cos(t)
    sn = math.sin(t)
    h = s / 2
    corners = [(x + c * h - sn * h, y + sn * h + c * h),
               (x + c * h + sn * h, y + sn * h - c * h),
               (x - c * h + sn * h, y - sn * h - c * h),
               (x - c * h - sn * h, y - sn * h + c * h)]
    return all(0 - 1e-9 <= px <= 1 + 1e-9 and 0 - 1e-9 <= py <= 1 + 1e-9 for px, py in corners)


def _valid(squares):
    n = len(squares)
    for i in range(n):
        if not _inside(squares[i]):
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _total(squares):
    return sum(s[3] for s in squares)


# ---------------------------------------------------------------------------
# Candidate constructions
# ---------------------------------------------------------------------------

def _grid(n):
    """Best k x k grid with remaining cells split to maximize sum."""
    best = None
    best_val = -1
    for k in range(1, n + 1):
        if k * k > n:
            # k rows, put n squares
            rows = k
            cols = k
            total_cells = rows * cols
            if total_cells < n:
                continue
            # put n squares in grid: choose to merge?  Simpler: uniform grid of k rows with m_i squares
            pass
    # k rows, distribute n among rows as evenly as possible
    for k in range(1, n + 1):
        base = n // k
        rem = n % k
        if base == 0:
            continue
        counts = [base + (1 if i < rem else 0) for i in range(k)]
        row_h = 1.0 / k
        sqs = []
        ok = True
        for i, cnt in enumerate(counts):
            if cnt == 0:
                continue
            w = 1.0 / cnt
            side = min(row_h, w)
            y = (i + 0.5) * row_h
            for j in range(cnt):
                x = (j + 0.5) * w
                sqs.append((x, y, 0.0, side))
        # if side < row_h, we waste space; maybe re-scale
        if len(sqs) == n:
            # improve: make squares fill more
            s = min(row_h, 1.0 / max(counts))
            # try to uniform
            sqs = []
            for i, cnt in enumerate(counts):
                if cnt == 0:
                    continue
                w = 1.0 / cnt
                side = row_h  # try max size
                if side > w:
                    side = w
                y = (i + 0.5) * row_h
                for j in range(cnt):
                    x = (j + 0.5) * w
                    sqs.append((x, y, 0.0, side))
            if _valid(sqs):
                val = _total(sqs)
                if val > best_val:
                    best_val = val
                    best = sqs
    # also k rows each with 1 square (columns)
    for k in range(1, n + 1):
        cols = k
        base = n // k
        rem = n % k
        if base == 0:
            continue
        counts = [base + (1 if i < rem else 0) for i in range(k)]
        col_w = 1.0 / k
        sqs = []
        for i, cnt in enumerate(counts):
            if cnt == 0:
                continue
            h = 1.0 / cnt
            side = min(col_w, h)
            x = (i + 0.5) * col_w
            for j in range(cnt):
                y = (j + 0.5) * h
                sqs.append((x, y, 0.0, side))
        if len(sqs) == n and _valid(sqs):
            val = _total(sqs)
            if val > best_val:
                best_val = val
                best = sqs
    return best


def _guillotine(n, depth=0):
    """Recursively split rectangle, place squares."""
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # try all splits
    best = None
    best_val = -1
    # split n into n1 + n2
    for n1 in range(1, n):
        n2 = n - n1
        # horizontal split: heights proportional to sqrt?  tau = area
        # approximate: side lengths scale with sqrt(area).  For n squares in a rect of area A, sum ~ sqrt(n*A)
        # so split area proportional to n1/n
        pass
    # simple heuristic: split area proportional to count
    # horizontal
    for n1 in range(1, n):
        n2 = n - n1
        # area split proportional to n1/n and n2/n
        a1 = n1 / n
        a2 = n2 / n
        # rectangle 1: width 1, height a1 (since unit square)
        # top rect: [0,1] x [0,a1], bottom: [0,1] x [a1,1]
        # place n1 in top, n2 in bottom
        r1 = _guillotine_rect(n1, 0, 0, 1, a1, depth + 1)
        r2 = _guillotine_rect(n2, 0, a1, 1, 1 - a1, depth + 1)
        if r1 is None or r2 is None:
            continue
        sqs = r1 + r2
        if _valid(sqs):
            val = _total(sqs)
            if val > best_val:
                best_val = val
                best = sqs
        # vertical
        r1 = _guillotine_rect(n1, 0, 0, a1, 1, depth + 1)
        r2 = _guillotine_rect(n2, a1, 0, 1 - a1, 1, depth + 1)
        if r1 is None or r2 is None:
            continue
        sqs = r1 + r2
        if _valid(sqs):
            val = _total(sqs)
            if val > best_val:
                best_val = val
                best = sqs
    return best


def _guillotine_rect(n, x0, y0, w, h, depth=0):
    """Place n squares in rectangle (x0,y0,w,h)."""
    if n == 0:
        return []
    if depth > 8:
        # base case: grid
        return _rect_grid(n, x0, y0, w, h)
    if n == 1:
        s = min(w, h)
        return [(x0 + w / 2, y0 + h / 2, 0.0, s)]
    # try splits
    best = None
    best_val = -1
    for n1 in range(1, n):
        n2 = n - n1
        frac = n1 / n
        # horizontal split
        h1 = h * frac
        h2 = h - h1
        r1 = _guillotine_rect(n1, x0, y0, w, h1, depth + 1)
        r2 = _guillotine_rect(n2, x0, y0 + h1, w, h2, depth + 1)
        if r1 is not None and r2 is not None:
            sqs = r1 + r2
            if _valid(sqs):
                val = _total(sqs)
                if val > best_val:
                    best_val = val
                    best = sqs
        # vertical split
        w1 = w * frac
        w2 = w - w1
        r1 = _guillotine_rect(n1, x0, y0, w1, h, depth + 1)
        r2 = _guillotine_rect(n2, x0 + w1, y0, w2, h, depth + 1)
        if r1 is not None and r2 is not None:
            sqs = r1 + r2
            if _valid(sqs):
                val = _total(sqs)
                if val > best_val:
                    best_val = val
                    best = sqs
    if best is None:
        return _rect_grid(n, x0, y0, w, h)
    return best


def _rect_grid(n, x0, y0, w, h):
    """Grid n squares in rectangle."""
    best = None
    best_val = -1
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        if rows * cols < n:
            continue
        cell_w = w / cols
        cell_h = h / rows
        side = min(cell_w, cell_h)
        sqs = []
        cnt = 0
        for i in range(rows):
            for j in range(cols):
                if cnt >= n:
                    break
                cx = x0 + (j + 0.5) * cell_w
                cy = y0 + (i + 0.5) * cell_h
                sqs.append((cx, cy, 0.0, side))
                cnt += 1
            if cnt >= n:
                break
        if _valid(sqs):
            val = _total(sqs)
            if val > best_val:
                best_val = val
                best = sqs
    return best


def _pack_best(n):
    """Try multiple construction methods and pick the best valid one."""
    candidates = []

    # Method 1: square grid k x k with remaining as smaller squares
    for k in range(1, n + 1):
        if k * k > n:
            break
        # grid k x k, remaining n - k*k as size 0 or try to split some cells
        rem = n - k * k
        side = 1.0 / k
        sqs = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
        # add remaining inside some cells?  Simply add tiny squares in corners
        # Better: replace one cell by 4 smaller squares
        # Try: if rem > 0, divide some cells
        # For simplicity, distribute: put rem squares of size 0
        sqs += [(0.5, 0.5, 0.0, 0.0)] * rem
        candidates.append(sqs)

    # Method 2: rows with varying counts
    g = _grid(n)
    if g:
        candidates.append(g)

    # Method 3: guillotine
    gui = _guillotine(n)
    if gui:
        candidates.append(gui)

    # Method 4: all in one row (n columns)
    for k in range(1, n + 1):
        cnt = k
        side = 1.0 / cnt
        sqs = [((i + 0.5) * side, 0.5, 0.0, side) for i in range(cnt)]
        if len(sqs) == n:
            candidates.append(sqs)

    # Method 5: all in one column
    for k in range(1, n + 1):
        cnt = k
        side = 1.0 / cnt
        sqs = [(0.5, (i + 0.5) * side, 0.0, side) for i in range(cnt)]
        if len(sqs) == n:
            candidates.append(sqs)

    # Handle n=1 special
    if n == 1:
        candidates.append([(0.5, 0.5, 0.0, 1.0)])

    best = None
    best_val = -1
    for c in candidates:
        if len(c) != n:
            continue
        if _valid(c):
            val = _total(c)
            if val > best_val:
                best_val = val
                best = c
    if best is None:
        # fallback: grid
        k = math.isqrt(n)
        side = 1.0 / k if k > 0 else 1.0
        best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    return best


# ---------------------------------------------------------------------------
# Local refinement
# ---------------------------------------------------------------------------

def _improve(squares, n, iterations=3000):
    """Random local improvement: perturb centres/sizes, keep if valid and better."""
    squares = [list(s) for s in squares]
    best = [list(s) for s in squares]
    best_val = _total(squares)
    cur = [list(s) for s in squares]
    cur_val = best_val

    rng = random.Random(12345 + n)

    for it in range(iterations):
        # pick a random square
        idx = rng.randrange(n)
        if len(cur[idx]) != 4:
            continue
        old = list(cur[idx])
        # perturb
        s = cur[idx][3]
        dx = rng.gauss(0, 0.005)
        dy = rng.gauss(0, 0.005)
        ds = rng.gauss(0, 0.005)
        da = rng.gauss(0, 0.005)
        cur[idx][0] = min(1, max(0, cur[idx][0] + dx))
        cur[idx][1] = min(1, max(0, cur[idx][1] + dy))
        cur[idx][3] = min(1, max(0, cur[idx][3] + ds))
        cur[idx][2] = (cur[idx][2] + da) % 1.0
        # check validity
        ok = True
        for j in range(n):
            if j == idx:
                continue
            if _overlap(tuple(cur[idx]), tuple(cur[j])):
                ok = False
                break
        if ok and _inside(tuple(cur[idx])):
            new_val = _total(cur)
            if new_val > cur_val:
                cur_val = new_val
                if cur_val > best_val:
                    best_val = cur_val
                    best = [list(s) for s in cur]
            else:
                cur[idx] = old
        else:
            cur[idx] = old

        # occasionally also try to grow all squares proportionally
        if it % 500 == 499:
            # try scale all sizes slightly
            alpha = 1.0 + rng.gauss(0, 0.01)
            scaled = []
            ok = True
            for s in cur:
                ns = s[3] * alpha
                if ns > 1:
                    ns = 1.0
                scaled.append([s[0], s[1], s[2], ns])
            if _valid([tuple(s) for s in scaled]):
                cur = scaled
                cur_val = _total(cur)
                if cur_val > best_val:
                    best_val = cur_val
                    best = [list(s) for s in cur]

    return [tuple(s) for s in best]


# ---------------------------------------------------------------------------
# Main solver
# ---------------------------------------------------------------------------

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side 0.5 stacked
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # three squares
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    if n == 4:
        return [((i + 0.5) * 0.5, (j + 0.5) * 0.5, 0.0, 0.5)
                for i in range(2) for j in range(2)]

    # general construction
    best = _pack_best(n)

    # refine with local search (limited by time)
    if n <= 100:
        improved = _improve(best, n, iterations=2000)
        if _valid(improved) and _total(improved) >= _total(best) - 1e-9:
            best = improved

    return best
