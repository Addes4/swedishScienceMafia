import math
from functools import lru_cache

import numpy as np
from scipy.optimize import minimize


def _axis_aligned_rows(n):
    """Fast constructive heuristic: partition into rows of equal-height rectangles,
    then place a square in each row rectangle; balance side lengths via optimization.

    For n squares, choose r rows and split n into r positive integer counts c_i.
    Row height = min over i of (available width / c_i).  We assign square side s_i
    <= min(row_height, row_width/c_i) and optimize sum s_i.
    Because rows are disjoint rectangles, any center placements inside rows are valid.
    """
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_val = -1.0

    # candidate row counts
    row_counts = set(range(1, min(n, 12) + 1))
    # also try divisors-ish and values up to n for small n
    for r in range(1, n + 1):
        if r <= 12 or n <= 30 or r in (n, max(1, n // 2), max(1, n // 3), max(1, n // 4)):
            row_counts.add(r)

    for r in row_counts:
        if r > n:
            continue
        # distribute n into r parts as evenly as possible; also try a few variants
        base = n // r
        rem = n % r
        counts_list = []
        c0 = [base + (1 if i < rem else 0) for i in range(r)]
        counts_list.append(c0)
        # try putting remainder on last rows
        if rem:
            c1 = [base] * (r - rem) + [base + 1] * rem
            counts_list.append(c1)
        # small perturbations for small r
        if r <= 8:
            for shift in range(1, r):
                c = c0[shift:] + c0[:shift]
                counts_list.append(c)

        for counts in counts_list:
            if any(c <= 0 for c in counts):
                continue
            if sum(counts) != n:
                continue

            # initial row heights proportional to 1/sqrt(count)?  Simple equal height.
            h = 1.0 / r
            sizes = []
            for c in counts:
                sizes.append(min(h, 1.0 / c))
            sizes = np.array(sizes, dtype=float)
            heights = np.full(r, 1.0 / r, dtype=float)

            def unpack(x):
                hh = x[:r]
                ss = x[r:]
                return hh, ss

            def objective(x):
                _, ss = unpack(x)
                return -np.sum(ss)

            def cons_fn(x):
                hh, ss = unpack(x)
                con = []
                # sum heights <= 1
                con.append(1.0 - np.sum(hh))
                # each square side <= its row height
                for i in range(r):
                    con.append(hh[i] - ss[i])
                    con.append(ss[i])
                    # capacity: c_i * ss_i <= 1 (width)
                    con.append(1.0 - counts[i] * ss[i])
                # hh >= 0
                for i in range(r):
                    con.append(hh[i])
                return np.array(con)

            x0 = np.concatenate([heights, sizes])
            bounds = [(0.0, 1.0)] * r + [(0.0, 1.0)] * r
            try:
                res = minimize(objective, x0, method="SLSQP", bounds=bounds,
                               constraints={"type": "ineq", "fun": cons_fn},
                               options={"maxiter": 200, "ftol": 1e-12})
            except Exception:
                res = None
            if res is not None and res.success:
                hh, ss = unpack(res.x)
                val = float(np.sum(ss))
            else:
                # fall back to simple equal construction
                hh = np.full(r, 1.0 / r)
                ss = np.array([min(hh[i], 1.0 / counts[i]) for i in range(r)])
                val = float(np.sum(ss))

            if val > best_val:
                best_val = val
                best = (counts, hh.copy(), ss.copy())

    if best is None:
        k = math.isqrt(n)
        side = 1.0 / k
        return [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)] + [(0.5, 0.5, 0.0, 0.0)] * (n - k * k)

    counts, hh, ss = best
    # normalize heights to exactly 1
    hh = hh * (1.0 / hh.sum()) if hh.sum() > 0 else np.full(len(hh), 1.0 / len(hh))
    # recheck sizes
    for i in range(len(ss)):
        ss[i] = min(ss[i], hh[i], 1.0 / counts[i])

    squares = []
    y0 = 0.0
    for i, c in enumerate(counts):
        h = hh[i]
        s = ss[i]
        if c == 0:
            y0 += h
            continue
        # width used if all squares size s: c*s <= 1
        # left margin to center the row if c*s < 1
        used = c * s
        x0 = (1.0 - used) * 0.5
        # center vertically
        cy = y0 + h * 0.5
        for j in range(c):
            cx = x0 + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y0 += h

    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _try_rotated_extra(n):
    """For certain n, one rotated square can be placed in leftover area of a grid.
    This handles common tricky values where an extra square fits if tilted.
    """
    # Known constructions: place an axis-aligned grid of k x k, then use remaining
    # L-shaped / corner-like space for an additional rotated square.
    # For generality, we use a simple heuristic: try placing m axis-aligned squares
    # in a grid plus one rotated square in a corner gap.
    best = None
    best_sum = -1.0

    # We'll consider constructions: k x k grid plus an extra tilted square in a corner
    # by shrinking the grid slightly.
    for k in range(1, int(math.sqrt(n)) + 3):
        m = k * k
        if m > n:
            continue
        extra = n - m
        if extra < 0:
            continue
        # Start from standard grid side = 1/k. To fit one extra tilted square,
        # shrink grid side to s and place grid in bottom-left, tilted square in top-right.
        # For extra==1, try a few sizes.
        if extra == 1 and k >= 1:
            # Pack k*k squares in a block of size (k*s) x (k*s) at bottom-left.
            # A rotated square of side t in the top-right corner between the block
            # and the unit square boundary.  Simple estimate: rotate 45 deg, it must fit
            # in the remaining L-shaped region.  We brute-force a bit.
            def eval_layout(s, t):
                # block [0, k*s] x [0, k*s]
                if k * s > 1.0 + 1e-12:
                    return -1
                if k * s + 1e-12 < 0:
                    return -1
                # rotated square center (cx, cy), angle pi/4
                ang = 0.25
                # axis-aligned bounding box of rotated square
                rad = math.sqrt(2.0) * t * 0.5
                # place its bounding box in [k*s, 1] x [k*s, 1]
                if k * s + 2 * rad <= 1.0 + 1e-12:
                    # fits in top-right corner axis-aligned bbox
                    cx = k * s + rad
                    cy = k * s + rad
                    # ensure vertices in unit square (rotate bbox already inside)
                    # check corners of rotated square
                    cosa = math.cos(2 * math.pi * ang)
                    sina = math.sin(2 * math.pi * ang)
                    # half diagonal vectors
                    dx = t * 0.5
                    corners = []
                    for sx in (-1, 1):
                        for sy in (-1, 1):
                            # local corner (sx*dx, sy*dx) rotated
                            px = cx + cosa * sx * dx - sina * sy * dx
                            py = cy + sina * sx * dx + cosa * sy * dx
                            corners.append((px, py))
                    if all(-1e-9 <= x <= 1 + 1e-9 and -1e-9 <= y <= 1 + 1e-9 for x, y in corners):
                        # also avoid overlap with block: corners must not lie inside block (except boundary)
                        ok = True
                        for (px, py) in corners:
                            if px < k * s - 1e-9 and py < k * s - 1e-9:
                                ok = False
                                break
                        if ok:
                            return k * k * s + t
                return -1

            # search over s and t
            lo, hi = 0.0, 1.0 / k
            for _ in range(80):
                mid = (lo + hi) * 0.5
                # choose t such that 2*rad + k*s = 1 -> t = (1 - k*s)/sqrt(2)
                t = max(0.0, (1.0 - k * mid) / math.sqrt(2.0))
                val = eval_layout(mid, t)
                if val > 0:
                    lo = mid  # try larger s (thus smaller t) but might not fit; actually maximize sum
                    # We'll instead direct search around optimum: sum = k^2*s + t, t = (1-k*s)/sqrt2
                    # derivative k^2 - k/sqrt2 >0 so larger s better, but constraint corners.
                    lo = mid
                else:
                    hi = mid
            # Try the boundary condition exactly: t=(1-k*s)/sqrt2, and find max feasible s by testing.
            best_local = -1
            best_params = None
            for it in range(200):
                s = (it + 0.5) / 200.0 / k
                t = (1.0 - k * s) / math.sqrt(2.0)
                val = eval_layout(s, t)
                if val > best_local:
                    best_local = val
                    best_params = (s, t)
            # Also try optimizing sum directly with a fine grid allowing gap in corner
            for it in range(200):
                s = (it + 0.5) / 200.0 / k
                # t limited by vertical/horizontal gap: rotated square bbox size sqrt2*t <= 1-k*s
                t = (1.0 - k * s) / math.sqrt(2.0)
                if t < 0:
                    continue
                # But maybe t can be larger if center not exactly at corner?  We'll just use this.
                val = k * k * s + t
                # feasibility: corners inside, and rotated square outside block
                if eval_layout(s, t) > 0 and val > best_sum:
                    # verify no overlap: since bbox in top-right and block in bottom-left, it is fine.
                    best_sum = val
                    # build squares
                    squares = []
                    for i in range(k):
                        for j in range(k):
                            squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                    rad = math.sqrt(2.0) * t * 0.5
                    cx = k * s + rad
                    cy = k * s + rad
                    squares.append((cx, cy, 0.25, t))
                    while len(squares) < n:
                        squares.append((0.5, 0.5, 0.0, 0.0))
                    best = squares[:n]

    return best


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        s = 0.5
        return [(0.25, 0.5, 0.0, s), (0.75, 0.5, 0.0, s)]
    if n == 3:
        # two on bottom, one on top, all equal s=1/2? Then sum=1.5, but can we do better?
        # Three squares: one on left full height? Actually 3 squares of side 1/2 fit: bottom two, top one centered.
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s), (0.5, 0.75, 0.0, s)]
    if n == 4:
        s = 0.5
        return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(2) for j in range(2)]
    if n == 5:
        # best known: four squares of side 0.5 in corners? Actually 5 squares of side 1/3? sum 5/3~1.666.
        # Better: 4 squares side 0.5 minus? Let's use grid 3x3 with 5 squares side 1/3? too small.
        # Known optimal for 5: four squares side ~0.5 and one smaller? But 4 side .5 already fill unit.
        # Actually 5 squares: 0.5,0.5,0.5,0.5? overlap if 4 of .5 fill exactly, no room for 5th.
        # Place 4 squares of side 0.5 at corners, leaving cross-shaped gap in middle? 
        # Four .5 squares fill entire unit. So need smaller.
        # Use rows: 2+3. Row heights 0.5, 0.5. 2 squares in top row: side 0.5 each fills width.
        # 3 squares in bottom row: side 1/3. Sum = 1.0 + 1.0 = 2.0? Wait 2*0.5 + 3*(1/3)=1+1=2.
        # Check: top row y in [0.5,1], two squares side 0.5 -> fill [0,1]x[0.5,1].
        # bottom row three squares side 1/3, centered: width 1, height 1/3 <= 0.5 okay.
        # So sum=2.0. Good.
        s1 = 0.5
        s2 = 1.0 / 3.0
        return [(0.25, 0.75, 0.0, s1), (0.75, 0.75, 0.0, s1),
                (1.0 / 6.0, 1.0 / 6.0, 0.0, s2), (0.5, 1.0 / 6.0, 0.0, s2), (5.0 / 6.0, 1.0 / 6.0, 0.0, s2)]
    if n == 6:
        # 3+3 rows: side 1/3 each, sum = 2.0. Or 2+2+2 with height 1/3, side 1/3: sum 2.
        # Can we do better? 6 squares: maybe 2x2 grid of .5 (sum 2) plus 2 zero? no.
        # Try rows 2,2,2: each row height 1/3, two squares side 1/3 -> width 2/3, waste.
        # Better: 3 rows of 2 squares side 0.5? Height 1/3 each, side min(1/3, 0.5)=1/3 sum 2.
        # Known optimal for 6 is ~2.0? Let's use 2 columns of 3: same.
        # We'll use uniform 3x2 grid side 1/3 => sum=2.
        s = 1.0 / 3.0
        return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(3) for j in range(2)]
    if n == 7:
        # 3+4 rows: sides 1/3 and 1/4 sum = 3*(1/3)+4*(1/4)=2.0.
        # But maybe 2+2+3: heights 1/3 each -> sides 1/3,1/3,1/3 sum 7/3~2.333? Check:
        # Row 1: 2 squares side 1/3 in height 1/3 -> width 2/3.
        # Row 2: same. Row 3: 3 squares side 1/3 fills width.
        # Heights sum = 1. Sum sides = 7/3 ≈ 2.333. Good.
        s = 1.0 / 3.0
        squares = []
        # row 1
        squares += [(1.0/3.0 * 0.5, 5.0/6.0, 0.0, s), (1.0/3.0 * 1.5, 5.0/6.0, 0.0, s)]
        # row 2
        squares += [(1.0/3.0 * 0.5, 0.5, 0.0, s), (1.0/3.0 * 1.5, 0.5, 0.0, s)]
        # row 3
        squares += [(1.0/6.0, 1.0/6.0, 0.0, s), (0.5, 1.0/6.0, 0.0, s), (5.0/6.0, 1.0/6.0, 0.0, s)]
        return squares
    if n == 8:
        # 4+4 rows side 1/4 sum 2, or 3+3+2: heights 1/3 -> sides 1/3,1/3,1/2? row 3 with 2 squares can be side 1/2 but height 1/3 limits to 1/3. sum=8/3~2.666? Check:
        # heights 1/3,1/3,1/3: sides min(1/3,1/3)=1/3, row3 two squares side 1/3. sum=8/3≈2.667.
        # Can do 3+3+2 with heights 1/3 each and sides 1/3. good.
        s = 1.0 / 3.0
        squares = []
        squares += [(1.0/6.0, 5.0/6.0, 0.0, s), (0.5, 5.0/6.0, 0.0, s), (5.0/6.0, 5.0/6.0, 0.0, s)]
        squares += [(1.0/6.0, 0.5, 0.0, s), (0.5, 0.5, 0.0, s), (5.0/6.0, 0.5, 0.0, s)]
        squares += [(0.25, 1.0/6.0, 0.0, s), (0.75, 1.0/6.0, 0.0, s)]
        return squares
    if n == 9:
        s = 1.0 / 3.0
        return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(3) for j in range(3)]
    if n == 10:
        # rows 3+3+4? heights 1/3 each -> sides 1/3 => sum 10/3 ≈ 3.333.
        # Try 2+3+3+2? Actually 4 rows: 2,3,3,2 -> heights 1/4 each -> sides 1/4 sum 10/4=2.5.
        # So 3 rows better.
        s = 1.0 / 3.0
        squares = []
        # row1: 4 squares side 1/4 in height 1/3? or 3 squares side 1/3
        # We'll do 3 rows: 3,3,4. Third row 4 squares side 1/4 in height 1/3.
        # sum = 3*(1/3)+3*(1/3)+4*(1/4)=1+1+1=3.0.
        # But better: 3+3+4 could use side 1/3 for first two rows, last row side 1/4 sum=3.0.
        # Alternatively 3 rows all side 1/3 with counts summing to 10 impossible since 3*3=9<10.
        # Another: 4+3+3 with side 1/3 for all? counts 4,3,3: 4 squares side 1/3 need width 4/3>1. no.
        # Optimize: counts 3,4,3? no. Let's just use rows 3,3,4 with side 1/3,1/3,1/4.
        squares += [(1.0/6.0, 5.0/6.0, 0.0, s), (0.5, 5.0/6.0, 0.0, s), (5.0/6.0, 5.0/6.0, 0.0, s)]
        squares += [(1.0/6.0, 0.5, 0.0, s), (0.5, 0.5, 0.0, s), (5.0/6.0, 0.5, 0.0, s)]
        q = 1.0 / 4.0
        squares += [(1.0/8.0, 1.0/6.0, 0.0, q), (3.0/8.0, 1.0/6.0, 0.0, q),
                    (5.0/8.0, 1.0/6.0, 0.0, q), (7.0/8.0, 1.0/6.0, 0.0, q)]
        return squares
    # General case: use improved heuristic
    res = _try_rotated_extra(n)
    if res is not None and len(res) == n:
        # check sum greater than simple grid
        simple = _axis_aligned_rows(n)
        if simple:
            s1 = sum(sq[3] for sq in simple)
            s2 = sum(sq[3] for sq in res)
            if s2 >= s1:
                return res
    return _axis_aligned_rows(n)
