import math
import random

INF = float("inf")


def _sides_of(sol):
    return [s[3] for s in sol]


def _total(sol):
    return sum(s[3] for s in sol)


def _corners(cx, cy, a, s):
    """Return the four corners of the square."""
    ca = math.cos(2.0 * math.pi * a)
    sa = math.sin(2.0 * math.pi * a)
    h = 0.5 * s
    dx = (ca * h, -sa * h)
    dy = (sa * h, ca * h)
    return (
        (cx + dx[0] + dy[0], cy + dx[1] + dy[1]),
        (cx + dx[0] - dy[0], cy + dx[1] - dy[1]),
        (cx - dx[0] - dy[0], cy - dx[1] - dy[1]),
        (cx - dx[0] + dy[0], cy - dx[1] + dy[1]),
    )


def _in_unit(sol):
    for cx, cy, a, s in sol:
        if s <= 0:
            continue
        for x, y in _corners(cx, cy, a, s):
            if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
                return False
    return True


def _axes(cx, cy, a, s):
    ca = math.cos(2.0 * math.pi * a)
    sa = math.sin(2.0 * math.pi * a)
    h = 0.5 * s
    return (ca * h, sa * h), (-sa * h, ca * h), (cx, cy)


def _projection(poly, ax):
    ux, uy, _ = ax
    vs = [x * ux + y * uy for x, y in poly]
    return min(vs), max(vs)


def _poly(cx, cy, a, s):
    return _corners(cx, cy, a, s)


def _overlap_area(sq1, sq2):
    """SAT overlap depth for two squares, returns penetration amount (approx)."""
    poly1 = _poly(sq1[0], sq1[1], sq1[2], sq1[3])
    poly2 = _poly(sq2[0], sq2[1], sq2[2], sq2[3])
    axes1 = _axes(sq1[0], sq1[1], sq1[2], sq1[3])[:2]
    axes2 = _axes(sq2[0], sq2[1], sq2[2], sq2[3])[:2]
    min_depth = INF
    for ax in axes1 + axes2:
        lo1, hi1 = _projection(poly1, ax)
        lo2, hi2 = _projection(poly2, ax)
        d = min(hi1 - lo2, hi2 - lo1)
        if d <= 0:
            return 0.0
        if d < min_depth:
            min_depth = d
    return min_depth


def _feasible(sol, eps=1e-8):
    n = len(sol)
    for i in range(n):
        s = sol[i][3]
        if s <= 0:
            continue
        if not _in_unit([sol[i]]):
            return False
        for j in range(i + 1, n):
            if sol[j][3] <= 0:
                continue
            if _overlap_area(sol[i], sol[j]) > eps:
                return False
    return True


def _recover(sol, iters=2000, rng=None):
    """Repair overlaps by shrinking squares involved and moving them apart."""
    rng = rng or random
    sol = [list(s) for s in sol]
    n = len(sol)

    for _ in range(iters):
        improved = False
        for i in range(n):
            s1 = sol[i]
            if s1[3] <= 0:
                continue
            # clamp into unit
            cx, cy, a, s = s1
            h = 0.5 * s
            ca = abs(math.cos(2 * math.pi * a)) + abs(math.sin(2 * math.pi * a))
            half_ext = 0.5 * s * ca
            if cx - half_ext < 0:
                s1[0] = half_ext
            elif cx + half_ext > 1:
                s1[0] = 1 - half_ext
            if cy - half_ext < 0:
                s1[1] = half_ext
            elif cy + half_ext > 1:
                s1[1] = 1 - half_ext

            for j in range(i + 1, n):
                s2 = sol[j]
                if s2[3] <= 0:
                    continue
                ov = _overlap_area(s1, s2)
                if ov > 1e-9:
                    improved = True
                    # push apart along centre difference
                    dx = s2[0] - s1[0]
                    dy = s2[1] - s1[1]
                    d = math.hypot(dx, dy)
                    if d < 1e-9:
                        dx, dy = rng.uniform(-1, 1), rng.uniform(-1, 1)
                        d = math.hypot(dx, dy) or 1.0
                    push = 0.5 * ov + 1e-4
                    ux, uy = dx / d, dy / d
                    s1[0] -= ux * push
                    s1[1] -= uy * push
                    s2[0] += ux * push
                    s2[1] += uy * push
                    # also shrink a bit if needed
                    shrink = ov * 0.5
                    s1[3] = max(0.0, s1[3] - shrink)
                    s2[3] = max(0.0, s2[3] - shrink)
        if not improved:
            break
    return [tuple(s) for s in sol]


def _grow(sol, iters=500, rng=None):
    """Try to grow all squares while keeping feasibility."""
    rng = rng or random
    sol = [list(s) for s in sol]
    n = len(sol)
    for _ in range(iters):
        changed = False
        # grow each square by amount limited by neighbours
        for i in range(n):
            s1 = sol[i]
            cur = s1[3]
            if cur <= 0:
                continue
            # find max growth allowed
            maxg = 0.1
            # boundary constraint with rotated bounding box
            cx, cy, a = s1[0], s1[1], s1[2]
            ca = abs(math.cos(2 * math.pi * a)) + abs(math.sin(2 * math.pi * a))
            hx = 0.5 * ca
            if hx > 0:
                lim_x = min(cx / hx, (1 - cx) / hx) - cur if cx <= 0.5 else (1 - cx) / hx - cur
                # recompute cleanly
                lim_x = min(cx, 1 - cx) / hx - cur
            else:
                lim_x = INF
            if hx > 0:
                lim_y = min(cy, 1 - cy) / hx - cur
            else:
                lim_y = INF
            maxg = min(maxg, max(0.0, lim_x), max(0.0, lim_y))

            for j in range(n):
                if j == i or sol[j][3] <= 0:
                    continue
                # growth limited by overlap with j
                ov = _overlap_area(s1, sol[j])
                if ov > 0:
                    maxg = min(maxg, 0.0)
                else:
                    # if nearby, estimate
                    d = math.hypot(s1[0] - sol[j][0], s1[1] - sol[j][1])
                    # conservative: don't try huge
                    pass
            if maxg > 1e-4:
                s1[3] += min(maxg, 0.01)
                changed = True
        if not changed:
            break
    return [tuple(s) for s in sol]


def _initial_grid(n):
    k = math.isqrt(n)
    side = 1.0 / k if k > 0 else 1.0
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    sq.sort(key=lambda t: -t[3])
    while len(sq) < n:
        sq.append((0.5, 0.5, 0.0, 0.0))
    return sq[:n]


def _initial_rot(n):
    """Place rotated squares in a row pattern / brick pattern."""
    sq = []
    # try rows of rotated squares at 45 degrees
    ang = 0.25
    # bounding box of rotated square side s is s*(|c|+|s|) = s*sqrt2
    # fit m per row
    best = None
    for m in range(1, n + 1):
        cols = m
        s_col = 1.0 / (cols * math.sqrt(2))
        rows = math.ceil(n / cols)
        s_row = 1.0 / (rows * math.sqrt(2))
        s = min(s_col, s_row)
        if s <= 0:
            continue
        total = s * n
        if best is None or total > best[0]:
            best = (total, cols, rows, s)
    if best is None:
        return _initial_grid(n)
    _, cols, rows, s = best
    for idx in range(n):
        r = idx // cols
        c = idx % cols
        cx = (c + 0.5) * (1.0 / cols)
        cy = (r + 0.5) * (1.0 / rows)
        sq.append((cx, cy, ang, s))
    return sq


def _initial_random(n, rng):
    sq = []
    for _ in range(n):
        cx = rng.random()
        cy = rng.random()
        a = rng.random()
        s = rng.random() * 0.3
        sq.append((cx, cy, a, s))
    return sq


def _initial_mixed(n):
    """Grid plus rotated extra squares in gaps."""
    k = math.isqrt(n)
    side = 1.0 / k if k > 0 else 1.0
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    while len(sq) < n:
        # place small rotated squares at random free-ish spots
        sq.append((0.5, 0.5, 0.25, 0.0))
    return sq[:n]


def solve(n):
    if n <= 0:
        return []
    rng = random.Random(12345 + n * 7919)

    candidates = []
    candidates.append(_initial_grid(n))
    if n <= 200:
        candidates.append(_initial_rot(n))
    candidates.append(_initial_mixed(n))
    for _ in range(8):
        candidates.append(_initial_random(n, rng))

    best = None
    best_score = -1.0

    time_budget = 50.0
    import time
    t0 = time.time()

    for start in candidates:
        if time.time() - t0 > time_budget:
            break
        sol = _recover(start, iters=1500, rng=rng)
        if not _feasible(sol, eps=1e-6):
            sol = _recover(sol, iters=800, rng=rng)
        if _feasible(sol, eps=1e-6):
            sol = _grow(sol, iters=300, rng=rng)
            if not _feasible(sol, eps=1e-6):
                sol = _recover(sol, iters=500, rng=rng)
            if _feasible(sol, eps=1e-6):
                sc = _total(sol)
                if sc > best_score:
                    best_score = sc
                    best = sol

    if best is None:
        # fallback: grid
        best = _initial_grid(n)
        if not _feasible(best, eps=1e-6):
            best = _recover(best, iters=3000, rng=rng)

    # final cleanup
    best = _recover(best, iters=2000, rng=rng)
    if not _feasible(best, eps=1e-6):
        # shrink everything slightly
        best = [(cx, cy, a, max(0.0, s * 0.99)) for cx, cy, a, s in best]
        best = _recover(best, iters=3000, rng=rng)

    # clamp all coords to [0,1]
    out = []
    for cx, cy, a, s in best:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        a = a % 1.0
        s = min(1.0, max(0.0, s))
        out.append((cx, cy, a, s))
    return out
