import math
import random
import numpy as np
from scipy.optimize import minimize

# A square is represented as (cx, cy, angle_fraction, side)
# angle_fraction in [0,1), 0.25 = 90 degrees.

def _rotate_pts(pts, theta):
    c = math.cos(theta)
    s = math.sin(theta)
    return [(c * x - s * y, s * x + c * y) for x, y in pts]

def _square_corners(cx, cy, ang_rad, side):
    # side is full length; half-side h
    h = 0.5 * side
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    r = _rotate_pts(pts, ang_rad)
    return [(cx + x, cy + y) for x, y in r]

def _poly_area(poly):
    a = 0.0
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        a += x1 * y2 - x2 * y1
    return 0.5 * abs(a)

def _inside_unit(poly, eps=1e-9):
    for x, y in poly:
        if x < -eps or x > 1 + eps or y < -eps or y > 1 + eps:
            return False
    return True

def _seg_intersect(p1, p2, q1, q2):
    def orient(a, b, c):
        return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
    def on_seg(a, b, c):
        return min(a[0], b[0]) - 1e-12 <= c[0] <= max(a[0], b[0]) + 1e-12 and \
               min(a[1], b[1]) - 1e-12 <= c[1] <= max(a[1], b[1]) + 1e-12
    o1 = orient(p1, p2, q1)
    o2 = orient(p1, p2, q2)
    o3 = orient(q1, q2, p1)
    o4 = orient(q1, q2, p2)
    if o1 * o2 < -1e-18 and o3 * o4 < -1e-18:
        return True
    if abs(o1) < 1e-12 and on_seg(p1, p2, q1): return True
    if abs(o2) < 1e-12 and on_seg(p1, p2, q2): return True
    if abs(o3) < 1e-12 and on_seg(q1, q2, p1): return True
    if abs(o4) < 1e-12 and on_seg(q1, q2, p2): return True
    return False

def _convex_polys_overlap(A, B):
    # Separating axis theorem for convex polygons; touches allowed (area 0 intersection)
    for poly in (A, B):
        n = len(poly)
        for i in range(n):
            p1 = poly[i]
            p2 = poly[(i + 1) % n]
            # normal
            nx = -(p2[1] - p1[1])
            ny = (p2[0] - p1[0])
            # project both
            def proj(P):
                xs = [x * nx + y * ny for x, y in P]
                return min(xs), max(xs)
            a0, a1 = proj(A)
            b0, b1 = proj(B)
            if a1 <= b0 + 1e-12 or b1 <= a0 + 1e-12:
                return False
    return True

def _overlap_penalty(squares):
    """Return penalty due to overlaps and outside-unit, plus area of overlap estimate."""
    n = len(squares)
    polys = []
    for cx, cy, angf, side in squares:
        if side <= 0:
            polys.append(None)
        else:
            ang = 2.0 * math.pi * angf
            polys.append(_square_corners(cx, cy, ang, side))
    pen = 0.0
    for i in range(n):
        A = polys[i]
        if A is None: continue
        if not _inside_unit(A):
            # approximate violation
            v = 0.0
            for x, y in A:
                v += max(0.0, -x) + max(0.0, x - 1.0) + max(0.0, -y) + max(0.0, y - 1.0)
            pen += v * 10.0
        for j in range(i + 1, n):
            B = polys[j]
            if B is None: continue
            if _convex_polys_overlap(A, B):
                # estimate overlap area via simple polygon of intersections? use bbox overlap
                ax0 = min(p[0] for p in A); ax1 = max(p[0] for p in A)
                ay0 = min(p[1] for p in A); ay1 = max(p[1] for p in A)
                bx0 = min(p[0] for p in B); bx1 = max(p[0] for p in B)
                by0 = min(p[1] for p in B); by1 = max(p[1] for p in B)
                w = max(0.0, min(ax1, bx1) - max(ax0, bx0))
                h = max(0.0, min(ay1, by1) - max(ay0, by0))
                pen += (w * h + 1e-6) * 100.0
    return pen

def _total_side(squares):
    return sum(s for _, _, _, s in squares)

def _initial(n):
    # Try several structured starts and pick best feasible by greedy improvement.
    best = None
    best_score = -1e300
    # 1. grid
    k = max(1, int(math.isqrt(n)))
    while k * k > n:
        k -= 1
    side = 1.0 / k
    arr = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    while len(arr) < n:
        arr.append((0.5, 0.5, 0.0, 0.0))
    arr = arr[:n]
    # 2. try random-ish perturbations with smaller side
    rng = random.Random(12345 + n)
    for trial in range(8):
        a = []
        s = side * (0.6 + 0.4 * rng.random())
        for i in range(n):
            cx = 0.5
            cy = 0.5
            if trial > 0:
                cx = rng.random()
                cy = rng.random()
            a.append((cx, cy, rng.random(), s))
        # spread
        if trial > 0:
            # place on grid with jitter
            g = max(1, int(math.ceil(math.sqrt(n))))
            ss = 1.0 / (g + 0.5)
            idx = 0
            a = []
            for ii in range(g):
                for jj in range(g):
                    if idx >= n: break
                    cx = (ii + 0.5) / g + (rng.random() - 0.5) * 0.02
                    cy = (jj + 0.5) / g + (rng.random() - 0.5) * 0.02
                    cx = min(max(cx, 0.0), 1.0)
                    cy = min(max(cy, 0.0), 1.0)
                    a.append((cx, cy, 0.0, min(ss, 1.0)))
                    idx += 1
                if idx >= n: break
            while len(a) < n:
                a.append((0.5, 0.5, 0.0, 0.0))
        cand = _repair(a, n)
        sc = _total_side(cand) - _overlap_penalty(cand) * 1e-6
        if sc > best_score:
            best_score = sc
            best = cand
    return best

def _repair(squares, n):
    """Greedy repair: scale down offending squares until feasible, then try grow."""
    sq = [list(s) for s in squares]
    # iterative repair
    for _ in range(300):
        pen = _overlap_penalty(sq)
        if pen < 1e-9:
            break
        # find worst pairs / outside and shrink sides
        worst = -1
        for i in range(n):
            cx, cy, ang, side = sq[i]
            if side <= 0: continue
            # shrink by 0.98
            sq[i][3] = side * 0.97
        # also clip centers
        for i in range(n):
            cx, cy, ang, side = sq[i]
            cx = min(max(cx, 0.0), 1.0)
            cy = min(max(cy, 0.0), 1.0)
            sq[i][0] = cx
            sq[i][1] = cy
    # ensure all sides nonnegative
    for i in range(n):
        if sq[i][3] < 0: sq[i][3] = 0.0
    return [tuple(s) for s in sq]

def _try_grow(squares, n, rng):
    """Try random moves that increase sizes while remaining feasible."""
    sq = [list(s) for s in squares]
    for it in range(600):
        i = rng.randrange(n)
        if sq[i][3] <= 0:
            # activate a zero square at a random position with tiny size
            sq[i] = [rng.random(), rng.random(), rng.random(), 0.01]
            continue
        cx, cy, ang, side = sq[i]
        op = rng.randrange(5)
        if op == 0:
            # grow side
            side = min(1.0, side * (1.0 + rng.random() * 0.05))
        elif op == 1:
            # shrink
            side = max(0.0, side * (1.0 - rng.random() * 0.05))
        elif op == 2:
            # rotate
            ang = (ang + (rng.random() - 0.5) * 0.2) % 1.0
        elif op == 3:
            # move
            cx = min(max(cx + (rng.random() - 0.5) * 0.1, 0.0), 1.0)
            cy = min(max(cy + (rng.random() - 0.5) * 0.1, 0.0), 1.0)
        else:
            # move and grow
            cx = min(max(cx + (rng.random() - 0.5) * 0.05, 0.0), 1.0)
            cy = min(max(cy + (rng.random() - 0.5) * 0.05, 0.0), 1.0)
            side = min(1.0, side * (1.0 + rng.random() * 0.03))
        old = sq[i]
        sq[i] = [cx, cy, ang, side]
        pen = _overlap_penalty(sq)
        if pen > 1e-9:
            sq[i] = old
        else:
            # occasionally try to shrink all others slightly to allow bigger i
            if rng.random() < 0.05:
                # attempt to increase i further while scaling others down
                for j in range(n):
                    if j != i and sq[j][3] > 0:
                        sq[j][3] *= 0.995
                if _overlap_penalty(sq) > 1e-9:
                    sq[i] = old
    # final cleanup: remove negative
    for i in range(n):
        if sq[i][3] < 0: sq[i][3] = 0.0
    return [tuple(s) for s in sq]

def solve(n):
    if n <= 0:
        return []
    rng = random.Random(987 + n)
    best = None
    best_score = -1e18

    # Start from structured / repaired initial
    init = _initial(n)
    candidates = [init]

    # Also try pure grid
    k = max(1, int(math.isqrt(n)))
    while k * k > n:
        k -= 1
    side = 1.0 / k
    grid = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    while len(grid) < n:
        grid.append((0.5, 0.5, 0.0, 0.0))
    candidates.append(grid[:n])

    # baseline plus random restarts
    for cand in candidates:
        cur = _repair(cand, n)
        # grow phase with several random restarts
        for r in range(4):
            rng2 = random.Random(1000 + 17 * n + r)
            trial = _try_grow(cur, n, rng2)
            trial = _repair(trial, n)
            # local coordinate descent: try to increase each side if feasible
            trial = _coordinate_ascent(trial, n, rng2)
            score = _total_side(trial)
            pen = _overlap_penalty(trial)
            if pen < 1e-9 and score > best_score:
                best_score = score
                best = trial
            # keep best even with tiny penalty
            if score - pen * 1e-6 > best_score:
                best_score = score - pen * 1e-6
                best = trial
    if best is None:
        # fallback
        best = _repair(grid[:n], n)
    # final polish
    best = _coordinate_ascent(best, n, random.Random(42 + n))
    best = _repair(best, n)
    # ensure tuple format and clip
    out = []
    for cx, cy, ang, side in best:
        cx = min(max(float(cx), 0.0), 1.0)
        cy = min(max(float(cy), 0.0), 1.0)
        ang = float(ang) % 1.0
        side = max(0.0, float(side))
        out.append((cx, cy, ang, side))
    return out[:n]

def _coordinate_ascent(squares, n, rng):
    sq = [list(s) for s in squares]
    # try increasing each side with backtracking
    for _ in range(6):
        improved = False
        for i in range(n):
            old = list(sq[i])
            if sq[i][3] <= 0:
                continue
            # Try to increase side
            for factor in [1.02, 1.05, 1.1, 1.2]:
                sq[i][3] = old[3] * factor
                if _overlap_penalty(sq) < 1e-9:
                    improved = True
                    break
                sq[i][3] = old[3]
        if not improved:
            break
    # small random rotation/move search
    for _ in range(200):
        i = rng.randrange(n)
        if sq[i][3] <= 0: continue
        old = list(sq[i])
        cx, cy, ang, side = sq[i]
        cx = min(max(cx + (rng.random() - 0.5) * 0.02, 0.0), 1.0)
        cy = min(max(cy + (rng.random() - 0.5) * 0.02, 0.0), 1.0)
        ang = (ang + (rng.random() - 0.5) * 0.05) % 1.0
        sq[i] = [cx, cy, ang, side]
        if _overlap_penalty(sq) > 1e-9:
            sq[i] = old
    return [tuple(s) for s in sq]
