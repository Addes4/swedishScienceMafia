import math
import random

# ----------------------------------------------------------------------
# Basic geometry helpers
# ----------------------------------------------------------------------

def square_corners(cx, cy, ang, s):
    """Return 4 corners of a square (centre, angle in turns, side)."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa,
                    cy + dx * sa + dy * ca))
    return pts

def clamp(v, lo, hi):
    if v < lo:
        return lo
    if v > hi:
        return hi
    return v

def sat_overlap(a_pts, b_pts):
    """SAT overlap depth between two convex polygons.
       Returns True if they overlap in interior and a rough penetration measure."""
    axes = []
    for pts in (a_pts, b_pts):
        for i in range(4):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            axes.append((-ey, ex))
    best = 1e9
    for ax, ay in axes:
        na = math.hypot(ax, ay)
        if na < 1e-14:
            continue
        ax, ay = ax / na, ay / na
        amin, amax = 1e9, -1e9
        for x, y in a_pts:
            p = x * ax + y * ay
            if p < amin: amin = p
            if p > amax: amax = p
        bmin, bmax = 1e9, -1e9
        for x, y in b_pts:
            p = x * ax + y * ay
            if p < bmin: bmin = p
            if p > bmax: bmax = p
        # overlap on this axis
        ov = min(amax, bmax) - max(amin, bmin)
        if ov <= 0:
            return False, 0.0
        if ov < best:
            best = ov
    return True, best

def in_unit(pts):
    for x, y in pts:
        if x < -1e-12 or x > 1 + 1e-12 or y < -1e-12 or y > 1 + 1e-12:
            return False
    return True

def violation_measure(squares):
    """Total penalty: overlap depth plus boundary violation."""
    n = len(squares)
    corners = [square_corners(*sq) for sq in squares]
    pen = 0.0
    # boundary violations
    for pts in corners:
        for x, y in pts:
            if x < 0:
                pen += (-x) ** 2
            if x > 1:
                pen += (x - 1) ** 2
            if y < 0:
                pen += (-y) ** 2
            if y > 1:
                pen += (y - 1) ** 2
    # overlaps (only for positive-size squares)
    for i in range(n):
        if squares[i][3] <= 1e-15:
            continue
        ci = corners[i]
        for j in range(i + 1, n):
            if squares[j][3] <= 1e-15:
                continue
            ov, depth = sat_overlap(ci, corners[j])
            if ov:
                pen += depth * depth
    return pen

def total_side(squares):
    return sum(sq[3] for sq in squares)

# ----------------------------------------------------------------------
# Greedy initial packings
# ----------------------------------------------------------------------

def grid_packing(n):
    k = max(1, int(math.isqrt(n)))
    side = 1.0 / k
    sq = []
    for i in range(k):
        for j in range(k):
            sq.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    sq = sq[:n]
    while len(sq) < n:
        sq.append((0.5, 0.5, 0.0, 0.0))
    return sq

def slice_packing(n):
    """Greedy: put squares in a row then squarish subdivision."""
    sq = []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # try several grid / sliced starts
    best = None
    best_val = -1
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        if rows * cols < n:
            continue
        w = 1.0 / cols
        h = 1.0 / rows
        s = min(w, h)
        cand = []
        for i in range(cols):
            for j in range(rows):
                if len(cand) < n:
                    cand.append(((i + 0.5) * w, (j + 0.5) * h, 0.0, s))
        while len(cand) < n:
            cand.append((0.5, 0.5, 0.0, 0.0))
        val = total_side(cand)
        if val > best_val:
            best_val = val
            best = cand
    return best

def random_packing(n, rng):
    sq = []
    for _ in range(n):
        s = rng.random() * 0.3
        cx = rng.random()
        cy = rng.random()
        ang = rng.random()
        sq.append((cx, cy, ang, s))
    return sq

# ----------------------------------------------------------------------
# Local search / simulated annealing
# ----------------------------------------------------------------------

def optimize(squares, n, rng, time_budget_iters):
    """Penalty-based stochastic local optimisation."""
    sq = [list(s) for s in squares]
    # ensure positive sizes slightly
    for s in sq:
        if s[3] < 1e-12:
            s[3] = 1e-9
    best = [s[:] for s in sq]
    best_score = total_side(sq) - 1000.0 * violation_measure(sq)

    T0 = 0.05
    T1 = 1e-4
    cur_score = best_score

    for it in range(time_budget_iters):
        f = it / max(1, time_budget_iters - 1)
        T = T0 * (T1 / T0) ** f

        idx = rng.randrange(n)
        old = sq[idx][:]
        # choose move
        r = rng.random()
        if r < 0.35:
            # move centre
            sq[idx][0] = clamp(sq[idx][0] + rng.gauss(0, 0.03), 0.0, 1.0)
            sq[idx][1] = clamp(sq[idx][1] + rng.gauss(0, 0.03), 0.0, 1.0)
        elif r < 0.55:
            # rotate
            sq[idx][2] = (sq[idx][2] + rng.gauss(0, 0.05)) % 1.0
        elif r < 0.85:
            # resize
            sq[idx][3] = max(0.0, sq[idx][3] + rng.gauss(0, 0.02))
        else:
            # combined
            sq[idx][0] = clamp(sq[idx][0] + rng.gauss(0, 0.05), 0.0, 1.0)
            sq[idx][1] = clamp(sq[idx][1] + rng.gauss(0, 0.05), 0.0, 1.0)
            sq[idx][2] = (sq[idx][2] + rng.gauss(0, 0.08)) % 1.0
            sq[idx][3] = max(0.0, sq[idx][3] + rng.gauss(0, 0.03))

        new_pen = violation_measure(sq)
        new_side = total_side(sq)
        new_score = new_side - 1000.0 * new_pen

        delta = new_score - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(T, 1e-12)):
            cur_score = new_score
            if new_score > best_score:
                best_score = new_score
                best = [s[:] for s in sq]
        else:
            sq[idx] = old

    return best

# ----------------------------------------------------------------------
# Repair: make a feasible packing, dropping sizes if needed
# ----------------------------------------------------------------------

def repair(squares):
    """Ensure feasibility; shrink / move if necessary."""
    sq = [list(s) for s in squares]
    n = len(sq)
    for _ in range(200):
        pen = violation_measure(sq)
        if pen < 1e-12:
            break
        corners = [square_corners(*s) for s in sq]
        changed = False
        # shrink offending squares
        for i in range(n):
            if sq[i][3] <= 0:
                continue
            ci = corners[i]
            bad = False
            for x, y in ci:
                if x < -1e-12 or x > 1+1e-12 or y < -1e-12 or y > 1+1e-12:
                    bad = True
                    break
            if not bad:
                for j in range(n):
                    if i == j or sq[j][3] <= 0:
                        continue
                    ov, _ = sat_overlap(ci, corners[j])
                    if ov:
                        bad = True
                        break
            if bad:
                sq[i][3] *= 0.98
                if sq[i][3] < 1e-12:
                    sq[i][3] = 0.0
                changed = True
        if not changed:
            # move slightly toward centre
            for i in range(n):
                if sq[i][3] > 0:
                    sq[i][0] += (0.5 - sq[i][0]) * 0.05
                    sq[i][1] += (0.5 - sq[i][1]) * 0.05
    # final safety: if still bad, drop problem squares to zero
    for _ in range(50):
        pen = violation_measure(sq)
        if pen < 1e-10:
            break
        corners = [square_corners(*s) for s in sq]
        worst_i = -1
        worst_v = -1
        for i in range(n):
            if sq[i][3] <= 0:
                continue
            ci = corners[i]
            v = 0.0
            for x, y in ci:
                if x < 0: v += (-x)
                if x > 1: v += (x - 1)
                if y < 0: v += (-y)
                if y > 1: v += (y - 1)
            for j in range(n):
                if i == j or sq[j][3] <= 0:
                    continue
                ov, d = sat_overlap(ci, corners[j])
                if ov:
                    v += d
            if v > worst_v:
                worst_v = v
                worst_i = i
        if worst_i >= 0:
            sq[worst_i][3] = 0.0
        else:
            break
    return [(s[0], s[1], s[2] % 1.0, max(0.0, s[3])) for s in sq]

# ----------------------------------------------------------------------
# Multi-start driver
# ----------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n * 7919)

    # collect starts
    starts = []
    starts.append(grid_packing(n))
    starts.append(slice_packing(n))
    if n <= 100:
        for _ in range(3):
            starts.append(random_packing(n, rng))
    else:
        for _ in range(1):
            starts.append(random_packing(n, rng))

    best_sq = None
    best_val = -1.0

    # total iteration budget per n (approximate, fast C-like operations via pure python)
    base_iters = int(min(60000, max(4000, 4000 + n * 8)))

    for si, st in enumerate(starts):
        # tune budget
        iters = base_iters
        cand = optimize(st, n, rng, iters)
        cand = repair(cand)
        val = total_side(cand)
        if val > best_val:
            best_val = val
            best_sq = cand

    # final polish: short annealing around best
    for _ in range(2):
        cand = optimize(best_sq, n, rng, int(base_iters * 0.4))
        cand = repair(cand)
        val = total_side(cand)
        if val > best_val:
            best_val = val
            best_sq = cand

    # final output
    out = []
    for cx, cy, ang, s in best_sq:
        out.append((clamp(cx, 0.0, 1.0), clamp(cy, 0.0, 1.0), ang % 1.0, max(0.0, s)))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
