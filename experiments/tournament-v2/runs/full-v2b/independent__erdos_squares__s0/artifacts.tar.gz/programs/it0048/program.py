import math
import random
import numpy as np
from scipy.optimize import minimize

EPS = 1e-9

# ---------- geometry ----------

def corners(cx, cy, ang, s):
    """Return the 4 corners of a square (center, angle fraction of full turn, side)."""
    th = 2.0 * math.pi * ang
    c, si = math.cos(th), math.sin(th)
    h = s * 0.5
    pts = []
    for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        x = cx + h * (sx * c - sy * si)
        y = cy + h * (sx * si + sy * c)
        pts.append((x, y))
    return pts

def axes(cx, cy, ang, s):
    """Return center and two unit axes of the square."""
    th = 2.0 * math.pi * ang
    c, si = math.cos(th), math.sin(th)
    u = (c, si)
    v = (-si, c)
    return (cx, cy), u, v

def proj_radius(pts, ax):
    n = len(pts)
    mn = mx = pts[0][0]*ax[0] + pts[0][1]*ax[1]
    for i in range(1, n):
        d = pts[i][0]*ax[0] + pts[i][1]*ax[1]
        if d < mn: mn = d
        if d > mx: mx = d
    return 0.5 * (mx - mn), 0.5 * (mx + mn)

def overlap_area(i, j, P):
    """Approximate overlap area between squares i and j (returns >0 if overlapping)."""
    ci = P[i][0:2]; ai = P[i][2]; si = P[i][3]
    cj = P[j][0:2]; aj = P[j][2]; sj = P[j][3]
    if si <= 0 or sj <= 0:
        return 0.0
    c1, u1, v1 = axes(ci[0], ci[1], ai, si)
    c2, u2, v2 = axes(cj[0], cj[1], aj, sj)
    h1 = si * 0.5
    h2 = sj * 0.5
    # separating axis tests using both squares' axes + diagonal axes
    for u in (u1, v1, u2, v2):
        r1, m1 = proj_radius(corners(ci[0], ci[1], ai, si), u)
        r2, m2 = proj_radius(corners(cj[0], cj[1], aj, sj), u)
        if r1 + r2 <= abs(m1 - m2) + 1e-12:
            return 0.0
    # if no separating axis found, estimate overlap depth
    # project both onto both axes of i and j, compute min overlap in each direction
    ov = []
    for u in (u1, v1, u2, v2):
        c1p = c1[0]*u[0] + c1[1]*u[1]
        c2p = c2[0]*u[0] + c2[1]*u[1]
        r1, _ = proj_radius(corners(ci[0], ci[1], ai, si), u)
        r2, _ = proj_radius(corners(cj[0], cj[1], aj, sj), u)
        # signed distance of centers along this axis
        d = abs(c1p - c2p)
        ov.append(max(0.0, r1 + r2 - d))
    return min(ov) if ov else 0.0

def containment_penalty(x, y, s):
    """Penalty if square with half-diagonal s*sqrt(2)/2 extends outside [0,1]."""
    r = s * math.sqrt(2.0) / 2.0
    pen = 0.0
    if x - r < -1e-9: pen += (r - x) ** 2
    if x + r > 1 + 1e-9: pen += (x + r - 1) ** 2
    if y - r < -1e-9: pen += (r - y) ** 2
    if y + r > 1 + 1e-9: pen += (y + r - 1) ** 2
    return pen

# ---------- objective ----------

def unpack(v, n):
    P = []
    for i in range(n):
        cx = v[4*i]
        cy = v[4*i+1]
        ang = v[4*i+2]
        s = v[4*i+3]
        P.append((cx, cy, ang, s))
    return P

def objective_and_grad(v, n, w_cont=500.0, w_over=500.0, target_bonus=0.0):
    P = unpack(v, n)
    total = 0.0
    for cx, cy, ang, s in P:
        total += s
    # penalties
    pen_cont = 0.0
    for cx, cy, ang, s in P:
        pen_cont += containment_penalty(cx, cy, s)
    pen_over = 0.0
    for i in range(n):
        for j in range(i+1, n):
            ai = P[i][3]
            aj = P[j][3]
            if ai <= 0.0 or aj <= 0.0:
                continue
            d2 = (P[i][0]-P[j][0])**2 + (P[i][1]-P[j][1])**2
            rmax = (ai + aj)**2
            if d2 > rmax:
                continue
            o = overlap_area(i, j, P)
            if o > 0:
                pen_over += o
    return -(total - w_cont*pen_cont - w_over*pen_over)

def objective(v, n):
    return objective_and_grad(v, n)

# numerical gradient helper (fallback)
def num_grad(fun, v, n, eps=1e-6):
    g = np.zeros_like(v)
    f0 = fun(v, n)
    for i in range(len(v)):
        vv = v.copy()
        vv[i] += eps
        g[i] = (fun(vv, n) - f0) / eps
    return g

# decompose gradient: we know d(total)/dv is linear, penalties differentiate numerically
def obj_grad(v, n, w_cont=500.0, w_over=500.0):
    # numerical gradient of full objective is simplest and robust
    return num_grad(objective, v, n)

# ---------- initial layouts ----------

def layout_grid(n, k):
    """k x k grid plus zero-size leftovers."""
    s = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            out.append(((i+0.5)*s, (j+0.5)*s, 0.0, s))
    out = out[:n]
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out

def layout_rows(n, m):
    """m equal squares in a row stacked vertically; each row fits floor(1/s) squares... 
       Instead: m columns, n//m rows of full width; remainder in last row."""
    # simple: arrange into rows, each row has c squares of equal size
    c = max(1, int(math.ceil(math.sqrt(n))))
    r = int(math.ceil(n / c))
    s = min(1.0 / c, 1.0 / r)
    out = []
    idx = 0
    for j in range(r):
        for i in range(c):
            if idx >= n: break
            out.append(((i+0.5)*s, (j+0.5)*s, 0.0, s))
            idx += 1
        if idx >= n: break
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out

def layout_brick(n):
    """Brick-like staggered rows."""
    best = None
    for c in range(1, n+1):
        r = int(math.ceil(n / c))
        if r < 1: continue
        s = min(1.0 / c, 1.0 / r)
        out = []
        idx = 0
        for j in range(r):
            shift = 0.0
            if j % 2 == 1:
                shift = s * 0.5
            for i in range(c):
                if idx >= n: break
                x = (i+0.5)*s + shift
                if x > 1 - s*0.5: x = 1 - s*0.5
                if x < s*0.5: x = s*0.5
                out.append((x, (j+0.5)*s, 0.0, s))
                idx += 1
        while len(out) < n:
            out.append((0.5, 0.5, 0.0, 0.0))
        # rough estimate
        val = sum(p[3] for p in out)
        if best is None or val > best[0]:
            best = (val, out)
    return best[1] if best else layout_grid(n, max(1, int(math.isqrt(n))))

def random_jitter(layout, scale=0.05, rng=None):
    if rng is None: rng = random
    out = []
    for (cx, cy, ang, s) in layout:
        if s <= 0:
            out.append((cx, cy, ang, s))
            continue
        ncx = min(1.0, max(0.0, cx + rng.uniform(-scale, scale)))
        ncy = min(1.0, max(0.0, cy + rng.uniform(-scale, scale)))
        nang = (ang + rng.uniform(-scale, scale)) % 1.0
        ns = s
        out.append((ncx, ncy, nang, ns))
    return out

# ---------- local optimization ----------

def pack_to_vector(P):
    v = []
    for cx, cy, ang, s in P:
        v.extend([cx, cy, ang, s])
    return np.array(v, dtype=float)

def vector_to_pack(v, n):
    return unpack(v, n)

def fix_vector(v, n):
    """Clip center coordinates to [0,1] and sizes to >=0, angles mod 1."""
    v = v.copy()
    for i in range(n):
        v[4*i] = min(1.0, max(0.0, v[4*i]))
        v[4*i+1] = min(1.0, max(0.0, v[4*i+1]))
        v[4*i+2] = v[4*i+2] % 1.0
        v[4*i+3] = max(0.0, v[4*i+3])
    return v

def optimize_layout(P, n, maxiter=200, w_cont=500.0, w_over=500.0, verbose=False):
    v0 = fix_vector(pack_to_vector(P), n)
    bounds = []
    for i in range(n):
        bounds.append((0.0, 1.0))  # cx
        bounds.append((0.0, 1.0))  # cy
        bounds.append((0.0, 0.999999))  # angle (mod 1)
        bounds.append((0.0, 1.0))  # side
    def fun(v):
        return objective(v, n)
    try:
        res = minimize(
            fun, v0, method='L-BFGS-B', bounds=bounds,
            options={'maxiter': maxiter, 'ftol': 1e-12, 'gtol': 1e-8}
        )
        v = fix_vector(res.x, n)
        return v, res.fun
    except Exception:
        return v0, fun(v0)

# ---------- main solve ----------

def solve(n):
    if n <= 0:
        return []
    rng = random.Random(12345)

    # candidate initial layouts
    candidates = []
    # grid for perfect squares
    k = int(math.isqrt(n))
    for kk in (k, k+1, max(1, k-1)):
        if kk < 1: continue
        candidates.append(layout_grid(n, kk))
    # rows / brick
    candidates.append(layout_rows(n, max(1, int(math.ceil(math.sqrt(n))))))
    candidates.append(layout_brick(n))
    # random equal-size
    for _ in range(3):
        s = 1.0 / max(1, int(math.ceil(math.sqrt(n))))
        P = []
        for i in range(n):
            if i < n:
                P.append((rng.uniform(s*0.5, 1-s*0.5), rng.uniform(s*0.5, 1-s*0.5), rng.random(), s))
        while len(P) < n:
            P.append((0.5, 0.5, 0.0, 0.0))
        candidates.append(P)

    best_val = -1e18
    best_P = None
    w_cont = 800.0
    w_over = 800.0
    # first pass: lower penalty weights to explore, then increase
    stages = [(200.0, 200.0), (800.0, 800.0), (3000.0, 3000.0)]
    for P0 in candidates:
        P = P0
        # global-ish jitter
        P = random_jitter(P, scale=0.03, rng=rng)
        for (wc, wo) in stages:
            v0 = fix_vector(pack_to_vector(P), n)
            bounds = [(0.0, 1.0)]*(4*n)
            for i in range(n):
                bounds[4*i] = (0.0, 1.0)
                bounds[4*i+1] = (0.0, 1.0)
                bounds[4*i+2] = (0.0, 2.0*math.pi)
                bounds[4*i+3] = (0.0, 1.0)

            def fun(v, wc=wc, wo=wo):
                return objective_and_grad(v, n, w_cont=wc, w_over=wo)

            try:
                res = minimize(
                    fun, v0, method='L-BFGS-B', bounds=bounds,
                    options={'maxiter': 150, 'ftol': 1e-12, 'gtol': 1e-8}
                )
                v = res.x.copy()
                v = fix_vector(v, n)
                P = unpack(v, n)
            except Exception:
                pass
        val = sum(p[3] for p in P)
        # measure actual overlap/containment
        pen_c = sum(containment_penalty(*p) for p in P)
        pen_o = 0.0
        for i in range(n):
            for j in range(i+1, n):
                if P[i][3] > 0 and P[j][3] > 0:
                    pen_o += overlap_area(i, j, P)
        # feasible bonus
        feas = -100.0*(pen_c + pen_o)
        score = val + feas
        if score > best_val:
            best_val = score
            best_P = P

    if best_P is None:
        best_P = layout_grid(n, max(1, int(math.isqrt(n))))

    # final cleanup: if any overlaps remain, shrink slightly
    P = best_P
    for _ in range(3):
        pen_o = 0.0
        for i in range(n):
            for j in range(i+1, n):
                if P[i][3] > 0 and P[j][3] > 0:
                    pen_o += overlap_area(i, j, P)
        if pen_o < 1e-9:
            break
        # reduce sizes slightly
        newP = []
        for cx, cy, ang, s in P:
            newP.append((cx, cy, ang, max(0.0, s*0.98)))
        P = newP

    # ensure feasibility: clip to unit square
    P = [(min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), ang % 1.0, max(0.0, s))
         for (cx, cy, ang, s) in P]
    return P

if __name__ == "__main__":
    for n in range(1, 21):
        P = solve(n)
        print(n, sum(p[3] for p in P), P[:3])
