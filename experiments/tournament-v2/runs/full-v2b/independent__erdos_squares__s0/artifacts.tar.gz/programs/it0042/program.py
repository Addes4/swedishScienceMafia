import math
import random
import numpy as np
from scipy.optimize import minimize, NonlinearConstraint, LinearConstraint

TIME_LIMIT = 52.0


def _box_square(cx, cy, ang, s):
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    corners = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        corners.append((cx + ca * dx - sa * dy, cy + sa * dx + ca * dy))
    return corners


def _overlap(ax, ay, aang, asd, bx, by, bang, bsd):
    A = _box_square(ax, ay, aang, asd)
    B = _box_square(bx, by, bang, bsd)
    def axes(poly):
        out = []
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ex, ey = x2 - x1, y2 - y1
            l = math.hypot(ex, ey)
            if l > 1e-15:
                out.append((-ey / l, ex / l))
        return out
    for nx, ny in axes(A) + axes(B):
        amin = amax = A[0][0] * nx + A[0][1] * ny
        for x, y in A[1:]:
            d = x * nx + y * ny
            if d < amin: amin = d
            if d > amax: amax = d
        bmin = bmax = B[0][0] * nx + B[0][1] * ny
        for x, y in B[1:]:
            d = x * nx + y * ny
            if d < bmin: bmin = d
            if d > bmax: bmax = d
        if amax <= bmin + 1e-12 or bmax <= amin + 1e-12:
            return 0.0
    Ax = [p[0] for p in A]; Ay = [p[1] for p in A]
    if max(Ax) <= min(p[0] for p in B) + 1e-12: return 0.0
    if max(p[0] for p in B) <= min(Ax) + 1e-12: return 0.0
    if max(Ay) <= min(p[1] for p in B) + 1e-12: return 0.0
    if max(p[1] for p in B) <= min(Ay) + 1e-12: return 0.0
    cx1 = sum(Ax) / 4.0; cy1 = sum(Ay) / 4.0
    cx2 = sum(p[0] for p in B) / 4.0; cy2 = sum(p[1] for p in B) / 4.0
    return math.hypot(cx1 - cx2, cy1 - cy2) + 1.0


def _feasible(sq):
    n = len(sq)
    for i in range(n):
        cx, cy, ang, s = sq[i]
        if s < -1e-12: return False
        if cx < -1e-9 or cx > 1 + 1e-9 or cy < -1e-9 or cy > 1 + 1e-9:
            return False
        A = _box_square(cx, cy, ang, max(s, 0.0))
        for x, y in A:
            if x < -1e-8 or x > 1 + 1e-8 or y < -1e-8 or y > 1 + 1e-8:
                return False
        for j in range(i):
            if _overlap(cx, cy, ang, s, *sq[j]) > 0:
                return False
    return True


def _grid_init(n):
    k = int(math.isqrt(n))
    if k * k < n:
        k += 1
    s = 1.0 / k
    sq = []
    for i in range(k):
        for j in range(k):
            if len(sq) < n:
                sq.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
    while len(sq) < n:
        sq.append([0.5, 0.5, 0.0, 0.0])
    return sq


def _sum(sq):
    return sum(max(0.0, s[3]) for s in sq)


def _neighbor(sq, rng, scale):
    n = len(sq)
    i = rng.randrange(n)
    cx, cy, ang, s = sq[i]
    mode = rng.random()
    if mode < 0.45:
        dx = rng.uniform(-scale, scale) * (1.0 - s)
        dy = rng.uniform(-scale, scale) * (1.0 - s)
        cx = min(1.0 - s * 0.0, max(0.0, cx + dx))
        cy = min(1.0 - s * 0.0, max(0.0, cy + dy))
    elif mode < 0.7:
        s = max(0.0, s + rng.uniform(-scale, scale) * 0.2)
    else:
        ang = (ang + rng.uniform(-0.15, 0.15)) % 1.0
    cand = [list(t) for t in sq]
    cand[i] = [cx, cy, ang, s]
    return cand


def _repair(sq, rng, iters=250):
    n = len(sq)
    cur = [list(t) for t in sq]
    best = [list(t) for t in cur]
    bestv = _sum(cur) if _feasible(cur) else -1e18
    for _ in range(iters):
        i = rng.randrange(n)
        j = rng.randrange(n)
        if i == j:
            continue
        cx, cy, ang, s = cur[i]
        ox, oy, oang, osd = cur[j]
        if _overlap(cx, cy, ang, s, ox, oy, oang, osd) > 0:
            A = _box_square(cx, cy, ang, s)
            B = _box_square(ox, oy, oang, osd)
            cxa = sum(p[0] for p in A) / 4.0
            cya = sum(p[1] for p in A) / 4.0
            cxb = sum(p[0] for p in B) / 4.0
            cyb = sum(p[1] for p in B) / 4.0
            dx, dy = cxa - cxb, cya - cyb
            d = math.hypot(dx, dy) + 1e-9
            dx, dy = dx / d, dy / d
            push = 0.02
            cur[i][0] = min(1.0, max(0.0, cx + dx * push))
            cur[i][1] = min(1.0, max(0.0, cy + dy * push))
            cur[j][0] = min(1.0, max(0.0, ox - dx * push))
            cur[j][1] = min(1.0, max(0.0, oy - dy * push))
        if _feasible(cur):
            v = _sum(cur)
            if v > bestv:
                bestv = v
                best = [list(t) for t in cur]
    return best


def _slsqp_improve(sq):
    n = len(sq)
    x0 = np.array([v for s in sq for v in s], dtype=float)
    for i in range(n):
        if x0[4 * i + 2] < 0 or x0[4 * i + 2] > 1:
            x0[4 * i + 2] %= 1.0
        if x0[4 * i + 3] < 0:
            x0[4 * i + 3] = 0.0

    def negsum(x):
        return -sum(max(0.0, x[4 * i + 3]) for i in range(n))

    def constraints_all(x):
        out = []
        for i in range(n):
            cx, cy, ang, s = x[4 * i:4 * i + 4]
            if s < 0:
                out.append(s)
            A = np.array(_corners_np(cx, cy, ang, max(0.0, s)))
            for v in A[:, 0]:
                out.append(v)
                out.append(1.0 - v)
            for v in A[:, 1]:
                out.append(v)
                out.append(1.0 - v)
        for i in range(n):
            for j in range(i + 1, n):
                out.append(-_overlap_np(x[4 * i:4 * i + 4], x[4 * j:4 * j + 4]))
        return np.array(out)

    try:
        res = minimize(negsum, x0, method="SLSQP",
                       constraints=[{"type": "ineq", "fun": constraints_all}],
                       options={"maxiter": 60, "ftol": 1e-10})
        if res.success and res.fun < 0:
            x = res.x
            cand = []
            for i in range(n):
                cx, cy, ang, s = x[4 * i:4 * i + 4]
                if s < 0: s = 0.0
                if cx < 0: cx = 0
                if cx > 1: cx = 1
                if cy < 0: cy = 0
                if cy > 1: cy = 1
                cand.append([cx, cy, ang % 1.0, s])
            if _feasible(cand) and _sum(cand) > _sum(sq):
                return cand
    except Exception:
        pass
    return sq


def _corners_np(cx, cy, ang, s):
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    return [
        (cx + ca * -h - sa * -h, cy + sa * -h + ca * -h),
        (cx + ca * h - sa * -h, cy + sa * h + ca * -h),
        (cx + ca * h - sa * h, cy + sa * h + ca * h),
        (cx + ca * -h - sa * h, cy + sa * -h + ca * h),
    ]


def _overlap_np(si, sj):
    cx, cy, ang, s = si
    ox, oy, oang, osd = sj
    A = _box_square(cx, cy, ang, max(0.0, s))
    B = _box_square(ox, oy, oang, max(0.0, osd))
    def axes(poly):
        out = []
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ex, ey = x2 - x1, y2 - y1
            l = math.hypot(ex, ey)
            if l > 1e-15:
                out.append((-ey / l, ex / l))
        return out
    for nx, ny in axes(A) + axes(B):
        amin = amax = A[0][0] * nx + A[0][1] * ny
        for x, y in A[1:]:
            d = x * nx + y * ny
            if d < amin: amin = d
            if d > amax: amax = d
        bmin = bmax = B[0][0] * nx + B[0][1] * ny
        for x, y in B[1:]:
            d = x * nx + y * ny
            if d < bmin: bmin = d
            if d > bmax: bmax = d
        if amax <= bmin + 1e-12 or bmax <= amin + 1e-12:
            return 0.0
    return 1.0


def solve(n):
    rng = random.Random(12345 + n * 7919)
    best = _grid_init(n)
    if not _feasible(best):
        best = [[0.5, 0.5, 0.0, 0.0] for _ in range(n)]
    bestval = _sum(best)

    pool = [best]
    t0 = __import__("time").time()
    scale = 0.15
    while __import__("time").time() - t0 < TIME_LIMIT * 0.5:
        base = pool[rng.randrange(len(pool))] if pool else best
        cand = _neighbor(base, rng, scale)
        cand = _repair(cand, rng, iters=120)
        if _feasible(cand):
            v = _sum(cand)
            if v > bestval:
                bestval = v
                best = [list(t) for t in cand]
            pool.append(cand)
            if len(pool) > 40:
                pool.pop(0)
        if rng.random() < 0.02:
            scale = max(0.03, min(0.4, scale + rng.uniform(-0.05, 0.05)))

    cur = best
    cur = _slsqp_improve(cur)
    if _feasible(cur) and _sum(cur) > bestval:
        bestval = _sum(cur)
        best = cur

    while __import__("time").time() - t0 < TIME_LIMIT:
        base = best
        for _ in range(30):
            cand = _neighbor(base, rng, 0.1)
            cand = _repair(cand, rng, iters=150)
            if _feasible(cand) and _sum(cand) > bestval:
                bestval = _sum(cand)
                best = [list(t) for t in cand]
                break
        else:
            break

    result = []
    for cx, cy, ang, s in best:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        s = max(0.0, min(1.0, s))
        result.append((cx, cy, ang, s))
    if not _feasible([[a, b, c, d] for a, b, c, d in result]):
        return [(0.5, 0.5, 0.0, 0.0)] * n
    return result
