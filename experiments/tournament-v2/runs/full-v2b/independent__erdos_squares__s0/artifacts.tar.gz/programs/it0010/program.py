import math
import random
import numpy as np
from scipy.optimize import minimize

def _corners(cx, cy, angle, side):
    """Return 4 corners of a square centered at (cx,cy), rotated by angle (fraction of full turn)."""
    theta = 2 * math.pi * angle
    c, s = math.cos(theta), math.sin(theta)
    h = side / 2.0
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + x * c - y * s, cy + x * s + y * c) for x, y in pts]

def _overlap(s1, s2):
    """Check if two squares (cx, cy, angle, side) overlap in interiors (allow touching)."""
    if s1[3] <= 0 or s2[3] <= 0:
        return False
    c1 = _corners(*s1)
    c2 = _corners(*s2)
    # For convex polygons: SAT with edge normals of both
    for poly in (c1, c2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            edge = (x2 - x1, y2 - y1)
            # normal
            nx, ny = -edge[1], edge[0]
            # project both polygons
            proj1 = [nx * p[0] + ny * p[1] for p in c1]
            proj2 = [nx * p[0] + ny * p[1] for p in c2]
            if max(proj1) < min(proj2) - 1e-12 or max(proj2) < min(proj1) - 1e-12:
                return False
    return True

def _inside(s):
    """Check square s is inside unit square."""
    if s[3] <= 0:
        return True
    for x, y in _corners(*s):
        if x < -1e-12 or x > 1 + 1e-12 or y < -1e-12 or y > 1 + 1e-12:
            return False
    return True

def _feasible(squares):
    """Check all squares inside unit square and no overlapping interiors."""
    for s in squares:
        if not _inside(s):
            return False
    for i in range(len(squares)):
        for j in range(i + 1, len(squares)):
            if _overlap(squares[i], squares[j]):
                return False
    return True

def _random_solution(n):
    """Generate a random feasible packing."""
    if n == 0:
        return []
    squares = []
    # Start with small random squares, then try to grow them
    for _ in range(n):
        # Random small square
        side = 0.01
        cx = random.uniform(side/2, 1 - side/2)
        cy = random.uniform(side/2, 1 - side/2)
        angle = random.uniform(0, 1)
        squares.append((cx, cy, angle, side))
    # Greedy grow each square
    for _ in range(30):
        for i in range(n):
            # Try to increase side
            best = squares[i][3]
            for _ in range(10):
                new_side = best * random.uniform(1.0, 1.5) + 0.001
                cx, cy, angle, _ = squares[i]
                # Clamp center
                cx = max(new_side/2, min(1 - new_side/2, cx))
                cy = max(new_side/2, min(1 - new_side/2, cy))
                new_s = (cx, cy, angle, new_side)
                if _inside(new_s):
                    # Check overlap with others
                    ok = True
                    for j in range(n):
                        if i != j and _overlap(new_s, squares[j]):
                            ok = False
                            break
                    if ok:
                        squares[i] = new_s
                        best = new_side
            squares[i] = (squares[i][0], squares[i][1], squares[i][2], best)
    return squares

def _grid_solution(n):
    """Start with a grid packing."""
    k = math.isqrt(n)
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]

def _optimize(squares, n, max_iter=100):
    """Local optimization: adjust positions, angles, sizes."""
    squares = [list(s) for s in squares]
    for iteration in range(max_iter):
        improved = False
        for i in range(n):
            if squares[i][3] <= 0:
                # Try to place a small square somewhere
                for _ in range(20):
                    cx = random.uniform(0.01, 0.99)
                    cy = random.uniform(0.01, 0.99)
                    angle = random.uniform(0, 1)
                    side = 0.005
                    new_s = (cx, cy, angle, side)
                    if _inside(new_s):
                        ok = True
                        for j in range(n):
                            if i != j and _overlap(new_s, tuple(squares[j])):
                                ok = False
                                break
                        if ok:
                            squares[i] = list(new_s)
                            improved = True
                            break
                continue
            # Try to grow this square
            best_side = squares[i][3]
            best_params = squares[i][:3]
            # Random perturbations
            for _ in range(50):
                ds = best_side * random.uniform(0, 0.3) + 0.001
                new_side = best_side + ds
                # Try new center and angle
                for _ in range(10):
                    dcx = random.uniform(-0.05, 0.05)
                    dcy = random.uniform(-0.05, 0.05)
                    da = random.uniform(-0.1, 0.1)
                    cx = max(new_side/2, min(1 - new_side/2, squares[i][0] + dcx))
                    cy = max(new_side/2, min(1 - new_side/2, squares[i][1] + dcy))
                    angle = (squares[i][2] + da) % 1.0
                    new_s = (cx, cy, angle, new_side)
                    if not _inside(new_s):
                        continue
                    ok = True
                    for j in range(n):
                        if i != j and _overlap(new_s, tuple(squares[j])):
                            ok = False
                            break
                    if ok:
                        squares[i] = list(new_s)
                        best_side = new_side
                        improved = True
                        break
                if improved:
                    break
        if not improved:
            # Try local coordinate descent on all parameters simultaneously
            break
    return [tuple(s) for s in squares]

def solve(n):
    """Return n squares inside unit square maximising sum of side lengths."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    best_squares = None
    best_score = -1
    
    # Try multiple strategies
    strategies = []
    
    # Grid-based
    if n <= 100:
        k = math.isqrt(n)
        if k * k <= n:
            strategies.append(_grid_solution(n))
    
    # Random starts
    num_random = 3 if n <= 20 else 1
    for _ in range(num_random):
        strategies.append(_random_solution(n))
    
    # Also try grid with extra squares
    if n <= 50:
        k = math.isqrt(n)
        remaining = n - k * k
        if remaining > 0:
            # Try k x k grid plus smaller squares in gaps
            side = 1.0 / k
            squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
            # Add remaining as tiny squares
            squares += [(0.5, 0.5, 0.0, 0.0001)] * remaining
            strategies.append(_optimize(squares, n, max_iter=50))
    
    # For small n, try more optimization
    if n <= 10:
        for _ in range(5):
            s = _random_solution(n)
            s = _optimize(s, n, max_iter=200)
            strategies.append(s)
    
    for s in strategies:
        s_opt = _optimize(s, n, max_iter=100 if n <= 30 else 30)
        if _feasible(s_opt):
            score = sum(x[3] for x in s_opt)
            if score > best_score:
                best_score = score
                best_squares = s_opt
    
    if best_squares is None:
        # Fallback: grid
        best_squares = _grid_solution(n)
    
    # Final polish
    best_squares = _optimize(best_squares, n, max_iter=50)
    
    # Ensure n squares
    if len(best_squares) < n:
        best_squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_squares))
    best_squares = best_squares[:n]
    
    # Verify and fix if needed
    if not _feasible(best_squares):
        best_squares = _grid_solution(n)
    
    # Clamp all values to [0,1]
    result = []
    for cx, cy, angle, side in best_squares:
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        angle = angle % 1.0
        side = max(0.0, min(1.0, side))
        result.append((cx, cy, angle, side))
    
    return result
