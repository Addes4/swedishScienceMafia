import math
import random

def solve(n):
    if n <= 0:
        return []
    
    # Generalized approach: use a combination of grid packing and local optimization
    # For small n, we can try to find better packings via optimization
    # For larger n, use a grid-based approach with possible refinement
    
    # Start with a good initial configuration
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    # For n >= 2, use recursive/guillotine or grid-based placement
    # Try to find arrangement that fits n squares with larger total side
    
    # Strategy: use a tiling approach where we recursively subdivide
    # This works well for specific n but we need general
    
    # For general n, we can use a grid plus optimize the last few squares
    # A common effective approach: pack k^2 squares in grid, remaining r squares
    # can be placed by adjusting sizes
    
    # Let's try a heuristic: find best grid size and distribute extra squares
    
    best_squares = None
    best_score = -1.0
    
    # Try different grid configurations
    for k in range(1, int(math.sqrt(n)) + 2):
        if k*k > n + k:  # too many cells
            continue
        
        # Try to pack n squares using a k x k grid with some cells split
        # We can split cells to accommodate more squares
        
        # Simple approach: start with k x k grid of size 1/k
        # We have extra cells = k*k, we need n squares
        # If n <= k*k, we can use k x k grid and make some squares size 0
        # But better: use all k*k cells with size 1/k, and if n > k*k, 
        # we need to subdivide some cells
        
        if n <= k*k:
            # Use k x k grid, all size 1/k, zero-size for rest
            side = 1.0 / k
            squares = []
            for i in range(k):
                for j in range(k):
                    if len(squares) < n:
                        squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
            while len(squares) < n:
                squares.append((0.5, 0.5, 0.0, 0.0))
            score = sum(s[3] for s in squares)
            if score > best_score:
                best_score = score
                best_squares = squares[:]
        else:
            # n > k*k, need to subdivide some cells
            # Subdivide one cell into 4 smaller squares (2x2 grid within cell)
            # Each split adds 3 squares, but reduces total side
            # Try splitting as many cells as needed
            extra = n - k*k
            # Each split of one cell into 4 adds 3 squares
            # We need extra squares, so split ceil(extra/3) cells
            # But this is complex; let's try a different approach
            
            # Alternative: use a finer grid
            k2 = k + 1
            if k2*k2 >= n:
                side = 1.0 / k2
                squares = []
                for i in range(k2):
                    for j in range(k2):
                        if len(squares) < n:
                            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
                while len(squares) < n:
                    squares.append((0.5, 0.5, 0.0, 0.0))
                score = sum(s[3] for s in squares)
                if score > best_score:
                    best_score = score
                    best_squares = squares[:]
    
    # Also try non-grid: recursive guillotine cuts
    # For n squares, we can recursively divide the unit square
    def guillotine_pack(n, x, y, w, h, squares):
        """Pack n squares into rectangle (x,y,w,h) using guillotine cuts."""
        if n == 0:
            return
        if n == 1:
            side = min(w, h)
            squares.append((x + w/2, y + h/2, 0.0, side))
            return
        
        # Try horizontal split
        # n1 squares in top part, n2 in bottom
        best_score = -1
        best_split = None
        
        for n1 in range(1, n):
            n2 = n - n1
            # Optimal split proportion: side lengths proportional to sqrt(n1), sqrt(n2)
            # But we want to maximize sum of sides
            # For simplicity, try equal split
            # Better: try to match side lengths
            # If we split horizontally, each part gets height h1, h2 with h1+h2=h
            # The squares in part 1 are limited by min(w, h1)
            # We want to maximize n1 * min(w, h1) + n2 * min(w, h2)
            # This is complex; just try a few splits
            
            # Try proportional to sqrt(n1) : sqrt(n2)
            r = math.sqrt(n1) / (math.sqrt(n1) + math.sqrt(n2))
            h1 = h * r
            h2 = h - h1
            
            # Check if we can pack n1 squares of size min(w,h1) and n2 of size min(w,h2)
            s1 = min(w, h1)
            s2 = min(w, h2)
            
            # Simple check: can we fit n1 squares of size s1 in (w,h1)?
            # Actually we're packing recursively, so this is just a heuristic
            score = n1 * s1 + n2 * s2
            if score > best_score:
                best_score = score
                best_split = ('h', h1, n1)
            
            # Try vertical split
            r = math.sqrt(n1) / (math.sqrt(n1) + math.sqrt(n2))
            w1 = w * r
            w2 = w - w1
            s1 = min(w1, h)
            s2 = min(w2, h)
            score = n1 * s1 + n2 * s2
            if score > best_score:
                best_score = score
                best_split = ('v', w1, n1)
        
        if best_split[0] == 'h':
            _, h1, n1 = best_split
            guillotine_pack(n1, x, y, w, h1, squares)
            guillotine_pack(n - n1, x, y + h1, w, h - h1, squares)
        else:
            _, w1, n1 = best_split
            guillotine_pack(n1, x, y, w1, h, squares)
            guillotine_pack(n - n1, x + w1, y, w - w1, h, squares)
    
    squares = []
    guillotine_pack(n, 0, 0, 1, 1, squares)
    score = sum(s[3] for s in squares)
    if score > best_score:
        best_score = score
        best_squares = squares[:]
    
    # Local optimization: try to improve by adjusting sizes and positions
    # For small n, do a more thorough optimization
    if n <= 50:
        # Random restarts with local search
        for _ in range(200):
            # Start with best found so far or random
            if best_squares is None:
                continue
            current = [list(s) for s in best_squares]
            
            # Random perturbation
            for i in range(n):
                if current[i][3] > 0:
                    current[i][0] += random.uniform(-0.01, 0.01)
                    current[i][1] += random.uniform(-0.01, 0.01)
                    current[i][2] += random.uniform(-0.01, 0.01)
                    current[i][3] *= random.uniform(0.95, 1.05)
                    # Clamp
                    current[i][0] = max(0, min(1, current[i][0]))
                    current[i][1] = max(0, min(1, current[i][1]))
                    current[i][2] = current[i][2] % 1.0
                    current[i][3] = max(0, min(1, current[i][3]))
            
            # Check feasibility and compute score
            if is_feasible(current, n):
                score = sum(s[3] for s in current)
                if score > best_score:
                    best_score = score
                    best_squares = [tuple(s) for s in current]
    
    # Ensure we return exactly n squares
    result = best_squares[:n] if best_squares else []
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    
    return result[:n]


def is_feasible(squares, n):
    """Check if arrangement of n squares is feasible (no overlapping interiors)."""
    # First check bounds
    for cx, cy, angle, side in squares:
        if side <= 0:
            continue
        # Check if square fits in unit square
        # Corners of rotated square
        corners = get_corners(cx, cy, angle, side)
        for x, y in corners:
            if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
                return False
    
    # Check pairwise overlap
    # For small n, O(n^2) is fine
    for i in range(n):
        for j in range(i+1, n):
            if squares[i][3] <= 0 or squares[j][3] <= 0:
                continue
            if squares_overlap(squares[i], squares[j]):
                return False
    
    return True


def get_corners(cx, cy, angle, side):
    """Get corners of a square with center (cx,cy), rotation angle (fraction of turn), side length."""
    half = side / 2
    theta = angle * 2 * math.pi
    cos_t = math.cos(theta)
    sin_t = math.sin(theta)
    
    # Corners in local coordinates
    local = [(-half, -half), (half, -half), (half, half), (-half, half)]
    corners = []
    for lx, ly in local:
        x = cx + lx * cos_t - ly * sin_t
        y = cy + lx * sin_t + ly * cos_t
        corners.append((x, y))
    return corners


def squares_overlap(s1, s2):
    """Check if two squares have overlapping interiors using SAT."""
    corners1 = get_corners(s1[0], s1[1], s1[2], s1[3])
    corners2 = get_corners(s2[0], s2[1], s2[2], s2[3])
    
    # Separation axes: normals to edges of both squares
    axes = []
    for corners in [corners1, corners2]:
        for i in range(4):
            p1 = corners[i]
            p2 = corners[(i+1) % 4]
            edge = (p2[0] - p1[0], p2[1] - p1[1])
            normal = (-edge[1], edge[0])
            length = math.hypot(normal[0], normal[1])
            if length > 1e-12:
                axes.append((normal[0]/length, normal[1]/length))
    
    # Check if any axis separates the squares
    for axis in axes:
        proj1 = [p[0]*axis[0] + p[1]*axis[1] for p in corners1]
        proj2 = [p[0]*axis[0] + p[1]*axis[1] for p in corners2]
        min1, max1 = min(proj1), max(proj1)
        min2, max2 = min(proj2), max(proj2)
        if max1 <= min2 + 1e-9 or max2 <= min1 + 1e-9:
            return False
    
    return True


# For actual submission, we need a simpler but effective approach
# The above is too complex and may have issues. Let's use a cleaner version.

def solve(n):
    """Place n squares inside unit square to maximize sum of side lengths."""
    if n <= 0:
        return []
    
    # Start with best grid packing
    best_squares = None
    best_score = -1.0
    
    # Try different grid configurations
    for k in range(1, int(math.sqrt(n)) + 2):
        if k*k > n + k:
            break
        
        if n <= k*k:
            # Use k x k grid
            side = 1.0 / k
            squares = []
            for i in range(k):
                for j in range(k):
                    if len(squares) < n:
                        squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
            while len(squares) < n:
                squares.append((0.5, 0.5, 0.0, 0.0))
            score = sum(s[3] for s in squares)
            if score > best_score:
                best_score = score
                best_squares = squares[:]
        
        # Also try k x (k+1) grid variants
        if k*(k+1) >= n:
            side = 1.0 / (k+1)  # must fit in both dimensions
            # Actually for k x (k+1), we can use different aspect
            # Let's just try to fit n squares in a grid with aspect ratio 1
            # The best uniform grid is when rows*cols >= n and we maximize min(1/rows, 1/cols)
            # That's just the square grid
            
    # Try guillotine packing
    def guillotine_pack(n, x, y, w, h, squares):
        if n == 0:
            return
        if n == 1:
            side = min(w, h)
            squares.append((x + w/2, y + h/2, 0.0, side))
            return
        
        best_score = -1
        best_choice = None
        
        for n1 in range(1, n):
            n2 = n - n1
            # Try horizontal split
            r = math.sqrt(n1) / (math.sqrt(n1) + math.sqrt(n2))
            h1 = h * r
            h2 = h - h1
            s1 = min(w, h1)
            s2 = min(w, h2)
            score = n1 * s1 + n2 * s2
            if score > best_score:
                best_score = score
                best_choice = ('h', h1, n1, h2, n2)
            
            # Try vertical split
            w1 = w * r
            w2 = w - w1
            s1 = min(w1, h)
            s2 = min(w2, h)
            score = n1 * s1 + n2 * s2
            if score > best_score:
                best_score = score
                best_choice = ('v', w1, n1, w2, n2)
        
        if best_choice[0] == 'h':
            _, h1, n1, h2, n2 = best_choice
            guillotine_pack(n1, x, y, w, h1, squares)
            guillotine_pack(n2, x, y + h1, w, h2, squares)
        else:
            _, w1, n1, w2, n2 = best_choice
            guillotine_pack(n1, x, y, w1, h, squares)
            guillotine_pack(n2, x + w1, y, w2, h, squares)
    
    squares = []
    guillotine_pack(n, 0, 0, 1, 1, squares)
    score = sum(s[3] for s in squares)
    if score > best_score:
        best_score = score
        best_squares = squares[:]
    
    # For small n, try optimization
    if n <= 30:
        # Try to improve by allowing non-grid arrangements
        # Simple approach: randomly perturb and check
        import copy
        best = best_squares[:]
        
        for _ in range(100):
            current = [list(s) for s in best]
            # Perturb
            for i in range(n):
                if current[i][3] > 0:
                    current[i][0] += random.uniform(-0.02, 0.02)
                    current[i][1] += random.uniform(-0.02, 0.02)
                    current[i][2] = random.uniform(0, 1) if random.random() < 0.1 else current[i][2]
            
            # Clamp
            for i in range(n):
                current[i][0] = max(0.001, min(0.999, current[i][0]))
                current[i][1] = max(0.001, min(0.999, current[i][1]))
                current[i][2] = current[i][2] % 1.0
            
            # Check feasibility
            if is_feasible(current, n):
                score = sum(s[3] for s in current)
                if score > best_score:
                    best_score = score
                    best = [tuple(s) for s in current]
        
        best_squares = best
    
    result = best_squares[:n]
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    
    return result[:n]


def get_corners(cx, cy, angle, side):
    """Get corners of a square."""
    half = side / 2
    theta = angle * 2 * math.pi
    cos_t = math.cos(theta)
    sin_t = math.sin(theta)
    
    local = [(-half, -half), (half, -half), (half, half), (-half, half)]
    corners = []
    for lx, ly in local:
        x = cx + lx * cos_t - ly * sin_t
        y = cy + lx * sin_t + ly * cos_t
        corners.append((x, y))
    return corners


def is_feasible(squares, n):
    """Check if squares are feasible."""
    for cx, cy, angle, side in squares:
        if side <= 1e-10:
            continue
        corners = get_corners(cx, cy, angle, side)
        for x, y in corners:
            if x < -1e-7 or x > 1 + 1e-7 or y < -1e-7 or y > 1 + 1e-7:
                return False
    
    for i in range(n):
        for j in range(i+1, n):
            if squares[i][3] <= 1e-10 or squares[j][3] <= 1e-10:
                continue
            if squares_overlap(squares[i], squares[j]):
                return False
    return True


def squares_overlap(s1, s2):
    """SAT overlap check."""
    corners1 = get_corners(s1[0], s1[1], s1[2], s1[3])
    corners2 = get_corners(s2[0], s2[1], s2[2], s2[3])
    
    axes = []
    for corners in [corners1, corners2]:
        for i in range(4):
            p1 = corners[i]
            p2 = corners[(i+1) % 4]
            edge = (p2[0] - p1[0], p2[1] - p1[1])
            normal = (-edge[1], edge[0])
            length = math.hypot(normal[0], normal[1])
            if length > 1e-12:
                axes.append((normal[0]/length, normal[1]/length))
    
    for axis in axes:
        proj1 = [p[0]*axis[0] + p[1]*axis[1] for p in corners1]
        proj2 = [p[0]*axis[0] + p[1]*axis[1] for p in corners2]
        min1, max1 = min(proj1), max(proj1)
        min2, max2 = min(proj2), max(proj2)
        if max1 <= min2 + 1e-8 or max2 <= min1 + 1e-8:
            return False
    return True


if __name__ == "__main__":
    for n in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20]:
        result = solve(n)
        score = sum(s[3] for s in result)
        print(f"n={n}: score={score:.6f}, squares={len(result)}")
