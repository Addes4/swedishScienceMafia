import math
import random
from scipy.optimize import minimize

def solve(n):
    # Start with a baseline grid packing
    k = math.isqrt(n)
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    squares = squares[:n]
    # For small n, try to improve via simple optimization
    if n <= 25:
        # Use a simple local search: perturb sizes and positions, accept if sum increases and no overlap
        best = [list(s) for s in squares]
        best_sum = sum(s[3] for s in best)
        for _ in range(5000):
            i = random.randrange(n)
            # Perturb size and position
            s = best[i][:]
            s[0] = min(max(0.0, s[0] + random.uniform(-0.05, 0.05)), 1.0)
            s[1] = min(max(0.0, s[1] + random.uniform(-0.05, 0.05)), 1.0)
            s[3] = max(0.0, s[3] + random.uniform(-0.05, 0.05))
            # Check if inside unit square (center must be at least side/2 from edges if no rotation)
            if s[3] > 0:
                if s[0] - s[3]/2 < -1e-9 or s[0] + s[3]/2 > 1+1e-9 or s[1] - s[3]/2 < -1e-9 or s[1] + s[3]/2 > 1+1e-9:
                    continue
            # Check overlap with others (axis-aligned rectangles)
            ok = True
            for j in range(n):
                if i == j: continue
                t = best[j]
                if t[3] <= 0: continue
                # bounding boxes
                ax1, ax2 = s[0] - s[3]/2, s[0] + s[3]/2
                ay1, ay2 = s[1] - s[3]/2, s[1] + s[3]/2
                bx1, bx2 = t[0] - t[3]/2, t[0] + t[3]/2
                by1, by2 = t[1] - t[3]/2, t[1] + t[3]/2
                if ax1 < bx2 - 1e-9 and bx1 < ax2 - 1e-9 and ay1 < by2 - 1e-9 and by1 < ay2 - 1e-9:
                    ok = False
                    break
            if ok:
                old_sum = sum(best[j][3] for j in range(n))
                new_sum = old_sum - best[i][3] + s[3]
                if new_sum > best_sum:
                    best[i] = s
                    best_sum = new_sum
        return [tuple(s) for s in best]
    else:
        # For larger n, use a greedy packing: sort by size, place largest first in grid-like fashion
        # Simple: use k x k grid for k = floor(sqrt(n)), then distribute remaining squares as small
        k = math.isqrt(n)
        side = 1.0 / k
        sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
        # For remaining squares, place them with tiny size near center
        for _ in range(n - len(sq)):
            sq.append((0.5, 0.5, 0.0, 0.0))
        return sq[:n]
