import math
import random

# We use a simple but effective approach: place n squares greedily with
# different target sizes, then locally optimize positions/rotations.
# The unit square is discretized implicitly by rejecting placements that
# overlap existing squares (using separating axis theorem for rotated squares).


def _corners(cx, cy, a, s):
    """Return the four corners of a square with center (cx,cy), angle a (fraction of turn), side s."""
    t = a * 2 * math.pi
    c = math.cos(t)
    si = math.sin(t)
    h = s * 0.5
    # local corners (+-h, +-h) rotated
    pts = []
    for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
        x = cx + dx * c - dy * si
        y = cy + dx * si + dy * c
        pts.append((x, y))
    return pts


def _overlap(sq1, sq2):
    """Check if two squares (cx,cy,a,s) overlap in interiors using SAT."""
    if sq1[3] <= 0 or sq2[3] <= 0:
        return False
    p1 = _corners(*sq1)
    p2 = _corners(*sq2)
    # separation axes: for each edge of both squares
    axes = []
    for i in range(4):
        x1, y1 = p1[i]
        x2, y2 = p1[(i + 1) % 4]
        axes.append((y2 - y1, -(x2 - x1)))
        x1, y1 = p2[i]
        x2, y2 = p2[(i + 1) % 4]
        axes.append((y2 - y1, -(x2 - x1)))
    for ax, ay in axes:
        n1 = math.hypot(ax, ay)
        if n1 < 1e-12:
            continue
        ax /= n1
        ay /= n1
        min1 = min(p[0] * ax + p[1] * ay for p in p1)
        max1 = max(p[0] * ax + p[1] * ay for p in p1)
        min2 = min(p[0] * ax + p[1] * ay for p in p2)
        max2 = max(p[0] * ax + p[1] * ay for p in p2)
        if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
            return False
    return True


def _inside(cx, cy, a, s):
    """Check square entirely inside unit square."""
    if s <= 0:
        return 0 <= cx <= 1 and 0 <= cy <= 1
    pts = _corners(cx, cy, a, s)
    for x, y in pts:
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def _try_place(existing, s, rng, tries=300):
    """Try to place a square of side s avoiding existing. Return the square or None."""
    if s <= 0:
        # place a point anywhere not inside another (interior irrelevant for zero area)
        return (0.5, 0.5, 0.0, 0.0)
    for _ in range(tries):
        a = rng.choice([0.0, 0.25, rng.random(), rng.random() * 0.25])
        # random position, biased toward center for large squares
        cx = rng.random()
        cy = rng.random()
        # try to fit: if s is large relative to 1, clustering near center helps
        if not _inside(cx, cy, a, s):
            continue
        sq = (cx, cy, a, s)
        ok = True
        for e in existing:
            if _overlap(sq, e):
                ok = False
                break
        if ok:
            return sq
    return None


def _greedy(n, sched, rng, time_budget_iters=4):
    """Greedy: for each target size in sched, try to place. Returns list of squares (or zero squares)."""
    placed = []
    for s in sched:
        if len(placed) >= n:
            break
        sq = _try_place(placed, s, rng, tries=400)
        if sq is not None:
            placed.append(sq)
    return placed


def _local_opt(squares, rng, iters=2000):
    """Randomly perturb one square's placement; accept if sum of sides doesn't decrease
    and overlaps/outsideness are avoided. We only move zero-size squares to fill."""
    n = len(squares)
    # For zero-size squares, we can always keep them; but to improve, we try replacing
    # a zero square with a small positive one or growing an existing one.
    best = list(squares)
    best_sum = sum(s[3] for s in best)
    for _ in range(iters):
        cand = list(best)
        i = rng.randrange(n)
        old = cand[i]
        # grow or shrink or move
        action = rng.random()
        if action < 0.5 and old[3] > 0:
            new_s = min(old[3] * (1 + rng.random() * 0.05), 1.0)
            if rng.random() < 0.3:
                new_s = old[3]
            a = old[2] + (rng.random() - 0.5) * 0.05
            a = a % 1.0
            cx = old[0] + (rng.random() - 0.5) * 0.02
            cy = old[1] + (rng.random() - 0.5) * 0.02
            cx = min(max(cx, 0.0), 1.0)
            cy = min(max(cy, 0.0), 1.0)
            cand[i] = (cx, cy, a, new_s)
        elif old[3] <= 0:
            # try to place a small square
            new_s = rng.random() * 0.05
            a = rng.random()
            cx = rng.random()
            cy = rng.random()
            cand[i] = (cx, cy, a, new_s)
        else:
            a = old[2] + (rng.random() - 0.5) * 0.1
            cx = old[0] + (rng.random() - 0.5) * 0.05
            cy = old[1] + (rng.random() - 0.5) * 0.05
            cx = min(max(cx, 0.0), 1.0)
            cy = min(max(cy, 0.0), 1.0)
            cand[i] = (cx, cy, a % 1.0, old[3])
        # check feasibility
        if not _inside(*cand[i]):
            continue
        ok = True
        for j in range(n):
            if i == j:
                continue
            if _overlap(cand[i], cand[j]):
                ok = False
                break
        if not ok:
            continue
        new_sum = sum(s[3] for s in cand)
        if new_sum >= best_sum - 1e-12:
            best = cand
            best_sum = new_sum
    return best


def solve(n):
    """Return n squares inside the unit square, disjoint interiors, maximize sum of sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    rng = random.Random(12345)

    # Build a schedule of target side lengths.
    # Start with a grid estimate: k x k grid gives sum = 1 for n=k^2, but we want more.
    # A good schedule: place several large squares then fill with decreasing sizes.
    # Try multiple schedules and pick the best.

    schedules = []

    # Schedule 1: decreasing geometric
    k = math.isqrt(n)
    base = 1.0 / k if k > 0 else 1.0
    sched = []
    for i in range(n):
        sched.append(base * (0.9 ** (i % (k * k) if k > 0 else 1)))
    schedules.append(sched)

    # Schedule 2: all slightly different, from largest to smallest
    sched2 = []
    # A simple heuristic: try sizes 1/sqrt(n) * factor, but allow variation.
    # Instead, try a few candidate largest sizes.
    for factor in [1.0, 0.9, 0.8, 0.7, 0.6]:
        s = base * factor
        for i in range(n):
            sched2.append(s * (0.95 ** i))
        schedules.append(sched2)

    # Schedule 3: descending from 1/(ceil(sqrt(n))) to small
    trials = []
    for _ in range(6):
        sched3 = []
        for i in range(n):
            # exponentially decreasing from around base
            sched3.append(base * math.exp(-rng.random() * i * 0.1))
        schedules.append(sched3)

    best_squares = None
    best_sum = -1.0

    for sched in schedules:
        # Try greedy with this schedule, multiple random restarts
        for trial in range(3):
            rng2 = random.Random(rng.randrange(10**9))
            squares = _greedy(n, sched, rng2)
            if len(squares) < n:
                # pad with zero-size squares
                while len(squares) < n:
                    squares.append((0.5, 0.5, 0.0, 0.0))
            # local optimization
            squares = _local_opt(squares, rng2, iters=800)
            s = sum(sq[3] for sq in squares)
            if s > best_sum:
                best_sum = s
                best_squares = squares

    # Ensure exactly n squares
    if best_squares is None:
        best_squares = [(0.5, 0.5, 0.0, 0.0)] * n
    result = []
    for sq in best_squares[:n]:
        cx, cy, a, s = sq
        # clamp values to [0,1]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = a % 1.0
        s = min(max(s, 0.0), 1.0)
        result.append((cx, cy, a, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
