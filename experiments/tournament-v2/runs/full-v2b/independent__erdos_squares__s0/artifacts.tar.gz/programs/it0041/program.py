import math
import random


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Start from a near-optimal grid for perfect squares, then improve.
    k = max(1, int(math.sqrt(n)))
    while k * k > n:
        k -= 1
    side = 1.0 / k

    sq = []
    for i in range(k):
        for j in range(k):
            sq.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
            if len(sq) == n:
                break
        if len(sq) == n:
            break

    while len(sq) < n:
        sq.append([0.5, 0.5, 0.0, 0.0])

    # Simple local search: try small random perturbations that reduce total overlap
    # while preserving feasibility, or increase total side if feasible.
    def overlap_area(a, b):
        # Approximate overlap by bounding boxes after considering rotation via extents.
        ax, ay, aa, as_ = a
        bx, by, ba, bs = b
        # Use exact polygon clipping for a rotated square.
        def corners(x, y, ang, s):
            c = math.cos(2 * math.pi * ang)
            sn = math.sin(2 * math.pi * ang)
            h = s * 0.5
            pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
            return [(x + px * c - py * sn, y + px * sn + py * c) for px, py in pts]

        pa = corners(ax, ay, aa, as_)
        pb = corners(bx, by, ba, bs)
        # Sutherland-Hodgman polygon intersection area via shapely-free clipping.
        def clip(subject, clipper):
            out = subject
            for i in range(len(clipper)):
                a1 = clipper[i]
                a2 = clipper[(i + 1) % len(clipper)]
                inp = out
                out = []
                if not inp:
                    break
                for j in range(len(inp)):
                    p1 = inp[j]
                    p2 = inp[(j + 1) % len(inp)]
                    d1 = (a2[0] - a1[0]) * (p1[1] - a1[1]) - (a2[1] - a1[1]) * (p1[0] - a1[0])
                    d2 = (a2[0] - a1[0]) * (p2[1] - a1[1]) - (a2[1] - a1[1]) * (p2[0] - a1[0])
                    if d1 >= 0:
                        out.append(p1)
                    if (d1 >= 0) != (d2 >= 0):
                        t = d1 / (d1 - d2)
                        out.append((p1[0] + t * (p2[0] - p1[0]), p1[1] + t * (p2[1] - p1[1])))
            return out

        inter = clip(pa, pb)
        if len(inter) < 3:
            return 0.0
        area = 0.0
        for i in range(len(inter)):
            x1, y1 = inter[i]
            x2, y2 = inter[(i + 1) % len(inter)]
            area += x1 * y2 - x2 * y1
        return abs(area) * 0.5

    def penalty(arr):
        p = 0.0
        m = len(arr)
        for i in range(m):
            x, y, a, s = arr[i]
            if s < 0:
                p += 100.0 * (-s)
            # boundary violation
            c = math.cos(2 * math.pi * a)
            sn = math.sin(2 * math.pi * a)
            h = s * 0.5
            ext_x = abs(c) * h + abs(sn) * h
            ext_y = abs(sn) * h + abs(c) * h
            if x - ext_x < 0:
                p += 100.0 * (ext_x - x)
            if x + ext_x > 1:
                p += 100.0 * (x + ext_x - 1)
            if y - ext_y < 0:
                p += 100.0 * (ext_y - y)
            if y + ext_y > 1:
                p += 100.0 * (y + ext_y - 1)
            for j in range(i + 1, m):
                p += overlap_area(arr[i], arr[j])
        return p

    total = sum(s[3] for s in sq)
    best = [list(s) for s in sq]
    best_total = total
    best_pen = penalty(best)

    rng = random.Random(12345)
    temp = 0.02
    for step in range(5000):
        arr = [list(s) for s in best]
        i = rng.randrange(len(arr))
        choice = rng.random()
        if choice < 0.4:
            arr[i][3] *= 1.0 + rng.uniform(-0.08, 0.08)
        elif choice < 0.7:
            arr[i][0] += rng.uniform(-0.05, 0.05)
            arr[i][1] += rng.uniform(-0.05, 0.05)
        else:
            arr[i][2] += rng.uniform(-0.1, 0.1)
            arr[i][2] %= 1.0

        for s in arr:
            s[3] = max(0.0, min(1.0, s[3]))
            s[0] = max(0.0, min(1.0, s[0]))
            s[1] = max(0.0, min(1.0, s[1]))

        pen = penalty(arr)
        new_total = sum(s[3] for s in arr)
        if pen <= best_pen + 1e-9 or (pen < best_pen * 1.02 and rng.random() < 0.1):
            if new_total > best_total or pen < best_pen - 1e-9:
                best = arr
                best_total = new_total
                best_pen = pen
        temp *= 0.9995

    # Final greedy expansion: try to enlarge each square while feasible.
    for _ in range(10):
        improved = False
        for i in range(n):
            old = best[i][3]
            hi, lo = 1.0, old
            for _ in range(20):
                mid = (hi + lo) * 0.5
                best[i][3] = mid
                if penalty(best) < 1e-7:
                    lo = mid
                    improved = True
                else:
                    hi = mid
            best[i][3] = lo
        if not improved:
            break

    return [tuple(s) for s in best]
