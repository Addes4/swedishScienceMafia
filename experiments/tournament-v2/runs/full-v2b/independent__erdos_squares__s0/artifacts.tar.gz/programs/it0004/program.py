import math
import numpy as np


def _overlap_amount(s1, s2):
    """Return positive if the interiors of the two squares overlap."""
    x1, y1, a1, s1 = s1
    x2, y2, a2, s2 = s2
    if s1 <= 1e-15 or s2 <= 1e-15:
        return 0.0
    t1 = a1 * 2.0 * math.pi
    t2 = a2 * 2.0 * math.pi
    c1, s1a = math.cos(t1), math.sin(t1)
    c2, s2a = math.cos(t2), math.sin(t2)

    # separating axis theorem for two squares
    axes = [
        (c1, s1a), (-s1a, c1),
        (c2, s2a), (-s2a, c2),
    ]
    dx, dy = x2 - x1, y2 - y1

    for ax, ay in axes:
        # projection radius of square 1 on axis
        r1 = 0.5 * s1 * (abs(c1 * ax + s1a * ay) + abs(-s1a * ax + c1 * ay))
        r2 = 0.5 * s2 * (abs(c2 * ax + s2a * ay) + abs(-s2a * ax + c2 * ay))
        dist = abs(dx * ax + dy * ay)
        if dist >= r1 + r2 - 1e-12:
            return 0.0
    # if no axis separates, measure penetration roughly
    pen = 1e9
    for ax, ay in axes:
        r1 = 0.5 * s1 * (abs(c1 * ax + s1a * ay) + abs(-s1a * ax + c1 * ay))
        r2 = 0.5 * s2 * (abs(c2 * ax + s2a * ay) + abs(-s2a * ax + c2 * ay))
        dist = abs(dx * ax + dy * ay)
        pen = min(pen, r1 + r2 - dist)
    return max(0.0, pen)


def _valid(squares):
    for i in range(len(squares)):
        x, y, a, s = squares[i]
        if x < -1e-12 or x > 1 + 1e-12 or y < -1e-12 or y > 1 + 1e-12:
            return False
        if s < -1e-15:
            return False
        t = a * 2 * math.pi
        c, sn = math.cos(t), math.sin(t)
        ex = 0.5 * s * (abs(c) + abs(sn))
        ey = 0.5 * s * (abs(sn) + abs(c))
        if x - ex < -1e-10 or x + ex > 1 + 1e-10 or y - ey < -1e-10 or y + ey > 1 + 1e-10:
            return False
    for i in range(len(squares)):
        for j in range(i + 1, len(squares)):
            if _overlap_amount(squares[i], squares[j]) > 1e-11:
                return False
    return True


def _total(squares):
    return sum(s[3] for s in squares)


def _greedy_grid(n):
    """Try many grid-like arrangements, keep the best valid one."""
    best = None
    best_val = -1.0

    def consider(sq):
        nonlocal best, best_val
        if _valid(sq):
            v = _total(sq)
            if v > best_val:
                best_val = v
                best = [tuple(p) for p in sq]

    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        if cols <= 0:
            continue
        # uniform grid with rows x cols, last row may be partial
        side = min(1.0 / rows, 1.0 / cols)
        if side <= 0:
            continue
        sq = []
        for r in range(rows):
            for c in range(cols):
                if len(sq) >= n:
                    break
                x = (c + 0.5) * side + (1.0 - cols * side) * 0.5
                y = (r + 0.5) * side + (1.0 - rows * side) * 0.5
                sq.append((x, y, 0.0, side))
            if len(sq) >= n:
                break
        while len(sq) < n:
            sq.append((0.5, 0.5, 0.0, 0.0))
        # expand last row squares if possible
        consider(sq)

    return best, best_val


def _refine(squares, n, time_budget_iters=2000):
    """Coordinate descent on centers and sizes, keeping validity."""
    sq = [list(p) for p in squares]
    if not _valid(sq):
        return squares
    best = [tuple(p) for p in sq]
    best_val = _total(sq)

    rng = random.Random(12345)

    # Work mostly on the non-zero squares
    for it in range(time_budget_iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for idx in order:
            if sq[idx][3] <= 1e-12:
                continue
            # try moving this square a little
            for dx, dy in [(0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01),
                           (0.005, 0.005), (-0.005, 0.005),
                           (0.005, -0.005), (-0.005, -0.005)]:
                old = sq[idx][:]
                sq[idx][0] += dx
                sq[idx][1] += dy
                if _valid(sq):
                    v = _total(sq)
                    if v > best_val + 1e-12:
                        best_val = v
                        best = [tuple(p) for p in sq]
                        improved = True
                    else:
                        sq[idx] = old
                else:
                    sq[idx] = old

            # try growing this square
            for ds in [0.01, 0.005, 0.002, 0.001]:
                old = sq[idx][:]
                sq[idx][3] = min(1.0, sq[idx][3] + ds)
                if _valid(sq):
                    v = _total(sq)
                    if v > best_val + 1e-12:
                        best_val = v
                        best = [tuple(p) for p in sq]
                        improved = True
                    else:
                        sq[idx] = old
                else:
                    sq[idx] = old

            # try rotating a bit
            for da in [0.002, -0.002, 0.005, -0.005, 0.01, -0.01]:
                old = sq[idx][:]
                sq[idx][2] = (sq[idx][2] + da) % 1.0
                if _valid(sq):
                    v = _total(sq)
                    if v > best_val + 1e-12:
                        best_val = v
                        best = [tuple(p) for p in sq]
                        improved = True
                    else:
                        sq[idx] = old
                else:
                    sq[idx] = old

        if not improved:
            # small random perturbation to escape local optimum
            for _ in range(3):
                idx = rng.randrange(n)
                if sq[idx][3] <= 1e-12:
                    continue
                old = sq[idx][:]
                sq[idx][0] += rng.uniform(-0.01, 0.01)
                sq[idx][1] += rng.uniform(-0.01, 0.01)
                sq[idx][2] = (sq[idx][2] + rng.uniform(-0.02, 0.02)) % 1.0
                sq[idx][3] *= (1.0 + rng.uniform(-0.05, 0.05))
                if not _valid(sq):
                    sq[idx] = old

    return best


def _construct_rotated_greedy(n):
    """Greedy: place axis-aligned squares in a packing, use one rotated leftover."""
    best = None
    best_val = -1.0

    # Try sequences: place a grid of axis-aligned squares and a rotated big square
    for k in range(1, n + 1):
        # k axis-aligned squares in a row-ish structure and remaining rotated?
        # simpler: use k^2 grid and put rotated square in leftover
        m = int(math.isqrt(k))
        if m * m > k or (m + 1) * (m + 1) <= k:
            m = max(1, int(math.isqrt(k)))
        side = 1.0 / m
        sq = []
        for i in range(m):
            for j in range(m):
                if len(sq) >= k:
                    break
                sq.append( ((i + 0.5) * side, (j + 0.5) * side, 0.0, side) )
            if len(sq) >= k:
                break
        while len(sq) < k:
            sq.append((0.5, 0.5, 0.0, 0.0))
        # now try to add one rotated square in the remaining gap
        if k < n:
            # find a place for rotated square: try center at different locations
            for rot in [0.125, 0.25, 0.375]:
                for cx in [0.5]:
                    for cy in [0.5]:
                        for ss in [0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4]:
                            trial = sq + [(cx, cy, rot, ss)]
                            if _valid(trial):
                                while len(trial) < n:
                                    trial.append((0.5, 0.5, 0.0, 0.0))
                                v = _total(trial)
                                if v > best_val:
                                    best_val = v
                                    best = [tuple(p) for p in trial]
    return best, best_val


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    candidates = []

    b, v = _greedy_grid(n)
    if b is not None:
        candidates.append((v, b))

    b2, v2 = _construct_rotated_greedy(n)
    if b2 is not None:
        candidates.append((v2, b2))

    if not candidates:
        # fallback
        k = max(1, int(math.isqrt(n)))
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
        squares = squares[:n]
        while len(squares) < n:
            squares.append((0.5, 0.5, 0.0, 0.0))
        return squares[:n]

    candidates.sort(key=lambda t: -t[0])
    best_sq = candidates[0][1]

    # refine the best few candidates
    for _, cand in candidates[:3]:
        ref = _refine(cand, n, time_budget_iters=800)
        if _valid(ref) and _total(ref) > _total(best_sq):
            best_sq = ref

    # final safety check
    if not _valid(best_sq):
        k = max(1, int(math.isqrt(n)))
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
        squares = squares[:n]
        while len(squares) < n:
            squares.append((0.5, 0.5, 0.0, 0.0))
        return squares[:n]

    # ensure exactly n
    if len(best_sq) < n:
        best_sq = list(best_sq) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_sq))
    best_sq = best_sq[:n]

    return [tuple(p) for p in best_sq]


# allow importing random for refinement
import random
