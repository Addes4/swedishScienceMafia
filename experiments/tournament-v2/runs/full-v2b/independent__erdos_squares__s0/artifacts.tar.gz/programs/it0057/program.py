import math
import random
import numpy as np
from scipy.optimize import minimize

def _corners(cx, cy, ang, s):
    c = math.cos(ang * 2.0 * math.pi)
    sn = math.sin(ang * 2.0 * math.pi)
    h = s * 0.5
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        out.append((cx + x * c - y * sn, cy + x * sn + y * c))
    return out

def _axes(ang):
    t = ang * 2.0 * math.pi
    c = math.cos(t)
    sn = math.sin(t)
    # two orthogonal unit axes of the square
    return [(c, sn), (-sn, c)]

def _sat_gap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """Return max separation along any candidate axis; >0 means feasible gap."""
    axes = [(1.0, 0.0), (0.0, 1.0)]
    axes.extend(_axes(a1))
    axes.extend(_axes(a2))
    # projection half-widths
    best = -1e100
    for ax, ay in axes:
        # projections of centers
        p1 = cx1 * ax + cy1 * ay
        p2 = cx2 * ax + cy2 * ay
        # half width of rotated square along axis
        # |cos| and |sin| in local basis
        t1 = a1 * 2.0 * math.pi
        t2 = a2 * 2.0 * math.pi
        c1 = abs(math.cos(t1) * ax + math.sin(t1) * ay)
        d1 = abs(-math.sin(t1) * ax + math.cos(t1) * ay)
        w1 = s1 * 0.5 * (c1 + d1)
        c2 = abs(math.cos(t2) * ax + math.sin(t2) * ay)
        d2 = abs(-math.sin(t2) * ax + math.cos(t2) * ay)
        w2 = s2 * 0.5 * (c2 + d2)
        gap = abs(p1 - p2) - (w1 + w2)
        if gap > best:
            best = gap
    return best

def _packing_feasible(v, n):
    for i in range(n):
        cx, cy, a, s = v[4*i:4*i+4]
        if s < -1e-9 or cx < -1e-9 or cx > 1+1e-9 or cy < -1e-9 or cy > 1+1e-9:
            return False
    for i in range(n):
        cx1, cy1, a1, s1 = v[4*i:4*i+4]
        if s1 <= 1e-12:
            continue
        for j in range(i+1, n):
            cx2, cy2, a2, s2 = v[4*j:4*j+4]
            if s2 <= 1e-12:
                continue
            if _sat_gap(cx1, cy1, a1, s1, cx2, cy2, a2, s2) > -1e-7:
                return False
    return True

def _obj(v):
    n = len(v)//4
    return -sum(max(0.0, v[4*i+3]) for i in range(n))

def _constraints(v, n):
    cons = []
    for i in range(n):
        cx, cy, a, s = v[4*i:4*i+4]
        # bounds represented as inequalities >=0
        cons.append({'type': 'ineq', 'fun': lambda v, i=i: v[4*i]})
        cons.append({'type': 'ineq', 'fun': lambda v, i=i: 1.0 - v[4*i]})
        cons.append({'type': 'ineq', 'fun': lambda v, i=i: v[4*i+1]})
        cons.append({'type': 'ineq', 'fun': lambda v, i=i: 1.0 - v[4*i+1]})
        cons.append({'type': 'ineq', 'fun': lambda v, i=i: v[4*i+3]})
        # inscribed stay in square: rotated square fits iff half-diagonal * (|cos|+|sin|) <= distance constraints...
        # Enforce all corners inside [0,1]^2 via 4 corner coordinate constraints.
        cons.append({'type': 'ineq', 'fun': lambda v, i=i: 1.0 - max(_corners(v[4*i],v[4*i+1],v[4*i+2],v[4*i+3])[0][0], _corners(v[4*i],v[4*i+1],v[4*i+2],v[4*i+3])[2][0])})
        cons.append({'type': 'ineq', 'fun': lambda v, i=i: min(_corners(v[4*i],v[4*i+1],v[4*i+2],v[4*i+3])[0][0], _corners(v[4*i],v[4*i+1],v[4*i+2],v[4*i+3])[2][0])})
        cons.append({'type': 'ineq', 'fun': lambda v, i=i: 1.0 - max(_corners(v[4*i],v[4*i+1],v[4*i+2],v[4*i+3])[0][1], _corners(v[4*i],v[4*i+1],v[4*i+2],v[4*i+3])[2][1])})
        cons.append({'type': 'ineq', 'fun': lambda v, i=i: min(_corners(v[4*i],v[4*i+1],v[4*i+2],v[4*i+3])[0][1], _corners(v[4*i],v[4*i+1],v[4*i+2],v[4*i+3])[2][1])})
    for i in range(n):
        for j in range(i+1, n):
            def gap(v, i=i, j=j):
                cx1, cy1, a1, s1 = v[4*i:4*i+4]
                cx2, cy2, a2, s2 = v[4*j:4*j+4]
                return -_sat_gap(cx1, cy1, a1, s1, cx2, cy2, a2, s2)
            cons.append({'type': 'ineq', 'fun': gap})
    return cons

def _initial_grid(n):
    k = int(math.isqrt(n))
    while k*k < n:
        k += 1
    side = 1.0/k
    v = []
    cnt = 0
    for i in range(k):
        for j in range(k):
            if cnt >= n:
                break
            v.extend([ (i+0.5)*side, (j+0.5)*side, 0.0, side ])
            cnt += 1
        if cnt >= n:
            break
    while len(v) < 4*n:
        v.extend([0.5,0.5,0.0,0.0])
    return v

def _initial_guillotine(n):
    # recursively split unit square, assign one square per region
    rects = [(0.0,0.0,1.0)]
    while len(rects) < n:
        # split largest-area rectangle (roughly)
        rects.sort(key=lambda r: r[2]*r[2], reverse=True)
        x,y,s = rects.pop(0)
        frac = 0.55 + 0.1*random.random()
        a = s*frac
        b = s-a
        if random.random() < 0.5:
            rects.append((x,y,a)); rects.append((x+a,y,b))
        else:
            rects.append((x,y,a)); rects.append((x,y+a,b))
    v = []
    for x,y,s in rects[:n]:
        v.extend([x+s*0.5, y+s*0.5, 0.0, s])
    while len(v) < 4*n:
        v.extend([0.5,0.5,0.0,0.0])
    return v

def _initial_random(n):
    v = []
    for i in range(n):
        s = min(0.09, 0.35/math.sqrt(max(1,n)))
        cx = random.random()*(1-s)+s*0.5
        cy = random.random()*(1-s)+s*0.5
        a = random.random()
        v.extend([cx,cy,a,s])
    return v

def _improve(v, n, maxiter=1200):
    x0 = np.array(v, dtype=float)
    bounds = []
    for i in range(n):
        bounds.extend([(0.0,1.0),(0.0,1.0),(0.0,1.0),(0.0,1.0)])
    cons = _constraints(v, n)
    try:
        res = minimize(_obj, x0, method='SLSQP', bounds=bounds, constraints=cons,
                       options={'maxiter': maxiter, 'ftol':1e-12, 'disp':False})
        if res.success:
            return list(res.x)
    except Exception:
        pass
    try:
        res = minimize(_obj, x0, method='trust-constr', bounds=bounds,
                       constraints=cons, options={'maxiter': maxiter, 'disp':False, 'gtol':1e-10})
        return list(res.x)
    except Exception:
        return v

def solve(n):
    random.seed(12345 + n)
    if n == 0:
        return []
    best_v = None
    best_score = -1.0
    # candidate starts
    starts = []
    starts.append(_initial_grid(n))
    starts.append(_initial_guillotine(n))
    for _ in range(max(1, min(8, 80//n+2))):
        starts.append(_initial_random(n))
    for v in starts:
        vv = _improve(v, n, maxiter=900)
        score = -_obj(vv)
        if score > best_score and _packing_feasible(vv, n):
            best_score = score
            best_v = vv
    if best_v is None:
        best_v = _initial_grid(n)
    out = []
    for i in range(n):
        cx, cy, a, s = best_v[4*i:4*i+4]
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        a = a - math.floor(a)
        s = max(0.0, s)
        out.append((cx, cy, a, s))
    return out
