import math
import random
import numpy as np
from scipy.optimize import minimize


# ---------- geometry helpers ----------

def corners(cx, cy, a, s):
    """Return the 4 corners of a square (centre, angle as fraction of turn, side)."""
    t = 2.0 * math.pi * a
    c, sn = math.cos(t), math.sin(t)
    h = s * 0.5
    # local corners (x, y), rotated
    pts = []
    for lx, ly in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + c * lx - sn * ly, cy + sn * lx + c * ly))
    return pts


def _axis_proj(pts, ax, ay):
    d = [p[0] * ax + p[1] * ay for p in pts]
    return min(d), max(d)


def overlap(m, other):
    """SAT overlap test for two convex quads (lists of corners). Return penetration depth
    along the least-penetrating axis, or 0 if disjoint/touching."""
    axes = []
    for poly in (m, other):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            L = math.hypot(ex, ey)
            if L > 1e-15:
                axes.append((-ey / L, ex / L))
    best = float('inf')
    for ax, ay in axes:
        a0, a1 = _axis_proj(m, ax, ay)
        b0, b1 = _axis_proj(other, ax, ay)
        inter = min(a1, b1) - max(a0, b0)
        if inter <= 1e-12:
            return 0.0
        if inter < best:
            best = inter
    return best if best != float('inf') else 0.0


# ---------- scoring ----------

def total_side(params, n):
    return sum(params[i][3] for i in range(n))


# ---------- constraints for SLSQP ----------

def build_constraints(n):
    cons = []

    def _bounds(params):
        out = []
        for i in range(n):
            cx, cy, a, s = params[i]
            pts = corners(cx, cy, a, s)
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            out.append(min(xs))
            out.append(-max(xs) + 1.0)
            out.append(min(ys))
            out.append(-max(ys) + 1.0)
        return out

    cons.append({'type': 'ineq', 'fun': lambda p, n=n: _bounds(p)})

    def _nonoverlap(params):
        polys = [corners(*params[i]) for i in range(n)]
        out = []
        for i in range(n):
            for j in range(i + 1, n):
                out.append(overlap(polys[i], polys[j]) + 1e-9 if overlap(polys[i], polys[j]) > 0 else 0.0)
        # SLSQP wants >= 0; disjointness is overlap == 0, so we give positive
        # only when overlapping. Negative would mean overlap -> constraint < 0.
        return out

    def _nonoverlap2(params):
        polys = [corners(*params[i]) for i in range(n)]
        out = []
        for i in range(n):
            for j in range(i + 1, n):
                ov = overlap(polys[i], polys[j])
                out.append(-ov)
        return out

    cons.append({'type': 'ineq', 'fun': lambda p, n=n: _nonoverlap2(p)})

    return cons


def pack_slsqp(x0, n, maxiter=200, ftol=1e-9):
    cons = build_constraints(n)

    def obj(x):
        return -sum(x[4 * i + 3] for i in range(n))

    bounds = [(0.0, 1.0)] * (4 * n)

    try:
        res = minimize(obj, x0, method='SLSQP', bounds=bounds,
                       constraints=cons, options={'maxiter': maxiter, 'ftol': ftol,
                                                  'disp': False})
    except Exception:
        return None, -1e18
    if res is None or not np.all(np.isfinite(res.x)):
        return None, -1e18
    # check validity
    xr = res.x.copy()
    # enforce bounds
    xr = np.clip(xr, 0.0, 1.0)
    polys = []
    ok = True
    for i in range(n):
        cx, cy, a, s = xr[4 * i:4 * i + 4]
        pts = corners(cx, cy, a, s)
        for p in pts:
            if p[0] < -1e-6 or p[0] > 1 + 1e-6 or p[1] < -1e-6 or p[1] > 1 + 1e-6:
                # nudge?
                pass
        polys.append(pts)
    for i in range(n):
        for j in range(i + 1, n):
            if overlap(polys[i], polys[j]) > 1e-7:
                ok = False
                break
        if not ok:
            break
    score = sum(xr[4 * i + 3] for i in range(n))
    return xr, score if ok else -1e18


# ---------- initial layouts ----------

def grid_layout(n, k, side=None, rotated=False):
    if side is None:
        side = 1.0 / k
    squares = []
    cells = [(i, j) for i in range(k) for j in range(k)]
    random.shuffle(cells)
    for idx in range(n):
        if idx < len(cells):
            i, j = cells[idx]
            a = 0.0
            if rotated and (i + j) % 2 == 1:
                a = 0.25
            s = side
            cx = (i + 0.5) * (1.0 / k)
            cy = (j + 0.5) * (1.0 / k)
            maxs = side
            # shrink if rotated would overflow (shouldn't if using 1/k)
            squares.append([cx, cy, a, maxs])
        else:
            squares.append([0.5, 0.5, 0.0, 0.0])
    return squares


def guillotine_layout(n, seed=0):
    """Randomized guillotine / slicing layout, all axis-aligned squares."""
    rng = random.Random(seed)
    rects = [(0.0, 0.0, 1.0, 1.0)]
    # grow rectangles by repeated splits
    target = n
    while len(rects) < target:
        # pick largest-area rect
        rects.sort(key=lambda r: r[2] * r[3], reverse=True)
        # pick among largest 3
        idx = rng.randint(0, min(2, len(rects) - 1))
        x, y, w, h = rects.pop(idx)
        if rng.random() < 0.5:
            # vertical split
            t = rng.uniform(0.25, 0.75)
            rects.append((x, y, w * t, h))
            rects.append((x + w * t, y, w * (1 - t), h))
        else:
            t = rng.uniform(0.25, 0.75)
            rects.append((x, y, w, h * t))
            rects.append((x, y + h * t, w, h * (1 - t)))
    rects = rects[:n]
    squares = []
    for x, y, w, h in rects:
        s = min(w, h)
        cx = x + w / 2
        cy = y + h / 2
        squares.append([cx, cy, 0.0, s])
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    return squares


def random_layout(n, seed=0):
    rng = random.Random(seed)
    squares = []
    for i in range(n):
        cx = rng.uniform(0.05, 0.95)
        cy = rng.uniform(0.05, 0.95)
        a = rng.choice([0.0, 0.25, 0.125, 0.375])
        s = rng.uniform(0.0, 0.3)
        squares.append([cx, cy, a, s])
    return squares


def optimize_from(squares, n, maxiter=250):
    x0 = np.array([v for sq in squares for v in sq], dtype=float)
    xr, sc = pack_slsqp(x0, n, maxiter=maxiter)
    return xr, sc


# ---------- main solver ----------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_score = -1.0

    # ---------- seed generation ----------
    seeds = []

    k = math.isqrt(n)
    if k >= 1:
        seeds.append(grid_layout(n, k))
        if k * k < n:
            seeds.append(grid_layout(n, k + 1))

    # a few guillotine layouts
    for s in range(min(6, n + 2)):
        seeds.append(guillotine_layout(n, seed=s))

    # random layouts
    for s in range(min(4, n + 2)):
        seeds.append(random_layout(n, seed=100 + s))

    # rotated grid variant
    if k >= 1:
        sr = grid_layout(n, k, rotated=True)
        # shrink rotated ones a bit to be safe
        for sq in sr:
            if sq[2] != 0.0:
                sq[3] *= 0.99
        seeds.append(sr)

    # ---------- improvement ----------

    # First, quick greedy: try every seed through SLSQP with modest iterations.
    for sq in seeds:
        xr, sc = optimize_from(sq, n, maxiter=120)
        if sc > best_score:
            best_score = sc
            best = xr

    # Then refine the best a few times with more iterations / restarts.
    if best is not None:
        for _ in range(3):
            xr, sc = optimize_from(best.reshape(n, 4).tolist(), n, maxiter=300)
            if sc > best_score:
                best_score = sc
                best = xr

    if best is None:
        # fallback
        return [(0.5, 0.5, 0.0, 0.0)] * n

    result = []
    for i in range(n):
        cx, cy, a, s = best[4 * i:4 * i + 4]
        cx = float(min(1.0, max(0.0, cx)))
        cy = float(min(1.0, max(0.0, cy)))
        a = float(a % 1.0)
        s = float(max(0.0, s))
        result.append((cx, cy, a, s))

    # Final safety clamp: shrink overlapping squares iteratively
    result = repair(result, n)
    return result


def repair(result, n):
    """If any overlap remains, aggressively shrink overlapping squares."""
    for _ in range(60):
        polys = [corners(*result[i]) for i in range(n)]
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                ov = overlap(polys[i], polys[j])
                if ov > 1e-7:
                    # shrink both by half the overlap
                    ci = result[i]
                    cj = result[j]
                    si = max(0.0, ci[3] - ov * 0.5 - 1e-9)
                    sj = max(0.0, cj[3] - ov * 0.5 - 1e-9)
                    result[i] = (ci[0], ci[1], ci[2], si)
                    result[j] = (cj[0], cj[1], cj[2], sj)
                    changed = True
        if not changed:
            break
        # also clamp to bounds
        for i in range(n):
            cx, cy, a, s = result[i]
            pts = corners(cx, cy, a, s)
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            dx = 0.0
            if min(xs) < 0:
                dx = -min(xs)
            elif max(xs) > 1:
                dx = 1 - max(xs)
            dy = 0.0
            if min(ys) < 0:
                dy = -min(ys)
            elif max(ys) > 1:
                dy = 1 - max(ys)
            result[i] = (cx + dx, cy + dy, a, s)
    return result


if __name__ == "__main__":
    for n in range(1, 15):
        r = solve(n)
        print(n, sum(s for _, _, _, s in r))
