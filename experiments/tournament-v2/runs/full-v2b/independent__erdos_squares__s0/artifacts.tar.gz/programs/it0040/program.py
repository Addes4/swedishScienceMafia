import math
import random
import numpy as np
from scipy.optimize import minimize

def solve(n):
    # For small n, use exact/known-ish good layouts via optimization.
    # For general n, build a binary space partition (guillotine) and optimize
    # the split positions and orientations.

    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Represent a guillotine partition tree:
    # Each node is either a leaf (contains exactly one square) or a split.
    # Layout: split a rectangle (axis-aligned initially) into two rectangles.
    # Then recursively split.
    # The square in a leaf is the largest axis-aligned square fitting in that rectangle.
    # We optimize split fractions to maximize sum of min(w,h) over leaves.
    #
    # This is a simplification; we then optionally apply a local adjustment
    # (rotating/scaling) to handle cases where non-guillotine or rotated squares help.

    # Build a random binary tree with n leaves.
    # Then optimize split fractions using coordinate descent / random search.

    best = None
    best_val = -1.0

    # Try several random tree structures and optimize each.
    # Use deterministic seed for reproducibility.
    rng = random.Random(12345 + n)

    def build_tree(num_leaves):
        # returns nested tuples: ('leaf',) or ('split', orient, left, right)
        if num_leaves == 1:
            return ('leaf',)
        # split roughly in half
        left_n = rng.randint(1, num_leaves - 1)
        right_n = num_leaves - left_n
        orient = rng.choice(['h', 'v'])
        return ('split', orient, build_tree(left_n), build_tree(right_n))

    def eval_tree(tree, params, rect):
        # rect = (x0, y0, w, h)
        x0, y0, w, h = rect
        if tree[0] == 'leaf':
            s = min(w, h)
            return s, [(x0 + w/2, y0 + h/2, 0.0, s)]
        _, orient, left, right = tree
        # param is fraction in [0,1] for this split
        p = params[0]
        rest = params[1:]
        if orient == 'h':
            # split horizontally (top/bottom)
            h1 = h * p
            h2 = h * (1 - p)
            r1 = (x0, y0, w, h1)
            r2 = (x0, y0 + h1, w, h2)
        else:
            w1 = w * p
            w2 = w * (1 - p)
            r1 = (x0, y0, w1, h)
            r2 = (x0 + w1, y0, w2, h)
        # need to know how many params each subtree uses: count splits
        def count_splits(t):
            if t[0] == 'leaf':
                return 0
            return 1 + count_splits(t[2]) + count_splits(t[3])
        nl = count_splits(left)
        s1, sq1 = eval_tree(left, rest[:nl], r1)
        s2, sq2 = eval_tree(right, rest[nl:], r2)
        return s1 + s2, sq1 + sq2

    def count_splits(t):
        if t[0] == 'leaf':
            return 0
        return 1 + count_splits(t[2]) + count_splits(t[3])

    # multiple restarts
    restarts = 8 if n <= 20 else 4
    for _ in range(restarts):
        tree = build_tree(n)
        ns = count_splits(tree)
        if ns == 0:
            # n==1 handled
            continue
        # initial params
        p0 = np.full(ns, 0.5)
        # objective: minimize negative sum
        def obj(p):
            p = np.clip(p, 0.01, 0.99)
            val, _ = eval_tree(tree, p, (0.0, 0.0, 1.0, 1.0))
            return -val
        # coordinate descent
        p = p0.copy()
        val = obj(p)
        step = 0.25
        for it in range(200):
            improved = False
            for i in range(ns):
                for d in (step, -step):
                    p2 = p.copy()
                    p2[i] = np.clip(p2[i] + d, 0.01, 0.99)
                    v2 = obj(p2)
                    if v2 < val - 1e-9:
                        val = v2
                        p = p2
                        improved = True
            if not improved:
                step *= 0.5
                if step < 1e-4:
                    break
        val, squares = eval_tree(tree, p, (0.0, 0.0, 1.0, 1.0))
        if val > best_val:
            best_val = val
            best = squares

    # Now, improve further: some squares may have side 0 or be suboptimal.
    # Also, try to pack exactly n with possibly rotated squares using a greedy
    # approach. But keep it simple: return best found.
    if best is None or len(best) < n:
        # fallback
        k = math.isqrt(n)
        side = 1.0 / k
        best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    return best[:n]
