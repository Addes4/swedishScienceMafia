import math
import random
import time

import numpy as np
from scipy.optimize import minimize


# ----------------------------- utilities -----------------------------

def _poly(cx, cy, ang, s):
    """Corner points of square centred at (cx,cy), angle fraction of turn, side s."""
    t = 2.0 * math.pi * ang
    ca, sa = math.cos(t), math.sin(t)
    h = 0.5 * s
    pts = []
    for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        x = cx + h * (sx * ca - sy * sa)
        y = cy + h * (sx * sa + sy * ca)
        pts.append((x, y))
    return pts


def _overlap_area(p1, p2):
    """Separating-axis based intersection area of two convex polygons."""
    def axes(poly):
        ax = []
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ex, ey = x2 - x1, y2 - y1
            ax.append((-ey, ex))
        return ax

    def project(poly, axis):
        vals = [x * axis[0] + y * axis[1] for x, y in poly]
        return min(vals), max(vals)

    polys = [p1, p2]
    axes_all = axes(p1) + axes(p2)
    best = None
    for axis in axes_all:
        a = math.hypot(*axis)
        if a < 1e-15:
            continue
        axis = (axis[0] / a, axis[1] / a)
        lo1, hi1 = project(p1, axis)
        lo2, hi2 = project(p2, axis)
        if hi1 <= lo2 or hi2 <= lo1:
            return 0.0
    # Sutherland-Hodgman clipping
    def inside(p, a, b):
        return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) >= -1e-14

    def intersect(p, a, b):
        d1x, d1y = b[0] - a[0], b[1] - a[1]
        d2x, d2y = p[1][0] - p[0][0], p[1][1] - p[0][1]
        den = d1x * d2y - d1y * d2x
        if abs(den) < 1e-18:
            return p[0]
        t = ((p[0][0] - a[0]) * d2y - (p[0][1] - a[1]) * d2x) / den
        return (a[0] + t * d1x, a[1] + t * d1y)

    output = list(p1)
    cp = p2
    for i in range(len(cp)):
        a = cp[i]
        b = cp[(i + 1) % len(cp)]
        inp = output
        output = []
        if not inp:
            break
        s = inp[-1]
        for e in inp:
            if inside(e, a, b):
                if not inside(s, a, b):
                    output.append(intersect((s, e), a, b))
                output.append(e)
            elif inside(s, a, b):
                output.append(intersect((s, e), a, b))
            s = e
    if len(output) < 3:
        return 0.0
    area = 0.0
    for i in range(len(output)):
        x1, y1 = output[i]
        x2, y2 = output[(i + 1) % len(output)]
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5


def _pair_overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    if s1 <= 1e-13 or s2 <= 1e-13:
        return 0.0
    return _overlap_area(_poly(cx1, cy1, a1, s1), _poly(cx2, cy2, a2, s2))


def _out_of_bounds(cx, cy, ang, s):
    if s <= 1e-13:
        return 0.0
    pts = _poly(cx, cy, ang, s)
    pen = 0.0
    for x, y in pts:
        if x < 0.0:
            pen += -x
        if x > 1.0:
            pen += x - 1.0
        if y < 0.0:
            pen += -y
        if y > 1.0:
            pen += y - 1.0
    return pen


# ----------------------------- initial configs -----------------------------

def _grid(n):
    k = math.isqrt(n)
    s = 1.0 / k
    res = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
    return res[:n]


def _nearly_grid(n):
    """Approximate grid with remaining squares distributed to increase total side."""
    k = math.isqrt(n)
    rem = n - k * k
    base = 1.0 / k
    res = []
    # place k columns, each height 1; distribute rem extra rows unevenly
    # build k x k cells, then split some cells so total count is n
    cells = [[base * i, base * (i + 1), base * j, base * (j + 1)] for i in range(k) for j in range(k)]
    # use rem extra cells by cutting some cells vertically/horizontally into two rectangles
    # choose largest cells to split
    extra = rem
    idx = 0
    while extra > 0 and idx < len(cells):
        x0, x1, y0, y1 = cells[idx]
        w = x1 - x0
        h = y1 - y0
        if w >= h:
            # split vertically
            cells[idx] = [x0, x0 + w * 0.5, y0, y1]
            cells.append([x0 + w * 0.5, x1, y0, y1])
        else:
            cells[idx] = [x0, x1, y0, y0 + h * 0.5]
            cells.append([x0, x1, y0 + h * 0.5, y1])
        extra -= 1
        idx += 1
        # keep sorted by area descending roughly
        cells.sort(key=lambda c: -(c[1] - c[0]) * (c[3] - c[2]))
    for x0, x1, y0, y1 in cells[:n]:
        cx, cy = 0.5 * (x0 + x1), 0.5 * (y0 + y1)
        s = min(x1 - x0, y1 - y0)
        res.append((cx, cy, 1e-12, s))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]


def _random_config(n, rng):
    res = []
    for _ in range(n):
        s = rng.uniform(0.0, 0.45)
        cx = rng.uniform(0.0, 1.0)
        cy = rng.uniform(0.0, 1.0)
        ang = rng.uniform(0.0, 1.0)
        res.append((cx, cy, ang, s))
    return res


def _staggered(n):
    """Start from grid-like rows with alternating offsets."""
    k = math.isqrt(n)
    s = 1.0 / (k + 0.15)
    res = []
    y = 0.0
    rows = 0
    while len(res) < n and rows < k + 1:
        cols = min(k + 1, n - len(res))
        xoff = 0.5 * s if (rows % 2 == 1) else 0.0
        for i in range(cols):
            cx = xoff + (i + 0.5) * s
            cy = y + 0.5 * s
            if 0 <= cx <= 1 and 0 <= cy <= 1:
                res.append((cx, cy, 0.0, s))
        y += s
        rows += 1
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]


# ----------------------------- objective -----------------------------

def _pack(init, n, time_limit):
    """Local optimisation of a configuration."""
    start = time.time()
    x0 = np.array(init, dtype=float).ravel()
    x0 = np.clip(x0, 0.0, 1.0)

    def unpack(x):
        return [(x[4 * i], x[4 * i + 1], x[4 * i + 2], x[4 * i + 3]) for i in range(n)]

    def obj(x):
        cfg = unpack(x)
        pen = 0.0
        # boundary penalty
        for cx, cy, ang, s in cfg:
            if s > 0.0:
                pen += 300.0 * _out_of_bounds(cx, cy, ang, s)
        # overlap penalty
        # O(n^2) but n is moderate; use active-set style with squares not tiny
        act = [k for k in range(n) if cfg[k][3] > 1e-12]
        for ii in range(len(act)):
            i = act[ii]
            cx1, cy1, a1, s1 = cfg[i]
            for jj in range(ii + 1, len(act)):
                j = act[jj]
                cx2, cy2, a2, s2 = cfg[j]
                # quick bounding circle check
                r1 = 0.70710678 * s1
                r2 = 0.70710678 * s2
                if (cx1 - cx2) ** 2 + (cy1 - cy2) ** 2 > (r1 + r2) ** 2:
                    continue
                ov = _pair_overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2)
                if ov > 1e-14:
                    pen += 800.0 * ov
        return -sum(c[3] for c in cfg) + pen

    # coordinate search / Nelder-Mead
    def cb(x):
        return obj(x)

    try:
        res = minimize(obj, x0, method="Nelder-Mead",
                       options={"maxiter": 4000, "xatol": 1e-7, "fatol": 1e-9,
                                "adaptive": True})
        best = res.x
        bestf = res.fun
    except Exception:
        best = x0
        bestf = obj(x0)

    # small local pattern search to fix degeneracies
    cur = best.copy()
    curf = bestf
    scale = 0.05
    for it in range(600):
        if time.time() - start > time_limit:
            break
        improved = False
        for i in range(len(cur)):
            for delta in (scale, -scale):
                cand = cur.copy()
                cand[i] = min(1.0, max(0.0, cand[i] + delta))
                f = obj(cand)
                if f < curf - 1e-12:
                    cur, curf = cand, f
                    improved = True
                    break
            if improved:
                break
        if not improved:
            scale *= 0.5
            if scale < 1e-7:
                break
    return unpack(np.clip(cur, 0.0, 1.0))


# ----------------------------- special small n -----------------------------

def _special(n):
    """Return a high-quality configuration for small n if known."""
    # For squares in unit square (Moser's worm-like packing) known optimal ratios
    # total sides: n=1 ->1. n=2 ->1. n=3 -> about 1.2071. n=4 -> 1 (grid). etc.
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two equal halves: side 0.5 each, total 1.0
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # Known: place two squares of side 1/2 stacked on left? total ~1.2071
        # optimal for n=3: three squares total side 6 - 2*sqrt(5)? Actually
        # best known: 2 squares side 0.5 plus one tilted square side ~0.2071? Let's use
        # construction: one square in corner of side 0.5, another 0.5 in opposite,
        # largest remaining rotated square in remaining area has side sqrt(2)-1 ~0.4142?
        # Safer: split unit square into 3 rectangles to fit squares, then outer
        # Here use two side .5 and one side .2071 in corner gap; total .2071+.5+.5=1.2071
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5), (0.8536, 0.1464, 0.0, 0.2071)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    return None


# ----------------------------- main -----------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    sp = _special(n)
    if sp is not None and len(sp) == n:
        return sp

    rng = random.Random(12345 + n)
    t_start = time.time()
    limit = 52.0

    candidates = []
    # structured starts
    try:
        candidates.append(_nearly_grid(n))
    except Exception:
        pass
    try:
        candidates.append(_staggered(n))
    except Exception:
        pass
    try:
        candidates.append(_grid(n))
    except Exception:
        pass

    # add random multi-starts
    for _ in range(max(3, min(12, 30 // max(1, n // 5)))):
        candidates.append(_random_config(n, rng))

    best_cfg = None
    best_val = -1.0

    for idx, init in enumerate(candidates):
        if time.time() - t_start > limit * 0.65:
            break
        cfg = _pack(init, n, max(2.0, (limit - (time.time() - t_start)) / max(1, len(candidates) - idx)))
        val = sum(c[3] for c in cfg)
        if val > best_val:
            best_val = val
            best_cfg = cfg

    # final polish with remaining time
    if best_cfg is not None and time.time() - t_start < limit:
        remaining = limit - (time.time() - t_start)
        cfg2 = _pack(best_cfg, n, remaining)
        val2 = sum(c[3] for c in cfg2)
        if val2 >= best_val:
            best_cfg = cfg2
            best_val = val2

    # fallback
    if best_cfg is None:
        best_cfg = _grid(n)

    # clean tiny numerical issues
    out = []
    for cx, cy, ang, s in best_cfg[:n]:
        cx = min(1.0, max(0.0, float(cx)))
        cy = min(1.0, max(0.0, float(cy)))
        ang = float(ang) % 1.0
        s = min(1.0, max(0.0, float(s)))
        out.append((cx, cy, ang, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
