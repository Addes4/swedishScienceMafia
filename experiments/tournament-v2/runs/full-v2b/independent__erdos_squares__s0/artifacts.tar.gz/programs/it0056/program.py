import math
import numpy as np
from scipy.optimize import minimize


def _poly(cx, cy, ang, s):
    """Return the four corners of a square as a 4x2 array."""
    a = ang * 2.0 * math.pi
    c, sn = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = np.array([[-h, -h], [h, -h], [h, h], [-h, h]])
    R = np.array([[c, -sn], [sn, c]])
    return pts @ R.T + np.array([cx, cy])


def _overlap(poly1, poly2, eps=1e-12):
    """Check whether two convex polygons overlap with positive area (SAT)."""
    for poly in (poly1, poly2):
        n = len(poly)
        for i in range(n):
            edge = poly[(i + 1) % n] - poly[i]
            axis = np.array([-edge[1], edge[0]])
            norm = np.linalg.norm(axis)
            if norm < 1e-15:
                continue
            axis /= norm
            p1 = poly1 @ axis
            p2 = poly2 @ axis
            if p1.max() < p2.min() - eps or p2.max() < p1.min() - eps:
                return False
    return True


def _inside_unit(poly, eps=1e-12):
    return (np.all(poly >= -eps) and np.all(poly <= 1.0 + eps))


def _feasible(sq, eps=1e-10):
    n = len(sq)
    polys = [_poly(cx, cy, ang, s) for cx, cy, ang, s in sq]
    for i in range(n):
        if not _inside_unit(polys[i], eps):
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap(polys[i], polys[j], eps):
                return False
    return True


def _grid_layout(n):
    """Place k^2 squares in a grid plus remainder, all axis-aligned."""
    if n == 0:
        return []
    k = math.isqrt(n)
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    rem = n - k * k
    # Put remainder as zero-size squares at centre
    out += [(0.5, 0.5, 0.0, 0.0)] * rem
    return out


def _corner_grid_layout(n):
    """Four corner squares + grid in remaining region, for n >= 4."""
    if n < 4:
        return _grid_layout(n)
    # Try a parameter t for the corner square side, grid fills middle band.
    # Place corner squares in [0,t]^2 etc. Remaining cross-shaped area
    # approximated by splitting into strips; we instead use a central grid.
    best = None
    best_sum = -1.0
    # Search a few structured layouts.
    for k in range(1, max(2, int(math.sqrt(n))) + 2):
        for use_corners in (True, False):
            for ang in (0.0, 0.25):
                for t in np.linspace(0.05, 0.5, 80):
                    side_c = t
                    if use_corners:
                        # corners occupy boxes of size 1/sqrt(2) along diagonal,
                        # but simple axis squares of side t in corners.
                        # after placing corners, remaining region excludes
                        # [0,t]x[0,t], [1-t,1]x[0,t], etc.
                        pass
                    # We'll instead just try general grid with corner boost:
                    # corners with side t, plus central grid of gx x gy cells
                    pass
    # Fallback: simple grid with 45-degree rotated corner boost heuristic
    # Try placing 4 corner squares of size s and a grid for n-4.
    best_sum = -1.0
    best = None
    m = n - 4
    if m >= 0:
        for s in np.linspace(0.0, 0.45, 120):
            # corners of size s at the four corners (axis-aligned)
            rem_min = s  # central region shrinks
            avail = 1.0 - 2.0 * s
            if avail <= 0:
                continue
            if m == 0:
                layout = [
                    (s / 2, s / 2, 0.0, s),
                    (1 - s / 2, s / 2, 0.0, s),
                    (s / 2, 1 - s / 2, 0.0, s),
                    (1 - s / 2, 1 - s / 2, 0.0, s),
                ]
                val = 4 * s
                if val > best_sum:
                    best_sum = val
                    best = layout
                continue
            # grid for m squares inside [s, 1-s]^2
            g = math.isqrt(m)
            if g == 0:
                continue
            gs = avail / g
            layout = [
                (s / 2, s / 2, 0.0, s),
                (1 - s / 2, s / 2, 0.0, s),
                (s / 2, 1 - s / 2, 0.0, s),
                (1 - s / 2, 1 - s / 2, 0.0, s),
            ]
            for i in range(g):
                for j in range(g):
                    if len(layout) >= n:
                        break
                    cx = s + (i + 0.5) * gs
                    cy = s + (j + 0.5) * gs
                    layout.append((cx, cy, 0.0, gs))
                if len(layout) >= n:
                    break
            while len(layout) < n:
                layout.append((0.5, 0.5, 0.0, 0.0))
            val = sum(x[3] for x in layout)
            if val > best_sum and _feasible(layout):
                best_sum = val
                best = layout
    if best is None:
        best = _grid_layout(n)
    return best


def _improve(sq, iterations=40, time_budget=2.0):
    """Small greedy inflation: try increasing each square's side slightly."""
    import time
    start = time.time()
    sq = [list(x) for x in sq]
    n = len(sq)
    for _ in range(iterations):
        if time.time() - start > time_budget:
            break
        improved = False
        for i in range(n):
            cx, cy, ang, s = sq[i]
            if s <= 1e-14:
                continue
            # try growing
            lo, hi = s, s * 1.5 + 0.05
            for _ in range(20):
                mid = (lo + hi) * 0.5
                trial = list(sq)
                trial[i] = [cx, cy, ang, mid]
                if _feasible([tuple(x) for x in trial]):
                    lo = mid
                else:
                    hi = mid
            if lo > s + 1e-12:
                sq[i] = [cx, cy, ang, lo]
                improved = True
        if not improved:
            break
    return [tuple(x) for x in sq]


def solve(n):
    """Return n squares maximising the sum of side lengths."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # Start from structured layout
    if n < 8:
        base = _grid_layout(n)
        # For small n, try rotated single large square plus grid.
        best = base
        best_sum = sum(x[3] for x in best)
        # Try one central square + others small in corners
        # Because of time, just do grid.
    else:
        base = _corner_grid_layout(n)
    # Improve
    try:
        improved = _improve(base, iterations=30, time_budget=3.0)
        if sum(x[3] for x in improved) > sum(x[3] for x in base) and _feasible(improved):
            return improved
    except Exception:
        pass
    return base
