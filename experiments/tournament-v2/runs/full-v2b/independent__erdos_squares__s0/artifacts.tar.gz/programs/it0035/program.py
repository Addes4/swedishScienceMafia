import math
import random

import numpy as np
from scipy.optimize import minimize


def _inside(cx, cy, a, s):
    ca = math.cos(2 * math.pi * a)
    sa = math.sin(2 * math.pi * a)
    h = s * 0.5
    # half-extent in x/y of the rotated square
    ex = abs(ca) * h + abs(sa) * h
    ey = abs(sa) * h + abs(ca) * h
    return cx - ex >= -1e-12 and cx + ex <= 1 + 1e-12 and cy - ey >= -1e-12 and cy + ey <= 1 + 1e-12


def _corners(cx, cy, a, s):
    ca = math.cos(2 * math.pi * a)
    sa = math.sin(2 * math.pi * a)
    h = s * 0.5
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        out.append((cx + ca * x - sa * y, cy + sa * x + ca * y))
    return out


def _overlap(p1, p2):
    # separating axis test for two convex polygons
    poly1 = p1
    poly2 = p2
    for poly in (poly1, poly2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            nx = y2 - y1
            ny = x1 - x2
            ln = math.hypot(nx, ny)
            if ln < 1e-12:
                continue
            nx /= ln
            ny /= ln
            min1 = min(x * nx + y * ny for x, y in poly1)
            max1 = max(x * nx + y * ny for x, y in poly1)
            min2 = min(x * nx + y * ny for x, y in poly2)
            max2 = max(x * nx + y * ny for x, y in poly2)
            if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
                return False
    return True


def _feasible(squares):
    n = len(squares)
    for i in range(n):
        cx, cy, a, s = squares[i]
        if s <= 1e-12:
            continue
        if not _inside(cx, cy, a, s):
            return False
        p1 = _corners(cx, cy, a, s)
        for j in range(i + 1, n):
            cx2, cy2, a2, s2 = squares[j]
            if s2 <= 1e-12:
                continue
            p2 = _corners(cx2, cy2, a2, s2)
            if _overlap(p1, p2):
                return False
    return True


def _grid(n):
    k = int(math.floor(math.sqrt(n)))
    while k * k > n:
        k -= 1
    side = 1.0 / k
    res = []
    for i in range(k):
        for j in range(k):
            res.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    while len(res) < n:
        res.append([0.5, 0.5, 0.0, 0.0])
    return res[:n]


def _pack_objective(vars_, fixed_squares, extra_idx):
    # vars_ describes one new square: cx, cy, a, s
    cx, cy, a, s = vars_[0], vars_[1], vars_[2], vars_[3]
    if s < 0:
        s = 0.0
    penalty = 0.0
    # inside unit square
    ex, ey = _half_extent(a, s)
    if cx - ex < -1e-9:
        penalty += (cx - ex) ** 2 * 1e6
    if cx + ex > 1 + 1e-9:
        penalty += (cx + ex - 1.0) ** 2 * 1e6
    if cy - ey < -1e-9:
        penalty += (cy - ey) ** 2 * 1e6
    if cy + ey > 1 + 1e-9:
        penalty += (cy + ey - 1.0) ** 2 * 1e6
    # no overlap with fixed squares
    newpoly = _corners(cx, cy, a, s)
    for f in fixed_squares:
        if f[3] <= 1e-12:
            continue
        if _overlap(newpoly, _corners(f[0], f[1], f[2], f[3])):
            penalty += 10.0
    return -s + penalty


def _half_extent(a, s):
    ca = math.cos(2 * math.pi * a)
    sa = math.sin(2 * math.pi * a)
    h = s * 0.5
    return abs(ca) * h + abs(sa) * h, abs(sa) * h + abs(ca) * h


def _try_insert(squares):
    best = None
    best_val = -1e18
    n = len(squares)
    # Try many random starts
    rng = random.Random(12345)
    for _ in range(60):
        cx = rng.random()
        cy = rng.random()
        a = rng.random()
        s = rng.uniform(0.01, 0.35)
        x0 = np.array([cx, cy, a, s])
        try:
            res = minimize(
                _pack_objective,
                x0,
                args=(squares, n),
                method="Nelder-Mead",
                options={"maxiter": 800, "xatol": 1e-8, "fatol": 1e-8},
            )
            val = -res.fun
            if val > best_val:
                best_val = val
                best = res.x
        except Exception:
            pass
    if best is None:
        return None
    cx, cy, a, s = best
    s = max(0.0, min(s, 1.0))
    if s < 1e-6:
        return None
    cand = list(squares) + [[cx, cy, a, s]]
    if _feasible(cand):
        return cand
    # small local repair
    for _ in range(200):
        cx = min(max(cx + random.uniform(-0.01, 0.01), 0.0), 1.0)
        cy = min(max(cy + random.uniform(-0.01, 0.01), 0.0), 1.0)
        a = (a + random.uniform(-0.01, 0.01)) % 1.0
        s = max(0.0, min(s + random.uniform(-0.01, 0.01), 1.0))
        cand = list(squares) + [[cx, cy, a, s]]
        if _feasible(cand):
            return cand
    return None


def solve(n):
    if n <= 0:
        return []
    squares = _grid(n)
    # Remove the smallest squares (zeros) and try to add a real square back
    iter_count = 0
    max_iter = 500
    while iter_count < max_iter:
        iter_count += 1
        # find index of smallest square
        idx = min(range(len(squares)), key=lambda i: squares[i][3])
        if squares[idx][3] > 1e-9 and len(squares) == n:
            # try to improve existing packing by removing one
            break
        rest = [squares[i] for i in range(len(squares)) if i != idx]
        new_pack = _try_insert(rest)
        if new_pack is not None and len(new_pack) == len(squares):
            old_sum = sum(s[3] for s in squares)
            new_sum = sum(s[3] for s in new_pack)
            if new_sum > old_sum + 1e-9:
                squares = new_pack
                continue
        break
    # Ensure exactly n squares
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    squares = squares[:n]
    # Final feasibility check
    if not _feasible(squares):
        squares = _grid(n)
    return [(float(s[0]), float(s[1]), float(s[2]), float(s[3])) for s in squares]
