import math
import random
import numpy as np
from scipy.optimize import minimize


def _corners(cx, cy, ang, s):
    """Return 4 corners of the square."""
    ca = math.cos(2 * math.pi * ang)
    sa = math.sin(2 * math.pi * ang)
    h = s * 0.5
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + ca * x - sa * y, cy + sa * x + ca * y) for x, y in pts]


def _overlap_area(sq1, sq2):
    """Check overlap between two squares using separating axis theorem.
    Return 0 if no overlap, else positive overlap measure (approx)."""
    c1 = _corners(*sq1)
    c2 = _corners(*sq2)
    # axes from both squares
    axes = []
    for pts in (c1, c2):
        for i in range(4):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 1e-12:
                axes.append((-ey / ln, ex / ln))
    min_overlap = float('inf')
    for ax, ay in axes:
        p1 = [x * ax + y * ay for x, y in c1]
        p2 = [x * ax + y * ay for x, y in c2]
        o = min(max(p1), max(p2)) - max(min(p1), min(p2))
        if o <= 0:
            return 0.0
        min_overlap = min(min_overlap, o)
    return max(0.0, min_overlap)


def _in_unit(sq):
    for x, y in _corners(*sq):
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def _clamp_square(sq):
    """Clamp a square so it fits in the unit square (if possible by translation only)."""
    cx, cy, ang, s = sq
    if s <= 0:
        return (0.5, 0.5, 0.0, 0.0)
    ca = math.cos(2 * math.pi * ang)
    sa = math.sin(2 * math.pi * ang)
    h = s * 0.5
    local = [(-h, -h), (h, -h), (h, h), (-h, h)]
    xs = [cx + ca * x - sa * y for x, y in local]
    ys = [cy + sa * x + ca * y for x, y in local]
    minx, maxx = min(xs), max(xs)
    miny, maxy = min(ys), max(ys)
    # try to translate inside
    dx = 0.0
    if minx < 0:
        dx = -minx
    elif maxx > 1:
        dx = 1 - maxx
    dy = 0.0
    if miny < 0:
        dy = -miny
    elif maxy > 1:
        dy = 1 - maxy
    return (cx + dx, cy + dy, ang, s)


def _score(squares):
    """Sum of side lengths minus huge penalty for overlaps/outside."""
    total = 0.0
    pen = 0.0
    n = len(squares)
    # bounds penalty
    for sq in squares:
        if not _in_unit(sq):
            # penalize
            c = _corners(*sq)
            for x, y in c:
                d = 0.0
                if x < 0: d += x * x
                if x > 1: d += (x - 1) ** 2
                if y < 0: d += y * y
                if y > 1: d += (y - 1) ** 2
                pen += d * 1e4
        total += sq[3]
    for i in range(n):
        if squares[i][3] <= 0:
            continue
        for j in range(i + 1, n):
            if squares[j][3] <= 0:
                continue
            ov = _overlap_area(squares[i], squares[j])
            if ov > 0:
                pen += ov * ov * 1e6
    return total - pen


def _grid_layout(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    # best grid possibly with some leftover placed in gaps? Just k x k.
    side = 1.0 / k
    sqs = []
    for i in range(k):
        for j in range(k):
            sqs.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # remaining: place tiny squares at centers of existing? No - zero size.
    while len(sqs) < n:
        sqs.append((0.5, 0.5, 0.0, 0.0))
    return sqs


def _row_layout(n):
    """Try horizontal rows of squares."""
    best = None
    best_score = -1
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        h = 1.0 / rows
        w = 1.0 / cols
        s = min(h, w)
        sqs = []
        cnt = 0
        for r in range(rows):
            for c in range(cols):
                if cnt >= n:
                    break
                sqs.append(((c + 0.5) * w, (r + 0.5) * h, 0.0, s))
                cnt += 1
            if cnt >= n:
                break
        while len(sqs) < n:
            sqs.append((0.5, 0.5, 0.0, 0.0))
        sc = sum(sq[3] for sq in sqs)
        if sc > best_score:
            best_score = sc
            best = sqs
    return best


def _rotated_row_layout(n):
    """Place squares rotated 45 degrees in a grid pattern."""
    best = None
    best_score = -1
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        h = 1.0 / rows
        w = 1.0 / cols
        # rotated 45 deg: bounding box side = s * sqrt(2)
        s = min(h, w) / math.sqrt(2)
        sqs = []
        cnt = 0
        for r in range(rows):
            for c in range(cols):
                if cnt >= n:
                    break
                sqs.append(((c + 0.5) * w, (r + 0.5) * h, 0.125, s))
                cnt += 1
            if cnt >= n:
                break
        while len(sqs) < n:
            sqs.append((0.5, 0.5, 0.0, 0.0))
        sc = sum(sq[3] for sq in sqs)
        if sc > best_score:
            best_score = sc
            best = sqs
    return best


def _mixed_layout(n):
    """Try to fit squares in rows with alternating rotations for better packing."""
    best = None
    best_score = -1
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        h = 1.0 / rows
        w = 1.0 / cols
        # alternate orientation
        sqs = []
        cnt = 0
        for r in range(rows):
            for c in range(cols):
                if cnt >= n:
                    break
                # alternate angles
                ang = 0.0 if (r + c) % 2 == 0 else 0.125
                if ang == 0.0:
                    s = min(h, w)
                else:
                    s = min(h, w) / math.sqrt(2) if min(h, w) * math.sqrt(2) > min(h, w) else min(h, w) / math.sqrt(2)
                    # actually rotated square needs bounding box sqrt(2)*s <= min(h,w), so s = min(h,w)/sqrt(2)
                    s = min(h, w) / math.sqrt(2)
                sqs.append(((c + 0.5) * w, (r + 0.5) * h, ang, s))
                cnt += 1
            if cnt >= n:
                break
        while len(sqs) < n:
            sqs.append((0.5, 0.5, 0.0, 0.0))
        sc = sum(sq[3] for sq in sqs)
        if sc > best_score:
            best_score = sc
            best = sqs
    return best


def _local_search(squares, iterations=2000, seed=None):
    """Stochastic local search with shrinking perturbation."""
    if seed is not None:
        random.seed(seed)
    n = len(squares)
    if n == 0:
        return squares
    current = [list(sq) for sq in squares]
    cur_score = _score(current)
    best = [list(sq) for sq in current]
    best_score = cur_score

    for it in range(iterations):
        # copy and perturb
        cand = [list(sq) for sq in current]
        # perturb one or more squares
        k = 1 if random.random() < 0.7 else 2
        for _ in range(k):
            idx = random.randint(0, n - 1)
            # choose perturbation type
            r = random.random()
            temp = max(0.001, 0.05 * (1 - it / iterations))
            if r < 0.5:
                # move center
                cand[idx][0] = max(0.0, min(1.0, cand[idx][0] + random.gauss(0, temp)))
                cand[idx][1] = max(0.0, min(1.0, cand[idx][1] + random.gauss(0, temp)))
            elif r < 0.8:
                # change angle
                cand[idx][2] = (cand[idx][2] + random.gauss(0, 0.05 * temp)) % 1.0
            else:
                # change size
                cand[idx][3] = max(0.0, min(1.0, cand[idx][3] + random.gauss(0, temp)))
        # clamp
        for i in range(n):
            cand[i] = list(_clamp_square(tuple(cand[i])))
        sc = _score(cand)
        if sc > cur_score or random.random() < math.exp((sc - cur_score) / max(1e-6, 0.01 * (1 - it / iterations))):
            current = cand
            cur_score = sc
            if sc > best_score:
                best_score = sc
                best = [list(sq) for sq in cand]

    # also try gradient-free refinement using scipy minimize on coordinates
    return best


def _refine(squares):
    """Use scipy.optimize.minimize on a relaxed objective."""
    n = len(squares)
    if n == 0:
        return squares

    def obj(x):
        sqs = []
        for i in range(n):
            cx = x[4 * i]
            cy = x[4 * i + 1]
            ang = x[4 * i + 2]
            s = x[4 * i + 3]
            sqs.append((cx, cy, ang, s))
        return -_score(sqs)

    x0 = []
    bounds = []
    for sq in squares:
        x0 += [sq[0], sq[1], sq[2], sq[3]]
        bounds += [(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)]

    try:
        res = minimize(obj, x0, method='L-BFGS-B', bounds=bounds,
                       options={'maxiter': 200, 'ftol': 1e-9})
        x = res.x
        out = []
        for i in range(n):
            out.append([x[4 * i], x[4 * i + 1], x[4 * i + 2], x[4 * i + 3]])
        # clamp
        out = [list(_clamp_square(tuple(sq))) for sq in out]
        if _score(out) > _score(squares):
            return out
    except Exception:
        pass
    return squares


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Generate candidate layouts
    candidates = []
    candidates.append(_grid_layout(n))
    candidates.append(_row_layout(n))
    candidates.append(_rotated_row_layout(n))
    candidates.append(_mixed_layout(n))

    # also try some random perturbations
    best_sq = None
    best_sc = -1e18

    for layout in candidates:
        sqs = [list(sq) for sq in layout]
        sc = _score(sqs)
        if sc > best_sc:
            best_sc = sc
            best_sq = [list(sq) for sq in sqs]

    # Local search from best candidates with different seeds
    seeds = [0, 1, 2, 3, 4]
    for seed in seeds:
        random.seed(seed)
        # start from a random candidate
        start = random.choice(candidates)
        sqs = [list(sq) for sq in start]
        # random perturb initial
        for i in range(n):
            if sqs[i][3] > 0:
                sqs[i][0] += random.gauss(0, 0.01)
                sqs[i][1] += random.gauss(0, 0.01)
                sqs[i][2] += random.gauss(0, 0.02)
                sqs[i] = list(_clamp_square(tuple(sqs[i])))
        refined = _local_search(sqs, iterations=1000, seed=seed)
        sc = _score(refined)
        if sc > best_sc:
            best_sc = sc
            best_sq = [list(sq) for sq in refined]

    # try refinement with scipy from best
    for _ in range(3):
        refined = _refine(best_sq)
        sc = _score(refined)
        if sc > best_sc:
            best_sc = sc
            best_sq = [list(sq) for sq in refined]

    # final local search around best
    for seed in range(10, 20):
        random.seed(seed)
        sqs = [list(sq) for sq in best_sq]
        for i in range(n):
            if sqs[i][3] > 0 and random.random() < 0.5:
                sqs[i][0] = max(0.0, min(1.0, sqs[i][0] + random.gauss(0, 0.005)))
                sqs[i][1] = max(0.0, min(1.0, sqs[i][1] + random.gauss(0, 0.005)))
                sqs[i][2] = (sqs[i][2] + random.gauss(0, 0.01)) % 1.0
                sqs[i] = list(_clamp_square(tuple(sqs[i])))
        refined = _local_search(sqs, iterations=500, seed=seed)
        sc = _score(refined)
        if sc > best_sc:
            best_sc = sc
            best_sq = [list(sq) for sq in refined]

    # Ensure valid output
    result = []
    for sq in best_sq:
        cx, cy, ang, s = sq
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        ang = ang % 1.0
        s = max(0.0, min(1.0, s))
        result.append((cx, cy, ang, s))
    # pad if needed
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
