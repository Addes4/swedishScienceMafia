"""Packing n squares in the unit square, maximising the sum of side lengths.

Approach: build a good initial layout (largest k x k grid, optionally with
a leftover row/column optimized by 1-D strip packing), then improve it with
a randomized local search that perturbs centers and sizes and repairs
overlaps by shrinking/projecting overlapping pairs.  Rotations are allowed
and used when beneficial by trying random small angles.
"""
import math
import random

random.seed(12345)


def _overlap_area(a, b):
    # approximate overlap test via separating axis for oriented squares
    # returns True if interiors overlap
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 1e-12 or bsz <= 1e-12:
        return False
    # quick bounding circle reject
    ra = asz * 0.5 * math.sqrt(2.0)
    rb = bsz * 0.5 * math.sqrt(2.0)
    if (ax - bx) ** 2 + (ay - by) ** 2 >= (ra + rb) ** 2:
        return False
    # SAT for two oriented rectangles (squares)
    def corners(cx, cy, ang, s):
        c = math.cos(2 * math.pi * ang)
        si = math.sin(2 * math.pi * ang)
        h = s * 0.5
        pts = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            pts.append((cx + dx * c - dy * si, cy + dx * si + dy * c))
        return pts

    pa = corners(ax, ay, aa, asz)
    pb = corners(bx, by, ba, bsz)
    axes = []
    for pts in (pa, pb):
        for i in range(2):
            x1, y1 = pts[i]
            x2, y2 = pts[i + 1]
            ex, ey = x2 - x1, y2 - y1
            L = math.hypot(ex, ey)
            axes.append((-ey / L, ex / L))
    for nx, ny in axes:
        amin = amax = pa[0][0] * nx + pa[0][1] * ny
        for p in pa[1:]:
            v = p[0] * nx + p[1] * ny
            if v < amin:
                amin = v
            if v > amax:
                amax = v
        bmin = bmax = pb[0][0] * nx + pb[0][1] * ny
        for p in pb[1:]:
            v = p[0] * nx + p[1] * ny
            if v < bmin:
                bmin = v
            if v > bmax:
                bmax = v
        if amax <= bmin + 1e-12 or bmax <= amin + 1e-12:
            return False
    return True


def _inside(sq):
    x, y, ang, s = sq
    if s <= 1e-12:
        return True
    h = s * 0.5
    r = h * math.sqrt(2.0)
    return (x - r >= -1e-9 and x + r <= 1 + 1e-9 and
            y - r >= -1e-9 and y + r <= 1 + 1e-9)


def _feasible(sqs):
    for i in range(len(sqs)):
        if not _inside(sqs[i]):
            return False
        for j in range(i + 1, len(sqs)):
            if _overlap_area(sqs[i], sqs[j]):
                return False
    return True


def _total(sqs):
    return sum(s[3] for s in sqs)


def _grid_layout(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    sqs = []
    for i in range(k):
        for j in range(k):
            sqs.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # leftover squares: place in a row along the top with optimized sizes
    leftover = n - k * k
    if leftover > 0:
        # put leftover squares in one extra column of width w fitting in [0,1-k*side]... 
        # better: shrink grid slightly to make room for a column
        # try to distribute: use a column on the right with leftover squares
        # maximize sum by choosing column width t and leftover square size t
        # grid becomes k columns of size s + 1 column of size t with s = (1-t)/k
        # actually simpler: pack leftover into a strip of height t on top
        # sum = k*k*(1-t)/k + leftover * min(t, (1-t)/k)
        # We'll just do a simple strip: leftover squares side t in top strip
        # choose t to maximize leftover*t + k*k*(1-t)/k
        # derivative: leftover - k = 0 -> if leftover>k increase t else t->0
        best = None
        for t in [i / 200.0 for i in range(1, 200)]:
            s = (1.0 - t) / k
            lsz = min(t, s)
            if lsz <= 0:
                continue
            val = k * k * s + leftover * lsz
            if best is None or val > best[0]:
                best = (val, t, s, lsz)
        if best is None:
            best = (0, 0, side, 0)
        _, t, s, lsz = best
        sqs = []
        for i in range(k):
            for j in range(k):
                sqs.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        # leftover in a row in the top strip
        if lsz > 0:
            cols = min(leftover, max(1, int(1.0 / lsz)))
            for idx in range(leftover):
                cx = (idx % cols + 0.5) * lsz
                cy = 1.0 - t + (idx // cols + 0.5) * lsz
                if cy > 1.0:
                    cy = 1.0 - lsz * 0.5
                sqs.append((min(max(cx, lsz * 0.5), 1 - lsz * 0.5),
                            min(max(cy, lsz * 0.5), 1 - lsz * 0.5),
                            0.0, lsz))
    return sqs


def _repair(sqs, iters=40):
    """Push overlapping squares apart and clamp inside; shrink if needed."""
    sqs = [list(s) for s in sqs]
    for _ in range(iters):
        moved = False
        for i in range(len(sqs)):
            x, y, ang, s = sqs[i]
            if s <= 1e-12:
                continue
            h = s * 0.5
            r = h * math.sqrt(2.0)
            if x - r < 0:
                sqs[i][0] = r
                moved = True
            elif x + r > 1:
                sqs[i][0] = 1 - r
                moved = True
            if y - r < 0:
                sqs[i][1] = r
                moved = True
            elif y + r > 1:
                sqs[i][1] = 1 - r
                moved = True
        for i in range(len(sqs)):
            for j in range(i + 1, len(sqs)):
                if _overlap_area(sqs[i], sqs[j]):
                    # shrink both a bit and push apart
                    si = sqs[i][3]
                    sj = sqs[j][3]
                    dx = sqs[i][0] - sqs[j][0]
                    dy = sqs[i][1] - sqs[j][1]
                    d = math.hypot(dx, dy) + 1e-9
                    push = 0.5 * (si + sj) - d
                    if push > 0:
                        ux, uy = dx / d, dy / d
                        sqs[i][0] += ux * push * 0.5
                        sqs[i][1] += uy * push * 0.5
                        sqs[j][0] -= ux * push * 0.5
                        sqs[j][1] -= uy * push * 0.5
                    # also shrink slightly to help convergence
                    sqs[i][3] = si * 0.998
                    sqs[j][3] = sj * 0.998
                    moved = True
        if not moved:
            break
    return [tuple(s) for s in sqs]


def _local_search(sqs, time_budget_steps=600):
    best = list(sqs)
    best_val = _total(best)
    cur = list(best)
    cur_val = best_val
    n = len(cur)
    for step in range(time_budget_steps):
        new = [list(s) for s in cur]
        # perturb a few squares
        k = random.randint(1, max(1, n // 4))
        for _ in range(k):
            idx = random.randrange(n)
            x, y, ang, s = new[idx]
            scale = 0.03 * (1.0 - step / (time_budget_steps + 1)) + 0.002
            x += random.uniform(-scale, scale)
            y += random.uniform(-scale, scale)
            if random.random() < 0.3:
                ang += random.uniform(-0.03, 0.03)
            if random.random() < 0.5:
                s *= 1.0 + random.uniform(-0.05, 0.05)
                s = max(0.0, min(1.0, s))
            new[idx] = [x, y, ang, s]
        # occasionally grow all sizes slightly
        if random.random() < 0.15:
            for q in new:
                q[3] *= 1.01
        cand = _repair(new, iters=15)
        cv = _total(cand)
        if cv > cur_val - 1e-9 and _feasible(cand):
            cur = cand
            cur_val = cv
            if cv > best_val:
                best = cand
                best_val = cv
        elif random.random() < 0.05:
            cur = cand
            cur_val = cv
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    sqs = _grid_layout(n)
    sqs = _repair(sqs, iters=30)
    best = _local_search(sqs, time_budget_steps=400)
    # ensure exactly n squares and feasibility
    best = _repair(best, iters=20)
    best = list(best[:n])
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    # final guarantee: remove any overlapping by shrinking
    for _ in range(30):
        bad = False
        for i in range(n):
            for j in range(i + 1, n):
                if _overlap_area(best[i], best[j]):
                    bad = True
                    xi, yi, ai, si = best[i]
                    xj, yj, aj, sj = best[j]
                    best[i] = (xi, yi, ai, si * 0.97)
                    best[j] = (xj, yj, aj, sj * 0.97)
        if not bad and _feasible(best):
            break
    # clamp to [0,1]
    out = []
    for x, y, a, s in best:
        out.append((min(max(x, 0.0), 1.0), min(max(y, 0.0), 1.0),
                    a % 1.0, max(0.0, min(1.0, s))))
    return out
