import math
import random

def _inside(poly, sq):
    cx, cy, ang, side = sq
    a = ang * 2 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side / 2.0
    corners = [(cx + ca*dx - sa*dy, cy + sa*dx + ca*dy)
               for dx, dy in ((-h,-h),(h,-h),(h,h),(-h,h))]
    if any(x < -1e-12 or x > 1+1e-12 or y < -1e-12 or y > 1+1e-12 for x,y in corners):
        return False
    return True

def _overlap(s1, s2):
    def axes(s):
        cx, cy, ang, side = s
        a = ang * 2 * math.pi
        ca, sa = math.cos(a), math.sin(a)
        return [(ca, sa), (-sa, ca)]
    def corners(s):
        cx, cy, ang, side = s
        a = ang * 2 * math.pi
        ca, sa = math.cos(a), math.sin(a)
        h = side / 2.0
        return [(cx + ca*dx - sa*dy, cy + sa*dx + ca*dy)
                for dx, dy in ((-h,-h),(h,-h),(h,h),(-h,h))]
    c1 = corners(s1)
    c2 = corners(s2)
    for ax in axes(s1) + axes(s2):
        p1 = [c1[0][0]*ax[0]+c1[0][1]*ax[1], c1[1][0]*ax[0]+c1[1][1]*ax[1],
              c1[2][0]*ax[0]+c1[2][1]*ax[1], c1[3][0]*ax[0]+c1[3][1]*ax[1]]
        p2 = [c2[0][0]*ax[0]+c2[0][1]*ax[1], c2[1][0]*ax[0]+c2[1][1]*ax[1],
              c2[2][0]*ax[0]+c2[2][1]*ax[1], c2[3][0]*ax[0]+c2[3][1]*ax[1]]
        if max(p1) <= min(p2) + 1e-12 or max(p2) <= min(p1) + 1e-12:
            return False
    return True

def _valid(sqs):
    n = len(sqs)
    for i in range(n):
        if not _inside(None, sqs[i]):
            return False
        for j in range(i+1, n):
            if _overlap(sqs[i], sqs[j]):
                return False
    return True

def _greedy(n):
    # Use candidate grid of centers and angles; place squares as large as possible.
    angles = [0.0, 0.125, 0.0625, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875]
    # Precompute candidate positions
    m = 12
    cands = []
    for i in range(m+1):
        for j in range(m+1):
            cx = i / m if m else 0.5
            cy = j / m if m else 0.5
            cx = min(max(cx, 0.0), 1.0)
            cy = min(max(cy, 0.0), 1.0)
            for ang in angles:
                cands.append((cx, cy, ang))
    random.seed(12345)
    random.shuffle(cands)
    squares = []
    # For each square, try to place as large as possible.
    # Start with a max side upper bound, binary search over side.
    for _ in range(n):
        best = None
        best_side = -1.0
        # fraction of candidates to try to keep time bounded
        cand_sub = cands[:400]
        for (cx, cy, ang) in cand_sub:
            # upper bound: limited by unit square for this center/angle
            lo = 0.0
            hi = 1.5
            # binary search largest side that fits with existing squares
            for _bs in range(18):
                mid = (lo + hi) / 2
                if mid <= 0:
                    lo = mid
                    continue
                sq = (cx, cy, ang, mid)
                if not _inside(None, sq):
                    hi = mid
                    continue
                ok = True
                for s in squares:
                    if _overlap(sq, s):
                        ok = False
                        break
                if ok:
                    lo = mid
                else:
                    hi = mid
            if lo > best_side:
                best_side = lo
                best = (cx, cy, ang, lo)
        if best is None or best_side <= 1e-12:
            squares.append((0.5, 0.5, 0.0, 0.0))
        else:
            squares.append(best)
        # early exit if very small
    return squares

def _refine(sqs, iters=200):
    # Coordinate descent: for each square, try to grow it by moving/rotating slightly
    n = len(sqs)
    best = list(sqs)
    best_score = sum(s[3] for s in sqs)
    rng = random.Random(999)
    for _ in range(iters):
        improved = False
        for i in range(n):
            cx, cy, ang, side = best[i]
            # try small perturbations
            for _t in range(6):
                # Try to increase side
                nd = side * (1.05 + rng.random()*0.2) + 0.001
                ncx = cx + (rng.random()-0.5)*0.05
                ncy = cy + (rng.random()-0.5)*0.05
                nang = ang + (rng.random()-0.5)*0.1
                ncx = min(max(ncx, 0.0), 1.0)
                ncy = min(max(ncy, 0.0), 1.0)
                sq = (ncx, ncy, nang % 1.0, nd)
                if not _inside(None, sq):
                    continue
                ok = True
                for j in range(n):
                    if j == i:
                        continue
                    if _overlap(sq, best[j]):
                        ok = False
                        break
                if ok:
                    old = best[i][3]
                    if nd > old:
                        best[i] = sq
                        best_score += nd - old
                        improved = True
        # Also try shrinking and repositioning to help others? Keep simple.
        if not improved:
            break
    return best

def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n <= 400:
        sqs = _greedy(n)
        sqs = _refine(sqs, iters=80 if n < 50 else 30)
        # compute score
        return sqs
    else:
        # grid fallback for very large n
        k = math.isqrt(n)
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        return squares[:n]
