import math
import random
import time
from functools import lru_cache

import numpy as np
from scipy.optimize import minimize


def _area_upper_bound(n):
    # trivial upper bound: sum sides <= sqrt(n)
    return math.sqrt(n)


def _grid_solution(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0) for _ in range(n)]
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
    return sq[:n]


def _square_vertices(cx, cy, angle, side):
    # angle fraction of full turn
    th = 2.0 * math.pi * angle
    c = math.cos(th) * side * 0.5
    s = math.sin(th) * side * 0.5
    return [
        (cx + c - s, cy + s + c),
        (cx - c - s, cy - s + c),
        (cx - c + s, cy - s - c),
        (cx + c + s, cy + s - c),
    ]


def _sat_overlap_area_sq(sq1, sq2):
    """Approximate whether two squares overlap using separating axis theorem.
    Returns True if they share interior points (overlap area > eps).
    """
    if sq1[3] <= 1e-14 or sq2[3] <= 1e-14:
        return False
    verts1 = _square_vertices(*sq1)
    verts2 = _square_vertices(*sq2)
    axes = []
    for pts in (verts1, verts2):
        for i in range(4):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            # normal
            axes.append((-ey, ex))
    for ax, ay in axes:
        nlen = math.hypot(ax, ay)
        if nlen < 1e-15:
            continue
        ax, ay = ax / nlen, ay / nlen
        p1 = [ax * x + ay * y for x, y in verts1]
        p2 = [ax * x + ay * y for x, y in verts2]
        if min(p1) >= max(p2) - 1e-12 or min(p2) >= max(p1) - 1e-12:
            return False
    return True


def _packing_score(squares):
    return sum(max(0.0, s[3]) for s in squares)


def _is_feasible(squares, eps=1e-9):
    for i in range(len(squares)):
        cx, cy, ang, sd = squares[i]
        if sd < -eps:
            return False
        if sd > eps:
            vs = _square_vertices(cx, cy, ang, sd)
            for x, y in vs:
                if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
                    return False
        for j in range(i + 1, len(squares)):
            if _sat_overlap_area_sq(squares[i], squares[j]):
                return False
    return True


def _repair(squares):
    """Greedy repair: shrink squares that violate constraints."""
    squares = [list(s) for s in squares]
    n = len(squares)
    for _ in range(200):
        changed = False
        for i in range(n):
            cx, cy, ang, sd = squares[i]
            if sd <= 0:
                continue
            # boundary clamp
            vs = _square_vertices(cx, cy, ang, sd)
            minx = min(v[0] for v in vs)
            maxx = max(v[0] for v in vs)
            miny = min(v[1] for v in vs)
            maxy = max(v[1] for v in vs)
            if minx < 0:
                cx -= minx
                changed = True
            if maxx > 1:
                cx -= (maxx - 1)
                changed = True
            if miny < 0:
                cy -= miny
                changed = True
            if maxy > 1:
                cy -= (maxy - 1)
                changed = True
            cx = min(max(cx, 0.0), 1.0)
            cy = min(max(cy, 0.0), 1.0)
            squares[i] = [cx, cy, ang, sd]
        # overlap shrink
        for i in range(n):
            for j in range(i + 1, n):
                if squares[i][3] <= 0 or squares[j][3] <= 0:
                    continue
                if _sat_overlap_area_sq(squares[i], squares[j]):
                    # shrink both slightly
                    squares[i][3] *= 0.98
                    squares[j][3] *= 0.98
                    changed = True
        if not changed:
            break
    return [tuple(s) for s in squares]


def _objective_and_constraints(xvec, n):
    """xvec: [cx, cy, ang, sd] * n
    We minimize negative sum side + penalty for overlaps and boundary violations.
    """
    sq = []
    for i in range(n):
        cx = xvec[4 * i]
        cy = xvec[4 * i + 1]
        ang = xvec[4 * i + 2]
        sd = xvec[4 * i + 3]
        sq.append((cx, cy, ang, sd))
    # objective: maximize sum side -> minimize negative
    obj = -sum(max(0.0, s[3]) for s in sq)
    # penalty
    pen = 0.0
    for i in range(n):
        cx, cy, ang, sd = sq[i]
        if sd < 0:
            pen += 1e3 * (sd * sd)
            continue
        vs = _square_vertices(cx, cy, ang, sd)
        for x, y in vs:
            if x < 0:
                pen += 1e3 * x * x
            if x > 1:
                pen += 1e3 * (x - 1) ** 2
            if y < 0:
                pen += 1e3 * y * y
            if y > 1:
                pen += 1e3 * (y - 1) ** 2
        for j in range(i + 1, n):
            if _sat_overlap_area_sq(sq[i], sq[j]):
                pen += 1e3
    return obj + pen


def _optimize_packing(squares, time_limit, rng):
    n = len(squares)
    # flatten
    x0 = []
    for cx, cy, ang, sd in squares:
        x0.extend([cx, cy, ang, sd])
    x0 = np.array(x0, dtype=float)
    # bounds: centres [0,1], angle [0, 0.5) (due to symmetry), side [0,1]
    bounds = []
    for i in range(n):
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 0.5))
        bounds.append((0.0, 1.0))

    def fun(x):
        return _objective_and_constraints(x, n)

    best_x = x0.copy()
    best_val = fun(best_x)
    start = time.time()
    iters = 0
    while time.time() - start < time_limit and iters < 40:
        iters += 1
        if iters == 1:
            xstart = x0.copy()
        else:
            xstart = x0.copy()
            # perturb
            for i in range(n):
                if rng.random() < 0.5:
                    xstart[4 * i] += rng.gauss(0, 0.05)
                    xstart[4 * i] = min(max(xstart[4 * i], 0.0), 1.0)
                if rng.random() < 0.5:
                    xstart[4 * i + 1] += rng.gauss(0, 0.05)
                    xstart[4 * i + 1] = min(max(xstart[4 * i + 1], 0.0), 1.0)
                if rng.random() < 0.5:
                    xstart[4 * i + 2] += rng.gauss(0, 0.05)
                    xstart[4 * i + 2] = min(max(xstart[4 * i + 2], 0.0), 0.5)
                if rng.random() < 0.5:
                    xstart[4 * i + 3] *= max(0.1, 1.0 + rng.gauss(0, 0.1))
                    xstart[4 * i + 3] = min(max(xstart[4 * i + 3], 0.0), 1.0)
        try:
            res = minimize(fun, xstart, method='SLSQP', bounds=bounds,
                           options={'maxiter': 200, 'ftol': 1e-10, 'disp': False})
        except Exception:
            continue
        if res.fun < best_val:
            best_val = res.fun
            best_x = res.x.copy()
    # rebuild squares
    result = []
    for i in range(n):
        cx = best_x[4 * i]
        cy = best_x[4 * i + 1]
        ang = best_x[4 * i + 2]
        sd = best_x[4 * i + 3]
        result.append((cx, cy, ang, max(0.0, sd)))
    return result


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares of side 0.5 stacked
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # three squares: one side 0.5, two side 0.25 in remaining L-shape
        return [(0.25, 0.75, 0.0, 0.5), (0.75, 0.25, 0.0, 0.25), (0.75, 0.75, 0.0, 0.25)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    # For n = 5 and above, try structured guillotine packings and numerical optimization
    # Start with grid solution
    base = _grid_solution(n)
    best = base[:]
    best_score = _packing_score(best)

    # Try some simple recursive guillotine packings for small n
    if n <= 12:
        # Try splitting unit square into two rectangles recursively
        # We'll generate candidate packings by fitting squares into a grid with one missing
        k = math.isqrt(n)
        if k * k < n:
            # try k+1 by k+1 grid with some squares removed and others enlarged
            # simple heuristic: start from grid, try to enlarge some
            pass

    # Numerical optimization
    rng = random.Random(12345)
    time_budget = 25.0  # seconds
    start_time = time.time()

    # Try optimization from grid
    cand = _optimize_packing(base, time_budget * 0.6, rng)
    cand = _repair(cand)
    if _is_feasible(cand):
        score = _packing_score(cand)
        if score > best_score:
            best = cand
            best_score = score

    # Try random restarts
    attempts = 0
    while time.time() - start_time < time_budget and attempts < 30:
        attempts += 1
        # random initial
        init = []
        for i in range(n):
            cx = rng.random()
            cy = rng.random()
            ang = rng.random() * 0.5
            sd = rng.random() * 0.3
            init.append((cx, cy, ang, sd))
        cand = _optimize_packing(init, min(5.0, time_budget * 0.2), rng)
        cand = _repair(cand)
        if _is_feasible(cand):
            score = _packing_score(cand)
            if score > best_score:
                best = cand
                best_score = score

    # Final repair
    best = _repair(best)
    if not _is_feasible(best):
        # fallback to grid
        best = _grid_solution(n)
        best = _repair(best)

    # Ensure exactly n squares
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    best = best[:n]

    # Final validation: zero out any negative
    best = [(c[0], c[1], c[2], max(0.0, c[3])) for c in best]

    return best
