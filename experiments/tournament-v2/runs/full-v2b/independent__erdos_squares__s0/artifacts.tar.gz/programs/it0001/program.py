import math
import numpy as np
from scipy.optimize import minimize


def _overlap_constraint(sq, others):
    """Return the minimum separation gap for square sq against others (>=0 ok)."""
    return 0.0


def _rect_pack(n):
    """Construct initial packing: recursively split into n rectangles,
    place a square centered in each, oriented axis-aligned.
    Uses simplest split: grid-ish with a few larger/smaller cells."""
    if n <= 0:
        return []
    # Build a binary splitting tree choosing roughly balanced areas.
    rects = [(0.0, 0.0, 1.0, 1.0)]
    # split until we have n rects
    while len(rects) < n:
        # pick the rectangle with largest area (min square side) to split
        idx = max(range(len(rects)), key=lambda i: rects[i][2] * rects[i][3])
        x, y, w, h = rects.pop(idx)
        # split along the longer dimension
        if w >= h:
            f = 0.5
            # bias split to make squares possible
            rects.append((x, y, w * f, h))
            rects.append((x + w * f, y, w * (1 - f), h))
        else:
            f = 0.5
            rects.append((x, y, w, h * f))
            rects.append((x, y + h * f, w, h * (1 - f)))
    out = []
    for x, y, w, h in rects:
        s = min(w, h)
        out.append([x + w / 2.0, y + h / 2.0, 0.0, s])
    return out


def _ax_overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """Separating-axis separation (signed) between two squares.
    Returns gap: positive means separated."""
    # local half extents
    h1x = s1 / 2.0
    h1y = s1 / 2.0
    # rotation matrices
    t1 = a1 * 2 * math.pi
    t2 = a2 * 2 * math.pi
    c1, n1 = math.cos(t1), math.sin(t1)
    c2, n2 = math.cos(t2), math.sin(t2)
    # axes: 4 unit vectors
    axes = [(c1, n1), (-n1, c1), (c2, n2), (-n2, c2)]
    dx = cx2 - cx1
    dy = cy2 - cy1
    sep_min = float('inf')
    # projections of half-extent vectors: for square 1 axes e1x, e1y
    # half extent along axis for square i = |eix*axis|*hi + |eiy*axis|*hi
    # e1x = (c1,n1), e1y=(-n1,c1)
    def halfproj(cx, cy, a, s, axis):
        t = a * 2 * math.pi
        c, sn = math.cos(t), math.sin(t)
        ex = (c, sn)
        ey = (-sn, c)
        h = s / 2.0
        return abs(ex[0]*axis[0] + ex[1]*axis[1]) * h + abs(ey[0]*axis[0] + ey[1]*axis[1]) * h
    for ax in axes:
        d = abs(dx * ax[0] + dy * ax[1])
        h1 = halfproj(cx1, cy1, a1, s1, ax)
        h2 = halfproj(cx2, cy2, a2, s2, ax)
        gap = d - (h1 + h2)
        if gap < sep_min:
            sep_min = gap
    return sep_min


def _refine(sqs, n, time_budget=45.0):
    """Locally optimize using SLSQP, then a simple random-restart hill climb."""
    # variables: for each square cx, cy, angle, side
    # constraints: 
    #   - square inside unit box (via its four corners)
    #   - non-overlap pairwise (axis separation >= eps)
    # objective: maximize sum side -> minimize -sum side
    eps = -1e-7  # allow tiny overlap tolerance? use 0
    eps = 0.0
    m = n
    x0 = []
    for cx, cy, a, s in sqs:
        x0.append(cx)
        x0.append(cy)
        x0.append(a)
        x0.append(s)
    x0 = np.array(x0, dtype=float)

    def unpack(x):
        arr = x.reshape((n, 4))
        return arr

    def corners(cx, cy, a, s):
        t = a * 2 * math.pi
        c, sn = math.cos(t), math.sin(t)
        h = s / 2.0
        pts = []
        for (ex, ey) in ((1, 1), (-1, 1), (-1, -1), (1, -1)):
            wx = ex * c - ey * sn
            wy = ex * sn + ey * c
            pts.append((cx + wx * h, cy + wy * h))
        return pts

    def obj(x):
        arr = x.reshape((n, 4))
        return -np.sum(arr[:, 3])

    # build constraints once; use many inequality constraints
    cons = []

    # bound constraints handled via bounds
    bounds = []
    for i in range(n):
        bounds.append((0.0, 1.0))  # cx
        bounds.append((0.0, 1.0))  # cy
        bounds.append((0.0, 1.0))  # angle
        bounds.append((0.0, 1.0))  # side

    def inside_con(x):
        arr = x.reshape((n, 4))
        vals = []
        for i in range(n):
            cx, cy, a, s = arr[i]
            for (px, py) in corners(cx, cy, a, s):
                vals.append(px - 0.0)
                vals.append(1.0 - px)
                vals.append(py - 0.0)
                vals.append(1.0 - py)
        return vals

    def nonoverlap_con(x):
        arr = x.reshape((n, 4))
        vals = []
        for i in range(n):
            for j in range(i+1, n):
                cx1, cy1, a1, s1 = arr[i]
                cx2, cy2, a2, s2 = arr[j]
                g = _ax_overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2)
                vals.append(g)
        return vals

    class InsideConstraint:
        def __call__(self, x):
            return inside_con(x)
    class NoOverlap:
        def __call__(self, x):
            return nonoverlap_con(x)

    cons.append({'type': 'ineq', 'fun': inside_con})
    if n > 1:
        cons.append({'type': 'ineq', 'fun': nonoverlap_con})

    try:
        res = minimize(obj, x0, method='SLSQP', bounds=bounds, constraints=cons,
                       options={'maxiter': 200, 'ftol': 1e-9, 'disp': False})
        if res.success or np.sum(res.x.reshape((n,4))[:,3]) > np.sum(x0.reshape((n,4))[:,3]):
            x0 = res.x
    except Exception:
        pass

    arr = x0.reshape((n, 4))
    return [(float(cx), float(cy), float(a), float(s)) for cx, cy, a, s in arr]


def _repair(sqs):
    """Ensure validity: clamp inside unit square and remove overlaps greedily."""
    out = []
    n = len(sqs)
    arr = [list(s) for s in sqs]
    # clamp
    for i in range(n):
        cx, cy, a, s = arr[i]
        # shrink to fit if needed
        # compute max allowed
        t = a * 2 * math.pi
        c, sn = math.cos(t), math.sin(t)
        h = s / 2.0
        maxhx = 0.0
        maxhy = 0.0
        for (ex, ey) in ((1,1),(-1,1),(-1,-1),(1,-1)):
            wx = (ex*c - ey*sn)
            wy = (ex*sn + ey*c)
            maxhx = max(maxhx, abs(wx))
            maxhy = max(maxhy, abs(wy))
        # bounding half-extents
        bx = maxhx * h
        by = maxhy * h
        # clamp center
        cx = min(max(cx, bx), 1.0 - bx)
        cy = min(max(cy, by), 1.0 - by)
        # if still too big shrink
        s2 = s
        if bx > 0.5 or by > 0.5:
            scale = min(0.5 / bx, 0.5 / by) if bx > 0 or by > 0 else 1.0
            s2 = s * scale
            bx = maxhx * s2 / 2.0
            by = maxhy * s2 / 2.0
            cx = min(max(cx, bx), 1.0 - bx)
            cy = min(max(cy, by), 1.0 - by)
        arr[i] = [cx, cy, a, s2]
    # greedy overlap removal: shrink offending squares
    for _ in range(200):
        worst = None
        worst_gap = 0.0
        # find most overlapping pair
        for i in range(n):
            for j in range(i+1, n):
                g = _ax_overlap(*arr[i], *arr[j])
                if g < -1e-9:
                    if g < worst_gap:
                        worst_gap = g
                        worst = (i, j)
        if worst is None:
            break
        i, j = worst
        # shrink both by factor
        si = arr[i][3]
        sj = arr[j][3]
        if si >= sj:
            arr[i][3] = si * 0.9
        else:
            arr[j][3] = sj * 0.9
        # re-clamp
        for k in (i, j):
            cx, cy, a, s = arr[k]
            t = a * 2 * math.pi
            c, sn = math.cos(t), math.sin(t)
            h = s / 2.0
            maxhx = 0.0; maxhy = 0.0
            for (ex, ey) in ((1,1),(-1,1),(-1,-1),(1,-1)):
                wx = (ex*c - ey*sn); wy = (ex*sn + ey*c)
                maxhx = max(maxhx, abs(wx)); maxhy = max(maxhy, abs(wy))
            bx = maxhx * h; by = maxhy * h
            cx = min(max(cx, bx), 1.0 - bx)
            cy = min(max(cy, by), 1.0 - by)
            arr[k] = [cx, cy, a, s]
    return [tuple(s) for s in arr]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # Build initial packing
    init = _rect_pack(n)
    # optimize
    refined = _refine(init, n)
    # repair to guarantee validity
    repaired = _repair(refined)
    # final safety: verify sum > 0, return exactly n
    result = repaired[:n]
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    # sanity double-check validity: if invalid, fall back to grid
    # (defensive)
    ok = True
    for i in range(n):
        if result[i][3] < -1e-9:
            ok = False
    if not ok:
        import math as _m
        k = _m.isqrt(n)
        side = 1.0 / k
        g = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
        g += [(0.5, 0.5, 0.0, 0.0)] * (n - len(g))
        return g[:n]
    return result
