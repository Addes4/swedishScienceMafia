import math
import random


def _squares_from_params(n, params):
    """params: list of (cx, cy, ang, s). Returns clipped/repaired list."""
    out = []
    for cx, cy, ang, s in params:
        out.append([cx, cy, ang, max(0.0, s)])
    return out


def _clamp_to_unit(sq):
    """Move/rotate-aware clamping: shrink square so it fits in unit box."""
    cx, cy, ang, s = sq
    if s <= 0:
        return [min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), ang, 0.0]
    # half-extent in x and y for rotated square
    c = abs(math.cos(2 * math.pi * ang))
    sn = abs(math.sin(2 * math.pi * ang))
    # For a square of side s rotated by angle, the axis-aligned bounding half-width is
    # (s/2)*(|cos|+|sin|) in each axis (same by symmetry).
    h = 0.5 * s * (c + sn)
    if h <= 0:
        return [min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), ang, s]
    # clamp centre
    lo_x, hi_x = h, 1.0 - h
    lo_y, hi_y = h, 1.0 - h
    if lo_x > hi_x:
        # too big to fit at current angle: shrink
        s2 = s * (1.0 / (c + sn)) if (c + sn) > 0 else 0.0
        s2 = min(s2, s)
        h2 = 0.5 * s2 * (c + sn)
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        cx = min(1.0 - h2, max(h2, cx))
        cy = min(1.0 - h2, max(h2, cy))
        return [cx, cy, ang, s2]
    cx = min(hi_x, max(lo_x, cx))
    cy = min(hi_y, max(lo_y, cy))
    return [cx, cy, ang, s]


def _corners(sq):
    cx, cy, ang, s = sq
    if s <= 0:
        return [(cx, cy)] * 4
    t = 2 * math.pi * ang
    c, sn = math.cos(t), math.sin(t)
    h = 0.5 * s
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + c * px - sn * py, cy + sn * px + c * py) for px, py in pts]


def _sat_overlap(a, b):
    """Return False if interiors disjoint, True otherwise (SAT for convex polys)."""
    ca = _corners(a)
    cb = _corners(b)
    axes = []
    for poly in (ca, cb):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ex, ey = x2 - x1, y2 - y1
            L = math.hypot(ex, ey)
            if L > 1e-15:
                axes.append((-ey / L, ex / L))
    for ax, ay in axes:
        mna = mxa = None
        for x, y in ca:
            p = x * ax + y * ay
            if mna is None or p < mna:
                mna = p
            if mxa is None or p > mxa:
                mxa = p
        mnb = mxb = None
        for x, y in cb:
            p = x * ax + y * ay
            if mnb is None or p < mnb:
                mnb = p
            if mxb is None or p > mxb:
                mxb = p
        # use strict separation with tiny tolerance
        if mxa <= mnb + 1e-12 or mxb <= mna + 1e-12:
            return False
    return True


def _total_side(sqs):
    return sum(s[3] for s in sqs)


def _repair(sqs, rng, max_iter=200):
    """Resolve overlaps by shrinking the smaller of overlapping pairs."""
    sqs = [list(s) for s in sqs]
    n = len(sqs)
    for _ in range(max_iter):
        moved = False
        for i in range(n):
            for j in range(i + 1, n):
                if sqs[i][3] <= 0 or sqs[j][3] <= 0:
                    continue
                if _sat_overlap(sqs[i], sqs[j]):
                    # shrink the smaller one (or both a bit)
                    si, sj = sqs[i][3], sqs[j][3]
                    if si <= sj:
                        target = i
                        other = j
                    else:
                        target = j
                        other = i
                    # binary search for max shrink factor
                    lo, hi = 0.0, 1.0
                    orig = sqs[target][3]
                    for _bs in range(30):
                        mid = 0.5 * (lo + hi)
                        trial = list(sqs[target])
                        trial[3] = orig * mid
                        trial = _clamp_to_unit(trial)
                        if _sat_overlap(trial, sqs[other]):
                            hi = mid
                        else:
                            lo = mid
                    news = orig * lo
                    if news < 0:
                        news = 0.0
                    sqs[target][3] = news
                    sqs[target] = _clamp_to_unit(sqs[target])
                    moved = True
        if not moved:
            break
    return sqs


def _initial(n, rng):
    """Build a good initial packing: grid of k x k plus optimize leftovers."""
    if n == 0:
        return []
    # Try several k values and pick best simple grid + fill strategy
    best = None
    for k in range(1, n + 1):
        if k * k > n:
            # k x k grid not enough slots? Actually k*k <= n needed to place k*k squares.
            pass
    # Choose k = floor(sqrt(n)) generally; but occasionally k+... can help if n>k^2
    k = int(math.isqrt(n))
    if k < 1:
        k = 1
    # Start with k x k grid
    s = 1.0 / k
    sqs = []
    used = 0
    for i in range(k):
        for j in range(k):
            if used >= n:
                break
            cx = (i + 0.5) * s
            cy = (j + 0.5) * s
            sqs.append([cx, cy, 0.0, s])
            used += 1
        if used >= n:
            break
    # For remaining, place small squares in gaps (initially tiny at random spots)
    while len(sqs) < n:
        sqs.append([rng.uniform(0.05, 0.95), rng.uniform(0.05, 0.95), 0.0, 0.0])
    return sqs


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    best_sqs = None
    best_val = -1.0

    # Multiple restarts with different initial grids/sizes
    for trial in range(6):
        k = int(math.isqrt(n))
        if k < 1:
            k = 1
        # vary grid side slightly
        if trial == 0:
            sqs = _initial(n, rng)
        elif trial == 1 and k >= 2:
            # k-1 grid with leftover larger squares
            kk = k - 1
            s = 1.0 / kk
            sqs = []
            for i in range(kk):
                for j in range(kk):
                    if len(sqs) >= n:
                        break
                    sqs.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
                if len(sqs) >= n:
                    break
            while len(sqs) < n:
                sqs.append([rng.uniform(0.05, 0.95), rng.uniform(0.05, 0.95), 0.0, 0.0])
        elif trial == 2 and k >= 1:
            # single row / column variants
            kk = min(n, 10)
            s = 1.0 / kk
            sqs = []
            for i in range(kk):
                sqs.append([(i + 0.5) * s, 0.5, 0.0, s])
            while len(sqs) < n:
                sqs.append([rng.uniform(0.05, 0.95), rng.uniform(0.05, 0.95), 0.0, 0.0])
        else:
            sqs = _initial(n, rng)
            # randomize
            for s in sqs:
                if rng.random() < 0.5:
                    s[0] = rng.uniform(0.1, 0.9)
                    s[1] = rng.uniform(0.1, 0.9)
                if rng.random() < 0.3:
                    s[2] = rng.random()
            sqs = [_clamp_to_unit(s) for s in sqs]

        # Repair overlaps
        sqs = _repair(sqs, rng, max_iter=100)

        # Simulated annealing / hill climbing on (cx, cy, angle, side)
        T = 0.15
        alpha = 0.995
        iters = 4000
        cur = [list(s) for s in sqs]
        cur_val = _total_side(cur)

        for it in range(iters):
            T = max(1e-4, T * alpha)
            i = rng.randrange(n)
            old = list(cur[i])
            mode = rng.random()
            if mode < 0.35:
                # perturb position
                cur[i][0] += rng.gauss(0, 0.04 * T)
                cur[i][1] += rng.gauss(0, 0.04 * T)
            elif mode < 0.55:
                # perturb angle
                cur[i][2] += rng.gauss(0, 0.05 * T)
            elif mode < 0.85:
                # perturb size (prefer growing)
                factor = 1.0 + rng.gauss(0.02, 0.08 * T)
                cur[i][3] *= factor
            else:
                # combine
                cur[i][0] += rng.gauss(0, 0.02 * T)
                cur[i][1] += rng.gauss(0, 0.02 * T)
                cur[i][2] += rng.gauss(0, 0.03 * T)
                cur[i][3] *= 1.0 + rng.gauss(0.01, 0.05 * T)

            cur[i] = _clamp_to_unit(cur[i])
            if cur[i][3] < 0:
                cur[i][3] = 0.0

            # Check overlaps involving i
            ok = True
            for j in range(n):
                if i == j:
                    continue
                if cur[i][3] <= 0 or cur[j][3] <= 0:
                    continue
                if _sat_overlap(cur[i], cur[j]):
                    ok = False
                    break
            if not ok:
                # try repair: shrink i until ok
                orig = cur[i][3]
                lo, hi = 0.0, 1.0
                trial_sq = list(cur[i])
                for _bs in range(25):
                    mid = 0.5 * (lo + hi)
                    trial_sq[3] = orig * mid
                    trial_sq = _clamp_to_unit(trial_sq)
                    conflict = False
                    for j in range(n):
                        if i == j:
                            continue
                        if trial_sq[3] <= 0 or cur[j][3] <= 0:
                            continue
                        if _sat_overlap(trial_sq, cur[j]):
                            conflict = True
                            break
                    if conflict:
                        hi = mid
                    else:
                        lo = mid
                cur[i][3] = orig * lo
                cur[i] = _clamp_to_unit(cur[i])

            new_val = _total_side(cur)
            # Accept if improved, or with small probability if worse
            if new_val >= cur_val or rng.random() < math.exp((new_val - cur_val) / max(1e-9, T)):
                cur_val = new_val
            else:
                cur[i] = old

            # occasionally do a global repair
            if it % 500 == 499:
                cur = _repair(cur, rng, max_iter=50)
                cur_val = _total_side(cur)

        cur = _repair(cur, rng, max_iter=50)
        val = _total_side(cur)
        if val > best_val:
            best_val = val
            best_sqs = [list(s) for s in cur]

    # Final cleanup: ensure validity and clamp
    result = []
    for s in best_sqs:
        s = _clamp_to_unit(s)
        result.append((min(1.0, max(0.0, s[0])),
                       min(1.0, max(0.0, s[1])),
                       min(1.0, max(0.0, s[2])),
                       min(1.0, max(0.0, s[3]))))

    # Ensure no overlaps remain (final safety repair)
    result = _repair([list(r) for r in result], rng, max_iter=100)
    result = [(min(1.0, max(0.0, r[0])),
               min(1.0, max(0.0, r[1])),
               min(1.0, max(0.0, r[2])),
               min(1.0, max(0.0, r[3]))) for r in result]

    if len(result) < n:
        result += [(0.5, 0.5, 0.0, 0.0)] * (n - len(result))
    return result[:n]
