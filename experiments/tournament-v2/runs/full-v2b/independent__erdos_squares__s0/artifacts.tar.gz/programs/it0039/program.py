import math
import random
from scipy.optimize import minimize


def _inside(cx, cy, ang, s):
    c = math.cos(2 * math.pi * ang)
    ss = math.sin(2 * math.pi * ang)
    a = abs(c)
    b = abs(ss)
    hx = 0.5 * s * (a + b)
    hy = 0.5 * s * (a + b)
    return cx - hx >= -1e-12 and cx + hx <= 1 + 1e-12 and cy - hy >= -1e-12 and cy + hy <= 1 + 1e-12


def _corners(cx, cy, ang, s):
    c = math.cos(2 * math.pi * ang)
    ss = math.sin(2 * math.pi * ang)
    h = 0.5 * s
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + dx * c - dy * ss
        y = cy + dx * ss + dy * c
        pts.append((x, y))
    return pts


def _edge_axis(pts):
    axes = []
    for i in range(4):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % 4]
        dx, dy = x2 - x1, y2 - y1
        L = math.hypot(dx, dy)
        if L > 1e-15:
            axes.append((-dy / L, dx / L))
    return axes


def _overlap(c1, c2):
    cx1, cy1, a1, s1 = c1
    cx2, cy2, a2, s2 = c2
    if s1 <= 1e-15 or s2 <= 1e-15:
        return False
    p1 = _corners(cx1, cy1, a1, s1)
    p2 = _corners(cx2, cy2, a2, s2)
    axes = _edge_axis(p1) + _edge_axis(p2)
    for ax, ay in axes:
        mn1 = min(px * ax + py * ay for px, py in p1)
        mx1 = max(px * ax + py * ay for px, py in p1)
        mn2 = min(px * ax + py * ay for px, py in p2)
        mx2 = max(px * ax + py * ay for px, py in p2)
        if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
            return False
    return True


def _can_place(cx, cy, ang, s, placed):
    if not _inside(cx, cy, ang, s):
        return False
    new = (cx, cy, ang, s)
    for p in placed:
        if _overlap(new, p):
            return False
    return True


def _max_scale(cx, cy, ang, placed, cap):
    lo, hi = 0.0, cap
    for _ in range(20):
        mid = (lo + hi) * 0.5
        if _can_place(cx, cy, ang, mid, placed):
            lo = mid
        else:
            hi = mid
    return lo


def _greedy(n):
    random.seed(12345)
    placed = []
    # Try a few candidate sizes for the first square to diversify.
    best = None
    best_score = -1.0

    order = []
    k = math.isqrt(n)
    rem = n - k * k
    for _ in range(k * k):
        order.append(1.0 / k)
    if rem > 0:
        for _ in range(rem):
            order.append(0.0)
    order.sort(reverse=True)

    trials = 12
    for t in range(trials):
        placed = []
        ok = True
        for s_target in order:
            if s_target <= 1e-15:
                placed.append((0.5, 0.5, 0.0, 0.0))
                continue
            cand = None
            if len(placed) == 0:
                cand = (0.5, 0.5, 0.0, s_target)
                if not _can_place(*cand[:3], cand[3], placed):
                    ok = False
                    break
                placed.append(cand)
                continue
            # Dense grid + random search at the target scale.
            best_local = None
            best_local_s = -1.0
            grid = 9 + 2 * t
            for ix in range(grid):
                for iy in range(grid):
                    cx = (ix + 0.5) / grid
                    cy = (iy + 0.5) / grid
                    for ia in range(4 + t):
                        ang = (ia / (4.0 + t)) % 0.5  # 0..0.5 covers 180 deg symmetry
                        if _can_place(cx, cy, ang, s_target * 0.999, placed):
                            val = _max_scale(cx, cy, ang, placed, s_target)
                            if val > best_local_s:
                                best_local_s = val
                                best_local = (cx, cy, ang, val)
            for _ in range(20 + 5 * t):
                cx = random.random()
                cy = random.random()
                ang = random.random() * 0.5
                if _can_place(cx, cy, ang, s_target * 0.999, placed):
                    val = _max_scale(cx, cy, ang, placed, s_target)
                    if val > best_local_s:
                        best_local_s = val
                        best_local = (cx, cy, ang, val)
            if best_local is None:
                # Try smaller scale as fallback
                for scale in (0.98, 0.95, 0.9, 0.8, 0.6, 0.4, 0.2):
                    st = s_target * scale
                    if st <= 1e-15:
                        break
                    for ix in range(6):
                        for iy in range(6):
                            for ia in range(4):
                                cx = (ix + 0.5) / 6
                                cy = (iy + 0.5) / 6
                                ang = (ia / 4.0) % 0.5
                                if _can_place(cx, cy, ang, st, placed):
                                    best_local = (cx, cy, ang, st)
                                    break
                            if best_local:
                                break
                        if best_local:
                            break
                    if best_local:
                        break
            if best_local is None:
                placed.append((0.5, 0.5, 0.0, 0.0))
            else:
                placed.append(best_local)

        score = sum(p[3] for p in placed)
        if score > best_score:
            best_score = score
            best = list(placed)

    return best if best is not None else [(0.5, 0.5, 0.0, 0.0)] * n


def _polish(squares, iters=200):
    n = len(squares)
    squares = [list(s) for s in squares]

    def total():
        return sum(s[3] for s in squares)

    def valid(i):
        cx, cy, ang, s = squares[i]
        if s < 0:
            return False
        if not _inside(cx, cy, ang, s):
            return False
        for j in range(n):
            if i == j:
                continue
            if _overlap(squares[i], squares[j]):
                return False
        return True

    cur = total()
    step = 0.02
    random.seed(999)
    for it in range(iters):
        improved = False
        for i in range(n):
            if squares[i][3] <= 1e-15:
                continue
            old = list(squares[i])
            for _ in range(6):
                cx = min(1.0, max(0.0, old[0] + random.uniform(-step, step)))
                cy = min(1.0, max(0.0, old[1] + random.uniform(-step, step)))
                ang = old[2] + random.uniform(-step * 2, step * 2)
                s = old[3] * (1.0 + random.uniform(-step, step))
                if s <= 0:
                    continue
                squares[i] = [cx, cy, ang, s]
                if valid(i):
                    nt = total()
                    if nt > cur + 1e-14:
                        cur = nt
                        old = list(squares[i])
                        improved = True
                    else:
                        squares[i] = old
                else:
                    squares[i] = old
        # Also try increasing size if possible
        for i in range(n):
            if squares[i][3] <= 1e-15:
                continue
            old = list(squares[i])
            for mult in (1.005, 1.01, 1.02):
                squares[i] = [old[0], old[1], old[2], old[3] * mult]
                if valid(i):
                    nt = total()
                    if nt > cur + 1e-14:
                        cur = nt
                        old = list(squares[i])
                        improved = True
                    else:
                        squares[i] = old
                else:
                    squares[i] = old
        if not improved:
            step *= 0.7
            if step < 1e-4:
                break
    return [tuple(s) for s in squares]


def _grid_solution(n):
    k = math.isqrt(n)
    side = 1.0 / k if k > 0 else 1.0
    result = []
    for i in range(k):
        for j in range(k):
            result.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    result += [(0.5, 0.5, 0.0, 0.0)] * (n - len(result))
    return result[:n]


def solve(n):
    if n <= 0:
        return []
    if n > 200:
        # For very large n, greedy is too slow; fall back to grid variants.
        candidates = [_grid_solution(n)]
        # Try to improve by slightly scaling/shrinking to make room for all squares.
        k = math.isqrt(n)
        base = 1.0 / k
        for shrink in (0.999, 0.995, 0.99):
            side = base * shrink
            result = []
            # center grid
            off = (1.0 - k * side) * 0.5
            for i in range(k):
                for j in range(k):
                    result.append((off + (i + 0.5) * side, off + (j + 0.5) * side, 0.0, side))
            extra = n - len(result)
            if extra > 0:
                # add tiny squares in gaps
                for _ in range(extra):
                    result.append((0.5, 0.5, 0.0, 0.0))
            result = result[:n]
            candidates.append(result)
        # pick best valid one
        best = candidates[0]
        best_s = sum(s[3] for s in best)
        for cand in candidates[1:]:
            s = sum(x[3] for x in cand)
            if s > best_s:
                best_s = s
                best = cand
        return best

    # Try greedy
    greedy = _greedy(n)
    # Compare with grid
    grid = _grid_solution(n)
    gs = sum(s[3] for s in greedy)
    grs = sum(s[3] for s in grid)
    if gs >= grs:
        result = _polish(greedy, iters=max(50, 300 // max(1, n)))
    else:
        result = _polish(grid, iters=max(50, 300 // max(1, n)))
    # Fallback if polish broke validity
    total = sum(s[3] for s in result)
    if total <= 0:
        return _grid_solution(n)
    # ensure validity
    for i in range(len(result)):
        for j in range(i + 1, len(result)):
            if _overlap(result[i], result[j]):
                return _grid_solution(n)
        if not _inside(result[i][0], result[i][1], result[i][2], result[i][3]):
            return _grid_solution(n)
    return result
