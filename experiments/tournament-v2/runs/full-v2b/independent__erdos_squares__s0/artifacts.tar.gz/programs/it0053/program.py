import math
import random
import numpy as np

# We'll implement a robust heuristic packer.

def clamp(v, lo=0.0, hi=1.0):
    return max(lo, min(hi, v))

def corners_of(cx, cy, ang, s):
    # ang in turns
    th = 2.0 * math.pi * ang
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + c * dx - sn * dy
        y = cy + sn * dx + c * dy
        pts.append((x, y))
    return pts

def bbox(cx, cy, ang, s):
    pts = corners_of(cx, cy, ang, s)
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)

def inside_unit(cx, cy, ang, s):
    if s <= 0:
        return True
    x0, y0, x1, y1 = bbox(cx, cy, ang, s)
    return x0 >= -1e-12 and y0 >= -1e-12 and x1 <= 1+1e-12 and y1 <= 1+1e-12

# --- overlap test between two squares using SAT ---
def project(pts, axis):
    d = axis[0]*pts[0][0] + axis[1]*pts[0][1]
    mn = mx = d
    for p in pts[1:]:
        d = axis[0]*p[0] + axis[1]*p[1]
        if d < mn: mn = d
        if d > mx: mx = d
    return mn, mx

def overlap_area_approx(a, b):
    # returns True if interiors overlap (strictly). Touching is allowed.
    (cx1, cy1, a1, s1) = a
    (cx2, cy2, a2, s2) = b
    if s1 <= 0 or s2 <= 0:
        return False
    P = corners_of(cx1, cy1, a1, s1)
    Q = corners_of(cx2, cy2, a2, s2)
    # SAT with axes = normals of both squares
    axes = []
    for pts in (P, Q):
        for i in range(4):
            x1, y1 = pts[i]
            x2, y2 = pts[(i+1) % 4]
            ex, ey = x2 - x1, y2 - y1
            n = (-ey, ex)
            L = math.hypot(*n)
            if L > 1e-15:
                axes.append((n[0]/L, n[1]/L))
    for ax in axes:
        mn1, mx1 = project(P, ax)
        mn2, mx2 = project(Q, ax)
        if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
            return False
    return True

def collision_penalty(squares):
    pen = 0.0
    n = len(squares)
    for i in range(n):
        if squares[i][3] <= 0: continue
        for j in range(i+1, n):
            if squares[j][3] <= 0: continue
            if overlap_area_approx(squares[i], squares[j]):
                # approximate magnitude: sum of sides overlap
                pen += (squares[i][3] + squares[j][3])
    return pen

def boundary_penalty(cx, cy, ang, s):
    if s <= 0:
        return 0.0
    x0, y0, x1, y1 = bbox(cx, cy, ang, s)
    p = 0.0
    if x0 < 0: p += -x0
    if y0 < 0: p += -y0
    if x1 > 1: p += x1 - 1
    if y1 > 1: p += y1 - 1
    return p * 5.0

def total_energy(squares, target_sides):
    e = 0.0
    for i, sq in enumerate(squares):
        cx, cy, ang, s = sq
        e += boundary_penalty(cx, cy, ang, s)**2
        e += (target_sides[i] - s)**2 * 2.0
    e += collision_penalty(squares) * 10.0
    return e

# ---------- initial layouts ----------

def grid_layout(n):
    # largest k x k grid, distribute remainder as small squares placed in gaps
    k = max(1, int(math.floor(math.sqrt(n))))
    while k*k > n:
        k -= 1
    side = 1.0 / k
    sq = []
    for i in range(k):
        for j in range(k):
            sq.append([(i+0.5)*side, (j+0.5)*side, 0.0, side])
    # fill remaining with tiny squares in centers (will relax)
    extra = n - len(sq)
    # put them near center with small size
    for t in range(extra):
        r = 0.3 + 0.1 * ((t*37) % 7)/7.0
        ang = ((t*53) % 17)/17.0
        sq.append([0.5 + 0.1*math.cos(t), 0.5 + 0.1*math.sin(t*1.3), ang, 0.02])
    return sq[:n]

def golden_layout(n):
    # a spiral-ish layout of equal squares then relax
    side = 1.0 / math.sqrt(n)
    sq = []
    for i in range(n):
        # sunflower / spiral
        r = 0.5 * math.sqrt((i+0.5)/n) * 0.9
        theta = i * 2.399963229728653
        cx = 0.5 + r * math.cos(theta)
        cy = 0.5 + r * math.sin(theta)
        cx = clamp(cx, side*0.5, 1-side*0.5)
        cy = clamp(cy, side*0.5, 1-side*0.5)
        sq.append([cx, cy, 0.0, side])
    return sq

def strip_layout(n):
    # rows of squares, each row height chosen so total width fills 1
    sq = []
    remaining = n
    y = 0.0
    rows = []
    # try a few row counts
    best = None
    for R in range(1, n+1):
        counts = [n//R + (1 if i < n % R else 0) for i in range(R)]
        counts = [c for c in counts if c > 0]
        if sum(counts) != n: continue
        # equal height squares in each row: h_i = 1/len(counts) ... but need sum of heights =1
        # if we make each row square size s_i and row has c_i columns, width c_i*s_i<=1, height s_i
        # want total height 1
        # try s_i = 1/R uniformly
        s = 1.0 / R
        ok = True
        for c in counts:
            if c * s > 1 + 1e-9:
                ok = False
                break
        if not ok: continue
        # feasible
        if best is None or R < best[0]:
            best = (R, counts, s)
    if best is None:
        return grid_layout(n)
    R, counts, s = best
    y = 0.0
    for c in counts:
        row_s = s
        # center row
        width = c * row_s
        x = (1.0 - width)/2.0 + row_s/2.0
        for j in range(c):
            sq.append([x + j*row_s, y + row_s/2.0, 0.0, row_s])
        y += row_s
    return sq[:n]

# ---------- relaxation ----------

def relax(squares, iterations=3000, seed=0):
    rng = random.Random(seed)
    n = len(squares)
    # target: try to grow all squares as much as possible
    # We'll use a simple projected gradient / random perturbation with acceptance.
    sq = [list(s) for s in squares]
    # normalize: clamp into unit
    for s in sq:
        s[0] = clamp(s[0], 0, 1)
        s[1] = clamp(s[1], 0, 1)
        if s[3] > 0:
            # shrink to fit initially
            while not inside_unit(s[0], s[1], s[2], s[3]) and s[3] > 1e-6:
                s[3] *= 0.99
        if s[3] < 0: s[3] = 0.0

    def energy(sq):
        # sum of sides (we want to maximize) -> minimize negative
        # plus penalties
        e = 0.0
        for s in sq:
            e -= s[3]
        # overlap penalty
        for i in range(n):
            if sq[i][3] <= 0: continue
            for j in range(i+1, n):
                if sq[j][3] <= 0: continue
                if overlap_area_approx(sq[i], sq[j]):
                    e += 50.0 * (sq[i][3] + sq[j][3])
        # boundary
        for s in sq:
            if s[3] <= 0: continue
            x0,y0,x1,y1 = bbox(s[0],s[1],s[2],s[3])
            if x0 < 0: e += 200*(-x0)**2
            if y0 < 0: e += 200*(-y0)**2
            if x1 > 1: e += 200*(x1-1)**2
            if y1 > 1: e += 200*(y1-1)**2
        return e

    cur_e = energy(sq)
    T = 0.05
    cool = 0.9995
    best = [list(s) for s in sq]
    best_e = cur_e
    for it in range(iterations):
        # pick a random square and perturb
        idx = rng.randrange(n)
        old = list(sq[idx])
        # random move type
        move = rng.random()
        if move < 0.4:
            # try grow
            if sq[idx][3] > 0:
                sq[idx][3] *= (1 + 0.05*rng.random())
            else:
                sq[idx][3] = 0.01 + 0.02*rng.random()
        elif move < 0.7:
            # move center
            sq[idx][0] += (rng.random()-0.5)*0.05
            sq[idx][1] += (rng.random()-0.5)*0.05
        elif move < 0.85:
            # rotate
            sq[idx][2] += (rng.random()-0.5)*0.1
        else:
            # shrink slightly
            sq[idx][3] *= (1 - 0.05*rng.random())
        # clamp
        sq[idx][0] = clamp(sq[idx][0], 0, 1)
        sq[idx][1] = clamp(sq[idx][1], 0, 1)
        if sq[idx][3] < 0: sq[idx][3] = 0.0
        if sq[idx][3] > 1.5: sq[idx][3] = 1.5
        new_e = energy(sq)
        if new_e < cur_e or rng.random() < math.exp(-(new_e-cur_e)/max(T,1e-9)):
            cur_e = new_e
            if new_e < best_e:
                best_e = new_e
                best = [list(s) for s in sq]
        else:
            sq[idx] = old
        T *= cool
        if T < 1e-4: T = 1e-4

    # final cleanup: clamp and shrink any overlapping
    for it in range(200):
        changed = False
        for i in range(n):
            if best[i][3] <= 0: continue
            for j in range(i+1, n):
                if best[j][3] <= 0: continue
                if overlap_area_approx(best[i], best[j]):
                    # shrink both
                    best[i][3] *= 0.95
                    best[j][3] *= 0.95
                    changed = True
        if not changed:
            break

    # ensure inside
    for s in best:
        if s[3] > 0:
            while not inside_unit(s[0], s[1], s[2], s[3]) and s[3] > 1e-8:
                s[3] *= 0.99
    return [(s[0], s[1], s[2], max(0.0, s[3])) for s in best]

# ---------- main ----------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    candidates = []
    # strategy pool
    candidates.append(grid_layout(n))
    if n > 1:
        candidates.append(strip_layout(n))
    candidates.append(golden_layout(n))
    # rotated grid variants by angle offset at init (will relax)
    # also try random starts
    rng = random.Random(12345)
    for _ in range(2):
        sq = []
        side = 1.0 / math.sqrt(n)
        for i in range(n):
            cx = rng.random()
            cy = rng.random()
            ang = rng.random()
            s = side * (0.5 + 0.5*rng.random())
            # clamp
            sq.append([clamp(cx,s/2,1-s/2), clamp(cy,s/2,1-s/2), ang, s])
        candidates.append(sq)

    best_sum = -1
    best_sq = None
    for ci, cand in enumerate(candidates):
        # shrink all to be safe initially
        cand2 = [list(s) for s in cand]
        for s in cand2:
            s[0] = clamp(s[0], 0, 1)
            s[1] = clamp(s[1], 0, 1)
            if s[3] > 0:
                tries = 0
                while not inside_unit(s[0], s[1], s[2], s[3]) and s[3] > 1e-9 and tries < 100:
                    s[3] *= 0.98
                    tries += 1
        # relax
        res = relax(cand2, iterations=2500 + 100*min(n,20), seed=ci*17+3)
        # compute sum and validity
        ok = True
        total = 0.0
        for s in res:
            if s[3] > 0 and not inside_unit(s[0], s[1], s[2], s[3]):
                ok = False
                break
            total += s[3]
        if ok:
            # check overlaps
            for i in range(n):
                if res[i][3] <= 0: continue
                for j in range(i+1, n):
                    if res[j][3] <= 0: continue
                    if overlap_area_approx(res[i], res[j]):
                        ok = False
                        break
                if not ok: break
        if ok and total > best_sum:
            best_sum = total
            best_sq = res

    if best_sq is None:
        # fallback grid
        best_sq = [(s[0], s[1], s[2], s[3]) for s in grid_layout(n)]

    # final safety: shrink until valid
    result = [list(s) for s in best_sq]
    for _ in range(100):
        bad = False
        for i in range(n):
            if result[i][3] <= 0: continue
            if not inside_unit(result[i][0], result[i][1], result[i][2], result[i][3]):
                result[i][3] *= 0.95
                bad = True
            for j in range(i+1, n):
                if result[j][3] <= 0: continue
                if overlap_area_approx(result[i], result[j]):
                    result[i][3] *= 0.95
                    result[j][3] *= 0.95
                    bad = True
        if not bad:
            break

    out = []
    for s in result:
        out.append((float(clamp(s[0],0,1)), float(clamp(s[1],0,1)), float(s[2] % 1.0), float(max(0.0, s[3]))))
    # pad
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
