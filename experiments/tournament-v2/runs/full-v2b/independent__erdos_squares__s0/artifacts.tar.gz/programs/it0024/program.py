import math
import random

def _overlap(s1, s2):
    cx1, cy1, a1, s1_ = s1
    cx2, cy2, a2, s2_ = s2
    if s1_ <= 1e-12 or s2_ <= 1e-12:
        return False
    # Use separating axis theorem for two rotated squares.
    # Each square has 4 axes (2 unique per square but use all for safety).
    axes = []
    for ang, side in ((a1, s1_), (a2, s2_)):
        theta = ang * 2 * math.pi
        c, s = math.cos(theta), math.sin(theta)
        axes.append((c, s))
        axes.append((-s, c))
    # projection radius of a square on axis (nx,ny)
    def proj(sq):
        ca, sa, side = sq
        theta = ca * 2 * math.pi
        c, s = math.cos(theta), math.sin(theta)
        # corners relative
        h = side / 2.0
        pts = [(h, h), (-h, h), (-h, -h), (h, -h)]
        out = []
        for (px, py) in pts:
            rx = px * c - py * s
            ry = px * s + py * c
            out.append((rx, ry))
        return out
    p1 = proj((cx1, cy1, a1, s1_))
    p2 = proj((cx2, cy2, a2, s2_))
    for (nx, ny) in axes:
        # normalise
        ln = math.hypot(nx, ny)
        if ln < 1e-15:
            continue
        nx /= ln
        ny /= ln
        min1 = min(px * nx + py * ny for (px, py) in p1)
        max1 = max(px * nx + py * ny for (px, py) in p1)
        min2 = min(px * nx + py * ny for (px, py) in p2)
        max2 = max(px * nx + py * ny for (px, py) in p2)
        if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
            return False
    return True

def _inside(cx, cy, ang, side):
    theta = ang * 2 * math.pi
    c, s = math.cos(theta), math.sin(theta)
    h = side / 2.0
    for (px, py) in [(h, h), (-h, h), (-h, -h), (h, -h)]:
        rx = px * c - py * s + cx
        ry = px * s + py * c + cy
        if rx < -1e-12 or rx > 1 + 1e-12 or ry < -1e-12 or ry > 1 + 1e-12:
            return False
    return True

def solve(n):
    if n <= 0:
        return []
    # Grid of axis-aligned squares: find largest k with k*k <= n
    k = int(math.isqrt(n))
    # If k*k < n, we might still fit extra small rotated squares.
    squares = []
    if k > 0:
        side = 1.0 / k
        for i in range(k):
            for j in range(k):
                squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # Fill remaining with greedy rotated squares in gaps
    remaining = n - len(squares)
    # We'll do a grid search for each new square: choose largest side that fits
    # in some empty spot. To keep time reasonable, scan candidate centers on a grid.
    tried = set()
    for _ in range(remaining):
        best = None
        # try multiple angles
        for ang in [0.0, 0.125, 0.25, 0.375, 0.0625, 0.1875, 0.3125, 0.4375, 0.5]:
            # candidate centers: perturb grid
            for gx in range(0, 21):
                for gy in range(0, 21):
                    cx = gx / 20.0
                    cy = gy / 20.0
                    # binary search max side at this angle/center
                    lo, hi = 0.0, 1.0
                    for _ in range(20):
                        mid = (lo + hi) / 2.0
                        cand = (cx, cy, ang, mid)
                        if _inside(cx, cy, ang, mid):
                            ok = True
                            for sq in squares:
                                if _overlap(cand, sq):
                                    ok = False
                                    break
                            if ok:
                                lo = mid
                            else:
                                hi = mid
                        else:
                            hi = mid
                    if lo > 1e-6:
                        if best is None or lo > best[3]:
                            best = (cx, cy, ang, lo)
        if best is None:
            squares.append((0.5, 0.5, 0.0, 0.0))
        else:
            squares.append(best)
    return squares
