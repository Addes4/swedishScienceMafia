import math
import random
import time


def _overlap_ok(a, b, eps=1e-9):
    # Convert to corner points and use SAT for rotated squares.
    x1, y1, t1, s1 = a
    x2, y2, t2, s2 = b
    if s1 <= 0 or s2 <= 0:
        return True
    a1 = t1 * 2 * math.pi
    a2 = t2 * 2 * math.pi
    c1, s_1 = math.cos(a1), math.sin(a1)
    c2, s_2 = math.cos(a2), math.sin(a2)

    def pts(x, y, c, s, h):
        # half side h, square centered (x,y), rotated
        ux, uy = c * h, s * h
        vx, vy = -s * h, c * h
        return [(x + ux + vx, y + uy + vy), (x + ux - vx, y + uy - vy),
                (x - ux - vx, y - uy - vy), (x - ux + vx, y - uy + vy)]

    p1 = pts(x1, y1, c1, s_1, s1 * 0.5)
    p2 = pts(x2, y2, c2, s_2, s2 * 0.5)
    axes = [(c1, s_1), (-s_1, c1), (c2, s_2), (-s_2, c2)]
    for ax, ay in axes:
        p1p = [px * ax + py * ay for px, py in p1]
        p2p = [px * ax + py * ay for px, py in p2]
        if max(p1p) <= min(p2p) + eps or max(p2p) <= min(p1p) + eps:
            return True
    return False


def _inside(x, y, t, s):
    if s <= 0:
        return True
    a = t * 2 * math.pi
    c, sn = math.cos(a), math.sin(a)
    h = s * 0.5
    for sx in (-1, 1):
        for sy in (-1, 1):
            dx = sx * h * c - sy * h * sn
            dy = sx * h * sn + sy * h * c
            if x + dx < -1e-9 or x + dx > 1 + 1e-9 or y + dy < -1e-9 or y + dy > 1 + 1e-9:
                return False
    return True


def _valid(x, y, t, s, placed):
    if not _inside(x, y, t, s):
        return False
    for p in placed:
        if not _overlap_ok((x, y, t, s), p):
            return False
    return True


def _max_side_at(x, y, t, placed, hi):
    # binary search max side <= hi that fits at (x,y,t)
    lo = 0.0
    if not _valid(x, y, t, 1e-12, placed):
        return 0.0
    for _ in range(24):
        mid = (lo + hi) * 0.5
        if _valid(x, y, t, mid, placed):
            lo = mid
        else:
            hi = mid
    return lo


def solve(n):
    if n <= 0:
        return []
    start = time.time()
    limit = 55.0

    # First greedy construction: repeatedly place the largest square possible.
    placed = []
    remaining = n
    # grid of positions for size placement
    # try corners/edges/center and random points
    attempts = []
    side0 = 1.0
    # Greedy largest-first until time or no room.
    while remaining > 0 and time.time() - start < limit * 0.5:
        best = None
        best_s = -1.0
        # candidate centers on a grid
        best_s, best_c = _greedy_one(placed, remaining, start, limit * 0.5)
        if best_s is None or best_s <= 1e-12:
            break
        placed.append(best_s)
        remaining -= 1

    # fill remaining with tiny/zero squares near corners to avoid overlap
    while remaining > 0:
        placed.append((0.0, 0.0, 0.0, 0.0))
        remaining -= 1

    # Local improvement: try small perturbations to improve total side.
    if time.time() - start < limit:
        placed = _refine(placed, start, limit)

    # Ensure exact n
    if len(placed) > n:
        placed = placed[:n]
    while len(placed) < n:
        placed.append((0.5, 0.5, 0.0, 0.0))
    return placed


def _greedy_one(placed, remaining, start, tlimit):
    best_s = None
    best_c = None
    # Candidate centers: grid + random
    cands = []
    g = 6
    for i in range(g + 1):
        for j in range(g + 1):
            cands.append((i / g, j / g))
    rng = random.Random(12345)
    for _ in range(400):
        cands.append((rng.random(), rng.random()))
    angles = [0.0, 0.25, 0.5, 0.75, 0.125, 0.375]
    for (x, y) in cands:
        if time.time() - start > tlimit:
            break
        for t in angles:
            s = _max_side_at(x, y, t, placed, 1.0)
            if best_s is None or s > best_s:
                best_s = s
                best_c = (x, y, t, s)
    return best_s, best_c


def _refine(placed, start, limit):
    rng = random.Random(987654)
    placed = [list(p) for p in placed]

    def total(ps):
        return sum(p[3] for p in ps)

    cur_val = total(placed)
    best = [list(p) for p in placed]
    best_val = cur_val

    while time.time() - start < limit:
        idx = rng.randrange(len(placed))
        x, y, t, s = placed[idx]
        # random perturbation
        nx = x + rng.gauss(0, 0.02)
        ny = y + rng.gauss(0, 0.02)
        nt = t + rng.gauss(0, 0.02)
        nt = nt % 1.0
        nx = min(max(nx, 0.0), 1.0)
        ny = min(max(ny, 0.0), 1.0)

        # Try to grow or maintain
        others = [tuple(p) for k2, p in enumerate(placed) if k2 != idx]
        # remove current, try place with potentially larger size
        old = placed[idx]
        placed[idx] = None
        # binary search max side at new pos
        ns = _max_side_at(nx, ny, nt, others, 1.0)
        placed[idx] = old

        if ns > s + 1e-12:
            placed[idx] = [nx, ny, nt, ns]
            cur_val = total(placed)
            if cur_val > best_val:
                best_val = cur_val
                best = [list(p) for p in placed]
        elif rng.random() < 0.05:
            # random move even if not better
            placed[idx] = [nx, ny, nt, ns]
            cur_val = total(placed)

    return [tuple(p) for p in best]
