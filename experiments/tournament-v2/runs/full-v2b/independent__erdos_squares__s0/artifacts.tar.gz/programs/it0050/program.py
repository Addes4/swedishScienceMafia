import math
import random
import numpy as np
from scipy.optimize import minimize


def _overlap_area(a, b):
    # Use separating axis theorem for convex polygons (squares)
    # Return True if interiors overlap (positive area intersection)
    # Convert to polygons
    def poly(cx, cy, ang, s):
        ang = ang * 2 * math.pi
        ca, sa = math.cos(ang), math.sin(ang)
        h = s / 2.0
        pts = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            x = cx + dx * ca - dy * sa
            y = cy + dx * sa + dy * ca
            pts.append((x, y))
        return pts

    pa = poly(*a)
    pb = poly(*b)
    # SAT
    def axes(p):
        ax = []
        for i in range(len(p)):
            x1, y1 = p[i]
            x2, y2 = p[(i + 1) % len(p)]
            ex, ey = x2 - x1, y2 - y1
            n = math.hypot(ex, ey)
            if n < 1e-12:
                continue
            ax.append((-ey / n, ex / n))
        return ax

    for axis in axes(pa) + axes(pb):
        ax, ay = axis
        proj_a = [x * ax + y * ay for x, y in pa]
        proj_b = [x * ax + y * ay for x, y in pb]
        if max(proj_a) <= min(proj_b) + 1e-11 or max(proj_b) <= min(proj_a) + 1e-11:
            return False
    return True


def _total_penalty(state, n):
    # state: array of 4*n (cx, cy, ang, s)
    pen = 0.0
    squ = []
    for i in range(n):
        cx, cy, ang, s = state[4 * i:4 * i + 4]
        squ.append((cx, cy, ang, s))
    # boundary penalties
    for cx, cy, ang, s in squ:
        # approximate bounding box
        t = abs(math.sin(ang * 2 * math.pi)) + abs(math.cos(ang * 2 * math.pi))
        r = s * t / 2.0 * 1.4142
        if cx - r < -1e-9:
            pen += (r - cx) ** 2
        if cx + r > 1 + 1e-9:
            pen += (cx + r - 1) ** 2
        if cy - r < -1e-9:
            pen += (r - cy) ** 2
        if cy + r > 1 + 1e-9:
            pen += (cy + r - 1) ** 2
    return pen


def _objective(state, n, w_overlap=1e6, w_bound=1e6):
    total_side = 0.0
    squ = []
    for i in range(n):
        cx, cy, ang, s = state[4 * i:4 * i + 4]
        total_side += s
        squ.append((cx, cy, ang, s))
    pen = 0.0
    # boundary penalties: exact via polygon vertices
    for cx, cy, ang, s in squ:
        angr = ang * 2 * math.pi
        ca, sa = math.cos(angr), math.sin(angr)
        h = s / 2.0
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            x = cx + dx * ca - dy * sa
            y = cy + dx * sa + dy * ca
            if x < -1e-9:
                pen += (-x) ** 2
            if x > 1 + 1e-9:
                pen += (x - 1) ** 2
            if y < -1e-9:
                pen += (-y) ** 2
            if y > 1 + 1e-9:
                pen += (y - 1) ** 2
    # overlap penalty (sample pairwise, but only if boxes might overlap)
    for i in range(n):
        cx1, cy1, ang1, s1 = squ[i]
        if s1 <= 1e-12:
            continue
        r1 = s1 * 0.71
        for j in range(i + 1, n):
            cx2, cy2, ang2, s2 = squ[j]
            if s2 <= 1e-12:
                continue
            if abs(cx1 - cx2) > r1 + s2 * 0.71 + 0.05:
                continue
            if abs(cy1 - cy2) > r1 + s2 * 0.71 + 0.05:
                continue
            # SAT overlap amount
            ov = _overlap_amount(squ[i], squ[j])
            if ov > 0:
                pen += ov * ov
    return -total_side + w_overlap * pen + w_bound * pen


def _overlap_amount(a, b):
    # return positive overlap area estimate via SAT
    def poly(cx, cy, ang, s):
        angr = ang * 2 * math.pi
        ca, sa = math.cos(angr), math.sin(angr)
        h = s / 2.0
        pts = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            x = cx + dx * ca - dy * sa
            y = cy + dx * sa + dy * ca
            pts.append((x, y))
        return pts

    pa = poly(*a)
    pb = poly(*b)

    def axes(p):
        ax = []
        for i in range(len(p)):
            x1, y1 = p[i]
            x2, y2 = p[(i + 1) % len(p)]
            ex, ey = x2 - x1, y2 - y1
            n = math.hypot(ex, ey)
            if n < 1e-12:
                continue
            ax.append((-ey / n, ex / n))
        return ax

    min_overlap = None
    for axis in axes(pa) + axes(pb):
        ax, ay = axis
        proj_a = [x * ax + y * ay for x, y in pa]
        proj_b = [x * ax + y * ay for x, y in pb]
        o = min(max(proj_a), max(proj_b)) - max(min(proj_a), min(proj_b))
        if o <= 0:
            return 0.0
        if min_overlap is None or o < min_overlap:
            min_overlap = o
    return min_overlap if min_overlap else 0.0


def _initial_grid(n):
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # extra squares: distribute as slightly smaller on edges
    extra = n - k * k
    for idx in range(extra):
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_known_layouts(n):
    """Generate several candidate starting layouts, pick best by sum with no overlap."""
    candidates = []

    # Layout 1: grid
    candidates.append(_initial_grid(n))

    # Layout 2: grid with larger k by allowing smaller pieces
    for k in range(max(1, math.isqrt(n) - 2), math.isqrt(n) + 3):
        if k <= 0:
            continue
        # k*k grid plus extras
        side = 1.0 / k
        layout = []
        for i in range(k):
            for j in range(k):
                layout.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        # add extras as tiny squares at random positions
        for idx in range(n - len(layout)):
            layout.append((0.5 + 0.01 * idx, 0.5, 0.0, 0.0))
        if len(layout) >= n:
            candidates.append(layout[:n])

    # Layout 3: rows of equal squares
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        if rows == 0:
            continue
        side = 1.0 / max(cols, rows)
        layout = []
        for i in range(cols):
            for j in range(rows):
                if len(layout) < n:
                    layout.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        while len(layout) < n:
            layout.append((0.5, 0.5, 0.0, 0.0))
        candidates.append(layout)

    return candidates


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    # Try initial candidates
    candidates = _best_known_layouts(n)

    # Also try a fine-tuned grid arrangement
    k = math.isqrt(n)
    base_side = 1.0 / k
    layout = _initial_grid(n)
    candidates.append(layout)

    # Try perturbed versions of the grid
    random.seed(12345)
    for _ in range(min(5, n)):
        cand = [list(sq) for sq in layout]
        for sq in cand:
            sq[0] += random.uniform(-0.005, 0.005)
            sq[1] += random.uniform(-0.005, 0.005)
            sq[2] += random.uniform(-0.01, 0.01)
        candidates.append([tuple(sq) for sq in cand])

    # Optimize each candidate
    for cand in candidates:
        state = np.array([v for sq in cand for v in sq], dtype=float)

        # simple local search without scipy for speed
        def total_side_of(st):
            return sum(st[4 * i + 3] for i in range(n))

        def compute_pen(stb):
            p = 0.0
            squ = [(stb[4 * i], stb[4 * i + 1], stb[4 * i + 2], stb[4 * i + 3]) for i in range(n)]
            for cx, cy, ang, s in squ:
                angr = ang * 2 * math.pi
                ca, sa = math.cos(angr), math.sin(angr)
                h = s / 2.0
                for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
                    x = cx + dx * ca - dy * sa
                    y = cy + dx * sa + dy * ca
                    if x < -1e-9:
                        p += (-x) ** 2
                    if x > 1 + 1e-9:
                        p += (x - 1) ** 2
                    if y < -1e-9:
                        p += (-y) ** 2
                    if y > 1 + 1e-9:
                        p += (y - 1) ** 2
            for i in range(n):
                s1 = squ[i][3]
                if s1 <= 1e-13:
                    continue
                for j in range(i + 1, n):
                    s2 = squ[j][3]
                    if s2 <= 1e-13:
                        continue
                    cx1, cy1, _, _ = squ[i]
                    cx2, cy2, _, _ = squ[j]
                    if abs(cx1 - cx2) > s1 * 0.71 + s2 * 0.71 + 1e-9:
                        continue
                    if abs(cy1 - cy2) > s1 * 0.71 + s2 * 0.71 + 1e-9:
                        continue
                    ov = _overlap_amount(squ[i], squ[j])
                    if ov > 0:
                        p += ov * ov
            return p

        # Simple iterative improvement
        cur = state.copy()
        cur_pen = compute_pen(cur)
        cur_sum = total_side_of(cur)

        step = 0.01
        for it in range(200):
            improved = False
            idx = random.randrange(n)
            for param in range(4):
                k_param = 4 * idx + param
                old = cur[k_param]
                for delta in (step, -step):
                    cur[k_param] = old + delta
                    new_pen = compute_pen(cur)
                    new_sum = total_side_of(cur)
                    # accept if reduces penalty and non-decreasing sum, or improves total
                    if new_pen < cur_pen - 1e-12 or (new_pen <= cur_pen + 1e-12 and new_sum > cur_sum + 1e-12):
                        cur_pen = new_pen
                        cur_sum = new_sum
                        improved = True
                        break
                    else:
                        cur[k_param] = old
                else:
                    cur[k_param] = old
            if not improved:
                step *= 0.5
                if step < 1e-6:
                    break

        # Final adjustment: ensure validity, shrink if needed
        final_squares = [(cur[4 * i], cur[4 * i + 1], cur[4 * i + 2], cur[4 * i + 3]) for i in range(n)]
        final_squares = _fix_validity(final_squares)
        total = sum(sq[3] for sq in final_squares)

        if total > best_sum:
            best_sum = total
            best = final_squares

    return best


def _fix_validity(squares):
    # Ensure all squares inside [0,1]^2 and no overlapping interiors.
    # First clamp centers
    sq = [list(s) for s in squares]
    n = len(sq)
    for s in sq:
        s[3] = max(0.0, min(1.0, s[3]))
        s[0] = max(0.0, min(1.0, s[0]))
        s[1] = max(0.0, min(1.0, s[1]))

    # Clamp inside boundaries by shrinking/moving
    for _ in range(3):
        for s in sq:
            cx, cy, ang, side = s
            angr = ang * 2 * math.pi
            ca, sa = math.cos(angr), math.sin(angr)
            h = side / 2.0
            minx = miny = float('inf')
            maxx = maxy = -float('inf')
            for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
                x = cx + dx * ca - dy * sa
                y = cy + dx * sa + dy * ca
                minx = min(minx, x)
                maxx = max(maxx, x)
                miny = min(miny, y)
                maxy = max(maxy, y)
            if minx < 0:
                s[0] -= minx
            if maxx > 1:
                s[0] -= (maxx - 1)
            if miny < 0:
                s[1] -= miny
            if maxy > 1:
                s[1] -= (maxy - 1)

    # Resolve overlaps by shrinking smaller square
    for i in range(n):
        for j in range(i + 1, n):
            s1 = sq[i]
            s2 = sq[j]
            if s1[3] <= 1e-12 or s2[3] <= 1e-12:
                continue
            ov = _overlap_amount(tuple(s1), tuple(s2))
            if ov > 0:
                # shrink both slightly
                s1[3] *= 0.98
                s2[3] *= 0.98
                # reposition to separate
                cx1, cy1 = s1[0], s1[1]
                cx2, cy2 = s2[0], s2[1]
                d = math.hypot(cx1 - cx2, cy1 - cy2)
                if d < 1e-12:
                    cx2 += 0.001
                # move apart
                for _ in range(20):
                    if not _overlap_amount(tuple(s1), tuple(s2)) > 0:
                        break
                    cx1, cy1 = s1[0], s1[1]
                    cx2, cy2 = s2[0], s2[1]
                    d = math.hypot(cx1 - cx2, cy1 - cy2) + 1e-12
                    ux, uy = (cx1 - cx2) / d, (cy1 - cy2) / d
                    s1[0] += ux * 0.001
                    s1[1] += uy * 0.001
                    s2[0] -= ux * 0.001
                    s2[1] -= uy * 0.001

    # clamp centers again
    for s in sq:
        s[0] = max(0.0, min(1.0, s[0]))
        s[1] = max(0.0, min(1.0, s[1]))

    # final clamping
    for s in sq:
        s[3] = max(0.0, min(1.0, s[3]))

    return [tuple(s) for s in sq]
