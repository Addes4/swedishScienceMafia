import math
import random
import time
import numpy as np
from scipy.optimize import minimize

# Disjointness check for rotated squares using SAT (Separating Axis Theorem)
def _overlap(s1, s2):
    cx1, cy1, a1, s1_ = s1
    cx2, cy2, a2, s2_ = s2
    if s1_ <= 1e-12 or s2_ <= 1e-12:
        return False
    # half side
    h1 = s1_ * 0.5
    h2 = s2_ * 0.5
    # angle in radians
    th1 = a1 * 2.0 * math.pi
    th2 = a2 * 2.0 * math.pi
    # corners of rectangle 1 (square)
    c1, s1v = math.cos(th1), math.sin(th1)
    c2, s2v = math.cos(th2), math.sin(th2)
    # axes
    axes = [(c1, s1v), (-s1v, c1), (c2, s2v), (-s2v, c2)]
    # project both squares onto each axis
    for ax, ay in axes:
        # square 1 projection: center dot axis ± half*(|c1*ax+s1v*ay| + |-s1v*ax+c1*ay|)
        p1 = cx1 * ax + cy1 * ay
        r1 = h1 * (abs(c1 * ax + s1v * ay) + abs(-s1v * ax + c1 * ay))
        p2 = cx2 * ax + cy2 * ay
        r2 = h2 * (abs(c2 * ax + s2v * ay) + abs(-s2v * ax + c2 * ay))
        if p1 + r1 <= p2 - r2 - 1e-10 or p2 + r2 <= p1 - r1 - 1e-10:
            return False
    return True

def _check_all(squares):
    m = len(squares)
    for i in range(m):
        for j in range(i+1, m):
            if _overlap(squares[i], squares[j]):
                return False
        # boundary check: all corners inside [0,1]^2
        cx, cy, a, s = squares[i]
        if s <= 1e-12:
            continue
        h = s * 0.5
        th = a * 2.0 * math.pi
        c, sn = math.cos(th), math.sin(th)
        for sx, sy in [(-h, -h), (h, -h), (h, h), (-h, h)]:
            px = cx + sx * c - sy * sn
            py = cy + sx * sn + sy * c
            if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
                return False
    return True

def _score(squares):
    return sum(s for _, _, _, s in squares)

def _clip_square(sq):
    cx, cy, a, s = sq
    if s <= 1e-12:
        return (0.5, 0.5, 0.0, 0.0)
    # shrink/translate until inside
    # adaptive transform
    for _ in range(30):
        inside = True
        h = s * 0.5
        th = a * 2.0 * math.pi
        c, sn = math.cos(th), math.sin(th)
        pts = []
        for sx, sy in [(-h, -h), (h, -h), (h, h), (-h, h)]:
            px = cx + sx * c - sy * sn
            py = cy + sx * sn + sy * c
            pts.append((px, py))
        minx = min(p[0] for p in pts)
        maxx = max(p[0] for p in pts)
        miny = min(p[1] for p in pts)
        maxy = max(p[1] for p in pts)
        if minx < 0:
            cx -= minx
        if maxx > 1:
            cx -= (maxx - 1)
        if miny < 0:
            cy -= miny
        if maxy > 1:
            cy -= (maxy - 1)
        # check again
        pts = []
        for sx, sy in [(-h, -h), (h, -h), (h, h), (-h, h)]:
            px = cx + sx * c - sy * sn
            py = cy + sx * sn + sy * c
            pts.append((px, py))
        minx = min(p[0] for p in pts)
        maxx = max(p[0] for p in pts)
        miny = min(p[1] for p in pts)
        maxy = max(p[1] for p in pts)
        if minx >= -1e-9 and maxx <= 1+1e-9 and miny >= -1e-9 and maxy <= 1+1e-9:
            break
        else:
            s *= 0.9
            h = s * 0.5
    return (max(0.0, min(1.0, cx)), max(0.0, min(1.0, cy)), a % 1.0, max(0.0, s))

def _place_greedy(n):
    """Place squares greedily in a grid, then fill leftover with rotated squares."""
    # grid size: choose k such that k^2 <= n, maximize k
    k = int(math.isqrt(n))
    # number of full grid squares
    ngrid = k * k
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i+0.5)*side, (j+0.5)*side, 0.0, side))
    rem = n - ngrid
    if rem > 0:
        # try to insert rotated squares in gaps along edges
        # simple: try to place rem squares of size ~ side*0.3 rotated 45 deg in random spots
        attempts = 0
        placed = 0
        while placed < rem and attempts < 2000:
            attempts += 1
            # try random candidate in [0,1]^2
            cx = random.random()
            cy = random.random()
            # size proportional to side
            s = side * random.uniform(0.1, 0.5)
            a = random.random()
            cand = (cx, cy, a, s)
            cand = _clip_square(cand)
            if cand[3] <= 1e-12:
                continue
            ok = True
            for sq in squares:
                if _overlap(sq, cand):
                    ok = False
                    break
            if ok:
                squares.append(cand)
                placed += 1
        # pad remaining with zeros
        while len(squares) < n:
            squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]

def _local_improve(squares, time_limit):
    """Simulated annealing to improve sum of sides."""
    n = len(squares)
    squares = [list(sq) for sq in squares]
    best = [list(sq) for sq in squares]
    best_score = _score(squares)
    start = time.time()
    it = 0
    temp = 0.1
    while time.time() - start < time_limit:
        it += 1
        # pick a random square to modify
        i = random.randrange(n)
        old = list(squares[i])
        # decide move type
        r = random.random()
        if r < 0.4:
            # move center
            cx = old[0] + random.gauss(0, 0.05)
            cy = old[1] + random.gauss(0, 0.05)
            cx = max(0.0, min(1.0, cx))
            cy = max(0.0, min(1.0, cy))
            new = [cx, cy, old[2], old[3]]
        elif r < 0.7:
            # rotate
            a = old[2] + random.gauss(0, 0.1)
            new = [old[0], old[1], a % 1.0, old[3]]
        elif r < 0.9:
            # resize
            s = old[3] * (1.0 + random.gauss(0, 0.1))
            s = max(0.0, min(1.0, s))
            new = [old[0], old[1], old[2], s]
        else:
            # combined
            cx = old[0] + random.gauss(0, 0.03)
            cy = old[1] + random.gauss(0, 0.03)
            a = old[2] + random.gauss(0, 0.05)
            s = old[3] * (1.0 + random.gauss(0, 0.05))
            new = [max(0.0, min(1.0, cx)), max(0.0, min(1.0, cy)), a % 1.0, max(0.0, min(1.0, s))]
        new = _clip_square(new)
        # check overlap with others
        ok = True
        for j in range(n):
            if j == i:
                continue
            if _overlap(tuple(new), tuple(squares[j])):
                ok = False
                break
        if not ok:
            continue
        # accept
        old_score = old[3]
        new_score = new[3]
        delta = new_score - old_score
        if delta >= 0 or random.random() < math.exp(delta / max(1e-9, temp)):
            squares[i] = new
            cur_score = _score(squares)
            if cur_score > best_score:
                best_score = cur_score
                best = [list(sq) for sq in squares]
        # cool
        temp *= 0.9999
        if temp < 1e-6:
            temp = 0.05
    return [tuple(sq) for sq in best]

def solve(n):
    """Main solve function."""
    if n <= 0:
        return []
    if n == 1:
        # single square: maximize side = 1
        return [(0.5, 0.5, 0.0, 1.0)]
    # time budget: 60s max, but use less for small n
    time_budget = min(55.0, 0.5 + n * 0.05)
    # initial greedy placement
    squares = _place_greedy(n)
    # try to improve with SA
    try:
        squares = _local_improve(squares, time_budget)
    except Exception:
        pass
    # final check and clip
    result = []
    for sq in squares:
        sq = _clip_square(sq)
        result.append(sq)
    # ensure exactly n
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
