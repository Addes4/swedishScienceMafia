import math
import random

def solve(n):
    if n <= 0:
        return []
    
    best_squares = None
    best_score = -1.0
    
    # --- Try a simple grid for larger n as initialization ---
    k = max(1, int(math.sqrt(n)))
    grid_squares = []
    side = 1.0 / k
    count = 0
    for i in range(k):
        for j in range(k):
            if count < n:
                grid_squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
                count += 1
    while len(grid_squares) < n:
        grid_squares.append((0.5, 0.5, 0.0, 0.0))
    grid_squares = grid_squares[:n]
    
    # Helper to evaluate score
    def score(sqs):
        return sum(s[3] for s in sqs)
    
    # Helper to check overlap between two squares (quick check)
    def overlap_area(s1, s2):
        # bounding circle check first
        x1, y1, a1, sz1 = s1
        x2, y2, a2, sz2 = s2
        if sz1 == 0 or sz2 == 0:
            return 0.0
        r1 = sz1 * math.sqrt(2) / 2.0
        r2 = sz2 * math.sqrt(2) / 2.0
        dx = x1 - x2
        dy = y1 - y2
        if dx*dx + dy*dy > (r1+r2)**2:
            return 0.0
        # SAT for rotated squares
        # each square has 4 axes
        def get_vertices(cx, cy, angle, side):
            c = math.cos(2*math.pi*angle)
            s = math.sin(2*math.pi*angle)
            h = side / 2.0
            # corners relative
            corners = [(-h, -h), (h, -h), (h, h), (-h, h)]
            verts = []
            for dx, dy in corners:
                rx = dx*c - dy*s
                ry = dx*s + dy*c
                verts.append((cx+rx, cy+ry))
            return verts
        v1 = get_vertices(x1, y1, a1, sz1)
        v2 = get_vertices(x2, y2, a2, sz2)
        # axes: for each square, normal to its edges
        axes = []
        for angle in (a1, a2):
            c = math.cos(2*math.pi*angle)
            s = math.sin(2*math.pi*angle)
            axes.append((c, s))
            axes.append((-s, c))
        # project
        for ax, ay in axes:
            proj1 = [vx*ax + vy*ay for vx, vy in v1]
            proj2 = [vx*ax + vy*ay for vx, vy in v2]
            min1, max1 = min(proj1), max(proj1)
            min2, max2 = min(proj2), max(proj2)
            if max1 < min2 - 1e-12 or max2 < min1 - 1e-12:
                return 0.0
        # If all axes overlap, then shapes overlap (for convex polygons SAT works)
        # We need actual overlap area > 0? For our purpose, just detect overlap.
        return 1.0  # indicates potential overlap

    # Try to improve from grid by adjusting sizes
    # Simple greedy: increase each square size as much as possible while fitting
    def greedy_improve(sqs, iterations=100):
        sqs = [list(s) for s in sqs]
        current = sqs[:]
        for _ in range(iterations):
            improved = False
            # random order
            order = list(range(len(current)))
            random.shuffle(order)
            for idx in order:
                x, y, ang, sz = current[idx]
                if sz >= 1.0:
                    continue
                # try to increase size
                max_try = min(1.0, sz + 0.05)
                step = 0.01
                while max_try > sz:
                    new_sz = min(max_try, sz + step)
                    # check if still fits in unit square
                    # approximate check: center within [sz/2, 1-sz/2] for axis-aligned, but rotated is complex
                    # We'll just check bounding box roughly
                    c = math.cos(2*math.pi*ang)
                    s = math.sin(2*math.pi*ang)
                    h = new_sz/2.0
                    # rotated square bounding box half-width
                    hw = h*(abs(c)+abs(s))
                    hh = h*(abs(c)+abs(s))
                    if x - hw < -1e-9 or x + hw > 1+1e-9 or y - hh < -1e-9 or y + hh > 1+1e-9:
                        break
                    # check overlap with others
                    ok = True
                    for jdx, other in enumerate(current):
                        if idx == jdx:
                            continue
                        if overlap_area((x,y,ang,new_sz), other) > 0.5:
                            ok = False
                            break
                    if ok:
                        sz = new_sz
                        current[idx][3] = sz
                        improved = True
                    else:
                        break
                # try small rotation
                for delta_ang in [0.001, -0.001, 0.005, -0.005]:
                    new_ang = (ang + delta_ang) % 1.0
                    c = math.cos(2*math.pi*new_ang)
                    s = math.sin(2*math.pi*new_ang)
                    h = sz/2.0
                    hw = h*(abs(c)+abs(s))
                    hh = h*(abs(c)+abs(s))
                    if x - hw < -1e-9 or x + hw > 1+1e-9 or y - hh < -1e-9 or y + hh > 1+1e-9:
                        continue
                    ok = True
                    for jdx, other in enumerate(current):
                        if idx == jdx:
                            continue
                        if overlap_area((x,y,new_ang,sz), other) > 0.5:
                            ok = False
                            break
                    if ok:
                        current[idx][2] = new_ang
                        improved = True
                        break
                # try small translation
                for dx, dy in [(0.001,0), (-0.001,0), (0,0.001), (0,-0.001)]:
                    nx, ny = x+dx, y+dy
                    c = math.cos(2*math.pi*ang)
                    s = math.sin(2*math.pi*ang)
                    h = sz/2.0
                    hw = h*(abs(c)+abs(s))
                    hh = h*(abs(c)+abs(s))
                    if nx - hw < -1e-9 or nx + hw > 1+1e-9 or ny - hh < -1e-9 or ny + hh > 1+1e-9:
                        continue
                    ok = True
                    for jdx, other in enumerate(current):
                        if idx == jdx:
                            continue
                        if overlap_area((nx,ny,ang,sz), other) > 0.5:
                            ok = False
                            break
                    if ok:
                        current[idx][0] = nx
                        current[idx][1] = ny
                        improved = True
                        break
            if not improved:
                break
        return [tuple(s) for s in current]

    # For small n, use specific known good configurations
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side by side
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # one big on left, two small on right
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    if n == 4:
        # 2x2 grid
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    
    # For n >= 5, start with grid and improve
    # Try a few restarts with different random seeds
    best = None
    best_val = -1.0
    for trial in range(5):
        random.seed(trial * 12345 + n)
        # start from grid but add some perturbation
        sqs = [list(s) for s in grid_squares]
        # random perturbation
        for s in sqs:
            if s[3] > 0:
                s[0] += random.uniform(-0.02, 0.02)
                s[1] += random.uniform(-0.02, 0.02)
                s[0] = max(s[3]/2, min(1-s[3]/2, s[0]))
                s[1] = max(s[3]/2, min(1-s[3]/2, s[1]))
        improved = greedy_improve(sqs, iterations=50)
        val = score(improved)
        if val > best_val:
            best_val = val
            best = improved
    
    # Ensure all in [0,1] and valid
    result = []
    for x, y, a, s in best:
        x = max(0.0, min(1.0, x))
        y = max(0.0, min(1.0, y))
        a = a % 1.0
        s = max(0.0, min(1.0, s))
        result.append((x, y, a, s))
    
    # Pad with zeros if needed
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    
    return result[:n]
