import math
import random

SQRT2 = math.sqrt(2.0)


class Square:
    __slots__ = ("cx", "cy", "ang", "s", "c", "sn")

    def __init__(self, cx=0.5, cy=0.5, ang=0.0, s=0.0):
        self.cx = cx
        self.cy = cy
        self.ang = ang
        self.s = s
        self._set_trig()

    def _set_trig(self):
        a = self.ang * 2.0 * math.pi
        self.c = math.cos(a)
        self.sn = math.sin(a)

    def half_extent(self):
        return 0.5 * self.s * (abs(self.c) + abs(self.sn))

    def bounds(self):
        e = self.half_extent()
        return (self.cx - e, self.cx + e, self.cy - e, self.cy + e)


def _overlap(a, b, eps=1e-12):
    # SAT for two rotated squares.
    if a.s <= eps or b.s <= eps:
        return False
    if a.sn == 0.0 and b.sn == 0.0:
        # fast path, axis aligned
        ax1, ax2, ay1, ay2 = a.bounds()
        bx1, bx2, by1, by2 = b.bounds()
        return not (ax2 <= bx1 + eps or bx2 <= ax1 + eps or
                    ay2 <= by1 + eps or by2 <= ay1 + eps)
    # general SAT
    dx = b.cx - a.cx
    dy = b.cy - a.cy
    # axes of a
    for (ux, uy) in ((a.c, a.sn), (-a.sn, a.c)):
        r = 0.5 * (a.s * (abs(ux * a.c + uy * a.sn) + abs(ux * -a.sn + uy * a.c)) +
                   b.s * (abs(ux * b.c + uy * b.sn) + abs(ux * -b.sn + uy * b.c)))
        d = abs(dx * ux + dy * uy)
        if d >= r - eps:
            return False
    # axes of b
    for (ux, uy) in ((b.c, b.sn), (-b.sn, b.c)):
        r = 0.5 * (a.s * (abs(ux * a.c + uy * a.sn) + abs(ux * -a.sn + uy * a.c)) +
                   b.s * (abs(ux * b.c + uy * b.sn) + abs(ux * -b.sn + uy * b.c)))
        d = abs(dx * ux + dy * uy)
        if d >= r - eps:
            return False
    return True


def _clamp_inside(sq):
    e = sq.half_extent()
    x0 = e
    x1 = 1.0 - e
    y0 = e
    y1 = 1.0 - e
    if sq.cx < x0:
        sq.cx = x0
    elif sq.cx > x1:
        sq.cx = x1
    if sq.cy < y0:
        sq.cy = y0
    elif sq.cy > y1:
        sq.cy = y1


def _make_squares(n):
    if n == 0:
        return []
    if n == 1:
        return [Square(0.5, 0.5, 0.0, 1.0)]

    # Start with axis-aligned grid / recursion-like layout.
    # Find k = largest integer with k^2 <= n and use grid, then extra squares
    # placed by greedy insertion.
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(Square((i + 0.5) * side, (j + 0.5) * side, 0.0, side))

    # For the remaining n - k^2 squares, use greedy insertion.
    while len(squares) < n:
        sq = _greedy_insert(squares, len(squares) + 1)
        squares.append(sq)
    return squares


def _valid_position(squares, cx, cy, ang, s):
    probe = Square(cx, cy, ang, s)
    e = probe.half_extent()
    if e > 0.5 + 1e-12:
        return False
    if cx - e < -1e-12 or cx + e > 1.0 + 1e-12:
        return False
    if cy - e < -1e-12 or cy + e > 1.0 + 1e-12:
        return False
    for o in squares:
        if _overlap(probe, o):
            return False
    return True


def _max_side_at(squares, cx, cy, ang):
    # Binary search largest s that is valid
    lo = 0.0
    hi = 1.0
    # quick upper bound from container
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        if _valid_position(squares, cx, cy, ang, mid):
            lo = mid
        else:
            hi = mid
    return lo


def _greedy_insert(squares, total_n):
    """Insert one square greedily."""
    best_s = 0.0
    best = None
    # candidate positions
    cands = [(0.5, 0.5, 0.0)]
    # grid of candidates
    steps = 12
    for i in range(steps):
        for j in range(steps):
            x = (i + 0.5) / steps
            y = (j + 0.5) / steps
            cands.append((x, y, 0.0))
            cands.append((x, y, 0.25))
            cands.append((x, y, math.atan2(1, 1) / (2 * math.pi)))  # 45 deg
    # also near corners/edges
    for x in (0.28, 0.5, 0.72):
        for y in (0.28, 0.5, 0.72):
            cands.append((x, y, 0.0))

    for (x, y, a) in cands:
        s = _max_side_at(squares, x, y, a)
        if s > best_s + 1e-12:
            best_s = s
            best = (x, y, a)

    if best is None:
        return Square(0.5, 0.5, 0.0, 0.0)
    x, y, a = best
    sq = Square(x, y, a, best_s)
    _clamp_inside(sq)
    return sq


def _relax(squares, iterations=2000):
    """Try to grow squares and reposition them to increase total size."""
    n = len(squares)
    if n == 0:
        return
    order = list(range(n))
    for it in range(iterations):
        random.shuffle(order)
        changed = False
        for idx in order:
            sq = squares[idx]
            if sq.s <= 0:
                continue
            # Try to grow slightly
            factor = 1.0 + random.uniform(0.001, 0.05)
            new_s = sq.s * factor
            # keep bounded
            e = 0.5 * new_s * (abs(sq.c) + abs(sq.sn))
            if e > 0.5:
                continue
            # Try grow in place
            if _valid_position([o for j, o in enumerate(squares) if j != idx],
                                sq.cx, sq.cy, sq.ang, new_s):
                sq.s = new_s
                changed = True
                continue
            # Try small perturbations
            for _ in range(6):
                dx = random.uniform(-0.03, 0.03)
                dy = random.uniform(-0.03, 0.03)
                da = random.uniform(-0.02, 0.02)
                nx = min(max(sq.cx + dx, 0.0), 1.0)
                ny = min(max(sq.cy + dy, 0.0), 1.0)
                na = (sq.ang + da) % 1.0
                e = 0.5 * new_s * (abs(math.cos(na * 2 * math.pi)) + abs(math.sin(na * 2 * math.pi)))
                if e > 0.5:
                    continue
                nx = min(max(nx, e), 1.0 - e)
                ny = min(max(ny, e), 1.0 - e)
                if _valid_position([o for j, o in enumerate(squares) if j != idx],
                                   nx, ny, na, new_s):
                    sq.cx = nx
                    sq.cy = ny
                    sq.ang = na
                    sq.s = new_s
                    sq._set_trig()
                    changed = True
                    break
        if not changed and it > 100:
            # try global compaction: shrink-free but move towards density
            break


def solve(n):
    squares = _make_squares(n)
    if n == 0:
        return []
    # Greedy insert for all if small n (better than fixed grid)
    if n <= 64:
        squares = _make_squares(0)
        for _ in range(n):
            squares.append(_greedy_insert(squares, len(squares) + 1))

    # improvement: try to grow all squares
    _relax(squares, iterations=1500)

    result = []
    for sq in squares:
        result.append((min(max(sq.cx, 0.0), 1.0),
                       min(max(sq.cy, 0.0), 1.0),
                       sq.ang % 1.0,
                       max(0.0, sq.s)))
    # pad if needed
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
