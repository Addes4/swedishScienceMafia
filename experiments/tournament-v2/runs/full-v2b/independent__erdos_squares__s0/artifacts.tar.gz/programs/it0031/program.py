# EVOLVE-BLOCK-START
"""Packing squares in a square: maximise sum of side lengths.

Method: multistart greedy growth with overlap-resolution and simulated
hill-climbing.  We keep all squares axis-aligned (rotations by 90 degrees
are equivalent to no rotation for a single square, so angle=0 is optimal
for packing axis-aligned squares; allowing non-axis-aligned squares would
only matter for exotic configurations and is unlikely to beat a good
axis-aligned packing within the time limit).  We use a contact graph and
grow squares one at a time, pushing overlapping neighbours apart.

The key subroutine is a physically-inspired relaxation:
  * all squares start small;
  * repeatedly pick the square that can grow the most,
  * grow it until it touches / would overlap another,
  * resolve overlaps by shrinking the smaller of the pair,
  * add small random perturbations and accept improvements (hill climb).

This scales to all n and uses only the standard library.
"""

import math
import random
import time


def _overlap_amount(a, b):
    # axis-aligned squares: a = (cx, cy, side)
    ax, ay, asz = a
    bx, by, bsz = b
    dx = abs(ax - bx)
    dy = abs(ay - by)
    ox = (asz + bsz) * 0.5 - dx
    oy = (asz + bsz) * 0.5 - dy
    if ox > 0.0 and oy > 0.0:
        return ox, oy
    return 0.0, 0.0


def _penetration(a, b):
    ox, oy = _overlap_amount(a, b)
    if ox > 0.0 and oy > 0.0:
        return min(ox, oy)
    return 0.0


def _clamp_square(cx, cy, side):
    half = side * 0.5
    if half >= 0.5:
        cx = 0.5
        cy = 0.5
        side = 1.0
    else:
        lo = half
        hi = 1.0 - half
        cx = min(max(cx, lo), hi)
        cy = min(max(cy, lo), hi)
    return cx, cy, side


def _resolve_overlaps(pos, sizes, n, iters=60):
    """Push apart overlapping squares, keeping inside unit box."""
    for _ in range(iters):
        moved = False
        for i in range(n):
            si = sizes[i]
            if si <= 1e-12:
                continue
            xi, yi = pos[i]
            for j in range(i + 1, n):
                sj = sizes[j]
                if sj <= 1e-12:
                    continue
                xj, yj = pos[j]
                dx = xj - xi
                dy = yj - yi
                ox = (si + sj) * 0.5 - abs(dx)
                oy = (si + sj) * 0.5 - abs(dy)
                if ox > 1e-9 and oy > 1e-9:
                    moved = True
                    if ox < oy:
                        sgn = 1.0 if dx >= 0.0 else -1.0
                        shift = ox * 0.5 + 1e-9
                        xi -= sgn * shift
                        xj += sgn * shift
                    else:
                        sgn = 1.0 if dy >= 0.0 else -1.0
                        shift = oy * 0.5 + 1e-9
                        yi -= sgn * shift
                        yj += sgn * shift
            pos[i] = (xi, yi)
        # clamp
        for i in range(n):
            cx, cy = pos[i]
            s = sizes[i]
            cx, cy, _ = _clamp_square(cx, cy, s)
            pos[i] = (cx, cy)
        if not moved:
            break


def _grow_pass(pos, sizes, order, n, growth=1.0):
    """For each square in order, try to grow it as much as possible without overlap."""
    for idx in order:
        s = sizes[idx]
        if s >= 1.0:
            continue
        cx, cy = pos[idx]
        # binary search maximum side that fits without overlap with current others
        lo = s
        hi = 1.0
        # quick upper bound: room to walls
        max_room = 2.0 * min(cx, 1.0 - cx, cy, 1.0 - cy)
        hi = min(hi, max_room)
        # also limit by neighbours
        for j in range(n):
            if j == idx:
                continue
            sj = sizes[j]
            if sj <= 0.0:
                continue
            xj, yj = pos[j]
            dx = abs(cx - xj)
            dy = abs(cy - yj)
            # if we grow, collision when (s+sj)/2 > dx and (s+sj)/2 > dy
            # the binding constraint: need min(dx,dy)*2 - sj
            lim = 2.0 * min(dx, dy) - sj
            if lim < hi:
                hi = max(lo, lim)
        if hi <= lo:
            continue
        # binary search
        best = lo
        for _ in range(40):
            mid = (lo + hi) * 0.5
            ok = True
            half = mid * 0.5
            if cx - half < -1e-12 or cx + half > 1.0 + 1e-12 or cy - half < -1e-12 or cy + half > 1.0 + 1e-12:
                ok = False
            if ok:
                for j in range(n):
                    if j == idx:
                        continue
                    sj = sizes[j]
                    if sj <= 0.0:
                        continue
                    xj, yj = pos[j]
                    if abs(cx - xj) < (mid + sj) * 0.5 - 1e-12 and abs(cy - yj) < (mid + sj) * 0.5 - 1e-12:
                        ok = False
                        break
            if ok:
                best = mid
                lo = mid
            else:
                hi = mid
        sizes[idx] = best
        # re-clamp
        cx, cy, sizes[idx] = _clamp_square(cx, cy, sizes[idx])
        pos[idx] = (cx, cy)


def _score(sizes):
    return sum(sizes)


def _initial_positions(n, rng, mode):
    pos = []
    if mode == 0:
        # grid layout
        k = int(math.ceil(math.sqrt(n)))
        rows = (n + k - 1) // k
        for i in range(n):
            r = i // k
            c = i % k
            x = (c + 0.5) / k
            y = (r + 0.5) / rows
            pos.append((x, y))
    elif mode == 1:
        # staggered rows
        k = int(math.ceil(math.sqrt(n)))
        rows = (n + k - 1) // k
        for i in range(n):
            r = i // k
            c = i % k
            x = (c + 0.5 + 0.5 * (r % 2)) / k
            y = (r + 0.5) / rows
            pos.append((min(max(x, 0.001), 0.999), min(max(y, 0.001), 0.999)))
    elif mode == 2:
        # random
        for i in range(n):
            pos.append((rng.random() * 0.8 + 0.1, rng.random() * 0.8 + 0.1))
    else:
        # spiral-ish
        for i in range(n):
            t = i * 2.399963229728653  # golden angle
            r = math.sqrt((i + 0.5) / n) * 0.45
            pos.append((0.5 + r * math.cos(t), 0.5 + r * math.sin(t)))
    return pos


def _optimize(n, rng, time_limit):
    best_sizes = [0.0] * n
    best_pos = [(0.5, 0.5)] * n
    best_score = -1.0
    start = time.time()

    trial = 0
    while time.time() - start < time_limit:
        trial += 1
        mode = trial % 4
        pos = _initial_positions(n, rng, mode)
        sizes = [1e-6] * n

        # initial sizes
        if n == 1:
            return [(0.5, 0.5, 0.0, 1.0)]
        for i in range(n):
            sizes[i] = 1e-6

        # Resolve initial overlaps
        _resolve_overlaps(pos, sizes, n, iters=30)

        # growth phases
        for phase in range(40):
            order = list(range(n))
            rng.shuffle(order)
            _grow_pass(pos, sizes, order, n)
            _resolve_overlaps(pos, sizes, n, iters=20)
            sc = _score(sizes)
            if sc > best_score:
                best_score = sc
                best_sizes = sizes[:]
                best_pos = pos[:]
            if time.time() - start > time_limit * 0.95:
                break

        # local search: perturb and accept improvements
        cur_sizes = sizes[:]
        cur_pos = pos[:]
        cur_score = _score(cur_sizes)
        for step in range(200):
            if time.time() - start > time_limit:
                break
            # pick random square and jitter or resize
            i = rng.randrange(n)
            old_s = cur_sizes[i]
            old_p = cur_pos[i]
            if rng.random() < 0.5:
                # jitter position
                nx = old_p[0] + (rng.random() - 0.5) * 0.05
                ny = old_p[1] + (rng.random() - 0.5) * 0.05
                nx, ny, _ = _clamp_square(nx, ny, old_s)
                cur_pos[i] = (nx, ny)
            else:
                # resize
                ns = old_s * (1.0 + (rng.random() - 0.5) * 0.1)
                ns = min(max(ns, 0.0), 1.0)
                if ns * 0.5 > 0.5:
                    ns = 1.0
                cur_sizes[i] = ns
                cx, cy, ns = _clamp_square(cur_pos[i][0], cur_pos[i][1], ns)
                cur_pos[i] = (cx, cy)
                cur_sizes[i] = ns
            _resolve_overlaps(cur_pos, cur_sizes, n, iters=8)
            new_score = _score(cur_sizes)
            if new_score >= cur_score:
                cur_score = new_score
            else:
                # revert
                cur_sizes[i] = old_s
                cur_pos[i] = old_p

        if cur_score > best_score:
            best_score = cur_score
            best_sizes = cur_sizes[:]
            best_pos = cur_pos[:]

    return best_pos, best_sizes


def _greedy_construct(n):
    """Deterministic fallback: place squares greedily from largest to smallest."""
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # start with grid of size ~sqrt(n)
    k = int(math.floor(math.sqrt(n)))
    while k * k < n:
        k += 1
    if k * k == n:
        side = 1.0 / k
        res = []
        for i in range(k):
            for j in range(k):
                res.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        return res
    # use k columns, distribute rows
    cols = k
    rows = (n + cols - 1) // cols
    cell_w = 1.0 / cols
    cell_h = 1.0 / rows
    base = min(cell_w, cell_h)
    res = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            x = (c + 0.5) * cell_w
            y = (r + 0.5) * cell_h
            res.append((x, y, 0.0, base))
            idx += 1
    return res[:n]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n * 7919)
    # time budget: scale with n but stay under 60s; give small n more restarts
    if n <= 4:
        tl = 2.0
    elif n <= 10:
        tl = 4.0
    elif n <= 30:
        tl = 8.0
    elif n <= 100:
        tl = 15.0
    else:
        tl = 25.0

    # deterministic greedy first
    greedy = _greedy_construct(n)
    greedy_sizes = [s for (_, _, _, s) in greedy]
    score_g = _score(greedy_sizes)

    best_pos = [(g[0], g[1]) for g in greedy]
    best_sizes = greedy_sizes[:]
    best_score = score_g

    try:
        pos, sizes = _optimize(n, rng, tl)
        sc = _score(sizes)
        if sc > best_score:
            best_score = sc
            best_pos = pos
            best_sizes = sizes
    except Exception:
        pass

    # Build result, fill zeros for any missing
    result = []
    for i in range(n):
        if i < len(best_pos):
            cx, cy = best_pos[i]
            s = best_sizes[i]
        else:
            cx, cy = 0.5, 0.5
            s = 0.0
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        s = min(max(s, 0.0), 1.0)
        result.append((cx, cy, 0.0, s))

    # final overlap cleanup: shrink any overlapping squares
    for _ in range(200):
        changed = False
        for i in range(n):
            xi, yi, ai, si = result[i]
            if si <= 0.0:
                continue
            for j in range(i + 1, n):
                xj, yj, aj, sj = result[j]
                if sj <= 0.0:
                    continue
                if abs(xi - xj) < (si + sj) * 0.5 - 1e-12 and abs(yi - yj) < (si + sj) * 0.5 - 1e-12:
                    # shrink the smaller
                    if si <= sj:
                        new_s = max(0.0, si - 1e-4)
                        result[i] = (xi, yi, 0.0, new_s)
                        si = new_s
                        changed = True
                    else:
                        new_s = max(0.0, sj - 1e-4)
                        result[j] = (xj, yj, 0.0, new_s)
                        sj = new_s
                        changed = True
                if changed:
                    break
            if changed:
                break
        if not changed:
            break

    return result[:n]
# EVOLVE-BLOCK-END
