import math
import random

def _can_place(x, y, s, placed):
    # conservative check for axis-aligned squares only
    for px, py, pa, ps in placed:
        if pa != 0.0:
            continue
        if abs(px - x) < (ps + s) * 0.5 and abs(py - y) < (ps + s) * 0.5:
            return False
    return True

def _greedy_rect(w, h, n, placed, ox, oy):
    """Fill axis-aligned rect [ox,ox+w]x[oy,oy+h] with up to n axis-aligned squares."""
    if n <= 0 or w <= 1e-12 or h <= 1e-12:
        return
    # choose orientation: cut along longer side
    if w >= h:
        # place a square of side h at left, then recurse on remaining strip
        s = h
        cx = ox + s * 0.5
        cy = oy + s * 0.5
        placed.append((cx, cy, 0.0, s))
        if n > 1:
            _greedy_rect(w - s, h, n - 1, placed, ox + s, oy)
    else:
        s = w
        cx = ox + s * 0.5
        cy = oy + s * 0.5
        placed.append((cx, cy, 0.0, s))
        if n > 1:
            _greedy_rect(w, h - s, n - 1, placed, ox, oy + s)

def _score(squares):
    return sum(s[3] for s in squares)

def _improve(squares, n):
    best = list(squares)
    best_score = _score(best)
    # local perturbation: shrink/expand one square and adjust neighbours greedily
    improved = True
    iters = 0
    while improved and iters < 200:
        improved = False
        iters += 1
        for i in range(n):
            for factor in (1.02, 0.98, 1.05, 0.95):
                new = [list(s) for s in best]
                s = new[i][3] * factor
                if s > 1.0 or s <= 0:
                    continue
                new[i][3] = s
                # check safety
                ok = True
                for j in range(n):
                    if i == j:
                        continue
                    if abs(new[i][0] - new[j][0]) < (new[i][3] + new[j][3]) * 0.5 and \
                       abs(new[i][1] - new[j][1]) < (new[i][3] + new[j][3]) * 0.5:
                        if new[i][2] == 0.0 and new[j][2] == 0.0:
                            ok = False
                            break
                if ok:
                    sc = _score(new)
                    if sc > best_score + 1e-9:
                        best = new
                        best_score = sc
                        improved = True
    return [tuple(s) for s in best]

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_score = -1.0

    # Try multiple strip decompositions and greedy fills
    strategies = []
    # Simple grid fallback
    k = math.isqrt(n)
    side = 1.0 / k
    grid_squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    grid_squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(grid_squares))
    strategies.append(_improve(grid_squares[:n], n))

    # Try greedy with strips of decreasing width
    for first_frac in [0.5, 0.6, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 1.0]:
        placed = []
        # place first large square
        s0 = first_frac
        placed.append((s0 * 0.5, s0 * 0.5, 0.0, s0))
        remaining = n - 1
        # leftover L-shaped region: right rect and top rect
        right_w = 1.0 - s0
        right_h = s0
        top_w = 1.0
        top_h = 1.0 - s0
        # allocate remaining among the two rects proportionally to area
        area_right = right_w * right_h
        area_top = top_w * top_h
        total_area = area_right + area_top
        if total_area > 0:
            n_right = int(round(remaining * area_right / total_area))
            n_right = max(0, min(remaining, n_right))
            n_top = remaining - n_right
        else:
            n_right = 0
            n_top = remaining
        _greedy_rect(right_w, right_h, n_right, placed, s0, 0.0)
        _greedy_rect(top_w, top_h, n_top, placed, 0.0, s0)
        # pad if short
        while len(placed) < n:
            placed.append((0.5, 0.5, 0.0, 0.0))
        placed = placed[:n]
        placed = _improve(placed, n)
        sc = _score(placed)
        if sc > best_score:
            best_score = sc
            best = placed

    # More random strip attempts
    for _ in range(30):
        placed = []
        # random first square size
        s0 = random.uniform(0.65, 0.95)
        placed.append((s0 * 0.5, s0 * 0.5, 0.0, s0))
        remaining = n - 1
        right_w = 1.0 - s0
        right_h = s0
        top_w = 1.0
        top_h = 1.0 - s0
        # random split
        if remaining > 0:
            n_right = random.randint(0, remaining)
        else:
            n_right = 0
        n_top = remaining - n_right
        _greedy_rect(right_w, right_h, n_right, placed, s0, 0.0)
        _greedy_rect(top_w, top_h, n_top, placed, 0.0, s0)
        while len(placed) < n:
            placed.append((0.5, 0.5, 0.0, 0.0))
        placed = placed[:n]
        placed = _improve(placed, n)
        sc = _score(placed)
        if sc > best_score:
            best_score = sc
            best = placed

    # Try a few different first-square corner placements
    for cx in [0.0, 1.0]:
        for cy in [0.0, 1.0]:
            for s0 in [0.7, 0.8, 0.9]:
                placed = []
                placed.append((0.5, 0.5, 0.0, 0.0))  # placeholder
                # Actually place square centered so it fits; for corner placements, center adjusts
                # Just do grid for simplicity
                pass

    return best

