import math
import random
import numpy as np
from scipy.optimize import minimize


def _corners(cx, cy, ang, s):
    """Return 4 corners of a square centred at (cx,cy), rotated by ang turns."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + dx * ca - dy * sa
        y = cy + dx * sa + dy * ca
        pts.append((x, y))
    return pts


def _axes(ang):
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    return (ca, sa), (-sa, ca)


def _overlap_area(sq1, sq2):
    """Separating axis test for two convex squares; returns penetration depth (0 if separated)."""
    p1 = _corners(*sq1)
    p2 = _corners(*sq2)
    (a1x, a1y), (a2x, a2y) = _axes(sq1[2])
    axes = [(a1x, a1y), (a2x, a2y)]
    (b1x, b1y), (b2x, b2y) = _axes(sq2[2])
    axes += [(b1x, b1y), (b2x, b2y)]
    min_pen = float("inf")
    for ax, ay in axes:
        n1 = [px * ax + py * ay for px, py in p1]
        n2 = [px * ax + py * ay for px, py in p2]
        gap = max(min(n2) - max(n1), min(n1) - max(n2))
        if gap > 0:
            return 0.0
        if -gap < min_pen:
            min_pen = -gap
    return min_pen


def _contain_penalty(sq):
    """Penalty if square exits [0,1]^2."""
    pts = _corners(*sq)
    pen = 0.0
    for x, y in pts:
        if x < 0:
            pen += -x
        elif x > 1:
            pen += x - 1
        if y < 0:
            pen += -y
        elif y > 1:
            pen += y - 1
    return pen


def _total_overlap(sqs, idx=None):
    tot = 0.0
    n = len(sqs)
    rng = range(n) if idx is None else idx
    for i in rng:
        for j in range(i + 1, n):
            tot += _overlap_area(sqs[i], sqs[j])
    return tot


def _eval(params, n):
    sqs = []
    for i in range(n):
        cx = params[4 * i]
        cy = params[4 * i + 1]
        ang = params[4 * i + 2]
        s = max(0.0, params[4 * i + 3])
        sqs.append((cx, cy, ang, s))
    return sqs


def _objective(params, n, w_pen=1e3):
    sqs = _eval(params, n)
    total = sum(s for _, _, _, s in sqs)
    pen = 0.0
    for sq in sqs:
        pen += _contain_penalty(sq)
    pen += _total_overlap(sqs)
    return -total + w_pen * pen


def _initial(n):
    """Constructive start."""
    k = math.isqrt(n)
    r = n - k * k
    side = 1.0 / k
    sqs = []
    if r == 0:
        for i in range(k):
            for j in range(k):
                sqs.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    else:
        # use k x k grid for k*k, then try to split some cells to fit remaining
        for i in range(k):
            for j in range(k):
                sqs.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        # add tiny squares at random free-ish positions
        for t in range(r):
            sqs.append((0.5, 0.5, 0.0, 0.0))
    return sqs


def _pack_improve(sqs, n, iters=200):
    """Greedy: shrink all, then try to expand one at a time."""
    sqs = [list(s) for s in sqs]
    for _ in range(iters):
        # shrink all by small factor
        for s in sqs:
            s[3] *= 0.995
        # expand each while legal
        order = list(range(n))
        random.shuffle(order)
        for i in order:
            lo, hi = sqs[i][3], 1.0
            for _ in range(25):
                mid = (lo + hi) * 0.5
                trial = list(sqs[i])
                trial[3] = mid
                if _contain_penalty(trial) > 1e-12:
                    hi = mid
                    continue
                bad = False
                for j in range(n):
                    if i == j:
                        continue
                    if _overlap_area(trial, sqs[j]) > 1e-12:
                        bad = True
                        break
                if bad:
                    hi = mid
                else:
                    lo = mid
            sqs[i][3] = lo
    return [tuple(s) for s in sqs]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    best = None
    best_score = -1.0

    for attempt in range(3):
        init = _initial(n)
        # add random jitter
        rng = random.Random(attempt)
        sqs = []
        for cx, cy, ang, s in init:
            cx += rng.uniform(-0.02, 0.02)
            cy += rng.uniform(-0.02, 0.02)
            ang += rng.uniform(-0.02, 0.02)
            sqs.append((cx, cy, ang, s))

        # continuous optimisation
        params = np.array([v for sq in sqs for v in sq], dtype=float)
        res = minimize(
            _objective, params, args=(n,),
            method="L-BFGS-B",
            options={"maxiter": 300, "ftol": 1e-12},
        )
        sqs2 = _eval(res.x, n)
        # clean up: clip containment and resolve overlaps via pack improve
        sqs3 = [list(s) for s in sqs2]
        for s in sqs3:
            s[0] = max(0.0, min(1.0, s[0]))
            s[1] = max(0.0, min(1.0, s[1]))
            s[3] = max(0.0, min(1.0, s[3]))
        sqs3 = _pack_improve(sqs3, n, iters=120)

        score = sum(s for _, _, _, s in sqs3) - 1e3 * (
            sum(_contain_penalty(sq) for sq in sqs3) + _total_overlap(sqs3)
        )
        if score > best_score:
            best_score = score
            best = sqs3

    # final validation: if overlaps remain, fall back to grid
    pen = sum(_contain_penalty(sq) for sq in best) + _total_overlap(best)
    if pen > 1e-6:
        k = math.isqrt(n)
        side = 1.0 / k
        best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]

    return [tuple(map(float, s)) for s in best]
