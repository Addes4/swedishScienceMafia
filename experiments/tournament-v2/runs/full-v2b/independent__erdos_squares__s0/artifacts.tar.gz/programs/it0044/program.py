import math
import random
import numpy as np
from scipy.optimize import minimize


def _overlap_ok(sqs, idx, x, y, ang, s, eps=1e-10):
    """Quick check that square idx at (x,y,ang,s) does not overlap others."""
    def corners(cx, cy, a, side):
        ca = math.cos(a)
        sa = math.sin(a)
        h = side * 0.5
        pts = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            px = cx + dx * ca - dy * sa
            py = cy + dx * sa + dy * ca
            pts.append((px, py))
        return pts

    ci = corners(x, y, ang, s)
    for j, (ox, oy, oa, os) in enumerate(sqs):
        if j == idx:
            continue
        cj = corners(ox, oy, oa, os)
        # SAT for convex polygons: if any separating axis exists, no overlap
        seps = []
        for poly in (ci, cj):
            m = len(poly)
            for k in range(m):
                p1 = poly[k]
                p2 = poly[(k + 1) % m]
                nx = p2[1] - p1[1]
                ny = -(p2[0] - p1[0])
                ln = math.hypot(nx, ny)
                if ln > 1e-15:
                    nx /= ln
                    ny /= ln
                    seps.append((nx, ny))
        separated = False
        for nx, ny in seps:
            a_min = a_max = ci[0][0] * nx + ci[0][1] * ny
            for px, py in ci[1:]:
                v = px * nx + py * ny
                if v < a_min:
                    a_min = v
                elif v > a_max:
                    a_max = v
            b_min = b_max = cj[0][0] * nx + cj[0][1] * ny
            for px, py in cj[1:]:
                v = px * nx + py * ny
                if v < b_min:
                    b_min = v
                elif v > b_max:
                    b_max = v
            if a_max <= b_min + eps or b_max <= a_min + eps:
                separated = True
                break
        if not separated:
            return False
    return True


def _total_and_penalty(params, n, mode):
    """Return negative total side minus huge penalty for invalid placement."""
    penalty = 0.0
    total = 0.0
    sqs = []
    for i in range(n):
        base = i * 4
        x = params[base]
        y = params[base + 1]
        ang = params[base + 2]
        s = params[base + 3]
        # clamp
        if mode:
            s = max(0.0, min(1.0, s))
            x = max(0.0, min(1.0, x))
            y = max(0.0, min(1.0, y))
            # stay inside
            ca = math.cos(ang)
            sa = math.sin(ang)
            h = s * 0.5
            for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
                px = x + dx * ca - dy * sa
                py = y + dx * sa + dy * ca
                if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
                    penalty += 1000.0 * (abs(px - 0.5) + abs(py - 0.5))
        total += s
        sqs.append((x, y, ang, s))
    # overlap check O(n^2) but n generally small
    for i in range(n):
        for j in range(i + 1, n):
            if not _overlap_ok_pair(sqs[i], sqs[j]):
                penalty += 1000.0
    return -total + penalty


def _overlap_ok_pair(a, b):
    """Return True if two squares do NOT overlap (SAT)."""
    def corners(cx, cy, ang, s):
        ca = math.cos(ang)
        sa = math.sin(ang)
        h = s * 0.5
        res = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            px = cx + dx * ca - dy * sa
            py = cy + dx * sa + dy * ca
            res.append((px, py))
        return res

    ci = corners(*a)
    cj = corners(*b)
    seps = []
    for poly in (ci, cj):
        m = len(poly)
        for k in range(m):
            p1 = poly[k]
            p2 = poly[(k + 1) % m]
            nx = p2[1] - p1[1]
            ny = -(p2[0] - p1[0])
            ln = math.hypot(nx, ny)
            if ln > 1e-15:
                nx /= ln
                ny /= ln
                seps.append((nx, ny))
    for nx, ny in seps:
        a_min = a_max = ci[0][0] * nx + ci[0][1] * ny
        for px, py in ci[1:]:
            v = px * nx + py * ny
            if v < a_min:
                a_min = v
            elif v > a_max:
                a_max = v
        b_min = b_max = cj[0][0] * nx + cj[0][1] * ny
        for px, py in cj[1:]:
            v = px * nx + py * ny
            if v < b_min:
                b_min = v
            elif v > b_max:
                b_max = v
        if a_max < b_min + 1e-10 or b_max < a_min + 1e-10:
            return True
    return False


def _eval_params(params, n):
    return _total_and_penalty(params, n, False)


def _make_grid(n):
    """Initial grid-based packing plus zeros."""
    k = math.isqrt(n)
    side = 1.0 / k
    sqs = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    sqs += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sqs))
    return sqs[:n]


def _optimize(n, sqs, time_budget=8.0):
    """Local continuous optimization from a starting configuration."""
    params = np.zeros(n * 4)
    for i, (x, y, a, s) in enumerate(sqs):
        params[4 * i] = x
        params[4 * i + 1] = y
        params[4 * i + 2] = a
        params[4 * i + 3] = s

    best = params.copy()
    best_val = _eval_params(best, n)

    # Multiple restarts / perturbation around current best
    max_iter = 2000 if n <= 16 else 800
    for restart in range(6):
        p0 = best + np.random.randn(n * 4) * (0.02 if restart > 0 else 0.0)
        p0 = np.clip(p0, -0.1, 1.1)
        # keep angle in [0,1)
        p0[2::4] = np.mod(p0[2::4], 1.0)

        res = minimize(
            _eval_params, p0, args=(n,),
            method='L-BFGS-B',
            options={'maxiter': max_iter, 'ftol': 1e-12, 'gtol': 1e-8}
        )
        val = _eval_params(res.x, n)
        if val < best_val - 1e-9:
            best_val = val
            best = res.x.copy()

    # clean up: validity check, clip, and if overlapping fall back
    result = []
    ok = True
    for i in range(n):
        x = float(np.clip(best[4 * i], 0.0, 1.0))
        y = float(np.clip(best[4 * i + 1], 0.0, 1.0))
        a = float(np.mod(best[4 * i + 2], 1.0))
        s = float(np.clip(best[4 * i + 3], 0.0, 1.0))
        result.append((x, y, a, s))

    # verify no overlaps; if any, shrink offending
    for i in range(n):
        for j in range(i + 1, n):
            if not _overlap_ok_pair(result[i], result[j]):
                x1, y1, a1, s1 = result[i]
                x2, y2, a2, s2 = result[j]
                # shrink both to 80% in an attempt to resolve
                s1 *= 0.8
                s2 *= 0.8
                result[i] = (x1, y1, a1, s1)
                result[j] = (x2, y2, a2, s2)

    # final validity pass: shrink until valid (simple loop)
    for _ in range(30):
        bad = False
        for i in range(n):
            for j in range(i + 1, n):
                if not _overlap_ok_pair(result[i], result[j]):
                    bad = True
                    x1, y1, a1, s1 = result[i]
                    x2, y2, a2, s2 = result[j]
                    s1 *= 0.95
                    s2 *= 0.95
                    result[i] = (x1, y1, a1, s1)
                    result[j] = (x2, y2, a2, s2)
        if not bad:
            break

    # ensure inside (shrink if needed)
    final = []
    for x, y, a, s in result:
        s = max(0.0, min(1.0, s))
        ca = math.cos(a)
        sa = math.sin(a)
        h = s * 0.5
        minx = min(x + dx * ca - dy * sa for dx, dy in ((-h,-h),(h,-h),(h,h),(-h,h)))
        maxx = max(x + dx * ca - dy * sa for dx, dy in ((-h,-h),(h,-h),(h,h),(-h,h)))
        miny = min(y + dx * sa + dy * ca for dx, dy in ((-h,-h),(h,-h),(h,h),(-h,h)))
        maxy = max(y + dx * sa + dy * ca for dx, dy in ((-h,-h),(h,-h),(h,h),(-h,h)))
        if minx < 0 or maxx > 1 or miny < 0 or maxy > 1:
            # shrink proportionally or translate if possible
            cx = (0.0 + 1.0) / 2
            cy = (0.0 + 1.0) / 2
            # translate toward centre
            tx = 0.0
            ty = 0.0
            if minx < 0:
                tx = -minx
            elif maxx > 1:
                tx = 1 - maxx
            if miny < 0:
                ty = -miny
            elif maxy > 1:
                ty = 1 - maxy
            nx = x + tx
            ny = y + ty
            # after translate, still check; if not, shrink
            minx2 = min(nx + dx * ca - dy * sa for dx, dy in ((-h,-h),(h,-h),(h,h),(-h,h)))
            maxx2 = max(nx + dx * ca - dy * sa for dx, dy in ((-h,-h),(h,-h),(h,h),(-h,h)))
            miny2 = min(ny + dx * sa + dy * ca for dx, dy in ((-h,-h),(h,-h),(h,h),(-h,h)))
            maxy2 = max(ny + dx * sa + dy * ca for dx, dy in ((-h,-h),(h,-h),(h,h),(-h,h)))
            if minx2 >= -1e-9 and maxx2 <= 1 + 1e-9 and miny2 >= -1e-9 and maxy2 <= 1 + 1e-9:
                x, y = nx, ny
            else:
                # scale side down
                sc = 1.0
                if minx < 0 or maxx > 1:
                    sc = min(sc, min(1.0, (1.0) / max(1e-9, (maxx - minx))))
                if miny < 0 or maxy > 1:
                    sc = min(sc, min(1.0, (1.0) / max(1e-9, (maxy - miny))))
                s *= sc * 0.95
                x = min(max(x, s * 0.5), 1 - s * 0.5)
                y = min(max(y, s * 0.5), 1 - s * 0.5)
        final.append((float(x), float(y), float(a), float(s)))
    return final


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # known good small configurations (approximate)
    known = {}
    if n == 2:
        known = [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
        # total 1.0, but can we do better? two squares side sum ~1.0
        # slight rotation could do a bit better? Probably not.
    if n == 3:
        # 2 equal + 1, can fit using optimized layout: total ~1.0
        known = [(0.25, 0.5, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.75, 0.75, 0.0, 0.0)]
        # placeholder, optimizer will improve
    if n == 4:
        known = [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                 (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    if n == 5:
        # known good layout: 2x2 grid + one rotated in centre? approximate
        known = None
    if n == 7:
        known = None

    # initial configuration
    if known is not None:
        sqs = known + [(0.5, 0.5, 0.0, 0.0)] * max(0, n - len(known))
    else:
        sqs = _make_grid(n)

    sqs = sqs[:n]

    # optimize with time budget depending on n
    if n <= 12:
        budget = 6.0
    elif n <= 25:
        budget = 5.0
    else:
        budget = 4.0

    try:
        result = _optimize(n, sqs, time_budget=budget)
    except Exception:
        result = sqs

    # final safety: ensure valid
    for i in range(n):
        x, y, a, s = result[i]
        s = max(0.0, min(1.0, s))
        x = max(0.0, min(1.0, x))
        y = max(0.0, min(1.0, y))
        a = float(math.fmod(a, 1.0))
        result[i] = (x, y, a, s)

    # shrink any overlapping
    for _ in range(20):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                if not _overlap_ok_pair(result[i], result[j]):
                    changed = True
                    x1, y1, a1, s1 = result[i]
                    x2, y2, a2, s2 = result[j]
                    s1 *= 0.9
                    s2 *= 0.9
                    result[i] = (x1, y1, a1, s1)
                    result[j] = (x2, y2, a2, s2)
        if not changed:
            break

    return result
