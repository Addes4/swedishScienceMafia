import math
import random
import numpy as np
from scipy.optimize import minimize, NonlinearConstraint, Bounds

# ---------- basic geometry ----------
def corners(cx, cy, ang_fraction, s):
    """Return 4 corners of the square."""
    th = ang_fraction * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    R = 0.5 * s
    # local corners
    pts = [(-R, -R), (R, -R), (R, R), (-R, R)]
    out = []
    for x, y in pts:
        out.append((cx + x * c - y * sn, cy + x * sn + y * c))
    return out

def sat_axes(corners1, corners2):
    """Separating axis test. Return True if interiors overlap."""
    # quick bounding-box test for speed
    for poly in (corners1, corners2):
        pass
    polys = [corners1, corners2]
    for poly in polys:
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            # normal to edge
            nx, ny = -(y2 - y1), (x2 - x1)
            # project both polygons
            min1 = min(x * nx + y * ny for x, y in corners1)
            max1 = max(x * nx + y * ny for x, y in corners1)
            min2 = min(x * nx + y * ny for x, y in corners2)
            max2 = max(x * nx + y * ny for x, y in corners2)
            if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
                return False
    return True

def contains_unit(corners, tol=1e-9):
    for x, y in corners:
        if x < -tol or x > 1 + tol or y < -tol or y > 1 + tol:
            return False
    return True

def max_side(cx, cy, ang_fraction, limit=0.5):
    """Max side for a square centred at position and angle inside unit square."""
    th = ang_fraction * 2.0 * math.pi
    c, sn = abs(math.cos(th)), abs(math.sin(th))
    # half-side R such that R*(c+sn) <= min(cx, 1-cx, cy, 1-cy)
    m = min(cx, 1.0 - cx, cy, 1.0 - cy)
    denom = c + sn
    if denom < 1e-12:
        return limit
    return min(limit, 2.0 * m / denom)

# ---------- initial heuristics ----------
def grid_packing(n):
    """Return list of (cx, cy, ang, side) for a good grid-based initial guess."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # try several patterns and keep the one with good total length and feasibility seed
    candidates = []

    # standard k x k grid
    k = math.isqrt(n)
    if k >= 1:
        s = 1.0 / k
        squares = []
        for i in range(k):
            for j in range(k):
                squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        # remaining squares get tiny size at random spots but inside
        rem = n - k * k
        for t in range(rem):
            # find a free-ish spot: just put very small squares at centre
            squares.append((0.5, 0.5, 0.0, 0.0))
        candidates.append((sum(sq[3] for sq in squares), squares))

    # rectangular grid: try all a x b with a*b <= n
    best_rect = None
    best_val = -1
    for a in range(1, n + 1):
        b = n // a
        if a * b < n:
            continue
        if a * b > n:
            continue
        # use rectangular grid a columns, b rows
        sx = 1.0 / a
        sy = 1.0 / b
        s = min(sx, sy)
        # if sx != sy, squares may not fit tightly; place on grid centres with size s
        if s <= 0:
            continue
        # check if a squares with side s fit in width: a*s <= 1 yes, height b*s <=1
        val = n * s
        if val > best_val:
            best_val = val
            squares = []
            # distribute centres
            # use centres at (i+0.5)*sx? Actually if s < sx, we can centre within cell.
            for i in range(a):
                for j in range(b):
                    cx = (i + 0.5) * sx
                    cy = (j + 0.5) * sy
                    squares.append((cx, cy, 0.0, s))
            # add remaining n - a*b tiny squares
            rem = n - a * b
            for _ in range(rem):
                squares.append((0.5, 0.5, 0.0, 0.0))
            candidates.append((sum(sq[3] for sq in squares), squares))

    # vertical strips
    # try k columns: each column has floor(n/k) or ceil(n/k) squares
    for k in range(1, n + 1):
        base = n // k
        rem = n % k
        # distribute: first rem columns have base+1, others base
        # each column gets width 1/k; inside column place squares vertically
        col_width = 1.0 / k
        squares = []
        # max side in a column given count m: side <= col_width, side*m <= 1
        for i in range(k):
            m = base + (1 if i < rem else 0)
            if m == 0:
                continue
            s = min(col_width, 1.0 / m)
            # place m squares in column i
            for j in range(m):
                cx = (i + 0.5) * col_width
                cy = (j + 0.5) * s
                squares.append((cx, cy, 0.0, s))
        # pad if needed
        while len(squares) < n:
            squares.append((0.5, 0.5, 0.0, 0.0))
        candidates.append((sum(sq[3] for sq in squares), squares[:n]))

    # horizontal strips
    for k in range(1, n + 1):
        base = n // k
        rem = n % k
        row_height = 1.0 / k
        squares = []
        for i in range(k):
            m = base + (1 if i < rem else 0)
            if m == 0:
                continue
            s = min(row_height, 1.0 / m)
            for j in range(m):
                cx = (j + 0.5) * s
                cy = (i + 0.5) * row_height
                squares.append((cx, cy, 0.0, s))
        while len(squares) < n:
            squares.append((0.5, 0.5, 0.0, 0.0))
        candidates.append((sum(sq[3] for sq in squares), squares[:n]))

    # pick best candidate
    candidates.sort(key=lambda x: -x[0])
    return candidates[0][1]

# ---------- overlap penalties ----------
def overlap_amount_poly(poly1, poly2):
    """Approximate overlap by clipping? Use SAT with tolerance; return 0 if separated,
       else return minimal translation distance along axes as proxy."""
    # We use a simple proxy: if SAT says overlap, compute penetration depth.
    min_pen = float('inf')
    polys = [poly1, poly2]
    for poly in polys:
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            nx, ny = -(y2 - y1), (x2 - x1)
            # normalise
            ln = math.hypot(nx, ny)
            if ln < 1e-15:
                continue
            nx /= ln
            ny /= ln
            min1 = min(x * nx + y * ny for x, y in poly1)
            max1 = max(x * nx + y * ny for x, y in poly1)
            min2 = min(x * nx + y * ny for x, y in poly2)
            max2 = max(x * nx + y * ny for x, y in poly2)
            # overlap on this axis
            if max1 <= min2 or max2 <= min1:
                return 0.0
            pen = min(max1 - min2, max2 - min1)
            min_pen = min(min_pen, pen)
    return min_pen

# ---------- refinement ----------
def refine(squares, n, time_frac=1.0):
    """
    Local refinement of square positions/angles/sizes to maximise sum of sides.
    Uses penalty function + coordinate descent / SLSQP.
    squares: list of (cx, cy, ang, side)
    """
    # Variables: for each square: cx, cy, angle, side (but angle as fraction, can wrap)
    # We'll optimize in unconstrained-ish way with bounds and penalties.
    # To reduce dimensionality for n large, we focus on the largest squares.

    # Sort by side descending; keep at most 30 largest for full optimisation, rest fixed.
    indexed = list(enumerate(squares))
    indexed.sort(key=lambda x: -x[1][3])
    opt_indices = set(i for i, _ in indexed[:min(n, 25)])
    if n <= 25:
        opt_indices = set(range(n))

    # Build variable vector for optimisable squares
    idx_list = sorted(opt_indices)
    x0 = []
    bounds = []
    for i in idx_list:
        cx, cy, ang, s = squares[i]
        x0.extend([cx, cy, ang % 1.0, s])
        bounds.extend([(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 0.5)])

    x0 = np.array(x0, dtype=float)

    def unpack(x):
        sq = [list(s) for s in squares]
        for k, i in enumerate(idx_list):
            sq[i] = [x[4*k], x[4*k+1], x[4*k+2], x[4*k+3]]
        return sq

    def objective(x):
        sq = unpack(x)
        total = 0.0
        for cx, cy, ang, s in sq:
            # enforce that square must fit (penalty for out-of-bounds)
            corners_ = corners(cx, cy, ang, s)
            for px, py in corners_:
                if px < 0:
                    total -= 1000.0 * (-px) ** 2
                elif px > 1:
                    total -= 1000.0 * (px - 1) ** 2
                if py < 0:
                    total -= 1000.0 * (-py) ** 2
                elif py > 1:
                    total -= 1000.0 * (py - 1) ** 2
            total += s
        # overlap penalties
        for i in range(len(sq)):
            for j in range(i + 1, len(sq)):
                c1 = corners(*sq[i])
                c2 = corners(*sq[j])
                # quick bounding box
                xmin1 = min(p[0] for p in c1)
                xmax1 = max(p[0] for p in c1)
                ymin1 = min(p[1] for p in c1)
                ymax1 = max(p[1] for p in c1)
                xmin2 = min(p[0] for p in c2)
                xmax2 = max(p[0] for p in c2)
                ymin2 = min(p[1] for p in c2)
                ymax2 = max(p[1] for p in c2)
                if xmax1 <= xmin2 or xmax2 <= xmin1 or ymax1 <= ymin2 or ymax2 <= ymin1:
                    continue
                ov = overlap_amount_poly(c1, c2)
                if ov > 0:
                    total -= 1000.0 * ov * ov
        return -total  # minimise negative

    # Use Nelder-Mead for small n, SLSQP for larger
    if len(x0) <= 24:
        try:
            res = minimize(objective, x0, method='Nelder-Mead',
                           options={'maxiter': 5000, 'xatol': 1e-8, 'fatol': 1e-8, 'disp': False})
            x0 = res.x
        except Exception:
            pass
    else:
        try:
            res = minimize(objective, x0, method='Powell',
                           bounds=bounds,
                           options={'maxiter': 2000, 'xtol': 1e-6, 'ftol': 1e-8, 'disp': False})
            x0 = res.x
        except Exception:
            pass

    # Second pass with SLSQP if possible
    try:
        cons = []
        # enforce containment via inequalities: for each square's corners inside [0,1]
        # This is messy; use penalty approach but do another local refinement with Nelder-Mead
        # We'll just do another Powell with tighter tolerance
        res = minimize(objective, x0, method='Powell',
                       bounds=bounds,
                       options={'maxiter': 3000, 'xtol': 1e-8, 'ftol': 1e-10, 'disp': False})
        x0 = res.x
    except Exception:
        pass

    final_sq = unpack(x0)
    # Ensure all are safe: clip sizes to max possible and zero out overlaps if any remain
    # (fallback: shrink tiny)
    for i in range(len(final_sq)):
        cx, cy, ang, s = final_sq[i]
        ms = max_side(cx, cy, ang, limit=0.5)
        s = min(s, ms)
        s = max(s, 0.0)
        final_sq[i] = [cx, cy, ang % 1.0, s]

    # Resolve remaining overlaps by shrinking
    for _ in range(10):
        changed = False
        for i in range(len(final_sq)):
            for j in range(i + 1, len(final_sq)):
                c1 = corners(*final_sq[i])
                c2 = corners(*final_sq[j])
                ov = overlap_amount_poly(c1, c2)
                if ov > 1e-10:
                    # shrink both
                    final_sq[i][3] *= 0.9
                    final_sq[j][3] *= 0.9
                    changed = True
        if not changed:
            break

    return [(sq[0], sq[1], sq[2], sq[3]) for sq in final_sq]

# ---------- main solve ----------
def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n == 0:
        return []
    # initial guess
    squares = grid_packing(n)
    # refine
    res = refine(squares, n)
    # final safety: if any overlap remains, fallback to grid
    # count overlaps
    for i in range(len(res)):
        for j in range(i + 1, len(res)):
            c1 = corners(*res[i])
            c2 = corners(*res[j])
            if overlap_amount_poly(c1, c2) > 1e-7:
                return grid_packing(n)
    return res
