import math
import numpy as np
from scipy.optimize import minimize


def _rot_corners(cx, cy, ang, s):
    """Return the 4 corners of a square (cx, cy, angle fraction, side s)."""
    th = 2.0 * math.pi * ang
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    # local corners of square centered at origin, then rotate + translate
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        rx = c * x - sn * y + cx
        ry = sn * x + c * y + cy
        out.append((rx, ry))
    return out


def _axes(ang):
    th = 2.0 * math.pi * ang
    c, sn = math.cos(th), math.sin(th)
    # edge directions
    return (c, sn), (-sn, c)


def _overlap_penalty(sq1, sq2):
    """Return positive violation if interiors overlap (approx via SAT)."""
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= 1e-14 or s2 <= 1e-14:
        return 0.0
    p1 = _rot_corners(cx1, cy1, a1, s1)
    p2 = _rot_corners(cx2, cy2, a2, s2)
    axes = list(_axes(a1)) + list(_axes(a2))
    best = -1e9
    for ax, ay in axes:
        min1 = min(px * ax + py * ay for px, py in p1)
        max1 = max(px * ax + py * ay for px, py in p1)
        min2 = min(px * ax + py * ay for px, py in p2)
        max2 = max(px * ax + py * ay for px, py in p2)
        gap = max(min1 - max2, min2 - max1)
        if gap > best:
            best = gap
    # best < 0 means separated on some axis; >0 means all axes overlap -> interior overlap
    # For disjoint interiors we need best <= 0 with epsilon tolerance.
    return max(0.0, best + 1e-12)


def _objective(params, n):
    # maximize sum side -> minimize -sum side
    xs = params.reshape(n, 4)
    return -np.sum(xs[:, 3])


def _constraints(params, n):
    xs = params.reshape(n, 4)
    cons = []
    # bounds: center in [0,1]
    for i in range(n):
        cx, cy, ang, s = xs[i]
        cons.append(cx)
        cons.append(1.0 - cx)
        cons.append(cy)
        cons.append(1.0 - cy)
    # squares inside box: corners in [0,1]
    for i in range(n):
        cx, cy, ang, s = xs[i]
        if s > 0:
            for (px, py) in _rot_corners(cx, cy, ang, s):
                cons.append(px)
                cons.append(1.0 - px)
                cons.append(py)
                cons.append(1.0 - py)
    # overlap penalty constraints
    for i in range(n):
        for j in range(i + 1, n):
            cons.append(-_overlap_penalty(tuple(xs[i]), tuple(xs[j])))
    return np.array(cons)


def _initial_guess(n):
    """Several structured starting points; return list of parameter arrays."""
    guesses = []

    # 1) grid k x k with leftover zero
    k = math.isqrt(n)
    if k >= 1:
        side = 1.0 / k
        xs = []
        for i in range(k):
            for j in range(k):
                if len(xs) >= n:
                    break
                xs.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
            if len(xs) >= n:
                break
        while len(xs) < n:
            xs.append([0.5, 0.5, 0.0, 0.0])
        guesses.append(np.array(xs).ravel())

    # 2) grid with rows of different counts (strip packing)
    # try rows: distribute n into r rows with alternating sizes; simple heuristic
    for r in range(1, min(n, 12) + 1):
        counts = [n // r] * r
        for i in range(n % r):
            counts[i] += 1
        # each row has same height = min over rows of 1/count * something
        # we can fit each row independently: side = min(1/count, 1/r)?
        # Simpler: uniform grid-like rows
        side = min(1.0 / max(counts), 1.0 / r)
        xs = []
        y = 0.0
        for cnt in counts:
            if cnt == 0:
                continue
            h = side
            w = 1.0 / cnt
            for c in range(cnt):
                if len(xs) >= n:
                    break
                xs.append([(c + 0.5) * w, y + h * 0.5, 0.0, min(w, h)])
            y += h
        while len(xs) < n:
            xs.append([0.5, 0.5, 0.0, 0.0])
        guesses.append(np.array(xs).ravel())

    # 3) perturbed grid starts
    base = guesses[0].reshape(-1, 4).copy()
    for scale in [0.01, 0.03, 0.05]:
        xp = base.copy()
        for i in range(xp.shape[0]):
            if xp[i, 3] > 0:
                xp[i, 0] = min(1.0, max(0.0, xp[i, 0] + np.random.uniform(-scale, scale)))
                xp[i, 1] = min(1.0, max(0.0, xp[i, 1] + np.random.uniform(-scale, scale)))
                xp[i, 2] = np.random.uniform(0.0, 0.5)
        guesses.append(xp.ravel())

    # 4) all zero except largest grid
    return guesses


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    np.random.seed(12345)

    best_params = None
    best_val = -1e18

    guesses = _initial_guess(n)

    # time budget guard
    import time
    start = time.time()
    time_limit = 58.0

    def cons_fun(params):
        return _constraints(params, n)

    bounds = []
    for _ in range(n):
        bounds += [(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 0.5)]

    for gi, x0 in enumerate(guesses):
        if time.time() - start > time_limit:
            break
        try:
            res = minimize(
                _objective, x0,
                args=(n,),
                method='SLSQP',
                bounds=bounds,
                constraints={'type': 'ineq', 'fun': cons_fun},
                options={'maxiter': 300, 'ftol': 1e-9, 'disp': False}
            )
            if res.success or res.fun < best_val:
                val = -res.fun
                if val > best_val and np.all(cons_fun(res.x) >= -1e-6):
                    best_val = val
                    best_params = res.x.copy()
        except Exception:
            continue

        # local refinement from best so far with random restarts
        if best_params is not None and gi % 2 == 1:
            for _ in range(2):
                if time.time() - start > time_limit:
                    break
                xp = best_params.copy()
                for i in range(n):
                    if xp[4 * i + 3] > 0:
                        xp[4 * i + 0] = min(1.0, max(0.0, xp[4 * i + 0] + np.random.uniform(-0.02, 0.02)))
                        xp[4 * i + 1] = min(1.0, max(0.0, xp[4 * i + 1] + np.random.uniform(-0.02, 0.02)))
                        xp[4 * i + 2] = min(1.0, max(0.0, xp[4 * i + 2] + np.random.uniform(-0.05, 0.05)))
                try:
                    res = minimize(
                        _objective, xp,
                        args=(n,),
                        method='SLSQP',
                        bounds=bounds,
                        constraints={'type': 'ineq', 'fun': cons_fun},
                        options={'maxiter': 200, 'ftol': 1e-9, 'disp': False}
                    )
                    if res.fun < -best_val and np.all(cons_fun(res.x) >= -1e-6):
                        best_val = -res.fun
                        best_params = res.x.copy()
                except Exception:
                    pass

    if best_params is None:
        # fallback: simple grid
        k = math.isqrt(n)
        side = 1.0 / k
        out = []
        for i in range(k):
            for j in range(k):
                if len(out) >= n:
                    break
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
            if len(out) >= n:
                break
        while len(out) < n:
            out.append((0.5, 0.5, 0.0, 0.0))
        return out[:n]

    xs = best_params.reshape(n, 4)
    result = []
    for i in range(n):
        cx, cy, ang, s = xs[i]
        # clamp to [0,1] as required by problem
        cx = min(1.0, max(0.0, float(cx)))
        cy = min(1.0, max(0.0, float(cy)))
        ang = min(1.0, max(0.0, float(ang)))
        s = min(1.0, max(0.0, float(s)))
        result.append((cx, cy, ang, s))
    return result
