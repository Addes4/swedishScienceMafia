"""Optimized square packing solver using simulated annealing with soft penalties."""
import math
import random
import numpy as np

TWO_PI = 2.0 * math.pi


def _sat_overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """Return True if two squares (center, angle fraction, side) overlap in interior."""
    if s1 <= 0.0 or s2 <= 0.0:
        return False
    t1 = a1 * TWO_PI
    t2 = a2 * TWO_PI
    c1, s1_ = math.cos(t1), math.sin(t1)
    c2, s2_ = math.cos(t2), math.sin(t2)
    h1 = s1 * 0.5
    h2 = s2 * 0.5
    # Axes to test: both squares' edge normals
    axes = ((c1, s1_), (-s1_, c1), (c2, s2_), (-s2_, c2))
    dx = cx2 - cx1
    dy = cy2 - cy1
    for ax, ay in axes:
        # projection radius of square 1
        r1 = h1 * (abs(c1 * ax + s1_ * ay) + abs(-s1_ * ax + c1 * ay))
        r2 = h2 * (abs(c2 * ax + s2_ * ay) + abs(-s2_ * ax + c2 * ay))
        d = abs(dx * ax + dy * ay)
        if d >= r1 + r2 - 1e-12:
            return False
    return True


def _penalty(squares):
    """Total overlap area proxy + boundary penalty."""
    total = 0.0
    n = len(squares)
    for i in range(n):
        cx, cy, a, s = squares[i]
        if s <= 0.0:
            # point square: boundary only if outside
            if cx < 0.0 or cx > 1.0 or cy < 0.0 or cy > 1.0:
                total += 1000.0 * ((min(0.0, cx) ** 2 + max(0.0, cx - 1.0) ** 2) +
                                   (min(0.0, cy) ** 2 + max(0.0, cy - 1.0) ** 2))
            continue
        h = s * 0.5
        t = a * TWO_PI
        # AABB half-extent
        ex = h * (abs(math.cos(t)) + abs(math.sin(t)))
        ey = h * (abs(-math.sin(t)) + abs(math.cos(t)))
        # boundary violation
        if cx - ex < 0.0:
            total += (0.0 - (cx - ex)) ** 2
        if cx + ex > 1.0:
            total += (cx + ex - 1.0) ** 2
        if cy - ey < 0.0:
            total += (0.0 - (cy - ey)) ** 2
        if cy + ey > 1.0:
            total += (cy + ey - 1.0) ** 2
        for j in range(i + 1, n):
            cx2, cy2, a2, s2 = squares[j]
            if s2 <= 0.0:
                continue
            if _sat_overlap(cx, cy, a, s, cx2, cy2, a2, s2):
                # approximate overlap area penalty
                total += 10.0 * (min(s, s2) ** 2)
    return total


def _score(squares, w):
    """Objective: sum of sides - w * penalty."""
    tot = sum(sq[3] for sq in squares)
    if w > 0.0:
        tot -= w * _penalty(squares)
    return tot


def _clamp_squares(squares):
    """Fix boundary violations by shrinking/shifting slightly."""
    out = []
    for cx, cy, a, s in squares:
        if s <= 0.0:
            out.append((min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), a, 0.0))
            continue
        h = s * 0.5
        t = a * TWO_PI
        ex = h * (abs(math.cos(t)) + abs(math.sin(t)))
        ey = h * (abs(-math.sin(t)) + abs(math.cos(t)))
        # shrink if needed
        max_s = s
        if ex > 0.5:
            max_s = min(max_s, 0.5 / (0.5 * (abs(math.cos(t)) + abs(math.sin(t)))))
        if ey > 0.5:
            max_s = min(max_s, 0.5 / (0.5 * (abs(-math.sin(t)) + abs(math.cos(t)))))
        s = max(0.0, min(s, max_s))
        h = s * 0.5
        ex = h * (abs(math.cos(t)) + abs(math.sin(t)))
        ey = h * (abs(-math.sin(t)) + abs(math.cos(t)))
        cx = min(max(cx, ex), 1.0 - ex)
        cy = min(max(cy, ey), 1.0 - ey)
        out.append((cx, cy, a, s))
    return out


def _initial(n, rng):
    """Initial layout: grid or dense packing."""
    squares = []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two unit/2 squares
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # 0.5, 0.5 in a column + 0.5
        return [(0.25, 0.25, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    # For general n, arrange in a grid-plus-remainder
    k = int(math.floor(math.sqrt(n)))
    while k * k > n:
        k -= 1
    # total count in k x k grid
    side = 1.0 / k
    count = 0
    for i in range(k):
        for j in range(k):
            if count < n:
                squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
                count += 1
    # remaining squares: fill empty space with small squares or points
    extra = n - len(squares)
    for _ in range(extra):
        squares.append((rng.random(), rng.random(), rng.random(), 0.02))
    return squares


def _anneal(squares, n, rng, iters=3000, T0=0.05, T1=1e-5):
    """Simulated annealing on square parameters."""
    squares = [list(sq) for sq in squares]
    w = 5.0
    best = [list(sq) for sq in squares]
    best_val = _score(squares, w)
    cur_val = best_val
    T = T0
    alpha = (T1 / T0) ** (1.0 / max(iters, 1))
    for it in range(iters):
        T *= alpha
        if rng.random() < 0.5:
            # perturb a random square
            i = rng.randrange(n)
            sq = squares[i]
            if sq[3] <= 0.0:
                sq[0] = min(max(sq[0] + rng.uniform(-0.05, 0.05), 0.0), 1.0)
                sq[1] = min(max(sq[1] + rng.uniform(-0.05, 0.05), 0.0), 1.0)
                sq[3] = max(0.0, rng.uniform(0.0, 0.05))
            else:
                r = rng.random()
                if r < 0.3:
                    sq[0] += rng.gauss(0, 0.03)
                elif r < 0.6:
                    sq[1] += rng.gauss(0, 0.03)
                elif r < 0.8:
                    sq[2] = (sq[2] + rng.gauss(0, 0.05)) % 1.0
                else:
                    sq[3] += rng.gauss(0, 0.02)
                # clamp
                sq[0] = min(max(sq[0], 0.0), 1.0)
                sq[1] = min(max(sq[1], 0.0), 1.0)
                sq[3] = max(0.0, min(sq[3], 1.0))
        else:
            # perturb a random pair jointly (move)
            i = rng.randrange(n)
            j = rng.randrange(n)
            if i != j:
                dx = rng.gauss(0, 0.03)
                dy = rng.gauss(0, 0.03)
                squares[i][0] = min(max(squares[i][0] + dx, 0.0), 1.0)
                squares[i][1] = min(max(squares[i][1] + dy, 0.0), 1.0)
                squares[j][0] = min(max(squares[j][0] - dx, 0.0), 1.0)
                squares[j][1] = min(max(squares[j][1] - dy, 0.0), 1.0)
        # incremental acceptance
        new_val = _score(squares, w)
        delta = new_val - cur_val
        if delta >= 0.0 or rng.random() < math.exp(delta / max(T, 1e-12)):
            cur_val = new_val
            if new_val > best_val:
                best_val = new_val
                best = [list(sq) for sq in squares]
        else:
            # revert
            pass
    # final polish: increase barrier weight
    w = 50.0
    cur_val = _score(best, w)
    best_val = cur_val
    for it in range(iters):
        T *= alpha
        i = rng.randrange(n)
        sq = best[i]
        if sq[3] <= 0.0:
            sq[0] = min(max(sq[0] + rng.uniform(-0.02, 0.02), 0.0), 1.0)
            sq[1] = min(max(sq[1] + rng.uniform(-0.02, 0.02), 0.0), 1.0)
            sq[3] = max(0.0, rng.uniform(0.0, 0.03))
        else:
            r = rng.random()
            if r < 0.35:
                sq[0] += rng.gauss(0, 0.01)
            elif r < 0.7:
                sq[1] += rng.gauss(0, 0.01)
            elif r < 0.85:
                sq[2] = (sq[2] + rng.gauss(0, 0.02)) % 1.0
            else:
                sq[3] += rng.gauss(0, 0.01)
            sq[0] = min(max(sq[0], 0.0), 1.0)
            sq[1] = min(max(sq[1], 0.0), 1.0)
            sq[3] = max(0.0, min(sq[3], 1.0))
        new_val = _score(best, w)
        delta = new_val - cur_val
        if delta >= 0.0 or rng.random() < math.exp(delta / max(T, 1e-12)):
            cur_val = new_val
        else:
            # revert: reload best
            pass
    return best


def solve(n):
    """
    Return n squares (centre_x, centre_y, angle, side) inside unit square,
    disjoint interiors, maximising sum of sides.
    """
    if n <= 0:
        return []
    rng = random.Random(12345)
    best = None
    best_sum = -1.0

    # Try multiple restarts and annealing
    n_restarts = 4 if n <= 30 else 2
    for r in range(n_restarts):
        rng = random.Random(1234 + r * 7919)
        init = _initial(n, rng)
        # For larger n, use more iterations
        iters = max(2000, min(8000, 300 * n))
        try:
            result = _anneal(init, n, rng, iters=iters)
        except Exception:
            result = init
        # final safe clamping
        result = _clamp_squares(result)
        s = sum(sq[3] for sq in result)
        # Verify overlap; if any, shrink offending squares
        result = _fix_overlaps(result)
        s = sum(sq[3] for sq in result)
        if s > best_sum:
            best_sum = s
            best = result
    if best is None:
        best = _initial(n, rng)
    # ensure all within [0,1] and valid
    out = []
    for cx, cy, a, s in best:
        out.append((min(max(cx, 0.0), 1.0),
                    min(max(cy, 0.0), 1.0),
                    a % 1.0,
                    max(0.0, min(s, 1.0))))
    return out


def _fix_overlaps(squares):
    """Detect and reduce overlaps by shrinking the smaller square."""
    squares = [list(sq) for sq in squares]
    n = len(squares)
    changed = True
    guard = 0
    while changed and guard < 20:
        changed = False
        guard += 1
        for i in range(n):
            for j in range(i + 1, n):
                if squares[i][3] <= 0.0 or squares[j][3] <= 0.0:
                    continue
                if _sat_overlap(squares[i][0], squares[i][1], squares[i][2], squares[i][3],
                                squares[j][0], squares[j][1], squares[j][2], squares[j][3]):
                    # shrink smaller square
                    if squares[i][3] <= squares[j][3]:
                        squares[i][3] *= 0.85
                    else:
                        squares[j][3] *= 0.85
                    changed = True
    # clamp to boundary
    return _clamp_squares(squares)


# Export
__all__ = ['solve']
