import math
import random

def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # --- Phase 1: grid tiling k x k ---
    k = math.isqrt(n)
    r = n - k * k           # leftover squares
    rects = []              # each: [cx, cy, angle, side]
    s = 1.0 / k
    for i in range(k):
        for j in range(k):
            rects.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])

    # --- Phase 2: distribute leftover by splitting some cells ---
    # Choose r cells to split into 4 quarters (each split adds 3 squares).
    # Prefer to add squares as small ones inside, keeping big tiles intact.
    # If r >= 3 we can split cells; else add tiny squares in corners of free area.
    idx = 0
    while r >= 3 and idx < len(rects):
        # split this cell into 4
        cx, cy, ang, side = rects[idx]
        assert abs(ang) < 1e-12
        hs = side * 0.25   # half of quarter
        q = side * 0.5
        rects[idx] = [cx - q, cy - q, 0.0, side]  # placeholder will be replaced
        # replace with 4 quarters
        rects[idx:idx+1] = [
            [cx - 0.25*side, cy - 0.25*side, 0.0, 0.5*side],
            [cx + 0.25*side, cy - 0.25*side, 0.0, 0.5*side],
            [cx - 0.25*side, cy + 0.25*side, 0.0, 0.5*side],
            [cx + 0.25*side, cy + 0.25*side, 0.0, 0.5*side],
        ]
        r -= 3
        idx += 4  # move past new ones

    # Any remaining r (0,1,2) -> place tiny squares near a corner of some cell
    # (small enough not to interfere)
    if r > 0:
        base = [0.0, 0.0, 0.0, 1e-4]
        for _ in range(r):
            rects.append(base[:])

    if len(rects) < n:
        rects += [[0.5, 0.5, 0.0, 0.0]] * (n - len(rects))
    rects = rects[:n]

    # --- Phase 3: local improvement (coordinate ascent on centers) ---
    # Move each square toward the closest wall/corner greedily, resizing if possible.
    # We use a simple iterative "spread" heuristic:
    def clamped(v):
        return min(max(v, 0.0), 1.0)

    # Try to grow each square slightly and shift it into free space.
    # Since we can't easily compute free space with rotations, we do random small
    # perturbations that increase side while keeping it within [0,1] (axis-aligned only).
    # For rotated, we skip growth.

    best = [r[:] for r in rects]
    best_score = sum(r[3] for r in rects)

    # Deterministic improvement: try to expand each square a tiny bit if there's room
    # (approximation: check if new bounding box fits in [0,1])
    for _ in range(20):
        improved = False
        for i in range(len(best)):
            cx, cy, ang, side = best[i]
            if abs(ang) > 1e-9:
                continue
            # try to expand side by delta keeping center fixed and inside
            for delta in (side * 0.1, side * 0.05, side * 0.01):
                ns = side + delta
                half = ns / 2.0
                if cx - half < -1e-12 or cx + half > 1 + 1e-12:
                    continue
                if cy - half < -1e-12 or cy + half > 1 + 1e-12:
                    continue
                # check overlap with all other squares (axis-aligned AABB only)
                ok = True
                for j in range(len(best)):
                    if j == i:
                        continue
                    ox, oy, oa, os = best[j]
                    if abs(oa) > 1e-9:
                        # rotated: skip strict check (conservative: shrink bounding circle)
                        # treat as circle radius os*0.71
                        dist = math.hypot(cx-ox, cy-oy)
                        if dist < (ns + os*1.42) / 2.0:
                            ok = False
                            break
                    else:
                        # AABB overlap check with small epsilon
                        if abs(cx - ox) < (ns + os)/2.0 - 1e-9 and abs(cy - oy) < (ns + os)/2.0 - 1e-9:
                            ok = False
                            break
                if ok:
                    best[i][3] = ns
                    improved = True
                    break
        if not improved:
            break

    # Final safety clamp
    result = []
    for cx, cy, ang, side in best:
        side = max(0.0, min(1.0, side))
        cx = clamped(cx)
        cy = clamped(cy)
        ang = ang % 1.0
        result.append((cx, cy, ang, side))
    return result[:n]
