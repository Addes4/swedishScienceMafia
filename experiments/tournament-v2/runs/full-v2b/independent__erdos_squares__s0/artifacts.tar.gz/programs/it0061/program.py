import math


def solve(n):
    if n == 0:
        return []

    # Try several strip counts and choose the best total.
    best = None
    for strips in range(1, min(n, 60) + 1):
        squares = _strip_construction(n, strips)
        if squares is None:
            continue
        total = sum(s[3] for s in squares)
        if best is None or total > best[0]:
            best = (total, squares)

    if best is None:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    return best[1]


def _strip_construction(n, strips):
    """Fill the unit square with `strips` horizontal strips.
    Strip i has height h_i and contains m_i squares of side s_i = h_i.
    The number of squares across strip i is floor(1 / s_i) (at least 1).
    We then allocate the remaining squares as size 0.
    """
    # Start with equal heights.
    h = [1.0 / strips] * strips
    total_sq = 1.0

    # Iteratively adjust heights using a greedy coordinate ascent.
    # For each strip, try to increase its height if it allows more squares,
    # while shrinking other strips.
    for _ in range(200):
        improved = False
        for i in range(strips):
            # Try all possible integer counts m for strip i.
            # Given m squares of side s, we need m*s <= 1, so s <= 1/m.
            # Also the strip height is s.
            # We want to maximize m*s (contribution).
            # Current height of strip i:
            hi = h[i]
            # Try increasing hi to the next useful value 1/m where m = floor(1/hi) - 1
            # or decreasing to 1/m where m = floor(1/hi) + 1
            m_cur = max(1, int(math.floor(1.0 / hi)) if hi > 0 else 1)
            candidates = set()
            for delta in (-1, 1):
                m = m_cur + delta
                if m >= 1:
                    candidates.add(1.0 / m)
            # Also consider current
            candidates.add(hi)

            for hnew in candidates:
                if hnew <= 0 or hnew > 1:
                    continue
                # Check feasibility: sum of heights must be <= 1.
                # We need to adjust other strips to make room.
                # Simple approach: scale other strips proportionally.
                others = [h[j] for j in range(strips) if j != i]
                if not others:
                    if hnew > 1:
                        continue
                    h[i] = hnew
                    improved = True
                    break
                sum_others = sum(others)
                if sum_others == 0:
                    continue
                # Total height with new = hnew + sum_others. If >1, scale others down.
                if hnew + sum_others > 1.0 + 1e-12:
                    scale = (1.0 - hnew) / sum_others
                    if scale < 0:
                        continue
                    new_h = [hnew if j == i else h[j] * scale for j in range(strips)]
                else:
                    new_h = list(h)
                    new_h[i] = hnew

                # Check that we can get at least n squares total.
                # Count squares possible.
                count = 0
                for j in range(strips):
                    hj = new_h[j]
                    if hj <= 0:
                        continue
                    mj = max(1, int(math.floor(1.0 / hj + 1e-12)))
                    count += mj
                if count >= n:
                    # Also check feasibility: sum <= 1
                    if sum(new_h) <= 1.0 + 1e-9:
                        # Compare contribution
                        old_contrib = 0
                        new_contrib = 0
                        for j in range(strips):
                            if j == i:
                                old_contrib += (max(1, int(math.floor(1.0 / h[j] + 1e-12))) if h[j] > 0 else 1) * h[j]
                                new_contrib += (max(1, int(math.floor(1.0 / new_h[j] + 1e-12))) if new_h[j] > 0 else 1) * new_h[j]
                            else:
                                old_contrib += (max(1, int(math.floor(1.0 / h[j] + 1e-12))) if h[j] > 0 else 1) * h[j]
                                new_contrib += (max(1, int(math.floor(1.0 / new_h[j] + 1e-12))) if new_h[j] > 0 else 1) * new_h[j]
                        if new_contrib > old_contrib + 1e-15:
                            h = new_h
                            improved = True
                            break
        if not improved:
            break

    # Build squares from final heights.
    squares = []
    y = 0.0
    remaining = n
    for i in range(strips):
        hi = h[i]
        if hi <= 1e-15 or remaining <= 0:
            continue
        m = max(1, int(math.floor(1.0 / hi + 1e-12)))
        m = min(m, remaining)
        # Place m squares of side hi across the strip.
        for k in range(m):
            cx = (k + 0.5) * hi
            cy = y + hi * 0.5
            if cx + hi * 0.5 > 1.0 + 1e-12:
                # Shouldn't happen with m = floor(1/hi)
                break
            squares.append((cx, cy, 0.0, hi))
            remaining -= 1
        y += hi

    # If we have fewer than n squares, pad with zeros.
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))

    return squares[:n]
