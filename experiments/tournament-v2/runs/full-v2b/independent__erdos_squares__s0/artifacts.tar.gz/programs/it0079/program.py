import math
import random
import numpy as np
from scipy.optimize import minimize

def _overlap_area(s1, s2):
    # approximate overlap via sampling? Instead use separation constraints for axis-aligned/rotated.
    # We'll use a penalty method based on SAT-like projection for convex polygons.
    def corners(cx, cy, ang, side):
        a = ang * 2 * math.pi
        ca, sa = math.cos(a), math.sin(a)
        h = side / 2.0
        pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
        return [(cx + x * ca - y * sa, cy + x * sa + y * ca) for x, y in pts]

    def proj(poly, axis):
        dots = [p[0] * axis[0] + p[1] * axis[1] for p in poly]
        return min(dots), max(dots)

    def sat_overlap(poly1, poly2):
        # returns True if interiors overlap (for convex polys)
        for poly in (poly1, poly2):
            n = len(poly)
            for i in range(n):
                x1, y1 = poly[i]
                x2, y2 = poly[(i + 1) % n]
                edge = (x2 - x1, y2 - y1)
                axis = (-edge[1], edge[0])
                ln = math.hypot(*axis)
                if ln < 1e-12:
                    continue
                axis = (axis[0] / ln, axis[1] / ln)
                min1, max1 = proj(poly1, axis)
                min2, max2 = proj(poly2, axis)
                if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
                    return False
        return True

    p1 = corners(*s1)
    p2 = corners(*s2)
    return sat_overlap(p1, p2)

def _in_unit(cx, cy, ang, side, tol=1e-9):
    a = ang * 2 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side / 2.0
    for dx, dy in [(-h, -h), (h, -h), (h, h), (-h, h)]:
        x = cx + dx * ca - dy * sa
        y = cy + dx * sa + dy * ca
        if x < -tol or x > 1 + tol or y < -tol or y > 1 + tol:
            return False
    return True

def _clamp_to_unit(cx, cy, ang, side):
    # compute feasible translation interval for a rotated square to stay in [0,1]^2
    a = ang * 2 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side / 2.0
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    xs = []
    ys = []
    for x, y in pts:
        xs.append(x * ca - y * sa)
        ys.append(x * sa + y * ca)
    minx, maxx = min(xs), max(xs)
    miny, maxy = min(ys), max(ys)
    cx = min(max(cx, -minx), 1 - maxx)
    cy = min(max(cy, -miny), 1 - maxy)
    # also possible side too large
    max_side_x = 1.0 / (maxx - minx) if maxx > minx else 1e9
    max_side_y = 1.0 / (maxy - miny) if maxy > miny else 1e9
    max_side = min(max_side_x, max_side_y)
    if side > max_side:
        side = max_side
    return cx, cy, ang, side

def _objective_and_penalty(params, n, w):
    # params: list of (cx,cy,ang,side) flattened
    squares = []
    idx = 0
    pen = 0.0
    for i in range(n):
        cx = params[idx]; cy = params[idx+1]; ang = params[idx+2]; side = params[idx+3]
        idx += 4
        # penalize out of bounds
        a = ang * 2 * math.pi
        ca, sa = math.cos(a), math.sin(a)
        h = side / 2.0
        for dx, dy in [(-h, -h), (h, -h), (h, h), (-h, h)]:
            x = cx + dx * ca - dy * sa
            y = cy + dx * sa + dy * ca
            if x < 0: pen += w * (0 - x)
            if x > 1: pen += w * (x - 1)
            if y < 0: pen += w * (0 - y)
            if y > 1: pen += w * (y - 1)
        squares.append((cx, cy, ang, side))
    # penalize overlaps
    for i in range(n):
        for j in range(i+1, n):
            s1 = squares[i]; s2 = squares[j]
            if s1[3] < 1e-12 or s2[3] < 1e-12:
                continue
            if _overlap_area(s1, s2):
                # compute a rough overlap penalty
                # use distance between centers vs sum of half-diagonals
                dx = s1[0] - s2[0]; dy = s1[1] - s2[1]
                d = math.hypot(dx, dy)
                r1 = s1[3] * 0.7071; r2 = s2[3] * 0.7071
                pen += w * max(0.0, (r1 + r2) - d)**2
    obj = -sum(s[3] for s in squares) + pen
    return obj

def _optimize(n, squares, iters=200):
    if n == 0:
        return squares
    x0 = []
    for cx, cy, ang, side in squares:
        x0.extend([cx, cy, ang, side])
    x0 = np.array(x0)
    bounds = []
    for i in range(n):
        bounds.append((0, 1))
        bounds.append((0, 1))
        bounds.append((0, 0.5))
        bounds.append((0, 1.5))
    w = 50.0
    def fun(x):
        return _objective_and_penalty(x, n, w)
    res = minimize(fun, x0, method='L-BFGS-B', bounds=bounds,
                   options={'maxiter': iters, 'ftol': 1e-12, 'gtol': 1e-10})
    # extract and clamp
    x = res.x
    out = []
    idx = 0
    for i in range(n):
        cx = x[idx]; cy = x[idx+1]; ang = x[idx+2] % 1.0; side = max(0.0, x[idx+3])
        idx += 4
        cx, cy, ang, side = _clamp_to_unit(cx, cy, ang, side)
        out.append((cx, cy, ang, side))
    return out

def _initial_grid(n):
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # add remaining squares with tiny size at random positions
    rng = random.Random(42)
    while len(squares) < n:
        cx = rng.random()
        cy = rng.random()
        ang = rng.random()
        side = 0.0
        squares.append((cx, cy, ang, side))
    return squares[:n]

def _initial_spiral(n):
    # place squares on a spiral with decreasing size, greedy check
    squares = []
    # number of squares to place with positive size
    m = n
    if m == 0:
        return []
    # try to maximize sum: use an approximate iterative greedy
    # Start with a big square, then try to fit others.
    # Simple approach: divide space. For small n use known patterns via optimization from random starts.
    rng = random.Random(123)
    # create a random packing with random small squares
    for i in range(m):
        side = 1.0 / math.sqrt(m) * (0.5 + 0.5 * rng.random())
        side = min(side, 1.0)
        cx = rng.random()
        cy = rng.random()
        ang = rng.random() * 0.25  # limit rotations to 0-0.25 turns
        cx, cy, ang, side = _clamp_to_unit(cx, cy, ang, side)
        squares.append((cx, cy, ang, side))
    return squares

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # For small n, try multiple random starts and pick best.
    best = None
    best_sum = -1
    # number of restarts
    restarts = 1 if n > 30 else 3
    for r in range(restarts):
        if r == 0:
            sq = _initial_grid(n)
        else:
            sq = _initial_spiral(n)
        # random perturbation
        sq2 = []
        rng = random.Random(r*1000 + n)
        for cx, cy, ang, side in sq:
            if rng.random() < 0.5:
                cx += (rng.random() - 0.5) * 0.1
                cy += (rng.random() - 0.5) * 0.1
                ang += (rng.random() - 0.5) * 0.1
            cx, cy, ang, side = _clamp_to_unit(cx, cy, ang, side)
            sq2.append((cx, cy, ang, side))
        # optimize
        iters = 150 if n <= 20 else 60
        try:
            opt_sq = _optimize(n, sq2, iters=iters)
        except Exception:
            opt_sq = sq2
        # check feasibility and sum
        s = sum(x[3] for x in opt_sq)
        # verify no overlaps
        ok = True
        for i in range(n):
            if not _in_unit(*opt_sq[i]):
                ok = False
                break
            for j in range(i+1, n):
                if opt_sq[i][3] > 1e-12 and opt_sq[j][3] > 1e-12:
                    if _overlap_area(opt_sq[i], opt_sq[j]):
                        ok = False
                        break
            if not ok:
                break
        if ok and s > best_sum:
            best_sum = s
            best = opt_sq
    if best is None:
        # fallback to grid
        best = _initial_grid(n)
    # final cleanup: ensure feasibility
    out = []
    for cx, cy, ang, side in best:
        cx, cy, ang, side = _clamp_to_unit(cx, cy, ang, side)
        out.append((cx, cy, ang, side))
    # double check overlaps and shrink if necessary
    for i in range(len(out)):
        for j in range(i+1, len(out)):
            if out[i][3] > 1e-12 and out[j][3] > 1e-12:
                while _overlap_area(out[i], out[j]):
                    # shrink the smaller one
                    if out[i][3] < out[j][3]:
                        out[i] = (out[i][0], out[i][1], out[i][2], out[i][3]*0.9)
                    else:
                        out[j] = (out[j][0], out[j][1], out[j][2], out[j][3]*0.9)
                    if out[i][3] < 1e-12 or out[j][3] < 1e-12:
                        break
    return out
