# EVOLVE-BLOCK-START
"""Best fit with an exact-fill preference.

Put the item in the bin whose resulting leftover is smallest (tightest fit).
Among bins with the same leftover, prefer the one that becomes exactly empty
(leftover 0) so fragmented partial bins get fully consumed instead of leaving
scattered small gaps.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item
    # Base: prefer the tightest fit (smallest leftover).
    # Small bonus when the bin is exactly filled (leftover == 0) to consume full bins.
    exact = (leftover == 0).astype(np.float64)
    return -leftover.astype(np.float64) + 1e-3 * exact
# EVOLVE-BLOCK-END
