# EVOLVE-BLOCK-START
"""Best-Fit augmented with a soft, distribution-aware fragment-avoidance term.

Core rule stays classic Best-Fit (prefer the bin with the smallest
non-negative residual after placement).  A tiny secondary term nudges ties
and near-ties toward residuals that have historically been useful as an
exact item size or as the complement of a likely item, estimated from a
running histogram of observed items.  The penalty is bounded so it can never
override a meaningful residual difference, keeping the robust best-fit
ordering.
"""
import numpy as np

# Running histogram of observed item sizes (index 1..100).
_hist = np.zeros(101, dtype=np.float64)
_seen = 0.0


def priority(item, bins):
    global _hist, _seen

    # --- update empirical distribution with the current item ---
    _hist[item] += 1.0
    _seen += 1.0

    residual = bins - item  # remaining capacity after placing here

    # Empirical frequency of item sizes (smoothed, normalized to [0,1]).
    freq = _hist / max(_seen, 1.0)

    # For each bin, how "refillable" is the residual post-placement?
    # Residual r is good if r is a frequent item size, or if r is a frequent
    # complement 100 - item' for a likely future item'.
    r = residual.astype(np.float64)
    # frequency lookup, clipped to valid size range
    idx = np.clip(r.astype(np.int64), 0, 100)
    score_freq = freq[idx]

    # complement usefulness: how likely is a future item of size 100 - r ?
    comp = np.clip(100 - idx, 0, 100)
    score_comp = freq[comp]

    # Soft bonus in [0,1]; small weight so best-fit dominates.
    bonus = 0.5 * score_freq + 0.5 * score_comp

    # Classic best-fit primary term: higher score for smaller residual.
    # Use a steeper mapping so differences in residual matter much more
    # than the bounded bonus.
    primary = -(r.astype(np.float64)) * 4.0

    return primary + bonus
# EVOLVE-BLOCK-END

