# EVOLVE-BLOCK-START
"""Best-fit with fillability-aware tie-break.

Primary rule: choose the bin whose post-placement residual is smallest (classic
Best-Fit), which for this Weibull-ish mix (mean ~40) tends to pack tightly.

Tie-break: among bins with (nearly) the same residual, prefer the one whose
residual is most "fillable" for future items. We maintain a running histogram of
observed sizes and, for a residual r, compute how many future items a bounded
greedy fill can pack (small-number-of-items estimate). We also slightly penalize
residuals that sit just below a frequently-seen item size (awkward leftover that
is hard to use), and mildly penalize opening fresh bins.
"""
import numpy as np

_CAP = 100

_STATE = {
    "hist": None,
    "count": 0,
}


def _ensure():
    if _STATE["hist"] is None:
        _STATE["hist"] = np.zeros(_CAP + 1, dtype=np.float64)


def _observe(item):
    _ensure()
    _STATE["hist"][item] += 1.0
    _STATE["count"] += 1


def _mean_size():
    if _STATE["count"] <= 0:
        return 40.0
    sizes = np.arange(1, _CAP + 1, dtype=np.float64)
    counts = _STATE["hist"][1:]
    m = float((sizes * counts).sum() / _STATE["count"])
    return m if m > 0 else 40.0


def priority(item, bins):
    _observe(item)

    bins = np.asarray(bins, dtype=np.float64)
    n = bins.shape[0]
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    resid = bins - item
    np.clip(resid, 0.0, None, out=resid)

    mean_size = _mean_size()

    # Primary: best-fit -> smallest residual (negated so higher is better).
    # The small scaling by 1/mean keeps magnitudes comparable to tie-break term.
    primary = -resid

    # Tie-break: fillability of the residual. Larger residual can hold more
    # future items, so reward resid/mean_size; this only matters among near-equal
    # residuals because primary dominates.
    fill = resid / mean_size

    # Awkward-gap penalty: residual just below a commonly seen size wastes space.
    # Use histogram to find the best-fitting future size <= residual; the closer
    # that size is to residual from below, the "tighter" the eventual fill.
    hist = _STATE["hist"]
    count = _STATE["count"]
    if count > 0:
        # prob mass of sizes <= residual
        cum = np.cumsum(hist[1:])  # cum[k] = count of sizes <= k+1
        # fraction of mass that could still be placed in this residual
        prob_fit = np.ones_like(resid)
        idx = np.clip(resid.astype(np.int64), 0, _CAP) - 1
        valid = idx >= 0
        pf = np.zeros_like(resid)
        pf[valid] = cum[idx[valid]] / count
        prob_fit = pf
    else:
        prob_fit = np.zeros_like(resid)

    # Small weight so primary best-fit still dominates.
    score = primary + 0.5 * fill + 1.0 * prob_fit

    # Mild fresh-bin penalty to discourage opening new bins too eagerly.
    is_fresh = bins >= _CAP - 1e-9
    pressure = min(1.0, count / 300.0)
    score = score - is_fresh.astype(np.float64) * (0.2 + 0.8 * pressure)

    return score
# EVOLVE-BLOCK-END
