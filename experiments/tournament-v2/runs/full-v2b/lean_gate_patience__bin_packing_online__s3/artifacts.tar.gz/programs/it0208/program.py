# EVOLVE-BLOCK-START
"""Best-Fit with a Least-Fit fallback when only empty bins can hold the item."""
import numpy as np


def priority(item, bins):
    """Classic Best-Fit, but when the item only fits in empty bins, split evenly.

    Normally we choose the bin leaving the smallest non-negative residual
    (classic Best-Fit), which minimizes wasted space per placement. However,
    when every fitting bin is completely empty (remaining capacity 100), all
    residuals are identical (100 - item), so Best-Fit's tie-break reduces to
    picking the first empty bin. In that situation there is nothing to gain
    from the tight-fit logic, so we simply rank by bin index to keep the
    behavior deterministic and equivalent to Best-Fit.
    """
    residual = bins - item
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
