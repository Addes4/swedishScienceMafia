"""Best-fit with adaptive residual-utility tie-breaking."""
import numpy as np

_cap = 100
_hist = np.ones(_cap + 1, dtype=np.float64)  # Laplace-smoothed counts of seen items
_total = float(_cap + 1)


def priority(item, bins):
    global _hist, _total
    # Update empirical size histogram with the arriving item.
    _hist[item] += 1.0
    _total += 1.0

    # Probability that a future item exactly fills a given residual.
    # We care about residuals that are "useful": either small enough to be
    # dead space we don't mind, or matched by a common size so it can be closed.
    probs = _hist / _total  # probs[r] = P(next item size == r), index 0..100

    residual = bins - item  # remaining capacity after placing item here

    # Base score: best-fit (prefer smallest residual).
    score = -residual.astype(np.float64)

    # Adaptive bonus: residuals that can likely be matched by a common item
    # size (closable to near-zero) get a bonus proportional to the probability
    # mass of items that exactly fill them. Residual 0 is already ideal.
    # Use probabilities indexed safely.
    r = residual
    r_clipped = np.clip(r, 0, _cap)
    match_bonus = probs[r_clipped]

    # Dead-space bonus: residuals too small to fit a typical small item are
    # effectively free (wasted anyway), so slight preference is harmless.
    small_mean = np.dot(np.arange(_cap + 1), probs)
    dead_thresh = max(1.0, 0.25 * small_mean)
    dead_bonus = (r < dead_thresh).astype(np.float64) * 0.5

    # Combine: the bonus magnitude is small relative to residual differences,
    # so it only acts as a tie-breaker among similar best-fit choices.
    return score + 0.5 * match_bonus + dead_bonus
