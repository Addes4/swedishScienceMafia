"""Distribution-aware best fit with exact-fit bonus.

Score each fitting bin by how tightly it packs (small residual is good) plus a
bonus when the residual after placement equals a frequently observed past item
size, since such residuals are likely to be filled exactly by a future item.
The bonus is derived from a running histogram of past item sizes.
"""

import numpy as np

STATE = {
    "hist": np.zeros(101, dtype=np.float64),  # counts of past item sizes
    "n": 0.0,
}


def priority(item, bins):
    st = STATE
    hist = st["hist"]
    n = st["n"]

    bins = np.asarray(bins)
    k = bins.shape[0]
    if k == 0:
        return bins

    residuals = bins - item
    tight = -residuals.astype(np.float64)

    total = hist.sum()
    if total <= 0 or n <= 0:
        scores = tight
    else:
        # Probability that a future item exactly matches a given residual.
        p = hist / total  # length 101

        res = residuals.astype(np.int64)
        res_clipped = np.clip(res, 0, 100)
        match_prob = p[res_clipped]

        # Normalize the bonus to a small fraction of the residual scale so it
        # only breaks near-ties in favor of fillable residuals.
        bonus = match_prob * 100.0
        scores = tight + 0.25 * bonus

    # Update histogram with this item (only after scoring).
    if 1 <= item <= 100:
        hist[item] += 1.0
        st["n"] = n + 1.0

    return scores
