# EVOLVE-BLOCK-START
"""Adaptive fresh-bin-resistant best fit.

Score for a bin with remaining capacity r when placing item of size s:
    score = -(r - s) - lam * (r / 100)

The first term is the plain best-fit tightness (prefer smallest residual).
The second term penalizes high remaining capacity ("fresh" bins), discouraging
opening new bins.  lam adapts from a running estimate of item-size pressure:
when recent items are large (high mean), lam shrinks (tight best-fit dominates);
when recent items are small, lam grows (resist opening fresh bins so small items
can later fill the leftovers).
"""
import numpy as np


def priority(item, bins):
    # --- state on the function object ---
    st = priority.__dict__
    if 'mean' not in st:
        st['mean'] = 40.0      # running EWMA of item sizes
        st['var'] = 200.0      # running EWMA of squared deviation
        st['count'] = 0
        st['lam'] = 0.5

    # update running statistics with current item (before scoring)
    m = st['mean']
    v = st['var']
    d = item - m
    st['mean'] = m + 0.05 * d
    st['var'] = (1.0 - 0.05) * (v + 0.05 * d * d)
    st['count'] += 1

    mean = st['mean']
    var = st['var']
    sd = var ** 0.5
    pressure = mean / 50.0                 # ~1 at mean 50
    vol = sd / 25.0                        # normalized variability

    # lambda: larger when items are small and steady, smaller when big/variable
    lam = 0.8 / (1.0 + 1.5 * pressure + 0.5 * vol)
    lam = float(min(max(lam, 0.0), 1.2))
    st['lam'] = lam

    # scores: tightest residual first, with penalty for fresh (high capacity) bins
    residual = bins - item
    return -(residual.astype(np.float64)) - lam * (bins.astype(np.float64) / 100.0)
# EVOLVE-BLOCK-END
