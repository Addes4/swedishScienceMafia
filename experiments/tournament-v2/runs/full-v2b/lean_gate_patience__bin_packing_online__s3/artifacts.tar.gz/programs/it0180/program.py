# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a closing bonus and awkward-gap penalty.

Primary rule: best fit (smallest post-placement residual among feasible bins).
A strong bonus is added when the placement closes the bin, i.e. the residual
becomes smaller than the smallest item size observed so far (no future item can
fit). Additionally, a mild penalty discourages leaving a bin with a residual in
the "awkward gap": big enough not to be closed cheaply, but too small to hold
items near the typical/large end of the distribution. This penalty is kept
strictly weaker than the closing bonus so the closing rule dominates.
"""
import numpy as np

CAP = 100

# Smallest item size observed so far (used to detect effective bin closing).
_min_item = CAP + 1
# Largest item size observed so far (used to gauge "large" items).
_max_item = 0


def priority(item, bins):
    global _min_item, _max_item

    if item < _min_item:
        _min_item = item
    if item > _max_item:
        _max_item = item

    b = np.asarray(bins, dtype=np.float64)
    residual = b - item
    residual = np.maximum(residual, 0.0)

    # Best-fit: prefer the smallest residual.
    score = -residual

    if _min_item <= CAP:
        # Closing bonus: residual can no longer hold any item seen so far.
        close = residual < _min_item
        score += 1000.0 * close

        # Awkward-gap penalty: residual is small-ish but still large enough to
        # hold items, yet below a threshold where the bin is hard to fill
        # densely. Penalize staying in this region to encourage cleaner bins.
        gap_hi = 0.6 * _max_item if _max_item > 0 else _min_item
        if gap_hi < _min_item:
            gap_hi = _min_item
        awkward = (residual >= _min_item) & (residual < gap_hi)
        score -= 2.0 * awkward * residual

    return score
# EVOLVE-BLOCK-END
