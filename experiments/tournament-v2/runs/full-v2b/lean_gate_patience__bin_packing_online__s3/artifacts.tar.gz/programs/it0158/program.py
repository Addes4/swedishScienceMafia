# EVOLVE-BLOCK-START
"""Best-fit with residual-tightness bonus tuned to Weibull-like sizes."""
import numpy as np


class _State:
    def __init__(self):
        self.min_item = 101
        self.n = 0
        self.mean = 40.0

    def observe(self, item):
        if item < self.min_item:
            self.min_item = item
        self.n += 1
        # running mean
        self.mean += (item - self.mean) / self.n


_state = _State()


def priority(item, bins):
    """Best-fit primary, with a bonus for residuals below the running mean."""
    _state.observe(item)

    residual = bins - item

    score = -residual.astype(np.float64)

    mean = _state.mean
    # Bonus for bins whose post-placement residual is small relative to the
    # typical item: such bins are close to full and should be packed tightly.
    # Scale is tiny so it only breaks near-ties in the residual ordering.
    bonus = np.where(residual < mean, (mean - residual) / (mean + 1.0), 0.0)
    score += 1e-2 * bonus

    return score
# EVOLVE-BLOCK-END
