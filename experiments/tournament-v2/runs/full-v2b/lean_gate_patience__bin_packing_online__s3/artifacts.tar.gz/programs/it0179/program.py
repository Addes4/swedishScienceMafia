# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a quantile-based closing bonus.

Primary rule: best fit (smallest post-placement residual among feasible bins).
A strong bonus is added when the placement "effectively closes" the bin, i.e.
the residual becomes smaller than a low percentile of the item sizes observed so
far (no typical future item can fit). The percentile generalizes the pure
minimum-item rule and reduces fragmentation slightly.
"""
import numpy as np

CAP = 100

# Running histogram of observed item sizes (index 1..100).
_hist = np.zeros(CAP + 2, dtype=np.float64)
_count = 0
# Cached low percentile of observed sizes.
_pct = CAP + 1


def _update_pct():
    """Recompute the low percentile of observed item sizes."""
    global _pct
    if _count <= 0:
        _pct = CAP + 1
        return
    target = 0.15 * _count
    c = np.cumsum(_hist[1:CAP + 1])
    idx = int(np.searchsorted(c, target, side="left"))
    _pct = float(idx + 1)


def priority(item, bins):
    global _count

    # Update running histogram and percentile.
    if 1 <= item <= CAP:
        _hist[item] += 1.0
        _count += 1
        _update_pct()

    b = np.asarray(bins, dtype=np.float64)
    residual = b - item

    # Best-fit: prefer the smallest non-negative residual.
    score = -np.maximum(residual, 0.0)

    # Closing bonus: reward placements whose residual can't hold a typical item.
    if _pct <= CAP:
        score += 1000.0 * (residual < _pct)

    return score
# EVOLVE-BLOCK-END
