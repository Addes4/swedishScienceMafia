# EVOLVE-BLOCK-START
"""Adaptive best-fit with pressure-driven fresh-bin penalty."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.m2 = 0.0          # for running variance
        self.lam = 0.0
        self.last_rem = 100.0


_state = _State()


def priority(item, bins):
    """Score bins: tightness minus adaptive penalty on large remaining capacity."""
    s = _state

    # Update running estimate of recent item-size pressure.
    s.n += 1
    delta = item - s.mean
    s.mean += delta / s.n
    s.m2 += delta * (item - s.mean)
    var = s.m2 / s.n if s.n > 1 else 0.0
    std = var ** 0.5

    # Pressure: larger mean and larger variability => tighter packing desired.
    # Normalize mean to ~[0,1] over range 1..100.
    mean_norm = s.mean / 100.0
    std_norm = std / 100.0
    pressure = 0.7 * mean_norm + 0.3 * std_norm   # ~0..~0.6

    # lambda: penalty strength for high-remaining (fresh) bins.
    # High pressure -> low lambda (tight best-fit). Low pressure -> higher lambda.
    s.lam = max(0.0, 0.8 * (0.55 - pressure))

    # Tightness term: prefer bins whose remaining capacity is just >= item.
    tightness = -(bins - item)

    # Fresh-bin penalty: penalize high remaining capacity.
    # bins are the capacities the item fits in, so bins >= item.
    penalty = s.lam * bins

    return tightness - penalty
# EVOLVE-BLOCK-END
