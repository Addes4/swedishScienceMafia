# EVOLVE-BLOCK-START
"""Best-fit with a near-tie tolerance favoring larger residuals."""
import numpy as np


class _State:
    def __init__(self):
        self.min_item = 101  # smallest item seen so far

    def observe(self, item):
        if item < self.min_item:
            self.min_item = item


_state = _State()


def priority(item, bins):
    """Best-fit: smallest post-placement residual wins; near-ties prefer larger residual."""
    _state.observe(item)

    residual = bins - item  # int64 array, all >= 0 since bin fits item

    # Primary: smaller residual is better.
    score = -residual.astype(np.float64)

    # Among residuals that are close to the minimum, prefer the larger residual
    # (more usable slack) to reduce fragmentation.
    best = residual.min()
    near = residual <= best + 2
    # larger residual -> higher score within the near-best band
    score += near * residual.astype(np.float64) * 1e-2

    # Tiny bonus for residuals no future item (of observed min size) can use.
    min_item = _state.min_item
    if min_item > 1:
        closed = residual < min_item
        score += closed * 1e-3

    return score
# EVOLVE-BLOCK-END
