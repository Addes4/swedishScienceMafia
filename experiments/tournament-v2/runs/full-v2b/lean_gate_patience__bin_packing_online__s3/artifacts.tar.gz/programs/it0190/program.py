import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),
    "count": 0.0,
    "mean": 40.0,
}


def priority(item, bins):
    st = _state
    st["hist"][item] += 1.0
    st["count"] += 1.0
    c = st["count"]
    st["mean"] = st["mean"] + (item - st["mean"]) / c

    n = bins.size
    # Empirical distribution over sizes seen so far (plus a prior).
    hist = st["hist"]
    total = c + 1.0
    p = (hist + 1.0 / 101.0) / total  # Laplace-ish smoothing over 1..100

    # Expected number of typical items that can still be packed into a residual r
    # via a simple greedy continuous fill estimate: sum_j p_j * (r // j) roughly.
    # We precompute an expected fill factor for residuals 0..100.
    sizes = np.arange(1, 101, dtype=np.float64)
    pm = p[1:101]

    # For each possible residual capacity, estimate expected greedy pack count.
    # Use E[floor(r/j)] weighted by p_j; approximated cheaply.
    resid_fill = np.zeros(101, dtype=np.float64)
    # cumulative distribution to compute E[floor(r/j)] via sum over j
    inv_sizes = 1.0 / sizes
    # approximate E[floor(r/j)] ~ r*E[1/j] - E[frac]; use r*E[1/j]
    e_inv = float(pm.dot(inv_sizes))
    ev = float(pm.dot(sizes))

    resid = bins - item  # residual after placing item in each candidate bin
    resid = np.clip(resid, 0, 100)

    # Tightness of the placement: prefer small residual relative to typical item.
    # Harmonic-style: higher score when residual is small but still usable.
    tight = -resid.astype(np.float64)

    # Future fillability: expected items packable into residual.
    fill = resid * e_inv  # linear proxy of greedy fill count

    # Penalty for residuals that are too small to fit typical items but not zero
    # (wasted space), and reward residuals that are close to multiples of mean size.
    waste = np.where((resid > 0) & (resid < st["mean"] * 0.5),
                     (st["mean"] * 0.5 - resid), 0.0)

    # Combine: prefer tight fit, but value residuals that can still host items.
    score = tight * 0.6 + fill * 1.0 - waste * 0.5

    return score
