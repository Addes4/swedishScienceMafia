"""Online bin packing: best-fit with a closing bonus and histogram tie-breaks.

Primary rule (proven strong): strongly prefer a placement that closes the bin
(post-placement residual below the smallest item size seen so far); otherwise
prefer the tightest fit (smallest residual).

Tie-break rule: when several bins yield the *same* residual, choose among them
using a running histogram of item sizes: prefer the bin whose residual is more
"fillable" per the observed distribution, breaking the arbitrary index-order
bias that causes fragmentation.
"""
import numpy as np

_cnt_min = 101          # smallest item size observed so far
_total = 0.0
_sum = 0.0

# Running histogram of item sizes (1..100), plus a feasibility cache.
_hist = np.zeros(101, dtype=np.float64)
_SIGMA = 8.0            # smoothing bandwidth for fillability estimate


def _fillability(residual, min_size):
    """Estimate how densely a residual can be packed using observed sizes."""
    if residual < min_size:
        return 0.0
    # Expected number of items that fit if we greedily pack with typical sizes,
    # weighted by how much mass exists at or below the residual.
    tot = _hist.sum()
    if tot <= 0.0:
        return float(residual) / 40.0
    # Effective mean size of items that could still go into this residual,
    # blended with the global mean for stability.
    idx = np.arange(1, 101, dtype=np.float64)
    w = _hist[1:101]
    usable = idx <= residual
    if not usable.any():
        return 0.0
    mass_below = w[usable].sum()
    global_mean = (_sum / _total) if _total > 0 else 40.0
    if mass_below <= 1e-9:
        eff_mean = global_mean
    else:
        eff_mean = float((w[usable] * idx[usable]).sum() / mass_below)
    if eff_mean < 1e-9:
        eff_mean = global_mean
    est_items = float(residual) / eff_mean
    # Weight by the probability mass that is actually usable (fills nicely).
    return est_items * (mass_below / tot) ** 0.5


def priority(item, bins):
    global _cnt_min, _total, _sum

    s = int(item)
    if s < _cnt_min:
        _cnt_min = s
    _total += 1.0
    _sum += s
    _hist[s] += 1.0

    min_size = _cnt_min if _cnt_min <= 100 else 1

    n = bins.shape[0]
    scores = np.empty(n, dtype=np.float64)

    for i in range(n):
        b = int(bins[i])
        residual = b - s

        if residual < min_size:
            # Closing the bin: best possible outcome.
            scores[i] = 1e6 - residual
        else:
            # Tightest fit, plus a small fillability tie-break that only
            # matters when residuals are (near) equal.
            fill = _fillability(residual, min_size)
            scores[i] = -float(residual) + 1e-3 * fill

    return scores
