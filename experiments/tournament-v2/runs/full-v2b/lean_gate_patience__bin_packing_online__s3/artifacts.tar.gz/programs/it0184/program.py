# EVOLVE-BLOCK-START
"""Online bin choice: best-fit with a graded closing bonus.

Primary rule: place the item into the bin with the smallest post-placement
residual (best fit) to keep bins tightly packed. Additionally, give a graded
bonus to placements that leave a small residual: the smaller the residual
relative to the smallest observed item, the larger the bonus. This lets a bin
that can no longer accept any observed item (residual < min_item) be treated as
fully closed, while residuals slightly above min_item still get a mild nudge
without overriding best-fit across the whole range.
"""
import numpy as np

_SIZE_MAX = 100

# Smallest item size observed so far (init to a large value).
_min_item = _SIZE_MAX + 1


def priority(item, bins):
    global _min_item
    item = int(item)
    if item < _min_item:
        _min_item = item

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item
    fits = residual >= 0

    # Best-fit: prefer the smallest non-negative residual.
    score = -residual

    # Graded closing bonus: maximum when residual < min_item, decaying linearly
    # to zero at residual = 2*min_item (so mid residuals don't dominate).
    thresh = _min_item
    # bonus = _SIZE_MAX * clip((2*thresh - residual)/(2*thresh - ... ))
    # Simpler: bonus high if residual < thresh, mild decay up to 2*thresh.
    decay = np.clip((2.0 * thresh - residual) / thresh, 0.0, 1.0)
    bonus = _SIZE_MAX * decay
    score = score + bonus

    score = np.where(fits, score, -1e9)

    return score
# EVOLVE-BLOCK-END

