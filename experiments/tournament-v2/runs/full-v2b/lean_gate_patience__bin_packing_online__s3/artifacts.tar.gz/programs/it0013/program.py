# EVOLVE-BLOCK-START
"""Best-fit with exact-fit preference tiebreaker."""
import numpy as np


def priority(item, bins):
    """Choose the bin with smallest residual that fits (best-fit); prefer exact fits."""
    residual = bins.astype(np.float64)
    # Primary: minimize leftover after placement -> maximize (item - residual) = -leftover.
    score = -residual
    # Secondary: tiny bonus for an exact fit (residual == item), which fills a bin perfectly
    # and never wastes space, breaking ties toward the tightest possible pack.
    exact = (residual == item)
    score = score + exact * 1e-6
    return score
# EVOLVE-BLOCK-END
