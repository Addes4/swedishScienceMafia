import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "sumsq": 0.0,
    "recent": [],
    "max_recent": 0.0,
}


def priority(item, bins):
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["sumsq"] += item * item
    st["recent"].append(item)
    if len(st["recent"]) > 100:
        st["recent"].pop(0)

    n = st["n"]
    mean = st["sum"] / n
    sd = max(0.0, st["sumsq"] / n - mean * mean) ** 0.5

    recent = st["recent"]
    # Running estimate of a "large" future item size: high quantile of recent items.
    if len(recent) >= 20:
        large = float(np.percentile(recent, 85))
    else:
        large = mean + 0.5 * sd
    large = max(1.0, large)

    rem = bins.astype(np.float64)
    fresh = rem >= 100.0 - 1e-9

    residual = rem - item  # >= 0 for bins the item fits in

    # Core: Best-Fit (maximize item - residual => minimize residual).
    score = item - residual

    # Bonus for partially-filled bins whose leftover is >= a typical large item,
    # i.e. the space stays usable. Scale by how much usable space remains.
    usable = np.clip(residual / large, 0.0, 1.0)
    score += 0.15 * usable * (1.0 - fresh.astype(np.float64))

    # Slight penalty for opening fresh bins, only meaningful when alternatives exist.
    score -= 0.05 * fresh.astype(np.float64)

    return score
