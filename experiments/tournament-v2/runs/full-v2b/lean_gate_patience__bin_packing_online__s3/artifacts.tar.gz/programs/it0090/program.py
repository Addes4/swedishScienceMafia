"""Best-fit with a histogram-based residual bonus.

Primary rule: minimize the residual capacity after placement (classic best fit),
which is strong for online bin packing. A small bonus is added for residuals that
match historically frequent item sizes, so bins are slightly preferred when their
leftover is likely to be refillable by a single future item.
"""

import numpy as np

STATE = {
    "hist": np.zeros(101, dtype=np.float64),  # counts of past item sizes
    "n": 0.0,
}


def priority(item, bins):
    st = STATE
    hist = st["hist"]
    n = st["n"]

    bins = np.asarray(bins)
    k = bins.shape[0]
    if k == 0:
        return bins

    residuals = bins - item

    # Tightness: smaller residual is better (best fit baseline).
    tight = -residuals.astype(np.float64)

    total = hist.sum()
    if total > 0:
        # Normalized frequency of past items that exactly equal the residual.
        res_clipped = np.clip(residuals.astype(np.int64), 0, 100)
        freq = hist[res_clipped] / total
        # Small bonus for residuals that match a common past item size.
        bonus = 2.0 * freq
    else:
        bonus = 0.0

    scores = tight + bonus

    # Update histogram with this item (past information only).
    if 1 <= item <= 100:
        hist[item] += 1.0
        st["n"] = n + 1.0

    return scores
