# EVOLVE-BLOCK-START
"""Online bin packing via expected residual fillability (histogram-based)."""
import numpy as np

# Global state: histogram of observed item sizes.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0
_EPS = 1e-9


def _update_hist(item):
    global _COUNT
    _HIST[item] += 1.0
    _COUNT += 1.0


def _typical_sizes():
    """Return array of item sizes weighted by observed frequency."""
    if _COUNT < 1.0:
        # Fallback: assume uniform-ish sizes around 1..100 weighted small.
        return np.arange(1, 101, dtype=np.float64)
    return np.nonzero(_HIST)[0].astype(np.float64)


def _expected_fill(residual, sizes, weights):
    """Estimate expected number of future items packable into residual via greedy fill.

    Greedy: repeatedly place the smallest available item that fits; count items.
    Continuous estimate scaled by weight of fitting items.
    """
    r = residual
    # Sum of expected counts: probability an item fits times progression.
    # Simple estimate: expected amount fillable ~ r * p where p is prob an item
    # fits; and number of items ~ that amount / mean size of fitting items.
    fitting_mask = sizes <= r
    if not np.any(fitting_mask):
        return 0.0
    w = weights[fitting_mask]
    s = sizes[fitting_mask]
    wsum = w.sum()
    if wsum <= _EPS:
        return 0.0
    # mean size of fitting items
    mean_fit = float(np.dot(w, s) / wsum)
    if mean_fit <= _EPS:
        return 0.0
    # Number expected ~ r / mean_fit (bounded), weighted by total probability
    return r / mean_fit


def priority(item, bins):
    global _COUNT
    _update_hist(item)

    sizes = _typical_sizes()
    weights = _HIST[sizes.astype(np.int64)] if _COUNT >= 1.0 else np.ones(len(sizes))

    residual = bins - item  # post-placement residual

    # Score: reward low residual (tight fit) and high expected future fillability
    # of the residual.  Best fit term is -residual; fillability term is
    # r/mean_fit, which favors residual that can still absorb future items.
    scores = np.empty(len(bins), dtype=np.float64)
    for i in range(len(bins)):
        r = int(residual[i])
        fill = _expected_fill(r, sizes, weights)
        # Tightness: prefer small residual.  Use scaled tightness.
        tightness = -r / 100.0
        # Fillability: expected number of future items. Prefer moderate.
        # Weight so that residual just under typical item size is preferred,
        # but a nearly-empty bin (r large) yields large fill count -> penalize
        # slightly to discourage opening/wasting fresh bins.
        scores[i] = tightness + 0.35 * fill

    return scores
# EVOLVE-BLOCK-END
