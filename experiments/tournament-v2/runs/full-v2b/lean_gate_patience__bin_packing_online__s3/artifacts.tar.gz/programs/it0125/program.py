# EVOLVE-BLOCK-START
"""Online bin packing: best-fit tightness plus an adaptive complement bonus.

The base rule is classic best-fit (minimize post-placement residual).  On top of
that we add a small bonus when the residual left in a bin is *exactly fillable*
by a single likely future item size, estimated from a running histogram of past
items.  A residual that matches a common item size means the bin can be closed
by one more typical item, which is the cheapest way to reclaim space.  The bonus
is small so it never dominates the tightness term; it only breaks near-ties in
favour of residuals that the distribution can actually reuse.
"""

import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_BONUS = 2.0
_COMPLEMENT = np.zeros(101, dtype=np.float64)  # per-residual bonus, cached
_last_update = -1


def _rebuild_complement():
    """Build a lookup: bonus for a residual r if r is a likely item size."""
    global _COMPLEMENT
    total = _HIST.sum()
    if total <= 0:
        _COMPLEMENT[:] = 0.0
        return
    # probability mass of each size, normalized
    p = _HIST / total
    # bonus proportional to how likely r is to appear as a single item
    _COMPLEMENT[:] = _BONUS * 100.0 * p


def priority(item, bins):
    global _HIST, _last_update

    bins = np.asarray(bins, dtype=np.float64)
    residuals = bins - item  # residual capacity after placing here

    # Base term: tightness -> prefer small residual.
    score = -residuals

    # Complement bonus: reward residuals that equal a likely future item size.
    r_int = np.clip(residuals, 0, 100).astype(np.int64)
    score = score + _COMPLEMENT[r_int]

    # Record the observed item size, with mild decay to stay adaptive.
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        total = _HIST.sum()
        if total > 3000:
            _HIST *= 0.999

    # Refresh complement table periodically (cheap, every 25 items).
    if item != _last_update:
        _last_update = item
    _rebuild_complement()

    return score
# EVOLVE-BLOCK-END
