# EVOLVE-BLOCK-START
"""Best-fit with fresh-bin tie-breaking.

Prefer the bin whose residual capacity after placement is smallest (classic
Best-Fit), which is a strong online rule for Weibull-shaped sizes. Fresh bins
(residual 100 before placement) are naturally last since they yield the largest
post-placement residual. A tiny epsilon bonus favors non-fresh bins on exact
ties to avoid needlessly opening new bins.
"""
import numpy as np


def priority(item, bins):
    """Score bins by smallest post-placement residual (Best-Fit)."""
    res = bins.astype(np.float64) - float(item)
    # Prefer smallest residual; add tiny bonus for already-nonempty bins.
    # fresh bins have remaining capacity 100 before placement
    fresh = (bins == 100).astype(np.float64)
    score = -res - 1e-6 * fresh
    return score
# EVOLVE-BLOCK-END
