# EVOLVE-BLOCK-START
"""Online bin packing: pure best-fit with a small used-bin preference."""

import numpy as np


def priority(item, bins):
    """Score each bin; item goes to highest score (first on ties).

    Best fit: prefer the smallest post-placement residual (tightest fit).
    A tiny bonus is added to non-fresh bins so that, among equally tight fits,
    already-opened bins are preferred, minimizing new bin openings.
    """
    bins = np.asarray(bins, dtype=np.float64)
    residuals = bins - item  # >= 0 for bins the item fits in

    # Tightness: smaller residual -> higher score.
    score = -residuals

    # Small bonus for bins that already hold items (capacity < 100), so we
    # prefer to keep packing existing bins rather than opening fresh ones.
    not_fresh = (bins < 100.0 - 1e-9).astype(np.float64)
    score += 0.001 * not_fresh

    return score
# EVOLVE-BLOCK-END
