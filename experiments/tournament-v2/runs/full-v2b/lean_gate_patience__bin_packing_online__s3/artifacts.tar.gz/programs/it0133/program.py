# EVOLVE-BLOCK-START
"""Best-fit with histogram-based refillability bonus."""
import numpy as np

# Running histogram of past item sizes (1..100)
_hist = np.zeros(101, dtype=np.float64)
_hist_count = 0.0

# Cache of the refillability bonus table, keyed on histogram count
_refill_cache = None
_refill_tag = -1.0

_RES = np.arange(101, dtype=np.float64)


def _build_refill_table():
    """For each residual r (0..100), return a bonus in [0,1] measuring how likely
    the residual can be exactly or nearly filled by a single upcoming item drawn
    from the running distribution. Peaks at the most probable item sizes."""
    global _refill_cache, _refill_tag
    if _hist_count < 50:
        # Not enough data yet: uniform-ish prior
        probs = np.full(101, 1.0 / 100.0)
    else:
        probs = _hist / _hist_count
    probs = probs.copy()
    probs[0] = 0.0
    total = probs.sum()
    if total <= 0:
        probs = np.full(101, 1.0 / 100.0)
        probs[0] = 0.0
        total = probs.sum()
    probs /= total

    # Bonus for residual r: probability mass at sizes close to r (within a small window),
    # i.e. how likely the next item can neatly consume this residual.
    table = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        lo = max(1, r - 2)
        hi = min(100, r + 2)
        table[r] = probs[lo:hi + 1].sum()
    # Normalize so max is 1
    mx = table.max()
    if mx > 0:
        table /= mx
    _refill_cache = table
    _refill_tag = _hist_count
    return table


def priority(item, bins):
    global _hist, _hist_count, _refill_cache, _refill_tag

    bins = np.asarray(bins, dtype=np.int64)
    n = bins.shape[0]

    if 1 <= item <= 100:
        _hist[item] += 1.0
        _hist_count += 1.0

    residual = bins - item  # residual capacity after placing item here

    # Refillability table
    if _refill_cache is None or (_hist_count - _refill_tag) > 50.0:
        table = _build_refill_table()
    else:
        table = _refill_cache

    refill = table[np.clip(residual, 0, 100)]

    # Base score: best-fit (smaller residual is better)
    base = -residual.astype(np.float64)

    # Bonus: encourage residuals that future items can neatly consume,
    # but only when the residual is not so large that it's really a "fresh" bin.
    # A residual that can still hold ~2+ mean items is valuable on its own,
    # so only reward small residuals (which otherwise look wasteful) if refillable.
    small_residual = residual < 25
    bonus = np.where(small_residual, 4.0 * refill, 0.0)

    return base + bonus
# EVOLVE-BLOCK-END
