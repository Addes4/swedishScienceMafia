# EVOLVE-BLOCK-START
"""Online bin choice: best-fit with an adaptive closing bonus.

Primary rule: place the item into the bin with the smallest post-placement
residual (best fit) to keep bins tightly packed. Additionally, give a large
bonus to placements that "close" a bin: leave a residual too small to hold
almost any future item. Rather than using the absolute minimum observed item
(which is driven by rare tiny items), we use a low percentile of the observed
size distribution as the closing threshold, so fewer bins are left with a
useless sliver of slack.
"""
import numpy as np

_SIZE_MAX = 100

# Running reservoir/histogram of observed item sizes (small, fast).
_SIZE_BINS = 101
_hist = np.zeros(_SIZE_BINS, dtype=np.float64)
_count = 0


def _closing_threshold():
    """Low percentile (approx 10th) of observed sizes, as closing threshold."""
    if _count < 50:
        return _SIZE_MAX + 1
    cdf = np.cumsum(_hist) / _count
    idx = int(np.searchsorted(cdf, 0.10))
    # Use a tiny bit above the percentile so truly-closing bins qualify.
    return max(1, idx)


def priority(item, bins):
    global _count
    item = int(item)
    if 0 <= item < _SIZE_BINS:
        _hist[item] += 1.0
    _count += 1

    thr = _closing_threshold()

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item

    # Best-fit: prefer the smallest non-negative residual.
    score = -residual

    # Closing bonus: residual below threshold => bin effectively closed.
    closed = (residual >= 0) & (residual < thr)
    score = score + closed * _SIZE_MAX

    # Ensure non-fitting bins are never chosen.
    fits = residual >= 0
    score = np.where(fits, score, -1e9)

    return score
# EVOLVE-BLOCK-END
