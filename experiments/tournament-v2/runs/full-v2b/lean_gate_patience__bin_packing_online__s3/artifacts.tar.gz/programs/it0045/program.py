# EVOLVE-BLOCK-START
"""Best-fit with residual-reuse scoring driven by the empirical item distribution."""
import numpy as np


class _Model:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def update(self, item):
        self.counts[item] += 1.0
        self.total += 1.0

    def probs(self):
        p = self.counts.copy()
        if self.total > 0:
            p /= self.total
        else:
            p[1:101] = 1.0 / 100.0
        return p


_MODEL = _Model()


def priority(item, bins):
    global _MODEL
    m = _MODEL
    m.update(int(item))

    # tightness: best-fit baseline (favor smaller residuals)
    tight = -(bins - item)

    p = m.probs()  # p[1..100] probability of each item size

    leftover = bins - item  # integer residuals >= 0

    # Residual-reuse value: probability that the NEXT item exactly fills this
    # residual (using the running histogram). A residual equal to a common size
    # gets consumed exactly, so it is "valuable" and we prefer leaving it.
    reuse = p[np.clip(leftover, 0, 100)]

    # Also credit residuals that can hold at least a typical item (still usable).
    # Fraction of future items that fit in this residual.
    cum = np.cumsum(p)  # cum[r] = P(size <= r)
    usable = cum[np.clip(leftover, 0, 100)]

    score = tight + 0.6 * reuse + 0.15 * usable
    return score
# EVOLVE-BLOCK-END
