# EVOLVE-BLOCK-START
"""Histogram-aware best-fit with residual "reusability" bonus.

Primary rule: best-fit (smallest residual after placement). Tie-break: prefer
bins whose residual exactly equals a frequently-seen item size, so the leftover
is likely to be consumed by a future item, reducing wasted space. A mild
consolidation bonus also favors used bins over fresh ones.
"""
import numpy as np

_STATE = {
    "hist": None,
    "count": 0.0,
}


def priority(item, bins):
    s = _STATE

    if s["hist"] is None:
        s["hist"] = np.zeros(101, dtype=np.float64)
    s["count"] += 1.0
    if s["count"] > 1.0:
        # decayed histogram of past item sizes (exclude current item)
        s["hist"] *= 0.997
    hist = s["hist"]
    hist[item] += 1.0

    b = bins.astype(np.float64)
    resid = b - item

    # best-fit primary term
    score = -resid

    if s["count"] > 50:
        # reusability: normalized frequency of residual being a common size
        ri = np.clip(resid.astype(np.int64), 0, 100)
        freq = hist[ri]
        maxfreq = hist.max() + 1e-9
        # exact-match bonus (strongest when residual equals a very common size)
        score += 0.4 * (freq / maxfreq)

        # mild consolidation: prefer used bins (residual < 100) over fresh ones
        fresh = (b >= 100.0).astype(np.float64)
        score -= 0.15 * fresh * (freq / maxfreq)

    return score
# EVOLVE-BLOCK-END
