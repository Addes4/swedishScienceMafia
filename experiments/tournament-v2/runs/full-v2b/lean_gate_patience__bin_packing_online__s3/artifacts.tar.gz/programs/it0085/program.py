# EVOLVE-BLOCK-START
"""Online best-fit with a residual "fillability" tie-breaker learned from history."""
import numpy as np


class _State:
    def __init__(self):
        # Running mean of item sizes (for scaling the tie-break bonus)
        self.mean = 40.0
        # EWMA of the average residual just before a bin gets closed off,
        # i.e., how "fillable" typical residuals are.
        self.fill = 50.0


_state = _State()


def priority(item, bins):
    """Best-fit primary score; small tie-break favoring fillable residuals."""
    st = _state
    st.mean = 0.98 * st.mean + 0.02 * item

    residual = bins.astype(np.float64) - float(item)

    # Primary: classic best fit (smaller residual is better).
    score = -residual

    # Tie-break: reward residuals that are close to the running mean of
    # "useful" residuals, which empirically tend to be well refillable.
    # Weight is kept small so it never overrides the best-fit ordering.
    dev = np.abs(residual - st.mean)
    score += 1e-4 * (-dev)

    return score
# EVOLVE-BLOCK-END
