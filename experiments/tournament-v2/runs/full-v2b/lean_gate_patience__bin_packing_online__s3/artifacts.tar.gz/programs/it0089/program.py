"""Adaptive distribution-aware bin-choice rule.

Combines a tightness term (best fit) with a predicted-usefulness term for the
resulting residual capacity, estimated from a running histogram of past item
sizes. A pressure signal (EWMA of recent item sizes) adapts the trade-off so
the rule shifts between tight best fit and refill-friendly placement.
"""

import numpy as np

STATE = {
    "hist": np.zeros(101, dtype=np.float64),  # counts of past item sizes
    "n": 0.0,
    "ewma": 0.0,   # EWMA of recent item sizes (pressure)
    "var": 0.0,    # EWMA of squared deviations
    "init": False,
}


def _residual_value(res, hist, n, ewma):
    """Estimate how useful a residual capacity `res` is.

    Using the running histogram of past sizes, estimate the expected fraction of
    the residual that a single future item would consume, weighted by the
    probability that some past-size item exactly fits or nearly fits. We reward
    residuals that historically get used up efficiently (small leftover).
    """
    if res <= 0:
        return -1e9
    # Probability mass of past items <= res
    r = int(res)
    if r > 100:
        r = 100
    total = hist.sum()
    if total <= 0:
        # No history: mild preference for tighter fits
        return -float(res)
    # Expected waste after placing one more item from the empirical distribution
    # among those that fit. We approximate by the mean size of fitting items.
    fit_mass = hist[: r + 1].sum()
    if fit_mass <= 0:
        # Nothing fits: residual is likely wasted; penalize by size
        return -float(res)
    idx = np.arange(r + 1)
    mean_fit = float((idx * hist[: r + 1]).sum()) / fit_mass
    # Expected leftover if we place one fitting item
    leftover = res - mean_fit
    if leftover < 0:
        leftover = 0.0
    # Value = negative expected leftover (want it small) scaled by fit probability
    p_fit = fit_mass / total
    return -leftover * (0.5 + 0.5 * p_fit)


def priority(item, bins):
    st = STATE
    hist = st["hist"]
    n = st["n"]

    # Update pressure/EWMA from the arriving item (past information only).
    if not st["init"]:
        st["ewma"] = float(item)
        st["var"] = 0.0
        st["init"] = True
    else:
        a = 0.05
        prev = st["ewma"]
        st["ewma"] = (1 - a) * prev + a * item
        d = item - prev
        st["var"] = (1 - a) * st["var"] + a * d * d

    bins = np.asarray(bins)
    k = bins.shape[0]
    if k == 0:
        return bins

    residuals = bins - item

    # Tightness: smaller residual is better (best fit baseline).
    tight = -residuals.astype(np.float64)

    # Predicted usefulness of the residual after placement.
    total = hist.sum()
    if total <= 0:
        usefulness = -residuals.astype(np.float64)
    else:
        # Vectorized residual-value estimation using cumulative histogram.
        cum = np.concatenate(([0.0], np.cumsum(hist)))
        idx = np.arange(101)
        cum_sz = np.concatenate(([0.0], np.cumsum(idx * hist)))

        res_clipped = np.clip(residuals.astype(np.int64), 0, 100)
        fit_mass = cum[res_clipped + 1]
        sz_sum = cum_sz[res_clipped + 1]

        with np.errstate(divide="ignore", invalid="ignore"):
            mean_fit = np.where(fit_mass > 0, sz_sum / np.maximum(fit_mass, 1e-9), 0.0)
        p_fit = fit_mass / total
        leftover = np.maximum(residuals - mean_fit, 0.0)
        usefulness = -leftover * (0.5 + 0.5 * p_fit)
        # If nothing fits, residual is likely wasted: push down.
        nothing_fits = fit_mass <= 0
        usefulness = np.where(nothing_fits, -residuals.astype(np.float64), usefulness)

    # Pressure-adaptive weight: under high mean/variability, favor tight fit.
    pressure = st["ewma"]
    variability = np.sqrt(max(st["var"], 0.0))
    # Scale: larger pressure reduces reliance on usefulness.
    w = 1.0 / (1.0 + pressure / 25.0 + variability / 50.0)
    w = float(min(max(w, 0.05), 1.0))

    scores = (1.0 - w) * tight + w * usefulness

    # Update histogram with this item (only after scoring).
    if 1 <= item <= 100:
        hist[item] += 1.0
        st["n"] = n + 1.0

    return scores
