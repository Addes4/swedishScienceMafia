# EVOLVE-BLOCK-START
"""Distribution-aware lookahead best fit.

For each candidate bin, we estimate how many more items (drawn from a running
histogram of observed item sizes) would typically be needed to finish filling the
remaining capacity after this item is placed, using a greedy "fill with typical
sizes, prefer exact-fit" simulation.  The bin with the lowest expected leftover
is preferred, with a mild tie-break toward tighter immediate fits.
"""
import numpy as np


class _State:
    def __init__(self):
        # histogram of item sizes (1..100), Laplace-smoothed
        self.counts = np.ones(101, dtype=np.float64)
        self.counts[0] = 0.0
        self.total = float(np.sum(self.counts))
        # precomputed distribution for sampling typical fill items (deterministic)
        self._cached_size = None
        self._cached_pmf = None

    def observe(self, item):
        self.counts[item] += 1.0
        self.total += 1.0

    def dist(self):
        pmf = self.counts / self.total
        return pmf


_state = _State()


def _greedy_fill(capacity, sizes_desc, probs_desc, max_steps=6):
    """Estimate leftover capacity when filling `capacity` with typical items.

    Uses a deterministic greedy: repeatedly take the most likely item that fits,
    otherwise the largest item that fits.  This models the residual value of the
    capacity rather than exact dynamic programming.
    """
    cap = capacity
    for _ in range(max_steps):
        if cap <= 0:
            break
        # try the most probable size that fits
        chosen = 0
        for s, p in zip(sizes_desc, probs_desc):
            if s <= cap:
                chosen = s
                break
        if chosen < 1:
            break
        cap -= chosen
    return cap


def priority(item, bins):
    """Score bins by expected post-placement leftover under a running size model."""
    _state.observe(item)

    pmf = _state.dist()
    # sizes sorted by probability descending, then by size descending
    order = np.argsort(-pmf, kind="stable")
    probs_desc = pmf[order]
    sizes_desc = order.astype(np.int64)

    obj = np.asarray(bins, dtype=np.int64)
    rem = obj - item  # remaining capacity after placing item
    n = rem.shape[0]

    # For each distinct remaining capacity, evaluate leftover estimate once.
    # Cache per unique value to keep it fast.
    uniq, inv = np.unique(rem, return_inverse=True)
    leftover = np.empty(uniq.shape[0], dtype=np.float64)
    for k in range(uniq.shape[0]):
        leftover[k] = _greedy_fill(int(uniq[k]), sizes_desc, probs_desc)

    est_left = leftover[inv]

    # Prefer smaller expected leftover; tie-break toward tighter fit (smaller rem).
    score = -est_left * 1000.0 - rem.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
