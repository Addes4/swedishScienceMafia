"""Spread items across bins to keep residues uniform (least-loaded first)."""
import numpy as np


def priority(item, bins):
    # Prefer the bin with the largest remaining capacity (emptiest first).
    return bins
