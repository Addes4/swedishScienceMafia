# EVOLVE-BLOCK-START
"""Distribution-aware lookahead fill bin choice.

For each candidate bin we form the residual capacity that would remain and estimate
how well that residual could later be filled by items drawn from the empirical size
distribution seen so far (a running histogram). A bin is scored by the tightness of the
current fit combined with an estimate of the usable fraction of its post-placement
residual, computed by a greedy expected-fill simulation over the running histogram.
"""
import numpy as np

_SIZE = 100


class _Model:
    def __init__(self, decay=0.995):
        # running (exponentially weighted) histogram of item sizes
        self.h = np.ones(_SIZE + 1, dtype=np.float64)  # Laplace smoothing
        self.h[0] = 0.0
        self.total = float(self.h[1:].sum())
        self.decay = decay
        # incremental histogram for fast updates
        self.counts = np.zeros(_SIZE + 1, dtype=np.float64)
        self.counts[1:] = 1.0
        self._n = 0

    def observe(self, item):
        # decay the running histogram and add the new item
        self.h *= self.decay
        self.h[item] += 1.0
        # renormalize occasionally to avoid overflow/underflow drift
        self._n += 1
        if self._n % 256 == 0:
            s = self.h[1:].sum()
            if s > 0:
                self.h[1:] /= s
                self.h[1:] *= 100.0
        self.counts[item] += 1.0

    def probs(self):
        # normalize current running histogram to a pmf over sizes 1..100
        p = self.h[1:].copy()
        s = p.sum()
        if s <= 0:
            return np.full(_SIZE, 1.0 / _SIZE, dtype=np.float64)
        return p / s


_model = _Model()


def _expected_fill(residual, probs):
    """Greedy expected number of items that fit in `residual` drawn from `probs`.

    We use the expected size to approximate how many more items can be packed,
    rewarding residuals that are large enough to hold typical (not just tiny) items.
    """
    if residual <= 0:
        return 0.0
    # mean size under the distribution
    sizes = np.arange(1, _SIZE + 1, dtype=np.float64)
    mean = float(np.dot(probs, sizes))
    if mean <= 0:
        mean = 1.0
    # expected count of items fillable; small residuals near 0 give little value
    return residual / mean


def priority(item, bins):
    """Score bins by tight fit plus expected usefulness of the resulting residual."""
    _model.observe(item)
    probs = _model.probs()
    sizes = np.arange(1, _SIZE + 1, dtype=np.float64)
    mean = float(np.dot(probs, sizes))
    if mean <= 1e-9:
        mean = 1.0

    # residual after placement
    res = bins.astype(np.float64) - float(item)
    # tightness: prefer small residual (best fit); normalized by mean size
    tightness = -res / mean

    # usefulness: reward residuals that can still host ~a typical item
    # saturating term so a huge empty residual isn't over-rewarded
    usefulness = np.minimum(res, mean) / mean

    # fresh bins (residual after placement large) are penalized slightly under the
    # assumption that space will be used by more items; keep dense packing.
    score = tightness + 0.35 * usefulness
    return score
# EVOLVE-BLOCK-END
