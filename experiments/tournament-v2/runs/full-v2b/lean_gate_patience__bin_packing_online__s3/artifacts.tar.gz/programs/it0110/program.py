# EVOLVE-BLOCK-START
"""Classic Best Fit: choose the bin that leaves the smallest residual."""
import numpy as np


def priority(item, bins):
    # residual = remaining capacity after placing the item
    res = bins.astype(np.float64) - float(item)
    # higher score = smaller residual = best fit
    return -res
# EVOLVE-BLOCK-END
