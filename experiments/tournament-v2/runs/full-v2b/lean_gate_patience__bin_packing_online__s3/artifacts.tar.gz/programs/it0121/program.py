# EVOLVE-BLOCK-START
"""Online bin packing with a running histogram of past item sizes.

Scoring rule
------------
For each candidate bin with remaining capacity c, placing the item leaves residual
r = c - item.  We want to pick the bin that is both a tight fit (small r) and whose
residual is likely to be reusable by future items drawn from the observed size
distribution.

We maintain a running histogram of placed item sizes.  From it we estimate, for a
given residual capacity r, an "expected number of items that will fit into r under a
greedy first-fit fill", i.e. a simple lower bound on how many future items could be
packed into that leftover space:

    sort the observed size levels ascending; greedily count how many items can be
    packed into capacity r using the most frequent (or the representative) sizes.

Concretely we compute a fillability value f(r) via a small DP/greedy over the
histogram mass, then combine:

    score = -r  (tightness)  +  alpha * f(r)

where f(r) can be negative (penalty) for large residuals that the distribution
cannot refill usefully, and positive for residuals matching common item sizes.
alpha adapts to item pressure (mean size seen so far).

Package order does not matter for correctness, only the returned scores.
"""

import numpy as np

# Size histogram bins: one bucket per integer size 1..100.
_HIST = np.zeros(101, dtype=np.float64)
_ALPHA = 0.5
_FILL_CACHE = {}


def _expected_fill(residual, mean_size):
    """Estimate how many future items of mean size fill `residual`.

    Uses a smooth estimate: number of items ~ residual / mean_size, but only counting
    capacity that is "reachable", i.e. residual large enough for typical items.
    """
    if residual <= 0:
        return 0.0
    # typical item size ~ mean_size; expected count of items that fit greedily
    return residual / (mean_size + 1e-9)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _HIST, _ALPHA

    bins = np.asarray(bins, dtype=np.float64)
    total = _HIST.sum()
    if total > 0:
        mean_size = float((_HIST * np.arange(101, dtype=np.float64)).sum() / total)
    else:
        mean_size = 40.0

    residuals = bins - item  # residual capacity after placing the item here

    # Tightness term: prefer small residual.
    tight = -residuals

    # Fillability term: reward residuals that can be refilled by future items.
    # expected number of refill items ~ residual / mean_size, but only useful up to
    # a saturation point.  A residual that is a poor match (odd remainder) is
    # penalized via fractional part.
    ratio = residuals / (mean_size + 1e-9)
    n_fill = np.floor(ratio)
    frac = ratio - n_fill
    # Reward integer multiples of typical size (good packing), penalize wasted frac.
    fill = n_fill - 2.0 * frac

    # Fresh bins (residual == 100 - item) get a mild penalty when item pressure is
    # high so that remaining space is preserved for large items.
    fresh = (bins >= 100.0 - 1e-9)
    pressure = min(1.0, mean_size / 50.0)
    fresh_penalty = fresh * (pressure * 5.0)

    score = tight + _ALPHA * fill - fresh_penalty

    # Update histogram with observed item size.
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        if total > 2000:
            _HIST *= 0.999

    return score
# EVOLVE-BLOCK-END
