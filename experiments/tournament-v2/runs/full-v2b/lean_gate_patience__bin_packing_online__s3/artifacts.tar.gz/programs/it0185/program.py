# EVOLVE-BLOCK-START
"""Online bin choice: best-fit with a closing bonus and gap penalty.

Primary rule: place the item into the bin with the smallest post-placement
residual (best fit). Give a large bonus to placements that "close" a bin
(residual below the smallest item seen so far). Add a mild penalty for
residuals just above the closing threshold, which are the most wasteful
slivers, so ties break toward either a fully closed bin or a clearly roomy one.
"""
import numpy as np

_SIZE_MAX = 100

# Smallest item size observed so far (init to a large value).
_min_item = _SIZE_MAX + 1


def priority(item, bins):
    global _min_item
    item = int(item)
    if item < _min_item:
        _min_item = item

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item

    # Best-fit: prefer the smallest non-negative residual.
    score = -residual

    # Closing bonus: residual below smallest observed item => bin is closed.
    closed = (residual >= 0) & (residual < _min_item)
    score = score + closed * _SIZE_MAX

    # Mild penalty for residuals that are just above the closing threshold:
    # these slivers are too small for typical items but not fully closed, so
    # they waste capacity. Prefer either a closed bin or a roomier one.
    t = float(_min_item)
    margin = 2.0 * t
    near = (residual >= t) & (residual < t + margin) & (~closed)
    rel = (residual - t) / margin
    penalty = (1.0 - rel) * 0.5 * t
    score = score - np.where(near, penalty, 0.0)

    # Ensure non-fitting bins are never chosen.
    fits = residual >= 0
    score = np.where(fits, score, -1e9)

    return score
# EVOLVE-BLOCK-END
