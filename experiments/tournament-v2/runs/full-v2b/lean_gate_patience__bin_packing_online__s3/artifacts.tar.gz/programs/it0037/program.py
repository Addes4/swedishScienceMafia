# EVOLVE-BLOCK-START
"""Adaptive scoring that prefers leaving a healthy residual (worst-fit capped) vs pure best-fit."""
import numpy as np


class _State:
    def __init__(self):
        self.mean = 40.0
        self.var = 100.0
        self.count = 0


_state = _State()


def priority(item, bins):
    """Score bins to balance tightness with keeping useful residual room.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin it fits in.
    """
    st = _state

    x = float(item)
    st.count += 1
    alpha = 0.05 if st.count < 200 else 0.01
    delta = x - st.mean
    st.mean += alpha * delta
    st.var += alpha * (delta * delta - st.var)

    std = st.var ** 0.5 if st.var > 0 else 1.0

    # Target residual we'd like to leave behind: close to the mean item size,
    # so the bin remains usable for future items.
    target = st.mean
    # Allow flexibility proportional to the item's own size.
    tol = 0.5 * st.mean + 0.3 * std + 0.5 * x

    residual = bins - item  # post-placement remaining capacity

    # Reward residuals that land near the target band; strongly penalize very
    # small residuals (wasted bin) and very large residuals (fresh bins).
    dist = np.abs(residual - target)
    score = -dist / tol

    # Small extra preference for keeping room when residual exceeds target
    # (avoid filling a roomy bin completely).
    score += 0.1 * np.minimum(residual, 100.0) / 100.0

    # Mild best-fit tiebreaker.
    score += 0.02 * (-residual) / 100.0

    return score
# EVOLVE-BLOCK-END
